const I18N = {
  fr: {
    meta: {
      index: {
        title: "danswholesaleplants | Observations sur l’orientation spatiale",
        description: "Plateforme de recherche bilingue basée à Bruxelles dédiée au guidage numérique, à la signalétique et à l’accessibilité dans les infrastructures publiques complexes."
      },
      services: {
        title: "Méthodologies d’orientation | danswholesaleplants",
        description: "Analyses structurées des défis d’orientation, principes d’information, cartographie des parcours et interfaces de navigation pour les bâtiments publics."
      },
      about: {
        title: "À propos de l’observatoire | danswholesaleplants",
        description: "Découvrez comment danswholesaleplants documente l’UX spatiale, la mobilité piétonne et la gouvernance de la signalétique dans les environnements belges."
      },
      blog: {
        title: "Carnet d’observations sur l’orientation | danswholesaleplants",
        description: "Articles techniques sur la navigation intérieure, les stratégies de signalétique, l’accessibilité et l’analytique spatiale au sein des infrastructures publiques."
      },
      post1: {
        title: "Calibrer l’orientation intérieure dans des bâtiments civiques modulaires",
        description: "Diagnostic, boucles d’évaluation et scénarisation de la signalétique pour des environnements civiques adaptatifs."
      },
      post2: {
        title: "Évaluer l’analytique des flux piétons dans les halls de transit",
        description: "Alignement des jeux de données capteurs et des observations pour éclairer la signalétique et les décisions opérationnelles dans les gares."
      },
      post3: {
        title: "Composer des parcours inclusifs pour des publics multilingues",
        description: "Conception de systèmes d’orientation bilingues et multimodaux au service de visiteurs diversifiés."
      },
      post4: {
        title: "Relier les jumeaux numériques à la recherche UX spatiale",
        description: "Articuler les modèles numériques et les observations terrain pour maintenir un guidage fiable."
      },
      post5: {
        title: "Orchestrer des couches temporelles dans les stratégies d’orientation",
        description: "Structurer le guidage pour le quotidien, les événements et les situations d’urgence grâce à la temporalité."
      },
      contact: {
        title: "Contact | danswholesaleplants",
        description: "Rejoignez l’observatoire bruxellois de l’orientation pour des collaborations, des demandes de documents ou des échanges de recherche."
      },
      faq: {
        title: "FAQ | danswholesaleplants",
        description: "Réponses aux questions fréquentes sur les méthodes de recherche spatiale, les jeux de données et les formats de collaboration."
      },
      terms: {
        title: "Conditions d’utilisation | danswholesaleplants",
        description: "Cadre régissant l’accès aux analyses d’orientation, à la documentation et aux ressources numériques de danswholesaleplants."
      },
      privacy: {
        title: "Notice de confidentialité | danswholesaleplants",
        description: "Informations sur la collecte, l’utilisation, la conservation et les droits liés aux données gérées par danswholesaleplants."
      },
      cookies: {
        title: "Politique de cookies | danswholesaleplants",
        description: "Détails sur les cookies nécessaires, de préférences, analytiques et marketing utilisés par danswholesaleplants."
      },
      refund: {
        title: "Politique de remboursement | danswholesaleplants",
        description: "Explications sur le caractère non commercial des études et sur les conditions d’annulation d’échanges de connaissances."
      },
      disclaimer: {
        title: "Clause de non-responsabilité | danswholesaleplants",
        description: "Précisions sur la portée informative, les limites de responsabilité et les références externes de danswholesaleplants."
      },
      thankYou: {
        title: "Merci | danswholesaleplants",
        description: "Confirmation que votre message a bien été reçu par l’équipe de danswholesaleplants."
      },
      notFound: {
        title: "Page introuvable | danswholesaleplants",
        description: "La page demandée est indisponible sur danswholesaleplants."
      }
    },
    global: {
      brand: "danswholesaleplants",
      nav: {
        home: "Accueil",
        services: "Services",
        about: "À propos",
        blog: "Blog",
        faq: "FAQ",
        contact: "Contact"
      },
      language: {
        fr: "FR",
        en: "EN"
      },
      menuToggleLabel: "Basculer le menu de navigation",
      languageSwitcherLabel: "Sélection de la langue"
    },
    footer: {
      tagline: "Observatoire bruxellois dédié à l’orientation spatiale et à la signalétique numérique.",
      contactTitle: "Coordonnées",
      phoneLabel: "Téléphone :",
      emailLabel: "Courriel :",
      addressLabel: "Adresse :",
      phone: "+32 2 123 45 67",
      email: "contact@danswholesaleplants.com",
      addressLine: "Rue de la Loi 155, 1040 Bruxelles, Belgique",
      manageCookies: "Gérer les préférences de cookies",
      legalTitle: "Références légales",
      links: {
        terms: "Conditions d’utilisation",
        privacy: "Notice de confidentialité",
        cookies: "Politique de cookies",
        refund: "Politique de remboursement",
        disclaimer: "Clause de non-responsabilité"
      },
      copyPrefix: "© danswholesaleplants",
      copySuffix: "Tous droits réservés."
    },
    cookie: {
      title: "Gestion des cookies",
      body: "Nous utilisons des cookies pour garantir le fonctionnement du site, mémoriser vos préférences et observer l’usage afin d’améliorer la navigation. Choisissez vos options ci-dessous.",
      necessary: "Essentiels",
      necessaryDesc: "Toujours actifs pour assurer la sécurité, la session et la conservation de votre langue.",
      preferences: "Préférences",
      preferencesDesc: "Mémorisent vos choix de navigation, comme l’ouverture du menu ou l’ordre des sections.",
      analytics: "Analytiques",
      analyticsDesc: "Aident à comprendre l’audience et les performances des contenus de manière agrégée.",
      marketing: "Marketing",
      marketingDesc: "Réservés pour de futurs contenus externes ; actuellement non activés mais proposés pour transparence.",
      acceptAll: "Tout accepter",
      declineAll: "Tout refuser",
      save: "Enregistrer la sélection"
    },
    toasts: {
      languageSet: "Langue actualisée.",
      cookieAccepted: "Préférences enregistrées : tous les cookies activés.",
      cookieDeclined: "Préférences enregistrées : seuls les cookies essentiels restent actifs.",
      cookieSaved: "Préférences de cookies sauvegardées.",
      formInvalid: "Veuillez compléter les champs requis avant l’envoi.",
      formSubmitting: "Formulaire transmis, redirection en cours."
    },
    home: {
      hero: `<h1>Intelligence d’orientation numérique pour espaces publics complexes</h1>
<p>Nous assemblons données spatiales, observations humaines et intentions architecturales pour concevoir des systèmes d’orientation lisibles face aux fluctuations quotidiennes. Chaque insight est documenté et référencé pour les planificateurs, architectes et équipes d’exploitation.</p>
<div class="hero-actions">
  <a class="button button-primary" href="services.html">Consulter les méthodologies</a>
  <a class="button button-secondary" href="blog.html">Lire les notes récentes</a>
</div>
<ul class="hero-list">
  <li>Cartographier les parcours utilisateurs dans des bâtiments adaptatifs</li>
  <li>Aligner la signalétique numérique sur les attentes des piétons</li>
  <li>Constituer des preuves pour des expériences spatiales inclusives</li>
</ul>`,
      heroVisual: `<img src="https://picsum.photos/seed/wayfinding-hero/900/700" width="900" height="700" alt="Interprétation abstraite d’un atrium civique avec balises numériques" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/900/700';">
<div class="hero-caption glass-panel">
  <p>Fenêtre d’observation autour du noyau de circulation de la Rue de la Loi.</p>
</div>`,
      preamble: `<h2>Des résultats d’orientation structurés par la recherche terrain</h2>
<p>La plateforme enregistre entretiens in situ, comptages de flux et inventaires de signalétique pour révéler la coopération entre couches digitales et physiques. Les enseignements se transforment en cadres modulaires réutilisables par les autorités publiques et institutions culturelles.</p>
<div class="metrics-grid">
  <div class="metric-card glass-panel">
    <span class="metric-value">42 visites de site</span>
    <span class="metric-label">Documentées dans des lieux belges et transfrontaliers depuis 2018</span>
  </div>
  <div class="metric-card glass-panel">
    <span class="metric-value">18 protocoles d’orientation</span>
    <span class="metric-label">Comparés à des critères de lisibilité pour les campus urbains</span>
  </div>
  <div class="metric-card glass-panel">
    <span class="metric-value">9 audits expérientiels</span>
    <span class="metric-label">Expliquant l’interprétation des familles de signes par les visiteurs</span>
  </div>
</div>`,
      features: `<h2>Des cadres d’orientation prêts pour des environnements complexes</h2>
<p>Chaque cadre associe intention architecturale et analytique comportementale pour garantir une navigation intérieure cohérente durant les pointes et les événements spéciaux.</p>
<div class="grid featured-grid">
  <article class="card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/signage-beacon-01/600/420" width="600" height="420" loading="lazy" alt="Balise de signalétique numérique près d’escaliers mécaniques" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/600/420';">
    <h3>Cartographie des traces comportementales</h3>
    <p>Les trajectoires superposées révèlent comment les visiteurs combinent panneaux analogiques, notifications mobiles et affordances architecturales.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/wayfinding-simulation-02/600/420" width="600" height="420" loading="lazy" alt="Tableau de simulation pour des itinéraires de navigation intérieure" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/600/420';">
    <h3>Séquençage narratif adaptatif</h3>
    <p>Des matrices de scénarios coordonnent densité d’information, code couleur et iconographie pour que les familles de signes restent souples sans perdre en clarté.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/interface-orchestration-03/600/420" width="600" height="420" loading="lazy" alt="Composants d’interface illustrant des répertoires réactifs" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/600/420';">
    <h3>Orchestration des interfaces</h3>
    <p>Des systèmes de design relient kiosques, couches mobiles et dispositifs d’assistance pour maintenir des invitations cohérentes dans tout le bâtiment.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/performance-loop-04/600/420" width="600" height="420" loading="lazy" alt="Tableaux de bord mesurant des indicateurs de guidage" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/600/420';">
    <h3>Boucles de rétroaction sur la performance</h3>
    <p>Des tableaux de bord itératifs comparent circulation planifiée et observations réelles, avec un focus sur le temps de parcours, les points d’hésitation et les écarts d’accessibilité.</p>
  </article>
</div>`,
      layers: `<div class="split-layout">
  <div class="split-column glass-panel animate-on-scroll">
    <h2>Lectures de navigation multi-échelles</h2>
    <p>La cartographie macro décrit l’orientation globale tandis que les micro-invitations confirment les décisions aux seuils, ascenseurs et entrées.</p>
    <p>La documentation relie chaque signal aux routines de maintenance pour que la programmation des écrans numériques suive les mises à jour physiques.</p>
  </div>
  <div class="split-column glass-panel animate-on-scroll">
    <h3>Capture de données en mouvement</h3>
    <ul class="styled-list">
      <li>Instantanés temporels montrant les variations entre périodes de pointe et périodes calmes.</li>
      <li>Vérifications des contrastes et de la typographie alignées sur les directives d’accessibilité.</li>
      <li>Tâches de guidage enregistrées avec des publics neurodivers et des aides à la mobilité.</li>
    </ul>
  </div>
</div>`,
      recommendations: `<h2>Recommandations pour des gains rapides de lisibilité</h2>
<p>Ces recommandations synthétisent des observations récurrentes dans des bâtiments publics belges aux flux variables.</p>
<div class="grid recommendation-grid">
  <article class="card glass-panel animate-on-scroll">
    <h3>Prototyper aux points de décision</h3>
    <p>Concentrez les pilotes là où les visiteurs hésitent : carrefours d’accueil, noyaux d’ascenseurs et transitions entre zones sécurisées et publiques.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <h3>Synchroniser mises à jour digitales et physiques</h3>
    <p>Référencez chaque famille de signalétique pour que les responsables de contenu activent le même message sur kiosques, parois et appareils portables.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <h3>Mesurer au-delà de la satisfaction</h3>
    <p>Suivez temps d’achèvement, détours et exceptions d’accessibilité afin de comprendre la performance du guidage sur une semaine complète.</p>
  </article>
</div>`,
      testimonials: `<h2>Témoignages</h2>
<p>Des praticiens expliquent comment la documentation a renforcé leurs décisions de guidage.</p>
<div class="testimonial-grid">
  <figure class="glass-panel animate-on-scroll">
    <blockquote>« Les jeux de données superposés ont clarifié où notre campus hospitalier devait installer des dalles tactiles avant d’étendre la signalétique numérique. »</blockquote>
    <figcaption>Anne Leroy — Stratège infrastructure</figcaption>
  </figure>
  <figure class="glass-panel animate-on-scroll">
    <blockquote>« Associer cartes de densité aux déambulations qualitatives a offert à notre centre culturel une feuille de route pour le multilinguisme. »</blockquote>
    <figcaption>Jonas Verbeeck — Responsable programmation culturelle</figcaption>
  </figure>
  <figure class="glass-panel animate-on-scroll">
    <blockquote>« L’étude a relié déviations temporaires et scripts de routage actualisés, limitant la confusion pendant les rénovations par phases. »</blockquote>
    <figcaption>Elsa Dubois — Coordinatrice travaux publics</figcaption>
  </figure>
</div>`,
      blogTeaser: `<h2>Dernières notes de recherche</h2>
<p>Sélection de lectures décrivant des expérimentations d’orientation récentes.</p>
<div class="blog-preview-grid">
  <article class="blog-preview glass-panel animate-on-scroll">
    <h3>Calibrer l’orientation intérieure dans des bâtiments civiques modulaires</h3>
    <p>Tracer les rythmes de circulation pour coordonner des ensembles de signalétique modulaires.</p>
    <a class="text-link" href="post1.html">Accéder à l’article</a>
  </article>
  <article class="blog-preview glass-panel animate-on-scroll">
    <h3>Évaluer l’analytique des flux piétons dans les halls de transit</h3>
    <p>Relier données capteurs et observation in situ pour un récit équilibré.</p>
    <a class="text-link" href="post2.html">Accéder à l’article</a>
  </article>
  <article class="blog-preview glass-panel animate-on-scroll">
    <h3>Composer des parcours inclusifs pour des publics multilingues</h3>
    <p>Concevoir des informations stratifiées lisibles dans plusieurs langues.</p>
    <a class="text-link" href="post3.html">Accéder à l’article</a>
  </article>
</div>
<a class="button button-ghost" href="blog.html">Explorer le blog complet</a>`
    },
    services: {
      hero: `<h1>Méthodologies d’orientation compilées pour les infrastructures publiques</h1>
<p>Ce répertoire synthétise des étapes reproductibles pour décrypter la signalétique dans les pôles de transport, institutions culturelles et bâtiments administratifs. Utilisez ces notes pour aligner plans architecturaux et parcours vécus.</p>
<div class="hero-actions">
  <a class="button button-primary" href="contact.html">Organiser un échange de connaissances</a>
  <a class="button button-secondary" href="faq.html">Consulter la FAQ</a>
</div>`,
      catalog: `<div class="services-grid">
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Diagnostics d’orientation spatiale</h2>
    <p>La phase de diagnostic débute par plusieurs jours d’immersion dans le bâtiment. Les analystes collectent récits d’entrée, formations de files, zones d’attente et premières références de signalétique. Des notes sensorielles décrivent l’ambiance sonore, les transitions matérielles et la lumière naturelle qui soutiennent ou freinent l’orientation.</p>
    <p>Les livrables incluent des diagrammes superposés reliant observations comportementales et repères physiques. Ils signalent les zones de friction pour cibler les couloirs et seuils à investiguer en priorité.</p>
  </article>
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Principes de design informationnel</h2>
    <p>La bibliothèque de principes rassemble échelles typographiques, jeux d’icônes, contrastes et implantations qui fonctionnent dans les infrastructures publiques belges. Chaque principe renvoie à la norme ou à la directive d’accessibilité correspondante.</p>
    <p>La documentation intègre les cycles de maintenance en détaillant l’influence des adhésifs, éclairages et matériels d’affichage sur la lisibilité durable.</p>
  </article>
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Cartographie des parcours piétons</h2>
    <p>Les cartes de parcours compilent les tâches de résidents, touristes, personnels et prestataires. Elles décrivent les attentes à l’entrée, les séquences de correspondance et les moments où l’assurance est essentielle.</p>
    <p>Chaque carte propose des options de récupération de service pour les visiteurs qui manquent un point de décision, afin de multiplier les repères sans surcharger le paysage visuel.</p>
  </article>
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Interfaces de navigation interactives</h2>
    <p>Les interfaces numériques complètent la signalétique physique via kiosques réactifs, projections et superpositions mobiles. Les prototypes combinent données temps réel et couches de référence statiques.</p>
    <p>Des ateliers réunissent architectes, développeurs et éditeurs de contenu afin de chorégraphier états d’écran, transitions et scénarios d’escalade en cas de perturbation.</p>
  </article>
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Recherche sur les standards d’accessibilité</h2>
    <p>La recherche en accessibilité aligne les dispositifs d’orientation sur les directives européennes et les exigences belges. Les mesures couvrent amplitudes de portée, supports tactiles, aides auditives et seuils de contraste.</p>
    <p>Les conclusions se structurent en registres de conformité qui guident la rédaction des cahiers des charges, la passation des marchés et le suivi continu.</p>
  </article>
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Études de guidage visuel urbain</h2>
    <p>Le guidage extérieur coordonne repères à l’échelle de la ville et informations propres au site. Les études examinent les entonnoirs d’arrivée, la lumière, la végétation et la concurrence des messages.</p>
    <p>Les recommandations se déclinent en plans par phases pour les places, pôles d’échanges et quartiers culturels où les visiteurs passent d’un guidage extérieur à intérieur.</p>
  </article>
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Audits de lisibilité de la signalétique</h2>
    <p>Les audits de lisibilité évaluent familles de signes, marquages au sol et invites numériques pour leur cohérence. Les analystes testent hiérarchies de messages, numérotation et aides à l’orientation telles que plans ou maquettes.</p>
    <p>Les livrables incluent des matrices de priorité indiquant les éléments à redessiner, remplacer ou intégrer dans des routines de maintenance.</p>
  </article>
</div>`,
      approach: `<div class="split-layout">
  <div class="split-column glass-panel animate-on-scroll">
    <h2>Architecture du processus</h2>
    <p>Chaque méthodologie suit un rythme d’exploration, de synthèse et de validation. Les sprints de découverte décrivent l’état présent, la synthèse transforme les observations en cadres et la validation implique les parties prenantes via des parcours commentés et des simulations.</p>
    <ol class="ordered-list">
      <li>Les sprints de découverte collectent preuves visuelles, entretiens et données spatiales.</li>
      <li>Les sessions de synthèse convertissent la matière brute en récits d’orientation stratifiés.</li>
      <li>Les boucles de validation testent ces récits avec des publics représentatifs et des experts en accessibilité.</li>
      <li>La publication assemble les décisions dans des documents traçables.</li>
    </ol>
  </div>
  <div class="split-column glass-panel animate-on-scroll">
    <h3>Artefacts de soutien</h3>
    <ul class="styled-list">
      <li>Matrices d’observation reliant comportements et stimuli environnementaux.</li>
      <li>Échelles typographiques et bibliothèques d’icônes alignées sur les standards d’accessibilité.</li>
      <li>Playbooks opérationnels décrivant rôles, responsabilités et déclencheurs de mise à jour.</li>
    </ul>
    <p>Les artefacts restent modulaires pour être réutilisés lors de futures rénovations ou planifications de scénarios.</p>
  </div>
</div>`,
      frameworks: `<div class="callout glass-panel animate-on-scroll">
  <h2>Gouvernance des cadres</h2>
  <p>Maintenir la qualité du guidage suppose une gouvernance partagée entre design, exploitation et politiques publiques. Nous recensons boucles de retour, circuits d’escalade et instances de pilotage qui alignent les dispositifs avec les objectifs civiques.</p>
  <a class="button button-ghost" href="about.html">Découvrir le contexte organisationnel</a>
</div>`
    },
    about: {
      hero: `<h1>Observatoire bruxellois de l’orientation spatiale</h1>
<p>danswholesaleplants documente la manière dont les personnes se déplacent dans des environnements complexes et comment le design informationnel structure ces déplacements. L’observatoire croise recherche qualitative et données quantitatives pour guider la décision publique.</p>`,
      narrative: `<div class="split-layout">
  <div class="split-column glass-panel animate-on-scroll">
    <h2>Origines</h2>
    <p>L’initiative est née de collaborations entre urbanistes, designers d’interaction et institutions culturelles en quête de parcours visiteurs cohérents. Les premiers projets visaient à concilier signalétique temporaire et architecture permanente lors de rénovations.</p>
    <p>Aujourd’hui l’observatoire entretient un corpus grandissant d’études de cas couvrant musées, hôpitaux, hubs de mobilité et campus civiques en Belgique.</p>
  </div>
  <div class="split-column glass-panel animate-on-scroll">
    <h3>Angles de recherche</h3>
    <ul class="styled-list">
      <li>Collecte d’insights comportementaux par marches ethnographiques et entretiens.</li>
      <li>Audits de design informationnel évaluant clarté, accessibilité et maintenance.</li>
      <li>Approche systémique reliant gouvernance, technologies et cycles architecturaux.</li>
    </ul>
  </div>
</div>`,
      values: `<div class="grid values-grid">
  <article class="card glass-panel animate-on-scroll">
    <h2>La preuve avant l’intuition</h2>
    <p>Nous privilégions les données de terrain afin que chaque recommandation s’appuie sur un comportement observé ou une norme documentée.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <h2>Orientation inclusive</h2>
    <p>Les méthodologies intègrent la diversité des mobilités, des sens et des langues dès la conception plutôt que de corriger a posteriori.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <h2>Gestion transparente</h2>
    <p>Les conclusions sont archivées avec une provenance claire pour que les équipes futures comprennent les décisions passées.</p>
  </article>
</div>`,
      commitments: `<section class="glass-panel animate-on-scroll">
  <h2>Engagements envers les partenaires</h2>
  <p>Les collaborations reposent sur une documentation ouverte, des retours itératifs et une co-rédaction des insights. Les partenaires accèdent aux notes brutes, aux jeux de données structurés et aux gabarits méthodologiques.</p>
  <div class="timeline">
    <div class="timeline-item">
      <span class="timeline-year">2018</span>
      <p>Premier audit d’orientation dans un lieu culturel bruxellois, révélant la nécessité d’une micro-rédaction bilingue.</p>
    </div>
    <div class="timeline-item">
      <span class="timeline-year">2020</span>
      <p>L’ouverture vers des environnements de santé introduit des études de guidage tactile avec des spécialistes de la mobilité.</p>
    </div>
    <div class="timeline-item">
      <span class="timeline-year">2023</span>
      <p>L’intégration des jumeaux numériques renforce la planification de scénarios pour les rénovations complexes.</p>
    </div>
  </div>
</section>`,
      resources: `<div class="callout glass-panel animate-on-scroll">
  <h3>Sessions d’échange de connaissances</h3>
  <p>Des ateliers saisonniers rassemblent équipes municipales pour comparer expérimentations, partager les difficultés et documenter les pratiques transférables.</p>
  <a class="button button-ghost" href="contact.html">Demander les modalités de participation</a>
</div>`
    },
    blog: {
      hero: `<h1>Chroniques de terrain sur l’orientation</h1>
<p>Parcourez les dernières réflexions reliant analytique spatiale, design de signalétique et recherche sur l’accessibilité. Chaque article renvoie vers des ressources supplémentaires.</p>`,
      cards: `<div class="blog-list">
  <article class="blog-card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/blog-card-01/800/520" width="800" height="520" loading="lazy" alt="Atrium intérieur avec signalétique modulaire" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/800/520';">
    <div class="blog-card-body">
      <h2>Calibrer l’orientation intérieure dans des bâtiments civiques modulaires</h2>
      <p class="blog-card-meta">12 février 2024 • Lecture de 9 minutes</p>
      <p>Diagnostic des ancrages d’orientation et chorégraphie de la signalétique modulaire.</p>
      <a class="text-link" href="post1.html">Lire l’article</a>
    </div>
  </article>
  <article class="blog-card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/blog-card-02/800/520" width="800" height="520" loading="lazy" alt="Couloir de transit avec flux piétons" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/800/520';">
    <div class="blog-card-body">
      <h2>Évaluer l’analytique des flux piétons dans les halls de transit</h2>
      <p class="blog-card-meta">18 mars 2024 • Lecture de 8 minutes</p>
      <p>Validation croisée des données capteurs et des observations de terrain pour guider les hubs de transport.</p>
      <a class="text-link" href="post2.html">Lire l’article</a>
    </div>
  </article>
  <article class="blog-card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/blog-card-03/800/520" width="800" height="520" loading="lazy" alt="Cartes multilingues et visiteurs" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/800/520';">
    <div class="blog-card-body">
      <h2>Composer des parcours inclusifs pour des publics multilingues</h2>
      <p class="blog-card-meta">9 avril 2024 • Lecture de 10 minutes</p>
      <p>Stratégies pour coordonner langues, pictogrammes et rituels d’accueil.</p>
      <a class="text-link" href="post3.html">Lire l’article</a>
    </div>
  </article>
  <article class="blog-card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/blog-card-04/800/520" width="800" height="520" loading="lazy" alt="Visualisation 3D d’un jumeau numérique" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/800/520';">
    <div class="blog-card-body">
      <h2>Relier les jumeaux numériques à la recherche UX spatiale</h2>
      <p class="blog-card-meta">2 mai 2024 • Lecture de 11 minutes</p>
      <p>Alignement des modèles numériques et des parcours vécus pour anticiper les scénarios d’exploitation.</p>
      <a class="text-link" href="post4.html">Lire l’article</a>
    </div>
  </article>
  <article class="blog-card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/blog-card-05/800/520" width="800" height="520" loading="lazy" alt="Signalétique temporaire pendant un événement" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/800/520';">
    <div class="blog-card-body">
      <h2>Orchestrer des couches temporelles dans les stratégies d’orientation</h2>
      <p class="blog-card-meta">27 mai 2024 • Lecture de 9 minutes</p>
      <p>Organisation des rythmes quotidiens, événementiels et d’urgence pour maintenir la lisibilité.</p>
      <a class="text-link" href="post5.html">Lire l’article</a>
    </div>
  </article>
</div>
<p class="blog-note">Pour accéder à des archives ou à des études spécifiques, contactez l’équipe via la page dédiée.</p>`
    },
    contact: {
      hero: `<h1>Contacter danswholesaleplants</h1>
<p>Partagez vos questions d’orientation spatiale, demandez de la documentation ou proposez des collaborations centrées sur les environnements publics. Les réponses sont préparées à Bruxelles avec un support bilingue.</p>`,
      details: `<div class="contact-details glass-panel animate-on-scroll" id="contacts">
  <h2>Coordonnées de contact</h2>
  <p><strong>Téléphone :</strong> <a href="tel:+3221234567">+32 2 123 45 67</a></p>
  <p><strong>Courriel :</strong> <a href="mailto:contact@danswholesaleplants.com">contact@danswholesaleplants.com</a></p>
  <p><strong>Adresse :</strong> Rue de la Loi 155, 1040 Bruxelles, Belgique</p>
  <p>Les consultations se font sur rendez-vous afin de garantir la disponibilité des matériaux de recherche.</p>
</div>`,
      map: `<figure class="map-embed glass-panel animate-on-scroll">
  <div class="map-frame">
    <iframe src="https://www.openstreetmap.org/export/embed.html?bbox=4.3780%2C50.8430%2C4.3840%2C50.8470&layer=mapnik&marker=50.8450%2C4.3810" title="Carte de la rue de la Loi 155 à Bruxelles" loading="lazy"></iframe>
  </div>
  <figcaption>Situé dans le quartier européen avec des connexions directes en transport.</figcaption>
</figure>`,
      form: `<p>Décrivez votre contexte afin d’orienter la demande vers le bon axe de recherche.</p>
<div class="form-grid">
  <div class="form-field">
    <label for="name">Nom</label>
    <input type="text" id="name" name="name" required placeholder="Nom complet">
  </div>
  <div class="form-field">
    <label for="email">Courriel</label>
    <input type="email" id="email" name="email" required placeholder="vous@example.com">
  </div>
  <div class="form-field">
    <label for="organisation">Organisation</label>
    <input type="text" id="organisation" name="organisation" placeholder="Institution ou équipe">
  </div>
  <div class="form-field">
    <label for="focus">Domaine d’intérêt</label>
    <select id="focus" name="focus" required>
      <option value="" disabled selected>Sélectionner un sujet</option>
      <option value="wayfinding">Stratégie d’orientation</option>
      <option value="accessibility">Revue d’accessibilité</option>
      <option value="mapping">Cartographie des espaces</option>
      <option value="research">Collaboration de recherche</option>
    </select>
  </div>
</div>
<div class="form-field">
  <label for="message">Message</label>
  <textarea id="message" name="message" rows="6" required placeholder="Décrivez la question d’orientation, le contexte et les livrables souhaités."></textarea>
</div>
<div class="form-field checkbox-field">
  <label>
    <input type="checkbox" name="updates" value="yes">
    <span>Recevoir les synthèses trimestrielles</span>
  </label>
</div>
<button type="submit" class="button button-primary">Envoyer le message</button>
<p class="form-note">En envoyant ce formulaire, vous acceptez les dispositions de notre notice de confidentialité.</p>`
    },
    faq: {
      hero: `<h1>Questions fréquentes</h1>
<p>Cette section couvre le périmètre de la recherche, les modalités de partage des données et la manière dont les observations sont actualisées.</p>`,
      content: `<div class="faq-grid">
  <details class="faq-item glass-panel animate-on-scroll">
    <summary>Comment les données de terrain sont-elles collectées ?</summary>
    <p>Les équipes réalisent des parcours accompagnés, enregistrent des entretiens, effectuent des comptages ponctuels et documentent les repères visuels. Chaque observation est horodatée et reliée à des croquis ou photographies de contexte.</p>
  </details>
  <details class="faq-item glass-panel animate-on-scroll">
    <summary>À quelle fréquence les insights sont-ils mis à jour ?</summary>
    <p>Les synthèses principales sont révisées chaque trimestre tandis que les notes de terrain peuvent évoluer après chaque mission. Les anciennes versions restent archivées pour assurer la traçabilité.</p>
  </details>
  <details class="faq-item glass-panel animate-on-scroll">
    <summary>Quels types de bâtiments sont étudiés ?</summary>
    <p>Nous couvrons musées, campus administratifs, hôpitaux, pôles de mobilité et grands équipements sportifs ou culturels lorsque la circulation piétonne est complexe.</p>
  </details>
  <details class="faq-item glass-panel animate-on-scroll">
    <summary>Comment l’accessibilité est-elle intégrée ?</summary>
    <p>Chaque étude inclut des mesures de contraste, de signalisation tactile, de confort acoustique et des tests utilisateurs avec des personnes aux profils variés.</p>
  </details>
  <details class="faq-item glass-panel animate-on-scroll">
    <summary>Comment participer à une étude ?</summary>
    <p>Les organisations publiques peuvent proposer un site via la page contact. Une réunion de cadrage permet de vérifier l’adéquation avec le programme de recherche.</p>
  </details>
  <details class="faq-item glass-panel animate-on-scroll">
    <summary>Comment sont livrés les matériaux numériques ?</summary>
    <p>Les documents sont remis sous forme de dossiers structurés comprenant formats PDF, jeux de données tabulaires et bibliothèques de design, accompagnés d’un guide d’utilisation.</p>
  </details>
</div>`
    },
    terms: {
      hero: `<h1>Conditions d’utilisation</h1>
<p>Ces conditions encadrent l’accès et la citation des analyses, schémas et publications diffusés par danswholesaleplants.</p>`,
      content: `<section class="legal-section glass-panel animate-on-scroll">
  <h2>1. Champ d’application</h2>
  <p>Les présentes conditions s’appliquent à tout contenu publié sur danswholesaleplants.com et aux fichiers statiques associés. La navigation sur le site vaut acceptation de ce cadre.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>2. Définitions</h2>
  <p>« Observatoire » désigne danswholesaleplants. « Contenus » couvre textes, graphiques, bases de données et supports audiovisuels. « Utilisateur » désigne toute personne consultant ces ressources.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>3. Utilisation des matériaux</h2>
  <p>Les contenus sont fournis à des fins informationnelles. Toute réutilisation doit citer clairement la source et ne peut induire que l’observatoire fournit une prestation opérationnelle.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>4. Contexte de recherche</h2>
  <p>Les publications reflètent un état de recherche en constante évolution. Elles ne constituent ni offre commerciale ni engagement contractuel.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>5. Fiabilité des informations</h2>
  <p>L’observatoire s’efforce d’assurer l’exactitude des données mais ne garantit pas l’exhaustivité. Les utilisateurs restent responsables de vérifier la pertinence pour leur contexte.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>6. Responsabilités des utilisateurs</h2>
  <p>Les utilisateurs s’engagent à ne pas altérer les contenus, à respecter les licences indiquées et à adopter une diffusion conforme aux cadres légaux en vigueur.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>7. Contributions externes</h2>
  <p>Toute contribution envoyée à l’observatoire peut être intégrée aux recherches après validation éditoriale. Les contributeurs garantissent disposer des droits nécessaires.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>8. Accessibilité</h2>
  <p>Nous visons une accessibilité renforcée pour l’ensemble des pages. Les retours sur des obstacles rencontrés sont les bienvenus pour améliorer le site.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>9. Données analytiques</h2>
  <p>Les données anonymisées issues d’outils analytiques servent à améliorer l’expérience. Les détails figurent dans la notice de confidentialité.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>10. Cookies</h2>
  <p>Le fonctionnement du site implique des cookies essentiels et optionnels. Leur gestion est décrite dans la politique de cookies accessible séparément.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>11. Modifications</h2>
  <p>L’observatoire peut adapter ces conditions sans préavis majeur. La date de mise à jour est indiquée en tête de document.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>12. Propriété intellectuelle</h2>
  <p>Sauf mention contraire, les droits restent la propriété de l’observatoire. Les logos de partenaires appartiennent à leurs entités respectives.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>13. Conformité réglementaire</h2>
  <p>Les contenus respectent la législation belge et européenne applicable aux publications numériques publiques.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>14. Contact</h2>
  <p>Les questions relatives à ces conditions peuvent être adressées à contact@danswholesaleplants.com ou via la page de contact.</p>
</section>`
    },
    privacy: {
      hero: `<h1>Notice de confidentialité</h1>
<p>Cette notice décrit les données collectées via danswholesaleplants, leur usage et vos droits associés.</p>`,
      content: `<section class="legal-section glass-panel animate-on-scroll">
  <h2>1. Responsable du traitement</h2>
  <p>Le responsable du traitement est danswholesaleplants, Rue de la Loi 155, 1040 Bruxelles.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>2. Données collectées</h2>
  <p>Nous collectons les informations fournies via les formulaires, ainsi que des données techniques anonymisées telles que type de navigateur et pages consultées.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>3. Méthodes de collecte</h2>
  <p>Les données proviennent directement des utilisateurs ou d’outils analytiques paramétrés pour un suivi agrégé.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>4. Finalités</h2>
  <p>Les données servent à répondre aux demandes, organiser des échanges de connaissances et améliorer la qualité éditoriale du site.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>5. Bases juridiques</h2>
  <p>Le traitement s’appuie sur votre consentement explicite, sur la préparation d’échanges ou sur l’intérêt légitime d’amélioration du service.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>6. Conservation</h2>
  <p>Les informations sont conservées le temps nécessaire pour répondre aux demandes puis archivées de manière pseudonymisée ou supprimées.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>7. Partage</h2>
  <p>Les données ne sont pas cédées à des tiers commerciaux. Des prestataires techniques peuvent intervenir pour l’hébergement ou la maintenance sous accord de confidentialité.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>8. Droits des personnes</h2>
  <p>Vous disposez de droits d’accès, de rectification, d’effacement, de limitation et d’opposition. Adressez vos demandes à contact@danswholesaleplants.com.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>9. Sécurité</h2>
  <p>Nous appliquons des mesures techniques et organisationnelles destinées à protéger les données contre l’accès non autorisé.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>10. Mise à jour de la notice</h2>
  <p>La présente notice peut être actualisée. La date de dernière révision est communiquée en en-tête de document.</p>
</section>`
    },
    cookiesPage: {
      hero: `<h1>Politique de cookies</h1>
<p>Cette page détaille les cookies utilisés sur danswholesaleplants et la manière de gérer vos préférences.</p>`,
      content: `<section class="legal-section glass-panel animate-on-scroll">
  <h2>Résumé général</h2>
  <p>Nous utilisons des cookies essentiels pour garantir la sécurité et la stabilité du site, ainsi que des cookies optionnels pour améliorer l’expérience. Les cookies marketing restent désactivés par défaut.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>Gestion</h2>
  <p>Vous pouvez ajuster vos préférences à tout moment via le panneau accessible depuis le pied de page. Les choix sont stockés localement.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>Tableau des cookies</h2>
  <table>
    <thead>
      <tr>
        <th>Nom</th>
        <th>Fournisseur</th>
        <th>Type</th>
        <th>Finalité</th>
        <th>Durée</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>site_session</td>
        <td>danswholesaleplants</td>
        <td>Essentiel</td>
        <td>Maintenir la session et garantir la sécurité du site.</td>
        <td>Session</td>
      </tr>
      <tr>
        <td>site_lang</td>
        <td>danswholesaleplants</td>
        <td>Préférences</td>
        <td>Mémoriser la langue sélectionnée par l’utilisateur.</td>
        <td>12 mois</td>
      </tr>
      <tr>
        <td>analytics_flow</td>
        <td>danswholesaleplants</td>
        <td>Analytiques</td>
        <td>Mesurer les parcours agrégés et identifier les contenus consultés.</td>
        <td>6 mois</td>
      </tr>
      <tr>
        <td>marketing_slot</td>
        <td>Réservé</td>
        <td>Marketing</td>
        <td>Prévu pour de futurs contenus externes ; inactif à ce jour.</td>
        <td>0 (désactivé)</td>
      </tr>
    </tbody>
  </table>
</section>`
    },
    refund: {
      hero: `<h1>Politique de remboursement</h1>
<p>Ce document précise la nature non commerciale des activités de l’observatoire et les modalités des échanges annulés.</p>`,
      content: `<section class="legal-section glass-panel animate-on-scroll">
  <h2>1. Contexte</h2>
  <p>danswholesaleplants diffuse des analyses et anime des échanges méthodologiques sans vendre de produits ni de prestations marchandes.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>2. Absence de transactions</h2>
  <p>Aucun paiement n’est traité via ce site. Les ressources sont accessibles librement ou sur invitation.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>3. Accès à la documentation</h2>
  <p>Les documents partagés restent disponibles sans facturation. Les demandes de retrait peuvent être adressées par courriel.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>4. Sessions d’échange</h2>
  <p>Les ateliers ou conversations programmés peuvent être annulés ou reportés sans compensation financière.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>5. Annulations</h2>
  <p>Si un participant ne peut assister à une session, il est invité à prévenir pour permettre une reprogrammation.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>6. Matériels externes</h2>
  <p>Les références à des ouvrages ou outils tiers ne constituent pas un engagement d’achat. Chaque organisation reste libre d’y recourir ou non.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>7. Ressources numériques</h2>
  <p>Les accès temporaires à des espaces de partage peuvent être clôturés après la fin d’un cycle de travail, sans remboursement puisqu’aucun paiement n’est perçu.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>8. Retours et feedback</h2>
  <p>Les retours sur les documents ou ateliers sont encouragés afin d’améliorer la qualité. Ils n’ouvrent pas droit à compensation financière.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>9. Mise à jour</h2>
  <p>Cette politique peut évoluer pour clarifier les modalités d’échanges de connaissances.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>10. Contact</h2>
  <p>Pour toute question, écrivez à contact@danswholesaleplants.com.</p>
</section>`
    },
    disclaimer: {
      hero: `<h1>Clause de non-responsabilité</h1>
<p>Cette clause rappelle la portée informative des contenus diffusés par l’observatoire.</p>`,
      content: `<section class="legal-section glass-panel animate-on-scroll">
  <h2>1. Information générale</h2>
  <p>Les contenus sont fournis pour nourrir la réflexion sur l’orientation spatiale et ne constituent pas un avis professionnel individualisé.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>2. Absence de garantie</h2>
  <p>L’observatoire ne garantit pas que les recommandations conviennent à toutes les configurations. Chaque utilisateur doit évaluer leur applicabilité.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>3. Autonomie des décisions</h2>
  <p>Les organismes restent responsables des décisions prises à partir des informations publiées.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>4. Liens externes</h2>
  <p>Les liens vers des ressources tierces sont fournis pour référence. L’observatoire n’a pas de contrôle sur leur contenu.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>5. Limitation de responsabilité</h2>
  <p>L’observatoire ne pourra être tenu responsable de dommages indirects résultant de l’utilisation des informations disponibles.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>6. Mises à jour</h2>
  <p>La clause peut être révisée. Les utilisateurs sont invités à la consulter régulièrement.</p>
</section>`
    },
    thankYou: {
      content: `<div class="glass-panel animate-on-scroll not-found">
  <h1>Merci pour votre message</h1>
  <p>Votre demande a été transmise à l’équipe. Une réponse vous sera adressée dans les meilleurs délais, généralement sous cinq jours ouvrés.</p>
  <a class="button button-primary" href="index.html">Retour à l’accueil</a>
</div>`
    },
    notFound: {
      content: `<div class="glass-panel animate-on-scroll not-found">
  <h1>Page introuvable</h1>
  <p>Le contenu recherché n’est plus disponible ou l’adresse saisie est incorrecte.</p>
  <a class="button button-primary" href="index.html">Explorer le site</a>
</div>`
    },
    posts: {
      post1: `<h1>Calibrer l’orientation intérieure dans des bâtiments civiques modulaires</h1>
<p class="post-meta">Publié le 12 février 2024 • Lecture de 9 minutes</p>
<figure>
  <img src="https://picsum.photos/seed/post1-hero/1200/720" width="1200" height="720" loading="lazy" alt="Atrium modulable avec circulation piétonne" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/1200/720';">
  <figcaption>Modélisation d’un atrium civique où la signalétique doit suivre les reconfigurations.</figcaption>
</figure>
<h2>Interpréter les rythmes spatiaux modulaires</h2>
<p>Les bâtiments civiques modulaires réorganisent fréquemment leurs blocs programmatiques pour accueillir de nouveaux services, des expositions temporaires ou des exigences de sécurité. Chaque réarrangement perturbe les parcours antérieurs et oblige les visiteurs à renégocier leurs repères. La phase initiale de diagnostic cartographie donc la configuration actuelle tout en examinant l’historique des agencements. La consultation des plans d’archives croisée avec les traces capteurs met en évidence les seuils qui demeurent des points d’ancrage malgré les transformations.</p>
<p>Ces bâtiments s’appuient souvent sur des cloisons préfabriquées et des supports de signalétique démontables. Leur flexibilité s’accompagne d’un risque de surcharge visuelle lorsque plusieurs services les mettent à jour indépendamment. Les marches exploratoires inventorient transitions matérielles, éclairage et acoustique afin d’identifier les zones où la densité d’information peut être allégée. Les résultats alimentent une hiérarchie distinguant marqueurs identitaires pérennes et guidages situationnels.</p>
<p>Une stratégie inclusive doit considérer des publics disposant de cartes mentales différentes. Le personnel quotidien n’a besoin de renfort qu’aux embranchements majeurs, tandis que les visiteurs ponctuels souhaitent des confirmations précoces. Pour concilier ces attentes, nous combinons entretiens scénarisés et parcours chronométrés. Le jeu de données indique où la signalétique numérique doit faire écho aux repères statiques et où des invitations tactiles doivent compléter la lecture.</p>
<h3>Boucles d’évaluation itératives</h3>
<p>Les boucles d’évaluation reposent sur la collecte de retours pendant et après la circulation. Des invitations rapides via codes QR et stations physiques permettent de préciser le moment exact de la confusion. Les annotations qualitatives sont mises en regard des comptages et des temps de stationnement afin de vérifier si la perception reflète le comportement observé.</p>
<p>Chaque cycle se conclut par un atelier de chorégraphie des messages réunissant architectes, équipes d’exploitation et maintenance. Ensemble, ils prototypent la séquence d’information pour des trajets critiques tels que l’évacuation, les flux événementiels ou les rendez-vous administratifs. Les simulations mettent en lumière les listes numériques nécessitant des variations horaires et les panneaux statiques devant intégrer des superpositions multilingues.</p>
<p>Enfin, les apprentissages sont synthétisés dans un guide opérationnel modulaire. Il documente les déclencheurs de révision des scripts, l’actualisation des applications et le rafraîchissement des marquages au sol lors de l’arrivée d’un nouvel usage. L’accent est mis sur la traçabilité afin de relier le contexte historique aux déploiements présents et éviter la réapparition de points aveugles.</p>`,
      post2: `<h1>Évaluer l’analytique des flux piétons dans les halls de transit</h1>
<p class="post-meta">Publié le 18 mars 2024 • Lecture de 8 minutes</p>
<figure>
  <img src="https://picsum.photos/seed/post2-hero/1200/720" width="1200" height="720" loading="lazy" alt="Hall de transit animé avec voyageurs" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/1200/720';">
  <figcaption>Observation d’un hall intermodal avec superposition des flux piétons.</figcaption>
</figure>
<h2>Aligner capteurs et observation</h2>
<p>Les halls multimodaux concentrent flux de trains, tramways, bus et couloirs de service. Les plateformes d’analytique promettent de rationaliser cette complexité, mais les données peuvent induire en erreur sans ancrage terrain. L’évaluation commence par cartographier la couverture des capteurs afin de s’assurer que chaque corridor, mezzanine et escalier est représenté. Les zones protégées par le patrimoine ou impactées par des travaux temporaires génèrent souvent des angles morts.</p>
<p>Nous superposons comptages manuels et exercices de shadowing à la carte des capteurs pour valider les bases. Les observateurs notent hésitations, retours en arrière et recours à la signalétique informelle. Ces annotations révèlent la manière dont les voyageurs ressentent les ruptures de seuil, surtout lorsqu’ils passent d’espaces contrôlés à ouverts. Les notes qualitatives expliquent souvent des anomalies dans le tableau de bord, telles qu’un effet d’entonnoir inattendu.</p>
<p>Après synchronisation du jeu de données, l’analyse porte sur la directionnalité. Les logiciels agrègent fréquemment les mouvements, masquant l’asymétrie entre arrivées et départs. Nous isolons les pointes pendulaires, les flux de week-end et les pics événementiels pour comprendre la pression exercée sur la signalétique. La vérification inclut les aides à la mobilité et les voyageurs chargés dont le rythme peut fausser la perception de densité.</p>
<h3>Fabriquer des tableaux de bord actionnables</h3>
<p>Un tableau de bord utile met en avant les variables qui influencent réellement les décisions spatiales. Nous co-concevons les indicateurs avec les gestionnaires de gare, identifiant ceux qui signalent un besoin d’intervention. Une hausse des contre-flux près des escaliers peut par exemple indiquer une signalétique contradictoire, tandis qu’un temps d’attente accru devant les distributeurs révèle une interface confuse.</p>
<p>Pour éviter les réactions tardives, nous intégrons des déclencheurs prédictifs. Les historiques révèlent des tensions récurrentes liées aux travaux ou aux campagnes saisonnières. Convertis en alertes, ces motifs permettent de repositionner les médiateurs et de rafraîchir les messages avant l’apparition de plaintes.</p>
<p>L’évaluation se clôt par un canevas de rapport destiné à d’autres sites de transport. Chaque section documente la provenance des données, les méthodes de calibration et les liens entre analytique et ajustements spatiaux. Partager ce canevas au sein du réseau belge de mobilité alimente des rénovations mieux anticipées.</p>`,
      post3: `<h1>Composer des parcours inclusifs pour des publics multilingues</h1>
<p class="post-meta">Publié le 9 avril 2024 • Lecture de 10 minutes</p>
<figure>
  <img src="https://picsum.photos/seed/post3-hero/1200/720" width="1200" height="720" loading="lazy" alt="Visiteurs consultant une signalétique multilingue" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/1200/720';">
  <figcaption>Analyse des supports bilingues dans un centre culturel bruxellois.</figcaption>
</figure>
<h2>Cadres de communication superposés</h2>
<p>La diversité linguistique belge met à l’épreuve les systèmes d’orientation basés sur le texte. Les visiteurs rencontrent néerlandais, français, allemand ou anglais au sein d’un même site. Notre cadre inclusif commence par recenser les langues nécessaires à chaque segment de parcours et par identifier l’iconographie déjà en place. Cet audit évite les redondances et clarifie les éléments mutualisables.</p>
<p>Nous analysons ensuite les temps de compréhension. Pour les consignes de sécurité, la clarté doit transcender les préférences linguistiques. Des tests rassemblant des groupes représentatifs mesurent le délai nécessaire pour confirmer l’itinéraire. Les retours dévoilent des pictogrammes peu parlants ou des contrastes insuffisants. La démarche s’étend aux annonces sonores et aux interfaces numériques pour garantir une cohérence multimodale.</p>
<p>Le contenu multilingue requiert une gouvernance précise. Nous définissons des modèles de responsabilité assignant la mise à jour des traductions, les circuits de validation et les contrôles qualité. Cette gouvernance évite les divergences terminologiques entre signalétique physique, applications mobiles et plans imprimés. Des stratégies de secours sont prévues lorsque l’urgence impose un déploiement avant traduction complète.</p>
<h3>Rituels inclusifs</h3>
<p>Des rituels renforcent la lisibilité. Nous encourageons hôtes, guides et équipes de sécurité à intégrer des micro-briefings qui reprennent les repères majeurs. Ces interventions incluent gestes vers des points de repère, vérifications rapides de compréhension et rappel de symboles universels.</p>
<p>Pour vérifier l’efficacité, nous conduisons des études longitudinales auprès de visiteurs réguliers. Les questionnaires révèlent les progrès perçus et les zones encore ambiguës. Le retour est comparé aux incidents de désorientation pour ajuster la hiérarchie des messages.</p>
<p>Les résultats se matérialisent dans des boîtes à outils comprenant matrices de traduction, guides de ton et check-lists d’accessibilité. Ces outils encouragent une approche holistique afin que l’inclusion linguistique fasse partie intégrante de l’expérience spatiale.</p>`,
      post4: `<h1>Relier les jumeaux numériques à la recherche UX spatiale</h1>
<p class="post-meta">Publié le 2 mai 2024 • Lecture de 11 minutes</p>
<figure>
  <img src="https://picsum.photos/seed/post4-hero/1200/720" width="1200" height="720" loading="lazy" alt="Simulation numérique d’un bâtiment public" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/1200/720';">
  <figcaption>Un jumeau numérique enrichi d’indicateurs de perception spatiale.</figcaption>
</figure>
<h2>Définir les questions de navigation</h2>
<p>Le jumeau numérique promet une réplique vivante de l’environnement bâti, mais son utilité dépend de sa capacité à refléter les parcours utilisateurs. Nous commençons par formuler les questions de navigation auxquelles le modèle doit répondre : évacuation, trajets quotidiens, visites guidées. Ce cadrage priorise les couches de données à intégrer.</p>
<p>La collecte implique la fusion de fichiers BIM, flux IoT et observations ethnographiques. Les notes qualitatives se traduisent en attributs tels que perception de l’encombrement, confort lumineux ou repères sonores. Leur intégration permet d’analyser des scénarios en tenant compte de la perception humaine.</p>
<p>Une fois le modèle enrichi, nous simulons des itinéraires sous différents régimes d’exploitation. Les pointes soulignent les goulots où la signalétique est masquée. Les scénarios de maintenance révèlent les ruptures de chaîne d’orientation provoquées par des fermetures temporaires. Chaque simulation est documentée par captures et commentaires, constituant une bibliothèque de récits.</p>
<h3>Maintenir l’alignement</h3>
<p>Le jumeau vieillit vite s’il n’est pas alimenté par le terrain. Des réunions de calibration régulières rassemblent responsables de site pour valider les changements de layout, les mises à jour technologiques et les politiques d’exploitation.</p>
<p>Nous invitons également le personnel à comparer leurs routines avec les itinéraires du jumeau. Leurs observations révèlent des normes sociales comme les zones d’attente privilégiées ou les entrées informelles, enrichissant la fidélité du modèle.</p>
<p>Ce dialogue entre jumeau numérique et recherche UX crée un langage partagé entre équipes data et designers. Le jumeau devient un espace de test pour signalétique, éclairage et points de service avant leur mise en œuvre, tout en conservant la mémoire des décisions passées.</p>`,
      post5: `<h1>Orchestrer des couches temporelles dans les stratégies d’orientation</h1>
<p class="post-meta">Publié le 27 mai 2024 • Lecture de 9 minutes</p>
<figure>
  <img src="https://picsum.photos/seed/post5-hero/1200/720" width="1200" height="720" loading="lazy" alt="Signalétique temporaire déployée pour un événement" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/1200/720';">
  <figcaption>Signalétique supplémentaire activée pendant un événement nocturne.</figcaption>
</figure>
<h2>Composer avec la temporalité</h2>
<p>Le guidage ne suit pas une seule temporalité. Les bâtiments doivent répondre aux routines quotidiennes, événements ponctuels et situations d’urgence. Notre approche temporelle débute par un inventaire des scénarios récurrents. Nous identifions les parties prenantes, la durée et les publics concernés.</p>
<p>Chaque scénario reçoit des couches de communication. La signalétique de base reste permanente tandis que des superpositions — alertes numériques, marquages au sol, équipes mobiles — s’activent selon des déclencheurs précis tels que météo ou visite officielle. L’alignement avec les plannings garantit la disponibilité des équipes.</p>
<p>La temporalité impacte aussi les infrastructures. Signalétique mobile, barrières retractables et scénographies lumineuses doivent être stockées et entretenues. Des inventaires détaillent leur localisation et le temps de déploiement. Les registres de maintenance évitent que des supports dégradés nuisent à la crédibilité.</p>
<h3>Tester et capitaliser</h3>
<p>Avant chaque activation, nous réalisons des répétitions pour mesurer la vitesse de transition entre modes d’exploitation. Les tests révèlent des points de friction comme des validations de contenu trop lentes ou des réserves difficilement accessibles.</p>
<p>Les boucles de retour clôturent le processus. Après chaque événement, les équipes consignant ce qui a fonctionné ou non alimentent un historique. Les comparaisons sur plusieurs mois mettent en lumière les lacunes récurrentes, par exemple un besoin accru de signalétique bilingue tardive.</p>
<p>En traitant le temps comme un matériau de conception, les équipes de guidage construisent un service vivant, prêt pour l’imprévu tout en restant clair au quotidien.</p>`
    }
  },
  en: {
    meta: {
      index: {
        title: "danswholesaleplants | Spatial Orientation Insights",
        description: "Bilingual research hub from Brussels covering digital wayfinding, signage design, and accessibility for complex public infrastructures."
      },
      services: {
        title: "Orientation Methodologies | danswholesaleplants",
        description: "Structured analysis of spatial orientation, informational design principles, journey mapping, and interactive navigation research for public buildings."
      },
      about: {
        title: "About the Observatory | danswholesaleplants",
        description: "Learn how danswholesaleplants documents spatial UX, pedestrian mobility, and wayfinding governance across Belgian environments."
      },
      blog: {
        title: "Field Notes on Wayfinding | danswholesaleplants",
        description: "Technical articles examining interior navigation, signage strategy, accessibility, and spatial analytics within public infrastructures."
      },
      post1: {
        title: "Calibrating Indoor Wayfinding in Modular Civic Buildings",
        description: "Exploring diagnostics, evaluation loops, and modular signage choreography for adaptable civic environments."
      },
      post2: {
        title: "Evaluating Pedestrian Flow Analytics in Transit Concourses",
        description: "Aligning sensor datasets with observation to inform wayfinding and operational decisions in transit hubs."
      },
      post3: {
        title: "Composing Inclusive Pathways for Multilingual Audiences",
        description: "Designing bilingual and multimodal orientation systems that support diverse visitors."
      },
      post4: {
        title: "Interfacing Digital Twins with Spatial UX Research",
        description: "Connecting digital twin models with field insights to maintain reliable wayfinding guidance."
      },
      post5: {
        title: "Sequencing Temporal Layers in Wayfinding Strategies",
        description: "Structuring guidance for routine days, special events, and emergencies through temporal layering."
      },
      contact: {
        title: "Contact | danswholesaleplants",
        description: "Reach the Brussels-based orientation observatory for collaboration, documentation requests, or shared research."
      },
      faq: {
        title: "FAQ | danswholesaleplants",
        description: "Answers to common questions about spatial orientation research methods, datasets, and collaboration formats."
      },
      terms: {
        title: "Terms of Use | danswholesaleplants",
        description: "Conditions governing access to orientation insights, documentation, and digital resources hosted by danswholesaleplants."
      },
      privacy: {
        title: "Privacy Notice | danswholesaleplants",
        description: "Information about data collection, usage, storage, and rights relating to the Danswholesaleplants platform."
      },
      cookies: {
        title: "Cookie Policy | danswholesaleplants",
        description: "Details on necessary, preference, analytics, and marketing cookies used on danswholesaleplants."
      },
      refund: {
        title: "Refund Policy | danswholesaleplants",
        description: "Explanation of non-commercial study access and conditions for cancelling knowledge exchanges."
      },
      disclaimer: {
        title: "Disclaimer | danswholesaleplants",
        description: "Clarifications on informational intent, responsibility limits, and external references for danswholesaleplants."
      },
      thankYou: {
        title: "Thank You | danswholesaleplants",
        description: "Confirmation that your message reached the danswholesaleplants team."
      },
      notFound: {
        title: "Page Not Found | danswholesaleplants",
        description: "The requested page could not be located on danswholesaleplants."
      }
    },
    global: {
      brand: "danswholesaleplants",
      nav: {
        home: "Home",
        services: "Services",
        about: "About",
        blog: "Blog",
        faq: "FAQ",
        contact: "Contact"
      },
      language: {
        fr: "FR",
        en: "EN"
      },
      menuToggleLabel: "Toggle navigation menu",
      languageSwitcherLabel: "Language selection"
    },
    footer: {
      tagline: "Brussels observatory focused on spatial orientation and digital wayfinding.",
      contactTitle: "Contact details",
      phoneLabel: "Phone:",
      emailLabel: "Email:",
      addressLabel: "Address:",
      phone: "+32 2 123 45 67",
      email: "contact@danswholesaleplants.com",
      addressLine: "Rue de la Loi 155, 1040 Brussels, Belgium",
      manageCookies: "Manage cookie preferences",
      legalTitle: "Legal references",
      links: {
        terms: "Terms of use",
        privacy: "Privacy notice",
        cookies: "Cookie policy",
        refund: "Refund policy",
        disclaimer: "Disclaimer"
      },
      copyPrefix: "© danswholesaleplants",
      copySuffix: "All rights reserved."
    },
    cookie: {
      title: "Cookie management",
      body: "We use cookies to keep the site secure, remember your preferences, and study aggregated usage to improve navigation. Adjust your settings below.",
      necessary: "Necessary",
      necessaryDesc: "Always on to maintain security, sessions, and your language choice.",
      preferences: "Preferences",
      preferencesDesc: "Remember navigation choices such as menu state or section ordering.",
      analytics: "Analytics",
      analyticsDesc: "Help understand audience patterns and content performance in aggregate.",
      marketing: "Marketing",
      marketingDesc: "Reserved for future external content; currently inactive and listed for transparency.",
      acceptAll: "Accept all",
      declineAll: "Decline all",
      save: "Save selection"
    },
    toasts: {
      languageSet: "Language updated.",
      cookieAccepted: "Preferences saved: all cookies enabled.",
      cookieDeclined: "Preferences saved: only essential cookies remain active.",
      cookieSaved: "Cookie preferences stored.",
      formInvalid: "Please complete the required fields before submitting.",
      formSubmitting: "Message submitted, redirecting."
    },
    home: {
      hero: `<h1>Digital Wayfinding Intelligence for Complex Public Spaces</h1>
<p>We assemble spatial data, human observations, and architectural intent to build orientation systems that remain legible during daily fluctuations. Each insight is documented with references for planners, architects, and operations teams.</p>
<div class="hero-actions">
  <a class="button button-primary" href="services.html">Review methodologies</a>
  <a class="button button-secondary" href="blog.html">Read latest field notes</a>
</div>
<ul class="hero-list">
  <li>Mapping user journeys across adaptive buildings</li>
  <li>Aligning digital signage with pedestrian expectations</li>
  <li>Curating evidence for inclusive spatial experiences</li>
</ul>`,
      heroVisual: `<img src="https://picsum.photos/seed/wayfinding-hero/900/700" width="900" height="700" alt="Abstract rendering of a civic atrium with digital guidance beacons" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/900/700';">
<div class="hero-caption glass-panel">
  <p>Observation window orbiting the circulation core at Rue de la Loi.</p>
</div>`,
      preamble: `<h2>Structured orientation outcomes informed by field research</h2>
<p>The platform records on-site interviews, flow counts, and signage inventories to reveal how digital and physical layers cooperate. Findings are synthesised into modular frameworks that can be reused by public authorities and cultural institutions.</p>
<div class="metrics-grid">
  <div class="metric-card glass-panel">
    <span class="metric-value">42 site walkthroughs</span>
    <span class="metric-label">Documented across Belgian and cross-border venues since 2018</span>
  </div>
  <div class="metric-card glass-panel">
    <span class="metric-value">18 orientation protocols</span>
    <span class="metric-label">Compared to benchmark legibility criteria for urban campuses</span>
  </div>
  <div class="metric-card glass-panel">
    <span class="metric-value">9 experiential audits</span>
    <span class="metric-label">Detailing how visitors interpret layered sign families</span>
  </div>
</div>`,
      features: `<h2>Orientation frameworks ready for complex environments</h2>
<p>Each framework couples architectural intent with behavioural analytics, ensuring that interior navigation remains coherent during peak hours and special events.</p>
<div class="grid featured-grid">
  <article class="card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/signage-beacon-01/600/420" width="600" height="420" loading="lazy" alt="Digital signage beacon adjacent to escalators" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/600/420';">
    <h3>Behavioural trail mapping</h3>
    <p>Layered motion traces reveal how visitors stitch together cues from analogue signage, mobile prompts, and architectural affordances.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/wayfinding-simulation-02/600/420" width="600" height="420" loading="lazy" alt="Simulation dashboard for indoor navigation paths" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/600/420';">
    <h3>Adaptive narrative sequencing</h3>
    <p>Scenario matrices coordinate information density, colour coding, and iconography so that signage families can flex without losing clarity.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/interface-orchestration-03/600/420" width="600" height="420" loading="lazy" alt="Interface components demonstrating responsive directory screens" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/600/420';">
    <h3>Interface orchestration</h3>
    <p>Design tokens bridge kiosks, mobile layers, and assistive devices, enabling consistent navigation prompts throughout a building.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/performance-loop-04/600/420" width="600" height="420" loading="lazy" alt="Performance dashboards measuring wayfinding indicators" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/600/420';">
    <h3>Performance feedback loops</h3>
    <p>Iterative dashboards compare planned circulation with live observations, focusing on dwell time, confusion points, and accessibility gaps.</p>
  </article>
</div>`,
      layers: `<div class="split-layout">
  <div class="split-column glass-panel animate-on-scroll">
    <h2>Multi-scalar navigation insights</h2>
    <p>Macro mapping outlines full building orientation, while micro prompts confirm decisions at thresholds, elevators, and entries.</p>
    <p>Documentation links each signal to maintenance routines, ensuring digital signage schedules align with physical updates.</p>
  </div>
  <div class="split-column glass-panel animate-on-scroll">
    <h3>Data capture in motion</h3>
    <ul class="styled-list">
      <li>Temporal snapshots showing shifts between peak and off-peak circulation.</li>
      <li>Contrast ratios and typography audits aligning with accessibility directives.</li>
      <li>Granular wayfinding tasks recorded with neurodiverse audiences and mobility aids.</li>
    </ul>
  </div>
</div>`,
      recommendations: `<h2>Recommendations for immediate orientation gains</h2>
<p>These recommendations synthesise frequent findings from Belgian public buildings with layered movement patterns.</p>
<div class="grid recommendation-grid">
  <article class="card glass-panel animate-on-scroll">
    <h3>Prototype at decision points</h3>
    <p>Concentrate pilots where visitors hesitate: lobby intersections, lift cores, and transitions between security and public zones.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <h3>Synchronise digital and physical updates</h3>
    <p>Catalogue every signage family, ensuring content managers update the same message set across kiosks, walls, and handheld devices.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <h3>Measure beyond satisfaction</h3>
    <p>Track completion times, rerouting instances, and accessibility exceptions to understand how guidance performs over a full week.</p>
  </article>
</div>`,
      testimonials: `<h2>Testimonials</h2>
<p>Practitioners comment on how the documentation strengthened navigation decisions.</p>
<div class="testimonial-grid">
  <figure class="glass-panel animate-on-scroll">
    <blockquote>“The layered datasets clarified where our hospital campus needed tactile floor inserts before expanding digital signage.”</blockquote>
    <figcaption>Anne Leroy — Infrastructure Strategist</figcaption>
  </figure>
  <figure class="glass-panel animate-on-scroll">
    <blockquote>“Combining path density maps with qualitative walk-throughs gave our cultural centre a roadmap for multilingual messaging.”</blockquote>
    <figcaption>Jonas Verbeeck — Cultural Programming Lead</figcaption>
  </figure>
  <figure class="glass-panel animate-on-scroll">
    <blockquote>“The study linked temporary detours with updated routing scripts, preventing confusion during phased renovations.”</blockquote>
    <figcaption>Elsa Dubois — Public Works Coordinator</figcaption>
  </figure>
</div>`,
      blogTeaser: `<h2>Latest research notes</h2>
<p>Selected readings outlining recent orientation experiments.</p>
<div class="blog-preview-grid">
  <article class="blog-preview glass-panel animate-on-scroll">
    <h3>Calibrating indoor wayfinding in modular civic buildings</h3>
    <p>Tracing circulation rhythms to coordinate modular signage packages.</p>
    <a class="text-link" href="post1.html">Access article</a>
  </article>
  <article class="blog-preview glass-panel animate-on-scroll">
    <h3>Evaluating pedestrian flow analytics in transit concourses</h3>
    <p>Linking sensor data with in-person observation for balanced narratives.</p>
    <a class="text-link" href="post2.html">Access article</a>
  </article>
  <article class="blog-preview glass-panel animate-on-scroll">
    <h3>Composing inclusive pathways for multilingual audiences</h3>
    <p>Designing layered information that remains legible across languages.</p>
    <a class="text-link" href="post3.html">Access article</a>
  </article>
</div>
<a class="button button-ghost" href="blog.html">Explore full blog</a>`
    },
    services: {
      hero: `<h1>Orientation methodologies catalogued for public infrastructures</h1>
<p>This reference library summarises replicable steps for decoding wayfinding within transit hubs, cultural institutions, and administrative buildings. Use these notes to align architectural plans with live user journeys.</p>
<div class="hero-actions">
  <a class="button button-primary" href="contact.html">Coordinate a knowledge exchange</a>
  <a class="button button-secondary" href="faq.html">Review the FAQ</a>
</div>`,
      catalog: `<div class="services-grid">
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Spatial orientation diagnostics</h2>
    <p>The diagnostic sequence begins with multi-day immersion inside the building. Analysts capture entrance narratives, queue formations, dwell hotspots, and first-contact signage. Sensory notes describe sound spillover, material transitions, and daylight variations that either support or hinder navigation.</p>
    <p>Outputs include layered diagrams connecting behavioural insights with physical anchors. These diagrams flag friction zones, enabling future studies to focus on corridors and thresholds that trigger the most detours.</p>
  </article>
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Informational design principles</h2>
    <p>The principles library compiles typography scales, icon sets, contrast ratios, and spatial placements that perform well in Belgian public infrastructures. Each principle references the standards body or accessibility guideline it supports.</p>
    <p>Documentation considers maintenance cycles, detailing how adhesives, lighting fixtures, and display hardware influence long-term legibility.</p>
  </article>
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Pedestrian journey mapping</h2>
    <p>Journey maps assemble tasks from residents, tourists, staff, and service providers. They include entry expectations, transfer sequences, and moments when reassurance is essential.</p>
    <p>Each map proposes service recovery options for visitors who miss a decision point, ensuring alternative cues exist without overwhelming the visual environment.</p>
  </article>
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Interactive navigation interfaces</h2>
    <p>Digital interfaces complement physical signage through responsive kiosks, projection surfaces, and mobile overlays. Prototypes combine real-time data with static reference layers.</p>
    <p>Workshops unite architects, developers, and content editors to choreograph screen states, transitions, and escalation paths in case of disruption.</p>
  </article>
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Accessibility standards research</h2>
    <p>Accessibility research aligns orientation assets with European directives and Belgian regulations. Measurements cover reach ranges, tactile materials, auditory support, and contrast thresholds.</p>
    <p>Findings are organised into compliance registers that guide specification, procurement, and ongoing monitoring.</p>
  </article>
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Urban visual guidance studies</h2>
    <p>Outdoor wayfinding coordinates city-scale cues with site-specific information. Studies examine arrival funnels, lighting conditions, foliage cycles, and competing advertisements.</p>
    <p>Recommendations translate into phased plans for plazas, transit interchanges, and cultural districts where visitors transition between exterior and interior guidance.</p>
  </article>
  <article class="service-card glass-panel animate-on-scroll">
    <h2>Wayfinding readability audits</h2>
    <p>Readability audits evaluate signage families, floor graphics, and digital prompts for consistency. Analysts test message hierarchies, numeration schemes, and orientation aids such as maps or 3D models.</p>
    <p>Deliverables include priority matrices indicating which assets require redesign, replacement, or maintenance routines.</p>
  </article>
</div>`,
      approach: `<div class="split-layout">
  <div class="split-column glass-panel animate-on-scroll">
    <h2>Process architecture</h2>
    <p>Each methodology follows a cadence of exploration, synthesis, and validation. Discovery sprints document the present state, synthesis transforms observations into frameworks, and validation engages stakeholders through walk-throughs and tabletop simulations.</p>
    <ol class="ordered-list">
      <li>Discovery sprints gather evidence with photographs, interviews, and spatial analytics.</li>
      <li>Synthesis sessions convert raw material into layered orientation narratives.</li>
      <li>Validation loops test narratives with representative audiences and accessibility experts.</li>
      <li>Publication consolidates decisions into traceable guidance documents.</li>
    </ol>
  </div>
  <div class="split-column glass-panel animate-on-scroll">
    <h3>Support artifacts</h3>
    <ul class="styled-list">
      <li>Observation matrices documenting behaviour against environmental cues.</li>
      <li>Typographic scales and icon libraries aligned with accessibility standards.</li>
      <li>Operational playbooks describing roles, responsibilities, and update triggers.</li>
    </ul>
    <p>Artifacts remain modular so teams can reuse them during future renovations or scenario planning.</p>
  </div>
</div>`,
      frameworks: `<div class="callout glass-panel animate-on-scroll">
  <h2>Framework stewardship</h2>
  <p>Maintaining orientation quality requires shared stewardship between design, operations, and policy teams. We catalogue feedback loops, escalation paths, and governance boards that keep navigation assets aligned with civic objectives.</p>
  <a class="button button-ghost" href="about.html">View organisational context</a>
</div>`
    },
    about: {
      hero: `<h1>Brussels-based observatory for spatial orientation</h1>
<p>danswholesaleplants documents how people move through complex environments and how information design shapes those movements. The observatory combines qualitative fieldwork with quantitative datasets to guide public decision-makers.</p>`,
      narrative: `<div class="split-layout">
  <div class="split-column glass-panel animate-on-scroll">
    <h2>Origins</h2>
    <p>The initiative emerged from collaborations between urban planners, interaction designers, and cultural institutions seeking coherent visitor journeys. Early projects focused on reconciling temporary signage with permanent architecture during renovations.</p>
    <p>Today the observatory maintains a growing repository of case studies covering museums, hospitals, transit hubs, and civic campuses across Belgium.</p>
  </div>
  <div class="split-column glass-panel animate-on-scroll">
    <h3>Research lenses</h3>
    <ul class="styled-list">
      <li>Behavioural insight collection through ethnographic walks and interviews.</li>
      <li>Information design audits evaluating clarity, accessibility, and maintenance.</li>
      <li>Systems thinking connecting governance, technology, and architectural cycles.</li>
    </ul>
  </div>
</div>`,
      values: `<div class="grid values-grid">
  <article class="card glass-panel animate-on-scroll">
    <h2>Evidence before assumptions</h2>
    <p>We privilege field data over intuition, ensuring each recommendation traces back to observed behaviour or documented standards.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <h2>Inclusive orientation</h2>
    <p>Methodologies incorporate mobility, sensory, and linguistic diversity from the outset rather than retrofitting accessibility.</p>
  </article>
  <article class="card glass-panel animate-on-scroll">
    <h2>Transparent stewardship</h2>
    <p>Findings are archived with clear provenance so future teams understand why and how decisions were made.</p>
  </article>
</div>`,
      commitments: `<section class="glass-panel animate-on-scroll">
  <h2>Commitments for partners</h2>
  <p>Collaborations rely on open documentation, iterative feedback, and shared authorship of insights. Partners access raw notes, structured datasets, and methodological templates.</p>
  <div class="timeline">
    <div class="timeline-item">
      <span class="timeline-year">2018</span>
      <p>Initial spatial orientation audit at a Brussels cultural venue highlighted the need for bilingual microcopy systems.</p>
    </div>
    <div class="timeline-item">
      <span class="timeline-year">2020</span>
      <p>Expansion to healthcare environments introduced tactile guidance studies with mobility specialists.</p>
    </div>
    <div class="timeline-item">
      <span class="timeline-year">2023</span>
      <p>Integration of digital twin analysis strengthened scenario planning for complex renovations.</p>
    </div>
  </div>
</section>`,
      resources: `<div class="callout glass-panel animate-on-scroll">
  <h3>Knowledge exchange sessions</h3>
  <p>Seasonal workshops gather municipal teams to compare orientation experiments, share challenges, and document transferable practices.</p>
  <a class="button button-ghost" href="contact.html">Request participation details</a>
</div>`
    },
    blog: {
      hero: `<h1>Field notes across Belgian infrastructures</h1>
<p>Browse recent reflections linking spatial analytics, signage design, and accessibility research. Each post references further reading and practical frameworks.</p>`,
      cards: `<div class="blog-list">
  <article class="blog-card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/blog-card-01/800/520" width="800" height="520" loading="lazy" alt="Interior atrium with modular signage" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/800/520';">
    <div class="blog-card-body">
      <h2>Calibrating indoor wayfinding in modular civic buildings</h2>
      <p class="blog-card-meta">12 February 2024 • 9 minute read</p>
      <p>Diagnosing orientation anchors and choreographing modular signage systems.</p>
      <a class="text-link" href="post1.html">Read article</a>
    </div>
  </article>
  <article class="blog-card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/blog-card-02/800/520" width="800" height="520" loading="lazy" alt="Transit concourse with travellers" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/800/520';">
    <div class="blog-card-body">
      <h2>Evaluating pedestrian flow analytics in transit concourses</h2>
      <p class="blog-card-meta">18 March 2024 • 8 minute read</p>
      <p>Cross-validating sensor outputs and field observations to guide transport hubs.</p>
      <a class="text-link" href="post2.html">Read article</a>
    </div>
  </article>
  <article class="blog-card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/blog-card-03/800/520" width="800" height="520" loading="lazy" alt="Visitors reading multilingual signage" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/800/520';">
    <div class="blog-card-body">
      <h2>Composing inclusive pathways for multilingual audiences</h2>
      <p class="blog-card-meta">9 April 2024 • 10 minute read</p>
      <p>Strategies for coordinating language layers, pictograms, and host rituals.</p>
      <a class="text-link" href="post3.html">Read article</a>
    </div>
  </article>
  <article class="blog-card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/blog-card-04/800/520" width="800" height="520" loading="lazy" alt="Digital twin visualisation of a public building" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/800/520';">
    <div class="blog-card-body">
      <h2>Interfacing digital twins with spatial UX research</h2>
      <p class="blog-card-meta">2 May 2024 • 11 minute read</p>
      <p>Aligning data models and lived journeys to anticipate operational scenarios.</p>
      <a class="text-link" href="post4.html">Read article</a>
    </div>
  </article>
  <article class="blog-card glass-panel animate-on-scroll">
    <img src="https://picsum.photos/seed/blog-card-05/800/520" width="800" height="520" loading="lazy" alt="Temporary signage deployed for an event" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/800/520';">
    <div class="blog-card-body">
      <h2>Sequencing temporal layers in wayfinding strategies</h2>
      <p class="blog-card-meta">27 May 2024 • 9 minute read</p>
      <p>Coordinating daily, event, and emergency guidance modes without losing clarity.</p>
      <a class="text-link" href="post5.html">Read article</a>
    </div>
  </article>
</div>
<p class="blog-note">For archives or tailored case studies, contact the team through the contact page.</p>`
    },
    contact: {
      hero: `<h1>Contact danswholesaleplants</h1>
<p>Share spatial orientation questions, request documentation, or propose collaborations focused on public environments. Responses originate from Brussels with bilingual support.</p>`,
      details: `<div class="contact-details glass-panel animate-on-scroll" id="contacts">
  <h2>Contact coordinates</h2>
  <p><strong>Phone:</strong> <a href="tel:+3221234567">+32 2 123 45 67</a></p>
  <p><strong>Email:</strong> <a href="mailto:contact@danswholesaleplants.com">contact@danswholesaleplants.com</a></p>
  <p><strong>Address:</strong> Rue de la Loi 155, 1040 Brussels, Belgium</p>
  <p>Visits are scheduled by appointment to ensure research materials are available.</p>
</div>`,
      map: `<figure class="map-embed glass-panel animate-on-scroll">
  <div class="map-frame">
    <iframe src="https://www.openstreetmap.org/export/embed.html?bbox=4.3780%2C50.8430%2C4.3840%2C50.8470&layer=mapnik&marker=50.8450%2C4.3810" title="Map of Rue de la Loi 155, Brussels" loading="lazy"></iframe>
  </div>
  <figcaption>Located in the European district with direct public transit links.</figcaption>
</figure>`,
      form: `<p>Please describe your context so we can direct the request to the right research strand.</p>
<div class="form-grid">
  <div class="form-field">
    <label for="name">Name</label>
    <input type="text" id="name" name="name" required placeholder="Full name">
  </div>
  <div class="form-field">
    <label for="email">Email</label>
    <input type="email" id="email" name="email" required placeholder="you@example.com">
  </div>
  <div class="form-field">
    <label for="organisation">Organisation</label>
    <input type="text" id="organisation" name="organisation" placeholder="Institution or team">
  </div>
  <div class="form-field">
    <label for="focus">Focus area</label>
    <select id="focus" name="focus" required>
      <option value="" disabled selected>Select a topic</option>
      <option value="wayfinding">Wayfinding strategy</option>
      <option value="accessibility">Accessibility review</option>
      <option value="mapping">Space mapping</option>
      <option value="research">Research collaboration</option>
    </select>
  </div>
</div>
<div class="form-field">
  <label for="message">Message</label>
  <textarea id="message" name="message" rows="6" required placeholder="Describe the orientation question, context, and desired deliverables."></textarea>
</div>
<div class="form-field checkbox-field">
  <label>
    <input type="checkbox" name="updates" value="yes">
    <span>Receive quarterly synthesis updates</span>
  </label>
</div>
<button type="submit" class="button button-primary">Submit message</button>
<p class="form-note">By submitting this form you agree to the terms described in our privacy notice.</p>`
    },
    faq: {
      hero: `<h1>Frequently asked questions</h1>
<p>This section outlines the research scope, data sharing arrangements, and how observations stay current.</p>`,
      content: `<div class="faq-grid">
  <details class="faq-item glass-panel animate-on-scroll">
    <summary>How is field data collected?</summary>
    <p>Teams conduct guided walks, record interviews, run spot counts, and document visual cues. Each observation is time-stamped and linked to contextual sketches or photography.</p>
  </details>
  <details class="faq-item glass-panel animate-on-scroll">
    <summary>How often are insights updated?</summary>
    <p>Core syntheses are refreshed quarterly while field notes may change after each mission. Previous versions remain archived for traceability.</p>
  </details>
  <details class="faq-item glass-panel animate-on-scroll">
    <summary>What types of buildings are studied?</summary>
    <p>We cover museums, administrative campuses, hospitals, mobility hubs, and major cultural or sports venues where pedestrian circulation is complex.</p>
  </details>
  <details class="faq-item glass-panel animate-on-scroll">
    <summary>How is accessibility addressed?</summary>
    <p>Every study includes measurements for contrast, tactile guidance, acoustic comfort, and user tests with varied mobility and sensory profiles.</p>
  </details>
  <details class="faq-item glass-panel animate-on-scroll">
    <summary>How can organisations participate?</summary>
    <p>Public bodies can propose a site via the contact page. A scoping call confirms alignment with the research programme.</p>
  </details>
  <details class="faq-item glass-panel animate-on-scroll">
    <summary>How are digital assets delivered?</summary>
    <p>Deliverables include structured folders containing PDFs, tabular datasets, and design libraries, accompanied by a usage guide.</p>
  </details>
</div>`
    },
    terms: {
      hero: `<h1>Terms of use</h1>
<p>These terms regulate how you access and reference the analyses, diagrams, and publications shared by danswholesaleplants.</p>`,
      content: `<section class="legal-section glass-panel animate-on-scroll">
  <h2>1. Scope</h2>
  <p>These terms apply to all content hosted on danswholesaleplants.com and affiliated static files. By browsing the site you acknowledge this framework.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>2. Definitions</h2>
  <p>“Observatory” refers to danswholesaleplants. “Content” covers text, graphics, datasets, and audiovisual assets. “User” refers to any person accessing these resources.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>3. Use of materials</h2>
  <p>Materials are provided for informational purposes. Reuse requires explicit attribution and must not imply that the observatory delivers operational services.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>4. Research context</h2>
  <p>The publications reflect an evolving research state. They do not constitute offers or contractual commitments.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>5. Accuracy</h2>
  <p>The observatory seeks accuracy but cannot guarantee completeness. Users remain responsible for verifying relevance to their context.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>6. User responsibilities</h2>
  <p>Users agree not to alter materials, to respect indicated licences, and to share content in accordance with applicable laws.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>7. External contributions</h2>
  <p>Contributions submitted to the observatory may be incorporated after editorial review. Contributors guarantee they hold the necessary rights.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>8. Accessibility</h2>
  <p>We strive for enhanced accessibility. Feedback about barriers is welcome to improve the site.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>9. Data insights</h2>
  <p>Aggregated analytics support experience improvements. Details appear in the privacy notice.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>10. Cookies</h2>
  <p>The site uses essential and optional cookies. Management options are described in the dedicated cookie policy.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>11. Changes</h2>
  <p>The observatory may update these terms without significant notice. The revision date is displayed at the top of the document.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>12. Intellectual property</h2>
  <p>Unless stated otherwise, rights remain with the observatory. Partner logos belong to their respective entities.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>13. Compliance</h2>
  <p>Content complies with applicable Belgian and EU regulations for public digital publications.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>14. Contact</h2>
  <p>Questions about these terms can be addressed to contact@danswholesaleplants.com or through the contact page.</p>
</section>`
    },
    privacy: {
      hero: `<h1>Privacy notice</h1>
<p>This notice explains the data collected through danswholesaleplants, how it is used, and your related rights.</p>`,
      content: `<section class="legal-section glass-panel animate-on-scroll">
  <h2>1. Controller</h2>
  <p>The data controller is danswholesaleplants, Rue de la Loi 155, 1040 Brussels.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>2. Data collected</h2>
  <p>We collect information supplied through forms and anonymous technical data such as browser type and pages viewed.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>3. Collection methods</h2>
  <p>Data originates directly from users or from analytics tools configured for aggregated monitoring.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>4. Purpose</h2>
  <p>Data supports responses to enquiries, knowledge exchange logistics, and improvements to the site’s editorial quality.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>5. Legal bases</h2>
  <p>Processing is based on your explicit consent, on preparing knowledge exchanges, or on the legitimate interest of improving the service.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>6. Storage</h2>
  <p>Information is retained as long as necessary to address requests, then archived pseudonymously or deleted.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>7. Sharing</h2>
  <p>Data is not sold to commercial parties. Technical providers may access it for hosting or maintenance under confidentiality agreements.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>8. Rights</h2>
  <p>You may exercise rights of access, rectification, erasure, limitation, and objection by emailing contact@danswholesaleplants.com.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>9. Security</h2>
  <p>Technical and organisational measures protect data from unauthorised access.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>10. Updates</h2>
  <p>This notice may be amended. The latest revision date appears at the top of the document.</p>
</section>`
    },
    cookiesPage: {
      hero: `<h1>Cookie policy</h1>
<p>This page details the cookies used on danswholesaleplants and how you can manage them.</p>`,
      content: `<section class="legal-section glass-panel animate-on-scroll">
  <h2>General overview</h2>
  <p>We use essential cookies to keep the site secure and stable, plus optional cookies to improve experience. Marketing cookies remain disabled by default.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>Management</h2>
  <p>Preferences can be adjusted at any time via the control displayed in the footer. Choices are stored locally.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>Cookie table</h2>
  <table>
    <thead>
      <tr>
        <th>Name</th>
        <th>Provider</th>
        <th>Type</th>
        <th>Purpose</th>
        <th>Duration</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>site_session</td>
        <td>danswholesaleplants</td>
        <td>Necessary</td>
        <td>Maintain session integrity and keep the site secure.</td>
        <td>Session</td>
      </tr>
      <tr>
        <td>site_lang</td>
        <td>danswholesaleplants</td>
        <td>Preferences</td>
        <td>Remember the language selected by the user.</td>
        <td>12 months</td>
      </tr>
      <tr>
        <td>analytics_flow</td>
        <td>danswholesaleplants</td>
        <td>Analytics</td>
        <td>Measure aggregated journeys and identify the content reached.</td>
        <td>6 months</td>
      </tr>
      <tr>
        <td>marketing_slot</td>
        <td>Reserved</td>
        <td>Marketing</td>
        <td>Reserved for future external content; currently inactive.</td>
        <td>0 (disabled)</td>
      </tr>
    </tbody>
  </table>
</section>`
    },
    refund: {
      hero: `<h1>Refund policy</h1>
<p>This document clarifies the non-commercial nature of the observatory and the framework for cancelled exchanges.</p>`,
      content: `<section class="legal-section glass-panel animate-on-scroll">
  <h2>1. Context</h2>
  <p>danswholesaleplants publishes analyses and hosts methodological exchanges without selling products or commercial services.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>2. No transactions</h2>
  <p>No payments are processed through this site. Resources are available freely or by invitation.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>3. Documentation access</h2>
  <p>Shared documents remain available without charge. Requests for removal can be sent by email.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>4. Exchanges</h2>
  <p>Workshops or conversations may be cancelled or rescheduled without financial compensation.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>5. Cancellations</h2>
  <p>If a participant cannot attend a session, notifying the team enables timely rescheduling.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>6. External materials</h2>
  <p>References to third-party publications or tools do not imply endorsement or expectation of purchase.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>7. Digital resources</h2>
  <p>Temporary access to shared folders may close once a work cycle ends, with no refund since no payment is collected.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>8. Feedback</h2>
  <p>Feedback on documents or workshops is encouraged to improve quality and does not trigger financial compensation.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>9. Updates</h2>
  <p>This policy may evolve to clarify knowledge exchange procedures.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>10. Contact</h2>
  <p>Questions can be sent to contact@danswholesaleplants.com.</p>
</section>`
    },
    disclaimer: {
      hero: `<h1>Disclaimer</h1>
<p>This statement highlights the informational scope of the observatory’s content.</p>`,
      content: `<section class="legal-section glass-panel animate-on-scroll">
  <h2>1. General information</h2>
  <p>The content is designed to stimulate reflection on spatial orientation and does not represent personalised professional advice.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>2. No guarantees</h2>
  <p>The observatory does not guarantee that recommendations will suit every configuration. Users must assess applicability.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>3. Independent decisions</h2>
  <p>Organisations remain responsible for decisions derived from the published information.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>4. External links</h2>
  <p>Links to third-party resources are provided for reference. The observatory has no control over their content.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>5. Liability</h2>
  <p>The observatory is not liable for indirect damages resulting from the use of the information provided.</p>
</section>
<section class="legal-section glass-panel animate-on-scroll">
  <h2>6. Updates</h2>
  <p>This disclaimer may be revised. Users are invited to consult it regularly.</p>
</section>`
    },
    thankYou: {
      content: `<div class="glass-panel animate-on-scroll not-found">
  <h1>Thank you for your message</h1>
  <p>Your request has been shared with the team. Expect a reply within five business days.</p>
  <a class="button button-primary" href="index.html">Return to home</a>
</div>`
    },
    notFound: {
      content: `<div class="glass-panel animate-on-scroll not-found">
  <h1>Page not found</h1>
  <p>The content you are looking for is unavailable or the URL may be incorrect.</p>
  <a class="button button-primary" href="index.html">Visit the homepage</a>
</div>`
    },
    posts: {
      post1: `<h1>Calibrating Indoor Wayfinding in Modular Civic Buildings</h1>
<p class="post-meta">Published on 12 February 2024 • 9 minute read</p>
<figure>
  <img src="https://picsum.photos/seed/post1-hero/1200/720" width="1200" height="720" loading="lazy" alt="Modular atrium with circulating visitors" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/1200/720';">
  <figcaption>Rendering of a civic atrium where signage must adapt to modular layouts.</figcaption>
</figure>
<h2>Interpreting modular spatial rhythms</h2>
<p>Modular civic buildings frequently reorganise programmatic blocks to absorb new services, temporary exhibitions, or security requirements. Each rearrangement disrupts prior circulation patterns and forces visitors to renegotiate familiar cues. The initial diagnostic phase therefore maps not just the current layout but also the library of historical configurations. Reviewing archival floor plans alongside present-day sensor traces highlights which thresholds act as constant orientation anchors, even when surrounding corridors are reconfigured.</p>
<p>These buildings often rely on prefabricated partitions and demountable signage carriers. While flexible, the components risk becoming visually noisy when multiple departments update them independently. During walkthroughs we catalogue material transitions, lighting conditions, and acoustics to understand where information density can be reduced. The findings feed into a hierarchy that separates persistent identity markers from situational guidance, preventing modular additions from overwhelming the spatial narrative.</p>
<p>An inclusive orientation strategy must account for audiences arriving with different cognitive maps. Staff who traverse the building daily require reinforcement only at branching points, whereas first-time visitors need early confirmation they are on the right track. To address this divergence we pair scenario-based interviews with timed navigation tasks. The resulting dataset indicates where dynamic digital signage should echo static landmarks and where tactile prompts should supplement them.</p>
<h3>Iterative evaluation loops</h3>
<p>Iterative evaluation loops depend on capturing feedback during and after circulation. We prepare quick-response prompts accessible through QR markers and physical comment stations, inviting users to describe the exact moment confusion arose. Qualitative notes are then aligned with occupancy counts and dwell-time sensors to confirm whether perception matches observed behaviour.</p>
<p>Each evaluation cycle ends with a content choreography workshop involving architects, operations staff, and maintenance teams. Together they prototype message sequencing for significant journeys such as emergency egress, event routing, and administrative appointments. By simulating these journeys, the group identifies which digital playlists require time-of-day variations and which static panels need multilingual overlays to remain legible.</p>
<p>Finally, we translate lessons into a modular operations guide. The guide documents trigger points for revising signage scripts, updating wayfinding apps, and renewing floor graphics whenever the building absorbs a new function. Emphasising version control keeps archival context linked to current deployments, enabling future teams to reinterpret the space without repeating orientation blind spots.</p>`,
      post2: `<h1>Evaluating Pedestrian Flow Analytics in Transit Concourses</h1>
<p class="post-meta">Published on 18 March 2024 • 8 minute read</p>
<figure>
  <img src="https://picsum.photos/seed/post2-hero/1200/720" width="1200" height="720" loading="lazy" alt="Transit concourse with travellers" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/1200/720';">
  <figcaption>Multi-modal concourse monitored with layered pedestrian flows.</figcaption>
</figure>
<h2>Aligning sensors with observation</h2>
<p>Transit concourses concentrate intersecting flows from trains, trams, buses, and service corridors. Analytics platforms often promise to rationalise this complexity, yet the data can mislead when not grounded in on-site observation. Our evaluation approach begins by mapping sensor coverage to ensure every corridor, mezzanine, and stair bundle is represented. Gaps frequently appear where heritage architecture prohibits modern hardware or where temporary works disrupt line-of-sight.</p>
<p>We layer manual counts and shadowing exercises onto the sensor map to validate baselines. Observers note qualitative cues such as hesitation, backtracking, and reliance on informal signage. These annotations reveal how passengers experience threshold changes, especially when moving between controlled and open zones. The manual notes often explain anomalies in the analytics dashboard, such as unexpected accumulations in seemingly clear corridors.</p>
<p>Once the dataset is synchronised, we examine directionality. Pedestrian flow software tends to aggregate movements, masking the asymmetry between arrivals and departures. We therefore isolate commute peaks, weekend leisure patterns, and event-based surges to understand how each scenario stresses wayfinding assets differently. The review also checks whether the system recognises mobility aids and luggage carriers whose slower pace can misrepresent congestion.</p>
<h3>Designing actionable dashboards</h3>
<p>Dashboards become effective when they present only the variables that matter to spatial decisions. We co-design panels with station managers, identifying indicators that signal the need for intervention. For example, a rise in counterflow activity near escalators may indicate conflicting signage, while an increase in dwell time near ticket machines might reveal interface confusion.</p>
<p>To avoid reactive adjustments, we integrate predictive triggers. Historical datasets highlight recurring stress points tied to construction cycles or seasonal ticketing campaigns. By converting these patterns into alerts, the concourse team can pre-position stewards and refresh messaging before anomalies become complaints.</p>
<p>The evaluation closes with a reporting template capturing lessons for other transit sites. Each section documents data provenance, calibration methods, and links between analytics and spatial adjustments. Sharing the template across Belgium’s mobility network ensures that future concourse refurbishments start with more precise expectations about data quality and its translation into wayfinding improvements.</p>`,
      post3: `<h1>Composing Inclusive Pathways for Multilingual Audiences</h1>
<p class="post-meta">Published on 9 April 2024 • 10 minute read</p>
<figure>
  <img src="https://picsum.photos/seed/post3-hero/1200/720" width="1200" height="720" loading="lazy" alt="Visitors reading multilingual signage" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/1200/720';">
  <figcaption>Evaluating bilingual supports inside a Brussels cultural centre.</figcaption>
</figure>
<h2>Layered communication frameworks</h2>
<p>Belgium’s linguistic diversity challenges orientation systems that rely on text-heavy signage. Visitors may encounter Dutch, French, German, or English within the same facility. Our inclusive pathway framework starts by cataloguing the languages required for each journey segment and identifying the icons, colours, and tactile cues already in use. This audit prevents redundancy and clarifies which elements can be shared across languages without diluting meaning.</p>
<p>Next we analyse comprehension speeds. For emergency instructions, clarity must transcend language preferences. We run comprehension tests with representative groups, timing how long participants need to confirm their route. Feedback reveals when pictograms lack cultural resonance or when colour contrasts fail accessibility standards. The tests extend to audio announcements and digital interfaces, ensuring multimodal communication remains coherent.</p>
<p>Multilingual content also depends on governance. We establish content ownership models that specify who updates translations, how revisions are validated, and how quality assurance is maintained. Version control avoids inconsistent terminology between physical signage, mobile apps, and printed maps. The governance plan includes fallback strategies when urgent updates must be deployed before translation can be completed.</p>
<h3>Embedding inclusive rituals</h3>
<p>Inclusive pathways benefit from rituals that reaffirm orientation cues. We encourage hosts, guides, and security staff to adopt micro-briefings that reinforce the primary navigation storyline. These briefings include gestures toward landmarks, quick checks for understanding, and references to universally recognisable symbols. Rituals create a human layer that complements digital guidance.</p>
<p>To verify effectiveness, we conduct longitudinal studies tracking repeat visitors. Surveys capture whether people notice improvements and which signals remain ambiguous. We correlate this feedback with incident reports where misdirection occurred, helping teams fine-tune message hierarchies.</p>
<p>Finally, we package outcomes into design toolkits containing translation matrices, tone-of-voice guidelines, and accessibility checklists. Toolkits encourage future projects to approach multilingual orientation holistically, ensuring that language inclusion is woven into the spatial experience rather than appended late in the process.</p>`,
      post4: `<h1>Interfacing Digital Twins with Spatial UX Research</h1>
<p class="post-meta">Published on 2 May 2024 • 11 minute read</p>
<figure>
  <img src="https://picsum.photos/seed/post4-hero/1200/720" width="1200" height="720" loading="lazy" alt="Digital twin simulation of a civic building" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/1200/720';">
  <figcaption>Digital twin enriched with perception-based indicators.</figcaption>
</figure>
<h2>Defining navigation questions</h2>
<p>Digital twins promise a living replica of built environments, yet their usefulness for wayfinding depends on how faithfully they reflect user journeys. When we connect spatial UX research to a twin, we begin by defining the navigation questions the model must answer. Does the team need to evaluate emergency egress, daily commuting patterns, or visitor tours? This focus guides which data layers deserve priority.</p>
<p>Gathering relevant data requires blending architectural BIM files, IoT sensor feeds, and ethnographic insights. We translate qualitative notes into attributes such as perceived clutter, lighting comfort, and audio cues. Embedding these indicators in the digital twin allows scenario analysis to account for human perception rather than only geometric precision.</p>
<p>With the model enriched, we simulate routes under different operating conditions. Peak-hour sequences reveal bottlenecks where signage becomes obscured by crowds. Maintenance scenarios show when temporary closures break wayfinding chains. Each simulation is recorded with screenshots and commentary, building a library of narratives that decision-makers can review without launching the twin themselves.</p>
<h3>Maintaining alignment</h3>
<p>Digital twins age rapidly if they are not tethered to field updates. We institute regular calibration meetings where facility managers confirm layout changes, technology upgrades, and operational policies. These updates ensure the twin remains a reliable companion to on-site audits.</p>
<p>Another ritual involves validating the twin with users who experience the physical space daily. We invite staff to compare routes in the model with their lived routines, noting mismatches or overlooked shortcuts. Their insights often reveal subtle social norms, such as preferred waiting zones or informal entrances, which enrich the twin’s fidelity.</p>
<p>Ultimately, the combination of digital twins and spatial UX research cultivates a shared language between data teams and designers. The twin becomes a staging ground for testing signage, lighting, and service touchpoints before they reach construction. By documenting every iteration, organisations create a durable knowledge base that smooths future upgrades and retains memory of past decisions.</p>`,
      post5: `<h1>Sequencing Temporal Layers in Wayfinding Strategies</h1>
<p class="post-meta">Published on 27 May 2024 • 9 minute read</p>
<figure>
  <img src="https://picsum.photos/seed/post5-hero/1200/720" width="1200" height="720" loading="lazy" alt="Temporary signage deployed for an event" onerror="this.onerror=null; this.src='https://picsum.photos/seed/fallback-'+Math.floor(Math.random()*999999)+'/1200/720';">
  <figcaption>Additional signage activated during a night-time event.</figcaption>
</figure>
<h2>Treating time as a design material</h2>
<p>Wayfinding rarely operates on a single timeline. Buildings accommodate daily routines, special events, and emergency situations that each demand tailored communication. Our temporal layering approach begins with cataloguing every recurring scenario within the venue. We map which stakeholders initiate the scenario, how long it lasts, and which audiences are affected.</p>
<p>Once scenarios are mapped, we assign communication layers. Baseline signage remains constant, while overlays—digital alerts, floor graphics, or ambassadors—activate when needed. We document triggers, such as weather advisories or VIP visits, that instruct teams to deploy additional layers. Aligning triggers with staffing rosters ensures the right people manage each activation.</p>
<p>Temporal layers also affect physical infrastructure. Portable signage, retractable barriers, and lighting presets must be stored and maintained. We create inventories that track where each asset lives and how long deployment takes. Maintenance logs prevent degraded materials from undermining credibility during critical moments.</p>
<h3>Testing rhythms in advance</h3>
<p>Before scenarios unfold, we rehearse transitions. Dry runs move from normal operations to special events and back, timing how quickly each layer appears and disappears. These rehearsals expose friction points, such as slow content approval or inaccessible storage rooms.</p>
<p>Feedback loops close the cycle. After each activation, teams record what worked, what confused visitors, and which resources became strained. Comparing logs across months exposes structural issues, like insufficient bilingual signage for late-night events or underused notification channels.</p>
<p>By treating time as a design material, wayfinding teams craft guidance that adapts gracefully to change. Temporal layering transforms orientation into a living service, preserving clarity during routine days while remaining ready for exceptional circumstances.</p>`
    }
  }
};

const DEFAULT_LANG = "fr";
const LANGUAGE_STORAGE_KEY = "site_lang";
const COOKIE_STORAGE_KEY = "cookie_consent";
let currentLang = DEFAULT_LANG;

const animationObserver = new IntersectionObserver(
  entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("in-view");
        animationObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.15 }
);

function getStoredLanguage() {
  try {
    const stored = localStorage.getItem(LANGUAGE_STORAGE_KEY);
    if (stored && I18N[stored]) {
      return stored;
    }
  } catch (error) {
    console.warn("Unable to access stored language.", error);
  }
  return null;
}

function storeLanguage(lang) {
  try {
    localStorage.setItem(LANGUAGE_STORAGE_KEY, lang);
  } catch (error) {
    console.warn("Unable to store language preference.", error);
  }
}

function getTranslation(dictionary, path) {
  return path.split(".").reduce((acc, key) => (acc && acc[key] !== undefined ? acc[key] : undefined), dictionary);
}

function applyTranslations(lang) {
  const dictionary = I18N[lang];
  if (!dictionary) return;
  document.documentElement.setAttribute("lang", lang);

  document.querySelectorAll("[data-i18n]").forEach(node => {
    const key = node.getAttribute("data-i18n");
    const translation = getTranslation(dictionary, key);
    if (translation !== undefined) {
      node.textContent = translation;
    }
  });

  document.querySelectorAll("[data-i18n-html]").forEach(node => {
    const key = node.getAttribute("data-i18n-html");
    const translation = getTranslation(dictionary, key);
    if (translation !== undefined) {
      node.innerHTML = translation;
    }
  });

  document.querySelectorAll("[data-i18n-aria]").forEach(node => {
    const key = node.getAttribute("data-i18n-aria");
    const translation = getTranslation(dictionary, key);
    if (translation !== undefined) {
      node.setAttribute("aria-label", translation);
    }
  });

  const titleNode = document.querySelector("[data-i18n-title]");
  if (titleNode) {
    const key = titleNode.getAttribute("data-i18n-title");
    const translation = getTranslation(dictionary, key);
    if (translation !== undefined) {
      document.title = translation;
    }
  }

  document.querySelectorAll("[data-i18n-meta]").forEach(node => {
    const key = node.getAttribute("data-i18n-meta");
    const translation = getTranslation(dictionary, key);
    if (translation !== undefined) {
      node.setAttribute("content", translation);
    }
  });

  updateLanguageButtons(lang);
  observeAnimatedElements();
}

function setLanguage(lang, options = {}) {
  if (!I18N[lang]) return;
  currentLang = lang;
  storeLanguage(lang);
  applyTranslations(lang);
  if (!options.silent) {
    showToast(I18N[lang].toasts.languageSet);
  }
}

function updateLanguageButtons(lang) {
  document.querySelectorAll(".language-switcher .lang-btn").forEach(button => {
    const isActive = button.dataset.lang === lang;
    button.classList.toggle("active", isActive);
    button.setAttribute("aria-pressed", isActive ? "true" : "false");
  });
}

function observeAnimatedElements() {
  document.querySelectorAll(".animate-on-scroll").forEach(element => {
    if (!element.dataset.observed) {
      animationObserver.observe(element);
      element.dataset.observed = "true";
    }
  });
}

function initLanguageSwitcher() {
  document.querySelectorAll(".language-switcher .lang-btn").forEach(button => {
    button.addEventListener("click", () => {
      const lang = button.dataset.lang;
      if (lang && lang !== currentLang) {
        setLanguage(lang);
      }
    });
  });
}

function initNavigation() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  if (!toggle || !nav) return;

  toggle.addEventListener("click", () => {
    const expanded = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", (!expanded).toString());
    nav.setAttribute("data-visible", (!expanded).toString());
  });

  nav.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      toggle.setAttribute("aria-expanded", "false");
      nav.setAttribute("data-visible", "false");
    });
  });
}

function showToast(message) {
  const container = document.querySelector(".toast-container");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 400);
  }, 3600);
}

function getStoredCookieState() {
  try {
    const stored = localStorage.getItem(COOKIE_STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.warn("Unable to parse cookie preferences.", error);
  }
  return null;
}

function saveCookieState(state) {
  try {
    localStorage.setItem(COOKIE_STORAGE_KEY, JSON.stringify(state));
  } catch (error) {
    console.warn("Unable to store cookie preferences.", error);
  }
}

function initCookieBanner() {
  const banner = document.querySelector(".cookie-banner");
  if (!banner) return;
  const toggles = banner.querySelectorAll("[data-cookie-type]");
  const acceptBtn = banner.querySelector('[data-cookie-action="accept"]');
  const declineBtn = banner.querySelector('[data-cookie-action="decline"]');
  const saveBtn = banner.querySelector('[data-cookie-action="save"]');

  let state = getStoredCookieState();
  if (!state) {
    state = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      updatedAt: null,
      status: "unset"
    };
    banner.setAttribute("data-hidden", "false");
  } else {
    renderCookieState(toggles, state);
    banner.setAttribute("data-hidden", "true");
  }

  toggles.forEach(toggle => {
    if (toggle.disabled) return;
    toggle.addEventListener("change", () => {
      const type = toggle.dataset.cookieType;
      const checked = toggle.checked;
      state[type] = checked;
      state.updatedAt = new Date().toISOString();
      state.status = "custom";
      saveCookieState(state);
    });
  });

  acceptBtn.addEventListener("click", () => {
    state = {
      necessary: true,
      preferences: true,
      analytics: true,
      marketing: true,
      updatedAt: new Date().toISOString(),
      status: "accepted"
    };
    renderCookieState(toggles, state);
    saveCookieState(state);
    banner.setAttribute("data-hidden", "true");
    showToast(I18N[currentLang].toasts.cookieAccepted);
  });

  declineBtn.addEventListener("click", () => {
    state = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      updatedAt: new Date().toISOString(),
      status: "declined"
    };
    renderCookieState(toggles, state);
    saveCookieState(state);
    banner.setAttribute("data-hidden", "true");
    showToast(I18N[currentLang].toasts.cookieDeclined);
  });

  saveBtn.addEventListener("click", () => {
    state.updatedAt = new Date().toISOString();
    state.status = "custom";
    saveCookieState(state);
    banner.setAttribute("data-hidden", "true");
    showToast(I18N[currentLang].toasts.cookieSaved);
  });

  document.querySelectorAll("[data-open-cookie]").forEach(button => {
    button.addEventListener("click", () => {
      renderCookieState(toggles, state);
      banner.setAttribute("data-hidden", "false");
    });
  });
}

function renderCookieState(toggles, state) {
  toggles.forEach(toggle => {
    const type = toggle.dataset.cookieType;
    if (state[type] !== undefined) {
      toggle.checked = state[type];
    }
  });
}

function initForms() {
  const contactForm = document.querySelector('[data-form="contact"]');
  if (contactForm) {
    contactForm.addEventListener("submit", event => {
      if (!contactForm.checkValidity()) {
        event.preventDefault();
        contactForm.reportValidity();
        showToast(I18N[currentLang].toasts.formInvalid);
      } else {
        showToast(I18N[currentLang].toasts.formSubmitting);
      }
    });
  }
}

function updateCurrentYear() {
  const yearNode = document.getElementById("current-year");
  if (yearNode) {
    yearNode.textContent = new Date().getFullYear().toString();
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const storedLang = getStoredLanguage();
  setLanguage(storedLang || DEFAULT_LANG, { silent: true });
  initLanguageSwitcher();
  initNavigation();
  initCookieBanner();
  initForms();
  updateCurrentYear();
  observeAnimatedElements();
});