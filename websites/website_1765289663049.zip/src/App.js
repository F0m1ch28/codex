```javascript
import React from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/HomePage';
import ArchivesPage from './pages/ArchivesPage';
import StudyPage from './pages/StudyPage';
import InterviewsPage from './pages/InterviewsPage';
import ResourcesPage from './pages/ResourcesPage';
import ContactPage from './pages/ContactPage';
import TermsPage from './pages/TermsPage';
import PrivacyPage from './pages/PrivacyPage';
import CookiePolicyPage from './pages/CookiePolicyPage';
import styles from './App.module.css';

const RouteChangeHandler = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

const App = () => (
  <BrowserRouter>
    <Helmet>
      <title>Historic Streets of France Review</title>
      <meta
        name="description"
        content="Historic Streets of France Review documente et analyse les rues historiques françaises à travers des enquêtes archivistiques et urbaines."
      />
    </Helmet>
    <div className={styles.app}>
      <Header />
      <RouteChangeHandler />
      <main id="contenu-principal" className={styles.mainContent}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/archives" element={<ArchivesPage />} />
          <Route path="/etude/:studySlug" element={<StudyPage />} />
          <Route path="/entretiens" element={<InterviewsPage />} />
          <Route path="/ressources" element={<ResourcesPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/conditions-utilisation" element={<TermsPage />} />
          <Route path="/politique-confidentialite" element={<PrivacyPage />} />
          <Route path="/politique-cookies" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
      <CookieBanner />
    </div>
  </BrowserRouter>
);

export default App;
```