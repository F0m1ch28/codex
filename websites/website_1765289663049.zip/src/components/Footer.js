```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className={styles.footer} aria-label="Pied de page">
      <div className={styles.inner}>
        <div className={styles.columnWide}>
          <h2 className={styles.title}>Historic Streets of France Review</h2>
          <p className={styles.description}>
            La revue analyse les rues historiques françaises à travers des enquêtes archivistiques, des observations de terrain et des entretiens
            avec des spécialistes du patrimoine urbain.
          </p>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Navigation</h3>
          <ul className={styles.list}>
            <li>
              <Link to="/" className={styles.link}>Accueil</Link>
            </li>
            <li>
              <Link to="/archives" className={styles.link}>Archives</Link>
            </li>
            <li>
              <Link to="/entretiens" className={styles.link}>Entretiens</Link>
            </li>
            <li>
              <Link to="/ressources" className={styles.link}>Ressources</Link>
            </li>
            <li>
              <Link to="/contact" className={styles.link}>Contact recherche</Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Coordonnées</h3>
          <p className={styles.contactLine}>
            Courriel :{' '}
            <a href="mailto:recherche@historicstreets-fr-review.org" className={styles.link}>
              recherche@historicstreets-fr-review.org
            </a>
          </p>
          <p className={styles.contactLine}>Temps moyen de réponse : 72 heures ouvrées.</p>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Thématiques clés</h3>
          <ul className={styles.list}>
            <li>Patrimoine urbain</li>
            <li>Évolution architecturale</li>
            <li>Archives municipales</li>
            <li>Mémoire collective</li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <p className={styles.copy}>
          &copy; {currentYear} Historic Streets of France Review. Tous droits réservés.
        </p>
        <div className={styles.bottomLinks}>
          <Link to="/conditions-utilisation" className={styles.bottomLink}>
            Conditions d’utilisation
          </Link>
          <Link to="/politique-confidentialite" className={styles.bottomLink}>
            Politique de confidentialité
          </Link>
          <Link to="/politique-cookies" className={styles.bottomLink}>
            Politique de cookies
          </Link>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
```