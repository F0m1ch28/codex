```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }
    const stored = window.localStorage.getItem('hsfr-cookie-consent');
    if (stored !== 'accepted') {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('hsfr-cookie-consent', 'accepted');
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Information relative aux cookies">
      <p className={styles.text}>
        Le site Historic Streets of France Review utilise des cookies analytiques strictement nécessaires au suivi éditorial.
        Les modalités d’utilisation sont détaillées dans la{' '}
        <Link to="/politique-cookies" className={styles.link}>
          politique relative aux cookies
        </Link>
        .
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Compris
      </button>
    </div>
  );
};

export default CookieBanner;
```