```javascript
import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (!menuOpen) {
      return undefined;
    }
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [menuOpen]);

  const navLinkClass = ({ isActive }) =>
    isActive ? `${styles.navLink} ${styles.navLinkActive}` : styles.navLink;

  const toggleMenu = () => {
    setMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <div className={styles.inner}>
        <div className={styles.logo} aria-label="Historic Streets of France Review">
          Historic Streets of France Review
        </div>
        <button
          type="button"
          className={`${styles.navToggle} ${menuOpen ? styles.navToggleOpen : ''}`}
          onClick={toggleMenu}
          aria-expanded={menuOpen}
          aria-controls="navigation-principale"
          aria-label="Ouvrir le menu principal"
        >
          <span className={styles.toggleBar} />
          <span className={styles.toggleBar} />
          <span className={styles.toggleBar} />
        </button>
        <nav
          id="navigation-principale"
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Navigation principale"
        >
          <ul className={styles.navList}>
            <li className={styles.navItem}>
              <NavLink end to="/" className={navLinkClass} onClick={closeMenu}>
                Accueil
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/archives" className={navLinkClass} onClick={closeMenu}>
                Archives
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/entretiens" className={navLinkClass} onClick={closeMenu}>
                Entretiens
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/ressources" className={navLinkClass} onClick={closeMenu}>
                Ressources
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink to="/contact" className={navLinkClass} onClick={closeMenu}>
                Contact
              </NavLink>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
```