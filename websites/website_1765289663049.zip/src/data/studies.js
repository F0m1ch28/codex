```javascript
const studies = [
  {
    id: 1,
    slug: 'rue-des-archives-paris',
    title: "Rue des Archives, Paris : stratigraphie sociale d'un axe discret",
    subtitle: 'Lecture diachronique du Marais administratif',
    date: '2024-03-12',
    location: 'Paris, 3e arrondissement',
    tags: ['Paris', 'Patrimoine urbain', 'XIXe siècle', 'Archives'],
    excerpt:
      "La rue des Archives révèle, à travers son bâti composite et ses archives municipales, une cohabitation subtile entre mémoire nationale et vie de quartier.",
    image:
      'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=800&q=80',
    imageAlt:
      "Perspective douce sur une rue parisienne pavée entourée d'immeubles historiques",
    heroImage:
      'https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1600&q=80',
    introduction:
      "Dans le quartier du Marais, la rue des Archives s'étire sur un tracé qui agrège des alignements médiévaux, des percées du XIXe siècle et des aménités administratives républicaines. Les registres cadastraux et les cahiers de doléances disponibles aux Archives de Paris attestent d'une rue dont la fonction a progressivement glissé de l'artisanat vers les services publics. L'enquête présentée ici s'intéresse à cette stratigraphie, scrutant le bâti, les mouvements de population et les usages politiques qui ont façonné ce fragment urbain discret mais stratégique.",
    sections: [
      {
        heading: 'Strates topographiques et morphologie héritée',
        paragraphs: [
          "Les plans terriers du XVIIe siècle montrent une voie encore irrégulière, serrée entre des parcelles profondes appartenant à des institutions religieuses. Le cadastre napoléonien introduit une première rationalisation, sans toutefois effacer les décrochements qui rendent la perspective incomparable avec les grands boulevards haussmanniens. L'analyse des coupes longitudinales réalisées par le service d'alignement en 1894 met en évidence une cohabitation rare entre hôtels particuliers préservés et immeubles de rapport structurés sur six niveaux. Les relevés photographiques de Charles Marville corroborent cette lecture, laissant apparaître des façades plâtrières ponctuées de mascarons discrets.",
          "Au-delà de la simple description morphologique, la rue des Archives éclaire la manière dont Paris a géré la transition vers la modernité sans renoncer à certaines permanences. Les archives montrent que les discussions autour de l'élargissement de la voie furent longtemps suspendues à la présence d'archives nationales, contrariées par les contraintes de conservation des documents. L'arbitrage administratif a privilégié la consolidation du bâti existant, préférant la restauration des maçonneries et la mise aux normes des réseaux plutôt qu'une transformation radicale. Cette décision a maintenu une échelle piétonne rare dans le centre de la capitale."
        ],
        image: {
          url: 'https://images.unsplash.com/photo-1529429617124-aee0014817be?auto=format&fit=crop&w=1200&q=80',
          alt: "Plan ancien et documents d'archives étalés sur une table de travail"
        }
      },
      {
        heading: 'Habitat, métiers et sociabilité quotidienne',
        paragraphs: [
          "Les rôles de taille conservés entre 1820 et 1870 attestent de la présence persistante de relieurs, d'orfèvres et de maîtres imprimeurs, tandis que les recensements postérieurs à 1900 révèlent l'installation de fonctionnaires et de gardiens des archives nationales. Cette mutation socioprofessionnelle n'a pas effacé les sociabilités d'atelier : les témoignages de résidents publiés dans La Gazette du Marais décrivent une cohabitation entre le rythme silencieux des salles de lecture et les conversations animées des boucheries de proximité. Les corridors des immeubles se transforment en lieux de médiation, où se négocient les usages du trottoir et la préservation du calme nécessaire au travail archivistique.",
          "L'examen des baux et des plans d'intérieur conservés au fonds 87B indique la présence d'appartements traversants, légèrement remaniés dans les années 1960 pour accueillir des cabinets d'avocats spécialisés en droit patrimonial. Cette dynamique tertiaire a introduit un nouvel équilibre sonore, rythmé par les rendez-vous successifs et les flux d'usagers. Malgré ces transformations, la rue conserve un encadrement commerçant modeste, composé de librairies spécialisées, de relieurs-restaurateurs et d'un café discret fréquenté par les archivistes. Les enquêtes de terrain menées entre 2021 et 2023 confirment la résilience de ces activités, soutenues par une clientèle internationale attachée à la consultation de documents originaux."
        ]
      },
      {
        heading: 'Moments politiques et récits de rue',
        paragraphs: [
          "Les cartons de police du mois de juillet 1789 évoquent la peur de voir les archives incendiées, peur qui conduisit à l'installation temporaire de gardes nationaux à l'angle avec la rue Rambuteau. Plus tard, les mobilisations populaires de 1830 et 1848 s'y matérialisent par des attroupements décrits comme disciplinés, formant des barrières humaines pour protéger les fonds publics. La rue devient un observatoire privilégié du lien entre mémoire nationale et agitation politique, chaque crise rappelant la nécessité d'un accès sécurisé aux documents fondateurs de la République.",
          "Au XXe siècle, la rue des Archives accueille des délégations d'historiens étrangers, notamment lors du congrès international des archivistes en 1956. Les photographies conservées par l'Agence France-Presse montrent des files de chercheurs longeant les façades aux tonalités beiges. Les récits enregistrés auprès d'anciens conservateurs dans les années 1980 soulignent que la rue constitue un décor intangible, rassurant pour les usagers réguliers. Ce sentiment de familiarité se retrouve dans les observations ethnographiques contemporaines, qui décrivent une gestion partagée de l'espace public entre riverains, lecteurs et personnels administratifs."
        ]
      },
      {
        heading: 'Transmission, réhabilitation et usages actuels',
        paragraphs: [
          "La réhabilitation programmée en 2016 a mobilisé un consortium de spécialistes du patrimoine bâti, avec un accent sur l'amélioration thermique des immeubles tout en respectant les menuiseries d'origine. Les procès-verbaux des réunions de chantier témoignent d'un dialogue serré entre architectes du patrimoine, ingénieurs et responsables de conservation. La rue a ainsi bénéficié d'un éclairage nocturne à tonalité chaude, conçu pour valoriser la pierre et faciliter la déambulation des lecteurs quittant les archives en soirée.",
          "Aujourd'hui, la rue des Archives est l'objet de dispositifs participatifs : les panneaux de médiation installés en 2022 proposent des capsules historiques en trois langues, tandis qu'un inventaire participatif des devantures est en cours. Les habitants sollicités soulignent l'importance de maintenir un équilibre entre flux touristiques et activités silencieuses. Cette observation rejoint les recommandations du Plan Local d'Urbanisme bioclimatique, qui préconise des usages mesurés et une intensification douce des rez-de-chaussée, afin de respecter la vocation documentaire et mémorielle de l'axe."
        ],
        image: {
          url: 'https://images.unsplash.com/photo-1519974719765-e6559eac2575?auto=format&fit=crop&w=1200&q=80',
          alt: 'Façades parisiennes illuminées en soirée avec des passants'
        }
      }
    ],
    quote: {
      text:
        "La rue des Archives agit comme un corridor de mémoire : chaque façade signale une étape de la construction républicaine, et les usages actuels démontrent que la lecture de la ville reste un acte collectif.",
      author: "Camille Vasseur, historienne de l’urbanisme, entretien réalisé en septembre 2023"
    },
    conclusion:
      "L'analyse diachronique de la rue des Archives souligne la capacité d'une voie modeste à rassembler des enjeux nationaux. L'équilibre entre conservation documentaire, activités de proximité et interventions architecturales mesurées constitue le fil rouge de son histoire récente. Les archives consultées, croisées avec les observations ethnographiques contemporaines, montrent que la rue demeure un espace de médiation entre mémoire nationale et pratiques quotidiennes. À l'heure où Paris réévalue ses centralités, la rue des Archives offre un laboratoire précieux pour penser la cohabitation de fonctions administratives et d'une vie de quartier attentive aux temporalités lentes.",
    sources: [
      {
        label: "Archives municipales de Paris, fonds 87B : Dossiers de voirie et d'alignement",
        url: 'https://archives.paris.fr/'
      },
      {
        label: 'Bibliothèque nationale de France, Gallica : Album Marville, planches 245-256',
        url: 'https://gallica.bnf.fr/'
      },
      {
        label: 'Conseil de Paris, séance du 15 novembre 2016 : Projet de réhabilitation de la rue des Archives',
        url: 'https://www.paris.fr/'
      }
    ]
  },
  {
    id: 2,
    slug: 'rue-saint-jean-lyon',
    title: 'Rue Saint-Jean, Lyon : continuités médiévales et scénographie contemporaine',
    date: '2024-02-05',
    location: 'Lyon, Vieux-Lyon',
    tags: ['Lyon', 'Patrimoine mondial', 'Médiation culturelle'],
    excerpt:
      "Dans le secteur sauvegardé du Vieux-Lyon, la rue Saint-Jean conjugue traboules, artisans et flux touristiques sous un contrôle patrimonial attentif.",
    image:
      'https://images.unsplash.com/photo-1505761671935-60b3a7427bad?auto=format&fit=crop&w=800&q=80',
    imageAlt: 'Rue étroite du Vieux-Lyon avec façades colorées et passants',
    heroImage:
      'https://images.unsplash.com/photo-1455587734955-081b22074882?auto=format&fit=crop&w=1600&q=80',
    introduction:
      "La rue Saint-Jean constitue l'épine dorsale du Vieux-Lyon, secteur inscrit au patrimoine mondial de l'UNESCO depuis 1998. Les notaires royaux l'ont occupée dès le XVIe siècle, avant que les commerçants spécialisés dans les étoffes fines ne façonnent ses façades colorées. L'étude observe les dispositifs de médiation déployés par la Ville de Lyon pour concilier fréquentation touristique élevée et préservation des structures médiévales.",
    sections: [
      {
        heading: 'Gestion des flux et ouverture des traboules',
        paragraphs: [
          "Les registres municipaux de 1987 indiquent la mise en place de conventions avec les copropriétés pour maintenir l'ouverture de certaines traboules aux heures de visite. Les protocoles imposent un entretien conjoint et un éclairage discret. Les observations de terrain réalisées en 2023 montrent que ces passages demeurent fréquentés, avec une signalétique sobre élaborée par le service du patrimoine. Les étudiants en architecture participant aux visites commentées contribuent à une médiation essentiellement pédagogique.",
          "Les flux touristiques sont régulés par la piétonnisation progressive de l'axe. Les capteurs de fréquentation placés en 2021 renseignent un pic estival à 12 500 passages quotidiens. Les mesures adoptées consistent en des plages horaires dédiées aux livraisons et un dialogue constant avec les artisans. Les ateliers de soierie et les libraires spécialisés profitent de ces arrangements, garantissant un fonctionnement ordinaire malgré la pression touristique."
        ]
      },
      {
        heading: 'Valorisation nocturne et vie de quartier',
        paragraphs: [
          "La programmation nocturne initiée par la Fête des Lumières a transformé la rue Saint-Jean en scène temporaire. Les documents internes de la métropole soulignent la volonté d'éviter une folklorisation excessive. Les projections lumineuses sont limitées aux éléments architecturaux majeurs, tandis que les commerces sont invités à adapter leurs vitrines à une charte patrimoniale. Les riverains, réunis au sein de l'association Saint-Jean Habiter, veillent au respect de la tranquillité nocturne.",
          "Les enquêtes ethnographiques menées auprès des habitants âgés révèlent une appropriation quotidienne toujours forte : la rue reste un corridor de services de proximité, reliant écoles, paroisses et marchés alimentaires. Les ajustements urbains récents — pavés stabilisés, mobilier discret, collecte des déchets à horaires fixes — répondent à cette dimension résidentielle. La rue Saint-Jean apparaît ainsi comme un laboratoire de conciliation entre patrimoine vivant et usages ordinaires."
        ]
      }
    ],
    conclusion:
      "La rue Saint-Jean illustre l'agir concerté des acteurs patrimoniaux lyonnais. La régulation des flux, la vigilance des associations habitantes et l'implication des artisans maintiennent un équilibre délicat. L'expérience offre des enseignements exportables vers d'autres centres historiques confrontés à des fréquentations massives.",
    sources: [
      {
        label: "Ville de Lyon, service du Patrimoine : conventions d'ouverture des traboules, 1987-2022",
        url: 'https://www.lyon.fr/'
      },
      {
        label: 'Inventaire général du patrimoine culturel, Région Auvergne-Rhône-Alpes',
        url: 'https://inventaire.auvergnerhonealpes.fr/'
      }
    ]
  },
  {
    id: 3,
    slug: 'rue-de-la-republique-marseille',
    title: "Rue de la République, Marseille : reconversion d'un axe portuaire",
    date: '2024-01-18',
    location: 'Marseille, 2e arrondissement',
    tags: ['Marseille', 'Aménagement portuaire', 'XXIe siècle'],
    excerpt:
      "Conçue sous le Second Empire pour relier le Vieux-Port aux bassins industriels, la rue de la République fait l'objet d'une requalification progressive orientée vers des usages mixtes.",
    image:
      'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=800&q=80',
    imageAlt: "Boulevard marseillais bordé d'immeubles haussmanniens sous un ciel bleu",
    heroImage:
      'https://images.unsplash.com/photo-1505731132164-cca90383e1af?auto=format&fit=crop&w=1600&q=80',
    introduction:
      "La rue de la République constitue l'une des rares percées haussmanniennes de Marseille. Les archives métropolitaines documentent un projet initialement tourné vers les flux portuaires. Depuis 2005, la ville et l'Établissement Public d'Aménagement Euroméditerranée pilotent une reconversion visant à diversifier les usages et à renforcer l'ancrage résidentiel.",
    sections: [
      {
        heading: 'Réaffectation des rez-de-chaussée',
        paragraphs: [
          "Les études notariales montrent une vacance commerciale élevée au début des années 2000, atteignant 38 % des cellules. Les appels à manifestation d'intérêt lancés en 2010 ont permis d'accueillir des structures culturelles, des coopératives alimentaires et un centre de ressources pour la mémoire portuaire. La charte architecturale impose des vitrines transparentes et des enseignes discrètes.",
          "Les enquêtes menées auprès des habitants du quartier Joliette révèlent une perception contrastée : la montée du coût des loyers inquiète, mais la diversification des services de proximité est perçue comme un progrès. Les associations de locataires ont négocié des clauses anti-spéculation avec certains bailleurs institutionnels, documentées dans les procès-verbaux de 2018."
        ]
      },
      {
        heading: 'Mobilités et continuités portuaires',
        paragraphs: [
          "L'ouverture du tramway T2 en 2016 a redessiné les cheminements piétons. Les comptages réalisés par la métropole attestent d'une augmentation de 22 % des déplacements doux. Parallèlement, les anciennes halles portuaires accueillent des évènements temporaires, renforçant les liens symboliques avec le front de mer.",
          "La rue de la République sert désormais de colonne vertébrale à un quartier en transition. Les projets de végétalisation légère et les programmes artistiques in situ participent à une relecture contemporaine d'un axe longtemps dédié aux convois industriels."
        ]
      }
    ],
    conclusion:
      "La reconversion de la rue de la République montre la complexité d'un héritage haussmannien dans une ville portuaire méditerranéenne. Les arbitrages entre attractivité économique, droits des locataires et mémoire industrielle demeurent au cœur des négociations. Les prochains bilans devront mesurer la capacité de cette rue à fédérer des usages mixtes sans rompre les continuités historiques avec le port.",
    sources: [
      {
        label: 'Euroméditerranée, dossiers de consultation 2010-2023',
        url: 'https://www.euromediterranee.fr/'
      },
      {
        label: 'Métropole Aix-Marseille-Provence, observatoire des mobilités 2023',
        url: 'https://www.ampmetropole.fr/'
      }
    ]
  },
  {
    id: 4,
    slug: 'passage-napolitain-nice',
    title: "Passage Napolitain, Nice : micro-géographie d'un passage couvert",
    date: '2023-12-02',
    location: 'Nice, centre-ville',
    tags: ['Nice', 'Passage couvert', 'Commerces indépendants'],
    excerpt:
      "Discret passage traversant l'îlot Masséna, le Passage Napolitain témoigne d'une forme urbaine hybride entre galerie marchande et ruelle privée.",
    image:
      'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?auto=format&fit=crop&w=800&q=80',
    imageAlt: 'Passage couvert avec lumière douce et petites boutiques',
    heroImage:
      'https://images.unsplash.com/photo-1522337660859-02fbefca4702?auto=format&fit=crop&w=1600&q=80',
    introduction:
      "Aménagé en 1885 pour relier la place Masséna à la rue Gioffredo, le Passage Napolitain a conservé sa verrière originelle et une vingtaine de cellules commerciales. Les registres municipaux mentionnent un dispositif de copropriété complexe associant propriétaires, commerçants et services techniques.",
    sections: [
      {
        heading: 'Régime juridique et entretien',
        paragraphs: [
          "Les procès-verbaux de l'assemblée syndicale révèlent un entretien partagé : la ville assure la verrière, les copropriétaires la mosaïque au sol. Cette gouvernance à plusieurs niveaux garantit la permanence d'un matériau rare dans le centre de Nice.",
          "Les diagnostics patrimoniaux de 2019 identifient des besoins de restauration ciblés : reprise des joints métalliques, traitement anti-sel. Les travaux ont été coordonnés avec la Direction du patrimoine historique afin de préserver les vitrines en bois, témoins du commerce balnéaire de la Belle Époque."
        ]
      },
      {
        heading: 'Vie commerçante discrète',
        paragraphs: [
          "Contrairement aux passages parisiens, le Passage Napolitain maintient un rythme quotidien apaisé. Les boutiques de seconde main, un atelier de restauration de cadres et une librairie italophone composent une offre resserrée. Les enquêtes auprès des commerçants font état d'une clientèle fidèle, composée d'habitants du centre et de travailleurs du Palais de Justice voisin.",
          "La municipalité accompagne cette dynamique par des résidences d'auteurs et des lectures publiques. La programmation culturelle se veut discrète pour ne pas saturer l'espace. Ce modèle met en évidence la capacité d'un passage couvert à fonctionner comme un salon urbain, propice à la contemplation plutôt qu'à la consommation rapide."
        ]
      }
    ],
    conclusion:
      "Le Passage Napolitain illustre une micro-géographie où la gouvernance partagée et les programmations mesurées garantissent une ambiance singulière. L'exemple niçois rappelle que les passages couverts restent des laboratoires pour penser des traversées piétonnes qualitatives dans les centres denses.",
    sources: [
      {
        label: 'Ville de Nice, Direction du patrimoine historique, dossier Passage Napolitain',
        url: 'https://www.nice.fr/'
      },
      {
        label: 'Association Passage Napolitain, comptes rendus 2015-2023',
        url: 'https://www.facebook.com/passagenapolitain/'
      }
    ]
  }
];

export default studies;
```