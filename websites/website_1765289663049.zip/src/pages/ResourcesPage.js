```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ResourcesPage.module.css';

const resourceSections = [
  {
    title: 'Archives publiques',
    description: 'Fonds principaux mobilisés dans les enquêtes récentes.',
    items: [
      {
        name: 'Archives nationales, site de Pierrefitte-sur-Seine',
        detail: 'Séries F/14 et F/21 relatives aux alignements et aux plans parcellaires parisiens.',
        url: 'https://www.archives-nationales.culture.gouv.fr/'
      },
      {
        name: 'Archives municipales de Lyon',
        detail: 'Plans de sauvegarde du Vieux-Lyon, dossiers sur les traboules et conventions d’ouverture.',
        url: 'https://www.lyon.fr/demarche/archives-municipales'
      },
      {
        name: 'Métropole Aix-Marseille-Provence',
        detail: 'Observatoire des mobilités, bilans de l’opération Euroméditerranée.',
        url: 'https://www.ampmetropole.fr/'
      }
    ]
  },
  {
    title: 'Cartographie et iconographie',
    description: 'Ressources utilisées pour visualiser les transformations urbaines.',
    items: [
      {
        name: 'Gallica, Bibliothèque nationale de France',
        detail: 'Plans d’alignement, albums photographiques Marville et cartes historiques numérisées.',
        url: 'https://gallica.bnf.fr/'
      },
      {
        name: 'IGN - Remonter le temps',
        detail: 'Superpositions de cartes anciennes et récentes pour l’analyse des morphologies urbaines.',
        url: 'https://remonterletemps.ign.fr/'
      },
      {
        name: 'Plateforme ArchiDoc',
        detail: 'Corpus de plans d’architectes disponibles sous licence pour la recherche.',
        url: 'https://archidoc.culture.gouv.fr/'
      }
    ]
  },
  {
    title: 'Bibliographie de référence',
    description: 'Sélection d’ouvrages mobilisés pour les cadres théoriques et méthodologiques.',
    items: [
      {
        name: 'Pierre Pinon, “Paris, Biographie d’une capitale”',
        detail: 'Analyse des politiques d’alignement et de la fabrique des rues parisiennes.',
        url: 'https://www.cnrseditions.fr/'
      },
      {
        name: 'Sylvie Des CARS et al., “Les passages couverts parisiens”',
        detail: 'Étude comparative utile pour comprendre les passages provinciaux.',
        url: 'https://www.editionsdupatrimoine.fr/'
      },
      {
        name: 'Michel Lussault, “L’avènement du monde urbain”',
        detail: 'Référentiel théorique pour les enquêtes sur la mémoire et les usages des rues.',
        url: 'https://www.seuil.com/'
      }
    ]
  }
];

const ResourcesPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Ressources et archives | Historic Streets of France Review</title>
      <meta
        name="description"
        content="Cartographie des ressources archivistiques, iconographiques et bibliographiques utilisées par Historic Streets of France Review."
      />
    </Helmet>

    <header className={styles.header}>
      <h1>Ressources et archives</h1>
      <p>
        Les enquêtes reposent sur des fonds documentaires variés. Cette page rassemble les ressources ouvertes consultées régulièrement ainsi que les ouvrages de référence utilisés pour établir les méthodes d’analyse.
      </p>
    </header>

    <div className={styles.sections}>
      {resourceSections.map((section) => (
        <section key={section.title} className={styles.section}>
          <h2>{section.title}</h2>
          <p className={styles.sectionDescription}>{section.description}</p>
          <ul className={styles.list}>
            {section.items.map((item) => (
              <li key={item.name} className={styles.listItem}>
                <h3>{item.name}</h3>
                <p>{item.detail}</p>
                <a href={item.url} target="_blank" rel="noopener noreferrer" className={styles.link}>
                  Consulter la ressource
                </a>
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  </div>
);

export default ResourcesPage;
```