```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPage.module.css';

const TermsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Conditions d’utilisation | Historic Streets of France Review</title>
      <meta
        name="description"
        content="Conditions générales d’utilisation du site Historic Streets of France Review."
      />
    </Helmet>

    <h1>Conditions d’utilisation</h1>
    <p className={styles.intro}>
      Les présentes conditions ont pour objet de définir les modalités d’accès et d’utilisation du site Historic Streets of France Review. En consultant ce site, chaque utilisateur reconnaît avoir pris connaissance des règles ci-dessous.
    </p>

    <section className={styles.section}>
      <h2>1. Objet et champ d’application</h2>
      <p>
        Historic Streets of France Review publie un contenu journalistique et documentaire consacré aux rues historiques françaises. Les présentes conditions s’appliquent à toute personne accédant au site, qu’il s’agisse d’une consultation ponctuelle ou régulière.
      </p>
    </section>

    <section className={styles.section}>
      <h2>2. Accès au site</h2>
      <p>
        L’accès au site est gratuit. Des opérations de maintenance peuvent entraîner une interruption temporaire sans préavis. Historic Streets of France Review ne saurait être tenue pour responsable d’éventuels dommages résultant d’une impossibilité d’accès.
      </p>
    </section>

    <section className={styles.section}>
      <h2>3. Contenu éditorial</h2>
      <p>
        Les articles sont élaborés à partir de sources vérifiées et d’enquêtes archivistiques. Malgré la vigilance éditoriale, des erreurs peuvent subsister. Toute demande de rectification doit être adressée à l’adresse de contact figurant sur la page dédiée.
      </p>
    </section>

    <section className={styles.section}>
      <h2>4. Propriété intellectuelle</h2>
      <p>
        L’ensemble des textes, éléments graphiques et photographies publiés sur le site sont protégés par le droit d’auteur. Toute reproduction intégrale ou partielle requiert l’autorisation écrite de Historic Streets of France Review ou des ayants droit identifiés.
      </p>
    </section>

    <section className={styles.section}>
      <h2>5. Hyperliens</h2>
      <p>
        Le site peut proposer des liens vers d’autres ressources en ligne. Historic Streets of France Review ne contrôle pas ces contenus externes et décline toute responsabilité quant aux informations diffusées par ces sites tiers.
      </p>
    </section>

    <section className={styles.section}>
      <h2>6. Responsabilité de l’utilisateur</h2>
      <p>
        L’utilisateur s’engage à consulter le site dans le respect des lois en vigueur et à ne pas entraver son fonctionnement. Toute tentative d’accès non autorisé aux systèmes d’information est passible de poursuites.
      </p>
    </section>

    <section className={styles.section}>
      <h2>7. Données personnelles</h2>
      <p>
        Les données collectées via le formulaire de contact sont traitées conformément à la politique de confidentialité publiée sur le site. Aucune donnée n’est cédée à des tiers à des fins commerciales.
      </p>
    </section>

    <section className={styles.section}>
      <h2>8. Cookies</h2>
      <p>
        L’utilisation de cookies est décrite dans la politique spécifique accessible depuis le pied de page. La poursuite de la navigation implique l’acceptation de cookies strictement nécessaires.
      </p>
    </section>

    <section className={styles.section}>
      <h2>9. Modification des conditions</h2>
      <p>
        Historic Streets of France Review peut mettre à jour les présentes conditions à tout moment afin de refléter l’évolution du site. La date de mise à jour figure en tête de document lorsque des modifications substantielles interviennent.
      </p>
    </section>

    <section className={styles.section}>
      <h2>10. Droit applicable</h2>
      <p>
        Les présentes conditions sont soumises au droit français. En cas de litige, les tribunaux compétents seront ceux du ressort de la cour d’appel de Paris.
      </p>
    </section>
  </div>
);

export default TermsPage;
```