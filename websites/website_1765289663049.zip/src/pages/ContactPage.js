```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ContactPage.module.css';

const initialFormState = {
  name: '',
  email: '',
  organisation: '',
  subject: '',
  message: ''
};

const ContactPage = () => {
  const [formData, setFormData] = React.useState(initialFormState);
  const [status, setStatus] = React.useState({ type: '', message: '' });
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const trimmed = {
      name: formData.name.trim(),
      email: formData.email.trim(),
      organisation: formData.organisation.trim(),
      subject: formData.subject.trim(),
      message: formData.message.trim()
    };

    if (!trimmed.name || !trimmed.email || !trimmed.message) {
      setStatus({
        type: 'error',
        message: 'Les champs nom, courriel et message sont requis pour instruire la demande.'
      });
      return;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(trimmed.email)) {
      setStatus({
        type: 'error',
        message: 'Le courriel indiqué ne respecte pas le format attendu.'
      });
      return;
    }

    setStatus({ type: 'info', message: 'Transmission en cours...' });
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setStatus({
        type: 'success',
        message:
          'La demande a été transmise. La rédaction répond habituellement sous 72 heures ouvrées.'
      });
      setFormData(initialFormState);
    }, 900);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact recherche | Historic Streets of France Review</title>
        <meta
          name="description"
          content="Coordonnées professionnelles et formulaire de contact pour les recherches menées par Historic Streets of France Review."
        />
      </Helmet>

      <header className={styles.header}>
        <h1>Contact recherche</h1>
        <p>
          Le formulaire ci-dessous est dédié aux sollicitations liées aux enquêtes, aux coopérations entre spécialistes ou aux accès encadrés aux corpus d’archives mentionnés sur le site.
        </p>
        <p className={styles.emailLine}>
          Courriel de référence :{' '}
          <a href="mailto:recherche@historicstreets-fr-review.org">
            recherche@historicstreets-fr-review.org
          </a>
        </p>
      </header>

      <div className={styles.content}>
        <section className={styles.formSection}>
          <h2>Formulaire professionnel</h2>
          <form onSubmit={handleSubmit} className={styles.form} noValidate>
            <div className={styles.fieldGroup}>
              <label htmlFor="name">Nom complet *</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                autoComplete="name"
                required
              />
            </div>
            <div className={styles.fieldGroup}>
              <label htmlFor="email">Courriel professionnel *</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                autoComplete="email"
                required
              />
            </div>
            <div className={styles.fieldGroup}>
              <label htmlFor="organisation">Institution ou organisation</label>
              <input
                id="organisation"
                name="organisation"
                type="text"
                value={formData.organisation}
                onChange={handleChange}
              />
            </div>
            <div className={styles.fieldGroup}>
              <label htmlFor="subject">Objet du message</label>
              <input
                id="subject"
                name="subject"
                type="text"
                value={formData.subject}
                onChange={handleChange}
              />
            </div>
            <div className={styles.fieldGroupFull}>
              <label htmlFor="message">Message détaillé *</label>
              <textarea
                id="message"
                name="message"
                rows={6}
                value={formData.message}
                onChange={handleChange}
                required
              />
            </div>
            <button type="submit" className={styles.button} disabled={isSubmitting}>
              {isSubmitting ? 'Transmission...' : 'Transmettre la demande'}
            </button>
          </form>
          {status.message && (
            <p className={`${styles.status} ${styles[status.type]}`} role="status" aria-live="polite">
              {status.message}
            </p>
          )}
        </section>

        <aside className={styles.infoSection}>
          <h2>Informations pratiques</h2>
          <ul className={styles.list}>
            <li>
              <strong>Traitement des demandes :</strong> la rédaction examine les sollicitations deux fois par semaine afin de préserver le temps de dépouillement.
            </li>
            <li>
              <strong>Priorités :</strong> enquêtes universitaires, projets collaboratifs avec des institutions patrimoniales, demandes de précision sur les sources citées.
            </li>
            <li>
              <strong>Accès aux archives :</strong> toute reproduction ou extraction de document suit les règles des dépôts publics consultés.
            </li>
            <li>
              <strong>Temps de réponse :</strong> une réponse est adressée sous 72 heures ouvrées, hors périodes de fermeture des services d’archives.
            </li>
          </ul>
        </aside>
      </div>
    </div>
  );
};

export default ContactPage;
```