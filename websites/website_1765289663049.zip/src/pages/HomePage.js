```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import studiesData from '../data/studies';
import styles from './HomePage.module.css';

const HomePage = () => {
  const latestStudies = [...studiesData]
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 4);

  const topics = [
    'Patrimoine urbain',
    'Évolution architecturale',
    'Rues emblématiques',
    'Mémoire collective',
    'Archives municipales',
    'Cartographies historiques'
  ];

  const approachColumns = [
    {
      title: 'Lecture archivistique',
      description:
        'Consultation systématique des minutes notariales, des cadastres et des dossiers de voirie afin de restituer la chronologie précise des modifications urbaines.'
    },
    {
      title: 'Observation in situ',
      description:
        'Relevés photographiques, carnets de terrain et mesures de flux piétons permettent de comparer les sources historiques aux usages contemporains.'
    },
    {
      title: 'Analyse experte',
      description:
        'Mise en perspective par des historiens, urbanistes et conservateurs pour qualifier les politiques patrimoniales et les médiations culturelles.'
    }
  ];

  const fieldNotes = [
    { value: '28', label: 'fonds d’archives dépouillés depuis 2022' },
    { value: '64', label: 'cartes et plans géoréférencés étudiés' },
    { value: '19', label: 'entretiens conduits avec des spécialistes locaux' }
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Historic Streets of France Review | Observatoire des rues patrimoniales</title>
        <meta
          name="description"
          content="Historic Streets of France Review offre des analyses journalistiques et archivistiques sur les rues historiques françaises."
        />
      </Helmet>

      <section
        className={styles.heroSection}
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1491557345352-5929e343eb89?auto=format&fit=crop&w=1600&q=80')"
        }}
        role="region"
        aria-labelledby="hero-heading"
      >
        <div className={styles.heroOverlay}>
          <div className={styles.heroContent}>
            <h1 id="hero-heading">Historic Streets of France Review</h1>
            <p className={styles.heroSubtitle}>Observatoire journalistique des rues historiques françaises</p>
            <p className={styles.heroText}>
              La revue Historic Streets of France Review documente les continuités urbaines, la stratigraphie sociale et les médiations culturelles qui accompagnent les rues patrimoniales. Les enquêtes croisent dépouillements d’archives, analyses morphologiques et regards d’experts.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionInner}>
          <h2 className={styles.sectionTitle}>Mission éditoriale</h2>
          <p className={styles.sectionDescription}>
            La publication s’intéresse aux rues françaises dont la valeur patrimoniale résulte de strates historiques, d’usages variés et d’enjeux sociaux évolutifs. Chaque dossier se construit à partir d’un protocole rigoureux qui associe archives municipales, cartographies anciennes et observation de terrain.
          </p>
          <div className={styles.aboutGrid}>
            <article className={styles.aboutCard}>
              <h3>Documentation longue durée</h3>
              <p>
                Les dossiers s’appuient sur des séries d’archives couvrant plusieurs siècles afin d’identifier les inflexions réglementaires, les transformations du bâti et les récits transmis au sein des quartiers.
              </p>
            </article>
            <article className={styles.aboutCard}>
              <h3>Lecture croisée des expertises</h3>
              <p>
                Les analyses intègrent des contributions d’historiens, d’urbanistes et de conservateurs qui éclairent les enjeux d’entretien, de transmission et de médiation culturelle.
              </p>
            </article>
            <article className={styles.aboutCard}>
              <h3>Cartographie narrative</h3>
              <p>
                Les études aboutissent à des cartographies interprétées, associant plans historiques, relevés piétons et annotations ethnographiques afin de restituer les rythmes de chaque rue.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="latest-studies">
        <div className={styles.sectionInner}>
          <div className={styles.sectionHeader}>
            <h2 id="latest-studies" className={styles.sectionTitle}>
              Dernières études publiées
            </h2>
            <p className={styles.sectionDescription}>
              Chaque étude présente un récit contextualisé, une analyse morphologique et des pistes de médiation pour les acteurs du patrimoine et de l’urbanisme.
            </p>
          </div>
          <div className={styles.cardsGrid}>
            {latestStudies.map((study) => {
              const formattedDate = new Intl.DateTimeFormat('fr-FR', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              }).format(new Date(study.date));

              return (
                <article key={study.id} className={styles.card}>
                  <div className={styles.cardImageWrapper}>
                    <img src={study.image} alt={study.imageAlt} className={styles.cardImage} loading="lazy" />
                  </div>
                  <div className={styles.cardBody}>
                    <p className={styles.cardMeta}>{formattedDate}</p>
                    <h3 className={styles.cardTitle}>{study.title}</h3>
                    <p className={styles.cardExcerpt}>{study.excerpt}</p>
                    <Link to={`/etude/${study.slug}`} className={styles.cardLink}>
                      Lire l’étude
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="topics-list">
        <div className={styles.sectionInner}>
          <h2 id="topics-list" className={styles.sectionTitle}>
            Thématiques de recherche
          </h2>
          <p className={styles.sectionDescription}>
            Les investigations couvrent des champs complémentaires permettant de saisir la matérialité des rues, leurs acteurs et leurs mémoires.
          </p>
          <div className={styles.topicGrid}>
            {topics.map((topic) => (
              <div key={topic} className={styles.topicItem}>
                <span className={styles.topicDot} aria-hidden="true" />
                <span>{topic}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="approach-heading">
        <div className={styles.sectionInner}>
          <h2 id="approach-heading" className={styles.sectionTitle}>
            Approche méthodologique
          </h2>
          <p className={styles.sectionDescription}>
            Les dossiers mobilisent des corpus documentaires et des compétences variées afin de restituer les continuités et les transitions urbaines.
          </p>
          <div className={styles.methodGrid}>
            {approachColumns.map((column) => (
              <article key={column.title} className={styles.methodCard}>
                <h3>{column.title}</h3>
                <p>{column.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="fieldnotes-heading">
        <div className={styles.sectionInner}>
          <h2 id="fieldnotes-heading" className={styles.sectionTitle}>
            Indicateurs de terrain
          </h2>
          <p className={styles.sectionDescription}>
            Les chiffres ci-dessous reflètent le volume de sources consultées et la dynamique des enquêtes menées par la rédaction.
          </p>
          <div className={styles.fieldnotesGrid}>
            {fieldNotes.map((note) => (
              <div key={note.label} className={styles.fieldnoteCard}>
                <span className={styles.fieldnoteValue}>{note.value}</span>
                <span className={styles.fieldnoteLabel}>{note.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="archive-focus">
        <div className={styles.sectionInner}>
          <h2 id="archive-focus" className={styles.sectionTitle}>
            Veille documentaire
          </h2>
          <p className={styles.sectionDescription}>
            Les prochaines publications porteront sur des axes en cours d’exploration, articulés avec les chantiers urbains et les archives fraîchement accessibles.
          </p>
          <div className={styles.outlookGrid}>
            <article className={styles.outlookCard}>
              <h3>Quartiers ferroviaires</h3>
              <p>Étude des rues attenantes aux gares secondaires et des transformations induites par la logistique urbaine.</p>
            </article>
            <article className={styles.outlookCard}>
              <h3>Dynamiques riveraines</h3>
              <p>Observation des rues portuaires face aux reconversions culturelles et aux dispositifs mémoriels émergents.</p>
            </article>
            <article className={styles.outlookCard}>
              <h3>Cartes sensibles</h3>
              <p>Expérimentation de supports cartographiques participatifs pour restituer les ambiances sonores des rues patrimoniales.</p>
            </article>
          </div>
          <div className={styles.archiveLinkWrapper}>
            <Link to="/archives" className={styles.archiveLink}>
              Accès à l’intégralité des études
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
```