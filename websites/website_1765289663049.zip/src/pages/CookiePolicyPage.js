```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPage.module.css';

const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Politique de cookies | Historic Streets of France Review</title>
      <meta
        name="description"
        content="Politique de cookies appliquée par Historic Streets of France Review."
      />
    </Helmet>

    <h1>Politique de cookies</h1>
    <p className={styles.intro}>
      Historic Streets of France Review utilise une quantité limitée de cookies afin d’assurer le bon fonctionnement du site et de disposer d’indicateurs d’audience anonymisés.
    </p>

    <section className={styles.section}>
      <h2>1. Définition</h2>
      <p>
        Un cookie est un fichier texte déposé sur le terminal de l’utilisateur à l’occasion de la consultation d’un site web. Il permet de stocker des informations limitées pendant une durée déterminée.
      </p>
    </section>

    <section className={styles.section}>
      <h2>2. Cookies utilisés</h2>
      <ul className={styles.list}>
        <li>
          <strong>Cookie de session</strong> : nécessaire au fonctionnement du site, il maintient la cohérence de navigation pendant la visite.
        </li>
        <li>
          <strong>Cookie analytique interne</strong> : mesure la fréquentation des pages de manière agrégée afin d’évaluer l’intérêt pour les thématiques abordées.
        </li>
      </ul>
    </section>

    <section className={styles.section}>
      <h2>3. Absence de cookies publicitaires</h2>
      <p>
        Aucun cookie tiers à finalité publicitaire n’est déposé via Historic Streets of France Review. Les données collectées ne servent pas à établir des profils marketing.
      </p>
    </section>

    <section className={styles.section}>
      <h2>4. Gestion des consentements</h2>
      <p>
        L’utilisateur est informé de la présence de cookies via un bandeau dédié. La poursuite de la navigation implique l’acceptation des cookies nécessaires. Le cas échéant, ils peuvent être supprimés depuis les paramètres du navigateur.
      </p>
    </section>

    <section className={styles.section}>
      <h2>5. Durée de conservation</h2>
      <p>
        Les cookies de session expirent automatiquement à la fermeture du navigateur. Les cookies analytiques sont conservés pour une durée maximale de treize mois.
      </p>
    </section>

    <section className={styles.section}>
      <h2>6. Paramétrage du navigateur</h2>
      <p>
        Chaque utilisateur peut configurer son navigateur pour accepter ou refuser les cookies. Les instructions figurent dans les menus d’aide des principaux navigateurs (Chrome, Firefox, Safari, Edge).
      </p>
    </section>
  </div>
);

export default CookiePolicyPage;
```