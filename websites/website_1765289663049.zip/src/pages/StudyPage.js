```javascript
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import studiesData from '../data/studies';
import styles from './StudyPage.module.css';

const StudyPage = () => {
  const { studySlug } = useParams();
  const study = React.useMemo(
    () => studiesData.find((entry) => entry.slug === studySlug),
    [studySlug]
  );

  if (!study) {
    return (
      <div className={styles.notFound}>
        <Helmet>
          <title>Étude introuvable | Historic Streets of France Review</title>
        </Helmet>
        <h1>Étude introuvable</h1>
        <p>
          Le dossier recherché n’est pas disponible. L’archive permet de parcourir l’ensemble des études publiées.
        </p>
        <Link to="/archives" className={styles.backLinkStandalone}>
          Revenir à l’archive
        </Link>
      </div>
    );
  }

  const formattedDate = new Intl.DateTimeFormat('fr-FR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  }).format(new Date(study.date));

  return (
    <article className={styles.page}>
      <Helmet>
        <title>{`${study.title} | Historic Streets of France Review`}</title>
        <meta name="description" content={study.excerpt} />
      </Helmet>
      <header
        className={styles.hero}
        style={{
          backgroundImage: `linear-gradient(135deg, rgba(26,54,93,0.75), rgba(123,26,26,0.55)), url('${study.heroImage}')`
        }}
      >
        <div className={styles.heroContent}>
          <p className={styles.location}>{study.location}</p>
          <h1>{study.title}</h1>
          {study.subtitle && <p className={styles.subtitle}>{study.subtitle}</p>}
          <p className={styles.meta}>Publié le {formattedDate}</p>
          <ul className={styles.tagList}>
            {study.tags.map((tag) => (
              <li key={tag} className={styles.tagItem}>
                {tag}
              </li>
            ))}
          </ul>
        </div>
      </header>

      <div className={styles.content}>
        <p className={styles.introduction}>{study.introduction}</p>

        {study.sections.map((section) => (
          <section key={section.heading} className={styles.section}>
            <h2>{section.heading}</h2>
            {section.image && (
              <figure className={styles.figure}>
                <img src={section.image.url} alt={section.image.alt} loading="lazy" />
                <figcaption>{section.image.alt}</figcaption>
              </figure>
            )}
            {section.paragraphs.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </section>
        ))}

        {study.quote && (
          <blockquote className={styles.quote}>
            <p>« {study.quote.text} »</p>
            <cite>{study.quote.author}</cite>
          </blockquote>
        )}

        <section className={styles.section}>
          <h2>Conclusion</h2>
          <p>{study.conclusion}</p>
        </section>

        {study.sources && study.sources.length > 0 && (
          <section className={styles.section} aria-labelledby="sources-heading">
            <h2 id="sources-heading">Sources et références</h2>
            <ul className={styles.sourceList}>
              {study.sources.map((source) => (
                <li key={source.label}>
                  <a href={source.url} target="_blank" rel="noopener noreferrer">
                    {source.label}
                  </a>
                </li>
              ))}
            </ul>
          </section>
        )}
      </div>

      <div className={styles.backLinkWrapper}>
        <Link to="/archives" className={styles.backLink}>
          Retour à l’archive des études
        </Link>
      </div>
    </article>
  );
};

export default StudyPage;
```