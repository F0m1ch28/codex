```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import studiesData from '../data/studies';
import styles from './ArchivesPage.module.css';

const defaultTag = 'Toutes les thématiques';

const ArchivesPage = () => {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [tagFilter, setTagFilter] = React.useState(defaultTag);

  const sortedStudies = React.useMemo(
    () => [...studiesData].sort((a, b) => new Date(b.date) - new Date(a.date)),
    []
  );

  const availableTags = React.useMemo(() => {
    const tagsSet = new Set();
    studiesData.forEach((study) => {
      study.tags.forEach((tag) => tagsSet.add(tag));
    });
    return [defaultTag, ...Array.from(tagsSet).sort((a, b) => a.localeCompare(b, 'fr'))];
  }, []);

  const filteredStudies = React.useMemo(() => {
    return sortedStudies.filter((study) => {
      const normalizedSearch = searchTerm.trim().toLowerCase();
      const matchesSearch =
        normalizedSearch.length === 0 ||
        study.title.toLowerCase().includes(normalizedSearch) ||
        study.excerpt.toLowerCase().includes(normalizedSearch) ||
        (study.subtitle && study.subtitle.toLowerCase().includes(normalizedSearch));
      const matchesTag = tagFilter === defaultTag || study.tags.includes(tagFilter);
      return matchesSearch && matchesTag;
    });
  }, [sortedStudies, searchTerm, tagFilter]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Archive des études | Historic Streets of France Review</title>
        <meta
          name="description"
          content="Archive des études publiées par Historic Streets of France Review, classées par thématiques et lieux."
        />
      </Helmet>

      <header className={styles.header}>
        <h1>Archive des études</h1>
        <p>
          Cette archive recense l’ensemble des études publiées depuis 2023. Les entrées peuvent être filtrées par mots-clés ou par thématiques pour faciliter le repérage des dossiers.
        </p>
      </header>

      <div className={styles.controls} role="search">
        <div className={styles.controlGroup}>
          <label htmlFor="search-input" className={styles.label}>
            Rechercher une étude
          </label>
          <input
            id="search-input"
            type="search"
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            placeholder="Titre, lieu ou période"
            className={styles.field}
          />
        </div>
        <div className={styles.controlGroup}>
          <label htmlFor="tag-select" className={styles.label}>
            Filtrer par thématique
          </label>
          <select
            id="tag-select"
            value={tagFilter}
            onChange={(event) => setTagFilter(event.target.value)}
            className={styles.field}
          >
            {availableTags.map((tag) => (
              <option key={tag} value={tag}>
                {tag}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className={styles.grid} role="list">
        {filteredStudies.length === 0 ? (
          <div className={styles.emptyState}>
            <p>Aucun résultat ne correspond aux critères sélectionnés.</p>
          </div>
        ) : (
          filteredStudies.map((study) => {
            const formattedDate = new Intl.DateTimeFormat('fr-FR', {
              day: '2-digit',
              month: 'long',
              year: 'numeric'
            }).format(new Date(study.date));
            return (
              <article key={study.slug} className={styles.card} role="listitem">
                <header className={styles.cardHeader}>
                  <p className={styles.date}>{formattedDate}</p>
                  <h2 className={styles.title}>{study.title}</h2>
                  {study.subtitle && <p className={styles.subtitle}>{study.subtitle}</p>}
                </header>
                <p className={styles.excerpt}>{study.excerpt}</p>
                <ul className={styles.tagList}>
                  {study.tags.map((tag) => (
                    <li key={tag} className={styles.tagItem}>
                      {tag}
                    </li>
                  ))}
                </ul>
                <Link to={`/etude/${study.slug}`} className={styles.link}>
                  Consulter l’étude
                </Link>
              </article>
            );
          })
        )}
      </div>
    </div>
  );
};

export default ArchivesPage;
```