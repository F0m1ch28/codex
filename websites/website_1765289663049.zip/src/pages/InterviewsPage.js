```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './InterviewsPage.module.css';

const interviews = [
  {
    id: 1,
    name: 'Élise Garnier',
    role: 'Archiviste municipale, Toulouse',
    theme: 'Plans directeurs et réappropriations contemporaines',
    date: 'Entretien collecté en avril 2024',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80',
    excerpt:
      "Élise Garnier décrit la méthode employée pour rapprocher les plans directeurs de 1850 des observations contemporaines sur la rue Saint-Rome, révélant l'importance des alignements invisibles.",
    highlights: [
      'Numérisation coordonnée de 12 000 feuillets cadastraux',
      'Dispositifs de médiation dédiés aux commerçants riverains'
    ]
  },
  {
    id: 2,
    name: 'Jean-Baptiste Caradec',
    role: 'Urbaniste, Euroméditerranée Marseille',
    theme: 'Requalification des axes portuaires',
    date: 'Entretien collecté en février 2024',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=601&q=80',
    excerpt:
      "Jean-Baptiste Caradec revient sur les arbitrages menés pour la rue de la République, entre exigences logistiques, habitat social et nouvelles fonctions culturelles.",
    highlights: [
      'Suivi des indicateurs de mobilité douce',
      'Dialogue avec les assemblées de copropriétaires'
    ]
  },
  {
    id: 3,
    name: 'Mouna Rahmani',
    role: 'Chercheuse associée, École d’urbanisme de Paris',
    theme: 'Mémoires sensibles et passages couverts',
    date: 'Entretien collecté en novembre 2023',
    image:
      'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80',
    excerpt:
      "Mouna Rahmani analyse l'ambiance du Passage Napolitain à Nice et la gouvernance partagée qui accompagne sa restauration discrète.",
    highlights: [
      'Observations ethnographiques sur trois saisons',
      'Cartographie sonore des circulations piétonnes'
    ]
  }
];

const InterviewsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Experts et entretiens | Historic Streets of France Review</title>
      <meta
        name="description"
        content="Entretiens avec des historiens, urbanistes et archivistes mobilisés par Historic Streets of France Review."
      />
    </Helmet>

    <header className={styles.header}>
      <h1>Experts et entretiens</h1>
      <p>
        Les entretiens éclairent les méthodes, les choix techniques et les récits portés par les acteurs du patrimoine urbain. Les extraits présentés ici synthétisent des échanges approfondis dont les transcriptions complètes sont accessibles sur demande professionnelle.
      </p>
    </header>

    <div className={styles.grid}>
      {interviews.map((interview) => (
        <article key={interview.id} className={styles.card}>
          <div className={styles.imageWrapper}>
            <img src={interview.image} alt={interview.name} loading="lazy" />
          </div>
          <div className={styles.cardBody}>
            <h2 className={styles.name}>{interview.name}</h2>
            <p className={styles.role}>{interview.role}</p>
            <p className={styles.theme}>{interview.theme}</p>
            <p className={styles.date}>{interview.date}</p>
            <p className={styles.excerpt}>{interview.excerpt}</p>
            <ul className={styles.highlightList}>
              {interview.highlights.map((highlight) => (
                <li key={highlight}>{highlight}</li>
              ))}
            </ul>
            <Link to="/contact" className={styles.link}>
              Demander l’accès à la transcription
            </Link>
          </div>
        </article>
      ))}
    </div>
  </div>
);

export default InterviewsPage;
```