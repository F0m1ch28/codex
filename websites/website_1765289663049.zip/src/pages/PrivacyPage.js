```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPage.module.css';

const PrivacyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Politique de confidentialité | Historic Streets of France Review</title>
      <meta
        name="description"
        content="Politique de confidentialité appliquée par Historic Streets of France Review."
      />
    </Helmet>

    <h1>Politique de confidentialité</h1>
    <p className={styles.intro}>
      Historic Streets of France Review accorde une importance particulière à la protection des données personnelles transmises via le formulaire de contact. Les dispositions ci-dessous précisent les traitements mis en œuvre.
    </p>

    <section className={styles.section}>
      <h2>1. Responsable du traitement</h2>
      <p>
        Le responsable du traitement des données est la rédaction de Historic Streets of France Review. Les demandes relatives à la protection des données peuvent être adressées à l’adresse de contact indiquée sur la page correspondante.
      </p>
    </section>

    <section className={styles.section}>
      <h2>2. Données collectées</h2>
      <p>
        Lors de l’utilisation du formulaire, sont recueillis le nom, l’adresse électronique, l’organisation d’appartenance et le contenu du message. Ces informations sont nécessaires pour instruire les demandes professionnelles reçues.
      </p>
    </section>

    <section className={styles.section}>
      <h2>3. Finalités</h2>
      <p>
        Les données servent exclusivement à répondre aux sollicitations documentaires ou partenariales, assurer un suivi des échanges et produire, le cas échéant, des statistiques internes anonymisées.
      </p>
    </section>

    <section className={styles.section}>
      <h2>4. Base légale</h2>
      <p>
        Le traitement repose sur l’intérêt légitime de Historic Streets of France Review à gérer sa correspondance professionnelle et à sécuriser l’accès aux sources mentionnées.
      </p>
    </section>

    <section className={styles.section}>
      <h2>5. Durée de conservation</h2>
      <p>
        Les courriels et formulaires sont conservés pendant une durée maximale de deux ans, sauf obligation légale de conservation plus longue. Au-delà, les données sont supprimées ou anonymisées.
      </p>
    </section>

    <section className={styles.section}>
      <h2>6. Destinataires</h2>
      <p>
        Les données sont accessibles uniquement aux membres de la rédaction chargés du suivi des demandes. Aucun transfert commercial n’est effectué vers des tiers.
      </p>
    </section>

    <section className={styles.section}>
      <h2>7. Droits des personnes</h2>
      <p>
        Conformément au règlement (UE) 2016/679, chaque personne dispose d’un droit d’accès, de rectification, d’effacement, de limitation et d’opposition. L’exercice de ces droits s’effectue par courriel via l’adresse officielle du site.
      </p>
    </section>

    <section className={styles.section}>
      <h2>8. Sécurité</h2>
      <p>
        Des mesures organisationnelles et techniques sont mises en place pour prévenir la perte, l’altération ou l’accès non autorisé aux données. Les contenus sensibles sont hébergés sur des serveurs situés dans l’Union européenne.
      </p>
    </section>

    <section className={styles.section}>
      <h2>9. Cookies et mesures d’audience</h2>
      <p>
        Seuls des cookies analytiques indispensables sont utilisés. Les détails figurent dans la politique spécifique aux cookies et peuvent être consultés à tout moment.
      </p>
    </section>
  </div>
);

export default PrivacyPage;
```