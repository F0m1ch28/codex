document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('[data-nav-toggle]');
    const navDrawer = document.querySelector('[data-nav-drawer]');
    const header = document.querySelector('.site-header');

    if (navToggle && navDrawer) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navDrawer.classList.toggle('open');
        });

        navDrawer.addEventListener('click', (event) => {
            if (event.target.tagName === 'A') {
                navToggle.classList.remove('active');
                navDrawer.classList.remove('open');
            }
        });
    }

    if (header) {
        const toggleScrolled = () => {
            if (window.scrollY > 20) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        };
        toggleScrolled();
        window.addEventListener('scroll', toggleScrolled);
    }

    const cookieBanner = document.querySelector('[data-cookie-banner]');
    const cookieButtons = document.querySelectorAll('[data-cookie-action]');
    const cookieStorageKey = 'undividmpr-cookie-choice';

    const setCookieChoice = (choice) => {
        try {
            localStorage.setItem(cookieStorageKey, JSON.stringify({
                choice,
                timestamp: new Date().toISOString()
            }));
        } catch (error) {
            console.warn('Cookie preference could not be stored.', error);
        }
    };

    const getCookieChoice = () => {
        try {
            const value = localStorage.getItem(cookieStorageKey);
            return value ? JSON.parse(value) : null;
        } catch (error) {
            return null;
        }
    };

    if (cookieBanner) {
        const storedChoice = getCookieChoice();
        if (!storedChoice) {
            cookieBanner.classList.remove('hidden');
        }
        cookieButtons.forEach((button) => {
            button.addEventListener('click', () => {
                const action = button.getAttribute('data-cookie-action');
                setCookieChoice(action);
                cookieBanner.classList.add('hidden');
            });
        });
    }

    const postsGrid = document.querySelector('[data-posts-grid]');
    const searchInput = document.querySelector('[data-post-search]');
    const categoryFilter = document.querySelector('[data-category-filter]');
    const paginationContainer = document.querySelector('[data-pagination]');
    if (postsGrid && paginationContainer) {
        const posts = Array.from(postsGrid.querySelectorAll('[data-post]'));
        let currentPage = 1;
        const postsPerPage = 6;
        let activeCategory = 'all';
        let searchTerm = '';

        const updatePagination = (totalItems) => {
            const totalPages = Math.ceil(totalItems / postsPerPage) || 1;
            paginationContainer.innerHTML = '';
            for (let page = 1; page <= totalPages; page += 1) {
                const button = document.createElement('button');
                button.type = 'button';
                button.textContent = page;
                if (page === currentPage) {
                    button.classList.add('active');
                }
                button.addEventListener('click', () => {
                    currentPage = page;
                    renderPosts();
                });
                paginationContainer.appendChild(button);
            }
        };

        const renderPosts = () => {
            const filtered = posts.filter((post) => {
                const category = post.getAttribute('data-category');
                const matchesCategory = activeCategory === 'all' || category === activeCategory;
                const textContent = post.textContent.toLowerCase();
                const matchesSearch = textContent.includes(searchTerm);
                return matchesCategory && matchesSearch;
            });
            posts.forEach((post) => post.classList.add('is-hidden'));
            const start = (currentPage - 1) * postsPerPage;
            const end = start + postsPerPage;
            filtered.slice(start, end).forEach((post) => post.classList.remove('is-hidden'));
            updatePagination(filtered.length);
        };

        if (categoryFilter) {
            categoryFilter.addEventListener('click', (event) => {
                const button = event.target.closest('button[data-filter]');
                if (!button) return;
                activeCategory = button.getAttribute('data-filter');
                categoryFilter.querySelectorAll('button').forEach((btn) => btn.classList.remove('active'));
                button.classList.add('active');
                currentPage = 1;
                renderPosts();
            });
        }

        if (searchInput) {
            searchInput.addEventListener('input', (event) => {
                searchTerm = event.target.value.trim().toLowerCase();
                currentPage = 1;
                renderPosts();
            });
        }

        renderPosts();
    }

    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        const feedback = document.querySelector('[data-form-feedback]');
        contactForm.addEventListener('submit', (event) => {
            const requiredFields = contactForm.querySelectorAll('[required]');
            let isValid = true;

            requiredFields.forEach((field) => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('invalid');
                } else {
                    field.classList.remove('invalid');
                }
            });

            const emailField = contactForm.querySelector('input[type="email"]');
            if (emailField && emailField.value) {
                const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailPattern.test(emailField.value)) {
                    isValid = false;
                    emailField.classList.add('invalid');
                }
            }

            if (!isValid) {
                event.preventDefault();
                if (feedback) {
                    feedback.classList.add('visible');
                }
            } else if (feedback) {
                feedback.classList.remove('visible');
            }
        });
    }
});