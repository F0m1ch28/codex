(function () {
    const navToggle = document.getElementById("navToggle");
    const primaryNav = document.getElementById("primaryNav");
    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", function () {
            primaryNav.classList.toggle("open");
        });
    }

    const yearElements = document.querySelectorAll(".current-year");
    const currentYear = new Date().getFullYear();
    yearElements.forEach(function (element) {
        element.textContent = currentYear;
    });

    const banner = document.getElementById("cookieBanner");
    const storageKey = "brashlodjvCookiePreference";
    if (banner) {
        const savedPreference = localStorage.getItem(storageKey);
        if (savedPreference) {
            banner.classList.add("hidden");
        }
        banner.addEventListener("click", function (event) {
            const target = event.target;
            if (target && target.dataset.action) {
                event.preventDefault();
                localStorage.setItem(storageKey, target.dataset.action);
                banner.classList.add("hidden");
                window.location.href = "cookies.html";
            }
        });
    }
})();