document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", function () {
            const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", (!isExpanded).toString());
            navMenu.classList.toggle("is-open");
        });

        navMenu.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                if (navMenu.classList.contains("is-open")) {
                    navMenu.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const acceptBtn = document.getElementById("cookie-accept");
    const declineBtn = document.getElementById("cookie-decline");
    const storageKey = "nigerHBFXConsent";

    function hideCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.remove("is-visible");
        }
    }

    function showCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.add("is-visible");
        }
    }

    if (localStorage.getItem(storageKey) === null) {
        showCookieBanner();
    }

    if (acceptBtn) {
        acceptBtn.addEventListener("click", function () {
            localStorage.setItem(storageKey, "accepted");
            hideCookieBanner();
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", function () {
            localStorage.setItem(storageKey, "declined");
            hideCookieBanner();
        });
    }
});