document.addEventListener("DOMContentLoaded", function () {
    const banner = document.getElementById("cookie-banner");
    if (!banner) {
        return;
    }

    const storedChoice = localStorage.getItem("mentalvhuxCookieChoice");
    if (storedChoice) {
        banner.classList.add("hidden");
    }

    const buttons = banner.querySelectorAll(".cookie-button");
    buttons.forEach(function (button) {
        button.addEventListener("click", function () {
            const choice = button.dataset.choice || "undecided";
            localStorage.setItem("mentalvhuxCookieChoice", choice);
            banner.classList.add("hidden");
        });
    });
});