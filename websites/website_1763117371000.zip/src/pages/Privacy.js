import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

function Privacy() {
  return (
    <div className={styles.privacy}>
      <Helmet>
        <title>Privacy Notice | AnimalQDKT Tech Solutions</title>
        <meta
          name="description"
          content="Read how AnimalQDKT Tech Solutions collects, processes, and protects personal data in line with GDPR requirements."
        />
      </Helmet>
      <section className="sectionPadding">
        <div className="container">
          <h1 className="sectionTitle">Privacy Notice</h1>
          <div className={styles.content}>
            <p>Last updated: August 2023</p>

            <h2>1. Purpose of this notice</h2>
            <p>
              AnimalQDKT Tech Solutions respects your privacy and is committed to safeguarding personal data. This
              notice explains how we collect, process, and protect information in line with the UK GDPR.
            </p>

            <h2>2. Data we collect</h2>
            <p>
              We may collect personal information including name, email address, company, and details shared through our
              contact forms or during business engagements. We also collect technical data such as IP addresses and
              analytics relating to website usage.
            </p>

            <h2>3. How we use data</h2>
            <p>
              Personal data is used to respond to enquiries, deliver contracted services, share updates about our work,
              and improve our digital platforms. We process data on lawful bases including consent, contract, and
              legitimate interest.
            </p>

            <h2>4. Sharing data</h2>
            <p>
              We do not sell personal data. We may share data with trusted service providers who support our operations
              (for example, hosting, analytics, or productivity platforms). These providers are bound by data processing
              agreements.
            </p>

            <h2>5. Data retention</h2>
            <p>
              Data is retained only for as long as necessary to fulfil the purpose it was collected for, including legal,
              accounting, or reporting requirements.
            </p>

            <h2>6. International transfers</h2>
            <p>
              If data is transferred outside the UK or EEA, we implement appropriate safeguards such as Standard
              Contractual Clauses or adequacy decisions.
            </p>

            <h2>7. Your rights</h2>
            <p>
              You have rights to access, rectify, erase, restrict, or object to processing of your personal data. You
              can also request data portability. To exercise these rights, contact us at{' '}
              <a href="mailto:hello@animalqdkt.com" className={styles.link}>
                hello@animalqdkt.com
              </a>
              .
            </p>

            <h2>8. Cookies and analytics</h2>
            <p>
              We use cookies and similar technologies to understand site usage and enhance experience. Details are
              explained in our Cookie Policy.
            </p>

            <h2>9. Complaints</h2>
            <p>
              If you have concerns about data handling, please contact us. You also have the right to lodge a complaint
              with the Information Commissioner’s Office (ICO).
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Privacy;