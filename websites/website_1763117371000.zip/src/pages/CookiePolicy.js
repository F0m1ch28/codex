import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

function CookiePolicy() {
  return (
    <div className={styles.cookiePolicy}>
      <Helmet>
        <title>Cookie Policy | AnimalQDKT Tech Solutions</title>
        <meta
          name="description"
          content="Learn how AnimalQDKT Tech Solutions uses cookies to enhance our website performance and ensure GDPR compliance."
        />
      </Helmet>
      <section className="sectionPadding">
        <div className="container">
          <h1 className="sectionTitle">Cookie Policy</h1>
          <div className={styles.content}>
            <p>Last updated: August 2023</p>

            <h2>1. What are cookies?</h2>
            <p>
              Cookies are small text files stored on your device when you visit a website. They help us recognise your
              browser, remember preferences, and analyse site performance.
            </p>

            <h2>2. Types of cookies we use</h2>
            <ul>
              <li>
                <strong>Essential cookies:</strong> Required for security, accessibility, and basic functionality.
              </li>
              <li>
                <strong>Analytics cookies:</strong> Provide aggregated insights into how visitors interact with our
                site, helping us improve content.
              </li>
            </ul>

            <h2>3. Managing cookies</h2>
            <p>
              You can control cookies through your browser settings or the preferences available in our cookie banner.
              Disabling certain cookies may affect website performance.
            </p>

            <h2>4. Third-party cookies</h2>
            <p>
              We may use trusted third-party services such as analytics providers. These services may set their own
              cookies, governed by their privacy policies.
            </p>

            <h2>5. Updates</h2>
            <p>
              We review this policy periodically. Any changes will be published on this page with an updated revision
              date.
            </p>

            <p>
              For questions about cookies or data practices, contact{' '}
              <a href="mailto:hello@animalqdkt.com" className={styles.link}>
                hello@animalqdkt.com
              </a>
              .
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default CookiePolicy;