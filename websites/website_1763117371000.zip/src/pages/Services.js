import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const serviceDetails = [
  {
    title: 'Web Development',
    subtitle: 'React • Node.js • Next.js',
    description:
      'Product-driven engineering squads crafting accessible, high-performing web applications. We own delivery from research and architecture to automated testing and observability.',
    points: [
      'Modern front-end architectures with React, Next.js, and TypeScript',
      'API design with Node.js, GraphQL, and microservices patterns',
      'Design systems and component libraries aligned with brand DNA',
      'Progressive web app capabilities and performance optimisation'
    ],
    image: 'https://picsum.photos/900/600?random=151'
  },
  {
    title: 'Cloud Solutions',
    subtitle: 'AWS • Azure • GCP',
    description:
      'Cloud specialists building secure, scalable platforms with automation at the centre. We bring infrastructure as code, DevSecOps, and governance frameworks to each engagement.',
    points: [
      'Cloud landing zones and multi-account strategies',
      'Infrastructure as code with Terraform and Pulumi',
      'Security baselines, compliance automation, and threat modelling',
      'Observability, FinOps guardrails, and site reliability enablement'
    ],
    image: 'https://picsum.photos/900/600?random=152'
  },
  {
    title: 'Software Engineering',
    subtitle: 'Custom Platforms',
    description:
      'From complex enterprise systems to data-rich products, we deliver dependable software that scales. Our teams combine domain-driven design with lean product practices.',
    points: [
      'Domain modelling and service decomposition workshops',
      'Event-driven architectures with Kafka and serverless patterns',
      'Automated testing, contract testing, and continuous delivery pipelines',
      'Security-first engineering with threat and privacy assessments'
    ],
    image: 'https://picsum.photos/900/600?random=153'
  },
  {
    title: 'Digital Transformation',
    subtitle: 'Consulting & Strategy',
    description:
      'We guide organisations through change with strategic roadmaps, operating model design, and hands-on coaching. The goal is to embed lasting capability.',
    points: [
      'Transformation discovery and value stream mapping',
      'Target operating model design for product and platform teams',
      'Capability assessments, training academies, and playbook creation',
      'Executive advisory and portfolio governance coaching'
    ],
    image: 'https://picsum.photos/900/600?random=154'
  }
];

function Services() {
  return (
    <div className={styles.services}>
      <Helmet>
        <title>Services | AnimalQDKT Tech Solutions</title>
        <meta
          name="description"
          content="Discover AnimalQDKT Tech Solutions services covering web development, cloud solutions, software engineering, and digital transformation."
        />
      </Helmet>

      <section className={`${styles.hero} sectionPadding`} aria-labelledby="services-hero-heading">
        <div className="container">
          <h1 id="services-hero-heading" className="sectionTitle">
            Services crafted for ambitious digital teams
          </h1>
          <p className="sectionSubtitle">
            AnimalQDKT Tech Solutions delivers end-to-end capabilities that help organisations build, ship, and scale
            resilient products across the modern technology stack.
          </p>
        </div>
      </section>

      <section className="sectionPadding">
        <div className="container">
          <div className={styles.servicesList}>
            {serviceDetails.map((service, index) => (
              <article key={service.title} className={styles.servicePanel}>
                <div className={styles.serviceContent}>
                  <span className={styles.serviceIndex}>{index + 1}</span>
                  <h2>{service.title}</h2>
                  <p className={styles.subtitle}>{service.subtitle}</p>
                  <p className={styles.description}>{service.description}</p>
                  <ul className={styles.points}>
                    {service.points.map((point) => (
                      <li key={point}>{point}</li>
                    ))}
                  </ul>
                </div>
                <div className={styles.serviceImageWrapper}>
                  <img src={service.image} alt={`${service.title} illustration`} loading="lazy" />
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.outcomes} sectionPadding`} aria-labelledby="outcomes-heading">
        <div className="container">
          <h2 id="outcomes-heading">Tangible outcomes from every engagement</h2>
          <div className={styles.outcomeGrid}>
            <div className={styles.outcomeCard}>
              <h3>Visibility and alignment</h3>
              <p>
                Delivery rituals, dashboards, and communications frameworks strengthen stakeholder trust and keep focus
                on measurable outcomes.
              </p>
            </div>
            <div className={styles.outcomeCard}>
              <h3>High-performing platforms</h3>
              <p>
                Architectures built with performance, resilience, and security guardrails, ensuring teams can iterate
                with confidence.
              </p>
            </div>
            <div className={styles.outcomeCard}>
              <h3>Empowered teams</h3>
              <p>
                Coaching, playbooks, and capability uplift programmes embed practices that last beyond a single
                engagement.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Services;