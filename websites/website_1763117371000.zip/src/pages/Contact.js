import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

function Contact() {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Enter a valid email address.';
    }
    if (!formData.message.trim()) newErrors.message = 'Tell us about your project goals.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setStatus({
        type: 'error',
        message: 'Please review the highlighted fields.'
      });
      return;
    }

    setErrors({});
    setStatus({
      type: 'success',
      message: 'Thank you. A member of the team will reach out shortly.'
    });
    setFormData(initialFormState);
  };

  return (
    <div className={styles.contact}>
      <Helmet>
        <title>Contact | AnimalQDKT Tech Solutions</title>
        <meta
          name="description"
          content="Contact AnimalQDKT Tech Solutions to discuss engineering, cloud, or transformation projects from our London headquarters."
        />
      </Helmet>

      <section className={`${styles.hero} sectionPadding`} aria-labelledby="contact-heading">
        <div className="container">
          <h1 id="contact-heading" className="sectionTitle">
            Let’s talk about your next chapter
          </h1>
          <p className="sectionSubtitle">
            Share your ambitions and we will assemble the right team to co-create a roadmap, identify measurable value,
            and deliver dependable technology.
          </p>
        </div>
      </section>

      <section className="sectionPadding">
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.details}>
              <h2>London headquarters</h2>
              <p>42 Tech Park Avenue, London, E14 5AB, United Kingdom</p>
              <p>
                Phone:{' '}
                <a href="tel:+442079460958" className={styles.link}>
                  +44 20 7946 0958
                </a>
              </p>
              <p>
                Email:{' '}
                <a href="mailto:hello@animalqdkt.com" className={styles.link}>
                  hello@animalqdkt.com
                </a>
              </p>
              <div className={styles.socials}>
                <a href="#" aria-label="LinkedIn" className={styles.link}>
                  LinkedIn
                </a>
                <a href="#" aria-label="Twitter" className={styles.link}>
                  Twitter
                </a>
                <a href="#" aria-label="GitHub" className={styles.link}>
                  GitHub
                </a>
              </div>
              <div className={styles.mapWrapper} aria-label="Map of AnimalQDKT Tech Solutions office in London">
                <iframe
                  title="AnimalQDKT Tech Solutions London office map"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d19819.98217633766!2d-0.0247697!3d51.5049974!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487602bffc52e539%3A0xf1bba52f1b19097d!2sCanary%20Wharf%2C%20London!5e0!3m2!1sen!2suk!4v1694623790001!5m2!1sen!2suk"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
            <div className={styles.formCard}>
              <h2>Send us a message</h2>
              <form onSubmit={handleSubmit} noValidate spellCheck="false">
                <div className={styles.formGroup}>
                  <label htmlFor="contact-name">Name*</label>
                  <input
                    id="contact-name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={(event) =>
                      setFormData((prev) => ({ ...prev, name: event.target.value }))
                    }
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'contact-name-error' : undefined}
                  />
                  {errors.name && (
                    <span id="contact-name-error" className={styles.error}>
                      {errors.name}
                    </span>
                  )}
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="contact-email">Email*</label>
                  <input
                    id="contact-email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={(event) =>
                      setFormData((prev) => ({ ...prev, email: event.target.value }))
                    }
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'contact-email-error' : undefined}
                  />
                  {errors.email && (
                    <span id="contact-email-error" className={styles.error}>
                      {errors.email}
                    </span>
                  )}
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="contact-company">Company</label>
                  <input
                    id="contact-company"
                    name="company"
                    type="text"
                    value={formData.company}
                    onChange={(event) =>
                      setFormData((prev) => ({ ...prev, company: event.target.value }))
                    }
                  />
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="contact-message">How can we help?*</label>
                  <textarea
                    id="contact-message"
                    name="message"
                    rows="5"
                    value={formData.message}
                    onChange={(event) =>
                      setFormData((prev) => ({ ...prev, message: event.target.value }))
                    }
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'contact-message-error' : undefined}
                  />
                  {errors.message && (
                    <span id="contact-message-error" className={styles.error}>
                      {errors.message}
                    </span>
                  )}
                </div>
                <button type="submit" className="btnPrimary">
                  Send message
                </button>
                {status && (
                  <p
                    className={`${styles.status} ${
                      status.type === 'success' ? styles.statusSuccess : styles.statusError
                    }`}
                    role="status"
                  >
                    {status.message}
                  </p>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Contact;