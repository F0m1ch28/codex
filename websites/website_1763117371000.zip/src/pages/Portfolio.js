import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Portfolio.module.css';

const projects = [
  {
    title: 'Meridian Rail Operations Platform',
    category: 'Cloud',
    description:
      'Re-architected critical operations systems onto a cloud-native platform with domain-driven microservices and fully automated pipelines.',
    technologies: ['React', 'Node.js', 'AWS', 'Terraform'],
    image: 'https://picsum.photos/1000/700?random=161'
  },
  {
    title: 'Northwind Learning Experience',
    category: 'Product',
    description:
      'Delivered a personalised digital learning environment with adaptive content, advanced analytics, and inclusive user journeys.',
    technologies: ['Next.js', 'GraphQL', 'Azure', 'PostgreSQL'],
    image: 'https://picsum.photos/1000/700?random=162'
  },
  {
    title: 'Horizon Utilities Customer Hub',
    category: 'Transformation',
    description:
      'Partnered with leadership to define product roadmaps, build cross-functional squads, and implement DevSecOps practices.',
    technologies: ['React', 'Node.js', 'Kubernetes', 'Azure DevOps'],
    image: 'https://picsum.photos/1000/700?random=163'
  },
  {
    title: 'GovData Policy Engine',
    category: 'Data',
    description:
      'Delivered a secure data processing platform handling sensitive datasets with full observability and audit trails.',
    technologies: ['Python', 'Kafka', 'GCP', 'BigQuery'],
    image: 'https://picsum.photos/1000/700?random=164'
  },
  {
    title: 'Aurora Mobility Fleet Intelligence',
    category: 'Cloud',
    description:
      'Built a telematics pipeline with edge processing, real-time dashboards, and predictive maintenance insights for a European mobility provider.',
    technologies: ['Go', 'React', 'AWS', 'IoT Core'],
    image: 'https://picsum.photos/1000/700?random=165'
  },
  {
    title: 'Pulse Health Research Portal',
    category: 'Product',
    description:
      'Designed and implemented a compliant portal for research collaboration, featuring consent management and privacy-by-design workflows.',
    technologies: ['Vue.js', 'Node.js', 'AWS', 'DynamoDB'],
    image: 'https://picsum.photos/1000/700?random=166'
  }
];

const filters = ['All', 'Cloud', 'Product', 'Transformation', 'Data'];

function Portfolio() {
  const [activeFilter, setActiveFilter] = useState('All');

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'All') return projects;
    return projects.filter((project) => project.category === activeFilter);
  }, [activeFilter]);

  return (
    <div className={styles.portfolio}>
      <Helmet>
        <title>Portfolio | AnimalQDKT Tech Solutions</title>
        <meta
          name="description"
          content="Explore AnimalQDKT Tech Solutions portfolio featuring cloud migrations, product builds, transformation programmes, and data platforms."
        />
      </Helmet>

      <section className={`${styles.hero} sectionPadding`} aria-labelledby="portfolio-heading">
        <div className="container">
          <h1 id="portfolio-heading" className="sectionTitle">
            Portfolio and case studies
          </h1>
          <p className="sectionSubtitle">
            A selection of engagements where AnimalQDKT Tech Solutions partnered with organisations to unlock momentum
            through engineering excellence and human-centred change.
          </p>
        </div>
      </section>

      <section className="sectionPadding">
        <div className="container">
          <div className={styles.filterBar} role="tablist" aria-label="Project categories">
            {filters.map((filter) => (
              <button
                key={filter}
                type="button"
                className={`${styles.filterButton} ${activeFilter === filter ? styles.filterActive : ''}`}
                onClick={() => setActiveFilter(filter)}
                aria-selected={activeFilter === filter}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.grid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img src={project.image} alt={`${project.title} project visual`} loading="lazy" />
                </div>
                <div className={styles.cardContent}>
                  <span className={styles.category}>{project.category}</span>
                  <h2>{project.title}</h2>
                  <p>{project.description}</p>
                  <div className={styles.techList}>
                    {project.technologies.map((tech) => (
                      <span key={tech}>{tech}</span>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Portfolio;