import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const statsData = [
  { label: 'Successful deliveries', value: 128, suffix: '+' },
  { label: 'Cloud migrations completed', value: 47, suffix: '' },
  { label: 'Automation rate achieved', value: 82, suffix: '%' },
  { label: 'Client satisfaction score', value: 94, suffix: '%' }
];

const servicesData = [
  {
    title: 'Full-Stack Engineering',
    description:
      'Product squads delivering resilient web platforms with React, Node.js, and TypeScript.',
    icon: '🛠️'
  },
  {
    title: 'Cloud Architecture',
    description:
      'AWS, Azure, and GCP specialists designing secure, scalable infrastructure blueprints.',
    icon: '☁️'
  },
  {
    title: 'Platform Enablement',
    description:
      'Accelerating releases through CI/CD automation, observability, and SRE coaching.',
    icon: '🚀'
  }
];

const processSteps = [
  {
    title: 'Discover & Define',
    description:
      'Co-create vision and success metrics through collaborative workshops, architecture health checks, and user journey mapping.'
  },
  {
    title: 'Design & Validate',
    description:
      'Rapid prototyping, solution spikes, and experience design ensuring feasibility and alignment with business objectives.'
  },
  {
    title: 'Build & Evolve',
    description:
      'Cross-functional squads iterating in sprints, backed by automation, quality gates, and transparent reporting.'
  },
  {
    title: 'Scale & Support',
    description:
      'Ongoing optimisation, enablement, and cloud governance delivering reliable operations with measurable impact.'
  }
];

const testimonials = [
  {
    quote:
      'AnimalQDKT guided our transformation from monolithic services to a modular architecture while keeping uptime impeccable.',
    name: 'Emily Carter',
    role: 'Director of Technology, Meridian Rail'
  },
  {
    quote:
      'Their engineering leadership accelerated our release cadence and enabled the team to own the platform confidently.',
    name: 'Liam Patel',
    role: 'Head of Digital Platforms, Horizon Utilities'
  },
  {
    quote:
      'From discovery to launch, the squad brought clarity, energy, and craftsmanship that reshaped stakeholder expectations.',
    name: 'Sophie Nguyen',
    role: 'Product Lead, Northwind Learning'
  }
];

const faqs = [
  {
    question: 'How quickly can your teams onboard to an existing delivery initiative?',
    answer:
      'We typically complete onboarding within two weeks, including architecture orientation, tooling alignment, and clear delivery milestones.'
  },
  {
    question: 'Do you collaborate with internal engineering teams?',
    answer:
      'Absolutely. We pair with internal experts, share playbooks, and design joint rituals so knowledge remains within your organisation.'
  },
  {
    question: 'What industries do you focus on?',
    answer:
      'We partner with finance, mobility, public sector, energy, and technology scale-ups, applying domain knowledge to each engagement.'
  }
];

const blogPosts = [
  {
    title: 'Designing observable cloud-native platforms',
    excerpt:
      'Learn how structured observability enables high-velocity delivery while safeguarding customer experience.',
    date: 'August 2023'
  },
  {
    title: 'Human-centred transformation for complex enterprises',
    excerpt:
      'A field guide to embedding change agents, aligning teams, and measuring value in digital transformation journeys.',
    date: 'June 2023'
  },
  {
    title: 'From MVP to resilient product operations',
    excerpt:
      'Frameworks to mature product organisations without sacrificing innovation, featuring lessons from our London studio.',
    date: 'May 2023'
  }
];

function useCountUp(target, duration = 1600) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let start = 0;
    const increment = Math.max(1, Math.round((target / duration) * 16));
    const interval = setInterval(() => {
      start += increment;
      if (start >= target) {
        setCount(target);
        clearInterval(interval);
      } else {
        setCount(start);
      }
    }, 16);
    return () => clearInterval(interval);
  }, [target, duration]);

  return count;
}

function StatCard({ label, value, suffix }) {
  const count = useCountUp(value);
  return (
    <div className={styles.statCard}>
      <p className={styles.statValue}>
        {count}
        {suffix}
      </p>
      <p className={styles.statLabel}>{label}</p>
    </div>
  );
}

function Home() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeFaq, setActiveFaq] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={styles.home}>
      <Helmet>
        <title>AnimalQDKT Tech Solutions | Engineering Your Digital Future</title>
        <meta
          name="description"
          content="Discover how AnimalQDKT Tech Solutions engineers digital platforms, cloud infrastructures, and transformation programmes from London."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <p className={styles.heroBadge}>London • Cloud • Engineering</p>
            <h1 className={styles.heroTitle}>Engineering Your Digital Future</h1>
            <p className={styles.heroSubtitle}>
              AnimalQDKT Tech Solutions brings together strategists, architects, and product engineers to create
              platforms that move with your business. We embed with your teams to ship measurable outcomes, not just
              deliverables.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contact" className="btnPrimary">
                Start Your Project
              </Link>
              <Link to="/portfolio" className="btnSecondary">
                View our work
              </Link>
            </div>
          </div>
          <div className={styles.heroVisual} role="presentation" />
        </div>
      </section>

      <section className={`${styles.intro} sectionPadding`} aria-labelledby="intro-heading">
        <div className="container">
          <div className={styles.introGrid}>
            <div>
              <h2 id="intro-heading" className="sectionTitle">
                Trusted partner for ambitious teams
              </h2>
              <p className="sectionSubtitle">
                We founded AnimalQDKT Tech Solutions to pair world-class engineering with business clarity. From cloud
                native transformations to product acceleration, our squads co-design journeys that de-risk change.
              </p>
            </div>
            <div className={styles.introHighlights}>
              <div className={styles.highlightCard}>
                <h3>Outcome-driven delivery</h3>
                <p>
                  We embed measurable objectives, transparent reporting, and decision-ready communication throughout the
                  engagement lifecycle.
                </p>
              </div>
              <div className={styles.highlightCard}>
                <h3>Interdisciplinary squads</h3>
                <p>
                  Engineers, product strategists, designers, and data specialists collaborate to unlock resilient
                  outcomes at pace.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Company metrics">
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat) => (
              <StatCard key={stat.label} {...stat} />
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.services} sectionPadding`} id="services" aria-labelledby="services-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="services-heading" className="sectionTitle">
              Our Services
            </h2>
            <p className="sectionSubtitle">
              Precision engineering, modern cloud infrastructure, and advisory capabilities shaped to your operating
              context.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <div key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className={styles.serviceLink}>
                  Explore capability →
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.process} sectionPadding`} aria-labelledby="process-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="process-heading" className="sectionTitle">
              How We Work
            </h2>
            <p className="sectionSubtitle">
              A transparent delivery framework that blends discovery, experimentation, and sustainable operations.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <div key={step.title} className={styles.processCard}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.whyUs} sectionPadding`} aria-labelledby="why-heading">
        <div className="container">
          <div className={styles.whyGrid}>
            <div>
              <h2 id="why-heading" className="sectionTitle">
                Why choose AnimalQDKT Tech Solutions
              </h2>
              <p className="sectionSubtitle">
                We provide leadership, empathy, and modern engineering craft. Collaboration with us feels clear, energising, and purposeful.
              </p>
            </div>
            <ul className={styles.whyList}>
              <li>
                <h3>London-based, globally informed</h3>
                <p>
                  We unite insights from UK public sector programmes, fintech platforms, and industrial IoT initiatives.
                </p>
              </li>
              <li>
                <h3>Human-centred change</h3>
                <p>
                  Empowering teams through playbooks, co-creation, and diligent coaching, ensuring capability remains when we step back.
                </p>
              </li>
              <li>
                <h3>Quality engineered into every sprint</h3>
                <p>
                  Automated testing, resilient pipelines, and observability dashboards align the squad around product health.
                </p>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className={`${styles.testimonials} sectionPadding`} aria-labelledby="testimonials-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="testimonials-heading" className="sectionTitle">
              Client Success Stories
            </h2>
            <p className="sectionSubtitle">
              Stories from partners who trusted AnimalQDKT Tech Solutions to unlock engineering momentum.
            </p>
          </div>
          <div className={styles.testimonialWrapper}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.testimonialActive : ''
                }`}
                aria-hidden={index !== activeTestimonial}
              >
                <p className={styles.testimonialQuote}>"{testimonial.quote}"</p>
                <p className={styles.testimonialAuthor}>
                  {testimonial.name} · <span>{testimonial.role}</span>
                </p>
              </article>
            ))}
          </div>
          <div className={styles.testimonialDots} role="tablist" aria-label="Testimonial selector">
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Show testimonial ${index + 1}`}
                aria-selected={index === activeTestimonial}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.caseStudy} sectionPadding`} aria-labelledby="case-heading">
        <div className="container">
          <div className={styles.caseGrid}>
            <div className={styles.caseImageWrapper}>
              <img
                src="https://picsum.photos/1200/800?random=131"
                alt="Product team reviewing a cloud infrastructure diagram"
                loading="lazy"
              />
            </div>
            <div>
              <h2 id="case-heading" className="sectionTitle">
                Rebuilding critical platforms for Meridian Rail
              </h2>
              <p className="sectionSubtitle">
                How strategic re-platforming, cloud automation, and product coaching helped the Meridian Rail
                operations team improve release cadence from quarterly to weekly while maintaining compliance.
              </p>
              <ul className={styles.casePoints}>
                <li>Introduced modular architecture and domain-driven design across legacy services.</li>
                <li>Delivered automated compliance reporting and observability dashboards for leadership.</li>
                <li>Enabled internal teams with playbooks, pairing sessions, and capability assessments.</li>
              </ul>
              <Link to="/portfolio" className="btnSecondary">
                Explore more case studies
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.faq} sectionPadding`} aria-labelledby="faq-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="faq-heading" className="sectionTitle">
              Frequently asked questions
            </h2>
            <p className="sectionSubtitle">
              Answers to the conversations we have most often with technology and product leaders.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqs.map((item, index) => (
              <div key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqQuestion}
                  onClick={() => setActiveFaq((prev) => (prev === index ? -1 : index))}
                  aria-expanded={activeFaq === index}
                >
                  {item.question}
                  <span aria-hidden="true">{activeFaq === index ? '−' : '+'}</span>
                </button>
                {activeFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.blog} sectionPadding`} aria-labelledby="blog-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="blog-heading" className="sectionTitle">
              Latest insights
            </h2>
            <p className="sectionSubtitle">
              Perspectives from our strategists, architects, and delivery specialists on engineering modern platforms.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <p className={styles.blogDate}>{post.date}</p>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <a href="#" className={styles.blogLink} aria-label={`${post.title} article placeholder link`}>
                  Continue reading →
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.cta} sectionPadding`} aria-labelledby="cta-heading">
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2 id="cta-heading">Ready to design new momentum?</h2>
              <p>
                Start a conversation with AnimalQDKT Tech Solutions and discover how a dedicated delivery squad can move
                your digital roadmap forward with confidence.
              </p>
            </div>
            <Link to="/contact" className="btnPrimary">
              Start Your Project
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;