import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Team.module.css';

const teamMembers = [
  {
    name: 'Maya Thompson',
    role: 'Head of Engineering',
    bio: 'Guides cross-functional squads and shapes engineering strategy across digital platforms.',
    certifications: ['AWS Certified Solutions Architect', 'Certified Scrum Professional'],
    experience: '15 years in large-scale platform delivery.',
    image: 'https://picsum.photos/400/400?random=171'
  },
  {
    name: 'Daniel Osei',
    role: 'Principal Cloud Architect',
    bio: 'Designs secure cloud architectures and governance models for regulated industries.',
    certifications: ['Azure Solutions Architect Expert', 'CISSP'],
    experience: '10 years building cloud foundations for enterprises.',
    image: 'https://picsum.photos/400/400?random=172'
  },
  {
    name: 'Priya Patel',
    role: 'Digital Transformation Lead',
    bio: 'Partners with leadership teams on operating model design and delivery excellence.',
    certifications: ['SAFe Program Consultant', 'Prosci Change Practitioner'],
    experience: '12 years enabling transformation programmes.',
    image: 'https://picsum.photos/400/400?random=173'
  },
  {
    name: 'Lewis Walker',
    role: 'Principal Software Engineer',
    bio: 'Specialises in distributed systems, event-driven architectures, and DevSecOps practices.',
    certifications: ['Certified Kubernetes Administrator'],
    experience: '11 years building resilient systems for high-growth companies.',
    image: 'https://picsum.photos/400/400?random=174'
  },
  {
    name: 'Isabella Rodrigues',
    role: 'Lead Product Strategist',
    bio: 'Helps organisations align customer experience with product roadmaps and measurable outcomes.',
    certifications: ['Design Sprint Masterclass', 'Product Strategy Certification'],
    experience: '9 years shaping digital product vision.',
    image: 'https://picsum.photos/400/400?random=175'
  },
  {
    name: 'Omar Rahman',
    role: 'Data & AI Engineering Lead',
    bio: 'Builds data platforms, machine learning pipelines, and governance frameworks.',
    certifications: ['Google Professional Data Engineer', 'Databricks Certified Data Engineer'],
    experience: '8 years delivering data-intensive platforms.',
    image: 'https://picsum.photos/400/400?random=176'
  }
];

function Team() {
  return (
    <div className={styles.team}>
      <Helmet>
        <title>Our Team | AnimalQDKT Tech Solutions</title>
        <meta
          name="description"
          content="Meet the AnimalQDKT Tech Solutions leadership and engineering team delivering complex digital initiatives from London."
        />
      </Helmet>

      <section className={`${styles.hero} sectionPadding`} aria-labelledby="team-heading">
        <div className="container">
          <h1 id="team-heading" className="sectionTitle">
            Meet our team
          </h1>
          <p className="sectionSubtitle">
            A multidisciplinary collective of strategists, engineers, architects, and delivery leads dedicated to
            building enduring digital capabilities.
          </p>
        </div>
      </section>

      <section className="sectionPadding">
        <div className="container">
          <div className={styles.grid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.card}>
                <div className={styles.avatarWrapper}>
                  <img src={member.image} alt={`${member.name} portrait`} loading="lazy" />
                </div>
                <div className={styles.info}>
                  <h2>{member.name}</h2>
                  <p className={styles.role}>{member.role}</p>
                  <p className={styles.bio}>{member.bio}</p>
                  <p className={styles.experience}>{member.experience}</p>
                  <div className={styles.certifications}>
                    {member.certifications.map((cert) => (
                      <span key={cert}>{cert}</span>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Team;