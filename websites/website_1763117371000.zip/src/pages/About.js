import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const timeline = [
  {
    year: '2015',
    title: 'Founded in Shoreditch',
    description:
      'AnimalQDKT Tech Solutions began in a shared studio in Shoreditch, bringing together developers and strategists focused on cloud-native delivery.'
  },
  {
    year: '2018',
    title: 'Expanding engineering leadership',
    description:
      'We introduced transformation coaches and SRE specialists to guide clients through large-scale re-platforming programmes.'
  },
  {
    year: '2021',
    title: 'Global delivery partnerships',
    description:
      'Our squads collaborated with organisations across Europe and Asia, sharing playbooks and enabling distributed product teams.'
  },
  {
    year: '2023',
    title: 'New London Delivery Hub',
    description:
      'We opened our Tech Park Avenue hub to host client immersion labs, innovation sprints, and cross-functional enablement sessions.'
  }
];

const expertise = [
  'Lean product strategy and value discovery',
  'Service-oriented architecture and API platforms',
  'Cloud infrastructure on AWS, Azure, and GCP',
  'Data engineering pipelines and governance',
  'DevSecOps transformation and automation',
  'Experience design and research operations'
];

const techStack = [
  'React',
  'Next.js',
  'TypeScript',
  'Node.js',
  'GraphQL',
  'Go',
  'Python',
  'Kubernetes',
  'Terraform',
  'AWS',
  'Azure',
  'Google Cloud',
  'Docker',
  'PostgreSQL',
  'MongoDB',
  'Apache Kafka'
];

function About() {
  return (
    <div className={styles.about}>
      <Helmet>
        <title>About AnimalQDKT Tech Solutions | Our Story & Values</title>
        <meta
          name="description"
          content="Meet AnimalQDKT Tech Solutions, a London-based team of engineers, strategists, and designers building resilient digital platforms."
        />
      </Helmet>

      <section className={`${styles.banner} sectionPadding`} aria-labelledby="about-heading">
        <div className="container">
          <h1 id="about-heading" className="sectionTitle">
            About AnimalQDKT Tech Solutions
          </h1>
          <p className="sectionSubtitle">
            Born in London, we are a collective of engineers, strategists, and experience designers who care deeply about
            building platforms that endure. Our mission is to create environments where technology and people thrive
            together.
          </p>
        </div>
      </section>

      <section className={`${styles.story} sectionPadding`} aria-labelledby="story-heading">
        <div className="container">
          <div className={styles.storyGrid}>
            <div>
              <h2 id="story-heading">Our story</h2>
              <p>
                AnimalQDKT Tech Solutions started as a small product studio helping start-ups ship faster. As our teams
                partnered with larger enterprises, we saw the need for a consultancy that values craft, empathy, and
                curiosity as much as technical expertise. We respond to complex challenges with cross-functional squads
                who can see both the system and the people within it.
              </p>
              <p>
                From data-driven policy platforms for government departments to highly regulated financial services
                ecosystems, we help clients modernise without disruption. Each engagement blends architecture precision
                with coaching to ensure teams remain confident long after go-live.
              </p>
            </div>
            <div className={styles.storyImageWrapper}>
              <img
                src="https://picsum.photos/900/600?random=141"
                alt="AnimalQDKT team collaborating in London workspace"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.timeline} sectionPadding`} aria-labelledby="timeline-heading">
        <div className="container">
          <h2 id="timeline-heading">Milestones</h2>
          <div className={styles.timelineGrid}>
            {timeline.map((item) => (
              <div key={item.year} className={styles.timelineItem}>
                <span className={styles.timelineYear}>{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.expertise} sectionPadding`} aria-labelledby="expertise-heading">
        <div className="container">
          <div className={styles.expertiseGrid}>
            <div>
              <h2 id="expertise-heading">Expertise that spans disciplines</h2>
              <p>
                Our team blends seasoned engineering leadership with product strategy, design research, and data
                science. This mix allows us to interrogate challenges from multiple angles and ensure that outcomes
                align with measurable goals.
              </p>
            </div>
            <ul className={styles.expertiseList}>
              {expertise.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className={`${styles.values} sectionPadding`} aria-labelledby="values-heading">
        <div className="container">
          <h2 id="values-heading">Mission and values</h2>
          <div className={styles.valuesGrid}>
            <div className={styles.valueCard}>
              <h3>Engineering with integrity</h3>
              <p>
                We believe that thoughtful engineering is rooted in transparency and accountability. Our teams share
                context openly, build inclusive cultures, and make ethical decisions about data and technology.
              </p>
            </div>
            <div className={styles.valueCard}>
              <h3>Learning is a constant</h3>
              <p>
                Every engagement contributes to shared knowledge. We invest in labs, hack days, and continuous training
                so we can pass learning directly to our partners.
              </p>
            </div>
            <div className={styles.valueCard}>
              <h3>People first, technology second</h3>
              <p>
                Technology is most effective when teams feel empowered. We design rituals, platforms, and processes that
                support people alongside systems.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.stack} sectionPadding`} aria-labelledby="stack-heading">
        <div className="container">
          <h2 id="stack-heading">Technology stack</h2>
          <p className="sectionSubtitle">
            Tools and platforms we regularly deploy to create scalable, maintainable, and observable solutions.
          </p>
          <div className={styles.stackGrid}>
            {techStack.map((tool) => (
              <span key={tool} className={styles.stackItem}>
                {tool}
              </span>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default About;