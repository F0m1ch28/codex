import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

function Terms() {
  return (
    <div className={styles.terms}>
      <Helmet>
        <title>Terms of Use | AnimalQDKT Tech Solutions</title>
        <meta
          name="description"
          content="Review the terms of use for AnimalQDKT Tech Solutions digital platforms and services."
        />
      </Helmet>
      <section className="sectionPadding">
        <div className="container">
          <h1 className="sectionTitle">Terms of Use</h1>
          <div className={styles.content}>
            <p>Last updated: August 2023</p>

            <h2>1. Introduction</h2>
            <p>
              These terms govern your use of the AnimalQDKT Tech Solutions website. By accessing our site, you agree to
              comply with these terms. If you do not agree, please discontinue use.
            </p>

            <h2>2. Intellectual property</h2>
            <p>
              All content on this site, including text, graphics, logos, and imagery, is owned by AnimalQDKT Tech
              Solutions or our partners. Content may not be copied, reproduced, or distributed without written
              permission.
            </p>

            <h2>3. Acceptable use</h2>
            <p>
              You agree not to misuse our site or interfere with its security. This includes attempting unauthorised
              access, introducing malicious code, or using the site in ways that compromise performance.
            </p>

            <h2>4. Third-party links</h2>
            <p>
              Our site may include links to third-party resources. These are provided for information only and do not
              represent endorsement. We are not responsible for external content or practices.
            </p>

            <h2>5. Limitation of liability</h2>
            <p>
              AnimalQDKT Tech Solutions provides site content for general information. We make no warranties regarding
              completeness or accuracy and are not liable for any losses arising from reliance on the information
              provided.
            </p>

            <h2>6. Governing law</h2>
            <p>
              These terms are governed by the laws of England and Wales. Any disputes will be resolved in the courts of
              England and Wales.
            </p>

            <h2>7. Contact</h2>
            <p>
              Questions about these terms should be sent to{' '}
              <a href="mailto:hello@animalqdkt.com" className={styles.link}>
                hello@animalqdkt.com
              </a>
              .
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Terms;