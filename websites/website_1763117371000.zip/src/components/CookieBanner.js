import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'animalqdkt_cookie_consent';

function CookieBanner() {
  const [visible, setVisible] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <div className={styles.content}>
        <p className={styles.message}>
          We use cookies to analyse traffic and tailor experiences. Read our policy to see how we manage data in
          compliance with GDPR.
        </p>
        {expanded && (
          <div className={styles.details}>
            <p>
              Essential cookies keep the site secure and functional. Analytical cookies help us understand product
              performance so we can improve engineering outcomes. You can adjust preferences at any time by contacting
              hello@animalqdkt.com.
            </p>
          </div>
        )}
        <div className={styles.actions}>
          <button type="button" className="btnPrimary" onClick={handleAccept}>
            Accept cookies
          </button>
          <button
            type="button"
            className="btnGhost"
            onClick={() => setExpanded((prev) => !prev)}
            aria-expanded={expanded}
          >
            {expanded ? 'Hide details' : 'Manage preferences'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;