import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About' },
  { to: '/services', label: 'Services' },
  { to: '/portfolio', label: 'Portfolio' },
  { to: '/team', label: 'Team' },
  { to: '/contact', label: 'Contact' }
];

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (menuOpen) {
      document.body.classList.add('menu-open');
    } else {
      document.body.classList.remove('menu-open');
    }
  }, [menuOpen]);

  return (
    <header className={styles.header} aria-label="Primary navigation">
      <a href="#main-content" className="skip-link">
        Skip to content
      </a>
      <div className={`container ${styles.headerInner}`}>
        <Link to="/" className={styles.brand} aria-label="AnimalQDKT Tech Solutions home">
          <span className={styles.logoMark}>A</span>
          <div>
            <span className={styles.brandName}>AnimalQDKT</span>
            <span className={styles.brandTagline}>Tech Solutions</span>
          </div>
        </Link>
        <nav className={styles.navigation}>
          <button
            className={styles.menuToggle}
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-expanded={menuOpen}
            aria-controls="primary-menu"
            aria-label="Toggle navigation menu"
          >
            <span />
            <span />
            <span />
          </button>
          <ul
            id="primary-menu"
            className={`${styles.navList} ${menuOpen ? styles.navListOpen : ''}`}
          >
            {navItems.map((item) => (
              <li key={item.to} className={styles.navItem}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.navLinkActive : ''}`
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
            <li className={styles.navCta}>
              <Link to="/contact" className="btnPrimary">
                Start a Conversation
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}

export default Header;