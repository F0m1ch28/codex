import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.footerGrid}`}>
        <div>
          <div className={styles.brandBlock}>
            <span className={styles.logoMark}>A</span>
            <div>
              <h3 className={styles.brandName}>AnimalQDKT Tech Solutions</h3>
              <p className={styles.brandSub}>
                Engineering resilient digital products from the heart of London.
              </p>
            </div>
          </div>
          <p className={styles.contactLine}>
            42 Tech Park Avenue, London, E14 5AB, United Kingdom
          </p>
          <p className={styles.contactLine}>
            <a href="tel:+442079460958" className={styles.footerLink}>
              +44 20 7946 0958
            </a>
          </p>
          <p className={styles.contactLine}>
            <a href="mailto:hello@animalqdkt.com" className={styles.footerLink}>
              hello@animalqdkt.com
            </a>
          </p>
        </div>
        <div>
          <h4 className={styles.columnTitle}>Explore</h4>
          <ul className={styles.linkList}>
            <li>
              <Link to="/about" className={styles.footerLink}>
                About
              </Link>
            </li>
            <li>
              <Link to="/services" className={styles.footerLink}>
                Services
              </Link>
            </li>
            <li>
              <Link to="/portfolio" className={styles.footerLink}>
                Portfolio
              </Link>
            </li>
            <li>
              <Link to="/team" className={styles.footerLink}>
                Team
              </Link>
            </li>
            <li>
              <Link to="/contact" className={styles.footerLink}>
                Contact
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className={styles.columnTitle}>Insights</h4>
          <ul className={styles.linkList}>
            <li>
              <a
                href="#"
                className={styles.footerLink}
                aria-label="Technology insights article placeholder link"
              >
                Modernising legacy estates
              </a>
            </li>
            <li>
              <a href="#" className={styles.footerLink} aria-label="Cloud readiness article placeholder link">
                Cloud adoption scorecard
              </a>
            </li>
            <li>
              <a href="#" className={styles.footerLink} aria-label="Engineering blog placeholder link">
                Engineering playbook
              </a>
            </li>
          </ul>
        </div>
        <div>
          <h4 className={styles.columnTitle}>Legal</h4>
          <ul className={styles.linkList}>
            <li>
              <Link to="/terms" className={styles.footerLink}>
                Terms of Use
              </Link>
            </li>
            <li>
              <Link to="/privacy" className={styles.footerLink}>
                Privacy Notice
              </Link>
            </li>
            <li>
              <Link to="/cookie-policy" className={styles.footerLink}>
                Cookie Policy
              </Link>
            </li>
          </ul>
          <div className={styles.socials}>
            <a href="#" className={styles.socialLink} aria-label="LinkedIn">
              LinkedIn
            </a>
            <a href="#" className={styles.socialLink} aria-label="Twitter">
              Twitter
            </a>
            <a href="#" className={styles.socialLink} aria-label="GitHub">
              GitHub
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <div className="container">
          <p className={styles.bottomText}>
            © {new Date().getFullYear()} AnimalQDKT Tech Solutions. Built with precision in London.
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;