document.addEventListener('DOMContentLoaded', () => {
  const header = document.getElementById('siteHeader');
  const navToggle = document.getElementById('menuToggle');
  const navLinks = document.getElementById('navLinks');
  const yearEl = document.getElementById('currentYear');

  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  if (navToggle && navLinks) {
    const toggleNav = () => {
      const isOpen = navLinks.classList.toggle('nav-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    };

    navToggle.addEventListener('click', toggleNav);

    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (navLinks.classList.contains('nav-open')) {
          navLinks.classList.remove('nav-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth > 900 && navLinks.classList.contains('nav-open')) {
        navLinks.classList.remove('nav-open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  if (header) {
    const setHeaderState = () => {
      if (window.scrollY > 96) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    };
    setHeaderState();
    window.addEventListener('scroll', setHeaderState);
  }

  const testimonialGrid = document.getElementById('testimonialGrid');
  if (testimonialGrid) {
    fetch('data/testimonials.json')
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to load testimonials');
        }
        return response.json();
      })
      .then(data => {
        testimonialGrid.innerHTML = '';
        const testimonials = data.testimonials || [];
        testimonials.forEach(testimonial => {
          const card = document.createElement('article');
          card.className = 'testimonial-card';
          card.innerHTML = `
            <p>“${testimonial.quote}”</p>
            <div>
              <span class="attribution">${testimonial.name}</span><br>
              <span class="attribution">${testimonial.title}</span>
            </div>
          `;
          testimonialGrid.appendChild(card);
        });
        if (!testimonials.length) {
          testimonialGrid.innerHTML = '<article class="testimonial-card placeholder"><p>Testimonials will arrive shortly.</p><span class="attribution">LumaForge Collective</span></article>';
        }
      })
      .catch(() => {
        testimonialGrid.innerHTML = '<article class="testimonial-card placeholder"><p>We encountered a hiccup loading stories. Please refresh to try again.</p><span class="attribution">LumaForge Collective</span></article>';
      });
  }

  const insightList = document.getElementById('insightList');
  if (insightList) {
    fetch('content/pillar-articles.json')
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to load insights');
        }
        return response.json();
      })
      .then(data => {
        insightList.innerHTML = '';
        const insights = data.insights || [];
        insights.forEach(item => {
          const article = document.createElement('article');
          article.className = 'insight-card';
          article.innerHTML = `
            <span>${item.category}</span>
            <h3>${item.title}</h3>
            <p>${item.excerpt}</p>
            <a class="text-button" href="${item.url}">Read the narrative →</a>
          `;
          insightList.appendChild(article);
        });
        if (!insights.length) {
          insightList.innerHTML = '<article class="insight-card placeholder"><h3>Insights coming soon</h3><p>Our team is preparing new field notes.</p></article>';
        }
      })
      .catch(() => {
        insightList.innerHTML = '<article class="insight-card placeholder"><h3>Unable to fetch insights</h3><p>Please check your network connection and reload.</p></article>';
      });
  }

  const cookieBanner = document.getElementById('cookieBanner');
  if (cookieBanner) {
    const acceptButton = document.getElementById('cookieAccept');
    const rejectButton = document.getElementById('cookieReject');
    const customizeButton = document.getElementById('cookieCustomize');
    const saveButton = document.getElementById('cookieSave');
    const analyticsCheckbox = document.getElementById('cookieAnalytics');
    const marketingCheckbox = document.getElementById('cookieMarketing');
    const customizePanel = document.getElementById('cookieCustomizePanel');
    const PREFERENCES_KEY = 'cookiePreferences';

    const showBanner = () => {
      cookieBanner.classList.add('is-visible');
      cookieBanner.removeAttribute('aria-hidden');
    };

    const hideBanner = () => {
      cookieBanner.classList.remove('is-visible');
      cookieBanner.setAttribute('aria-hidden', 'true');
    };

    const sendPreferences = async preferences => {
      try {
        await fetch('/api/preferences', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(preferences)
        });
      } catch (error) {
        console.warn('Preference sync failed', error);
      }
    };

    const savePreferences = (prefs, silent = false) => {
      const payload = {
        ...prefs,
        updatedAt: new Date().toISOString()
      };
      localStorage.setItem(PREFERENCES_KEY, JSON.stringify(payload));
      if (!silent) {
        hideBanner();
      }
      sendPreferences(payload);
    };

    const stored = localStorage.getItem(PREFERENCES_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        analyticsCheckbox.checked = Boolean(parsed.analytics);
        marketingCheckbox.checked = Boolean(parsed.marketing);
        hideBanner();
      } catch {
        showBanner();
      }
    } else {
      showBanner();
    }

    const toggleCustomize = () => {
      const isExpanded = customizeButton.getAttribute('aria-expanded') === 'true';
      customizeButton.setAttribute('aria-expanded', String(!isExpanded));
      customizePanel.hidden = isExpanded;
      if (!isExpanded) {
        customizePanel.classList.add('open');
      } else {
        customizePanel.classList.remove('open');
      }
    };

    acceptButton.addEventListener('click', () => {
      analyticsCheckbox.checked = true;
      marketingCheckbox.checked = true;
      savePreferences(
        { necessary: true, analytics: true, marketing: true },
        false
      );
    });

    rejectButton.addEventListener('click', () => {
      analyticsCheckbox.checked = false;
      marketingCheckbox.checked = false;
      savePreferences(
        { necessary: true, analytics: false, marketing: false },
        false
      );
    });

    customizeButton.addEventListener('click', toggleCustomize);

    saveButton.addEventListener('click', () => {
      const prefs = {
        necessary: true,
        analytics: analyticsCheckbox.checked,
        marketing: marketingCheckbox.checked
      };
      savePreferences(prefs, false);
    });
  }
});