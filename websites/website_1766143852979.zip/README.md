LumaForge Collective Website
============================

Overview
--------
This project delivers a multi-page marketing experience for LumaForge Collective, featuring a fully responsive interface, animated gradients, and integrated consent management. Pages include the landing experience, privacy policy, terms of service, and FAQ.

Structure
---------
- index.html — Primary marketing experience with dynamic insights and testimonials.
- policy.html — Privacy commitments and governance overview.
- terms.html — Terms of service and engagement framework.
- faq.html — Frequently asked questions.
- styles.css — Responsive visual system, advanced layouts, and global typography.
- script.js — Navigation controls, content hydration, and cookie preference handling.
- data/testimonials.json — Voice-of-client narratives loaded asynchronously.
- content/pillar-articles.json — Insight entries supplied to the insights section.
- Additional assets (icons, notes, brand documents) expand the bundled archive.

Getting Started
---------------
Open index.html in any modern browser. The experience is optimized for Chromium, Firefox, and Safari engines. No build step is required.

Cookie Preferences
------------------
The consent banner saves selections to localStorage and syncs with /api/preferences. Adjust analytics or marketing toggles through the Customize button on any page.

Customization
-------------
Update colors or typography within :root in styles.css. Add new testimonials or insights by editing the JSON data sources.

License
-------
All content © LumaForge Collective, 2024. External assets sourced from Pexels per their license.