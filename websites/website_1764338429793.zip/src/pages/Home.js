```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import styles from './Home.module.css';

const statsData = [
  { id: 1, label: 'Проектов реализовано', value: 320 },
  { id: 2, label: 'Экспертов в команде', value: 85 },
  { id: 3, label: 'Годов на рынке', value: 12 },
  { id: 4, label: 'Клиентов в портфеле', value: 140 }
];

const servicesData = [
  {
    id: 1,
    icon: '🧭',
    title: 'IT-консалтинг и аудит',
    description: 'Анализ бизнес-процессов, roadmap цифровой трансформации и оптимизация IT-ландшафта.'
  },
  {
    id: 2,
    icon: '⚙️',
    title: 'Разработка решений',
    description: 'Создание корпоративных систем, интеграция сервисов, адаптация под любую инфраструктуру.'
  },
  {
    id: 3,
    icon: '🛡️',
    title: 'Кибербезопасность',
    description: 'Комплексная защита данных, мониторинг угроз и проведение регулярных тестирований.'
  },
  {
    id: 4,
    icon: '☁️',
    title: 'Облачные сервисы',
    description: 'Миграция в облако, DevOps сопровождение и гибридные сценарии для высокой доступности.'
  }
];

const processSteps = [
  {
    id: 1,
    title: 'Диагностика и аналитика',
    description: 'Проводим интервью, аудит инфраструктуры и определяем цели проекта.'
  },
  {
    id: 2,
    title: 'Проектирование архитектуры',
    description: 'Создаём техническую концепцию, прототипы и план внедрения.'
  },
  {
    id: 3,
    title: 'Реализация и интеграция',
    description: 'Настраиваем сервисы, разрабатываем решения и объединяем их с текущими системами.'
  },
  {
    id: 4,
    title: 'Поддержка и развитие',
    description: 'Обучаем команду заказчика, обеспечиваем SLA и непрерывное улучшение.'
  }
];

const projectsData = [
  {
    id: 'p1',
    title: 'Единая цифровая платформа банка',
    category: 'Финансы',
    description: 'Объединили фронт-офис и бэк-офис, построили безопасную архитектуру обмена данными.',
    image: 'https://picsum.photos/1200/800?random=201'
  },
  {
    id: 'p2',
    title: 'Цифровизация сети клиник',
    category: 'Медицина',
    description: 'Внедрили электронную медицинскую карту и систему предиктивной аналитики.',
    image: 'https://picsum.photos/1200/800?random=202'
  },
  {
    id: 'p3',
    title: 'Платформа управления логистикой',
    category: 'Логистика',
    description: 'Реализовали модуль планирования маршрутов и контроль KPI в реальном времени.',
    image: 'https://picsum.photos/1200/800?random=203'
  },
  {
    id: 'p4',
    title: 'Интеллектуальная система прогнозирования',
    category: 'Ритейл',
    description: 'Создали ML-модели для прогнозирования спроса и оптимизации складских запасов.',
    image: 'https://picsum.photos/1200/800?random=204'
  }
];

const testimonialsData = [
  {
    id: 1,
    quote:
      'Команда ТехноПрофи показала глубокую экспертизу и гибкость. Внедрение новой CRM прошло без сбоев, и сегодня мы видим рост эффективности продаж.',
    author: 'Максим Романов',
    position: 'Директор по развитию, «СеверБанк»'
  },
  {
    id: 2,
    quote:
      'Проект миграции в облако был выполнен с опережением сроков. Качество поддержки позволяет нам уверенно масштабировать сервисы.',
    author: 'Екатерина Смирнова',
    position: 'CIO, «HealthLine Clinics»'
  },
  {
    id: 3,
    quote:
      'ТехноПрофи помогли выстроить прозрачную систему аналитики данных. Мы быстрее принимаем решения и точнее прогнозируем спрос.',
    author: 'Андрей Куликов',
    position: 'COO, «RetailPro»'
  }
];

const faqData = [
  {
    id: 1,
    question: 'Какие отрасли вы обслуживаете?',
    answer:
      'Мы работаем с финансовыми организациями, промышленными предприятиями, медицинскими учреждениями, ритейлом и сектором госуслуг. Экспертиза позволяет адаптировать решения под специфику отрасли.'
  },
  {
    id: 2,
    question: 'Как быстро вы можете приступить к проекту?',
    answer:
      'После предварительного знакомства и согласования целей старт проекта возможен в течение 2-3 недель. Для срочных задач формируем выделенную команду в кратчайшие сроки.'
  },
  {
    id: 3,
    question: 'Вы берёте на себя поддержку после внедрения?',
    answer:
      'Да, мы предоставляем комплексную поддержку с гарантированными SLA, регулярными обзорами и планом развития решений.'
  },
  {
    id: 4,
    question: 'Можно ли провести аудит существующих систем?',
    answer:
      'Мы проводим полноценный IT-аудит, оцениваем архитектуру, безопасность и эффективность процессов, предоставляем подробный отчёт с рекомендациями.'
  }
];

const blogPosts = [
  {
    id: 1,
    title: 'Как построить масштабируемую архитектуру данных',
    excerpt:
      'Разбираем ключевые принципы построения современной архитектуры данных и ошибки, которых стоит избегать.',
    date: '12 декабря 2023',
    link: '/services'
  },
  {
    id: 2,
    title: 'DevOps практики: ускоряем вывод продукта на рынок',
    excerpt:
      'Показываем, как реорганизовать процессы в компании и сократить цикл разработки с помощью DevOps.',
    date: '28 ноября 2023',
    link: '/services'
  },
  {
    id: 3,
    title: 'Кибербезопасность для бизнеса: чек-лист на 2024 год',
    excerpt:
      'Подготовили чек-лист из 12 шагов, которые помогут минимизировать риски и защитить критичные системы.',
    date: '15 октября 2023',
    link: '/services'
  }
];

const partnersList = [
  'СберТех',
  'МосИТ',
  'InnovaSoft',
  'CityCloud',
  'DataForge',
  'NetWave'
];

const Home = () => {
  const navigate = useNavigate();
  const contactRef = React.useRef(null);

  const [statsValues, setStatsValues] = React.useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = React.useState(0);
  const [activeCategory, setActiveCategory] = React.useState('Все');
  const [openFaq, setOpenFaq] = React.useState(faqData[0].id);
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });
  const [errors, setErrors] = React.useState({});
  const [statusMessage, setStatusMessage] = React.useState('');
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [loadedProjectImages, setLoadedProjectImages] = React.useState({});

  const filteredProjects =
    activeCategory === 'Все'
      ? projectsData
      : projectsData.filter((project) => project.category === activeCategory);

  React.useEffect(() => {
    let animationFrame;
    const duration = 1800;
    const startTimestamp = performance.now();

    const animate = (timestamp) => {
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      const values = statsData.map((stat) => Math.floor(stat.value * progress));
      setStatsValues(values);
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const handleScrollToContact = () => {
    if (contactRef.current) {
      contactRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const validateEmail = (email) => /\S+@\S+\.\S+/.test(email);

  const handleSubmit = (event) => {
    event.preventDefault();
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Введите имя';
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите рабочий email';
    } else if (!validateEmail(formData.email.trim())) {
      newErrors.email = 'Введите корректный email';
    }
    if (!formData.message.trim()) newErrors.message = 'Опишите вашу задачу';

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      setIsSubmitting(true);
      setStatusMessage('');
      setTimeout(() => {
        setIsSubmitting(false);
        setStatusMessage('Спасибо! Мы свяжемся с вами в течение рабочего дня.');
        setFormData({
          name: '',
          email: '',
          company: '',
          message: ''
        });
      }, 1400);
    }
  };

  return (
    <>
      <Helmet>
        <title>ТехноПрофи — IT-решения, консалтинг и поддержка в Москве</title>
        <meta
          name="description"
          content="ТехноПрофи разрабатывает IT-решения, проводит консалтинг и обеспечивает поддержку для бизнеса в Москве. Инновации, безопасность и масштабируемость."
        />
        <meta
          name="keywords"
          content="IT-решения, консалтинг, разработка, поддержка, Москва, ТехноПрофи"
        />
      </Helmet>

      <section
        className={styles.hero}
        style={{
          backgroundImage:
            'linear-gradient(135deg, rgba(30, 64, 175, 0.7), rgba(30, 58, 138, 0.6)), url(https://picsum.photos/1600/900?random=101)'
        }}
      >
        <div className={styles.heroContent}>
          <span className={styles.heroTag}>Ведущий поставщик IT-решений в Москве</span>
          <h1>
            Цифровые технологии
            <span> для ускорения бизнеса</span>
          </h1>
          <p>
            Мы объединяем стратегию, разработку и поддержку, чтобы ваши IT-системы работали быстро,
            безопасно и без простоев. Берём на себя весь цикл — от идеи до масштабирования.
          </p>
          <div className={styles.heroActions}>
            <button type="button" className={styles.heroButtonPrimary} onClick={handleScrollToContact}>
              Обсудить задачу
            </button>
            <button
              type="button"
              className={styles.heroButtonSecondary}
              onClick={() => navigate('/services')}
            >
              Смотреть услуги
            </button>
          </div>
          <div className={styles.heroMeta}>
            <div>
              <strong>ISO 27001</strong>
              <span>сертифицированная безопасность</span>
            </div>
            <div>
              <strong>24/7</strong>
              <span>поддержка и мониторинг</span>
            </div>
            <div>
              <strong>SLA 99.95%</strong>
              <span>гарантия доступности</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className={styles.statsGrid}>
          {statsData.map((stat, index) => (
            <article key={stat.id} className={styles.statCard}>
              <span className={styles.statValue}>{statsValues[index]}+</span>
              <span className={styles.statLabel}>{stat.label}</span>
              <span className={styles.statAccent} />
            </article>
          ))}
        </div>
      </section>

      <section className={styles.servicesSection} id="services">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Наши компетенции</span>
          <h2>IT-услуги для устойчивого роста</h2>
          <p>
            ТехноПрофи помогает компаниям выстраивать гибкие и безопасные цифровые платформы. Мы
            соединяем стратегию и технологии, чтобы вы опережали ожидания клиентов.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          {servicesData.map((service) => (
            <article key={service.id} className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">{service.icon}</span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <button
                type="button"
                className={styles.serviceLink}
                onClick={() => navigate('/services')}
              >
                Подробнее
              </button>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.aboutPreview}>
        <div className={styles.aboutContent}>
          <span className={styles.sectionTag}>О компании</span>
          <h2>Экосистема решений для вашего бизнеса</h2>
          <p>
            Мы создаём масштабируемые решения, обеспечиваем непрерывную поддержку и выступаем
            технологическим партнёром на каждом этапе цифровой трансформации. Наша команда объединяет
            архитекторов, аналитиков, разработчиков и инженеров по безопасности.
          </p>
          <ul className={styles.aboutList}>
            <li>Глубокая экспертиза в России и международные практики</li>
            <li>Технологическое партнёрство с лидерами рынка</li>
            <li>Прозрачное управление проектами и контроль качества</li>
          </ul>
          <button
            type="button"
            className={styles.aboutButton}
            onClick={() => navigate('/about')}
          >
            Узнать больше о ТехноПрофи
          </button>
        </div>
        <div className={styles.aboutMedia}>
          <img
            src="https://picsum.photos/800/600?random=102"
            alt="Команда ТехноПрофи за обсуждением цифрового проекта"
            loading="lazy"
          />
          <div className={styles.aboutBadge}>
            <strong>Digital Impact 2023</strong>
            <span>Лучший проект по аналитике данных</span>
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Как мы работаем</span>
          <h2>От vision до измеримых результатов</h2>
          <p>
            Прозрачная методология и гибкий подход позволяют нам реализовывать проекты любой
            сложности, сохраняя сроки и качество.
          </p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step, index) => (
            <article key={step.id} className={styles.processCard}>
              <span className={styles.processIndex}>
                {index + 1 < 10 ? `0${index + 1}` : index + 1}
              </span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Портфолио</span>
          <h2>Проекты, которыми мы гордимся</h2>
          <p>
            Мы помогаем компаниям строить цифровые платформы, повышать безопасность и повышать
            эффективность процессов.
          </p>
        </div>
        <div className={styles.filterBar}>
          {['Все', 'Финансы', 'Медицина', 'Логистика', 'Ритейл'].map((category) => (
            <button
              key={category}
              type="button"
              className={`${styles.filterButton} ${
                activeCategory === category ? styles.filterButtonActive : ''
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <div className={styles.projectImageWrapper}>
                <img
                  src={project.image}
                  alt={project.title}
                  loading="lazy"
                  onLoad={() =>
                    setLoadedProjectImages((prev) => ({ ...prev, [project.id]: true }))
                  }
                  className={`${styles.projectImage} ${
                    loadedProjectImages[project.id] ? styles.projectImageLoaded : ''
                  }`}
                />
              </div>
              <div className={styles.projectContent}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <button
                  type="button"
                  className={styles.projectButton}
                  onClick={() => navigate('/services')}
                >
                  Как мы работали
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Отзывы</span>
          <h2>Нас рекомендуют лидеры рынка</h2>
          <p>
            Мы выстраиваем долгосрочные партнёрства, обеспечивая прозрачность, открытость и
            ответственность на каждом этапе проектов.
          </p>
        </div>
        <div className={styles.testimonialCarousel}>
          <div className={styles.testimonial}>
            <p className={styles.testimonialQuote}>
              «{testimonialsData[activeTestimonial].quote}»
            </p>
            <div className={styles.testimonialAuthor}>
              <strong>{testimonialsData[activeTestimonial].author}</strong>
              <span>{testimonialsData[activeTestimonial].position}</span>
            </div>
          </div>
          <div className={styles.testimonialControls}>
            <button
              type="button"
              onClick={() =>
                setActiveTestimonial((prev) =>
                  prev === 0 ? testimonialsData.length - 1 : prev - 1
                )
              }
              aria-label="Предыдущий отзыв"
            >
              ←
            </button>
            <div className={styles.testimonialDots}>
              {testimonialsData.map((item, index) => (
                <span
                  key={item.id}
                  className={`${styles.testimonialDot} ${
                    index === activeTestimonial ? styles.testimonialDotActive : ''
                  }`}
                />
              ))}
            </div>
            <button
              type="button"
              onClick={() =>
                setActiveTestimonial((prev) => (prev + 1) % testimonialsData.length)
              }
              aria-label="Следующий отзыв"
            >
              →
            </button>
          </div>
        </div>
      </section>

      <section className={styles.partnersSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Партнёры</span>
          <h2>Доверие ведущих компаний</h2>
          <p>
            Сотрудничаем с технологическими лидерами, чтобы предоставлять лучшие практики и решения.
          </p>
        </div>
        <div className={styles.partnersGrid}>
          {partnersList.map((partner) => (
            <span key={partner} className={styles.partnerItem}>
              {partner}
            </span>
          ))}
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>FAQ</span>
          <h2>Частые вопросы</h2>
          <p>Не нашли ответ? Напишите нам — мы подготовим предложение под вашу задачу.</p>
        </div>
        <div className={styles.faqList}>
          {faqData.map((item) => (
            <article
              key={item.id}
              className={`${styles.faqItem} ${openFaq === item.id ? styles.faqItemOpen : ''}`}
            >
              <button
                type="button"
                className={styles.faqQuestion}
                onClick={() => setOpenFaq((prev) => (prev === item.id ? null : item.id))}
                aria-expanded={openFaq === item.id}
              >
                {item.question}
                <span>{openFaq === item.id ? '−' : '+'}</span>
              </button>
              <div className={styles.faqAnswer}>
                <p>{item.answer}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Блог</span>
          <h2>Свежие материалы</h2>
          <p>Делимся практическими инсайтами и трендами из мира технологий.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.id} className={styles.blogCard}>
              <span className={styles.blogDate}>{post.date}</span>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <button
                type="button"
                className={styles.blogButton}
                onClick={() => navigate(post.link)}
              >
                Читать
              </button>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <span className={styles.sectionTag}>Готовы к переменам?</span>
          <h2>Давайте обсудим ваш IT-проект</h2>
          <p>
            Расскажите о своих планах, и мы подготовим индивидуальную стратегию внедрения цифровых
            решений.
          </p>
        </div>
        <div className={styles.ctaActions}>
          <button type="button" onClick={handleScrollToContact}>
            Оставить заявку
          </button>
          <button type="button" onClick={() => navigate('/contacts')}>
            Контакты
          </button>
        </div>
      </section>

      <section className={styles.contactSection} id="home-contact" ref={contactRef}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Связаться</span>
          <h2>Заполните форму — мы ответим в ближайшее время</h2>
          <p>
            Расскажите о ваших задачах, и эксперты ТехноПрофи подготовят первичное решение и
            предложат оптимальный формат сотрудничества.
          </p>
        </div>
        <form className={styles.contactForm} onSubmit={handleSubmit} noValidate>
          <div className={styles.formRow}>
            <label htmlFor="home-name">Имя*</label>
            <input
              id="home-name"
              type="text"
              name="name"
              placeholder="Как к вам обращаться"
              value={formData.name}
              onChange={(event) =>
                setFormData((prev) => ({ ...prev, name: event.target.value }))
              }
              aria-invalid={Boolean(errors.name)}
            />
            {errors.name && <span className={styles.errorText}>{errors.name}</span>}
          </div>
          <div className={styles.formRow}>
            <label htmlFor="home-email">Рабочий email*</label>
            <input
              id="home-email"
              type="email"
              name="email"
              placeholder="name@company.ru"
              value={formData.email}
              onChange={(event) =>
                setFormData((prev) => ({ ...prev, email: event.target.value }))
              }
              aria-invalid={Boolean(errors.email)}
            />
            {errors.email && <span className={styles.errorText}>{errors.email}</span>}
          </div>
          <div className={styles.formRow}>
            <label htmlFor="home-company">Компания</label>
            <input
              id="home-company"
              type="text"
              name="company"
              placeholder="Название организации"
              value={formData.company}
              onChange={(event) =>
                setFormData((prev) => ({ ...prev, company: event.target.value }))
              }
            />
          </div>
          <div className={styles.formRowFull}>
            <label htmlFor="home-message">Задача*</label>
            <textarea
              id="home-message"
              name="message"
              rows="4"
              placeholder="Опишите проект, текущие цели или проблемы"
              value={formData.message}
              onChange={(event) =>
                setFormData((prev) => ({ ...prev, message: event.target.value }))
              }
              aria-invalid={Boolean(errors.message)}
            />
            {errors.message && <span className={styles.errorText}>{errors.message}</span>}
          </div>
          <div className={styles.formFooter}>
            <button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Отправляем...' : 'Отправить заявку'}
            </button>
            <p>
              Нажимая на кнопку, вы соглашаетесь с{' '}
              <button
                type="button"
                className={styles.inlineLink}
                onClick={() => navigate('/privacy')}
              >
                политикой обработки данных
              </button>
              .
            </p>
          </div>
          {statusMessage && (
            <div className={styles.successMessage} role="status" aria-live="polite">
              {statusMessage}
            </div>
          )}
        </form>
      </section>
    </>
  );
};

export default Home;
```