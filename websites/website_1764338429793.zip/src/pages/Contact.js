```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [errors, setErrors] = React.useState({});
  const [status, setStatus] = React.useState('');
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const validateEmail = (email) => /\S+@\S+\.\S+/.test(email);
  const validatePhone = (phone) => /^\+?\d.{8,}$/.test(phone);

  const handleSubmit = (event) => {
    event.preventDefault();
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Введите имя';
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите email';
    } else if (!validateEmail(formData.email.trim())) {
      newErrors.email = 'Некорректный email';
    }
    if (formData.phone && !validatePhone(formData.phone.trim())) {
      newErrors.phone = 'Некорректный номер телефона';
    }
    if (!formData.message.trim()) newErrors.message = 'Напишите, что вас интересует';

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      setIsSubmitting(true);
      setStatus('');
      setTimeout(() => {
        setIsSubmitting(false);
        setStatus('Спасибо! Мы получили вашу заявку и свяжемся с вами в ближайшее время.');
        setFormData({
          name: '',
          email: '',
          phone: '',
          message: ''
        });
      }, 1500);
    }
  };

  return (
    <>
      <Helmet>
        <title>Контакты ТехноПрофи — Москва, ул. Тверская, д. 15, офис 304</title>
        <meta
          name="description"
          content="Свяжитесь с компанией ТехноПрофи: адрес в Москве, телефон +7 (495) 123-45-67, электронная почта info@technoprofi.ru. Оставьте заявку через форму."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Свяжитесь с нами</h1>
          <p>
            Готовы обсудить проект, ответить на вопросы и предложить оптимальный сценарий внедрения
            решений.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className={styles.infoCard}>
          <h2>Контактные данные</h2>
          <ul>
            <li>
              <strong>Адрес:</strong> Москва, ул. Тверская, д. 15, офис 304
            </li>
            <li>
              <strong>Телефон:</strong> <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            </li>
            <li>
              <strong>Email:</strong> <a href="mailto:info@technoprofi.ru">info@technoprofi.ru</a>
            </li>
            <li>
              <strong>Время работы:</strong> Пн-Пт 09:00–19:00
            </li>
          </ul>
        </div>

        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <h2>Отправить запрос</h2>
          <div className={styles.formGrid}>
            <div className={styles.formField}>
              <label htmlFor="contact-name">Имя*</label>
              <input
                id="contact-name"
                type="text"
                value={formData.name}
                onChange={(event) =>
                  setFormData((prev) => ({ ...prev, name: event.target.value }))
                }
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span>{errors.name}</span>}
            </div>
            <div className={styles.formField}>
              <label htmlFor="contact-email">Email*</label>
              <input
                id="contact-email"
                type="email"
                value={formData.email}
                onChange={(event) =>
                  setFormData((prev) => ({ ...prev, email: event.target.value }))
                }
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span>{errors.email}</span>}
            </div>
            <div className={styles.formField}>
              <label htmlFor="contact-phone">Телефон</label>
              <input
                id="contact-phone"
                type="tel"
                value={formData.phone}
                onChange={(event) =>
                  setFormData((prev) => ({ ...prev, phone: event.target.value }))
                }
                aria-invalid={Boolean(errors.phone)}
              />
              {errors.phone && <span>{errors.phone}</span>}
            </div>
            <div className={styles.formFieldFull}>
              <label htmlFor="contact-message">Сообщение*</label>
              <textarea
                id="contact-message"
                rows="4"
                value={formData.message}
                onChange={(event) =>
                  setFormData((prev) => ({ ...prev, message: event.target.value }))
                }
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span>{errors.message}</span>}
            </div>
          </div>
          <button type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'Отправляем...' : 'Отправить'}
          </button>
          {status && (
            <p className={styles.formStatus} role="status" aria-live="polite">
              {status}
            </p>
          )}
        </form>
      </section>

      <section className={styles.mapSection} aria-label="Карта расположения офиса ТехноПрофи">
        <iframe
          title="Офис ТехноПрофи на карте Москвы"
          src="https://www.openstreetmap.org/export/embed.html?bbox=37.598%2C55.761%2C37.608%2C55.767&layer=mapnik&marker=55.7645%2C37.603"
          allowFullScreen
          loading="lazy"
        />
      </section>
    </>
  );
};

export default Contact;
```