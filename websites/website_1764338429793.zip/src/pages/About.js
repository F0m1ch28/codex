```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const timeline = [
  {
    year: '2012',
    title: 'Старт команды',
    description:
      'Создали команду архитекторов и системных аналитиков для реализации сложных проектов.'
  },
  {
    year: '2016',
    title: 'Собственные R&D-центры',
    description: 'Открыли лабораторию по аналитике данных и компетенции по DevOps.'
  },
  {
    year: '2020',
    title: 'Международные проекты',
    description: 'Вышли на новые рынки и расширили портфель крупных корпоративных клиентов.'
  },
  {
    year: '2023',
    title: '300+ проектов',
    description: 'Выполнили проекты для финансового, медицинского и промышленного секторов.'
  }
];

const values = [
  {
    id: 1,
    title: 'Ответственность',
    description:
      'Берём на себя обязательства по качеству и соблюдению сроков, подтверждённые SLA и KPI.'
  },
  {
    id: 2,
    title: 'Инновации',
    description:
      'Ежегодно инвестируем в R&D и внедряем проверенные практики в продуктах клиентов.'
  },
  {
    id: 3,
    title: 'Партнёрство',
    description:
      'Работаем как часть вашей команды: прозрачные процессы, регулярные отчёты и гибкое взаимодействие.'
  }
];

const team = [
  {
    id: 1,
    name: 'Мария Воронцова',
    role: 'Генеральный директор',
    description:
      '20 лет в управлении IT-проектами. Отвечает за стратегию развития и качество клиентского сервиса.',
    image: 'https://picsum.photos/400/400?random=301'
  },
  {
    id: 2,
    name: 'Алексей Глушков',
    role: 'Технический директор',
    description:
      'Руководит инженерными командами, сертифицирован AWS Solutions Architect, эксперт по DevOps.',
    image: 'https://picsum.photos/400/400?random=302'
  },
  {
    id: 3,
    name: 'Екатерина Литвинова',
    role: 'Директор по консалтингу',
    description:
      'Ведёт проекты трансформации и управляет программой стратегического консалтинга.',
    image: 'https://picsum.photos/400/400?random=303'
  },
  {
    id: 4,
    name: 'Игорь Назаров',
    role: 'Руководитель практики безопасности',
    description:
      'Эксперт по информационной безопасности, сертификации ISO и управлению рисками.',
    image: 'https://picsum.photos/400/400?random=304'
  }
];

const certificates = [
  {
    id: 1,
    title: 'ISO/IEC 27001:2022',
    description: 'Система менеджмента информационной безопасности.'
  },
  {
    id: 2,
    title: 'Cisco Advanced Security Architecture',
    description: 'Партнёрский статус по реализации решений уровня enterprise.'
  },
  {
    id: 3,
    title: 'Microsoft Solutions Partner',
    description: 'Поставщик корпоративных решений Microsoft Azure и M365.'
  }
];

const About = () => (
  <>
    <Helmet>
      <title>О компании ТехноПрофи — миссия, команда, достижения</title>
      <meta
        name="description"
        content="ТехноПрофи — технологический партнёр для бизнеса. Узнайте больше о нашей миссии, ценностях, команде экспертов и сертификатах."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <span className={styles.tag}>О нас</span>
        <h1>Делаем технологии драйвером роста бизнеса</h1>
        <p>
          ТехноПрофи — российская компания, специализирующаяся на цифровой трансформации, разработке
          корпоративных систем и управлении IT-инфраструктурой. Мы совмещаем технологическую
          экспертизу, стратегическое мышление и клиентоориентированный подход.
        </p>
      </div>
      <div className={styles.heroMedia}>
        <img
          src="https://picsum.photos/1200/600?random=105"
          alt="Стратегическая сессия команды ТехноПрофи"
          loading="lazy"
        />
      </div>
    </section>

    <section className={styles.missionSection}>
      <div className={styles.missionCard}>
        <h2>Наша миссия</h2>
        <p>
          Мы помогаем компаниям превращать данные и технологии в конкурентные преимущества. Наши
          решения ускоряют принятие решений, повышают эффективность процессов и обеспечивают высокий
          уровень безопасности.
        </p>
      </div>
      <div className={styles.values}>
        {values.map((value) => (
          <article key={value.id} className={styles.valueCard}>
            <h3>{value.title}</h3>
            <p>{value.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.timelineSection}>
      <h2>Путь развития</h2>
      <div className={styles.timeline}>
        {timeline.map((item) => (
          <article key={item.year} className={styles.timelineItem}>
            <span className={styles.timelineYear}>{item.year}</span>
            <h3>{item.title}</h3>
            <p>{item.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.teamSection}>
      <div className={styles.teamHeader}>
        <h2>Команда экспертов</h2>
        <p>
          Мы объединяем специалистов с международными сертификатами и опытом реализации крупных
          проектов в разных отраслях.
        </p>
      </div>
      <div className={styles.teamGrid}>
        {team.map((member) => (
          <article key={member.id} className={styles.teamCard}>
            <div className={styles.teamImageWrapper}>
              <img
                src={member.image}
                alt={`${member.name} — ${member.role}`}
                loading="lazy"
              />
              <div className={styles.teamOverlay}>
                <p>{member.description}</p>
              </div>
            </div>
            <div className={styles.teamContent}>
              <h3>{member.name}</h3>
              <span>{member.role}</span>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.certSection}>
      <h2>Сертификаты и партнёрства</h2>
      <div className={styles.certGrid}>
        {certificates.map((cert) => (
          <article key={cert.id} className={styles.certCard}>
            <h3>{cert.title}</h3>
            <p>{cert.description}</p>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default About;
```