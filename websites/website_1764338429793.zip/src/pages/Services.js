```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    id: 1,
    title: 'IT-консалтинг',
    description:
      'Строим стратегию цифровой трансформации, оптимизируем IT-ландшафт, проводим аудит бизнес-процессов и технологий.',
    features: [
      'Оценка зрелости процессов и инфраструктуры',
      'Формирование технологического roadmap',
      'Проектирование корпоративной архитектуры',
      'Экономическая эффективность и финансовое моделирование'
    ]
  },
  {
    id: 2,
    title: 'Разработка программного обеспечения',
    description:
      'Проектируем и создаём корпоративные приложения, интегрируем решения и обеспечиваем сопровождение.',
    features: [
      'Разработка web и мобильных приложений',
      'Интеграция с существующими системами',
      'Построение microservices и API-платформ',
      'QA и автоматизация тестирования'
    ]
  },
  {
    id: 3,
    title: 'Техническая поддержка',
    description:
      'Обеспечиваем стабильную работу систем, мониторинг доступности и оперативное реагирование на инциденты.',
    features: [
      '24/7 мониторинг и служба поддержки',
      'Управление инцидентами и проблемами',
      'Регламентные работы и обновления',
      'Обучение и поддержка пользователей'
    ]
  },
  {
    id: 4,
    title: 'Облачные решения',
    description:
      'Мигрируем сервисы в облако, настраиваем инфраструктуру и управляем ресурсами для максимальной эффективности.',
    features: [
      'Миграция и модернизация приложений',
      'Создание гибридных и мультиоблачных сред',
      'Настройка CI/CD и DevOps практик',
      'Оптимизация затрат и управляемость'
    ]
  }
];

const engagement = [
  {
    id: 1,
    title: 'Discovery',
    description: 'Интервью, сбор требований, аудит инфраструктуры, оценка рисков и формирование цели.'
  },
  {
    id: 2,
    title: 'Проектирование',
    description: 'Создание архитектуры, выбор технологий, план реализации и модели взаимодействия.'
  },
  {
    id: 3,
    title: 'Разработка и внедрение',
    description: 'Итеративное развитие, интеграция, тестирование, пилотирование и запуск.'
  },
  {
    id: 4,
    title: 'Поддержка и развитие',
    description: 'SLA, мониторинг, управление изменениями, обучение команд и постоянное улучшение.'
  }
];

const Services = () => (
  <>
    <Helmet>
      <title>Услуги ТехноПрофи — консалтинг, разработка, поддержка, облако</title>
      <meta
        name="description"
        content="IT-консалтинг, разработка ПО, техническая поддержка и облачные решения от ТехноПрофи. Комплексное сопровождение технологических проектов."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <h1>Комплекс услуг для цифровой трансформации</h1>
        <p>
          Предлагаем полный цикл — от стратегического консалтинга до поддержки и модернизации
          решений. Выбирайте готовые сервисы или формируйте индивидуальный пакет.
        </p>
      </div>
    </section>

    <section className={styles.servicesSection}>
      <div className={styles.servicesGrid}>
        {services.map((service) => (
          <article key={service.id} className={styles.serviceCard}>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
            <ul>
              {service.features.map((feature) => (
                <li key={feature}>{feature}</li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.engagementSection}>
      <div className={styles.engagementHeader}>
        <h2>Как мы подключаемся к проекту</h2>
        <p>
          Прозрачная методология, гибкое планирование и ориентир на результат на каждом этапе
          сотрудничества.
        </p>
      </div>
      <div className={styles.engagementGrid}>
        {engagement.map((stage) => (
          <article key={stage.id} className={styles.engagementCard}>
            <span>{stage.id < 10 ? `0${stage.id}` : stage.id}</span>
            <h3>{stage.title}</h3>
            <p>{stage.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.finalCta}>
      <div className={styles.finalCtaContent}>
        <h2>Готовы подобрать оптимальное решение?</h2>
        <p>Свяжитесь с нами, и мы сформируем индивидуальное предложение под ваш запрос.</p>
        <a href="/contacts">Связаться</a>
      </div>
    </section>
  </>
);

export default Services;
```