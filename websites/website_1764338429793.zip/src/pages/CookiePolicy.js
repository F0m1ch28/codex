```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Политика Cookies — ТехноПрофи</title>
      <meta
        name="description"
        content="Политика использования файлов cookies на сайте ТехноПрофи. Узнайте, какие данные собираются и как управлять своими настройками."
      />
    </Helmet>

    <section className={styles.container}>
      <h1>Политика использования файлов Cookies</h1>
      <p>Последнее обновление: 2 января 2024 года</p>

      <h2>1. Что такое cookies</h2>
      <p>
        Cookies — это небольшие текстовые файлы, которые сохраняются на вашем устройстве при
        посещении сайта. Они помогают улучшить работу сайта и сделать взаимодействие удобнее.
      </p>

      <h2>2. Какие cookies мы используем</h2>
      <ul>
        <li>Технические cookies — необходимы для корректного отображения страниц.</li>
        <li>Аналитические cookies — позволяют анализировать посещаемость и улучшать сервис.</li>
        <li>Функциональные cookies — запоминают ваши настройки и предпочтения.</li>
      </ul>

      <h2>3. Управление cookies</h2>
      <p>
        Вы можете настроить или отключить cookies в настройках браузера. Однако это может повлиять на
        функционирование сайта. Используя сайт, вы соглашаетесь на обработку cookies.
      </p>

      <h2>4. Контакты</h2>
      <p>
        Вопросы по использованию cookies направляйте на{' '}
        <a href="mailto:info@technoprofi.ru">info@technoprofi.ru</a>.
      </p>
    </section>
  </>
);

export default CookiePolicy;
```