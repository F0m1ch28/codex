```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.brand}>
          <div className={styles.logoGroup}>
            <span className={styles.logoMark}>Т</span>
            <span className={styles.logoText}>ТехноПрофи</span>
          </div>
          <p className={styles.brandDescription}>
            Комплексные IT-решения, консалтинг и сопровождение для компаний, которые стремятся к
            технологическому лидерству.
          </p>
        </div>
        <div className={styles.grid}>
          <div>
            <h3 className={styles.footerTitle}>Навигация</h3>
            <ul className={styles.linkList}>
              <li><Link to="/">Главная</Link></li>
              <li><Link to="/about">О компании</Link></li>
              <li><Link to="/services">Услуги</Link></li>
              <li><Link to="/contacts">Контакты</Link></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.footerTitle}>Правовая информация</h3>
            <ul className={styles.linkList}>
              <li><Link to="/terms">Условия использования</Link></li>
              <li><Link to="/privacy">Политика конфиденциальности</Link></li>
              <li><Link to="/cookie-policy">Политика Cookies</Link></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.footerTitle}>Контакты</h3>
            <ul className={styles.contactList}>
              <li>Москва, ул. Тверская, д. 15, офис 304</li>
              <li><a href="tel:+74951234567">+7 (495) 123-45-67</a></li>
              <li><a href="mailto:info@technoprofi.ru">info@technoprofi.ru</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottomLine}>
        <p>© {currentYear} ООО «ТехноПрофи». Все права защищены.</p>
        <div className={styles.socials}>
          <a href="https://t.me" target="_blank" rel="noreferrer">Telegram</a>
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">LinkedIn</a>
          <a href="https://vk.com" target="_blank" rel="noreferrer">VK</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
```