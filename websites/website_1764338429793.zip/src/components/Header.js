```javascript
import React from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { id: 1, path: '/', label: 'Главная' },
  { id: 2, path: '/about', label: 'О компании' },
  { id: 3, path: '/services', label: 'Услуги' },
  { id: 4, path: '/contacts', label: 'Контакты' }
];

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const location = useLocation();

  React.useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  React.useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 1024) {
        setIsMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="На главную страницу">
          <span className={styles.logoMark}>Т</span>
          <span className={styles.logoText}>ТехноПрофи</span>
        </Link>
        <nav
          className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`}
          aria-label="Основная навигация"
        >
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.id}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.navLinkActive : ''}`
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <a className={styles.navPhone} href="tel:+74951234567">
            +7 (495) 123-45-67
          </a>
        </nav>
        <button
          type="button"
          className={`${styles.menuButton} ${isMenuOpen ? styles.menuButtonActive : ''}`}
          aria-expanded={isMenuOpen}
          aria-label="Меню"
          onClick={() => setIsMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;
```