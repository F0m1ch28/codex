```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(() => {
    if (typeof window !== 'undefined') {
      return !localStorage.getItem('technoprofi_cookie_consent');
    }
    return true;
  });

  const handleAccept = () => {
    localStorage.setItem('technoprofi_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.message}>
        <h4>Мы используем cookies</h4>
        <p>
          Продолжая пользоваться сайтом, вы даёте согласие на обработку файлов cookies. Подробности
          в <Link to="/cookie-policy">Политике cookies</Link>.
        </p>
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Согласен
      </button>
    </div>
  );
};

export default CookieBanner;
```