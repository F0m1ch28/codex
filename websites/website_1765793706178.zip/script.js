document.addEventListener('DOMContentLoaded', () => {
  const header = document.querySelector('.site-header');
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  const cta = document.querySelector('.nav-cta');

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const isOpen = header.dataset.navOpen === 'true';
      header.dataset.navOpen = !isOpen;
      navToggle.setAttribute('aria-expanded', String(!isOpen));
      if (!isOpen) {
        nav.classList.add('is-open');
      } else {
        nav.classList.remove('is-open');
      }
    });

    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        header.dataset.navOpen = false;
        navToggle.setAttribute('aria-expanded', 'false');
        nav.classList.remove('is-open');
      });
    });
  }

  if (cta) {
    cta.addEventListener('focus', () => header.dataset.navOpen = false);
  }

  const banner = document.querySelector('.cookie-banner');
  const acceptBtn = banner?.querySelector('[data-action="accept"]');
  const declineBtn = banner?.querySelector('[data-action="decline"]');
  const consent = localStorage.getItem('cookieConsent');

  const hideBanner = () => {
    banner?.setAttribute('data-visible', 'false');
  };

  if (banner && !consent) {
    requestAnimationFrame(() => {
      banner.setAttribute('data-visible', 'true');
    });
  }

  acceptBtn?.addEventListener('click', () => {
    localStorage.setItem('cookieConsent', 'accepted');
    hideBanner();
  });

  declineBtn?.addEventListener('click', () => {
    localStorage.setItem('cookieConsent', 'declined');
    hideBanner();
  });
});