import { useEffect, useState } from 'react';

const Seo = ({ title, description, keywords }) => {
  const [HelmetComponent, setHelmetComponent] = useState(null);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return undefined;
    }

    const applyFallbackMeta = () => {
      if (title) {
        document.title = title;
      }
      if (description) {
        let descriptionTag = document.querySelector('meta[name="description"]');
        if (!descriptionTag) {
          descriptionTag = document.createElement('meta');
          descriptionTag.setAttribute('name', 'description');
          document.head.appendChild(descriptionTag);
        }
        descriptionTag.setAttribute('content', description);
      }
      if (keywords) {
        let keywordsTag = document.querySelector('meta[name="keywords"]');
        if (!keywordsTag) {
          keywordsTag = document.createElement('meta');
          keywordsTag.setAttribute('name', 'keywords');
          document.head.appendChild(keywordsTag);
        }
        keywordsTag.setAttribute('content', keywords);
      }
    };

    applyFallbackMeta();

    const attemptAttach = () => {
      if (window.ReactHelmet && window.ReactHelmet.Helmet) {
        setHelmetComponent(() => window.ReactHelmet.Helmet);
        return true;
      }
      return false;
    };

    if (attemptAttach()) {
      return undefined;
    }

    const intervalId = window.setInterval(() => {
      if (attemptAttach()) {
        window.clearInterval(intervalId);
      }
    }, 200);

    return () => window.clearInterval(intervalId);
  }, [title, description, keywords]);

  if (HelmetComponent) {
    const Helmet = HelmetComponent;
    return (
      <Helmet>
        {title && <title>{title}</title>}
        {description && <meta name="description" content={description} />}
        {keywords && <meta name="keywords" content={keywords} />}
        <html lang="ru" />
      </Helmet>
    );
  }

  return null;
};

export default Seo;