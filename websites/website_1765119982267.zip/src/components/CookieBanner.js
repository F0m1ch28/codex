import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const storageKey = 'company-cookie-consent';
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const savedConsent = window.localStorage.getItem(storageKey);
    if (!savedConsent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem(storageKey, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <aside className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        Мы используем cookie, чтобы персонализировать опыт и анализировать работу сайта. Подробнее в{' '}
        <Link to="/cookie-policy" className={styles.link}>
          политике использования cookie
        </Link>
        .
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.acceptButton} onClick={acceptCookies}>
          Принять
        </button>
      </div>
    </aside>
  );
};

export default CookieBanner;