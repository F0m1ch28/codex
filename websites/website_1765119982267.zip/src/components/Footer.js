import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className={styles.footer} aria-label="Подвал сайта">
      <div className={`container ${styles.grid}`}>
        <div className={styles.column}>
          <span className={styles.logo}>Компания</span>
          <p className={styles.text}>
            Мы объединяем стратегию, дизайн и технологии, чтобы помогать организациям
            расти устойчиво и осознанно.
          </p>
        </div>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Навигация</h3>
          <nav className={styles.links} aria-label="Навигация по сайту в подвале">
            <NavLink to="/">Главная</NavLink>
            <NavLink to="/uslugi">Услуги</NavLink>
            <NavLink to="/o-kompanii">О компании</NavLink>
            <NavLink to="/kontakty">Контакты</NavLink>
          </nav>
        </div>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Правовая информация</h3>
          <nav className={styles.links} aria-label="Правовые документы">
            <NavLink to="/terms">Условия использования</NavLink>
            <NavLink to="/privacy">Политика конфиденциальности</NavLink>
            <NavLink to="/cookie-policy">Политика использования cookie</NavLink>
          </nav>
        </div>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Контакты</h3>
          <p className={styles.text}>[Адрес компании]</p>
          <a className={styles.link} href="tel:+7XXXXXXXXXX">[+7 (XXX) XXX-XX-XX]</a>
          <a className={styles.link} href="mailto:info@компания.ru">[info@компания.ru]</a>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {year} Компания. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;