import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './HomePage.module.css';

const statsData = [
  { label: 'Лет опыта в трансформации компаний', value: 12, suffix: '+' },
  { label: 'Успешных проектов в разных отраслях', value: 180, suffix: '+' },
  { label: 'Экспертов и партнеров в команде', value: 45, suffix: '+' },
  { label: 'Повторных обращений от клиентов', value: 92, suffix: '%' },
];

const servicesData = [
  {
    title: 'Стратегический консалтинг',
    description:
      'Разрабатываем направление роста и перестраиваем бизнес-модели с учетом динамики рынка.',
    points: ['Диагностика бизнеса', 'Дорожные карты трансформации', 'Запуск стратегических инициатив'],
  },
  {
    title: 'Цифровые решения',
    description:
      'Проектируем платформы и сервисы, которые помогают командам и клиентам работать быстрее.',
    points: ['Внедрение платформ и CRM', 'Создание цифровых продуктов', 'Автоматизация процессов'],
  },
  {
    title: 'Маркетинг и коммуникации',
    description:
      'Помогаем бренду говорить на языке аудитории и выстраивать доверительные отношения.',
    points: ['Контент-стратегии', 'Комплексные кампании', 'Аналитика и оптимизация'],
  },
  {
    title: 'Операционная эффективность',
    description:
      'Настраиваем процессы и обучение, чтобы сотрудники были вовлечены и мотивированы.',
    points: ['Аудит процессов', 'Lean-практики', 'Программы наставничества'],
  },
];

const processSteps = [
  {
    title: 'Диагностика и инсайты',
    text: 'Погружаемся в контекст, проводим интервью с ключевыми стейкхолдерами и собираем данные, чтобы увидеть картину целиком.',
  },
  {
    title: 'Проектирование решения',
    text: 'Формируем гипотезы, создаем прототипы, проверяем с командами и согласовываем план внедрения.',
  },
  {
    title: 'Запуск и сопровождение',
    text: 'Организуем проектные команды, управляем изменениями и поддерживаем сотрудников в ходе внедрения.',
  },
  {
    title: 'Масштабирование',
    text: 'Помогаем закрепить результаты, выстраиваем мониторинг и передаем навыки вашим специалистам.',
  },
];

const testimonials = [
  {
    quote:
      'Команда "Компания" помогла нам выстроить полностью новый клиентский путь. Они не только предложили концепцию, но и сопровождали внедрение, адаптируя подход под наш темп.',
    name: 'Елена Петрова',
    role: 'Директор по развитию, RetailCity',
  },
  {
    quote:
      'Результатом совместной работы стала платформа, которая объединяет продажи, сервис и аналитику. Это заметно ускорило принятие решений и повысило лояльность клиентов.',
    name: 'Александр Орлов',
    role: 'CEO, Fintech360',
  },
  {
    quote:
      'После трансформации внутренние процессы стали прозрачными, а вовлеченность сотрудников выросла. "Компания" работает с большим уважением к людям и культуре бизнеса.',
    name: 'Мария Смирнова',
    role: 'HR-партнер, NovaManufacturing',
  },
];

const teamMembers = [
  {
    name: 'Сергей Ковалев',
    role: 'Партнер по стратегиям',
    image: 'https://picsum.photos/400/400?random=31',
    bio: 'Более 15 лет помогает технологическим компаниям выходить на новые рынки и развивать продуктовые ленты.',
  },
  {
    name: 'Алина Соловьева',
    role: 'Руководитель digital-направления',
    image: 'https://picsum.photos/400/400?random=32',
    bio: 'Отвечает за проектирование цифровых сервисов, объединяя дизайн-мышление и аналитический подход.',
  },
  {
    name: 'Дмитрий Журавлев',
    role: 'Эксперт по операционным моделям',
    image: 'https://picsum.photos/400/400?random=33',
    bio: 'Специализируется на оптимизации процессов и формировании корпоративных академий.',
  },
  {
    name: 'Ирина Волкова',
    role: 'Лидер по работе с клиентами',
    image: 'https://picsum.photos/400/400?random=34',
    bio: 'Строит коммуникационные стратегии и помогает брендам говорить на понятном языке.',
  },
];

const projectsData = [
  {
    title: 'Переоснащение клиентского сервиса',
    category: 'Цифровая трансформация',
    image: 'https://picsum.photos/1200/800?random=41',
    description:
      'Создали омниканальную платформу для взаимодействия с клиентами, объединив чат, поддержку и самообслуживание.',
  },
  {
    title: 'Запуск новой платформы знаний',
    category: 'Обучение и развитие',
    image: 'https://picsum.photos/1200/800?random=42',
    description:
      'Построили внутреннюю экосистему обучения с игровыми механиками и аналитикой прогресса сотрудников.',
  },
  {
    title: 'Обновление бренда и коммуникаций',
    category: 'Маркетинг и бренд',
    image: 'https://picsum.photos/1200/800?random=43',
    description:
      'Разработали идентичность и комплексную коммуникационную стратегию для выхода на международные рынки.',
  },
  {
    title: 'Центр управления данными',
    category: 'Цифровая трансформация',
    image: 'https://picsum.photos/1200/800?random=44',
    description:
      'Внедрили единый контур данных с подключением BI-инструментов, что позволило прогнозировать спрос и управлять запасами.',
  },
];

const faqData = [
  {
    question: 'С чего начинается работа с вашей командой?',
    answer:
      'Мы стартуем с экспресс-диагностики: проводим интервью с ключевыми участниками, анализируем показатели и формируем гипотезы. Затем вместе определяем приоритеты и формат сотрудничества.',
  },
  {
    question: 'Можно ли подключить вас к уже идущему проекту?',
    answer:
      'Да, у нас есть опыт встраивания в действующие инициативы. Мы аккуратно оцениваем текущий статус, договариваемся о ролях и усиливаем команды там, где это критично для результата.',
  },
  {
    question: 'Как вы работаете с распределенными командами?',
    answer:
      'Используем гибридный формат: фасилитируем онлайн-сессии, выстраиваем цифровые процессы и регулярно проводим офлайн-интенсивы для укрепления культуры и доверия.',
  },
  {
    question: 'Предоставляете ли вы сопровождение после внедрения?',
    answer:
      'Обязательно. Мы помогаем закрепить изменения, проводим обучение по новой модели работы и остаемся на связи, чтобы адаптировать решения под дальнейший рост.',
  },
];

const blogPosts = [
  {
    title: 'Как построить стратегию, которая адаптируется к изменениям',
    date: '15 февраля 2024',
    category: 'Стратегия',
    excerpt:
      'Говорим о том, как вовлечь ключевые команды, тестировать гипотезы и превращать стратегические документы в живые практики.',
  },
  {
    title: 'Организационный дизайн: инструменты для быстрого масштабирования',
    date: '2 марта 2024',
    category: 'Операционное управление',
    excerpt:
      'Разбираем, как обновить процессы и роли, чтобы поддерживать устойчивый рост бизнеса и управлять знаниями.',
  },
  {
    title: 'Цифровые сервисы глазами клиентов: подходы к co-creation',
    date: '18 марта 2024',
    category: 'Цифровая трансформация',
    excerpt:
      'Делимся методиками совместного проектирования продуктов вместе с клиентами и сотрудниками фронт-линии.',
  },
];

const HomePage = () => {
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeFilter, setActiveFilter] = useState('Все');
  const [openedFaq, setOpenedFaq] = useState(null);

  useEffect(() => {
    let animationFrame;
    const start = performance.now();
    const duration = 2000;

    const animate = (time) => {
      const progress = Math.min((time - start) / duration, 1);
      const updated = statsData.map((stat) => Math.round(stat.value * progress));
      setAnimatedStats(updated);
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7500);
    return () => clearInterval(interval);
  }, []);

  const categories = useMemo(() => {
    const set = new Set(['Все']);
    projectsData.forEach((project) => set.add(project.category));
    return Array.from(set);
  }, []);

  const filteredProjects =
    activeFilter === 'Все'
      ? projectsData
      : projectsData.filter((project) => project.category === activeFilter);

  const toggleFaq = (index) => {
    setOpenedFaq((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.page}>
      <Seo
        title="Компания — стратегические, цифровые и коммуникационные решения"
        description="Компания ускоряет развитие бизнеса: стратегия роста, цифровые продукты, маркетинг и трансформация процессов. Работаем с командами и укрепляем культуру изменений."
        keywords="консалтинг, цифровая трансформация, стратегия, маркетинг, развитие бизнеса"
      />

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <div className={styles.heroContent}>
              <span className={styles.heroLabel}>Сильные решения для сложных задач</span>
              <h1 className={styles.heroTitle}>
                Комплексные стратегии роста, технологии и команды, которые работают согласованно
              </h1>
              <p className={styles.heroText}>
                Мы видим потенциал бизнеса, соединяем людей и создаем инструменты, которые помогают
                двигаться вперед. От стратегии до внедрения — рядом с вами на каждом этапе.
              </p>
              <div className={styles.heroActions}>
                <Link className={styles.primaryButton} to="/kontakty">
                  Запланировать консультацию
                </Link>
                <Link className={styles.secondaryButton} to="/uslugi">
                  Посмотреть услуги
                </Link>
              </div>
            </div>
            <div className={styles.heroMedia} aria-hidden="true">
              <img
                src="https://picsum.photos/800/600?random=21"
                alt="Современная команда за работой"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statNumber}>
                  {animatedStats[index]}
                  {stat.suffix}
                </span>
                <p className={styles.statLabel}>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>Услуги</span>
            <h2 className={styles.sectionTitle}>
              Собираем гибкие решения вокруг потребностей вашего бизнеса
            </h2>
            <p className={styles.sectionDescription}>
              Наша команда сочетает стратегическое мышление, технологическую экспертизу и опыт
              изменений. Формируем состав и инструменты под ваши цели, чтобы гарантировать эффект.
            </p>
          </div>
          <div className={styles.serviceGrid}>
            {servicesData.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <ul className={styles.serviceList}>
                  {service.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
                <Link to="/uslugi" className={styles.serviceLink} aria-label={`Подробнее про: ${service.title}`}>
                  Подробнее →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>Подход</span>
            <h2 className={styles.sectionTitle}>Работаем открыто, поддерживая людей и результат</h2>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <div key={step.title} className={styles.processStep}>
                <span className={styles.stepNumber}>{`0${index + 1}`}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>Отзывы</span>
            <h2 className={styles.sectionTitle}>Клиенты о совместном пути</h2>
          </div>
          <div className={styles.testimonialCard}>
            <p className={styles.testimonialQuote}>
              «{testimonials[currentTestimonial].quote}»
            </p>
            <div className={styles.testimonialAuthor}>
              <span>{testimonials[currentTestimonial].name}</span>
              <small>{testimonials[currentTestimonial].role}</small>
            </div>
            <div className={styles.testimonialNav} role="tablist" aria-label="Отзывы клиентов">
              {testimonials.map((testimonial, index) => (
                <button
                  key={testimonial.name}
                  type="button"
                  className={`${styles.testimonialButton} ${
                    currentTestimonial === index ? styles.testimonialButtonActive : ''
                  }`}
                  onClick={() => setCurrentTestimonial(index)}
                  aria-label={`Показать отзыв: ${testimonial.name}`}
                  aria-selected={currentTestimonial === index}
                  role="tab"
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>Команда</span>
            <h2 className={styles.sectionTitle}>Люди, которые ведут проекты к результату</h2>
            <p className={styles.sectionDescription}>
              Мы объединяем экспертов из консалтинга, продуктов, коммуникаций и обучения, чтобы
              каждая инициатива была целостной.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span className={styles.teamRole}>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>Кейсы</span>
            <h2 className={styles.sectionTitle}>Проекты, которыми мы гордимся</h2>
          </div>
          <div className={styles.filterBar} role="tablist" aria-label="Фильтр проектов">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${
                  activeFilter === category ? styles.filterButtonActive : ''
                }`}
                onClick={() => setActiveFilter(category)}
                role="tab"
                aria-selected={activeFilter === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img src={project.image} alt={project.title} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>FAQ</span>
            <h2 className={styles.sectionTitle}>Часто задаваемые вопросы</h2>
          </div>
          <div className={styles.faqList}>
            {faqData.map((faq, index) => (
              <div key={faq.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqQuestion}
                  onClick={() => toggleFaq(index)}
                  aria-expanded={openedFaq === index}
                >
                  <span>{faq.question}</span>
                  <span className={styles.faqIcon}>{openedFaq === index ? '−' : '+'}</span>
                </button>
                {openedFaq === index && <p className={styles.faqAnswer}>{faq.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>Инсайты</span>
            <h2 className={styles.sectionTitle}>Делимся наблюдениями и инструментами</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span className={styles.blogMeta}>
                  {post.date} · {post.category}
                </span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/o-kompanii" aria-label={`Читать: ${post.title}`}>
                  Читать подробнее →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <h2>Готовы обсудить цель или вызов?</h2>
            <p>
              Расскажите, что происходит в вашей организации. Мы предложим формат встречи и подготовим
              команду экспертов именно под вашу задачу.
            </p>
            <Link className={styles.ctaButton} to="/kontakty">
              Связаться с нами
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;