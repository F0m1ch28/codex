import { useState } from 'react';
import Seo from '../components/Seo';
import styles from './ServicesPage.module.css';

const serviceTabs = [
  {
    title: 'Стратегия и трансформация',
    description:
      'Помогаем сформулировать ясное направление развития, найти точки роста и подготовить организацию к изменениям.',
    benefits: [
      'Диагностика бизнеса и аудит возможностей',
      'Разработка стратегических дорожных карт',
      'Настройка портфеля инициатив и управление изменениями',
      'Фасилитация стратегических сессий и воркшопов',
    ],
    highlight:
      'Концентрируемся на вовлечении ключевых людей, чтобы стратегия не оставалась на бумаге, а превращалась в действия.',
  },
  {
    title: 'Цифровые продукты и технологии',
    description:
      'Создаем цифровые решения, которые адаптируются под процессы компании и привычки пользователей.',
    benefits: [
      'Исследование пользователей и сервис-дизайн',
      'Проектирование и разработка цифровых платформ',
      'Интеграция CRM, ERP и аналитических систем',
      'Гибкое управление продуктовой командой',
    ],
    highlight:
      'Работаем спринтами, регулярно тестируем гипотезы и измеряем эффект для бизнес-показателей и клиентов.',
  },
  {
    title: 'Маркетинг, бренд и коммуникации',
    description:
      'Строим идентичность и коммуникации, которые объединяют бренда и его аудиторию и помогают удерживать внимание.',
    benefits: [
      'Разработка платформы бренда и визуальной идентичности',
      'Контент-стратегия и управление каналами',
      'Маркетинговая аналитика и оптимизация воронки',
      'Программы для вовлечения сотрудников как амбассадоров',
    ],
    highlight:
      'Сочетаем данные и творчество, формируем гибкую структуру коммуникаций и обучаем команды поддерживать тон бренда.',
  },
  {
    title: 'Операционное развитие и люди',
    description:
      'Выстраиваем процессы, культуру и среду, в которой сотрудники раскрывают потенциал, а клиенты чувствуют заботу.',
    benefits: [
      'Карта процессов и регламенты нового формата работы',
      'Внедрение agile-практик и управленческих инструментов',
      'Разработка программ обучения и наставничества',
      'Сопровождение изменений и поддержка руководителей',
    ],
    highlight:
      'Заботимся о том, чтобы новые практики органично вписывались в культуру компании и укрепляли вовлеченность людей.',
  },
];

const additionalServices = [
  {
    title: 'Сопровождение продукта',
    text: 'Берем на себя управление продуктовой командой, чтобы ускорить запуск и поддерживать развитие сервиса после релиза.',
  },
  {
    title: 'Аналитика и исследования',
    text: 'Проводим количественные и качественные исследования, строим систему показателей и визуализируем данные для принятия решений.',
  },
  {
    title: 'Корпоративные мероприятия',
    text: 'Организуем стратегические сессии, обучения и офлайн-интенсивы для распределенных коллективов.',
  },
];

const ServicesPage = () => {
  const [activeTab, setActiveTab] = useState(serviceTabs[0]);

  return (
    <div className={styles.page}>
      <Seo
        title="Услуги — стратегия, цифровые продукты, маркетинг и операционное развитие"
        description="Компания предлагает комплекс услуг: стратегия и трансформация, разработка цифровых продуктов, маркетинг и бренд, операционное развитие и обучение команд."
        keywords="услуги, стратегия, цифровые продукты, маркетинг, операционное развитие"
      />

      <section className={styles.intro}>
        <div className="container">
          <span className={styles.sectionTag}>Услуги</span>
          <h1>Комплексный подход к развитию бизнеса</h1>
          <p>
            Мы формируем проектную команду вокруг вашей задачи и сопровождаем процесс от диагностики
            до масштабирования. Используем гибкие методы и прозрачные метрики, чтобы вы видели
            прогресс на каждом этапе.
          </p>
        </div>
      </section>

      <section className={styles.tabsSection}>
        <div className="container">
          <div className={styles.tabs}>
            {serviceTabs.map((tab) => (
              <button
                key={tab.title}
                type="button"
                className={`${styles.tabButton} ${
                  activeTab.title === tab.title ? styles.tabButtonActive : ''
                }`}
                onClick={() => setActiveTab(tab)}
                aria-pressed={activeTab.title === tab.title}
              >
                {tab.title}
              </button>
            ))}
          </div>
          <div className={styles.tabContent}>
            <div className={styles.tabMain}>
              <h2>{activeTab.title}</h2>
              <p>{activeTab.description}</p>
            </div>
            <div className={styles.detailsGrid}>
              <div className={styles.detailsCard}>
                <h3>Что включено</h3>
                <ul className={styles.benefitsList}>
                  {activeTab.benefits.map((benefit) => (
                    <li key={benefit}>{benefit}</li>
                  ))}
                </ul>
              </div>
              <div className={styles.detailsCard}>
                <h3>Особенность подхода</h3>
                <p>{activeTab.highlight}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.extraSection}>
        <div className="container">
          <h2>Дополнительные форматы поддержки</h2>
          <div className={styles.extraGrid}>
            {additionalServices.map((service) => (
              <article key={service.title} className={styles.extraCard}>
                <h3>{service.title}</h3>
                <p>{service.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.workflowSection}>
        <div className="container">
          <div className={styles.workflowCard}>
            <h2>Как выглядит совместный проект</h2>
            <ol className={styles.workflowList}>
              <li>
                <strong>Диагностика и фокус.</strong> Проводим интервью, изучаем данные, определяем ключевые цели.
              </li>
              <li>
                <strong>Проектирование решения.</strong> Формируем команды, прототипируем сервисы, согласуем дорожную карту.
              </li>
              <li>
                <strong>Запуск и координация.</strong> Управляем прогрессом, подключаем экспертов и обучаем людей.
              </li>
              <li>
                <strong>Масштабирование и сопровождение.</strong> Помогаем закрепить практики и передаем методологию вашей команде.
              </li>
            </ol>
          </div>
        </div>
      </section>

      <section className={styles.contactPromo}>
        <div className="container">
          <div className={styles.contactCard}>
            <h2>Нужна помощь в выборе формата?</h2>
            <p>
              Расскажите нам о задаче — мы предложим оптимальную команду и подготовим план действий.
              Первый разговор помогает понять масштаб и подобрать лучший сценарий.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;