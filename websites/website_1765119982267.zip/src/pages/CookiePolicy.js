import Seo from '../components/Seo';
import styles from './LegalPage.module.css';

const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Seo
      title="Политика использования cookie — Компания"
      description="Описание того, какие cookie использует сайт компании, для чего они нужны и как управлять настройками."
      keywords="cookie, политика использования, настройки"
    />

    <header className={styles.header}>
      <h1>Политика использования файлов cookie</h1>
      <p className={styles.lastUpdated}>Последнее обновление: 1 апреля 2024 года</p>
    </header>

    <section className={styles.content}>
      <p>
        Cookie помогают нам сделать взаимодействие с сайтом более удобным. В этом разделе мы
        объясняем, какие файлы cookie применяются и как вы можете управлять своими настройками.
      </p>

      <h2 className={styles.sectionTitle}>1. Что такое cookie</h2>
      <p>
        Cookie — это небольшие текстовые файлы, которые сохраняются на вашем устройстве при
        посещении сайта. Они позволяют запомнить ваши предпочтения и улучшить работу ресурсов.
      </p>

      <h2 className={styles.sectionTitle}>2. Какие cookie мы используем</h2>
      <ul className={styles.list}>
        <li>
          <strong>Необходимые cookie:</strong> обеспечивают работу сайта и сохраняют ваши выбранные настройки.
        </li>
        <li>
          <strong>Аналитические cookie:</strong> помогают нам понимать, как пользователи взаимодействуют с сайтом и какие страницы востребованы.
        </li>
        <li>
          <strong>Функциональные cookie:</strong> позволяют персонализировать опыт и запоминать ваши действия.
        </li>
      </ul>

      <h2 className={styles.sectionTitle}>3. Управление cookie</h2>
      <p>
        Вы можете настроить или отключить cookie в параметрах браузера. Имейте в виду, что
        блокировка необходимых cookie может повлиять на корректную работу сайта.
      </p>

      <h2 className={styles.sectionTitle}>4. Обратная связь</h2>
      <p>
        Если у вас есть вопросы по использованию cookie, напишите нам: [info@компания.ru].
      </p>
    </section>
  </div>
);

export default CookiePolicyPage;