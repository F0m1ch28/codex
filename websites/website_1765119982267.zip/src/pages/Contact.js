import { useState } from 'react';
import Seo from '../components/Seo';
import styles from './ContactsPage.module.css';

const initialForm = {
  name: '',
  company: '',
  email: '',
  message: '',
};

const ContactsPage = () => {
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, укажите имя';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Нам нужен ваш email для обратной связи';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(formData.email)) {
      newErrors.email = 'Введите корректный email';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Расскажите коротко о задаче';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setErrors((prev) => ({
      ...prev,
      [name]: undefined,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    console.info('Отправка формы:', formData);
    setIsSubmitted(true);
    setFormData(initialForm);
  };

  return (
    <div className={styles.page}>
      <Seo
        title="Контакты — свяжитесь с командой Компания"
        description="Связаться с командой Компания: заполните форму, чтобы обсудить стратегию, цифровой продукт или трансформацию команды. Мы ответим в течение двух рабочих дней."
        keywords="контакты, консультация, связаться, Компания"
      />

      <section className={styles.intro}>
        <div className="container">
          <span className={styles.sectionTag}>Контакты</span>
          <h1>Расскажите о своей задаче — мы рядом</h1>
          <p>
            Ответим в течение двух рабочих дней и предложим формат первой встречи. Если вам важно
            ускориться, подписывайтесь на удобный канал связи в форме.
          </p>
        </div>
      </section>

      <section className={styles.contactsSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.contactInfo}>
              <h2>Как нас найти</h2>
              <div className={styles.infoBlock}>
                <h3>Офис</h3>
                <p>[Адрес компании]</p>
              </div>
              <div className={styles.infoBlock}>
                <h3>Телефон</h3>
                <a href="tel:+7XXXXXXXXXX">[+7 (XXX) XXX-XX-XX]</a>
              </div>
              <div className={styles.infoBlock}>
                <h3>Email</h3>
                <a href="mailto:info@компания.ru">[info@компания.ru]</a>
              </div>
              <div className={styles.infoBlock}>
                <h3>Социальные сети</h3>
                <ul className={styles.socialList}>
                  <li><a href="#!" aria-label="LinkedIn">LinkedIn</a></li>
                  <li><a href="#!" aria-label="Telegram">Telegram</a></li>
                  <li><a href="#!" aria-label="YouTube">YouTube</a></li>
                </ul>
              </div>
            </div>

            <div className={styles.formCard}>
              <h2>Напишите нам</h2>
              <p className={styles.formIntro}>
                Опишите ситуацию, и мы подберем эксперта для первичной консультации.
              </p>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <div className={styles.field}>
                  <label htmlFor="name">Имя *</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Как к вам обращаться?"
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'name-error' : undefined}
                  />
                  {errors.name && (
                    <span className={styles.error} id="name-error">
                      {errors.name}
                    </span>
                  )}
                </div>

                <div className={styles.field}>
                  <label htmlFor="company">Компания</label>
                  <input
                    id="company"
                    name="company"
                    type="text"
                    value={formData.company}
                    onChange={handleChange}
                    placeholder="Название организации"
                  />
                </div>

                <div className={styles.field}>
                  <label htmlFor="email">Email *</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="name@company.com"
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'email-error' : undefined}
                  />
                  {errors.email && (
                    <span className={styles.error} id="email-error">
                      {errors.email}
                    </span>
                  )}
                </div>

                <div className={styles.field}>
                  <label htmlFor="message">Сообщение *</label>
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Расскажите, что происходит и чего вы хотите достичь"
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'message-error' : undefined}
                  />
                  {errors.message && (
                    <span className={styles.error} id="message-error">
                      {errors.message}
                    </span>
                  )}
                </div>

                <button type="submit" className={styles.submitButton}>
                  Отправить запрос
                </button>
                {isSubmitted && (
                  <p className={styles.success}>
                    Спасибо! Мы получили ваше сообщение и свяжемся в ближайшее время.
                  </p>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.mapSection}>
        <div className="container">
          <div className={styles.mapPlaceholder} role="img" aria-label="Карта расположения офиса">
            <img src="https://picsum.photos/1200/500?random=61" alt="Карта района офиса" loading="lazy" />
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactsPage;