import Seo from '../components/Seo';
import styles from './AboutPage.module.css';

const historyPoints = [
  {
    year: '2014',
    title: 'Запуск компании',
    description:
      'Собрали ядро команды и начали с проектов в сфере стратегического консалтинга и коммуникаций.',
  },
  {
    year: '2017',
    title: 'Фокус на цифровых продуктах',
    description:
      'Открыли собственное дизайн- и технологическое направление, чтобы внедрять решения быстрее.',
  },
  {
    year: '2020',
    title: 'Международные проекты',
    description:
      'Вышли на рынки Европы и Азии, запустили программы трансформации для распределенных команд.',
  },
  {
    year: '2023',
    title: 'Экосистема партнерств',
    description:
      'Создали сеть экспертов и интеграторов, которая позволяет собирать мультидисциплинарные команды под задачи клиентов.',
  },
];

const values = [
  {
    title: 'Осмысленный прогресс',
    text: 'Ставим во главу угла устойчивый эффект. Работая с изменениями, измеряем не только результаты, но и влияние на людей.',
  },
  {
    title: 'Открытость и диалог',
    text: 'Верим в прозрачность и честную обратную связь. Партнерский формат помогает нам двигаться вместе с клиентом.',
  },
  {
    title: 'Эксперимент и обучение',
    text: 'Постоянно проверяем гипотезы, делимся знаниями и создаем пространство для роста внутри команд.',
  },
  {
    title: 'Ответственность за результат',
    text: 'Сопровождаем до момента, когда новая система начинает работать самостоятельно, и передаем инструменты вашей команде.',
  },
];

const leadershipTeam = [
  {
    name: 'Сергей Ковалев',
    position: 'Сооснователь и партнер',
    description:
      'Курирует стратегическую повестку, помогает руководителям выстраивать долгосрочное видение и экосистемы продуктов.',
  },
  {
    name: 'Алина Соловьева',
    position: 'Партнер по digital и дизайну',
    description:
      'Отвечает за продуктовые треки, сервис-дизайн и интеграцию технологий в бизнес-процессы.',
  },
  {
    name: 'Дмитрий Журавлев',
    position: 'Партнер по операционным изменениям',
    description:
      'Строит операционные модели, управляет трансформационными программами и обучением персонала.',
  },
];

const AboutPage = () => (
  <div className={styles.page}>
    <Seo
      title="О компании — команда, подход и история"
      description="Компания — команда стратегов, дизайнеров, технологов и фасилитаторов. Мы строим устойчивые изменения, работаем с культурами и поддерживаем людей в процессе трансформации."
      keywords="о компании, консалтинг, трансформация, команда, ценности"
    />

    <section className={styles.hero}>
      <div className="container">
        <div className={styles.heroContent}>
          <span className={styles.heroLabel}>О компании</span>
          <h1>Мы создаем решения, которые помогают организациям смело смотреть в будущее</h1>
          <p>
            Наша команда — это стратеги, аналитики, дизайнеры, фасилитаторы и инженеры. Мы
            сопровождаем бизнес от идеи до масштабирования, развивая внутренние компетенции и
            культуру изменений.
          </p>
        </div>
        <div className={styles.heroImage} aria-hidden="true">
          <img src="https://picsum.photos/800/600?random=51" alt="Рабочая сессия команды" loading="lazy" />
        </div>
      </div>
    </section>

    <section className={styles.missionSection}>
      <div className="container">
        <div className={styles.missionGrid}>
          <div className={styles.missionCard}>
            <h2>Наша миссия</h2>
            <p>
              Соединять людей, технологии и смыслы, чтобы бизнес развивался устойчиво, а сотрудники
              чувствовали вовлеченность и поддержку.
            </p>
          </div>
          <div className={styles.missionCard}>
            <h2>Как мы работаем</h2>
            <p>
              Ставим в центр партнерство с командами клиентов. Выстраиваем совместное управление,
              делимся инструментами и обеспечиваем прозрачность на каждом этапе.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.timelineSection}>
      <div className="container">
        <h2 className={styles.sectionTitle}>История развития</h2>
        <div className={styles.timeline}>
          {historyPoints.map((item) => (
            <div key={item.year} className={styles.timelineItem}>
              <span className={styles.timelineYear}>{item.year}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.valuesSection}>
      <div className="container">
        <h2 className={styles.sectionTitle}>Ценности, на которые мы опираемся</h2>
        <div className={styles.valuesList}>
          {values.map((value) => (
            <div key={value.title} className={styles.valueItem}>
              <h3>{value.title}</h3>
              <p>{value.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.leadershipSection}>
      <div className="container">
        <h2 className={styles.sectionTitle}>Лидерская команда</h2>
        <div className={styles.leadershipGrid}>
          {leadershipTeam.map((leader) => (
            <article key={leader.name} className={styles.leaderCard}>
              <h3>{leader.name}</h3>
              <span className={styles.leaderPosition}>{leader.position}</span>
              <p>{leader.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.ctaBanner}>
      <div className="container">
        <div className={styles.ctaContent}>
          <h2>Хотите познакомиться ближе?</h2>
          <p>
            Давайте обсудим вашу задачу и решим, как наша экспертиза может поддержать команду. Мы
            открыты к сотрудничеству в любом формате, от консультаций до долгосрочных программ.
          </p>
        </div>
      </div>
    </section>
  </div>
);

export default AboutPage;