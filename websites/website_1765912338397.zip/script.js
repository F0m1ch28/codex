(function () {
  document.addEventListener('DOMContentLoaded', function () {
    var consentKey = 'ykv-cookie-consent';
    var bestScoreKey = 'ykv-best-score';
    var hintsKey = 'ykv-hints-used';
    var banner = document.getElementById('cookie-banner');
    var acceptBtn = document.getElementById('cookie-accept');
    var declineBtn = document.getElementById('cookie-decline');
    var storageAllowed = false;
    var consentState = null;

    function safeGet(key) {
      try {
        return window.localStorage.getItem(key);
      } catch (error) {
        return null;
      }
    }

    function safeSet(key, value) {
      try {
        window.localStorage.setItem(key, value);
      } catch (error) {
        return false;
      }
      return true;
    }

    function safeRemove(key) {
      try {
        window.localStorage.removeItem(key);
      } catch (error) {
        return false;
      }
      return true;
    }

    consentState = safeGet(consentKey);
    if (consentState === 'accepted') {
      storageAllowed = true;
      if (banner) {
        banner.classList.add('is-hidden');
      }
    } else if (consentState === 'declined') {
      storageAllowed = false;
      if (banner) {
        banner.classList.add('is-hidden');
      }
    } else if (banner) {
      banner.classList.remove('is-hidden');
    }

    function refreshLeaderboardView() {
      var bestScoreCell = document.getElementById('player-best-score');
      var accuracyCell = document.getElementById('player-accuracy');
      var hintsCell = document.getElementById('player-hints');
      var consentNote = document.getElementById('consent-note');
      var storedScore = storageAllowed ? parseInt(safeGet(bestScoreKey) || '0', 10) : 0;
      var storedHints = storageAllowed ? parseInt(safeGet(hintsKey) || '0', 10) : 0;

      if (bestScoreCell) {
        bestScoreCell.textContent = storedScore > 0 ? storedScore.toString() : '—';
      }
      if (accuracyCell) {
        accuracyCell.textContent = storedScore > 0 ? Math.min(100, Math.max(70, 70 + storedScore / 2)).toFixed(0) + '%' : '—';
      }
      if (hintsCell) {
        hintsCell.textContent = storedScore > 0 ? storedHints.toString() : '—';
      }
      if (consentNote) {
        consentNote.textContent = storageAllowed
          ? 'Cookie включены — ваш рекорд сохранён и учтён в рейтинге.'
          : 'Cookie отключены. Включите их, чтобы сохранять прогресс и отображаться в рейтинге.';
      }
    }

    function applyConsent(state) {
      storageAllowed = state === 'accepted';
      if (banner) {
        banner.classList.add('is-hidden');
      }
      safeSet(consentKey, state);
      if (!storageAllowed) {
        safeRemove(bestScoreKey);
        safeRemove(hintsKey);
      }
      refreshLeaderboardView();
    }

    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        applyConsent('accepted');
      });
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', function () {
        applyConsent('declined');
      });
    }

    var gameTarget = document.getElementById('game-target');
    var wordOptions = document.getElementById('word-options');
    var selectionWrapper = document.getElementById('game-selection');
    var statusEl = document.getElementById('game-status');
    var currentScoreEl = document.getElementById('game-current-score');
    var bestScoreEl = document.getElementById('game-best-score');
    var roundEl = document.getElementById('game-round');
    var hintsList = document.getElementById('game-hints');
    var hintBtn = document.getElementById('give-hint');
    var resetBtn = document.getElementById('reset-game');
    var nextBtn = document.getElementById('next-round');

    var scenarios = [
      {
        title: 'Ночная доставка еды в центре города',
        words: ['заказать', 'доставку', 'роллов', 'ночью', 'в', 'центре'],
        distractors: ['быстро', 'дёшево', 'рецепт', 'самовывоз'],
        hints: ['Подумайте о ночной доставке еды.', 'Уточнение по времени суток и локации.', 'Нужен тип кухни и район.']
      },
      {
        title: 'Выбор фильма для семейного просмотра',
        words: ['лучшие', 'фильмы', 'для', 'семейного', 'просмотра'],
        distractors: ['хардкор', 'ужасы', 'ночью', 'экшен'],
        hints: ['Ключевой запрос связан с рекомендациями.', 'Добавьте аудиторию.', 'Формулировка должна звучать как подборка.']
      },
      {
        title: 'Покупка абонемента в фитнес клуб',
        words: ['купить', 'абонемент', 'в', 'фитнес', 'клуб', 'со', 'скидкой'],
        distractors: ['доставка', 'онлайн', 'дизайн', 'офис'],
        hints: ['Речь о покупке услуги.', 'Добавьте тип услуги и место.', 'Не забудьте про выгоду.']
      },
      {
        title: 'Поиск дешёвых авиабилетов',
        words: ['дешёвые', 'авиабилеты', 'в', 'стамбул', 'из', 'москвы'],
        distractors: ['рецепт', 'рейтинг', 'ночью', 'подкаст'],
        hints: ['Путешествие: нужна страна и город.', 'Укажите направление перелёта.', 'Добавьте город вылета.']
      },
      {
        title: 'Аренда студии для фотосъёмки',
        words: ['аренда', 'фотостудии', 'на', '3', 'часа', 'москва'],
        distractors: ['купить', 'онлайн', 'срочно', 'кофе'],
        hints: ['Сервис аренды.', 'Добавьте длительность.', 'Не забудьте указать город.']
      },
      {
        title: 'Создание цифрового портфолио дизайнера',
        words: ['как', 'создать', 'цифровое', 'портфолио', 'дизайнера'],
        distractors: ['купить', 'доставка', 'ночью', 'рецепт'],
        hints: ['Запрос от дизайнера.', 'Нужно слово про портфолио.', 'Добавьте вопросительную форму.']
      },
      {
        title: 'Подбор онлайн-курса по аналитике данных',
        words: ['подобрать', 'онлайн', 'курс', 'по', 'аналитике', 'данных'],
        distractors: ['игра', 'путешествие', 'ночью', 'ресторан'],
        hints: ['Образовательная тематика.', 'Добавьте формат обучения.', 'Не забудьте направление.']
      },
      {
        title: 'Где найти свежие новости технологий',
        words: ['свежие', 'новости', 'технологий', 'читать', 'онлайн'],
        distractors: ['купить', 'ночью', 'доставка', 'спорт'],
        hints: ['Запрос новостного типа.', 'Используйте слово «новости».', 'Добавьте формат потребления.']
      }
    ];

    var currentScenario = null;
    var selectedWords = [];
    var currentScore = 0;
    var bestScore = storageAllowed ? parseInt(safeGet(bestScoreKey) || '0', 10) : 0;
    var roundCounter = 1;
    var hintIndex = 0;
    var hintsUsedTotal = storageAllowed ? parseInt(safeGet(hintsKey) || '0', 10) : 0;
    var hintUsedThisRound = false;

    if (bestScoreEl) {
      bestScoreEl.textContent = bestScore.toString();
    }

    function updateScoreboard() {
      if (currentScoreEl) {
        currentScoreEl.textContent = currentScore.toString();
      }
      if (bestScoreEl) {
        bestScoreEl.textContent = bestScore.toString();
      }
      if (roundEl) {
        var displayRound = roundCounter < 10 ? '0' + roundCounter : roundCounter.toString();
        roundEl.textContent = displayRound;
      }
      refreshLeaderboardView();
    }

    function saveProgress() {
      if (!storageAllowed) {
        return;
      }
      safeSet(bestScoreKey, bestScore.toString());
      safeSet(hintsKey, hintsUsedTotal.toString());
    }

    function clearHintsList() {
      if (!hintsList) {
        return;
      }
      hintsList.innerHTML = '';
      var baseItem = document.createElement('li');
      baseItem.className = 'hint-item';
      baseItem.textContent = 'Подсказки появятся по запросу.';
      hintsList.appendChild(baseItem);
    }

    function shuffle(array) {
      var result = array.slice();
      for (var i = result.length - 1; i > 0; i -= 1) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = result[i];
        result[i] = result[j];
        result[j] = temp;
      }
      return result;
    }

    function resetWordButtons() {
      if (!wordOptions) {
        return;
      }
      Array.prototype.forEach.call(wordOptions.querySelectorAll('button'), function (button) {
        button.disabled = false;
        button.classList.remove('is-selected');
      });
    }

    function renderSelection() {
      if (!selectionWrapper) {
        return;
      }
      selectionWrapper.innerHTML = '';
      selectedWords.forEach(function (word) {
        var token = document.createElement('span');
        token.className = 'game-selection-word';
        token.textContent = word;
        selectionWrapper.appendChild(token);
      });
    }

    function setStatus(message, state) {
      if (!statusEl) {
        return;
      }
      statusEl.textContent = message;
      statusEl.classList.remove('is-success', 'is-error');
      if (state) {
        statusEl.classList.add(state);
      }
    }

    function disableWordButtons() {
      if (!wordOptions) {
        return;
      }
      Array.prototype.forEach.call(wordOptions.querySelectorAll('button'), function (button) {
        button.disabled = true;
      });
    }

    function loadScenario() {
      if (!gameTarget || !wordOptions) {
        return;
      }
      currentScenario = scenarios[Math.floor(Math.random() * scenarios.length)];
      selectedWords = [];
      hintIndex = 0;
      hintUsedThisRound = false;
      renderSelection();
      setStatus('Выберите слова в правильном порядке.', null);
      gameTarget.textContent = currentScenario.title;
      clearHintsList();
      if (nextBtn) {
        nextBtn.disabled = true;
      }
      var optionsArray = currentScenario.words.concat(currentScenario.distractors);
      var shuffled = shuffle(optionsArray);
      wordOptions.innerHTML = '';
      shuffled.forEach(function (word) {
        var button = document.createElement('button');
        button.type = 'button';
        button.className = 'word-option';
        button.textContent = word;
        button.addEventListener('click', function () {
          if (selectedWords.length < currentScenario.words.length) {
            selectedWords.push(word);
            button.disabled = true;
            button.classList.add('is-selected');
            renderSelection();
            if (selectedWords.length === currentScenario.words.length) {
              evaluateSelection();
            }
          }
        });
        wordOptions.appendChild(button);
      });
    }

    function evaluateSelection() {
      if (!currentScenario) {
        return;
      }
      var chosen = selectedWords.join(' ');
      var expected = currentScenario.words.join(' ');
      var success = chosen === expected;
      if (success) {
        var reward = hintUsedThisRound ? 7 : 10;
        currentScore += reward;
        bestScore = Math.max(bestScore, currentScore);
        setStatus('Отлично! Запрос собран точно. +' + reward + ' баллов.', 'is-success');
        saveProgress();
      } else {
        currentScore = Math.max(0, currentScore - 5);
        setStatus('Есть неточность. Проверьте порядок и попробуйте снова. -5 баллов.', 'is-error');
      }
      disableWordButtons();
      if (nextBtn) {
        nextBtn.disabled = false;
      }
      updateScoreboard();
    }

    if (hintBtn) {
      hintBtn.addEventListener('click', function () {
        if (!currentScenario || !hintsList) {
          return;
        }
        if (hintIndex >= currentScenario.hints.length) {
          setStatus('Все подсказки уже раскрыты.', null);
          return;
        }
        if (hintIndex === 0) {
          hintsList.innerHTML = '';
        }
        var hintItem = document.createElement('li');
        hintItem.className = 'hint-item active';
        hintItem.textContent = currentScenario.hints[hintIndex];
        hintsList.appendChild(hintItem);
        hintIndex += 1;
        hintUsedThisRound = true;
        hintsUsedTotal += 1;
        saveProgress();
        setTimeout(function () {
          hintItem.classList.remove('active');
        }, 1500);
      });
    }

    if (resetBtn) {
      resetBtn.addEventListener('click', function () {
        currentScore = 0;
        roundCounter = 1;
        selectedWords = [];
        hintsUsedTotal = storageAllowed ? parseInt(safeGet(hintsKey) || '0', 10) : 0;
        renderSelection();
        updateScoreboard();
        resetWordButtons();
        loadScenario();
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', function () {
        roundCounter += 1;
        selectedWords = [];
        renderSelection();
        resetWordButtons();
        loadScenario();
      });
    }

    if (gameTarget && wordOptions) {
      loadScenario();
      updateScoreboard();
    } else {
      refreshLeaderboardView();
    }
  });
})();