document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      nav.classList.toggle('is-open');
    });

    nav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          nav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const consentKey = 'tyonrbellCookieConsent';
  const cookieBanner = document.getElementById('cookie-banner');

  if (cookieBanner) {
    const existingConsent = localStorage.getItem(consentKey);
    if (!existingConsent) {
      cookieBanner.setAttribute('data-visible', 'true');
    }

    cookieBanner.querySelectorAll('[data-cookie-action]').forEach((button) => {
      button.addEventListener('click', () => {
        const action = button.dataset.cookieAction;
        localStorage.setItem(consentKey, action);
        cookieBanner.setAttribute('data-visible', 'false');
      });
    });
  }
});