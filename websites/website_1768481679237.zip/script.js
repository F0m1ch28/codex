document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('.nav-toggle');
    var body = document.body;
    if (navToggle) {
        navToggle.addEventListener('click', function () {
            body.classList.toggle('nav-open');
        });
        document.querySelectorAll('.primary-nav a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (body.classList.contains('nav-open')) {
                    body.classList.remove('nav-open');
                }
            });
        });
    }

    var cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        var accepted = localStorage.getItem('commonmaefCookieDecision');
        if (accepted) {
            cookieBanner.classList.add('hidden');
        }
        cookieBanner.querySelectorAll('.cookie-btn').forEach(function (btn) {
            btn.addEventListener('click', function (event) {
                event.preventDefault();
                var choice = btn.dataset.choice || 'undecided';
                localStorage.setItem('commonmaefCookieDecision', choice);
                cookieBanner.classList.add('hidden');
                setTimeout(function () {
                    window.location.href = btn.getAttribute('href');
                }, 180);
            });
        });
    }
});