document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const body = document.body;

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navToggle.classList.toggle('is-active');
            siteNav.classList.toggle('open');
            body.classList.toggle('nav-open');
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                navToggle.classList.remove('is-active');
                siteNav.classList.remove('open');
                body.classList.remove('nav-open');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-accept');
    const declineBtn = document.querySelector('.cookie-decline');
    const consent = localStorage.getItem('etchsavg-cookie-consent');

    if (cookieBanner && !consent) {
        setTimeout(() => cookieBanner.classList.add('active'), 800);
    }

    const handleConsent = value => {
        localStorage.setItem('etchsavg-cookie-consent', value);
        if (cookieBanner) cookieBanner.classList.remove('active');
    };

    if (acceptBtn) {
        acceptBtn.addEventListener('click', () => handleConsent('accepted'));
    }

    if (declineBtn) {
        declineBtn.addEventListener('click', () => handleConsent('declined'));
    }

    const accordions = document.querySelectorAll('.accordion-button');
    accordions.forEach(button => {
        button.addEventListener('click', () => {
            const content = button.nextElementSibling;
            const icon = button.querySelector('span');

            if (content.classList.contains('active')) {
                content.classList.remove('active');
                icon.style.transform = 'rotate(0deg)';
            } else {
                document.querySelectorAll('.accordion-content').forEach(item => {
                    item.classList.remove('active');
                });
                document.querySelectorAll('.accordion-button span').forEach(span => {
                    span.style.transform = 'rotate(0deg)';
                });
                content.classList.add('active');
                icon.style.transform = 'rotate(180deg)';
            }
        });
    });
});