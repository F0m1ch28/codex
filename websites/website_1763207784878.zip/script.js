document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const scrollTopButton = document.querySelector('.scroll-top');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAccept = document.getElementById('cookie-accept');
    const contactForm = document.getElementById('contact-form');
    const formResponse = document.getElementById('form-response');
    const yearSpan = document.getElementById('year');

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    function handleScroll() {
        if (window.scrollY > 300) {
            scrollTopButton?.classList.add('visible');
        } else {
            scrollTopButton?.classList.remove('visible');
        }
    }

    window.addEventListener('scroll', handleScroll);

    scrollTopButton?.addEventListener('click', e => {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    if (cookieBanner) {
        const consent = localStorage.getItem('nt-cookie-consent');
        if (!consent) {
            cookieBanner.classList.add('active');
        }
        cookieAccept?.addEventListener('click', () => {
            localStorage.setItem('nt-cookie-consent', 'accepted');
            cookieBanner.classList.remove('active');
        });
    }

    if (contactForm && formResponse) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const requiredFields = ['name', 'company', 'email', 'subject', 'message'];
            const missing = requiredFields.filter(field => !formData.get(field));
            if (missing.length > 0) {
                formResponse.textContent = 'Please complete all required fields before submitting.';
                formResponse.style.color = '#d9534f';
                return;
            }
            formResponse.textContent = 'Thank you. Your message has been received and we will respond within one business day.';
            formResponse.style.color = '#2f5b9f';
            contactForm.reset();
        });
    }
});