document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  const scrollTopBtn = document.getElementById("scrollTop");
  const cookieBanner = document.getElementById("cookieBanner");
  const acceptCookiesBtn = document.getElementById("acceptCookies");
  const currentYearEls = document.querySelectorAll(".current-year");
  const navLinks = document.querySelectorAll(".nav-link");
  const form = document.getElementById("contactForm");
  const formStatus = document.getElementById("formStatus");

  if (navToggle) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
      navToggle.setAttribute("aria-expanded", !expanded);
      siteNav.classList.toggle("open");
    });
  }

  window.addEventListener("scroll", () => {
    if (window.scrollY > 240) {
      scrollTopBtn.classList.add("visible");
    } else {
      scrollTopBtn.classList.remove("visible");
    }
  });

  scrollTopBtn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  navLinks.forEach(link => {
    link.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "instant" });
      if (siteNav.classList.contains("open")) {
        siteNav.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  });

  const consent = localStorage.getItem("dh-cookie-consent");
  if (!consent) {
    cookieBanner.classList.add("show");
  }

  acceptCookiesBtn.addEventListener("click", () => {
    localStorage.setItem("dh-cookie-consent", "accepted");
    cookieBanner.classList.remove("show");
  });

  const year = new Date().getFullYear();
  currentYearEls.forEach(el => (el.textContent = year));

  if (form) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      let valid = true;

      form.querySelectorAll("input, textarea").forEach(field => {
        const errorSpan = form.querySelector(`.error-message[data-for="${field.id}"]`);
        if (field.hasAttribute("required") && !field.value.trim()) {
          valid = false;
          if (errorSpan) errorSpan.textContent = "Пожалуйста, заполните поле.";
        } else if (field.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value)) {
          valid = false;
          if (errorSpan) errorSpan.textContent = "Введите корректный email.";
        } else if (errorSpan) {
          errorSpan.textContent = "";
        }
      });

      if (!valid) {
        formStatus.textContent = "";
        return;
      }

      // Simulate successful submission
      form.reset();
      formStatus.textContent = "Сообщение отправлено. Мы свяжемся с вами после изучения темы.";
    });
  }
});