export const categories = [
  {
    id: 'video-covers',
    name: 'Обложки для видео',
    description: 'Выразительные обложки для YouTube и видеохостингов с акцентом на storytelling и высокий CTR.',
    image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=1600&q=80'
  },
  {
    id: 'avatars',
    name: 'Аватарки и иконки',
    description: 'Уникальные аватарки для каналов, подкастов и личных брендов в единой визуальной системе.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1600&q=80'
  },
  {
    id: 'stream-banners',
    name: 'Баннеры для стримов',
    description: 'Адаптивные баннеры и плашки для Twitch, Trovo, YouTube Live и других стриминговых платформ.',
    image: 'https://images.unsplash.com/photo-1487956382158-bb926046304a?auto=format&fit=crop&w=1600&q=80'
  },
  {
    id: 'social-media',
    name: 'Графика для соцсетей',
    description: 'Посты, сторис и карусели для Instagram, TikTok, VK, LinkedIn и Facebook.',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1600&q=80'
  }
];

export const items = [
  {
    slug: 'dynamic-youtube-thumbnail',
    title: 'Динамичная миниатюра для YouTube',
    category: 'video-covers',
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1600&q=80',
    alt: 'Динамичная обложка для YouTube с яркими элементами',
    description: 'Энергичная обложка с акцентом на эмоции, крупные детали и контрастную типографику для повышения кликабельности ролика.',
    features: [
      'Оптимизированные заголовки и акценты',
      'Брендовые цвета и шрифты',
      'Версии для A/B тестов',
      'Формат JPG и PSD'
    ],
    tags: ['YouTube', 'CTR', 'Storytelling']
  },
  {
    slug: 'minimalist-video-cover',
    title: 'Минималистичная обложка серии',
    category: 'video-covers',
    image: 'https://images.unsplash.com/photo-1487017159836-4e23ece2e4cf?auto=format&fit=crop&w=1600&q=80',
    alt: 'Минималистичная обложка для серии видео',
    description: 'Минималистичная серия обложек с лаконичными элементами и единым визуальным кодом для образовательного контента.',
    features: [
      'Чёткая сетка и модульность',
      'Пак коллекций для разных эпизодов',
      'Готовые стили типографики',
      'Оптимизация под мобильные устройства'
    ],
    tags: ['Серия', 'Минимализм', 'Образование']
  },
  {
    slug: 'cinematic-video-poster',
    title: 'Кинематографический постер выпуска',
    category: 'video-covers',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1600&q=80',
    alt: 'Кинематографическая обложка для видео',
    description: 'Кинематографический стиль с драматическим светом и фактурными текстурами — идеально для трейлеров и storytelling-роликов.',
    features: [
      'Сложный композитинг и цветокор',
      'Настроенные маски и эффекты света',
      'Лёгкая адаптация под 4K',
      'Включены предпросмотры'
    ],
    tags: ['Кинематограф', 'Премьера', 'Трейлер']
  },
  {
    slug: 'neon-stream-banner',
    title: 'Неоновый баннер для стримов',
    category: 'stream-banners',
    image: 'https://images.unsplash.com/photo-1551816230-ef5deaed4a26?auto=format&fit=crop&w=1600&q=80',
    alt: 'Неоновый баннер для стримингового канала',
    description: 'Футуристичный баннер в неоновой палитре с адаптацией под баннеры Twitch, YouTube Live и Discord.',
    features: [
      'Полный набор баннеров и панелей',
      'Слои для изменения текста и аватарки',
      'Гид по подключению',
      '2400px базовое разрешение'
    ],
    tags: ['Twitch', 'Неон', 'Футуризм']
  },
  {
    slug: 'esports-stream-package',
    title: 'Киберспортивный стрим-пак',
    category: 'stream-banners',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1600&q=80',
    alt: 'Киберспортивный пакет графики для стримера',
    description: 'Комплект баннеров, рамок и экранов ожидания в стиле киберспортивной трансляции.',
    features: [
      'Экран «Скоро начнём» + «Перерыв»',
      'Титры для новых подписчиков',
      'PSD и PNG файлы',
      'Инструкция по настройке OBS'
    ],
    tags: ['Киберспорт', 'OBS', 'Пакет']
  },
  {
    slug: 'vibe-stream-overlay',
    title: 'Атмосферная стрим-оверлей',
    category: 'stream-banners',
    image: 'https://images.unsplash.com/photo-1531537571171-a707bf2683da?auto=format&fit=crop&w=1600&q=80',
    alt: 'Атмосферный overlay для видеострима',
    description: 'Мягкая палитра, плавные градиенты и авторский pattern создают уютное настроение для чат-стримов.',
    features: [
      'Анимационные рекомендации',
      'Готовые слои для виджетов',
      'Статус-плашки и таймеры',
      'Файлы для After Effects'
    ],
    tags: ['Overlay', 'Gradient', 'Live']
  },
  {
    slug: 'signature-avatar-kit',
    title: 'Подписьный набор аватарок',
    category: 'avatars',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1600&q=80',
    alt: 'Коллекция брендированных аватарок',
    description: 'Уникальная серия аватарок для команд и личных брендов с адаптацией под квадрат, круг и сторис-кружок.',
    features: [
      '5 вариантов композиций',
      'Настраиваемые шрифты и цвета',
      'Готовые mockup-превью',
      'Векторные элементы'
    ],
    tags: ['Брендинг', 'Личный бренд', 'Иконки']
  },
  {
    slug: 'podcast-avatar-illustration',
    title: 'Иллюстрация для подкаста',
    category: 'avatars',
    image: 'https://images.unsplash.com/photo-1531256456869-ce942a665e80?auto=format&fit=crop&w=1600&q=80',
    alt: 'Яркая иллюстрация для подкаст-аватарки',
    description: 'Характерная иллюстрация в стиле flat с портретной стилизацией и выразительными акцентами.',
    features: [
      '3 варианта освещения',
      'Форматы PNG и SVG',
      'Совместимость с Figma',
      'Слои для подмены деталей'
    ],
    tags: ['Подкаст', 'Иллюстрация', 'Flat']
  },
  {
    slug: 'tech-icon-pack',
    title: 'Технологичный набор иконок',
    category: 'avatars',
    image: 'https://images.unsplash.com/photo-1451188502541-13943edb6acb?auto=format&fit=crop&w=1600&q=80',
    alt: 'Технологичные иконки на темном фоне',
    description: 'Набор иконок для продуктов и SaaS-команд: логотипы, маркеры, индикаторы с аккуратной геометрией.',
    features: [
      'Доступно 24 варианта',
      'Векторная графика',
      'Гайд по применению',
      'Шаблоны для презентаций'
    ],
    tags: ['SaaS', 'Технологии', 'UI']
  },
  {
    slug: 'instagram-carousel-kit',
    title: 'Карусель для Instagram',
    category: 'social-media',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1600&q=80',
    alt: 'Карусельные слайды для Instagram',
    description: 'Комплект из 8 слайдов с модульной сеткой для образовательных постов в Instagram и VK.',
    features: [
      'Готовые шаблоны для Reels превью',
      'Совместимость с Canva и Photoshop',
      'Варианты типографики',
      'Инструкция по верстке серии'
    ],
    tags: ['Instagram', 'Карусель', 'Образование']
  },
  {
    slug: 'tiktok-story-frame',
    title: 'Визуальные рамки для TikTok Stories',
    category: 'social-media',
    image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1600&q=80',
    alt: 'Яркие рамки для вертикального видео',
    description: 'Вертикальные шаблоны с анимированными рекомендациями и зонами для текста — идеально для TikTok и Shorts.',
    features: [
      'Соотношение 9:16',
      'Слои для анимации',
      'Гайд по экспорту',
      'Запасные цветовые схемы'
    ],
    tags: ['TikTok', 'Vertical', 'Stories']
  },
  {
    slug: 'linkedin-brand-kit',
    title: 'Бренд-пакет для LinkedIn',
    category: 'social-media',
    image: 'https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=1600&q=80',
    alt: 'Профессиональная графика для LinkedIn',
    description: 'Строгая графика для LinkedIn: баннеры, карточки с кейсами и инфографика в деловой стилистике.',
    features: [
      'Расширенный шаблон постов',
      'Использование корпоративной палитры',
      'Вариации для презентаций',
      'Экспорт в PNG и PDF'
    ],
    tags: ['LinkedIn', 'B2B', 'Инфографика']
  }
];