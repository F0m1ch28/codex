import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import CatalogPage from './pages/Catalog';
import VideoCoversPage from './pages/VideoCovers';
import AvatarsPage from './pages/Avatars';
import StreamBannersPage from './pages/StreamBanners';
import SocialMediaPage from './pages/SocialMedia';
import ItemPage from './pages/Item';
import AboutPage from './pages/About';
import ServicesPage from './pages/Services';
import ContactPage from './pages/Contact';
import FaqPage from './pages/Faq';
import TermsPage from './pages/Terms';
import PrivacyPage from './pages/Privacy';
import CookiePolicyPage from './pages/CookiePolicy';
import NotFoundPage from './pages/NotFound';
import styles from './App.module.css';

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

function App() {
  return (
    <Router>
      <ScrollToTopOnRouteChange />
      <div className={styles.app}>
        <Header />
        <main className={styles.main} id="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/catalog" element={<CatalogPage />} />
            <Route path="/catalog/video-covers" element={<VideoCoversPage />} />
            <Route path="/catalog/avatars" element={<AvatarsPage />} />
            <Route path="/catalog/stream-banners" element={<StreamBannersPage />} />
            <Route path="/catalog/social-media" element={<SocialMediaPage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/item/:slug" element={<ItemPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/faq" element={<FaqPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/privacy" element={<PrivacyPage />} />
            <Route path="/cookie-policy" element={<CookiePolicyPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Footer />
        <ScrollToTopButton />
        <CookieBanner />
      </div>
    </Router>
  );
}

export default App;