import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={`container ${styles.inner}`}>
      <div className={styles.brand}>
        <h2>DigitalCovers</h2>
        <p>
          DigitalCovers — международная онлайн-платформа. Мы создаём и курируем коллекции цифровых обложек,
          аватарок, баннеров и графики для социальных сетей, помогая контент-мейкерам выделяться и формировать узнаваемый стиль.
        </p>
        <div className={styles.contacts}>
          <a href="mailto:support@digitalcovers.com" className={styles.link}>support@digitalcovers.com</a>
          <a href="mailto:partners@digitalcovers.com" className={styles.link}>partners@digitalcovers.com</a>
        </div>
      </div>

      <div className={styles.columns}>
        <div>
          <h3>Разделы</h3>
          <ul>
            <li><Link to="/">Главная</Link></li>
            <li><Link to="/catalog">Каталог</Link></li>
            <li><Link to="/services">Услуги</Link></li>
            <li><Link to="/about">О нас</Link></li>
            <li><Link to="/contact">Контакты</Link></li>
            <li><Link to="/faq">FAQ</Link></li>
          </ul>
        </div>
        <div>
          <h3>Категории</h3>
          <ul>
            <li><Link to="/catalog/video-covers">Обложки для видео</Link></li>
            <li><Link to="/catalog/avatars">Аватарки и иконки</Link></li>
            <li><Link to="/catalog/stream-banners">Баннеры для стримов</Link></li>
            <li><Link to="/catalog/social-media">Графика для соцсетей</Link></li>
          </ul>
        </div>
        <div>
          <h3>Правовая информация</h3>
          <ul>
            <li><Link to="/terms">Лицензионное соглашение</Link></li>
            <li><Link to="/privacy">Политика конфиденциальности</Link></li>
            <li><Link to="/cookie-policy">Политика использования cookies</Link></li>
          </ul>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <div className="container">
        <p>© {new Date().getFullYear()} DigitalCovers. Все права защищены. Мы уважаем авторское право и создаём оригинальные макеты.</p>
      </div>
    </div>
  </footer>
);

export default Footer;