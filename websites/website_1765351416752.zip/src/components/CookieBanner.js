import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const COOKIE_STORAGE_KEY = 'digitalcovers-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const storedConsent = localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!storedConsent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem(COOKIE_STORAGE_KEY, choice);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Сообщение о cookies">
      <div className={styles.text}>
        <h4>Мы используем cookies</h4>
        <p>
          DigitalCovers применяет файлы cookies для улучшения работы платформы и персонализации рекомендаций.
          Подробнее — в нашей <Link to="/cookie-policy">Политике использования cookies</Link>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" onClick={() => handleChoice('declined')} className={`btn ${styles.secondary}`}>
          Отклонить
        </button>
        <button type="button" onClick={() => handleChoice('accepted')} className="btn">
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;