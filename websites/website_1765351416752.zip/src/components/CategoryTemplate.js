import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { categories, items } from '../data/products';
import styles from './CategoryTemplate.module.css';

const CategoryTemplate = ({ categoryId, title, description, keywords, ctaLabel }) => {
  const categoryInfo = categories.find((cat) => cat.id === categoryId);
  const categoryItems = items.filter((item) => item.category === categoryId);

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>{`${title} | Каталог DigitalCovers`}</title>
        <meta name="description" content={description} />
        <meta name="keywords" content={keywords} />
      </Helmet>

      <section className={styles.hero} style={{ backgroundImage: `url(${categoryInfo?.image})` }}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <span className="section-label">Категория</span>
            <h1>{title}</h1>
            <p>{description}</p>
            <div className={styles.heroActions}>
              <Link to="/contact" className="btn">Связаться с командой</Link>
              <Link to="/catalog" className="btn btn-secondary">Вернуться в каталог</Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.sectionHeading}>
            <h2>Подборка в категории</h2>
            <p>
              {ctaLabel} Каждый макет создаётся с учётом актуальных трендов и готов к публикации на международных площадках.
            </p>
          </div>

          <div className={styles.grid}>
            {categoryItems.map((item) => (
              <article key={item.slug} className={styles.card}>
                <div className={styles.preview}>
                  <img src={item.image} alt={item.alt} loading="lazy" />
                  <div className={styles.previewOverlay}>
                    <div className={styles.tags}>
                      {item.tags.map((tag) => (
                        <span key={tag} className="tag">{tag}</span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className={styles.cardBody}>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                  <ul className={styles.features}>
                    {item.features.slice(0, 3).map((feature) => (
                      <li key={feature}>{feature}</li>
                    ))}
                  </ul>
                  <Link to={`/item/${item.slug}`} className={styles.detailsLink}>
                    Смотреть детали
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default CategoryTemplate;