import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { categories } from '../data/products';
import styles from './Home.module.css';

const advantages = [
  {
    title: 'Единый стиль для цифровых продуктов',
    description: 'Сотни проработанных макетов с унифицированной сеткой и символикой бренда, чтобы ваши каналы выглядели целостно на всех площадках.',
    icon: '🎯'
  },
  {
    title: 'Готовность к международной аудитории',
    description: 'Шаблоны адаптированы под требования YouTube, Twitch, TikTok, Instagram и других платформ, включая рекомендации по локализации.',
    icon: '🌍'
  },
  {
    title: 'Дизайн-команда в пару кликов',
    description: 'Вместо долгих брифов — готовые решения, которые можно кастомизировать. Пишите нам, и мы дополним макеты под ваш бренд-гайд.',
    icon: '⚡'
  }
];

const statsData = [
  { label: 'Готовых макетов', value: 860 },
  { label: 'Клиентов по всему миру', value: 120 },
  { label: 'Категорий и стилей', value: 28 },
  { label: 'Средний рост CTR', value: 34, suffix: '%' }
];

const servicesHighlight = [
  {
    title: 'Экспресс-подбор коллекции',
    text: 'Подберём подборку обложек, аватарок и баннеров под задачи бренда за 24 часа, учитывая ваш тон коммуникации.',
    link: '/services',
    icon: '⚙️'
  },
  {
    title: 'Индивидуальный дизайн-набор',
    text: 'Создадим кастомный набор графики на основе вашего брендбука, подготовим 3-5 вариантов на выбор.',
    link: '/services',
    icon: '🎨'
  },
  {
    title: 'Визуальная поддержка запуска',
    text: 'Поможем оформить визуал для премьер, марафонов и запусков продуктов: баннеры, лендинг-иллюстрации, карусели.',
    link: '/contact',
    icon: '🚀'
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Выберите коллекцию',
    text: 'Изучите каталог готовых решений и отметьте понравившиеся макеты или пришлите референсы.'
  },
  {
    step: '02',
    title: 'Согласуйте детали',
    text: 'Мы уточняем задачи, стиль и платформы. При необходимости предлагаем кастомизацию и дополнительные форматы.'
  },
  {
    step: '03',
    title: 'Получите готовый пакет',
    text: 'Передаём файлы в нужных разрешениях, инструкции по внедрению и рекомендации по дальнейшей работе с визуалом.'
  }
];

const projectFilters = ['Все', 'YouTube', 'Стримы', 'Социальные сети'];
const projectItems = [
  {
    title: 'YouTube-серия «Tech Labs»',
    category: 'YouTube',
    description: 'Единый визуальный стиль для образовательной tech-серии, который увеличил CTR обложек на 41%.',
    image: 'https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7?auto=format&fit=crop&w=1400&q=80'
  },
  {
    title: 'Оформление Twitch-канала NeonFox',
    category: 'Стримы',
    description: 'Полный пакет графики для стримера: overlay, панели, экран ожидания и анимированные оповещения.',
    image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=1400&q=80'
  },
  {
    title: 'Соцсетевой релиз подкаста',
    category: 'Социальные сети',
    description: 'Серия карточек, сторис и обложек для запуска подкаста, стилизованного под винтажные кассеты.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1400&q=80'
  },
  {
    title: 'YouTube Premium Gaming',
    category: 'YouTube',
    description: 'Набор геймерских миниатюр с 3D-элементами и неоновой палитрой для международного канала.',
    image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1400&q=80'
  },
  {
    title: 'Live-платформа: брендинг для ивента',
    category: 'Стримы',
    description: 'Визуальная концепция и набор баннеров для геймерского онлайн-фестиваля с мерч-зоной.',
    image: 'https://images.unsplash.com/photo-1555421689-491a97ff2040?auto=format&fit=crop&w=1400&q=80'
  },
  {
    title: 'Digital-марафон для эксперта',
    category: 'Социальные сети',
    description: 'Карусели, гайды и шаблоны вовлекающих сторис для трёхнедельного марафона эксперта по маркетингу.',
    image: 'https://images.unsplash.com/photo-1474631245212-32dc3c8310c6?auto=format&fit=crop&w=1400&q=80'
  }
];

const testimonials = [
  {
    name: 'Наталья Ким',
    role: 'Руководитель контента, Creator School',
    quote: 'Получили не просто красивые обложки, а продуманную систему визуальной коммуникации. Команда DigitalCovers помогла сформировать единый стиль и дала рекомендации по визуальной аналитике.',
    avatar: 'https://images.unsplash.com/photo-1614289371518-722f2615943f?auto=format&fit=crop&w=200&q=80'
  },
  {
    name: 'Лео Пачеко',
    role: 'Стример и продюсер NeonFox',
    quote: 'Новые баннеры и overlay для стримов идеально отражают атмосферу канала. Поддержка ребят помогла быстро внедрить графику в OBS и подготовить сезонный мерч.',
    avatar: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&w=200&q=80'
  },
  {
    name: 'София Иванова',
    role: 'Маркетолог, стартап Aivenly',
    quote: 'Благодаря готовым шаблонам мы быстрее запускаем кампании в LinkedIn и делимся результатами. Особенно полезны инструкции по адаптации под разные форматы.',
    avatar: 'https://images.unsplash.com/photo-1531379410502-63bfe8cdaf6f?auto=format&fit=crop&w=200&q=80'
  }
];

const teamMembers = [
  {
    name: 'Алексей Воронов',
    role: 'Креативный директор',
    bio: '10 лет в digital-дизайне, отвечает за визуальные концепции и арт-дирекшн коллекций DigitalCovers.',
    avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=300&q=80'
  },
  {
    name: 'Мария Лебедева',
    role: 'Lead-дизайнер',
    bio: 'Специализация — графика для YouTube и Twitch. Разрабатывает сетки, типографику и адаптивные шаблоны.',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80'
  },
  {
    name: 'Даниэль Ромеро',
    role: 'Motion-дизайнер',
    bio: 'Создаёт анимацию и motion-пакеты для запуска стримов и социальных сетей, консультирует по внедрению.',
    avatar: 'https://images.unsplash.com/photo-1557684387-08927d28e9c7?auto=format&fit=crop&w=300&q=80'
  },
  {
    name: 'Екатерина Омелян',
    role: 'Аналитик визуального контента',
    bio: 'Следит за трендами, проводит аудит визуала брендов и собирает рекомендации по вовлечению аудитории.',
    avatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=300&q=80'
  }
];

const blogArticles = [
  {
    title: 'Как адаптировать визуал под разные платформы и устройства',
    excerpt: 'Разбираем особенности обложек и баннеров для YouTube, Twitch и TikTok: размеры, композиция и ошибки, которые снижают вовлечённость.',
    date: 'Март 2024',
    url: '/services'
  },
  {
    title: '7 трендов графики для стримов в 2024 году',
    excerpt: 'Неон, handmade-текстуры, bold-типографика и другие элементы, которые формируют стиль стриминговых каналов.',
    date: 'Февраль 2024',
    url: '/catalog/stream-banners'
  },
  {
    title: 'Как подготовить визуал к международному запуску',
    excerpt: 'Чек-лист по локализации, работе с цветом и текстом, чтобы ваш визуал выглядел уверенно на глобальном рынке.',
    date: 'Январь 2024',
    url: '/contact'
  }
];

const HomePage = () => {
  const [statsValues, setStatsValues] = React.useState(statsData.map(() => 0));
  const statsIntervals = React.useRef([]);
  const [activeFilter, setActiveFilter] = React.useState('Все');
  const [testimonialIndex, setTestimonialIndex] = React.useState(0);

  React.useEffect(() => {
    statsIntervals.current = statsData.map((stat, index) => (
      setInterval(() => {
        setStatsValues((prev) => {
          const next = [...prev];
          const increment = Math.max(1, Math.round(stat.value / 40));
          if (next[index] < stat.value) {
            next[index] = Math.min(stat.value, next[index] + increment);
          } else {
            clearInterval(statsIntervals.current[index]);
          }
          return next;
        });
      }, 40)
    ));

    return () => statsIntervals.current.forEach((interval) => clearInterval(interval));
  }, []);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => clearInterval(timer);
  }, []);

  const filteredProjects = activeFilter === 'Все'
    ? projectItems
    : projectItems.filter((item) => item.category === activeFilter);

  return (
    <>
      <Helmet>
        <title>DigitalCovers — готовая графика для видео, стримов и соцсетей</title>
        <meta
          name="description"
          content="DigitalCovers — платформа с готовыми обложками, аватарками, баннерами и графикой для глобальных проектов. Выберите коллекцию и адаптируйте под свой бренд."
        />
        <meta
          name="keywords"
          content="обложки для видео, аватарки, баннеры для стримов, миниатюры YouTube, графика для соцсетей, цифровые товары"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <div className={styles.heroContent}>
              <span className="section-label">Цифровая графика</span>
              <h1>Создаём визуальные решения, которые помогают вашим контент-проектам выделяться</h1>
              <p>
                Каталог DigitalCovers — это готовые коллекции обложек, аватарок, баннеров и социальных шаблонов
                для международной аудитории. Гибкая кастомизация, актуальные тренды и поддержка дизайнеров.
              </p>
              <div className={styles.heroActions}>
                <Link to="/catalog" className="btn">Открыть каталог</Link>
                <Link to="/contact" className="btn btn-secondary">Обсудить задачу</Link>
              </div>
              <div className={styles.heroMeta}>
                <div>
                  <span>Без шаблонности</span>
                  <p>Каждый макет уникален и готов к публикации</p>
                </div>
                <div>
                  <span>Международный охват</span>
                  <p>Работаем с авторами из 26 стран</p>
                </div>
              </div>
            </div>
            <div className={styles.heroVisual}>
              <div className={styles.heroCard}>
                <img
                  src="https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&w=900&q=80"
                  alt="Коллаж из цифровых обложек и баннеров"
                />
                <div className={styles.heroOverlay}>
                  <p>Готовые коллекции · Индивидуальные решения · Стратегия визуала</p>
                </div>
              </div>
              <div className={styles.heroBadge}>
                <span>2024</span>
                <p>Обновление каталога каждые 2 недели</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className={styles.advantagesGrid}>
            {advantages.map((advantage) => (
              <article key={advantage.title} className={styles.advantageCard}>
                <span className={styles.advantageIcon} aria-hidden="true">{advantage.icon}</span>
                <h3>{advantage.title}</h3>
                <p>{advantage.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {statsValues[index]}
                  {stat.suffix || ''}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.categoriesSection}>
        <div className="container">
          <div className="section-heading">
            <span className="section-label">Категории</span>
            <h2 className="section-title">Популярные подборки DigitalCovers</h2>
            <p className="section-description">
              Мы отбираем коллекции, которые помогают брендам и авторам запускать контент быстрее,
              сохраняя высокий уровень визуальной культуры. Нажмите на категорию, чтобы посмотреть подборку.
            </p>
          </div>
          <div className={styles.categoriesGrid}>
            {categories.map((category) => (
              <Link key={category.id} to={`/catalog/${category.id}`} className={styles.categoryCard}>
                <div className={styles.categoryImage}>
                  <img src={category.image} alt={category.name} loading="lazy" />
                  <div className={styles.categoryOverlay} />
                </div>
                <div className={styles.categoryContent}>
                  <h3>{category.name}</h3>
                  <p>{category.description}</p>
                  <span className={styles.categoryLink}>Перейти →</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <div className="section-heading">
            <span className="section-label">Дополнительные услуги</span>
            <h2 className="section-title">Как DigitalCovers помогает брендам запускать визуальные продукты</h2>
            <p className="section-description">
              Нужна доработка коллекции под фирменный стиль, адаптация под новые площадки или полный сетап визуала — мы готовы подключиться.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesHighlight.map((service) => (
              <div key={service.title} className={styles.serviceCard}>
                <span className={styles.serviceIcon}>{service.icon}</span>
                <h3>{service.title}</h3>
                <p>{service.text}</p>
                <Link to={service.link} className={styles.serviceLink}>Узнать подробнее</Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <div key={step.step} className={styles.processCard}>
                <span className={styles.processNumber}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <div className="section-heading">
            <span className="section-label">Проекты</span>
            <h2 className="section-title">Примеры коллекций и внедрения</h2>
            <p className="section-description">
              Смотрим, как готовые наборы DigitalCovers помогают авторам расширять аудиторию,
              запускать новые форматы и визуально поддерживать инфоповоды.
            </p>
          </div>
          <div className={styles.filterBar} role="tablist">
            {projectFilters.map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={`${styles.filterButton} ${activeFilter === filter ? styles.filterButtonActive : ''}`}
                role="tab"
                aria-selected={activeFilter === filter}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img src={project.image} alt={project.title} loading="lazy" />
                  <span className="tag">{project.category}</span>
                </div>
                <div className={styles.projectContent}>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <div className={styles.testimonialsWrapper}>
            <div className={styles.testimonialInfo}>
              <span className="section-label">Отзывы</span>
              <h2>Нам доверяют авторы, студии и digital-команды</h2>
              <p>
                От индивидуальных стримеров до образовательных платформ и технологических стартапов —
                мы помогаем строить узнаваемый визуальный язык и запускать проекты с первой попытки.
              </p>
              <Link to="/contact" className="btn btn-secondary">Получить консультацию</Link>
            </div>
            <div className={styles.testimonialCard}>
              <div className={styles.testimonialAvatar}>
                <img src={testimonials[testimonialIndex].avatar} alt={testimonials[testimonialIndex].name} />
              </div>
              <blockquote>{testimonials[testimonialIndex].quote}</blockquote>
              <div className={styles.testimonialAuthor}>
                <span>{testimonials[testimonialIndex].name}</span>
                <p>{testimonials[testimonialIndex].role}</p>
              </div>
              <div className={styles.testimonialControls}>
                <button
                  type="button"
                  onClick={() => setTestimonialIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1))}
                  aria-label="Предыдущий отзыв"
                >
                  ←
                </button>
                <button
                  type="button"
                  onClick={() => setTestimonialIndex((prev) => (prev + 1) % testimonials.length)}
                  aria-label="Следующий отзыв"
                >
                  →
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className="section-heading">
            <span className="section-label">Команда</span>
            <h2 className="section-title">Люди, которые создают DigitalCovers</h2>
            <p className="section-description">
              Мы объединяем дизайнеров, иллюстраторов, motion-специалистов и аналитиков визуала, чтобы строить комплексные решения.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <div key={member.name} className={styles.teamCard}>
                <div className={styles.teamAvatar}>
                  <img src={member.avatar} alt={member.name} loading="lazy" />
                </div>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <div className="section-heading">
            <span className="section-label">Insights</span>
            <h2 className="section-title">Актуальные заметки о визуальной коммуникации</h2>
            <p className="section-description">
              Делимся инсайтами о digital-дизайне, трендах платформ и способах улучшить вовлечённость контента через графику.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogArticles.map((article) => (
              <article key={article.title} className={styles.blogCard}>
                <span className={styles.blogDate}>{article.date}</span>
                <h3>{article.title}</h3>
                <p>{article.excerpt}</p>
                <Link to={article.url} className={styles.blogLink}>Читать рекомендацию</Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Готовы прокачать визуал вашей платформы?</h2>
              <p>
                Расскажите о задаче — подберём идеальную коллекцию или подготовим индивидуальные макеты.
                Поддерживаем авторов из любой точки мира, отвечаем в течение одного рабочего дня.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <Link to="/catalog" className="btn">Изучить каталог</Link>
              <Link to="/contact" className="btn btn-secondary">Связаться с нами</Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;