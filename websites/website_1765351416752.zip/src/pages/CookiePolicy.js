import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Политика использования cookies | DigitalCovers</title>
      <meta
        name="description"
        content="Узнайте, как DigitalCovers использует cookies для улучшения работы платформы."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Политика использования cookies</h1>
        <p>Последнее обновление: 12 марта 2024 года</p>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>1. Что такое cookies</h2>
        <p>
          Cookies — это небольшие текстовые файлы, которые сохраняются на вашем устройстве. Они помогают идентифицировать пользователя и запоминать настройки.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>2. Зачем мы используем cookies</h2>
        <ul>
          <li>Аналитика и улучшение интерфейса сайта.</li>
          <li>Запоминание предпочтений пользователей (например, выбранного языка).</li>
          <li>Обеспечение корректной работы форм и функционала страницы.</li>
        </ul>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>3. Управление cookies</h2>
        <p>
          Вы можете запретить или удалить cookies через настройки своего браузера. Обратите внимание, что это может повлиять на функциональность сайта.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>4. Контакты</h2>
        <p>
          Вопросы по вопросам cookies можно направлять на <a href="mailto:support@digitalcovers.com">support@digitalcovers.com</a>.
        </p>
      </div>
    </section>
  </div>
);

export default CookiePolicyPage;