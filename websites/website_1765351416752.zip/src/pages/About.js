import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const AboutPage = () => (
  <>
    <Helmet>
      <title>О DigitalCovers — команда и подход</title>
      <meta
        name="description"
        content="Узнайте, как команда DigitalCovers создаёт цифровые коллекции графики для авторов, брендов и студий по всему миру."
      />
      <meta
        name="keywords"
        content="DigitalCovers, команда дизайнеров, цифровой дизайн, визуальная стратегия"
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <div className={styles.heroContent}>
          <span className="section-label">О нас</span>
          <h1>DigitalCovers — команда дизайнеров, которая помогает контенту говорить громче</h1>
          <p>
            Мы работаем на стыке дизайна, аналитики и контент-маркетинга. Наша цель — дать авторам быстрый доступ
            к профессиональной графике, которую легко адаптировать под любые платформы.
          </p>
        </div>
      </div>
    </section>

    <section className={styles.mission}>
      <div className="container">
        <div className={styles.missionGrid}>
          <div className={styles.missionCard}>
            <h2>Миссия DigitalCovers</h2>
            <p>
              Сократить время между идеей и запуском контента, сохранив качество визуальной презентации. Мы изучаем
              платформы, следим за трендами и тестируем композиции, чтобы вы могли концентрироваться на смыслах.
            </p>
          </div>
          <div className={styles.missionList}>
            <h3>Наши ориентиры</h3>
            <ul>
              <li><strong>Оригинальность:</strong> каждая коллекция создаётся с нуля и проходит проверку на уникальность.</li>
              <li><strong>Гибкость:</strong> поддерживаем популярные форматы и предоставляем гайды по адаптации.</li>
              <li><strong>Ответственность:</strong> соблюдаем дедлайны и помогаем внедрить дизайн в рабочие процессы.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.timeline}>
      <div className="container">
        <div className="section-heading">
          <span className="section-label">История</span>
          <h2 className="section-title">Как развивалась платформа</h2>
          <p className="section-description">
            От небольшого дизайн-студии до международной платформы с коллекциями для YouTube, Twitch, TikTok и бизнес-сообществ.
          </p>
        </div>
        <div className={styles.timelineGrid}>
          <div className={styles.timelineItem}>
            <span>2019</span>
            <h3>Старт DigitalCovers</h3>
            <p>Запустили первую коллекцию обложек для образовательных YouTube-каналов и получили первые международные заказы.</p>
          </div>
          <div className={styles.timelineItem}>
            <span>2020</span>
            <h3>Расширение на стриминговый рынок</h3>
            <p>Создали пакеты графики для Twitch и Trovo, добавили поддержку overlay и экранов ожидания.</p>
          </div>
          <div className={styles.timelineItem}>
            <span>2021</span>
            <h3>Интеграция аналитики</h3>
            <p>Добавили визуальные рекомендации на основе показателей CTR и audience retention, усилили команду аналитиков.</p>
          </div>
          <div className={styles.timelineItem}>
            <span>2023</span>
            <h3>Глобальные клиенты</h3>
            <p>Работаем с авторами из 26 стран, запускаем проекты для EdTech, гейминга и креативных студий.</p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.values}>
      <div className="container">
        <div className={styles.valuesGrid}>
          <div className={styles.valuesIntro}>
            <h2>Ценности, которые ведут нас вперёд</h2>
            <p>
              Дизайн — это не только форма, но и стратегия. Поэтому мы строим процессы так, чтобы каждый макет работал
              на цели бизнеса и помогал командам расти.
            </p>
          </div>
          <ul className={styles.valuesList}>
            <li>
              <h3>Прозрачность</h3>
              <p>Мы делимся файлами, исходниками, гайдлайнами и объясняем, как использовать макеты эффективно.</p>
            </li>
            <li>
              <h3>Партнёрство</h3>
              <p>Строим долгосрочные отношения, помогаем планировать визуал под запуск продуктов и кампаний.</p>
            </li>
            <li>
              <h3>Обучение</h3>
              <p>Проводим лекции, показываем backstage-процессы и рассказываем, как дизайн влияет на метрики.</p>
            </li>
          </ul>
        </div>
      </div>
    </section>
  </>
);

export default AboutPage;