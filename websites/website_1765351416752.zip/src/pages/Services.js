import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './Services.module.css';

const servicePlans = [
  {
    title: 'Подбор коллекции',
    description: 'Вы получили бриф, сроки поджимают — мы подбираем готовые макеты, адаптируем цвета и типографику под бренд.',
    items: [
      '3–5 вариантов на выбор',
      'Настройка цвета и шрифтов',
      'Подготовка превью',
      'Гайд по внедрению'
    ],
    link: '/contact'
  },
  {
    title: 'Индивидуальный дизайн',
    description: 'Создаём уникальные обложки, баннеры, аватарки и презентационные материалы, исходя из тональности бренда.',
    items: [
      'Концепция и moodboard',
      'Разработка визуальных систем',
      'Подготовка исходников',
      'Поддержка до запуска'
    ],
    link: '/contact'
  },
  {
    title: 'Визуальная стратегия',
    description: 'Помогаем сформировать библиотеку графики для регулярного контента: гайды, шаблоны, правила использования.',
    items: [
      'Аудит текущего визуала',
      'Контент-план по визуалу',
      'Система шаблонов и сеток',
      'Обучение команды'
    ],
    link: '/contact'
  }
];

const ServicesPage = () => (
  <>
    <Helmet>
      <title>Услуги DigitalCovers — подбор и кастомизация графики</title>
      <meta
        name="description"
        content="Информацию об услугах DigitalCovers: подбор коллекций, индивидуальный дизайн и визуальная стратегия для брендов и авторов."
      />
      <meta
        name="keywords"
        content="услуги дизайна, подбор графики, кастомизация обложек, визуальная стратегия"
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <div className={styles.heroContent}>
          <span className="section-label">Услуги</span>
          <h1>Мы адаптируем графику под ваши задачи</h1>
          <p>
            Помимо каталога готовых решений, команда DigitalCovers помогает выстраивать комплексный визуал:
            от экспресс-подборов до полного сопровождения запуска.
          </p>
          <a href="mailto:partners@digitalcovers.com" className="btn">Запросить консультацию</a>
        </div>
      </div>
    </section>

    <section className={styles.plans}>
      <div className="container">
        <div className="section-heading">
          <span className="section-label">Форматы сотрудничества</span>
          <h2 className="section-title">Выберите удобный сценарий</h2>
          <p className="section-description">
            Мы гибко подстраиваемся под процессы вашей команды: работаем с брифами, организуем созвоны
            и предоставляем промежуточные отчёты.
          </p>
        </div>
        <div className={styles.planGrid}>
          {servicePlans.map((plan) => (
            <div key={plan.title} className={styles.planCard}>
              <h3>{plan.title}</h3>
              <p>{plan.description}</p>
              <ul>
                {plan.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <Link to={plan.link} className={styles.planLink}>Связаться →</Link>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.workflow}>
      <div className="container">
        <div className={styles.workflowInner}>
          <h2>Как проходит работа</h2>
          <div className={styles.steps}>
            <div>
              <span>1</span>
              <h3>Диагностика и бриф</h3>
              <p>Задаём вопросы, изучаем ваши площадки и аудиторию, определяем визуальные ориентиры.</p>
            </div>
            <div>
              <span>2</span>
              <h3>Концепция и прототипы</h3>
              <p>Предлагаем moodboard, цветовые схемы, сетки. После согласования создаём первые макеты.</p>
            </div>
            <div>
              <span>3</span>
              <h3>Передача файлов и поддержка</h3>
              <p>Финализируем визуал, собираем пакет исходников и инструкций, сопровождаем внедрение.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default ServicesPage;