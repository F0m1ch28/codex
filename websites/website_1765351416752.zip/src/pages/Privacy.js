import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const PrivacyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Политика конфиденциальности | DigitalCovers</title>
      <meta
        name="description"
        content="Политика конфиденциальности DigitalCovers: как мы обрабатываем и защищаем данные пользователей."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Политика конфиденциальности</h1>
        <p>Последнее обновление: 12 марта 2024 года</p>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>1. Собираемые данные</h2>
        <p>
          Мы обрабатываем данные, которые вы добровольно передаёте через формы, email или при подписке на обновления.
          Это может включать имя, email и описание проекта.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>2. Цели обработки</h2>
        <ul>
          <li>Ответ на запросы и предоставление услуг DigitalCovers.</li>
          <li>Отправка новостей о каталоге и обновления сервиса (по вашему согласию).</li>
          <li>Анализ и улучшение наших продуктов и коммуникаций.</li>
        </ul>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>3. Хранение и защита</h2>
        <p>
          Мы используем защищённые каналы передачи данных и актуальные методы безопасности. Доступ к информации имеют только сотрудники, задействованные в оказании услуг.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>4. Права пользователей</h2>
        <p>
          Вы можете запросить копию своих данных, их уточнение или удаление. Направьте запрос на <a href="mailto:support@digitalcovers.com">support@digitalcovers.com</a>,
          и мы ответим в течение 30 дней.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>5. Изменения политики</h2>
        <p>
          Мы можем обновлять Политику конфиденциальности. Актуальная версия всегда доступна на этой странице с указанием даты обновления.
        </p>
      </div>
    </section>
  </div>
);

export default PrivacyPage;