import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const ContactPage = () => {
  const [formData, setFormData] = React.useState(initialState);
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Укажите имя или название проекта.';
    if (!formData.email.trim()) {
      newErrors.email = 'Добавьте рабочий email.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/i.test(formData.email)) {
      newErrors.email = 'Проверьте формат email.';
    }
    if (!formData.message.trim()) newErrors.message = 'Опишите задачу или интересующую коллекцию.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData(initialState);
    }
  };

  return (
    <>
      <Helmet>
        <title>Контакты DigitalCovers</title>
        <meta
          name="description"
          content="Свяжитесь с DigitalCovers: support@digitalcovers.com для вопросов и partners@digitalcovers.com для сотрудничества."
        />
        <meta
          name="keywords"
          content="контакты DigitalCovers, support@digitalcovers.com, partners@digitalcovers.com"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-label">Связаться с нами</span>
            <h1>Расскажите, какой визуал вам нужен</h1>
            <p>
              Используйте форму или напишите напрямую. Мы ответим в течение одного рабочего дня и расскажем,
              как лучше всего реализовать задачу.
            </p>
            <div className={styles.contactInfo}>
              <div>
                <h3>Общие вопросы</h3>
                <a href="mailto:support@digitalcovers.com">support@digitalcovers.com</a>
              </div>
              <div>
                <h3>Партнёрство и кастомизация</h3>
                <a href="mailto:partners@digitalcovers.com">partners@digitalcovers.com</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.formSection}>
        <div className="container">
          <div className={styles.formWrapper}>
            {submitted && (
              <div className="success-message">
                Спасибо! Мы получили ваше сообщение и свяжемся с вами по указанному email.
              </div>
            )}
            <form onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Имя или название проекта *</label>
                <input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(event) => setFormData({ ...formData, name: event.target.value })}
                  placeholder="Например, Digital Lab"
                />
                {errors.name && <span className="error-message">{errors.name}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="email">Email для связи *</label>
                <input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(event) => setFormData({ ...formData, email: event.target.value })}
                  placeholder="contact@company.com"
                />
                {errors.email && <span className="error-message">{errors.email}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="company">Ссылка на ваш проект</label>
                <input
                  id="company"
                  type="text"
                  value={formData.company}
                  onChange={(event) => setFormData({ ...formData, company: event.target.value })}
                  placeholder="https://"
                />
              </div>

              <div className={styles.field}>
                <label htmlFor="message">Какой визуал вам нужен? *</label>
                <textarea
                  id="message"
                  value={formData.message}
                  onChange={(event) => setFormData({ ...formData, message: event.target.value })}
                  placeholder="Расскажите о задачах, бренде, стилевых предпочтениях и сроках."
                />
                {errors.message && <span className="error-message">{errors.message}</span>}
              </div>

              <button type="submit" className="btn">Отправить запрос</button>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;