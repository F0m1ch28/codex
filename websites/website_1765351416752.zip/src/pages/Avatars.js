import React from 'react';
import CategoryTemplate from '../components/CategoryTemplate';

const AvatarsPage = () => (
  <CategoryTemplate
    categoryId="avatars"
    title="Аватарки и иконки"
    description="Соберите узнаваемый образ бренда или личного проекта. Мы предлагаем стилизованные аватарки и наборы иконок, которые масштабируются от соцсетей до приложений."
    keywords="аватарки, иконки для соцсетей, дизайн аватарок, цифровой портрет"
    ctaLabel="Адаптируйте любой макет под разные платформы: от круглых аватарок до анимаций для сторис."
  />
);

export default AvatarsPage;