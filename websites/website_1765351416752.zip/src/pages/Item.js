import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { items, categories } from '../data/products';
import styles from './Item.module.css';

const ItemPage = () => {
  const { slug } = useParams();
  const item = items.find((entry) => entry.slug === slug);
  const categoryName = categories.find((cat) => cat.id === item?.category)?.name;

  if (!item) {
    return (
      <div className={`container ${styles.notFound}`}>
        <Helmet>
          <title>Элемент не найден | DigitalCovers</title>
        </Helmet>
        <h1>Мы не нашли этот макет</h1>
        <p>Возможно, он был обновлён или перенесён. Зайдите в <Link to="/catalog">каталог</Link>, чтобы выбрать актуальные решения.</p>
      </div>
    );
  }

  return (
    <article className={styles.itemPage}>
      <Helmet>
        <title>{`${item.title} | DigitalCovers`}</title>
        <meta name="description" content={item.description} />
        <meta name="keywords" content={`${item.tags.join(', ')}, ${categoryName}`} />
      </Helmet>

      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroImage}>
            <img src={item.image} alt={item.alt} />
          </div>
          <div className={styles.heroContent}>
            <span className="tag">{categoryName}</span>
            <h1>{item.title}</h1>
            <p>{item.description}</p>
            <div className={styles.tags}>
              {item.tags.map((tag) => (
                <span key={tag} className="tag">{tag}</span>
              ))}
            </div>
            <div className={styles.heroActions}>
              <a href="mailto:support@digitalcovers.com" className="btn">Запросить файлы</a>
              <Link to="/catalog" className="btn btn-secondary">Вернуться в каталог</Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.details}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.card}>
              <h2>Что включено</h2>
              <ul>
                {item.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
            </div>
            <div className={styles.card}>
              <h2>Как использовать</h2>
              <p>
                Получите исходные файлы, замените текст и цвета на свои, а затем экспортируйте нужные форматы.
                Команда DigitalCovers поможет адаптировать макет под дополнительные площадки и даст технические рекомендации.
              </p>
              <p>
                Напишите нам на <a href="mailto:partners@digitalcovers.com">partners@digitalcovers.com</a>, если вам нужна кастомизация или расширение серии.
              </p>
            </div>
          </div>
        </div>
      </section>
    </article>
  );
};

export default ItemPage;