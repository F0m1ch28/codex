import React from 'react';
import CategoryTemplate from '../components/CategoryTemplate';

const VideoCoversPage = () => (
  <CategoryTemplate
    categoryId="video-covers"
    title="Обложки для видео"
    description="Макеты с продуманной типографикой и яркими акцентами для YouTube, Vimeo и образовательных платформ. Повышайте CTR и узнаваемость канала благодаря визуальной системе."
    keywords="обложки для видео, миниатюры YouTube, дизайн обложек YouTube, видеообложки"
    ctaLabel="Используйте готовые обложки, чтобы выделить ключевые видео и повысить кликабельность."
  />
);

export default VideoCoversPage;