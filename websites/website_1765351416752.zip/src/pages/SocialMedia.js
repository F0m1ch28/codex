import React from 'react';
import CategoryTemplate from '../components/CategoryTemplate';

const SocialMediaPage = () => (
  <CategoryTemplate
    categoryId="social-media"
    title="Графика для соцсетей"
    description="Шаблоны для постов, сторис, каруселей и презентаций: создавайте контент быстрее и поддерживайте целостность бренда во всех социальных сетях."
    keywords="графика для соцсетей, instagram шаблоны, tiktok дизайн, карусели"
    ctaLabel="Используйте карусели, сторис и карточки, чтобы рассказывать истории, делиться новостями и усиливать вовлечённость."
  />
);

export default SocialMediaPage;