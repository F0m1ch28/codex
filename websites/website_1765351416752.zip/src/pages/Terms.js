import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const TermsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Лицензионное соглашение | DigitalCovers</title>
      <meta
        name="description"
        content="Лицензионное соглашение DigitalCovers: правила использования цифровых макетов и правовая информация."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Лицензионное соглашение DigitalCovers</h1>
        <p>Последнее обновление: 12 марта 2024 года</p>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>1. Общие положения</h2>
        <p>
          DigitalCovers предоставляет доступ к цифровым графическим материалам (далее — «Материалы»), включая обложки,
          аватарки, баннеры и иные визуальные элементы. Используя материалы, вы соглашаетесь соблюдать условия настоящего документа.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>2. Лицензионные права</h2>
        <ul>
          <li>Материалы предоставляются по невexclusive лицензии. Вы можете использовать их в коммерческих и некоммерческих проектах.</li>
          <li>Лицензия распространяется на один бренд, компанию или автора. Для нескольких проектов потребуется дополнительная лицензия.</li>
          <li>Вы вправе модифицировать материалы, адаптируя их под свои задачи, с учётом соблюдения авторских прав.</li>
        </ul>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>3. Запрещённые действия</h2>
        <ul>
          <li>Перепродажа, распространение или публикация исходных файлов без письменного согласия DigitalCovers.</li>
          <li>Использование материалов для проектов, связанных с политикой, насилием, дискриминацией или контентом для взрослых.</li>
          <li>Представление материалов как собственных авторских работ без внесённых изменений.</li>
        </ul>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>4. Интеллектуальная собственность</h2>
        <p>
          Все материалы защищены законами об авторском праве и принадлежат DigitalCovers и нашим авторам. Покупка лицензии не означает передачу исключительных прав.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className="container">
        <h2>5. Обратная связь</h2>
        <p>
          Вопросы и предложения по условиям соглашения можно направлять на <a href="mailto:support@digitalcovers.com">support@digitalcovers.com</a>.
        </p>
      </div>
    </section>
  </div>
);

export default TermsPage;