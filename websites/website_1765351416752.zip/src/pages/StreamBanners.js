import React from 'react';
import CategoryTemplate from '../components/CategoryTemplate';

const StreamBannersPage = () => (
  <CategoryTemplate
    categoryId="stream-banners"
    title="Баннеры для стримов"
    description="Комплексные пакеты графики для стримеров: overlay, панели, закрывающие экраны и баннеры для анонсов. Поддерживаем Twitch, Trovo, YouTube Live и другие платформы."
    keywords="баннеры для стримов, overlay, twitch баннеры, графика для стримеров"
    ctaLabel="Выбирайте пакет, который отражает атмосферу вашего канала, и дополняйте его уникальными элементами."
  />
);

export default StreamBannersPage;