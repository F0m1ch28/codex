import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './NotFound.module.css';

const NotFoundPage = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Страница не найдена | DigitalCovers</title>
    </Helmet>
    <span>404</span>
    <h1>Кажется, такая страница не существует</h1>
    <p>
      Проверьте адрес или вернитесь на главную. Мы будем рады помочь найти нужную коллекцию или рассказать о новых релизах.
    </p>
    <div className={styles.actions}>
      <Link to="/" className="btn">На главную</Link>
      <Link to="/catalog" className="btn btn-secondary">В каталог</Link>
    </div>
  </div>
);

export default NotFoundPage;