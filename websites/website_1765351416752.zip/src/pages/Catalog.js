import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { categories, items } from '../data/products';
import styles from './Catalog.module.css';

const CatalogPage = () => {
  const highlightedItems = items.slice(0, 6);

  return (
    <>
      <Helmet>
        <title>Каталог DigitalCovers — готовые коллекции графики</title>
        <meta
          name="description"
          content="Каталог DigitalCovers: обложки для видео, аватарки, баннеры для стримов и графика для соцсетей. Готовые коллекции и гибкая кастомизация."
        />
        <meta
          name="keywords"
          content="каталог цифровой графики, обложки для видео, баннеры, аватарки, шаблоны для соцсетей"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <div>
              <span className="section-label">Каталог</span>
              <h1>Откройте коллекции DigitalCovers</h1>
              <p>
                Используйте фильтр по категориям и изучите подборки готовых макетов. Каждый файл адаптирован под крупные
                платформы и детально описан для удобной кастомизации.
              </p>
            </div>
            <div className={styles.heroAside}>
              <p>Не нашли нужный стиль? <Link to="/contact">Напишите нам</Link>, и мы подготовим персональную рекомендацию.</p>
              <Link to="/services" className="btn btn-secondary">Узнать об индивидуальных услугах</Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.categories}>
        <div className="container">
          <h2>Категории каталога</h2>
          <div className={styles.categoryGrid}>
            {categories.map((category) => (
              <Link key={category.id} to={`/catalog/${category.id}`} className={styles.categoryCard}>
                <div className={styles.categoryImage}>
                  <img src={category.image} alt={category.name} loading="lazy" />
                </div>
                <div className={styles.categoryBody}>
                  <h3>{category.name}</h3>
                  <p>{category.description}</p>
                  <span>Перейти →</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.highlight}>
        <div className="container">
          <div className="section-heading">
            <span className="section-label">В центре внимания</span>
            <h2 className="section-title">Выбор редакции</h2>
            <p className="section-description">
              Несколько макетов, которые отлично подойдут для быстрого старта. Подберите визуал, адаптируйте цвета и публикуйте уже сегодня.
            </p>
          </div>
          <div className={styles.itemGrid}>
            {highlightedItems.map((item) => (
              <article key={item.slug} className={styles.itemCard}>
                <div className={styles.itemImage}>
                  <img src={item.image} alt={item.alt} loading="lazy" />
                </div>
                <div className={styles.itemBody}>
                  <span className="tag">{categories.find((c) => c.id === item.category)?.name}</span>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                  <Link to={`/item/${item.slug}`} className={styles.itemLink}>Подробнее</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default CatalogPage;