import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Faq.module.css';

const faqs = [
  {
    question: 'Можно ли адаптировать готовый макет под фирменные цвета?',
    answer: 'Да, в каждый пакет входят исходные файлы. Мы также можем адаптировать макет за вас — просто отправьте брендбук или примеры, и мы подготовим версию в заданной стилистике.'
  },
  {
    question: 'Как быстро вы отвечаете на запросы?',
    answer: 'Среднее время ответа — один рабочий день. Для срочных задач можно написать на partners@digitalcovers.com с пометкой «СРОЧНО».'
  },
  {
    question: 'В каких форматах вы передаёте файлы?',
    answer: 'Мы предоставляем исходники в PSD, Figma и AI (когда это возможно), а также экспортируем готовые PNG/JPG. При необходимости подготовим гайды и шаблоны для Canva.'
  },
  {
    question: 'Вы помогаете с анимацией и motion-графикой?',
    answer: 'Да, в команде есть motion-дизайнеры. Мы подготавливаем исходники для After Effects или создаём анимированные сцены по запросу.'
  },
  {
    question: 'Можно ли заказать эксклюзивную коллекцию?',
    answer: 'Да, мы создаём эксклюзивные наборы для брендов и агентств. Опишите задачу через форму на странице «Контакты», и мы предложим план работ.'
  }
];

const FaqPage = () => {
  const [openIndex, setOpenIndex] = React.useState(null);

  return (
    <>
      <Helmet>
        <title>FAQ DigitalCovers — ответы на вопросы</title>
        <meta
          name="description"
          content="Частые вопросы о коллекциях DigitalCovers, кастомизации, форматах файлов и сроках ответов."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-label">FAQ</span>
            <h1>Ответы на популярные вопросы</h1>
            <p>Если вы не нашли нужную информацию — напишите нам на support@digitalcovers.com, и мы расскажем подробнее.</p>
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.faqList}>
            {faqs.map((item, index) => {
              const isOpen = openIndex === index;
              return (
                <div key={item.question} className={`${styles.faqItem} ${isOpen ? styles.faqItemOpen : ''}`}>
                  <button
                    type="button"
                    className={styles.faqQuestion}
                    onClick={() => setOpenIndex(isOpen ? null : index)}
                    aria-expanded={isOpen}
                  >
                    <span>{item.question}</span>
                    <span>{isOpen ? '−' : '+'}</span>
                  </button>
                  {isOpen && <p className={styles.faqAnswer}>{item.answer}</p>}
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </>
  );
};

export default FaqPage;