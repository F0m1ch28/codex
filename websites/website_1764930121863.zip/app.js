document.addEventListener("DOMContentLoaded", () => {
  const cookieBanner = document.querySelector("[data-cookie-banner]");
  const acceptBtn = document.querySelector("[data-cookie-accept]");
  const declineBtn = document.querySelector("[data-cookie-decline]");
  const cookiePreference = localStorage.getItem("cdmCookiePreference");

  if (cookieBanner && !cookiePreference) {
    setTimeout(() => cookieBanner.classList.add("is-active"), 400);
  }
  const handleCookieChoice = (choice) => {
    localStorage.setItem("cdmCookiePreference", choice);
    if (cookieBanner) {
      cookieBanner.classList.remove("is-active");
    }
  };
  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => handleCookieChoice("accepted"));
  }
  if (declineBtn) {
    declineBtn.addEventListener("click", () => handleCookieChoice("declined"));
  }

  const scenarioButtons = document.querySelectorAll("[data-scenario]");
  const metricPanel = document.querySelector("[data-scenario-panel]");
  if (scenarioButtons.length && metricPanel) {
    const scenarioData = {
      baseline: {
        "Executive Confidence": "78% leadership adoption of KPI suite",
        "Reporting Velocity": "18% faster month-end analytics cycle",
        "Data Reliability": "99.3% reconciled metric integrity"
      },
      accelerated: {
        "Executive Confidence": "91% leadership adoption of KPI suite",
        "Reporting Velocity": "34% faster month-end analytics cycle",
        "Data Reliability": "99.6% reconciled metric integrity"
      },
      predictive: {
        "Executive Confidence": "96% leadership adoption of KPI suite",
        "Reporting Velocity": "47% faster month-end analytics cycle",
        "Data Reliability": "99.8% reconciled metric integrity"
      }
    };
    const updateMetrics = (scenario) => {
      const metrics = scenarioData[scenario];
      metricPanel.querySelectorAll("[data-metric-key]").forEach((node) => {
        const key = node.dataset.metricKey;
        if (metrics[key]) {
          node.textContent = metrics[key];
        }
      });
    };
    scenarioButtons.forEach((button) => {
      button.addEventListener("click", () => {
        scenarioButtons.forEach((btn) => btn.classList.remove("active"));
        button.classList.add("active");
        updateMetrics(button.dataset.scenario);
      });
    });
    scenarioButtons[0].classList.add("active");
    updateMetrics(scenarioButtons[0].dataset.scenario);
  }

  const depthControls = document.querySelectorAll("[data-depth]");
  const depthOutput = document.querySelector("[data-depth-output]");
  if (depthControls.length && depthOutput) {
    const depthData = {
      design:
        "Structured metric architecture blueprints mapping enterprise objectives to cascaded KPIs, governance cadences, and stewardship roles across Canadian business units.",
      integration:
        "Embedded analytics infrastructure that aligns ERP, CRM, and provincial data hubs into a single semantic model with governed lineage and KPI health monitoring.",
      enablement:
        "Executive and practitioner enablement programs delivering analytics playbooks, dashboard certification, and on-demand office hours tailored to Canadian regulatory contexts."
    };
    const setDepth = (key, control) => {
      depthControls.forEach((btn) => btn.classList.remove("active"));
      control.classList.add("active");
      depthOutput.textContent = depthData[key];
    };
    depthControls.forEach((control) => {
      control.addEventListener("click", () => setDepth(control.dataset.depth, control));
    });
    setDepth(depthControls[0].dataset.depth, depthControls[0]);
  }

  const contactForm = document.querySelector("#contact-form");
  const feedback = document.querySelector("#form-feedback");
  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      const requiredFields = ["full-name", "email", "company", "message"];
      let hasError = false;
      requiredFields.forEach((fieldId) => {
        const field = contactForm.querySelector(`#${fieldId}`);
        if (!field) return;
        if (!field.value.trim()) {
          hasError = true;
          field.setAttribute("aria-invalid", "true");
          field.classList.add("input-error");
        } else {
          field.removeAttribute("aria-invalid");
          field.classList.remove("input-error");
        }
      });
      if (hasError) {
        event.preventDefault();
        if (feedback) {
          feedback.textContent = "Please complete the highlighted fields to help us understand your analytics objectives.";
          feedback.className = "form-feedback form-feedback--error is-visible";
        }
      } else if (feedback) {
        feedback.textContent = "Thank you. Our analytics advisory team will respond within one business day.";
        feedback.className = "form-feedback form-feedback--success is-visible";
      }
    });
  }
});