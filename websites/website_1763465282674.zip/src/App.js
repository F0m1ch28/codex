import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Leitfaden from './pages/Leitfaden';
import Programme from './pages/Programme';
import Tools from './pages/Tools';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import About from './pages/About';
import Contact from './pages/Contact';
import Impressum from './pages/Impressum';
import Datenschutz from './pages/Datenschutz';
import AGB from './pages/AGB';

function App() {
  return (
    <div className="app">
      <Helmet>
        <html lang="de" />
        <title>Alveriona – Digitale Hygiene & innere Ruhe</title>
        <meta
          name="description"
          content="Alveriona hilft Dir, digitale Hygiene zu stärken, Informationsfluten zu sortieren und mehr Fokus in Deinen Alltag zu bringen."
        />
      </Helmet>
      <a href="#hauptinhalt" className="skipLink">
        Zum Inhalt springen
      </a>
      <Header />
      <main id="hauptinhalt" className="mainContent" role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/leitfaden" element={<Leitfaden />} />
          <Route path="/programme" element={<Programme />} />
          <Route path="/tools" element={<Tools />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogPost />} />
          <Route path="/ueber-uns" element={<About />} />
          <Route path="/kontakt" element={<Contact />} />
          <Route path="/impressum" element={<Impressum />} />
          <Route path="/datenschutz" element={<Datenschutz />} />
          <Route path="/agb" element={<AGB />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
}

export default App;