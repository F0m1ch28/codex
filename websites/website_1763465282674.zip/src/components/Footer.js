import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={`container ${styles.inner}`}>
        <div className={styles.brand}>
          <h2 id="footer-heading">Alveriona</h2>
          <p>
            Dein digitaler Begleiter für mehr Fokus, Struktur und Gelassenheit
            in einer Welt voller Informationen.
          </p>
          <p className={styles.disclaimer}>
            Hinweis: Alveriona bietet keine medizinische oder therapeutische Beratung.
          </p>
        </div>
        <div className={styles.columns}>
          <div>
            <h3>Navigation</h3>
            <ul>
              <li>
                <NavLink to="/">Startseite</NavLink>
              </li>
              <li>
                <NavLink to="/leitfaden">Leitfaden</NavLink>
              </li>
              <li>
                <NavLink to="/programme">Programme</NavLink>
              </li>
              <li>
                <NavLink to="/tools">Tools</NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h3>Rechtliches</h3>
            <ul>
              <li>
                <NavLink to="/impressum">Impressum</NavLink>
              </li>
              <li>
                <NavLink to="/datenschutz">Datenschutz</NavLink>
              </li>
              <li>
                <NavLink to="/agb">AGB</NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h3>Kontakt</h3>
            <ul className={styles.contactList}>
              <li>Musterstraße 12, 10115 Berlin</li>
              <li>E-Mail: [vom Kunden zu ergänzen]</li>
              <li>Telefon: optional</li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© {new Date().getFullYear()} Alveriona. Alle Rechte vorbehalten.</p>
        <div className={styles.socials}>
          <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
            LinkedIn
          </a>
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">
            Instagram
          </a>
        </div>
      </div>
    </footer>
  );
}

export default Footer;