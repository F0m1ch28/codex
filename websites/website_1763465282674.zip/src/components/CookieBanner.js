import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('alveriona_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('alveriona_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('alveriona_cookie_consent', 'declined');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie-Hinweis">
      <div className={styles.content}>
        <p>
          Wir verwenden Cookies, um Dir ein reibungsloses Erlebnis zu bieten. Deine Daten bleiben bei uns in guten Händen. Entscheide selbst, was für Dich passt.
        </p>
        <div className={styles.actions}>
          <button type="button" className={styles.secondary} onClick={handleDecline}>
            Nur notwendige Cookies
          </button>
          <button type="button" className={styles.primary} onClick={handleAccept}>
            Alles klar
          </button>
        </div>
        <a className={styles.link} href="/datenschutz">
          Mehr Infos zum Datenschutz
        </a>
      </div>
    </div>
  );
}

export default CookieBanner;