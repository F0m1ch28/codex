export const blogPosts = [
  {
    slug: 'achtsamer-umgang-mit-benachrichtigungen',
    title: 'Achtsamer Umgang mit Benachrichtigungen',
    category: 'Alltag',
    readingTime: '5 Min.',
    coverImage: 'https://picsum.photos/1200/720?random=11',
    excerpt:
      'Wie Du Benachrichtigungen bewusst steuerst und wieder entscheidest, wann Dein Smartphone deine Aufmerksamkeit bekommt.',
    publishedAt: '05. Januar 2024',
    content: [
      'Benachrichtigungen sind nützlich – wenn sie Dir dienen. Sobald sie Dich dominieren, wird es anstrengend. Ein erster Schritt ist daher, die eigenen Trigger zu kennen. Wann springst Du auf jedes Ping an? Welche Apps brauchen wirklich sofortige Aufmerksamkeit?',
      'Plane einen kleinen Audit: Gehe durch Deine Einstellungen und schalte alles aus, was Dich nicht aktiv weiterbringt. Gruppiere Benachrichtigungen, plane stille Phasen und setze klare Regeln, wann Du Apps bewusst prüfst.',
      'Das Ziel ist nicht, alles abzuschalten, sondern selbst zu steuern, wie viel Input Dich erreicht. Mit einem bewusst gestalteten Setup schaffst Du Raum für Fokus – ohne das Gefühl zu haben, etwas zu verpassen.'
    ]
  },
  {
    slug: 'digitale-pausen-rituale',
    title: 'Digitale Pausen als tägliche Rituale',
    category: 'Routine',
    readingTime: '6 Min.',
    coverImage: 'https://picsum.photos/1200/720?random=12',
    excerpt:
      'Regelmäßige Mikro-Pausen helfen Dir, den digitalen Fokus zu halten. So etablierst Du sie als festen Bestandteil Deiner Woche.',
    publishedAt: '18. Dezember 2023',
    content: [
      'Digitale Pausen müssen nichts Großes sein. Wichtig ist, dass sie regelmäßig stattfinden und bewusst erlebt werden. Stelle Dir Timer, die Dich freundlich daran erinnern, kurz aufzustehen, das Fenster zu öffnen oder Deine Augen zu entspannen.',
      'Nutze kleine Übergänge, zum Beispiel nach Meetings oder vor dem Feierabend, um Deinem Kopf einen Reset zu gönnen. Notiere Dir, was Dir in diesen Momenten guttut, und teste verschiedene Rituale, bis Du Deinen Mix gefunden hast.',
      'Mit der Zeit wirst Du merken, dass Deine Konzentration wieder stabiler wird. Pausen sind kein Luxus, sondern ein Baustein Deiner digitalen Hygiene.'
    ]
  },
  {
    slug: 'infodetox-fuer-den-newsfeed',
    title: 'Info-Detox für Deinen Newsfeed',
    category: 'News',
    readingTime: '7 Min.',
    coverImage: 'https://picsum.photos/1200/720?random=13',
    excerpt:
      'So bringst Du Ordnung in Deine Informationsquellen und sorgst für einen Newsfeed, der Dich stärkt statt stresst.',
    publishedAt: '02. Dezember 2023',
    content: [
      'Starte damit, Deine Quellen zu inventarisieren. Welche Newsletter, Podcasts oder Social-Accounts geben Dir wirklich Mehrwert? Alles andere darf in eine Pause gehen.',
      'Definiere feste Zeitfenster für News. Es lohnt sich, morgens und abends in Ruhe zu lesen statt permanent querzuscrollen. Nutze Tools, um Artikel zu speichern und später konzentriert zu lesen.',
      'Bleib flexibel: Dein Info-Bedarf ändert sich je nach Lebensphase. Überprüfe regelmäßig, welche Kanäle aktiv bleiben dürfen, und hab keine Scheu, Neues auszuprobieren.'
    ]
  },
  {
    slug: 'fokuszeiten-im-team-etablieren',
    title: 'Fokuszeiten im Team etablieren',
    category: 'Zusammenarbeit',
    readingTime: '8 Min.',
    coverImage: 'https://picsum.photos/1200/720?random=14',
    excerpt:
      'Wie Du in Deinem Team ruhige Fokusräume schaffst, ohne die Zusammenarbeit zu gefährden.',
    publishedAt: '20. November 2023',
    content: [
      'Kommunikation im Team bedeutet nicht, jederzeit erreichbar zu sein. Lege gemeinsam Fokusinseln fest, in denen alle ungestört arbeiten können.',
      'Schaffe Transparenz darüber, wie „dringend“ definiert ist und welche Kanäle für Notfälle genutzt werden. So entsteht Vertrauen, dass niemand etwas verpasst.',
      'Eine kleine Retro nach einigen Wochen zeigt, wie gut die neuen Regeln funktionieren. Passe sie iterativ an, bis sie für alle praktikabel sind.'
    ]
  }
];