import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Leitfaden.module.css';

const steps = [
  {
    id: 1,
    title: 'Status-Check',
    description:
      'Starte mit einem ehrlichen Blick auf Deinen Alltag: Was stresst Dich? Welche Apps fordern permanent Deine Aufmerksamkeit?',
    bullets: [
      'Mini-Tracking der Bildschirmzeit',
      'Emotionale Check-ins nach intensiven Medienmomenten',
      'Liste aller genutzten Informationsquellen'
    ]
  },
  {
    id: 2,
    title: 'Aufräumen',
    description:
      'Schaffe Platz für Klarheit. Sortiere Deine digitalen Räume und verabschiede Dich von Ballast, der nicht zu Deinen Zielen passt.',
    bullets: [
      'Benachrichtigungen priorisieren oder deaktivieren',
      'Newsletter und Feeds neu bewerten',
      'Messengern klare Zuständigkeiten geben'
    ]
  },
  {
    id: 3,
    title: 'Regeln',
    description:
      'Definiere Leitplanken, die Dir Orientierung geben – ohne Dich einzuengen. Sie helfen Dir, Deine Energie zu schützen.',
    bullets: [
      'Zeitfenster für News, Social & Kommunikation',
      'Grenzen für Devices (z. B. Schlafzimmerfrei)',
      'Team-Absprachen für Erreichbarkeit'
    ]
  },
  {
    id: 4,
    title: 'Routinen',
    description:
      'Mit wiederkehrenden Ritualen festigst Du Deine neue Balance. Klein anfangen, regelmäßig prüfen, flexibel bleiben.',
    bullets: [
      'Morgendlicher Fokus-Check-in',
      'Digitale Pausen als Mikro-Ritual',
      'Wöchentliche Reflexion mit Deinem Future-Self'
    ]
  }
];

function Leitfaden() {
  const [currentStep, setCurrentStep] = useState(0);

  const nextStep = () => {
    setCurrentStep((prev) => (prev + 1) % steps.length);
  };

  return (
    <>
      <Helmet>
        <title>Leitfaden für digitale Hygiene | Alveriona</title>
        <meta
          name="description"
          content="Der 4-Schritte-Leitfaden von Alveriona hilft Dir, digitale Hygiene aufzubauen – von Status-Check bis Routine."
        />
      </Helmet>
      <section className={`container ${styles.wrapper}`}>
        <header className={styles.header}>
          <h1>Dein 4-Schritte-Leitfaden</h1>
          <p>
            Jeder Schritt baut auf dem vorherigen auf. Nimm Dir Zeit, bleib freundlich zu Dir selbst
            und feiere jeden kleinen Fortschritt.
          </p>
        </header>

        <div className={styles.steps}>
          {steps.map((step, index) => (
            <article
              key={step.id}
              className={`${styles.stepCard} ${index === currentStep ? styles.stepActive : ''}`}
            >
              <div className={styles.stepHeader}>
                <span>Schritt {step.id}</span>
                <h2>{step.title}</h2>
              </div>
              <p>{step.description}</p>
              <ul>
                {step.bullets.map((bullet) => (
                  <li key={bullet}>{bullet}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>

        <div className={styles.cta}>
          <button type="button" onClick={nextStep}>
            Nächsten Schritt ansehen
          </button>
          <p>
            Tipp: Notiere Dir nach jedem Schritt kurz, wie Du Dich fühlst. Das stärkt Deine
            Selbstwahrnehmung.
          </p>
        </div>
      </section>
    </>
  );
}

export default Leitfaden;