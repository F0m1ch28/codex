import React, { useEffect, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';
import { blogPosts } from '../data/blogPosts';

const statsConfig = [
  { id: 'ruhe', label: 'Mehr Klarheit pro Tag', suffix: '%', target: 32 },
  { id: 'zeit', label: 'Zeit zurückgewonnen', suffix: ' Std/Woche', target: 6 },
  { id: 'teams', label: 'Teams mit Fokus-Regeln', suffix: '+', target: 120 }
];

const testimonials = [
  {
    name: 'Leonie, UX-Designerin',
    quote:
      '„Alveriona hat mir geholfen, meinen Medienkonsum bewusst zu steuern. Seitdem bin ich abends wieder entspannt.“'
  },
  {
    name: 'Markus, Teamleiter',
    quote:
      '„Wir haben als Team klare Notification-Regeln eingeführt. Die Meetings sind jetzt konzentrierter und kürzer.“'
  },
  {
    name: 'Aylin, Studierende',
    quote:
      '„Der 7-Tage-Info-Detox war mein Reset. Ich nutze jetzt feste Check-in Zeiten – mein Kopf dankt es mir.“'
  }
];

const teamMembers = [
  {
    name: 'Klara Weiss',
    role: 'Digital Balance Coach',
    image: 'https://picsum.photos/400/400?random=21',
    focus: 'Entwirrt Informationsquellen und entwickelt alltagstaugliche Routinen.'
  },
  {
    name: 'Jonas Berg',
    role: 'Habit Designer',
    image: 'https://picsum.photos/400/400?random=22',
    focus: 'Gestaltet Mini-Gewohnheiten, die sich leicht in Dein Leben integrieren.'
  },
  {
    name: 'Mira Scholz',
    role: 'Community Lead',
    image: 'https://picsum.photos/400/400?random=23',
    focus: 'Sorgt für Austausch und Motivation ohne Druck oder Perfektionismus.'
  }
];

const projects = [
  {
    title: 'Info-Detox Woche',
    category: 'Challenges',
    image: 'https://picsum.photos/800/520?random=31',
    description: 'Sieben Tage, sieben Aufgaben. Alltagstaugliche Inputs, die Dich sanft entschleunigen.'
  },
  {
    title: 'Benachrichtigungs-Reset',
    category: 'Workshops',
    image: 'https://picsum.photos/800/520?random=32',
    description: 'Interaktiver Workshop für Teams, die Ruhe in Messenger-Arbeitsflüsse bringen möchten.'
  },
  {
    title: 'Fokuszonen-Canvas',
    category: 'Tools',
    image: 'https://picsum.photos/800/520?random=33',
    description: 'Visuelles Canvas, um persönliche Fokuszeiten und Pausen sichtbar zu machen.'
  },
  {
    title: 'Digitaler Abendmodus',
    category: 'Challenges',
    image: 'https://picsum.photos/800/520?random=34',
    description: 'Geführtes Abendritual, das Dir hilft, dein Smartphone pünktlich schlafen zu schicken.'
  }
];

const faqItems = [
  {
    question: 'Was genau bedeutet digitale Hygiene?',
    answer:
      'Digitale Hygiene beschreibt bewusst gestaltete Gewohnheiten im Umgang mit Informationen, Geräten und Medien. Ziel ist ein ausgewogenes Gleichgewicht zwischen Input und Erholung – ohne Perfektionismus.'
  },
  {
    question: 'Brauche ich dafür viel Zeit?',
    answer:
      'Nein. Unsere Impulse sind auf kurze, wirksame Schritte ausgelegt. Du startest mit 5-10 Minuten pro Tag und passt alles an Dein Leben an.'
  },
  {
    question: 'Sind die Programme medizinische Beratung?',
    answer:
      'Nein. Alveriona bietet keine medizinischen oder therapeutischen Leistungen. Wir vermitteln alltagstaugliche Methoden für mehr Fokus und Ruhe.'
  },
  {
    question: 'Kann ich Alveriona im Team nutzen?',
    answer:
      'Ja. Viele unserer Werkzeuge lassen sich gemeinsam einsetzen. Wir unterstützen Dich gern dabei, Team-Fokuszeiten zu etablieren.'
  }
];

function Home() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [filteredCategory, setFilteredCategory] = useState('Alle');
  const [statsValues, setStatsValues] = useState(
    statsConfig.reduce((acc, stat) => ({ ...acc, [stat.id]: 0 }), {})
  );
  const [statsStarted, setStatsStarted] = useState(false);
  const statsRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !statsStarted) {
          setStatsStarted(true);
        }
      },
      { threshold: 0.4 }
    );
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => observer.disconnect();
  }, [statsStarted]);

  useEffect(() => {
    if (statsStarted) {
      const intervals = statsConfig.map((stat) => {
        const increment = stat.target / 60;
        return setInterval(() => {
          setStatsValues((prev) => {
            const current = prev[stat.id];
            if (current >= stat.target) {
              clearInterval(intervals[statsConfig.indexOf(stat)]);
              return { ...prev, [stat.id]: stat.target };
            }
            return { ...prev, [stat.id]: parseFloat((current + increment).toFixed(1)) };
          });
        }, 22);
      });

      return () => intervals.forEach((interval) => clearInterval(interval));
    }
  }, [statsStarted]);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    filteredCategory === 'Alle'
      ? projects
      : projects.filter((project) => project.category === filteredCategory);

  return (
    <>
      <Helmet>
        <title>Alveriona – Weniger Info-Stress, mehr Ruhe im Kopf</title>
        <meta
          name="description"
          content="Hol Dir digitale Hygiene in Deinen Alltag: mit Leitfaden, Tools, Programmen und einem empathischen Ansatz. Weniger Informationsstress, mehr Fokus."
        />
      </Helmet>
      <section className={`container ${styles.hero}`}>
        <div className={styles.heroText}>
          <h1>Weniger Info-Stress. Mehr Ruhe im Kopf.</h1>
          <p>
            Alveriona begleitet Dich dabei, digitale Reize zu sortieren, klare Routinen aufzubauen
            und wieder frei durchzuatmen. Sanft, praktisch und ohne Dogmen.
          </p>
          <div className={styles.heroActions}>
            <Link to="/programme" className={`buttonPrimary ${styles.heroPrimary}`}>
              Jetzt starten
            </Link>
            <Link to="/leitfaden" className="buttonSecondary">
              Digitale Hygiene entdecken
            </Link>
          </div>
          <ul className={styles.heroHighlights} aria-label="Highlights">
            <li>Alltagstaugliche Schritt-für-Schritt-Anleitungen</li>
            <li>Fokus auf mentale Klarheit statt Endlos-Optimierung</li>
            <li>Gemeinsam lernen statt allein kämpfen</li>
          </ul>
        </div>
        <div className={styles.heroMedia}>
          <div className={styles.heroImageWrapper}>
            <img
              src="https://picsum.photos/1600/900?random=1"
              alt="Person entspannt sich bei einer digitalen Pause"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section ref={statsRef} className={styles.stats}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsConfig.map((stat) => (
              <article key={stat.id} className={styles.statCard}>
                <span className={styles.statValue}>
                  {Math.round(statsValues[stat.id])}
                  {stat.suffix}
                </span>
                <p>{stat.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`container ${styles.intro}`}>
        <div className={styles.introContent}>
          <h2>Digitale Hygiene – was bedeutet das konkret?</h2>
          <p>
            Digitale Hygiene hilft Dir, Informationsflüsse bewusst zu gestalten. Du entscheidest
            wieder selbst, welche Apps, Feeds und Nachrichten Dir guttun. Das Ergebnis: Mehr Fokus,
            mehr Ruhe, mehr Zeit für Dinge, die Dir wichtig sind.
          </p>
          <ul className={styles.bulletList}>
            <li>Bewusste Bildschirmzeiten</li>
            <li>Wohl dosierte Informationsquellen</li>
            <li>Feste Routinen für Pausen & Erholung</li>
            <li>Klare Regeln für Benachrichtigungen</li>
          </ul>
        </div>
      </section>

      <section className={`container ${styles.benefits}`}>
        <header className={styles.sectionHeader}>
          <h2>Deine Vorteile mit Alveriona</h2>
          <p>Wir übersetzen digitale Selbstfürsorge in kleine Schritte, die sofort wirken.</p>
        </header>
        <div className={styles.benefitGrid}>
          <article className={styles.benefitCard}>
            <h3>Fokus statt Multitasking</h3>
            <p>
              Lerne, wie Du tiefe Arbeitsphasen schützt und trotzdem mit Deinem Umfeld verbunden
              bleibst.
            </p>
          </article>
          <article className={styles.benefitCard}>
            <h3>Gelassener Medienkonsum</h3>
            <p>
              Durchdachte Filter und Check-ins sorgen dafür, dass Deine Zeit online Dich inspiriert
              statt zu überfordern.
            </p>
          </article>
          <article className={styles.benefitCard}>
            <h3>Nachhaltige Routinen</h3>
            <p>
              Mit kleinen Ritualen etablierst Du langfristige Gewohnheiten – ganz ohne strenge Regeln.
            </p>
          </article>
          <article className={styles.benefitCard}>
            <h3>Gemeinschaft & Austausch</h3>
            <p>
              Unsere Community unterstützt Dich mit Ideen, Erfahrungswerten und freundlicher Motivation.
            </p>
          </article>
        </div>
      </section>

      <section className={`container ${styles.topics}`}>
        <header className={styles.sectionHeader}>
          <h2>Themen, die Dir helfen, den Überblick zu behalten</h2>
        </header>
        <div className={styles.topicGrid}>
          <article>
            <h3>Bildschirmzeit bewusst planen</h3>
            <p>Verabschiede Dich von zufälligem Scrollen und gewinne Deine Abende zurück.</p>
          </article>
          <article>
            <h3>Social Media entstressen</h3>
            <p>Kuratiere Feeds, die Dich inspirieren – ganz ohne FOMO.</p>
          </article>
          <article>
            <h3>News smarter konsumieren</h3>
            <p>Wähle zuverlässige Quellen und lies zum richtigen Zeitpunkt.</p>
          </article>
          <article>
            <h3>Notifications bändigen</h3>
            <p>Gestalte Dein Smartphone so, dass es Dich unterstützt statt unterbricht.</p>
          </article>
        </div>
      </section>

      <section className={styles.why}>
        <div className="container">
          <div className={styles.whyContent}>
            <div>
              <h2>Warum Alveriona?</h2>
              <p>
                Wir verbinden aktuelle Erkenntnisse zu digitaler Belastung mit pragmatischen
                Lösungen. Kein Dogma, keine Verbote, sondern ein empathischer Umgang mit dem
                digitalen Alltag.
              </p>
            </div>
            <ul>
              <li>
                <strong>Human-first:</strong> Du bist wichtiger als jedes Tool. Wir starten immer bei Deinen Bedürfnissen.
              </li>
              <li>
                <strong>Flexibel:</strong> Passe alles an Deinen Rhythmus an – beruflich, privat oder im Team.
              </li>
              <li>
                <strong>Ganzheitlich:</strong> Fokus, Pausen, Austausch und Grenzen gehören zusammen.
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className={`container ${styles.process}`}>
        <header className={styles.sectionHeader}>
          <h2>So begleiten wir Dich Schritt für Schritt</h2>
          <p>Die Alveriona-Methode verbindet Check-ins, Ordnung, Regeln und Routinen.</p>
        </header>
        <div className={styles.processGrid}>
          <article>
            <span>01</span>
            <h3>Status-Check</h3>
            <p>Wir reflektieren gemeinsam, wo Infos, Apps oder Geräte Dich stressen.</p>
          </article>
          <article>
            <span>02</span>
            <h3>Aufräumen</h3>
            <p>Du sortierst Kanäle, räumst digitale Plätze auf und schaffst Übersicht.</p>
          </article>
          <article>
            <span>03</span>
            <h3>Regeln</h3>
            <p>Wir definieren klare Leitplanken für Benachrichtigungen, Nachrichten und Screenzeiten.</p>
          </article>
          <article>
            <span>04</span>
            <h3>Routinen</h3>
            <p>Mit kleinen, wiederkehrenden Handlungen verfestigst Du Deine neue Balance.</p>
          </article>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.testimonialHeader}>
            <h2>„Ich bin wieder Herrin meiner Aufmerksamkeit.“</h2>
            <p>O-Töne aus unserer Community, die zeigen, dass kleine Schritte Wirkung entfalten.</p>
          </div>
          <div className={styles.testimonialCarousel} role="region" aria-live="polite">
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.testimonialActive : ''
                }`}
              >
                <p>{testimonial.quote}</p>
                <span>{testimonial.name}</span>
              </article>
            ))}
            <div className={styles.carouselControls}>
              <button
                type="button"
                aria-label="Vorheriges Testimonial"
                onClick={() =>
                  setActiveTestimonial((prev) =>
                    prev === 0 ? testimonials.length - 1 : prev - 1
                  )
                }
              >
                ←
              </button>
              <button
                type="button"
                aria-label="Nächstes Testimonial"
                onClick={() =>
                  setActiveTestimonial((prev) => (prev + 1) % testimonials.length)
                }
              >
                →
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className={`container ${styles.team}`}>
        <header className={styles.sectionHeader}>
          <h2>Lerne das Team kennen</h2>
          <p>Wir kombinieren Coaching, Habit Design und Community-Building.</p>
        </header>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
              <div className={styles.teamContent}>
                <h3>{member.name}</h3>
                <p className={styles.teamRole}>{member.role}</p>
                <p>{member.focus}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`container ${styles.projects}`}>
        <header className={styles.sectionHeader}>
          <h2>Projekte & Formate – passgenau für Dich</h2>
          <div className={styles.projectFilters} role="tablist">
            {['Alle', 'Challenges', 'Workshops', 'Tools'].map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.projectFilterButton} ${
                  filteredCategory === category ? styles.projectFilterActive : ''
                }`}
                onClick={() => setFilteredCategory(category)}
                role="tab"
                aria-selected={filteredCategory === category}
              >
                {category}
              </button>
            ))}
          </div>
        </header>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <div className={styles.projectImage}>
                <img src={project.image} alt={`Projekt ${project.title}`} loading="lazy" />
              </div>
              <div className={styles.projectInfo}>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`container ${styles.faq}`}>
        <header className={styles.sectionHeader}>
          <h2>FAQ – häufige Fragen</h2>
          <p>Alles, was Du vor Deinem Start wissen möchtest.</p>
        </header>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <details key={item.question} className={styles.faqItem}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={`container ${styles.blogPreview}`}>
        <header className={styles.sectionHeader}>
          <h2>Blog: frische Impulse für Deine digitale Hygiene</h2>
          <p>Kurze Lesehäppchen für mehr Klarheit, Fokus und innere Balance.</p>
        </header>
        <div className={styles.blogGrid}>
          {blogPosts.slice(0, 3).map((post) => (
            <article key={post.slug} className={styles.blogCard}>
              <div className={styles.blogImage}>
                <img src={post.coverImage} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.blogContent}>
                <span>{post.category} · {post.readingTime}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={`/blog/${post.slug}`} className={styles.blogLink}>
                  Weiterlesen
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Bist Du bereit für mehr digitale Ruhe?</h2>
            <p>
              Starte heute mit Deinem persönlichen Leitfaden oder teste eines unserer Programme.
              Alveriona passt sich Deinem Alltag an – nicht umgekehrt.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/leitfaden" className="buttonPrimary">
                Leitfaden anschauen
              </Link>
              <Link to="/kontakt" className="buttonSecondary">
                Persönlichen Austausch wählen
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Home;