import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './AGB.module.css';

function AGB() {
  return (
    <>
      <Helmet>
        <title>AGB | Alveriona</title>
        <meta
          name="description"
          content="Allgemeine Geschäftsbedingungen von Alveriona. Transparente Regeln für die Zusammenarbeit."
        />
      </Helmet>
      <section className={`container ${styles.wrapper}`}>
        <h1>Allgemeine Geschäftsbedingungen (AGB)</h1>

        <section>
          <h2>1. Geltungsbereich</h2>
          <p>
            Diese AGB gelten für alle Leistungen, Programme und digitalen Inhalte, die Alveriona
            Digital Balance anbietet. Abweichende Bedingungen werden nur anerkannt, wenn wir ihnen
            schriftlich zustimmen.
          </p>
        </section>

        <section>
          <h2>2. Leistungen</h2>
          <p>
            Alveriona unterstützt Dich mit Programmen, Workshops und Tools rund um digitale Hygiene
            und Informationsbalance. Es handelt sich um präventive Angebote ohne medizinische oder
            therapeutische Wirkung.
          </p>
        </section>

        <section>
          <h2>3. Vertragsschluss</h2>
          <p>
            Ein Vertrag kommt zustande, wenn wir Deine Anfrage schriftlich bestätigen oder Du eine
            Buchung in unserem System tätigst. Du erhältst anschließend eine Bestätigung per E-Mail.
          </p>
        </section>

        <section>
          <h2>4. Teilnahmevoraussetzungen</h2>
          <p>
            Unsere Angebote richten sich an volljährige Personen. Minderjährige benötigen die
            Zustimmung ihrer gesetzlichen Vertretung.
          </p>
        </section>

        <section>
          <h2>5. Haftung</h2>
          <p>
            Wir haften für Vorsatz und grobe Fahrlässigkeit. Für leichte Fahrlässigkeit haften wir
            nur bei Verletzung wesentlicher Vertragspflichten. Die Haftung für Schäden aus der
            Verletzung des Lebens, des Körpers oder der Gesundheit bleibt unberührt.
          </p>
        </section>

        <section>
          <h2>6. Datenschutz</h2>
          <p>
            Der Schutz Deiner Daten ist uns wichtig. Details findest Du in unserer
            Datenschutzerklärung.
          </p>
        </section>

        <section>
          <h2>7. Schlussbestimmungen</h2>
          <p>
            Es gilt deutsches Recht. Sollten einzelne Bestimmungen unwirksam sein, bleibt die
            Wirksamkeit der übrigen Regelungen unberührt.
          </p>
        </section>
      </section>
    </>
  );
}

export default AGB;