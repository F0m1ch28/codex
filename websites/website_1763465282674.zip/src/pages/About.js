import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

function About() {
  return (
    <>
      <Helmet>
        <title>Über uns | Alveriona</title>
        <meta
          name="description"
          content="Alveriona verbindet digitale Hygiene mit empathischen Lösungen. Erfahre mehr über Mission, Werte und Team."
        />
      </Helmet>
      <section className={`container ${styles.wrapper}`}>
        <header className={styles.header}>
          <h1>Wir glauben an digitale Ruhe für alle</h1>
          <p>
            Alveriona wurde gegründet, weil Informationsflut längst zum Alltag gehört – und trotzdem
            zu wenig Unterstützung existiert. Wir helfen Dir, digitale Räume bewusst zu gestalten,
            ohne Dich zu überfordern.
          </p>
        </header>

        <section className={styles.mission}>
          <article>
            <h2>Mission</h2>
            <p>
              Wir stärken Menschen und Teams darin, digitale Hygiene zur Selbstverständlichkeit zu
              machen. Unser Fokus liegt auf realistischen, empathischen Lösungen – nicht auf
              Verzicht.
            </p>
          </article>
          <article>
            <h2>Werte</h2>
            <ul>
              <li>
                <strong>Empathie:</strong> Wir hören zu, bevor wir Empfehlungen geben.
              </li>
              <li>
                <strong>Alltagstauglichkeit:</strong> Jeder Tipp ist im echten Leben erprobt.
              </li>
              <li>
                <strong>Datenschutz:</strong> Deine Daten bleiben bei Dir. Punkt.
              </li>
            </ul>
          </article>
        </section>

        <section className={styles.approach}>
          <h2>Unser Ansatz</h2>
          <div className={styles.cards}>
            <article>
              <h3>Wissenschaft & Erfahrung</h3>
              <p>
                Wir kombinieren Erkenntnisse aus Psychologie, Habit Design und Digital Wellbeing mit
                jahrelanger Beratungspraxis.
              </p>
            </article>
            <article>
              <h3>Keine medizinischen Versprechen</h3>
              <p>
                Alveriona bietet keine medizinische Beratung. Wir arbeiten präventiv,
                ressourcenorientiert und verweisen bei Bedarf an Fachstellen.
              </p>
            </article>
            <article>
              <h3>Datenschutz & Seriosität</h3>
              <p>
                Transparente Prozesse, DSGVO-konforme Systeme und klare Verantwortlichkeiten sind
                für uns selbstverständlich.
              </p>
            </article>
          </div>
        </section>

        <section className={styles.team}>
          <h2>Team</h2>
          <div className={styles.teamGrid}>
            <article>
              <img src="https://picsum.photos/400/400?random=41" alt="Klara Weiss Portrait" />
              <h3>Klara Weiss</h3>
              <p>Gründerin & Digital Balance Coach</p>
            </article>
            <article>
              <img src="https://picsum.photos/400/400?random=42" alt="Jonas Berg Portrait" />
              <h3>Jonas Berg</h3>
              <p>Habit Designer & Programm-Lead</p>
            </article>
            <article>
              <img src="https://picsum.photos/400/400?random=43" alt="Mira Scholz Portrait" />
              <h3>Mira Scholz</h3>
              <p>Community & Partnerschaften</p>
            </article>
          </div>
        </section>
      </section>
    </>
  );
}

export default About;