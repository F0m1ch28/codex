import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programme.module.css';

const programmes = [
  {
    title: '7-Tage-Info-Detox',
    description:
      'Sieben Tage mit kompakten Impulsen, die Deine Informationsströme entschleunigen und neu sortieren.',
    duration: '7 Tage',
    audience: 'Für Einsteiger:innen, die einen Reset wünschen'
  },
  {
    title: 'Benachrichtigungs-Reset',
    description:
      'Gemeinsam checken wir Benachrichtigungen, Sounds und Prioritäten. Du behältst Kontrolle, ganz ohne radikale Schritte.',
    duration: '5 Module',
    audience: 'Für Berufstätige & Teams'
  },
  {
    title: 'Digitaler Abendmodus',
    description:
      'Ein Abendritual, das Dir hilft, gut abzuschalten. Mit Audio-Guides, Reflexionsfragen und sanften Routinen.',
    duration: '10 Abende',
    audience: 'Für alle, die besser schlafen möchten'
  },
  {
    title: 'Fokus-Sprints',
    description:
      'Wir strukturieren Deine Woche in Fokus-Sprints mit klaren Pausenfenstern und Check-ins.',
    duration: '4 Wochen',
    audience: 'Für Menschen mit vielen parallelen Projekten'
  }
];

function Programme() {
  return (
    <>
      <Helmet>
        <title>Programme für digitale Hygiene | Alveriona</title>
        <meta
          name="description"
          content="Wähle aus Programmen wie Info-Detox oder Benachrichtigungs-Reset. Starte in Dein individuelles digitales Gleichgewicht."
        />
      </Helmet>
      <section className={`container ${styles.wrapper}`}>
        <header className={styles.header}>
          <h1>Programme, die zu Deinem Alltag passen</h1>
          <p>
            Egal ob Du allein starten möchtest oder Dein Team mitnimmst – die Alveriona-Programme
            haben klare Ziele, flexible Umsetzung und viel Raum für Dich.
          </p>
        </header>
        <div className={styles.grid}>
          {programmes.map((programme) => (
            <article key={programme.title} className={styles.card}>
              <div className={styles.cardHeader}>
                <h2>{programme.title}</h2>
                <span>{programme.duration}</span>
              </div>
              <p>{programme.description}</p>
              <div className={styles.meta}>
                <strong>Zielgruppe:</strong>
                <span>{programme.audience}</span>
              </div>
              <button type="button" className={styles.button}>
                Programm starten
              </button>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

export default Programme;