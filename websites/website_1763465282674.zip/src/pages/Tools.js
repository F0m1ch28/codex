import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const tools = [
  {
    title: 'Notifications-Checkliste',
    description:
      'Prüfe Schritt für Schritt, welche Benachrichtigungen Dir wirklich helfen – mit klaren Fragen und Prioritäten.',
    features: ['Prioritätensystem', 'Team- & Privat-Perspektive', 'Sofort anwendbar'],
    linkLabel: 'Checkliste herunterladen'
  },
  {
    title: 'Wochenplan für bildschirmarme Zeiten',
    description:
      'Plane bewusste Offscreen-Momente und Rituale. Hilft Dir, Pausen sichtbar zu machen.',
    features: ['Visuelles Canvas', 'Platz für Ideen', 'Gemeinsam nutzbar'],
    linkLabel: 'Plan entdecken'
  },
  {
    title: 'Fokus-Fenster Timer',
    description:
      'Ein sanfter Timer, der Dich durch Fokus- und Pausenphasen begleitet – flexibel anpassbar.',
    features: ['Flexibel einstellbar', 'Audio- & Text-Prompts', 'Reflexionsfragen'],
    linkLabel: 'Timer ausprobieren'
  },
  {
    title: 'Digitale Detox Box',
    description:
      'Eine Sammlung kleiner Challenges für Momente, in denen Du Dein Gerät bewusst beiseite legen möchtest.',
    features: ['10 Impulse', 'Gemeinsam spielbar', 'Motivierendes Design'],
    linkLabel: 'Box öffnen'
  }
];

function Tools() {
  return (
    <>
      <Helmet>
        <title>Tools & Checklisten | Alveriona</title>
        <meta
          name="description"
          content="Kostenlose Tools und Checklisten für Notifications, Bildschirmzeiten und Fokus-Routinen."
        />
      </Helmet>
      <section className={`container ${styles.wrapper}`}>
        <header className={styles.header}>
          <h1>Tools für Deine digitale Hygiene</h1>
          <p>
            Nutze herunterladbare Checklisten, Pläne und Timer, um Deinen Alltag Schritt für Schritt
            digital leichter zu machen.
          </p>
        </header>
        <div className={styles.grid}>
          {tools.map((tool) => (
            <article key={tool.title} className={styles.card}>
              <div>
                <h2>{tool.title}</h2>
                <p>{tool.description}</p>
              </div>
              <ul>
                {tool.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
              <button type="button">{tool.linkLabel}</button>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

export default Tools;