import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Datenschutz.module.css';

function Datenschutz() {
  return (
    <>
      <Helmet>
        <title>Datenschutz | Alveriona</title>
        <meta
          name="description"
          content="Datenschutzerklärung von Alveriona gemäß DSGVO. Transparente Informationen über Datenerhebung und -verarbeitung."
        />
      </Helmet>
      <section className={`container ${styles.wrapper}`}>
        <h1>Datenschutzerklärung</h1>

        <section>
          <h2>1. Verantwortliche Stelle</h2>
          <p>
            Verantwortlich für die Datenverarbeitung auf dieser Website ist:<br />
            Alveriona Digital Balance<br />
            Musterstraße 12, 10115 Berlin<br />
            E-Mail: [vom Kunden zu ergänzen]
          </p>
        </section>

        <section>
          <h2>2. Erhebung und Speicherung personenbezogener Daten</h2>
          <p>
            Wir verarbeiten personenbezogene Daten, die Du uns freiwillig mitteilst (z. B.
            Kontaktformular). Darüber hinaus werden beim Besuch der Website automatisch technische
            Daten erhoben (z. B. IP-Adresse, Browsertyp, Besuchszeit). Diese Daten dienen der
            Sicherstellung eines technisch stabilen Betriebs.
          </p>
        </section>

        <section>
          <h2>3. Zwecke der Verarbeitung</h2>
          <ul>
            <li>Beantwortung Deiner Anfragen</li>
            <li>Bereitstellung der Website und Verbesserung der Nutzererfahrung</li>
            <li>Erfüllung gesetzlicher Verpflichtungen</li>
          </ul>
        </section>

        <section>
          <h2>4. Rechtsgrundlagen</h2>
          <p>
            Die Verarbeitung erfolgt gemäß Art. 6 Abs. 1 lit. b DSGVO (Vertragserfüllung) und
            Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse an einer sicheren Website). Bei
            Einwilligungen stützen wir uns auf Art. 6 Abs. 1 lit. a DSGVO.
          </p>
        </section>

        <section>
          <h2>5. Cookies</h2>
          <p>
            Wir verwenden essenzielle Cookies, um diese Website zuverlässig bereitzustellen. Optional
            kannst Du statistische Cookies erlauben. Deine Einstellungen kannst Du jederzeit im
            Cookie-Banner ändern.
          </p>
        </section>

        <section>
          <h2>6. Speicherdauer</h2>
          <p>
            Wir speichern personenbezogene Daten nur so lange, wie es für die jeweiligen Zwecke
            erforderlich ist oder gesetzliche Aufbewahrungspflichten bestehen.
          </p>
        </section>

        <section>
          <h2>7. Weitergabe an Dritte</h2>
          <p>
            Eine Weitergabe an Dritte erfolgt nur, wenn dies gesetzlich erlaubt ist oder Du zuvor
            eingewilligt hast. Wir nutzen ausschließlich DSGVO-konforme Dienstleister.
          </p>
        </section>

        <section>
          <h2>8. Deine Rechte</h2>
          <p>
            Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung
            sowie Datenübertragbarkeit. Außerdem kannst Du Einwilligungen jederzeit widerrufen und
            Dich bei einer Aufsichtsbehörde beschweren.
          </p>
        </section>

        <section>
          <h2>9. Sicherheit</h2>
          <p>
            Wir setzen technische und organisatorische Sicherheitsmaßnahmen ein, um Deine Daten vor
            Verlust, Manipulation oder unberechtigtem Zugriff zu schützen.
          </p>
        </section>

        <section>
          <h2>10. Aktualität</h2>
          <p>
            Diese Datenschutzerklärung hat den Stand Januar 2024. Wir passen sie bei Bedarf an
            gesetzliche Änderungen an.
          </p>
        </section>
      </section>
    </>
  );
}

export default Datenschutz;