import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialState = { name: '', email: '', message: '' };

function Contact() {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Bitte gib Deinen Namen ein.';
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte gib Deine E-Mail-Adresse ein.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Bitte gib eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.message.trim()) newErrors.message = 'Bitte formuliere Deine Nachricht.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setFormData(initialState);
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Alveriona</title>
        <meta
          name="description"
          content="Nimm Kontakt mit Alveriona auf. Wir freuen uns auf Deine Nachricht rund um digitale Hygiene und Fokus."
        />
      </Helmet>
      <section className={`container ${styles.wrapper}`}>
        <header className={styles.header}>
          <h1>Lass uns sprechen</h1>
          <p>
            Egal ob Du Fragen zu Programmen hast, Unterstützung für Dein Team suchst oder Feedback
            geben möchtest – wir antworten Dir innerhalb von zwei Werktagen.
          </p>
        </header>

        <div className={styles.grid}>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Name</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={(event) =>
                  setFormData((prev) => ({ ...prev, name: event.target.value }))
                }
                aria-invalid={!!errors.name}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && (
                <span id="name-error" className={styles.error}>
                  {errors.name}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="email">E-Mail</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={(event) =>
                  setFormData((prev) => ({ ...prev, email: event.target.value }))
                }
                aria-invalid={!!errors.email}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && (
                <span id="email-error" className={styles.error}>
                  {errors.email}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="message">Nachricht</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={(event) =>
                  setFormData((prev) => ({ ...prev, message: event.target.value }))
                }
                aria-invalid={!!errors.message}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && (
                <span id="message-error" className={styles.error}>
                  {errors.message}
                </span>
              )}
            </div>

            <button type="submit">Nachricht senden</button>
            {submitted && (
              <div className={styles.success} role="status" aria-live="polite">
                Danke für Deine Nachricht! Wir melden uns so schnell wie möglich.
              </div>
            )}
          </form>

          <aside className={styles.info}>
            <h2>Kontaktdaten</h2>
            <ul>
              <li>
                <strong>Adresse:</strong> Musterstraße 12, 10115 Berlin
              </li>
              <li>
                <strong>E-Mail:</strong> [vom Kunden zu ergänzen]
              </li>
              <li>
                <strong>Telefon:</strong> optional
              </li>
            </ul>
            <h3>Wann lohnt sich eine Nachricht?</h3>
            <p>
              Immer dann, wenn Du Unterstützung bei Fokus, Informationsflut oder digitalen Routinen
              brauchst. Wir freuen uns auf Deine Perspektive.
            </p>
          </aside>
        </div>
      </section>
    </>
  );
}

export default Contact;