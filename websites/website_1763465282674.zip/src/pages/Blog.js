import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Blog.module.css';
import { blogPosts } from '../data/blogPosts';

function Blog() {
  const [category, setCategory] = useState('Alle');
  const categories = useMemo(
    () => ['Alle', ...new Set(blogPosts.map((post) => post.category))],
    []
  );

  const filteredPosts =
    category === 'Alle' ? blogPosts : blogPosts.filter((post) => post.category === category);

  return (
    <>
      <Helmet>
        <title>Blog | Alveriona</title>
        <meta
          name="description"
          content="Impulse und Inspiration rund um digitale Hygiene, Fokus und Informationsbalance im Alveriona Blog."
        />
      </Helmet>
      <section className={`container ${styles.wrapper}`}>
        <header className={styles.header}>
          <h1>Blog: Frische Impulse für Deinen Alltag</h1>
          <p>
            Kurze Lesehäppchen, Reflexionen aus der Community und praxisnahe Tipps, damit digitale
            Achtsamkeit leicht fällt.
          </p>
        </header>
        <div className={styles.filters}>
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              className={`${styles.filterButton} ${category === cat ? styles.active : ''}`}
              onClick={() => setCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className={styles.grid}>
          {filteredPosts.map((post) => (
            <article key={post.slug} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={post.coverImage} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.content}>
                <span>{post.category} · {post.readingTime}</span>
                <h2>{post.title}</h2>
                <p>{post.excerpt}</p>
                <Link to={`/blog/${post.slug}`} className={styles.link}>
                  Weiterlesen
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

export default Blog;