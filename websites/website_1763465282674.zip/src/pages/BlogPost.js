import React from 'react';
import { Helmet } from 'react-helmet';
import { Link, useParams } from 'react-router-dom';
import styles from './BlogPost.module.css';
import { blogPosts } from '../data/blogPosts';

function BlogPost() {
  const { slug } = useParams();
  const post = blogPosts.find((entry) => entry.slug === slug);

  if (!post) {
    return (
      <section className={`container ${styles.notFound}`}>
        <Helmet>
          <title>Beitrag nicht gefunden | Alveriona</title>
          <meta name="robots" content="noindex" />
        </Helmet>
        <h1>Ups, dieser Beitrag wurde nicht gefunden.</h1>
        <p>Vielleicht wurde er verschoben. Schau Dich gern im Blog um.</p>
        <Link to="/blog" className="buttonPrimary">
          Zurück zum Blog
        </Link>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} | Alveriona</title>
        <meta name="description" content={post.excerpt} />
      </Helmet>
      <article className={styles.article}>
        <div className={styles.hero}>
          <img src={post.coverImage} alt={post.title} />
          <div className={styles.meta}>
            <span>{post.category}</span>
            <span>{post.readingTime}</span>
            <span>{post.publishedAt}</span>
          </div>
        </div>
        <div className={`container ${styles.body}`}>
          <header className={styles.header}>
            <h1>{post.title}</h1>
            <p>{post.excerpt}</p>
          </header>
          {post.content.map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
          <div className={styles.backLink}>
            <Link to="/blog" className="buttonSecondary">
              Zurück zur Übersicht
            </Link>
          </div>
        </div>
      </article>
    </>
  );
}

export default BlogPost;