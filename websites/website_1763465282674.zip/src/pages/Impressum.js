import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Impressum.module.css';

function Impressum() {
  return (
    <>
      <Helmet>
        <title>Impressum | Alveriona</title>
        <meta name="robots" content="index,follow" />
      </Helmet>
      <section className={`container ${styles.wrapper}`}>
        <h1>Impressum</h1>
        <section>
          <h2>Angaben gemäß § 5 TMG</h2>
          <p>Alveriona Digital Balance (Einzelunternehmen)</p>
          <p>Musterstraße 12<br />10115 Berlin<br />Deutschland</p>
        </section>
        <section>
          <h2>Kontakt</h2>
          <p>E-Mail: [vom Kunden zu ergänzen]</p>
          <p>Telefon: optional</p>
        </section>
        <section>
          <h2>Vertretungsberechtigt</h2>
          <p>Klara Weiss</p>
        </section>
        <section>
          <h2>Umsatzsteuer-ID</h2>
          <p>USt-IdNr.: wird ergänzt</p>
        </section>
        <section>
          <h2>Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV</h2>
          <p>Klara Weiss<br />Musterstraße 12<br />10115 Berlin</p>
        </section>
        <section>
          <h2>Haftung für Inhalte</h2>
          <p>
            Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten
            nach den allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis 10 TMG sind wir als
            Diensteanbieter jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde
            Informationen zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige
            Tätigkeit hinweisen.
          </p>
        </section>
        <section>
          <h2>Haftung für Links</h2>
          <p>
            Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen
            Einfluss haben. Deshalb können wir für diese fremden Inhalte auch keine Gewähr
            übernehmen.
          </p>
        </section>
        <section>
          <h2>Urheberrecht</h2>
          <p>
            Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen
            dem deutschen Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art
            der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen
            Zustimmung.
          </p>
        </section>
      </section>
    </>
  );
}

export default Impressum;