import React, { useState, useEffect } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem("elevatex-cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem("elevatex-cookie-consent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner">
      <div className="cookie-inner">
        <p>
          We use cookies to personalize content, analyze performance, and
          improve your experience. By using our site, you agree to our cookie
          policy.
        </p>
        <button onClick={handleAccept} className="btn-primary">
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;