import React from "react";
import { NavLink } from "react-router-dom";

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div>
          <div className="footer-logo">ElevateX</div>
          <p className="footer-desc">
            ElevateX partners with ambitious brands to deliver transformative
            digital experiences that unlock new opportunities and accelerate
            growth.
          </p>
          <div className="footer-social">
            <a href="https://linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer">
              Twitter
            </a>
            <a href="https://dribbble.com" target="_blank" rel="noreferrer">
              Dribbble
            </a>
          </div>
        </div>
        <div>
          <h4>Company</h4>
          <ul>
            <li>
              <NavLink to="/about">About</NavLink>
            </li>
            <li>
              <NavLink to="/services">Services</NavLink>
            </li>
            <li>
              <NavLink to="/contact">Contact</NavLink>
            </li>
          </ul>
        </div>
        <div>
          <h4>Resources</h4>
          <ul>
            <li>
              <a href="#blog">Insights</a>
            </li>
            <li>
              <a href="#faq">Support</a>
            </li>
            <li>
              <a href="#process">Process</a>
            </li>
          </ul>
        </div>
        <div>
          <h4>Legal</h4>
          <ul>
            <li>
              <NavLink to="/terms">Terms &amp; Conditions</NavLink>
            </li>
            <li>
              <NavLink to="/privacy">Privacy Policy</NavLink>
            </li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {year} ElevateX Digital. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;