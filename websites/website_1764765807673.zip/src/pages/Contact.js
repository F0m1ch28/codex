import React, { useState } from "react";

const Contact = () => {
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formState.name.trim()) newErrors.name = "Name is required.";
    if (!formState.email.trim()) {
      newErrors.email = "Email is required.";
    } else if (!/\S+@\S+\.\S+/.test(formState.email)) {
      newErrors.email = "Please enter a valid email.";
    }
    if (!formState.message.trim())
      newErrors.message = "Please share a brief project overview.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setFormState((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
    setErrors((prev) => ({ ...prev, [e.target.name]: "" }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setTimeout(() => {
      setFormState({
        name: "",
        email: "",
        company: "",
        message: "",
      });
      setSubmitted(false);
    }, 2000);
  };

  return (
    <div className="page contact-page">
      <section className="page-hero">
        <div className="container narrow">
          <p className="eyebrow">Contact</p>
          <h1>Let’s shape the future of your digital ecosystem</h1>
          <p>
            Tell us about your goals and we’ll connect you with the right team
            of strategists, designers, and engineers to bring them to life.
          </p>
        </div>
      </section>

      <section className="contact-section">
        <div className="container contact-grid">
          <div className="contact-info">
            <h2>Partner with ElevateX</h2>
            <p>
              Our engagements typically begin within 2-3 weeks. We’ll start with
              a discovery session to understand your needs, share best practices,
              and outline a tailored plan of action.
            </p>
            <ul className="contact-list">
              <li>
                <strong>Email:</strong> hello@elevatex.com
              </li>
              <li>
                <strong>Headquarters:</strong> 845 Market Street, Suite 300, San
                Francisco, CA
              </li>
              <li>
                <strong>Phone:</strong> +1 (415) 555-2048
              </li>
            </ul>
          </div>
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-field">
              <label htmlFor="name">Full Name*</label>
              <input
                type="text"
                name="name"
                id="name"
                value={formState.name}
                onChange={handleChange}
                placeholder="Your name"
              />
              {errors.name && <span className="error">{errors.name}</span>}
            </div>
            <div className="form-field">
              <label htmlFor="email">Work Email*</label>
              <input
                type="email"
                name="email"
                id="email"
                value={formState.email}
                onChange={handleChange}
                placeholder="name@company.com"
              />
              {errors.email && <span className="error">{errors.email}</span>}
            </div>
            <div className="form-field">
              <label htmlFor="company">Company</label>
              <input
                type="text"
                name="company"
                id="company"
                value={formState.company}
                onChange={handleChange}
                placeholder="Company name"
              />
            </div>
            <div className="form-field">
              <label htmlFor="message">Project Overview*</label>
              <textarea
                name="message"
                id="message"
                rows="5"
                value={formState.message}
                onChange={handleChange}
                placeholder="Tell us about timelines, goals, and success metrics."
              />
              {errors.message && (
                <span className="error">{errors.message}</span>
              )}
            </div>
            <button className="btn-primary" type="submit" disabled={submitted}>
              {submitted ? "Sending..." : "Submit Inquiry"}
            </button>
            <p className="form-footnote">
              By submitting this form, you agree to our{" "}
              <a href="/privacy">privacy policy</a>.
            </p>
          </form>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-wrapper">
          <div className="cta-content">
            <p className="eyebrow light">Work With Us</p>
            <h2>We’ll respond within two business days</h2>
            <p>
              Looking for a partner that moves fast, thinks deeply, and delivers
              impact? Let’s craft your next milestone together.
            </p>
          </div>
          <div className="cta-actions">
            <a href="mailto:hello@elevatex.com" className="btn-light">
              Email Our Team
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;