import React, { useState, useEffect, useMemo } from "react";

const statsData = [
  { label: "Projects Delivered", value: 240 },
  { label: "Growth Partners", value: 120 },
  { label: "Awards Won", value: 18 },
  { label: "Client Satisfaction", value: 98, suffix: "%" },
];

const servicesData = [
  {
    title: "Digital Strategy",
    description:
      "Comprehensive growth roadmaps that align your organization for measurable success.",
    icon: "🎯",
  },
  {
    title: "Experience Design",
    description:
      "Immersive experiences that seamlessly connect your brand with your customers.",
    icon: "✨",
  },
  {
    title: "Product Engineering",
    description:
      "Robust web and mobile applications built for scalability, performance, and security.",
    icon: "⚙️",
  },
];

const processSteps = [
  {
    step: "01",
    title: "Discover & Align",
    text: "We begin by understanding your business model, customers, and growth targets.",
  },
  {
    step: "02",
    title: "Design & Prototype",
    text: "Our design teams craft interactive journeys that bring your product vision to life.",
  },
  {
    step: "03",
    title: "Build & Iterate",
    text: "Engineers deliver clean, reliable code with agile sprints and transparent progress.",
  },
  {
    step: "04",
    title: "Launch & Scale",
    text: "We deploy, monitor, and optimize continuously to drive sustained market impact.",
  },
];

const testimonials = [
  {
    name: "Alex Morgan",
    role: "VP Product, Horizon Labs",
    quote:
      "ElevateX transformed our entire digital ecosystem. Their expertise and attention to detail accelerated our roadmap by months.",
  },
  {
    name: "Priya Kapoor",
    role: "CEO, Nimbus Ventures",
    quote:
      "From strategy to launch, the team delivered exceptional outcomes. Our user satisfaction scores have never been higher.",
  },
  {
    name: "David Chen",
    role: "CTO, Crestline Analytics",
    quote:
      "Their engineering rigor and design excellence created a platform that scaled effortlessly during our IPO.",
  },
];

const teamMembers = [
  {
    name: "Samantha Lee",
    role: "Chief Experience Officer",
    image: "https://picsum.photos/400/400?random=31",
  },
  {
    name: "Jordan Rivera",
    role: "Head of Product Engineering",
    image: "https://picsum.photos/400/400?random=32",
  },
  {
    name: "Emilia Novak",
    role: "Director of Strategy",
    image: "https://picsum.photos/400/400?random=33",
  },
];

const projectData = [
  {
    id: 1,
    title: "Atlas Commerce Platform",
    category: "Product",
    image: "https://picsum.photos/1200/800?random=41",
  },
  {
    id: 2,
    title: "Nova Banking Experience",
    category: "Experience",
    image: "https://picsum.photos/1200/800?random=42",
  },
  {
    id: 3,
    title: "Lumen Healthcare Portal",
    category: "Transformation",
    image: "https://picsum.photos/1200/800?random=43",
  },
  {
    id: 4,
    title: "Flux Mobility App",
    category: "Product",
    image: "https://picsum.photos/1200/800?random=44",
  },
];

const faqData = [
  {
    question: "What industries do you specialize in?",
    answer:
      "We work with high-growth companies across finance, technology, healthcare, and consumer industries, adapting our playbooks for each unique market.",
  },
  {
    question: "How quickly can we launch a project?",
    answer:
      "Discovery typically takes two weeks. We then define a collaborative roadmap with rapid sprint cycles to deliver tangible results within the first 30 days.",
  },
  {
    question: "Do you support post-launch optimization?",
    answer:
      "Yes. We partner long-term with our clients to analyze performance, run experiments, and continually optimize for scaling growth.",
  },
  {
    question: "What is your engagement model?",
    answer:
      "We offer flexible engagement models including dedicated teams, project-based initiatives, and consultative retainers tailored to your objectives.",
  },
];

const blogPosts = [
  {
    title: "Designing Product Ecosystems for Sustainable Growth",
    image: "https://picsum.photos/800/600?random=52",
    date: "Jan 12, 2024",
    excerpt:
      "Why product ecosystems outperform standalone experiences and how to architect them for long-term success.",
  },
  {
    title: "The Future of AI-Augmented Customer Journeys",
    image: "https://picsum.photos/800/600?random=53",
    date: "Feb 02, 2024",
    excerpt:
      "A playbook for leveraging intelligent automation to elevate every touchpoint of the customer lifecycle.",
  },
  {
    title: "Scaling Engineering Teams with Clarity and Confidence",
    image: "https://picsum.photos/800/600?random=54",
    date: "Mar 18, 2024",
    excerpt:
      "Frameworks and rituals for building high-performing engineering squads ready to solve complex challenges.",
  },
];

const Home = () => {
  const [activeProjectFilter, setActiveProjectFilter] = useState("All");
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeFaq, setActiveFaq] = useState(null);
  const [animatedStats, setAnimatedStats] = useState(
    statsData.map(() => 0)
  );

  const filteredProjects = useMemo(() => {
    if (activeProjectFilter === "All") return projectData;
    return projectData.filter(
      (project) => project.category === activeProjectFilter
    );
  }, [activeProjectFilter]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            statsData.forEach((stat, index) => {
              const increment = Math.ceil(stat.value / 40);
              let current = 0;
              const timer = setInterval(() => {
                current += increment;
                if (current >= stat.value) {
                  current = stat.value;
                  clearInterval(timer);
                }
                setAnimatedStats((prev) => {
                  const clone = [...prev];
                  clone[index] = current;
                  return clone;
                });
              }, 40);
            });
            observer.disconnect();
          }
        });
      },
      {
        threshold: 0.4,
      }
    );
    const el = document.querySelector(".stats-section");
    if (el) observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div className="home-page">
      <section className="hero-section">
        <div className="container hero-grid">
          <div className="hero-content">
            <p className="eyebrow">Award-Winning Digital Consultancy</p>
            <h1>
              We architect transformative experiences that accelerate your next
              chapter of growth.
            </h1>
            <p className="hero-text">
              From market-leading strategies to enterprise-grade products, we
              help ambitious teams launch breakthrough experiences with clarity,
              confidence, and measurable impact.
            </p>
            <div className="hero-actions">
              <a href="/contact" className="btn-primary">
                Schedule a Consultation
              </a>
              <a href="/services" className="btn-outline">
                Explore Services
              </a>
            </div>
            <div className="hero-trust">
              <span>Trusted by leaders at</span>
              <div className="hero-badges">
                <span>Horizon Labs</span>
                <span>Nova</span>
                <span>Crestline</span>
                <span>Atlas</span>
              </div>
            </div>
          </div>
          <div className="hero-image-wrap">
            <img
              src="https://picsum.photos/1600/900?random=11"
              alt="Digital transformation collaboration"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="stats-section">
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <div key={stat.label} className="stat-card">
              <span className="stat-value">
                {animatedStats[index]}
                {stat.suffix || "+"}
              </span>
              <span className="stat-label">{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="services-highlight" id="services">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">Capabilities</p>
            <h2>End-to-end services engineered for momentum</h2>
            <p>
              Our integrated teams span strategy, design, technology, and
              growth, enabling us to turn bold visions into extraordinary
              realities.
            </p>
          </div>
          <div className="service-grid">
            {servicesData.map((service) => (
              <div className="service-card" key={service.title}>
                <div className="service-icon">{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <a href="/services" className="service-link">
                  Learn more →
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="process-section" id="process">
        <div className="container">
          <div className="section-header align-left">
            <p className="eyebrow">Proven Approach</p>
            <h2>Our process delivers clarity, velocity, and measurable value</h2>
            <p>
              A collaborative framework refined across hundreds of engagements.
              We co-create with your teams to de-risk transformation and launch
              with confidence.
            </p>
          </div>
          <div className="process-grid">
            {processSteps.map((step) => (
              <div className="process-card" key={step.step}>
                <span className="process-step">{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonial-section">
        <div className="container testimonial-wrapper">
          <div className="testimonial-content">
            <p className="eyebrow">Client Stories</p>
            <h2>
              “{testimonials[testimonialIndex].quote}”
            </h2>
            <div className="testimonial-meta">
              <span>{testimonials[testimonialIndex].name}</span>
              <span>{testimonials[testimonialIndex].role}</span>
            </div>
          </div>
          <div className="testimonial-controls">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setTestimonialIndex(index)}
                className={
                  index === testimonialIndex ? "dot active" : "dot"
                }
                aria-label={`View testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="team-section">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">Leadership</p>
            <h2>The minds powering transformative outcomes</h2>
            <p>
              Seasoned strategists, designers, and technologists collaborating
              seamlessly to craft the future of digital experiences.
            </p>
          </div>
          <div className="team-grid">
            {teamMembers.map((member) => (
              <div className="team-card" key={member.name}>
                <div className="team-image">
                  <img
                    src={`${member.image}`}
                    alt={`${member.name} - ${member.role}`}
                    loading="lazy"
                  />
                </div>
                <div className="team-info">
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>
                    {member.name.split(" ")[0]} leads high-impact programs that
                    help Fortune 500 and venture-backed teams capture
                    whitespace opportunities.
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="projects-section" id="projects">
        <div className="container">
          <div className="section-header align-left">
            <p className="eyebrow">Selected Work</p>
            <h2>Breakthrough engagements that redefine possibility</h2>
          </div>
          <div className="project-filters">
            {["All", "Product", "Experience", "Transformation"].map(
              (filter) => (
                <button
                  key={filter}
                  className={
                    activeProjectFilter === filter ? "btn-primary" : "btn-outline"
                  }
                  onClick={() => setActiveProjectFilter(filter)}
                >
                  {filter}
                </button>
              )
            )}
          </div>
          <div className="projects-grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.id}>
                <div className="project-image">
                  <img
                    src={project.image}
                    alt={`${project.title} digital project`}
                    loading="lazy"
                  />
                </div>
                <div className="project-meta">
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>
                    We partnered with leading innovators to orchestrate a
                    seamless omnichannel ecosystem and deliver measurable lifts
                    in revenue, engagement, and loyalty.
                  </p>
                  <a href="/contact" className="project-link">
                    Discuss similar initiative →
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq-section" id="faq">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">Questions</p>
            <h2>Frequently asked questions</h2>
          </div>
          <div className="faq-grid">
            {faqData.map((item, index) => (
              <div
                key={item.question}
                className={`faq-item ${
                  activeFaq === index ? "open" : ""
                }`}
              >
                <button
                  className="faq-question"
                  onClick={() =>
                    setActiveFaq((prev) => (prev === index ? null : index))
                  }
                  aria-expanded={activeFaq === index}
                >
                  <span>{item.question}</span>
                  <span className="faq-toggle">{activeFaq === index ? "−" : "+"}</span>
                </button>
                <div className="faq-answer">
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="blog-section" id="blog">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">Insights</p>
            <h2>Latest thinking from the ElevateX team</h2>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.title}>
                <div className="blog-image">
                  <img
                    src={post.image}
                    alt={`${post.title} cover`}
                    loading="lazy"
                  />
                </div>
                <div className="blog-meta">
                  <span>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <a href="/contact" className="blog-link">
                    Request full report →
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-wrapper">
          <div className="cta-content">
            <p className="eyebrow light">Next Steps</p>
            <h2>Ready to build the next pinnacle experience?</h2>
            <p>
              Let’s co-create the digital products, platforms, and programs that
              move your business ahead of the curve. Our strategists will tailor
              a launch plan within 48 hours.
            </p>
          </div>
          <div className="cta-actions">
            <a href="/contact" className="btn-light">
              Book Strategy Session
            </a>
            <a href="/services" className="btn-outline-light">
              View Capabilities
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;