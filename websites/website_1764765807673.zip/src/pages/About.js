import React from "react";

const cultureHighlights = [
  {
    title: "Human-centered innovation",
    description:
      "We design around people—customers, employees, and communities—to craft experiences that resonate and endure.",
  },
  {
    title: "Radical collaboration",
    description:
      "Cross-functional squads align vision and execution, empowering every stakeholder to contribute their best work.",
  },
  {
    title: "Outcome obsession",
    description:
      "We hold ourselves accountable to measurable business impact, not just deliverables or vanity metrics.",
  },
];

const leadershipTeam = [
  {
    name: "Noah Martinez",
    role: "Founder & CEO",
    image: "https://picsum.photos/400/400?random=61",
  },
  {
    name: "Ava Thompson",
    role: "Chief Strategy Officer",
    image: "https://picsum.photos/400/400?random=62",
  },
  {
    name: "Oliver Carter",
    role: "Chief Technology Officer",
    image: "https://picsum.photos/400/400?random=63",
  },
  {
    name: "Mia Jensen",
    role: "VP Client Partnerships",
    image: "https://picsum.photos/400/400?random=64",
  },
];

const About = () => {
  return (
    <div className="page about-page">
      <section className="page-hero">
        <div className="container narrow">
          <p className="eyebrow">About ElevateX</p>
          <h1>We partner with visionaries to shape the next era of digital</h1>
          <p>
            ElevateX was founded to close the gap between ambition and execution.
            Today, we bring together strategists, designers, engineers, and
            analysts under one collaborative engine that accelerates growth for
            global brands and emerging leaders alike.
          </p>
        </div>
      </section>

      <section className="image-section">
        <div className="container">
          <img
            src="https://picsum.photos/1200/800?random=21"
            alt="ElevateX collaborative workspace"
            loading="lazy"
          />
        </div>
      </section>

      <section className="values-section">
        <div className="container">
          <div className="section-header align-left">
            <p className="eyebrow">Our Philosophy</p>
            <h2>Building culture-first teams for exponential impact</h2>
            <p>
              Every engagement reflects our core values—integrity, empathy,
              craftsmanship, and relentless curiosity. It’s how we continuously
              deliver experiences that earn loyalty and unlock new growth.
            </p>
          </div>
          <div className="values-grid">
            {cultureHighlights.map((item) => (
              <div className="value-card" key={item.title}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="team-section about-team">
        <div className="container">
          <div className="section-header">
            <p className="eyebrow">Leadership Team</p>
            <h2>Global experts united by purpose</h2>
          </div>
          <div className="team-grid">
            {leadershipTeam.map((leader) => (
              <div className="team-card" key={leader.name}>
                <div className="team-image">
                  <img
                    src={leader.image}
                    alt={`${leader.name}, ${leader.role}`}
                    loading="lazy"
                  />
                </div>
                <div className="team-info">
                  <h3>{leader.name}</h3>
                  <span>{leader.role}</span>
                  <p>
                    {leader.name.split(" ")[0]} drives programs that unite
                    brilliant minds across strategy, design, and technology to
                    deliver lasting change.
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section secondary">
        <div className="container cta-wrapper">
          <div className="cta-content">
            <p className="eyebrow light">Join Us</p>
            <h2>We’re hiring trailblazers who are ready to redefine digital</h2>
            <p>
              Explore opportunities to work with ambitious clients, solve
              complex challenges, and build products that shape the future.
            </p>
          </div>
          <div className="cta-actions">
            <a href="/contact" className="btn-light">
              View Careers
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;