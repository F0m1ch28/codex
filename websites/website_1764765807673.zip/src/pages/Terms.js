import React from "react";

const Terms = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <p className="eyebrow">Terms</p>
          <h1>Terms &amp; Conditions</h1>
          <p>
            These terms outline the rules and regulations for using ElevateX
            Digital’s services and website. By accessing this site, you accept
            these terms in full.
          </p>
        </div>
      </section>
      <section className="legal-content">
        <div className="container narrow">
          <h2>Use of Site</h2>
          <p>
            The information provided on this site is for informational purposes.
            While we strive for accuracy, ElevateX does not warrant that all
            content is complete or up-to-date. Unauthorized use of the site may
            result in legal action.
          </p>
          <h2>Intellectual Property</h2>
          <p>
            All content, trademarks, and intellectual property remain the
            exclusive property of ElevateX unless otherwise noted. You may not
            copy, distribute, or modify any materials without prior written
            consent.
          </p>
          <h2>Limitations of Liability</h2>
          <p>
            ElevateX shall not be liable for any indirect or consequential loss
            arising out of the use or inability to use the services offered. We
            make no guarantees regarding uptime, performance, or outcomes unless
            expressly stated in a signed agreement.
          </p>
          <h2>Governing Law</h2>
          <p>
            These terms are governed by and construed in accordance with the
            laws of California, United States. Any disputes will be subject to
            the exclusive jurisdiction of the courts in San Francisco County.
          </p>
          <h2>Contact</h2>
          <p>
            For questions regarding these terms, please contact us at{" "}
            <a href="mailto:legal@elevatex.com">legal@elevatex.com</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Terms;