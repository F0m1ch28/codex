import React, { useState } from "react";

const services = [
  {
    category: "Strategy",
    title: "Growth Vision Sprint",
    description:
      "Define your north-star metrics, opportunity spaces, and investment roadmap in just 14 days.",
  },
  {
    category: "Strategy",
    title: "Market Intelligence",
    description:
      "Quantitative and qualitative insights that reveal customer needs, competitor moves, and whitespace opportunities.",
  },
  {
    category: "Design",
    title: "Experience Blueprint",
    description:
      "Map end-to-end journeys and architect frictionless experiences across digital and physical touchpoints.",
  },
  {
    category: "Design",
    title: "Brand Systems",
    description:
      "Develop modular brand identities and design systems that scale across products and platforms.",
  },
  {
    category: "Technology",
    title: "Product Engineering",
    description:
      "Full-stack engineering squads building cloud-native, performant, and secure software products.",
  },
  {
    category: "Technology",
    title: "Platform Modernization",
    description:
      "Re-architect legacy systems with modern infrastructure, automation, and intelligent data layers.",
  },
  {
    category: "Growth",
    title: "Lifecycle Orchestration",
    description:
      "Personalized lifecycle programs that convert, retain, and grow your most valuable customers.",
  },
  {
    category: "Growth",
    title: "Data & Experimentation",
    description:
      "Analytics ecosystems and testing frameworks that deliver continuous performance gains.",
  },
];

const Services = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const filteredServices =
    activeCategory === "All"
      ? services
      : services.filter((service) => service.category === activeCategory);

  return (
    <div className="page services-page">
      <section className="page-hero">
        <div className="container narrow">
          <p className="eyebrow">Services</p>
          <h1>Integrated capabilities to unlock your next level</h1>
          <p>
            Whether you’re launching a new venture, modernizing an enterprise,
            or scaling a standout product, ElevateX assembles the right experts
            and frameworks to fuel momentum.
          </p>
        </div>
      </section>

      <section className="services-filter-section">
        <div className="container">
          <div className="service-filters">
            {["All", "Strategy", "Design", "Technology", "Growth"].map(
              (category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={
                    activeCategory === category ? "btn-primary" : "btn-outline"
                  }
                >
                  {category}
                </button>
              )
            )}
          </div>
          <div className="service-grid detailed">
            {filteredServices.map((service) => (
              <div className="service-card" key={service.title}>
                <span className="service-category">{service.category}</span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <a href="/contact" className="service-link">
                  Book discovery →
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="image-section">
        <div className="container">
          <img
            src="https://picsum.photos/1200/800?random=22"
            alt="ElevateX service collaboration"
            loading="lazy"
          />
        </div>
      </section>

      <section className="cta-section secondary">
        <div className="container cta-wrapper">
          <div className="cta-content">
            <p className="eyebrow light">Let’s Collaborate</p>
            <h2>Co-create the solutions that keep you ahead</h2>
            <p>
              Share your challenges and we’ll craft a tailored roadmap covering
              strategy, design, and engineering to accelerate your next win.
            </p>
          </div>
          <div className="cta-actions">
            <a href="/contact" className="btn-light">
              Start your roadmap
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;