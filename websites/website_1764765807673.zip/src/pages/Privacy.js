import React from "react";

const Privacy = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <p className="eyebrow">Privacy</p>
          <h1>Privacy Policy</h1>
          <p>
            ElevateX is committed to protecting your personal data. This policy
            outlines the types of information we collect, how it is used, and
            the safeguards we maintain.
          </p>
        </div>
      </section>
      <section className="legal-content">
        <div className="container narrow">
          <h2>Information We Collect</h2>
          <p>
            We collect personal data that you provide directly, such as contact
            details submitted through forms, and data collected automatically,
            such as usage analytics and cookies.
          </p>
          <h2>How We Use Information</h2>
          <p>
            Data is used to respond to inquiries, deliver services, improve our
            offerings, and communicate updates. We only retain personal data for
            as long as necessary to fulfill these purposes.
          </p>
          <h2>Sharing and Disclosure</h2>
          <p>
            We do not sell your personal information. We may share data with
            trusted partners who assist in operating our website or servicing
            you, provided those parties agree to keep this information
            confidential.
          </p>
          <h2>Your Rights</h2>
          <p>
            Depending on your jurisdiction, you may request access, correction,
            or deletion of your personal data. Contact{" "}
            <a href="mailto:privacy@elevatex.com">privacy@elevatex.com</a> for
            assistance.
          </p>
          <h2>Updates</h2>
          <p>
            We may update this policy periodically. Changes will be posted on
            this page with an updated effective date.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;