(function () {
  document.addEventListener("DOMContentLoaded", function () {
    var banner = document.querySelector("[data-cookie-banner]");
    if (banner) {
      var acceptBtn = banner.querySelector("[data-cookie-accept]");
      var declineBtn = banner.querySelector("[data-cookie-decline]");
      var status = localStorage.getItem("oepCookieConsent");
      if (status !== "accepted" && status !== "declined") {
        banner.hidden = false;
      }
      if (acceptBtn) {
        acceptBtn.addEventListener("click", function () {
          localStorage.setItem("oepCookieConsent", "accepted");
          banner.hidden = true;
        });
      }
      if (declineBtn) {
        declineBtn.addEventListener("click", function () {
          localStorage.setItem("oepCookieConsent", "declined");
          banner.hidden = true;
        });
      }
    }

    var progressItems = document.querySelectorAll(".progress-track");
    progressItems.forEach(function (track) {
      var value = parseInt(track.getAttribute("data-progress"), 10);
      if (isNaN(value)) {
        value = 0;
      }
      value = Math.min(Math.max(value, 0), 100);
      var fill = track.querySelector(".progress-fill");
      var label = track.querySelector(".progress-label");
      if (fill) {
        fill.style.width = value + "%";
      }
      if (label) {
        label.textContent = value + "% аяқталды";
      }
    });
  });
})();