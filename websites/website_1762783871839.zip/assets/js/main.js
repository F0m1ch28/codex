document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.getElementById('navToggle');
    const primaryNav = document.getElementById('primaryNav');
    const scrollTopBtn = document.getElementById('scrollTopBtn');
    const newsletterForm = document.getElementById('newsletterForm');
    const newsletterFeedback = document.getElementById('newsletterFeedback');
    const contactForm = document.getElementById('contactForm');
    const contactFeedback = document.getElementById('contactFeedback');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookies = document.getElementById('acceptCookies');
    const yearSpan = document.getElementById('currentYear');

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    // Mobile navigation toggle
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = primaryNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                primaryNav.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    // Scroll to top button
    if (scrollTopBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                scrollTopBtn.style.display = 'flex';
            } else {
                scrollTopBtn.style.display = 'none';
            }
        });

        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Newsletter form
    if (newsletterForm && newsletterFeedback) {
        newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const emailValue = newsletterForm.email.value.trim();
            if (!emailValue) {
                newsletterFeedback.textContent = 'Inserisci un indirizzo email valido.';
                newsletterFeedback.style.color = '#DC2626';
                return;
            }
            newsletterFeedback.textContent = 'Grazie! Riceverai presto le prossime note di campo.';
            newsletterFeedback.style.color = '#2563EB';
            newsletterForm.reset();
        });
    }

    // Contact form
    if (contactForm && contactFeedback) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = contactForm.name.value.trim();
            const email = contactForm.email.value.trim();
            const message = contactForm.message.value.trim();

            if (!name || !email || !message) {
                contactFeedback.textContent = 'Compila tutti i campi obbligatori.';
                contactFeedback.style.color = '#DC2626';
                return;
            }

            contactFeedback.textContent = 'Messaggio inviato. Ti risponderemo entro 2 giorni lavorativi.';
            contactFeedback.style.color = '#2563EB';
            contactForm.reset();
        });
    }

    // Cookie banner
    const COOKIE_STORAGE_KEY = 'campoenergetico_cookie_consent';

    if (cookieBanner && acceptCookies) {
        const consent = localStorage.getItem(COOKIE_STORAGE_KEY);
        if (!consent) {
            cookieBanner.style.display = 'block';
        }

        acceptCookies.addEventListener('click', () => {
            localStorage.setItem(COOKIE_STORAGE_KEY, 'accepted');
            cookieBanner.style.display = 'none';
        });
    }
});