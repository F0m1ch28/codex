document.addEventListener('DOMContentLoaded', function () {
  var banner = document.getElementById('cookieBanner');
  var acceptBtn = document.getElementById('cookieAccept');
  var declineBtn = document.getElementById('cookieDecline');

  if (!banner || !acceptBtn || !declineBtn) {
    return;
  }

  var consent = localStorage.getItem('edunext_cookie_consent');

  if (!consent) {
    banner.classList.add('active');
  }

  function closeBanner() {
    banner.classList.remove('active');
  }

  acceptBtn.addEventListener('click', function () {
    localStorage.setItem('edunext_cookie_consent', 'accepted');
    closeBanner();
  });

  declineBtn.addEventListener('click', function () {
    localStorage.setItem('edunext_cookie_consent', 'declined');
    closeBanner();
  });
});