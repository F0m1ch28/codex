const navToggle = document.querySelector('.menu-toggle');
const siteNav = document.querySelector('.site-nav');
const body = document.body;

if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
        const expanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', String(!expanded));
        siteNav.classList.toggle('open');
        body.classList.toggle('nav-open');
    });

    siteNav.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            siteNav.classList.remove('open');
            navToggle.setAttribute('aria-expanded', 'false');
            body.classList.remove('nav-open');
        });
    });
}

const currentPage = body.dataset.page;
if (currentPage) {
    const activeLink = document.querySelector(`[data-nav="${currentPage}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
}

const cookieBanner = document.getElementById('cookie-banner');
const cookieKey = 'ffirCookieConsent';

if (cookieBanner) {
    const savedChoice = localStorage.getItem(cookieKey);
    if (!savedChoice) {
        requestAnimationFrame(() => cookieBanner.classList.add('visible'));
    }

    const acceptBtn = cookieBanner.querySelector('.btn-accept');
    const declineBtn = cookieBanner.querySelector('.btn-decline');

    const closeBanner = (choice) => {
        localStorage.setItem(cookieKey, choice);
        cookieBanner.classList.remove('visible');
    };

    if (acceptBtn) {
        acceptBtn.addEventListener('click', () => closeBanner('accepted'));
    }
    if (declineBtn) {
        declineBtn.addEventListener('click', () => closeBanner('refused'));
    }
}

const ffirMarkers = [
    { position: { lat: 48.8686, lng: 2.3075 }, title: 'CNC – Paris' },
    { position: { lat: 48.9086, lng: 2.357 }, title: 'Studios Pathé – La Plaine Saint-Denis' },
    { position: { lat: 48.8462, lng: 2.273 }, title: 'France Télévisions – Paris' },
    { position: { lat: 48.8871, lng: 2.3376 }, title: 'La Fémis – Paris' },
    { position: { lat: 48.8767, lng: 2.3694 }, title: 'ENS Louis-Lumière – Saint-Denis' },
    { position: { lat: 43.5513, lng: 7.0128 }, title: 'Palais des Festivals – Cannes' },
    { position: { lat: 49.3596, lng: 0.0749 }, title: 'Centre International – Deauville' },
    { position: { lat: 45.899, lng: 6.1294 }, title: 'Bonlieu – Festival d’Annecy' }
];

window.initFilmMap = function initFilmMap() {
    const containers = document.querySelectorAll('[data-map]');
    if (!containers.length) return;

    containers.forEach((container) => {
        const map = new google.maps.Map(container, {
            center: { lat: 46.7111, lng: 1.7191 },
            zoom: 6,
            styles: [
                { featureType: 'all', elementType: 'geometry', stylers: [{ color: '#ebe3cd' }] },
                { featureType: 'water', elementType: 'geometry.fill', stylers: [{ color: '#c9c9c9' }] },
                { featureType: 'poi', stylers: [{ visibility: 'off' }] },
                { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#f5f1e6' }] },
                { featureType: 'road', elementType: 'labels', stylers: [{ visibility: 'off' }] }
            ],
            disableDefaultUI: true,
            zoomControl: true
        });

        ffirMarkers.forEach((markerData) => {
            new google.maps.Marker({
                position: markerData.position,
                map,
                title: markerData.title,
                icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 6,
                    fillColor: '#8b0000',
                    fillOpacity: 0.9,
                    strokeWeight: 0
                }
            });
        });
    });
};