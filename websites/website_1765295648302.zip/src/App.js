```javascript
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Methodologie from './pages/Methodologie';
import Articles from './pages/Articles';
import ArticleDetail from './pages/ArticleDetail';
import Categories from './pages/Categories';
import CategoryDetail from './pages/CategoryDetail';
import Interviews from './pages/Interviews';
import InterviewDetail from './pages/InterviewDetail';
import Ressources from './pages/Ressources';
import Contact from './pages/Contact';
import MentionsLegales from './pages/MentionsLegales';
import PolitiqueConfidentialite from './pages/PolitiqueConfidentialite';
import PolitiqueCookies from './pages/PolitiqueCookies';
import NotFound from './pages/NotFound';
import styles from './App.module.css';

const App = () => (
  <div className={styles.app}>
    <Header />
    <main className={styles.mainContent}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/a-propos" element={<About />} />
        <Route path="/methodologie" element={<Methodologie />} />
        <Route path="/articles" element={<Articles />} />
        <Route path="/articles/:slug" element={<ArticleDetail />} />
        <Route path="/categories" element={<Categories />} />
        <Route path="/categories/:categorySlug" element={<CategoryDetail />} />
        <Route path="/interviews" element={<Interviews />} />
        <Route path="/interviews/:slug" element={<InterviewDetail />} />
        <Route path="/ressources" element={<Ressources />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/mentions-legales" element={<MentionsLegales />} />
        <Route path="/confidentialite" element={<PolitiqueConfidentialite />} />
        <Route path="/politique-cookies" element={<PolitiqueCookies />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTop />
  </div>
);

export default App;
```