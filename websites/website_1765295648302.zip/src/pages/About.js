```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const About = () => (
  <div className={styles.page}>
    <Helmet>
      <title>À Propos — French Equestrian Clubs Review</title>
      <meta
        name="description"
        content="Présentation de la rédaction, de ses objectifs et de l’approche indépendante de French Equestrian Clubs Review."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.container}>
        <h1 className={styles.title}>À propos de la rédaction</h1>
        <p className={styles.lead}>
          French Equestrian Clubs Review documente les dynamiques équestres
          françaises à travers des enquêtes rigoureuses, des analyses
          historiques et des observations de terrain. La rédaction privilégie
          une grille de lecture à la fois culturelle, sportive et sociale.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Une équipe pluridisciplinaire</h2>
        <p>
          La rédaction rassemble des journalistes spécialisés, des
          documentalistes et des chercheurs associés. Chaque investigation est
          confiée à un binôme mêlant expertise sportive et approche historique.
          Les membres de l’équipe partagent un intérêt commun pour la
          compréhension fine des organisations associatives et des pratiques
          territoriales.
        </p>
        <p>
          Les enquêtes sont conduites selon un protocole précis : visite des
          infrastructures, entretiens semi-directifs, analyse des archives
          disponibles et restitution auprès des acteurs consultés. Cette
          méthode garantit la cohérence et la vérifiabilité des informations
          collectées.
        </p>
      </div>
    </section>

    <section className={styles.sectionAlt}>
      <div className={styles.container}>
        <h2>Angles de recherche</h2>
        <ul className={styles.list}>
          <li>
            <strong>Contextes territoriaux :</strong> observation des
            dynamiques rurales et urbaines, compréhension des partenariats
            locaux.
          </li>
          <li>
            <strong>Transmission des savoirs :</strong> suivi des cursus de
            formation, des pédagogies innovantes et des dispositifs de tutorat.
          </li>
          <li>
            <strong>Organisation des clubs :</strong> analyse des gouvernances,
            des statuts juridiques et des coopérations fédérales.
          </li>
          <li>
            <strong>Pratiques culturelles :</strong> exploration des traditions,
            des rituels et des manifestations qui structurent la vie des clubs.
          </li>
        </ul>
      </div>
    </section>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Engagement éditorial</h2>
        <p>
          La publication ne poursuit aucune vocation promotionnelle. Elle
          s’attache à restituer la pluralité des points de vue et à faciliter la
          compréhension du fonctionnement des clubs. Les lecteurs disposent ainsi
          d’un matériau fiable pour alimenter leurs propres recherches ou leurs
          débats professionnels.
        </p>
        <p>
          L’équipe s’engage à corriger rapidement toute information inexacte.
          Les mises à jour sont mentionnées au bas des articles ou des
          entretiens concernés. Les archives restent accessibles afin de
          documenter l’évolution des connaissances.
        </p>
      </div>
    </section>
  </div>
);

export default About;
```