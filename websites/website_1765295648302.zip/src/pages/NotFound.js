```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './NotFound.module.css';

const NotFound = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Page introuvable — French Equestrian Clubs Review</title>
    </Helmet>

    <div className={styles.container}>
      <h1>Page introuvable</h1>
      <p>
        La page demandée n’existe pas ou n’est plus disponible. Merci de
        retourner à l’accueil ou de poursuivre la navigation via le menu.
      </p>
      <Link to="/" className={styles.link}>
        Revenir à l’accueil
      </Link>
    </div>
  </div>
);

export default NotFound;
```