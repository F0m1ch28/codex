```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const MentionsLegales = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Mentions Légales — French Equestrian Clubs Review</title>
      <meta
        name="description"
        content="Informations légales relatives au site French Equestrian Clubs Review."
      />
    </Helmet>

    <header className={styles.header}>
      <div className={styles.container}>
        <h1>Mentions légales</h1>
        <p>
          Ce site éditorial est publié par la rédaction de French Equestrian
          Clubs Review. Les informations ci-dessous précisent le cadre juridique
          et les responsabilités associées.
        </p>
      </div>
    </header>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Éditeur</h2>
        <p>
          French Equestrian Clubs Review est une publication indépendante
          dédiée à l’étude des clubs équestres en France. L’équipe éditoriale
          assure la direction de la rédaction et la gestion des contenus.
        </p>
      </div>
    </section>

    <section className={styles.sectionAlt}>
      <div className={styles.container}>
        <h2>Hébergement</h2>
        <p>
          Le site est hébergé sur une infrastructure compatible avec les
          principales plateformes de déploiement statique, garantissant la
          disponibilité et la sécurité des données publiées.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Propriété intellectuelle</h2>
        <p>
          L’ensemble des contenus publiés (textes, photographies référencées,
          infographies) est protégé par la législation française et
          internationale relative aux droits d’auteur. Toute reproduction ou
          adaptation requiert l’accord préalable de la rédaction.
        </p>
      </div>
    </section>

    <section className={styles.sectionAlt}>
      <div className={styles.container}>
        <h2>Responsabilité éditoriale</h2>
        <p>
          Les articles et interviews sont réalisés selon un protocole de
          vérification interne. Les informations apportées par les personnes
          interviewées engagent ces dernières. Toute demande de correction peut
          être adressée via le formulaire de contact.
        </p>
      </div>
    </section>
  </div>
);

export default MentionsLegales;
```