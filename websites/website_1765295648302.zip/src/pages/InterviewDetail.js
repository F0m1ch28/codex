```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link, useParams } from 'react-router-dom';
import interviewsData from '../data/interviews';
import styles from './InterviewDetail.module.css';

const InterviewDetail = () => {
  const { slug } = useParams();
  const interview = interviewsData.find((item) => item.slug === slug);

  if (!interview) {
    return (
      <div className={styles.notFound}>
        <h1>Entretien introuvable</h1>
        <p>
          L’entretien demandé n’est pas disponible. Merci de consulter la liste
          principale des interviews.
        </p>
        <Link to="/interviews" className={styles.backLink}>
          Retourner aux interviews
        </Link>
      </div>
    );
  }

  const formattedDate = new Intl.DateTimeFormat('fr-FR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  }).format(new Date(interview.publishedDate));

  return (
    <article className={styles.page}>
      <Helmet>
        <title>{interview.title} — French Equestrian Clubs Review</title>
        <meta name="description" content={interview.excerpt} />
      </Helmet>

      <header className={styles.header}>
        <div className={styles.container}>
          <p className={styles.category}>{interview.category.replace(/-/g, ' ')}</p>
          <h1 className={styles.title}>{interview.title}</h1>
          <p className={styles.interviewee}>
            {interview.interviewee} — {interview.role}
          </p>
          <div className={styles.meta}>
            <span>{formattedDate}</span>
            <span aria-hidden="true">•</span>
            <span>{interview.readTime}</span>
          </div>
          <p className={styles.excerpt}>{interview.excerpt}</p>
        </div>
        <figure className={styles.imageWrapper}>
          <img src={interview.imageUrl} alt={interview.title} />
        </figure>
      </header>

      <section className={styles.contentSection}>
        <div className={styles.container}>
          {interview.content.split('\n\n').map((paragraph, index) => (
            <p key={`paragraph-${index}`} className={styles.paragraph}>
              {paragraph}
            </p>
          ))}
        </div>
      </section>

      <footer className={styles.footer}>
        <div className={styles.container}>
          <Link to="/interviews" className={styles.backLink}>
            Revenir à la liste des interviews
          </Link>
        </div>
      </footer>
    </article>
  );
};

export default InterviewDetail;
```