```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link, useParams } from 'react-router-dom';
import articlesData from '../data/articles';
import styles from './ArticleDetail.module.css';

const ArticleDetail = () => {
  const { slug } = useParams();
  const article = articlesData.find((item) => item.slug === slug);

  if (!article) {
    return (
      <div className={styles.notFound}>
        <h1>Article introuvable</h1>
        <p>
          L’étude demandée n’est pas référencée. Les archives peuvent être
          consultées à partir de la page principale des articles.
        </p>
        <Link to="/articles" className={styles.backLink}>
          Retourner aux articles
        </Link>
      </div>
    );
  }

  const formattedDate = new Intl.DateTimeFormat('fr-FR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  }).format(new Date(article.publishedDate));

  return (
    <article className={styles.page}>
      <Helmet>
        <title>{article.title} — French Equestrian Clubs Review</title>
        <meta name="description" content={article.excerpt} />
      </Helmet>

      <header className={styles.header}>
        <div className={styles.container}>
          <p className={styles.category}>{article.category.replace(/-/g, ' ')}</p>
          <h1 className={styles.title}>{article.title}</h1>
          <div className={styles.meta}>
            <span>{formattedDate}</span>
            <span aria-hidden="true">•</span>
            <span>{article.author}</span>
            <span aria-hidden="true">•</span>
            <span>{article.readTime}</span>
          </div>
          <p className={styles.excerpt}>{article.excerpt}</p>
        </div>
        <figure className={styles.imageWrapper}>
          <img src={article.imageUrl} alt={article.title} />
        </figure>
      </header>

      <section className={styles.contentSection}>
        <div className={styles.container}>
          {article.content.split('\n\n').map((paragraph, index) => (
            <p key={`paragraph-${index}`} className={styles.paragraph}>
              {paragraph}
            </p>
          ))}
        </div>
      </section>

      <footer className={styles.footer}>
        <div className={styles.container}>
          <Link to="/articles" className={styles.backLink}>
            Revenir à la liste des articles
          </Link>
        </div>
      </footer>
    </article>
  );
};

export default ArticleDetail;
```