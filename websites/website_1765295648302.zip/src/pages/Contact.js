```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const Contact = () => {
  const [status, setStatus] = useState(null);

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus(
      'Le formulaire a été enregistré. La rédaction prendra connaissance du message lors de sa prochaine session de lecture.'
    );
    event.target.reset();
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact — French Equestrian Clubs Review</title>
        <meta
          name="description"
          content="Formulaire de contact destiné aux chercheurs, encadrants et responsables souhaitant partager leurs observations."
        />
      </Helmet>

      <header className={styles.header}>
        <div className={styles.container}>
          <h1>Contact</h1>
          <p>
            Ce formulaire s’adresse aux chercheurs, responsables de clubs et
            experts souhaitant proposer une contribution ou signaler une source.
            Les messages sont lus lors des sessions de veille rédactionnelle.
          </p>
        </div>
      </header>

      <section className={styles.section}>
        <div className={styles.container}>
          <form className={styles.form} onSubmit={handleSubmit}>
            <div className={styles.field}>
              <label htmlFor="name">Nom</label>
              <input
                type="text"
                id="name"
                name="name"
                required
                placeholder="Indiquer le nom du contact"
              />
            </div>

            <div className={styles.field}>
              <label htmlFor="email">Adresse électronique</label>
              <input
                type="email"
                id="email"
                name="email"
                required
                placeholder="exemple@domaine.fr"
              />
            </div>

            <div className={styles.field}>
              <label htmlFor="subject">Objet</label>
              <input
                type="text"
                id="subject"
                name="subject"
                required
                placeholder="Préciser le sujet du message"
              />
            </div>

            <div className={styles.field}>
              <label htmlFor="message">Message</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                required
                placeholder="Décrire la proposition, la ressource ou la question de recherche"
              />
            </div>

            <p className={styles.note}>
              Les informations saisies sont utilisées uniquement pour répondre
              au message. Aucune donnée n’est transmise à des tiers.
            </p>

            <button type="submit" className={styles.submitButton}>
              Enregistrer le message
            </button>

            {status && <p className={styles.status}>{status}</p>}
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;
```