```javascript
const categories = [
  {
    name: 'Clubs hippiques de France',
    slug: 'club-hippique-de-france',
    description:
      'Structures affiliées, gouvernance interne, cadres juridiques et articulation avec les fédérations territoriales.',
    imageUrl:
      'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Centres équestres et poney-clubs',
    slug: 'centres-equestres-et-poney-clubs',
    description:
      'Équipements de proximité, pédagogies adaptées aux publics jeunes, modèles d’animation associative et municipale.',
    imageUrl:
      'https://images.unsplash.com/photo-1508684484983-3763a3f04b7f?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Disciplines équestres',
    slug: 'disciplines-equestres',
    description:
      'Dressage, saut d’obstacles, concours complet et pratiques émergentes observés sous l’angle technique et culturel.',
    imageUrl:
      'https://images.unsplash.com/photo-1517849845537-4d257902454a?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Cavalerie et soins des chevaux',
    slug: 'cavalerie-et-soins-des-chevaux',
    description:
      'Approches vétérinaires, infrastructures de soins, suivi alimentaire et innovations en matière de bien-être équin.',
    imageUrl:
      'https://images.unsplash.com/photo-1578321272173-dee45ef9c395?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Pédagogie et formations',
    slug: 'pedagogie-et-formations',
    description:
      'Transmission des savoirs, formation des encadrants, certifications et parcours d’apprentissage différenciés.',
    imageUrl:
      'https://images.unsplash.com/photo-1504208434309-cb69f4fe52b0?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Histoire et évolution',
    slug: 'histoire-et-evolution',
    description:
      'Chronologie des clubs, influence des mouvements sportifs, adaptation aux mutations sociétales et technologiques.',
    imageUrl:
      'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Rôle social et culturel',
    slug: 'role-social-et-culturel',
    description:
      'Partenariats locaux, inclusion de nouveaux publics, initiatives éducatives et rayonnement territorial.',
    imageUrl:
      'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Pratiques régionales',
    slug: 'pratiques-regionales',
    description:
      'Spécificités territoriales, traditions locales, patrimoines vivants et adaptation aux contextes paysagers.',
    imageUrl:
      'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80'
  }
];

export default categories;
```