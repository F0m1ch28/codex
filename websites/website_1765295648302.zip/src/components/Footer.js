```javascript
import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.brandBlock}>
        <p className={styles.logo}>French Equestrian Clubs Review</p>
        <p className={styles.text}>
          Publication indépendante consacrée à l’étude des clubs équestres en
          France, de leurs traditions et de leurs mutations contemporaines.
        </p>
        <p className={styles.text}>
          Ce média ne poursuit aucune finalité commerciale et privilégie une
          approche documentaire et analytique.
        </p>
      </div>
      <div className={styles.linksBlock}>
        <h3 className={styles.heading}>Navigation</h3>
        <ul className={styles.linkList}>
          <li>
            <NavLink to="/a-propos">À Propos</NavLink>
          </li>
          <li>
            <NavLink to="/methodologie">Méthodologie</NavLink>
          </li>
          <li>
            <NavLink to="/articles">Tous les Articles</NavLink>
          </li>
          <li>
            <NavLink to="/interviews">Interviews</NavLink>
          </li>
          <li>
            <NavLink to="/ressources">Ressources</NavLink>
          </li>
          <li>
            <NavLink to="/contact">Contact</NavLink>
          </li>
        </ul>
      </div>
      <div className={styles.legalBlock}>
        <h3 className={styles.heading}>Références</h3>
        <ul className={styles.linkList}>
          <li>
            <NavLink to="/mentions-legales">Mentions Légales</NavLink>
          </li>
          <li>
            <NavLink to="/confidentialite">
              Politique de Confidentialité
            </NavLink>
          </li>
          <li>
            <NavLink to="/politique-cookies">Politique des Cookies</NavLink>
          </li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <p className={styles.bottomText}>
        © {new Date().getFullYear()} French Equestrian Clubs Review. Tous droits
        réservés.
      </p>
    </div>
  </footer>
);

export default Footer;
```