```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './ArticleCard.module.css';

const ArticleCard = ({ article }) => {
  if (!article) {
    return null;
  }

  const {
    title,
    slug,
    category,
    excerpt,
    imageUrl,
    author,
    publishedDate,
    readTime
  } = article;

  const formattedDate = new Intl.DateTimeFormat('fr-FR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  }).format(new Date(publishedDate));

  return (
    <article className={styles.card}>
      <figure className={styles.imageWrapper}>
        <img src={imageUrl} alt={title} className={styles.image} />
      </figure>
      <div className={styles.content}>
        <p className={styles.category}>{category.replace(/-/g, ' ')}</p>
        <h3 className={styles.title}>
          <Link to={`/articles/${slug}`} className={styles.titleLink}>
            {title}
          </Link>
        </h3>
        <p className={styles.excerpt}>{excerpt}</p>
        <div className={styles.meta}>
          <span>{formattedDate}</span>
          <span aria-hidden="true">•</span>
          <span>{author}</span>
          <span aria-hidden="true">•</span>
          <span>{readTime}</span>
        </div>
        <Link to={`/articles/${slug}`} className={styles.readMore}>
          Lire l’étude
        </Link>
      </div>
    </article>
  );
};

export default ArticleCard;
```