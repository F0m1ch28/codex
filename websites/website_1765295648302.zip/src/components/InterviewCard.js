```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './InterviewCard.module.css';

const InterviewCard = ({ interview }) => {
  if (!interview) {
    return null;
  }

  const {
    title,
    slug,
    category,
    excerpt,
    imageUrl,
    interviewee,
    role,
    publishedDate,
    readTime
  } = interview;

  const formattedDate = new Intl.DateTimeFormat('fr-FR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  }).format(new Date(publishedDate));

  return (
    <article className={styles.card}>
      <figure className={styles.imageWrapper}>
        <img src={imageUrl} alt={title} className={styles.image} />
      </figure>
      <div className={styles.content}>
        <p className={styles.category}>{category.replace(/-/g, ' ')}</p>
        <h3 className={styles.title}>
          <Link to={`/interviews/${slug}`} className={styles.titleLink}>
            {title}
          </Link>
        </h3>
        <p className={styles.interviewee}>
          {interviewee} — {role}
        </p>
        <p className={styles.excerpt}>{excerpt}</p>
        <div className={styles.meta}>
          <span>{formattedDate}</span>
          <span aria-hidden="true">•</span>
          <span>{readTime}</span>
        </div>
        <Link to={`/interviews/${slug}`} className={styles.readMore}>
          Lire l’entretien
        </Link>
      </div>
    </article>
  );
};

export default InterviewCard;
```