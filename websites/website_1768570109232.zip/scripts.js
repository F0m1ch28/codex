document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAccept = document.getElementById('cookieAccept');
    const cookieDecline = document.getElementById('cookieDecline');
    const yearElement = document.getElementById('currentYear');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            navMenu.classList.toggle('is-open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('is-open')) {
                    navMenu.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (yearElement) {
        const currentYear = new Date().getFullYear();
        yearElement.textContent = currentYear;
    }

    const COOKIE_KEY = 'hydroloktk_cookie_consent';

    function showCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.add('is-visible');
        }
    }

    function hideCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.remove('is-visible');
        }
    }

    if (cookieBanner && cookieAccept && cookieDecline) {
        const storedPreference = localStorage.getItem(COOKIE_KEY);
        if (!storedPreference) {
            setTimeout(showCookieBanner, 1200);
        }

        cookieAccept.addEventListener('click', () => {
            localStorage.setItem(COOKIE_KEY, 'accepted');
            hideCookieBanner();
        });

        cookieDecline.addEventListener('click', () => {
            localStorage.setItem(COOKIE_KEY, 'declined');
            hideCookieBanner();
        });
    }
});