(function () {
    const navToggle = document.querySelector(".nav-toggle");
    const mainNav = document.querySelector(".main-nav");

    if (navToggle && mainNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", (!expanded).toString());
            mainNav.classList.toggle("is-open");
        });

        mainNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 761 && mainNav.classList.contains("is-open")) {
                    mainNav.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieButtons = document.querySelectorAll(".cookie-banner a[data-cookie-action]");

    const setCookiePreference = (preference) => {
        try {
            const expiryDate = new Date();
            expiryDate.setFullYear(expiryDate.getFullYear() + 1);
            localStorage.setItem("psuk_cookie_preference", JSON.stringify({
                value: preference,
                timestamp: new Date().toISOString()
            }));
        } catch (error) {
            console.warn("Cookie preference could not be saved.", error);
        }
    };

    const getCookiePreference = () => {
        try {
            const stored = localStorage.getItem("psuk_cookie_preference");
            return stored ? JSON.parse(stored) : null;
        } catch (error) {
            console.warn("Cookie preference could not be retrieved.", error);
            return null;
        }
    };

    if (cookieBanner) {
        if (!getCookiePreference()) {
            cookieBanner.classList.add("is-visible");
        }

        cookieButtons.forEach(button => {
            button.addEventListener("click", (event) => {
                event.preventDefault();
                const preference = button.getAttribute("data-cookie-action");
                setCookiePreference(preference);
                cookieBanner.classList.remove("is-visible");
            });
        });
    }

    const postsContainer = document.querySelector("[data-posts-list]");
    if (postsContainer) {
        const filterButtons = document.querySelectorAll("[data-filter]");
        const searchInput = document.querySelector("[data-search]");
        const paginationContainer = document.querySelector("[data-pagination]");
        const cards = Array.from(postsContainer.querySelectorAll("[data-topic]"));
        const itemsPerPage = 6;
        let activeTopic = "all";
        let currentPage = 1;
        let searchTerm = "";

        const renderPagination = (totalItems) => {
            if (!paginationContainer) return;
            paginationContainer.innerHTML = "";
            const totalPages = Math.max(1, Math.ceil(totalItems / itemsPerPage));

            const createButton = (page) => {
                const button = document.createElement("button");
                button.type = "button";
                button.textContent = page;
                if (page === currentPage) {
                    button.classList.add("is-active");
                }
                button.addEventListener("click", () => {
                    currentPage = page;
                    updateDisplay();
                });
                return button;
            };

            for (let page = 1; page <= totalPages; page += 1) {
                paginationContainer.appendChild(createButton(page));
            }
        };

        const updateDisplay = () => {
            const filteredCards = cards.filter(card => {
                const matchesTopic = activeTopic === "all" || card.dataset.topic === activeTopic;
                const matchesSearch = card.dataset.keywords?.toLowerCase().includes(searchTerm.toLowerCase()) || card.textContent.toLowerCase().includes(searchTerm.toLowerCase());
                return matchesTopic && matchesSearch;
            });

            cards.forEach(card => {
                card.setAttribute("hidden", "hidden");
            });

            const totalItems = filteredCards.length;
            const totalPages = Math.max(1, Math.ceil(totalItems / itemsPerPage));
            if (currentPage > totalPages) {
                currentPage = totalPages;
            }

            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = startIndex + itemsPerPage;

            filteredCards.slice(startIndex, endIndex).forEach(card => {
                card.removeAttribute("hidden");
            });

            renderPagination(totalItems);
        };

        filterButtons.forEach(button => {
            button.addEventListener("click", () => {
                activeTopic = button.getAttribute("data-filter");
                filterButtons.forEach(btn => btn.classList.remove("is-active"));
                button.classList.add("is-active");
                currentPage = 1;
                updateDisplay();
            });
        });

        if (searchInput) {
            searchInput.addEventListener("input", (event) => {
                searchTerm = event.target.value.trim();
                currentPage = 1;
                updateDisplay();
            });
        }

        updateDisplay();
    }
})();