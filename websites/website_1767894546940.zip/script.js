document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const mainNav = document.querySelector('.main-nav');

    if (navToggle && mainNav) {
        navToggle.addEventListener('click', () => {
            mainNav.classList.toggle('open');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieAccept = document.querySelector('.cookie-accept');
    const cookieDecline = document.querySelector('.cookie-decline');
    const cookieConsent = localStorage.getItem('gcCookieConsent');

    if (cookieBanner && cookieConsent) {
        cookieBanner.classList.add('hidden');
    }

    if (cookieAccept) {
        cookieAccept.addEventListener('click', () => {
            localStorage.setItem('gcCookieConsent', 'accepted');
            cookieBanner.classList.add('hidden');
        });
    }

    if (cookieDecline) {
        cookieDecline.addEventListener('click', () => {
            localStorage.setItem('gcCookieConsent', 'declined');
            cookieBanner.classList.add('hidden');
            window.location.href = 'cookies.html';
        });
    }

    const backToTop = document.querySelector('.back-to-top');
    if (backToTop) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 400) {
                backToTop.classList.add('visible');
            } else {
                backToTop.classList.remove('visible');
            }
        });

        backToTop.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const timelineFilterButtons = document.querySelectorAll('[data-decade-filter]');
    const timelineEntries = document.querySelectorAll('.timeline-entry');
    if (timelineFilterButtons.length && timelineEntries.length) {
        timelineFilterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const target = button.getAttribute('data-decade-filter');
                timelineFilterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');

                timelineEntries.forEach(entry => {
                    if (target === 'all' || entry.getAttribute('data-decade') === target) {
                        entry.style.display = 'block';
                    } else {
                        entry.style.display = 'none';
                    }
                });
            });
        });
    }

    const filterButtons = document.querySelectorAll('[data-filter]');
    const filterableItems = document.querySelectorAll('[data-tags]');
    if (filterButtons.length && filterableItems.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const target = button.getAttribute('data-filter');
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                filterableItems.forEach(item => {
                    const tags = item.getAttribute('data-tags').split(',');
                    if (target === 'all' || tags.includes(target)) {
                        item.style.display = 'grid';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });
    }

    const legendCards = document.querySelectorAll('[data-modal]');
    const modalOverlay = document.querySelector('.modal');
    if (legendCards.length && modalOverlay) {
        const modalContent = modalOverlay.querySelector('.modal-content-inner');
        legendCards.forEach(card => {
            card.addEventListener('click', () => {
                const modalData = card.querySelector('.modal-text');
                if (modalData && modalContent) {
                    modalContent.innerHTML = modalData.innerHTML;
                    modalOverlay.classList.add('open');
                }
            });
        });

        const modalClose = modalOverlay.querySelector('.modal-close');
        modalClose.addEventListener('click', () => modalOverlay.classList.remove('open'));
        modalOverlay.addEventListener('click', (event) => {
            if (event.target === modalOverlay) {
                modalOverlay.classList.remove('open');
            }
        });
    }

    const galleryImages = document.querySelectorAll('.gallery-grid img');
    const lightbox = document.querySelector('.lightbox');
    if (galleryImages.length && lightbox) {
        const lightboxImg = lightbox.querySelector('img');
        galleryImages.forEach(image => {
            image.addEventListener('click', () => {
                lightboxImg.src = image.src;
                lightboxImg.alt = image.alt;
                lightbox.classList.add('open');
            });
        });

        lightbox.addEventListener('click', () => {
            lightbox.classList.remove('open');
        });
    }
});