(function () {
    const state = {
        timer: null,
        interval: null,
        dataset: null,
        isActive: false,
        score: 0,
        found: 0,
        total: 0,
        streak: 0,
        bestStreak: 0,
        guesses: new Set(),
        hintsUsed: 0,
        hintMessages: [],
        playerName: "Игрок",
        difficulty: "normal",
        startedAt: null
    };

    const difficulties = {
        easy: {
            title: "Лёгкая",
            duration: 70,
            hintLimit: 3,
            scoreMultiplier: 0.9,
            penalty: 5
        },
        normal: {
            title: "Норма",
            duration: 55,
            hintLimit: 2,
            scoreMultiplier: 1,
            penalty: 8
        },
        hard: {
            title: "Сложная",
            duration: 40,
            hintLimit: 1,
            scoreMultiplier: 1.2,
            penalty: 10
        },
        extreme: {
            title: "Экстрим",
            duration: 30,
            hintLimit: 0,
            scoreMultiplier: 1.35,
            penalty: 14
        }
    };

    const suggestionLibrary = [
        {
            prompt: "Как вы слушаете музыку в Яндексе?",
            category: "Музыка",
            suggestions: [
                { text: "яндекс музыка", points: 120, aliases: ["yandex music", "яндексмузыка"] },
                { text: "яндекс музыка подписка", points: 110, aliases: ["подписка на яндекс музыку"] },
                { text: "яндекс музыка скачать", points: 100, aliases: ["скачать трек яндекс"] },
                { text: "яндекс музыка офлайн", points: 95, aliases: ["офлайн режим яндекс музыка"] },
                { text: "яндекс музыка плейлист дня", points: 90, aliases: ["плейлист дня"] },
                { text: "яндекс музыка рекомендации", points: 85, aliases: ["рекомендации яндекс музыка"] }
            ],
            hints: [
                "Вспомните главный музыкальный сервис Яндекса и его ключевые функции.",
                "Подумайте о подписке, офлайн-режиме и персональных плейлистах."
            ]
        },
        {
            prompt: "Как вы заказываете еду через Яндекс?",
            category: "Еда",
            suggestions: [
                { text: "яндекс еда", points: 120, aliases: ["yandex food"] },
                { text: "яндекс еда промокод", points: 110, aliases: ["промокод на яндекс еду"] },
                { text: "яндекс еда доставка", points: 100, aliases: ["доставка яндекс"] },
                { text: "яндекс еда подписка", points: 95, aliases: ["подписка яндекс еда"] },
                { text: "яндекс еда статус заказа", points: 90, aliases: ["статус заказа яндекс"] },
                { text: "яндекс еда отзывы", points: 85, aliases: ["отзывы яндекс еда"] }
            ],
            hints: [
                "Начните с основного сервиса Яндекса, связанного с ресторанами.",
                "Расширьте тему: доставка, подписка и скидки."
            ]
        },
        {
            prompt: "Как вы планируете путешествие с Яндексом?",
            category: "Путешествия",
            suggestions: [
                { text: "яндекс путешествия", points: 120, aliases: ["yandex travel"] },
                { text: "яндекс путешествия билеты", points: 110, aliases: ["билеты яндекс"] },
                { text: "яндекс путешествия отели", points: 100, aliases: ["отели яндекс"] },
                { text: "яндекс путешествия карта", points: 95, aliases: ["карта яндекс путешествия"] },
                { text: "яндекс путешествия страховка", points: 90, aliases: ["страховка в путешествии"] },
                { text: "яндекс путешествия отзывы", points: 85, aliases: ["отзывы яндекс путешествия"] }
            ],
            hints: [
                "Сконцентрируйтесь на сервисах бронирования и планирования поездок.",
                "Не забудьте про отели, билеты и страховку."
            ]
        },
        {
            prompt: "Как вы оптимизируете рабочий день через Яндекс?",
            category: "Работа",
            suggestions: [
                { text: "яндекс 360", points: 120, aliases: ["yandex 360"] },
                { text: "яндекс диск", points: 110, aliases: ["yandex disk"] },
                { text: "яндекс почта", points: 100, aliases: ["yandex mail"] },
                { text: "яндекс календари", points: 95, aliases: ["календарь яндекс"] },
                { text: "яндекс трекер", points: 90, aliases: ["tracker yandex"] },
                { text: "яндекс коннект", points: 85, aliases: ["yandex connect"] }
            ],
            hints: [
                "Вспомните корпоративные сервисы Яндекса.",
                "Подумайте о почте, календарях и хранении данных."
            ]
        },
        {
            prompt: "Как вы исследуете город с Яндексом?",
            category: "Город",
            suggestions: [
                { text: "яндекс карты", points: 120, aliases: ["yandex maps", "карты яндекс"] },
                { text: "яндекс карты пробки", points: 110, aliases: ["пробки яндекс"] },
                { text: "яндекс карты построить маршрут", points: 100, aliases: ["маршрут яндекс"] },
                { text: "яндекс карты панорамы", points: 95, aliases: ["панорамы яндекс"] },
                { text: "яндекс карты отзывы", points: 90, aliases: ["отзывы места яндекс"] },
                { text: "яндекс карты метро", points: 85, aliases: ["метро яндекс"] }
            ],
            hints: [
                "Сервис для навигации и транспорта.",
                "Протестируйте слова «пробки», «маршрут», «панорамы»."
            ]
        },
        {
            prompt: "Как вы пользуетесь умной колонкой Яндекса?",
            category: "Смарт-устройства",
            suggestions: [
                { text: "яндекс станция", points: 120, aliases: ["yandex station"] },
                { text: "яндекс станция алиса", points: 110, aliases: ["станция алиса"] },
                { text: "яндекс станция настройка", points: 100, aliases: ["настройка станции"] },
                { text: "яндекс станция музыка", points: 95, aliases: ["музыка на станции"] },
                { text: "яндекс станция управление домом", points: 90, aliases: ["умный дом яндекс"] },
                { text: "яндекс станция подписка плюс", points: 85, aliases: ["подписка плюс станция"] }
            ],
            hints: [
                "Речь про умное устройство Яндекса.",
                "Сфокусируйтесь на голосовом помощнике и умном доме."
            ]
        }
    ];

    const leaderboardKey = "ikvy-leaderboard";

    function normalizeString(input) {
        return input
            .toString()
            .trim()
            .toLowerCase()
            .replace(/\s+/g, " ")
            .replace(/ё/g, "е");
    }

    function formatTime(seconds) {
        const safe = Math.max(0, seconds);
        const m = Math.floor(safe / 60);
        const s = safe % 60;
        return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
    }

    function pickDataset(previous) {
        if (!suggestionLibrary.length) {
            return null;
        }
        let index = Math.floor(Math.random() * suggestionLibrary.length);
        if (typeof previous === "number" && suggestionLibrary.length > 1) {
            while (index === previous) {
                index = Math.floor(Math.random() * suggestionLibrary.length);
            }
        }
        return { data: suggestionLibrary[index], index };
    }

    function deepCopyDataset(dataset) {
        return {
            prompt: dataset.prompt,
            category: dataset.category,
            hints: Array.isArray(dataset.hints) ? [...dataset.hints] : [],
            suggestions: dataset.suggestions.map(item => ({
                text: item.text,
                points: item.points,
                aliases: item.aliases ? [...item.aliases] : [],
                found: false,
                foundAt: null
            }))
        };
    }

    function logEvent(logEl, message, type = "system") {
        if (!logEl) return;
        const entry = document.createElement("span");
        entry.dataset.type = type;
        entry.textContent = message;
        logEl.appendChild(entry);
        logEl.scrollTop = logEl.scrollHeight;
    }

    function loadLeaderboard() {
        try {
            const raw = localStorage.getItem(leaderboardKey);
            if (!raw) return [];
            const parsed = JSON.parse(raw);
            return Array.isArray(parsed) ? parsed : [];
        } catch (err) {
            console.warn("Не удалось загрузить лидерборд", err);
            return [];
        }
    }

    function saveLeaderboard(entries) {
        try {
            localStorage.setItem(leaderboardKey, JSON.stringify(entries.slice(0, 20)));
        } catch (err) {
            console.warn("Не удалось сохранить лидерборд", err);
        }
    }

    function updateLeaderboardTable(root, entries) {
        if (!root) {
            return;
        }
        const tbody = root.querySelector("[data-leaderboard-body]");
        if (!tbody) {
            return;
        }
        tbody.innerHTML = "";
        if (!entries.length) {
            const row = document.createElement("tr");
            row.className = "empty-row";
            const cell = document.createElement("td");
            cell.colSpan = 5;
            cell.textContent = "Лидерборд пока пуст. Сыграйте, чтобы открыть список.";
            row.appendChild(cell);
            tbody.appendChild(row);
            return;
        }
        entries.forEach((entry, index) => {
            const row = document.createElement("tr");
            const date = new Date(entry.timestamp);
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${entry.name}</td>
                <td>${entry.score}</td>
                <td>${entry.difficultyTitle}</td>
                <td>${date.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" })}</td>
            `;
            tbody.appendChild(row);
        });
    }

    function persistScore(score, name, difficultyKey) {
        const entries = loadLeaderboard();
        const diff = difficulties[difficultyKey] || difficulties.normal;
        entries.push({
            score,
            name: name || "Игрок",
            difficulty: difficultyKey,
            difficultyTitle: diff.title,
            timestamp: Date.now()
        });
        entries.sort((a, b) => b.score - a.score);
        saveLeaderboard(entries);
        return entries;
    }

    function attachGame() {
        const root = document.getElementById("gameRoot");
        if (!root) {
            return;
        }

        const promptEl = root.querySelector("[data-prompt]");
        const timerEl = root.querySelector("[data-timer]");
        const scoreEl = root.querySelector("[data-score]");
        const foundEl = root.querySelector("[data-found]");
        const totalEl = root.querySelector("[data-total]");
        const streakEl = root.querySelector("[data-streak]");
        const difficultyLabelEl = root.querySelector("[data-difficulty-label]");
        const hintsLeftEl = root.querySelector("[data-hints-left]");
        const hintBoxEl = root.querySelector("[data-hints]");
        const feedbackEl = root.querySelector("[data-feedback]");
        const answersListEl = root.querySelector("[data-answers-list]");
        const logEl = root.querySelector("[data-log]");
        const startButton = root.querySelector("[data-start]");
        const giveupButton = root.querySelector("[data-giveup]");
        const hintButton = root.querySelector("[data-hint-button]");
        const guessForm = root.querySelector("[data-guess-form]");
        const guessInput = root.querySelector("[data-guess-input]");
        const nameInput = root.querySelector("[data-player-name]");
        const difficultySelect = root.querySelector("[data-difficulty]");
        const leaderboardSection = document.querySelector("[data-leaderboard]");

        updateLeaderboardTable(leaderboardSection, loadLeaderboard());

        function updateStatus() {
            timerEl.textContent = formatTime(state.timer);
            scoreEl.textContent = state.score;
            foundEl.textContent = state.found;
            totalEl.textContent = state.total;
            streakEl.textContent = state.streak;
            const diffConfig = difficulties[state.difficulty] || difficulties.normal;
            difficultyLabelEl.textContent = diffConfig.title;
            hintsLeftEl.textContent = Math.max(0, diffConfig.hintLimit - state.hintsUsed);
        }

        function renderAnswers() {
            answersListEl.innerHTML = "";
            if (!state.dataset) {
                return;
            }
            state.dataset.suggestions.forEach((suggestion, index) => {
                const li = document.createElement("div");
                li.className = `answer-item${suggestion.found ? " found" : ""}`;
                const orderNumber = `${index + 1}.`;
                const label = suggestion.found ? suggestion.text : "•••";
                const pointsText = suggestion.found ? `${suggestion.points} очков` : "";
                li.innerHTML = `<span>${orderNumber} ${label}</span><span>${pointsText}</span>`;
                answersListEl.appendChild(li);
            });
        }

        function revealHint() {
            if (!state.isActive || !state.dataset) {
                return;
            }
            const diffConfig = difficulties[state.difficulty] || difficulties.normal;
            if (state.hintsUsed >= diffConfig.hintLimit) {
                feedbackEl.textContent = "Лимит подсказок исчерпан.";
                feedbackEl.className = "feedback-message error";
                return;
            }
            const hint = state.dataset.hints[state.hintsUsed] || "Больше подсказок нет — полагайтесь на интуицию.";
            state.hintsUsed += 1;
            state.hintMessages.push(`Подсказка ${state.hintsUsed}: ${hint}`);
            hintBoxEl.innerHTML = state.hintMessages.map(text => `<span>${text}</span>`).join("");
            hintsLeftEl.textContent = Math.max(0, diffConfig.hintLimit - state.hintsUsed);
            feedbackEl.textContent = "Подсказка активирована.";
            feedbackEl.className = "feedback-message success";
            logEvent(logEl, `Вы запросили подсказку №${state.hintsUsed}.`, "system");
        }

        function resetUI() {
            state.isActive = false;
            state.score = 0;
            state.found = 0;
            state.streak = 0;
            state.bestStreak = 0;
            state.guesses.clear();
            state.dataset = null;
            state.total = 0;
            state.timer = 0;
            state.hintsUsed = 0;
            state.hintMessages = [];
            feedbackEl.textContent = "Раунд не начат. Нажмите «Запустить раунд».";
            feedbackEl.className = "feedback-message";
            hintBoxEl.innerHTML = "Подсказки появятся по запросу.";
            hintsLeftEl.textContent = "0";
            answersListEl.innerHTML = "";
            promptEl.textContent = "Нажмите «Запустить раунд», чтобы получить первую подсказку.";
            guessInput.value = "";
            guessInput.disabled = true;
            hintButton.disabled = true;
            startButton.disabled = false;
            nameInput.disabled = false;
            difficultySelect.disabled = false;
            updateStatus();
        }

        function endGame(reason) {
            if (!state.isActive) {
                return;
            }
            state.isActive = false;
            clearInterval(state.interval);
            state.interval = null;
            feedbackEl.textContent = `${reason} Итог: ${state.score} очков. Лучший стрик: ${state.bestStreak}.`;
            feedbackEl.className = "feedback-message";
            guessInput.disabled = true;
            hintButton.disabled = true;
            startButton.disabled = false;
            nameInput.disabled = false;
            difficultySelect.disabled = false;
            logEvent(logEl, `Раунд завершён. ${reason}`, "system");
            if (state.found > 0 || state.score > 0) {
                const entries = persistScore(state.score, state.playerName, state.difficulty);
                updateLeaderboardTable(leaderboardSection, entries);
            }
        }

        function tick() {
            if (!state.isActive) {
                return;
            }
            state.timer -= 1;
            if (state.timer <= 0) {
                state.timer = 0;
                updateStatus();
                endGame("Время истекло.");
                return;
            }
            updateStatus();
        }

        function startTimer(duration) {
            clearInterval(state.interval);
            state.timer = duration;
            state.interval = setInterval(tick, 1000);
        }

        function startGame() {
            const name = nameInput.value.trim() || "Игрок";
            const difficultyKey = difficultySelect.value in difficulties ? difficultySelect.value : "normal";
            state.playerName = name;
            state.difficulty = difficultyKey;

            const selection = pickDataset(state.dataset ? state.dataset.index : null);
            state.dataset = deepCopyDataset(selection.data);
            state.dataset.index = selection.index;

            state.total = state.dataset.suggestions.length;
            state.found = 0;
            state.score = 0;
            state.streak = 0;
            state.bestStreak = 0;
            state.guesses.clear();
            state.hintsUsed = 0;
            state.hintMessages = [];
            state.startedAt = Date.now();

            const diffConfig = difficulties[difficultyKey];
            state.timer = diffConfig.duration;

            renderAnswers();
            updateStatus();

            promptEl.textContent = `${state.dataset.prompt}`;
            feedbackEl.textContent = "Раунд начался. Введите первую подсказку!";
            feedbackEl.className = "feedback-message success";

            hintBoxEl.innerHTML = "Подсказки появятся по запросу.";
            hintsLeftEl.textContent = diffConfig.hintLimit;

            guessInput.disabled = false;
            guessInput.value = "";
            guessInput.focus();
            hintButton.disabled = diffConfig.hintLimit === 0;
            startButton.disabled = true;
            nameInput.disabled = true;
            difficultySelect.disabled = true;
            state.isActive = true;

            logEl.innerHTML = "";
            logEvent(logEl, `Запущен раунд: ${state.dataset.category}. Сложность — ${diffConfig.title}.`, "system");

            startTimer(diffConfig.duration);
        }

        function handleGuess(event) {
            event.preventDefault();
            if (!state.isActive || !state.dataset) {
                return;
            }
            const rawGuess = guessInput.value;
            const normalized = normalizeString(rawGuess);
            guessInput.value = "";
            if (!normalized) {
                feedbackEl.textContent = "Введите гипотезу.";
                feedbackEl.className = "feedback-message error";
                return;
            }
            if (state.guesses.has(normalized)) {
                feedbackEl.textContent = "Такой ответ уже был. Попробуйте новое предположение.";
                feedbackEl.className = "feedback-message error";
                logEvent(logEl, `Повтор ответа: «${rawGuess}»`, "error");
                return;
            }
            state.guesses.add(normalized);
            const match = state.dataset.suggestions.find(item => {
                const mainMatch = normalizeString(item.text) === normalized;
                const aliasMatch = Array.isArray(item.aliases) && item.aliases.some(alias => normalizeString(alias) === normalized);
                return (mainMatch || aliasMatch) && !item.found;
            });
            if (match) {
                match.found = true;
                match.foundAt = Date.now();
                state.found += 1;
                state.streak += 1;
                state.bestStreak = Math.max(state.bestStreak, state.streak);
                const diffConfig = difficulties[state.difficulty];
                const base = match.points;
                const streakMultiplier = 1 + Math.min(0.4, (state.streak - 1) * 0.05);
                const earned = Math.round(base * diffConfig.scoreMultiplier * streakMultiplier);
                state.score += earned;
                renderAnswers();
                feedbackEl.textContent = `Отлично! Подсказка «${match.text}» раскрыта. +${earned} очков.`;
                feedbackEl.className = "feedback-message success";
                logEvent(logEl, `Верно: «${match.text}» (+${earned}).`, "success");
                updateStatus();
                if (state.found === state.total) {
                    endGame("Все подсказки открыты!");
                }
            } else {
                const diffConfig = difficulties[state.difficulty];
                state.streak = 0;
                if (state.score > 0) {
                    state.score = Math.max(0, state.score - diffConfig.penalty);
                }
                feedbackEl.textContent = `Нет совпадения. -${diffConfig.penalty} очков.`;
                feedbackEl.className = "feedback-message error";
                logEvent(logEl, `Неверно: «${rawGuess}».`, "error");
                updateStatus();
            }
        }

        resetUI();

        startButton?.addEventListener("click", startGame);
        giveupButton?.addEventListener("click", () => {
            if (state.isActive) {
                endGame("Раунд остановлен вручную.");
            }
        });
        hintButton?.addEventListener("click", revealHint);
        guessForm?.addEventListener("submit", handleGuess);

        document.addEventListener("visibilitychange", () => {
            if (document.hidden && state.isActive) {
                endGame("Вкладка была скрыта. Раунд завершён.");
            }
        });
    }

    function manageNavigation() {
        const navToggle = document.querySelector("[data-nav-toggle]");
        const nav = document.querySelector("[data-main-nav]");
        if (!navToggle || !nav) {
            return;
        }
        navToggle.addEventListener("click", () => {
            const isOpen = nav.classList.toggle("is-open");
            navToggle.setAttribute("aria-expanded", String(isOpen));
        });
        nav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                if (nav.classList.contains("is-open")) {
                    nav.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    function manageCookies() {
        const banner = document.querySelector("[data-cookie-banner]");
        if (!banner) {
            return;
        }
        const acceptBtn = banner.querySelector("[data-cookie-accept]");
        const declineBtn = banner.querySelector("[data-cookie-decline]");

        const storageKey = "ikvy-cookie-consent";

        function hideBanner() {
            banner.classList.remove("show");
        }

        function showBanner() {
            banner.classList.add("show");
        }

        const consent = localStorage.getItem(storageKey);
        if (!consent) {
            setTimeout(showBanner, 600);
        }

        acceptBtn?.addEventListener("click", () => {
            localStorage.setItem(storageKey, "accepted");
            hideBanner();
        });

        declineBtn?.addEventListener("click", () => {
            localStorage.setItem(storageKey, "declined");
            hideBanner();
            localStorage.removeItem(leaderboardKey);
        });
    }

    document.addEventListener("DOMContentLoaded", () => {
        manageNavigation();
        manageCookies();
        attachGame();
    });
})();