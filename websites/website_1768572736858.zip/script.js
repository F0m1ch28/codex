document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.site-nav a');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            navToggle.classList.toggle('open');
            siteNav.classList.toggle('active');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (siteNav.classList.contains('active')) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    navToggle.classList.remove('open');
                    siteNav.classList.remove('active');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptButton = document.getElementById('cookieAccept');
    const declineButton = document.getElementById('cookieDecline');
    const cookieStatus = localStorage.getItem('occupitekt_cookie_choice');

    if (cookieBanner) {
        if (!cookieStatus) {
            cookieBanner.classList.add('active');
        }

        const handleDecision = (value) => {
            localStorage.setItem('occupitekt_cookie_choice', value);
            cookieBanner.classList.remove('active');
        };

        if (acceptButton) {
            acceptButton.addEventListener('click', () => handleDecision('accepted'));
        }

        if (declineButton) {
            declineButton.addEventListener('click', () => handleDecision('declined'));
        }
    }
});