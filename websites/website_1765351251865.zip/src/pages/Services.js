import React from 'react';
import styles from './Services.module.css';

const services = [
  {
    title: 'YouTube-обложки под ключ',
    description: 'Комплект статичных или анимированных обложек для вашего канала с учётом рубрик и плейлистов.',
    image: 'https://picsum.photos/900/700?random=101',
    items: ['Анализ ниши и конкурентов', '3 концепции на выбор', 'Гайд по визуальному стилю'],
  },
  {
    title: 'Брендинг для стримеров',
    description: 'Полный набор графики для Twitch и других платформ: аватар, баннеры, экран заставки.',
    image: 'https://picsum.photos/900/700?random=102',
    items: ['Пакет экранов', 'Анимации', 'Единая цветовая система'],
  },
  {
    title: 'Аватарки и логотипы',
    description: 'Индивидуальные иллюстрации и монограммы, которые масштабируются без потери качества.',
    image: 'https://picsum.photos/900/700?random=103',
    items: ['3 стилистических направления', 'Версии для темной/светлой темы', 'Favicon и адаптивные версии'],
  },
  {
    title: 'Оформление подкастов',
    description: 'Обложки для выпусков, баннеры и графика для соцсетей под ваш подкаст.',
    image: 'https://picsum.photos/900/700?random=104',
    items: ['Серия обложек', 'Шаблон для Reels/Shorts', 'Готовые файлы для площадок'],
  },
];

const ServicesPage = () => {
  React.useEffect(() => {
    document.title = 'Услуги | DigitalCovers';
  }, []);

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <h1>Услуги DigitalCovers</h1>
        <p>
          Мы делаем так, чтобы визуальная айдентика вашего проекта работала на узнаваемость и рост аудитории. Выбирайте готовые пакеты или
          собирайте индивидуальное решение вместе с нашими дизайнерами.
        </p>
      </section>

      <section className={styles.grid}>
        {services.map((service) => (
          <article key={service.title} className={styles.card}>
            <img src={service.image} alt={service.title} loading="lazy" />
            <div className={styles.body}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <ul>
                {service.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.banner}>
        <div className={styles.bannerContent}>
          <h2>Индивидуально под ваш стиль</h2>
          <p>
            Расскажите о проекте, и мы подготовим moodboard, визуальные референсы и дорожную карту с этапами и сроками, чтобы вы точно знали, что получаете.
          </p>
        </div>
        <div className={styles.bannerBadge}>24/7 поддержка</div>
      </section>
    </div>
  );
};

export default ServicesPage;