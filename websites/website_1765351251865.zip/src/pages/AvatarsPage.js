import React from 'react';
import styles from './AvatarsPage.module.css';

const avatars = [
  {
    title: 'Неоновый персонаж',
    description: 'Выразительная иллюстрация для стримеров и киберкоманд. Энергичная палитра и баланс света.',
    image: 'https://picsum.photos/800/800?random=81',
  },
  {
    title: 'Минималистичный монограмма',
    description: 'Графичный логотип для личного бренда или консультационных услуг. Чистые линии и сильный силуэт.',
    image: 'https://picsum.photos/800/800?random=82',
  },
  {
    title: 'Иллюстративный портрет',
    description: 'Стильный портрет с акцентом на эмоции и характер. Подходит для подкастеров и ведущих.',
    image: 'https://picsum.photos/800/800?random=83',
  },
  {
    title: '3D-аватар',
    description: 'Объёмный персонаж в стилистике метавселенных. Используем модели с высоким качеством рендера.',
    image: 'https://picsum.photos/800/800?random=84',
  },
];

const AvatarsPage = () => {
  React.useEffect(() => {
    document.title = 'Аватарки и профили | DigitalCovers';
  }, []);

  return (
    <div className={styles.page}>
      <header className={styles.hero}>
        <h1>Аватарки и логотипы</h1>
        <p>
          Сформируйте мгновенное узнавание в соцсетях. Мы создаём аватарки, которые одинаково хорошо выглядят на мобильных и десктопах,
          сохраняя читабельность даже в маленьких размерах.
        </p>
      </header>

      <section className={styles.grid}>
        {avatars.map((avatar) => (
          <article key={avatar.title} className={styles.card}>
            <img src={avatar.image} alt={avatar.title} loading="lazy" />
            <div className={styles.body}>
              <h2>{avatar.title}</h2>
              <p>{avatar.description}</p>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.highlight}>
        <h2>Ценности дизайна</h2>
        <p>
          Мы учитываем читаемость, адаптацию под темные и светлые темы, а также подготавливаем версии для сторис, превью и анимации.
        </p>
      </section>
    </div>
  );
};

export default AvatarsPage;