import React from 'react';
import styles from './About.module.css';

const timeline = [
  { year: '2018', text: 'Команда дизайнеров и motion-художников объединилась для работы над первыми YouTube-каналами.' },
  { year: '2020', text: 'Запустили DigitalCovers и создали более 500 кастомных обложек и аватарок.' },
  { year: '2022', text: 'Расширили команду, добавили аналитиков для исследования трендов и UX-команду.' },
  { year: '2024', text: 'Вышли на международный рынок, сотрудничаем с агентствами и брендами из Европы и Азии.' },
];

const team = [
  { name: 'Ксения Лебедева', role: 'Арт-директор', image: 'https://picsum.photos/400/400?random=91' },
  { name: 'Роман Григорьев', role: 'Ведущий дизайнер', image: 'https://picsum.photos/400/400?random=92' },
  { name: 'Светлана Орлова', role: 'Motion-дизайнер', image: 'https://picsum.photos/400/400?random=93' },
  { name: 'Егор Дмитриев', role: 'Аналитик трендов', image: 'https://picsum.photos/400/400?random=94' },
];

const AboutPage = () => {
  React.useEffect(() => {
    document.title = 'О нас | DigitalCovers';
  }, []);

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <h1>Мы строим визуальные бренды для креаторов</h1>
        <p>
          DigitalCovers — команда дизайнеров, аналитиков и иллюстраторов, увлечённых развитием цифрового контента. Наша миссия —
          помогать создателям выделяться и рассказывать истории через визуал.
        </p>
      </section>

      <section className={styles.values}>
        <article>
          <h2>Фокус на эффект</h2>
          <p>
            Мы измеряем успех не только красотой. CTR, среднее время просмотра и конверсии в подписку — ключевые метрики, которые
            лежат в основе каждого решения.
          </p>
        </article>
        <article>
          <h2>Коллаборация</h2>
          <p>
            Мы открыто делимся мнениями, проводим воркшопы с клиентами и создаём открытую среду для экспериментов.
          </p>
        </article>
        <article>
          <h2>Дизайн-система</h2>
          <p>
            Работая над каналом или брендом, мы создаём целостную систему графики, чтобы каждый элемент поддерживал общее настроение.
          </p>
        </article>
      </section>

      <section className={styles.timeline}>
        <h2>Наш путь</h2>
        <div className={styles.timelineList}>
          {timeline.map((item) => (
            <div key={item.year} className={styles.timelineItem}>
              <span className={styles.timelineYear}>{item.year}</span>
              <p>{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.team}>
        <h2>Команда</h2>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={member.name} loading="lazy" />
              <div className={styles.teamBody}>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default AboutPage;