import React from 'react';
import styles from './Contact.module.css';

const ContactsPage = () => {
  const [formData, setFormData] = React.useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  React.useEffect(() => {
    document.title = 'Контакты | DigitalCovers';
  }, []);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Введите имя';
    if (!formData.email.trim()) {
      newErrors.email = 'Введите email';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Некорректный email';
    }
    if (!formData.message.trim()) newErrors.message = 'Опишите задачу или вопрос';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setFormData({ name: '', email: '', message: '' });
    }
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <h1>Связаться с DigitalCovers</h1>
        <p>Опишите свою задачу, отправьте ссылки на канал или референсы — мы подготовим персональное предложение и сроки.</p>
      </section>

      <section className={styles.grid}>
        <div className={styles.formWrapper}>
          <h2>Напишите нам</h2>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <label className={styles.field}>
              <span>Имя</span>
              <input
                type="text"
                name="name"
                placeholder="Как к вам обращаться"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </label>
            <label className={styles.field}>
              <span>Email</span>
              <input
                type="email"
                name="email"
                placeholder="name@example.com"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </label>
            <label className={styles.field}>
              <span>Сообщение</span>
              <textarea
                name="message"
                placeholder="Расскажите о проекте, платформах и ожиданиях"
                rows={5}
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </label>
            <button type="submit" className={styles.submitButton}>
              Отправить запрос
            </button>
            {submitted && <p className={styles.success}>Спасибо! Мы свяжемся с вами в ближайшее время.</p>}
          </form>
        </div>
        <aside className={styles.info}>
          <h2>Как мы работаем</h2>
          <ul>
            <li>
              <strong>1. Брифинг. </strong>
              Обсуждаем ваши цели, аудиторию и предпочтения по визуалу.
            </li>
            <li>
              <strong>2. Концепции. </strong>
              Подготавливаем moodboard и отправляем предварительные варианты.
            </li>
            <li>
              <strong>3. Финал. </strong>
              После согласования доставляем финальные файлы и инструкции.
            </li>
          </ul>
          <div className={styles.contactDetails}>
            <p><strong>Email:</strong> <a href="mailto:support@digitalcovers.example.com">support@digitalcovers.example.com</a></p>
            <p><strong>Адрес:</strong> Цифровые товары, доставляемые онлайн</p>
            <p><strong>Работаем:</strong> Пн-Вс, 09:00 — 22:00 (UTC+3)</p>
          </div>
        </aside>
      </section>
    </div>
  );
};

export default ContactsPage;