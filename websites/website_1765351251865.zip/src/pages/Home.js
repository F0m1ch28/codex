import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './Home.module.css';

const HomePage = () => {
  const navigate = useNavigate();
  const stats = [
    { label: 'Уникальных дизайнов создано', value: 1250 },
    { label: 'Довольных проектов ежемесячно', value: 180 },
    { label: 'Среднее время доставки (часов)', value: 2 },
  ];
  const [displayStats, setDisplayStats] = React.useState(stats.map(() => 0));

  React.useEffect(() => {
    const intervals = stats.map((stat, index) => {
      const target = stat.value;
      const duration = 1200;
      const frameRate = 16;
      const totalFrames = duration / frameRate;
      const increment = target / totalFrames;
      return setInterval(() => {
        setDisplayStats((prev) => {
          const next = [...prev];
          next[index] = Math.min(target, Math.round(next[index] + increment));
          return next;
        });
      }, frameRate);
    });
    return () => intervals.forEach(clearInterval);
  }, []);

  const categories = [
    {
      title: 'Обложки для видео',
      description: 'Создаём эффектные превью для YouTube и других видеоплатформ, которые привлекают внимание с первой секунды.',
      image: 'https://picsum.photos/800/600?random=12',
      link: '/video-covers',
    },
    {
      title: 'Аватарки и логотипы',
      description: 'Профессиональные аватарки и лого для стримеров, брендов и креаторов. Запоминайтесь с первого взгляда.',
      image: 'https://picsum.photos/800/600?random=14',
      link: '/avatars',
    },
  ];

  const popularProducts = [
    {
      title: 'Контрастная обложка для tech-канала',
      image: 'https://picsum.photos/800/600?random=21',
      tags: ['YouTube', 'Технологии'],
    },
    {
      title: 'Геймерская обложка с неоном',
      image: 'https://picsum.photos/800/600?random=22',
      tags: ['Twitch', 'Киберспорт'],
    },
    {
      title: 'Минималистичная обложка для влогов',
      image: 'https://picsum.photos/800/600?random=23',
      tags: ['YouTube', 'Lifestyle'],
    },
    {
      title: 'Смелый баннер для подкаста',
      image: 'https://picsum.photos/800/600?random=24',
      tags: ['Spotify', 'Подкасты'],
    },
  ];

  const processSteps = [
    { title: 'Выберите стиль', description: 'Просмотрите каталог, отфильтруйте по нише или настроению и выберите понравившийся дизайн.' },
    { title: 'Настройте детали', description: 'Передайте нам необходимые тексты, изображения или пожелания по цветовой палитре.' },
    { title: 'Получите мгновенно', description: 'После оплаты мы отправим готовые файлы в высоком разрешении на вашу почту.' },
    { title: 'Поддержка', description: 'Оперативно внесём мелкие правки и поможем адаптировать дизайн под другие форматы.' },
  ];

  const advantages = [
    { title: 'Высокое качество', description: 'Каждый дизайн проходит тщательную проверку качества, чтобы выглядеть идеально на всех устройствах.' },
    { title: 'Уникальные стилы', description: 'Мы изучаем ваш бренд, чтобы создать визуально запоминающийся стиль без шаблонов.' },
    { title: 'Скорость доставки', description: 'Большинство проектов готово в течение нескольких часов после согласования деталей.' },
    { title: 'Поддержка 24/7', description: 'Команда поддержки отвечает на запросы и сопровождает вас на каждом шаге сотрудничества.' },
  ];

  const testimonials = [
    {
      name: 'Алексей Новиков',
      role: 'YouTube-блогер, 450K подписчиков',
      quote: 'DigitalCovers спасли мой канал. CTR вырос почти вдвое благодаря новым обложкам. Работаем уже третий месяц и впечатления только положительные.',
      image: 'https://picsum.photos/200/200?random=31',
    },
    {
      name: 'Мария Нефедова',
      role: 'PR-менеджер стриминговой студии',
      quote: 'Аватарки и баннеры оформлены настолько гармонично, что наши соцсети наконец выглядят единообразно. Очень внимательные дизайнеры.',
      image: 'https://picsum.photos/200/200?random=32',
    },
    {
      name: 'Игорь Котов',
      role: 'Создатель подкаста «Голос цифры»',
      quote: 'Удобно, что можно заказать серию обложек сразу. Получили полный пакет с макетами и инструкцией по стилю. Рекомендую.',
      image: 'https://picsum.photos/200/200?random=33',
    },
  ];

  const [currentTestimonial, setCurrentTestimonial] = React.useState(0);
  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const projects = [
    {
      title: 'Серия обложек для игрового стриминга',
      category: 'video',
      image: 'https://picsum.photos/1200/800?random=41',
    },
    {
      title: 'Айдентика для нового подкаста',
      category: 'branding',
      image: 'https://picsum.photos/1200/800?random=42',
    },
    {
      title: 'Аватарки команды киберспорта',
      category: 'avatar',
      image: 'https://picsum.photos/1200/800?random=43',
    },
    {
      title: 'Обновление YouTube-канала про дизайн',
      category: 'video',
      image: 'https://picsum.photos/1200/800?random=44',
    },
  ];
  const [filter, setFilter] = React.useState('all');

  const filteredProjects = filter === 'all' ? projects : projects.filter((project) => project.category === filter);

  const faq = [
    {
      question: 'Сколько времени занимает создание обложки?',
      answer:
        'Среднее время подготовки — от 2 до 6 часов после получения всех материалов. Комплексные проекты с сериями из 5-10 обложек занимают до двух дней.',
    },
    {
      question: 'Можно ли внести правки после получения дизайна?',
      answer:
        'Конечно. Мы предоставляем до двух раундов правок бесплатно. Они включают уточнение текстов, замену фотографий и корректировку цветовой палитры.',
    },
    {
      question: 'В каких форматах вы передаёте файлы?',
      answer:
        'Доставляем готовые дизайны в JPEG/PNG для публикации, а также PSD или Figma-ссылку по запросу, чтобы вы могли адаптировать их в будущем.',
    },
    {
      question: 'Работаете ли вы с брендами и агентствами?',
      answer:
        'Да, мы обслуживаем креативные агентства и крупные бренды. Предложим white-label сотрудничество и выделенную команду дизайнеров.',
    },
  ];
  const [openFaq, setOpenFaq] = React.useState(0);

  const blogPosts = [
    {
      title: 'Как повысить CTR на YouTube с помощью визуала',
      link: '/blog/ctr-youtube',
      image: 'https://picsum.photos/800/600?random=51',
      date: '12 марта 2024',
      excerpt: 'Технические и эмоциональные триггеры, которые помогут выделить ваш ролик из сотен похожих в выдаче.',
    },
    {
      title: 'Создаём узнаваемый стиль канала с обложками-сериями',
      link: '/blog/series-style',
      image: 'https://picsum.photos/800/600?random=52',
      date: '27 февраля 2024',
      excerpt: 'Рассказываем, как выстроить систему визуальных паттернов для регулярных рубрик и плейлистов.',
    },
    {
      title: 'Аватарка для стримера: 5 ошибок, которых стоит избегать',
      link: '/blog/avatar-mistakes',
      image: 'https://picsum.photos/800/600?random=53',
      date: '15 февраля 2024',
      excerpt: 'Практические советы по типографике, цвету и композиции, которые сделают ваш профиль заметным.',
    },
  ];

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.heroBadge}>Графика для создателей контента</span>
          <h1 className={styles.heroTitle}>
            Профессиональные обложки и аватарки,
            <span className={styles.heroHighlight}> которые визуально усиливают ваши истории</span>
          </h1>
          <p className={styles.heroSubtitle}>
            DigitalCovers создаёт яркие превью, баннеры и аватарки, которые помогают выделиться на YouTube, Twitch, Spotify и в соцсетях.
            Визуальный стиль, выстроенный на данных и эстетике.
          </p>
          <div className={styles.heroActions}>
            <button
              type="button"
              className={styles.primaryButton}
              onClick={() => navigate('/video-covers')}
            >
              Смотреть каталог
            </button>
            <Link to="/services" className={styles.secondaryButton}>
              Все услуги
            </Link>
          </div>
          <ul className={styles.heroStats} aria-label="Ключевые показатели">
            {stats.map((stat, index) => (
              <li key={stat.label} className={styles.heroStat}>
                <span className={styles.heroStatValue}>{displayStats[index]}+</span>
                <span className={styles.heroStatLabel}>{stat.label}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className={styles.heroVisual} aria-hidden="true">
          <div className={styles.heroImageWrapper}>
            <img
              src="https://picsum.photos/960/960?random=11"
              alt="Современный цифровой дизайн обложки"
              className={styles.heroImage}
              loading="lazy"
            />
            <div className={styles.heroOverlayCard}>
              <p className={styles.overlayTitle}>Мгновенная доставка</p>
              <p className={styles.overlayText}>Файлы в 4K, адаптированные для разных платформ и устройств.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.categories} id="catalog">
        <div className={styles.sectionHeading}>
          <h2>Категории, которые любят зрители</h2>
          <p>Найдем точное визуальное решение для вашего канала, бренда или личного проекта.</p>
        </div>
        <div className={styles.categoryGrid}>
          {categories.map((category) => (
            <article key={category.title} className={styles.categoryCard}>
              <img src={category.image} alt={category.title} className={styles.categoryImage} loading="lazy" />
              <div className={styles.categoryBody}>
                <h3>{category.title}</h3>
                <p>{category.description}</p>
                <Link to={category.link} className={styles.cardLink}>
                  Перейти к примерам →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.popular}>
        <div className={styles.sectionHeading}>
          <h2>Популярные новинки</h2>
          <p>Свежие дизайны, созданные на основе актуальных трендов и аналитики ваших ниш.</p>
        </div>
        <div className={styles.popularGrid}>
          {popularProducts.map((product) => (
            <article key={product.title} className={styles.popularCard}>
              <div className={styles.popularImageWrapper}>
                <img src={product.image} alt={product.title} loading="lazy" />
              </div>
              <div className={styles.popularBody}>
                <h3>{product.title}</h3>
                <ul className={styles.tagList}>
                  {product.tags.map((tag) => (
                    <li key={tag} className={styles.tag}>{tag}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeading}>
          <h2>Как это работает</h2>
          <p>Прозрачный процесс, который экономит ваше время и даёт предсказуемый результат.</p>
        </div>
        <ol className={styles.processGrid}>
          {processSteps.map((step, index) => (
            <li key={step.title} className={styles.processCard}>
              <span className={styles.stepNumber}>{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className={styles.advantages}>
        <div className={styles.sectionHeading}>
          <h2>Почему DigitalCovers</h2>
          <p>Каждый элемент выверен: от типографики до адаптации под разные экраны.</p>
        </div>
        <div className={styles.advantagesGrid}>
          {advantages.map((advantage) => (
            <article key={advantage.title} className={styles.advantageCard}>
              <h3>{advantage.title}</h3>
              <p>{advantage.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeading}>
          <h2>Отзывы клиентов</h2>
          <p>Опыт креаторов и команд, с которыми мы строим визуальную коммуникацию.</p>
        </div>
        <div className={styles.testimonialCarousel}>
          <button
            type="button"
            className={styles.carouselControl}
            onClick={() =>
              setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)
            }
            aria-label="Предыдущий отзыв"
          >
            ←
          </button>
          <div className={styles.testimonialCard}>
            <img
              src={testimonials[currentTestimonial].image}
              alt={testimonials[currentTestimonial].name}
              className={styles.testimonialImage}
              loading="lazy"
            />
            <blockquote className={styles.testimonialQuote}>
              “{testimonials[currentTestimonial].quote}”
            </blockquote>
            <p className={styles.testimonialName}>{testimonials[currentTestimonial].name}</p>
            <p className={styles.testimonialRole}>{testimonials[currentTestimonial].role}</p>
          </div>
          <button
            type="button"
            className={styles.carouselControl}
            onClick={() =>
              setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
            }
            aria-label="Следующий отзыв"
          >
            →
          </button>
        </div>
        <div className={styles.carouselDots} role="tablist" aria-label="Переключение отзывов">
          {testimonials.map((_, index) => (
            <button
              key={index}
              type="button"
              className={`${styles.dot} ${currentTestimonial === index ? styles.dotActive : ''}`}
              onClick={() => setCurrentTestimonial(index)}
              aria-label={`Показать отзыв ${index + 1}`}
              aria-pressed={currentTestimonial === index}
            />
          ))}
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.sectionHeading}>
          <h2>Недавние проекты</h2>
          <p>Графика, которая помогает брендам и личным каналам рассказывать свою историю.</p>
        </div>
        <div className={styles.filterBar} role="tablist" aria-label="Фильтр проектов">
          <button
            type="button"
            className={`${styles.filterButton} ${filter === 'all' ? styles.filterActive : ''}`}
            onClick={() => setFilter('all')}
          >
            Все
          </button>
          <button
            type="button"
            className={`${styles.filterButton} ${filter === 'video' ? styles.filterActive : ''}`}
            onClick={() => setFilter('video')}
          >
            Обложки
          </button>
          <button
            type="button"
            className={`${styles.filterButton} ${filter === 'avatar' ? styles.filterActive : ''}`}
            onClick={() => setFilter('avatar')}
          >
            Аватарки
          </button>
          <button
            type="button"
            className={`${styles.filterButton} ${filter === 'branding' ? styles.filterActive : ''}`}
            onClick={() => setFilter('branding')}
          >
            Айдентика
          </button>
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <img src={project.image} alt={project.title} loading="lazy" />
              <div className={styles.projectBody}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <Link to="/services" className={styles.cardLink}>
                  Подробнее о проекте →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.sectionHeading}>
          <h2>Вопросы и ответы</h2>
          <p>Если не нашли нужную информацию — напишите нам, мы ответим в течение часа.</p>
        </div>
        <div className={styles.accordion}>
          {faq.map((item, index) => (
            <div key={item.question} className={styles.accordionItem}>
              <button
                type="button"
                className={styles.accordionButton}
                onClick={() => setOpenFaq((prev) => (prev === index ? -1 : index))}
                aria-expanded={openFaq === index}
              >
                <span>{item.question}</span>
                <span className={styles.accordionIcon}>{openFaq === index ? '−' : '+'}</span>
              </button>
              <div
                className={`${styles.accordionPanel} ${openFaq === index ? styles.accordionPanelOpen : ''}`}
              >
                <p>{item.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blog}>
        <div className={styles.sectionHeading}>
          <h2>Гид по визуальному брендингу</h2>
          <p>Экспертные материалы для создателей контента и маркетинговых команд.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <img src={post.image} alt={post.title} loading="lazy" />
              <div className={styles.blogBody}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.cardLink}>
                  Читать статью →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Готовы обновить визуал?</h2>
          <p>
            Оставьте заявку и получите подборку дизайнов, адаптированных под вашу нишу и стиль. Начните повышать вовлечённость
            аудитории прямо сейчас.
          </p>
          <div className={styles.ctaActions}>
            <button
              type="button"
              className={styles.primaryButton}
              onClick={() => navigate('/contacts')}
            >
              Связаться с нами
            </button>
            <Link to="/video-covers" className={styles.secondaryButton}>
              Каталог обложек
            </Link>
          </div>
        </div>
        <div className={styles.ctaVisual} aria-hidden="true">
          <img
            src="https://picsum.photos/1000/760?random=61"
            alt="Современный пример цифровой графики"
            loading="lazy"
          />
        </div>
      </section>
    </div>
  );
};

export default HomePage;