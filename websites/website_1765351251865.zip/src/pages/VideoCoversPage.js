import React from 'react';
import styles from './VideoCoversPage.module.css';

const videoCovers = [
  {
    title: 'Технологичный обзор',
    description: 'Лаконичная композиция с акцентом на продукт и ярким заголовком, который заметен на YouTube-лентах.',
    image: 'https://picsum.photos/900/600?random=71',
    features: ['Контрастный заголовок', 'Место под логотип', '4K разрешение'],
  },
  {
    title: 'Gaming Highlight',
    description: 'Взрывная неоновая палитра, динамический фон и яркая типографика для стриминговых записей.',
    image: 'https://picsum.photos/900/600?random=72',
    features: ['Неоновые акценты', 'Фокус на персонаже', 'Готово под Twitch'],
  },
  {
    title: 'Lifestyle влог',
    description: 'Теплые тона, мягкие градиенты и акцент на эмоциях. Подходит для travel и lifestyle каналов.',
    image: 'https://picsum.photos/900/600?random=73',
    features: ['Градиенты', 'Наглядные подписи', 'Минимализм'],
  },
  {
    title: 'Экспертный разбор',
    description: 'Чистая сетка, структурированные блоки и место для инфографики. Отлично для образовательного контента.',
    image: 'https://picsum.photos/900/600?random=74',
    features: ['Инфографика', 'Строгий стиль', 'Figma-шаблон'],
  },
];

const VideoCoversPage = () => {
  React.useEffect(() => {
    document.title = 'Обложки для видео | DigitalCovers';
  }, []);

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div>
          <h1>Обложки для видео</h1>
          <p>
            Мы создаём визуальные решения, которые повышают CTR и делают ваш контент узнаваемым. Каждая обложка адаптируется под
            специфику платформы и предпочтения аудитории.
          </p>
        </div>
      </section>

      <section className={styles.grid}>
        {videoCovers.map((cover) => (
          <article key={cover.title} className={styles.card}>
            <div className={styles.imageWrapper}>
              <img src={cover.image} alt={cover.title} loading="lazy" />
            </div>
            <div className={styles.body}>
              <h2>{cover.title}</h2>
              <p>{cover.description}</p>
              <ul>
                {cover.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.info}>
        <h2>Что вы получаете</h2>
        <ul className={styles.featuresList}>
          <li>Предпросмотры в нескольких цветовых вариантах</li>
          <li>Файлы для YouTube, TikTok, VK и кастомных плееров</li>
          <li>Итоговую композицию в 4K + PSD/PNG</li>
        </ul>
      </section>
    </div>
  );
};

export default VideoCoversPage;