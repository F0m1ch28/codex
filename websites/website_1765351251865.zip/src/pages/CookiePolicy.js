import React from 'react';
import styles from './CookiePolicy.module.css';

const CookiePolicyPage = () => {
  React.useEffect(() => {
    document.title = 'Политика использования cookies | DigitalCovers';
  }, []);

  return (
    <div className={styles.page}>
      <h1>Политика использования cookies</h1>
      <p>Последнее обновление: 1 марта 2024 года</p>
      <section>
        <h2>1. Что такое cookies</h2>
        <p>Cookies — это небольшие файлы, которые сохраняются в вашем браузере для обеспечения корректной работы сайта.</p>
      </section>
      <section>
        <h2>2. Зачем мы используем cookies</h2>
        <p>Мы применяем cookies для аналитики, персонализации контента и запоминания ваших предпочтений.</p>
      </section>
      <section>
        <h2>3. Управление cookies</h2>
        <p>Вы можете изменить настройки cookies в браузере. Учтите, что некоторые разделы сайта могут работать некорректно.</p>
      </section>
      <section>
        <h2>4. Сторонние сервисы</h2>
        <p>Мы можем использовать аналитические инструменты, которые также создают cookies. Они действуют в соответствии со своими политиками.</p>
      </section>
      <section>
        <h2>5. Контакты</h2>
        <p>Вопросы о cookies направляйте на support@digitalcovers.example.com.</p>
      </section>
    </div>
  );
};

export default CookiePolicyPage;