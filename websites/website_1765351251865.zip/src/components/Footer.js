import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.brand}>
          <span className={styles.logoMark}>DC</span>
          <div>
            <p className={styles.brandName}>DigitalCovers</p>
            <p className={styles.brandTagline}>
              Цифровые графические решения для контент-креаторов и брендов.
            </p>
          </div>
        </div>
        <div className={styles.grid}>
          <div>
            <h3 className={styles.heading}>Навигация</h3>
            <ul className={styles.list}>
              <li><Link to="/" className={styles.link}>Главная</Link></li>
              <li><Link to="/video-covers" className={styles.link}>Обложки для видео</Link></li>
              <li><Link to="/avatars" className={styles.link}>Аватарки</Link></li>
              <li><Link to="/services" className={styles.link}>Все услуги</Link></li>
              <li><Link to="/about" className={styles.link}>О нас</Link></li>
              <li><Link to="/contacts" className={styles.link}>Контакты</Link></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.heading}>Документы</h3>
            <ul className={styles.list}>
              <li><Link to="/terms" className={styles.link}>Условия использования</Link></li>
              <li><Link to="/privacy" className={styles.link}>Политика конфиденциальности</Link></li>
              <li><Link to="/cookie-policy" className={styles.link}>Политика cookies</Link></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.heading}>Контакты</h3>
            <ul className={styles.list}>
              <li className={styles.textItem}>
                Цифровые товары, доставляемые онлайн
              </li>
              <li>
                <a className={styles.link} href="mailto:support@digitalcovers.example.com">
                  support@digitalcovers.example.com
                </a>
              </li>
              <li className={styles.socials}>
                <a className={styles.socialLink} href="https://www.behance.net" target="_blank" rel="noreferrer noopener" aria-label="Behance">
                  Behance
                </a>
                <a className={styles.socialLink} href="https://dribbble.com" target="_blank" rel="noreferrer noopener" aria-label="Dribbble">
                  Dribbble
                </a>
                <a className={styles.socialLink} href="https://www.instagram.com" target="_blank" rel="noreferrer noopener" aria-label="Instagram">
                  Instagram
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className={styles.bottom}>
          <p className={styles.copy}>© {currentYear} DigitalCovers. Все права защищены.</p>
          <p className={styles.signature}>Создано с вниманием к деталям и любви к дизайну.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;