import React from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = window.localStorage.getItem('digitalcovers_cookie_consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('digitalcovers_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <aside className={styles.banner} role="region" aria-label="Уведомление о cookies">
      <div className={styles.content}>
        <p className={styles.text}>
          Мы используем cookies, чтобы анализировать трафик и улучшать качество дизайнов. Продолжая использовать сайт, вы соглашаетесь с
          <a href="/cookie-policy" className={styles.link}> политикой cookies</a>.
        </p>
        <button className={styles.button} type="button" onClick={handleAccept}>
          Принять
        </button>
      </div>
    </aside>
  );
};

export default CookieBanner;