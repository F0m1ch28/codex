import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const Services = () => {
  const services = [
    {
      title: "Стратегический IT-консалтинг",
      description:
        "Комплексные исследования, аудит зрелости и разработка дорожных карт развития цифровой инфраструктуры.",
      points: [
        "Оценка цифровой зрелости и аудит приложений",
        "Оптимизация процессов и автоматизация",
        "Управление портфелем проектов и PMO",
      ],
      image: "https://picsum.photos/seed/techsolutions-consulting/800/520",
    },
    {
      title: "Облачные и платформенные решения",
      description:
        "Проектирование инфраструктуры в облаке, миграция сервисов и сопровождение DevOps-практик.",
      points: [
        "Облачные архитектуры и гибридные модели",
        "Контейнеризация, CI/CD, автоматизация поставок",
        "Мониторинг, FinOps и оптимизация затрат",
      ],
      image: "https://picsum.photos/seed/techsolutions-cloud/800/520",
    },
    {
      title: "Кибербезопасность и управление рисками",
      description:
        "Системы мониторинга угроз, защита данных и реагирование на инциденты на уровне предприятия.",
      points: [
        "SOC, SIEM и непрерывный мониторинг",
        "Управление уязвимостями и тесты на проникновение",
        "Антифрод, IAM и обучение сотрудников",
      ],
      image: "https://picsum.photos/seed/techsolutions-security/800/520",
    },
  ];

  return (
    <>
      <Helmet>
        <title>Услуги TechSolutions Inc.</title>
        <meta
          name="description"
          content="IT консалтинг, облачные решения и кибербезопасность от TechSolutions Inc."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Комплексные услуги для цифровой трансформации</h1>
        <p>
          Мы создаём стратегию, внедряем технологии и поддерживаем организационные изменения,
          чтобы ваша компания достигала целей быстрее.
        </p>
      </section>

      <section className={styles.services}>
        {services.map((service, index) => (
          <article key={service.title} className={styles.card}>
            <div className={styles.image}>
              <img src={service.image} alt={service.title} />
            </div>
            <div className={styles.content}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <ul>
                {service.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.process}>
        <div className={styles.processContent}>
          <h2>Подход к работе</h2>
          <p>
            Каждая инициатива проходит через чётко выстроенный процесс, который помогает быстро достигать результатов и минимизировать риски.
          </p>
          <div className={styles.steps}>
            <div>
              <span>01</span>
              <h3>Диагностика</h3>
              <p>Погружаемся в контекст, проводим интервью и анализ текущих систем.</p>
            </div>
            <div>
              <span>02</span>
              <h3>Проектирование</h3>
              <p>Формируем целевую архитектуру, план внедрения и показатели успеха.</p>
            </div>
            <div>
              <span>03</span>
              <h3>Внедрение</h3>
              <p>Создаём проектную команду, управляем изменениями и обучаем сотрудников.</p>
            </div>
            <div>
              <span>04</span>
              <h3>Сопровождение</h3>
              <p>Поддерживаем системы, анализируем метрики и предлагаем улучшения.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;