import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const About = () => {
  return (
    <>
      <Helmet>
        <title>О компании TechSolutions Inc.</title>
        <meta
          name="description"
          content="Узнайте о миссии, ценностях и команде TechSolutions Inc., ведущего IT-консультанта в России."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>О компании</h1>
          <p>
            TechSolutions Inc. — стратегический партнёр для организаций, стремящихся к инновациям и устойчивому развитию через технологии.
          </p>
        </div>
      </section>

      <section className={styles.story}>
        <div className={styles.text}>
          <h2>История становления</h2>
          <p>
            Компания была основана в 2008 году командой экспертов из телеком и финансового сектора. Мы поставили цель сделать комплексную цифровую трансформацию доступной, понятной и измеримой. От первых проектов по оптимизации инфраструктуры мы выросли до комплекса услуг по разработке стратегии, внедрению технологий и сопровождению изменений.
          </p>
          <p>
            Сегодня TechSolutions Inc. поддерживает организации в России и СНГ, помогая им формировать конкурентоспособные цифровые экосистемы.
          </p>
        </div>
        <div className={styles.image}>
          <img
            src="https://picsum.photos/seed/techsolutions-history/900/600"
            alt="Современный офис TechSolutions Inc."
          />
        </div>
      </section>

      <section className={styles.values}>
        <h2>Наши ценности</h2>
        <div className={styles.valuesGrid}>
          <article>
            <h3>Ответственность</h3>
            <p>
              Берём на себя ответственность за результат и продолжаем работу до тех пор, пока решение не заработает на практике.
            </p>
          </article>
          <article>
            <h3>Партнёрство</h3>
            <p>
              Строим долгосрочные отношения, выстраиваем совместную команду и делимся знаниями, чтобы развитие продолжалось после завершения проекта.
            </p>
          </article>
          <article>
            <h3>Инновации</h3>
            <p>
              Изучаем технологии, проверяем гипотезы и внедряем лучшие практики, сохраняя фокус на бизнес-целях клиента.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.team}>
        <div className={styles.teamContent}>
          <h2>Команда экспертов</h2>
          <p>
            В TechSolutions Inc. работают сертифицированные архитекторы, аналитики, разработчики и специалисты по безопасности. Мы объединяем кросс-функциональные команды, чтобы охватить весь цикл цифровых изменений: от стратегии и проектирования до внедрения и поддержки.
          </p>
        </div>
        <div className={styles.teamCards}>
          <div className={styles.card}>
            <span>40+</span>
            <p>сертификаций ведущих мировых вендоров</p>
          </div>
          <div className={styles.card}>
            <span>6</span>
            <p>отраслевых экспертиз, включая финансы и производство</p>
          </div>
          <div className={styles.card}>
            <span>95%</span>
            <p>клиентов возвращаются с новыми задачами</p>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;