import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

const initialFormState = {
  name: "",
  email: "",
  company: "",
  message: "",
};

const Contact = () => {
  const [form, setForm] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = "Введите имя.";
    if (!form.email.trim()) {
      newErrors.email = "Введите email.";
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(form.email)) {
      newErrors.email = "Введите корректный email.";
    }
    if (!form.message.trim()) newErrors.message = "Опишите запрос.";
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setForm(initialFormState);
  };

  return (
    <>
      <Helmet>
        <title>Контакты TechSolutions Inc.</title>
        <meta
          name="description"
          content="Свяжитесь с TechSolutions Inc. по вопросам IT консалтинга и цифровых проектов."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Свяжитесь с нами</h1>
        <p>
          Расскажите о ваших задачах, и мы предложим оптимальный формат сотрудничества и команду экспертов.
        </p>
      </section>

      <section className={styles.contactSection}>
        <div className={styles.formWrapper}>
          <h2>Заполните форму</h2>
          {submitted && <div className={styles.success}>Спасибо! Мы свяжемся с вами в ближайшее время.</div>}
          <form onSubmit={handleSubmit} noValidate>
            <label>
              Имя*
              <input
                type="text"
                name="name"
                value={form.name}
                onChange={handleChange}
                placeholder="Ваше имя"
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </label>
            <label>
              Email*
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                placeholder="name@company.com"
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </label>
            <label>
              Компания
              <input
                type="text"
                name="company"
                value={form.company}
                onChange={handleChange}
                placeholder="Название компании"
              />
            </label>
            <label>
              Сообщение*
              <textarea
                name="message"
                rows="5"
                value={form.message}
                onChange={handleChange}
                placeholder="Опишите запрос или текущий проект"
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </label>
            <button type="submit">Отправить</button>
          </form>
        </div>
        <div className={styles.contactInfo}>
          <div className={styles.infoCard}>
            <h3>Контактные данные</h3>
            <ul>
              <li>Адрес: ул. Технологическая, 15, Москва, 115280</li>
              <li>Телефон: <a href="tel:+74951234567">+7 (495) 123-45-67</a></li>
              <li>Email: <a href="mailto:info@techsolutions.ru">info@techsolutions.ru</a></li>
            </ul>
          </div>
          <div className={styles.map}>
            <iframe
              title="Офис TechSolutions Inc."
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2245.5604100736484!2d37.67602651592809!3d55.705726980542474!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x414aac8f3573e041%3A0x5948899acc0a2f03!2sUlitsa%20Tekhnologicheskaya%2C%2015%2C%20Moskva%2C%20115280!5e0!3m2!1sen!2sru!4v1700000000000!5m2!1sen!2sru"
              allowFullScreen=""
              loading="lazy"
            ></iframe>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;