import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const Home = () => {
  return (
    <>
      <Helmet>
        <title>TechSolutions Inc. — IT консалтинг и инновации</title>
        <meta
          name="description"
          content="TechSolutions Inc. помогает компаниям внедрять инновационные IT-решения, управлять инфраструктурой и защищать данные."
        />
      </Helmet>
      <section className={styles.hero} id="top">
        <div className={styles.heroContent}>
          <h1>
            IT-консалтинг и цифровые решения для устойчивого роста вашего бизнеса
          </h1>
          <p>
            Мы объединяем стратегию, технологии и экспертизу, чтобы ускорить цифровую трансформацию,
            повысить эффективность процессов и обеспечить безопасность данных.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contact" className={styles.primaryButton}>
              Связаться с командой
            </Link>
            <Link to="/services" className={styles.secondaryButton}>
              Все услуги
            </Link>
          </div>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/seed/techsolutions-hero/900/600"
            alt="Современная IT-команда за работой"
          />
        </div>
      </section>

      <section className={styles.metrics}>
        <div className={styles.metricCard}>
          <span>15+</span>
          <p>лет опыта в цифровой трансформации</p>
        </div>
        <div className={styles.metricCard}>
          <span>120</span>
          <p>завершённых проектов в крупных компаниях</p>
        </div>
        <div className={styles.metricCard}>
          <span>24/7</span>
          <p>поддержка критически важных процессов</p>
        </div>
      </section>

      <section className={styles.services} id="services">
        <div className={styles.sectionHeader}>
          <h2>Ключевые направления</h2>
          <p>
            Мы создаём масштабируемые IT-решения, адаптированные к вашим задачам, и сопровождаем
            внедрение на каждом этапе.
          </p>
        </div>
        <div className={styles.serviceGrid}>
          <article className={styles.serviceCard}>
            <div className={styles.serviceIcon}>🧭</div>
            <h3>IT консалтинг</h3>
            <p>
              Стратегическое планирование, аудит инфраструктуры, дорожные карты цифровой трансформации и управление изменениями.
            </p>
            <Link to="/services" className={styles.cardLink}>
              Подробнее
            </Link>
          </article>
          <article className={styles.serviceCard}>
            <div className={styles.serviceIcon}>☁️</div>
            <h3>Облачные решения</h3>
            <p>
              Архитектура гибридных и публичных облаков, миграция сервисов, оптимизация затрат и DevOps-практики.
            </p>
            <Link to="/services" className={styles.cardLink}>
              Подробнее
            </Link>
          </article>
          <article className={styles.serviceCard}>
            <div className={styles.serviceIcon}>🛡️</div>
            <h3>Кибербезопасность</h3>
            <p>
              Многоуровневая защита данных, управление рисками, SOC-сервисы и непрерывный мониторинг угроз.
            </p>
            <Link to="/services" className={styles.cardLink}>
              Подробнее
            </Link>
          </article>
        </div>
      </section>

      <section className={styles.story}>
        <div className={styles.storyImage}>
          <img
            src="https://picsum.photos/seed/techsolutions-team/900/600"
            alt="Команда TechSolutions Inc. обсуждает проект"
          />
        </div>
        <div className={styles.storyContent}>
          <h2>Мы строим цифровое будущее вместе с вами</h2>
          <p>
            TechSolutions Inc. объединяет инженеров, аналитиков и консультантов, которые помогают
            компаниям уверенно проходить путь трансформации. Мы работаем рядом с вашей командой,
            делимся экспертизой и настраиваем процессы так, чтобы изменения приносили осязаемую пользу.
          </p>
          <ul>
            <li>Партнёрский подход и прозрачная коммуникация</li>
            <li>Команды, сертифицированные ведущими вендорами</li>
            <li>Сфокусированность на измеримом результате</li>
          </ul>
          <Link to="/about" className={styles.secondaryButton}>
            Узнать больше о нас
          </Link>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Готовы ускорить цифровые изменения?</h2>
          <p>
            Оставьте контактные данные, и наш консультант свяжется с вами, чтобы обсудить задачи и предложить план действий.
          </p>
          <Link to="/contact" className={styles.primaryButton}>
            Назначить встречу
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;