import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.brand}>
          <h3>TechSolutions Inc.</h3>
          <p>
            Комплексный IT консалтинг и сопровождение цифровой трансформации
            бизнеса любого масштаба.
          </p>
        </div>
        <div className={styles.links}>
          <h4>Навигация</h4>
          <nav className={styles.nav}>
            <NavLink to="/services">Услуги</NavLink>
            <NavLink to="/about">О компании</NavLink>
            <NavLink to="/contact">Контакты</NavLink>
            <NavLink to="/terms">Условия использования</NavLink>
            <NavLink to="/privacy">Конфиденциальность</NavLink>
            <NavLink to="/cookie-policy">Cookie-файлы</NavLink>
          </nav>
        </div>
        <div className={styles.contact}>
          <h4>Контакты</h4>
          <ul>
            <li>ул. Технологическая, 15, Москва, 115280</li>
            <li>
              Телефон: <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            </li>
            <li>
              Email: <a href="mailto:info@techsolutions.ru">info@techsolutions.ru</a>
            </li>
          </ul>
          <div className={styles.socials}>
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
              <span aria-hidden="true">in</span>
            </a>
            <a href="https://www.facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook">
              <span aria-hidden="true">f</span>
            </a>
            <a href="https://t.me" target="_blank" rel="noreferrer" aria-label="Telegram">
              <span aria-hidden="true">▶</span>
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} TechSolutions Inc. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;