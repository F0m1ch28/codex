import React, { useState, useEffect } from "react";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [preferences, setPreferences] = useState({
    analytics: true,
    marketing: false,
  });

  useEffect(() => {
    const consent = localStorage.getItem("cookieConsent");
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("cookieConsent", JSON.stringify({ ...preferences, essential: true }));
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem(
      "cookieConsent",
      JSON.stringify({ analytics: false, marketing: false, essential: true })
    );
    setIsVisible(false);
  };

  const togglePreference = (key) => {
    setPreferences((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner}>
      <div className={styles.content}>
        <h4>Мы используем cookie</h4>
        <p>
          Мы применяем cookie-файлы для улучшения работы сайта, анализа трафика и персонализации контента.
          Вы можете изменить настройки в любое время.
        </p>
        <button
          className={styles.settingsButton}
          onClick={() => setShowSettings((prev) => !prev)}
        >
          {showSettings ? "Скрыть настройки" : "Настройки"}
        </button>
        {showSettings && (
          <div className={styles.settings}>
            <label>
              <input type="checkbox" checked disabled /> Необходимые cookie
            </label>
            <label>
              <input
                type="checkbox"
                checked={preferences.analytics}
                onChange={() => togglePreference("analytics")}
              />
              Аналитические
            </label>
            <label>
              <input
                type="checkbox"
                checked={preferences.marketing}
                onChange={() => togglePreference("marketing")}
              />
              Маркетинговые
            </label>
          </div>
        )}
      </div>
      <div className={styles.actions}>
        <button className={styles.decline} onClick={handleDecline}>
          Отклонить
        </button>
        <button className={styles.accept} onClick={handleAccept}>
          Принять все
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;