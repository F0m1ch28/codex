import React, { useState, useEffect } from "react";

const CookieBanner = () => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem("cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setOpen(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem("cookie-consent", "accepted");
    setOpen(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem("cookie-consent", "declined");
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-banner__content">
        <h4>We value your privacy</h4>
        <p>
          We use cookies to enhance your browsing experience, analyze site traffic, and assist in our marketing efforts.
          You can manage preferences anytime in your browser settings.
        </p>
      </div>
      <div className="cookie-banner__actions">
        <button className="btn btn--ghost" onClick={handleDecline}>
          Decline
        </button>
        <button className="btn btn--primary" onClick={handleAccept}>
          Accept All
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;