import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="container site-footer__grid">
        <div className="site-footer__brand">
          <div className="site-footer__logo">
            <span className="site-footer__logo-mark">Σ</span>
            <span>Summit Strategy Group</span>
          </div>
          <p>
            We partner with ambitious leaders to design data-driven strategies, orchestrate seamless execution, and
            deliver measurable results.
          </p>
          <div className="site-footer__social">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
              LinkedIn
            </a>
            <a href="https://www.twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
              Twitter
            </a>
            <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram">
              Instagram
            </a>
          </div>
        </div>
        <div>
          <h4>Company</h4>
          <ul>
            <li>
              <Link to="/about">About us</Link>
            </li>
            <li>
              <Link to="/services">Services</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
            <li>
              <Link to="/terms">Terms &amp; Conditions</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4>Solutions</h4>
          <ul>
            <li>
              <Link to="/services">Digital Transformation</Link>
            </li>
            <li>
              <Link to="/services">Operational Excellence</Link>
            </li>
            <li>
              <Link to="/services">Customer Experience</Link>
            </li>
            <li>
              <Link to="/services">Innovation Labs</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4>Contact</h4>
          <ul className="site-footer__contact">
            <li>
              <strong>Email:</strong> <a href="mailto:hello@summitstrategy.com">hello@summitstrategy.com</a>
            </li>
            <li>
              <strong>Phone:</strong> <a href="tel:+12345556789">+1 (234) 555-6789</a>
            </li>
            <li>
              428 Market Street<br />
              Suite 900<br />
              San Francisco, CA 94105
            </li>
          </ul>
        </div>
      </div>
      <div className="site-footer__bottom">
        <div className="container">
          <p>© {new Date().getFullYear()} Summit Strategy Group. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;