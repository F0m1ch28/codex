import React, { useState, useEffect } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.classList.add("menu-open");
    } else {
      document.body.classList.remove("menu-open");
    }
  }, [isMenuOpen]);

  const navLinks = [
    { to: "/", label: "Home" },
    { to: "/about", label: "About" },
    { to: "/services", label: "Services" },
    { to: "/contact", label: "Contact" },
  ];

  return (
    <header className={`site-header ${scrolled ? "site-header--scrolled" : ""}`}>
      <div className="container site-header__inner">
        <Link to="/" className="site-header__logo" aria-label="Summit Strategy Group home">
          <span className="site-header__logo-mark">Σ</span>
          <span>
            Summit <strong>Strategy</strong>
          </span>
        </Link>
        <nav className={`site-nav ${isMenuOpen ? "site-nav--open" : ""}`} aria-label="Main navigation">
          <ul>
            {navLinks.map((link) => (
              <li key={link.to}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) => (isActive ? "active" : undefined)}
                  end={link.to === "/"}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
            <li className="site-nav__cta">
              <Link to="/contact" className="btn btn--primary">
                Start a Project
              </Link>
            </li>
          </ul>
        </nav>
        <button
          className={`site-header__toggle ${isMenuOpen ? "site-header__toggle--open" : ""}`}
          onClick={() => setIsMenuOpen((prev) => !prev)}
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
          aria-label="Toggle navigation"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;