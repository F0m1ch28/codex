import React, { useState } from "react";

const servicePackages = [
  {
    title: "Enterprise Transformation Blueprint",
    summary:
      "Comprehensive strategy and execution model tailored to unlock sustainable growth and operational resilience.",
    deliverables: [
      "Vision and value realization roadmap",
      "Operating model & governance redesign",
      "Technology enablement plan",
      "Change management playbook",
    ],
    outcomes: "Align leadership priorities, accelerate decision-making, and build an executable delivery roadmap.",
  },
  {
    title: "Customer Experience Reimagination",
    summary:
      "Human-centered redesign combining qualitative research, analytics, and journey orchestration.",
    deliverables: [
      "Customer persona & needs synthesis",
      "End-to-end journey maps with moments that matter",
      "Service blueprint and CX measurement framework",
      "Training & enablement for frontline teams",
    ],
    outcomes: "Elevate satisfaction, increase retention, and boost revenue through differentiated experiences.",
  },
  {
    title: "Digital Product Acceleration",
    summary:
      "Launch or modernize digital products with cross-functional squads, agile governance, and rapid experimentation.",
    deliverables: [
      "Product strategy & north-star vision",
      "Design sprints and prototyping",
      "Tech architecture & backlog prioritization",
      "Scaled agile delivery coaching",
    ],
    outcomes: "Reduce time-to-market, mitigate risks, and ensure adoption through data-driven validation.",
  },
];

const Services = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className="page services">
      <section className="subpage-hero">
        <div className="container subpage-hero__content">
          <span className="section-eyebrow">Services</span>
          <h1>Where strategy meets execution.</h1>
          <p>
            We orchestrate multi-disciplinary teams that connect strategy, design, data, and technology. Explore our
            signature service offerings built to deliver value at every stage of your transformation journey.
          </p>
        </div>
      </section>

      <section className="container services__packages">
        <div className="services__tabs">
          {servicePackages.map((service, index) => (
            <button
              key={service.title}
              className={`service-tab ${activeIndex === index ? "service-tab--active" : ""}`}
              onClick={() => setActiveIndex(index)}
            >
              {service.title}
            </button>
          ))}
        </div>
        <div className="service-panel">
          <div className="service-panel__header">
            <h2>{servicePackages[activeIndex].title}</h2>
            <p>{servicePackages[activeIndex].summary}</p>
          </div>
          <div className="service-panel__grid">
            <div>
              <h3>What’s included</h3>
              <ul>
                {servicePackages[activeIndex].deliverables.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
            <div>
              <h3>Value delivered</h3>
              <p>{servicePackages[activeIndex].outcomes}</p>
              <div className="service-panel__cta">
                <a href="#contact" className="btn btn--primary">
                  Request proposal
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="services__differentiators">
        <div className="container section-heading">
          <span className="section-eyebrow">Why Summit</span>
          <div className="section-heading__content">
            <h2>The Summit difference.</h2>
            <p>
              Our engagements are designed for momentum. We combine strategic rigor, human-centered design, and
              world-class program delivery to ensure initiatives launch strong and sustain impact.
            </p>
          </div>
        </div>
        <div className="container differentiators__grid">
          <div className="differentiator-card">
            <h3>Integrated teams</h3>
            <p>
              Experience designers, strategists, change leaders, and technologists working as one integrated squad.
            </p>
          </div>
          <div className="differentiator-card">
            <h3>Data-powered insight</h3>
            <p>
              We deploy advanced analytics, market scans, and voice-of-customer signals to inform every decision.
            </p>
          </div>
          <div className="differentiator-card">
            <h3>Momentum governance</h3>
            <p>
              A proven rhythm of agile rituals, KPI dashboards, and leadership alignment keeps programs on track.
            </p>
          </div>
          <div className="differentiator-card">
            <h3>Capability transfer</h3>
            <p>
              We build your muscle memory—coaching teams, upskilling talent, and leaving behind the tools to sustain.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;