import React, { useState } from "react";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    company: "",
    email: "",
    message: "",
  });

  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please share your full name.";
    if (!formData.company.trim()) newErrors.company = "Let us know your company.";
    if (!formData.email.trim()) {
      newErrors.email = "Email is required.";
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        newErrors.email = "Please enter a valid email address.";
      }
    }
    if (!formData.message.trim()) newErrors.message = "Please describe your challenge or project goals.";
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      setStatus(null);
      return;
    }
    setStatus("loading");
    setTimeout(() => {
      setStatus("success");
      setFormData({ name: "", company: "", email: "", message: "" });
    }, 1200);
  };

  return (
    <div className="page contact">
      <section className="subpage-hero">
        <div className="container subpage-hero__content">
          <span className="section-eyebrow">Contact</span>
          <h1>Let’s build something remarkable together.</h1>
          <p>
            Ready to explore how we can accelerate your initiatives? Share your details and we’ll connect you with the
            right specialists to discuss your vision.
          </p>
        </div>
      </section>

      <section className="container contact__layout">
        <div className="contact__form">
          <h2>Tell us about your goals</h2>
          <p>We respond to every inquiry within one business day.</p>
          <form onSubmit={handleSubmit} noValidate>
            <div className="form-field">
              <label htmlFor="name">Full name</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                placeholder="Alex Morgan"
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className="form-error">{errors.name}</span>}
            </div>
            <div className="form-field">
              <label htmlFor="company">Company</label>
              <input
                id="company"
                name="company"
                type="text"
                value={formData.company}
                onChange={handleChange}
                placeholder="Summit Technologies"
                aria-invalid={Boolean(errors.company)}
              />
              {errors.company && <span className="form-error">{errors.company}</span>}
            </div>
            <div className="form-field">
              <label htmlFor="email">Work email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="alex@summittechnologies.com"
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className="form-error">{errors.email}</span>}
            </div>
            <div className="form-field">
              <label htmlFor="message">How can we help?</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                placeholder="Share your objectives, challenges, or project timeline."
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span className="form-error">{errors.message}</span>}
            </div>
            <button type="submit" className="btn btn--primary btn--large" disabled={status === "loading"}>
              {status === "loading" ? "Sending..." : "Submit inquiry"}
            </button>
            {status === "success" && (
              <div className="form-success" role="status">
                Thank you! Our team will reach out shortly.
              </div>
            )}
          </form>
        </div>
        <div className="contact__details">
          <div className="contact-card">
            <h3>Connect directly</h3>
            <ul>
              <li>
                <strong>Email:</strong> <a href="mailto:hello@summitstrategy.com">hello@summitstrategy.com</a>
              </li>
              <li>
                <strong>Phone:</strong> <a href="tel:+12345556789">+1 (234) 555-6789</a>
              </li>
            </ul>
            <p>Office hours: Monday–Friday, 8:30 AM–6:00 PM PT</p>
          </div>
          <div className="contact-card">
            <h3>Visit our HQ</h3>
            <p>
              428 Market Street<br />
              Suite 900<br />
              San Francisco, CA 94105
            </p>
            <div className="image-wrapper image-wrapper--map">
              <img
                src="https://picsum.photos/800/600?random=2"
                alt="Aerial view of a modern business district representing the Summit Strategy Group headquarters"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;