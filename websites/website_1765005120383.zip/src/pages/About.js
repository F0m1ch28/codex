import React from "react";

const About = () => {
  return (
    <div className="page about">
      <section className="subpage-hero">
        <div className="container subpage-hero__content">
          <span className="section-eyebrow">About Summit Strategy Group</span>
          <h1>We partner with visionary leaders to architect the future.</h1>
          <p>
            Summit Strategy Group was founded on the belief that transformative impact happens at the intersection of
            strategy, creativity, technology, and human ambition. Our team brings decades of experience guiding global
            organizations through complexity and change.
          </p>
        </div>
      </section>

      <section className="container about__mission">
        <div className="about-card">
          <h2>Our mission</h2>
          <p>
            To empower organizations to navigate disruption, unlock growth, and deliver exceptional experiences by
            aligning people, process, and technology.
          </p>
        </div>
        <div className="about-card">
          <h2>Our DNA</h2>
          <ul>
            <li>Operators at heart—focused on measurable impact and execution excellence.</li>
            <li>Design thinkers—obsessed with understanding the human experience behind every journey.</li>
            <li>Technologists—curious about what’s next and passionate about building future-ready capabilities.</li>
            <li>Partners—integrated with your teams, accountable to shared outcomes.</li>
          </ul>
        </div>
      </section>

      <section className="about__timeline">
        <div className="container section-heading">
          <span className="section-eyebrow">Our Journey</span>
          <div className="section-heading__content">
            <h2>From boutique advisory to global transformation partner.</h2>
            <p>
              We’ve grown intentionally—expanding our capabilities to match the evolving needs of our clients while
              staying true to our collaborative DNA.
            </p>
          </div>
        </div>
        <div className="container timeline">
          <div className="timeline__item">
            <div className="timeline__year">2014</div>
            <div className="timeline__content">
              <h3>Summit Strategy Group launches in San Francisco</h3>
              <p>
                A team of former Fortune 100 executives and innovation leaders form a consultancy to help organizations
                bridge strategy with execution.
              </p>
            </div>
          </div>
          <div className="timeline__item">
            <div className="timeline__year">2017</div>
            <div className="timeline__content">
              <h3>Digital innovation practice debuts</h3>
              <p>
                We expanded into experience design, data science, and engineering to build transformative digital
                products end-to-end.
              </p>
            </div>
          </div>
          <div className="timeline__item">
            <div className="timeline__year">2020</div>
            <div className="timeline__content">
              <h3>Global reach across three continents</h3>
              <p>
                With hubs in New York, London, and Singapore, we now support clients navigating change in over 18
                countries.
              </p>
            </div>
          </div>
          <div className="timeline__item">
            <div className="timeline__year">2023</div>
            <div className="timeline__content">
              <h3>Launched sustainability & inclusion lab</h3>
              <p>
                Helping organizations embed purpose-driven strategies, inclusive design, and ESG-focused innovation
                into their operations.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="about__values">
        <div className="container section-heading">
          <span className="section-eyebrow">Values</span>
          <div className="section-heading__content">
            <h2>The principles that guide our every decision.</h2>
            <p>
              Our culture is rooted in curiosity, collaboration, and respect. We believe lasting partnerships are built
              on transparency and shared success.
            </p>
          </div>
        </div>
        <div className="container values__grid">
          <div className="value-card">
            <h3>Integrity & Trust</h3>
            <p>
              We operate with honesty, respect, and accountability—showing up as an extension of your team, not as an
              outside vendor.
            </p>
          </div>
          <div className="value-card">
            <h3>Inclusive Collaboration</h3>
            <p>
              We design with diverse voices at the table, ensuring solutions reflect the needs of customers, employees,
              and communities.
            </p>
          </div>
          <div className="value-card">
            <h3>Bold Thinking</h3>
            <p>
              We challenge assumptions and explore unconventional approaches that unlock new growth horizons.
            </p>
          </div>
          <div className="value-card">
            <h3>Momentum Mindset</h3>
            <p>
              We mobilize quickly, iterate fast, and maintain focus on outcomes—keeping transformation moving forward.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;