import React, { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { Link } from "react-router-dom";

const statsData = [
  { id: 1, label: "Enterprise Transformations", value: 120 },
  { id: 2, label: "Net Promoter Score", value: 72, suffix: "+" },
  { id: 3, label: "Countries Served", value: 18 },
  { id: 4, label: "Client Satisfaction", value: 98, suffix: "%" },
];

const servicesData = [
  {
    id: 1,
    title: "Strategic Advisory",
    description:
      "Executive-level guidance to align your leadership agenda with market realities and emerging opportunities.",
    icon: "🎯",
  },
  {
    id: 2,
    title: "Digital Transformation",
    description:
      "Modernize your operating model with cloud-native platforms, automation, and intelligent analytics.",
    icon: "💡",
  },
  {
    id: 3,
    title: "Customer Experience",
    description:
      "Design frictionless journeys, measure sentiment in real-time, and orchestrate moments that matter.",
    icon: "🌐",
  },
  {
    id: 4,
    title: "Innovation Labs",
    description:
      "Deploy rapid experimentation frameworks, build MVPs, and scale breakthrough ideas at speed.",
    icon: "🚀",
  },
];

const processSteps = [
  {
    title: "Discover & Diagnose",
    description: "We deep-dive into your ecosystem, uncover friction points, and quantify value potential.",
  },
  {
    title: "Co-Design Strategy",
    description: "Collaborative blueprinting with your stakeholders to craft actionable, data-backed roadmaps.",
  },
  {
    title: "Execute & Orchestrate",
    description: "Cross-functional delivery with relentless governance, agile rituals, and measurable KPIs.",
  },
  {
    title: "Sustain & Scale",
    description: "Enable your teams with tooling, training, and playbooks to sustain momentum long-term.",
  },
];

const testimonials = [
  {
    quote:
      "Summit Strategy reshaped our global service model in just 90 days. Their insights uncovered a 23% cost efficiency and elevated our customer satisfaction beyond expectations.",
    name: "Amelia Hart",
    title: "Chief Experience Officer, Meridian Labs",
  },
  {
    quote:
      "The team brought clarity to a complex transformation. Their ability to orchestrate technology, people, and governance accelerated our roadmap by 18 months.",
    name: "Daniel Cruz",
    title: "COO, Northwind Financial",
  },
  {
    quote:
      "From vision to execution, Summit Strategy became our trusted partner. The growth playbook they designed is now core to our expansion strategy.",
    name: "Priya Natarajan",
    title: "SVP Strategy, Horizon Retail Group",
  },
];

const teamMembers = [
  {
    name: "Elena Martinez",
    role: "Managing Partner",
    bio: "Architect of award-winning transformation programs across financial services and SaaS.",
    img: "https://picsum.photos/400/400?random=3",
  },
  {
    name: "Michael Chen",
    role: "Head of Innovation",
    bio: "Builds venture-grade digital products leveraging AI, automation, and market intelligence.",
    img: "https://picsum.photos/400/400?random=31",
  },
  {
    name: "Sofia Patel",
    role: "Director, CX Analytics",
    bio: "Transforms customer feedback into real-time insights that drive loyalty and retention.",
    img: "https://picsum.photos/400/400?random=32",
  },
  {
    name: "Liam O'Connor",
    role: "Principal Strategist",
    bio: "Former Fortune 100 leader skilled in operating model design and global change adoption.",
    img: "https://picsum.photos/400/400?random=33",
  },
];

const projectCategories = ["All", "Transformation", "Experience", "Strategy"];

const projects = [
  {
    id: 1,
    title: "Global Supply Chain Reinvention",
    category: "Transformation",
    description: "End-to-end modernization delivering 28% faster cycle times and real-time visibility.",
    img: "https://picsum.photos/1200/800?random=4",
  },
  {
    id: 2,
    title: "Omnichannel Experience Engine",
    category: "Experience",
    description: "Designed a unified customer layer across retail, mobile, and service centers.",
    img: "https://picsum.photos/1200/800?random=41",
  },
  {
    id: 3,
    title: "Growth Strategy Playbook",
    category: "Strategy",
    description: "Crafted a 5-year expansion roadmap unlocking three new markets in APAC.",
    img: "https://picsum.photos/1200/800?random=42",
  },
  {
    id: 4,
    title: "Automation Center of Excellence",
    category: "Transformation",
    description: "Deployed intelligent automation reducing operational costs by 34%.",
    img: "https://picsum.photos/1200/800?random=43",
  },
  {
    id: 5,
    title: "Voice of Customer Analytics",
    category: "Experience",
    description: "Built predictive models to anticipate churn and personalize retention offers.",
    img: "https://picsum.photos/1200/800?random=44",
  },
];

const faqs = [
  {
    question: "What industries do you specialize in?",
    answer:
      "Our consultants bring deep domain expertise across financial services, SaaS, consumer retail, healthcare, and manufacturing. We tailor every engagement to your industry regulations, customer expectations, and growth dynamics.",
  },
  {
    question: "How do you ensure measurable impact?",
    answer:
      "Every engagement begins with a baseline assessment and KPI framework. We co-create dashboards, establish decision cadences, and provide enablement to ensure accountability and visible progress.",
  },
  {
    question: "Do you offer implementation support?",
    answer:
      "Yes. Beyond advisory, our delivery squads embed with your teams, orchestrate programs, and manage cross-functional change to ensure momentum from ideation to scaling.",
  },
  {
    question: "What happens after the project ends?",
    answer:
      "We design sustainability plans with governance, playbooks, and training. Many clients retain us for ongoing advisory to ensure continued value realization and capability building.",
  },
];

const blogPosts = [
  {
    id: 1,
    title: "Reimagining Operational Efficiency in 2024",
    description: "Five high-impact levers to unlock resilient, tech-enabled operations.",
    date: "May 8, 2024",
    author: "Elena Martinez",
  },
  {
    id: 2,
    title: "Designing Journeys That Customers Love",
    description: "How leading brands translate insights into differentiated experiences.",
    date: "April 22, 2024",
    author: "Sofia Patel",
  },
  {
    id: 3,
    title: "Winning with Intelligent Automation",
    description: "Building a scalable automation roadmap without compromising governance.",
    date: "March 18, 2024",
    author: "Michael Chen",
  },
];

const LazyImage = ({ src, alt, className }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={`image-wrapper ${loaded ? "image-wrapper--loaded" : ""}`}>
      <img src={src} alt={alt} className={className} onLoad={() => setLoaded(true)} />
    </div>
  );
};

const Home = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const [filteredProjects, setFilteredProjects] = useState(projects);
  const [activeFAQ, setActiveFAQ] = useState(0);
  const [statsValues, setStatsValues] = useState(statsData.map(() => 0));
  const statsRef = useRef(null);
  const hasAnimated = useRef(false);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const heroImage = useMemo(() => "https://picsum.photos/1600/900?random=1", []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          const duration = 1800;
          const start = performance.now();

          const animate = (time) => {
            const progress = Math.min((time - start) / duration, 1);
            setStatsValues(
              statsData.map((stat) => Math.floor(progress * stat.value) + (stat.value === 0 ? 0 : 1 * (progress === 1 ? 0 : 0)))
            );
            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setStatsValues(statsData.map((stat) => stat.value));
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.4 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    setFilteredProjects(
      activeCategory === "All" ? projects : projects.filter((project) => project.category === activeCategory)
    );
  }, [activeCategory]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  const handleFAQToggle = (index) => {
    setActiveFAQ((prev) => (prev === index ? null : index));
  };

  const selectCategory = useCallback((category) => {
    setActiveCategory(category);
  }, []);

  return (
    <div className="page home">
      <section className="hero" id="hero">
        <div className="container hero__grid">
          <div className="hero__content">
            <div className="hero__eyebrow">Summit Strategy Group</div>
            <h1>
              Transform ambition into <span>measurable outcomes</span>.
            </h1>
            <p>
              We empower leaders to reimagine their organization through strategic clarity, digital acceleration, and
              human-centered change. From vision to execution, our consultants orchestrate transformation that sticks.
            </p>
            <div className="hero__cta">
              <Link to="/services" className="btn btn--primary btn--large">
                Explore Our Capabilities
              </Link>
              <a href="#contact" className="btn btn--ghost btn--large">
                Talk to an Expert
              </a>
            </div>
            <div className="hero__meta">
              <div>
                <strong>Trusted by 140+ enterprises</strong>
                <span>Fortune 500 and high-growth scale-ups</span>
              </div>
              <div>
                <strong>Global delivery footprint</strong>
                <span>Teams across North America, EMEA, and APAC</span>
              </div>
            </div>
          </div>
          <div className="hero__image">
            <LazyImage src={heroImage} alt="Executives collaborating in a modern boardroom" />
          </div>
        </div>
      </section>

      <section className="stats" ref={statsRef}>
        <div className="container stats__grid">
          {statsData.map((stat, index) => (
            <div key={stat.id} className="stats__item">
              <div className="stats__value">
                {statsValues[index]}
                {stat.suffix ? stat.suffix : ""}
              </div>
              <div className="stats__label">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="services" id="services">
        <div className="container section-heading">
          <span className="section-eyebrow">Services</span>
          <div className="section-heading__content">
            <h2>Strategic insight, unwavering execution.</h2>
            <p>
              Our multidisciplinary teams partner with you across the full transformation lifecycle—from strategic
              vision through customer experience, technology enablement, and change adoption.
            </p>
          </div>
        </div>
        <div className="container services__grid">
          {servicesData.map((service) => (
            <article key={service.id} className="service-card">
              <div className="service-card__icon" aria-hidden="true">
                {service.icon}
              </div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/services" className="service-card__link">
                Discover how we deliver
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="process" id="process">
        <div className="container section-heading">
          <span className="section-eyebrow">Our Process</span>
          <div className="section-heading__content">
            <h2>A proven approach engineered for momentum.</h2>
            <p>
              We combine strategy, design, technology, and change to accelerate execution while ensuring every decision
              is anchored in insight and measurable value.
            </p>
          </div>
        </div>
        <div className="container process__steps">
          {processSteps.map((step, index) => (
            <div key={step.title} className="process-step">
              <div className="process-step__index">
                <span>{(index + 1).toString().padStart(2, "0")}</span>
              </div>
              <div className="process-step__body">
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="testimonials" id="testimonials">
        <div className="container testimonials__grid">
          <div className="testimonials__intro">
            <span className="section-eyebrow">Client Stories</span>
            <h2>What leaders say about partnering with Summit.</h2>
            <p>
              We measure our success by the progress our clients achieve—unlocking new growth, elevating experiences,
              and building resilient organizations.
            </p>
            <div className="testimonials__controls">
              <button
                type="button"
                className="btn--circle"
                onClick={() =>
                  setCurrentTestimonial(
                    (prev) => (prev - 1 + testimonials.length) % testimonials.length
                  )
                }
                aria-label="Previous testimonial"
              >
                ‹
              </button>
              <button
                type="button"
                className="btn--circle"
                onClick={() => setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)}
                aria-label="Next testimonial"
              >
                ›
              </button>
            </div>
          </div>
          <div className="testimonials__carousel">
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`testimonial-card ${
                  currentTestimonial === index ? "testimonial-card--active" : ""
                }`}
              >
                <p className="testimonial-card__quote">“{testimonial.quote}”</p>
                <div className="testimonial-card__author">
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.title}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="team" id="team">
        <div className="container section-heading">
          <span className="section-eyebrow">Our Leadership</span>
          <div className="section-heading__content">
            <h2>Meet the strategists guiding every engagement.</h2>
            <p>
              A collective of thinkers, builders, and operators united by curiosity—and a relentless focus on client
              outcomes.
            </p>
          </div>
        </div>
        <div className="container team__grid">
          {teamMembers.map((member) => (
            <div key={member.name} className="team-card">
              <LazyImage src={member.img} alt={`Portrait of ${member.name}, ${member.role}`} />
              <div className="team-card__info">
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="projects" id="projects">
        <div className="container section-heading">
          <span className="section-eyebrow">Case Studies</span>
          <div className="section-heading__content">
            <h2>Selected outcomes across industries.</h2>
            <p>
              Our team thrives in complex environments—navigating transformation at scale while keeping the customer at
              the center of every decision.
            </p>
          </div>
        </div>
        <div className="container projects__controls">
          {projectCategories.map((category) => (
            <button
              key={category}
              className={`chip ${activeCategory === category ? "chip--active" : ""}`}
              onClick={() => selectCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className="container projects__grid">
          {filteredProjects.map((project) => (
            <article key={project.id} className="project-card">
              <LazyImage src={project.img} alt={`${project.title} project visualization`} />
              <div className="project-card__content">
                <span className="project-card__category">{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <Link to="/services" className="project-card__link">
                  View methodology
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="faq" id="faq">
        <div className="container section-heading">
          <span className="section-eyebrow">FAQ</span>
          <div className="section-heading__content">
            <h2>Your questions, answered.</h2>
            <p>
              We believe transparency creates trust. Explore common topics or connect with our consultants to discuss
              your unique needs.
            </p>
          </div>
        </div>
        <div className="container faq__list">
          {faqs.map((item, index) => (
            <div
              key={item.question}
              className={`faq-item ${activeFAQ === index ? "faq-item--open" : ""}`}
            >
              <button className="faq-item__toggle" onClick={() => handleFAQToggle(index)}>
                <span>{item.question}</span>
                <span aria-hidden="true">{activeFAQ === index ? "−" : "+"}</span>
              </button>
              <div className="faq-item__content">
                <p>{item.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="blog" id="insights">
        <div className="container section-heading">
          <span className="section-eyebrow">Insights</span>
          <div className="section-heading__content">
            <h2>Latest perspectives from our experts.</h2>
            <p>
              Stay ahead with fresh thinking on strategy, operations, customer experience, and the future of work.
            </p>
          </div>
        </div>
        <div className="container blog__grid">
          {blogPosts.map((post) => (
            <article key={post.id} className="blog-card">
              <span className="blog-card__meta">
                {post.date} • {post.author}
              </span>
              <h3>{post.title}</h3>
              <p>{post.description}</p>
              <Link to="/contact" className="blog-card__link">
                Request the briefing
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="cta" id="contact">
        <div className="container cta__inner">
          <div className="cta__content">
            <span className="section-eyebrow">Let’s build momentum</span>
            <h2>Ready to accelerate your strategic agenda?</h2>
            <p>
              Share your challenge and we’ll assemble the right team to guide you from strategy through execution.
              Expect a response from our leadership team within 24 hours.
            </p>
          </div>
          <div className="cta__actions">
            <Link to="/contact" className="btn btn--light btn--large">
              Schedule a consultation
            </Link>
            <a href="tel:+12345556789" className="btn btn--outline btn--large">
              Call +1 (234) 555-6789
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;