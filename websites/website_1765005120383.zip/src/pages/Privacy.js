import React from "react";

const Privacy = () => {
  return (
    <div className="page legal">
      <section className="subpage-hero">
        <div className="container subpage-hero__content">
          <span className="section-eyebrow">Privacy</span>
          <h1>Privacy Policy</h1>
          <p>
            Summit Strategy Group respects your privacy. This policy explains how we collect, use, and safeguard personal
            information when you interact with our website and services.
          </p>
        </div>
      </section>

      <section className="container legal__content">
        <h2>Information We Collect</h2>
        <p>
          We collect information you voluntarily provide, such as contact details submitted through forms, and data
          gathered automatically through cookies and analytics tools to improve our services.
        </p>

        <h2>How We Use Information</h2>
        <p>
          We use collected data to respond to inquiries, deliver services, personalize experiences, and improve our
          digital touchpoints. We may also send relevant updates or insights with your consent.
        </p>

        <h2>Data Sharing</h2>
        <p>
          We do not sell personal information. Data may be shared with trusted partners assisting in operations under
          confidentiality agreements, or when required by law.
        </p>

        <h2>Data Security</h2>
        <p>
          We implement administrative, technical, and physical safeguards designed to protect information from
          unauthorized access, disclosure, alteration, or destruction.
        </p>

        <h2>Cookies &amp; Preferences</h2>
        <p>
          Cookies help personalize your experience and analyze site performance. You can disable cookies in your browser
          settings, though some features may be limited.
        </p>

        <h2>Your Rights</h2>
        <p>
          You may request access, correction, or deletion of your personal data by contacting{" "}
          <a href="mailto:privacy@summitstrategy.com">privacy@summitstrategy.com</a>. We respond to all verified requests
          promptly.
        </p>

        <h2>Updates</h2>
        <p>
          We may update this policy to reflect changes in regulations or our practices. Updates will be posted with a
          revised date. Continued use signifies acceptance of changes.
        </p>

        <p className="legal__last-updated">Last updated: May 12, 2024</p>
      </section>
    </div>
  );
};

export default Privacy;