import React from "react";

const Terms = () => {
  return (
    <div className="page legal">
      <section className="subpage-hero">
        <div className="container subpage-hero__content">
          <span className="section-eyebrow">Legal</span>
          <h1>Terms &amp; Conditions</h1>
          <p>
            These terms outline the rules and guidelines for engaging with Summit Strategy Group’s services and digital
            properties. Please review them carefully.
          </p>
        </div>
      </section>

      <section className="container legal__content">
        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing our website or engaging with our consulting services, you confirm your acceptance of these Terms
          &amp; Conditions. If you disagree with any part, please discontinue use of our services.
        </p>

        <h2>2. Services</h2>
        <p>
          Summit Strategy Group provides advisory, transformation, and consulting services. Deliverables and timelines
          are defined in individual statements of work. We may update service descriptions without notice to reflect
          evolving capabilities.
        </p>

        <h2>3. Confidentiality</h2>
        <p>
          We treat all client information as confidential. Mutual non-disclosure agreements may be executed to protect
          sensitive information shared throughout the engagement.
        </p>

        <h2>4. Intellectual Property</h2>
        <p>
          All intellectual property developed by Summit Strategy Group remains our exclusive property unless otherwise
          specified. Clients receive rights to use deliverables internally as defined in respective agreements.
        </p>

        <h2>5. Limitation of Liability</h2>
        <p>
          Summit Strategy Group will not be liable for indirect, incidental, or consequential damages arising from the
          use of our services. Our total liability shall not exceed the fees paid for services under the applicable
          statement of work.
        </p>

        <h2>6. Governing Law</h2>
        <p>
          These terms are governed by the laws of the State of California, without regard to conflict-of-law principles.
          Any disputes shall be resolved in the state or federal courts located in San Francisco, California.
        </p>

        <h2>7. Updates</h2>
        <p>
          We may update these Terms &amp; Conditions periodically. Material changes will be posted on this page with an
          updated revision date. Continued use of our services indicates acceptance of the revised Terms.
        </p>

        <p className="legal__last-updated">Last updated: May 12, 2024</p>
      </section>
    </div>
  );
};

export default Terms;