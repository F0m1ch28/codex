document.addEventListener('DOMContentLoaded', () => {
  const banner = document.querySelector('[data-cookie-banner]');
  if (!banner) return;

  const status = localStorage.getItem('vd-cookie-consent');
  if (status) {
    banner.classList.add('is-hidden');
    banner.setAttribute('aria-hidden', 'true');
  } else {
    window.setTimeout(() => {
      banner.classList.add('is-visible');
      banner.setAttribute('aria-hidden', 'false');
    }, 800);
  }

  const acceptBtn = banner.querySelector('[data-accept]');
  const declineBtn = banner.querySelector('[data-decline]');

  acceptBtn?.addEventListener('click', () => {
    localStorage.setItem('vd-cookie-consent', 'accepted');
    banner.classList.remove('is-visible');
    banner.classList.add('is-hidden');
    banner.setAttribute('aria-hidden', 'true');
  });

  declineBtn?.addEventListener('click', () => {
    localStorage.setItem('vd-cookie-consent', 'declined');
    banner.classList.remove('is-visible');
    banner.classList.add('is-hidden');
    banner.setAttribute('aria-hidden', 'true');
  });
});