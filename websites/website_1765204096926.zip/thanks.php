<?php
$nombre = htmlspecialchars($_POST['nombre'] ?? '', ENT_QUOTES, 'UTF-8');
$empresa = htmlspecialchars($_POST['empresa'] ?? '', ENT_QUOTES, 'UTF-8');
$email = htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8');
$telefono = htmlspecialchars($_POST['telefono'] ?? '', ENT_QUOTES, 'UTF-8');
$mensaje = htmlspecialchars($_POST['mensaje'] ?? '', ENT_QUOTES, 'UTF-8');
$interes = htmlspecialchars($_POST['interes'] ?? '', ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Gracias | Viento Digital</title>
  <meta name="description" content="Confirmación de envío del formulario de contacto de Viento Digital.">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%230c3c78'/%3E%3Cpath d='M18 44c9-3 12-10 11-19-1-6 2-10 7-11 6-1 10 4 10 10 0 12-9 20-28 20z' fill='%23ffffff'/%3E%3Cpath d='M24 17l18 18' stroke='%238bd35a' stroke-width='4' stroke-linecap='round'/%3E%3C/svg%3E">
  <link rel="stylesheet" href="style.css">
  <script src="script.js" defer></script>
</head>
<body>
  <a href="#main" class="skip-link">Saltar al contenido principal</a>
  <header class="site-header">
    <div class="site-header__bar">
      <a class="brand" href="index.html">
        <span class="brand__mark">VD</span>
        <span>Viento Digital</span>
      </a>
      <nav class="nav" aria-label="Navegación principal">
        <ul class="nav__list">
          <li><a href="index.html" class="nav__link">Inicio</a></li>
          <li><a href="about.html" class="nav__link">La compañía</a></li>
          <li><a href="solutions.html" class="nav__link">Soluciones</a></li>
          <li><a href="technology.html" class="nav__link">Tecnología</a></li>
          <li><a href="operations.html" class="nav__link">Operaciones</a></li>
          <li><a href="projects.html" class="nav__link">Proyectos</a></li>
          <li><a href="contact.php" class="btn-small">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main id="main">
    <section class="section section--accent" aria-labelledby="thanks-title">
      <div class="container container--narrow">
        <div class="banner">
          <h1 id="thanks-title">Gracias, <?php echo $nombre ?: 'equipo'; ?>.</h1>
          <p>Hemos recibido tu mensaje y un especialista de Viento Digital se pondrá en contacto contigo en menos de 24 horas laborales.</p>
          <div class="accent-panel">
            <h3>Resumen del envío</h3>
            <ul class="list-clean">
              <?php if ($empresa) : ?><li><strong>Empresa:</strong> <?php echo $empresa; ?></li><?php endif; ?>
              <?php if ($email) : ?><li><strong>Email:</strong> <?php echo $email; ?></li><?php endif; ?>
              <?php if ($telefono) : ?><li><strong>Teléfono:</strong> <?php echo $telefono; ?></li><?php endif; ?>
              <?php if ($interes) : ?><li><strong>Área de interés:</strong> <?php echo $interes; ?></li><?php endif; ?>
              <?php if ($mensaje) : ?><li><strong>Mensaje:</strong> <?php echo $mensaje; ?></li><?php endif; ?>
            </ul>
          </div>
          <a class="btn" href="index.html">Volver al inicio</a>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="site-footer__grid">
      <div class="footer__brand">
        <a class="brand" href="index.html">
          <span class="brand__mark">VD</span>
          <span>Viento Digital</span>
        </a>
        <p>Digitalización avanzada para parques eólicos con enfoque integral en supervisión, analítica y operación inteligente.</p>
        <div>
          <strong>Dirección:</strong> Torre Iberdrola, Plaza Euskadi 5, Planta 18, 48009 Bilbao, España<br>
          <strong>Teléfono:</strong> <a href="tel:+34944708392">+34 944 708 392</a><br>
          <strong>Correo:</strong> <a href="mailto:hola@vientodigital.es">hola@vientodigital.es</a>
        </div>
      </div>
      <div class="footer__columns">
        <div>
          <h3>Compañía</h3>
          <ul class="footer__list">
            <li><a href="about.html">Valores y equipo</a></li>
            <li><a href="solutions.html">Soluciones</a></li>
            <li><a href="operations.html">Operaciones digitales</a></li>
            <li><a href="projects.html">Casos destacados</a></li>
          </ul>
        </div>
        <div>
          <h3>Recursos</h3>
          <ul class="footer__list">
            <li><a href="technology.html">Stack tecnológico</a></li>
            <li><a href="contact.php">Solicitar evaluación</a></li>
            <li><a href="privacy.html">Privacidad</a></li>
            <li><a href="cookies.html">Preferencias de cookies</a></li>
          </ul>
        </div>
        <div>
          <h3>Horario</h3>
          <p>Lunes a viernes: 08:30 - 18:00 CET<br>Soporte 24/7 para operaciones críticas.</p>
        </div>
      </div>
      <div class="footer__legal">
        <span>&copy; <span id="year">2024</span> Viento Digital. Todos los derechos reservados.</span>
        <a href="terms.html">Términos legales</a>
      </div>
    </div>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies" data-cookie-banner>
    <div>
      <h3>Control de cookies</h3>
      <p>Utilizamos cookies técnicas para asegurar el funcionamiento y analíticas para mejorar la experiencia. Configura tu preferencia.</p>
      <a class="badge-inline" href="cookies.html">Gestionar configuración</a>
    </div>
    <div class="cookie-banner__actions">
      <button type="button" class="btn btn--secondary" data-decline>Rechazar</button>
      <button type="button" class="btn" data-accept>Aceptar</button>
    </div>
  </div>
</body>
</html>