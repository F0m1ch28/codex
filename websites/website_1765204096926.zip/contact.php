<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Contacto | Solicitar evaluación digital eólica</title>
  <meta name="description" content="Contacta con Viento Digital para solicitar una evaluación digital, conocer nuestras soluciones y coordinar una sesión técnica.">
  <meta name="keywords" content="contacto Viento Digital, evaluación digital eólica, formulario contacto eólica, torre iberdrola">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta property="og:title" content="Contacto | Solicitar evaluación digital eólica">
  <meta property="og:description" content="Habla con el equipo de Viento Digital y agenda una evaluación digital de tu parque eólico.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.vientodigital.es/contact.php">
  <meta property="og:image" content="https://picsum.photos/1200/630?random=contacto-eolico">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%230c3c78'/%3E%3Cpath d='M18 44c9-3 12-10 11-19-1-6 2-10 7-11 6-1 10 4 10 10 0 12-9 20-28 20z' fill='%23ffffff'/%3E%3Cpath d='M24 17l18 18' stroke='%238bd35a' stroke-width='4' stroke-linecap='round'/%3E%3C/svg%3E">
  <link rel="stylesheet" href="style.css">
  <script src="script.js" defer></script>
</head>
<body>
  <a href="#main" class="skip-link">Saltar al contenido principal</a>
  <header class="site-header">
    <div class="site-header__bar">
      <a class="brand" href="index.html">
        <span class="brand__mark">VD</span>
        <span>Viento Digital</span>
      </a>
      <nav class="nav" aria-label="Navegación principal">
        <ul class="nav__list">
          <li><a href="index.html" class="nav__link">Inicio</a></li>
          <li><a href="about.html" class="nav__link">La compañía</a></li>
          <li><a href="solutions.html" class="nav__link">Soluciones</a></li>
          <li><a href="technology.html" class="nav__link">Tecnología</a></li>
          <li><a href="operations.html" class="nav__link">Operaciones</a></li>
          <li><a href="projects.html" class="nav__link">Proyectos</a></li>
          <li><a href="contact.php" class="btn-small current" aria-current="page">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main id="main">
    <section class="section" aria-labelledby="contact-title">
      <div class="container">
        <div class="split-layout">
          <div>
            <span class="badge">Solicitar Evaluación Digital</span>
            <h1 id="contact-title">Hablemos sobre la digitalización de tu parque eólico</h1>
            <p>Completa el formulario y organiza una sesión con nuestros especialistas para explorar oportunidades de mejora en monitorización, mantenimiento predictivo y operaciones centralizadas.</p>
            <div class="card">
              <h3>Datos de contacto</h3>
              <p><strong>Dirección:</strong> Torre Iberdrola, Plaza Euskadi 5, Planta 18, 48009 Bilbao, España</p>
              <p><strong>Teléfono:</strong> <a href="tel:+34944708392">+34 944 708 392</a></p>
              <p><strong>Correo:</strong> <a href="mailto:hola@vientodigital.es">hola@vientodigital.es</a></p>
              <p><strong>Horario:</strong> Lunes a viernes, 08:30 - 18:00 CET</p>
            </div>
          </div>
          <figure>
            <img src="https://picsum.photos/820/520?random=oficina-eolica" alt="Oficina moderna de Viento Digital en Bilbao" loading="lazy">
            <figcaption class="helper-text">Oficinas en Torre Iberdrola con centro de operaciones digitales.</figcaption>
          </figure>
        </div>
      </div>
    </section>

    <section class="section section--muted" id="contacto-form" aria-labelledby="form-title">
      <div class="container container--narrow">
        <h2 id="form-title">Formulario de contacto</h2>
        <form class="form" method="post" action="thanks.php">
          <div class="form__row form__row--split">
            <div>
              <label for="nombre">Nombre y apellidos</label>
              <input type="text" id="nombre" name="nombre" placeholder="Nombre completo" required>
            </div>
            <div>
              <label for="empresa">Empresa</label>
              <input type="text" id="empresa" name="empresa" placeholder="Nombre de la organización" required>
            </div>
          </div>
          <div class="form__row form__row--split">
            <div>
              <label for="email">Correo electrónico</label>
              <input type="email" id="email" name="email" placeholder="tucorreo@empresa.es" required>
            </div>
            <div>
              <label for="telefono">Teléfono</label>
              <input type="tel" id="telefono" name="telefono" placeholder="+34 600 000 000" required>
            </div>
          </div>
          <div class="form__row">
            <label for="parque">Parque eólico o región</label>
            <input type="text" id="parque" name="parque" placeholder="Nombre del parque o localización principal">
          </div>
          <div class="form__row">
            <label for="mensaje">Mensaje</label>
            <textarea id="mensaje" name="mensaje" placeholder="Describe objetivos, retos o preguntas específicas" required></textarea>
          </div>
          <div class="form__row">
            <label for="interes">Área de interés</label>
            <select id="interes" name="interes" aria-label="Selecciona el área de interés principal">
              <option value="monitorizacion">Monitorización avanzada e IoT</option>
              <option value="mantenimiento">Mantenimiento predictivo</option>
              <option value="plataforma">Plataforma de control</option>
              <option value="ciberseguridad">Ciberseguridad OT</option>
              <option value="transformacion">Transformación integral</option>
            </select>
          </div>
          <div class="checkbox">
            <input type="checkbox" id="consentimiento" name="consentimiento" value="sí" required>
            <label for="consentimiento">He leído y acepto la <a href="privacy.html">política de privacidad</a> y autorizo el tratamiento de mis datos para gestionar mi solicitud.</label>
          </div>
          <button type="submit" class="btn">Enviar solicitud</button>
        </form>
      </div>
    </section>

    <section class="section" aria-labelledby="mapa-title">
      <div class="container">
        <h2 id="mapa-title">Dónde estamos</h2>
        <iframe class="map" title="Mapa de Viento Digital en Bilbao" loading="lazy" allowfullscreen referrerpolicy="no-referrer-when-downgrade" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2967.909133180468!2d-2.936345884557879!3d43.26862288607062!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd4ef70564c7b7a7%3A0x8fab0dfb7b2df4f4!2sTorre%20Iberdrola!5e0!3m2!1ses!2ses!4v1700000000000"></iframe>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="site-footer__grid">
      <div class="footer__brand">
        <a class="brand" href="index.html">
          <span class="brand__mark">VD</span>
          <span>Viento Digital</span>
        </a>
        <p>Digitalización avanzada para parques eólicos con enfoque integral en supervisión, analítica y operación inteligente.</p>
        <div>
          <strong>Dirección:</strong> Torre Iberdrola, Plaza Euskadi 5, Planta 18, 48009 Bilbao, España<br>
          <strong>Teléfono:</strong> <a href="tel:+34944708392">+34 944 708 392</a><br>
          <strong>Correo:</strong> <a href="mailto:hola@vientodigital.es">hola@vientodigital.es</a>
        </div>
      </div>
      <div class="footer__columns">
        <div>
          <h3>Compañía</h3>
          <ul class="footer__list">
            <li><a href="about.html">Valores y equipo</a></li>
            <li><a href="solutions.html">Soluciones</a></li>
            <li><a href="operations.html">Operaciones digitales</a></li>
            <li><a href="projects.html">Casos destacados</a></li>
          </ul>
        </div>
        <div>
          <h3>Recursos</h3>
          <ul class="footer__list">
            <li><a href="technology.html">Stack tecnológico</a></li>
            <li><a href="contact.php">Solicitar evaluación</a></li>
            <li><a href="privacy.html">Privacidad</a></li>
            <li><a href="cookies.html">Preferencias de cookies</a></li>
          </ul>
        </div>
        <div>
          <h3>Horario</h3>
          <p>Lunes a viernes: 08:30 - 18:00 CET<br>Soporte 24/7 para operaciones críticas.</p>
        </div>
      </div>
      <div class="footer__legal">
        <span>&copy; <span id="year">2024</span> Viento Digital. Todos los derechos reservados.</span>
        <a href="terms.html">Términos legales</a>
      </div>
    </div>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies" data-cookie-banner>
    <div>
      <h3>Control de cookies</h3>
      <p>Utilizamos cookies técnicas para asegurar el funcionamiento y analíticas para mejorar la experiencia. Configura tu preferencia.</p>
      <a class="badge-inline" href="cookies.html">Gestionar configuración</a>
    </div>
    <div class="cookie-banner__actions">
      <button type="button" class="btn btn--secondary" data-decline>Rechazar</button>
      <button type="button" class="btn" data-accept>Aceptar</button>
    </div>
  </div>
</body>
</html>