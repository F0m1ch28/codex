import { useEffect } from 'react';

const usePageMeta = (title, description) => {
  useEffect(() => {
    const formattedTitle = title
      ? `${title} | French Automotive Sector Analysis`
      : 'French Automotive Sector Analysis';
    document.title = formattedTitle;

    if (description) {
      let metaTag = document.querySelector('meta[name="description"]');
      if (!metaTag) {
        metaTag = document.createElement('meta');
        metaTag.setAttribute('name', 'description');
        document.head.appendChild(metaTag);
      }
      metaTag.setAttribute('content', description);
    }
  }, [title, description]);
};

export default usePageMeta;