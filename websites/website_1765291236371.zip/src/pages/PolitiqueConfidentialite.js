import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './LegalPage.module.css';

const PolitiqueConfidentialite = () => {
  usePageMeta(
    'Politique de confidentialité',
    'Politique de confidentialité de French Automotive Sector Analysis.'
  );

  return (
    <div className={styles.page}>
      <h1>Politique de Confidentialité</h1>
      <p>
        French Automotive Sector Analysis attache une grande importance à la protection des données personnelles collectées via ses formulaires.
      </p>

      <h2>Données collectées</h2>
      <p>
        Les informations transmises via le formulaire de contact (nom, adresse électronique, organisation, message) sont utilisées exclusivement pour le traitement des demandes.
      </p>

      <h2>Base juridique</h2>
      <p>
        La collecte repose sur l’intérêt légitime de répondre aux sollicitations et de documenter les échanges éditoriaux.
      </p>

      <h2>Durée de conservation</h2>
      <p>
        Les messages sont conservés pendant la durée nécessaire à leur traitement, puis archivés de manière sécurisée.
      </p>

      <h2>Droits des personnes</h2>
      <p>
        Conformément au règlement général sur la protection des données, toute personne peut demander l’accès, la rectification ou l’effacement de ses informations en écrivant via le formulaire de contact.
      </p>

      <h2>Sécurité</h2>
      <p>
        La publication met en œuvre des mesures raisonnables pour préserver l’intégrité des données communiquées.
      </p>
    </div>
  );
};

export default PolitiqueConfidentialite;