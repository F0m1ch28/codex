import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './LegalPage.module.css';

const ConditionsUtilisation = () => {
  usePageMeta(
    'Conditions d’utilisation',
    'Conditions d’utilisation du site French Automotive Sector Analysis.'
  );

  return (
    <div className={styles.page}>
      <h1>Conditions d&apos;Utilisation</h1>
      <p>
        Les présentes conditions encadrent l’accès et l’utilisation de la plateforme French Automotive Sector Analysis, publication en ligne dédiée à l’industrie automobile.
      </p>

      <h2>1. Objet</h2>
      <p>
        Le site diffuse des contenus analytiques et informatifs. Toute consultation implique l’acceptation des présentes conditions.
      </p>

      <h2>2. Accès au site</h2>
      <p>
        L’accès est libre. Les informations sont fournies à titre informatif et peuvent évoluer sans préavis.
      </p>

      <h2>3. Propriété intellectuelle</h2>
      <p>
        Les textes, illustrations et éléments graphiques demeurent la propriété de la publication ou de leurs auteures et auteurs. Toute reproduction nécessite une autorisation écrite.
      </p>

      <h2>4. Responsabilité</h2>
      <p>
        La rédaction veille à l’exactitude des informations, sans garantie d’exhaustivité. Les utilisateurs et utilisatrices conservent la responsabilité de l’interprétation des contenus.
      </p>

      <h2>5. Liens externes</h2>
      <p>
        Le site peut présenter des liens vers des ressources externes pour enrichir l’information. Leur contenu reste sous la responsabilité de leurs éditrices et éditeurs.
      </p>

      <h2>6. Modification des conditions</h2>
      <p>
        Les conditions peuvent être ajustées afin de prendre en compte l’évolution du cadre réglementaire ou des services proposés.
      </p>
    </div>
  );
};

export default ConditionsUtilisation;