import React from 'react';
import PublicationCard from '../components/PublicationCard';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Commentaires.module.css';

const comments = [
  {
    title: 'Directive Euro 7 : lecture d’impact pour les sites français',
    excerpt:
      'Analyse des arbitrages techniques, du calendrier de mise en conformité et des incidences pour les équipementiers de dépollution.',
    date: '5 mars 2024',
    image: 'https://picsum.photos/seed/euro7directive/800/600',
    alt: 'Banc d’essai de moteur pour tests d’émissions',
    category: 'Commentaire',
    tags: ['Normes', 'Emission']
  },
  {
    title: 'Automatisation et métiers : quelles formations prioritaires ?',
    excerpt:
      'Panorama des programmes de formation continue mis en place dans les pôles de production et retour d’expérience sur les robots collaboratifs.',
    date: '21 février 2024',
    image: 'https://picsum.photos/seed/robotcollaboratif/800/600',
    alt: 'Technicien opérant un robot collaboratif sur une chaîne',
    category: 'Commentaire',
    tags: ['Robotisation', 'Compétences']
  },
  {
    title: 'Stratégies de plateformes multi-énergies',
    excerpt:
      'Point d’étape sur le positionnement des constructeurs nationaux face à la coexistence des architectures thermiques, hybrides et électriques.',
    date: '7 février 2024',
    image: 'https://picsum.photos/seed/platformmulti/800/600',
    alt: 'Prototypes automobiles multi-énergies sur piste d’essai',
    category: 'Commentaire',
    tags: ['Stratégie', 'Plateforme']
  },
  {
    title: 'Infrastructure de recharge : coordination territoriale',
    excerpt:
      'Retour sur les comités régionaux pilotant l’implantation des bornes et les interfaces avec les réseaux autoroutiers.',
    date: '26 janvier 2024',
    image: 'https://picsum.photos/seed/rechargefr/800/600',
    alt: 'Station de recharge électrique en région',
    category: 'Commentaire',
    tags: ['Recharge', 'Territoires']
  }
];

const Commentaires = () => {
  usePageMeta(
    'Commentaires d’experts',
    'Les commentaires d’experts interprètent l’actualité réglementaire et technologique de l’automobile française.'
  );

  return (
    <div className={styles.page}>
      <section className={styles.intro}>
        <h1>Commentaires d’experts</h1>
        <p>
          Les experts mobilisés éclairent les décisions européennes et nationales, évaluent les impacts sur la production et décryptent les attentes des chaînes d’approvisionnement.
        </p>
      </section>
      <section className={styles.listing}>
        <div className={styles.grid}>
          {comments.map((item) => (
            <PublicationCard key={item.title} {...item} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default Commentaires;