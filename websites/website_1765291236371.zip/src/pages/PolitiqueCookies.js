import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './LegalPage.module.css';

const PolitiqueCookies = () => {
  usePageMeta(
    'Politique des cookies',
    'Politique d’utilisation des cookies pour French Automotive Sector Analysis.'
  );

  return (
    <div className={styles.page}>
      <h1>Politique des Cookies</h1>
      <p>
        Cette politique décrit l’usage des cookies et technologies similaires sur French Automotive Sector Analysis.
      </p>

      <h2>Cookies utilisés</h2>
      <p>
        Des cookies de mesure d’audience sont susceptibles d’être déposés afin de comprendre l’usage du site et d’améliorer l’expérience éditoriale.
      </p>

      <h2>Gestion du consentement</h2>
      <p>
        Le bandeau d’information permet d’accepter ou de refuser les cookies non essentiels. L’absence de consentement limite l’activation des mesures d’audience.
      </p>

      <h2>Durée de stockage</h2>
      <p>
        Les cookies ont une durée de vie limitée, précisée dans les paramètres du navigateur. Ils peuvent être supprimés manuellement à tout moment.
      </p>

      <h2>Contact</h2>
      <p>
        Pour toute question relative aux cookies, la rédaction reste disponible via le formulaire de contact.
      </p>
    </div>
  );
};

export default PolitiqueCookies;