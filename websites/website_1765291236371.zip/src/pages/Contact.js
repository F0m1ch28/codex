import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  organisation: '',
  subject: '',
  message: ''
};

const Contact = () => {
  usePageMeta(
    'Contact',
    'Le formulaire de contact permet de soumettre des informations à la rédaction de French Automotive Sector Analysis.'
  );

  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Nom complet requis.';
    if (!formData.email.trim()) {
      newErrors.email = 'Adresse électronique requise.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Format d’adresse non valide.';
    }
    if (!formData.message.trim()) newErrors.message = 'Message requis.';
    return newErrors;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);

    if (Object.keys(validation).length === 0) {
      setStatus('Le message a été transmis à la rédaction.');
      setFormData(initialState);
    } else {
      setStatus(null);
    }
  };

  return (
    <div className={styles.page}>
      <section className={styles.intro}>
        <h1>Contact éditorial</h1>
        <p>
          Publication en ligne. Le formulaire ci-dessous centralise les retours d’expérience, les demandes de précision et les propositions de collaboration pédagogique.
        </p>
      </section>
      <section className={styles.formSection}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Nom complet</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              placeholder="Nom et prénom"
            />
            {errors.name && <p className={styles.error}>{errors.name}</p>}
          </div>

          <div className={styles.field}>
            <label htmlFor="email">Adresse électronique</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="adresse@exemple.fr"
            />
            {errors.email && <p className={styles.error}>{errors.email}</p>}
          </div>

          <div className={styles.field}>
            <label htmlFor="organisation">Organisation (facultatif)</label>
            <input
              id="organisation"
              name="organisation"
              type="text"
              value={formData.organisation}
              onChange={handleChange}
              placeholder="Entreprise, institution, laboratoire…"
            />
          </div>

          <div className={styles.field}>
            <label htmlFor="subject">Sujet</label>
            <input
              id="subject"
              name="subject"
              type="text"
              value={formData.subject}
              onChange={handleChange}
              placeholder="Objet du message"
            />
          </div>

          <div className={styles.field}>
            <label htmlFor="message">Message</label>
            <textarea
              id="message"
              name="message"
              rows="6"
              value={formData.message}
              onChange={handleChange}
              placeholder="Détails du message"
            />
            {errors.message && <p className={styles.error}>{errors.message}</p>}
          </div>

          <button type="submit" className={styles.submitButton}>
            Envoyer
          </button>
          {status && <p className={styles.success}>{status}</p>}
        </form>
      </section>
    </div>
  );
};

export default Contact;