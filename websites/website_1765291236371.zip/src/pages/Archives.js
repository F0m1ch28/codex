import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Archives.module.css';

const archives = [
  {
    year: 2024,
    items: [
      'Mars 2024 – Panorama des gigafactories européennes et alliances franco-allemandes',
      'Février 2024 – Observatoire des infrastructures de recharge sur les axes nationaux',
      'Janvier 2024 – Dossier spécial sur la relocalisation des pièces critiques'
    ]
  },
  {
    year: 2023,
    items: [
      'Décembre 2023 – Chronologie des annonces de plateformes électriques en France',
      'Septembre 2023 – Étude des exportations de véhicules vers l’Afrique du Nord',
      'Juin 2023 – Cartographie des laboratoires d’essai partagés entre constructeurs'
    ]
  },
  {
    year: 2022,
    items: [
      'Novembre 2022 – Retour sur les plans de formation liés à l’automatisation',
      'Août 2022 – Analyse des flux logistiques combinant rail et route',
      'Avril 2022 – État des lieux des directives environnementales applicables'
    ]
  }
];

const Archives = () => {
  usePageMeta(
    'Archives',
    'Les archives retracent les publications majeures de French Automotive Sector Analysis sur l’automobile française.'
  );

  return (
    <div className={styles.page}>
      <section className={styles.intro}>
        <h1>Archives éditoriales</h1>
        <p>
          Les archives référencent les collections thématiques et chronologiques pour faciliter la consultation des dossiers publiés depuis 2022.
        </p>
      </section>
      <section className={styles.archiveList}>
        {archives.map((yearBlock) => (
          <div key={yearBlock.year} className={styles.yearBlock}>
            <div className={styles.yearBadge}>{yearBlock.year}</div>
            <ul className={styles.items}>
              {yearBlock.items.map((item) => (
                <li key={item} className={styles.item}>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </section>
    </div>
  );
};

export default Archives;