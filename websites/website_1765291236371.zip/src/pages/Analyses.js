import React from 'react';
import PublicationCard from '../components/PublicationCard';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Analyses.module.css';

const analyses = [
  {
    title: 'Réindustrialisation des plateformes de motorisations hybrides',
    excerpt:
      'Le dossier retrace la réorganisation des pôles de mécanique et l’intégration progressive des chaînes hybrides parallèles dans les usines françaises.',
    date: '12 mars 2024',
    image: 'https://picsum.photos/seed/hybrideusine/800/600',
    alt: 'Technicien vérifiant une chaîne de motorisation hybride',
    category: 'Analyse',
    tags: ['Powertrain', 'Automatisation']
  },
  {
    title: 'Benchmark européen des laboratoires d’essais batterie',
    excerpt:
      'Panorama des centres R&D français et transfrontaliers, des bancs cycliques aux laboratoires de vieillissement accéléré.',
    date: '2 mars 2024',
    image: 'https://picsum.photos/seed/labbatterie/800/600',
    alt: 'Laboratoire d’essai de batteries automobile',
    category: 'Analyse',
    tags: ['Batteries', 'R&D']
  },
  {
    title: 'Contrôle qualité et vision artificielle sur lignes de peinture',
    excerpt:
      'Étude sur la mise en œuvre des caméras hyperspectrales, les gains en précision et les besoins en compétences spécialisées.',
    date: '19 février 2024',
    image: 'https://picsum.photos/seed/visionartificielle/800/600',
    alt: 'Atelier de peinture automobile utilisant la vision artificielle',
    category: 'Analyse',
    tags: ['Vision', 'Qualité']
  },
  {
    title: 'Chaîne logistique des pièces critiques post-2020',
    excerpt:
      'Analyse des modes d’approvisionnement, de la relocalisation partielle et des collaborations avec les fournisseurs de semi-conducteurs.',
    date: '2 février 2024',
    image: 'https://picsum.photos/seed/logistiqueauto/800/600',
    alt: 'Entrepôt logistique automobile',
    category: 'Analyse',
    tags: ['Logistique', 'Semi-conducteurs']
  },
  {
    title: 'Conception modulaire des planches de bord nouvelle génération',
    excerpt:
      'Étude des matériaux composites, de l’intégration HMI et des contraintes de recyclabilité dictées par les directives européennes.',
    date: '23 janvier 2024',
    image: 'https://picsum.photos/seed/plancherhmi/800/600',
    alt: 'Planche de bord automobile avec interface moderne',
    category: 'Analyse',
    tags: ['Design', 'Normes']
  },
  {
    title: 'Plans de charge des sites français sur la décennie 2024-2034',
    excerpt:
      'Synthèse des annonces de production, des volumes projetés et des arbitrages entre véhicules thermiques, hybrides et électriques.',
    date: '15 janvier 2024',
    image: 'https://picsum.photos/seed/planchargusine/800/600',
    alt: 'Vue intérieure d’une usine automobile française',
    category: 'Analyse',
    tags: ['Production', 'Stratégie industrielle']
  }
];

const Analyses = () => {
  usePageMeta(
    'Analyses',
    'Les analyses de French Automotive Sector Analysis détaillent les évolutions industrielles et technologiques des constructeurs français.'
  );

  return (
    <div className={styles.page}>
      <section className={styles.intro}>
        <h1>Analyses approfondies</h1>
        <p>
          Chaque analyse repose sur des données de production, des entretiens avec des ingénieurs de terrain et une lecture critique des orientations européennes. La sélection couvre les transitions industrielle, énergétique et logistique.
        </p>
      </section>
      <section className={styles.listing}>
        <div className={styles.grid}>
          {analyses.map((item) => (
            <PublicationCard key={item.title} {...item} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default Analyses;