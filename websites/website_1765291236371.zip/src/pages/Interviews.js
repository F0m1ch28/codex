import React from 'react';
import PublicationCard from '../components/PublicationCard';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Interviews.module.css';

const interviews = [
  {
    title: 'Entretien avec la responsable R&D propulsion de Douvrin',
    excerpt:
      'L’ingénieure en chef détaille la coordination des équipes sur les modules hybrides et la cohabitation avec les lignes thermiques.',
    date: '8 mars 2024',
    image: 'https://picsum.photos/seed/interviewrd/800/600',
    alt: 'Ingénieure en discussion dans un laboratoire automobile',
    category: 'Interview',
    tags: ['Hybridation', 'Organisation']
  },
  {
    title: 'Dialogue avec les architectes des cockpits immersifs',
    excerpt:
      'Les designers expliquent la convergence entre ergonomie, sécurité et identité de marque sur les futurs cockpits connectés.',
    date: '22 février 2024',
    image: 'https://picsum.photos/seed/cockpitdesign/800/600',
    alt: 'Designer automobile devant un prototype de cockpit',
    category: 'Interview',
    tags: ['Design', 'Interfaces']
  },
  {
    title: 'Une vision logistique partagée avec le port de Zeebruges',
    excerpt:
      'Le directeur d’exploitation revient sur la mutualisation des hubs ferroviaires et maritimes dédiés aux exportations françaises.',
    date: '9 février 2024',
    image: 'https://picsum.photos/seed/portlogistique/800/600',
    alt: 'Gestionnaire logistique sur un terminal portuaire',
    category: 'Interview',
    tags: ['Logistique', 'Export']
  },
  {
    title: 'Regards croisés sur la cybersécurité embarquée',
    excerpt:
      'Deux responsables sécurité détaillent l’intégration des protocoles de mise à jour OTA et la coopération avec les laboratoires nationaux.',
    date: '1 février 2024',
    image: 'https://picsum.photos/seed/cyberauto/800/600',
    alt: 'Ordinateurs analysant des données automobiles',
    category: 'Interview',
    tags: ['Cybersécurité', 'Logiciel']
  }
];

const Interviews = () => {
  usePageMeta(
    'Interviews',
    'Les interviews donnent la parole aux spécialistes de l’industrie automobile française sur les enjeux technologiques et organisationnels.'
  );

  return (
    <div className={styles.page}>
      <section className={styles.intro}>
        <h1>Interviews</h1>
        <p>
          Les rencontres publient des échanges structurés avec les femmes et les hommes qui pilotent l’innovation automobile. Les propos sont contextualisés et mis en perspective avec les grands chantiers de transition.
        </p>
      </section>
      <section className={styles.listing}>
        <div className={styles.grid}>
          {interviews.map((item) => (
            <PublicationCard key={item.title} {...item} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default Interviews;