import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Camille Leroy',
    title: 'Rédactrice en chef, spécialiste transitions industrielles',
    image: 'https://picsum.photos/seed/camilleleroy/400/400'
  },
  {
    name: 'Julien Martin',
    title: 'Analyste R&D, expert motorisations hybrides',
    image: 'https://picsum.photos/seed/julienmartin/400/400'
  },
  {
    name: 'Nadia Bensaïd',
    title: 'Journaliste data, cartographie logistique',
    image: 'https://picsum.photos/seed/nadiabensaid/400/400'
  },
  {
    name: 'Hugo Perrier',
    title: 'Historien de l’automobile, veille réglementaire',
    image: 'https://picsum.photos/seed/hugoperrier/400/400'
  }
];

const About = () => {
  usePageMeta(
    'À Propos',
    'Le projet French Automotive Sector Analysis rassemble des spécialistes pour analyser l’industrie automobile française.'
  );

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div>
          <h1>À propos de la rédaction</h1>
          <p>
            French Automotive Sector Analysis est une publication en ligne qui confronte données industrielles, travaux de laboratoires et retours d’expérience afin d’éclairer les mutations du secteur automobile français.
          </p>
        </div>
      </section>

      <section className={styles.gridSection}>
        <div className={styles.block}>
          <h2>Méthodologie</h2>
          <p>
            Les dossiers sont construits à partir de cycles d’enquête comprenant veille réglementaire, collecte de données quantitatives, visites de sites et entretiens avec des spécialistes. Chaque publication est relue par un binôme expert/éditorial pour garantir la rigueur.
          </p>
        </div>
        <div className={styles.block}>
          <h2>Couverture géographique</h2>
          <p>
            La rédaction suit les usines implantées dans toutes les régions françaises, croise ses observations avec les initiatives européennes et assure une veille sur les marchés extérieurs clés pour les exportations françaises.
          </p>
        </div>
      </section>

      <section className={styles.timeline}>
        <h2>Repères éditoriaux</h2>
        <ul>
          <li>
            <span className={styles.year}>2024</span>
            <p>Lancement de l’observatoire sur les gigafactories européennes et extension du réseau de contributrices techniques.</p>
          </li>
          <li>
            <span className={styles.year}>2023</span>
            <p>Publication des cartes logistiques interactives reliant sites français et plateformes portuaires.</p>
          </li>
          <li>
            <span className={styles.year}>2022</span>
            <p>Création du projet et mise en place des premiers partenariats avec des laboratoires indépendants.</p>
          </li>
        </ul>
      </section>

      <section className={styles.team}>
        <h2>Équipe permanente</h2>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <div key={member.name} className={styles.member}>
              <div className={styles.avatar}>
                <img src={member.image} alt={member.name} />
              </div>
              <p className={styles.name}>{member.name}</p>
              <p className={styles.role}>{member.title}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default About;