import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import PublicationCard from '../components/PublicationCard';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Home.module.css';

const statsData = [
  { label: 'Constructeurs étudiés', value: 18 },
  { label: 'Sites industriels cartographiés', value: 54 },
  { label: 'Analystes contributrices et contributeurs', value: 12 }
];

const Home = () => {
  usePageMeta(
    'Accueil',
    'Panorama indépendant des enjeux de l’industrie automobile française : innovation, chaînes d’approvisionnement et transition énergétique.'
  );

  const [displayStats, setDisplayStats] = useState(statsData.map(() => 0));

  useEffect(() => {
    const intervals = statsData.map((stat, index) => {
      const step = Math.max(1, Math.ceil(stat.value / 48));
      const intervalId = setInterval(() => {
        setDisplayStats((prev) => {
          const updated = [...prev];
          if (updated[index] >= stat.value) {
            clearInterval(intervalId);
            return prev;
          }
          updated[index] = Math.min(stat.value, updated[index] + step);
          if (updated[index] >= stat.value) {
            clearInterval(intervalId);
          }
          return updated;
        });
      }, 60);
      return intervalId;
    });

    return () => {
      intervals.forEach((id) => clearInterval(id));
    };
  }, []);

  const latestPublications = useMemo(
    () => [
      {
        title: 'Transformation des lignes d’assemblage en France',
        excerpt:
          'La revue technique examine la modernisation progressive des sites nationaux et la montée en cadence des plateformes multi-énergies.',
        date: '12 mars 2024',
        image: 'https://picsum.photos/seed/assemblagefr/800/600',
        alt: 'Chaîne d’assemblage automobile modernisée',
        category: 'Analyse',
        tags: ['Robotisation', 'Production', 'France']
      },
      {
        title: 'Cartographie des gigafactories en Europe',
        excerpt:
          'Les analystes passent au crible les projets de batteries et évaluent les complémentarités entre acteurs français et partenaires européens.',
        date: '4 mars 2024',
        image: 'https://picsum.photos/seed/gigafactoryeu/800/600',
        alt: 'Vue aérienne d’une usine de batteries',
        category: 'Analyse',
        tags: ['Batteries', 'Investissements industriels', 'Union européenne']
      },
      {
        title: 'Regards croisés sur l’hybridation',
        excerpt:
          'Les ingénieures interrogées décryptent les arbitrages entre chaînes cinématiques hybrides et tout-électrique sur les segments B et C.',
        date: '27 février 2024',
        image: 'https://picsum.photos/seed/hybridationfr/800/600',
        alt: 'Prototype automobile hybride sur banc d’essai',
        category: 'Interview',
        tags: ['Motorisations', 'Innovation']
      },
      {
        title: 'Logistique portuaire et exportations françaises',
        excerpt:
          'Un dossier met en perspective les hubs maritimes et ferroviaires mobilisés pour les livraisons de véhicules vers le reste du monde.',
        date: '19 février 2024',
        image: 'https://picsum.photos/seed/logistiqueports/800/600',
        alt: 'Terminal portuaire automobile',
        category: 'Commentaire',
        tags: ['Logistique', 'Exportations']
      }
    ],
    []
  );

  const keyTopics = [
    {
      title: 'Électrification et batteries',
      description:
        'Analyses détaillées des technologies de cellules, des partenariats industriels et des politiques publiques européennes.'
    },
    {
      title: 'Ingénierie et R&D',
      description:
        'Focus constant sur la recherche en motorisations, les bancs d’essai et le pilotage des programmes de conduite assistée.'
    },
    {
      title: 'Chaîne d’approvisionnement',
      description:
        'Suivi précis des flux matières, des équipementiers stratégiques et des adaptations logistiques en période de transition.'
    },
    {
      title: 'Marchés et design',
      description:
        'Décryptages des tendances de consommation, de la dynamique export et de l’évolution stylistique des modèles.'
    }
  ];

  const formats = [
    {
      title: 'Analyses',
      description:
        'Études approfondies, appuyées sur des données industrielles, des entretiens techniques et des retours d’expérience de terrain.'
    },
    {
      title: 'Interviews',
      description:
        'Entretiens structurés avec responsables R&D, designers, logisticiens et responsables de laboratoires spécialisés.'
    },
    {
      title: 'Commentaires d’experts',
      description:
        'Regards argumentés de spécialistes sur l’actualité réglementaire, technologique ou industrielle du secteur.'
    }
  ];

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.kicker}>Observatoire automobile</p>
          <h1>French Automotive Sector Analysis</h1>
          <p className={styles.subtitle}>
            La rédaction documente la mutation de l’industrie automobile française, des ateliers historiques aux plates-formes d’électrification, en s’appuyant sur des enquêtes de terrain et des données techniques.
          </p>
          <div className={styles.heroLinks}>
            <Link to="/analyses" className={styles.heroLink}>
              Section Analyses
            </Link>
            <Link to="/a-propos" className={styles.heroLinkSecondary}>
              Méthodologie éditoriale
            </Link>
          </div>
        </div>
        <div className={styles.heroVisual} aria-hidden="true">
          <div className={styles.heroImage} />
        </div>
      </section>

      <section className={styles.stats}>
        {statsData.map((stat, index) => (
          <div key={stat.label} className={styles.statItem}>
            <span className={styles.statValue}>{displayStats[index]}</span>
            <span className={styles.statLabel}>{stat.label}</span>
          </div>
        ))}
      </section>

      <section className={styles.latest}>
        <div className={styles.sectionHeader}>
          <h2>Dernières publications</h2>
          <p>
            La sélection ci-dessous met en lumière les dossiers récemment détaillés par la rédaction et ses partenaires scientifiques.
          </p>
        </div>
        <div className={styles.grid}>
          {latestPublications.map((item) => (
            <PublicationCard key={item.title} {...item} />
          ))}
        </div>
      </section>

      <section className={styles.topics}>
        <div className={styles.sectionHeader}>
          <h2>Chantiers de recherche prioritaires</h2>
          <p>
            Les axes de travail s’articulent autour des transformations industrielles, des choix technologiques et des cadres réglementaires européens.
          </p>
        </div>
        <div className={styles.topicsGrid}>
          {keyTopics.map((topic) => (
            <div key={topic.title} className={styles.topicCard}>
              <h3>{topic.title}</h3>
              <p>{topic.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.formats}>
        <div className={styles.sectionHeader}>
          <h2>Formats éditoriaux</h2>
          <p>
            Chaque format répond à un protocole de collecte d’informations distinct afin de garantir la précision et la contextualisation des conclusions.
          </p>
        </div>
        <div className={styles.formatGrid}>
          {formats.map((format) => (
            <div key={format.title} className={styles.formatCard}>
              <h3>{format.title}</h3>
              <p>{format.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.aboutPreview}>
        <div className={styles.aboutContent}>
          <h2>Vision éditoriale</h2>
          <p>
            L’équipe rassemble des profils issus de l’ingénierie, de l’histoire industrielle et de l’économie pour documenter la trajectoire des constructeurs nationaux et des réseaux de sous-traitance. Les enquêtes privilégient les approches comparatives entre régions françaises et pôles européens.
          </p>
          <Link to="/a-propos" className={styles.heroLink}>
            Découvrir l’orientation du projet
          </Link>
        </div>
        <div className={styles.aboutVisual} aria-hidden="true">
          <img src="https://picsum.photos/seed/laboauto/900/700" alt="Centre de recherche automobile en activité" />
        </div>
      </section>
    </div>
  );
};

export default Home;