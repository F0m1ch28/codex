import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import ScrollToTopButton from './components/ScrollToTopButton';

import Home from './pages/Home';
import Analyses from './pages/Analyses';
import Interviews from './pages/Interviews';
import Commentaires from './pages/Commentaires';
import Archives from './pages/Archives';
import About from './pages/About';
import Contact from './pages/Contact';
import ConditionsUtilisation from './pages/ConditionsUtilisation';
import PolitiqueConfidentialite from './pages/PolitiqueConfidentialite';
import PolitiqueCookies from './pages/PolitiqueCookies';

const Layout = ({ children }) => (
  <>
    <Header />
    <main className="mainContent">{children}</main>
    <Footer />
    <ScrollToTopButton />
    <CookieBanner />
  </>
);

const App = () => {
  return (
    <>
      <ScrollToTop />
      <Routes>
        <Route
          path="/"
          element={
            <Layout>
              <Home />
            </Layout>
          }
        />
        <Route
          path="/analyses"
          element={
            <Layout>
              <Analyses />
            </Layout>
          }
        />
        <Route
          path="/interviews"
          element={
            <Layout>
              <Interviews />
            </Layout>
          }
        />
        <Route
          path="/commentaires"
          element={
            <Layout>
              <Commentaires />
            </Layout>
          }
        />
        <Route
          path="/archives"
          element={
            <Layout>
              <Archives />
            </Layout>
          }
        />
        <Route
          path="/a-propos"
          element={
            <Layout>
              <About />
            </Layout>
          }
        />
        <Route
          path="/contact"
          element={
            <Layout>
              <Contact />
            </Layout>
          }
        />
        <Route
          path="/conditions-utilisation"
          element={
            <Layout>
              <ConditionsUtilisation />
            </Layout>
          }
        />
        <Route
          path="/politique-confidentialite"
          element={
            <Layout>
              <PolitiqueConfidentialite />
            </Layout>
          }
        />
        <Route
          path="/politique-cookies"
          element={
            <Layout>
              <PolitiqueCookies />
            </Layout>
          }
        />
      </Routes>
    </>
  );
};

export default App;