import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'fa-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner}>
      <p className={styles.text}>
        Ce site utilise des cookies pour mesurer l’audience et optimiser l’expérience éditoriale. Consultez la{' '}
        <Link to="/politique-cookies" className={styles.link}>politique des cookies</Link>.
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Accepter
      </button>
    </div>
  );
};

export default CookieBanner;