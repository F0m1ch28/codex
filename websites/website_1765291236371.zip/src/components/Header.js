import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Accueil' },
  { path: '/analyses', label: 'Analyses' },
  { path: '/interviews', label: 'Interviews' },
  { path: '/commentaires', label: 'Commentaires' },
  { path: '/archives', label: 'Archives' },
  { path: '/a-propos', label: 'À Propos' },
  { path: '/contact', label: 'Contact' }
];

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} aria-label="Accueil French Automotive Sector Analysis">
          French Automotive Sector Analysis
        </NavLink>
        <button
          className={styles.burger}
          type="button"
          onClick={() => setIsMenuOpen((prev) => !prev)}
          aria-expanded={isMenuOpen}
          aria-controls="site-navigation"
          aria-label="Ouvrir le menu"
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          id="site-navigation"
          className={`${styles.nav} ${isMenuOpen ? styles.open : ''}`}
        >
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                isActive ? `${styles.link} ${styles.active}` : styles.link
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;