import React from 'react';
import styles from './PublicationCard.module.css';

const PublicationCard = ({ title, excerpt, date, image, alt, category, tags }) => {
  return (
    <article className={styles.card}>
      <div className={styles.imageWrapper}>
        <img src={image} alt={alt} loading="lazy" />
      </div>
      <div className={styles.content}>
        <p className={styles.meta}>
          <span className={styles.category}>{category}</span>
          <span className={styles.date}>{date}</span>
        </p>
        <h3 className={styles.title}>{title}</h3>
        <p className={styles.excerpt}>{excerpt}</p>
        {tags && (
          <ul className={styles.tags}>
            {tags.map((tag) => (
              <li key={tag} className={styles.tag}>
                {tag}
              </li>
            ))}
          </ul>
        )}
      </div>
    </article>
  );
};

export default PublicationCard;