import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.col}>
          <p className={styles.brand}>French Automotive Sector Analysis</p>
          <p className={styles.description}>
            Publication en ligne dédiée à l’étude panoramique de l’industrie automobile française et européenne.
          </p>
        </div>
        <div className={styles.col}>
          <h3 className={styles.heading}>Navigation</h3>
          <nav className={styles.links}>
            <NavLink to="/" className={styles.link}>Accueil</NavLink>
            <NavLink to="/analyses" className={styles.link}>Analyses</NavLink>
            <NavLink to="/interviews" className={styles.link}>Interviews</NavLink>
            <NavLink to="/commentaires" className={styles.link}>Commentaires</NavLink>
            <NavLink to="/archives" className={styles.link}>Archives</NavLink>
            <NavLink to="/a-propos" className={styles.link}>À Propos</NavLink>
            <NavLink to="/contact" className={styles.link}>Contact</NavLink>
          </nav>
        </div>
        <div className={styles.col}>
          <h3 className={styles.heading}>Références</h3>
          <nav className={styles.links}>
            <NavLink to="/conditions-utilisation" className={styles.link}>Conditions d&apos;Utilisation</NavLink>
            <NavLink to="/politique-confidentialite" className={styles.link}>Politique de Confidentialité</NavLink>
            <NavLink to="/politique-cookies" className={styles.link}>Politique des Cookies</NavLink>
          </nav>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} French Automotive Sector Analysis. Tous droits réservés.</p>
      </div>
    </footer>
  );
};

export default Footer;