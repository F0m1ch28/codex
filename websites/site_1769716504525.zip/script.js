const I18N = {
  fr: {
    "header.logo": "danswholesaleplants",
    "nav.home": "Accueil",
    "nav.services": "Services",
    "nav.about": "Profil",
    "nav.blog": "Blog",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "nav.toggle": "Menu",
    "header.lang.fr": "FR",
    "header.lang.en": "EN",
    "footer.brand": "danswholesaleplants",
    "footer.tagline": "Observatoire spécialisé en orientation spatiale et signalétique numérique pour les environnements bâtis.",
    "footer.contactTitle": "Coordonnées",
    "footer.phoneText": "Téléphone : +32 2 123 45 67",
    "footer.emailText": "Courriel : contact@danswholesaleplants.com",
    "footer.addressText": "Adresse : Rue de la Loi 200, 1040 Bruxelles, Belgique",
    "footer.legalTitle": "Informations légales",
    "footer.terms": "Conditions d’utilisation",
    "footer.privacy": "Politique de confidentialité",
    "footer.cookies": "Politique relative aux cookies",
    "footer.refund": "Politique de rétractation",
    "footer.disclaimer": "Clause de non-responsabilité",
    "footer.manageCookies": "Gérer les cookies",
    "footer.copyright": "© {year} danswholesaleplants. Tous droits réservés.",
    "cookie.title": "Gestion des cookies",
    "cookie.description": "Nous utilisons des cookies pour analyser la navigation et améliorer l’expérience d’orientation numérique. Ajustez vos préférences selon vos besoins.",
    "cookie.manage": "Afficher les préférences",
    "cookie.manageLink": "Modifier les préférences de cookies",
    "cookie.accept": "Tout accepter",
    "cookie.decline": "Tout refuser",
    "cookie.save": "Enregistrer les préférences",
    "cookie.preferencesTitle": "Catégories de cookies",
    "cookie.toggle.necessary": "Nécessaires",
    "cookie.toggle.necessaryDesc": "Ces cookies soutiennent les fonctionnalités fondamentales du site et ne peuvent être désactivés.",
    "cookie.toggle.preferences": "Préférences",
    "cookie.toggle.preferencesDesc": "Mémorisent votre langue et des paramètres de présentation pour vos prochaines visites.",
    "cookie.toggle.analytics": "Mesure d’audience",
    "cookie.toggle.analyticsDesc": "Aident à comprendre l’utilisation du site afin d’optimiser les contenus et les parcours.",
    "cookie.toggle.marketing": "Visibilité de contenu",
    "cookie.toggle.marketingDesc": "Permettent de diffuser des contenus intégrés ou des ressources externes pertinentes.",
    "toast.formSuccess": "Votre message est en cours d’acheminement vers notre équipe.",
    "toast.formError": "Veuillez vérifier les champs requis avant l’envoi.",
    "toast.cookieSaved": "Vos préférences de cookies ont été mises à jour.",
    "toast.cookieDeclined": "Seuls les cookies nécessaires restent actifs.",
    "toast.cookieAccepted": "Toutes les catégories de cookies sont désormais activées.",
    "title.home": "danswholesaleplants • Orientation spatiale et signalétique numérique",
    "meta.home": "Analyses approfondies en orientation spatiale, navigation intérieure et expérience utilisateur pour les infrastructures publiques en Belgique.",
    "home.hero.title": "Systèmes de guidage spatial pour des environnements publics lisibles",
    "home.hero.subtitle": "Nous explorons les interactions entre signalétique numérique, cartographie immersive et circulation piétonne afin de rendre les bâtiments complexes intuitifs à parcourir.",
    "home.hero.primary": "Explorer nos services",
    "home.hero.secondary": "Découvrir notre approche",
    "home.intro.title": "Comprendre les espaces bâtis par la donnée et le design informationnel",
    "home.intro.text": "Nous combinons des observations sur site, des simulations piétonnes et des interfaces interactives pour construire des parcours sans friction dans les infrastructures belges.",
    "home.intro.items.1.title": "Cartographie relationnelle",
    "home.intro.items.1.text": "Nous rationalisons les plans intérieurs à l’aide de matrices topologiques et de réseaux de points d’intérêt pour réduire l’effort cognitif des usagers.",
    "home.intro.items.2.title": "Signalétique numérique adaptative",
    "home.intro.items.2.text": "Les écrans dynamiques sont synchronisés avec les flux réels pour relayer des informations contextuelles, temps réel et multilingues.",
    "home.intro.items.3.title": "Analyse des flux piétons",
    "home.intro.items.3.text": "Nous modélisons les densités et trajectoires pour anticiper les congestions et prioriser les aménagements à forte valeur d’usage.",
    "home.matrix.title": "Architecture de parcours pour des espaces interconnectés",
    "home.matrix.text": "Chaque projet s’appuie sur un schéma systémique qui relie heuristiques de navigation, affordances spatiales et outils numériques afin de rendre les environnements plus accessibles.",
    "home.matrix.items.1.title": "Profils utilisateurs",
    "home.matrix.items.1.text": "Évaluation des capacités spatiales et des besoins de mobilité pour chaque typologie d’usager.",
    "home.matrix.items.2.title": "Points d’orientation",
    "home.matrix.items.2.text": "Sélection de repères visuels et auditifs qui structurent la progression et renforcent la confiance.",
    "home.matrix.items.3.title": "Interfaces interactives",
    "home.matrix.items.3.text": "Prototypage d’écrans tactiles, de bornes et de cartes mobiles en cohérence avec la signalétique physique.",
    "home.matrix.items.4.title": "Évaluation continue",
    "home.matrix.items.4.text": "Boucles de retour terrain incluant eye-tracking, observations in situ et métriques de déplacement.",
    "home.metrics.title": "Indicateurs de nos terrains d’étude",
    "home.metrics.items.1": "327 parcours piétons audités dans des gares, campus et hôpitaux depuis 2018.",
    "home.metrics.items.2": "68 schémas de signalétique numérique co-construits avec des institutions publiques.",
    "home.metrics.items.3": "92 ateliers menés avec des usagers à besoins spécifiques pour tester l’inclusivité des dispositifs.",
    "home.recommendations.title": "Recommandations stratégiques",
    "home.recommendations.text": "Nos synthèses combinent observations concrètes et cadres méthodologiques pour guider les équipes responsables des espaces complexes.",
    "home.recommendations.items.1.title": "Structurer les repères",
    "home.recommendations.items.1.text": "Organiser les points d’orientation selon une hiérarchie claire facilite la mémorisation des parcours et limite la surcharge visuelle.",
    "home.recommendations.items.2.title": "Synchroniser les supports",
    "home.recommendations.items.2.text": "Aligner la terminologie des plans imprimés, des applications mobiles et des écrans numériques renforce la cohérence cognitive.",
    "home.recommendations.items.3.title": "Mesurer l’expérience",
    "home.recommendations.items.3.text": "Mettre en place des indicateurs de fluence et de confort permet d’ajuster continuellement la signalétique à l’usage réel.",
    "home.testimonials.title": "Témoignages",
    "home.testimonials.text": "Institutions belges et réseaux urbains partagent leurs retours sur nos analyses d’orientation et de guidage.",
    "home.testimonials.items.1.quote": "« Les cartes interactives proposées ont clarifié le fonctionnement de notre campus et réduit les sollicitations au point d’accueil de 37 %. »",
    "home.testimonials.items.1.author": "Sophie Thys, Responsable information, Université urbaine de Bruxelles",
    "home.testimonials.items.2.quote": "« La visualisation des flux piétons a rendu évidente la nécessité de redistribuer nos points d’entrée et a soutenu la rénovation du hall principal. »",
    "home.testimonials.items.2.author": "Marc De Smet, Coordinateur mobilité, Centre administratif flamand",
    "home.blogHighlight.title": "Focus sur nos analyses",
    "home.blogHighlight.text": "Retrouvez une sélection d’articles qui explorent les dimensions techniques et humaines de nos études de signalétique.",
    "home.blogHighlight.more": "Consulter toutes les publications",
    "title.services": "Services d’expertise • danswholesaleplants",
    "meta.services": "Cartographie interactive, signalétique numérique et analyse de flux piétons pour optimiser les environnements publics en Belgique.",
    "services.hero.title": "Domaines d’expertise détaillés",
    "services.hero.subtitle": "Nous accompagnons les collectivités, institutions culturelles et infrastructures de transport dans la compréhension fine de leurs parcours usagers.",
    "services.intro.title": "Une approche articulant analyse, design et validation",
    "services.intro.text": "Chaque mission mobilise un ensemble coordonné de diagnostics de terrain, de modélisations numériques et de tests utilisateurs afin de révéler la structure réelle des espaces.",
    "services.cards.1.title": "Analyse des défis d’orientation",
    "services.cards.1.text": "Cartographie des points de friction, observation des comportements et identification des zones où la lisibilité spatiale doit être renforcée.",
    "services.cards.2.title": "Conception de signalétique numérique",
    "services.cards.2.text": "Définition de scénarios d’usage, choix des médiums et création d’interfaces modulaires pour guider en temps réel les usagers.",
    "services.cards.3.title": "Plans interactifs et modélisation 3D",
    "services.cards.3.text": "Assemblage de données géométriques, d’attributs fonctionnels et d’itinéraires personnalisables pour les écrans tactiles et applications.",
    "services.cards.4.title": "Parcours utilisateurs inclusifs",
    "services.cards.4.text": "Prise en compte des mobilités réduites, des besoins sensoriels spécifiques et des usages multilingues dans la constitution des parcours.",
    "services.cards.5.title": "Accessibilité et UX spatiale",
    "services.cards.5.text": "Évaluation de l’ergonomie des repères, audit de la continuité de l’information et recommandations pour garantir une orientation intuitive.",
    "services.layers.title": "Livrables structurés en plusieurs couches",
    "services.layers.text": "Nos contributions s’intègrent dans les processus existants grâce à des formats modulaires, exploitables par les architectes, urbanistes et équipes digitales.",
    "services.layers.list.1": "Rapports analytiques illustrés, comprenant cartes thermiques, lignes de désir et diagrammes de densité.",
    "services.layers.list.2": "Kits graphiques et chartes iconographiques pour harmoniser la signalétique numérique et physique.",
    "services.layers.list.3": "Prototypes interactifs testables sur tablette ou bornes afin de recueillir des retours rapides des usagers.",
    "services.process.title": "Cycle de collaboration",
    "services.process.text": "Nous opérons par séquences courtes pour maintenir une dynamique de terrain et corriger rapidement les trajectoires de projet.",
    "services.process.steps.1.title": "Immersion situées",
    "services.process.steps.1.text": "Visites, observations et entretiens avec le personnel pour dresser un portrait fidèle des contextes.",
    "services.process.steps.2.title": "Synthèse opérationnelle",
    "services.process.steps.2.text": "Convergence entre données mesurées et objectifs institutionnels pour prioriser les actions.",
    "services.process.steps.3.title": "Expérimentation",
    "services.process.steps.3.text": "Tests utilisateurs, itérations de prototypes et accompagnement à la mise en œuvre.",
    "title.about": "À propos • danswholesaleplants",
    "meta.about": "Profil de danswholesaleplants : recherche en orientation spatiale, design informationnel et accessibilité dans les espaces publics belges.",
    "about.hero.title": "Une équipe dédiée aux environnements complexes",
    "about.hero.subtitle": "Nous réunissons des analystes de flux, des designers d’information et des spécialistes en accessibilité pour décrypter la relation entre architecture et usagers.",
    "about.mission.title": "Mission",
    "about.mission.text": "Apporter des repères clairs dans les espaces multilocaux en articulant expertise technique et sensibilité aux usages quotidiens.",
    "about.mission.items.1": "Observer les interactions entre personnes, architecture et supports numériques.",
    "about.mission.items.2": "Transformer les données spatiales en stratégies lisibles et partageables.",
    "about.mission.items.3": "Renforcer l’autonomie des usagers grâce à une information accessible.",
    "about.timeline.title": "Repères chronologiques",
    "about.timeline.items.1.title": "2015 — Premières immersions",
    "about.timeline.items.1.text": "Analyse de gares bruxelloises et définition d’un protocole d’observation des flux piétons.",
    "about.timeline.items.2.title": "2017 — Cartographie augmentée",
    "about.timeline.items.2.text": "Développement de plans interactifs pour des hôpitaux universitaires et déploiement de bornes multilingues.",
    "about.timeline.items.3.title": "2020 — Méthodes hybrides",
    "about.timeline.items.3.text": "Couplage d’outils de simulation et d’enquêtes qualitatives pour les campus et les musées.",
    "about.timeline.items.4.title": "2023 — Accessibilité renforcée",
    "about.timeline.items.4.text": "Intégration systématique des retours de personnes à déficience sensorielle dans les scénarios d’orientation.",
    "about.metrics.title": "Données clés",
    "about.metrics.items.1.label": "Sites audités",
    "about.metrics.items.1.value": "54 infrastructures publiques belges accompagnées.",
    "about.metrics.items.2.label": "Langues couvertes",
    "about.metrics.items.2.value": "8 langues prises en compte dans les supports d’orientation.",
    "about.metrics.items.3.label": "Partenariats",
    "about.metrics.items.3.value": "21 institutions collaboratrices sur le territoire belge.",
    "about.team.title": "Composition de l’équipe",
    "about.team.text": "Des profils complémentaires garantissent une vision systémique de l’orientation spatiale.",
    "about.team.members.1": "Delphine Lemaire — Analyste des mobilités piétonnes.",
    "about.team.members.2": "Hugo Verbeeck — Designer d’information et systèmes d’écrans.",
    "about.team.members.3": "Maya Renson — Spécialiste accessibilité et tests utilisateurs.",
    "about.approach.title": "Approche",
    "about.approach.text": "Chaque intervention privilégie la co-construction avec les équipes sur place et fait dialoguer données, observation et design.",
    "title.blog": "Blog • Analyses d’orientation spatiale",
    "meta.blog": "Articles techniques sur la signalétique numérique, la cartographie des flux et l’expérience piétonne dans les environnements belges.",
    "blog.hero.title": "Veille et retours d’expérience",
    "blog.hero.subtitle": "Des analyses détaillées pour décrypter les environnements complexes et inspirer les projets de signalétique.",
    "blog.intro.text": "Chaque article s’appuie sur des cas concrets, des métriques de terrain et des pistes méthodologiques applicables aux bâtiments publics.",
    "blog.card.button": "Lire l’article",
    "post1.title": "Modéliser la cognition spatiale dans les pôles de transit multilignes",
    "post1.excerpt": "Nous étudions comment les voyageurs comprennent la profondeur d’un réseau de transit et identifient leurs options de correspondance dans des environnements superposés.",
    "post1.meta": "Publié le 12 février 2024 · 7 minutes de lecture",
    "post2.title": "Évaluer la lisibilité des écrans dynamiques dans les centres civiques européens",
    "post2.excerpt": "Analyse de la perception des messages numériques dans des halls multifonctionnels où cohabitent services administratifs et flux d’événements publics.",
    "post2.meta": "Publié le 5 mars 2024 · 8 minutes de lecture",
    "post3.title": "Intégrer des données capteurs dans des cartes de campus interactives",
    "post3.excerpt": "Retour sur l’agrégation de capteurs de fréquentation et de données horaires pour guider les usagers d’un campus polycentrique.",
    "post3.meta": "Publié le 28 mars 2024 · 9 minutes de lecture",
    "post4.title": "Concevoir une orientation inclusive pour les sites patrimoniaux",
    "post4.excerpt": "Étude des contraintes patrimoniales et des adaptations numériques nécessaires pour des musées et monuments accessibles.",
    "post4.meta": "Publié le 16 avril 2024 · 8 minutes de lecture",
    "post5.title": "Résilience des flux piétons en scénarios d’urgence",
    "post5.excerpt": "Simulation de situations critiques afin de sécuriser les évacuations dans les grands équipements culturels et sportifs.",
    "post5.meta": "Publié le 6 mai 2024 · 7 minutes de lecture",
    "title.post1": "Modéliser la cognition spatiale dans les pôles de transit multilignes",
    "meta.post1": "Analyse approfondie de la cognition spatiale et des modèles de navigation dans les pôles de transit multilignes en Belgique.",
    "post1.section1.title": "Ancrer la modélisation dans la réalité des flux superposés",
    "post1.section1.p1": "Les pôles de transit multilignes, fréquents en Belgique, combinent trains, métros, bus et liaisons piétonnes aériennes. Nous avons observé pendant trois semaines un nœud majeur pour mesurer la manière dont les voyageurs élaborent leurs repères. Les entretiens ont révélé que la lecture simultanée de plusieurs niveaux suggère une structure mentale stratifiée où les repères visuels doivent être hiérarchisés.",
    "post1.section1.p2": "Pour traduire cette cartographie mentale, nous avons construit un modèle prenant en compte les transitions verticales et horizontales. Les zones où la charge cognitive s’accumule correspondent aux intersections où les modes se croisent. La modélisation démontre l’importance d’un langage graphique cohérent entre les supports physiques et numériques pour que l’usager garde une vision claire des enchaînements.",
    "post1.section1.subtitle": "Hiérarchie des repères multimodaux",
    "post1.section1.p3": "Les usagers localisent d’abord les informations générales (direction des lignes), puis recherchent les détails spécifiques (quais, temps d’attente). Une iconographie stable, associée à un code couleur constant, favorise la mémorisation et réduit les détours. C’est à cette condition que le modèle reste cohérent et que l’expérience se consolide.",
    "post1.section2.title": "Synchroniser données temps réel et plans statiques",
    "post1.section2.p1": "La plupart des pôles de transit belges disposent d’écrans dynamiques, mais leurs contenus ne sont pas toujours alignés sur la structure des plans fixes. Nous avons testé deux prototypes : l’un mettant en avant l’information de temps réel, l’autre privilégiant la représentation spatiale. Les voyageurs ont mieux retenu la destination lorsque les deux formats partageaient la même nomenclature et les mêmes repères visuels.",
    "post1.section2.p2": "Le modèle algorithmique intègre désormais un module de cohérence terminologique. Lorsqu’un changement de voie survient, le message numérique est automatiquement assorti d’un renvoi visuel correspondant sur les plans physiques. Cette synchronisation limite les hésitations et diminue les croisements intempestifs sur les passerelles.",
    "post1.section2.subtitle": "Gestion des changements inattendus",
    "post1.section2.p3": "Les perturbations révèlent les fragilités des modèles cognitifs. Nous avons simulé des reroutages en temps réel et analysé la propagation des détours. Les voyageurs bénéficiant d’un message aligné sur la cartographie de base ajustent rapidement leur trajectoire, tandis que les autres multiplient les retours en arrière. L’enjeu consiste donc à ancrer toute alerte sur des repères préalablement stabilisés.",
    "post1.section3.title": "Inclure la diversité des profils de voyageurs",
    "post1.section3.p1": "La cognition spatiale varie selon la fréquence d’usage, la maîtrise linguistique ou les capacités sensorielles. Nous avons constitué des groupes de test incluant des personnes à mobilité réduite, des touristes et des travailleurs quotidiens. Chacun a décrit sa logique de déplacement, révélant des besoins spécifiques en matière de rétroaction tactile, sonore ou contrastée.",
    "post1.section3.p2": "L’intégration de ces profils dans le modèle aboutit à des parcours alternatifs qui respectent les contraintes individuelles. Une signalétique numérique accessible doit proposer plusieurs modalités simultanées : texte clair, iconographie, audio et vibration. Les plateformes belges testées ont démontré que la combinaison de ces éléments améliore la confiance et l’autonomie.",
    "post1.section3.subtitle": "Vers un modèle évolutif",
    "post1.section3.p3": "Nous avons mis en place un tableau de bord qui mesure la compréhension des repères au fil du temps. Les ajustements de signalétique sont évalués sur la base des temps de parcours, des flux de questions adressées au personnel et des retours qualitatifs. Ce suivi continu transforme la modélisation en un outil vivant, capable de s’adapter aux évolutions des infrastructures.",
    "post1.conclusion.title": "Perspectives pour les pôles belges",
    "post1.conclusion.p1": "Les pôles de transit multilignes exigent une lecture simultanée de plusieurs couches d’information. La cohérence graphique, la synchronisation des données et l’attention aux divers profils utilisateur sont les trois piliers de notre modèle. Ils permettent de réduire la friction cognitive et d’augmenter la fluidité des déplacements.",
    "post1.conclusion.p2": "Les prochaines étapes consistent à intégrer davantage de capteurs pour affiner les prévisions de flux et à renforcer les programmes de tests auprès des usagers occasionnels. L’objectif reste d’offrir une orientation fiable, quel que soit le degré de familiarité avec le réseau.",
    "title.post2": "Évaluer la lisibilité des écrans dynamiques dans les centres civiques européens",
    "meta.post2": "Étude approfondie de la lisibilité des écrans dynamiques et de la signalétique numérique dans les centres civiques européens.",
    "post2.section1.title": "Comprendre les contraintes d’un hall polyvalent",
    "post2.section1.p1": "Les centres civiques belges concentrent des services administratifs, culturels et associatifs. Les écrans dynamiques y diffusent des annonces institutionnelles, des appels de guichet et des indications directionnelles. Nous avons étudié quatre sites représentatifs, en analysant la visibilité des messages selon l’angle de vue, la luminosité et la densité d’information.",
    "post2.section1.p2": "Les mesures photométriques ont montré que la lisibilité décroît lorsque l’intensité lumineuse dépasse 400 lux, notamment dans les halls vitrés. L’ajout d’un contraste renforcé et d’une typographie sans serif avec interligne large améliore la compréhension, surtout pour les annonces multilingues.",
    "post2.section1.subtitle": "Temps de consultation",
    "post2.section1.p3": "En moyenne, les usagers disposent de 6 à 9 secondes pour consulter un écran. Les messages les plus efficaces sont structurés par blocs courts, chacun consacré à une fonction précise : orientation, services, alertes. Cette segmentation réduit la charge cognitive et favorise le repérage rapide des informations pertinentes.",
    "post2.section2.title": "Synchroniser les écrans avec la signalétique fixe",
    "post2.section2.p1": "Les écrans dynamiques deviennent réellement utiles lorsqu’ils prolongent la signalétique existante. Nous avons cartographié les points de divergence terminologique entre supports numériques et panneaux physiques. Une harmonisation a été opérée afin que chaque zone, nom et pictogramme corresponde parfaitement aux plans papier et aux applications mobiles.",
    "post2.section2.p2": "Après harmonisation, les enquêtes ont révélé une baisse de 42 % des demandes d’orientation auprès du personnel d’accueil. Les usagers signalent que l’alignement des termes, des couleurs et des flèches leur permet de passer des écrans aux couloirs sans hésitation.",
    "post2.section2.subtitle": "Intégrer les alertes temporaires",
    "post2.section2.p3": "Les événements ponctuels (réunions citoyennes, expositions) introduisent des changements rapides. Nous avons mis en place un gabarit d’alertes standardisé, accompagné d’un marquage au sol temporaire. Cette coordination limite les confusions et assure une mise à jour cohérente sur tous les supports.",
    "post2.section3.title": "Prendre en compte les besoins d’accessibilité",
    "post2.section3.p1": "Les écrans doivent rester lisibles pour des personnes présentant des déficiences visuelles, auditives ou cognitives. Nous avons testé la compatibilité avec des lecteurs d’écran et vérifié la présence d’alternatives audio dans les espaces d’attente. Les contrastes ont été renforcés et les animations superflues supprimées pour stabiliser la lecture.",
    "post2.section3.p2": "Des boucles à induction magnétique ont été installées à proximité des écrans prioritaires afin d’orienter les personnes appareillées. Par ailleurs, les messages essentiels sont relayés sur une application mobile accessible, synchronisée en temps réel avec les contenus diffusés sur site.",
    "post2.section3.subtitle": "Vers une gouvernance éditoriale",
    "post2.section3.p3": "La lisibilité des écrans dépend d’une gouvernance éditoriale structurée. Nous avons accompagné les équipes internes dans la création d’un calendrier de publication, d’un processus de validation et d’un protocole de test régulier. Chaque mise à jour est désormais évaluée selon des indicateurs de clarté et de compréhension.",
    "post2.conclusion.title": "Gagner en cohérence dans les centres civiques",
    "post2.conclusion.p1": "L’efficacité des écrans dynamiques repose sur la convergence entre éléments visuels, scénarios de contenu et exigences d’accessibilité. Les centres civiques étudiés ont réduit les temps d’orientation et amélioré la satisfaction des usagers en appliquant ces principes.",
    "post2.conclusion.p2": "Nous poursuivons l’analyse en suivant l’évolution des usages au fil des saisons et en intégrant les retours des agents d’accueil, garants de la continuité d’information.",
    "title.post3": "Intégrer des données capteurs dans des cartes de campus interactives",
    "meta.post3": "Méthodologie d’intégration des données de capteurs dans des cartes de campus interactives pour optimiser la mobilité piétonne.",
    "post3.section1.title": "Fusionner des sources de données hétérogènes",
    "post3.section1.p1": "Les campus belges s’étendent souvent sur plusieurs pôles reliés par des cheminements piétons et des transports internes. Nous avons agrégé des données issues de capteurs Wi-Fi anonymisés, de compteurs optiques et de relevés manuels pour estimer les flux quotidiens.",
    "post3.section1.p2": "Un moteur de traitement unifie ces données toutes les cinq minutes afin d’alimenter les cartes interactives. Les fluctuations sont visualisées sous forme de couches colorées, facilitant l’identification des couloirs surchargés et des zones sous-utilisées.",
    "post3.section1.subtitle": "Qualité et fiabilité des mesures",
    "post3.section1.p3": "La calibration est essentielle pour maintenir la fiabilité du dispositif. Nous avons comparé les comptages automatiques avec des observations terrain pour ajuster les coefficients de conversion et corriger les biais liés aux doubles comptages.",
    "post3.section2.title": "Créer des parcours adaptatifs",
    "post3.section2.p1": "Les cartes interactives proposent désormais des itinéraires recommandés qui tiennent compte de l’affluence en temps réel. Lorsqu’un couloir dépasse un seuil de densité, des chemins alternatifs sont suggérés avec une estimation précise de la durée.",
    "post3.section2.p2": "Les usagers apprécient particulièrement les notifications contextuelles envoyées 10 minutes avant les changements de cours, leur permettant d’anticiper les déplacements. Les retours soulignent une diminution des retards et une meilleure répartition des flux.",
    "post3.section2.subtitle": "Respect de la vie privée",
    "post3.section2.p3": "Le traitement des données respecte strictement l’anonymat. Les identifiants sont hachés en périphérie et aucun suivi individuel n’est conservé. Cette transparence renforce la confiance et facilite l’adhésion de la communauté universitaire.",
    "post3.section3.title": "Accompagner les équipes opérationnelles",
    "post3.section3.p1": "Les cartes sont accompagnées d’un tableau de bord destiné aux équipes logistiques. Il présente des indicateurs de fréquentation, des alertes en cas de saturation et des recommandations pour ajuster la signalétique temporaire.",
    "post3.section3.p2": "Des formations ont été organisées pour que les services techniques interprètent correctement les données et planifient des interventions ciblées, qu’il s’agisse de maintenance ou de redistribution d’espaces.",
    "post3.section3.subtitle": "Évolutions à venir",
    "post3.section3.p3": "Les prochaines étapes explorent l’intégration de données météorologiques et de chantiers afin d’ajuster les parcours proposés. L’objectif est de maintenir une navigation fluide même en contexte changeant.",
    "post3.conclusion.title": "Cartes vivantes pour campus dynamiques",
    "post3.conclusion.p1": "En reliant capteurs et cartographie, les campus disposent d’un outil opérationnel pour améliorer la circulation et offrir une meilleure expérience aux usagers.",
    "post3.conclusion.p2": "Le modèle mis en place en Belgique peut inspirer d’autres territoires cherchant à synchroniser données et orientation dans des ensembles bâtis complexes.",
    "title.post4": "Concevoir une orientation inclusive pour les sites patrimoniaux",
    "meta.post4": "Étude de conception d’une orientation inclusive pour les sites patrimoniaux combinant respect architectural et accessibilité.",
    "post4.section1.title": "Respecter le patrimoine tout en informant",
    "post4.section1.p1": "Les sites patrimoniaux présentent des contraintes fortes : conservation des matériaux, réglementation stricte et flux de visiteurs fluctuants. Nous avons travaillé avec trois institutions belges pour concilier protection des lieux et orientation accessible.",
    "post4.section1.p2": "La signalétique physique privilégie des matériaux compatibles avec les bâtiments historiques, tandis que les supports numériques prennent le relais pour fournir du contenu détaillé sans surcharger les espaces.",
    "post4.section1.subtitle": "Dispositifs discrets",
    "post4.section1.p3": "Les dispositifs numériques sont intégrés dans des bornes autoportantes en retrait, évitant toute fixation sur les murs classés. Les éclairages sont calibrés pour ne pas altérer les matériaux tout en garantissant la lisibilité.",
    "post4.section2.title": "Rendre l’information accessible à tous",
    "post4.section2.p1": "Nous avons développé des parcours audio-guidés synchronisés avec la signalétique. Les visiteurs peuvent choisir des narrations adaptées, incluant des descriptions précises pour les personnes malvoyantes.",
    "post4.section2.p2": "Des maquettes tactiles et des cartes en relief complètent l’expérience. Les contenus numériques sont disponibles en plusieurs langues, avec un soin particulier accordé à la simplicité des phrases et à la cohérence des pictogrammes.",
    "post4.section2.subtitle": "Gestion des flux",
    "post4.section2.p3": "Les données de fréquentation permettent d’équilibrer les flux entre espaces majeurs et zones secondaires. Des notifications invitent les visiteurs à explorer des itinéraires alternatifs lorsque les salles principales s’approchent de la saturation.",
    "post4.section3.title": "Co-construire avec les équipes et le public",
    "post4.section3.p1": "Des ateliers participatifs ont réuni conservateurs, médiateurs et visiteurs réguliers pour co-définir la palette graphique et les priorités d’information. Cette démarche garantit l’appropriation du dispositif.",
    "post4.section3.p2": "Les tests utilisateurs ont permis d’ajuster la hauteur des supports, le niveau sonore des audio-descriptions et la taille des typographies. Chaque ajustement a été validé par les équipes de conservation.",
    "post4.section3.subtitle": "Transmission et maintenance",
    "post4.section3.p3": "Un guide opérationnel détaille les procédures de mise à jour des contenus numériques, les contrôles de lisibilité et la maintenance des équipements. Les sites concernés gagnent en autonomie tout en respectant les contraintes patrimoniales.",
    "post4.conclusion.title": "Patrimoine et accessibilité convergent",
    "post4.conclusion.p1": "Grâce à une approche multi-support, les sites patrimoniaux peuvent offrir une orientation inclusive sans compromettre leur intégrité architecturale.",
    "post4.conclusion.p2": "Les collaborations en Belgique démontrent qu’un dialogue constant entre conservation et innovation renforce la qualité d’accueil.",
    "title.post5": "Résilience des flux piétons en scénarios d’urgence",
    "meta.post5": "Analyse de la résilience des flux piétons en scénarios d’urgence pour les grands équipements publics en Belgique.",
    "post5.section1.title": "Construire des scénarios réalistes",
    "post5.section1.p1": "Les grands équipements accueillant du public doivent anticiper des situations exceptionnelles. Nous avons élaboré des scénarios d’urgence pour des salles de spectacle et stades en Belgique, en combinant modélisation et exercices sur site.",
    "post5.section1.p2": "Chaque scénario tient compte de la configuration architecturale, de la densité maximale et des comportements observés lors d’événements. Les résultats mettent en lumière les goulots d’étranglement et les besoins de signalétique renforcée.",
    "post5.section1.subtitle": "Cartographier les issues",
    "post5.section1.p3": "Les issues secondaires sont souvent sous-utilisées. Nous avons testé des éclairages directionnels temporaires et des messages audio synchronisés pour guider les foules vers les itinéraires les plus rapides.",
    "post5.section2.title": "Synchroniser procédures et supports numériques",
    "post5.section2.p1": "Les plans d’évacuation numériques sont intégrés aux applications des sites. En cas d’alerte, ils affichent en temps réel les sorties recommandées en fonction de la zone où se trouve l’utilisateur.",
    "post5.section2.p2": "Les écrans sur place reprennent la même information, garantissant une cohérence totale. Les personnels formés peuvent déclencher des scénarios spécifiques par simple sélection d’un protocole.",
    "post5.section2.subtitle": "Tester et ajuster",
    "post5.section2.p3": "Des exercices périodiques valident le dispositif. Les rapports post-exercice identifient les sections où les flux ralentissent. Cela permet de repositionner la signalétique temporaire ou d’adapter la formation des équipes.",
    "post5.section3.title": "Penser l’accessibilité en situation critique",
    "post5.section3.p1": "Les parcours d’évacuation doivent intégrer les besoins des personnes à mobilité réduite ou accompagnées d’enfants. Nous avons prévu des zones de refuge signalées et équipées d’interfaces de communication accessibles.",
    "post5.section3.p2": "Des messages spécifiques sont diffusés pour indiquer les points de rassemblement et rappeler les gestes à adopter. Les informations sonores, visuelles et vibratoires travaillent de concert pour toucher tous les publics.",
    "post5.section3.subtitle": "Vers une résilience proactive",
    "post5.section3.p3": "La résilience repose sur la préparation continue. Les données collectées lors des exercices alimentent un suivi longitudinal, permettant de prioriser les investissements en fonction des gains de fluidité constatés.",
    "post5.conclusion.title": "Sécuriser les parcours en toute circonstance",
    "post5.conclusion.p1": "L’association de simulations numériques, d’outils interactifs et de formations ciblées renforce considérablement la sécurité des visiteurs.",
    "post5.conclusion.p2": "Les équipements belges engagés dans cette démarche améliorent leur capacité de réponse et renforcent la confiance du public.",
    "title.contact": "Contact • danswholesaleplants",
    "meta.contact": "Coordonnées de danswholesaleplants et formulaire de contact pour les projets d’orientation spatiale en Belgique.",
    "contact.hero.title": "Dialoguer avec notre équipe",
    "contact.hero.subtitle": "Partagez vos questions ou projets liés à la signalétique numérique et à l’accessibilité des espaces.",
    "contact.intro.title": "Informations générales",
    "contact.intro.text": "Nous analysons chaque demande afin de proposer des pistes adaptées aux contraintes de vos lieux.",
    "contact.info.title": "Coordonnées directes",
    "contact.info.description": "Nos bureaux bruxellois restent ouverts du lundi au vendredi, de 9h00 à 17h30.",
    "contact.info.phone": "Téléphone : +32 2 123 45 67",
    "contact.info.email": "Courriel : contact@danswholesaleplants.com",
    "contact.info.address": "Adresse : Rue de la Loi 200, 1040 Bruxelles, Belgique",
    "contact.info.hours": "Accueil sur rendez-vous pour les visites de site et ateliers.",
    "contact.map.title": "Situer nos bureaux",
    "contact.map.caption": "Carte interactive centrée sur notre implantation bruxelloise.",
    "contact.form.title": "Formulaire de contact",
    "contact.form.intro": "Décrivez votre environnement et les enjeux d’orientation observés.",
    "contact.form.nameLabel": "Nom et prénom",
    "contact.form.namePlaceholder": "Entrez votre nom complet",
    "contact.form.organisationLabel": "Organisation",
    "contact.form.organisationPlaceholder": "Indiquez votre structure",
    "contact.form.emailLabel": "Adresse e-mail",
    "contact.form.emailPlaceholder": "nom@organisation.be",
    "contact.form.subjectLabel": "Objet",
    "contact.form.subjectPlaceholder": "Sujet de votre message",
    "contact.form.messageLabel": "Message",
    "contact.form.messagePlaceholder": "Décrivez le contexte, les sites concernés et vos objectifs.",
    "contact.form.notice": "Nous répondons sous cinq jours ouvrés en fonction de la complexité de la demande.",
    "contact.form.submit": "Envoyer",
    "title.faq": "FAQ • danswholesaleplants",
    "meta.faq": "Questions fréquentes sur l’orientation spatiale, la signalétique numérique et la méthodologie de danswholesaleplants.",
    "faq.hero.title": "Questions fréquentes",
    "faq.hero.subtitle": "Clarifications sur nos méthodes, les données utilisées et la collaboration avec les équipes sur site.",
    "faq.q1.question": "Comment débute une mission d’analyse d’orientation ?",
    "faq.q1.answer": "Nous commençons par une immersion sur site pour observer les parcours, identifier les points de friction et rencontrer les équipes opérationnelles.",
    "faq.q2.question": "Travaillez-vous uniquement avec des institutions publiques ?",
    "faq.q2.answer": "Nos projets se concentrent sur les environnements complexes à forte fréquentation, majoritairement publics, mais nous intervenons aussi sur des campus privés ouverts.",
    "faq.q3.question": "Comment intégrez-vous les retours des usagers ?",
    "faq.q3.answer": "Des ateliers, tests utilisateurs et enquêtes structurées alimentent chaque phase de conception et de validation.",
    "faq.q4.question": "Les recommandations incluent-elles des aspects techniques ?",
    "faq.q4.answer": "Oui, nous fournissons des spécifications relatives aux écrans, aux systèmes de contenu et aux interfaces nécessaires au déploiement.",
    "faq.q5.question": "Proposez-vous un suivi après la mise en œuvre ?",
    "faq.q5.answer": "Nous assurons un suivi post-déploiement pour mesurer l’efficacité et ajuster les dispositifs selon l’usage réel.",
    "faq.q6.question": "Comment abordez-vous la question multilingue ?",
    "faq.q6.answer": "Nous analysons les besoins linguistiques dès l’audit initial et concevons des supports capables de basculer facilement entre les langues requises.",
    "title.terms": "Conditions d’utilisation • danswholesaleplants",
    "meta.terms": "Conditions d’utilisation du site danswholesaleplants.com, cadre légal et responsabilités.",
    "terms.title": "Conditions d’utilisation",
    "terms.intro": "Les présentes conditions régissent l’accès et l’usage du site danswholesaleplants.com. La consultation du site implique l’acceptation intégrale de ces dispositions.",
    "terms.section1.title": "1. Objet",
    "terms.section1.body": "Le site présente des informations relatives à l’orientation spatiale, à la signalétique numérique et à la recherche en accessibilité. Il ne propose pas de transaction commerciale.",
    "terms.section2.title": "2. Accès au site",
    "terms.section2.body": "L’accès est libre et gratuit. Les coûts de connexion restent à la charge de l’utilisateur qui veille à la compatibilité de ses équipements.",
    "terms.section3.title": "3. Propriété intellectuelle",
    "terms.section3.body": "Les contenus, textes, graphismes et schémas publiés sont protégés par le droit d’auteur. Toute reproduction nécessite une autorisation écrite.",
    "terms.section4.title": "4. Utilisation des contenus",
    "terms.section4.body": "Les informations peuvent être consultées pour un usage personnel ou institutionnel non commercial. Toute modification dénaturant le sens original est interdite.",
    "terms.section5.title": "5. Références externes",
    "terms.section5.body": "Le site peut comporter des liens vers d’autres ressources. Nous n’exerçons aucun contrôle sur leur contenu et déclinons toute responsabilité quant à leur mise à jour.",
    "terms.section6.title": "6. Exactitude des informations",
    "terms.section6.body": "Nous veillons à la fiabilité des contenus, sans garantir une exhaustivité permanente. Les informations peuvent évoluer selon l’état des recherches.",
    "terms.section7.title": "7. Responsabilité",
    "terms.section7.body": "Nous ne pouvons être tenus responsables des dommages directs ou indirects découlant de l’utilisation du site ou de l’impossibilité d’y accéder.",
    "terms.section8.title": "8. Compte utilisateur",
    "terms.section8.body": "Le site ne propose pas de compte utilisateur. Toute interaction se fait via les coordonnées de contact ou le formulaire dédié.",
    "terms.section9.title": "9. Données personnelles",
    "terms.section9.body": "Les informations communiquées via le formulaire sont traitées selon la politique de confidentialité et servent uniquement à répondre aux demandes.",
    "terms.section10.title": "10. Accessibilité",
    "terms.section10.body": "Nous nous engageons à améliorer l’accessibilité du site. Les retours peuvent être envoyés à l’adresse contact@danswholesaleplants.com.",
    "terms.section11.title": "11. Disponibilité",
    "terms.section11.body": "Le site peut être interrompu pour maintenance ou mise à jour. Nous faisons en sorte de limiter ces périodes.",
    "terms.section12.title": "12. Modification des conditions",
    "terms.section12.body": "Nous pouvons modifier les présentes conditions pour tenir compte des évolutions légales ou fonctionnelles. Les visiteurs sont invités à les consulter régulièrement.",
    "terms.section13.title": "13. Droit applicable",
    "terms.section13.body": "Les conditions sont régies par le droit belge. Tout litige relève de la compétence des juridictions de Bruxelles.",
    "terms.section14.title": "14. Contact",
    "terms.section14.body": "Pour toute question relative aux conditions, merci d’écrire à contact@danswholesaleplants.com.",
    "title.privacy": "Politique de confidentialité • danswholesaleplants",
    "meta.privacy": "Politique de confidentialité de danswholesaleplants concernant la collecte et l’utilisation des données.",
    "privacy.title": "Politique de confidentialité",
    "privacy.intro": "Cette politique décrit la manière dont nous traitons les données personnelles recueillies via danswholesaleplants.com.",
    "privacy.section1.title": "1. Responsable de traitement",
    "privacy.section1.body": "Le responsable du traitement est danswholesaleplants, établi Rue de la Loi 200, 1040 Bruxelles.",
    "privacy.section2.title": "2. Données collectées",
    "privacy.section2.body": "Nous collectons uniquement les informations communiquées via le formulaire de contact : nom, organisation, adresse e-mail, objet et message.",
    "privacy.section3.title": "3. Journaux techniques",
    "privacy.section3.body": "Le serveur enregistre des journaux techniques anonymisés (adresse IP tronquée, type de navigateur, date et heure) pour assurer la sécurité du site.",
    "privacy.section4.title": "4. Finalités",
    "privacy.section4.body": "Les données servent à répondre aux demandes, préparer d’éventuels échanges et assurer un suivi qualitatif des interactions.",
    "privacy.section5.title": "5. Base légale",
    "privacy.section5.body": "Le traitement repose sur votre consentement lorsque vous soumettez le formulaire et sur notre intérêt légitime à organiser les réponses.",
    "privacy.section6.title": "6. Partage des données",
    "privacy.section6.body": "Les données ne sont pas vendues. Elles peuvent être partagées avec des partenaires techniques uniquement pour assurer l’hébergement sécurisé.",
    "privacy.section7.title": "7. Durée de conservation",
    "privacy.section7.body": "Les messages sont conservés trois ans maximum afin de suivre l’historique des échanges, sauf demande de suppression plus rapide.",
    "privacy.section8.title": "8. Droits des personnes",
    "privacy.section8.body": "Vous disposez d’un droit d’accès, de rectification, d’effacement, de limitation et d’opposition. Adressez vos demandes à contact@danswholesaleplants.com.",
    "privacy.section9.title": "9. Sécurité",
    "privacy.section9.body": "Nous mettons en œuvre des mesures techniques et organisationnelles pour protéger les données contre tout accès non autorisé.",
    "privacy.section10.title": "10. Évolutions",
    "privacy.section10.body": "La présente politique peut être mise à jour. La date de révision est indiquée en tête de document.",
    "title.cookies": "Politique de cookies • danswholesaleplants",
    "meta.cookies": "Informations sur l’utilisation des cookies par danswholesaleplants et gestion des préférences.",
    "cookies.title": "Politique relative aux cookies",
    "cookies.intro": "Nous utilisons des cookies pour assurer le fonctionnement du site et analyser la fréquentation afin d’améliorer nos contenus.",
    "cookies.usage": "Les cookies non nécessaires ne sont activés qu’avec votre accord. Vous pouvez ajuster vos choix à tout moment via le module de gestion.",
    "cookies.table.name": "Nom du cookie",
    "cookies.table.provider": "Fournisseur",
    "cookies.table.type": "Type",
    "cookies.table.purpose": "Finalité",
    "cookies.table.duration": "Durée",
    "cookies.row1.name": "session_id",
    "cookies.row1.provider": "danswholesaleplants.com",
    "cookies.row1.type": "Nécessaire",
    "cookies.row1.purpose": "Maintenir la session active lors de la navigation.",
    "cookies.row1.duration": "Session",
    "cookies.row2.name": "lang_pref",
    "cookies.row2.provider": "danswholesaleplants.com",
    "cookies.row2.type": "Préférences",
    "cookies.row2.purpose": "Enregistrer la langue choisie pour les visites futures.",
    "cookies.row2.duration": "12 mois",
    "cookies.row3.name": "analytics_flow",
    "cookies.row3.provider": "danswholesaleplants.com",
    "cookies.row3.type": "Mesure d’audience",
    "cookies.row3.purpose": "Mesurer l’efficacité des parcours et repérer les pages consultées.",
    "cookies.row3.duration": "13 mois",
    "cookies.manage": "Vous pouvez à tout moment modifier vos préférences en cliquant sur « Gérer les cookies » dans le pied de page.",
    "cookies.contact": "Pour toute question, écrivez à contact@danswholesaleplants.com.",
    "title.refund": "Politique de rétractation • danswholesaleplants",
    "meta.refund": "Politique de rétractation de danswholesaleplants pour les contenus et informations publiés.",
    "refund.title": "Politique de rétractation",
    "refund.intro": "Notre site diffuse des contenus informationnels sans transaction commerciale. Cette politique précise la manière dont nous traitons les demandes de retrait.",
    "refund.section1.title": "1. Nature des contenus",
    "refund.section1.body": "Les documents proposés sont des analyses, articles et synthèses méthodologiques.",
    "refund.section2.title": "2. Absence de vente",
    "refund.section2.body": "Aucune vente de service ou de produit n’est réalisée via le site. Il n’existe donc pas de procédure de remboursement financier.",
    "refund.section3.title": "3. Retrait d’un contenu",
    "refund.section3.body": "Vous pouvez demander le retrait de données personnelles publiées par erreur en écrivant à contact@danswholesaleplants.com.",
    "refund.section4.title": "4. Correction d’informations",
    "refund.section4.body": "Si un contenu nécessite une correction, nous analysons la demande et procédons aux ajustements appropriés.",
    "refund.section5.title": "5. Délais de traitement",
    "refund.section5.body": "Les demandes sont examinées sous quinze jours ouvrables. Nous informons le demandeur des suites données.",
    "refund.section6.title": "6. Documentation à fournir",
    "refund.section6.body": "Toute demande doit préciser l’URL concernée et la nature de l’information à retirer ou corriger.",
    "refund.section7.title": "7. Limites",
    "refund.section7.body": "Nous pouvons refuser un retrait lorsque la publication répond à un intérêt légitime ou repose sur des obligations légales.",
    "refund.section8.title": "8. Suivi des demandes",
    "refund.section8.body": "Les demandes et réponses sont archivées pour assurer la traçabilité des échanges.",
    "refund.section9.title": "9. Mise à jour",
    "refund.section9.body": "Cette politique peut évoluer pour s’adapter aux évolutions réglementaires ou fonctionnelles.",
    "refund.section10.title": "10. Contact",
    "refund.section10.body": "Adressez vos questions à contact@danswholesaleplants.com.",
    "title.disclaimer": "Clause de non-responsabilité • danswholesaleplants",
    "meta.disclaimer": "Clause de non-responsabilité de danswholesaleplants concernant l’utilisation des informations publiées sur le site.",
    "disclaimer.title": "Clause de non-responsabilité",
    "disclaimer.section1.title": "1. Nature des informations",
    "disclaimer.section1.body": "Les contenus ont une vocation informative et méthodologique. Ils ne constituent pas un avis professionnel personnalisé.",
    "disclaimer.section2.title": "2. Absence de garantie",
    "disclaimer.section2.body": "Nous ne garantissons pas que les informations répondront à tous les besoins particuliers ou qu’elles seront exemptes d’erreurs.",
    "disclaimer.section3.title": "3. Responsabilité de l’utilisateur",
    "disclaimer.section3.body": "L’utilisateur demeure responsable des décisions prises sur la base des informations consultées.",
    "disclaimer.section4.title": "4. Liens externes",
    "disclaimer.section4.body": "Nous déclinons toute responsabilité quant aux contenus des sites externes vers lesquels des liens peuvent renvoyer.",
    "disclaimer.section5.title": "5. Mises à jour",
    "disclaimer.section5.body": "Les informations peuvent être modifiées sans préavis afin de refléter l’évolution des projets et recherches.",
    "disclaimer.section6.title": "6. Contact",
    "disclaimer.section6.body": "Pour toute question relative à cette clause, merci d’écrire à contact@danswholesaleplants.com.",
    "title.thankyou": "Merci • danswholesaleplants",
    "meta.thankyou": "Confirmation de réception de votre message par danswholesaleplants.",
    "thankyou.heading": "Merci pour votre message",
    "thankyou.message": "Nous avons bien reçu votre demande. Notre équipe analysera votre contexte et reviendra vers vous sous cinq jours ouvrés.",
    "thankyou.button": "Retourner à l’accueil",
    "title.404": "Page non trouvée • danswholesaleplants",
    "meta.404": "La page que vous recherchez est introuvable sur danswholesaleplants.",
    "error.heading": "Page introuvable",
    "error.description": "Le lien que vous avez suivi ne mène à aucune ressource. Vérifiez l’URL ou utilisez le menu pour continuer votre navigation.",
    "error.button": "Revenir à l’accueil"
  },
  en: {
    "header.logo": "danswholesaleplants",
    "nav.home": "Home",
    "nav.services": "Services",
    "nav.about": "About",
    "nav.blog": "Blog",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "nav.toggle": "Menu",
    "header.lang.fr": "FR",
    "header.lang.en": "EN",
    "footer.brand": "danswholesaleplants",
    "footer.tagline": "Observatory dedicated to spatial orientation and digital signage in complex built environments.",
    "footer.contactTitle": "Contact details",
    "footer.phoneText": "Phone: +32 2 123 45 67",
    "footer.emailText": "Email: contact@danswholesaleplants.com",
    "footer.addressText": "Address: Rue de la Loi 200, 1040 Brussels, Belgium",
    "footer.legalTitle": "Legal information",
    "footer.terms": "Terms of use",
    "footer.privacy": "Privacy policy",
    "footer.cookies": "Cookie policy",
    "footer.refund": "Withdrawal policy",
    "footer.disclaimer": "Disclaimer",
    "footer.manageCookies": "Manage cookies",
    "footer.copyright": "© {year} danswholesaleplants. All rights reserved.",
    "cookie.title": "Cookie management",
    "cookie.description": "We use cookies to study navigation patterns and improve digital wayfinding experiences. Adjust the categories according to your needs.",
    "cookie.manage": "Show preferences",
    "cookie.manageLink": "Update cookie preferences",
    "cookie.accept": "Accept all",
    "cookie.decline": "Decline all",
    "cookie.save": "Save preferences",
    "cookie.preferencesTitle": "Cookie categories",
    "cookie.toggle.necessary": "Necessary",
    "cookie.toggle.necessaryDesc": "These cookies support essential site features and cannot be disabled.",
    "cookie.toggle.preferences": "Preferences",
    "cookie.toggle.preferencesDesc": "Remember your language choice and layout settings for future visits.",
    "cookie.toggle.analytics": "Analytics",
    "cookie.toggle.analyticsDesc": "Help us understand site usage and refine the content structure.",
    "cookie.toggle.marketing": "Content visibility",
    "cookie.toggle.marketingDesc": "Allow embedded resources and relevant external content to display properly.",
    "toast.formSuccess": "Your message is being routed to our team.",
    "toast.formError": "Please review the required fields before sending.",
    "toast.cookieSaved": "Your cookie preferences have been updated.",
    "toast.cookieDeclined": "Only necessary cookies remain active.",
    "toast.cookieAccepted": "All cookie categories are now active.",
    "title.home": "danswholesaleplants • Spatial orientation and digital signage",
    "meta.home": "In-depth insights on spatial orientation, indoor navigation and user experience for public infrastructures in Belgium.",
    "home.hero.title": "Spatial guidance systems for legible public environments",
    "home.hero.subtitle": "We explore how digital signage, immersive mapping and pedestrian circulation interact to make complex buildings intuitive to traverse.",
    "home.hero.primary": "View our services",
    "home.hero.secondary": "Learn about our approach",
    "home.intro.title": "Understanding built spaces through data and information design",
    "home.intro.text": "We combine on-site observations, pedestrian simulations and interactive interfaces to build frictionless journeys across Belgian infrastructures.",
    "home.intro.items.1.title": "Relational mapping",
    "home.intro.items.1.text": "We streamline indoor plans via topological matrices and point-of-interest networks to reduce user cognitive load.",
    "home.intro.items.2.title": "Adaptive digital signage",
    "home.intro.items.2.text": "Dynamic displays are synchronised with real flows to share contextual, real-time, multilingual information.",
    "home.intro.items.3.title": "Pedestrian flow analysis",
    "home.intro.items.3.text": "We model densities and trajectories to anticipate congestion and prioritise interventions with strong user value.",
    "home.matrix.title": "Journey architecture for interconnected spaces",
    "home.matrix.text": "Each assignment relies on a systemic scheme linking navigation heuristics, spatial affordances and digital tools to increase accessibility.",
    "home.matrix.items.1.title": "User profiles",
    "home.matrix.items.1.text": "Assess spatial abilities and mobility needs for every user typology.",
    "home.matrix.items.2.title": "Orientation cues",
    "home.matrix.items.2.text": "Select visual and auditory anchors that structure progression and reinforce confidence.",
    "home.matrix.items.3.title": "Interactive interfaces",
    "home.matrix.items.3.text": "Prototype touch screens, kiosks and mobile maps aligned with physical signage.",
    "home.matrix.items.4.title": "Continuous evaluation",
    "home.matrix.items.4.text": "Set up field feedback loops including eye-tracking, in-situ observations and movement metrics.",
    "home.metrics.title": "Key indicators from our fieldwork",
    "home.metrics.items.1": "327 pedestrian journeys audited across stations, campuses and hospitals since 2018.",
    "home.metrics.items.2": "68 digital signage schemes co-designed with Belgian public institutions.",
    "home.metrics.items.3": "92 workshops with users who have specific mobility or sensory needs to verify inclusivity.",
    "home.recommendations.title": "Strategic recommendations",
    "home.recommendations.text": "Our synthesis combines tangible observations and methodological frameworks to support teams in charge of complex environments.",
    "home.recommendations.items.1.title": "Structure the cues",
    "home.recommendations.items.1.text": "Organising orientation points into a clear hierarchy improves memorisation and reduces visual overload.",
    "home.recommendations.items.2.title": "Synchronise supports",
    "home.recommendations.items.2.text": "Aligning terminology across print plans, mobile apps and digital displays strengthens cognitive consistency.",
    "home.recommendations.items.3.title": "Measure experience",
    "home.recommendations.items.3.text": "Tracking fluency and comfort indicators enables continuous adjustments based on real usage.",
    "home.testimonials.title": "Testimonials",
    "home.testimonials.text": "Belgian institutions and urban networks share their feedback on our navigation and guidance analyses.",
    "home.testimonials.items.1.quote": "“The interactive maps clarified our campus layout and reduced inquiries at the reception desk by 37%.”",
    "home.testimonials.items.1.author": "Sophie Thys, Information Manager, Brussels Urban University",
    "home.testimonials.items.2.quote": "“The visualisation of pedestrian flows revealed the need to redistribute our entry points and supported the renovation of the main hall.”",
    "home.testimonials.items.2.author": "Marc De Smet, Mobility Coordinator, Flemish Administrative Centre",
    "home.blogHighlight.title": "Spotlight on our analyses",
    "home.blogHighlight.text": "Explore a selection of articles examining the technical and human dimensions of our signage research.",
    "home.blogHighlight.more": "View all publications",
    "title.services": "Expert services • danswholesaleplants",
    "meta.services": "Interactive mapping, digital signage and pedestrian flow analysis to optimise public environments in Belgium.",
    "services.hero.title": "Detailed fields of expertise",
    "services.hero.subtitle": "We assist public entities, cultural venues and transport infrastructures in understanding their user journeys.",
    "services.intro.title": "A method connecting analysis, design and validation",
    "services.intro.text": "Every assignment blends on-site diagnostics, digital modelling and user testing to reveal the genuine structure of spaces.",
    "services.cards.1.title": "Orientation challenge audit",
    "services.cards.1.text": "Map friction points, observe behaviours and locate areas where spatial legibility must be reinforced.",
    "services.cards.2.title": "Digital signage design",
    "services.cards.2.text": "Define usage scenarios, select media and craft modular interfaces to guide users in real time.",
    "services.cards.3.title": "Interactive plans and 3D modelling",
    "services.cards.3.text": "Assemble geometric data, functional attributes and customisable routes for touch screens and mobile tools.",
    "services.cards.4.title": "Inclusive user journeys",
    "services.cards.4.text": "Address reduced mobility, sensory needs and multilingual contexts within each proposed path.",
    "services.cards.5.title": "Accessibility and spatial UX",
    "services.cards.5.text": "Assess signage ergonomics, audit information continuity and deliver guidelines for intuitive navigation.",
    "services.layers.title": "Deliverables structured in layers",
    "services.layers.text": "Our outputs integrate into existing workflows through modular formats usable by architects, planners and digital teams.",
    "services.layers.list.1": "Illustrated analytical reports with heat maps, desire lines and density diagrams.",
    "services.layers.list.2": "Graphic kits and icon sets aligning digital and physical signage.",
    "services.layers.list.3": "Interactive prototypes testable on tablets or kiosks to gather quick user feedback.",
    "services.process.title": "Collaboration cycle",
    "services.process.text": "We work in short sequences to keep field momentum and adjust the project path quickly.",
    "services.process.steps.1.title": "Situational immersion",
    "services.process.steps.1.text": "Visits, observations and staff interviews to portray the context accurately.",
    "services.process.steps.2.title": "Operational synthesis",
    "services.process.steps.2.text": "Merge measured data with institutional goals to prioritise actions.",
    "services.process.steps.3.title": "Experimentation",
    "services.process.steps.3.text": "User tests, prototype iterations and implementation support.",
    "title.about": "About • danswholesaleplants",
    "meta.about": "Profile of danswholesaleplants: research in wayfinding, information design and accessibility within Belgian public spaces.",
    "about.hero.title": "A team dedicated to complex environments",
    "about.hero.subtitle": "We unite flow analysts, information designers and accessibility experts to decode how architecture and users interact.",
    "about.mission.title": "Mission",
    "about.mission.text": "Provide clear cues within multilayered spaces by combining technical expertise and sensitivity to everyday use.",
    "about.mission.items.1": "Observe how people, architecture and digital supports interact.",
    "about.mission.items.2": "Turn spatial data into legible strategies that can be shared.",
    "about.mission.items.3": "Strengthen user autonomy through accessible information.",
    "about.timeline.title": "Timeline highlights",
    "about.timeline.items.1.title": "2015 — First immersions",
    "about.timeline.items.1.text": "Analysed Brussels stations and designed an observation protocol for pedestrian flows.",
    "about.timeline.items.2.title": "2017 — Augmented mapping",
    "about.timeline.items.2.text": "Developed interactive plans for university hospitals and deployed multilingual kiosks.",
    "about.timeline.items.3.title": "2020 — Hybrid methods",
    "about.timeline.items.3.text": "Combined simulation tools and qualitative surveys for campuses and museums.",
    "about.timeline.items.4.title": "2023 — Enhanced accessibility",
    "about.timeline.items.4.text": "Systematically integrated feedback from people with sensory impairments into orientation scenarios.",
    "about.metrics.title": "Key figures",
    "about.metrics.items.1.label": "Audited sites",
    "about.metrics.items.1.value": "54 Belgian public infrastructures supported.",
    "about.metrics.items.2.label": "Languages covered",
    "about.metrics.items.2.value": "8 languages considered across wayfinding supports.",
    "about.metrics.items.3.label": "Partnerships",
    "about.metrics.items.3.value": "21 collaborating institutions throughout Belgium.",
    "about.team.title": "Team composition",
    "about.team.text": "Complementary profiles ensure a systemic view of spatial orientation.",
    "about.team.members.1": "Delphine Lemaire — Pedestrian mobility analyst.",
    "about.team.members.2": "Hugo Verbeeck — Information and screen systems designer.",
    "about.team.members.3": "Maya Renson — Accessibility and user testing specialist.",
    "about.approach.title": "Approach",
    "about.approach.text": "Each assignment favours co-creation with on-site teams and connects data, observation and design.",
    "title.blog": "Blog • Spatial orientation insights",
    "meta.blog": "Technical articles on digital signage, flow mapping and pedestrian experience within Belgian environments.",
    "blog.hero.title": "Field notes and insights",
    "blog.hero.subtitle": "Detailed analyses to decode complex environments and inspire signage projects.",
    "blog.intro.text": "Each article builds on case studies, field metrics and methodological paths applicable to public buildings.",
    "blog.card.button": "Read article",
    "post1.title": "Modelling spatial cognition in multilined transit hubs",
    "post1.excerpt": "We examine how passengers grasp the depth of a transit network and locate transfer options within layered environments.",
    "post1.meta": "Published 12 February 2024 · 7-minute read",
    "post2.title": "Evaluating the legibility of dynamic screens in European civic centres",
    "post2.excerpt": "An analysis of how digital messages are perceived in multifunctional halls that blend administrative services with public events.",
    "post2.meta": "Published 5 March 2024 · 8-minute read",
    "post3.title": "Integrating sensor data into interactive campus maps",
    "post3.excerpt": "A review of how occupancy sensors and schedule data converge to guide users across a polycentric campus.",
    "post3.meta": "Published 28 March 2024 · 9-minute read",
    "post4.title": "Designing inclusive wayfinding for heritage sites",
    "post4.excerpt": "Exploring preservation constraints and digital adaptations required for accessible museums and monuments.",
    "post4.meta": "Published 16 April 2024 · 8-minute read",
    "post5.title": "Pedestrian flow resilience in emergency scenarios",
    "post5.excerpt": "Simulating critical situations to secure evacuations in major cultural and sports facilities.",
    "post5.meta": "Published 6 May 2024 · 7-minute read",
    "title.post1": "Modelling spatial cognition in multilined transit hubs",
    "meta.post1": "In-depth analysis of spatial cognition and navigation models within multilined transit hubs in Belgium.",
    "post1.section1.title": "Rooting the model in multilayered flows",
    "post1.section1.p1": "Multiline transit hubs in Belgium combine trains, metro lines, buses and aerial walkways. We observed one major hub for three weeks to measure how travellers build mental representations. Interviews showed that reading multiple levels simultaneously encourages a stratified mental map where orientation cues must be prioritised.",
    "post1.section1.p2": "To formalise this mental map we designed a model capturing vertical and horizontal transitions. Congestion-prone areas correspond to intersections where modes overlap. The model demonstrates that graphic consistency between physical and digital supports is crucial for users to keep a clear view of successive steps.",
    "post1.section1.subtitle": "Hierarchy of multimodal cues",
    "post1.section1.p3": "Travellers first scan broad information (direction of lines) and then search for specific details (platforms, waiting times). Stable iconography paired with a constant colour code reinforces memorisation and limits detours. Under these conditions the model remains coherent and the experience strengthens over time.",
    "post1.section2.title": "Synchronising real-time data and static plans",
    "post1.section2.p1": "Most Belgian transit hubs feature dynamic screens, yet their content is not always aligned with static plans. We tested two prototypes: one emphasising live data and another emphasising spatial representation. Passengers retained destinations better when both formats shared nomenclature and visual cues.",
    "post1.section2.p2": "The algorithmic model now includes a terminology coherence module. When a platform change occurs, the digital alert automatically references the equivalent cue on static plans. This synchronisation limits hesitation and reduces untimely crossings on bridges.",
    "post1.section2.subtitle": "Handling unexpected changes",
    "post1.section2.p3": "Disruptions expose cognitive fragilities. We simulated real-time rerouting and analysed how detours propagate. Travellers receiving alerts anchored to the base map adjusted quickly, whereas others retraced their steps repeatedly. Anchoring alerts on pre-established cues is therefore essential.",
    "post1.section3.title": "Accounting for diverse traveller profiles",
    "post1.section3.p1": "Spatial cognition varies according to usage frequency, language proficiency and sensory capabilities. We assembled test groups including reduced mobility users, tourists and daily commuters. Each described their decision-making process, revealing needs for tactile, audio or high-contrast feedback.",
    "post1.section3.p2": "Integrating these profiles into the model yields alternative paths that respect constraints. Accessible digital signage should deliver simultaneous modalities: clear text, iconography, audio prompts and vibration. Belgian platforms equipped with those features reported improved confidence and autonomy.",
    "post1.section3.subtitle": "Towards an evolving model",
    "post1.section3.p3": "We deployed a dashboard measuring how orientation cues are understood over time. Signage adjustments are evaluated via journey duration, questions addressed to staff and qualitative feedback. This continuous monitoring turns modelling into a living tool able to adapt as infrastructures evolve.",
    "post1.conclusion.title": "Outlook for Belgian hubs",
    "post1.conclusion.p1": "Multilined hubs demand simultaneous reading of multiple information layers. Graphic coherence, data synchronisation and attention to varied user profiles are the model’s three pillars. They collectively reduce cognitive friction and improve movement fluency.",
    "post1.conclusion.p2": "Next steps involve adding more sensors to refine flow forecasts and expanding tests with occasional users. The ultimate goal is dependable orientation regardless of network familiarity.",
    "title.post2": "Evaluating the legibility of dynamic screens in European civic centres",
    "meta.post2": "Comprehensive study of digital screen legibility and signage consistency in European civic centres.",
    "post2.section1.title": "Understanding the constraints of multifunction halls",
    "post2.section1.p1": "Belgian civic centres host administrative desks, cultural programmes and association events. Dynamic screens broadcast institutional announcements, queue calls and direction cues. We analysed four representative venues, studying message visibility according to viewing angle, brightness and information density.",
    "post2.section1.p2": "Photometric measurements showed that legibility drops when brightness exceeds 400 lux, especially in glass halls. Increasing contrast and using a generous sans serif typeface improved comprehension, particularly for multilingual messages.",
    "post2.section1.subtitle": "Consultation time",
    "post2.section1.p3": "Users typically spend 6 to 9 seconds reading a screen. Effective messages contain short blocks dedicated to a single function: orientation, services, alerts. This segmentation lowers cognitive load and enables quick identification of relevant information.",
    "post2.section2.title": "Aligning screens with static signage",
    "post2.section2.p1": "Dynamic screens deliver value when they extend existing signage. We mapped terminological discrepancies between digital and physical supports and harmonised them so that every zone, name and pictogram matches printed plans and mobile apps.",
    "post2.section2.p2": "After harmonisation, inquiries at reception desks dropped by 42%. Users reported that consistent wording, colours and arrows help them move from screens to corridors without hesitation.",
    "post2.section2.subtitle": "Integrating temporary alerts",
    "post2.section2.p3": "Occasional events trigger rapid layout changes. We implemented a standard alert template paired with temporary floor markings. Coordinated updates across supports limited confusion and ensured smooth circulation.",
    "post2.section3.title": "Addressing accessibility requirements",
    "post2.section3.p1": "Screens must remain legible for people with visual, auditory or cognitive impairments. We verified compatibility with screen readers and ensured audio alternatives are available in waiting areas. Extraneous animations were removed to stabilise reading.",
    "post2.section3.p2": "Induction loops were installed near key screens to assist hearing aid users. Essential messages are mirrored in an accessible mobile app synchronised with on-site content.",
    "post2.section3.subtitle": "Editorial governance",
    "post2.section3.p3": "Legibility relies on structured editorial governance. Internal teams now maintain a publication calendar, validation process and regular testing protocol. Each update is assessed with clarity and comprehension indicators.",
    "post2.conclusion.title": "Achieving coherence in civic centres",
    "post2.conclusion.p1": "Dynamic screens succeed when visual elements, content scenarios and accessibility standards converge. The studied civic centres reduced orientation times and improved user satisfaction by applying these principles.",
    "post2.conclusion.p2": "We continue monitoring seasonal usage changes and documenting feedback from front desk teams, who ensure continuity of information.",
    "title.post3": "Integrating sensor data into interactive campus maps",
    "meta.post3": "Methodology for integrating sensor data into interactive campus maps to optimise pedestrian mobility.",
    "post3.section1.title": "Merging heterogeneous data sources",
    "post3.section1.p1": "Belgian campuses often span multiple hubs linked by walkways and internal transport. We gathered anonymised Wi-Fi data, optical counters and manual tallies to estimate daily flows.",
    "post3.section1.p2": "An aggregation engine reconciles these inputs every five minutes to feed interactive maps. Fluctuations appear as coloured layers, helping identify overloaded corridors and underused areas.",
    "post3.section1.subtitle": "Measurement quality and reliability",
    "post3.section1.p3": "Calibration is crucial for trustworthy insights. We compared automated counts with field observations to adjust conversion factors and mitigate double counting.",
    "post3.section2.title": "Creating adaptive journeys",
    "post3.section2.p1": "Interactive maps now suggest routes tailored to real-time occupancy. When density surpasses a threshold, alternative paths with precise duration estimates are proposed.",
    "post3.section2.p2": "Users value contextual notifications sent 10 minutes before timetable changes, allowing them to anticipate movement. Feedback indicates fewer delays and better flow distribution.",
    "post3.section2.subtitle": "Privacy considerations",
    "post3.section2.p3": "Data processing honours strict anonymity. Identifiers are hashed at the edge and no individual tracking is stored. Transparency fosters trust and community acceptance.",
    "post3.section3.title": "Supporting operational teams",
    "post3.section3.p1": "Maps come with a dashboard for facility teams, showing occupancy indicators, saturation alerts and recommendations for temporary signage.",
    "post3.section3.p2": "Training sessions enable technical staff to interpret data correctly and plan targeted interventions, from maintenance to space reallocation.",
    "post3.section3.subtitle": "Future developments",
    "post3.section3.p3": "Next steps include incorporating weather and construction data to adjust suggested paths. The aim is fluid navigation even when conditions change.",
    "post3.conclusion.title": "Living maps for dynamic campuses",
    "post3.conclusion.p1": "By connecting sensors and cartography, campuses gain an operational tool that improves circulation and user experience.",
    "post3.conclusion.p2": "The Belgian model can inspire other regions seeking to synchronise data and wayfinding across complex estates.",
    "title.post4": "Designing inclusive wayfinding for heritage sites",
    "meta.post4": "Study on designing inclusive wayfinding for heritage sites, balancing architectural preservation and accessibility.",
    "post4.section1.title": "Honouring heritage while informing",
    "post4.section1.p1": "Heritage sites face strict constraints: material conservation, regulation and fluctuating visitor flows. We collaborated with three Belgian institutions to reconcile protection and accessible guidance.",
    "post4.section1.p2": "Physical signage uses heritage-friendly materials while digital supports deliver detailed content without overwhelming spaces.",
    "post4.section1.subtitle": "Discreet installations",
    "post4.section1.p3": "Digital tools sit in free-standing kiosks set back from listed walls. Lighting is calibrated to preserve materials yet ensure legibility.",
    "post4.section2.title": "Making information accessible",
    "post4.section2.p1": "We developed audio-guided routes synchronised with signage. Visitors choose narratives adapted to their needs, including precise descriptions for partially sighted audiences.",
    "post4.section2.p2": "Tactile models and raised-line maps complete the experience. Digital content is available in multiple languages, with simplified phrasing and consistent pictograms.",
    "post4.section2.subtitle": "Flow management",
    "post4.section2.p3": "Attendance data helps balance flows between major halls and secondary areas. Notifications encourage exploration of alternative routes when key rooms become crowded.",
    "post4.section3.title": "Co-creating with teams and visitors",
    "post4.section3.p1": "Workshops with curators, mediators and regular visitors defined the graphic palette and information priorities, ensuring ownership.",
    "post4.section3.p2": "User tests refined support height, audio levels and typography size. Every adjustment was validated by conservation teams.",
    "post4.section3.subtitle": "Transfer and maintenance",
    "post4.section3.p3": "An operational guide details how to update digital content, check legibility and maintain equipment. Sites gain autonomy while honouring heritage requirements.",
    "post4.conclusion.title": "Heritage and accessibility converge",
    "post4.conclusion.p1": "A multi-support approach allows heritage sites to deliver inclusive wayfinding without compromising architectural integrity.",
    "post4.conclusion.p2": "Belgian collaborations show that continued dialogue between conservation and innovation reinforces visitor experience.",
    "title.post5": "Pedestrian flow resilience in emergency scenarios",
    "meta.post5": "Analysis of pedestrian flow resilience in emergency scenarios for major public venues in Belgium.",
    "post5.section1.title": "Building realistic scenarios",
    "post5.section1.p1": "Large venues must anticipate exceptional circumstances. We devised emergency scenarios for Belgian arenas and stadiums, combining modelling and on-site drills.",
    "post5.section1.p2": "Each scenario considers architectural layout, peak density and behaviours observed during events. Results highlight bottlenecks and the need for reinforced signage.",
    "post5.section1.subtitle": "Mapping exits",
    "post5.section1.p3": "Secondary exits are often underused. We tested temporary directional lighting and synchronised audio messages to guide crowds towards quickest routes.",
    "post5.section2.title": "Aligning procedures and digital supports",
    "post5.section2.p1": "Digital evacuation plans integrate with venue apps. In case of alert they display recommended exits based on user location.",
    "post5.section2.p2": "On-site screens mirror the same information, ensuring coherence. Trained staff can trigger tailored scenarios via a simple protocol selection.",
    "post5.section2.subtitle": "Testing and refining",
    "post5.section2.p3": "Regular drills validate the setup. After-action reports pinpoint slowdowns, guiding repositioning of temporary signage or team training updates.",
    "post5.section3.title": "Embedding accessibility in critical moments",
    "post5.section3.p1": "Evacuation routes must address reduced mobility and families. We defined signposted refuge areas equipped with accessible communication interfaces.",
    "post5.section3.p2": "Dedicated messages indicate assembly points and key steps. Visual, audio and haptic signals operate together to reach all audiences.",
    "post5.section3.subtitle": "Towards proactive resilience",
    "post5.section3.p3": "Resilience depends on continuous preparation. Data gathered during drills feed longitudinal monitoring that prioritises investments based on observed fluency gains.",
    "post5.conclusion.title": "Securing journeys under any circumstance",
    "post5.conclusion.p1": "Combining simulations, interactive tools and targeted training significantly reinforces visitor safety.",
    "post5.conclusion.p2": "Belgian venues engaged in this approach enhance their response capacity and nurture public confidence.",
    "title.contact": "Contact • danswholesaleplants",
    "meta.contact": "danswholesaleplants contact details and form for spatial orientation inquiries in Belgium.",
    "contact.hero.title": "Connect with our team",
    "contact.hero.subtitle": "Share your questions or projects related to digital signage and accessible environments.",
    "contact.intro.title": "General information",
    "contact.intro.text": "We review each request to suggest pathways aligned with your site constraints.",
    "contact.info.title": "Direct contact",
    "contact.info.description": "Our Brussels office is open Monday to Friday, 09:00–17:30.",
    "contact.info.phone": "Phone: +32 2 123 45 67",
    "contact.info.email": "Email: contact@danswholesaleplants.com",
    "contact.info.address": "Address: Rue de la Loi 200, 1040 Brussels, Belgium",
    "contact.info.hours": "Visits by appointment for site audits and workshops.",
    "contact.map.title": "Locate our office",
    "contact.map.caption": "Interactive map centred on our Brussels location.",
    "contact.form.title": "Contact form",
    "contact.form.intro": "Describe your environment and the navigation issues you observed.",
    "contact.form.nameLabel": "Full name",
    "contact.form.namePlaceholder": "Enter your full name",
    "contact.form.organisationLabel": "Organisation",
    "contact.form.organisationPlaceholder": "Provide your organisation",
    "contact.form.emailLabel": "Email address",
    "contact.form.emailPlaceholder": "name@organisation.be",
    "contact.form.subjectLabel": "Subject",
    "contact.form.subjectPlaceholder": "Topic of your message",
    "contact.form.messageLabel": "Message",
    "contact.form.messagePlaceholder": "Explain the context, sites concerned and your objectives.",
    "contact.form.notice": "We reply within five working days depending on request complexity.",
    "contact.form.submit": "Send",
    "title.faq": "FAQ • danswholesaleplants",
    "meta.faq": "Frequently asked questions about spatial orientation, digital signage and the danswholesaleplants methodology.",
    "faq.hero.title": "Frequently asked questions",
    "faq.hero.subtitle": "Clarifications about our methods, the data we use and on-site collaboration.",
    "faq.q1.question": "How does an orientation audit begin?",
    "faq.q1.answer": "We start with on-site immersion to observe journeys, locate friction points and meet operational teams.",
    "faq.q2.question": "Do you only work with public institutions?",
    "faq.q2.answer": "We focus on high-traffic complex environments, mostly public, yet also support open private campuses.",
    "faq.q3.question": "How do you integrate user feedback?",
    "faq.q3.answer": "Workshops, user tests and structured surveys feed every design and validation phase.",
    "faq.q4.question": "Do recommendations include technical aspects?",
    "faq.q4.answer": "Yes, we provide specifications for screens, content systems and interfaces needed for deployment.",
    "faq.q5.question": "Do you offer follow-up after implementation?",
    "faq.q5.answer": "We provide post-deployment monitoring to measure effectiveness and adjust devices based on real use.",
    "faq.q6.question": "How do you address multilingual requirements?",
    "faq.q6.answer": "Language needs are assessed during initial audits and we design supports that switch easily between required languages.",
    "title.terms": "Terms of use • danswholesaleplants",
    "meta.terms": "Terms governing the use of danswholesaleplants.com, legal framework and responsibilities.",
    "terms.title": "Terms of use",
    "terms.intro": "These terms govern access to and use of danswholesaleplants.com. Visiting the site implies full acceptance of these provisions.",
    "terms.section1.title": "1. Purpose",
    "terms.section1.body": "The site shares information about spatial orientation, digital signage and accessibility research. No commercial transaction is offered.",
    "terms.section2.title": "2. Site access",
    "terms.section2.body": "Access is free of charge. Connection costs remain the responsibility of the user, who ensures equipment compatibility.",
    "terms.section3.title": "3. Intellectual property",
    "terms.section3.body": "Content, texts, graphics and diagrams are protected by copyright. Any reproduction requires written permission.",
    "terms.section4.title": "4. Content usage",
    "terms.section4.body": "Information may be consulted for personal or institutional non-commercial use. Altering content in a misleading way is forbidden.",
    "terms.section5.title": "5. External references",
    "terms.section5.body": "The site may reference external resources. We have no control over their content and accept no responsibility for updates.",
    "terms.section6.title": "6. Information accuracy",
    "terms.section6.body": "We aim for reliable content without guaranteeing constant completeness. Information may evolve with ongoing research.",
    "terms.section7.title": "7. Liability",
    "terms.section7.body": "We are not liable for direct or indirect damages resulting from site use or temporary unavailability.",
    "terms.section8.title": "8. User account",
    "terms.section8.body": "No user account is provided. Interactions occur via the contact details or the dedicated form.",
    "terms.section9.title": "9. Personal data",
    "terms.section9.body": "Information submitted through the form is processed in accordance with the privacy policy and solely for responding to requests.",
    "terms.section10.title": "10. Accessibility",
    "terms.section10.body": "We strive to enhance site accessibility. Feedback can be sent to contact@danswholesaleplants.com.",
    "terms.section11.title": "11. Availability",
    "terms.section11.body": "The site may be interrupted for maintenance or updates. We seek to keep such periods minimal.",
    "terms.section12.title": "12. Changes to terms",
    "terms.section12.body": "We may update these terms to reflect legal or functional changes. Visitors should review them regularly.",
    "terms.section13.title": "13. Governing law",
    "terms.section13.body": "These terms are governed by Belgian law. Disputes fall under the jurisdiction of Brussels courts.",
    "terms.section14.title": "14. Contact",
    "terms.section14.body": "Address term-related questions to contact@danswholesaleplants.com.",
    "title.privacy": "Privacy policy • danswholesaleplants",
    "meta.privacy": "danswholesaleplants privacy policy on the collection and use of personal data.",
    "privacy.title": "Privacy policy",
    "privacy.intro": "This policy explains how we process personal data collected via danswholesaleplants.com.",
    "privacy.section1.title": "1. Controller",
    "privacy.section1.body": "The controller is danswholesaleplants, Rue de la Loi 200, 1040 Brussels.",
    "privacy.section2.title": "2. Data collected",
    "privacy.section2.body": "We only collect information submitted through the contact form: name, organisation, email address, subject and message.",
    "privacy.section3.title": "3. Technical logs",
    "privacy.section3.body": "The server records anonymised technical logs (truncated IP, browser type, date and time) to secure the site.",
    "privacy.section4.title": "4. Purposes",
    "privacy.section4.body": "Data is used to answer requests, prepare potential exchanges and maintain quality follow-up.",
    "privacy.section5.title": "5. Legal basis",
    "privacy.section5.body": "Processing relies on your consent when submitting the form and on our legitimate interest in organising responses.",
    "privacy.section6.title": "6. Data sharing",
    "privacy.section6.body": "Data is not sold. It may be shared with technical partners solely to ensure secure hosting.",
    "privacy.section7.title": "7. Retention",
    "privacy.section7.body": "Messages are retained for up to three years to maintain communication history unless an earlier deletion is requested.",
    "privacy.section8.title": "8. Rights",
    "privacy.section8.body": "You may access, rectify, erase, restrict or oppose processing. Send requests to contact@danswholesaleplants.com.",
    "privacy.section9.title": "9. Security",
    "privacy.section9.body": "Technical and organisational measures protect data against unauthorised access.",
    "privacy.section10.title": "10. Updates",
    "privacy.section10.body": "This policy may change. The revision date is indicated at the top of the document.",
    "title.cookies": "Cookie policy • danswholesaleplants",
    "meta.cookies": "Information on cookie usage by danswholesaleplants and how to manage preferences.",
    "cookies.title": "Cookie policy",
    "cookies.intro": "We use cookies to ensure site functionality and analyse visits to improve our content.",
    "cookies.usage": "Non-essential cookies are activated only with your consent. You can adjust your choices anytime via the management module.",
    "cookies.table.name": "Cookie name",
    "cookies.table.provider": "Provider",
    "cookies.table.type": "Type",
    "cookies.table.purpose": "Purpose",
    "cookies.table.duration": "Duration",
    "cookies.row1.name": "session_id",
    "cookies.row1.provider": "danswholesaleplants.com",
    "cookies.row1.type": "Necessary",
    "cookies.row1.purpose": "Maintain active sessions while browsing.",
    "cookies.row1.duration": "Session",
    "cookies.row2.name": "lang_pref",
    "cookies.row2.provider": "danswholesaleplants.com",
    "cookies.row2.type": "Preferences",
    "cookies.row2.purpose": "Store chosen language for future visits.",
    "cookies.row2.duration": "12 months",
    "cookies.row3.name": "analytics_flow",
    "cookies.row3.provider": "danswholesaleplants.com",
    "cookies.row3.type": "Analytics",
    "cookies.row3.purpose": "Measure journey efficiency and identify popular pages.",
    "cookies.row3.duration": "13 months",
    "cookies.manage": "You can modify your choices anytime by clicking “Manage cookies” in the footer.",
    "cookies.contact": "Send cookie-related questions to contact@danswholesaleplants.com.",
    "title.refund": "Withdrawal policy • danswholesaleplants",
    "meta.refund": "danswholesaleplants withdrawal policy regarding published content and information.",
    "refund.title": "Withdrawal policy",
    "refund.intro": "Our site distributes informational content without commercial transactions. This policy explains how we handle removal requests.",
    "refund.section1.title": "1. Nature of content",
    "refund.section1.body": "Documents consist of analyses, articles and methodological summaries.",
    "refund.section2.title": "2. No sale",
    "refund.section2.body": "No sale of services or products occurs via the site. Financial refunds are therefore not applicable.",
    "refund.section3.title": "3. Removing content",
    "refund.section3.body": "You may request removal of personal data published in error by writing to contact@danswholesaleplants.com.",
    "refund.section4.title": "4. Correcting information",
    "refund.section4.body": "If content requires correction, we review the request and adjust when appropriate.",
    "refund.section5.title": "5. Processing time",
    "refund.section5.body": "Requests are reviewed within fifteen working days. We inform the requester of the outcome.",
    "refund.section6.title": "6. Required details",
    "refund.section6.body": "Requests must include the relevant URL and specify the information to remove or correct.",
    "refund.section7.title": "7. Limitations",
    "refund.section7.body": "We may refuse removal when publication meets legitimate interests or legal obligations.",
    "refund.section8.title": "8. Request tracking",
    "refund.section8.body": "Requests and responses are archived to ensure traceability.",
    "refund.section9.title": "9. Updates",
    "refund.section9.body": "This policy may evolve to address regulatory or functional changes.",
    "refund.section10.title": "10. Contact",
    "refund.section10.body": "Send your questions to contact@danswholesaleplants.com.",
    "title.disclaimer": "Disclaimer • danswholesaleplants",
    "meta.disclaimer": "danswholesaleplants disclaimer about the use of information published on the site.",
    "disclaimer.title": "Disclaimer",
    "disclaimer.section1.title": "1. Nature of information",
    "disclaimer.section1.body": "Content is provided for informational and methodological purposes only. It does not constitute personalised professional advice.",
    "disclaimer.section2.title": "2. No guarantee",
    "disclaimer.section2.body": "We do not guarantee that the information will meet every specific need or remain error-free.",
    "disclaimer.section3.title": "3. User responsibility",
    "disclaimer.section3.body": "Users remain responsible for decisions made on the basis of the information consulted.",
    "disclaimer.section4.title": "4. External links",
    "disclaimer.section4.body": "We are not responsible for the content of external sites referenced through links.",
    "disclaimer.section5.title": "5. Updates",
    "disclaimer.section5.body": "Information may change without notice to reflect evolving projects and research.",
    "disclaimer.section6.title": "6. Contact",
    "disclaimer.section6.body": "Direct questions regarding this disclaimer to contact@danswholesaleplants.com.",
    "title.thankyou": "Thank you • danswholesaleplants",
    "meta.thankyou": "Confirmation that danswholesaleplants has received your message.",
    "thankyou.heading": "Thank you for your message",
    "thankyou.message": "We have received your request. Our team will review your context and respond within five working days.",
    "thankyou.button": "Return to home",
    "title.404": "Page not found • danswholesaleplants",
    "meta.404": "The page you requested could not be found on danswholesaleplants.",
    "error.heading": "Page not found",
    "error.description": "The link you followed does not point to any resource. Check the URL or use the menu to continue browsing.",
    "error.button": "Go back home"
  }
};

const DEFAULT_LANG = "fr";
let currentLang = DEFAULT_LANG;

document.addEventListener("DOMContentLoaded", () => {
  const storedLang = localStorage.getItem("site_lang");
  currentLang = storedLang && I18N[storedLang] ? storedLang : DEFAULT_LANG;
  applyTranslations(currentLang);
  setupLanguageSwitcher();
  setupNavToggle();
  highlightActiveNav();
  setupAnimations();
  setupCookieBanner();
  setupForms();
  updateYearPlaceholders();
});

function applyTranslations(lang) {
  const dict = I18N[lang] || I18N[DEFAULT_LANG];
  document.documentElement.setAttribute("lang", lang);
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    const value = dict[key];
    if (typeof value !== "undefined") {
      el.innerHTML = value.replace("{year}", new Date().getFullYear());
    }
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    const value = dict[key];
    if (typeof value !== "undefined") {
      el.setAttribute("placeholder", value);
    }
  });
  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.getAttribute("data-i18n-alt");
    const value = dict[key];
    if (typeof value !== "undefined") {
      el.setAttribute("alt", value);
    }
  });
  const titleEl = document.querySelector("title[data-i18n-title]");
  if (titleEl) {
    const key = titleEl.getAttribute("data-i18n-title");
    const value = dict[key];
    if (typeof value !== "undefined") {
      document.title = value;
    }
  }
  document.querySelectorAll("meta[data-i18n-meta]").forEach((meta) => {
    const key = meta.getAttribute("data-i18n-meta");
    const value = dict[key];
    if (typeof value !== "undefined") {
      meta.setAttribute("content", value);
    }
  });
  document.querySelectorAll(".language-switcher button").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.lang === lang);
  });
  currentLang = lang;
}

function setupLanguageSwitcher() {
  document.querySelectorAll(".language-switcher button").forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.dataset.lang;
      if (lang && I18N[lang]) {
        localStorage.setItem("site_lang", lang);
        applyTranslations(lang);
        showToast(lang === "fr" ? "toast.cookieSaved" : "toast.cookieSaved", "success");
      }
    });
  });
}

function setupNavToggle() {
  const nav = document.getElementById("primaryNav");
  const toggle = document.getElementById("navToggle");
  if (!nav || !toggle) return;
  toggle.addEventListener("click", () => {
    nav.classList.toggle("open");
  });
  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      nav.classList.remove("open");
    });
  });
}

function highlightActiveNav() {
  const page = document.body.dataset.page;
  if (!page) return;
  document.querySelectorAll(".nav-links a").forEach((link) => {
    const href = link.getAttribute("href");
    if (href && href.includes(page)) {
      link.classList.add("active");
    }
  });
}

function setupAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );
  document.querySelectorAll(".animate-on-scroll").forEach((el) => observer.observe(el));
}

function setupForms() {
  document.querySelectorAll("form[data-form]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!form.checkValidity()) {
        event.preventDefault();
        form.reportValidity();
        showToast("toast.formError", "error");
      } else {
        showToast("toast.formSuccess", "success");
      }
    });
  });
}

function showToast(key, type = "info") {
  const dict = I18N[currentLang] || I18N[DEFAULT_LANG];
  const message = dict[key] || key;
  const container = document.getElementById("toastContainer");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("fade-out");
    toast.addEventListener("transitionend", () => toast.remove());
  }, 3200);
  setTimeout(() => toast.remove(), 3800);
}

function updateYearPlaceholders() {
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    if (el.innerHTML.includes("{year}")) {
      el.innerHTML = el.innerHTML.replace("{year}", new Date().getFullYear());
    }
  });
}

function setupCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  const manageToggle = document.getElementById("cookieManageToggle");
  const preferences = document.getElementById("cookiePreferences");
  const acceptBtn = document.getElementById("cookieAcceptAll");
  const declineBtn = document.getElementById("cookieDeclineAll");
  const saveBtn = document.getElementById("cookieSave");
  const reopenBtn = document.getElementById("openCookiePreferences");
  if (!banner || !acceptBtn || !declineBtn || !saveBtn || !preferences) return;

  const CHECKBOX_SELECTORS = "[data-cookie-type]";
  const STORAGE_KEY = "cookie_consent";

  let state = {
    necessary: true,
    preferences: false,
    analytics: false,
    marketing: false
  };

  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      state = Object.assign(state, parsed);
      banner.classList.remove("show");
    } catch {
      banner.classList.add("show");
    }
  } else {
    banner.classList.add("show");
  }

  updateCheckboxes();

  manageToggle.addEventListener("click", () => {
    preferences.classList.toggle("hidden");
  });

  document.querySelectorAll(CHECKBOX_SELECTORS).forEach((input) => {
    input.addEventListener("change", () => {
      const type = input.dataset.cookieType;
      if (!type) return;
      state[type] = type === "necessary" ? true : input.checked;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    });
  });

  acceptBtn.addEventListener("click", () => {
    state = { necessary: true, preferences: true, analytics: true, marketing: true };
    persistState();
    banner.classList.remove("show");
    showToast("toast.cookieAccepted", "success");
  });

  declineBtn.addEventListener("click", () => {
    state = { necessary: true, preferences: false, analytics: false, marketing: false };
    persistState();
    banner.classList.remove("show");
    showToast("toast.cookieDeclined", "error");
  });

  saveBtn.addEventListener("click", () => {
    persistState();
    banner.classList.remove("show");
    showToast("toast.cookieSaved", "success");
  });

  if (reopenBtn) {
    reopenBtn.addEventListener("click", () => {
      banner.classList.add("show");
      preferences.classList.remove("hidden");
    });
  }

  function persistState() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    updateCheckboxes();
  }

  function updateCheckboxes() {
    document.querySelectorAll(CHECKBOX_SELECTORS).forEach((input) => {
      const type = input.dataset.cookieType;
      if (!type) return;
      if (type === "necessary") {
        input.checked = true;
      } else {
        input.checked = !!state[type];
      }
    });
  }
}