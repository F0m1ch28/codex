import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={`${styles.footerContainer} container`}>
        <div className={styles.brandColumn}>
          <h2 id="footer-heading" className={styles.footerTitle}>
            Piękny Pies
          </h2>
          <p className={styles.footerText}>
            Salon groomingu psów w samym sercu Warszawy. Naszą misją jest harmonijne połączenie
            piękna, zdrowia i spokoju każdego pupila.
          </p>
          <div className={styles.footerMeta}>
            <p>ul. Piękna 123, 00-001 Warszawa</p>
            <a href="tel:+48123456789">+48 123 456 789</a>
            <a href="mailto:kontakt@pieknypies.pl">kontakt@pieknypies.pl</a>
          </div>
        </div>
        <div className={styles.linksColumn}>
          <h3>Nawigacja</h3>
          <ul>
            <li>
              <Link to="/">Strona główna</Link>
            </li>
            <li>
              <Link to="/uslugi-groomingowe">Usługi groomingowe</Link>
            </li>
            <li>
              <Link to="/o-nas">O nas</Link>
            </li>
            <li>
              <Link to="/galeria">Galeria metamorfoz</Link>
            </li>
            <li>
              <Link to="/kontakt">Kontakt</Link>
            </li>
          </ul>
        </div>
        <div className={styles.linksColumn}>
          <h3>Dokumenty</h3>
          <ul>
            <li>
              <Link to="/regulamin">Regulamin</Link>
            </li>
            <li>
              <Link to="/polityka-prywatnosci">Polityka prywatności</Link>
            </li>
            <li>
              <Link to="/polityka-cookie">Polityka plików cookie</Link>
            </li>
          </ul>
        </div>
        <div className={styles.infoColumn}>
          <h3>Godziny otwarcia</h3>
          <ul>
            <li>Pn-Pt: 8:00 – 19:00</li>
            <li>Sobota: 9:00 – 16:00</li>
            <li>Niedziela: po uzgodnieniu</li>
          </ul>
          <p className={styles.footerNote}>
            Obserwuj nas w mediach społecznościowych, aby inspirować się codziennymi metamorfozami
            naszych klientów.
          </p>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <div className="container">
          <p>© {currentYear} Piękny Pies. Wszystkie prawa zastrzeżone.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;