import React, { useEffect, useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { label: 'Strona główna', to: '/' },
  { label: 'Usługi', to: '/uslugi-groomingowe' },
  { label: 'O nas', to: '/o-nas' },
  { label: 'Galeria', to: '/galeria' },
  { label: 'Kontakt', to: '/kontakt' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} aria-label="Strona główna Piękny Pies">
          <span className={styles.logoAccent}>Piękny</span> Pies
        </NavLink>
        <button
          className={styles.mobileToggle}
          type="button"
          aria-label="Otwórz menu nawigacji"
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span className={styles.toggleBar}></span>
          <span className={styles.toggleBar}></span>
          <span className={styles.toggleBar}></span>
          <span className="sr-only">Menu</span>
        </button>
        <nav
          id="primary-navigation"
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Główna nawigacja"
        >
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
            <li className={styles.phoneItem}>
              <a className={styles.phoneLink} href="tel:+48123456789">
                +48 123 456 789
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;