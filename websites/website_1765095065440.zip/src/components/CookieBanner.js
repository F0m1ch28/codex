import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'pieknypiesCookieConsent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p className={styles.text}>
          Używamy plików cookie, aby zapewnić komfortowe i bezpieczne korzystanie z serwisu oraz
          analizować sposób, w jaki odwiedzający odkrywają nasze treści groomingowe.
        </p>
        <div className={styles.actions}>
          <a className={styles.link} href="/polityka-cookie">
            Dowiedz się więcej
          </a>
          <button type="button" className={styles.button} onClick={handleAccept}>
            Akceptuję
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;