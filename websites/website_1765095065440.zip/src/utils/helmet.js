import React from 'react';

let helmetLib = null;

if (typeof window !== 'undefined' && window.ReactHelmetAsync) {
  helmetLib = window.ReactHelmetAsync;
}

export const HelmetProvider = helmetLib
  ? helmetLib.HelmetProvider
  : ({ children }) => <>{children}</>;

export const Helmet = helmetLib ? helmetLib.Helmet : ({ children }) => <>{children}</>;