import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/Home';
import ServicesPage from './pages/Services';
import AboutPage from './pages/About';
import GalleryPage from './pages/Gallery';
import ContactPage from './pages/Contact';
import TermsPage from './pages/Terms';
import PrivacyPage from './pages/Privacy';
import CookiePolicyPage from './pages/CookiePolicy';

const RouteChangeHandler = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

function App() {
  return (
    <div className="app-wrapper">
      <Header />
      <RouteChangeHandler />
      <main className="main-content" role="main">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/uslugi-groomingowe" element={<ServicesPage />} />
          <Route path="/o-nas" element={<AboutPage />} />
          <Route path="/galeria" element={<GalleryPage />} />
          <Route path="/kontakt" element={<ContactPage />} />
          <Route path="/regulamin" element={<TermsPage />} />
          <Route path="/polityka-prywatnosci" element={<PrivacyPage />} />
          <Route path="/polityka-cookie" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
}

export default App;