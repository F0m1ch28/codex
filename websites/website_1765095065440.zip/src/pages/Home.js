import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const statsData = [
  { label: 'Zadowolonych opiekunów', value: 1350, suffix: '+' },
  { label: 'Lat troski o psy', value: 12, suffix: '' },
  { label: 'Metamorfoz rocznie', value: 980, suffix: '+' }
];

const servicesHighlight = [
  {
    title: 'Pełny grooming premium',
    description:
      'Kompleksowa kąpiel, strzyżenie i pielęgnacja dopasowana do rasy, charakteru i rodzaju sierści.',
    icon: '🐾'
  },
  {
    title: 'Spa i masaż relaksacyjny',
    description:
      'Aromaterapia, maski odżywcze i masaż, które wyciszają psa oraz regenerują skórę i sierść.',
    icon: '🛁'
  },
  {
    title: 'Stylizacja łap i pazurków',
    description:
      'Bezpieczne skracanie pazurów, pielęgnacja opuszek oraz odżywianie skóry specjalistycznymi produktami.',
    icon: '✂️'
  },
  {
    title: 'Higiena jamy ustnej',
    description:
      'Delikatna czyszczenie zębów, usuwanie kamienia i odświeżanie oddechu przy wsparciu weterynaryjnym.',
    icon: '🦷'
  }
];

const processSteps = [
  {
    title: 'Empatyczna konsultacja',
    description:
      'Poznajemy psa, słuchamy Twoich oczekiwań i wspólnie ustalamy plan pielęgnacji dopasowany do temperamentu pupila.'
  },
  {
    title: 'Rytuał powitalny',
    description:
      'Wprowadzamy psa do salonu bez pośpiechu, pozwalając mu poznać zapachy, dźwięki i spokojnie wejść w atmosferę spa.'
  },
  {
    title: 'Indywidualna pielęgnacja',
    description:
      'Realizujemy zabieg w tempie przyjaznym dla psa, korzystając z certyfikowanych kosmetyków i narzędzi najwyższej jakości.'
  },
  {
    title: 'Stylizacja i wskazówki domowe',
    description:
      'Ostatnie szlify, sesja zdjęciowa oraz przekazanie wskazówek, jak utrzymać efekt i komfort pupila między wizytami.'
  }
];

const testimonials = [
  {
    name: 'Magda i Figa',
    city: 'Warszawa, Śródmieście',
    quote:
      'Figa boi się suszarek, ale w Pięknym Psie po raz pierwszy wyszła z salonu z merdającym ogonem. Dziękuję za cierpliwość i wyczucie.'
  },
  {
    name: 'Marek i Bruno',
    city: 'Warszawa, Mokotów',
    quote:
      'Profesjonalizm w każdym calu. Bruno wygląda jak z okładki magazynu, a ja dostałem konkretny plan pielęgnacji domowej.'
  },
  {
    name: 'Karolina i Lili',
    city: 'Warszawa, Żoliborz',
    quote:
      'Lili ma bardzo delikatną skórę. Zespół dobrał kosmetyki, które cudownie ją odżywiły. Efekt wow utrzymał się tygodniami.'
  }
];

const galleryItems = [
  {
    id: 1,
    image: 'https://picsum.photos/600/520?random=201',
    caption: 'Metamorfoza goldendoodla po rytuale spa',
    service: 'Pełny grooming'
  },
  {
    id: 2,
    image: 'https://picsum.photos/600/520?random=202',
    caption: 'Stylizacja wystawowa dla owczarka szkockiego',
    service: 'Stylizacja sezonowa'
  },
  {
    id: 3,
    image: 'https://picsum.photos/600/520?random=203',
    caption: 'Masaż relaksacyjny i kąpiel hypoalergiczna',
    service: 'Spa i wellness'
  },
  {
    id: 4,
    image: 'https://picsum.photos/600/520?random=204',
    caption: 'Zdrowe łapki po zabiegu regeneracyjnym',
    service: 'Pielęgnacja łap'
  }
];

const teamMembers = [
  {
    name: 'Marta Zielińska',
    role: 'Master groomer & behawiorystka',
    description:
      'Specjalistka od ras długowłosych, certyfikowana przez European Grooming Association. W pracy łączy sztukę strzyżenia z behawiorystyką.',
    image: 'https://picsum.photos/400/400?random=303'
  },
  {
    name: 'Piotr Kowalczyk',
    role: 'Ekspert wellness i trychologii',
    description:
      'Odpowiada za kondycję skóry i sierści psów wrażliwych. Dobiera kuracje na bazie naturalnych składników i badań trychologicznych.',
    image: 'https://picsum.photos/400/400?random=304'
  },
  {
    name: 'Anna Nowicka',
    role: 'Groomer kreatywny & szkoleniowiec',
    description:
      'Uwielbia stylizacje kreatywne i przygotowania psów do sesji zdjęciowych. Prowadzi warsztaty z pielęgnacji domowej dla opiekunów.',
    image: 'https://picsum.photos/400/400?random=305'
  }
];

const projectsData = [
  {
    id: 1,
    title: 'Kompletna metamorfoza maltańczyka',
    category: 'Pełny grooming',
    image: 'https://picsum.photos/1200/800?random=401',
    description: 'Bezstresowa sesja z dogłębnym czesaniem, kąpielą SPA i modelowaniem futra.'
  },
  {
    id: 2,
    title: 'Rytuał przeciw wypadaniu sierści',
    category: 'Zdrowie i bezpieczeństwo',
    image: 'https://picsum.photos/1200/800?random=402',
    description: 'Program regenerujący skórę z peelingiem enzymatycznym i maską odbudowującą.'
  },
  {
    id: 3,
    title: 'Stylizacja sezonowa dla sznaucera',
    category: 'Stylizacja sezonowa',
    image: 'https://picsum.photos/1200/800?random=403',
    description: 'Precyzyjny trim z akcentem na brodę i brwi, by podkreślić charakter rasy.'
  },
  {
    id: 4,
    title: 'Pakiet spa dla psiego seniora',
    category: 'SPA & wellness',
    image: 'https://picsum.photos/1200/800?random=404',
    description: 'Delikatna kąpiel na bazie owsa, masaż rozluźniający i aromaterapia wyciszająca.'
  },
  {
    id: 5,
    title: 'Program higieny jamy ustnej',
    category: 'Zdrowie i bezpieczeństwo',
    image: 'https://picsum.photos/1200/800?random=405',
    description: 'Czyszczenie zębów metodą ultradźwiękową i edukacja właściciela w zakresie profilaktyki.'
  },
  {
    id: 6,
    title: 'Sesja mistrzowska na wystawę',
    category: 'Stylizacja sezonowa',
    image: 'https://picsum.photos/1200/800?random=406',
    description: 'Stylizacja pierzasta i błyszczący finisz gotowy na ring wystawowy.'
  }
];

const faqData = [
  {
    question: 'Jak przygotować psa do wizyty w salonie Piękny Pies?',
    answer:
      'Prosimy o krótki spacer przed wizytą i niekarmienie psa bezpośrednio przed zabiegiem. Jeśli pies ma szczególne potrzeby, poinformuj nas w formularzu lub telefonicznie.'
  },
  {
    question: 'Czy mogę pozostać z psem podczas zabiegu?',
    answer:
      'Na początku adaptacji zapraszamy opiekunów do wspólnej obecności w strefie relaksu. Następnie pies koncentruje się na groomerze, a Ty relaksujesz się w naszej strefie kawowej.'
  },
  {
    question: 'Jakie kosmetyki stosujecie w trakcie groomingu?',
    answer:
      'Pracujemy na profesjonalnych kosmetykach klasy premium, wegańskich i hipoalergicznych. Każdy produkt dobieramy do kondycji skóry i sierści, aby zapewnić bezpieczeństwo.'
  },
  {
    question: 'Czy przyjmujecie psy rezerwuary lękowe lub reaktywne?',
    answer:
      'Tak, nasi groomerzy współpracują z behawiorystą. Umawiamy wówczas dłuższy termin i stosujemy plan adaptacyjny w kilku etapach, aby pies czuł się komfortowo.'
  },
  {
    question: 'Jak często powinienem planować wizyty groomingowe?',
    answer:
      'Dla ras długowłosych rekomendujemy wizyty co 4–6 tygodni, dla krótkowłosych co 8–10 tygodni. Po wizycie przygotowujemy indywidualny harmonogram pielęgnacji.'
  }
];

const blogPosts = [
  {
    id: 1,
    title: '5 rytuałów domowej pielęgnacji, które pokocha Twój pies',
    description:
      'Dowiedz się, jak wprowadzić subtelne masaże, czesanie mindful i aromaterapię między wizytami w salonie.',
    date: '15 stycznia 2024'
  },
  {
    id: 2,
    title: 'Jak rozpoznać potrzeby trychologiczne sierści?',
    description:
      'Krok po kroku wyjaśniamy, kiedy sierść woła o pomoc i jak reagować, zanim pojawią się problemy skórne.',
    date: '8 grudnia 2023'
  },
  {
    id: 3,
    title: 'Bezstresowa adaptacja psa do groomingu',
    description:
      'Sprawdzone techniki oswojenia psa z zabiegami. Z poradnika korzystają rodziny naszych klientów.',
    date: '20 listopada 2023'
  }
];

const HomePage = () => {
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Wszystko');
  const [openFaq, setOpenFaq] = useState(0);

  const categories = useMemo(() => {
    const unique = [...new Set(projectsData.map((project) => project.category))];
    return ['Wszystko', ...unique];
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'Wszystko') {
      return projectsData;
    }
    return projectsData.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  useEffect(() => {
    const duration = 1800;
    let animationFrame;

    const start = performance.now();
    const step = (timestamp) => {
      const progress = Math.min((timestamp - start) / duration, 1);
      const updated = statsData.map((item) =>
        Math.round(item.value * progress)
      );
      setAnimatedStats(updated);
      if (progress < 1) {
        animationFrame = requestAnimationFrame(step);
      }
    };

    animationFrame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <Seo
        title="Piękny Pies | Profesjonalny salon groomingu psów w Warszawie"
        description="Piękny Pies to warszawski salon groomingu oferujący pełną pielęgnację psów: strzyżenie, kąpiele, trychologię i spa. Zadbaj o komfort i styl swojego pupila."
      />
      <section
        className={styles.hero}
        style={{
          backgroundImage:
            "linear-gradient(135deg, rgba(30,58,138,0.72), rgba(30,58,138,0.55)), url('https://picsum.photos/1600/900?random=101')"
        }}
      >
        <div className={`${styles.heroContent} container`}>
          <div className={styles.heroBadge}>Salon premium • Warszawa Śródmieście</div>
          <h1 className={styles.heroTitle}>
            Piękny Pies – przestrzeń, w której pielęgnacja psa staje się rytuałem pełnym spokoju
          </h1>
          <p className={styles.heroText}>
            Tworzymy salon, który szanuje psie emocje i stawia na indywidualne podejście. Od
            konsultacji behawioralnej po kreatywną stylizację – każdy etap jest dopracowany, aby
            Twój pupil czuł się bezpiecznie.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakt" className={styles.heroPrimary}>
              Umów wizytę
            </Link>
            <Link to="/uslugi-groomingowe" className={styles.heroSecondary}>
              Poznaj nasze rytuały
            </Link>
          </div>
          <div className={styles.heroStats}>
            <p>
              ul. Piękna 123, 00-001 Warszawa •{' '}
              <a href="tel:+48123456789">+48 123 456 789</a>
            </p>
          </div>
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Statystyki salonu">
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <p className={styles.statValue}>
                  {animatedStats[index]}
                  {stat.suffix}
                </p>
                <p className={styles.statLabel}>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.aboutSection}>
        <div className="container">
          <div className={styles.aboutGrid}>
            <div>
              <h2>Tworzymy dobre wspomnienia z pierwszego cięcia</h2>
              <p>
                W Pięknym Psie pielęgnacja to więcej niż zabieg – to doświadczenie zbudowane na
                zaufaniu. Pracujemy w kameralnych gabinetach, przy kojącej muzyce i aromaterapii,
                aby każdy pies czuł się bezpiecznie. Otacza go zespół groomerów, trychologa i
                behawiorysty, którzy dobierają plan w oparciu o temperament, kondycję skóry i styl
                życia rodziny.
              </p>
              <Link to="/o-nas" className={styles.linkMore}>
                Dowiedz się więcej o naszej filozofii
              </Link>
            </div>
            <div className={styles.aboutVisual}>
              <img
                src="https://picsum.photos/800/600?random=102"
                alt="Groomer delikatnie trzyma psa podczas pielęgnacji"
              />
              <div className={styles.aboutCard}>
                <strong>Przyjazna adaptacja</strong>
                <p>
                  Pierwsze wizyty prowadzimy w rytmie psa. Zapachy, dotyk i dźwięki wprowadzamy
                  stopniowo, aby stworzyć komfortowe środowisko.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.servicesSection} aria-labelledby="services-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="services-heading">Nasze signature usługi groomingowe</h2>
            <p>
              Każdy pies wymaga innej troski. Zobacz, jak łączymy tradycyjne techniki groomingu z
              nowoczesnymi rytuałami spa i opieką trychologiczną.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesHighlight.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.iconWrapper} aria-hidden="true">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/uslugi-groomingowe" className={styles.cardLink}>
                  Poznaj szczegóły
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection} aria-labelledby="process-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="process-heading">Jak wygląda wizyta w Pięknym Psie?</h2>
            <p>
              Pracujemy etapami, dbając o komfort, bezpieczeństwo i komunikację z opiekunem na każdym kroku.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processCard}>
                <span className={styles.processNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.galleryPreview} aria-labelledby="gallery-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="gallery-heading">Galeria “przed i po” – bo efekt mówi sam za siebie</h2>
            <p>
              Zobacz ulubione przemiany naszych klientów i przekonaj się, jak wiele zmienia spersonalizowany grooming.
            </p>
          </div>
          <div className={styles.galleryGrid}>
            {galleryItems.map((item) => (
              <figure key={item.id} className={styles.galleryCard}>
                <img src={item.image} alt={item.caption} loading="lazy" />
                <figcaption>
                  <strong>{item.service}</strong>
                  <span>{item.caption}</span>
                </figcaption>
              </figure>
            ))}
          </div>
          <div className={styles.galleryCta}>
            <Link to="/galeria" className={styles.heroSecondary}>
              Obejrzyj pełną galerię
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection} aria-labelledby="testimonials-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="testimonials-heading">Historie opiekunów, którzy zaufali Pięknemu Psowi</h2>
          </div>
          <div className={styles.testimonialCard}>
            <blockquote className={styles.testimonialQuote}>
              “{testimonials[activeTestimonial].quote}”
            </blockquote>
            <p className={styles.testimonialAuthor}>
              {testimonials[activeTestimonial].name} • {testimonials[activeTestimonial].city}
            </p>
            <div className={styles.testimonialControls}>
              {testimonials.map((testimonial, index) => (
                <button
                  key={testimonial.name}
                  type="button"
                  className={`${styles.testimonialDot} ${
                    index === activeTestimonial ? styles.dotActive : ''
                  }`}
                  aria-label={`Zobacz opinię: ${testimonial.name}`}
                  onClick={() => setActiveTestimonial(index)}
                ></button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection} aria-labelledby="team-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="team-heading">Poznaj zespół, który stworzy Twój rytuał groomingowy</h2>
            <p>
              Każdy z nas specjalizuje się w innym obszarze – od stylistów futra po trychologów i behawiorystów. Wspólnie dbamy o holistyczną opiekę.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={`${member.name} - ${member.role}`} loading="lazy" />
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection} aria-labelledby="projects-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="projects-heading">Rytuały dopasowane do potrzeb Twojego pupila</h2>
            <p>Wybierz kategorię, aby zobaczyć, jak personalizujemy zabiegi.</p>
          </div>
          <div className={styles.filterButtons} role="tablist" aria-label="Kategorie rytuałów">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={projectFilter === category}
                className={`${styles.filterButton} ${
                  projectFilter === category ? styles.filterActive : ''
                }`}
                onClick={() => setProjectFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection} aria-labelledby="faq-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="faq-heading">Najczęściej zadawane pytania</h2>
            <p>
              Zebraliśmy odpowiedzi na najczęstsze pytania opiekunów psów korzystających z naszych usług groomingowych.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqData.map((item, index) => (
              <article key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqButton}
                  aria-expanded={openFaq === index}
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>{openFaq === index ? '−' : '+'}</span>
                </button>
                {openFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection} aria-labelledby="blog-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="blog-heading">Wiedza i inspiracje dla opiekunów</h2>
            <p>
              Dzielimy się praktycznymi poradami, aby pielęgnacja domowa była przedłużeniem wizyty w salonie.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <p className={styles.blogDate}>{post.date}</p>
                <h3>{post.title}</h3>
                <p>{post.description}</p>
                <a href="#blog" className={styles.cardLink}>
                  Czytaj wskazówki
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.contactSection} aria-labelledby="contact-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="contact-heading">Odwiedź nasz salon przy ul. Pięknej 123 w Warszawie</h2>
            <p>
              Zapraszamy na osobistą konsultację lub kontakt telefoniczny. Chętnie poznamy Twojego psa i przygotujemy plan pielęgnacji.
            </p>
          </div>
          <div className={styles.contactGrid}>
            <div className={styles.contactCard}>
              <h3>Dane kontaktowe</h3>
              <ul>
                <li>
                  <strong>Adres:</strong> ul. Piękna 123, 00-001 Warszawa, Polska
                </li>
                <li>
                  <strong>Telefon:</strong>{' '}
                  <a href="tel:+48123456789">+48 123 456 789</a>
                </li>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:kontakt@pieknypies.pl">kontakt@pieknypies.pl</a>
                </li>
                <li>
                  <strong>Godziny:</strong> Pn-Pt 8:00-19:00, Sobota 9:00-16:00
                </li>
              </ul>
              <Link to="/kontakt" className={styles.heroPrimary}>
                Skontaktuj się z nami
              </Link>
            </div>
            <div className={styles.mapWrapper}>
              <iframe
                title="Mapa dojazdu Piękny Pies"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2444.947037505869!2d21.011707076955973!3d52.22338635722671!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x471ecc8d4f121111%3A0x5b02ba88168cf9c9!2sPi%C4%99kna%20123%2C%2000-001%20Warszawa!5e0!3m2!1spl!2spl!4v1700000000000!5m2!1spl!2spl"
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Gotowy na nowy rozdział pielęgnacji swojego pupila?</h2>
              <p>
                Zadzwoń lub napisz do nas, aby wspólnie zaplanować pierwszą wizytę. Zadbamy o wszystko – od diagnozy po perfekcyjne wykończenie.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <a href="tel:+48123456789" className={styles.heroPrimary}>
                Zadzwoń: +48 123 456 789
              </a>
              <Link to="/kontakt" className={styles.heroSecondary}>
                Wyślij wiadomość
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;