import React from 'react';
import Seo from '../components/Seo';
import styles from './Legal.module.css';

const CookiePolicyPage = () => (
  <>
    <Seo
      title="Polityka plików cookie | Piękny Pies Warszawa"
      description="Informacje na temat wykorzystywania plików cookie na stronie salonu Piękny Pies. Dowiedz się, jak zarządzać preferencjami."
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>Polityka plików cookie</h1>
        <p>
          Wyjaśniamy, jakie pliki cookie stosujemy na stronie Piękny Pies, w jakim celu je
          wykorzystujemy i jak możesz zmienić swoje ustawienia.
        </p>
      </div>
    </section>

    <section className={styles.content}>
      <div className="container">
        <article className={styles.article}>
          <h2>Rodzaje wykorzystywanych plików cookie</h2>
          <ul>
            <li>
              Cookie niezbędne – umożliwiają poprawne działanie strony oraz obsługę formularzy
              kontaktowych.
            </li>
            <li>
              Cookie analityczne – pomagają nam zrozumieć, jak użytkownicy korzystają z witryny i
              ulepszać jej funkcjonalność.
            </li>
          </ul>
        </article>

        <article className={styles.article}>
          <h2>Zarządzanie zgodą</h2>
          <p>
            Podczas pierwszej wizyty na stronie prosimy o wyrażenie zgody na użycie cookie. Możesz ją
            w każdej chwili wycofać, zmieniając ustawienia przeglądarki lub kontaktując się z nami.
          </p>
        </article>

        <article className={styles.article}>
          <h2>Kontakt</h2>
          <p>
            W sprawach związanych z polityką cookie skontaktuj się z nami: kontakt@pieknypies.pl
          </p>
        </article>
      </div>
    </section>
  </>
);

export default CookiePolicyPage;