import React, { useMemo, useState } from 'react';
import Seo from '../components/Seo';
import styles from './Gallery.module.css';

const galleryItems = [
  {
    id: 1,
    category: 'Metamorfozy',
    title: 'Nowa fryzura shi tzu',
    description:
      'Modelowanie futra z podkreśleniem ekspresyjnych oczu oraz lekkie cieniowanie końcówek.',
    image: 'https://picsum.photos/900/700?random=601'
  },
  {
    id: 2,
    category: 'Spa',
    title: 'Relaksująca kąpiel golden retrievera',
    description:
      'Hydromasaż i zestaw produktów odbudowujących połysk sierści po sezonie letnim.',
    image: 'https://picsum.photos/900/700?random=602'
  },
  {
    id: 3,
    category: 'Stylizacja',
    title: 'Stylizacja wystawowa pudla miniaturowego',
    description:
      'Klasyczna fryzura kontynentalna z perfekcyjnym wykończeniem stref ringowych.',
    image: 'https://picsum.photos/900/700?random=603'
  },
  {
    id: 4,
    category: 'Zdrowie',
    title: 'Program trychologiczny dla border collie',
    description:
      'Peeling enzymatyczny, maska nawilżająca i plan pielęgnacji domowej dla skóry wrażliwej.',
    image: 'https://picsum.photos/900/700?random=604'
  },
  {
    id: 5,
    category: 'Metamorfozy',
    title: 'Transformacja terriera szkockiego',
    description:
      'Trimowanie ręczne z akcentem na charakterystyczną brodę oraz kontury sylwetki.',
    image: 'https://picsum.photos/900/700?random=605'
  },
  {
    id: 6,
    category: 'Spa',
    title: 'Sesja masażu dla psiego seniora',
    description:
      'Delikatny masaż powięziowy i kąpiel solankowa na bazie minerałów z Morza Martwego.',
    image: 'https://picsum.photos/900/700?random=606'
  },
  {
    id: 7,
    category: 'Stylizacja',
    title: 'Pastelowe akcenty dla pomeraniana',
    description:
      'Naturalne pigmenty pastelowe, subtelne podcięcia i stylizacja ogonka w chmurkę.',
    image: 'https://picsum.photos/900/700?random=607'
  },
  {
    id: 8,
    category: 'Zdrowie',
    title: 'Rekonstrukcja łap husky’ego',
    description:
      'Zabieg regenerujący opuszki po sezonie zimowym z zastosowaniem balsamu ochronnego.',
    image: 'https://picsum.photos/900/700?random=608'
  }
];

const GalleryPage = () => {
  const categories = useMemo(() => ['Wszystko', ...new Set(galleryItems.map((item) => item.category))], []);
  const [filter, setFilter] = useState('Wszystko');

  const filteredItems = useMemo(() => {
    if (filter === 'Wszystko') {
      return galleryItems;
    }
    return galleryItems.filter((item) => item.category === filter);
  }, [filter]);

  return (
    <>
      <Seo
        title="Galeria metamorfoz | Piękny Pies Warszawa"
        description="Zobacz spektakularne metamorfozy psów w salonie Piękny Pies. Inspiracje, stylizacje i zabiegi spa wykonane przez naszych groomerów."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Galeria metamorfoz i rytuałów Pięknego Psa</h1>
          <p>
            Zapraszamy do wizualnej podróży po naszych zabiegach. Zdjęcia przedstawiają psy, które
            odwiedziły nasz salon i skorzystały z rytuałów dopasowanych do ich potrzeb.
          </p>
        </div>
      </section>

      <section className={styles.gallery}>
        <div className="container">
          <div className={styles.filters} role="tablist" aria-label="Filtruj galerię">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={filter === category}
                className={`${styles.filterButton} ${filter === category ? styles.filterActive : ''}`}
                onClick={() => setFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.grid}>
            {filteredItems.map((item) => (
              <article key={item.id} className={styles.card}>
                <img src={item.image} alt={`${item.title} - ${item.category}`} loading="lazy" />
                <div className={styles.cardContent}>
                  <span className={styles.cardCategory}>{item.category}</span>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default GalleryPage;