import React, { useMemo, useState } from 'react';
import Seo from '../components/Seo';
import styles from './Services.module.css';

const servicesData = [
  {
    id: 'grooming',
    title: 'Pełny grooming premium',
    intro:
      'Kompleksowy rytuał obejmujący kąpiel, pielęgnację, strzyżenie i stylizację w oparciu o anatomię rasy.',
    benefits: [
      'Szczegółowa konsultacja i diagnoza stanu sierści oraz skóry',
      'Kąpiel w dwóch etapach z odżywką wzmacniającą',
      'Strzyżenie modelujące z wykończeniem stref wrażliwych',
      'Stylizacja końcowa z suszeniem dyfuzyjnym i wygładzaniem'
    ],
    ritual:
      'W trakcie rytuału pielęgnacyjnego łączymy techniki czesania warstwowego, pracę z nożyczkami i trymerami oraz specjalistyczne kosmetyki. Całość uzupełniamy masażem relaksacyjnym łap.',
    image: 'https://picsum.photos/1100/700?random=501'
  },
  {
    id: 'spa',
    title: 'Spa i wellness dla psów',
    intro:
      'Program relaksacyjny dla psów potrzebujących wyciszenia, regeneracji skóry i odżywienia futra.',
    benefits: [
      'Hydromasaż w wannie z mikro-bąbelkami',
      'Maseczki odżywcze i algi regenerujące skórę',
      'Aromaterapia dobrana do temperamentu psa',
      'Delikatny masaż powięziowy i rozciąganie'
    ],
    ritual:
      'Zabieg rozpoczynamy od inhalacji, która wycisza zmysły psa. Następnie przeprowadzamy kąpiel z masażem terapeutycznym, maskę regenerującą oraz relaksacyjną sesję w strefie ciszy.',
    image: 'https://picsum.photos/1100/700?random=502'
  },
  {
    id: 'trichology',
    title: 'Trychologia i profilaktyka skóry',
    intro:
      'Specjalistyczne konsultacje i zabiegi dla psów z problemami skóry, nadmiernym linieniem lub łupieżem.',
    benefits: [
      'Diagnostyka skóry pod kamerą trychologiczną',
      'Peeling enzymatyczny i kąpiel terapeutyczna',
      'Dobór kosmetyków i suplementów do pielęgnacji domowej',
      'Plan redukcji stresu wpływającego na kondycję sierści'
    ],
    ritual:
      'Trycholog analizuje strukturę sierści oraz poziom nawilżenia skóry, dobierając odpowiednie preparaty. Zalecenia otrzymuje także opiekun, aby kontynuować terapię w domu.',
    image: 'https://picsum.photos/1100/700?random=503'
  }
];

const complementaryServices = [
  {
    title: 'Higiena jamy ustnej',
    description:
      'Delikatne usuwanie kamienia i osadu przy wsparciu ultradźwięków oraz dobór produktów do pielęgnacji domowej.'
  },
  {
    title: 'Pielęgnacja łap i pazurów',
    description:
      'Regeneracja opuszek, skracanie pazurów, kąpiele solankowe i zabezpieczenie łap przed podrażnieniami.'
  },
  {
    title: 'Stylizacje kreatywne',
    description:
      'Subtelne ozdoby, naturalne barwienie z użyciem pigmentów wegańskich i przygotowanie do sesji zdjęciowych.'
  },
  {
    title: 'Program senior',
    description:
      'Zabiegi dopasowane do potrzeb psów starszych: masaże rozluźniające, kąpiele łagodzące bóle stawów i indywidualne przerwy na odpoczynek.'
  }
];

const workflow = [
  {
    title: 'Plan pielęgnacji',
    detail:
      'Po konsultacji otrzymujesz spersonalizowany plan opieki obejmujący zabiegi w salonie i wskazówki domowe.'
  },
  {
    title: 'Rytuał w salonie',
    detail:
      'Każdy etap zabiegu jest komunikowany z opiekunem. Pies ma zapewnione przerwy i spokojne tempo pracy.'
  },
  {
    title: 'Opieka po wizycie',
    detail:
      'Monitorujemy efekty zabiegu, rekomendujemy kosmetyki i zapraszamy na kontrolny kontakt po kilku dniach.'
  }
];

const ServicesPage = () => {
  const [activeService, setActiveService] = useState(servicesData[0].id);

  const currentService = useMemo(
    () => servicesData.find((service) => service.id === activeService),
    [activeService]
  );

  return (
    <>
      <Seo
        title="Usługi groomingu psów | Piękny Pies Warszawa"
        description="Pełny grooming, spa, trychologia i pielęgnacja premium dla psów. Poznaj rytuały Pięknego Psa i wybierz zabieg dopasowany do Twojego pupila."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Rytuały pielęgnacyjne dopasowane do charakteru i stylu życia psa</h1>
          <p>
            W Pięknym Psie każdy zabieg jest tworzony indywidualnie. Rozpoczynamy od konsultacji,
            dobieramy kosmetyki, tempo pracy i rytuały, które zapewniają bezpieczeństwo oraz
            spektakularny efekt.
          </p>
        </div>
      </section>

      <section className={styles.servicesTabs} aria-labelledby="services-tabs-heading">
        <div className="container">
          <h2 id="services-tabs-heading">Wybierz obszar, który Cię interesuje</h2>
          <div className={styles.tabList} role="tablist">
            {servicesData.map((service) => (
              <button
                key={service.id}
                type="button"
                role="tab"
                aria-selected={activeService === service.id}
                className={`${styles.tabButton} ${
                  activeService === service.id ? styles.tabActive : ''
                }`}
                onClick={() => setActiveService(service.id)}
              >
                {service.title}
              </button>
            ))}
          </div>

          <div className={styles.serviceDetail} role="tabpanel">
            <div className={styles.detailContent}>
              <h3>{currentService.title}</h3>
              <p className={styles.detailIntro}>{currentService.intro}</p>
              <ul className={styles.detailList}>
                {currentService.benefits.map((benefit) => (
                  <li key={benefit}>{benefit}</li>
                ))}
              </ul>
              <p>{currentService.ritual}</p>
            </div>
            <div className={styles.detailVisual}>
              <img src={currentService.image} alt={currentService.title} />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.workflow} aria-labelledby="workflow-heading">
        <div className="container">
          <h2 id="workflow-heading">Jak dbamy o ciągłość pielęgnacji</h2>
          <div className={styles.workflowGrid}>
            {workflow.map((item) => (
              <article key={item.title} className={styles.workflowCard}>
                <h3>{item.title}</h3>
                <p>{item.detail}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.complementary} aria-labelledby="complementary-heading">
        <div className="container">
          <h2 id="complementary-heading">Usługi uzupełniające dla kompleksowej opieki</h2>
          <div className={styles.complementaryGrid}>
            {complementaryServices.map((service) => (
              <article key={service.title} className={styles.complementaryCard}>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Gotowy na indywidualną konsultację groomingową?</h2>
              <p>
                Zadzwoń lub napisz do nas, aby zaplanować pierwszą wizytę. Chętnie opowiemy, jak
                wygląda proces i jakie efekty możemy osiągnąć dla Twojego pupila.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <a href="tel:+48123456789" className={styles.ctaPrimary}>
                +48 123 456 789
              </a>
              <a href="mailto:kontakt@pieknypies.pl" className={styles.ctaSecondary}>
                kontakt@pieknypies.pl
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;