import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './About.module.css';

const pillars = [
  {
    title: 'Empatia wobec psich emocji',
    description:
      'Każdego gościa witamy w tempie, które jest dla niego komfortowe. Znamy sygnały stresu i reagujemy zanim pies poczuje dyskomfort.'
  },
  {
    title: 'Rzemiosło i estetyka',
    description:
      'Łączymy tradycyjne techniki groomingu z innowacyjnymi metodami stylizacji. Dbamy o proporcje, strukturę sierści i detale.'
  },
  {
    title: 'Holistyczne podejście',
    description:
      'Współpracujemy z behawiorystą i trychologiem. Dobieramy kosmetyki, suplementy i rytuały pielęgnacyjne odpowiadające kondycji psa.'
  }
];

const milestones = [
  {
    year: '2012',
    title: 'Narodziny Pięknego Psa',
    description:
      'Otwieramy kameralny salon na warszawskim Śródmieściu. Naszym priorytetem jest oswojenie psów z groomingiem.'
  },
  {
    year: '2016',
    title: 'Rozszerzenie zespołu',
    description:
      'Do zespołu dołącza trycholog oraz behawiorystka. Powstaje autorski program adaptacyjny dla psów wrażliwych.'
  },
  {
    year: '2020',
    title: 'Strefa SPA i wellness',
    description:
      'Rozbudowujemy salon o strefę masażu, aromaterapii oraz gabinet konsultacyjny dla opiekunów.'
  },
  {
    year: '2023',
    title: 'Program edukacyjny dla opiekunów',
    description:
      'Organizujemy warsztaty i szkolenia z pielęgnacji domowej, karmienia i profilaktyki trychologicznej.'
  }
];

const certificates = [
  'European Grooming Association – Master Groomer',
  'Certyfikat Trychologii Zwierzęcej – poziom ekspert',
  'Szkolenie Behawiorysty Psów Towarzyszących',
  'Szkolenia bezpieczeństwa groomingu psów reaktywnych'
];

const AboutPage = () => (
  <>
    <Seo
      title="O salonie Piękny Pies | Zespół groomerów i ekspertów z Warszawy"
      description="Poznaj historię, wartości i zespół salonu Piękny Pies. Od 2012 roku tworzymy miejsce, gdzie grooming psa jest wyjątkowym doświadczeniem."
    />
    <section className={styles.hero}>
      <div className="container">
        <span className={styles.badge}>O nas</span>
        <h1>
          Piękny Pies to salon stworzony z miłości do psów, estetyki i świadomej pielęgnacji
        </h1>
        <p>
          Zbudowaliśmy zespół, który łączy pasję, wiedzę i empatię. Naszym celem jest, aby każdy pies
          czuł się wysłuchany, a każdy opiekun miał pewność, że jego pupil jest w najlepszych rękach.
        </p>
      </div>
    </section>

    <section className={styles.pillars} aria-labelledby="pillars-heading">
      <div className="container">
        <h2 id="pillars-heading">Trzy filary Pięknego Psa</h2>
        <div className={styles.pillarsGrid}>
          {pillars.map((pillar) => (
            <article key={pillar.title} className={styles.pillarCard}>
              <h3>{pillar.title}</h3>
              <p>{pillar.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.story} aria-labelledby="story-heading">
      <div className="container">
        <div className={styles.storyGrid}>
          <div>
            <h2 id="story-heading">Dlaczego powstał Piękny Pies?</h2>
            <p>
              Jako opiekunowie psów, wiedzieliśmy, jak stresująca bywa wizyta u groomera. Chcieliśmy
              stworzyć przestrzeń, w której pies czuje się jak w spa, a opiekun ma pewność, że zabieg
              zostanie wykonany profesjonalnie i z troską o zdrowie pupila.
            </p>
            <p>
              Rozwijamy się razem z naszymi klientami. Bierzemy udział w międzynarodowych szkoleniach
              groomingowych, śledzimy trendy trychologiczne i stale podnosimy kompetencje zespołu.
              Dzięki temu możemy oferować rytuały pielęgnacyjne na najwyższym poziomie.
            </p>
            <Link to="/kontakt" className={styles.cta}>
              Umów konsultację wstępną
            </Link>
          </div>
          <div className={styles.storyVisual}>
            <img
              src="https://picsum.photos/900/650?random=106"
              alt="Zespół groomerów podczas konsultacji w salonie"
            />
          </div>
        </div>
      </div>
    </section>

    <section className={styles.timeline} aria-labelledby="timeline-heading">
      <div className="container">
        <h2 id="timeline-heading">Kamienie milowe naszego salonu</h2>
        <div className={styles.timelineGrid}>
          {milestones.map((milestone) => (
            <article key={milestone.year} className={styles.timelineCard}>
              <span className={styles.timelineYear}>{milestone.year}</span>
              <h3>{milestone.title}</h3>
              <p>{milestone.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.certificates} aria-labelledby="certificates-heading">
      <div className="container">
        <h2 id="certificates-heading">Certyfikaty i specjalistyczne szkolenia</h2>
        <ul className={styles.certificateList}>
          {certificates.map((certificate) => (
            <li key={certificate}>{certificate}</li>
          ))}
        </ul>
      </div>
    </section>

    <section className={styles.invite}>
      <div className="container">
        <div className={styles.inviteCard}>
          <div>
            <h2>Chcesz nas poznać jeszcze lepiej?</h2>
            <p>
              Odwiedź nas w salonie, zobacz jak wygląda zaplecze i porozmawiaj z groomerem przy
              aromatycznej kawie. Wspólnie ustalimy plan pielęgnacji Twojego pupila.
            </p>
          </div>
          <div className={styles.inviteActions}>
            <a href="tel:+48123456789" className={styles.ctaPrimary}>
              Zadzwoń do nas
            </a>
            <Link to="/kontakt" className={styles.ctaSecondary}>
              Wyślij wiadomość
            </Link>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default AboutPage;