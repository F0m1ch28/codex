import React from 'react';
import Seo from '../components/Seo';
import styles from './Legal.module.css';

const PrivacyPage = () => (
  <>
    <Seo
      title="Polityka prywatności | Piękny Pies Warszawa"
      description="Dowiedz się, jak salon Piękny Pies przetwarza dane osobowe klientów, w tym zasady kontaktu i ochrony prywatności."
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>Polityka prywatności salonu Piękny Pies</h1>
        <p>
          Dbamy o bezpieczeństwo Twoich danych. Poniżej znajdziesz informacje o tym, jakie dane
          zbieramy, w jakim celu oraz jak możesz nimi zarządzać.
        </p>
      </div>
    </section>

    <section className={styles.content}>
      <div className="container">
        <article className={styles.article}>
          <h2>Administrator danych</h2>
          <p>
            Administratorem danych osobowych jest Piękny Pies z siedzibą przy ul. Pięknej 123,
            00-001 Warszawa. Kontakt: kontakt@pieknypies.pl
          </p>
        </article>

        <article className={styles.article}>
          <h2>Zakres przetwarzanych danych</h2>
          <ul>
            <li>Dane kontaktowe: imię, nazwisko, numer telefonu, adres e-mail.</li>
            <li>
              Informacje dotyczące psa: rasa, wiek, stan zdrowia, preferencje dotyczące zabiegów.
            </li>
            <li>
              Dane dotyczące historii wizyt oraz preferencji pielęgnacyjnych w celu planowania
              kolejnych usług.
            </li>
          </ul>
        </article>

        <article className={styles.article}>
          <h2>Cel przetwarzania danych</h2>
          <p>
            Dane przetwarzamy w celu obsługi rezerwacji, świadczenia usług, kontaktu z klientem oraz
            wysyłki informacji dotyczących wizyt i zaleceń pielęgnacyjnych.
          </p>
        </article>

        <article className={styles.article}>
          <h2>Prawa osoby, której dane dotyczą</h2>
          <p>
            Masz prawo dostępu do swoich danych, ich sprostowania, usunięcia, ograniczenia
            przetwarzania oraz prawo wniesienia sprzeciwu. Możesz także zażądać przeniesienia danych
            do innego podmiotu.
          </p>
        </article>

        <article className={styles.article}>
          <h2>Przechowywanie i zabezpieczenia</h2>
          <p>
            Dane przechowujemy tak długo, jak jest to niezbędne do realizacji usług oraz zgodnie z
            obowiązującymi przepisami. Zastosowaliśmy zabezpieczenia techniczne i organizacyjne,
            które chronią dane przed nieuprawnionym dostępem.
          </p>
        </article>
      </div>
    </section>
  </>
);

export default PrivacyPage;