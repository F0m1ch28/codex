import React from 'react';
import Seo from '../components/Seo';
import styles from './Legal.module.css';

const TermsPage = () => (
  <>
    <Seo
      title="Regulamin | Piękny Pies Warszawa"
      description="Regulamin korzystania z usług salonu groomingu Piękny Pies w Warszawie. Poznaj zasady rezerwacji, przebiegu wizyt i odpowiedzialności."
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>Regulamin korzystania z usług salonu Piękny Pies</h1>
        <p>
          Dokument określa zasady świadczenia usług groomingowych, rezerwacji terminów oraz prawa i
          obowiązki opiekunów odwiedzających salon.
        </p>
      </div>
    </section>

    <section className={styles.content}>
      <div className="container">
        <article className={styles.article}>
          <h2>§1 Postanowienia ogólne</h2>
          <p>
            1. Salon Piękny Pies z siedzibą przy ul. Pięknej 123 w Warszawie świadczy usługi
            groomingu, pielęgnacji i konsultacji dla psów. <br />
            2. Niniejszy regulamin określa warunki współpracy między salonem a opiekunami psów. <br />
            3. Rezerwacja wizyty oznacza akceptację regulaminu.
          </p>
        </article>

        <article className={styles.article}>
          <h2>§2 Rezerwacja i organizacja wizyt</h2>
          <ul>
            <li>
              Rezerwacji można dokonać telefonicznie (+48 123 456 789) lub mailowo
              (kontakt@pieknypies.pl).
            </li>
            <li>Wizyty potwierdzane są drogą elektroniczną lub telefonicznie na 24h przed terminem.</li>
            <li>
              Odwołanie wizyty prosimy zgłaszać najpóźniej 24h przed planowanym terminem. Pozwala to
              nam zaproponować slot innym klientom.
            </li>
            <li>
              Spóźnienie powyżej 15 minut może skutkować skróceniem lub przełożeniem zabiegu, aby
              nie zakłócić harmonogramu.
            </li>
          </ul>
        </article>

        <article className={styles.article}>
          <h2>§3 Zdrowie i bezpieczeństwo psa</h2>
          <p>
            Opiekun zobowiązuje się poinformować zespół o stanie zdrowia psa, alergiach, leczeniu
            farmakologicznym, zmianach skórnych oraz ewentualnych zachowaniach lękowych. Salon ma
            prawo odmówić wykonania zabiegu w przypadku podejrzenia choroby zakaźnej lub zagrażającej
            zdrowiu psa.
          </p>
        </article>

        <article className={styles.article}>
          <h2>§4 Odpowiedzialność i zasady zachowania</h2>
          <ul>
            <li>
              Opiekun odpowiada za szkody wyrządzone przez psa na terenie salonu, z wyjątkiem
              sytuacji wynikających z winy salonu.
            </li>
            <li>
              Salon nie ponosi odpowiedzialności za skutki zatajenia informacji o stanie zdrowia psa.
            </li>
            <li>
              W przypadku wystąpienia nieprzewidzianych reakcji psa groomer może przerwać zabieg i
              zaproponować plan adaptacyjny.
            </li>
          </ul>
        </article>

        <article className={styles.article}>
          <h2>§5 Reklamacje</h2>
          <p>
            Uwagi dotyczące wykonanej usługi należy zgłaszać w salonie niezwłocznie po zabiegu lub w
            ciągu 24 godzin. Zależy nam na otwartym dialogu i wspólnym znalezieniu satysfakcjonującego rozwiązania.
          </p>
        </article>
      </div>
    </section>
  </>
);

export default TermsPage;