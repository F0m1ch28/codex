import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  phone: '',
  message: '',
  service: 'Pełny grooming'
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Podaj swoje imię i nazwisko.';
    if (!formData.email.trim()) {
      newErrors.email = 'Podaj adres email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Podaj prawidłowy adres email.';
    }
    if (!formData.message.trim()) newErrors.message = 'Napisz kilka słów o swoim psie.';
    return newErrors;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setFormData(initialFormState);
    }
  };

  return (
    <>
      <Seo
        title="Kontakt | Piękny Pies Warszawa"
        description="Skontaktuj się z salonem Piękny Pies. Umów wizytę groomingową, dowiedz się więcej o naszych usługach i poznaj plan pielęgnacji dla Twojego psa."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Skontaktuj się z Pięknym Psem</h1>
          <p>
            Opowiedz nam o swoim psie, a przygotujemy dla niego plan pielęgnacyjny. Zadzwoń, napisz
            lub odwiedź nas w salonie – jesteśmy tu, aby odpowiedzieć na wszystkie Twoje pytania.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.infoCard}>
              <h2>Dane kontaktowe</h2>
              <ul>
                <li>
                  <strong>Adres:</strong> ul. Piękna 123, 00-001 Warszawa, Polska
                </li>
                <li>
                  <strong>Telefon:</strong>{' '}
                  <a href="tel:+48123456789">+48 123 456 789</a>
                </li>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:kontakt@pieknypies.pl">kontakt@pieknypies.pl</a>
                </li>
                <li>
                  <strong>Godziny:</strong> Pn-Pt 8:00-19:00, Sobota 9:00-16:00
                </li>
              </ul>
              <p className={styles.note}>
                Jeśli Twój pies wymaga szczególnej opieki (lęk separacyjny, alergie), poinformuj nas
                w formularzu lub telefonicznie – przygotujemy salon przed wizytą.
              </p>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Formularz kontaktowy</h2>
              {submitted && (
                <div className={styles.success}>
                  Dziękujemy za wiadomość! Skontaktujemy się z Tobą w ciągu jednego dnia roboczego.
                </div>
              )}
              <label htmlFor="name">
                Imię i nazwisko
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                  placeholder="Wpisz swoje imię i nazwisko"
                />
                {errors.name && (
                  <span id="name-error" className={styles.error}>
                    {errors.name}
                  </span>
                )}
              </label>
              <label htmlFor="email">
                Adres email
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                  placeholder="np. kontakt@pieknypies.pl"
                />
                {errors.email && (
                  <span id="email-error" className={styles.error}>
                    {errors.email}
                  </span>
                )}
              </label>
              <label htmlFor="phone">
                Telefon (opcjonalnie)
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="+48 123 456 789"
                />
              </label>
              <label htmlFor="service">
                Wybierz interesującą Cię usługę
                <select
                  id="service"
                  name="service"
                  value={formData.service}
                  onChange={handleChange}
                >
                  <option>Pełny grooming</option>
                  <option>Spa i wellness</option>
                  <option>Trychologia i kondycja sierści</option>
                  <option>Higiena jamy ustnej</option>
                  <option>Pielęgnacja łap i pazurów</option>
                </select>
              </label>
              <label htmlFor="message">
                Opowiedz nam o swoim psie
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                  placeholder="Wiek, rasa, temperament, szczególne potrzeby..."
                ></textarea>
                {errors.message && (
                  <span id="message-error" className={styles.error}>
                    {errors.message}
                  </span>
                )}
              </label>
              <button type="submit" className={styles.submitButton}>
                Wyślij wiadomość
              </button>
            </form>
          </div>
        </div>
      </section>

      <section className={styles.mapSection}>
        <div className="container">
          <div className={styles.mapWrapper}>
            <iframe
              title="Lokalizacja salonu Piękny Pies"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2444.947037505869!2d21.011707076955973!3d52.22338635722671!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x471ecc8d4f121111%3A0x5b02ba88168cf9c9!2sPi%C4%99kna%20123%2C%2000-001%20Warszawa!5e0!3m2!1spl!2spl!4v1700000000000!5m2!1spl!2spl"
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;