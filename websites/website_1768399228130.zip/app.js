document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const mainNav = document.querySelector('.main-nav');

    if (navToggle && mainNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            mainNav.classList.toggle('open');
        });

        mainNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (mainNav.classList.contains('open')) {
                    mainNav.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-btn[data-action]');
    const cookieFlag = localStorage.getItem('smoothzncn_cookie_choice');

    if (cookieFlag && cookieBanner) {
        cookieBanner.style.display = 'none';
    }

    cookieButtons.forEach(btn => {
        btn.addEventListener('click', event => {
            event.preventDefault();
            const action = btn.dataset.action;
            localStorage.setItem('smoothzncn_cookie_choice', action);
            if (cookieBanner) {
                cookieBanner.style.display = 'none';
            }
            window.open('cookies.html', '_blank');
        });
    });
});