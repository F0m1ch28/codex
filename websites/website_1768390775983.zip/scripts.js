document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-active');
            navMenu.classList.toggle('is-open');
            document.body.style.overflow = navMenu.classList.contains('is-open') ? 'hidden' : '';
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('is-open')) {
                    navMenu.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                    document.body.style.overflow = '';
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = cookieBanner ? cookieBanner.querySelectorAll('.cookie-btn') : [];

    const cookieStorageKey = 'fiftyokcpi-cookie-choice';

    const showCookieBanner = () => {
        if (!cookieBanner) return;
        cookieBanner.classList.add('is-visible');
    };

    const hideCookieBanner = () => {
        if (!cookieBanner) return;
        cookieBanner.classList.remove('is-visible');
    };

    if (cookieBanner && !localStorage.getItem(cookieStorageKey)) {
        showCookieBanner();
    }

    cookieButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const action = btn.getAttribute('data-cookie-action');
            const target = btn.getAttribute('data-target');
            if (action === 'accept') {
                localStorage.setItem(cookieStorageKey, 'accepted');
            } else if (action === 'decline') {
                localStorage.setItem(cookieStorageKey, 'declined');
            }
            hideCookieBanner();
            if (target) {
                window.open(target, '_blank');
            }
        });
    });

    const forms = document.querySelectorAll('form[data-validate="true"]');
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                form.classList.add('is-error');
            }
        });
    });
});