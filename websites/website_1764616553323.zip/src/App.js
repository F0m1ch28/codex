import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import HomePage from "./pages/HomePage";
import InflationPage from "./pages/InflationPage";
import CoursePage from "./pages/CoursePage";
import ResourcesPage from "./pages/ResourcesPage";
import ContactPage from "./pages/ContactPage";
import ThankYouPage from "./pages/ThankYouPage";
import PrivacyPage from "./pages/PrivacyPage";
import CookiesPage from "./pages/CookiesPage";
import TermsPage from "./pages/TermsPage";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import DisclaimerModal from "./components/DisclaimerModal";
import { useLanguage } from "./context/LanguageContext";

const PageWrapper = ({ children }) => (
  <motion.div
    initial={{ opacity: 0, y: 16 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -12 }}
    transition={{ duration: 0.35, ease: "easeInOut" }}
  >
    {children}
  </motion.div>
);

const App = () => {
  const location = useLocation();
  const { language } = useLanguage();

  return (
    <>
      <Header />
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname + language}>
          <Route
            path="/"
            element={
              <PageWrapper>
                <HomePage />
              </PageWrapper>
            }
          />
          <Route
            path="/inflation"
            element={
              <PageWrapper>
                <InflationPage />
              </PageWrapper>
            }
          />
          <Route
            path="/course"
            element={
              <PageWrapper>
                <CoursePage />
              </PageWrapper>
            }
          />
          <Route
            path="/resources"
            element={
              <PageWrapper>
                <ResourcesPage />
              </PageWrapper>
            }
          />
          <Route
            path="/contact"
            element={
              <PageWrapper>
                <ContactPage />
              </PageWrapper>
            }
          />
          <Route
            path="/thank-you"
            element={
              <PageWrapper>
                <ThankYouPage />
              </PageWrapper>
            }
          />
          <Route
            path="/privacy"
            element={
              <PageWrapper>
                <PrivacyPage />
              </PageWrapper>
            }
          />
          <Route
            path="/cookies"
            element={
              <PageWrapper>
                <CookiesPage />
              </PageWrapper>
            }
          />
          <Route
            path="/terms"
            element={
              <PageWrapper>
                <TermsPage />
              </PageWrapper>
            }
          />
        </Routes>
      </AnimatePresence>
      <Footer />
      <CookieBanner />
      <DisclaimerModal />
    </>
  );
};

export default App;