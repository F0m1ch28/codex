import React from "react";
import { Helmet } from "react-helmet-async";
import "./ContactPage.css";
import { useLanguage } from "../context/LanguageContext";

const ContactPage = () => {
  const { language } = useLanguage();
  const isEnglish = language === "en";

  return (
    <div className="contact">
      <Helmet>
        <title>Contact Tu Progreso Hoy | Buenos Aires</title>
        <meta
          name="description"
          content="Contact Tu Progreso Hoy for educational partnerships, support queries, and media requests."
        />
      </Helmet>
      <section className="contact__hero">
        <h1>{isEnglish ? "Stay connected with our team" : "Conectá con nuestro equipo"}</h1>
        <p>
          {isEnglish
            ? "Reach out for onboarding support, cohort requests, or media inquiries. We respond within two business days."
            : "Contactanos por soporte de onboarding, solicitudes de cohortes o prensa. Respondemos en un máximo de dos días hábiles."}
        </p>
      </section>

      <section className="contact__grid">
        <div className="contact__card">
          <h2>{isEnglish ? "Contact details" : "Datos de contacto"}</h2>
          <p>
            Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
            <br />
            +54 11 5555-1234
            <br />
            hola@tuprogresohoy.ar
          </p>
          <form className="contact__form">
            <label htmlFor="topic">{isEnglish ? "Topic" : "Tema"}</label>
            <select id="topic" name="topic">
              <option>{isEnglish ? "Course onboarding" : "Onboarding del curso"}</option>
              <option>{isEnglish ? "Data partnership" : "Alianza de datos"}</option>
              <option>{isEnglish ? "Press & media" : "Prensa y medios"}</option>
            </select>
            <label htmlFor="message">{isEnglish ? "Message" : "Mensaje"}</label>
            <textarea id="message" name="message" rows="4" placeholder={isEnglish ? "Tell us how we can help you" : "Contanos en qué podemos ayudarte"} />
            <button type="submit">{isEnglish ? "Send message" : "Enviar mensaje"}</button>
          </form>
        </div>
        <div className="contact__map">
          <iframe
            title="Tu Progreso Hoy Buenos Aires Map"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3283.6780815634452!2d-58.38291568430896!3d-34.61178016540911!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccacdf8dccf3f%3A0x9a84f3f447e8eb!2sAv.%209%20de%20Julio%201000%2C%20C1043%20%20CABA!5e0!3m2!1sen!2sar!4v1700000000000!5m2!1sen!2sar"
            loading="lazy"
            allowFullScreen
          />
        </div>
      </section>

      <section className="contact__socials">
        <h2>{isEnglish ? "Follow our updates" : "Seguinos"}</h2>
        <div className="contact__socialGrid">
          <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn Tu Progreso Hoy">
            LinkedIn
          </a>
          <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer" aria-label="Twitter Tu Progreso Hoy">
            X (Twitter)
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" aria-label="YouTube Tu Progreso Hoy">
            YouTube
          </a>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;