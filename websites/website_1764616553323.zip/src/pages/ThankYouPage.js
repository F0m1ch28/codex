import React from "react";
import { Helmet } from "react-helmet-async";
import "./ThankYouPage.css";
import { useLanguage } from "../context/LanguageContext";

const ThankYouPage = () => {
  const { language } = useLanguage();
  const isEnglish = language === "en";

  return (
    <div className="thankyou">
      <Helmet>
        <title>Thank You | Tu Progreso Hoy</title>
        <meta name="description" content="Thank you for confirming your access to Tu Progreso Hoy." />
      </Helmet>
      <section className="thankyou__card">
        <h1>{isEnglish ? "You are all set!" : "¡Estás listo!"}</h1>
        <p>
          {isEnglish
            ? "Your request for the preview class has been confirmed. Check your inbox for access instructions and calendar invites."
            : "Tu solicitud para la clase de prueba fue confirmada. Revisá tu correo para obtener instrucciones de acceso e invitaciones de calendario."}
        </p>
        <a href="/" className="thankyou__btn">
          {isEnglish ? "Return home" : "Volver al inicio"}
        </a>
      </section>
    </div>
  );
};

export default ThankYouPage;