import React from "react";
import { Helmet } from "react-helmet-async";
import "./LegalPages.css";
import { useLanguage } from "../context/LanguageContext";

const TermsPage = () => {
  const { language } = useLanguage();
  const isEnglish = language === "en";

  return (
    <div className="legal">
      <Helmet>
        <title>Terms of Service | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Review the terms and conditions for using Tu Progreso Hoy, the educational SaaS platform."
        />
      </Helmet>
      <section className="legal__hero">
        <h1>{isEnglish ? "Terms of Service" : "Términos de Servicio"}</h1>
        <p>
          {isEnglish
            ? "These terms govern access to Tu Progreso Hoy. By joining, you acknowledge our educational focus and agree to comply with applicable regulations."
            : "Estos términos regulan el acceso a Tu Progreso Hoy. Al unirte, reconocés nuestro enfoque educativo y te comprometés a cumplir con la normativa aplicable."}
        </p>
      </section>
      <section className="legal__content">
        <h2>{isEnglish ? "1. Service scope" : "1. Alcance del servicio"}</h2>
        <p>
          {isEnglish
            ? "Tu Progreso Hoy offers educational content, data visualizations, and collaborative tools. We do not provide brokerage or investment services."
            : "Tu Progreso Hoy ofrece contenido educativo, visualizaciones de datos y herramientas colaborativas. No brindamos servicios de intermediación ni inversión."}
        </p>
        <h2>{isEnglish ? "2. Acceptable use" : "2. Uso aceptable"}</h2>
        <p>
          {isEnglish
            ? "Users agree to maintain the integrity of shared workspaces, respect community guidelines, and avoid unauthorized redistribution of content."
            : "Las personas usuarias se comprometen a mantener la integridad de los espacios compartidos, respetar las pautas comunitarias y evitar redistribuciones no autorizadas."}
        </p>
        <h2>{isEnglish ? "3. Intellectual property" : "3. Propiedad intelectual"}</h2>
        <p>
          {isEnglish
            ? "All materials remain the intellectual property of Tu Progreso Hoy. Limited licenses are granted for educational purposes."
            : "Todo material permanece como propiedad intelectual de Tu Progreso Hoy. Se otorgan licencias limitadas con fines educativos."}
        </p>
        <h2>{isEnglish ? "4. Liability" : "4. Responsabilidad"}</h2>
        <p>
          {isEnglish
            ? "We provide information on an as-is basis for learning. Users remain responsible for decisions derived from the content."
            : "Proveemos información tal cual para el aprendizaje. Quienes usan la plataforma son responsables de las decisiones derivadas del contenido."}
        </p>
        <h2>{isEnglish ? "5. Governing law" : "5. Legislación aplicable"}</h2>
        <p>
          {isEnglish
            ? "These terms are governed by the laws of the Argentine Republic. Disputes will be resolved in the courts of Buenos Aires."
            : "Estos términos se rigen por las leyes de la República Argentina. Cualquier disputa se resolverá en los tribunales de Buenos Aires."}
        </p>
      </section>
    </div>
  );
};

export default TermsPage;