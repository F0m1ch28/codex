import React from "react";
import { Helmet } from "react-helmet-async";
import "./LegalPages.css";
import { useLanguage } from "../.context/LanguageContext";

const PrivacyPage = () => {
  const { language } = useLanguage();
  const isEnglish = language === "en";

  return (
    <div className="legal">
      <Helmet>
        <title>Privacy Policy | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Review how Tu Progreso Hoy collects, stores, and processes personal data in compliance with Argentine regulations."
        />
      </Helmet>
      <section className="legal__hero">
        <h1>{isEnglish ? "Privacy Policy" : "Política de Privacidad"}</h1>
        <p>
          {isEnglish
            ? "This policy explains how Tu Progreso Hoy collects, uses, and safeguards personal information in accordance with Argentine regulations (Ley 25.326) and GDPR-aligned principles."
            : "Esta política explica cómo Tu Progreso Hoy recolecta, utiliza y resguarda información personal conforme a la normativa argentina (Ley 25.326) y principios alineados al RGPD."}
        </p>
      </section>
      <section className="legal__content">
        <h2>{isEnglish ? "1. Data collection" : "1. Recolección de datos"}</h2>
        <p>
          {isEnglish
            ? "We collect identification data (name, email) through forms, analytics data when consent is granted, and interaction logs for service improvement."
            : "Recolectamos datos identificatorios (nombre, correo) a través de formularios, datos analíticos cuando se otorga consentimiento y registros de interacción para mejorar el servicio."}
        </p>
        <h2>{isEnglish ? "2. Purpose and lawful basis" : "2. Finalidad y base legal"}</h2>
        <p>
          {isEnglish
            ? "Processing supports educational communications, cohort administration, and product analytics. The lawful bases are consent and legitimate interest in improving learning outcomes."
            : "El tratamiento respalda comunicaciones educativas, administración de cohortes y analítica del producto. Las bases legales son el consentimiento y el interés legítimo en mejorar los resultados de aprendizaje."}
        </p>
        <h2>{isEnglish ? "3. Data subject rights" : "3. Derechos de los titulares"}</h2>
        <p>
          {isEnglish
            ? "You may request access, rectification, deletion, or portability at any time by contacting privacidad@tuprogresohoy.ar. We respond within 10 business days."
            : "Podés solicitar acceso, rectificación, supresión o portabilidad en cualquier momento escribiendo a privacidad@tuprogresohoy.ar. Respondemos dentro de los 10 días hábiles."}
        </p>
        <h2>{isEnglish ? "4. International transfers" : "4. Transferencias internacionales"}</h2>
        <p>
          {isEnglish
            ? "Infrastructure providers located outside Argentina comply with standard contractual clauses and maintain ISO 27001 certifications."
            : "Los proveedores de infraestructura ubicados fuera de Argentina cumplen con cláusulas contractuales estándar y cuentan con certificaciones ISO 27001."}
        </p>
        <h2>{isEnglish ? "5. Retention" : "5. Conservación"}</h2>
        <p>
          {isEnglish
            ? "We retain personal data for the duration of the educational relationship and delete inactive accounts after 24 months."
            : "Conservamos los datos personales durante la relación educativa y eliminamos cuentas inactivas luego de 24 meses."}
        </p>
      </section>
    </div>
  );
};

export default PrivacyPage;