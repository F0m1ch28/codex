import React from "react";
import { Helmet } from "react-helmet-async";
import "./LegalPages.css";
import { useLanguage } from "../context/LanguageContext";

const CookiesPage = () => {
  const { language } = useLanguage();
  const isEnglish = language === "en";

  return (
    <div className="legal">
      <Helmet>
        <title>Cookie Policy | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Understand the cookies used by Tu Progreso Hoy and how to manage your preferences."
        />
      </Helmet>
      <section className="legal__hero">
        <h1>{isEnglish ? "Cookie Policy" : "Política de Cookies"}</h1>
        <p>
          {isEnglish
            ? "We use cookies to ensure secure access and improve the learning experience. You may opt in to analytics cookies for aggregated insights."
            : "Utilizamos cookies para asegurar el acceso y mejorar la experiencia de aprendizaje. Podés aceptar cookies analíticas para obtener insights agregados."}
        </p>
      </section>
      <section className="legal__content">
        <h2>{isEnglish ? "Essential cookies" : "Cookies esenciales"}</h2>
        <p>
          {isEnglish
            ? "Authenticate sessions and store language preference. These cookies are required to operate the platform."
            : "Autentican sesiones y almacenan la preferencia de idioma. Son necesarias para operar la plataforma."}
        </p>
        <h2>{isEnglish ? "Analytics cookies" : "Cookies analíticas"}</h2>
        <p>
          {isEnglish
            ? "Optional cookies measure engagement with modules and resources. Data is anonymized and aggregated."
            : "Las cookies opcionales miden la interacción con módulos y recursos. Los datos son anonimizados y agregados."}
        </p>
        <h2>{isEnglish ? "Managing preferences" : "Gestión de preferencias"}</h2>
        <p>
          {isEnglish
            ? "You can accept or decline non-essential cookies via the banner or by emailing privacidad@tuprogresohoy.ar."
            : "Podés aceptar o rechazar cookies no esenciales mediante el banner o escribiendo a privacidad@tuprogresohoy.ar."}
        </p>
      </section>
    </div>
  );
};

export default CookiesPage;