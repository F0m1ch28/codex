import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import "./InflationPage.css";
import { useLanguage } from "../context/LanguageContext";

const faqItems = [
  {
    questionEn: "How frequently is the ARS→USD rate updated?",
    answerEn:
      "We request data every 60 seconds from exchangerate.host. If the service is unavailable, we provide a fallback based on the latest confirmed publication and flag the timestamp.",
    questionEs: "¿Con qué frecuencia se actualiza el tipo de cambio ARS→USD?",
    answerEs:
      "Realizamos solicitudes cada 60 segundos a exchangerate.host. Si el servicio no está disponible, mostramos un valor de respaldo basado en la última publicación confirmada e indicamos la fecha."
  },
  {
    questionEn: "What CPI datasets are considered?",
    answerEn:
      "We combine the official INDEC CPI series with independent research groups when discrepancies exceed two consecutive months. Detailed sourcing is available in the downloadable audit trail.",
    questionEs: "¿Qué series del IPC se consideran?",
    answerEs:
      "Combinamos la serie oficial del IPC del INDEC con grupos de investigación independientes cuando existen discrepancias superiores a dos meses consecutivos. El detalle está disponible en la bitácora descargable."
  },
  {
    questionEn: "Can I download historical data?",
    answerEn:
      "Yes, the resources page includes CSV snapshots updated weekly. Each dataset contains metadata detailing methodology, transformations, and version history.",
    questionEs: "¿Puedo descargar datos históricos?",
    answerEs:
      "Sí, en la sección de recursos encontrarás archivos CSV actualizados semanalmente. Cada conjunto incluye metadatos con metodología, transformaciones e historial de versiones."
  },
  {
    questionEn: "Does Tu Progreso Hoy provide financial advice?",
    answerEn:
      "Tu Progreso Hoy is an educational SaaS. We provide data, frameworks, and learning modules but do not offer individualized financial advice or brokerage services.",
    questionEs: "¿Tu Progreso Hoy brinda asesoramiento financiero?",
    answerEs:
      "Tu Progreso Hoy es una plataforma educativa. Brindamos datos, marcos conceptuales y módulos de aprendizaje, pero no ofrecemos asesoramiento financiero individual ni servicios de intermediación."
  }
];

const InflationPage = () => {
  const { language } = useLanguage();
  const [openIndex, setOpenIndex] = useState(null);
  const isEnglish = language === "en";

  return (
    <div className="inflation">
      <Helmet>
        <title>Inflation Methodology & Framework | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Understand the methodology behind Tu Progreso Hoy's ARS to USD tracker, CPI context, and inflation analytics."
        />
      </Helmet>
      <section className="inflation__hero">
        <div className="inflation__heroInner">
          <h1>{isEnglish ? "Methodology & Transparency" : "Metodología y Transparencia"}</h1>
          <p>
            {isEnglish
              ? "We pursue rigor before conclusions. Our frameworks integrate currency behavior, consumer prices, and mobility indicators to reveal resilient financial habits."
              : "La rigurosidad antecede a las conclusiones. Integramos el comportamiento cambiario, los precios al consumidor y los indicadores de movilidad para revelar hábitos financieros resilientes."}
          </p>
        </div>
      </section>

      <section className="inflation__grid">
        <article>
          <h2>{isEnglish ? "Collection pillars" : "Pilares de recolección"}</h2>
          <ul>
            <li>
              {isEnglish
                ? "Live FX data sourced from exchangerate.host with redundancy through alternative monetary authorities."
                : "Datos FX en vivo de exchangerate.host con redundancia desde autoridades monetarias alternativas."}
            </li>
            <li>
              {isEnglish
                ? "CPI references derived from INDEC monthly releases, homogenized into seasonally adjusted series."
                : "Referencias del IPC derivadas de los informes mensuales del INDEC, homogeneizadas en series desestacionalizadas."}
            </li>
            <li>
              {isEnglish
                ? "Behavioral indicators: retail mobility, energy usage, and housing listings to contextualize inflation sentiment."
                : "Indicadores de comportamiento: movilidad comercial, uso energético y avisos inmobiliarios para contextualizar el sentimiento inflacionario."}
            </li>
          </ul>
        </article>
        <article>
          <h2>{isEnglish ? "Validation layers" : "Capas de validación"}</h2>
          <p>
            {isEnglish
              ? "Before publication, each dataset flows through structured checks—schema integrity, volatility thresholds, and peer review. Deviations beyond 2 standard deviations trigger manual oversight."
              : "Antes de publicarse, cada conjunto pasa por controles estructurados: integridad de esquema, umbrales de volatilidad y revisión por pares. Las desviaciones que superan las 2 desviaciones estándar activan supervisión manual."}
          </p>
          <p>
            {isEnglish
              ? "Weekly retrospectives log adjustments, ensuring learners can trace methodology shifts and replicate calculations."
              : "Los retrospectivos semanales registran ajustes, garantizando que quienes aprenden puedan rastrear cambios metodológicos y replicar cálculos."}
          </p>
        </article>
      </section>

      <section className="inflation__visuals" aria-label="Inflation context charts">
        <figure className="inflation__chart">
          <figcaption>{isEnglish ? "CPI vs FX deviation" : "Desviación IPC vs FX"}</figcaption>
          <div className="inflation__chartBars">
            {[32, 45, 28, 52, 37, 41].map((value, index) => (
              <div key={index} style={{ height: `${value + 20}px` }}>
                <span>{value}%</span>
              </div>
            ))}
          </div>
        </figure>
        <figure className="inflation__chart">
          <figcaption>{isEnglish ? "Monthly peso volatility" : "Volatilidad mensual del peso"}</figcaption>
          <div className="inflation__chartLine">
            <svg viewBox="0 0 300 120" role="img" aria-label="Peso volatility line chart">
              <polyline
                fill="none"
                stroke="rgba(37,99,235,0.7)"
                strokeWidth="4"
                strokeLinecap="round"
                points="10,90 60,70 110,82 160,60 210,76 260,48 290,55"
              />
            </svg>
          </div>
        </figure>
      </section>

      <section className="inflation__faq" aria-labelledby="faq-heading">
        <h2 id="faq-heading">{isEnglish ? "FAQs" : "Preguntas frecuentes"}</h2>
        <div className="inflation__accordion">
          {faqItems.map((item, index) => {
            const open = openIndex === index;
            return (
              <div key={item.questionEn} className={`inflation__item ${open ? "inflation__item--open" : ""}`}>
                <button
                  type="button"
                  onClick={() => setOpenIndex(open ? null : index)}
                  aria-expanded={open}
                  className="inflation__question"
                >
                  <span>{isEnglish ? item.questionEn : item.questionEs}</span>
                  <span aria-hidden="true">{open ? "−" : "+"}</span>
                </button>
                {open && (
                  <div className="inflation__answer">
                    <p>{isEnglish ? item.answerEn : item.answerEs}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};

export default InflationPage;