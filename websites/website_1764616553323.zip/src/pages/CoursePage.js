import React from "react";
import { Helmet } from "react-helmet-async";
import "./CoursePage.css";
import { useLanguage } from "../context/LanguageContext";

const modules = [
  {
    id: 1,
    titleEn: "Foundations: Inflation in everyday life",
    titleEs: "Fundamentos: La inflación en la vida cotidiana",
    descriptionEn: "Decode ARS price movements, salary adjustments, and inflation narratives using a learner-friendly framework.",
    descriptionEs: "Decodificá los movimientos de precios en ARS, los ajustes salariales y los relatos inflacionarios con un marco amigable.",
    outcomes: [
      "Build a personal inflation journal",
      "Interpret official vs. informal rates",
      "Map risk tolerances for essential expenses"
    ]
  },
  {
    id: 2,
    titleEn: "ARS→USD resilience playbook",
    titleEs: "Manual de resiliencia ARS→USD",
    descriptionEn: "Practice scenarios balancing peso obligations and dollar-linked goals through interactive simulations.",
    descriptionEs: "Practica escenarios que equilibran obligaciones en pesos y metas vinculadas al dólar mediante simulaciones interactivas.",
    outcomes: [
      "Prioritize savings paths",
      "Identify signal vs. noise in rate spikes",
      "Design adaptive monthly plans"
    ]
  },
  {
    id: 3,
    titleEn: "Financial systems literacy",
    titleEs: "Alfabetización en sistemas financieros",
    descriptionEn: "Understand Argentine banking instruments, digital wallets, and cross-border options with compliance context.",
    descriptionEs: "Comprendé instrumentos bancarios, billeteras digitales y opciones transfronterizas con contexto regulatorio.",
    outcomes: [
      "Evaluate product fees",
      "Organize documentation checklists",
      "Develop emergency liquidity buffers"
    ]
  },
  {
    id: 4,
    titleEn: "From insights to action",
    titleEs: "De los insights a la acción",
    descriptionEn: "Translate dashboards into weekly routines with accountability templates and community feedback loops.",
    descriptionEs: "Convertí tableros en rutinas semanales con plantillas de seguimiento y retroalimentación comunitaria.",
    outcomes: [
      "Implement a cadence review",
      "Share responsible goals publicly",
      "Leverage peer accountability"
    ]
  }
];

const audiences = [
  {
    titleEn: "Emerging professionals",
    titleEs: "Profesionales emergentes",
    detailEn: "Design a resilient budget amid currency fluctuations.",
    detailEs: "Diseñá un presupuesto resiliente frente a las fluctuaciones cambiarias."
  },
  {
    titleEn: "Startups & SMEs",
    titleEs: "Startups y PyMEs",
    detailEn: "Align finance teams with transparent dashboards and bilingual briefings.",
    detailEs: "Alineá equipos financieros con tableros transparentes y resúmenes bilingües."
  },
  {
    titleEn: "Family planners",
    titleEs: "Planificadores familiares",
    detailEn: "Structure priorities across education, housing, and emergencies with data support.",
    detailEs: "Estructurá prioridades de educación, vivienda y emergencias respaldadas en datos."
  }
];

const CoursePage = () => {
  const { language } = useLanguage();
  const isEnglish = language === "en";

  return (
    <div className="course">
      <Helmet>
        <title>Course Overview | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Explore the Tu Progreso Hoy personal finance starter course with modules designed for Argentina's inflationary context."
        />
      </Helmet>
      <section className="course__hero">
        <div className="course__heroInner">
          <h1>{isEnglish ? "Learning built for volatile markets" : "Aprendizaje diseñado para mercados volátiles"}</h1>
          <p>
            {isEnglish
              ? "Harness blended learning—cohort-based sessions, self-paced practice, and community checkpoints. Every module integrates Argentina's economic realities."
              : "Aprovechá el aprendizaje mixto: sesiones en cohortes, práctica autónoma y checkpoints comunitarios. Cada módulo integra las realidades económicas de Argentina."}
          </p>
          <a href="#modules" className="course__heroCta">
            {isEnglish ? "Jump to modules" : "Ir a los módulos"}
          </a>
        </div>
      </section>

      <section className="course__modules" id="modules">
        {modules.map((module) => (
          <article key={module.id} className="course__moduleCard">
            <div className="course__moduleHeader">
              <span className="course__moduleNumber">0{module.id}</span>
              <h2>{isEnglish ? module.titleEn : module.titleEs}</h2>
            </div>
            <p>{isEnglish ? module.descriptionEn : module.descriptionEs}</p>
            <ul>
              {module.outcomes.map((outcome) => (
                <li key={outcome}>{outcome}</li>
              ))}
            </ul>
          </article>
        ))}
      </section>

      <section className="course__audience">
        <h2>{isEnglish ? "Who benefits most" : "Quiénes aprovechan más"}</h2>
        <div className="course__audienceGrid">
          {audiences.map((item) => (
            <div key={item.titleEn} className="course__audienceCard">
              <h3>{isEnglish ? item.titleEn : item.titleEs}</h3>
              <p>{isEnglish ? item.detailEn : item.detailEs}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="course__cta">
        <div className="course__ctaInner">
          <h2>{isEnglish ? "Ready to explore?" : "¿Listo para explorar?"}</h2>
          <p>
            {isEnglish
              ? "Secure your complimentary lesson at the bottom of our homepage. Complete the form, confirm your email, and unlock a guided preview."
              : "Reservá tu lección de cortesía al pie de nuestra página principal. Completá el formulario, confirmá tu correo y accedé a un adelanto guiado."}
          </p>
          <a href="/#preview-class" className="course__ctaButton">
            {isEnglish ? "Go to form" : "Ir al formulario"}
          </a>
        </div>
      </section>
    </div>
  );
};

export default CoursePage;