import React from "react";
import { Helmet } from "react-helmet-async";
import "./ResourcesPage.css";
import { useLanguage } from "../context/LanguageContext";

const resources = [
  {
    category: "Guide",
    titleEn: "Blueprint: Tracking inflation in Argentina",
    titleEs: "Guía: Cómo rastrear la inflación en Argentina",
    descriptionEn:
      "Step-by-step checklist to interpret CPI announcements, monitor monetary policy, and connect trends with personal decisions.",
    descriptionEs:
      "Checklist paso a paso para interpretar anuncios de IPC, seguir la política monetaria y vincular tendencias con decisiones personales.",
    lang: "EN / ES",
    link: "#"
  },
  {
    category: "Dataset",
    titleEn: "ARS→USD daily CSV",
    titleEs: "CSV diario ARS→USD",
    descriptionEn:
      "Downloadable file with daily close, intraday averages, and volatility bands. Updated every Monday by 10:00 ART.",
    descriptionEs:
      "Archivo descargable con cierre diario, promedios intradiarios y bandas de volatilidad. Actualizado cada lunes a las 10:00 ART.",
    lang: "EN",
    link: "#"
  },
  {
    category: "Glossary",
    titleEn: "Glosario financiero bilingüe",
    titleEs: "Glosario financiero bilingüe",
    descriptionEn:
      "Key terms spanning inflation, savings, and compliance translated across English and Spanish for faster onboarding.",
    descriptionEs:
      "Términos clave sobre inflación, ahorro y cumplimiento traducidos entre inglés y español para una incorporación ágil.",
    lang: "ES",
    link: "#"
  },
  {
    category: "Playbook",
    titleEn: "Responsible budgeting workshop",
    titleEs: "Taller de presupuesto responsable",
    descriptionEn:
      "Scenario-based guide to align ARS cash flow with USD-linked obligations using Tu Progreso Hoy worksheets.",
    descriptionEs:
      "Guía basada en escenarios para alinear flujo en ARS con obligaciones en USD usando las planillas de Tu Progreso Hoy.",
    lang: "EN / ES",
    link: "#"
  }
];

const ResourcesPage = () => {
  const { language } = useLanguage();
  const isEnglish = language === "en";

  return (
    <div className="resources">
      <Helmet>
        <title>Resources & Glossaries | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Access guides, datasets, and glossaries in English and Spanish to understand ARS to USD inflation dynamics."
        />
      </Helmet>
      <section className="resources__hero">
        <div className="resources__heroInner">
          <h1>{isEnglish ? "Resources crafted for bilingual learners" : "Recursos creados para aprendices bilingües"}</h1>
          <p>
            {isEnglish
              ? "Curated articles, datasets, and glossaries keep teams informed while respecting Argentine context."
              : "Artículos, datos y glosarios curados mantienen informados a los equipos respetando el contexto argentino."}
          </p>
        </div>
      </section>
      <section className="resources__grid">
        {resources.map((resource) => (
          <article key={resource.titleEn} className="resources__card">
            <span className="resources__category">{resource.category}</span>
            <h2>{isEnglish ? resource.titleEn : resource.titleEs}</h2>
            <p>{isEnglish ? resource.descriptionEn : resource.descriptionEs}</p>
            <div className="resources__meta">
              <span>{resource.lang}</span>
              <a href={resource.link} aria-label={`${resource.titleEn} download`}>
                {isEnglish ? "Access resource" : "Acceder al recurso"}
              </a>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};

export default ResourcesPage;