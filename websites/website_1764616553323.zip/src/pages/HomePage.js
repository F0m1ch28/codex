import React, { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Helmet } from "react-helmet-async";
import "./HomePage.css";
import { useLanguage } from "../context/LanguageContext";

const HomePage = () => {
  const { t, language } = useLanguage();
  const [exchange, setExchange] = useState(null);
  const [history, setHistory] = useState([]);
  const [loadingRate, setLoadingRate] = useState(true);
  const [formData, setFormData] = useState({ name: "", email: "", consent: false });
  const [formError, setFormError] = useState("");
  const [awaitingConfirm, setAwaitingConfirm] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    let isMounted = true;

    const fetchData = async () => {
      setLoadingRate(true);
      try {
        const response = await fetch("https://api.exchangerate.host/latest?base=ARS&symbols=USD");
        const data = await response.json();
        if (isMounted && data && data.rates) {
          setExchange({
            rate: data.rates.USD,
            date: data.date
          });
          setLoadingRate(false);
        }
      } catch (error) {
        if (isMounted) {
          setExchange({
            rate: 0.0011,
            date: new Date().toISOString().split("T")[0]
          });
          setLoadingRate(false);
        }
      }
    };

    const fetchHistory = async () => {
      try {
        const today = new Date();
        const start = new Date(today);
        start.setDate(start.getDate() - 6);
        const format = (d) => d.toISOString().split("T")[0];
        const response = await fetch(
          `https://api.exchangerate.host/timeseries?base=ARS&symbols=USD&start_date=${format(start)}&end_date=${format(today)}`
        );
        const data = await response.json();
        if (isMounted && data && data.rates) {
          const points = Object.keys(data.rates)
            .sort()
            .map((date) => ({
              date,
              value: data.rates[date].USD
            }));
          setHistory(points);
        }
      } catch (error) {
        if (isMounted) {
          setHistory([
            { date: "Day -6", value: 0.0011 },
            { date: "Day -5", value: 0.00112 },
            { date: "Day -4", value: 0.00109 },
            { date: "Day -3", value: 0.00115 },
            { date: "Day -2", value: 0.00113 },
            { date: "Day -1", value: 0.00117 },
            { date: "Day 0", value: 0.00116 }
          ]);
        }
      }
    };

    fetchData();
    fetchHistory();
    const interval = setInterval(fetchData, 60000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const chartMax = useMemo(() => {
    if (!history.length) return 0.0015;
    return Math.max(...history.map((item) => item.value));
  }, [history]);

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name || !formData.email.includes("@") || !formData.consent) {
      setFormError(t.form.error);
      return;
    }
    setFormError("");
    setAwaitingConfirm(true);
  };

  const handleConfirm = () => {
    navigate("/thank-you", { replace: true, state: { email: formData.email } });
  };

  return (
    <div className="home">
      <Helmet>
        <html lang={language === "en" ? "en" : "es"} />
        <link rel="alternate" hrefLang="en" href="https://tu-progreso-hoy.netlify.app/" />
        <link rel="alternate" hrefLang="es-AR" href="https://tu-progreso-hoy.netlify.app/es" />
        <title>Tu Progreso Hoy | Inflation insights & financial learning</title>
        <meta
          name="description"
          content="Educational platform providing ARS to USD insights, CPI context, and personal finance fundamentals for Argentina."
        />
      </Helmet>
      <section className="home__hero">
        <div className="home__heroContent">
          <motion.h1 initial={{ y: 12, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.6 }}>
            {t.hero.title}
          </motion.h1>
          <motion.p initial={{ y: 16, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.7 }}>
            {t.hero.subtitle}
          </motion.p>
          <div className="home__heroActions">
            <Link to="/inflation" className="home__btn home__btn--primary">
              {t.hero.ctaPrimary}
            </Link>
            <Link to="/course" className="home__btn home__btn--secondary">
              {t.hero.ctaSecondary}
            </Link>
          </div>
          <div className="home__chips" aria-label="Core value statements">
            {t.hero.chips.map((chip) => (
              <span key={chip}>{chip}</span>
            ))}
          </div>
        </div>
        <div className="home__heroVisual" role="presentation">
          <div className="home__flagOverlay" />
          <img src="https://images.pexels.com/photos/6878115/pexels-photo-6878115.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Modern financial dashboard visualization" />
        </div>
      </section>

      <section className="home__tracker" aria-labelledby="tracker-heading">
        <div className="home__sectionHeader">
          <h2 id="tracker-heading">{t.tracker.title}</h2>
          <p>{t.tracker.description}</p>
        </div>
        <div className="home__trackerCard">
          <div className="home__trackerTop">
            <div>
              <span className="home__trackerLabel">ARS → USD</span>
              <h3>{loadingRate || !exchange ? "..." : exchange.rate.toFixed(6)}</h3>
            </div>
            <div className="home__trackerMeta">
              <span>
                {t.tracker.lastUpdated}: {exchange ? exchange.date : "—"}
              </span>
              <span className="home__trackerStatus">{loadingRate ? t.tracker.fetching : "Live"}</span>
            </div>
          </div>
          <div className="home__chart" role="img" aria-label="Seven-day ARS to USD trend">
            {history.map((point) => (
              <div key={point.date} className="home__chartBar" style={{ height: `${(point.value / chartMax) * 100}%` }}>
                <span>{point.value.toFixed(4)}</span>
                <small>{point.date}</small>
              </div>
            ))}
          </div>
          <p className="home__trackerSource">{t.tracker.source}</p>
          <p className="home__trackerDisclaimer">{t.tracker.disclaimer}</p>
        </div>
      </section>

      <section className="home__insights">
        <div className="home__sectionHeader">
          <h2>{t.insights.title}</h2>
        </div>
        <div className="home__cards">
          {t.insights.cards.map((card) => (
            <motion.article
              key={card.title}
              className="home__card"
              whileHover={{ y: -6 }}
              transition={{ duration: 0.3 }}
            >
              <h3>{card.title}</h3>
              <p>{card.body}</p>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="home__course">
        <div className="home__courseContent">
          <h2>{t.course.title}</h2>
          <p>{t.course.description}</p>
          <ul>
            {t.course.bullets.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <Link to="/course" className="home__btn home__btn--primary">
            {t.course.cta}
          </Link>
        </div>
        <div className="home__courseVisual">
          <img src="https://images.pexels.com/photos/6802042/pexels-photo-6802042.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Instructor explaining finance concepts" />
        </div>
      </section>

      <section className="home__testimonials" aria-labelledby="testimonials-heading">
        <div className="home__sectionHeader">
          <h2 id="testimonials-heading">{t.testimonials.title}</h2>
        </div>
        <div className="home__testimonialGrid">
          {t.testimonials.items.map((item) => (
            <blockquote key={item.name}>
              <p>“{item.quote}”</p>
              <footer>— {item.name}</footer>
            </blockquote>
          ))}
        </div>
      </section>

      <section className="home__formSection" id="preview-class">
        <div className="home__formCard">
          <h2>{t.form.title}</h2>
          <p>{t.form.description}</p>
          {!awaitingConfirm ? (
            <form onSubmit={handleSubmit} className="home__form">
              <label htmlFor="name">{t.form.nameLabel}</label>
              <input
                id="name"
                name="name"
                type="text"
                placeholder="Alicia Fernández"
                value={formData.name}
                onChange={(event) => setFormData((prev) => ({ ...prev, name: event.target.value }))}
                required
              />
              <label htmlFor="email">{t.form.emailLabel}</label>
              <input
                id="email"
                name="email"
                type="email"
                placeholder="a.fernandez@example.com"
                value={formData.email}
                onChange={(event) => setFormData((prev) => ({ ...prev, email: event.target.value }))}
                required
              />
              <div className="home__consent">
                <input
                  id="consent"
                  type="checkbox"
                  checked={formData.consent}
                  onChange={(event) => setFormData((prev) => ({ ...prev, consent: event.target.checked }))}
                />
                <label htmlFor="consent">{t.form.consentLabel}</label>
              </div>
              {formError && <p className="home__error" role="alert">{formError}</p>}
              <button type="submit" className="home__submitBtn">
                {t.form.button}
              </button>
            </form>
          ) : (
            <div className="home__confirm">
              <h3>{t.form.confirmTitle}</h3>
              <p>{t.form.confirmDescription}</p>
              <button type="button" onClick={handleConfirm} className="home__btn home__btn--primary">
                {t.form.confirmButton}
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default HomePage;