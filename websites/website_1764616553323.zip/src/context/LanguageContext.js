import React, { createContext, useContext, useMemo, useState } from "react";

const LanguageContext = createContext();

const translations = {
  en: {
    nav: {
      home: "Home",
      inflation: "Inflation",
      course: "Course",
      resources: "Resources",
      contact: "Contact"
    },
    hero: {
      title: "Navigate Argentina's inflation with clarity",
      subtitle:
        "Tu Progreso Hoy connects the evolution of the Argentine peso with actionable learning so you can plan responsibly.",
      ctaPrimary: "Explore insights",
      ctaSecondary: "View course",
      chips: [
        "Datos verificados para planificar tu presupuesto.",
        "Decisiones responsables, objetivos nítidos.",
        "Conocimiento financiero impulsado por tendencias."
      ]
    },
    tracker: {
      title: "ARS → USD tracker",
      description:
        "Monitor the daily exchange rate between Argentine pesos and U.S. dollars alongside historical CPI context.",
      lastUpdated: "Last updated",
      fetching: "Updating live data...",
      source: "Source: exchangerate.host and INDEC aggregated datasets",
      disclaimer:
        "Exchange values are provided for educational purposes only. They do not represent trading advice."
    },
    insights: {
      title: "Why Tu Progreso Hoy",
      cards: [
        {
          title: "Data-first clarity",
          body: "Análisis transparentes y datos de mercado para decidir con seguridad."
        },
        {
          title: "Responsible path",
          body: "Información confiable que respalda elecciones responsables sobre tu dinero."
        },
        {
          title: "Future-ready toolkit",
          body: "Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera."
        }
      ]
    },
    course: {
      title: "Personal Finance Starter Course",
      description:
        "Платформа educativa con datos esenciales, sin asesoría financiera directa. Move from information to sustained learning with modular lessons, coached simulations, and curated templates.",
      bullets: [
        "Pasos acertados hoy, mejor futuro mañana.",
        "De la información al aprendizaje: fortalece tu criterio financiero paso a paso."
      ],
      cta: "Discover modules"
    },
    testimonials: {
      title: "Community reflections",
      items: [
        {
          quote:
            "The weekly inflation briefs help me understand currency shifts without being overwhelmed.",
          name: "María C."
        },
        {
          quote:
            "Practical lessons and bilingual summaries keep our team aligned on budget planning.",
          name: "Santiago R."
        },
        {
          quote:
            "I appreciate the transparent methodology and the focus on responsible decision-making.",
          name: "Lucía P."
        }
      ]
    },
    form: {
      title: "Secure your preview class",
      description:
        "Access the guided onboarding with a complimentary lesson after confirming your email through our double opt-in process.",
      button: "Получить бесплатный пробный урок",
      emailLabel: "Work email",
      nameLabel: "Full name",
      consentLabel:
        "I agree to receive educational emails and understand I can opt out anytime.",
      confirmTitle: "Confirm your subscription",
      confirmDescription:
        "We just sent a confirmation email. Please click the link in your inbox and then confirm below to access your free lesson.",
      confirmButton: "I have confirmed my email",
      error: "Please provide your name, a valid email, and consent."
    },
    footer: {
      addressTitle: "Visit us",
      contactTitle: "Talk to us",
      phoneLabel: "Phone",
      emailLabel: "Email",
      emailValue: "hola@tuprogresohoy.ar",
      disclaimerTitle: "Disclaimers",
      disclaimerText:
        "Мы не предоставляем финансовые услуги · We do not provide financial services · No brindamos servicios financieros",
      policy: "Privacy Policy",
      cookies: "Cookies",
      terms: "Terms of Service",
      rights: "© " + new Date().getFullYear() + " Tu Progreso Hoy. All rights reserved."
    }
  },
  es: {
    nav: {
      home: "Inicio",
      inflation: "Inflación",
      course: "Curso",
      resources: "Recursos",
      contact: "Contacto"
    },
    hero: {
      title: "Gestioná la inflación argentina con claridad",
      subtitle:
        "Tu Progreso Hoy conecta la evolución del peso argentino con aprendizaje accionable para que planifiques con responsabilidad.",
      ctaPrimary: "Explorar indicadores",
      ctaSecondary: "Ver curso",
      chips: [
        "Datos verificados para planificar tu presupuesto.",
        "Decisiones responsables, objetivos nítidos.",
        "Conocimiento financiero impulsado por tendencias."
      ]
    },
    tracker: {
      title: "Monitor ARS → USD",
      description:
        "Controlá el tipo de cambio diario entre pesos argentinos y dólares estadounidenses con contexto histórico del IPC.",
      lastUpdated: "Última actualización",
      fetching: "Actualizando datos en vivo...",
      source: "Fuente: exchangerate.host e INDEC (datos agregados)",
      disclaimer:
        "Los valores se proveen con fines educativos y no constituyen asesoramiento de inversión."
    },
    insights: {
      title: "Por qué elegir Tu Progreso Hoy",
      cards: [
        {
          title: "Claridad basada en datos",
          body: "Análisis transparentes y datos de mercado para decidir con seguridad."
        },
        {
          title: "Ruta responsable",
          body: "Información confiable que respalda elecciones responsables sobre tu dinero."
        },
        {
          title: "Herramientas para el futuro",
          body: "Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera."
        }
      ]
    },
    course: {
      title: "Curso Inicial de Finanzas Personales",
      description:
        "Платформа educativa con datos esenciales, sin asesoría financiera directa. Pasá de la información a un aprendizaje sostenido con lecciones modulares, simulaciones guiadas y plantillas curadas.",
      bullets: [
        "Pasos acertados hoy, mejor futuro mañana.",
        "De la información al aprendizaje: fortalece tu criterio financiero paso a paso."
      ],
      cta: "Descubrir módulos"
    },
    testimonials: {
      title: "Testimonios",
      items: [
        {
          quote:
            "Los reportes semanales de inflación me permiten entender los movimientos del peso sin abrumarme.",
          name: "María C."
        },
        {
          quote:
            "Lecciones prácticas y resúmenes bilingües mantienen a nuestro equipo alineado en la planificación.",
          name: "Santiago R."
        },
        {
          quote:
            "Valoro la metodología transparente y el foco en decisiones responsables.",
          name: "Lucía P."
        }
      ]
    },
    form: {
      title: "Accedé a una clase de prueba",
      description:
        "Ingresá a la experiencia guiada con una lección de cortesía después de confirmar tu correo mediante nuestro doble opt-in.",
      button: "Получить бесплатный пробный урок",
      emailLabel: "Correo laboral",
      nameLabel: "Nombre completo",
      consentLabel:
        "Acepto recibir correos educativos y entiendo que puedo cancelar la suscripción en cualquier momento.",
      confirmTitle: "Confirmá tu suscripción",
      confirmDescription:
        "Te enviamos un correo de confirmación. Hacé clic en el enlace de tu bandeja de entrada y luego confirmá debajo para acceder a la clase gratuita.",
      confirmButton: "Ya confirmé mi correo",
      error: "Por favor completá nombre, un correo válido y el consentimiento."
    },
    footer: {
      addressTitle: "Visítanos",
      contactTitle: "Conversemos",
      phoneLabel: "Teléfono",
      emailLabel: "Correo",
      emailValue: "hola@tuprogresohoy.ar",
      disclaimerTitle: "Avisos",
      disclaimerText:
        "Мы не предоставляем финансовые услуги · We do not provide financial services · No brindamos servicios financieros",
      policy: "Política de Privacidad",
      cookies: "Cookies",
      terms: "Términos de Servicio",
      rights: "© " + new Date().getFullYear() + " Tu Progreso Hoy. Todos los derechos reservados."
    }
  }
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState("en");

  const value = useMemo(
    () => ({
      language,
      setLanguage,
      t: translations[language]
    }),
    [language]
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

export const useLanguage = () => useContext(LanguageContext);