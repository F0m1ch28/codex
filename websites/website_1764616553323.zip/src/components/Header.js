import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { useLanguage } from "../context/LanguageContext";
import "./Header.css";

const Header = () => {
  const { t, language, setLanguage } = useLanguage();
  const location = useLocation();
  const [open, setOpen] = useState(false);

  const navItems = [
    { path: "/", label: t.nav.home },
    { path: "/inflation", label: t.nav.inflation },
    { path: "/course", label: t.nav.course },
    { path: "/resources", label: t.nav.resources },
    { path: "/contact", label: t.nav.contact }
  ];

  return (
    <header className="header">
      <div className="header__inner">
        <Link to="/" className="header__logo" aria-label="Tu Progreso Hoy">
          <motion.div
            className="header__logoMark"
            initial={{ rotate: -8, scale: 0.8 }}
            animate={{ rotate: 0, scale: 1 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            TPH
          </motion.div>
          <span className="header__logoText">Tu Progreso Hoy</span>
        </Link>
        <nav className={`header__nav ${open ? "header__nav--open" : ""}`} aria-label="Main navigation">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`header__link ${location.pathname === item.path ? "header__link--active" : ""}`}
              onClick={() => setOpen(false)}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="header__actions">
          <div className="header__langToggle" role="group" aria-label="Language selector">
            <button
              type="button"
              className={`header__langBtn ${language === "en" ? "header__langBtn--active" : ""}`}
              onClick={() => setLanguage("en")}
            >
              EN
            </button>
            <button
              type="button"
              className={`header__langBtn ${language === "es" ? "header__langBtn--active" : ""}`}
              onClick={() => setLanguage("es")}
            >
              ES
            </button>
          </div>
          <button
            className="header__burger"
            onClick={() => setOpen((prev) => !prev)}
            aria-label="Toggle navigation"
            aria-expanded={open}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;