import React, { useEffect, useState } from "react";
import "./CookieBanner.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const [preference, setPreference] = useState("");

  useEffect(() => {
    const storedPreference = window.localStorage.getItem("cookiePreference");
    if (!storedPreference) {
      setVisible(true);
    } else {
      setPreference(storedPreference);
    }
  }, []);

  const handleChoice = (choice) => {
    window.localStorage.setItem("cookiePreference", choice);
    setPreference(choice);
    setVisible(false);
  };

  if (!visible || preference) {
    return null;
  }

  return (
    <div className="cookieBanner" role="dialog" aria-labelledby="cookie-title" aria-live="assertive">
      <div>
        <h3 id="cookie-title">Cookies & analytics</h3>
        <p>
          We use functional cookies to improve your browsing experience. Accept analytics to help us measure learning outcomes.
        </p>
        <div className="cookieBanner__actions">
          <button type="button" onClick={() => handleChoice("declined")} className="cookieBanner__btn cookieBanner__btn--secondary">
            Decline
          </button>
          <button type="button" onClick={() => handleChoice("accepted")} className="cookieBanner__btn">
            Accept
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;