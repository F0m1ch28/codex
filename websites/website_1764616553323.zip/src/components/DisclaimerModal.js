import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import "./DisclaimerModal.css";

const DisclaimerModal = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const seen = window.sessionStorage.getItem("financialDisclaimerSeen");
    if (!seen) {
      setShow(true);
    }
  }, []);

  const handleClose = () => {
    window.sessionStorage.setItem("financialDisclaimerSeen", "true");
    setShow(false);
  };

  return (
    <AnimatePresence>
      {show && (
        <div className="disclaimerModal" role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
          <motion.div
            className="disclaimerModal__content"
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ duration: 0.3 }}
          >
            <h2 id="disclaimer-title">Important notice</h2>
            <p>Мы не предоставляем финансовые услуги.</p>
            <p>We do not provide financial services.</p>
            <p>No brindamos servicios financieros.</p>
            <button type="button" onClick={handleClose} className="disclaimerModal__btn">
              Understood
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default DisclaimerModal;