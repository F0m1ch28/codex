import React from "react";
import { Link } from "react-router-dom";
import "./Footer.css";
import { useLanguage } from "../context/LanguageContext";

const Footer = () => {
  const { t } = useLanguage();

  return (
    <footer className="footer">
      <div className="footer__inner">
        <div>
          <h4 className="footer__title">Tu Progreso Hoy</h4>
          <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
          <p>{t.footer.phoneLabel}: +54 11 5555-1234</p>
          <p>
            {t.footer.emailLabel}: <a href="mailto:hola@tuprogresohoy.ar">{t.footer.emailValue}</a>
          </p>
        </div>
        <div>
          <h4 className="footer__title">{t.footer.addressTitle}</h4>
          <p>Argentina · Remote-ready · Bilingual support</p>
          <p>{t.footer.contactTitle}: +54 11 5555-1234</p>
        </div>
        <div>
          <h4 className="footer__title">{t.footer.disclaimerTitle}</h4>
          <p className="footer__disclaimer">{t.footer.disclaimerText}</p>
          <nav className="footer__links" aria-label="Legal">
            <Link to="/privacy">{t.footer.policy}</Link>
            <Link to="/cookies">{t.footer.cookies}</Link>
            <Link to="/terms">{t.footer.terms}</Link>
          </nav>
        </div>
      </div>
      <div className="footer__bottom">
        <small>{t.footer.rights}</small>
      </div>
    </footer>
  );
};

export default Footer;