document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navToggle.classList.toggle("is-active");
            siteNav.classList.toggle("nav-open");
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const storedConsent = localStorage.getItem("gcqg-cookie-consent");

    if (cookieBanner) {
        if (storedConsent) {
            cookieBanner.classList.add("hidden");
            cookieBanner.setAttribute("aria-hidden", "true");
        }

        cookieBanner.querySelectorAll(".cookie-choice").forEach((choice) => {
            choice.addEventListener("click", (event) => {
                event.preventDefault();
                const consentValue = choice.dataset.choice || "accepted";
                localStorage.setItem("gcqg-cookie-consent", consentValue);
                cookieBanner.classList.add("hidden");
                cookieBanner.setAttribute("aria-hidden", "true");
            });
        });
    }

    const filterButtons = document.querySelectorAll(".filter-btn[data-filter]");
    const destinationCards = document.querySelectorAll(".destination-card");

    if (filterButtons.length && destinationCards.length) {
        filterButtons.forEach((button) => {
            button.addEventListener("click", () => {
                const filter = button.dataset.filter;
                filterButtons.forEach((btn) => btn.classList.remove("is-active"));
                button.classList.add("is-active");

                destinationCards.forEach((card) => {
                    const region = card.dataset.region;
                    if (filter === "all" || region === filter) {
                        card.classList.remove("is-hidden");
                    } else {
                        card.classList.add("is-hidden");
                    }
                });
            });
        });
    }

    document.querySelectorAll(".story-carousel").forEach((carousel) => {
        const slides = carousel.querySelectorAll(".story-slide");
        if (!slides.length) {
            return;
        }
        let currentIndex = 0;
        slides[currentIndex].classList.add("is-active");

        const updateSlide = (newIndex) => {
            slides[currentIndex].classList.remove("is-active");
            slides[newIndex].classList.add("is-active");
            currentIndex = newIndex;
        };

        const prevButton = carousel.querySelector(".carousel-prev");
        const nextButton = carousel.querySelector(".carousel-next");

        if (prevButton) {
            prevButton.addEventListener("click", () => {
                const newIndex = (currentIndex - 1 + slides.length) % slides.length;
                updateSlide(newIndex);
            });
        }

        if (nextButton) {
            nextButton.addEventListener("click", () => {
                const newIndex = (currentIndex + 1) % slides.length;
                updateSlide(newIndex);
            });
        }
    });

    const commentButton = document.getElementById("postComment");
    if (commentButton) {
        commentButton.addEventListener("click", () => {
            const commentList = document.querySelector(".community-comments");
            const commentField = document.getElementById("memberComment");
            const nameField = document.getElementById("commentName");

            if (!commentList || !commentField) {
                return;
            }

            const message = commentField.value.trim();
            if (!message) {
                return;
            }

            const author = nameField && nameField.value.trim() ? nameField.value.trim() : "Explorer";
            const newComment = document.createElement("article");
            newComment.className = "comment-card";
            newComment.innerHTML = `<h4>${author}</h4><p>${message}</p><span class="comment-meta">Shared just now</span>`;
            commentList.prepend(newComment);

            commentField.value = "";
            if (nameField) {
                nameField.value = "";
            }
        });
    }
});