document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      siteNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', siteNav.classList.contains('open'));
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');
  const consentKey = 'canelytixConsent';

  if (!localStorage.getItem(consentKey) && cookieBanner) {
    cookieBanner.classList.add('show');
  }

  const handleConsent = (value) => {
    if (cookieBanner) {
      cookieBanner.classList.remove('show');
    }
    localStorage.setItem(consentKey, value);
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => handleConsent('accepted'));
  }
  if (declineBtn) {
    declineBtn.addEventListener('click', () => handleConsent('declined'));
  }

  const redirects = {
    '/history': '/briefs.html',
    '/history/': '/briefs.html',
    '/infrastructure': '/frameworks.html',
    '/infrastructure/': '/frameworks.html',
    '/systems': '/indicators.html',
    '/systems/': '/indicators.html',
    '/resilience': '/interpretation.html',
    '/resilience/': '/interpretation.html'
  };

  const path = window.location.pathname;
  if (redirects[path]) {
    window.location.replace(redirects[path]);
  }
});