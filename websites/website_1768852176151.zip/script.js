document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.getElementById('primary-menu');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function () {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navLinks.classList.toggle('is-open');
        });

        navLinks.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                navToggle.setAttribute('aria-expanded', 'false');
                navLinks.classList.remove('is-open');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const consentStatus = localStorage.getItem('gfcCookieConsent');
        if (!consentStatus) {
            requestAnimationFrame(function () {
                cookieBanner.classList.add('is-visible');
            });
        }

        cookieBanner.querySelectorAll('[data-cookie-action]').forEach(function (button) {
            button.addEventListener('click', function () {
                const action = button.getAttribute('data-cookie-action');
                if (action === 'accept') {
                    localStorage.setItem('gfcCookieConsent', 'accepted');
                } else if (action === 'decline') {
                    localStorage.setItem('gfcCookieConsent', 'declined');
                }
                cookieBanner.classList.remove('is-visible');
            });
        });
    }
});