document.addEventListener('DOMContentLoaded', () => {
  const htmlElement = document.documentElement;
  htmlElement.classList.remove('no-js');

  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');
  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = primaryNav.classList.toggle('nav-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  document.querySelectorAll('.fade-in').forEach(element => observer.observe(element));

  const banner = document.getElementById('cookieBanner');
  const acceptBtn = document.getElementById('cookieAccept');
  const declineBtn = document.getElementById('cookieDecline');
  const storageKey = 'uvb_cookie_choice';

  if (banner && acceptBtn && declineBtn) {
    const storedChoice = localStorage.getItem(storageKey);
    if (!storedChoice) {
      setTimeout(() => banner.classList.add('active'), 800);
    }

    const handleChoice = choice => {
      localStorage.setItem(storageKey, choice);
      banner.classList.remove('active');
    };

    acceptBtn.addEventListener('click', () => handleChoice('accepted'));
    declineBtn.addEventListener('click', () => handleChoice('declined'));
  }

  const toast = document.getElementById('formToast');
  const toastMessage = document.getElementById('toastMessage');
  const forms = document.querySelectorAll('form.js-form');

  const showToast = message => {
    if (!toast || !toastMessage) return;
    toastMessage.textContent = message;
    toast.classList.add('active');
    setTimeout(() => toast.classList.remove('active'), 2200);
  };

  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const message = form.dataset.toastMessage || 'Mesajul a fost trimis. Redirecționăm...';
      showToast(message);
      setTimeout(() => {
        window.location.href = form.getAttribute('action') || 'thank-you.html';
      }, 1400);
    });
  });

  const yearHolder = document.getElementById('currentYear');
  if (yearHolder) {
    yearHolder.textContent = new Date().getFullYear();
  }
});