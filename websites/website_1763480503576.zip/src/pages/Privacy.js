import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

function Privacy() {
  return (
    <>
      <Helmet>
        <title>Datenschutzerklärung | Valeronica</title>
        <meta
          name="description"
          content="Datenschutzhinweise der Valeronica GmbH. Wir schützen Deine Daten und nutzen sie ausschließlich zur Bearbeitung Deiner Anfrage."
        />
      </Helmet>
      <section className={styles.page}>
        <div className="container">
          <h1>Datenschutzerklärung</h1>
          <p className={styles.updated}>Stand: März 2024</p>

          <h2>1. Verantwortliche Stelle</h2>
          <p>Valeronica GmbH, Musterstraße 45, 10115 Berlin, E-Mail: hallo@valeronica.de, Telefon: +49 151 23456789.</p>

          <h2>2. Erhebung und Nutzung personenbezogener Daten</h2>
          <p>
            Wir verarbeiten personenbezogene Daten ausschließlich zur Kontaktaufnahme, Vertragsdurchführung oder zur Bereitstellung unserer
            Angebote. Eine Weitergabe erfolgt nur, wenn hierfür eine gesetzliche Grundlage besteht.
          </p>

          <h2>3. Rechtsgrundlagen</h2>
          <p>
            Die Verarbeitung erfolgt auf Basis von Art. 6 Abs. 1 lit. b DSGVO (Vertragsanbahnung/-durchführung) sowie Art. 6 Abs. 1 lit. f
            DSGVO (berechtigtes Interesse an einer effizienten Kommunikation).
          </p>

          <h2>4. Speicherdauer</h2>
          <p>
            Daten werden nur so lange gespeichert, wie es für den jeweiligen Zweck erforderlich ist oder gesetzliche Aufbewahrungspflichten
            bestehen.
          </p>

          <h2>5. Deine Rechte</h2>
          <p>
            Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung und Datenübertragbarkeit. Du kannst eine
            erteilte Einwilligung jederzeit widerrufen.
          </p>

          <h2>6. Cookies</h2>
          <p>
            Wir nutzen ausschließlich technisch notwendige Cookies und anonyme Reichweitenmessung. Du kannst Cookies in Deinem Browser
            deaktivieren. Die Funktionalität unserer Website bleibt weitgehend erhalten.
          </p>

          <h2>7. Sicherheit</h2>
          <p>
            Wir setzen technische und organisatorische Maßnahmen ein, um Daten vor Verlust oder unbefugtem Zugriff zu schützen. Unsere
            Systeme werden regelmäßig überprüft.
          </p>

          <h2>8. Kontakt Datenschutz</h2>
          <p>
            Bei Fragen zum Datenschutz erreichst Du uns unter hallo@valeronica.de. Du hast zudem das Recht, Dich bei einer Aufsichtsbehörde
            zu beschweren.
          </p>
        </div>
      </section>
    </>
  );
}

export default Privacy;