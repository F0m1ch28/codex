import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Guide.module.css';
import { Link } from 'react-router-dom';

const steps = [
  {
    title: '1. Standort-Check & Erwartungen',
    bullets: [
      'Was ist Dir aktuell am wichtigsten? Was darf warten?',
      'Welche Rahmenbedingungen (Budget, Zeit, Kontakte) sind vorhanden?',
      'Welche Erwartungen sind realistisch? Welche dürfen angepasst werden?'
    ]
  },
  {
    title: '2. Organisieren & Priorisieren',
    bullets: [
      'To-dos clustern: Papierkram, Wohnen, Sprache, Community.',
      'Prioritätenmatrix: Dringend vs. wichtig klären.',
      'Zeitfenster blocken und Mikro-Schritte formulieren.'
    ]
  },
  {
    title: '3. Kontakte & Community',
    bullets: [
      'Warm-up-Fragen vorbereiten statt Smalltalk-Druck.',
      'Orte und Formate auswählen, die zu Dir passen.',
      'Nachbereitung einplanen: Was hat gut getan, was nicht?'
    ]
  },
  {
    title: '4. Eigene Routinen aufbauen',
    bullets: [
      'Mini-Rituale für morgens, abends und Übergänge.',
      'Regelmäßiger Energie-Check: Was gibt Kraft, was nimmt sie?',
      'Reflexion: Fortschritte sichtbar machen und feiern.'
    ]
  }
];

function Guide() {
  return (
    <>
      <Helmet>
        <title>Valeronica Leitfaden | Schritt für Schritt ankommen</title>
        <meta
          name="description"
          content="Ein klarer Leitfaden für Deinen Neustart: Erwartungen sortieren, Prioritäten setzen, Community aufbauen und Routinen festigen."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Dein Leitfaden fürs Ankommen</h1>
          <p>
            Vier Schritte, die Dir Ruhe, Struktur und den richtigen Fokus geben. Nimm Dir, was zu Dir passt – und passe den
            Leitfaden laufend an Dein Leben an.
          </p>
        </div>
      </section>

      <section className={styles.steps}>
        <div className="container">
          <div className={styles.stepGrid}>
            {steps.map((step) => (
              <article key={step.title} className={styles.stepCard}>
                <h2>{step.title}</h2>
                <ul>
                  {step.bullets.map((bullet) => (
                    <li key={bullet}>{bullet}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
          <div className={styles.cta}>
            <Link to="/programs" className="buttonPrimary">
              Nächsten Schritt ansehen
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

export default Guide;