import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programs.module.css';

const programs = [
  {
    title: '14-Tage-Ankommens-Plan',
    description:
      'Tägliche Mikro-Impulse, strukturierte Reflexion und sanfte Routinen, um Dein neues Zuhause mental und organisatorisch aufzubauen.',
    duration: '14 Tage',
    focus: 'Routinen, Emotionale Stabilität, Klarheit',
    audience: 'Neuankömmlinge, die erste Wochen strukturieren möchten'
  },
  {
    title: 'Kontakte-knüpfen-Challenge',
    description:
      'Warm-up-Fragen, Check-ins, Community-Impulse und Event-Matching für authentische Verbindungen – ohne Smalltalk-Zwang.',
    duration: '10 Tage',
    focus: 'Community, Netzwerkaufbau, Selbstvertrauen',
    audience: 'Menschen, die neue Beziehungen aufbauen möchten'
  },
  {
    title: 'Bürokratie-Stress reduzieren',
    description:
      'Prioritätenmatrix, Termin-Breakdowns, Dokumenten-Checklisten und Energie-Management für Verwaltungsprozesse.',
    duration: '21 Tage',
    focus: 'Organisation, Priorisierung, Selbstwirksamkeit',
    audience: 'Neuankömmlinge mit Behörden- und Dokumentenfokus'
  }
];

function Programs() {
  return (
    <>
      <Helmet>
        <title>Programme & Challenges | Valeronica</title>
        <meta
          name="description"
          content="Entdecke die Programme von Valeronica: Strukturiert, empathisch und alltagstauglich für Deinen Umzug ins neue Land."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Programme & Challenges</h1>
          <p>
            Wähle das Format, das zu Deiner Situation passt. Jedes Programm ist flexibel anpassbar und kommt mit klaren Materialien,
            Check-ins und Reflexionen.
          </p>
        </div>
      </section>

      <section className={styles.programs}>
        <div className="container">
          <div className={styles.programGrid}>
            {programs.map((program) => (
              <article key={program.title} className={styles.programCard}>
                <h2>{program.title}</h2>
                <p>{program.description}</p>
                <ul>
                  <li><strong>Dauer:</strong> {program.duration}</li>
                  <li><strong>Fokus:</strong> {program.focus}</li>
                  <li><strong>Für wen:</strong> {program.audience}</li>
                </ul>
                <button type="button" className="buttonSecondary">
                  Programm starten
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Programs;