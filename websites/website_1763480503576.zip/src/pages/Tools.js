import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const tools = [
  {
    title: 'Umzugs-Checkliste neues Land',
    description: 'Chronologisch sortiert, mit Zeitpuffern und Links zu seriösen Informationsquellen.',
    features: ['Vorbereitung, Ankunft, Follow-up', 'Individuelle Prioritäten-Notizen', 'Check-in-Reminder']
  },
  {
    title: 'Wochenplan: Behörden & Lernen',
    description: 'Strukturierter Mix aus Behördenterminen, Lernzeiten und bewussten Ruhefenstern.',
    features: ['Kalender-Template', 'Energie-Level-Tracker', 'Reflexionsfragen für die Woche']
  },
  {
    title: 'Netzwerk-Impulse',
    description: 'Verbindungsreiche Fragen, Event-Ideen und Follow-up-Vorlagen für neue Kontakte.',
    features: ['Warm-up-Fragen', 'Erstes Gespräch Struktur', 'Nachbereitung & Learnings']
  }
];

function Tools() {
  return (
    <>
      <Helmet>
        <title>Tools & Checklisten | Valeronica</title>
        <meta
          name="description"
          content="Digitale Tools und Checklisten von Valeronica: Pragmatische Begleiter für Deinen Umzug und Dein Ankommen."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Tools & Checklisten</h1>
          <p>
            Alltagstaugliche Begleiter, die Du sofort nutzen kannst. Minimalistisch, fokussiert und so gestaltet, dass sie Dich
            nicht zusätzlich überfordern.
          </p>
        </div>
      </section>

      <section className={styles.tools}>
        <div className="container">
          <div className={styles.toolGrid}>
            {tools.map((tool) => (
              <article key={tool.title} className={styles.toolCard}>
                <h2>{tool.title}</h2>
                <p>{tool.description}</p>
                <ul>
                  {tool.features.map((feature) => (
                    <li key={feature}>{feature}</li>
                  ))}
                </ul>
                <button type="button" className="buttonSecondary">
                  Tool anfragen
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Tools;