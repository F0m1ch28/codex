import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  message: ''
};

function Contact() {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Bitte gib Deinen Namen ein.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte gib Deine E-Mail-Adresse ein.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Bitte gib eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Welche Frage hast Du?';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData(initialState);
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Valeronica</title>
        <meta
          name="description"
          content="Sprich mit Valeronica über Deinen Umzug: Wir beantworten Fragen, sortieren Prioritäten und planen Deine nächsten Schritte."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Kontaktiere uns</h1>
          <p>
            Du möchtest Orientierung, Fragen klären oder ein Programm starten? Schreib uns, und wir melden uns innerhalb von 48 Stunden.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.formWrapper}>
              {submitted && (
                <div className={styles.success} role="status">
                  Danke für Deine Nachricht! Wir melden uns zeitnah bei Dir.
                </div>
              )}
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label htmlFor="name">
                  Name
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'error-name' : undefined}
                    placeholder="Wie dürfen wir Dich ansprechen?"
                  />
                  {errors.name && <span id="error-name" className={styles.error}>{errors.name}</span>}
                </label>
                <label htmlFor="email">
                  E-Mail
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'error-email' : undefined}
                    placeholder="deinname@example.com"
                  />
                  {errors.email && <span id="error-email" className={styles.error}>{errors.email}</span>}
                </label>
                <label htmlFor="message">
                  Nachricht
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'error-message' : undefined}
                    placeholder="Was beschäftigt Dich gerade?"
                  />
                  {errors.message && <span id="error-message" className={styles.error}>{errors.message}</span>}
                </label>
                <button type="submit" className="buttonPrimary">
                  Nachricht senden
                </button>
              </form>
            </div>
            <div className={styles.info}>
              <div className={styles.card}>
                <h2>Kontaktdaten</h2>
                <ul>
                  <li><strong>E-Mail:</strong> <a href="mailto:hallo@valeronica.de">hallo@valeronica.de</a></li>
                  <li><strong>Telefon:</strong> <a href="tel:+4915123456789">+49 151 23456789</a></li>
                  <li><strong>Adresse:</strong> Valeronica GmbH, Musterstraße 45, 10115 Berlin</li>
                </ul>
              </div>
              <div className={styles.card}>
                <h2>Hinweis</h2>
                <p>
                  Wir leisten keine rechtliche, medizinische oder therapeutische Beratung. Bei Bedarf nennen wir Dir seriöse
                  Anlaufstellen und Fachpersonen.
                </p>
                <p>Datenschutz ist uns wichtig. Deine Daten werden ausschließlich zur Bearbeitung Deiner Anfrage verwendet.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Contact;