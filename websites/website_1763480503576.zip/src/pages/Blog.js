import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Blog.module.css';
import { blogPosts, blogCategories } from '../data/blogPosts';

function Blog() {
  const [activeCategory, setActiveCategory] = useState('Alle');

  const filteredPosts = useMemo(() => {
    if (activeCategory === 'Alle') {
      return blogPosts;
    }
    return blogPosts.filter((post) => post.category === activeCategory);
  }, [activeCategory]);

  return (
    <>
      <Helmet>
        <title>Valeronica Blog | Perspektiven fürs Ankommen</title>
        <meta
          name="description"
          content="Der Valeronica Blog bietet Impulse, Tools und Erfahrungsberichte rund um Umzug, Kulturschock, Alltag und Selbstfürsorge."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Valeronica Journal</h1>
          <p>
            Perspektiven, Tools und Geschichten rund ums Ankommen. Ehrlich, pragmatisch und motivierend – ohne leere Versprechen.
          </p>
        </div>
      </section>

      <section className={styles.list}>
        <div className="container">
          <div className={styles.filters} role="group" aria-label="Blogbeiträge filtern">
            {blogCategories.map((category) => (
              <button
                type="button"
                key={category}
                className={`${styles.filterButton} ${activeCategory === category ? styles.filterActive : ''}`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.postGrid}>
            {filteredPosts.map((post) => (
              <article key={post.slug} className={styles.postCard}>
                <div className={styles.postImage}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.postContent}>
                  <span className={styles.postMeta}>{post.category} · {post.readTime}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <Link to={`/blog/${post.slug}`} className={styles.postLink}>
                    Weiterlesen →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Blog;