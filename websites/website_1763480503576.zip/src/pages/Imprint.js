import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Imprint.module.css';

function Imprint() {
  return (
    <>
      <Helmet>
        <title>Impressum | Valeronica</title>
        <meta
          name="description"
          content="Impressum der Valeronica GmbH. Rechtliche Angaben und Kontaktinformationen."
        />
      </Helmet>
      <section className={styles.page}>
        <div className="container">
          <h1>Impressum</h1>
          <p>
            Angaben gemäß § 5 TMG:
            <br />
            Valeronica GmbH
            <br />
            Musterstraße 45
            <br />
            10115 Berlin
          </p>

          <h2>Vertreten durch</h2>
          <p>Geschäftsführung: Valeria König</p>

          <h2>Kontakt</h2>
          <p>
            Telefon: +49 151 23456789
            <br />
            E-Mail: hallo@valeronica.de
          </p>

          <h2>Registereintrag</h2>
          <p>
            Eintragung im Handelsregister.
            <br />
            Registergericht: Amtsgericht Berlin Charlottenburg
            <br />
            Registernummer: HRB 123456
          </p>

          <h2>Umsatzsteuer-ID</h2>
          <p>Umsatzsteuer-Identifikationsnummer gemäß § 27 a Umsatzsteuergesetz: DE123456789</p>

          <h2>Haftungshinweis</h2>
          <p>
            Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für externe Links. Für den Inhalt der verlinkten Seiten
            sind ausschließlich deren Betreiber verantwortlich.
          </p>

          <h2>Keine rechtliche oder medizinische Beratung</h2>
          <p>
            Die Inhalte unserer Angebote stellen keine rechtliche, medizinische oder therapeutische Beratung dar. Bei entsprechenden Fragen
            empfehlen wir Dir, qualifizierte Fachpersonen zu kontaktieren.
          </p>
        </div>
      </section>
    </>
  );
}

export default Imprint;