import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

function About() {
  return (
    <>
      <Helmet>
        <title>Über Valeronica | Menschlich ankommen im neuen Land</title>
        <meta
          name="description"
          content="Erfahre mehr über die Mission, Werte und Menschen hinter Valeronica. Wir begleiten Dich realistisch und empathisch beim Leben im neuen Land."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={`${styles.heroInner} container`}>
          <div>
            <h1>Über Valeronica</h1>
            <p>
              Wir glauben, dass Ankommen mehr ist als ein erledigter Umzug. Es geht um Routinen, die sich gut anfühlen, um
              Beziehungen, die tragen, und um ein Tempo, das Deine Energie respektiert. Deshalb verbinden wir Struktur und
              Empathie mit Tools, die sofort im Alltag funktionieren.
            </p>
          </div>
          <div className={styles.heroPanel}>
            <h2>Unsere Haltung</h2>
            <ul>
              <li>Wir hören zu, bevor wir beraten.</li>
              <li>Wir arbeiten realistisch, nicht idealistisch.</li>
              <li>Wir fokussieren auf Umsetzung statt Überforderung.</li>
              <li>Wir feiern kleine Schritte als echten Fortschritt.</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div className={styles.missionCard}>
              <h3>Unsere Mission</h3>
              <p>
                Menschen in neuen Lebens- und Arbeitskontexten bekommen oft widersprüchliche Informationen und zu hohe Erwartungen.
                Wir sorgen für Klarheit, Struktur und einen sicheren Raum, in dem Fragen erlaubt sind und Unsicherheiten ausgesprochen
                werden dürfen.
              </p>
            </div>
            <div className={styles.missionCard}>
              <h3>Alltagstauglichkeit zuerst</h3>
              <p>
                Unsere Materialien sind modular aufgebaut, leicht adaptierbar und bewusst nicht überladen. Du entscheidest, was
                gerade dran ist. Wir geben Dir Methoden an die Hand, mit denen Du selbstbestimmt weitergehen kannst.
              </p>
            </div>
            <div className={styles.missionCard}>
              <h3>Seriosität & Datenschutz</h3>
              <p>
                Wir arbeiten mit sicheren Tools, nach europäischen Datenschutzstandards und mit transparenten Prozessen. Persönliche
                Daten behandeln wir vertraulich. Wir bieten keine rechtliche, medizinische oder therapeutische Beratung an.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className="container">
          <h2>Unser Weg</h2>
          <div className={styles.timelineGrid}>
            <div>
              <span className={styles.timelineYear}>2017</span>
              <p>Start als persönliches Projekt, um internationalen Fachkräften Orientierung und Struktur zu geben.</p>
            </div>
            <div>
              <span className={styles.timelineYear}>2019</span>
              <p>Erweiterung um Community-Formate und Peer-Learning, Fokus auf Austausch ohne Smalltalk-Zwang.</p>
            </div>
            <div>
              <span className={styles.timelineYear}>2021</span>
              <p>Gründung der Valeronica GmbH in Berlin, Aufbau des Programmpanels für Unternehmen und Teams.</p>
            </div>
            <div>
              <span className={styles.timelineYear}>2023+</span>
              <p>Hybrid-Angebote aus Coaching, Tools und On-demand-Materialien – für Einzelpersonen, Teams und Communities.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2>Was uns leitet</h2>
          <div className={styles.valuesGrid}>
            <article>
              <h3>Empathie mit Haltung</h3>
              <p>Wir schaffen Sicherheit, bleiben gleichzeitig klar in unseren Empfehlungen und Prioritäten.</p>
            </article>
            <article>
              <h3>Selbstwirksamkeit stärken</h3>
              <p>Wir geben Dir Tools, damit Du Entscheidungen triffst, Prozesse verstehst und Dich kompetent fühlst.</p>
            </article>
            <article>
              <h3>Nachhaltiges Tempo</h3>
              <p>Ankommen ist kein Sprint. Wir arbeiten mit Energie-Checks, Pausen und bewussten Übergängen.</p>
            </article>
            <article>
              <h3>Transparenz & Integrität</h3>
              <p>Keine falschen Versprechen, keine versteckten Kosten. Was wir anbieten, kommunizieren wir klar.</p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
}

export default About;