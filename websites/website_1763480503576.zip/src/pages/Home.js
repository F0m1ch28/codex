import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';
import { blogPosts } from '../data/blogPosts';

const statsTargets = [
  { label: 'Begleitete Umzüge', value: 1200 },
  { label: 'Zufriedenheits-Score', value: 4.8, suffix: '/5' },
  { label: 'Community-Events', value: 87 }
];

const topics = [
  {
    title: 'Behörden & Bürokratie',
    description: 'Schritt-für-Schritt-Checklisten, Terminvorbereitung, verständliche Dokumentübersichten.',
    link: '/programs'
  },
  {
    title: 'Sprache & Lernen',
    description: 'Mini-Lernroutinen, Feedback-Schleifen, Motivation ohne Druck.',
    link: '/tools'
  },
  {
    title: 'Soziale Kontakte',
    description: 'Impulse für authentische Gespräche, Community-Karten und Warm-up-Fragen.',
    link: '/programs'
  },
  {
    title: 'Alltag & Routinen',
    description: 'Struktur ohne Starrheit: individuelle Wochenpläne, Ankommens-Tagebuch und Reset-Methoden.',
    link: '/guide'
  }
];

const benefits = [
  {
    title: 'Klare Struktur',
    description: 'Wir gliedern Deinen Weg in machbare Schritte – von der Vorbereitung bis zur neuen Routine.',
    icon: '🗂️'
  },
  {
    title: 'Menschliche Begleitung',
    description: 'Wir hören zu, stellen die richtigen Fragen und bleiben realistisch – ohne leere Versprechen.',
    icon: '🤝'
  },
  {
    title: 'Alltagstaugliche Tools',
    description: 'Von der Checkliste bis zur Reflexion: Du bekommst Materialien, die in Deinen Alltag passen.',
    icon: '🛠️'
  },
  {
    title: 'Community-Fokus',
    description: 'Erlebe Austausch mit Menschen, die ähnliche Wege gehen, und profitiere vom Miteinander.',
    icon: '✨'
  }
];

const processSteps = [
  {
    title: 'Klarheit schaffen',
    description: 'Wir sammeln Erwartungen, offene Fragen und Grenzen. So weißt Du, womit wir starten.'
  },
  {
    title: 'Prioritäten planen',
    description: 'Wir sortieren Deine To-dos, definieren sinnvolle Zeitfenster und vermeiden Überforderung.'
  },
  {
    title: 'Verbindungen stärken',
    description: 'Gemeinsam finden wir Orte, Formate und Menschen, die zu Dir passen – ohne Smalltalk-Zwang.'
  },
  {
    title: 'Routinen stabilisieren',
    description: 'Wir verankern neue Gewohnheiten, Feiern Fortschritte und passen an, was sich nicht rund anfühlt.'
  }
];

const programsPreview = [
  {
    title: '14-Tage-Ankommens-Plan',
    description: 'Tägliche Micro-Schritte, Reflexionsfragen und Mini-Feiern für Dein neues Zuhause.',
    duration: '14 Tage',
    target: 'Für Neustarter:innen',
    link: '/programs'
  },
  {
    title: 'Kontakte-knüpfen-Challenge',
    description: 'Sichere Gesprächsimpulse, Event-Vorschläge und Nachbereitungs-Check-ins.',
    duration: '10 Tage',
    target: 'Für Community-Suchende',
    link: '/programs'
  },
  {
    title: 'Bürokratie-Stress reduzieren',
    description: 'Vorlagen, Erinnerungsraster und Prioritäten-Clarifier für Behördenangelegenheiten.',
    duration: '21 Tage',
    target: 'Für viel Papierkram',
    link: '/programs'
  }
];

const testimonials = [
  {
    name: 'Leonie, 32',
    role: 'Umzug von Köln nach Kopenhagen',
    quote:
      'Der strukturierte Wochenplan plus ehrliche Gespräche haben mir geholfen, nicht in Panik zu verfallen. Ich konnte jeden Tag einen Schritt gehen – und das hat mir Sicherheit gegeben.'
  },
  {
    name: 'Arjun, 28',
    role: 'Von Bengaluru nach Berlin',
    quote:
      'Besonders wertvoll war der Fokus auf Community. Die Warm-up-Fragen für Events nutze ich immer noch. Ich fühle mich deutlich verbundener mit meinem neuen Umfeld.'
  },
  {
    name: 'Sophie, 41',
    role: 'Rückkehr aus Kanada nach Deutschland',
    quote:
      'Ich hatte Angst vor der ganzen Bürokratie. Der dreistufige Routineplan und die Checklisten haben mir Ruhe verschafft. Endlich kein Papierchaos mehr.'
  }
];

const teamMembers = [
  {
    name: 'Valeria König',
    role: 'Gründerin & Transition Coach',
    focus: 'Emotionale Stabilität & klare Routinen',
    bio: 'Valeria hat selbst in vier Ländern gelebt und hilft Menschen, ihren Alltag realistisch zu strukturieren.',
    image: 'https://picsum.photos/400/400?random=21'
  },
  {
    name: 'Jonas Richter',
    role: 'Community Designer',
    focus: 'Soziale Netzwerke & Eventformate',
    bio: 'Jonas entwickelt Begegnungsräume, die ohne Smalltalk-Druck funktionieren und echte Verbindung ermöglichen.',
    image: 'https://picsum.photos/400/400?random=22'
  },
  {
    name: 'Maya Fernández',
    role: 'Organisationsstrategin',
    focus: 'Bürokratie & Priorisierung',
    bio: 'Maya übersetzt komplexe Verwaltungsschritte in verständliche Roadmaps und praktische Checklisten.',
    image: 'https://picsum.photos/400/400?random=23'
  }
];

const faqItems = [
  {
    question: 'Bietet Valeronica rechtliche Beratung an?',
    answer:
      'Nein. Wir unterstützen Dich strukturell, organisatorisch und emotional. Für rechtliche Fragen empfehlen wir spezialisierte Berater:innen.'
  },
  {
    question: 'Wie individuell sind die Programme?',
    answer:
      'Jedes Programm enthält Anleitungen und Reflexionsfragen, mit denen Du Inhalte an Deine Situation anpasst. In Add-on-Sessions vertiefen wir individuelle Themen.'
  },
  {
    question: 'Brauche ich Vorkenntnisse oder perfekte Sprachkenntnisse?',
    answer:
      'Nein. Wir arbeiten bewusst mit klaren, verständlichen Materialien. Unsere Tools sind für unterschiedliche Sprachniveaus optimiert.'
  },
  {
    question: 'Wie läuft die Zusammenarbeit ab?',
    answer:
      'Du startest mit einem Orientierungsgespräch. Danach wählen wir Tools, Programme oder Live-Begleitung, die zu Deinem Ziel passen.'
  }
];

const projectsData = [
  {
    title: 'Community-Wochenplan für Neuankömmlinge',
    category: 'Community',
    description: 'Strukturierter Kalender mit Event-Impulsen, Ruhephasen und Reflexionsmomenten.',
    image: 'https://picsum.photos/1200/800?random=31'
  },
  {
    title: 'Paperwork-Sprint für Relocation Teams',
    category: 'Organisation',
    description: 'Team-Workshop mit Prioritäten-Matrix, Fristenkontrolle und Klarheitsboards.',
    image: 'https://picsum.photos/1200/800?random=32'
  },
  {
    title: 'Sprachfreundliche Morgenroutinen',
    category: 'Alltag',
    description: 'Kombination aus Mikro-Lerneinheiten, Audio-Impulsen und Reflexionsfragen.',
    image: 'https://picsum.photos/1200/800?random=33'
  },
  {
    title: 'Welcome Lab für internationale Fachkräfte',
    category: 'Community',
    description: 'Hybrid-Format aus Treffen, Peer-Gesprächen und begleitetem Ressourcenaufbau.',
    image: 'https://picsum.photos/1200/800?random=34'
  }
];

function Home() {
  const [stats, setStats] = useState(statsTargets.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeTeam, setActiveTeam] = useState(null);
  const [projectFilter, setProjectFilter] = useState('Alle');
  const [expandedFaq, setExpandedFaq] = useState(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prev) =>
        prev.map((value, index) => {
          const target = statsTargets[index].value;
          if (value >= target) return target;
          const increment = target < 5 ? 0.1 : Math.ceil(target / 60);
          const newValue = Math.min(value + increment, target);
          return Number(newValue.toFixed(1));
        })
      );
    }, 40);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'Alle') return projectsData;
    return projectsData.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  const blogPreview = useMemo(() => blogPosts.slice(0, 2), []);

  const handleFaqToggle = (index) => {
    setExpandedFaq((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Helmet>
        <title>Valeronica | Neues Land. Weniger Stress. Mehr Ankommen.</title>
        <meta
          name="description"
          content="Valeronica unterstützt Dich beim Umzug in ein neues Land – mit Struktur, Community und alltagstauglichen Tools."
        />
      </Helmet>
      <div id="hauptinhalt" className={styles.page}>
        <section className={styles.hero}>
          <div className={`${styles.heroInner} container`}>
            <div className={styles.heroContent}>
              <span className={styles.heroBadge}>Ankommen ohne Überforderung</span>
              <h1 className={styles.heroTitle}>Neues Land. Weniger Stress. Mehr Ankommen.</h1>
              <p className={styles.heroText}>
                Valeronica begleitet Dich empathisch, strukturiert und pragmatisch beim Umzug in ein neues Land. Wir
                verbinden emotionale Stabilität mit klaren Tools – für ein Ankommen, das sich wirklich nach Dir anfühlt.
              </p>
              <div className={styles.heroActions}>
                <Link to="/contact" className={`${styles.heroButton} buttonPrimary`}>
                  Jetzt starten
                </Link>
                <Link to="/guide" className="buttonSecondary">
                  Ankommen erleichtern
                </Link>
              </div>
              <div className={styles.heroStats}>
                {statsTargets.map((stat, index) => (
                  <div key={stat.label}>
                    <span className={styles.statNumber}>
                      {stats[index]}
                      {stat.suffix || ''}
                    </span>
                    <span className={styles.statLabel}>{stat.label}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className={styles.heroImageWrapper}>
              <img
                src="https://picsum.photos/1600/900?random=101"
                alt="Person plant entspannt ihren Umzug in ein neues Land"
                className={styles.heroImage}
                loading="eager"
              />
            </div>
          </div>
        </section>

        <section className={styles.benefitsSection}>
          <div className="container">
            <h2 className="sectionTitle">Was Dich mit Valeronica erwartet</h2>
            <p className="sectionSubtitle">
              Wir setzen auf Klarheit, Verbindung und alltagstaugliche Strukturen – damit Du Dein neues Leben selbstbewusst
              gestalten kannst.
            </p>
            <div className={styles.benefitsGrid}>
              {benefits.map((benefit) => (
                <article key={benefit.title} className={styles.benefitCard}>
                  <div className={styles.benefitIcon} aria-hidden="true">
                    {benefit.icon}
                  </div>
                  <h3>{benefit.title}</h3>
                  <p>{benefit.description}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.topicsSection}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2 className="sectionTitle">Deine wichtigsten Themen – fokussiert angehen</h2>
              <p className="sectionSubtitle">
                Von der ersten Anmeldung bis zum neuen Freundeskreis: Wir haben Deine Reise in handliche thematische Bausteine
                gegliedert.
              </p>
            </div>
            <div className={styles.topicsGrid}>
              {topics.map((topic) => (
                <Link key={topic.title} to={topic.link} className={styles.topicCard}>
                  <div>
                    <h3>{topic.title}</h3>
                    <p>{topic.description}</p>
                  </div>
                  <span className={styles.topicLink}>Mehr erfahren →</span>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.processSection}>
          <div className="container">
            <div className={styles.processHeader}>
              <h2 className="sectionTitle">So läuft unsere Zusammenarbeit</h2>
              <p className="sectionSubtitle">
                Ein klarer Rahmen gibt Dir Orientierung – ohne starre Vorgaben. Wir passen jeden Schritt an Deine Situation an.
              </p>
            </div>
            <div className={styles.processGrid}>
              {processSteps.map((step, index) => (
                <div key={step.title} className={styles.processCard}>
                  <span className={styles.processIndex}>{index + 1}</span>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.programsSection}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2 className="sectionTitle">Programme, die Dich in Bewegung bringen</h2>
              <p className="sectionSubtitle">
                Wähle aus klar strukturierten Challenges und Programmen, die wir gemeinsam justieren – für Deinen Alltag, Deine
                Energie, Deine Ziele.
              </p>
            </div>
            <div className={styles.programsGrid}>
              {programsPreview.map((program) => (
                <article key={program.title} className={styles.programCard}>
                  <h3>{program.title}</h3>
                  <p>{program.description}</p>
                  <ul>
                    <li><strong>Dauer:</strong> {program.duration}</li>
                    <li><strong>Für wen:</strong> {program.target}</li>
                  </ul>
                  <Link to={program.link} className={styles.programLink}>
                    Programm starten
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.projectsSection}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2 className="sectionTitle">Projekte & Formate in Aktion</h2>
              <p className="sectionSubtitle">
                Wir gestalten Räume und Tools, die wir mit Teams, Communities und Einzelpersonen umgesetzt haben.
              </p>
            </div>
            <div className={styles.projectFilters} role="group" aria-label="Projekte filtern">
              {['Alle', 'Organisation', 'Community', 'Alltag'].map((category) => (
                <button
                  type="button"
                  key={category}
                  className={`${styles.filterButton} ${projectFilter === category ? styles.filterActive : ''}`}
                  onClick={() => setProjectFilter(category)}
                >
                  {category}
                </button>
              ))}
            </div>
            <div className={styles.projectsGrid}>
              {filteredProjects.map((project) => (
                <article key={project.title} className={styles.projectCard}>
                  <div className={styles.projectImageWrapper}>
                    <img
                      src={project.image}
                      alt={`${project.title} – Projektbeispiel`}
                      loading="lazy"
                    />
                  </div>
                  <div className={styles.projectContent}>
                    <span className={styles.projectCategory}>{project.category}</span>
                    <h3>{project.title}</h3>
                    <p>{project.description}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.testimonialsSection}>
          <div className="container">
            <div className={styles.testimonialCard}>
              <div className={styles.testimonialHeader}>
                <h2 className="sectionTitle">Stimmen von Menschen, die mit uns angekommen sind</h2>
                <div className={styles.testimonialControls} role="group" aria-label="Testimonials wechseln">
                  <button
                    type="button"
                    onClick={() =>
                      setActiveTestimonial((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1))
                    }
                    aria-label="Vorheriges Testimonial"
                  >
                    ←
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setActiveTestimonial((prev) => (prev + 1) % testimonials.length)
                    }
                    aria-label="Nächstes Testimonial"
                  >
                    →
                  </button>
                </div>
              </div>
              <blockquote className={styles.testimonialQuote}>
                “{testimonials[activeTestimonial].quote}”
              </blockquote>
              <footer className={styles.testimonialFooter}>
                <span className={styles.testimonialName}>{testimonials[activeTestimonial].name}</span>
                <span className={styles.testimonialRole}>{testimonials[activeTestimonial].role}</span>
              </footer>
              <div className={styles.testimonialIndicators} role="tablist" aria-label="Testimonial Auswahl">
                {testimonials.map((testimonial, index) => (
                  <button
                    key={testimonial.name}
                    type="button"
                    className={`${styles.indicator} ${activeTestimonial === index ? styles.indicatorActive : ''}`}
                    onClick={() => setActiveTestimonial(index)}
                    aria-label={`Testimonial von ${testimonial.name}`}
                    aria-selected={activeTestimonial === index}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className={styles.teamSection}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2 className="sectionTitle">Dein Valeronica Team</h2>
              <p className="sectionSubtitle">
                Wir bringen Erfahrung aus Organisationsentwicklung, Coaching und Community-Design zusammen – menschlich,
                klar und alltagstauglich.
              </p>
            </div>
            <div className={styles.teamGrid}>
              {teamMembers.map((member, index) => (
                <article
                  key={member.name}
                  className={`${styles.teamCard} ${activeTeam === index ? styles.teamCardActive : ''}`}
                  onMouseEnter={() => setActiveTeam(index)}
                  onMouseLeave={() => setActiveTeam(null)}
                  onFocus={() => setActiveTeam(index)}
                  onBlur={() => setActiveTeam(null)}
                >
                  <div className={styles.teamImageWrapper}>
                    <img src={member.image} alt={`${member.name} – ${member.role}`} loading="lazy" />
                  </div>
                  <div className={styles.teamContent}>
                    <h3>{member.name}</h3>
                    <span className={styles.teamRole}>{member.role}</span>
                    <span className={styles.teamFocus}>{member.focus}</span>
                    <p>{member.bio}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.faqSection}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2 className="sectionTitle">Antworten auf häufige Fragen</h2>
              <p className="sectionSubtitle">
                Klarheit reduziert Stress. Wenn Deine Frage hier nicht beantwortet wird, melde Dich gerne bei uns.
              </p>
            </div>
            <div className={styles.faqList}>
              {faqItems.map((item, index) => (
                <div key={item.question} className={styles.faqItem}>
                  <button
                    type="button"
                    className={styles.faqButton}
                    onClick={() => handleFaqToggle(index)}
                    aria-expanded={expandedFaq === index}
                  >
                    <span>{item.question}</span>
                    <span aria-hidden="true">{expandedFaq === index ? '−' : '+'}</span>
                  </button>
                  {expandedFaq === index && (
                    <div className={styles.faqAnswer}>
                      <p>{item.answer}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.blogSection}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2 className="sectionTitle">Aktuelle Perspektiven aus dem Valeronica Journal</h2>
              <p className="sectionSubtitle">
                Gedanken, Tools und Erfahrungsberichte für Dein Ankommen – klar, ehrlich und menschlich.
              </p>
            </div>
            <div className={styles.blogGrid}>
              {blogPreview.map((post) => (
                <article key={post.slug} className={styles.blogCard}>
                  <div className={styles.blogImageWrapper}>
                    <img src={post.image} alt={post.title} loading="lazy" />
                  </div>
                  <div className={styles.blogContent}>
                    <span className={styles.blogMeta}>{post.category} · {post.readTime} Lesezeit</span>
                    <h3>{post.title}</h3>
                    <p>{post.excerpt}</p>
                    <Link to={`/blog/${post.slug}`} className={styles.blogLink}>
                      Weiterlesen
                    </Link>
                  </div>
                </article>
              ))}
            </div>
            <div className={styles.blogCta}>
              <Link to="/blog" className="buttonSecondary">
                Alle Beiträge ansehen
              </Link>
            </div>
          </div>
        </section>

        <section className={styles.ctaSection}>
          <div className="container">
            <div className={styles.ctaCard}>
              <div>
                <h2>Ankommen darf sich leichter anfühlen.</h2>
                <p>
                  Lass uns herausfinden, welche nächsten Schritte Dir gerade gut tun. In einem kurzen Orientierungsgespräch
                  klären wir Deine Fragen und planen gemeinsam.
                </p>
              </div>
              <div className={styles.ctaActions}>
                <Link to="/contact" className="buttonPrimary">
                  Orientierungsgespräch buchen
                </Link>
                <Link to="/guide" className="buttonSecondary">
                  Leitfaden entdecken
                </Link>
              </div>
            </div>
            <p className={styles.ctaHint}>
              Hinweis: Wir leisten keine rechtliche oder medizinische Beratung. Bei Bedarf vermitteln wir Dir seriöse Anlaufstellen.
            </p>
          </div>
        </section>
      </div>
    </>
  );
}

export default Home;