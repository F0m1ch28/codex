import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function Legal() {
  return (
    <>
      <Helmet>
        <title>Allgemeine Geschäftsbedingungen | Valeronica</title>
        <meta
          name="description"
          content="Allgemeine Geschäftsbedingungen der Valeronica GmbH. Transparente Regeln für unsere Zusammenarbeit."
        />
      </Helmet>
      <section className={styles.page}>
        <div className="container">
          <h1>Allgemeine Geschäftsbedingungen (AGB)</h1>
          <p className={styles.updated}>Stand: März 2024</p>

          <h2>1. Geltungsbereich</h2>
          <p>
            Diese Allgemeinen Geschäftsbedingungen gelten für alle Angebote, Programme, Workshops und Leistungen der Valeronica GmbH.
            Abweichende Bedingungen erkennen wir nur an, wenn wir ihnen schriftlich zustimmen.
          </p>

          <h2>2. Leistungen</h2>
          <p>
            Valeronica bietet Begleitprogramme, Workshops, Leitfäden und digitale Tools zur Unterstützung beim Umzug in ein neues Land.
            Es handelt sich nicht um rechtliche, medizinische oder therapeutische Beratung.
          </p>

          <h2>3. Vertragsabschluss</h2>
          <p>
            Ein Vertrag kommt zustande, sobald eine Buchung schriftlich oder digital bestätigt wird. Termine gelten als verbindlich,
            sobald sie von beiden Seiten bestätigt wurden.
          </p>

          <h2>4. Zahlungsbedingungen</h2>
          <p>
            Rechnungen sind innerhalb von 14 Tagen fällig, sofern nichts anderes vereinbart wurde. Alle Preise verstehen sich in Euro
            und enthalten die gesetzliche Umsatzsteuer, sofern anwendbar.
          </p>

          <h2>5. Stornierung</h2>
          <p>
            Stornierungen bis 48 Stunden vor Termin sind kostenfrei möglich. Bei späteren Absagen behalten wir uns vor, bis zu 50 % der
            vereinbarten Vergütung zu berechnen. Bereits begonnene Programme können nicht rückerstattet werden.
          </p>

          <h2>6. Haftung</h2>
          <p>
            Valeronica haftet nur für Schäden, die vorsätzlich oder grob fahrlässig verursacht wurden. Eine Haftung für entgangenen Gewinn
            oder Folgeschäden ist ausgeschlossen.
          </p>

          <h2>7. Datenschutz</h2>
          <p>
            Wir verarbeiten personenbezogene Daten ausschließlich im Rahmen der geltenden Datenschutzbestimmungen. Details findest Du in
            unserer Datenschutzerklärung.
          </p>

          <h2>8. Schlussbestimmungen</h2>
          <p>
            Es gilt das Recht der Bundesrepublik Deutschland. Gerichtsstand ist Berlin, sofern gesetzlich zulässig. Sollten einzelne
            Bestimmungen unwirksam sein, bleibt der Vertrag im Übrigen wirksam.
          </p>
        </div>
      </section>
    </>
  );
}

export default Legal;