import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';
import { Link } from 'react-router-dom';

const serviceGroups = [
  {
    title: 'Begleitprogramme',
    description:
      'Modulare Programme mit klaren Wochenzielen, Reflexionsfragen und Live-Check-ins für kontinuierliche Unterstützung.',
    highlights: ['14-Tage-Ankommens-Plan', 'Reset-Wochenenden', 'Fokus auf Energie statt To-do-Liste']
  },
  {
    title: 'Community-Formate',
    description:
      'Wir gestalten Räume für echten Austausch: Online, hybrid oder vor Ort – inkl. Moderation und Warm-up-Konzept.',
    highlights: ['Kontakte-knüpfen-Challenge', 'Welcome Circles', 'Peer-Support-Sessions']
  },
  {
    title: 'Struktur-Workshops',
    description:
      'Hands-on Sessions für Dokumente, Behörden und Prioritäten. Ideal für Relocation-Teams und Neuankömmlinge.',
    highlights: ['Bürokratie-Stress reduzieren', 'Prioritäten-Sprints', 'Organisations-Toolbox']
  }
];

const miniSessions = [
  {
    title: 'Orientierungsgespräch',
    description: '30 Minuten Klarheit: Wir sortieren Themen, definieren Prioritäten und empfehlen passende Schritte.',
    duration: '30 Minuten',
    format: 'Remote oder vor Ort',
    link: '/contact'
  },
  {
    title: 'Routine-Check',
    description: 'Analyse Deiner aktuellen Woche mit konkreten Anpassungen für mehr Ruhe und Fokus.',
    duration: '60 Minuten',
    format: 'Remote',
    link: '/contact'
  },
  {
    title: 'Community-Canvas',
    description: 'Wir entwerfen Deinen ganz persönlichen Verbindungsplan – angepasst an Energie, Interessen und Tempo.',
    duration: '90 Minuten',
    format: 'Hybrid',
    link: '/contact'
  }
];

function Services() {
  return (
    <>
      <Helmet>
        <title>Angebote von Valeronica | Programme, Workshops & Begleitung</title>
        <meta
          name="description"
          content="Entdecke die Angebote von Valeronica: Programme, Workshops und Sessions, die Ankommen strukturieren und emotional begleiten."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Angebote für ein Ankommen mit Struktur & Verbindung</h1>
          <p>
            Unsere Formate sind modular, flexibel und empathisch. Du entscheidest, was Du brauchst. Wir sorgen für Struktur, klare
            Kommunikation und nachhaltige Routinen.
          </p>
        </div>
      </section>

      <section className={styles.groups}>
        <div className="container">
          <div className={styles.groupGrid}>
            {serviceGroups.map((group) => (
              <article key={group.title} className={styles.groupCard}>
                <h2>{group.title}</h2>
                <p>{group.description}</p>
                <ul>
                  {group.highlights.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
                <Link to="/contact" className={styles.groupLink}>
                  Austausch starten →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.sessions}>
        <div className="container">
          <div className={styles.sessionsHeader}>
            <h2>Kompakte Sessions für schnelle Orientierung</h2>
            <p>
              Ideal, wenn Du punktuell Unterstützung brauchst oder unser Arbeiten kennenlernen möchtest. Wir arbeiten alltagstauglich,
              ohne Druck und mit klaren Ergebnissen.
            </p>
          </div>
          <div className={styles.sessionGrid}>
            {miniSessions.map((session) => (
              <article key={session.title} className={styles.sessionCard}>
                <h3>{session.title}</h3>
                <p>{session.description}</p>
                <dl>
                  <div>
                    <dt>Dauer</dt>
                    <dd>{session.duration}</dd>
                  </div>
                  <div>
                    <dt>Format</dt>
                    <dd>{session.format}</dd>
                  </div>
                </dl>
                <Link to={session.link} className={styles.sessionLink}>
                  Termin anfragen
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Services;