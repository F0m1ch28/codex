import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './BlogDetail.module.css';
import { blogPosts } from '../data/blogPosts';

function BlogDetail() {
  const { slug } = useParams();
  const post = blogPosts.find((entry) => entry.slug === slug);

  if (!post) {
    return (
      <section className={styles.notFound}>
        <div className="container">
          <h1>Beitrag nicht gefunden</h1>
          <p>Der gesuchte Artikel ist nicht verfügbar oder wurde verschoben.</p>
          <Link to="/blog" className="buttonPrimary">
            Zurück zum Blog
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} | Valeronica Blog</title>
        <meta name="description" content={post.excerpt} />
      </Helmet>
      <article className={styles.post}>
        <div className={styles.hero}>
          <div className="container">
            <span className={styles.meta}>{post.category} · {post.readTime}</span>
            <h1>{post.title}</h1>
            <p>{post.excerpt}</p>
          </div>
        </div>
        <div className={`${styles.contentWrapper} container`}>
          <div className={styles.imageWrapper}>
            <img src={post.image} alt={post.title} loading="lazy" />
          </div>
          <div className={styles.content}>
            {post.content.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
            <div className={styles.backLink}>
              <Link to="/blog" className="buttonSecondary">
                Zurück zum Blog
              </Link>
            </div>
          </div>
        </div>
      </article>
    </>
  );
}

export default BlogDetail;