import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { to: '/', label: 'Start' },
  { to: '/guide', label: 'Leitfaden' },
  { to: '/services', label: 'Angebote' },
  { to: '/programs', label: 'Programme' },
  { to: '/tools', label: 'Tools' },
  { to: '/blog', label: 'Blog' },
  { to: '/about', label: 'Über uns' },
  { to: '/contact', label: 'Kontakt' }
];

function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [isMenuOpen]);

  const handleLinkClick = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`}>
      <a href="#hauptinhalt" className={styles.skipLink}>
        Zum Inhalt springen
      </a>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="Valeronica Startseite">
          <span className={styles.logoAccent}>Valeronica</span>
          <span className={styles.logoSubline}>Ankommen leichter gemacht</span>
        </Link>
        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Hauptnavigation">
          <ul>
            {navItems.map((item) => (
              <li key={item.to}>
                <NavLink
                  end={item.to === '/'}
                  to={item.to}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                  onClick={handleLinkClick}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <Link to="/contact" className={styles.ctaLink} onClick={handleLinkClick}>
            Beratung anfragen
          </Link>
        </nav>
        <button
          type="button"
          className={`${styles.menuToggle} ${isMenuOpen ? styles.menuToggleOpen : ''}`}
          onClick={() => setIsMenuOpen((prev) => !prev)}
          aria-expanded={isMenuOpen}
          aria-controls="hauptnavigation"
          aria-label="Navigation umschalten"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
}

export default Header;