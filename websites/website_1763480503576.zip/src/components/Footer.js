import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.brand}>
          <span className={styles.logo}>Valeronica</span>
          <p>
            Wir begleiten Dich strukturiert, empathisch und alltagstauglich beim Ankommen in Deinem neuen Land.
          </p>
        </div>
        <div className={styles.columns}>
          <div>
            <h3>Navigation</h3>
            <ul>
              <li><Link to="/">Start</Link></li>
              <li><Link to="/guide">Leitfaden</Link></li>
              <li><Link to="/services">Angebote</Link></li>
              <li><Link to="/programs">Programme</Link></li>
              <li><Link to="/tools">Tools</Link></li>
            </ul>
          </div>
          <div>
            <h3>Ressourcen</h3>
            <ul>
              <li><Link to="/blog">Blog</Link></li>
              <li><Link to="/about">Über uns</Link></li>
              <li><Link to="/contact">Kontakt</Link></li>
              <li><Link to="/legal">AGB</Link></li>
              <li><Link to="/privacy">Datenschutz</Link></li>
              <li><Link to="/imprint">Impressum</Link></li>
            </ul>
          </div>
          <div>
            <h3>Kontakt</h3>
            <ul className={styles.contactList}>
              <li>Valeronica GmbH</li>
              <li>Musterstraße 45, 10115 Berlin</li>
              <li><a href="mailto:hallo@valeronica.de">hallo@valeronica.de</a></li>
              <li><a href="tel:+4915123456789">+49 151 23456789</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© {new Date().getFullYear()} Valeronica. Alle Rechte vorbehalten.</p>
        <p className={styles.hint}>Hinweis: Keine rechtliche, medizinische oder therapeutische Beratung.</p>
      </div>
    </footer>
  );
}

export default Footer;