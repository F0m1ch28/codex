import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'valeronica-cookie-consent';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie Hinweis">
      <p>
        Wir verwenden Cookies, um Deine Erfahrung zu verbessern und anonyme Statistiken zu sammeln. Es werden keine
        persönlichen Profile erstellt.
      </p>
      <button type="button" onClick={handleAccept}>
        Verstanden
      </button>
    </div>
  );
}

export default CookieBanner;