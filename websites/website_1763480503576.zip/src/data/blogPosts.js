export const blogPosts = [
  {
    slug: 'ankommen-ohne-ueberforderung',
    title: 'Ankommen ohne Überforderung: So findest Du Deinen Rhythmus',
    excerpt:
      'Wie Du vom ersten Tag an für Ruhe und Struktur sorgst – inklusive konkreter Mini-Routinen für die ersten Wochen.',
    category: 'Alltag',
    readTime: '6 Min.',
    image: 'https://picsum.photos/1200/720?random=11',
    content: [
      'Die ersten Tage im neuen Land fühlen sich oft an wie ein Sprint, dabei braucht Ankommen eher einen ruhigen Takt. Starte mit einem klaren Fokus: Welche drei Dinge brauchen heute wirklich Deine Aufmerksamkeit? Alles andere darf warten.',
      'Schaffe Dir kleine, wiederkehrende Momente. Ein Morgenritual von zehn Minuten reicht, um Deinem Tag einen verlässlichen Start zu geben. Vielleicht ein Kaffee am Fenster, ein kurzes Sprachnotiz-Tagebuch, oder ein Spaziergang durch Dein neues Viertel.',
      'Nutze Ankern, die Dir Stabilität geben. Schreib Dir abends drei Dinge auf, die heute gut liefen – egal wie klein. So trainierst Du Deinen Blick für Fortschritt, selbst wenn vieles noch ungewohnt wirkt.'
    ]
  },
  {
    slug: 'mut-zum-netzwerken',
    title: 'Mut zum Netzwerken: Kontakte knüpfen ohne Smalltalk-Stress',
    excerpt:
      'Neue Menschen kennenlernen muss nicht verkopft sein. Mit diesen Fragen und Impulsen gelingt Dir authentische Verbindung.',
    category: 'Community',
    readTime: '5 Min.',
    image: 'https://picsum.photos/1200/720?random=12',
    content: [
      'Der Schlüssel zu echten Kontakten sind Situationen, in denen sich Gespräche natürlich ergeben. Such Dir Orte, die etwas mit Deinen Interessen zu tun haben – ob Sprachcafé, Sportgruppe oder Fach-Meetup.',
      'Bereite zwei bis drei Einstiegsfragen vor, die über Smalltalk hinausgehen. Frag zum Beispiel: „Was hat Dich hierher geführt?“ oder „Welche Momente helfen Dir, Dich zuhause zu fühlen?“ Damit öffnest Du Räume für echte Geschichten.',
      'Feiere kleine Schritte. Jedes Gespräch, jede neue Bekanntschaft ist ein Erfolg. Halte fest, welche Begegnungen Dir gut getan haben und plane bewusst mehr davon ein.'
    ]
  },
  {
    slug: 'behoerden-blockaden-loesen',
    title: 'Behörden-Blockaden lösen: So strukturierst Du Papierkram',
    excerpt:
      'Drei schlanke Routinen, mit denen Du Dokumente, Termine und Fristen entspannt im Blick behältst.',
    category: 'Organisation',
    readTime: '7 Min.',
    image: 'https://picsum.photos/1200/720?random=13',
    content: [
      'Teile große Verwaltungsschritte in Mikroaufgaben: Unterlagen prüfen, Kontaktperson recherchieren, Termin vereinbaren. Jede erledigte Mikroaufgabe gibt Dir Momentum.',
      'Lege einen klaren Dokumenten-Spot an – digital oder physisch. Jedes Dokument bekommt sofort seinen Platz. So reduzierst Du Suchzeiten und Stress deutlich.',
      'Plane wöchentliche Behördenfenster ein. 45 Minuten reichen, um offene Punkte zu sichten. Blocke die Zeit im Kalender, damit Verwaltung zur Routine wird, statt zum Dauerproblem.'
    ]
  }
];

export const blogCategories = ['Alle', 'Alltag', 'Community', 'Organisation'];