document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            navToggle.classList.toggle('is-active');
            siteNav.classList.toggle('is-visible');
        });

        siteNav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.innerWidth < 768) {
                    navToggle.classList.remove('is-active');
                    siteNav.classList.remove('is-visible');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
        const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
        const storageKey = 'voluntra_cookie_consent';
        const consent = localStorage.getItem(storageKey);

        if (!consent) {
            setTimeout(function () {
                cookieBanner.classList.add('is-visible');
                cookieBanner.classList.add('fade-in');
            }, 600);
        }

        const handleConsent = function (value) {
            localStorage.setItem(storageKey, value);
            cookieBanner.classList.remove('is-visible');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                handleConsent('accepted');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                handleConsent('declined');
            });
        }
    }

    const searchInput = document.querySelector('#searchInput');
    const categoryFilter = document.querySelector('#categoryFilter');
    const postCards = document.querySelectorAll('[data-post-card]');

    if (postCards.length) {
        const filterPosts = function () {
            const searchTerm = searchInput ? searchInput.value.trim().toLowerCase() : '';
            const selectedCategory = categoryFilter ? categoryFilter.value : 'toate';

            postCards.forEach(function (card) {
                const title = card.querySelector('h3') ? card.querySelector('h3').textContent.toLowerCase() : '';
                const summary = card.querySelector('p') ? card.querySelector('p').textContent.toLowerCase() : '';
                const category = card.getAttribute('data-category');
                const matchesSearch = !searchTerm || title.includes(searchTerm) || summary.includes(searchTerm);
                const matchesCategory = selectedCategory === 'toate' || selectedCategory === category;

                if (matchesSearch && matchesCategory) {
                    card.style.display = '';
                    card.classList.add('fade-in');
                } else {
                    card.style.display = 'none';
                }
            });
        };

        if (searchInput) {
            searchInput.addEventListener('input', filterPosts);
        }
        if (categoryFilter) {
            categoryFilter.addEventListener('change', filterPosts);
        }
    }
});