document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', () => {
            const isOpen = navLinks.classList.toggle('is-open');
            menuToggle.classList.toggle('is-active', isOpen);
            menuToggle.setAttribute('aria-expanded', String(isOpen));
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('is-open')) {
                    navLinks.classList.remove('is-open');
                    menuToggle.classList.remove('is-active');
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const storedPreference = localStorage.getItem('hunchbbagtCookiePreference');

    if (cookieBanner && storedPreference) {
        cookieBanner.classList.add('is-hidden');
    }

    const cookieButtons = document.querySelectorAll('[data-cookie-action]');
    cookieButtons.forEach(button => {
        button.addEventListener('click', event => {
            const action = button.getAttribute('data-cookie-action');
            if (action) {
                localStorage.setItem('hunchbbagtCookiePreference', action);
            }
            if (cookieBanner) {
                cookieBanner.classList.add('is-hidden');
            }
        });
    });
});