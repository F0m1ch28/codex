document.addEventListener('DOMContentLoaded', function () {
    const banner = document.querySelector('.cookie-banner');
    if (banner) {
        const acceptBtn = banner.querySelector('.cookie-accept');
        const declineBtn = banner.querySelector('.cookie-decline');
        const consent = localStorage.getItem('ablazeCookieConsent');
        if (!consent) {
            banner.classList.add('active');
        }
        acceptBtn.addEventListener('click', function () {
            localStorage.setItem('ablazeCookieConsent', 'accepted');
            banner.classList.remove('active');
        });
        declineBtn.addEventListener('click', function () {
            localStorage.setItem('ablazeCookieConsent', 'declined');
            banner.classList.remove('active');
        });
    }
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('nav a').forEach(function (link) {
        if (link.getAttribute('href') === currentPage) {
            link.setAttribute('aria-current', 'page');
        }
    });
});