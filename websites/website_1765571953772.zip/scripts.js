document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');
  const navLinks = document.querySelectorAll('.main-nav .nav-link');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      body.classList.toggle('nav-open');
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        body.classList.remove('nav-open');
      });
    });
  }

  const currentYear = document.getElementById('current-year');
  if (currentYear) {
    currentYear.textContent = new Date().getFullYear();
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptButton = document.getElementById('cookie-accept');
  const declineButton = document.getElementById('cookie-decline');

  if (cookieBanner && acceptButton && declineButton) {
    const consent = localStorage.getItem('ql-cookie-consent');

    if (!consent) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add('is-visible');
      });
    } else {
      cookieBanner.classList.add('is-hidden');
    }

    acceptButton.addEventListener('click', () => {
      localStorage.setItem('ql-cookie-consent', 'accepted');
      cookieBanner.classList.remove('is-visible');
      cookieBanner.classList.add('is-hidden');
    });

    declineButton.addEventListener('click', () => {
      localStorage.setItem('ql-cookie-consent', 'declined');
      cookieBanner.classList.remove('is-visible');
      cookieBanner.classList.add('is-hidden');
    });
  }
});