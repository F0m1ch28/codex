(function () {
  const audioSource = "assets/audio/maximum-volume-loop.mp3";
  const internalLinkSelector = 'a.internal-link[href]';
  const localStorageKeys = {
    cookies: "mvx.cookiesConsent"
  };
  const historyStateKey = "mvx:state";

  class AudioManager {
    constructor() {
      if (window.__MaximumAudioInstance) {
        return window.__MaximumAudioInstance;
      }
      this.audio = new Audio(audioSource);
      this.audio.loop = true;
      this.audio.preload = "auto";
      this.audio.volume = 1;
      this.audio.crossOrigin = "anonymous";
      this.audio.autoplay = true;
      this.isReady = false;
      this.isPlaying = false;
      this.lastRequestedVolume = 1;
      this.unlockRequired = false;
      this.visualizerBars = [];
      this.statusElement = null;
      this.indicatorElement = null;
      this.volumeValueElement = null;
      this.volumeSliderElement = null;
      this.toggleButtonElement = null;
      this.unlockOverlay = null;
      window.__MaximumAudioInstance = this;
      this._bootstrap();
    }

    async _bootstrap() {
      try {
        await this.audio.play();
        this.isReady = true;
        this.isPlaying = true;
        this._updateUI();
      } catch (error) {
        this.unlockRequired = true;
        this.isPlaying = false;
        this._showUnlockOverlay();
      }
      this._bindEvents();
    }

    _bindEvents() {
      this.audio.addEventListener("play", () => {
        this.isPlaying = true;
        this._updateUI();
      });
      this.audio.addEventListener("pause", () => {
        this.isPlaying = false;
        this._updateUI();
      });
      this.audio.addEventListener("volumechange", () => {
        this.lastRequestedVolume = this.audio.volume;
        this._updateUI();
      });
      window.addEventListener("focus", () => {
        if (this.isReady && !this.audio.paused) {
          this.audio.volume = this.lastRequestedVolume;
        }
      });
    }

    _showUnlockOverlay() {
      if (!this.unlockOverlay) {
        this.unlockOverlay = document.getElementById("audio-unlock");
      }
      if (this.unlockOverlay) {
        this.unlockOverlay.classList.add("is-active");
        const callToAction = this.unlockOverlay.querySelector("[data-audio-unlock]");
        if (callToAction) {
          callToAction.addEventListener("click", () => this.forcePlay(), { once: true });
        }
      }
    }

    async forcePlay() {
      try {
        this.audio.volume = 1;
        this.lastRequestedVolume = 1;
        await this.audio.play();
        this.isReady = true;
        this.isPlaying = true;
        this.unlockRequired = false;
        if (this.unlockOverlay) {
          this.unlockOverlay.classList.remove("is-active");
        }
        this._updateUI();
      } catch (error) {
        console.warn("Автозапуск отклонён:", error);
        this._showUnlockOverlay();
      }
    }

    togglePlayback() {
      if (!this.isReady) {
        this.forcePlay();
        return;
      }
      if (this.audio.paused) {
        this.audio.play().catch(() => this._showUnlockOverlay());
      } else {
        this.audio.pause();
      }
    }

    setVolume(percent) {
      const normalized = Math.min(1, Math.max(0, percent / 100));
      this.lastRequestedVolume = normalized;
      this.audio.volume = normalized;
      if (this.audio.paused) {
        this.audio.play().catch(() => this._showUnlockOverlay());
      }
      this._updateUI();
    }

    registerControls({ status, indicator, volumeValue, slider, toggle, visualizer }) {
      this.statusElement = status || this.statusElement;
      this.indicatorElement = indicator || this.indicatorElement;
      this.volumeValueElement = volumeValue || this.volumeValueElement;
      this.volumeSliderElement = slider || this.volumeSliderElement;
      this.toggleButtonElement = toggle || this.toggleButtonElement;
      this.visualizerBars = visualizer || this.visualizerBars;
      if (this.volumeSliderElement) {
        this.volumeSliderElement.value = Math.round(this.audio.volume * 100);
      }
      this._updateUI();
    }

    _updateUI() {
      const statusText = this.isPlaying ? "Идет воспроизведение на максимальной интенсивности" : "Аудио приостановлено";
      const volumePercent = Math.round(this.audio.volume * 100);
      if (this.statusElement) {
        this.statusElement.textContent = `${statusText} · ${volumePercent}%`;
      }
      if (this.volumeValueElement) {
        this.volumeValueElement.textContent = `${volumePercent}%`;
      }
      if (this.indicatorElement) {
        this.indicatorElement.classList.toggle("is-paused", !this.isPlaying);
      }
      if (this.visualizerBars.length) {
        this.visualizerBars.forEach(bar => {
          bar.classList.toggle("is-paused", !this.isPlaying);
        });
      }
      if (this.toggleButtonElement) {
        this.toggleButtonElement.textContent = this.isPlaying ? "Пауза" : "Воспроизвести";
      }
      if (this.volumeSliderElement && document.activeElement !== this.volumeSliderElement) {
        this.volumeSliderElement.value = volumePercent;
      }
    }
  }

  const audioManager = new AudioManager();

  function initializeControls() {
    const status = document.querySelector("[data-audio-status]");
    const indicator = document.querySelector("[data-audio-indicator]");
    const volumeValue = document.querySelector("[data-volume-value]");
    const slider = document.querySelector("[data-volume-slider]");
    const toggle = document.querySelector("[data-audio-toggle]");
    const visualizer = Array.from(document.querySelectorAll("[data-audio-bar]"));
    audioManager.registerControls({ status, indicator, volumeValue, slider, toggle, visualizer });

    if (slider && !slider.dataset.bound) {
      slider.addEventListener("input", event => {
        audioManager.setVolume(parseInt(event.target.value, 10) || 0);
      });
      slider.dataset.bound = "true";
    }

    if (toggle && !toggle.dataset.bound) {
      toggle.addEventListener("click", () => audioManager.togglePlayback());
      toggle.dataset.bound = "true";
    }

    const unlockButton = document.querySelector("[data-audio-unlock]");
    if (unlockButton && !unlockButton.dataset.bound) {
      unlockButton.addEventListener("click", () => audioManager.forcePlay());
      unlockButton.dataset.bound = "true";
    }
  }

  function updateActiveNavigation(currentPath) {
    const links = document.querySelectorAll(internalLinkSelector);
    links.forEach(link => {
      const isActive = new URL(link.href, window.location.href).pathname === currentPath;
      link.classList.toggle("is-active", isActive);
      if (isActive) {
        link.setAttribute("aria-current", "page");
      } else {
        link.removeAttribute("aria-current");
      }
    });
  }

  function replaceMainContent(documentFragment) {
    const newMain = documentFragment.querySelector("main");
    const currentMain = document.querySelector("main");
    if (newMain && currentMain) {
      currentMain.className = newMain.className;
      currentMain.innerHTML = newMain.innerHTML;
    }
    const newBody = documentFragment.querySelector("body");
    if (newBody) {
      const pageId = newBody.getAttribute("data-page");
      if (pageId) {
        document.body.setAttribute("data-page", pageId);
      } else {
        document.body.removeAttribute("data-page");
      }
    }
  }

  async function handleNavigation(url, push = true) {
    const targetURL = new URL(url, window.location.origin);
    if (targetURL.origin !== window.location.origin) {
      window.location.href = targetURL.href;
      return;
    }
    if (targetURL.pathname === window.location.pathname) {
      return;
    }
    try {
      const response = await fetch(targetURL.pathname, {
        headers: {
          "X-Requested-With": "maximum-volume-experience"
        }
      });
      const html = await response.text();
      const parser = new DOMParser();
      const nextDocument = parser.parseFromString(html, "text/html");
      replaceMainContent(nextDocument);
      document.title = nextDocument.title;
      updateActiveNavigation(targetURL.pathname);
      initializeControls();
      initializeDynamicContent();
      window.scrollTo({ top: 0, behavior: "smooth" });
      if (push) {
        history.pushState({ [historyStateKey]: targetURL.pathname }, "", targetURL.pathname);
      }
    } catch (error) {
      console.error("Ошибка при загрузке страницы:", error);
      window.location.href = targetURL.href;
    }
  }

  function bindNavigation() {
    document.addEventListener("click", event => {
      const anchor = event.target.closest(internalLinkSelector);
      if (!anchor) {
        return;
      }
      const targetURL = anchor.getAttribute("href");
      if (!targetURL || targetURL.startsWith("http") || targetURL.startsWith("#") || targetURL.startsWith("mailto:")) {
        return;
      }
      event.preventDefault();
      handleNavigation(targetURL);
    });

    window.addEventListener("popstate", event => {
      const requestedPath = event.state && event.state[historyStateKey] ? event.state[historyStateKey] : window.location.pathname;
      handleNavigation(requestedPath, false);
    });
  }

  function initializeCookieBanner() {
    const banner = document.getElementById("cookieBanner");
    if (!banner) {
      return;
    }
    const storedChoice = localStorage.getItem(localStorageKeys.cookies);
    if (!storedChoice) {
      requestAnimationFrame(() => {
        banner.classList.add("is-visible");
      });
    }
    const acceptButton = banner.querySelector("[data-cookie-accept]");
    const declineButton = banner.querySelector("[data-cookie-decline]");
    if (acceptButton && !acceptButton.dataset.bound) {
      acceptButton.addEventListener("click", () => {
        localStorage.setItem(localStorageKeys.cookies, "accepted");
        banner.classList.remove("is-visible");
      });
      acceptButton.dataset.bound = "true";
    }
    if (declineButton && !declineButton.dataset.bound) {
      declineButton.addEventListener("click", () => {
        localStorage.setItem(localStorageKeys.cookies, "declined");
        banner.classList.remove("is-visible");
      });
      declineButton.dataset.bound = "true";
    }
  }

  function initializeDynamicContent() {
    const glowTargets = document.querySelectorAll("[data-glow]");
    glowTargets.forEach(target => {
      if (!target.dataset.bound) {
        target.addEventListener("pointermove", event => {
          const rect = target.getBoundingClientRect();
          const glow = target.querySelector(".glow");
          if (glow) {
            const x = ((event.clientX - rect.left) / rect.width) * 100;
            const y = ((event.clientY - rect.top) / rect.height) * 100;
            glow.style.setProperty("--x", `${x}%`);
            glow.style.setProperty("--y", `${y}%`);
          }
        });
        target.dataset.bound = "true";
      }
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    initializeControls();
    updateActiveNavigation(window.location.pathname);
    bindNavigation();
    initializeCookieBanner();
    initializeDynamicContent();
  });
})();