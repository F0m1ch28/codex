document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.site-nav');
    if (navToggle && nav) {
        navToggle.addEventListener('click', function () {
            nav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', nav.classList.contains('open'));
        });

        document.addEventListener('click', function (event) {
            if (!nav.contains(event.target) && !navToggle.contains(event.target)) {
                nav.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const hasConsent = localStorage.getItem('dlCookieConsent');
        if (!hasConsent) {
            cookieBanner.classList.add('active');
        }
        const acceptBtn = cookieBanner.querySelector('.cookie-button.accept');
        const declineBtn = cookieBanner.querySelector('.cookie-button.decline');

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                localStorage.setItem('dlCookieConsent', 'accepted');
                cookieBanner.classList.remove('active');
                window.open('cookies.html', '_blank');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                localStorage.setItem('dlCookieConsent', 'declined');
                window.location.href = 'cookies.html';
            });
        }
    }
});