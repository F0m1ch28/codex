import React, { useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion, useMotionValue, useTransform } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { FiArrowRight, FiExternalLink, FiLinkedin, FiTwitter } from 'react-icons/fi';
import { blogPosts } from '../data/posts';

const heroImage = 'https://picsum.photos/1600/900?random=311';
const featureImage = 'https://picsum.photos/800/600?random=312';
const teamImageBase = 'https://picsum.photos/400/400?';

const stats = [
  { label: 'Published Essays', value: 184, suffix: '', description: 'Curated research on developer workflows and systems thinking.' },
  { label: 'Practitioner Interviews', value: 67, suffix: '', description: 'Conversations with platform engineers and staff technologists.' },
  { label: 'Signals Catalogued', value: 142, suffix: '', description: 'Observable patterns across tooling, culture, and cloud strategy.' },
  { label: 'Newsletter Subscribers', value: 9230, suffix: '+', description: 'Engineering leaders staying current with DevLayer intelligence.' }
];

const featuredEssays = blogPosts;
const workflowPatterns = [
  {
    title: 'Pipeline Observability Windows',
    description:
      'Instrument CI/CD pipelines with domain-aligned telemetry. Layer synthetic spans over build steps to expose variance in compile, test, and deploy phases.',
    topics: ['CI/CD analytics', 'Build orchestration', 'Release cadence']
  },
  {
    title: 'Intentional IDE Ergonomics',
    description:
      'Model IDE ergonomics as a product surface. Audit extension sets, default templates, and workspace hydration to reduce onboarding friction.',
    topics: ['IDE ergonomics', 'Developer experience', 'Tool calibration']
  },
  {
    title: 'Branch Health Protocols',
    description:
      'Use merge health dashboards to visualize branch age, code review depth, and dependency drift. Align rituals that keep delivery stable.',
    topics: ['Version control', 'Release rituals', 'Quality gates']
  }
];

const mindsetNarratives = [
  {
    title: 'Cognitive Load Mapping',
    description:
      'Map cognitive load against codebase topology. Identify areas where mental models fragment and use pairing to stabilize shared understanding.',
    quote:
      'Teams that share cognitive scaffolding reduce defect rates by 23% across six sprints of observation.',
    author: 'DevLayer Field Study'
  },
  {
    title: 'Flow State Guardrails',
    description:
      'Define guardrails that protect maker time. Champion asynchronous update models, explicit focus windows, and backlog hygiene that respects deep work.',
    quote:
      'Calibrated focus windows produce reliable throughput and calmer retrospectives.',
    author: 'DevLayer Observability Lab'
  }
];

const toolingSignals = [
  {
    name: 'Runtime Feature Flags',
    signal:
      'Runtime controls move from static toggles to adaptive evaluation with telemetry-based ramping.',
    impact: 'Improves safety for progressive delivery and experiments.',
    trend: 'Widespread among platform squads by Q3 2024.'
  },
  {
    name: 'Portable Environments',
    signal:
      'Developer workspaces shift to containerized blueprints with deterministic boot.',
    impact: 'Cuts onboarding time and reduces configuration drift.',
    trend: 'Adopted by remote-first engineering teams.'
  },
  {
    name: 'Cross-Stack Infra DSLs',
    signal:
      'Infrastructure teams embrace generative DSLs that compile to Terraform and Kubernetes artifacts with guardrails baked in.',
    impact: 'Gives platform engineers reproducible patterns and policy compliance.',
    trend: 'Rising across cloud-scale organizations.'
  }
];

const highlights = [
  {
    title: 'From Incident Data to Cultural Learning',
    summary:
      'We examine post-incident rituals that transform raw data into actionable culture shifts.',
    link: '/mindset'
  },
  {
    title: 'Tracing Build-to-Deploy Latency',
    summary:
      'Latency between build completion and deploy readiness reveals the true cost of manual gates.',
    link: '/workflows'
  },
  {
    title: 'Designing a Platform Operations Nerve Center',
    summary:
      'How platform teams orchestrate signals across observability, change management, and service ownership.',
    link: '/services'
  }
];

const readingQueue = [
  {
    title: 'The Cognitive Architecture of Debugging',
    author: 'DevLayer Research Desk',
    tags: ['engineering psychology', 'debugging'],
    link: '/queue#cognitive-architecture'
  },
  {
    title: 'Resilience Patterns in Distributed Coordination',
    author: 'Field Guide Series',
    tags: ['distributed computing', 'cloud infrastructure'],
    link: '/queue#resilience-patterns'
  },
  {
    title: 'Pairing Rituals for Platform Teams',
    author: 'DevLayer Interviews',
    tags: ['platform engineering', 'team rituals'],
    link: '/queue#pairing-rituals'
  }
];

const processSteps = [
  {
    title: 'Signal Intake',
    description:
      'We collect field data from engineering leaders, platform teams, and developer productivity researchers across Canada and beyond.'
  },
  {
    title: 'Pattern Mining',
    description:
      'Patterns are distilled using comparative analysis across distributed teams, focusing on reproducible workflows and tooling signals.'
  },
  {
    title: 'Editorial Craft',
    description:
      'Our editors translate raw insights into narratives with diagrams, practical heuristics, and actionable recommendations.'
  },
  {
    title: 'Review & Validation',
    description:
      'Every piece undergoes technical review by practitioners to ensure accuracy and relevance for builders.'
  },
  {
    title: 'Signal Amplification',
    description:
      'Insights are shared across essays, newsletters, and briefings to help organizations steer engineering culture with clarity.'
  }
];

const testimonials = [
  {
    quote:
      'DevLayer helped our platform guild articulate pipeline health metrics that resonated across product and infrastructure teams.',
    author: 'Lena Cho',
    role: 'Director of Platform Engineering, Riverline',
    avatar: 'https://picsum.photos/160/160?random=415'
  },
  {
    quote:
      'The editorial rigor and practitioner interviews have become required reading for our staff engineers mentoring emergent teams.',
    author: 'Diego Fernandes',
    role: 'Principal Engineer, Northwind Labs',
    avatar: 'https://picsum.photos/160/160?random=416'
  },
  {
    quote:
      'Their coverage on cognitive load mapping reshaped how we approach system design reviews and documentation debt.',
    author: 'Hannah Patel',
    role: 'Engineering Manager, Aurora Systems',
    avatar: 'https://picsum.photos/160/160?random=417'
  }
];

const teamMembers = [
  {
    name: 'Amelia Kwan',
    role: 'Editor-in-Chief',
    focus: 'Governance of developer workflows and system resilience.',
    image: `${teamImageBase}random=501`,
    bio: 'Former staff engineer at cloud-scale fintech platforms. Specializes in weaving platform telemetry into narrative arcs.'
  },
  {
    name: 'Mikael Dubois',
    role: 'Head of Research',
    focus: 'Distributed systems, observability, and adaptive infrastructure patterns.',
    image: `${teamImageBase}random=502`,
    bio: 'Leads longitudinal studies on deployment cadence, reliability, and cross-functional alignment.'
  },
  {
    name: 'Priya Sharma',
    role: 'Culture Editor',
    focus: 'Engineering psychology, leadership rituals, and collaborative practice design.',
    image: `${teamImageBase}random=503`,
    bio: 'Former agile coach guiding platform teams across North America; facilitates qualitative interviews for DevLayer.'
  }
];

const projectGallery = [
  {
    title: 'Platform Benchmark Atlas',
    category: 'Platform',
    description:
      'A layered benchmark library mapping CI/CD lead time, deployment safety, and team rituals across 28 organizations.',
    image: 'https://picsum.photos/1200/800?random=611'
  },
  {
    title: 'Cognitive Load Field Study',
    category: 'Research',
    description:
      'Integrated qualitative interviews and telemetry to understand cognitive strain in distributed product squads.',
    image: 'https://picsum.photos/1200/800?random=612'
  },
  {
    title: 'Cloud Pattern Observatory',
    category: 'Systems',
    description:
      'Catalog of reusable infrastructure patterns with decision matrices for multi-cloud environments.',
    image: 'https://picsum.photos/1200/800?random=613'
  },
  {
    title: 'Developer Workflow Diagnostics',
    category: 'Experience',
    description:
      'Assessment toolkit measuring friction in onboarding, code review, and feedback loops within engineering organizations.',
    image: 'https://picsum.photos/1200/800?random=614'
  }
];

const faqItems = [
  {
    question: 'How does DevLayer select editorial topics?',
    answer:
      'We maintain a signal backlog informed by practitioner interviews, field research, and ongoing monitoring of developer tooling ecosystems. Topics are prioritized when they reveal emerging patterns across multiple teams or address recurring pain points in platform engineering.'
  },
  {
    question: 'Do you collaborate with organizations on bespoke research?',
    answer:
      'Yes. We produce tailored briefings, workflow diagnostics, and narrative playbooks for engineering orgs. Reach out through our contact form to co-design a research engagement.'
  },
  {
    question: 'How frequently do you publish new essays?',
    answer:
      'We release long-form essays twice per month, supported by weekly notes and curated reading queues that surface foundational resources.'
  },
  {
    question: 'Can I contribute to DevLayer?',
    answer:
      'We welcome proposals from experienced engineers, SREs, and technical writers. Share your idea through the contact page and include previous writing samples or talks.'
  }
];

const Home = () => {
  const [counters, setCounters] = useState(stats.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [projectFilter, setProjectFilter] = useState('All');
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState('');
  const navigate = useNavigate();

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'All') return projectGallery;
    return projectGallery.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  useEffect(() => {
    let frame;
    const duration = 1600;
    const start = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - start) / duration, 1);
      setCounters(
        stats.map((stat) => Math.floor(stat.value * progress))
      );
      if (progress < 1) {
        frame = requestAnimationFrame(animate);
      }
    };

    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const radial = useMotionValue(0);
  const rotate = useTransform(radial, [0, 1], ['-8deg', '8deg']);

  const handleNewsletterSubmit = (e) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newsletterEmail.trim())) {
      setNewsletterStatus('Please enter a valid email address.');
      return;
    }
    setNewsletterStatus('Thank you for subscribing to DevLayer insights.');
    setNewsletterEmail('');
  };

  const activeTestimonial = testimonials[testimonialIndex];

  return (
    <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950">
      <Helmet>
        <title>DevLayer | Developer Workflows, Cloud Infrastructure & Engineering Culture</title>
        <meta
          name="description"
          content="DevLayer is a Toronto-based editorial platform covering developer workflows, software systems, cloud infrastructure, platform engineering, and DevOps culture."
        />
        <meta
          name="keywords"
          content="developer workflows, software systems, cloud infrastructure, platform engineering, devops culture, technical writing, distributed computing, engineering psychology"
        />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Organization',
            name: 'DevLayer',
            url: 'https://www.devlayer.com',
            logo: 'https://www.devlayer.com/logo192.png',
            sameAs: [
              'https://github.com/devlayer',
              'https://www.linkedin.com/company/devlayer',
              'mailto:editorial@devlayer.com'
            ],
            address: {
              '@type': 'PostalAddress',
              streetAddress: '333 Bay St',
              addressLocality: 'Toronto',
              addressRegion: 'ON',
              postalCode: 'M5H 2R2',
              addressCountry: 'Canada'
            },
            contactPoint: {
              '@type': 'ContactPoint',
              telephone: '+1-416-905-6621',
              contactType: 'editorial'
            }
          })}
        </script>
      </Helmet>

      <section className="relative overflow-hidden">
        <motion.div
          style={{ rotate }}
          className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(233,_69,_96,_0.08),_transparent_55%)]"
        />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-20 relative">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <motion.div
              className="lg:col-span-6 space-y-8"
              initial={{ opacity: 0, y: 32 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
            >
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-accent/15 text-accent-light text-xs font-semibold border border-accent/20">
                Every Layer Tells a Story
              </span>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-heading font-semibold leading-tight text-surface-50">
                Editorial intelligence for developer workflows, systems, and culture.
              </h1>
              <p className="text-lg text-surface-200 max-w-xl leading-relaxed">
                We decode how software organizations build reliable platforms, align
                teams, and sustain technical excellence. Our essays blend qualitative
                research, telemetry, and practitioner voices from the field.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onMouseEnter={() => radial.set(1)}
                  onMouseLeave={() => radial.set(0)}
                  onClick={() => navigate('#featured')}
                  className="btn-primary"
                >
                  Explore Featured Essays <FiArrowRight className="h-4 w-4" />
                </button>
                <Link to="/blog" className="btn-secondary">
                  Browse Full Archive
                </Link>
              </div>
            </motion.div>
            <motion.div
              className="lg:col-span-6 relative"
              initial={{ opacity: 0, y: 32 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: 'easeOut' }}
            >
              <div className="glass-panel rounded-3xl overflow-hidden border border-surface-800/50 shadow-hero">
                <img
                  src={heroImage}
                  alt="Developers collaborating with layered system diagrams"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                <div className="bg-surface-900/80 backdrop-blur-lg px-6 py-5 space-y-3">
                  <p className="text-sm text-accent-light font-semibold uppercase tracking-[0.2em]">
                    Field Signals
                  </p>
                  <p className="text-sm text-surface-200 leading-relaxed">
                    Toronto-based research uncovering rituals and infrastructure that
                    keep engineering resilient at scale.
                  </p>
                  <div className="flex gap-3">
                    <span className="badge">Platform Engineering</span>
                    <span className="badge">Developer Workflows</span>
                    <span className="badge">Engineering Culture</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="relative py-20 bg-surface-950/60" id="stats">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(15,52,96,0.15),_transparent_55%)]" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-heading">Metrics that guide our editorial compass</h2>
          <p className="section-subheading max-w-3xl">
            We combine telemetry and qualitative research to surface signals that
            matter to modern engineering organizations.
          </p>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4 mt-12">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                className="glass-panel rounded-2xl border border-surface-800/50 p-6"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ delay: index * 0.1 }}
              >
                <p className="text-4xl font-heading font-semibold text-accent-light">
                  {counters[index]}
                  {stat.suffix}
                </p>
                <p className="mt-3 text-sm font-semibold text-surface-50 uppercase tracking-[0.2em]">
                  {stat.label}
                </p>
                <p className="mt-3 text-sm text-surface-300 leading-relaxed">
                  {stat.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="featured" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
            <div>
              <h2 className="section-heading">Featured essays</h2>
              <p className="section-subheading">
                Curated narratives dissecting developer workflows, platform engineering,
                and cloud-scale decision-making.
              </p>
            </div>
            <Link to="/blog" className="inline-flex items-center gap-2 text-accent-light text-sm font-semibold">
              View all essays <FiExternalLink />
            </Link>
          </div>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {featuredEssays.map((essay, index) => (
              <motion.article
                key={essay.slug}
                className="glass-panel border border-surface-800/50 rounded-3xl overflow-hidden group"
                whileHover={{ y: -6 }}
                transition={{ duration: 0.3 }}
              >
                <div className="relative overflow-hidden">
                  <img
                    src={essay.heroImage}
                    alt={essay.title}
                    className="h-56 w-full object-cover transform transition duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <span className="absolute top-4 left-4 badge">
                    {essay.category}
                  </span>
                </div>
                <div className="p-7 space-y-5">
                  <h3 className="text-xl font-heading text-surface-50 group-hover:text-accent-light transition">
                    {essay.title}
                  </h3>
                  <p className="text-sm text-surface-300 leading-relaxed">
                    {essay.excerpt}
                  </p>
                  <div className="flex items-center justify-between text-xs text-surface-400 uppercase tracking-[0.2em]">
                    <span>{essay.date}</span>
                    <span>{essay.readTime}</span>
                  </div>
                  <Link to={`/blog/${essay.slug}`} className="btn-tertiary">
                    Read the essay <FiArrowRight />
                  </Link>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-surface-950/80" id="workflow-patterns">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <h2 className="section-heading">Workflow Patterns</h2>
            <p className="section-subheading">
              Layered diagnostics across CI/CD, build pipelines, and day-to-day
              engineering rituals.
            </p>
            <img
              src={featureImage}
              alt="CI/CD pipelines visualized with layered metrics"
              className="rounded-3xl border border-surface-800/50 shadow-lg"
              loading="lazy"
            />
          </motion.div>
          <div className="space-y-6">
            {workflowPatterns.map((pattern, index) => (
              <motion.div
                key={pattern.title}
                className="glass-panel rounded-2xl border border-surface-800/60 p-6 hover:border-accent/40 transition"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ delay: index * 0.1 }}
              >
                <h3 className="text-xl font-heading text-surface-50">
                  {pattern.title}
                </h3>
                <p className="mt-3 text-sm text-surface-300 leading-relaxed">
                  {pattern.description}
                </p>
                <div className="flex flex-wrap gap-2 mt-4">
                  {pattern.topics.map((topic) => (
                    <span key={topic} className="chip">
                      {topic}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20" id="developer-mindset">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-12">
          {mindsetNarratives.map((item, index) => (
            <motion.div
              key={item.title}
              className="glass-panel rounded-3xl border border-surface-800/50 p-7 flex flex-col"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ delay: index * 0.1 }}
            >
              <h2 className="text-2xl font-heading text-surface-50">
                {item.title}
              </h2>
              <p className="mt-4 text-sm text-surface-300 leading-relaxed flex-1">
                {item.description}
              </p>
              <blockquote className="mt-6 border-l-2 border-accent/60 pl-4 text-sm text-surface-200 italic">
                “{item.quote}”
              </blockquote>
              <p className="mt-4 text-xs uppercase tracking-[0.2em] text-surface-400">
                {item.author}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="py-20 bg-surface-950/70" id="tooling-signals">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-heading">Tooling Signals</h2>
          <p className="section-subheading">
            Diagnostic signals guiding selection of engineering tools and platforms.
          </p>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {toolingSignals.map((signal) => (
              <motion.div
                key={signal.name}
                className="glass-panel rounded-2xl border border-surface-800/50 p-6"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
              >
                <h3 className="text-lg font-heading text-surface-50">
                  {signal.name}
                </h3>
                <p className="mt-3 text-sm text-surface-300 leading-relaxed">
                  {signal.signal}
                </p>
                <p className="mt-4 text-xs uppercase tracking-[0.2em] text-accent-light">
                  Impact
                </p>
                <p className="text-sm text-surface-200">{signal.impact}</p>
                <p className="mt-4 text-xs uppercase tracking-[0.2em] text-accent-light">
                  Trend
                </p>
                <p className="text-sm text-surface-200">{signal.trend}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20" id="editorial-highlights">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-heading">Editorial Highlights</h2>
          <p className="section-subheading">
            Strategic pieces shaping how engineering organizations view their operating layers.
          </p>
          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            {highlights.map((item, index) => (
              <motion.div
                key={item.title}
                className="glass-panel rounded-2xl border border-surface-800/50 p-6 hover:border-accent/40 transition"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ delay: index * 0.1 }}
              >
                <h3 className="text-xl font-heading text-surface-50">
                  {item.title}
                </h3>
                <p className="mt-3 text-sm text-surface-300 leading-relaxed">
                  {item.summary}
                </p>
                <Link to={item.link} className="btn-tertiary mt-4 inline-flex">
                  Continue reading <FiArrowRight />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-surface-950/80" id="process">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-heading text-center">Editorial Process</h2>
          <p className="section-subheading text-center max-w-3xl mx-auto">
            Our workflow transforms practitioner signals into actionable editorial content grounded in developer experience.
          </p>
          <div className="mt-12 grid gap-6 lg:grid-cols-5">
            {processSteps.map((step, index) => (
              <motion.div
                key={step.title}
                className="glass-panel rounded-2xl border border-surface-800/60 p-6"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ delay: index * 0.08 }}
              >
                <div className="text-sm font-semibold text-accent-light uppercase tracking-[0.3em]">
                  Step {index + 1}
                </div>
                <h3 className="mt-3 text-lg font-heading text-surface-50">
                  {step.title}
                </h3>
                <p className="mt-3 text-sm text-surface-300 leading-relaxed">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20" id="testimonials">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="glass-panel border border-surface-800/60 rounded-3xl overflow-hidden">
            <div className="grid lg:grid-cols-3">
              <div className="bg-gradient-to-br from-surface-900 to-surface-950 p-10">
                <h2 className="text-3xl font-heading text-surface-50">
                  Practitioner reflections
                </h2>
                <p className="mt-4 text-sm text-surface-300 leading-relaxed">
                  Engineering leaders rely on DevLayer insights to align platform
                  strategy, developer workflows, and culture.
                </p>
                <div className="mt-6 flex gap-3">
                  {testimonials.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setTestimonialIndex(idx)}
                      className={`h-2.5 w-8 rounded-full transition ${
                        testimonialIndex === idx
                          ? 'bg-accent-light'
                          : 'bg-surface-700'
                      }`}
                      aria-label={`Show testimonial ${idx + 1}`}
                    />
                  ))}
                </div>
              </div>
              <motion.div
                className="lg:col-span-2 p-10 space-y-6 bg-surface-900/70"
                key={activeTestimonial.author}
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="flex items-center gap-4">
                  <img
                    src={activeTestimonial.avatar}
                    alt={activeTestimonial.author}
                    className="h-16 w-16 rounded-full object-cover border border-surface-700"
                    loading="lazy"
                  />
                  <div>
                    <p className="text-lg font-heading text-surface-50">
                      {activeTestimonial.author}
                    </p>
                    <p className="text-sm text-surface-400">
                      {activeTestimonial.role}
                    </p>
                  </div>
                </div>
                <p className="text-xl leading-relaxed text-surface-100">
                  “{activeTestimonial.quote}”
                </p>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-surface-950/75" id="team">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-heading text-center">Editorial leadership</h2>
          <p className="section-subheading text-center max-w-3xl mx-auto">
            A multidisciplinary team connecting developer workflows, engineering
            psychology, and platform operations.
          </p>
          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {teamMembers.map((member, index) => (
              <motion.div
                key={member.name}
                className="glass-panel rounded-3xl border border-surface-800/60 overflow-hidden group"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className="relative">
                  <img
                    src={member.image}
                    alt={`${member.name} portrait`}
                    className="w-full h-64 object-cover transition duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-surface-950 via-transparent opacity-0 group-hover:opacity-100 transition" />
                </div>
                <div className="p-6 space-y-4">
                  <div>
                    <p className="text-lg font-heading text-surface-50">
                      {member.name}
                    </p>
                    <p className="text-sm text-accent-light font-semibold uppercase tracking-[0.2em]">
                      {member.role}
                    </p>
                  </div>
                  <p className="text-sm text-surface-300 leading-relaxed">
                    {member.focus}
                  </p>
                  <p className="text-sm text-surface-200 leading-relaxed">
                    {member.bio}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20" id="projects">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            <div>
              <h2 className="section-heading">Projects & Studies</h2>
              <p className="section-subheading">
                Initiatives translating research into actionable frameworks for engineering teams.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              {['All', 'Platform', 'Research', 'Systems', 'Experience'].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setProjectFilter(filter)}
                  className={`chip px-4 py-2 ${
                    projectFilter === filter
                      ? 'bg-accent text-surface-50 border-transparent'
                      : ''
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>
          <div className="mt-12 grid gap-8 lg:grid-cols-2">
            {filteredProjects.map((project) => (
              <motion.div
                key={project.title}
                className="glass-panel rounded-3xl border border-surface-800/60 overflow-hidden group"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
              >
                <div className="relative">
                  <img
                    src={project.image}
                    alt={`${project.title} visual`}
                    className="w-full h-64 object-cover transition duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <span className="absolute top-4 left-4 badge">
                    {project.category}
                  </span>
                </div>
                <div className="p-7 space-y-4">
                  <h3 className="text-2xl font-heading text-surface-50">
                    {project.title}
                  </h3>
                  <p className="text-sm text-surface-300 leading-relaxed">
                    {project.description}
                  </p>
                  <button
                    onClick={() => navigate('/services')}
                    className="btn-tertiary inline-flex"
                  >
                    See methodology <FiArrowRight />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-surface-950/85" id="faq">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-heading text-center">Frequently asked questions</h2>
          <div className="mt-10 space-y-4">
            {faqItems.map((item, idx) => (
              <details
                key={item.question}
                className="glass-panel rounded-2xl border border-surface-800/50 px-6 py-4 transition group"
              >
                <summary className="flex items-center justify-between text-lg font-heading text-surface-50 cursor-pointer list-none">
                  {item.question}
                  <span className="text-accent-light text-xl group-open:rotate-45 transition">
                    +
                  </span>
                </summary>
                <p className="mt-3 text-sm text-surface-300 leading-relaxed">
                  {item.answer}
                </p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20" id="reading-queue">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="section-heading">Reading Queue</h2>
          <p className="section-subheading">
            Curated resources grounding modern developer workflows and system design.
          </p>
          <div className="mt-10 space-y-6">
            {readingQueue.map((item) => (
              <motion.div
                key={item.title}
                className="glass-panel rounded-2xl border border-surface-800/60 p-6 text-left"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
              >
                <p className="text-lg font-heading text-surface-50">{item.title}</p>
                <p className="text-xs uppercase tracking-[0.2em] text-surface-400 mt-2">
                  {item.author}
                </p>
                <div className="flex flex-wrap gap-2 mt-4">
                  {item.tags.map((tag) => (
                    <span key={tag} className="chip">
                      {tag}
                    </span>
                  ))}
                </div>
                <Link to={item.link} className="btn-tertiary mt-4 inline-flex">
                  Add to queue <FiArrowRight />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-surface-950/80" id="blog-preview">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-heading text-center">Latest from the logbook</h2>
          <p className="section-subheading text-center max-w-3xl mx-auto">
            Recent essays chart the evolving landscape of platform engineering, cloud infrastructure, and collaborative practice.
          </p>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {blogPosts.slice(0, 3).map((post) => (
              <motion.article
                key={post.slug}
                className="glass-panel rounded-3xl border border-surface-800/50 overflow-hidden group"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
              >
                <img
                  src={post.heroImage}
                  alt={post.title}
                  className="h-48 w-full object-cover transition duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="p-6 space-y-4">
                  <p className="text-xs uppercase tracking-[0.2em] text-accent-light">
                    {post.category}
                  </p>
                  <h3 className="text-lg font-heading text-surface-50">
                    {post.title}
                  </h3>
                  <p className="text-sm text-surface-300 leading-relaxed">
                    {post.excerpt}
                  </p>
                  <Link to={`/blog/${post.slug}`} className="btn-tertiary">
                    Continue reading <FiArrowRight />
                  </Link>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20" id="cta">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="glass-panel rounded-3xl border border-accent/40 bg-gradient-to-r from-surface-950 to-surface-900 p-10 md:p-14 text-center space-y-6">
            <h2 className="text-3xl md:text-4xl font-heading text-surface-50">
              Stay ahead of engineering signals
            </h2>
            <p className="text-lg text-surface-200 max-w-3xl mx-auto">
              Subscribe to our weekly briefing on developer workflows, platform
              engineering, cloud infrastructure, and engineering culture. No noise,
              just practical insight.
            </p>
            <form
              onSubmit={handleNewsletterSubmit}
              className="flex flex-col md:flex-row gap-4 justify-center"
            >
              <input
                type="email"
                name="email"
                className="w-full md:w-80 px-5 py-3 rounded-full bg-surface-900 text-surface-100 border border-surface-700 focus:border-accent focus:outline-none"
                placeholder="your.email@example.com"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                aria-label="Newsletter email"
              />
              <button type="submit" className="btn-primary">
                Join the briefing <FiArrowRight className="h-4 w-4" />
              </button>
            </form>
            {newsletterStatus && (
              <p className="text-sm text-accent-light">{newsletterStatus}</p>
            )}
            <div className="flex justify-center gap-6 text-surface-300 text-sm">
              <a href="https://www.linkedin.com" className="hover:text-accent-light inline-flex items-center gap-2">
                <FiLinkedin /> LinkedIn
              </a>
              <a href="https://www.twitter.com" className="hover:text-accent-light inline-flex items-center gap-2">
                <FiTwitter /> Twitter
              </a>
            </div>
            <p className="text-xs text-surface-400">
              By subscribing, you agree to receive editorial updates aligned with our{' '}
              <Link to="/privacy" className="underline hover:text-accent-light">
                Privacy Policy
              </Link>
              .
            </p>
          </div>
        </div>
      </section>

      <section className="py-10 bg-surface-950/85">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs uppercase tracking-[0.3em] text-surface-400">
          DevLayer content is curated for educational use only. Signals, narratives, and guidance are provided without warranty.
        </div>
      </section>
    </main>
  );
};

export default Home;