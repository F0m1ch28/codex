import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';

const ContactThanks = () => (
  <main className="min-h-screen bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950 flex items-center justify-center px-4">
    <Helmet>
      <title>Thank You | DevLayer Contact</title>
      <meta
        name="description"
        content="Thank you for contacting DevLayer. Our editorial team will respond shortly."
      />
    </Helmet>
    <div className="glass-panel rounded-3xl border border-surface-800/60 p-8 max-w-md text-center space-y-5">
      <span className="badge">Message received</span>
      <h1 className="text-3xl font-heading text-surface-50">Thank you</h1>
      <p className="text-sm text-surface-300 leading-relaxed">
        Our editorial team has received your message and will respond within two business
        days.
      </p>
      <Link to="/" className="btn-primary w-full">
        Return home
      </Link>
    </div>
  </main>
);

export default ContactThanks;