import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

const initialForm = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const Contact = () => {
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Please provide your name.';
    if (!form.email.trim()) {
      newErrors.email = 'Please provide your email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = 'Enter a valid email.';
    }
    if (!form.message.trim()) newErrors.message = 'Tell us about your request.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    setTimeout(() => {
      navigate('/contact/thanks');
    }, 600);
  };

  return (
    <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950">
      <Helmet>
        <title>Contact DevLayer | Editorial & Research Collaborations</title>
        <meta
          name="description"
          content="Contact DevLayer for editorial collaborations, research partnerships, or workflow diagnostics. Located at 333 Bay St, Toronto."
        />
      </Helmet>
      <section className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <span className="badge">Contact</span>
          <h1 className="text-4xl md:text-5xl font-heading text-surface-50">
            Let’s explore your engineering story
          </h1>
          <p className="text-lg text-surface-200 leading-relaxed">
            Reach out to collaborate on editorial projects, platform strategy briefings,
            or research engagements.
          </p>
        </div>
      </section>

      <section className="pb-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 grid gap-10 lg:grid-cols-2">
          <div className="glass-panel rounded-3xl border border-surface-800/60 p-7 space-y-4">
            <h2 className="text-2xl font-heading text-surface-50">Contact details</h2>
            <p className="text-sm text-surface-300">
              DevLayer · Developer-Focused Editorial Platform
            </p>
            <p className="text-sm text-surface-300">
              333 Bay St, Toronto, ON M5H 2R2, Canada
            </p>
            <p className="text-sm text-surface-300">+1 (416) 905-6621</p>
            <p className="text-sm text-surface-300">
              editorial@devlayer.com
            </p>
            <div className="h-64 rounded-2xl overflow-hidden border border-surface-800/60">
              <iframe
                title="DevLayer Toronto Location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2886.357721014711!2d-79.3817062238668!3d43.64868805493485!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d2470cb2fb%3A0x5dffb391d4b2666b!2s333%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202R2!5e0!3m2!1sen!2sca!4v1705086274848!5m2!1sen!2sca"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>

          <motion.form
            onSubmit={handleSubmit}
            className="glass-panel rounded-3xl border border-surface-800/60 p-7 space-y-5"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div>
              <label className="form-label" htmlFor="name">
                Name
              </label>
              <input
                id="name"
                className={`form-input ${errors.name ? 'form-input-error' : ''}`}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Your name"
              />
              {errors.name && <p className="form-error">{errors.name}</p>}
            </div>
            <div>
              <label className="form-label" htmlFor="email">
                Email
              </label>
              <input
                id="email"
                className={`form-input ${errors.email ? 'form-input-error' : ''}`}
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="name@company.com"
              />
              {errors.email && <p className="form-error">{errors.email}</p>}
            </div>
            <div>
              <label className="form-label" htmlFor="company">
                Company or team
              </label>
              <input
                id="company"
                className="form-input"
                value={form.company}
                onChange={(e) => setForm({ ...form, company: e.target.value })}
                placeholder="Company name"
              />
            </div>
            <div>
              <label className="form-label" htmlFor="message">
                Tell us about your goals
              </label>
              <textarea
                id="message"
                className={`form-textarea ${errors.message ? 'form-input-error' : ''}`}
                rows="5"
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                placeholder="Share context for your engagement, timeline, and priorities."
              />
              {errors.message && <p className="form-error">{errors.message}</p>}
            </div>
            <button type="submit" className="btn-primary w-full">
              Submit message
            </button>
          </motion.form>
        </div>
      </section>
    </main>
  );
};

export default Contact;