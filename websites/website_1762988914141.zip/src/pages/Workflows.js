import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const sections = [
  {
    title: 'CI/CD Telemetry',
    description:
      'Instrument pipelines with commit-to-deploy duration metrics, flight path volatility, and rollback frequency. Compare signals against peer benchmarks to prioritize engineering improvements.',
    topics: ['Lead time', 'Deployment safety', 'Progressive delivery']
  },
  {
    title: 'Build Pipeline Ergonomics',
    description:
      'Design builds as modular steps with deterministic caching, incremental compilation, and actionable logs. Map developer friction to concrete backlog items.',
    topics: ['Caching strategy', 'Build reproducibility', 'Feedback loops']
  },
  {
    title: 'IDE & Workspace Calibration',
    description:
      'Treat developer environments as products. Standardize setup scripts, plugin bundles, and template repositories with rapid hydration flows.',
    topics: ['Workspace automation', 'Template libraries', 'Onboarding time']
  },
  {
    title: 'Team Rituals',
    description:
      'Facilitate rituals like async status updates, weekly retros, and code review clinics. Align them with continuous improvement metrics.',
    topics: ['Collaboration', 'Retrospectives', 'Review health']
  }
];

const Workflows = () => (
  <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950">
    <Helmet>
      <title>Workflow Patterns | DevLayer</title>
      <meta
        name="description"
        content="DevLayer workflow patterns covering CI/CD telemetry, build ergonomics, IDE calibration, and team rituals for modern developer productivity."
      />
    </Helmet>
    <section className="pt-24 pb-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
        <span className="badge">Workflow Patterns</span>
        <h1 className="text-4xl md:text-5xl font-heading text-surface-50">
          Operational blueprints for effective developer workflows
        </h1>
        <p className="text-lg text-surface-200 leading-relaxed">
          Our workflow analyses help teams trace the experience layer across pipelines,
          tooling, and collaboration rituals.
        </p>
      </div>
    </section>
    <section className="pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 grid gap-8 md:grid-cols-2">
        {sections.map((section, index) => (
          <motion.div
            key={section.title}
            className="glass-panel rounded-3xl border border-surface-800/60 p-7"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ delay: index * 0.1 }}
          >
            <h2 className="text-2xl font-heading text-surface-50">{section.title}</h2>
            <p className="mt-4 text-sm text-surface-300 leading-relaxed">
              {section.description}
            </p>
            <div className="flex flex-wrap gap-2 mt-4">
              {section.topics.map((topic) => (
                <span key={topic} className="chip">
                  {topic}
                </span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  </main>
);

export default Workflows;