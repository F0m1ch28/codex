import React from 'react';
import { Helmet } from 'react-helmet-async';

const archives = [
  {
    title: 'RFC 5246: The Transport Layer Security Protocol Version 1.2',
    year: 2008,
    link: 'https://www.rfc-editor.org/rfc/rfc5246',
    note: 'Foundation for secure communication patterns.'
  },
  {
    title: 'The Google SRE Book',
    year: 2016,
    link: 'https://sre.google/books/',
    note: 'Operational wisdom for reliability teams.'
  },
  {
    title: 'The Mythical Man-Month',
    year: 1975,
    link: 'https://archive.org/details/mythicalmanmonth00fred',
    note: 'Classic reflections on team dynamics and project timelines.'
  },
  {
    title: 'UNIX Time-Sharing System',
    year: 1974,
    link: 'https://www.bell-labs.com/usr/dmr/www/pdfs/UNIX_Analytic.pdf',
    note: 'Historical look at operating system design.'
  }
];

const Archives = () => (
  <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950">
    <Helmet>
      <title>Archives & Historical Links | DevLayer</title>
      <meta
        name="description"
        content="Historical computer science references, RFCs, and legacy documentation curated by DevLayer."
      />
    </Helmet>
    <section className="pt-24 pb-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
        <span className="badge">Archives</span>
        <h1 className="text-4xl md:text-5xl font-heading text-surface-50">
          Historical references grounding modern practice
        </h1>
        <p className="text-lg text-surface-200 leading-relaxed">
          We honor foundational work that influences current developer workflows,
          distributed computing, and platform engineering.
        </p>
      </div>
    </section>
    <section className="pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {archives.map((entry) => (
          <a
            key={entry.title}
            href={entry.link}
            className="block glass-panel rounded-3xl border border-surface-800/60 p-6 hover:border-accent/40 transition"
          >
            <div className="flex items-center justify-between text-xs uppercase tracking-[0.2em] text-accent-light">
              <span>{entry.year}</span>
              <span>Primary Source</span>
            </div>
            <h2 className="mt-3 text-xl font-heading text-surface-50">
              {entry.title}
            </h2>
            <p className="mt-3 text-sm text-surface-300 leading-relaxed">{entry.note}</p>
          </a>
        ))}
      </div>
    </section>
  </main>
);

export default Archives;