import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useLocation } from 'react-router-dom';
import { blogPosts } from '../../data/posts';
import { FiLinkedin, FiTwitter } from 'react-icons/fi';

const CloudPatternsForScale = () => {
  const location = useLocation();
  const article = blogPosts.find((post) => post.slug === 'cloud-patterns-for-scale');

  if (!article) return null;

  const shareUrl = `https://www.devlayer.com${location.pathname}`;

  return (
    <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950">
      <Helmet>
        <title>{article.title} | DevLayer</title>
        <meta name="description" content={article.metaDescription} />
        <meta name="keywords" content={article.keywords.join(', ')} />
        <meta property="og:title" content={`${article.title} | DevLayer`} />
        <meta property="og:description" content={article.metaDescription} />
        <meta property="og:image" content={article.heroImage} />
        <meta property="og:url" content={shareUrl} />
      </Helmet>
      <article className="pt-24 pb-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <span className="badge">Systems · Cloud Infrastructure</span>
          <h1 className="text-4xl md:text-5xl font-heading text-surface-50 leading-tight">
            Cloud Patterns for Sustainable Scale
          </h1>
          <p className="text-sm text-surface-300 uppercase tracking-[0.2em]">
            {article.author} · {article.date} · {article.readTime}
          </p>
          <img
            src={article.heroImage}
            alt="Cloud infrastructure architecture diagram"
            className="w-full rounded-3xl border border-surface-800/60"
            loading="lazy"
          />
          <p className="article-lead">
            Scaling cloud infrastructure is less about sheer capacity and more about
            resilient patterns. The most mature organizations blend guardrails, observability,
            and cost-aware design to ensure growth is sustainable. This article catalogs
            patterns observed across platform teams operating in multi-region and
            multi-cloud environments.
          </p>

          <h2 className="article-heading">Pattern 1: Policy-driven guardrails</h2>
          <p className="article-paragraph">
            Guardrails evolve from manual checklists into policy-as-code frameworks. By
            codifying deployment policies, platform teams reduce variance and provide
            developer autonomy without sacrificing reliability. Consider mapping policies
            to business outcomes: latency targets, compliance requirements, or cost
            envelopes.
          </p>

          <h2 className="article-heading">Pattern 2: Observability as a service</h2>
          <p className="article-paragraph">
            The most effective teams run observability platforms as internal services.
            They publish blueprints for instrumenting workloads, offer dashboards with
            curated signals, and automate alert hygiene. Teams then use these signals to
            run scenario planning and stress tests before customer traffic exposes weak
            points.
          </p>

          <h2 className="article-heading">Pattern 3: Adaptive capacity planning</h2>
          <p className="article-paragraph">
            Capacity management has moved beyond static thresholds. Leading teams combine
            forecasting models with real-time autoscaling, using insights from product
            roadmaps and historical load. By aligning platform teams with finance and
            product, infrastructure decisions stay grounded in strategic goals.
          </p>

          <div className="glass-panel rounded-2xl border border-surface-800/60 p-6 space-y-3">
            <p className="text-sm text-surface-200 leading-relaxed">
              Cloud patterns succeed when paired with collaborative culture. Encourage
              blameless post-incident reviews, shared dashboards, and cross-functional
              planning sessions to keep infrastructure responsive and sustainable.
            </p>
          </div>

          <div className="flex flex-wrap gap-3 items-center">
            <span className="text-xs uppercase tracking-[0.2em] text-accent-light">
              Share
            </span>
            <a
              href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(
                shareUrl
              )}&text=${encodeURIComponent(article.title)}`}
              className="chip inline-flex items-center gap-2"
            >
              <FiTwitter /> Tweet
            </a>
            <a
              href={`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(
                shareUrl
              )}&title=${encodeURIComponent(article.title)}`}
              className="chip inline-flex items-center gap-2"
            >
              <FiLinkedin /> LinkedIn
            </a>
          </div>
        </div>
      </article>
    </main>
  );
};

export default CloudPatternsForScale;