import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useLocation } from 'react-router-dom';
import { blogPosts } from '../../data/posts';
import { FiLinkedin, FiTwitter } from 'react-icons/fi';

const TheEvolutionOfDevOpsCulture = () => {
  const location = useLocation();
  const article = blogPosts.find(
    (post) => post.slug === 'the-evolution-of-devops-culture'
  );

  if (!article) return null;

  const shareUrl = `https://www.devlayer.com${location.pathname}`;

  return (
    <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950">
      <Helmet>
        <title>{article.title} | DevLayer</title>
        <meta name="description" content={article.metaDescription} />
        <meta name="keywords" content={article.keywords.join(', ')} />
        <meta property="og:title" content={`${article.title} | DevLayer`} />
        <meta property="og:description" content={article.metaDescription} />
        <meta property="og:image" content={article.heroImage} />
        <meta property="og:url" content={shareUrl} />
      </Helmet>
      <article className="pt-24 pb-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <span className="badge">Culture · Platform Engineering</span>
          <h1 className="text-4xl md:text-5xl font-heading text-surface-50 leading-tight">
            The Evolution of DevOps Culture
          </h1>
          <p className="text-sm text-surface-300 uppercase tracking-[0.2em]">
            {article.author} · {article.date} · {article.readTime}
          </p>
          <img
            src={article.heroImage}
            alt="DevOps culture evolution represented in diagrams"
            className="w-full rounded-3xl border border-surface-800/60"
            loading="lazy"
          />
          <p className="article-lead">
            DevOps began as a movement to bridge development and operations. Over time,
            it has matured into a culture of shared accountability, platform ownership,
            and continuous learning. This retrospective traces the evolutionary stages
            and highlights the rituals that keep DevOps relevant.
          </p>

          <h2 className="article-heading">From tooling to culture</h2>
          <p className="article-paragraph">
            Early adoption focused on tooling integration: CI servers, automated
            deployments, shared dashboards. Tooling provided leverage but often left
            cultural silos untouched. Teams that progressed recognized DevOps as a
            cultural contract, not a check-list.
          </p>

          <h2 className="article-heading">Shared ownership patterns</h2>
          <p className="article-paragraph">
            Modern DevOps culture emphasizes shared ownership. Product teams engage in
            on-call rotations, platform engineers enable self-service, and leadership
            supports blameless retrospectives. These rituals create psychological safety
            and accelerate learning cycles.
          </p>

          <h2 className="article-heading">Signals of maturity</h2>
          <ul className="article-list">
            <li>Cross-functional teams share the same goals and service metrics.</li>
            <li>Incident reviews feed into platform improvements, not blame logs.</li>
            <li>Feedback loops exist between developer experience teams and product squads.</li>
            <li>Platform roadmaps are shaped by service owners and infrastructure leads together.</li>
          </ul>

          <h2 className="article-heading">Looking ahead</h2>
          <p className="article-paragraph">
            DevOps continues to evolve with platform engineering. Central teams build
            enabling services while empowering product squads to ship safely. The culture
            thrives when leadership champions continuous improvement and ensures time for
            learning.
          </p>

          <div className="flex flex-wrap gap-3 items-center">
            <span className="text-xs uppercase tracking-[0.2em] text-accent-light">
              Share
            </span>
            <a
              href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(
                shareUrl
              )}&text=${encodeURIComponent(article.title)}`}
              className="chip inline-flex items-center gap-2"
            >
              <FiTwitter /> Tweet
            </a>
            <a
              href={`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(
                shareUrl
              )}&title=${encodeURIComponent(article.title)}`}
              className="chip inline-flex items-center gap-2"
            >
              <FiLinkedin /> LinkedIn
            </a>
          </div>
        </div>
      </article>
    </main>
  );
};

export default TheEvolutionOfDevOpsCulture;