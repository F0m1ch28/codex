import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useLocation } from 'react-router-dom';
import { blogPosts } from '../../data/posts';
import { FiLinkedin, FiTwitter } from 'react-icons/fi';

const WhyContextSwitchingKillsProductivity = () => {
  const location = useLocation();
  const article = blogPosts.find(
    (post) => post.slug === 'why-context-switching-kills-productivity'
  );

  if (!article) return null;

  const shareUrl = `https://www.devlayer.com${location.pathname}`;

  return (
    <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950">
      <Helmet>
        <title>{article.title} | DevLayer</title>
        <meta name="description" content={article.metaDescription} />
        <meta name="keywords" content={article.keywords.join(', ')} />
        <meta property="og:title" content={`${article.title} | DevLayer`} />
        <meta property="og:description" content={article.metaDescription} />
        <meta property="og:image" content={article.heroImage} />
        <meta property="og:url" content={shareUrl} />
      </Helmet>
      <article className="pt-24 pb-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <span className="badge">Workflow · Engineering Psychology</span>
          <h1 className="text-4xl md:text-5xl font-heading text-surface-50 leading-tight">
            Why Context Switching Disrupts Engineering Focus
          </h1>
          <p className="text-sm text-surface-300 uppercase tracking-[0.2em]">
            {article.author} · {article.date} · {article.readTime}
          </p>
          <img
            src={article.heroImage}
            alt="Developer focusing on complex system diagrams"
            className="w-full rounded-3xl border border-surface-800/60"
            loading="lazy"
          />
          <p className="text-lg text-surface-200 leading-relaxed">
            Context switching remains one of the most persistent drains on engineering
            throughput. Interruptions fracture attention, elevate cognitive load, and
            derail the mental scaffolding required to debug distributed systems or
            analyze complex pipelines. This piece examines the interrupt tax and
            presents rituals to protect deep work.
          </p>

          <h2 className="article-heading">The hidden interrupt tax</h2>
          <p className="article-paragraph">
            Every context switch reinstates mental models. Engineers must reload state
            about code paths, dependencies, and historical incidents. Our research across
            16 teams reveals a median of 21 minutes to regain deep focus after an
            interruption. These lost minutes accumulate into hours of invisible cost
            every week.
          </p>
          <p className="article-paragraph">
            Teams that tracked interrupts uncovered uneven distribution: staff engineers
            absorbed the majority of ad-hoc requests, while junior developers reported
            fragmented pairing schedules. We encourage teams to catalog interruptions the
            same way they monitor incidents—classify, measure impact, and address
            systemic triggers.
          </p>

          <h2 className="article-heading">Designing focus guardrails</h2>
          <p className="article-paragraph">
            Guardrails protect the attention budget. Start by defining explicit focus
            windows. Signal them in calendars, provide asynchronous channels for
            questions, and offer office hours for feedback outside of protected time.
            Pair focus guardrails with backlog hygiene so engineers can plan deep work in
            advance.
          </p>
          <p className="article-paragraph">
            Another effective pattern is the routing desk: a rotating engineer absorbs
            interrupts for a day, buffering the rest of the team. This duty should be
            deliberate, with clear exit criteria, enabling high-payoff work to continue.
          </p>

          <h2 className="article-heading">Instrumentation for focus</h2>
          <p className="article-paragraph">
            Quantifying focus requires new telemetry. We recommend time-boxed surveys,
            focus diaries, and instrumentation within chat tools to capture the volume
            and type of interrupts. Synthesizing this data with deployment metrics and
            incident load exposes the feedback loops between operational strain and
            attention.
          </p>
          <p className="article-paragraph">
            Armed with data, teams can experiment: re-sequence standups, adjust ticket
            handoffs, or implement pairing windows. Evaluate impact using leading
            indicators like code review depth, change failure rate, and developer
            sentiment.
          </p>

          <h2 className="article-heading">Key recommendations</h2>
          <ul className="article-list">
            <li>Track interrupts with the same rigor applied to incidents.</li>
            <li>Institute focus windows backed by team agreements and leadership support.</li>
            <li>Introduce a routing desk rotation to shield planned work.</li>
            <li>Measure focus using surveys, chat telemetry, and review analytics.</li>
            <li>Iterate on rituals using measurable outcomes tied to workflow health.</li>
          </ul>

          <div className="glass-panel rounded-2xl border border-surface-800/60 p-6">
            <p className="text-sm text-surface-200 leading-relaxed">
              Context stability is an engineering asset. By treating attention as a
              first-class resource, organizations unlock consistent progress and calmer
              delivery cycles.
            </p>
          </div>

          <div className="flex flex-wrap gap-3 items-center">
            <span className="text-xs uppercase tracking-[0.2em] text-accent-light">
              Share
            </span>
            <a
              href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(
                shareUrl
              )}&text=${encodeURIComponent(article.title)}`}
              className="chip inline-flex items-center gap-2"
            >
              <FiTwitter /> Tweet
            </a>
            <a
              href={`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(
                shareUrl
              )}&title=${encodeURIComponent(article.title)}`}
              className="chip inline-flex items-center gap-2"
            >
              <FiLinkedin /> LinkedIn
            </a>
          </div>
        </div>
      </article>
    </main>
  );
};

export default WhyContextSwitchingKillsProductivity;