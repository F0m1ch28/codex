import React from 'react';
import { Helmet } from 'react-helmet-async';

const notes = [
  {
    title: 'Observability Briefing',
    date: '2024-01-05',
    content:
      'We are gathering feedback on our Observability Diagnostics template. Expect updates to include data instrumentation checklists and narrative guidance for post-incident reviews.',
    tags: ['Observability', 'Research']
  },
  {
    title: 'Newsletter cadence update',
    date: '2023-12-15',
    content:
      'The Signal Dispatch newsletter now ships every Thursday with links to new essays, curated archives, and upcoming community sessions.',
    tags: ['Newsletter', 'Community']
  },
  {
    title: 'Platform benchmark survey',
    date: '2023-11-18',
    content:
      'We opened a new survey focused on platform outcome metrics: lead time, change failure rate, and platform adoption signals. Responses inform upcoming publications.',
    tags: ['Survey', 'Platform Engineering']
  }
];

const Notes = () => (
  <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950">
    <Helmet>
      <title>DevLayer Notes & Platform Updates</title>
      <meta
        name="description"
        content="DevLayer editorial notes covering observability briefings, newsletter cadence, and platform benchmark surveys."
      />
    </Helmet>
    <section className="pt-24 pb-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
        <span className="badge">Notes</span>
        <h1 className="text-4xl md:text-5xl font-heading text-surface-50">
          Ongoing updates from the DevLayer editorial studio
        </h1>
        <p className="text-lg text-surface-200 leading-relaxed">
          Quick signals, announcements, and experiments shaping our coverage.
        </p>
      </div>
    </section>
    <section className="pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {notes.map((note) => (
          <div
            key={note.title}
            className="glass-panel rounded-3xl border border-surface-800/60 p-6"
          >
            <div className="flex items-center justify-between text-xs uppercase tracking-[0.2em] text-accent-light">
              <span>{note.date}</span>
              <span>Update</span>
            </div>
            <h2 className="mt-3 text-xl font-heading text-surface-50">{note.title}</h2>
            <p className="mt-3 text-sm text-surface-300 leading-relaxed">{note.content}</p>
            <div className="flex flex-wrap gap-2 mt-4">
              {note.tags.map((tag) => (
                <span key={tag} className="chip">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  </main>
);

export default Notes;