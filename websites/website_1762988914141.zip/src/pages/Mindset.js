import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const essays = [
  {
    title: 'Decision Journals for Staff Engineers',
    summary:
      'Structured decision journals capture context, trade-offs, and future indicators. They become shared assets for mentorship and retrospective analysis.',
    link: '/blog/why-context-switching-kills-productivity'
  },
  {
    title: 'Calibrating Meeting Load to Protect Focus',
    summary:
      'Quantitative meeting audits highlight the balance between collaboration and maker time. We offer heuristics for adjusting calendars without losing alignment.',
    link: '/notes#meeting-audit'
  },
  {
    title: 'De-risking Knowledge Silos',
    summary:
      'Map domain expertise across teams, design pairing rotations, and build docs that encourage widespread comprehension.',
    link: '/archives#knowledge-silos'
  }
];

const Mindset = () => (
  <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950">
    <Helmet>
      <title>Developer Mindset Essays | DevLayer</title>
      <meta
        name="description"
        content="Insights on developer cognition, focus management, and engineering rituals that sustain healthy team dynamics."
      />
    </Helmet>
    <section className="pt-24 pb-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
        <span className="badge">Developer Mindset</span>
        <h1 className="text-4xl md:text-5xl font-heading text-surface-50">
          Essays exploring cognitive dimensions of engineering
        </h1>
        <p className="text-lg text-surface-200 leading-relaxed">
          We decode how attention, motivation, and team rituals influence the quality of
          software systems and developer experience.
        </p>
      </div>
    </section>
    <section className="pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {essays.map((essay, idx) => (
          <motion.article
            key={essay.title}
            className="glass-panel rounded-3xl border border-surface-800/60 p-7"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ delay: idx * 0.1 }}
          >
            <h2 className="text-2xl font-heading text-surface-50">{essay.title}</h2>
            <p className="mt-3 text-sm text-surface-300 leading-relaxed">
              {essay.summary}
            </p>
            <a href={essay.link} className="btn-tertiary mt-4 inline-flex">
              Read more
            </a>
          </motion.article>
        ))}
      </div>
    </section>
  </main>
);

export default Mindset;