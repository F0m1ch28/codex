import React from 'react';
import { Helmet } from 'react-helmet-async';

const Terms = () => (
  <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950 min-h-screen">
    <Helmet>
      <title>Terms of Use | DevLayer</title>
      <meta
        name="description"
        content="DevLayer terms of use covering intellectual property, acceptable use, and liability."
      />
    </Helmet>
    <section className="pt-24 pb-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <h1 className="text-4xl font-heading text-surface-50">Terms of Use</h1>
        <p className="text-sm text-surface-300 leading-relaxed">
          Effective date: January 2024
        </p>
        <div className="space-y-6 text-sm text-surface-300 leading-relaxed">
          <p>
            By accessing DevLayer, you agree to these terms. DevLayer content is provided
            for informational and educational purposes to support developer workflows,
            software systems research, and engineering culture study.
          </p>
          <h2 className="text-xl font-heading text-surface-50">Intellectual property</h2>
          <p>
            All essays, graphics, and media are owned by DevLayer unless otherwise noted.
            You may reference our work with attribution and links back to DevLayer. Use
            in publications or derivative projects requires written permission.
          </p>
          <h2 className="text-xl font-heading text-surface-50">Acceptable use</h2>
          <p>
            You may not use DevLayer in ways that disrupt service, compromise security,
            or misrepresent our research. Automated scraping is prohibited without prior
            agreement.
          </p>
          <h2 className="text-xl font-heading text-surface-50">Liability</h2>
          <p>
            DevLayer provides information “as is.” We strive for accuracy but cannot be
            responsible for decisions made using our content. Always validate practices
            within your organization’s context.
          </p>
          <h2 className="text-xl font-heading text-surface-50">Changes</h2>
          <p>
            We may update these terms. Continued use after changes indicates acceptance.
          </p>
          <h2 className="text-xl font-heading text-surface-50">Contact</h2>
          <p>
            For questions, email editorial@devlayer.com or write to DevLayer,
            333 Bay St, Toronto, ON M5H 2R2, Canada.
          </p>
        </div>
      </div>
    </section>
  </main>
);

export default Terms;