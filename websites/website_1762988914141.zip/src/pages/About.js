import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const timeline = [
  {
    year: '2018',
    title: 'Origins in Toronto',
    description:
      'DevLayer began as a collective of engineers and technical writers documenting real-world developer workflow experiments across Canadian technology teams.'
  },
  {
    year: '2020',
    title: 'Platform Engineering Focus',
    description:
      'We shifted toward platform engineering stories, amplifying signals from infrastructure teams navigating cloud-native transformations.'
  },
  {
    year: '2022',
    title: 'Field Research Lab',
    description:
      'Launched the DevLayer Field Research Lab to run longitudinal studies on cognitive load, tooling ergonomics, and distributed collaboration.'
  },
  {
    year: '2024',
    title: 'Global Perspective',
    description:
      'Nuestro editorial now spans practitioners across North America, Europe, and APAC to deliver inclusive perspectives on engineering culture.'
  }
];

const values = [
  {
    title: 'Evidence-driven storytelling',
    description:
      'Every essay, interview, and briefing is grounded in verified practitioner experience, data instrumentation, and cross-team observation.'
  },
  {
    title: 'Systems thinking',
    description:
      'We examine the interplay between tooling, process, and culture. Insights are framed as iterative systems rather than isolated quick fixes.'
  },
  {
    title: 'Accessible depth',
    description:
      'Our writing bridges deep technical context and narrative clarity, ensuring staff engineers and product leaders can align on next steps.'
  }
];

const About = () => {
  return (
    <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950">
      <Helmet>
        <title>About DevLayer | Mission, Editorial Values & Methodology</title>
        <meta
          name="description"
          content="Learn about DevLayer's mission, editorial values, research methodology, and history as a developer-focused editorial platform based in Toronto."
        />
        <meta
          name="keywords"
          content="developer workflows, editorial platform, engineering culture, technical writing, platform engineering research"
        />
      </Helmet>
      <section className="pt-24 pb-16">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <span className="badge">Our story</span>
          <h1 className="text-4xl md:text-5xl font-heading text-surface-50">
            Documenting the craft of engineering since 2018
          </h1>
          <p className="text-lg text-surface-200 leading-relaxed">
            DevLayer is a developer-focused editorial platform headquartered in Toronto.
            We chronicle how engineering organizations design workflows, build resilient
            systems, and nurture cultures that sustain technical excellence.
          </p>
        </div>
      </section>

      <section className="pb-16">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 grid gap-10 md:grid-cols-3">
          {values.map((value, idx) => (
            <motion.div
              key={value.title}
              className="glass-panel rounded-3xl border border-surface-800/60 p-7"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.25 }}
              transition={{ delay: idx * 0.1 }}
            >
              <p className="text-xs uppercase tracking-[0.2em] text-accent-light">
                Value {idx + 1}
              </p>
              <h2 className="mt-4 text-xl font-heading text-surface-50">{value.title}</h2>
              <p className="mt-3 text-sm text-surface-300 leading-relaxed">
                {value.description}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="pb-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-heading text-center">Methodology</h2>
          <p className="section-subheading text-center max-w-3xl mx-auto">
            Our editorial methodology combines field interviews, telemetry review, and
            rigorous synthesis to make complex engineering signals accessible.
          </p>
          <div className="mt-12 grid gap-8 md:grid-cols-2">
            <div className="glass-panel rounded-3xl border border-surface-800/50 p-7">
              <h3 className="text-lg font-heading text-surface-50">
                Qualitative research
              </h3>
              <p className="mt-3 text-sm text-surface-300 leading-relaxed">
                We conduct structured interviews with engineering leaders, staff
                engineers, developer productivity teams, and SREs. Insights are coded and
                cross-referenced to identify patterns across org sizes and domains.
              </p>
            </div>
            <div className="glass-panel rounded-3xl border border-surface-800/50 p-7">
              <h3 className="text-lg font-heading text-surface-50">
                Quantitative analysis
              </h3>
              <p className="mt-3 text-sm text-surface-300 leading-relaxed">
                Our research desk reviews telemetry snapshots such as deployment cadence,
                incident statistics, and tooling adoption data to validate practitioner
                narratives and expose root causes.
              </p>
            </div>
            <div className="glass-panel rounded-3xl border border-surface-800/50 p-7">
              <h3 className="text-lg font-heading text-surface-50">Narrative framing</h3>
              <p className="mt-3 text-sm text-surface-300 leading-relaxed">
                Editors translate findings into structured essays, diagrams, and
                playbooks that highlight trade-offs and decision criteria for engineering
                leaders.
              </p>
            </div>
            <div className="glass-panel rounded-3xl border border-surface-800/50 p-7">
              <h3 className="text-lg font-heading text-surface-50">
                Practitioner validation
              </h3>
              <p className="mt-3 text-sm text-surface-300 leading-relaxed">
                Each piece is reviewed by a practitioner cohort to ensure recommendations
                are actionable and grounded in operational realities.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="pb-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-heading text-center">Timeline</h2>
          <div className="mt-12 space-y-6">
            {timeline.map((item) => (
              <div
                key={item.year}
                className="glass-panel rounded-3xl border border-surface-800/50 p-7 flex flex-col md:flex-row md:items-start md:justify-between gap-4"
              >
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-accent-light">
                    {item.year}
                  </p>
                  <h3 className="mt-2 text-xl font-heading text-surface-50">
                    {item.title}
                  </h3>
                </div>
                <p className="text-sm text-surface-300 leading-relaxed md:max-w-xl">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <h2 className="text-3xl font-heading text-surface-50">
            Rooted in Toronto, connected globally
          </h2>
          <p className="text-lg text-surface-200 leading-relaxed">
            DevLayer operates from our studio at 333 Bay St, Toronto, engaging with
            engineers worldwide to surface stories that help teams navigate the future of
            software systems and developer culture.
          </p>
          <div className="flex justify-center gap-4">
            <a href="/services" className="btn-secondary">Explore services</a>
            <a href="/contact" className="btn-primary">
              Collaborate with us
            </a>
          </div>
        </div>
      </section>
    </main>
  );
};

export default About;