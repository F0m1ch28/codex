import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const services = [
  {
    title: 'Editorial Partnerships',
    description:
      'Collaborate with DevLayer editors to produce investigative essays, playbooks, and case studies that reflect your engineering journey.',
    deliverables: ['Narrative workshops', 'Research-backed essays', 'Executive briefings']
  },
  {
    title: 'Workflow Diagnostics',
    description:
      'Assessment frameworks that evaluate CI/CD health, developer tooling ergonomics, and feedback loops across teams.',
    deliverables: ['Telemetry synthesis', 'Workflow maps', 'Recommended experiments']
  },
  {
    title: 'Platform Strategy Briefings',
    description:
      'Custom briefings aligning platform engineering strategy with organizational goals, complete with comparative insights from peer teams.',
    deliverables: ['Strategic insights deck', 'Signals benchmark', 'Leadership Q&A']
  },
  {
    title: 'Culture & Mindset Labs',
    description:
      'Facilitated sessions exploring cognitive load, psychological safety, and rituals that enable sustainable engineering cultures.',
    deliverables: ['Facilitated workshops', 'Practice playbooks', 'Follow-up retrospectives']
  }
];

const engagementSteps = [
  {
    title: 'Discovery',
    detail:
      'We map current challenges, existing telemetry, and desired outcomes through interviews with engineering stakeholders.'
  },
  {
    title: 'Research Sprint',
    detail:
      'Our team conducts qualitative and quantitative research to surface actionable insights tailored to your organization.'
  },
  {
    title: 'Synthesis',
    detail:
      'Insights are distilled into narratives, diagrams, and frameworks ready to share with teams and leadership.'
  },
  {
    title: 'Activation',
    detail:
      'We facilitate sessions, briefings, or labs to activate recommendations and support implementation.'
  }
];

const Services = () => {
  return (
    <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950">
      <Helmet>
        <title>DevLayer Services | Editorial Partnerships & Workflow Diagnostics</title>
        <meta
          name="description"
          content="Discover DevLayer services including editorial partnerships, workflow diagnostics, platform strategy briefings, and culture labs tailored for engineering teams."
        />
      </Helmet>
      <section className="pt-24 pb-16 text-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <span className="badge">Services</span>
          <h1 className="text-4xl md:text-5xl font-heading text-surface-50">
            Partner with DevLayer to surface engineering impact
          </h1>
          <p className="text-lg text-surface-200 leading-relaxed">
            From workflow diagnostics to culture-rich storytelling, DevLayer helps
            engineering leaders illuminate the systems, tools, and mindsets shaping
            their teams.
          </p>
        </div>
      </section>

      <section className="pb-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 grid gap-8 md:grid-cols-2">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              className="glass-panel rounded-3xl border border-surface-800/60 p-7 hover:border-accent/40 transition"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.35 }}
              transition={{ delay: index * 0.1 }}
            >
              <h2 className="text-2xl font-heading text-surface-50">{service.title}</h2>
              <p className="mt-4 text-sm text-surface-300 leading-relaxed">
                {service.description}
              </p>
              <ul className="mt-5 space-y-2 text-sm text-surface-200">
                {service.deliverables.map((item) => (
                  <li key={item} className="flex items-center gap-3">
                    <span className="h-2 w-2 rounded-full bg-accent-light" />
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="pb-20 bg-surface-950/80">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="section-heading">Engagement journey</h2>
          <p className="section-subheading">
            A transparent process from discovery through activation.
          </p>
          <div className="mt-12 grid gap-6 md:grid-cols-4">
            {engagementSteps.map((step, index) => (
              <motion.div
                key={step.title}
                className="glass-panel rounded-2xl border border-surface-800/60 p-6 text-left"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ delay: index * 0.1 }}
              >
                <p className="text-xs uppercase tracking-[0.2em] text-accent-light">
                  Phase {index + 1}
                </p>
                <h3 className="mt-3 text-lg font-heading text-surface-50">{step.title}</h3>
                <p className="mt-3 text-sm text-surface-300 leading-relaxed">
                  {step.detail}
                </p>
              </motion.div>
            ))}
          </div>
          <div className="mt-12 flex justify-center">
            <a href="/contact" className="btn-primary">
              Start a conversation
            </a>
          </div>
        </div>
      </section>
    </main>
  );
};

export default Services;