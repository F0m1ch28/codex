import React from 'react';
import { Helmet } from 'react-helmet-async';

const Privacy = () => (
  <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950 min-h-screen">
    <Helmet>
      <title>Privacy Policy | DevLayer</title>
      <meta
        name="description"
        content="DevLayer privacy policy detailing data collection, cookies, and user rights."
      />
    </Helmet>
    <section className="pt-24 pb-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <h1 className="text-4xl font-heading text-surface-50">Privacy Policy</h1>
        <p className="text-sm text-surface-300 leading-relaxed">
          Effective date: January 2024
        </p>
        <div className="space-y-6 text-sm text-surface-300 leading-relaxed">
          <p>
            DevLayer respects your privacy. This policy explains what data we collect, how
            it is used, and your rights.
          </p>
          <h2 className="text-xl font-heading text-surface-50">Information we collect</h2>
          <p>
            We collect contact details you provide via forms and basic analytics such as
            page views, referrers, and device types. Analytics data helps us understand
            how engineers use the site.
          </p>
          <h2 className="text-xl font-heading text-surface-50">Cookies</h2>
          <p>
            DevLayer uses essential cookies to store preferences and anonymous analytics
            cookies to measure engagement. You can decline analytics cookies via the
            banner displayed on first visit.
          </p>
          <h2 className="text-xl font-heading text-surface-50">How we use data</h2>
          <p>
            Data is used to respond to inquiries, deliver newsletters when requested, and
            improve editorial experiences. We do not sell personal information.
          </p>
          <h2 className="text-xl font-heading text-surface-50">Data retention</h2>
          <p>
            Contact information is retained as long as necessary to respond to inquiries.
            Analytics data is retained for up to 18 months.
          </p>
          <h2 className="text-xl font-heading text-surface-50">Your rights</h2>
          <p>
            You may request access, correction, or deletion of your data by emailing
            privacy@devlayer.com.
          </p>
          <h2 className="text-xl font-heading text-surface-50">Contact</h2>
          <p>
            For privacy questions, email privacy@devlayer.com or write to DevLayer,
            333 Bay St, Toronto, ON M5H 2R2, Canada.
          </p>
        </div>
      </div>
    </section>
  </main>
);

export default Privacy;