import React from 'react';
import { Helmet } from 'react-helmet-async';

const categories = [
  {
    id: 'cognitive-architecture',
    title: 'Engineering Psychology',
    items: [
      'Cognitive Architectures of Debugging - DevLayer Research Desk',
      'Patterns of Flow and Recovery - Platform Practitioners Quarterly',
      'Attention Consent Agreements - Engineering Culture Journal'
    ]
  },
  {
    id: 'resilience-patterns',
    title: 'Distributed Systems',
    items: [
      'Resilience Patterns in Distributed Coordination - DevLayer Field Guide',
      'Adaptive Load Shedding in Cloud Systems - Cloud Signals Report',
      'Service Ownership Narratives - Reliability Roundtable'
    ]
  },
  {
    id: 'pairing-rituals',
    title: 'Team Practices',
    items: [
      'Pairing Rituals for Platform Teams - DevLayer Interviews',
      'Async Collaboration Handbooks - Workflows Magazine',
      'Engineering Leadership Playlists - Sound Practices Podcast'
    ]
  }
];

const Queue = () => (
  <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950">
    <Helmet>
      <title>Reading Queue | DevLayer</title>
      <meta
        name="description"
        content="DevLayer curated reading queue featuring engineering psychology, distributed systems resilience, and platform team rituals."
      />
    </Helmet>
    <section className="pt-24 pb-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
        <span className="badge">Reading Queue</span>
        <h1 className="text-4xl md:text-5xl font-heading text-surface-50">
          Curated reading to deepen your engineering practice
        </h1>
        <p className="text-lg text-surface-200 leading-relaxed">
          Our queue spotlights research, essays, and talks extending the conversations
          we start on DevLayer.
        </p>
      </div>
    </section>
    <section className="pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {categories.map((section) => (
          <div
            key={section.id}
            id={section.id}
            className="glass-panel rounded-3xl border border-surface-800/60 p-7"
          >
            <h2 className="text-2xl font-heading text-surface-50">{section.title}</h2>
            <ul className="mt-5 space-y-3 text-sm text-surface-300 leading-relaxed">
              {section.items.map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <span className="mt-2 h-1.5 w-1.5 rounded-full bg-accent-light" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  </main>
);

export default Queue;