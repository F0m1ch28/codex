import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useLocation, Link } from 'react-router-dom';
import { blogPosts } from '../data/posts';
import { FiArrowRight } from 'react-icons/fi';

const categories = ['All', 'Workflow', 'Systems', 'Tooling', 'Culture'];

const Blog = () => {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const initialQuery = params.get('query') || '';
  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredPosts = useMemo(() => {
    return blogPosts.filter((post) => {
      const matchesCategory =
        selectedCategory === 'All' || post.category === selectedCategory;
      const matchesSearch =
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.tags.some((tag) =>
          tag.toLowerCase().includes(searchTerm.toLowerCase())
        );
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchTerm]);

  return (
    <main className="bg-gradient-to-b from-surface-950 via-surface-900 to-surface-950 min-h-screen">
      <Helmet>
        <title>DevLayer Blog | Essays on Workflows, Systems & Culture</title>
        <meta
          name="description"
          content="Browse DevLayer essays detailing developer workflows, software systems, cloud infrastructure, and engineering culture."
        />
      </Helmet>
      <section className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <span className="badge">Essay Archive</span>
          <h1 className="text-4xl md:text-5xl font-heading text-surface-50">
            Essays decoding modern engineering
          </h1>
          <p className="text-lg text-surface-200 leading-relaxed">
            Deep dives into developer workflows, platform engineering, cloud
            infrastructure, and the culture that sustains resilient software.
          </p>
        </div>
      </section>

      <section className="pb-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="glass-panel rounded-3xl border border-surface-800/60 p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex flex-wrap gap-3">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`chip ${
                    selectedCategory === category
                      ? 'bg-accent text-surface-50 border-transparent'
                      : ''
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
            <input
              type="search"
              placeholder="Search essays"
              className="w-full md:w-80 px-4 py-2 rounded-full bg-surface-900 text-sm text-surface-100 border border-surface-700 focus:border-accent focus:outline-none"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="grid gap-8">
            {filteredPosts.length === 0 && (
              <div className="glass-panel rounded-3xl border border-surface-800/60 p-8 text-center text-surface-300">
                No essays matched the current filters. Try adjusting keywords or
                categories.
              </div>
            )}
            {filteredPosts.map((post) => (
              <article
                key={post.slug}
                className="glass-panel rounded-3xl border border-surface-800/60 overflow-hidden grid md:grid-cols-5"
              >
                <img
                  src={post.heroImage}
                  alt={post.title}
                  className="md:col-span-2 h-64 w-full object-cover"
                  loading="lazy"
                />
                <div className="md:col-span-3 p-7 space-y-4 flex flex-col justify-between">
                  <div className="space-y-3">
                    <p className="text-xs uppercase tracking-[0.2em] text-accent-light">
                      {post.category} · {post.date} · {post.readTime}
                    </p>
                    <h2 className="text-2xl font-heading text-surface-50">{post.title}</h2>
                    <p className="text-sm text-surface-300 leading-relaxed">
                      {post.excerpt}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {post.tags.map((tag) => (
                        <span key={tag} className="chip">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                  <Link to={`/blog/${post.slug}`} className="btn-tertiary inline-flex">
                    Read essay <FiArrowRight />
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
};

export default Blog;