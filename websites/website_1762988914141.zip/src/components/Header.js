import React, { useEffect, useMemo, useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FiMenu, FiX, FiMoon, FiSun, FiSearch } from 'react-icons/fi';

const navLinks = [
  { label: 'Overview', to: '/' },
  { label: 'Workflows', to: '/workflows' },
  { label: 'Mindset', to: '/mindset' },
  { label: 'Queue', to: '/queue' },
  { label: 'Archives', to: '/archives' },
  { label: 'Blog', to: '/blog' },
  { label: 'Contact', to: '/contact' }
];

const Header = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [theme, setTheme] = useState('dark');
  const [searchTerm, setSearchTerm] = useState('');
  const location = useLocation();
  const navigate = useNavigate();

  const isHome = useMemo(() => location.pathname === '/', [location.pathname]);

  useEffect(() => {
    const stored = window.localStorage.getItem('devlayer-theme');
    if (stored) {
      setTheme(stored);
      if (stored === 'dark') {
        document.documentElement.classList.add('theme-dark');
      } else {
        document.documentElement.classList.remove('theme-dark');
      }
    }
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  const toggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    window.localStorage.setItem('devlayer-theme', nextTheme);
    if (nextTheme === 'dark') {
      document.documentElement.classList.add('theme-dark');
    } else {
      document.documentElement.classList.remove('theme-dark');
    }
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (!searchTerm.trim()) return;
    navigate(`/blog?query=${encodeURIComponent(searchTerm.trim())}`);
    setSearchTerm('');
  };

  const handleLogoClick = () => {
    navigate('/');
    if (isHome) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-50 backdrop-blur-lg bg-surface-950/80 border-b border-surface-800/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="h-16 flex items-center justify-between">
          <button
            onClick={handleLogoClick}
            className="flex items-center gap-3 focus:outline-none focus-visible:ring-2 focus-visible:ring-accent"
            aria-label="DevLayer home"
          >
            <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-accent to-accent-light text-surface-50 flex items-center justify-center font-heading text-lg shadow-devlayer">
              DL
            </div>
            <div className="text-left">
              <span className="text-surface-50 font-heading text-lg leading-none">
                DevLayer
              </span>
              <p className="text-xs text-surface-400">Toronto Editorial Studio</p>
            </div>
          </button>

          <nav className="hidden lg:flex items-center space-x-6">
            {navLinks.map(({ label, to }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  `relative text-sm font-medium tracking-wide transition ${
                    isActive
                      ? 'text-accent-light'
                      : 'text-surface-200 hover:text-accent-light'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    {label}
                    {isActive && (
                      <motion.span
                        layoutId="nav-indicator"
                        className="absolute -bottom-2 left-0 right-0 h-0.5 bg-accent-light"
                      />
                    )}
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          <div className="hidden lg:flex items-center gap-4">
            <form
              onSubmit={handleSearchSubmit}
              className="relative w-56"
              aria-label="Search DevLayer content"
            >
              <FiSearch className="absolute left-3 top-3 h-4 w-4 text-surface-400" />
              <input
                type="search"
                className="pl-9 pr-3 py-2 rounded-full bg-surface-900 text-sm text-surface-100 border border-surface-800 focus:border-accent focus:outline-none transition"
                placeholder="Search research and essays"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </form>
            <button
              onClick={toggleTheme}
              className="flex items-center justify-center h-10 w-10 rounded-full border border-surface-800 hover:border-accent transition"
              aria-label="Toggle color theme"
            >
              {theme === 'dark' ? (
                <FiSun className="h-5 w-5 text-accent-light" />
              ) : (
                <FiMoon className="h-5 w-5 text-accent-light" />
              )}
            </button>
          </div>

          <button
            onClick={() => setMobileOpen((prev) => !prev)}
            className="lg:hidden flex items-center justify-center h-11 w-11 rounded-lg border border-surface-800 text-surface-100"
            aria-label="Toggle navigation"
          >
            {mobileOpen ? <FiX className="h-5 w-5" /> : <FiMenu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.nav
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="lg:hidden border-t border-surface-800 bg-surface-950/95 backdrop-blur-lg"
          >
            <div className="px-4 py-4 space-y-3">
              <form
                onSubmit={handleSearchSubmit}
                className="relative"
                aria-label="Search DevLayer content mobile"
              >
                <FiSearch className="absolute left-3 top-3 h-4 w-4 text-surface-400" />
                <input
                  type="search"
                  className="pl-9 pr-3 py-2.5 rounded-full bg-surface-900 text-sm text-surface-100 border border-surface-800 focus:border-accent focus:outline-none transition w-full"
                  placeholder="Search research and essays"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </form>
              <div className="grid gap-2">
                {navLinks.map(({ label, to }) => (
                  <NavLink
                    key={to}
                    to={to}
                    className={({ isActive }) =>
                      `px-4 py-3 rounded-lg text-sm font-semibold tracking-wide transition border border-transparent ${
                        isActive
                          ? 'bg-accent/15 text-accent-light border-accent/40'
                          : 'bg-surface-900 text-surface-200 hover:border-accent/40'
                      }`
                    }
                  >
                    {label}
                  </NavLink>
                ))}
              </div>
              <button
                onClick={toggleTheme}
                className="flex items-center justify-center gap-3 px-4 py-3 rounded-lg border border-surface-800 text-sm font-semibold text-surface-100"
              >
                {theme === 'dark' ? (
                  <>
                    <FiSun className="h-5 w-5 text-accent-light" />
                    Light theme
                  </>
                ) : (
                  <>
                    <FiMoon className="h-5 w-5 text-accent-light" />
                    Dark theme
                  </>
                )}
              </button>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;