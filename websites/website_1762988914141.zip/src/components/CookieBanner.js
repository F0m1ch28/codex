import React, { useEffect, useState } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('devlayer-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (value) => {
    window.localStorage.setItem('devlayer-cookie-consent', value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-5 inset-x-4 md:inset-x-auto md:right-6 md:left-6 z-40">
      <div className="glass-panel border border-surface-700/60 px-5 py-4 rounded-2xl backdrop-blur-xl bg-surface-900/85 shadow-xl flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="max-w-2xl text-sm text-surface-200 leading-relaxed">
          DevLayer uses essential cookies and telemetry to understand how engineering readers interact with our research. Data is aggregated and used to improve editorial flow.
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => handleConsent('declined')}
            className="px-4 py-2 rounded-full border border-surface-700 text-surface-200 hover:border-accent transition text-sm"
          >
            Decline
          </button>
          <button
            onClick={() => handleConsent('accepted')}
            className="px-4 py-2 rounded-full bg-gradient-to-r from-accent to-accent-light text-sm font-semibold text-surface-50 shadow-devlayer hover:scale-[1.01] transition"
          >
            Accept
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;