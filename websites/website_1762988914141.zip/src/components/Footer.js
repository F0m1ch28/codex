import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-surface-950 border-t border-surface-800/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid gap-10 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-accent to-accent-light flex items-center justify-center font-heading text-lg text-surface-50 shadow-devlayer">
                DL
              </div>
              <div>
                <p className="text-surface-50 font-heading text-lg leading-none">
                  DevLayer
                </p>
                <p className="text-xs text-surface-400">
                  Developer-Focused Editorial Platform
                </p>
              </div>
            </div>
            <p className="text-sm text-surface-300 leading-relaxed max-w-xs">
              DevLayer documents the craft of engineering systems, workflows, and
              culture for builders shaping resilient platforms.
            </p>
            <div className="flex gap-4 mt-5">
              <a
                href="https://github.com"
                className="footer-icon"
                aria-label="DevLayer GitHub"
              >
                <svg
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path d="M12 .5C5.6.5.5 5.6.5 12c0 5.1 3.3 9.4 7.9 10.9.6.1.8-.3.8-.6v-2.2c-3.2.7-3.8-1.5-3.8-1.5-.6-1.4-1.3-1.7-1.3-1.7-1.1-.7.1-.7.1-.7 1.2.1 1.8 1.2 1.8 1.2 1.1 1.9 2.9 1.4 3.6 1.1.1-.8.4-1.4.8-1.8-2.6-.3-5.4-1.3-5.4-5.9 0-1.3.5-2.3 1.2-3.2-.1-.3-.5-1.5.1-3 0 0 1-.3 3.3 1.2a11.4 11.4 0 0 1 6 0c2.3-1.5 3.3-1.2 3.3-1.2.6 1.5.2 2.7.1 3 .7.9 1.2 2 1.2 3.2 0 4.6-2.8 5.5-5.5 5.9.4.4.8 1.1.8 2.2v3.3c0 .3.2.8.9.6A11.5 11.5 0 0 0 23.5 12C23.5 5.6 18.4.5 12 .5Z" />
                </svg>
              </a>
              <a
                href="https://www.linkedin.com"
                className="footer-icon"
                aria-label="DevLayer LinkedIn"
              >
                <svg
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path d="M20.4 3H3.6C3 3 2.5 3.5 2.5 4.1v15.8c0 .6.5 1.1 1.1 1.1h16.8c.6 0 1.1-.5 1.1-1.1V4.1c0-.6-.5-1.1-1.1-1.1ZM8.4 18.5H5.7V9.6h2.7v8.9ZM7 8.4c-.9 0-1.5-.6-1.5-1.4 0-.9.6-1.4 1.6-1.4.9 0 1.5.6 1.5 1.4 0 .8-.6 1.4-1.6 1.4Zm11.5 10.1h-2.7v-4.9c0-1.2-.4-2.1-1.5-2.1-.8 0-1.2.6-1.5 1.1-.1.2-.1.6-.1.9v5H9.9s.1-8.1 0-8.9h2.7v1.3a2.7 2.7 0 0 1 2.4-1.3c1.7 0 3 1.1 3 3.5v5.4Z" />
                </svg>
              </a>
              <a
                href="mailto:editorial@devlayer.com"
                className="footer-icon"
                aria-label="DevLayer Email"
              >
                <svg
                  className="h-5 w-5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path d="M20 4H4a2 2 0 0 0-2 2v12c0 1.05.95 2 2 2h16c1.05 0 2-.95 2-2V6c0-1.05-.95-2-2-2Zm-.4 2L12 11.75 4.4 6h15.2ZM4 18V7.4l7.35 5.5c.2.15.45.25.65.25s.45-.1.65-.25L20 7.4V18H4Z" />
                </svg>
              </a>
            </div>
          </div>
          <div>
            <h3 className="footer-heading">Platform</h3>
            <ul className="space-y-3 text-sm text-surface-300">
              <li>
                <Link to="/about" className="footer-link">
                  Mission & Values
                </Link>
              </li>
              <li>
                <Link to="/services" className="footer-link">
                  Editorial Programs
                </Link>
              </li>
              <li>
                <Link to="/workflows" className="footer-link">
                  Workflow Patterns
                </Link>
              </li>
              <li>
                <Link to="/mindset" className="footer-link">
                  Developer Mindset Library
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="footer-heading">Resources</h3>
            <ul className="space-y-3 text-sm text-surface-300">
              <li>
                <Link to="/queue" className="footer-link">
                  Reading Queue
                </Link>
              </li>
              <li>
                <Link to="/archives" className="footer-link">
                  Historical Archives
                </Link>
              </li>
              <li>
                <Link to="/notes" className="footer-link">
                  Platform Notes
                </Link>
              </li>
              <li>
                <Link to="/blog" className="footer-link">
                  Essay Collection
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="footer-heading">Contact</h3>
            <ul className="space-y-3 text-sm text-surface-300">
              <li>DevLayer</li>
              <li>333 Bay St, Toronto, ON M5H 2R2, Canada</li>
              <li>+1 (416) 905-6621</li>
              <li>
                <Link to="/contact" className="footer-link">
                  Collaborate with the editorial team
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="footer-link">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="footer-link">
                  Terms of Use
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-surface-800/60 pt-6 flex flex-col md:flex-row md:items-center md:justify-between text-xs text-surface-400 gap-3">
          <p>© {new Date().getFullYear()} DevLayer. Crafted in Toronto for engineering storytellers.</p>
          <p>Content is curated for educational use only.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;