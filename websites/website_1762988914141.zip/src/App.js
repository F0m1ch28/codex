import React, { Suspense, lazy, useEffect } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import { Helmet } from 'react-helmet-async';

const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const Services = lazy(() => import('./pages/Services'));
const Workflows = lazy(() => import('./pages/Workflows'));
const Mindset = lazy(() => import('./pages/Mindset'));
const Queue = lazy(() => import('./pages/Queue'));
const Archives = lazy(() => import('./pages/Archives'));
const Notes = lazy(() => import('./pages/Notes'));
const Blog = lazy(() => import('./pages/Blog'));
const PostContextSwitching = lazy(() =>
  import('./pages/blog/WhyContextSwitchingKillsProductivity')
);
const PostCloudPatterns = lazy(() =>
  import('./pages/blog/CloudPatternsForScale')
);
const PostDevOpsEvolution = lazy(() =>
  import('./pages/blog/TheEvolutionOfDevOpsCulture')
);
const Contact = lazy(() => import('./pages/Contact'));
const ContactThanks = lazy(() => import('./pages/ContactThanks'));
const Terms = lazy(() => import('./pages/Terms'));
const Privacy = lazy(() => import('./pages/Privacy'));

const NotFound = () => (
  <main className="min-h-[50vh] flex flex-col items-center justify-center text-center px-6 py-20 bg-surface-900 text-surface-100">
    <Helmet>
      <title>Page Not Found | DevLayer</title>
      <meta
        name="description"
        content="The page you were looking for could not be located on DevLayer."
      />
    </Helmet>
    <h1 className="text-4xl font-heading font-semibold mb-4">Page Missing</h1>
    <p className="max-w-md mb-8 text-lg text-surface-200">
      We looked across every layer and couldn’t find the requested resource.
      Try navigating through the primary sections or return home.
    </p>
  </main>
);

const App = () => {
  const location = useLocation();

  useEffect(() => {
    document.documentElement.setAttribute('lang', 'en');
  }, []);

  return (
    <>
      <Helmet>
        <link rel="canonical" href={`https://www.devlayer.com${location.pathname}`} />
      </Helmet>
      <div className="app min-h-screen flex flex-col bg-surface-950 text-surface-100">
        <Header />
        <Suspense
          fallback={
            <div className="flex-1 flex items-center justify-center bg-surface-950">
              <div className="loader-glass">
                <span className="sr-only">Loading</span>
              </div>
            </div>
          }
        >
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/workflows" element={<Workflows />} />
            <Route path="/mindset" element={<Mindset />} />
            <Route path="/queue" element={<Queue />} />
            <Route path="/archives" element={<Archives />} />
            <Route path="/notes" element={<Notes />} />
            <Route path="/blog" element={<Blog />} />
            <Route
              path="/blog/why-context-switching-kills-productivity"
              element={<PostContextSwitching />}
            />
            <Route
              path="/blog/cloud-patterns-for-scale"
              element={<PostCloudPatterns />}
            />
            <Route
              path="/blog/the-evolution-of-devops-culture"
              element={<PostDevOpsEvolution />}
            />
            <Route path="/contact" element={<Contact />} />
            <Route path="/contact/thanks" element={<ContactThanks />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/404" element={<NotFound />} />
            <Route path="*" element={<Navigate to="/404" replace />} />
          </Routes>
        </Suspense>
        <Footer />
        <CookieBanner />
        <ScrollToTop />
      </div>
    </>
  );
};

export default App;