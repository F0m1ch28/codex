export const blogPosts = [
  {
    slug: 'why-context-switching-kills-productivity',
    title: 'Why Context Switching Disrupts Engineering Focus',
    category: 'Workflow',
    heroImage: 'https://picsum.photos/1200/720?random=201',
    excerpt:
      'Context switches fracture engineering focus and erode the structural integrity of delivery cadence. This analysis models the interrupt tax and outlines rituals that protect cognitive throughput.',
    author: 'Maya Sheridan',
    date: '2024-01-12',
    readTime: '9 min read',
    metaDescription:
      'Explore how context switching impacts developer workflows and how to redesign rituals that preserve deep work within engineering teams.',
    tags: ['developer workflows', 'engineering psychology', 'team practices'],
    keywords: [
      'developer workflows',
      'engineering psychology',
      'focus management',
      'cognitive load'
    ]
  },
  {
    slug: 'cloud-patterns-for-scale',
    title: 'Cloud Patterns for Sustainable Scale',
    category: 'Systems',
    heroImage: 'https://picsum.photos/1200/720?random=202',
    excerpt:
      'Cloud-native systems demand accountable patterns around observability, cost-aware architecture, and adaptive capacity planning. We catalog the signals that distinguish resilient scale.',
    author: 'Rahul Venkataraman',
    date: '2023-12-02',
    readTime: '12 min read',
    metaDescription:
      'Survey cloud infrastructure patterns that balance resilience, platform engineering guardrails, and sustainable growth for distributed systems.',
    tags: ['cloud infrastructure', 'platform engineering', 'distributed computing'],
    keywords: [
      'cloud infrastructure',
      'platform engineering',
      'distributed computing',
      'capacity planning'
    ]
  },
  {
    slug: 'the-evolution-of-devops-culture',
    title: 'The Evolution of DevOps Culture',
    category: 'Culture',
    heroImage: 'https://picsum.photos/1200/720?random=203',
    excerpt:
      'DevOps has matured from tooling coordination to cultural alignment. We trace the lineage of the practice, highlight missteps, and surface rituals that promote shared accountability.',
    author: 'Sasha McKenna',
    date: '2023-11-10',
    readTime: '10 min read',
    metaDescription:
      'Understand how DevOps culture has evolved, the rituals that sustain platform engineering teams, and the signals that keep alignment intact.',
    tags: ['devops culture', 'engineering culture', 'team dynamics'],
    keywords: [
      'devops culture',
      'engineering culture',
      'platform engineering',
      'team dynamics'
    ]
  }
];