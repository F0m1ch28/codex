document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !expanded);
            siteNav.classList.toggle('nav-open');
        });
    }

    const activePage = document.body.dataset.page;
    if (activePage) {
        const activeLink = document.querySelector(`.site-nav a[data-page="${activePage}"]`);
        if (activeLink) {
            activeLink.classList.add('active-link');
        }
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const choice = localStorage.getItem('cpwCookieChoice');
        if (!choice) {
            cookieBanner.classList.add('active');
        }

        const cookieButtons = cookieBanner.querySelectorAll('.cookie-actions a');
        cookieButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                const selection = button.dataset.choice || 'dismissed';
                localStorage.setItem('cpwCookieChoice', selection);
                cookieBanner.classList.remove('active');
            });
        });
    }

    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function (event) {
            event.preventDefault();
            window.location.href = 'thanks.html';
        });
    }

    const postsListing = document.querySelector('.posts-listing');
    const paginationContainer = document.querySelector('.pagination');
    const searchInput = document.getElementById('post-search');
    const categorySelect = document.getElementById('post-category');

    if (postsListing && paginationContainer && searchInput && categorySelect) {
        const itemsPerPage = 6;
        const cards = Array.from(postsListing.querySelectorAll('.post-card'));
        let filteredCards = cards.slice();
        let currentPage = 1;

        function applyFilters() {
            const query = searchInput.value.trim().toLowerCase();
            const category = categorySelect.value;
            filteredCards = cards.filter(function (card) {
                const matchesQuery = card.dataset.title.toLowerCase().includes(query);
                const matchesCategory = category === 'all' || card.dataset.category === category;
                return matchesQuery && matchesCategory;
            });
            currentPage = 1;
            render();
        }

        function renderPagination(totalPages) {
            paginationContainer.innerHTML = '';
            for (let i = 1; i <= totalPages; i += 1) {
                const button = document.createElement('button');
                button.textContent = String(i);
                if (i === currentPage) {
                    button.classList.add('active-page');
                }
                button.addEventListener('click', function () {
                    currentPage = i;
                    render();
                });
                paginationContainer.appendChild(button);
            }
        }

        function render() {
            cards.forEach(function (card) {
                card.style.display = 'none';
            });

            if (filteredCards.length === 0) {
                paginationContainer.innerHTML = '';
                return;
            }

            const totalPages = Math.ceil(filteredCards.length / itemsPerPage);
            const start = (currentPage - 1) * itemsPerPage;
            const end = start + itemsPerPage;
            const visibleCards = filteredCards.slice(start, end);

            visibleCards.forEach(function (card) {
                card.style.display = 'flex';
            });

            renderPagination(totalPages);
        }

        searchInput.addEventListener('input', applyFilters);
        categorySelect.addEventListener('change', applyFilters);

        applyFilters();
    }
});