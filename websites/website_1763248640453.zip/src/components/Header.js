import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMenu = () => {
    setMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setMenuOpen(false);
  };

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : 'auto';
  }, [menuOpen]);

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <div className="container">
        <div className={styles.inner}>
          <Link to="/" className={styles.logo} onClick={closeMenu} aria-label="На главную">
            <span className={styles.logoAccent}>Техно</span>Лаб
          </Link>
          <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Основная навигация">
            <ul className={styles.navList}>
              <li>
                <NavLink to="/" end className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`} onClick={closeMenu}>
                  Главная
                </NavLink>
              </li>
              <li>
                <NavLink to="/o-kompanii" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`} onClick={closeMenu}>
                  О компании
                </NavLink>
              </li>
              <li>
                <NavLink to="/uslugi" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`} onClick={closeMenu}>
                  Услуги
                </NavLink>
              </li>
              <li>
                <NavLink to="/blog" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`} onClick={closeMenu}>
                  Блог
                </NavLink>
              </li>
              <li>
                <NavLink to="/kontakty" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`} onClick={closeMenu}>
                  Контакты
                </NavLink>
              </li>
            </ul>
            <div className={styles.contact}>
              <a href="tel:+74951234567" className={styles.contactLink}>+7 (495) 123-45-67</a>
              <a href="mailto:info@technolab.ru" className={styles.contactLink}>info@technolab.ru</a>
            </div>
          </nav>
          <button
            className={`${styles.burger} ${menuOpen ? styles.burgerActive : ''}`}
            onClick={toggleMenu}
            aria-label="Переключить меню"
            aria-expanded={menuOpen}
            aria-controls="main-navigation"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;