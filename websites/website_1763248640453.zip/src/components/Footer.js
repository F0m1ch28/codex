import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brand}>
            <h2 id="footer-heading" className={styles.logo}>
              <span>Техно</span>Лаб
            </h2>
            <p className={styles.text}>
              Современные технологические решения для бизнеса, которые рождаются в Москве и работают по всему миру.
            </p>
            <p className={styles.copy}>© {new Date().getFullYear()} ТехноЛаб. Все права защищены.</p>
          </div>
          <div className={styles.column}>
            <h3 className={styles.heading}>Компания</h3>
            <ul className={styles.list}>
              <li><Link to="/o-kompanii" className={styles.link}>О компании</Link></li>
              <li><Link to="/uslugi" className={styles.link}>Услуги</Link></li>
              <li><Link to="/blog" className={styles.link}>Блог</Link></li>
              <li><Link to="/kontakty" className={styles.link}>Контакты</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.heading}>Правовая информация</h3>
            <ul className={styles.list}>
              <li><Link to="/politika-konfidencialnosti" className={styles.link}>Политика конфиденциальности</Link></li>
              <li><Link to="/usloviya-ispolzovaniya" className={styles.link}>Условия использования</Link></li>
              <li><Link to="/politika-cookies" className={styles.link}>Политика cookies</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.heading}>Контакты</h3>
            <ul className={styles.list}>
              <li className={styles.contactItem}>Москва, ул. Ленинградская, д. 25, офис 304</li>
              <li><a href="tel:+74951234567" className={styles.link}>+7 (495) 123-45-67</a></li>
              <li><a href="mailto:info@technolab.ru" className={styles.link}>info@technolab.ru</a></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;