import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'technolab-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о файлах cookies">
      <p className={styles.text}>
        Мы используем cookies, чтобы сделать сайт удобнее и эффективнее. Продолжая пользоваться сайтом, вы соглашаетесь с{' '}
        <Link to="/politika-cookies" className={styles.link}>политикой cookies</Link>.
      </p>
      <button className={styles.button} onClick={acceptCookies}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;