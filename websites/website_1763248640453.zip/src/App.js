import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const Services = lazy(() => import('./pages/Services'));
const Contact = lazy(() => import('./pages/Contact'));
const Blog = lazy(() => import('./pages/Blog'));
const PrivacyPolicy = lazy(() => import('./pages/PrivacyPolicy'));
const TermsOfService = lazy(() => import('./pages/TermsOfService'));
const CookiePolicy = lazy(() => import('./pages/CookiePolicy'));

const App = () => {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <Header />
      <main>
        <Suspense fallback={<div className="loading" aria-live="polite">Загрузка...</div>}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/o-kompanii" element={<About />} />
            <Route path="/uslugi" element={<Services />} />
            <Route path="/kontakty" element={<Contact />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/politika-konfidencialnosti" element={<PrivacyPolicy />} />
            <Route path="/usloviya-ispolzovaniya" element={<TermsOfService />} />
            <Route path="/politika-cookies" element={<CookiePolicy />} />
          </Routes>
        </Suspense>
      </main>
      <Footer />
      <CookieBanner />
    </BrowserRouter>
  );
};

export default App;