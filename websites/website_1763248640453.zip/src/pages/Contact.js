import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [form, setForm] = useState({ name: '', email: '', company: '', message: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Введите имя';
    if (!form.company.trim()) newErrors.company = 'Укажите компанию или проект';
    if (!form.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) newErrors.email = 'Введите корректный email';
    if (!form.message.trim()) newErrors.message = 'Опишите запрос';
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = validate();
    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      setStatus('Спасибо! Мы получили сообщение и свяжемся с вами в ближайшее время.');
      setForm({ name: '', email: '', company: '', message: '' });
      setTimeout(() => setStatus(''), 7000);
    }
  };

  return (
    <>
      <Helmet>
        <title>Контакты ТехноЛаб — свяжитесь с нами</title>
        <meta
          name="description"
          content="Свяжитесь с ТехноЛаб: Москва, ул. Ленинградская, д. 25, офис 304. Телефон +7 (495) 123-45-67, email info@technolab.ru. Обсудим ваш проект."
        />
        <meta name="keywords" content="Контакты, ТехноЛаб, Москва, IT-компания, email, телефон" />
        <link rel="canonical" href="https://www.example.com/kontakty" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Свяжитесь с ТехноЛаб</h1>
            <p>Расскажите о проекте, и мы подготовим рекомендации, команду и план действий.</p>
          </div>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>Контактные данные</h2>
              <p>Мы на связи в будние дни с 09:00 до 19:00 по московскому времени.</p>
              <ul>
                <li>
                  <strong>Адрес:</strong> Москва, ул. Ленинградская, д. 25, офис 304
                </li>
                <li>
                  <strong>Телефон:</strong> <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </li>
                <li>
                  <strong>Email:</strong> <a href="mailto:info@technolab.ru">info@technolab.ru</a>
                </li>
              </ul>
              <div className={styles.mapWrapper} aria-hidden="true">
                <iframe
                  title="Офис ТехноЛаб на карте"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2243.047744213249!2d37.541!3d55.805!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTXCsDQ4JzE4LjAiTiAzN8KwMzInMjcuNiJF!5e0!3m2!1sru!2sru!4v1700000000000"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Форма обратной связи</h2>
              <div className={styles.formField}>
                <label htmlFor="name">Имя</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={form.name}
                  onChange={handleChange}
                  aria-invalid={errors.name ? 'true' : 'false'}
                  aria-describedby={errors.name ? 'contact-name-error' : undefined}
                />
                {errors.name && <span id="contact-name-error" className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.formField}>
                <label htmlFor="company">Компания или проект</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={form.company}
                  onChange={handleChange}
                  aria-invalid={errors.company ? 'true' : 'false'}
                  aria-describedby={errors.company ? 'contact-company-error' : undefined}
                />
                {errors.company && <span id="contact-company-error" className={styles.error}>{errors.company}</span>}
              </div>
              <div className={styles.formField}>
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={form.email}
                  onChange={handleChange}
                  aria-invalid={errors.email ? 'true' : 'false'}
                  aria-describedby={errors.email ? 'contact-email-error' : undefined}
                />
                {errors.email && <span id="contact-email-error" className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.formField}>
                <label htmlFor="message">Сообщение</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={form.message}
                  onChange={handleChange}
                  aria-invalid={errors.message ? 'true' : 'false'}
                  aria-describedby={errors.message ? 'contact-message-error' : undefined}
                />
                {errors.message && <span id="contact-message-error" className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className={styles.submit}>Отправить</button>
              {status && <p className={styles.success} role="status">{status}</p>}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;