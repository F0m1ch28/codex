import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsConfig = [
  { label: 'лет в разработке', value: 12 },
  { label: 'завершённых проектов', value: 180 },
  { label: 'экспертов в штате', value: 95 },
  { label: 'уровень NPS', value: 92 }
];

const servicesData = [
  {
    title: 'Индивидуальная разработка ПО',
    description: 'Создаём цифровые продукты под конкретные бизнес-задачи, уделяя максимум внимания архитектуре и масштабируемости.',
    icon: '🧠'
  },
  {
    title: 'Цифровая трансформация',
    description: 'Помогаем компаниям перестроить процессы и внедрить современные технологические решения без остановки бизнеса.',
    icon: '🚀'
  },
  {
    title: 'Технологический консалтинг',
    description: 'Анализируем IT-ландшафт, формируем стратегию развития и сопровождаем внедрение лучших практик.',
    icon: '🧭'
  },
  {
    title: 'Поддержка и развитие',
    description: 'Обеспечиваем бесперебойную работу продуктов, модернизируем функциональность и следим за безопасностью.',
    icon: '🛡️'
  }
];

const advantagesData = [
  {
    title: 'Фокус на результат',
    text: 'Мы строим команды вокруг целей и измеримых показателей, чтобы решения приносили бизнес-ценность уже на первых итерациях.'
  },
  {
    title: 'Глубокая экспертиза',
    text: 'Опыт работы с высоконагруженными системами, облачными платформами и сложной интеграцией позволяет нам браться за самые требовательные проекты.'
  },
  {
    title: 'Партнёрство с клиентами',
    text: 'Вместо схемы «заказчик-исполнитель» вы получаете вовлечённого технологического союзника, который следит за продуктом после релиза.'
  }
];

const processSteps = [
  {
    title: 'Аналитика и концепция',
    text: 'Исследуем бизнес-цели, аудиторию и текущие процессы, формируем концепцию продукта и карту развития.',
    order: '01'
  },
  {
    title: 'Проектирование и дизайн',
    text: 'Строим архитектуру, планируем спринты, создаём UX/UI с акцентом на удобство и доступность.',
    order: '02'
  },
  {
    title: 'Разработка и тестирование',
    text: 'Работаем итеративно, обеспечиваем прозрачность, используем автоматизированные проверки качества.',
    order: '03'
  },
  {
    title: 'Запуск и поддержка',
    text: 'Проводим релиз, настраиваем мониторинг, обучаем команду заказчика и сопровождаем продукт.',
    order: '04'
  }
];

const testimonials = [
  {
    quote: 'Команда ТехноЛаб помогла нам переосмыслить систему внутреннего документооборота. Результат — сокращение времени обработки заявок на 40%.',
    name: 'Анна Руднева',
    position: 'Директор по операционному развитию, ИнноваПром'
  },
  {
    quote: 'Благодаря экспертному консалтингу ТехноЛаб мы выбрали технологическую платформу, которая выдерживает рост нагрузки без потерь в скорости.',
    name: 'Игорь Соколов',
    position: 'CEO, MedVision'
  },
  {
    quote: 'Мы ценим прозрачность и вовлечённость команды. Все решения аргументированы, а конечное качество продукта — на высоте.',
    name: 'Елена Киреева',
    position: 'Руководитель цифровых продуктов, EduNova'
  }
];

const teamMembers = [
  {
    name: 'Максим Орлов',
    role: 'Генеральный директор',
    focus: 'Стратегия, развитие клиентских сервисов',
    photo: 'https://picsum.photos/400/400?random=12'
  },
  {
    name: 'Валерия Петрова',
    role: 'Директор по технологиям',
    focus: 'Архитектура, инновации, техлидство',
    photo: 'https://picsum.photos/400/400?random=13'
  },
  {
    name: 'Сергей Киселёв',
    role: 'Руководитель продуктов',
    focus: 'Agile, работа с гипотезами, масштабирование',
    photo: 'https://picsum.photos/400/400?random=14'
  },
  {
    name: 'Алина Морозова',
    role: 'Head of Delivery',
    focus: 'Управление проектами, качество, процессы',
    photo: 'https://picsum.photos/400/400?random=15'
  }
];

const projectsData = [
  {
    id: 1,
    title: 'Платформа управления жизненным циклом оборудования',
    category: 'Промышленность',
    description: 'Единое окно для мониторинга, аналитики и планирования сервисных работ на производстве.',
    image: 'https://picsum.photos/1200/800?random=21'
  },
  {
    id: 2,
    title: 'Цифровая экосистема для образовательной сети',
    category: 'Образование',
    description: 'Модульное решение для дистанционных курсов, вовлечения студентов и аналитики прогресса.',
    image: 'https://picsum.photos/1200/800?random=22'
  },
  {
    id: 3,
    title: 'Портал поддержки медицинских специалистов',
    category: 'Здравоохранение',
    description: 'Платформа быстрого доступа к знаниям, консультациям и сервисам телемедицины.',
    image: 'https://picsum.photos/1200/800?random=23'
  },
  {
    id: 4,
    title: 'Модуль прогнозирования спроса',
    category: 'Retail',
    description: 'ML-инструмент, который помогает планировать поставки и сокращать остатки на складах.',
    image: 'https://picsum.photos/1200/800?random=24'
  }
];

const faqData = [
  {
    question: 'Как стартует проект с ТехноЛаб?',
    answer: 'Мы начинаем с аналитической сессии: фиксируем цели, KPI и ограничения. Затем формируем план работ, предлагаем команду и периметр MVP.'
  },
  {
    question: 'С какими технологиями вы работаете?',
    answer: 'Используем современный стек: Java, .NET, Node.js, Python, React, Vue, Kotlin, Swift, а также облачные решения и Kubernetes.'
  },
  {
    question: 'Можно ли подключиться только на консалтинг?',
    answer: 'Да. Мы проводим технологический аудит, помогаем выбрать архитектурный подход и сопровождаем внедрение необходимых улучшений.'
  },
  {
    question: 'Как обеспечивается качество и безопасность?',
    answer: 'У нас есть практика QA, автоматизированные тесты, code review, контроль уязвимостей и соответствие требованиям информационной безопасности клиента.'
  }
];

const blogPreviewPosts = [
  {
    title: 'Как построить масштабируемую архитектуру под рост бизнеса',
    excerpt: 'Разбираем ключевые принципы проектирования, которые позволяют продукту выдержать нагрузку без сложного рефакторинга.',
    date: '15 марта 2024',
    link: '/blog',
    image: 'https://picsum.photos/800/600?random=31'
  },
  {
    title: 'Дизайн процессов: как сделать запуск продукта предсказуемым',
    excerpt: 'Делимся опытом выстраивания гибкой, но управляемой модели разработки с прозрачными метриками.',
    date: '28 февраля 2024',
    link: '/blog',
    image: 'https://picsum.photos/800/600?random=32'
  },
  {
    title: 'Аналитика для руководителей: собираем цифровой портрет бизнеса',
    excerpt: 'О том, как интегрировать данные из разных систем и получать единую картину для принятия решений.',
    date: '6 февраля 2024',
    link: '/blog',
    image: 'https://picsum.photos/800/600?random=33'
  }
];

const Home = () => {
  const [counters, setCounters] = useState(statsConfig.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Все');
  const [homeForm, setHomeForm] = useState({ name: '', email: '', message: '' });
  const [homeErrors, setHomeErrors] = useState({});
  const [homeSuccess, setHomeSuccess] = useState(false);

  useEffect(() => {
    const durations = statsConfig.map(() => 1500);
    const increments = statsConfig.map((stat, idx) => stat.value / (durations[idx] / 30));

    const interval = setInterval(() => {
      setCounters((prev) =>
        prev.map((count, idx) => {
          const next = count + increments[idx];
          return next >= statsConfig[idx].value ? statsConfig[idx].value : next;
        })
      );
    }, 30);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    projectFilter === 'Все'
      ? projectsData
      : projectsData.filter((project) => project.category === projectFilter);

  const handleHomeInputChange = (e) => {
    const { name, value } = e.target;
    setHomeForm((prev) => ({ ...prev, [name]: value }));
  };

  const validateHomeForm = () => {
    const errors = {};
    if (!homeForm.name.trim()) errors.name = 'Укажите имя';
    if (!homeForm.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(homeForm.email)) errors.email = 'Введите корректный email';
    if (!homeForm.message.trim()) errors.message = 'Опишите задачу';
    return errors;
  };

  const handleHomeSubmit = (e) => {
    e.preventDefault();
    const errors = validateHomeForm();
    setHomeErrors(errors);
    if (Object.keys(errors).length === 0) {
      setHomeSuccess(true);
      setHomeForm({ name: '', email: '', message: '' });
      setTimeout(() => setHomeSuccess(false), 6000);
    }
  };

  return (
    <>
      <Helmet>
        <title>ТехноЛаб — Создаём цифровые продукты и сопровождаем трансформацию</title>
        <meta
          name="description"
          content="ТехноЛаб — IT-компания из Москвы, создающая программное обеспечение, проводящая технологический консалтинг и поддерживающая цифровые продукты на всех этапах."
        />
        <meta
          name="keywords"
          content="IT-компания, разработка программного обеспечения, IT-консалтинг, цифровая трансформация, Москва, технологии"
        />
        <link rel="canonical" href="https://www.example.com/" />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroOverlay} />
        <img
          src="https://picsum.photos/1600/900?random=101"
          alt="Команда IT-специалистов работает над проектом"
          className={styles.heroImage}
        />
        <div className={`container ${styles.heroContent}`}>
          <span className={styles.heroBadge}>IT-разработка и консалтинг</span>
          <h1 className={styles.heroTitle}>
            Создаём цифровые продукты, которые помогают бизнесу уверенно расти
          </h1>
          <p className={styles.heroText}>
            Мы объединяем экспертизу в разработке и технологическом консалтинге, чтобы идеи превращались в устойчивые и масштабируемые решения.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.heroButtonPrimary}>
              Обсудить проект
            </Link>
            <Link to="/uslugi" className={styles.heroButtonSecondary}>
              Все услуги
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsConfig.map((stat, idx) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>{Math.round(counters[idx])}+</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.about}>
        <div className="container">
          <div className={styles.aboutGrid}>
            <div className={styles.aboutContent}>
              <span className={styles.sectionBadge}>О компании</span>
              <h2 className={styles.sectionTitle}>ТехноЛаб — технологический партнёр полного цикла</h2>
              <p className={styles.sectionText}>
                Мы развиваем цифровые продукты на всех этапах: от стратегической сессии и прототипа до запуска платформы на тысячи пользователей. В центре подхода — ответственность, прозрачность и забота о бизнес-результате.
              </p>
              <ul className={styles.aboutList}>
                <li>Создаём архитектуру, которая выдерживает рост нагрузки</li>
                <li>Работаем по гибким методологиям с регулярными демонстрациями</li>
                <li>Передаём знания командам заказчика и обеспечиваем поддержку</li>
              </ul>
              <Link to="/o-kompanii" className={styles.linkButton}>
                Узнать больше
              </Link>
            </div>
            <div className={styles.aboutMedia}>
              <img
                src="https://picsum.photos/800/600?random=102"
                alt="Презентация технологического проекта"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.services} id="services">
        <div className="container">
          <div className={styles.servicesHeader}>
            <span className={styles.sectionBadge}>Услуги</span>
            <h2 className={styles.sectionTitle}>Что мы делаем</h2>
            <p className={styles.sectionDescription}>
              Подбираем оптимальный формат сотрудничества: от выделенной команды для разработки продукта до точечных консалтинговых сессий.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <span className={styles.serviceIcon} aria-hidden="true">{service.icon}</span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/uslugi" className={styles.serviceLink}>
                  Подробнее
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.advantages}>
        <div className="container">
          <div className={styles.advantagesInner}>
            <div className={styles.advantagesIntro}>
              <span className={styles.sectionBadge}>Преимущества</span>
              <h2 className={styles.sectionTitle}>Почему клиенты выбирают ТехноЛаб</h2>
              <p className={styles.sectionText}>
                Мы не делаем шаблонных решений: каждый проект собираем вокруг цели клиента и контролируем каждую деталь — от первых гипотез до поддержки.
              </p>
            </div>
            <div className={styles.advantagesCards}>
              {advantagesData.map((advantage) => (
                <article key={advantage.title} className={styles.advantageCard}>
                  <h3>{advantage.title}</h3>
                  <p>{advantage.text}</p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.processHeader}>
            <span className={styles.sectionBadge}>Процесс</span>
            <h2 className={styles.sectionTitle}>Работаем в прозрачных этапах</h2>
            <p className={styles.sectionDescription}>
              Каждому проекту назначаем проджекта и техлида. Они отвечают за коммуникацию, сроки, качество и удобство взаимодействия.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <div key={step.title} className={styles.processCard}>
                <span className={styles.processOrder}>{step.order}</span>
                <div className={styles.processContent}>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.testimonialsHeader}>
            <span className={styles.sectionBadgeLight}>Отзывы</span>
            <h2 className={styles.sectionTitleLight}>Что говорят клиенты</h2>
          </div>
          <div className={styles.testimonialCard}>
            <blockquote className={styles.testimonialQuote}>
              “{testimonials[testimonialIndex].quote}”
            </blockquote>
            <p className={styles.testimonialAuthor}>
              {testimonials[testimonialIndex].name}
              <span>{testimonials[testimonialIndex].position}</span>
            </p>
            <div className={styles.testimonialControls}>
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={`${styles.testimonialDot} ${index === testimonialIndex ? styles.testimonialDotActive : ''}`}
                  onClick={() => setTestimonialIndex(index)}
                  aria-label={`Показать отзыв ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.teamHeader}>
            <span className={styles.sectionBadge}>Команда</span>
            <h2 className={styles.sectionTitle}>Лидеры направлений ТехноЛаб</h2>
            <p className={styles.sectionDescription}>
              Наша команда собирает экспертов из разных сфер: архитекторы, аналитики, продуктовые менеджеры, DevOps и QA.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img src={member.photo} alt={`Фото: ${member.name}`} loading="lazy" />
                </div>
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p className={styles.teamFocus}>{member.focus}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <span className={styles.sectionBadge}>Проекты</span>
            <h2 className={styles.sectionTitle}>Портфолио решений</h2>
            <p className={styles.sectionDescription}>
              Мы собираем лучшие практики из разных отраслей и адаптируем их к вашим задачам.
            </p>
            <div className={styles.projectFilters}>
              {['Все', 'Промышленность', 'Образование', 'Здравоохранение', 'Retail'].map((filter) => (
                <button
                  key={filter}
                  className={`${styles.projectFilterButton} ${projectFilter === filter ? styles.projectFilterActive : ''}`}
                  onClick={() => setProjectFilter(filter)}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img src={project.image} alt={`Проект: ${project.title}`} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.faqHeader}>
            <span className={styles.sectionBadge}>FAQ</span>
            <h2 className={styles.sectionTitle}>Частые вопросы</h2>
            <p className={styles.sectionDescription}>
              Если вы не нашли ответ — напишите нам, и мы поделимся деталями.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqData.map((item, index) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>+</span>
                </summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.blogHeader}>
            <span className={styles.sectionBadge}>Блог</span>
            <h2 className={styles.sectionTitle}>Свежие материалы</h2>
            <p className={styles.sectionDescription}>
              Делимся практическими инсайтами из проектов и рассказываем, как технологии меняют бизнес.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPreviewPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImageWrapper}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.blogLink}>
                    Читать дальше
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaInner}>
            <h2>Готовы двигать ваш продукт вперёд?</h2>
            <p>Свяжитесь с нами, и мы подготовим индивидуальный план реализации задачи в течение трёх рабочих дней.</p>
            <div className={styles.ctaActions}>
              <Link to="/kontakty" className={styles.ctaButtonPrimary}>
                Назначить встречу
              </Link>
              <Link to="/o-kompanii" className={styles.ctaButtonSecondary}>
                О нас
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.homeContact} id="contact">
        <div className="container">
          <div className={styles.homeContactGrid}>
            <div className={styles.homeContactInfo}>
              <span className={styles.sectionBadge}>Связаться с нами</span>
              <h2 className={styles.sectionTitle}>Расскажите о вашей задаче</h2>
              <p className={styles.sectionDescription}>
                Напишите пару слов о проекте — мы свяжемся в ближайшее время, уточним детали и предложим варианты сотрудничества.
              </p>
              <ul className={styles.contactList}>
                <li><strong>Адрес:</strong> Москва, ул. Ленинградская, д. 25, офис 304</li>
                <li><strong>Телефон:</strong> <a href="tel:+74951234567">+7 (495) 123-45-67</a></li>
                <li><strong>Email:</strong> <a href="mailto:info@technolab.ru">info@technolab.ru</a></li>
              </ul>
            </div>
            <form className={styles.homeContactForm} onSubmit={handleHomeSubmit} noValidate>
              <label className={styles.formField}>
                <span>Имя</span>
                <input
                  type="text"
                  name="name"
                  value={homeForm.name}
                  onChange={handleHomeInputChange}
                  aria-invalid={homeErrors.name ? 'true' : 'false'}
                  aria-describedby={homeErrors.name ? 'home-name-error' : undefined}
                />
                {homeErrors.name && <span id="home-name-error" className={styles.errorText}>{homeErrors.name}</span>}
              </label>
              <label className={styles.formField}>
                <span>Email</span>
                <input
                  type="email"
                  name="email"
                  value={homeForm.email}
                  onChange={handleHomeInputChange}
                  aria-invalid={homeErrors.email ? 'true' : 'false'}
                  aria-describedby={homeErrors.email ? 'home-email-error' : undefined}
                />
                {homeErrors.email && <span id="home-email-error" className={styles.errorText}>{homeErrors.email}</span>}
              </label>
              <label className={styles.formField}>
                <span>Сообщение</span>
                <textarea
                  name="message"
                  rows="4"
                  value={homeForm.message}
                  onChange={handleHomeInputChange}
                  aria-invalid={homeErrors.message ? 'true' : 'false'}
                  aria-describedby={homeErrors.message ? 'home-message-error' : undefined}
                />
                {homeErrors.message && <span id="home-message-error" className={styles.errorText}>{homeErrors.message}</span>}
              </label>
              <button type="submit" className={styles.submitButton}>
                Отправить
              </button>
              {homeSuccess && (
                <p className={styles.successText} role="status">
                  Спасибо! Мы уже получили ваше сообщение и скоро ответим.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;