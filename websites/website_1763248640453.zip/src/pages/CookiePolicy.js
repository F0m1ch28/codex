import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Политика cookies — ТехноЛаб</title>
        <meta
          name="description"
          content="Подробная информация о том, как ТехноЛаб использует файлы cookies. Типы файлов и способы управления ими."
        />
        <link rel="canonical" href="https://www.example.com/politika-cookies" />
      </Helmet>

      <section className={styles.page}>
        <div className="container">
          <h1>Политика cookies</h1>
          <p>Последнее обновление: 1 марта 2024 года</p>

          <h2>1. Что такое cookies</h2>
          <p>
            Cookies — небольшие текстовые файлы, которые сохраняются на вашем устройстве при посещении сайта. Они помогают нам улучшать работу сервиса и понимать, как пользователи взаимодействуют с сайтом.
          </p>

          <h2>2. Какие cookies мы используем</h2>
          <ul>
            <li><strong>Технические cookies:</strong> обеспечивают корректную работу отдельных функций и форм.</li>
            <li><strong>Аналитические cookies:</strong> помогают понять, как пользователи взаимодействуют с сайтом, и повышать удобство.</li>
            <li><strong>Функциональные cookies:</strong> запоминают выбор пользователя (например, язык или подтверждение баннера).</li>
          </ul>

          <h2>3. Управление cookies</h2>
          <p>
            Вы можете ограничить или отключить использование cookies в настройках браузера. Обратите внимание: это может повлиять на функциональность сайта.
          </p>

          <h2>4. Контакты</h2>
          <p>
            Если у вас есть вопросы о политике cookies, напишите нам: info@technolab.ru.
          </p>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;