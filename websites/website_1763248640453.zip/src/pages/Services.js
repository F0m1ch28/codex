import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const servicePackages = [
  {
    title: 'Стратегия и Discovery',
    details: [
      'Сбор и анализ требований',
      'Карта заинтересованных сторон',
      'Проектирование пользовательских сценариев',
      'Аудит текущей архитектуры',
      'Roadmap и оценка MVP'
    ],
    focus: 'Определяем цели и границы продукта перед стартом разработки.'
  },
  {
    title: 'Разработка цифровых продуктов',
    details: [
      'Backend и frontend разработка',
      'Мобильные приложения',
      'Интеграция с внешними системами',
      'Создание дизайн-систем',
      'Настройка CI/CD'
    ],
    focus: 'Собираем команды под конкретные задачи, внедряем современный стек технологий.'
  },
  {
    title: 'Технологический консалтинг',
    details: [
      'Технические интервью и аудит процессов',
      'Разработка архитектурного видения',
      'Оптимизация DevOps-практик',
      'Работа с данными и аналитикой',
      'Настройка безопасности и мониторинга'
    ],
    focus: 'Помогаем сделать технологии управляемыми и предсказуемыми.'
  },
  {
    title: 'Поддержка и развитие',
    details: [
      'SLA-сопровождение',
      'Модернизация функциональности',
      'Проактивный мониторинг',
      'Управление релизами',
      'Обучение и передача знаний'
    ],
    focus: 'Обеспечиваем устойчивую работу и постепенное развитие продукта.'
  }
];

const techStack = [
  { title: 'Frontend', items: 'React, Next.js, Vue, TypeScript' },
  { title: 'Backend', items: 'Node.js, NestJS, Java, .NET, Python' },
  { title: 'Mobile', items: 'Kotlin, Swift, Flutter, React Native' },
  { title: 'Data & AI', items: 'PostgreSQL, ClickHouse, MLflow, TensorFlow' },
  { title: 'Infrastructure', items: 'AWS, Azure, Kubernetes, Terraform' },
  { title: 'Quality', items: 'Playwright, Cypress, SonarQube, Snyk' }
];

const Services = () => {
  const [activeService, setActiveService] = useState(servicePackages[0].title);

  const currentService = servicePackages.find((service) => service.title === activeService);

  return (
    <>
      <Helmet>
        <title>Услуги ТехноЛаб — разработка, консалтинг, поддержка</title>
        <meta
          name="description"
          content="Компетенции ТехноЛаб: Discovery, разработка цифровых продуктов, IT-консалтинг, сопровождение и развитие решений. Подробное описание услуг."
        />
        <meta name="keywords" content="Разработка, IT-консалтинг, поддержка, цифровые продукты, ТехноЛаб, услуги" />
        <link rel="canonical" href="https://www.example.com/uslugi" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Решения, собранные вокруг ваших задач</h1>
            <p>
              Мы комбинируем экспертизу в разработке, аналитике и управлении продуктом, чтобы создавать и развивать цифровые сервисы любого масштаба.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.tabs}>
            <nav className={styles.tabList} aria-label="Выбор услуги">
              {servicePackages.map((service) => (
                <button
                  key={service.title}
                  className={`${styles.tabButton} ${service.title === activeService ? styles.tabActive : ''}`}
                  onClick={() => setActiveService(service.title)}
                >
                  {service.title}
                </button>
              ))}
            </nav>
            <article className={styles.tabPanel}>
              <header>
                <h2>{currentService.title}</h2>
                <p>{currentService.focus}</p>
              </header>
              <ul>
                {currentService.details.map((detail) => (
                  <li key={detail}>{detail}</li>
                ))}
              </ul>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.stack}>
        <div className="container">
          <h2>Технологический стек</h2>
          <p className={styles.stackIntro}>
            Используем современные инструменты и практики, чтобы решения были надёжными, безопасными и масштабируемыми.
          </p>
          <div className={styles.stackGrid}>
            {techStack.map((item) => (
              <article key={item.title} className={styles.stackCard}>
                <h3>{item.title}</h3>
                <p>{item.items}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.workflow}>
        <div className="container">
          <div className={styles.workflowInner}>
            <h2>Как мы выстраиваем работу</h2>
            <ol>
              <li>
                <strong>Погружаемся в задачу.</strong> Проводим интервью, изучаем текущую инфраструктуру, определяем метрики успеха.
              </li>
              <li>
                <strong>Собираем команду.</strong> Формируем оптимальный состав специалистов, согласовываем формат взаимодействия и процессы.
              </li>
              <li>
                <strong>Работаем итерациями.</strong> Прозрачные спринты, регулярные демо, планирование релизов и контроль качества.
              </li>
              <li>
                <strong>Обеспечиваем поддержку.</strong> Передаём знания, внедряем мониторинг и сопровождаем продукт после релиза.
              </li>
            </ol>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;