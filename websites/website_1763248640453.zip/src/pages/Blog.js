import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Сценарии внедрения микросервисной архитектуры',
    date: '12 марта 2024',
    category: 'Архитектура',
    excerpt: 'Разбираем, как подготовиться к переходу на микросервисы, какие метрики отслеживать и как построить постепенную миграцию.',
    image: 'https://picsum.photos/800/600?random=41'
  },
  {
    title: 'Построение культуры качества в распределённых командах',
    date: '4 марта 2024',
    category: 'Процессы',
    excerpt: 'Что важно для внедрения QA-практик, как настроить автоматизацию и вовлечь команду в заботу о качестве.',
    image: 'https://picsum.photos/800/600?random=42'
  },
  {
    title: 'Как подготовить продукт к масштабированию',
    date: '26 февраля 2024',
    category: 'Продукт',
    excerpt: 'Планирование масштабирования начинается с архитектуры, аналитики и грамотной командной структуры.',
    image: 'https://picsum.photos/800/600?random=43'
  },
  {
    title: 'Observability: наблюдаемость как основа устойчивости',
    date: '19 февраля 2024',
    category: 'Инфраструктура',
    excerpt: 'Инструменты, метрики и подходы, которые помогают заранее видеть узкие места и реагировать на изменения.',
    image: 'https://picsum.photos/800/600?random=44'
  }
];

const Blog = () => {
  return (
    <>
      <Helmet>
        <title>Блог ТехноЛаб — практики и инсайты</title>
        <meta
          name="description"
          content="Блог ТехноЛаб: кейсы разработки, советы по управлению продуктами, технологические тренды и практики командной работы."
        />
        <meta name="keywords" content="Блог, ТехноЛаб, технологии, разработка, архитектура, продуктовые практики" />
        <link rel="canonical" href="https://www.example.com/blog" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Инсайты ТехноЛаб</h1>
            <p>Делимся опытом разработки, управления продуктами и технологической трансформации.</p>
          </div>
        </div>
      </section>

      <section className={styles.posts}>
        <div className="container">
          <div className={styles.grid}>
            {posts.map((post) => (
              <article key={post.title} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.cardContent}>
                  <span className={styles.meta}>{post.date} · {post.category}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <button className={styles.readMore} type="button">
                    Читать статью
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;