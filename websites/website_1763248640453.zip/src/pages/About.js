import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const milestones = [
  {
    year: '2012',
    title: 'Старт ТехноЛаб',
    description: 'Создали первую команду разработчиков и запустили пилотный проект для крупной медицинской сети.'
  },
  {
    year: '2015',
    title: 'Выход на крупные корпоративные проекты',
    description: 'Развернули несколько высоконагруженных решений для промышленности и транспорта.'
  },
  {
    year: '2018',
    title: 'Развитие консалтинга',
    description: 'Сформировали направление технологического консультирования и аудит архитектуры.'
  },
  {
    year: '2022',
    title: 'Собственные методологии',
    description: 'Отточили процессы, внедрили собственную Delivery-модель и практику кросс-функциональных команд.'
  }
];

const values = [
  {
    title: 'Ответственность',
    text: 'Берём на себя полную ответственность за результат, стараясь превзойти ожидания на каждом этапе проекта.'
  },
  {
    title: 'Инновации',
    text: 'Регулярно исследуем новые подходы и технологии, внедряем то, что действительно усиливает продукт.'
  },
  {
    title: 'Командность',
    text: 'Клиенты — часть нашей команды. Мы строим взаимодействие на прозрачности, вовлечённости и взаимном доверии.'
  },
  {
    title: 'Качество',
    text: 'Культура тестирования, code review и аналитики — обязательная составляющая любого решения ТехноЛаб.'
  }
];

const leadership = [
  {
    name: 'Максим Орлов',
    role: 'Генеральный директор',
    description: 'Стратегическое управление, развитие партнёрств и продуктов ТехноЛаб.',
    expertise: 'Digital-стратегии, корпоративные инновации'
  },
  {
    name: 'Валерия Петрова',
    role: 'Директор по технологиям',
    description: 'Определяет технологическую политику, курирует архитектуру и инженерные практики.',
    expertise: 'Архитектура, DevOps, автоматизация'
  },
  {
    name: 'Сергей Киселёв',
    role: 'Руководитель продуктового офиса',
    description: 'Отвечает за продуктовый подход, customer discovery и поддержку клиентских команд.',
    expertise: 'Product Management, Agile, Design Thinking'
  }
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>О компании ТехноЛаб — команда, подход и ценности</title>
        <meta
          name="description"
          content="ТехноЛаб — московская IT-компания, создающая программные решения и предоставляющая технологический консалтинг. Узнайте о нашей истории, команде и подходе."
        />
        <meta name="keywords" content="ТехноЛаб, IT-компания, команда разработчиков, консалтинг, история компании, ценности" />
        <link rel="canonical" href="https://www.example.com/o-kompanii" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.badge}>О компании</span>
            <h1>Мы строим технологические решения, которые помогают бизнесу развиваться</h1>
            <p>
              ТехноЛаб появился как компания энтузиастов разработки. Сегодня мы объединяем аналитиков, инженеров, дизайнеров и продуктовых менеджеров,
              чтобы создавать цифровые сервисы, устойчивые к любым вызовам.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div className={styles.missionText}>
              <h2>Миссия</h2>
              <p>
                Помогать компаниям уверенно использовать технологии, усиливая их бизнес-результаты. Мы верим, что грамотная цифровая стратегия и качественная реализация превращают идеи в долгосрочные продукты.
              </p>
            </div>
            <div className={styles.missionText}>
              <h2>Подход</h2>
              <p>
                Мы строим сотрудничество на принципе «одна команда». Каждый проект сопровождается выделенным проджектом, техлидом и аналитиком.
                Работаем короткими итерациями, фиксируя измеримые результаты. Внимание к деталям, открытая коммуникация и гибкость — обязательные элементы нашей работы.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.milestones}>
        <div className="container">
          <h2>Ключевые этапы развития</h2>
          <div className={styles.timeline}>
            {milestones.map((item) => (
              <article key={item.year} className={styles.timelineItem}>
                <span className={styles.year}>{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <div className={styles.valuesHeader}>
            <h2>Ценности, которые нас объединяют</h2>
            <p>Они формируют культуру ТехноЛаб и помогают принимать правильные решения в проектах.</p>
          </div>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.leadership}>
        <div className="container">
          <div className={styles.leadershipHeader}>
            <h2>Лидерская команда</h2>
            <p>Мы умножаем опыт друг друга и выстраиваем долгосрочные отношения с клиентами.</p>
          </div>
          <div className={styles.leadershipGrid}>
            {leadership.map((person) => (
              <article key={person.name} className={styles.leaderCard}>
                <h3>{person.name}</h3>
                <p className={styles.role}>{person.role}</p>
                <p>{person.description}</p>
                <span className={styles.expertise}>{person.expertise}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.culture}>
        <div className="container">
          <div className={styles.cultureInner}>
            <h2>Культура ответственности и развития</h2>
            <p>
              Мы регулярно инвестируем в обучение команды, проводим внутренние митапы, развиваем менторские программы и практики обмена знаниями.
              Это помогает нам сохранять высокие стандарты качества и оставаться на пике технологических трендов.
            </p>
            <p>
              Для клиентов мы — надёжный партнёр, который не боится сложных задач. Для команды — место, где ценят инициативу и поддерживают профессиональный рост.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;