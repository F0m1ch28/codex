document.addEventListener('DOMContentLoaded', () => {
  const banner = document.querySelector('[data-cookie-banner]');
  if (!banner) return;

  const storedChoice = localStorage.getItem('edparis-cookies');
  if (storedChoice) {
    banner.setAttribute('hidden', '');
    return;
  }

  const acceptBtn = banner.querySelector('[data-cookie-accept]');
  const declineBtn = banner.querySelector('[data-cookie-decline]');

  const closeBanner = (choice) => {
    localStorage.setItem('edparis-cookies', choice);
    banner.classList.remove('is-visible');
    banner.addEventListener('transitionend', () => {
      banner.setAttribute('hidden', '');
    }, { once: true });
  };

  acceptBtn?.addEventListener('click', () => closeBanner('accepted'));
  declineBtn?.addEventListener('click', () => closeBanner('declined'));

  requestAnimationFrame(() => banner.classList.add('is-visible'));
});