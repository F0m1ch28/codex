document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const body = document.body;

  if (navToggle) {
    navToggle.addEventListener('click', function () {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      body.classList.toggle('nav-visible');
    });
  }

  const navLinks = document.querySelectorAll('.site-nav a');
  navLinks.forEach(function (link) {
    link.addEventListener('click', function () {
      body.classList.remove('nav-visible');
      if (navToggle) {
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  });

  const revealElements = document.querySelectorAll('.reveal-on-scroll');
  const observer = new IntersectionObserver(function (entries, observerInstance) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observerInstance.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.18
  });

  revealElements.forEach(function (el) {
    observer.observe(el);
  });

  const form = document.querySelector('form[data-form="contact"]');
  if (form) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      const toast = document.getElementById('form-toast');
      if (toast) {
        toast.textContent = 'Message queued. Redirecting to confirmation.';
        toast.classList.add('visible');
        setTimeout(function () {
          toast.classList.remove('visible');
        }, 2200);
      }
      setTimeout(function () {
        window.location.href = form.getAttribute('action');
      }, 1600);
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptCookie = document.getElementById('cookie-accept');
  const declineCookie = document.getElementById('cookie-decline');
  const cookieChoice = localStorage.getItem('oeCookieChoice');

  if (!cookieChoice && cookieBanner) {
    cookieBanner.classList.add('active');
  }

  function setCookieChoice(value) {
    localStorage.setItem('oeCookieChoice', value);
    if (cookieBanner) {
      cookieBanner.classList.remove('active');
    }
  }

  if (acceptCookie) {
    acceptCookie.addEventListener('click', function () {
      setCookieChoice('accepted');
    });
  }

  if (declineCookie) {
    declineCookie.addEventListener('click', function () {
      setCookieChoice('declined');
    });
  }
});