document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.primary-nav');
    const body = document.body;

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('nav-open');
            body.classList.toggle('nav-open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('nav-open');
                body.classList.remove('nav-open');
                navToggle.setAttribute('aria-expanded', 'false');
                window.scrollTo({ top: 0, behavior: 'auto' });
            });
        });
    }

    const scrollBtn = document.getElementById('scrollTopBtn');
    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                scrollBtn.classList.add('visible');
            } else {
                scrollBtn.classList.remove('visible');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const cookieKey = 'tn_cookie_consent';
        const consent = localStorage.getItem(cookieKey);
        if (consent === 'accepted') {
            cookieBanner.classList.add('hide');
        } else {
            cookieBanner.classList.add('show');
            const acceptBtn = cookieBanner.querySelector('.cookie-accept');
            acceptBtn.addEventListener('click', () => {
                localStorage.setItem(cookieKey, 'accepted');
                cookieBanner.classList.remove('show');
                cookieBanner.classList.add('hide');
            });
        }
    }

    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const confirmation = contactForm.querySelector('.confirmation');
            confirmation.textContent = 'Thank you for reaching out. Our strategy advisors will respond within one business day.';
            contactForm.reset();
        });
    }

    const yearEl = document.getElementById('year');
    if (yearEl) {
        yearEl.textContent = new Date().getFullYear();
    }

    window.addEventListener('pageshow', () => {
        window.scrollTo(0, 0);
    });
});