(function () {
  const path = window.location.pathname.toLowerCase();
  const redirects = {
    "/history": "topology.html",
    "/history.html": "topology.html",
    "/infrastructure": "nodes.html",
    "/infrastructure.html": "nodes.html",
    "/systems": "coordination.html",
    "/systems.html": "coordination.html",
    "/resilience": "dynamics.html",
    "/resilience.html": "dynamics.html"
  };
  Object.keys(redirects).forEach(function (key) {
    if (path.endsWith(key)) {
      window.location.replace(redirects[key]);
    }
  });
})();
document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");
  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", function () {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      primaryNav.classList.toggle("open");
    });
    primaryNav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        if (window.innerWidth < 992) {
          navToggle.setAttribute("aria-expanded", "false");
          primaryNav.classList.remove("open");
        }
      });
    });
  }
  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const storedChoice = localStorage.getItem("gridexis_cookie_choice");
    if (!storedChoice) {
      requestAnimationFrame(function () {
        cookieBanner.classList.add("show");
      });
    }
    const acceptBtn = cookieBanner.querySelector("[data-cookie='accept']");
    const declineBtn = cookieBanner.querySelector("[data-cookie='decline']");
    function handleChoice(choice) {
      localStorage.setItem("gridexis_cookie_choice", choice);
      cookieBanner.classList.remove("show");
      setTimeout(function () {
        cookieBanner.style.display = "none";
      }, 400);
    }
    if (acceptBtn) {
      acceptBtn.addEventListener("click", function () {
        handleChoice("accepted");
      });
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", function () {
        handleChoice("declined");
      });
    }
  }
  const canvas = document.getElementById("gridCanvas");
  if (canvas) {
    const ctx = canvas.getContext("2d");
    const width = canvas.width = canvas.offsetWidth;
    const height = canvas.height = canvas.offsetHeight;
    const nodes = [];
    const gridSize = 10;
    function initNodes() {
      nodes.length = 0;
      for (let x = 0; x <= gridSize; x++) {
        for (let y = 0; y <= gridSize; y++) {
          nodes.push({
            x: (x / gridSize) * width,
            y: (y / gridSize) * height,
            phase: Math.random() * Math.PI * 2,
            speed: 0.005 + Math.random() * 0.01
          });
        }
      }
    }
    function draw() {
      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = "rgba(12,15,20,0.82)";
      ctx.fillRect(0, 0, width, height);
      ctx.strokeStyle = "rgba(37,99,235,0.35)";
      ctx.lineWidth = 1;
      for (let i = 0; i <= gridSize; i++) {
        const pos = (i / gridSize) * width;
        ctx.beginPath();
        ctx.moveTo(pos, 0);
        ctx.lineTo(pos, height);
        ctx.stroke();
      }
      for (let i = 0; i <= gridSize; i++) {
        const pos = (i / gridSize) * height;
        ctx.beginPath();
        ctx.moveTo(0, pos);
        ctx.lineTo(width, pos);
        ctx.stroke();
      }
      nodes.forEach(function (node, idx) {
        const pulse = Math.sin(Date.now() * node.speed + node.phase) * 4;
        const radius = 3 + pulse;
        ctx.beginPath();
        const color = idx % 3 === 0 ? "rgba(34,211,238,0.8)" : idx % 3 === 1 ? "rgba(74,222,128,0.8)" : "rgba(37,99,235,0.8)";
        ctx.fillStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = 12;
        ctx.arc(node.x, node.y, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      });
      requestAnimationFrame(draw);
    }
    initNodes();
    draw();
    window.addEventListener("resize", function () {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      initNodes();
    });
  }
});