import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Success from './pages/Success';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Cookies from './pages/Cookies';
import styles from './App.module.css';

const App = () => {
  return (
    <div className={styles.appWrapper}>
      <Header />
      <ScrollToTop />
      <main className={styles.mainContent}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/pro-nas" element={<About />} />
          <Route path="/posluhy" element={<Services />} />
          <Route path="/nashi-uspikhy" element={<Success />} />
          <Route path="/kontakty" element={<Contact />} />
          <Route path="/umovy" element={<Terms />} />
          <Route path="/konfidentsiinist" element={<Privacy />} />
          <Route path="/polityka-cookie" element={<Cookies />} />
          <Route
            path="*"
            element={
              <div className={styles.notFound}>
                <h1>Сторінку не знайдено</h1>
                <p>На жаль, сторінка, яку ви шукаєте, не існує.</p>
              </div>
            }
          />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
};

export default App;