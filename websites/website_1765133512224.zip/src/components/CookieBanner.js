import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem('cookieConsent');
    if (!storedConsent) {
      const timeout = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timeout);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookieConsent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
    }
  return (
    <div className={styles.banner} role="region" aria-label="Повідомлення про файли Cookie">
      <p>
        Ми використовуємо файли Cookie, щоб відстежувати якість сервісу та налаштовувати контент під потреби клієнтів. 
        Детальніше у <Link to="/polityka-cookie">Політиці Cookie</Link>.
      </p>
      <button type="button" onClick={handleAccept} className={styles.button}>
        Прийняти
      </button>
    </div>
  );
};

export default CookieBanner;