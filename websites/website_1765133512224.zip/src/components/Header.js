import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => {
    setMenuOpen((prev) => !prev);
  };

  const handleClose = () => {
    setMenuOpen(false);
  };

  return (
    <header className={styles.header} role="banner">
      <div className={styles.container}>
        <Link to="/" className={styles.logo} onClick={handleClose}>
          Професійне дресирування німецьких вівчарок
        </Link>
        <nav className={styles.nav} aria-label="Головне меню">
          <button
            type="button"
            className={styles.menuButton}
            onClick={handleToggle}
            aria-expanded={isMenuOpen}
            aria-controls="main-navigation"
          >
            <span className={styles.menuIcon} />
            <span className="sr-only">Перемкнути меню</span>
          </button>
          <ul
            id="main-navigation"
            className={`${styles.navList} ${isMenuOpen ? styles.open : ''}`}
          >
            <li>
              <NavLink to="/" onClick={handleClose} end>
                Головна
              </NavLink>
            </li>
            <li>
              <NavLink to="/pro-nas" onClick={handleClose}>
                Про нас
              </NavLink>
            </li>
            <li>
              <NavLink to="/posluhy" onClick={handleClose}>
                Послуги
              </NavLink>
            </li>
            <li>
              <NavLink to="/nashi-uspikhy" onClick={handleClose}>
                Наші успіхи
              </NavLink>
            </li>
            <li>
              <NavLink to="/kontakty" onClick={handleClose}>
                Контакти
              </NavLink>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;