import { useEffect } from 'react';

const Seo = ({ title, description, keywords }) => {
  useEffect(() => {
    const siteName = 'Професійне дресирування німецьких вівчарок';
    document.title = title ? `${title} | ${siteName}` : siteName;

    const ensureMetaTag = (name, content) => {
      if (!content) return;
      let element = document.querySelector(`meta[name="${name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('name', name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    ensureMetaTag('description', description || 'Професійні кінологи зосереджені на дресируванні німецьких вівчарок у Варшаві та Кракові.');
    ensureMetaTag('keywords', keywords || 'дресирування, німецькі вівчарки, кінолог, Варшава, Краків');
  }, [title, description, keywords]);

  return null;
};

export default Seo;