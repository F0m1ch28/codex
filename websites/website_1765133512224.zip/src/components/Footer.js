import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.container}>
        <div className={styles.brand}>
          <h2>Професійне дресирування німецьких вівчарок</h2>
          <p>
            Команда кінологів, які розуміють характер німецьких вівчарок і
            вибудовують результативний діалог між собакою та людиною.
          </p>
        </div>
        <div className={styles.columns}>
          <div>
            <h3>Меню</h3>
            <ul>
              <li><Link to="/">Головна</Link></li>
              <li><Link to="/pro-nas">Про нас</Link></li>
              <li><Link to="/posluhy">Послуги</Link></li>
              <li><Link to="/nashi-uspikhy">Наші успіхи</Link></li>
              <li><Link to="/kontakty">Контакти</Link></li>
            </ul>
          </div>
          <div>
            <h3>Контакти</h3>
            <address>
              <strong>Варшава:</strong> вул. Тренувальна, 10<br />
              <strong>Краків:</strong> вул. Кінологічна, 5А<br />
              <a href="tel:+48123456789">+48 123 456 789</a><br />
              <a href="mailto:trener@sobaky.pl">trener@sobaky.pl</a>
            </address>
          </div>
          <div>
            <h3>Правова інформація</h3>
            <ul>
              <li><Link to="/umovy">Умови</Link></li>
              <li><Link to="/konfidentsiinist">Конфіденційність</Link></li>
              <li><Link to="/polityka-cookie">Політика Cookie</Link></li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottomLine}>
        <p>© {new Date().getFullYear()} Професійне дресирування німецьких вівчарок. Усі права захищені.</p>
      </div>
    </footer>
  );
};

export default Footer;