import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Services.module.css';

const servicesList = [
  {
    key: 'okd',
    title: 'Загальний курс дресирування (ОКД)',
    intro: 'Вчимо собаку концентруватися на власнику, слідкувати за командою й працювати у будь-якому оточенні.',
    details: [
      'Стійкі команди: сидіти, лежати, поруч, місце, до мене з різних дистанцій.',
      'Побудова витримки у присутності людей, собак, транспортних засобів.',
      'Розвиток самоконтролю та правильне використання іграшок та ласощів.',
    ],
    image: 'https://images.unsplash.com/photo-1507146426996-ef05306b995a?auto=format&fit=crop&w=1200&q=80',
  },
  {
    key: 'behavior',
    title: 'Корекція небажаної поведінки',
    intro: 'Працюємо з реактивністю, агресією, страхами, гіперактивністю. Навчаємо власника впевнено керувати ситуацією.',
    details: [
      'Поглиблена діагностика причин поведінки, аналіз маркерів стресу.',
      'Системи зміни звичок: робота з ресурсами, зниження збудженості, вправи на релаксацію.',
      'Планування середовища й правил для всієї родини.',
    ],
    image: 'https://images.unsplash.com/photo-1508672019048-805c876b67e2?auto=format&fit=crop&w=1200&q=80',
  },
  {
    key: 'companion',
    title: 'Підготовка собаки-компаньйона',
    intro: 'Формуємо виховану та врівноважену вівчарку, яка комфортно почувається вдома й у подорожах.',
    details: [
      'Розвиток спокійної поведінки в квартирі, офісі, під час поїздок.',
      'Комунікація з дітьми, гостями, незнайомими тваринами.',
      'Побудова щоденних ритуалів для підтримки балансу енергії.',
    ],
    image: 'https://images.unsplash.com/photo-1535967023574-3e27d66ea1c3?auto=format&fit=crop&w=1200&q=80',
  },
  {
    key: 'defense',
    title: 'Основи захищено-караульної служби',
    intro: 'Відпрацьовуємо сценарії оборони, навчаємо власника правильно взаємодіяти з фігурантом та контролювати емоції собаки.',
    details: [
      'Вправи на пошук, затримання та відпуск відповідно до команд.',
      'Побудова впевненого хвату, робота з шумом та відволіканнями.',
      'Навчання власника техніці безпечної взаємодії та відпрацювання ситуацій.',
    ],
    image: 'https://images.unsplash.com/photo-1514986888952-8cd320577b68?auto=format&fit=crop&w=1200&q=80',
  },
];

const faqs = [
  {
    question: 'Скільки триває курс ОКД для німецької вівчарки?',
    answer: 'Базова програма займає 10–12 тижнів. Ми адаптуємо тривалість під собаку, забезпечуючи закріплення навичок між заняттями.',
  },
  {
    question: 'Чи можемо ми тренуватися вдома?',
    answer: 'Так. Частину занять можемо проводити на вашій локації у Варшаві або Кракові, щоб відпрацювати поведінку у звичному середовищі.',
  },
  {
    question: 'Що робити, якщо собака агресивна до людей?',
    answer: 'Перед початком тренувань ми проводимо оцінку поведінки, розробляємо план корекції та пояснюємо правила безпечної роботи.',
  },
  {
    question: 'Яка частота тренувань оптимальна?',
    answer: 'Рекомендуємо 1–2 тренування на тиждень із кінологом плюс домашні сесії за планом. Такий ритм дає стабільний прогрес.',
  },
];

const Services = () => {
  const [activeService, setActiveService] = useState(servicesList[0].key);
  const currentService = servicesList.find((service) => service.key === activeService);

  return (
    <>
      <Seo
        title="Послуги"
        description="Програми дресирування німецьких вівчарок: ОКД, корекція поведінки, підготовка собаки-компаньйона, основи захищено-караульної служби."
        keywords="ОКД, корекція поведінки, захищено-караульна служба, собака-компаньйон"
      />
      <div className={styles.page}>
        <header className={styles.header}>
          <h1>Наші програми</h1>
          <p>
            Кожна програма комбінується залежно від характеру вівчарки та очікувань родини. Ми працюємо за принципом зворотного звʼязку: 
            пояснюємо логіку і залишаємо докладні плани між сесіями.
          </p>
        </header>

        <section className={styles.selector} aria-labelledby="services-selector">
          <h2 id="services-selector" className="sr-only">Перелік послуг</h2>
          <div className={styles.tabs} role="tablist">
            {servicesList.map((service) => (
              <button
                key={service.key}
                type="button"
                role="tab"
                aria-selected={activeService === service.key}
                className={`${styles.tabButton} ${activeService === service.key ? styles.tabButtonActive : ''}`}
                onClick={() => setActiveService(service.key)}
              >
                {service.title}
              </button>
            ))}
          </div>

          <article className={styles.serviceDetail} role="tabpanel" aria-live="polite">
            <div className={styles.detailContent}>
              <h3>{currentService.title}</h3>
              <p className={styles.intro}>{currentService.intro}</p>
              <ul>
                {currentService.details.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <Link to="/kontakty" className={styles.ctaLink}>
                Запланувати консультацію →
              </Link>
            </div>
            <div className={styles.detailImageWrapper}>
              <img
                src={currentService.image}
                alt={currentService.title}
                loading="lazy"
              />
            </div>
          </article>
        </section>

        <section className={styles.faq} aria-labelledby="faq-title">
          <h2 id="faq-title">Поширені запитання</h2>
          <div className={styles.accordion}>
            {faqs.map((faq, index) => (
              <details key={faq.question} open={index === 0}>
                <summary>{faq.question}</summary>
                <p>{faq.answer}</p>
              </details>
            ))}
          </div>
        </section>

        <section className={styles.callout}>
          <div>
            <h2>Хочете отримати план дій для вашої вівчарки?</h2>
            <p>Залиште запит, і ми зателефонуємо, щоб обговорити потреби собаки, рівень навичок та формат тренувань.</p>
          </div>
          <Link to="/kontakty" className={styles.calloutButton}>
            Зв&apos;язатися з кінологом
          </Link>
        </section>
      </div>
    </>
  );
};

export default Services;