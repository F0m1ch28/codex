import React from 'react';
import Seo from '../components/Seo';
import styles from './About.module.css';

const milestones = [
  {
    year: '2012',
    title: 'Перші тренування',
    description:
      'Створили клуб дресирування німецьких вівчарок у Варшаві та сформували команду інструкторів.',
  },
  {
    year: '2016',
    title: 'Сертифікації IGP',
    description:
      'Наші кінологи склали міжнародні іспити IGP та IPO, зосередившись на керованості та мотивації собаки.',
  },
  {
    year: '2019',
    title: 'Відкриття локації у Кракові',
    description:
      'Розширили тренувальні майданчики та запустили програму корекції поведінки для міських собак.',
  },
  {
    year: '2023',
    title: 'Гібридні програми',
    description:
      'Поєднали офлайн-тренування з відеоаналізом, щоб підтримувати родини між заняттями.',
  },
];

const team = [
  {
    name: 'Ігор Ковальський',
    role: 'Головний кінолог, спеціаліст з ОКД',
    description:
      '10 років працює з вівчарками службової лінії. Сертифікований інструктор IGP, член польської федерації кінологів.',
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&w=600&q=80',
  },
  {
    name: 'Марія Новак',
    role: 'Тренерка з поведінкових програм',
    description:
      'Займається поведінкою собак, що проживають у великих містах, працює з гармонією сімʼї та собаки.',
    image: 'https://images.unsplash.com/photo-1594824477634-6f1d9c0fbaee?auto=format&fit=crop&w=600&q=80',
  },
  {
    name: 'Томаш Левандовський',
    role: 'Інструктор захищено-караульної служби',
    description:
      'Готує собак до роботи з фігурантом, вчить власників правильно керувати енергією робочої собаки.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80',
  },
];

const values = [
  {
    title: 'Відповідальність',
    description: 'Ми плануємо тренування так, щоб собака залишалася стабільною у побуті та під час роботи.',
  },
  {
    title: 'Партнерство',
    description: 'Власник — ключовий учасник процесу. Ми пояснюємо, як підтримувати навички щодня.',
  },
  {
    title: 'Безпека',
    description: 'Залучаємо тільки перевірені методики, що не завдають шкоди психіці та здоров’ю собаки.',
  },
];

const About = () => {
  return (
    <>
      <Seo
        title="Про нас"
        description="Познайомтеся з командою кінологів, що спеціалізуються на німецьких вівчарках у Варшаві та Кракові. Наші цінності, історія та підхід."
        keywords="кінолог Варшава, кінолог Краків, тренер німецьких вівчарок"
      />
      <article className={styles.page}>
        <header className={styles.hero}>
          <div>
            <h1>Про нашу команду та підхід</h1>
            <p>
              Ми об’єднуємо кінологів, що пройшли шлях від спортивних стартів до роботи з сімейними вівчарками.
              Головне завдання — створити собак, яким довіряють у нескінченній кількості сценаріїв.
            </p>
          </div>
          <img
            src="https://images.unsplash.com/photo-1596496051156-0127679c4f2c?auto=format&fit=crop&w=1400&q=80"
            alt="Команда кінологів під час аналізу тренування"
            loading="lazy"
          />
        </header>

        <section className={styles.mission}>
          <h2>Місія та бачення</h2>
          <div className={styles.missionGrid}>
            <p>
              Німецька вівчарка — це потужний інтелект, енергія та відданість. Щоб ці якості працювали на користь родини,
              потрібен план, послідовність і розуміння характеру. Саме тому ми працюємо комплексно: аналізуємо середовище,
              формуємо щоденні ритуали, тренуємо власника бути впевненим лідером.
            </p>
            <p>
              Ми прагнемо, щоб кожна собака, яка проходить наші програми, була соціалізованою, керованою і щасливою.
              Кожен тренер розробляє підхід під конкретну родину, враховуючи графік, рівень фізичної підготовки та амбіції власника.
            </p>
          </div>
        </section>

        <section className={styles.timeline} aria-labelledby="timeline-title">
          <h2 id="timeline-title">Ключові етапи</h2>
          <div className={styles.timelineGrid}>
            {milestones.map((item) => (
              <div key={item.year} className={styles.timelineCard}>
                <span>{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            ))}
          </div>
        </section>

        <section className={styles.team} aria-labelledby="team-title">
          <h2 id="team-title">Команда тренерів</h2>
          <p className={styles.teamIntro}>
            Ми не просто навчаємо команд — ми пояснюємо логіку, показуємо правильну мотивацію та вчимо читати мову тіла собаки.
          </p>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img src={member.image} alt={`${member.name} — ${member.role}`} loading="lazy" />
                </div>
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <p className={styles.role}>{member.role}</p>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.values} aria-labelledby="values-title">
          <h2 id="values-title">Наші цінності</h2>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.testimonials} aria-labelledby="about-testimonials">
          <h2 id="about-testimonials">Відгуки власників</h2>
          <div className={styles.quotesGrid}>
            <blockquote>
              <p>“Усвідомлення процесу — це те, що нам подарували тренери. Ми навчилися правильно реагувати на кожну ситуацію.”</p>
              <cite>Катажина, Краків</cite>
            </blockquote>
            <blockquote>
              <p>“Вони навчили мене бачити сигнали собаки. Тепер я розумію, коли потрібен відпочинок, а коли — додаткова мотивація.”</p>
              <cite>Ірина, Варшава</cite>
            </blockquote>
            <blockquote>
              <p>“Після курсу наша вівчарка стала працювати на голос, а не на натяг повідка. Це справжній прогрес.”</p>
              <cite>Павел, Варшава</cite>
            </blockquote>
          </div>
        </section>
      </article>
    </>
  );
};

export default About;