import React, { useMemo, useState } from 'react';
import Seo from '../components/Seo';
import styles from './Success.module.css';

const cases = [
  {
    id: 1,
    city: 'Варшава',
    title: 'Марсі та контроль при вигулі',
    description:
      'Собака реагувала на кожен рух навколо. За 10 тижнів відпрацювали витримку біля доріг і команду “поруч”.',
    result: 'Стабільна увага на власника, впевнені прогулянки у центрі.',
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 2,
    city: 'Краків',
    title: 'Рекса та подолання страхів',
    description:
      'Голосні звуки і транспорт викликали паніку. Працювали з десенсибілізацією, вправами на розслаблення.',
    result: 'Спокій на зупинках трамвая і фокус на завдання, а не на шум.',
    image: 'https://images.unsplash.com/photo-1517423440428-a5a00ad493e8?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 3,
    city: 'Варшава',
    title: 'Караульна служба для Неро',
    description:
      'Неро мав сильний драйв, але брак керованості. Відпрацювали роботу з фігурантом і чіткий відпуск.',
    result: 'Проходження тесту на захист, слухняність навіть у піку енергії.',
    image: 'https://images.unsplash.com/photo-1611695434398-ca9d75315682?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 4,
    city: 'Краків',
    title: 'Луна та родинна гармонія',
    description:
      'Молода вівчарка надто активно зустрічала гостей. Розробили ритуал спокійної зустрічі й вправи на самоконтроль.',
    result: 'Спокійні візити, Луна зосереджується на власнику та іграшці.',
    image: 'https://images.unsplash.com/photo-1619983081633-cc8c2c43c2d2?auto=format&fit=crop&w=1200&q=80',
  },
];

const Success = () => {
  const [filter, setFilter] = useState('усі');

  const filteredCases = useMemo(() => {
    if (filter === 'усі') return cases;
    return cases.filter((item) => item.city === filter);
  }, [filter]);

  return (
    <>
      <Seo
        title="Наші успіхи"
        description="Приклади дресирування німецьких вівчарок у Варшаві та Кракові. Випускники програм ОКД, корекції поведінки та захисної служби."
        keywords="успіхи дресирування, кейси німецьких вівчарок"
      />
      <div className={styles.page}>
        <header className={styles.header}>
          <h1>Випускники та їх історії</h1>
          <p>
            Кожен кейс — це спільна робота тренера та родини. Ми показуємо ключові зміни, яких вдалось досягти, та інструменти, що зберігають результат.
          </p>
        </header>

        <div className={styles.filters} role="tablist" aria-label="Фільтр історій успіху">
          {['усі', 'Варшава', 'Краків'].map((city) => (
            <button
              key={city}
              type="button"
              role="tab"
              aria-selected={filter === city}
              className={`${styles.filterButton} ${filter === city ? styles.active : ''}`}
              onClick={() => setFilter(city)}
            >
              {city}
            </button>
          ))}
        </div>

        <div className={styles.grid}>
          {filteredCases.map((item) => (
            <article key={item.id} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={item.image} alt={`${item.title} — ${item.city}`} loading="lazy" />
                <span className={styles.tag}>{item.city}</span>
              </div>
              <div className={styles.content}>
                <h2>{item.title}</h2>
                <p>{item.description}</p>
                <div className={styles.result}>
                  <h3>Результат</h3>
                  <p>{item.result}</p>
                </div>
              </div>
            </article>
          ))}
        </div>

        <section className={styles.metrics}>
          <div>
            <span>92%</span>
            <p>клієнтів продовжують тренуватися з нами понад 6 місяців</p>
          </div>
          <div>
            <span>48</span>
            <p>вівчарок підготували до захисної служби за останні 2 роки</p>
          </div>
          <div>
            <span>100%</span>
            <p>родин отримали післякурсові плани підтримки навичок</p>
          </div>
        </section>
      </div>
    </>
  );
};

export default Success;