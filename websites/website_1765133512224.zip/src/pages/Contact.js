import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  phone: '',
  message: '',
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Вкажіть ім'я.";
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Вкажіть email.';
    } else if (!/^[\w-.]+@[\w-]+\.[\w-.]+$/.test(formData.email.trim())) {
      newErrors.email = 'Перевірте формат email.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Опишіть запит.';
    }
    return newErrors;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length) {
      setErrors(validation);
      return;
    }

    setErrors({});
    setStatus('loading');

    setTimeout(() => {
      setStatus('success');
      setFormData(initialFormState);
    }, 1200);
  };

  return (
    <>
      <Seo
        title="Контакти"
        description="Контакти команди дресирування німецьких вівчарок у Варшаві та Кракові. Замовте консультацію або поставте питання."
        keywords="контакти кінолога, дресирування Варшава, дресирування Краків"
      />
      <div className={styles.page}>
        <header className={styles.header}>
          <h1>Звʼяжіться з нами</h1>
          <p>
            Розкажіть про вашу вівчарку, мету та графік. Ми запропонуємо формат співпраці і підготуємо індивідуальний план.
          </p>
        </header>

        <section className={styles.grid}>
          <div className={styles.contactsCard}>
            <h2>Контактні дані</h2>
            <ul>
              <li>
                <strong>Телефон:</strong>{' '}
                <a href="tel:+48123456789">+48 123 456 789</a>
              </li>
              <li>
                <strong>Email:</strong>{' '}
                <a href="mailto:trener@sobaky.pl">trener@sobaky.pl</a>
              </li>
            </ul>
            <div className={styles.locations}>
              <div>
                <h3>Варшава</h3>
                <p>вул. Тренувальна, 10</p>
              </div>
              <div>
                <h3>Краків</h3>
                <p>вул. Кінологічна, 5А</p>
              </div>
            </div>
            <p className={styles.note}>
              Працюємо щодня за попереднім записом. Виїжджаємо на тренування у межах міста та передмістя.
            </p>
          </div>

          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <fieldset>
              <legend>Форма зворотного звʼязку</legend>
              <label htmlFor="name">Ім&apos;я *</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && (
                <span id="name-error" className={styles.error}>{errors.name}</span>
              )}

              <label htmlFor="email">Email *</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && (
                <span id="email-error" className={styles.error}>{errors.email}</span>
              )}

              <label htmlFor="phone">Телефон</label>
              <input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
              />

              <label htmlFor="message">Запит *</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && (
                <span id="message-error" className={styles.error}>{errors.message}</span>
              )}
            </fieldset>
            <button type="submit" className={styles.submitButton} disabled={status === 'loading'}>
              {status === 'loading' ? 'Надсилаємо...' : 'Надіслати'}
            </button>
            {status === 'success' && (
              <div role="status" className={styles.successMessage}>
                Дякуємо! Ми звʼяжемося з вами протягом одного робочого дня.
              </div>
            )}
          </form>
        </section>
      </div>
    </>
  );
};

export default Contact;