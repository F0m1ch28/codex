import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const statsData = [
  { label: 'років живого досвіду', value: 12 },
  { label: 'випускників у Варшаві та Кракові', value: 340 },
  { label: 'індивідуальних програм поведінки', value: 86 },
];

const testimonials = [
  {
    quote: 'Після трьох місяців роботи наш Рекс став упевненим і керованим навіть у насиченому міському середовищі.',
    author: 'Анна, Варшава',
  },
  {
    quote: 'Команда відчула характер нашої собаки буквально з першого заняття. Ми нарешті знайшли розуміння.',
    author: 'Марцін, Краків',
  },
  {
    quote: 'Глибокі знання і тепле ставлення до вівчарок. Тренування нагадують партнерський діалог, а не накази.',
    author: 'Олена, Варшава',
  },
];

const servicesOverview = [
  {
    title: 'Загальний курс дресирування (ОКД)',
    description:
      'Відпрацьовуємо базові команди, витримку, керування емоціями собаки та взаємодію на повідку й без нього.',
    icon: '🎯',
  },
  {
    title: 'Корекція небажаної поведінки',
    description:
      'Разом аналізуємо причину небажаних реакцій та вибудовуємо послідовний алгоритм корекції для кожної сім’ї.',
    icon: '🧭',
  },
  {
    title: 'Підготовка собаки-компаньйона',
    description:
      'Розвиваємо навички спокійної поведінки вдома, в транспорті, з дітьми. Спрямовуємо енергію вівчарки у корисні заняття.',
    icon: '🤝',
  },
  {
    title: 'Основи захищено-караульної служби',
    description:
      'Вчимо собаку працювати з енергією, чітко реагувати на загрози та залишатися керованою у будь-яких сценаріях.',
    icon: '🛡️',
  },
];

const locations = [
  {
    city: 'Варшава',
    description: 'Проводимо індивідуальні й групові заняття на спеціально обладнаних майданчиках та у міських парках.',
    image:
      'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1200&q=80',
  },
  {
    city: 'Краків',
    description: 'Польові тренування, виїзди до клієнта, робота з міською динамікою та історичним центром.',
    image:
      'https://images.unsplash.com/photo-1520781359717-3eb98461c9fe?auto=format&fit=crop&w=1200&q=80',
  },
];

const galleryItems = [
  {
    id: 1,
    city: 'Варшава',
    title: 'Зв’язок під час руху',
    description: 'Комбінація команд на витримку та рух із власником.',
    image: 'https://images.unsplash.com/photo-1601758176176-0d4a6f1a2bb9?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 2,
    city: 'Краків',
    title: 'Робота з фігурантом',
    description: 'Сесія із захищено-караульної служби та правильного хвату.',
    image: 'https://images.unsplash.com/photo-1619983081633-cc8c2c43c2d2?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 3,
    city: 'Варшава',
    title: 'Соціалізація у місті',
    description: 'Відпрацювання спокою та концентрації у жвавих умовах.',
    image: 'https://images.unsplash.com/photo-1530281700549-e82e7bf110d6?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 4,
    city: 'Краків',
    title: 'Гра через навчання',
    description: 'Використовуємо мотиваційну гру як інструмент слухняності.',
    image: 'https://images.unsplash.com/photo-1517423440428-a5a00ad493e8?auto=format&fit=crop&w=1200&q=80',
  },
];

const blogPosts = [
  {
    title: 'Як пояснити вівчарці нову команду з першої спроби',
    excerpt: 'Покроковий алгоритм, що враховує темперамент та мотивацію німецької вівчарки.',
    link: '/posluhy',
  },
  {
    title: 'Соціалізація у великому місті: чек-лист кінолога',
    excerpt: 'Говоримо про безпечні знайомства з людьми, транспортом і міськими звуками.',
    link: '/pro-nas',
  },
  {
    title: 'Як зняти напругу собаки перед тренуванням',
    excerpt: 'Прості ритуали, що допомагають переключити собаку в робочий настрій.',
    link: '/posluhy',
  },
];

const Home = () => {
  const [animatedValues, setAnimatedValues] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeFilter, setActiveFilter] = useState('усі');

  useEffect(() => {
    const timers = statsData.map((stat, index) => {
      const target = stat.value;
      const duration = 1600;
      const step = Math.max(1, Math.floor(target / (duration / 30)));
      const interval = setInterval(() => {
        setAnimatedValues((prev) => {
          const next = [...prev];
          if (next[index] + step >= target) {
            next[index] = target;
            clearInterval(interval);
          } else {
            next[index] = next[index] + step;
          }
          return next;
        });
      }, 30);
      return interval;
    });

    return () => timers.forEach(clearInterval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6500);

    return () => clearInterval(interval);
  }, []);

  const filteredGallery = useMemo(() => {
    if (activeFilter === 'усі') {
      return galleryItems;
    }
    return galleryItems.filter((item) => item.city === activeFilter);
  }, [activeFilter]);

  return (
    <>
      <Seo
        title="Головна"
        description="Професійне дресирування німецьких вівчарок у Варшаві та Кракові. Індивідуальні програми ОКД, корекція поведінки, підготовка собак-компаньйонів."
        keywords="дресирування собак, німецька вівчарка, Варшава, Краків, ОКД, корекція поведінки"
      />
      <div className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Професійне дресирування німецьких вівчарок у Варшаві та Кракові</h1>
          <p>
            Допомагаємо власникам відкривати потенціал своїх собак: від перших базових команд
            до складних робочих навичок. Будуємо взаємну довіру та слухняність без стресу.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.primaryButton}>
              Зв&apos;язатися
            </Link>
            <Link to="/posluhy" className={styles.secondaryButton}>
              Дізнатися більше
            </Link>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://images.unsplash.com/photo-1600585154340-0ef3c08cf0c7?auto=format&fit=crop&w=1600&q=80"
            alt="Німецька вівчарка під час тренування з кінологом"
            loading="lazy"
          />
        </div>
      </div>

      <section className={styles.whyUs} aria-labelledby="why-us-title">
        <div className={styles.sectionHeader}>
          <h2 id="why-us-title">Чому ми?</h2>
          <p>
            Працюємо з характером і темпераментом німецьких вівчарок, зберігаючи контакт між собакою та родиною.
          </p>
        </div>
        <div className={styles.whyGrid}>
          <article>
            <h3>Досвід роботи з вівчарками</h3>
            <p>Понад десятирічна практика, виступи на польських та міжнародних іспитах з ОКД.</p>
          </article>
          <article>
            <h3>Індивідуальні програми</h3>
            <p>Плануємо тренування під ваш графік, спосіб життя та цілі: від спорту до міських прогулянок.</p>
          </article>
          <article>
            <h3>Робота з поведінкою</h3>
            <p>Вивчаємо причини занепокоєння, агресії чи гіперактивності, навчаємо стабільним реакціям.</p>
          </article>
          <article>
            <h3>Гуманний підхід</h3>
            <p>Поєднуємо сучасні методики зі здоровою дисципліною, зберігаючи мотивацію собаки.</p>
          </article>
        </div>
        <div className={styles.stats}>
          {statsData.map((stat, index) => (
            <div key={stat.label} className={styles.statCard}>
              <span className={styles.statNumber}>{animatedValues[index]}+</span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
        <div className={styles.testimonial} aria-live="polite">
          <blockquote>
            <p>“{testimonials[currentTestimonial].quote}”</p>
            <cite>— {testimonials[currentTestimonial].author}</cite>
          </blockquote>
          <div className={styles.testimonialControls}>
            <button
              type="button"
              onClick={() =>
                setCurrentTestimonial(
                  (currentTestimonial - 1 + testimonials.length) % testimonials.length
                )
              }
              aria-label="Попередній відгук"
            >
              ‹
            </button>
            <button
              type="button"
              onClick={() =>
                setCurrentTestimonial((currentTestimonial + 1) % testimonials.length)
              }
              aria-label="Наступний відгук"
            >
              ›
            </button>
          </div>
        </div>
      </section>

      <section className={styles.services} aria-labelledby="services-title">
        <div className={styles.sectionHeader}>
          <h2 id="services-title">Напрямки роботи</h2>
          <p>
            Виберіть фокус, який найкраще відповідає потребам вашої родини та собаки. Ми поєднуємо різні програми, щоб результат був стабільним.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          {servicesOverview.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">{service.icon}</span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/posluhy" className={styles.cardLink} aria-label={`Перейти до опису послуги ${service.title}`}>
                Деталі →
              </Link>
            </article>
          ))}
        </div>
        <div className={styles.sectionAction}>
          <Link to="/posluhy" className={styles.primaryButton}>
            Детальніше про послуги
          </Link>
        </div>
      </section>

      <section className={styles.locations} aria-labelledby="locations-title">
        <div className={styles.sectionHeader}>
          <h2 id="locations-title">Де ми працюємо?</h2>
          <p>
            Навчаємо в умовах, де собака живе щодня: домашні сесії, парки, спеціальні майданчики, промислові зони.
          </p>
        </div>
        <div className={styles.locationsGrid}>
          {locations.map((location) => (
            <article key={location.city} className={styles.locationCard}>
              <img src={location.image} alt={`Тренування у місті ${location.city}`} loading="lazy" />
              <div>
                <h3>{location.city}</h3>
                <p>{location.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.gallery} aria-labelledby="graduates-title">
        <div className={styles.sectionHeader}>
          <h2 id="graduates-title">Наші випускники</h2>
          <p>
            Кожна історія — це командна робота власника та собаки. Ми лише підказуємо послідовні кроки.
          </p>
        </div>
        <div className={styles.filters} role="tablist" aria-label="Фільтр міст">
          {['усі', 'Варшава', 'Краків'].map((filter) => (
            <button
              key={filter}
              type="button"
              role="tab"
              aria-selected={activeFilter === filter}
              className={`${styles.filterButton} ${activeFilter === filter ? styles.filterActive : ''}`}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>
        <div className={styles.galleryGrid}>
          {filteredGallery.map((item) => (
            <figure key={item.id} className={styles.galleryItem}>
              <img src={item.image} alt={`${item.title} — ${item.city}`} loading="lazy" />
              <figcaption>
                <strong>{item.title}</strong>
                <span>{item.description}</span>
                <span className={styles.galleryTag}>{item.city}</span>
              </figcaption>
            </figure>
          ))}
        </div>
        <div className={styles.sectionAction}>
          <Link to="/nashi-uspikhy" className={styles.secondaryButton}>
            Більше результатів
          </Link>
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-title">
        <div className={styles.sectionHeader}>
          <h2 id="process-title">Як почати?</h2>
          <p>
            Ми покроково ведемо вас від першої консультації до стабільного результату у реальному житті.
          </p>
        </div>
        <ol className={styles.steps}>
          <li>
            <span>1</span>
            <h3>Консультація</h3>
            <p>Обговорюємо цілі, розклад, заповнюємо коротку анкету про собаку та родину.</p>
          </li>
          <li>
            <span>2</span>
            <h3>Індивідуальний план</h3>
            <p>Узгоджуємо формат занять, систему мотивації, домашні завдання між сесіями.</p>
          </li>
          <li>
            <span>3</span>
            <h3>Тренування</h3>
            <p>Працюємо комплексно: дисципліна, стабільність, розрядка енергії, контроль у місті.</p>
          </li>
          <li>
            <span>4</span>
            <h3>Результат</h3>
            <p>Документуємо прогрес, коригуємо програму, даємо план підтримки навичок.</p>
          </li>
        </ol>
        <div className={styles.blogPreview}>
          <h3>Корисні матеріали від тренерів</h3>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title}>
                <h4>{post.title}</h4>
                <p>{post.excerpt}</p>
                <Link to={post.link}>Читати →</Link>
              </article>
            ))}
          </div>
        </div>
        <div className={styles.ctaBox}>
          <div>
            <h3>Готові зробити перший крок?</h3>
            <p>Заплануйте зустріч з кінологом і отримайте індивідуальні рекомендації для вашої вівчарки.</p>
          </div>
          <Link to="/kontakty" className={styles.primaryButton}>
            Записатися на консультацію
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;