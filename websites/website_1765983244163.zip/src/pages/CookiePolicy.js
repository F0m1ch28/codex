import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Политика Cookie — Valentor Amicado</title>
        <meta
          name="description"
          content="Узнайте, как Valentor Amicado использует файлы cookie. Управляйте своими настройками конфиденциальности."
        />
      </Helmet>

      <section className={styles.wrapper}>
        <h1>Политика Cookie</h1>
        <p>Настоящая политика объясняет, какие файлы cookie мы используем, почему это делаем и как вы можете управлять своими настройками.</p>

        <h2>1. Что такое cookie</h2>
        <p>Cookie — это небольшие текстовые файлы, которые сохраняются на вашем устройстве при посещении сайта. Они помогают запоминать ваши настройки и улучшать качество сервиса.</p>

        <h2>2. Какие cookie мы используем</h2>
        <ul className={styles.list}>
          <li><strong>Функциональные:</strong> обеспечивают корректную работу сайта и сохранение выбранных вами настроек.</li>
          <li><strong>Аналитические:</strong> позволяют понимать, как пользователи взаимодействуют с сайтом (используем агрегированные данные).</li>
        </ul>

        <h2>3. Управление cookie</h2>
        <p>Вы можете изменить своё решение о согласии на использование cookie в настройках браузера или написав нам на info@valentoramicado.site.</p>

        <h2>4. Контакты</h2>
        <p>По всем вопросам, связанным с использованием cookie, обращайтесь по адресу info@valentoramicado.site.</p>
      </section>
    </>
  );
};

export default CookiePolicy;