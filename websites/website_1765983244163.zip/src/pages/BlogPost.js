import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './BlogPost.module.css';
import { blogPosts } from '../data/blogPosts';

const BlogPost = () => {
  const { slug } = useParams();
  const post = blogPosts.find((item) => item.slug === slug);

  if (!post) {
    return (
      <section className={styles.wrapper}>
        <h1>Материал не найден</h1>
        <p>Похоже, статья была перемещена или удалена. Попробуйте вернуться в <Link to="/blog">раздел блога</Link>.</p>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} — Valentor Amicado</title>
        <meta name="description" content={post.excerpt} />
      </Helmet>

      <article className={styles.wrapper}>
        <header className={styles.hero}>
          <p className={styles.meta}>{post.date} · {post.readTime}</p>
          <h1>{post.title}</h1>
        </header>
        <div className={styles.cover}>
          <img src={post.cover} alt={post.title} />
        </div>
        <div className={styles.content}>
          {post.content.map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
          {post.highlights && post.highlights.length > 0 && (
            <div className={styles.highlightBox}>
              <h2>Ключевые идеи</h2>
              <ul>
                {post.highlights.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          )}
          <Link to="/blog" className={styles.backLink}>
            ← Вернуться в блог
          </Link>
        </div>
      </article>
    </>
  );
};

export default BlogPost;