import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialState = { name: '', email: '', message: '' };

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, укажите имя.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Пожалуйста, укажите email.';
    } else {
      const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email);
      if (!emailValid) {
        newErrors.email = 'Введите корректный email.';
      }
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Расскажите о своей задаче.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData(initialState);
      setErrors({});
    } else {
      setErrors(validationErrors);
      setSubmitted(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Контакты — Valentor Amicado</title>
        <meta
          name="description"
          content="Связаться с Valentor Amicado: адрес в Москве, телефон, электронная почта. Оставьте сообщение и получите персональную консультацию."
        />
      </Helmet>

      <section className={styles.wrapper}>
        <div className={styles.intro}>
          <h1>Свяжитесь с Valentor Amicado</h1>
          <p>
            Расскажите о своём запросе — подготовим предложение и обсудим первые шаги.
            Работаем в Москве и онлайн по всему миру.
          </p>
        </div>

        <div className={styles.content}>
          <div className={styles.info}>
            <h2>Контактные данные</h2>
            <ul>
              <li>
                <span>Адрес:</span>
                Москва, ул. Тверская, д. 10, офис 45
              </li>
              <li>
                <span>Телефон:</span>
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </li>
              <li>
                <span>Email:</span>
                <a href="mailto:info@valentoramicado.site">info@valentoramicado.site</a>
              </li>
            </ul>
            <div className={styles.note}>
              <p>Обычно отвечаем в течение рабочего дня. Если запрос срочный — позвоните по номеру телефона.</p>
            </div>
          </div>

          <div className={styles.formWrapper}>
            <h2>Напишите нам</h2>
            <form onSubmit={handleSubmit} noValidate>
              <label htmlFor="name">Имя</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                aria-describedby={errors.name ? 'name-error' : undefined}
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && (
                <span id="name-error" className={styles.error}>
                  {errors.name}
                </span>
              )}

              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                aria-describedby={errors.email ? 'email-error' : undefined}
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && (
                <span id="email-error" className={styles.error}>
                  {errors.email}
                </span>
              )}

              <label htmlFor="message">Сообщение</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                aria-describedby={errors.message ? 'message-error' : undefined}
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && (
                <span id="message-error" className={styles.error}>
                  {errors.message}
                </span>
              )}

              <button type="submit" className={styles.submit}>
                Отправить сообщение
              </button>
              {submitted && (
                <p className={styles.success} role="status">
                  Спасибо! Мы получили ваше сообщение и свяжемся с вами в ближайшее время.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;