import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './Blog.module.css';
import { blogPosts } from '../data/blogPosts';

const Blog = () => {
  return (
    <>
      <Helmet>
        <title>Блог — Valentor Amicado</title>
        <meta
          name="description"
          content="Блог Valentor Amicado: статьи о стратегии, лидерстве и трансформациях. Практические рекомендации и аналитика."
        />
      </Helmet>

      <section className={styles.wrapper}>
        <div className={styles.intro}>
          <h1>Блог Valentor Amicado</h1>
          <p>Здесь мы делимся практиками, историями клиентов и инструментами, которые помогают управлять изменениями осознанно.</p>
        </div>
        <div className={styles.grid}>
          {blogPosts.map((post) => (
            <article className={styles.card} key={post.slug}>
              <Link to={`/blog/${post.slug}`}>
                <div className={styles.imageWrapper}>
                  <img src={post.cover} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.cardContent}>
                  <p className={styles.meta}>{post.date} · {post.readTime}</p>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <span className={styles.readMore}>Читать далее →</span>
                </div>
              </Link>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Blog;