import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';
import { blogPosts } from '../data/blogPosts';

const services = [
  {
    title: 'Стратегический консалтинг',
    description: 'Помогаем сформулировать чёткую стратегию роста и подготовить команду к её реализации.',
    icon: '🧭'
  },
  {
    title: 'Персональное сопровождение',
    description: 'Индивидуальный коучинг для руководителей, помощь в принятии сложных решений и управлении изменениями.',
    icon: '🤝'
  },
  {
    title: 'Экспертная оценка',
    description: 'Аудит бизнес-процессов, диагностика команд и оценка потенциала проектов.',
    icon: '📊'
  },
  {
    title: 'Культурная трансформация',
    description: 'Работа с корпоративной культурой, вовлечённостью сотрудников и удержанием талантов.',
    icon: '🌱'
  }
];

const values = [
  {
    title: 'Конфиденциальность',
    description: 'Работаем по принципу закрытого партнерства: каждая консультация и каждый документ защищены.'
  },
  {
    title: 'Глубокий анализ',
    description: 'Перед рекомендациями проводим исследование контекста, данных и ожиданий ключевых стейкхолдеров.'
  },
  {
    title: 'Долгосрочные решения',
    description: 'Фокус на устойчивом росте и системных изменениях, а не на разовых «быстрых победах».'
  },
  {
    title: 'Клиентоориентированность',
    description: 'Гибко подстраиваем формат взаимодействия под ритм команды и уровень вовлечения руководителя.'
  }
];

const testimonials = [
  {
    name: 'Алексей Морозов',
    role: 'Генеральный директор «ТехИнновация»',
    quote: 'Работать с Valentor Amicado — значит получать анализ на глубине, о которой редко думаешь сам. Мы внедрили стратегию и за полгода выросли в новых сегментах.',
    avatar: 'https://i.pravatar.cc/150?img=15'
  },
  {
    name: 'Екатерина Лебедева',
    role: 'HRD «Новая Орбита»',
    quote: 'Удивительное сочетание гибкости и структурности. Команда стала увереннее, а ключевые процессы — прозрачнее.',
    avatar: 'https://i.pravatar.cc/150?img=32'
  },
  {
    name: 'Дмитрий Фадеев',
    role: 'Основатель стартапа «InsightFlow»',
    quote: 'Подход Valentor Amicado помог нам определить фокус и построить модель, которая масштабируется без потери качества сервиса.',
    avatar: 'https://i.pravatar.cc/150?img=49'
  }
];

const Home = () => {
  return (
    <>
      <Helmet>
        <title>Valentor Amicado — Стратегический консалтинг и персональное сопровождение</title>
        <meta
          name="description"
          content="Консультации Valentor Amicado: стратегический консалтинг, индивидуальное сопровождение руководителей и экспертная оценка бизнес-процессов."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroInner}>
          <p className={styles.heroEyebrow}>Стратегическое мышление · Эмоциональный интеллект · Результат</p>
          <h1>Valentor Amicado</h1>
          <p className={styles.heroSubtitle}>
            Помогаем лидерам и командам принимать уверенные решения, выстраивать устойчивые стратегии
            и превращать вызовы в новые возможности.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.primaryButton}>
              Записаться на консультацию
            </Link>
            <Link to="/uslugi" className={styles.secondaryButton}>
              Все услуги
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.intro} id="intro">
        <div className={styles.sectionHeader}>
          <h2>Синтез опыта и индивидуального подхода</h2>
          <p>
            Valentor Amicado — это пространство доверительного диалога для руководителей и команд, которые стремятся к осмысленным изменениям.
            Мы соединяем аналитический взгляд, лидерскую практику и человеческую эмпатию.
          </p>
        </div>
        <div className={styles.introGrid}>
          <div className={styles.introCard}>
            <h3>30+ проектов ежегодно</h3>
            <p>От технологических стартапов до зрелых компаний со штатом более 500 сотрудников.</p>
          </div>
          <div className={styles.introCard}>
            <h3>Авторские методики</h3>
            <p>Используем проверенные инструменты, адаптируем их под вашу индустрию и культуру.</p>
          </div>
          <div className={styles.introCard}>
            <h3>Прозрачная коммуникация</h3>
            <p>Каждый шаг согласовывается с вами, у команды всегда есть доступ к прогрессу и данным.</p>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className={styles.sectionHeader}>
          <h2>Ключевые направления</h2>
          <p>Выстраиваем партнерство и включаемся в ваши задачи с первого дня.</p>
        </div>
        <div className={styles.serviceGrid}>
          {services.map((service) => (
            <Link to="/uslugi" className={styles.serviceCard} key={service.title} aria-label={`Подробнее об услуге ${service.title}`}>
              <span className={styles.serviceIcon} aria-hidden="true">{service.icon}</span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <span className={styles.cardLink}>Узнать больше →</span>
            </Link>
          ))}
        </div>
      </section>

      <section className={styles.values}>
        <div className={styles.sectionHeader}>
          <h2>Почему выбирают Valentor Amicado</h2>
          <p>Мы создаём условия, в которых команда уверенно движется к результатам.</p>
        </div>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <div className={styles.valueCard} key={value.title}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.aboutHighlight}>
        <div className={styles.aboutGrid}>
          <div className={styles.aboutImageContainer}>
            <img
              src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80"
              alt="Команда консультантов Valentor Amicado за обсуждением стратегии"
            />
          </div>
          <div>
            <p className={styles.sectionLabel}>О команде</p>
            <h2>Доверие, основанное на прозрачности и экспертизе</h2>
            <p>
              Мы создаём атмосферу, в которой руководители могут говорить о сложном открыто.
              Наши консультации сочетают строгий подход к аналитике и заботу о человеческом факторе.
            </p>
            <ul className={styles.aboutList}>
              <li>Диагностика и настройка процессов всего за 3-4 недели.</li>
              <li>Подготовка команды к изменениям и сопровождение внедрения решений.</li>
              <li>Постоянная обратная связь и обучение на каждом этапе.</li>
            </ul>
            <Link to="/obo-mne" className={styles.secondaryButton}>
              Узнать больше о подходе
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <h2>Отзывы клиентов</h2>
          <p>Лидеры компаний рассказывают, как наша работа помогает им и их командам.</p>
        </div>
        <div className={styles.testimonialGrid}>
          {testimonials.map((testimonial) => (
            <article className={styles.testimonialCard} key={testimonial.name}>
              <img src={testimonial.avatar} alt={`Фото клиента ${testimonial.name}`} />
              <blockquote>
                <p>“{testimonial.quote}”</p>
              </blockquote>
              <div>
                <p className={styles.testimonialName}>{testimonial.name}</p>
                <p className={styles.testimonialRole}>{testimonial.role}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className={styles.sectionHeader}>
          <h2>Свежие материалы</h2>
          <p>Практики, истории и схемы, которыми мы делимся в блоге Valentor Amicado.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.slice(0, 3).map((post) => (
            <Link to={`/blog/${post.slug}`} className={styles.blogCard} key={post.slug}>
              <div className={styles.blogImageWrapper}>
                <img src={post.cover} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.blogContent}>
                <p className={styles.blogMeta}>{post.date} · {post.readTime}</p>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <span className={styles.cardLink}>Читать статью →</span>
              </div>
            </Link>
          ))}
        </div>
        <div className={styles.blogCta}>
          <Link to="/blog" className={styles.secondaryButton}>
            Перейти в блог
          </Link>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaBox}>
          <h2>Готовы обсудить ваш проект?</h2>
          <p>Расскажите о текущих вызовах — мы предложим формат, который поможет команде двигаться вперёд увереннее.</p>
          <Link to="/kontakty" className={styles.primaryButton}>
            Обсудить задачу
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;