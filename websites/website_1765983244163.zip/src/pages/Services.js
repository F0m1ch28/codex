import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

const serviceBlocks = [
  {
    title: 'Стратегический консалтинг',
    description:
      'Исследуем ваши данные, формулируем гипотезы развития и строим карту действий. Помогаем увидеть узкие места и выработать сценарии, которые выдерживают проверку кризисами.',
    points: [
      'Анализ рынка, конкурентов и позиционирования',
      'Формирование стратегической модели и целей',
      'Разработка дорожной карты и ключевых метрик'
    ],
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Персональное сопровождение руководителей',
    description:
      'Работаем один на один с лидером компании. Выстраиваем ясную систему приоритетов, развиваем управленческие навыки и поддерживаем во время изменений.',
    points: [
      'Executive coaching и планирование развития',
      'Подготовка к переговорам и публичным выступлениям',
      'Подсветка слепых зон и поддержка в принятии решений'
    ],
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Экспертная оценка и аудит процессов',
    description:
      'Проводим диагностику команды и ключевых процессов, выявляем риски и зоны роста. Результат — понятная карта улучшений и рекомендации к внедрению.',
    points: [
      'Интервью и анкетирование сотрудников',
      'Камеральный анализ документов и регламентов',
      'Разработка рекомендаций и сопровождение изменений'
    ],
    image: 'https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=1200&q=80'
  }
];

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Услуги — Valentor Amicado</title>
        <meta
          name="description"
          content="Стратегический консалтинг, персональное сопровождение и экспертная оценка от Valentor Amicado. Индивидуальные решения для вашего бизнеса."
        />
      </Helmet>

      <section className={styles.wrapper}>
        <div className={styles.intro}>
          <h1>Решения, которые поддерживают устойчивый рост</h1>
          <p>
            Мы соединяем стратегическое мышление, чёткую методологию и человеческий подход.
            Каждый проект стартует с исследования контекста, а затем выстраивается в партнёрстве с вами.
          </p>
        </div>

        <div className={styles.serviceGrid}>
          {serviceBlocks.map((service) => (
            <article className={styles.serviceCard} key={service.title}>
              <div className={styles.imageWrapper}>
                <img src={service.image} alt={service.title} />
              </div>
              <div className={styles.serviceContent}>
                <h2>{service.title}</h2>
                <p>{service.description}</p>
                <ul>
                  {service.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>

        <div className={styles.process}>
          <h2>Как мы работаем</h2>
          <div className={styles.processGrid}>
            <div>
              <span>01</span>
              <h3>Диагностика</h3>
              <p>Выслушиваем запрос, изучаем исходные данные, проводим интервью и фиксируем контекст.</p>
            </div>
            <div>
              <span>02</span>
              <h3>Проектирование</h3>
              <p>Совместно формируем цели, определяем метрики успеха и подбираем инструменты.</p>
            </div>
            <div>
              <span>03</span>
              <h3>Внедрение</h3>
              <p>Сопровождаем команду в реализации, фиксируем промежуточные результаты, корректируем план.</p>
            </div>
            <div>
              <span>04</span>
              <h3>Закрепление</h3>
              <p>Настраиваем систему обратной связи, обучаем и передаём инструменты для самостоятельной работы.</p>
            </div>
          </div>
        </div>

        <div className={styles.faq}>
          <h2>Частые вопросы</h2>
          <div className={styles.faqList}>
            <details>
              <summary>Сколько длится проект?</summary>
              <p>Средняя продолжительность — от 6 до 12 недель. Точная длительность зависит от сложности задач и вовлечённости команды.</p>
            </details>
            <details>
              <summary>Можно ли начать с короткой диагностики?</summary>
              <p>Да, мы предлагаем экспресс-диагностику, по результатам которой вы получаете карту приоритетов и решение о дальнейшем формате.</p>
            </details>
            <details>
              <summary>Работаете ли вы с региональными командами?</summary>
              <p>Мы проводим встречи онлайн и офлайн, адаптируемся к часовым поясам и формируем смешанный формат при необходимости.</p>
            </details>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;