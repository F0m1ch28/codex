import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem('va_cookie_consent');
    if (!storedConsent) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem('va_cookie_consent', choice);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление об использовании файлов cookie">
      <p>
        Мы используем файлы cookie для повышения удобства работы с сайтом и персонализации контента. Вы можете изменить своё решение в любой момент в разделе «Политика Cookie».
      </p>
      <div className={styles.actions}>
        <button type="button" onClick={() => handleChoice('accepted')} className={styles.accept}>
          Принять
        </button>
        <button type="button" onClick={() => handleChoice('declined')} className={styles.decline}>
          Отклонить
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;