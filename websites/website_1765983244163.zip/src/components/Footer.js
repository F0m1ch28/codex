import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.brand}>
          <Link to="/" className={styles.logo}>
            Valentor <span>Amicado</span>
          </Link>
          <p className={styles.description}>
            Персональные консультации, стратегическое сопровождение и внедрение решений, которые помогают лидерам и командам расти устойчиво.
          </p>
        </div>
        <div className={styles.columns}>
          <div className={styles.column}>
            <h4>Навигация</h4>
            <ul>
              <li><Link to="/">Главная</Link></li>
              <li><Link to="/uslugi">Услуги</Link></li>
              <li><Link to="/obo-mne">Обо мне</Link></li>
              <li><Link to="/blog">Блог</Link></li>
              <li><Link to="/kontakty">Контакты</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4>Правовая информация</h4>
            <ul>
              <li><Link to="/usloviya-ispolzovaniya">Условия использования</Link></li>
              <li><Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link></li>
              <li><Link to="/politika-cookie">Политика Cookie</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4>Контакты</h4>
            <ul className={styles.contacts}>
              <li>Москва, ул. Тверская, д. 10, офис 45</li>
              <li><a href="tel:+74951234567">+7 (495) 123-45-67</a></li>
              <li><a href="mailto:info@valentoramicado.site">info@valentoramicado.site</a></li>
            </ul>
            <div className={styles.socials}>
              <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn Valentor Amicado">
                in
              </a>
              <a href="https://t.me" target="_blank" rel="noreferrer" aria-label="Telegram Valentor Amicado">
                TG
              </a>
              <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube Valentor Amicado">
                ▶
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Valentor Amicado. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;