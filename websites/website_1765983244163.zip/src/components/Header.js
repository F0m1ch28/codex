import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <Link to="/" className={styles.logo} aria-label="Перейти на главную страницу Valentor Amicado">
          Valentor <span className={styles.logoAccent}>Amicado</span>
        </Link>
        <nav
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Основная навигация"
        >
          <ul className={styles.navList}>
            <li>
              <NavLink
                to="/"
                className={({ isActive }) =>
                  isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                }
              >
                Главная
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/uslugi"
                className={({ isActive }) =>
                  isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                }
              >
                Услуги
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/obo-mne"
                className={({ isActive }) =>
                  isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                }
              >
                Обо мне
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/blog"
                className={({ isActive }) =>
                  isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                }
              >
                Блог
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/kontakty"
                className={({ isActive }) =>
                  isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                }
              >
                Контакты
              </NavLink>
            </li>
          </ul>
        </nav>
        <div className={styles.actions}>
          <Link to="/kontakty" className={styles.cta}>
            Связаться
          </Link>
          <button
            type="button"
            className={styles.menuButton}
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-label={menuOpen ? 'Закрыть меню' : 'Открыть меню'}
            aria-expanded={menuOpen}
            aria-controls="main-navigation"
          >
            <span className={styles.burger} />
            <span className="visually-hidden">Меню</span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;