import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'hrAdvertiseCookiesAccepted';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      const accepted = localStorage.getItem(STORAGE_KEY);
      if (!accepted) {
        setVisible(true);
      }
    } catch (error) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    try {
      localStorage.setItem(STORAGE_KEY, 'true');
    } catch (error) {
      // ignore
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <aside className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.message}>
        <p>
          We use cookies to enhance your experience. By continuing to visit this site you agree to our use of cookies.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className="ctaButton" onClick={handleAccept}>
          Accept
        </button>
        <Link to="/cookie-policy" className={`${styles.learnMore} secondaryButton`}>
          Learn More
        </Link>
      </div>
    </aside>
  );
};

export default CookieBanner;