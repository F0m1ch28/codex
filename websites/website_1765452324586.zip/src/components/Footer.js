import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const serviceLinks = [
  { to: '/services', label: 'Services' },
  { to: '/case-studies', label: 'Case Studies' },
  { to: '/about-us', label: 'About Us' },
  { to: '/contact', label: 'Contact' }
];

const legalLinks = [
  { to: '/terms', label: 'Terms of Service' },
  { to: '/privacy', label: 'Privacy Policy' },
  { to: '/cookie-policy', label: 'Cookie Policy' }
];

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.footerInner}`}>
      <div className={styles.brandColumn}>
        <Link to="/" className={styles.brand}>
          HR <span>Advertise</span>
        </Link>
        <p className={styles.tagline}>
          Strategic advertising and communications tailored to the global HR landscape.
        </p>
        <div className={styles.socials} aria-label="Social media">
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
            <span className={styles.socialIcon}>in</span>
          </a>
          <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
            <span className={styles.socialIcon}>X</span>
          </a>
        </div>
      </div>

      <div className={styles.linkColumn}>
        <h4>Explore</h4>
        <ul>
          {serviceLinks.map((link) => (
            <li key={link.to}>
              <Link to={link.to}>{link.label}</Link>
            </li>
          ))}
        </ul>
      </div>

      <div className={styles.linkColumn}>
        <h4>Legal</h4>
        <ul>
          {legalLinks.map((link) => (
            <li key={link.to}>
              <Link to={link.to}>{link.label}</Link>
            </li>
          ))}
        </ul>
      </div>

      <div className={styles.contactColumn}>
        <h4>Contact</h4>
        <p>123 Marketing Avenue, Suite 500<br />San Francisco, CA 94107, USA</p>
        <p>
          <a href="tel:+15551234567">+1 (555) 123-4567</a><br />
          <a href="mailto:info@hradvertise.com">info@hradvertise.com</a>
        </p>
      </div>
    </div>

    <div className={styles.bottomBar}>
      <p>© {new Date().getFullYear()} HR Advertise. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;