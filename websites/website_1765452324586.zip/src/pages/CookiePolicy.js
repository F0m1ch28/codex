import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './LegalPage.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | HR Advertise</title>
      <meta
        name="description"
        content="Understand how HR Advertise uses cookies and similar technologies on this website."
      />
    </Helmet>

    <section className={styles.legalSection}>
      <div className="container">
        <div className={styles.legalCard}>
          <h1>Cookie Policy</h1>
          <p>Updated: July 2024</p>

          <h2>What are cookies?</h2>
          <p>
            Cookies are small text files that websites store on your device to remember preferences, enhance performance, and gather analytics. HR Advertise uses cookies to optimise user experience and understand how our site is used.
          </p>

          <h2>Types of cookies we use</h2>
          <ul>
            <li><strong>Essential cookies:</strong> Required for basic site functionality such as navigation.</li>
            <li><strong>Analytics cookies:</strong> Help us analyse site traffic, engagement, and content performance.</li>
            <li><strong>Preference cookies:</strong> Remember your settings and choices for improved usability.</li>
          </ul>

          <h2>Managing cookies</h2>
          <p>
            You can control or disable cookies through your browser settings. Blocking certain cookies may impact site functionality.
          </p>

          <h2>Third-party cookies</h2>
          <p>
            Trusted third parties may place cookies on our site to provide analytics or embedded content. These parties are responsible for their own policies and practices.
          </p>

          <h2>Updates</h2>
          <p>
            We may update this policy to reflect changes in technology or regulations. Updates will be posted on this page with a revised date.
          </p>

          <h2>Contact</h2>
          <p>
            For questions about our Cookie Policy, contact <a href="mailto:privacy@hradvertise.com">privacy@hradvertise.com</a>.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default CookiePolicy;