import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

const serviceCategories = [
  {
    id: 'employer-branding',
    name: 'Employer Branding',
    description:
      'Refresh your EVP, articulate culture, and empower ambassadors to attract candidates who thrive in your organisation.',
    outcomes: [
      'EVP research and persona development',
      'Visual identity and narrative system for talent audiences',
      'Employee advocacy programs and toolkits'
    ],
    image:
      'https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'recruitment-marketing',
    name: 'Recruitment Marketing',
    description:
      'Drive qualified applicants across hard-to-fill roles with media, creative, and automation tuned to talent signals.',
    outcomes: [
      'Programmatic job distribution & paid social',
      'ABM for senior and niche talent segments',
      'Always-on optimisation with conversion dashboards'
    ],
    image:
      'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'hr-tech-growth',
    name: 'HR Tech Go-To-Market',
    description:
      'Launch and scale HR technology products with positioning that speaks directly to HR decision-makers.',
    outcomes: [
      'Product messaging workshops and battlecards',
      'Demand generation, webinar and event strategy',
      'Lifecycle nurture flows and sales enablement'
    ],
    image:
      'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=1200&q=80'
  }
];

const serviceHighlights = [
  {
    title: 'Persona research',
    text: 'We interview candidates, hiring managers, and HR leaders to uncover motivations that inform creative briefs.'
  },
  {
    title: 'Creative production',
    text: 'In-house design, copywriting, and motion teams craft multi-channel assets optimised for HR environments.'
  },
  {
    title: 'Media strategy',
    text: 'We orchestrate media plans across job boards, social, programmatic, and talent communities to maximise resonance.'
  },
  {
    title: 'Analytics & optimisation',
    text: 'Unified reporting connects investment to HR KPIs, enabling agile optimisation and confident leadership updates.'
  }
];

const processItems = [
  {
    phase: 'Discover',
    detail: 'Stakeholder workshops, talent analytics, and EVP mapping to align objectives and success metrics.'
  },
  {
    phase: 'Design',
    detail: 'Translate insights into creative concepts, channel mix, and experience blueprints with rapid prototyping.'
  },
  {
    phase: 'Deploy',
    detail: 'Launch full-funnel campaigns with rigorous QA and agile adjustments driven by performance data.'
  },
  {
    phase: 'Deepen',
    detail: 'Iterate with continuous testing, feedback loops, and scaled enablement across HR and marketing teams.'
  }
];

const faqs = [
  {
    question: 'How do you tailor campaigns for different talent segments?',
    answer:
      'Every campaign begins with audience segmentation, journey mapping, and message testing. We differentiate creative for early-career, experienced, leadership, and specialist talent, layering in cultural nuances for global rollouts.'
  },
  {
    question: 'Can you integrate with our applicant tracking system?',
    answer:
      'Yes. We routinely integrate with ATS and HRIS platforms to ensure accurate attribution, candidate nurture, and feedback loops that inform campaign optimisation.'
  },
  {
    question: 'What does onboarding look like?',
    answer:
      'You will be onboarded through a structured 30-day roadmap covering discovery, data access, workshop sessions, and co-creation of campaign objectives. By day 30, we deliver a ready-to-launch blueprint with milestones.'
  }
];

const Services = () => {
  const [activeCategory, setActiveCategory] = useState(serviceCategories[0].id);

  const activeService = useMemo(
    () => serviceCategories.find((category) => category.id === activeCategory),
    [activeCategory]
  );

  return (
    <>
      <Helmet>
        <title>HR Advertise Services | Employer Branding & Recruitment Marketing</title>
        <meta
          name="description"
          content="Discover HR Advertise services including employer branding, recruitment marketing, and HR tech go-to-market campaigns tailored to global HR organisations."
        />
      </Helmet>

      <header className={styles.pageHero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Services</span>
            <h1>Integrated services for the modern HR organisation</h1>
            <p>
              We combine talent intelligence, creative, and media to solve the pressing challenges of HR teams. Each engagement is built around measurable impact, stakeholder alignment, and a deep respect for the employee experience.
            </p>
            <Link to="/contact" className="ctaButton">
              Book a consultation
            </Link>
          </div>
        </div>
      </header>

      <section className={styles.categoriesSection}>
        <div className="container">
          <div className={styles.categoriesNav} role="tablist" aria-label="Service categories">
            {serviceCategories.map((category) => (
              <button
                key={category.id}
                className={`${styles.categoryButton} ${category.id === activeCategory ? styles.categoryActive : ''}`}
                role="tab"
                aria-selected={category.id === activeCategory}
                onClick={() => setActiveCategory(category.id)}
              >
                {category.name}
              </button>
            ))}
          </div>

          {activeService && (
            <article className={styles.categoryPanel} role="tabpanel">
              <div className={styles.categoryText}>
                <h2>{activeService.name}</h2>
                <p>{activeService.description}</p>
                <ul>
                  {activeService.outcomes.map((outcome) => (
                    <li key={outcome}>{outcome}</li>
                  ))}
                </ul>
                <Link to="/case-studies" className="secondaryButton">
                  See related case studies
                </Link>
              </div>
              <div className={styles.categoryMedia}>
                <img src={activeService.image} alt={`${activeService.name} strategy session`} />
              </div>
            </article>
          )}
        </div>
      </section>

      <section className={styles.highlightsSection}>
        <div className="container">
          <div className="sectionHeader">
            <h2 className="sectionTitle">What sets our HR campaigns apart</h2>
            <p className="sectionSubtitle">
              Our multidisciplinary team spans employer branding strategists, recruitment marketers, HR tech specialists, and data scientists.
            </p>
          </div>
          <div className={styles.highlightGrid}>
            {serviceHighlights.map((item) => (
              <div key={item.title} className={styles.highlightCard}>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.processHeader}>
            <h2 className="sectionTitle">Our partnership process</h2>
            <p className="sectionSubtitle">
              A structured yet flexible methodology keeps your stakeholders aligned and your talent goals in focus.
            </p>
          </div>
          <div className={styles.processTimeline}>
            {processItems.map((item) => (
              <div key={item.phase} className={styles.processItem}>
                <div className={styles.processBadge}>{item.phase}</div>
                <p>{item.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.faqHeader}>
            <h2 className="sectionTitle">Frequently asked questions</h2>
            <p className="sectionSubtitle">
              Answers to the questions HR leaders and talent marketers ask before partnering with HR Advertise.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqs.map((faq) => (
              <details key={faq.question} className={styles.faqItem}>
                <summary>{faq.question}</summary>
                <p>{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.finalCta}>
        <div className="container">
          <div className={styles.finalCard}>
            <div>
              <h2>Align your HR marketing with business growth</h2>
              <p>
                Share your current talent goals and challenges. We&apos;ll come prepared with relevant benchmarks, creative recommendations, and a roadmap for the first 90 days.
              </p>
            </div>
            <Link to="/contact" className="ctaButton">
              Start the conversation
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;