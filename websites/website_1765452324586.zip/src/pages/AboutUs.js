import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './AboutUs.module.css';

const leadershipTeam = [
  {
    name: 'Maya Chen',
    role: 'Founder & Chief Strategist',
    bio: 'Former CHRO and global employer brand lead. Maya guides strategy and ensures every campaign aligns with HR priorities.',
    image:
      'https://images.unsplash.com/photo-1544723795-43253758b4ef?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'James Osei',
    role: 'Director of Recruitment Media',
    bio: 'Specialist in talent media buying and analytics with 12 years of experience scaling recruitment campaigns in tech and healthcare.',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Elena García',
    role: 'Head of Employer Branding',
    bio: 'Creative leader focused on EVP, storytelling, and culture design. Previously led employer brand for a Fortune 200 company.',
    image:
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Marcus Howard',
    role: 'VP, HR Tech Growth',
    bio: 'Marketing technologist who builds go-to-market engines for HR SaaS products, supporting product marketing and sales enablement.',
    image:
      'https://images.unsplash.com/photo-1552374196-c4e7ffc6e126?auto=format&fit=crop&w=400&q=80'
  }
];

const milestones = [
  {
    year: '2016',
    title: 'Agency founded',
    description: 'Built to serve HR teams navigating digital transformation and changing talent expectations.'
  },
  {
    year: '2018',
    title: 'Global firsts',
    description: 'Launched multi-market EVP campaigns across North America, Europe, and APAC for HR tech scaleups.'
  },
  {
    year: '2020',
    title: 'Remote-first evolution',
    description: 'Expanded virtual collaboration models and developed frameworks for distributed employee experiences.'
  },
  {
    year: '2023',
    title: 'Insights lab',
    description: 'Introduced our HR insights lab, enabling real-time benchmarking, sentiment analysis, and predictive reporting.'
  }
];

const AboutUs = () => (
  <>
    <Helmet>
      <title>About HR Advertise | HR Industry Marketing Specialists</title>
      <meta
        name="description"
        content="Learn about HR Advertise, the advertising agency dedicated to HR marketing, employer branding, and recruitment campaigns for global talent teams."
      />
    </Helmet>

    <header className={styles.pageHero}>
      <div className="container">
        <div className={styles.heroContent}>
          <span className="tag">About HR Advertise</span>
          <h1>We believe HR deserves marketing built for people</h1>
          <p>
            HR Advertise was founded by former HR leaders, creatives, and analysts who saw a gap between traditional marketing agencies and the nuanced needs of HR teams. Today, we operate as a strategic partner to HR innovators worldwide.
          </p>
        </div>
      </div>
    </header>

    <section className={styles.valuesSection}>
      <div className="container">
        <div className={styles.valuesGrid}>
          <article className={styles.valueCard}>
            <h2>Human-first strategy</h2>
            <p>
              People are the heart of every campaign we build. We prioritize empathy, inclusion, and clarity to honor the stories of employees, candidates, and HR practitioners.
            </p>
          </article>
          <article className={styles.valueCard}>
            <h2>Evidence-led creativity</h2>
            <p>
              Our creative teams partner closely with data analysts to ensure every idea is backed by insights, validated by testing, and optimised for performance.
            </p>
          </article>
          <article className={styles.valueCard}>
            <h2>Collaborative partnership</h2>
            <p>
              We embed with your HR, talent, and marketing teams, working transparently to co-create strategies and build internal capability.
            </p>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.teamSection}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Leadership Team</h2>
          <p className="sectionSubtitle">
            Our leadership brings together HR, marketing, and analytics expertise to guide every engagement.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {leadershipTeam.map((leader) => (
            <article key={leader.name} className={styles.teamCard}>
              <div className={styles.teamMedia}>
                <img src={leader.image} alt={`${leader.name}, ${leader.role}`} />
              </div>
              <div className={styles.teamContent}>
                <h3>{leader.name}</h3>
                <p className={styles.teamRole}>{leader.role}</p>
                <p>{leader.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.timelineSection}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Our journey</h2>
          <p className="sectionSubtitle">
            From day one, we have been committed to advancing HR through strategic communications and creative storytelling.
          </p>
        </div>
        <div className={styles.timeline}>
          {milestones.map((milestone) => (
            <div key={milestone.year} className={styles.timelineItem}>
              <div className={styles.timelineYear}>{milestone.year}</div>
              <div className={styles.timelineBody}>
                <h3>{milestone.title}</h3>
                <p>{milestone.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.cultureSection}>
      <div className="container">
        <div className={styles.cultureCard}>
          <div>
            <h2 className="sectionTitle">Inside HR Advertise</h2>
            <p>
              We are a distributed team across North America, Europe, and APAC. Our culture champions curiosity, continuous learning, and shared success. Weekly knowledge circles, mentoring programmes, and insights labs keep us sharp on the evolving world of HR.
            </p>
          </div>
          <img
            src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80"
            alt="HR Advertise team collaborating virtually"
          />
        </div>
      </div>
    </section>
  </>
);

export default AboutUs;