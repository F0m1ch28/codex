import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  company: '',
  email: '',
  objective: '',
  message: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your full name.';
    if (!formData.company.trim()) newErrors.company = 'Please enter your company or organisation.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email address.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!formData.objective.trim()) newErrors.objective = 'Please select your primary objective.';
    if (!formData.message.trim()) newErrors.message = 'Please provide a brief overview of your project.';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      setSubmitted(false);
      return;
    }
    setErrors({});
    setSubmitted(true);
    setFormData(initialFormState);
  };

  return (
    <>
      <Helmet>
        <title>Contact HR Advertise | HR Marketing Consultation</title>
        <meta
          name="description"
          content="Connect with HR Advertise to discuss HR marketing, employer branding, and recruitment advertising strategies tailored to your organisation."
        />
      </Helmet>

      <header className={styles.pageHero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Contact</span>
            <h1>Let&apos;s build your next HR milestone</h1>
            <p>
              Share your goals and we&apos;ll assemble the right mix of strategists, creatives, and analysts to support you. We typically respond within one business day.
            </p>
          </div>
        </div>
      </header>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.contactGrid}>
            <div className={styles.formCard}>
              <h2>Tell us about your objectives</h2>
              <p>
                Complete the form and our team will reach out with next steps, availability, and an agenda for our first conversation.
              </p>

              <form onSubmit={handleSubmit} className={styles.form} noValidate>
                <label htmlFor="name">Full Name</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Jordan Smith"
                  aria-invalid={Boolean(errors.name)}
                />
                {errors.name && <div className="alertError" role="alert">{errors.name}</div>}

                <label htmlFor="company">Company / Organisation</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="PeopleFirst HR"
                  aria-invalid={Boolean(errors.company)}
                />
                {errors.company && <div className="alertError" role="alert">{errors.company}</div>}

                <label htmlFor="email">Work Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="you@company.com"
                  aria-invalid={Boolean(errors.email)}
                />
                {errors.email && <div className="alertError" role="alert">{errors.email}</div> }

                <label htmlFor="objective">Primary Objective</label>
                <select
                  id="objective"
                  name="objective"
                  value={formData.objective}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.objective)}
                >
                  <option value="">Select an objective</option>
                  <option value="employer-branding">Refresh employer brand / EVP</option>
                  <option value="recruitment-marketing">Boost recruitment marketing performance</option>
                  <option value="hr-tech-launch">Launch or scale an HR tech product</option>
                  <option value="internal-comms">Strengthen internal HR communications</option>
                  <option value="other">Other HR marketing initiative</option>
                </select>
                {errors.objective && <div className="alertError" role="alert">{errors.objective}</div> }

                <label htmlFor="message">How can we help?</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Share context, timelines, and what success looks like."
                  aria-invalid={Boolean(errors.message)}
                />
                {errors.message && <div className="alertError" role="alert">{errors.message}</div> }

                <button type="submit" className="ctaButton">Submit inquiry</button>
                {submitted && (
                  <div className="alertSuccess" role="status">
                    Thank you for reaching out. Our team will contact you shortly.
                  </div>
                )}
              </form>
            </div>

            <aside className={styles.contactInfo}>
              <div className={styles.infoCard}>
                <h3>Direct contact</h3>
                <p>
                  <strong>Address:</strong><br />
                  123 Marketing Avenue, Suite 500<br />
                  San Francisco, CA 94107, USA
                </p>
                <p>
                  <strong>Phone:</strong><br />
                  <a href="tel:+15551234567">+1 (555) 123-4567</a>
                </p>
                <p>
                  <strong>Email:</strong><br />
                  <a href="mailto:info@hradvertise.com">info@hradvertise.com</a>
                </p>
              </div>

              <div className={styles.infoCard}>
                <h3>Engagement snapshots</h3>
                <ul>
                  <li>Discovery briefing & goal alignment</li>
                  <li>Insight workshops with HR stakeholders</li>
                  <li>Campaign blueprint presentation</li>
                  <li>Launch support & performance dashboards</li>
                </ul>
              </div>

              <div className={styles.mapCard}>
                <img
                  src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80"
                  alt="San Francisco skyline representing HR Advertise headquarters"
                />
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;