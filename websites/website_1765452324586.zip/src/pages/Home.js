import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const statsData = [
  { label: 'HR campaigns launched', value: 185 },
  { label: 'Growth in qualified candidates', value: 42, suffix: '%' },
  { label: 'Employer brand refreshes', value: 64 },
  { label: 'Countries activated', value: 27 }
];

const servicesPreview = [
  {
    title: 'Employer Branding Campaigns',
    description: 'Crafted narratives that resonate with talent communities and bring purpose to the forefront.',
    icon: '🎯'
  },
  {
    title: 'HR Tech Product Launches',
    description: 'Full-funnel go-to-market strategies that accelerate demos, trials, and platform adoption.',
    icon: '🚀'
  },
  {
    title: 'Recruitment Marketing',
    description: 'Precision targeting and creative built to attract high-caliber candidates where they search.',
    icon: '📣'
  },
  {
    title: 'HR Communications Strategy',
    description: 'Integrated communications plans to align talent, leadership, and culture at scale.',
    icon: '🧭'
  }
];

const processSteps = [
  {
    title: 'Diagnose the HR challenge',
    details: 'Deep-dive discovery sessions with talent, marketing, and operations stakeholders.'
  },
  {
    title: 'Design data-backed creative',
    details: 'Audience insights and message testing to build an evidence-based campaign blueprint.'
  },
  {
    title: 'Deploy across HR channels',
    details: 'Omnichannel activation across job boards, social, programmatic, and talent communities.'
  },
  {
    title: 'Deliver measurable growth',
    details: 'Transparent reporting tied to talent KPIs, recruitment velocity, and brand perception.'
  }
];

const featuredCaseStudy = {
  title: 'Scaling Talent Acquisition for a Global HR Tech Platform',
  description:
    'We rebuilt the employer value proposition and hyper-targeted HR personas across 12 countries, resulting in a 58% lift in qualified demo requests.',
  image:
    'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80',
  result: '58% increase in qualified leads • 38% faster hiring cycle',
  link: '/case-studies'
};

const testimonials = [
  {
    quote:
      'HR Advertise helped us reposition our talent brand globally. The candidate pipeline uplift and executive buy-in were immediate.',
    name: 'Evelyn Porter',
    role: 'VP Talent Acquisition, PeopleFirst',
    image:
      'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=300&q=80'
  },
  {
    quote:
      'Their team understands the nuance of HR messaging. The campaign generated more qualified applications in six weeks than the prior year.',
    name: 'Rahul Banerjee',
    role: 'Head of Recruitment Marketing, HireStream',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=300&q=80'
  },
  {
    quote:
      'From EVP workshops to analytics dashboards, HR Advertise delivered a consistent experience that elevated our global employer brand.',
    name: 'Lucia Gómez',
    role: 'Chief People Officer, TalentSync',
    image:
      'https://images.unsplash.com/photo-1544723795-43253758b4ef?auto=format&fit=crop&w=300&q=80'
  }
];

const clientLogos = ['PeopleFirst', 'TalentSync', 'HireStream', 'CultureWave', 'BrightHire'];

const blogPosts = [
  {
    title: 'Building Employer Brand Narratives That Win Trust',
    date: 'August 14, 2024',
    excerpt: 'Discover the storytelling framework we use to align HR, marketing, and leadership behind a single people promise.',
    link: '#'
  },
  {
    title: 'Five Data Signals Shaping Recruitment Advertising',
    date: 'July 30, 2024',
    excerpt: 'From programmatic bidding trends to candidate journey analytics, here are the metrics redefining talent funnels.',
    link: '#'
  },
  {
    title: 'How HR Tech Brands Can Humanize Product Launches',
    date: 'July 10, 2024',
    excerpt: 'Turn complex HR technology into meaningful employee outcomes with these positioning insights.',
    link: '#'
  }
];

const Home = () => {
  const [counterValues, setCounterValues] = useState(() =>
    statsData.map(() => 0)
  );
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  useEffect(() => {
    let animationFrame;
    const start = performance.now();
    const duration = 1400;

    const animate = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      setCounterValues(
        statsData.map((stat) =>
          Math.round(stat.value * progress)
        )
      );
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const activeTestimonial = useMemo(
    () => testimonials[testimonialIndex],
    [testimonialIndex]
  );

  return (
    <>
      <Helmet>
        <title>HR Advertise | Strategic Advertising for the HR Industry</title>
        <meta
          name="description"
          content="HR Advertise delivers recruitment advertising, employer branding, and HR tech marketing campaigns that accelerate talent acquisition worldwide."
        />
      </Helmet>

      <div className={styles.hero}>
        <div className={styles.heroOverlay} />
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroTag}>
            <span className="tag">Specialists in HR Marketing</span>
          </div>
          <h1 className={styles.heroTitle}>
            Strategic Advertising for the HR Industry
          </h1>
          <p className={styles.heroSubtitle}>
            Partner with the agency built for HR leaders, recruitment teams, and HR tech innovators. We design campaigns that connect with talent, elevate employer brands, and fuel growth across the global people ecosystem.
          </p>
          <div className={styles.heroActions}>
            <Link to="/services" className="ctaButton animatePulse">
              Explore Our Services
            </Link>
            <Link to="/contact" className="secondaryButton">
              Schedule a Strategy Call
            </Link>
          </div>
        </div>
      </div>

      <section className={styles.introSection}>
        <div className="container">
          <div className={styles.introContent}>
            <div>
              <h2 className="sectionTitle">HR marketing expertise you can feel</h2>
              <p className="sectionSubtitle">
                We translate complex people challenges into campaigns fueled by data, empathy, and creativity. Whether you are launching an HR technology solution or strengthening your employer brand, our specialists understand the language of talent.
              </p>
            </div>
            <div className={styles.statsGrid} role="list">
              {statsData.map((stat, index) => (
                <article key={stat.label} className={styles.statCard} role="listitem">
                  <span className={styles.statValue}>
                    {counterValues[index]}
                    {stat.suffix}
                  </span>
                  <span className={styles.statLabel}>{stat.label}</span>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Core services for HR innovators</h2>
            <p className="sectionSubtitle">
              From recruitment advertising to HR tech GTM, our integrated services help you engage the right people with the right message at the right moment.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesPreview.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className={styles.cardLink} aria-label={`Learn more about ${service.title}`}>
                  Discover more →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">A process built for talent transformation</h2>
            <p className="sectionSubtitle">
              Each engagement is guided by our four-step methodology, ensuring stakeholder alignment, creative clarity, and measurable outcomes.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processCard}>
                <div className={styles.processIndex}>
                  <span>{index + 1}</span>
                </div>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.details}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.caseStudySection}>
        <div className="container">
          <div className={styles.caseStudy}>
            <div className={styles.caseMedia}>
              <img src={featuredCaseStudy.image} alt="Global HR team collaborating on marketing strategy" />
            </div>
            <div className={styles.caseContent}>
              <h2 className="sectionTitle">{featuredCaseStudy.title}</h2>
              <p>{featuredCaseStudy.description}</p>
              <div className={styles.caseHighlight}>
                <span className="tag">Results</span>
                <p>{featuredCaseStudy.result}</p>
              </div>
              <Link to={featuredCaseStudy.link} className="ctaButton">
                View Case Study
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.whySection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Why HR leaders choose us</h2>
            <p className="sectionSubtitle">
              We combine deep HR industry knowledge with global marketing expertise to deliver campaigns that resonate with candidates, employees, and buyers alike.
            </p>
          </div>
          <div className={styles.whyGrid}>
            <div className={styles.whyCard}>
              <h3>Deep HR industry knowledge</h3>
              <p>
                Our strategists have worked inside HR tech, staffing, and enterprise HR teams. We understand the pressures of talent acquisition, internal comms, and EVP stewardship.
              </p>
            </div>
            <div className={styles.whyCard}>
              <h3>Data-driven storytelling</h3>
              <p>
                We blend qualitative insights with quantitative modelling to craft messaging that catalyzes action and strengthens your employer promise.
              </p>
            </div>
            <div className={styles.whyCard}>
              <h3>Integrated campaign delivery</h3>
              <p>
                Recruitment media, paid social, content, and experiential activations come together under one roof for seamless execution.
              </p>
            </div>
            <div className={styles.whyCard}>
              <h3>Measurable, transparent outcomes</h3>
              <p>
                We build dashboards tailored to HR KPIs so your team can confidently report impact to leadership and investors.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Trusted by HR-forward brands</h2>
            <p className="sectionSubtitle">
              HR departments, talent acquisition teams, and HR tech companies rely on HR Advertise to cut through the noise and connect with people.
            </p>
          </div>
          <div className={styles.logosRow}>
            {clientLogos.map((logo) => (
              <span key={logo} className={styles.logoBadge} aria-label={`Client: ${logo}`}>
                {logo}
              </span>
            ))}
          </div>

          <article className={styles.testimonialCard}>
            <div className={styles.testimonialMedia}>
              <img src={activeTestimonial.image} alt={`${activeTestimonial.name} headshot`} />
            </div>
            <div>
              <p className={styles.testimonialQuote}>&ldquo;{activeTestimonial.quote}&rdquo;</p>
              <p className={styles.testimonialAuthor}>
                {activeTestimonial.name} • <span>{activeTestimonial.role}</span>
              </p>
            </div>
          </article>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Latest insights for HR trailblazers</h2>
            <p className="sectionSubtitle">
              Perspectives on HR marketing, employer branding, and recruitment advertising directly from our strategists.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span className="tag">{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <a href={post.link} className={styles.blogLink}>
                  Read more →
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Ready to transform your HR marketing?</h2>
            <p>
              Let&apos;s align on goals, audiences, and activation. Our team will craft a tailored plan to help you attract, engage, and retain the talent and partners you need to thrive.
            </p>
            <Link to="/contact" className="ctaButton">
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;