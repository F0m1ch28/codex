import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CaseStudies.module.css';

const categories = ['All', 'HR Tech', 'Recruitment', 'Employer Branding'];

const caseStudiesData = [
  {
    title: 'Rebuilding the EVP for a multinational staffing firm',
    category: 'Employer Branding',
    image:
      'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1200&q=80',
    result: '72% lift in employee advocacy engagement',
    description:
      'We refreshed the employer value proposition, aligned leadership around core narratives, and launched a content-rich employee advocacy program across 18 markets.',
    tags: ['EVP Research', 'Culture Messaging', 'Content Studio']
  },
  {
    title: 'Driving HR tech demos across APAC',
    category: 'HR Tech',
    image:
      'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80',
    result: '3.2x increase in demo requests within 90 days',
    description:
      'By combining intent data, region-specific creative, and conversational nurture flows we accelerated pipeline creation for a SaaS HR platform entering new markets.',
    tags: ['Demand Generation', 'ABM', 'Lifecycle Marketing']
  },
  {
    title: 'Healthcare talent pipeline transformation',
    category: 'Recruitment',
    image:
      'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80',
    result: '38% reduction in time-to-fill for critical roles',
    description:
      'Our team orchestrated hyper-local recruitment campaigns, refreshed candidate journeys, and built real-time dashboards for a healthcare provider.',
    tags: ['Programmatic Media', 'Employer Brand Content', 'Analytics']
  },
  {
    title: 'Elevating a remote-first culture narrative',
    category: 'Employer Branding',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1200&q=80',
    result: 'Employer brand perception +27 points',
    description:
      'We designed a culture documentary series, digital experience hub, and onboarding comms that showcased the lived experience of distributed employees.',
    tags: ['Content Production', 'Digital Experience', 'Onboarding Comms']
  },
  {
    title: 'Recruitment marketing revamp for a fintech scaleup',
    category: 'Recruitment',
    image:
      'https://images.unsplash.com/photo-1531498860502-7c67cf02f77b?auto=format&fit=crop&w=1200&q=80',
    result: 'Qualified applications up 61%',
    description:
      'Integrated media strategy, refreshed creative, and automated nurture mapped to each stage of the candidate journey delivered a sustainable pipeline.',
    tags: ['Paid Social', 'Landing Pages', 'Automation']
  }
];

const CaseStudies = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredCaseStudies = useMemo(() => {
    if (selectedCategory === 'All') return caseStudiesData;
    return caseStudiesData.filter((study) => study.category === selectedCategory);
  }, [selectedCategory]);

  return (
    <>
      <Helmet>
        <title>Case Studies | HR Advertise Results in HR Marketing</title>
        <meta
          name="description"
          content="Explore HR Advertise case studies that showcase employer branding, recruitment marketing, and HR tech campaign results for global HR organisations."
        />
      </Helmet>

      <header className={styles.pageHero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Case Studies</span>
            <h1>Real HR marketing outcomes, globally</h1>
            <p>
              See how HR Advertise partners with HR tech innovators, recruitment teams, and enterprise organisations to deliver measurable impact.
            </p>
          </div>
        </div>
      </header>

      <section className={styles.caseSection}>
        <div className="container">
          <div className={styles.filterBar} role="tablist" aria-label="Filter case studies by category">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={selectedCategory === category}
                className={`${styles.filterButton} ${selectedCategory === category ? styles.filterActive : ''}`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>

          <div className={styles.caseGrid}>
            {filteredCaseStudies.map((study) => (
              <article key={study.title} className={styles.caseCard}>
                <div className={styles.cardImage}>
                  <img src={study.image} alt={study.title} />
                  <span className={styles.categoryTag}>{study.category}</span>
                </div>
                <div className={styles.cardContent}>
                  <h2>{study.title}</h2>
                  <p>{study.description}</p>
                  <div className={styles.result}>
                    <strong>Impact:</strong> {study.result}
                  </div>
                  <div className={styles.tagList}>
                    {study.tags.map((tag) => (
                      <span key={tag} className="tag">{tag}</span>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default CaseStudies;