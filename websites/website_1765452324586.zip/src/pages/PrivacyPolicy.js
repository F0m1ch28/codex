import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './LegalPage.module.css';

const PrivacyPolicy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | HR Advertise</title>
      <meta
        name="description"
        content="Review HR Advertise's Privacy Policy to learn how we collect, use, and protect personal information."
      />
    </Helmet>

    <section className={styles.legalSection}>
      <div className="container">
        <div className={styles.legalCard}>
          <h1>Privacy Policy</h1>
          <p>Updated: July 2024</p>

          <h2>Overview</h2>
          <p>
            HR Advertise respects your privacy. This policy explains the data we collect, how we use it, and the rights you have regarding your personal information.
          </p>

          <h2>Information we collect</h2>
          <ul>
            <li>Contact details such as name, email, company, and phone number.</li>
            <li>Project information provided through forms or consultations.</li>
            <li>Usage data, analytics, and cookies to improve the website experience.</li>
          </ul>

          <h2>How we use information</h2>
          <p>We use personal data to:</p>
          <ul>
            <li>Respond to inquiries and provide requested services.</li>
            <li>Send relevant insights, updates, or event invitations with consent.</li>
            <li>Improve user experience through analytics and feedback.</li>
          </ul>

          <h2>Sharing of information</h2>
          <p>
            We do not sell personal data. We may share information with trusted service providers who assist with operations, analytics, or communication, all under confidentiality agreements.
          </p>

          <h2>Data retention</h2>
          <p>
            We retain personal information for as long as necessary to fulfill the purposes described in this policy or as required by law.
          </p>

          <h2>Your rights</h2>
          <p>You have the right to:</p>
          <ul>
            <li>Request access to the personal data we hold about you.</li>
            <li>Request corrections or updates to your information.</li>
            <li>Opt out of marketing communications at any time.</li>
            <li>Request deletion of your personal data, subject to legal obligations.</li>
          </ul>

          <h2>Cookies</h2>
          <p>
            We use cookies and similar technologies to deliver core functionality and analyse website performance. You can adjust cookie preferences through your browser settings.
          </p>

          <h2>Security</h2>
          <p>
            We implement security measures to protect personal data from unauthorised access, disclosure, or misuse. However, no method is entirely secure, and we encourage users to share only necessary information.
          </p>

          <h2>Contact</h2>
          <p>
            For privacy inquiries, contact <a href="mailto:privacy@hradvertise.com">privacy@hradvertise.com</a> or +1 (555) 123-4567.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default PrivacyPolicy;