import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './LegalPage.module.css';

const TermsOfService = () => (
  <>
    <Helmet>
      <title>Terms of Service | HR Advertise</title>
      <meta
        name="description"
        content="Review the Terms of Service governing the use of the HR Advertise website and services."
      />
    </Helmet>

    <section className={styles.legalSection}>
      <div className="container">
        <div className={styles.legalCard}>
          <h1>Terms of Service</h1>
          <p>Updated: July 2024</p>

          <h2>1. Agreement to terms</h2>
          <p>
            By accessing the HR Advertise website or engaging with our services, you agree to abide by these Terms of Service. If you do not agree with any part, please discontinue use of the site.
          </p>

          <h2>2. Intellectual property</h2>
          <p>
            All content, branding, materials, and assets on this website are the intellectual property of HR Advertise unless otherwise noted. You may not reproduce, distribute, or create derivative works without written permission.
          </p>

          <h2>3. Use of services</h2>
          <p>
            HR Advertise provides marketing and advertising services tailored to HR organisations. All project scopes, deliverables, and success metrics will be outlined in a separate master services agreement or statement of work.
          </p>

          <h2>4. Confidentiality</h2>
          <p>
            We take confidentiality seriously. Any proprietary or confidential information shared between parties will be protected under mutual nondisclosure terms and applicable confidentiality clauses.
          </p>

          <h2>5. Third-party links</h2>
          <p>
            Our website may contain links to third-party resources. HR Advertise does not control or assume responsibility for the content or practices of these external websites.
          </p>

          <h2>6. Limitation of liability</h2>
          <p>
            HR Advertise will not be liable for any indirect, incidental, or consequential damages that arise from the use of our site or services. Our total liability is limited to the amount paid for specific services rendered.
          </p>

          <h2>7. Governing law</h2>
          <p>
            These terms are governed by the laws of the State of California, United States. Any disputes will be resolved through binding arbitration or the appropriate courts within that jurisdiction.
          </p>

          <h2>8. Changes to terms</h2>
          <p>
            HR Advertise may update these Terms of Service periodically. Any updates will be posted on this page with an updated revision date.
          </p>

          <h2>9. Contact</h2>
          <p>
            If you have questions about these Terms of Service, contact us at <a href="mailto:info@hradvertise.com">info@hradvertise.com</a> or +1 (555) 123-4567.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default TermsOfService;