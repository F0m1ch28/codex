document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            primaryNav.classList.toggle('nav-open');
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (primaryNav.classList.contains('nav-open')) {
                    primaryNav.classList.remove('nav-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedPreference = localStorage.getItem('waterrvonbCookies');
        if (!storedPreference) {
            cookieBanner.classList.add('show');
        }

        cookieBanner.querySelectorAll('[data-cookie-choice]').forEach(button => {
            button.addEventListener('click', (event) => {
                const choice = button.getAttribute('data-cookie-choice');
                const target = button.getAttribute('data-cookie-target');
                localStorage.setItem('waterrvonbCookies', choice);
                cookieBanner.classList.remove('show');
                if (target) {
                    window.location.href = target;
                }
                event.preventDefault();
            });
        });
    }
});