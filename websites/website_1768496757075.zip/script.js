document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav-list');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-actions .button');

    if (navToggle && navList) {
        navToggle.addEventListener('click', function () {
            navList.classList.toggle('nav-open');
        });
    }

    if (cookieBanner && cookieButtons.length) {
        cookieButtons.forEach(function (button) {
            button.addEventListener('click', function (event) {
                event.preventDefault();
                cookieBanner.classList.add('cookie-hidden');
                const target = button.getAttribute('href');
                if (target) {
                    window.location.href = target;
                }
            });
        });
    }
});