document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".main-navigation");
    const scrollTopBtn = document.querySelector(".scroll-top");
    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieAcceptBtn = document.getElementById("acceptCookies");
    const contactForm = document.getElementById("contactForm");
    const currentYearEl = document.getElementById("current-year");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navMenu.classList.toggle("open");
        });
    }

    document.querySelectorAll("a.nav-link").forEach(link => {
        link.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "instant" });
            if (navMenu && navMenu.classList.contains("open")) {
                navMenu.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            }
        });
    });

    window.addEventListener("scroll", () => {
        if (window.scrollY > 300) {
            scrollTopBtn.classList.add("show");
        } else {
            scrollTopBtn.classList.remove("show");
        }
    });

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    const cookieConsent = localStorage.getItem("smdCookieAccepted");
    if (!cookieConsent && cookieBanner) {
        cookieBanner.classList.add("active");
    }

    if (cookieAcceptBtn) {
        cookieAcceptBtn.addEventListener("click", () => {
            localStorage.setItem("smdCookieAccepted", "true");
            cookieBanner.classList.remove("active");
        });
    }

    if (contactForm) {
        const feedback = contactForm.querySelector(".form-feedback");
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            feedback.textContent = "Thank you for your message. Our team will respond within one business day.";
            contactForm.reset();
        });
    }

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }
});