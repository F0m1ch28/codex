document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('[data-nav-toggle]');
  const navMenu = document.querySelector('[data-nav-menu]');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', function () {
      const isOpen = navMenu.classList.toggle('is-open');
      navToggle.classList.toggle('is-active', isOpen);
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    const navLinks = navMenu.querySelectorAll('a');
    navLinks.forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.innerWidth < 768) {
          navMenu.classList.remove('is-open');
          navToggle.classList.remove('is-active');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptButton = cookieBanner.querySelector('[data-cookie-accept]');
    const declineButton = cookieBanner.querySelector('[data-cookie-decline]');
    const savedChoice = localStorage.getItem('abhTattooCookiesChoice');

    if (savedChoice) {
      cookieBanner.classList.add('is-hidden');
    }

    const handleChoice = function (choice) {
      localStorage.setItem('abhTattooCookiesChoice', choice);
      cookieBanner.classList.add('is-hidden');
    };

    if (acceptButton) {
      acceptButton.addEventListener('click', function (event) {
        event.preventDefault();
        handleChoice('accepted');
      });
    }

    if (declineButton) {
      declineButton.addEventListener('click', function (event) {
        event.preventDefault();
        handleChoice('declined');
      });
    }
  }
});