document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-links a');
    const scrollBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const contactForm = document.getElementById('contactForm');
    const formMessage = document.getElementById('formMessage');
    const cookieStorageKey = 'ntaCookieConsent';

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            siteNav.classList.toggle('open');
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (siteNav) {
                siteNav.classList.remove('open');
            }
            if (navToggle) {
                navToggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    const toggleScrollButton = () => {
        if (!scrollBtn) return;
        if (window.scrollY > 240) {
            scrollBtn.style.display = 'flex';
        } else {
            scrollBtn.style.display = 'none';
        }
    };

    window.addEventListener('scroll', toggleScrollButton);
    toggleScrollButton();

    if (scrollBtn) {
        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner) {
        const consent = localStorage.getItem(cookieStorageKey);
        if (consent !== 'accepted') {
            cookieBanner.classList.add('active');
        } else {
            cookieBanner.classList.add('hidden');
        }
    }

    if (acceptCookiesBtn && cookieBanner) {
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem(cookieStorageKey, 'accepted');
            cookieBanner.classList.remove('active');
            cookieBanner.classList.add('hidden');
        });
    }

    if (contactForm && formMessage) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            formMessage.textContent = 'Thank you for reaching out. A member of our team will contact you within one business day.';
            contactForm.reset();
        });
    }
});