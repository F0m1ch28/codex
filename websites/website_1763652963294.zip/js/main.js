document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.getElementById('nav-toggle');
  const siteNav = document.getElementById('site-nav');
  const cookieBanner = document.getElementById('cookie-banner');
  const acceptCookies = document.getElementById('accept-cookies');
  const rejectCookies = document.getElementById('reject-cookies');

  if (navToggle && siteNav) {
    const toggleNav = () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      navToggle.classList.toggle('nav-open');
      siteNav.classList.toggle('nav-open');
      document.body.classList.toggle('nav-active');
    };

    navToggle.addEventListener('click', toggleNav);

    siteNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (siteNav.classList.contains('nav-open')) {
          toggleNav();
        }
      });
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && siteNav.classList.contains('nav-open')) {
        toggleNav();
      }
    });
  }

  if (cookieBanner && acceptCookies && rejectCookies) {
    const consentKey = 'luminaCookieConsent';
    const storedConsent = localStorage.getItem(consentKey);

    if (!storedConsent) {
      cookieBanner.classList.add('visible');
    }

    const handleConsent = (value) => {
      localStorage.setItem(consentKey, value);
      cookieBanner.classList.remove('visible');
    };

    acceptCookies.addEventListener('click', () => handleConsent('accepted'));
    rejectCookies.addEventListener('click', () => handleConsent('rejected'));
  }
});