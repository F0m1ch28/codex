document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            siteNav.classList.toggle('is-open');
        });

        siteNav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (siteNav.classList.contains('is-open')) {
                    siteNav.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');
    const storageKey = 'redbiraeezCookieChoice';

    if (cookieBanner) {
        const storedChoice = localStorage.getItem(storageKey);
        if (!storedChoice) {
            cookieBanner.classList.add('show');
        }

        const handleChoice = function (choice) {
            cookieBanner.classList.remove('show');
            localStorage.setItem(storageKey, choice);
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                handleChoice('accepted');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                handleChoice('declined');
            });
        }
    }
});