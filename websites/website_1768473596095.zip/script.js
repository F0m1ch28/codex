document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const body = document.body;

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-active');
            navMenu.classList.toggle('is-open');
            body.classList.toggle('no-scroll', navMenu.classList.contains('is-open'));
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth > 1024) {
                navToggle.classList.remove('is-active');
                navMenu.classList.remove('is-open');
                body.classList.remove('no-scroll');
            }
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-accept');
    const declineBtn = document.querySelector('.cookie-decline');
    const storageKey = 'civioraCookieConsent';

    if (cookieBanner && acceptBtn && declineBtn) {
        const savedPreference = localStorage.getItem(storageKey);
        if (!savedPreference) {
            cookieBanner.classList.add('visible');
        }

        acceptBtn.addEventListener('click', () => {
            localStorage.setItem(storageKey, 'accepted');
            cookieBanner.classList.remove('visible');
        });

        declineBtn.addEventListener('click', () => {
            localStorage.setItem(storageKey, 'declined');
            cookieBanner.classList.remove('visible');
        });
    }

    const filterButtons = document.querySelectorAll('[data-filter]');
    const searchField = document.querySelector('#search-term');
    const postCards = document.querySelectorAll('[data-category]');

    const applyFilters = () => {
        const activeFilter = document.querySelector('[data-filter].is-active');
        const query = searchField ? searchField.value.trim().toLowerCase() : '';
        postCards.forEach(card => {
            const category = card.getAttribute('data-category');
            const title = card.querySelector('h3') ? card.querySelector('h3').textContent.toLowerCase() : '';
            const excerpt = card.querySelector('p') ? card.querySelector('p').textContent.toLowerCase() : '';
            const matchesFilter = activeFilter ? activeFilter.dataset.filter === 'all' || activeFilter.dataset.filter === category : true;
            const matchesSearch = query === '' || title.includes(query) || excerpt.includes(query);
            card.style.display = matchesFilter && matchesSearch ? '' : 'none';
        });
    };

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            filterButtons.forEach(btn => btn.classList.remove('is-active'));
            button.classList.add('is-active');
            applyFilters();
        });
    });

    if (searchField) {
        searchField.addEventListener('input', () => {
            applyFilters();
        });
    }

    applyFilters();
});