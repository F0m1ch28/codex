document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const body = document.body;

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('is-open');
            body.classList.toggle('nav-open');
            navToggle.classList.toggle('is-active');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('is-open');
                body.classList.remove('nav-open');
                navToggle.setAttribute('aria-expanded', 'false');
                navToggle.classList.remove('is-active');
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAccept = document.getElementById('cookie-accept');
    const cookieStorageKey = 'pi-cookie-consent';

    if (cookieBanner && cookieAccept) {
        if (!localStorage.getItem(cookieStorageKey)) {
            cookieBanner.classList.add('visible');
        }

        cookieAccept.addEventListener('click', () => {
            localStorage.setItem(cookieStorageKey, 'accepted');
            cookieBanner.classList.remove('visible');
        });
    }

    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const formMessage = contactForm.querySelector('.form-message');
            const formData = new FormData(contactForm);
            const name = formData.get('name').trim();
            const email = formData.get('email').trim();
            const message = formData.get('message').trim();

            if (!name || !email || !message) {
                formMessage.textContent = 'Compila i campi obbligatori prima di inviare.';
                formMessage.classList.remove('success');
                formMessage.classList.add('error');
                return;
            }

            formMessage.textContent = 'Richiesta inviata con successo. Ti ricontatteremo entro 24 ore lavorative.';
            formMessage.classList.remove('error');
            formMessage.classList.add('success');
            contactForm.reset();
        });
    }

    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', (event) => {
            event.preventDefault();
            alert('Grazie per esserti iscritto alla newsletter tecnica PetroItalia Progetti.');
            newsletterForm.reset();
        });
    }

    const animatedElements = document.querySelectorAll('[data-animate]');
    if (animatedElements.length > 0) {
        const observer = new IntersectionObserver((entries, obs) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate');
                    obs.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12 });

        animatedElements.forEach(el => observer.observe(el));
    }
});