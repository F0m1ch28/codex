document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector("[data-nav-toggle]");
  const siteNav = document.querySelector("[data-site-nav]");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = siteNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
  }

  const banner = document.querySelector("[data-cookie-banner]");
  if (banner) {
    const acceptBtn = banner.querySelector("[data-cookie-accept]");
    const declineBtn = banner.querySelector("[data-cookie-decline]");
    const consent = localStorage.getItem("cookieConsent");

    if (!consent) {
      banner.classList.add("is-visible");
    }

    const hideBanner = (value) => {
      localStorage.setItem("cookieConsent", value);
      banner.classList.remove("is-visible");
    };

    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => hideBanner("accepted"));
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => hideBanner("declined"));
    }
  }
});