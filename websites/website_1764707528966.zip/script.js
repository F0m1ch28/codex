document.addEventListener('DOMContentLoaded', () => {
  const banner = document.querySelector('.cookie-banner');
  if (!banner) return;

  const acceptBtn = banner.querySelector('[data-cookie-accept]');
  const declineBtn = banner.querySelector('[data-cookie-decline]');
  const storageKey = 'altaverino-cookie-consent';

  const storedPreference = localStorage.getItem(storageKey);
  if (!storedPreference) {
    requestAnimationFrame(() => {
      banner.classList.add('is-active');
    });
  }

  const hideBanner = (value) => {
    localStorage.setItem(storageKey, value);
    banner.classList.remove('is-active');
    banner.classList.add('is-hidden');
  };

  acceptBtn?.addEventListener('click', () => hideBanner('accepted'));
  declineBtn?.addEventListener('click', () => hideBanner('declined'));
});