'use strict';

document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', function () {
      const isOpen = siteNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    siteNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        siteNav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
    const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
    const storageKey = 'ikvy-cookie-consent';
    let storedConsent = null;

    try {
      storedConsent = localStorage.getItem(storageKey);
    } catch (error) {
      storedConsent = null;
    }

    if (!storedConsent) {
      setTimeout(function () {
        cookieBanner.classList.add('is-visible');
      }, 400);
    }

    const hideBanner = function (decision) {
      cookieBanner.classList.remove('is-visible');
      try {
        localStorage.setItem(storageKey, decision);
      } catch (error) {
        // Игнорируем ошибку доступа к localStorage
      }
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        hideBanner('accepted');
      });
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', function () {
        hideBanner('declined');
      });
    }
  }

  const gamePanel = document.querySelector('[data-game]');
  if (gamePanel) {
    const questionEl = gamePanel.querySelector('[data-question]');
    const tipEl = gamePanel.querySelector('[data-tip]');
    const feedbackEl = gamePanel.querySelector('[data-feedback]');
    const optionsContainer = gamePanel.querySelector('[data-options]');
    const optionButtons = Array.from(gamePanel.querySelectorAll('[data-option]'));
    const startButton = gamePanel.querySelector('[data-start]');
    const nextButton = gamePanel.querySelector('[data-next]');
    const scoreEl = gamePanel.querySelector('[data-score]');
    const roundEl = gamePanel.querySelector('[data-round]');
    const totalRoundsEl = gamePanel.querySelector('[data-total-rounds]');
    const progressBar = gamePanel.querySelector('[data-progress]');

    const scenarios = [
      {
        question: 'Пользователь спрашивает Алису: «Поставь таймер на кофе, чтобы я не забыл». Какое действие поможет быстрее?',
        options: [
          'Ответить, что таймер можно поставить в приложении Таймер',
          'Сразу запустить таймер и предложить сохранить шаблон',
          'Включить подборку новостей, чтобы пользователь не скучал'
        ],
        answer: 1,
        hint: 'Алиса должна закрывать задачу моментально, без переключений.',
        success: 'Вы моментально запустили таймер и сохранили шаблон — пользователь доволен скоростью.',
        fail: 'Переключение в другое приложение усложняет сценарий и снижает доверие.'
      },
      {
        question: 'В приложении Яндекс Музыка пользователь ищет «звук дождя для сна». Какой вариант повысит удержание?',
        options: [
          'Создать для него новую радиостанцию “Дождь и сон”',
          'Показать плейлист редакции без учёта предыдущих прослушиваний',
          'Рассказать про подборку подкастов про медитацию'
        ],
        answer: 0,
        hint: 'Персонализация — ключ к удержанию аудитории в музыке.',
        success: 'Новая радиостанция основана на поведении пользователя и удержит внимание дольше.',
        fail: 'Чужой плейлист может не попасть в ожидания, а лишние советы отвлекают.'
      },
      {
        question: 'В поиске пользователь вводит «самокат сломался, что делать». Какой ответ повысит лояльность?',
        options: [
          'Показать инструкцию из справки, как оформить заявку',
          'Предложить купить новый самокат на Маркете',
          'Показать истории успеха от других райдеров'
        ],
        answer: 0,
        hint: 'Человек переживает и ищет быстрый способ починки.',
        success: 'Пошаговая инструкция помогает решить проблему здесь и сейчас, повышая доверие.',
        fail: 'Продажи и истории не решают текущую боль пользователя.'
      },
      {
        question: 'Яндекс Еда: Пользователь заказывает ужин и задаёт вопрос «можете без лука?». Что выбрать?',
        options: [
          'Передать запрос ресторану и подтвердить изменение состава',
          'Предложить блюда из другой кухни без лука',
          'Сказать, что изменения невозможны'
        ],
        answer: 0,
        hint: 'Персонализация заказа повышает удовлетворённость по NPS.',
        success: 'Вы подтвердили изменение — пользователь чувствует заботу и остаётся с сервисом.',
        fail: 'Отказ без попытки помочь приводит к отмене заказа.'
      },
      {
        question: 'Яндекс Маркет видит, что пользователь часто возвращается к разделу умных колонок. Как его мотивировать купить?',
        options: [
          'Показать сравнение устройств и предложить оплату частями',
          'Отправить email с подборкой статей об экосистеме',
          'Показать баннер с общими акциями недели'
        ],
        answer: 0,
        hint: 'У пользователя высокая вовлечённость, нужно помочь принять решение.',
        success: 'Сравнение и гибкая оплата снимают барьеры и увеличивают конверсию.',
        fail: 'Общие акции не отвечают на конкретный запрос.'
      },
      {
        question: 'В Яндекс Навигаторе пользователь стоит в пробке и спрашивает: «Как быстрее?».',
        options: [
          'Показать альтернативный маршрут и оценку экономии времени',
          'Сделать подборку аудиокниг, чтобы время прошло быстрее',
          'Посоветовать выйти из машины и пройти пешком'
        ],
        answer: 0,
        hint: 'Главная задача — минимизировать задержку.',
        success: 'Альтернативный маршрут сэкономит время и повысит доверие к сервису.',
        fail: 'Развлечения не решают основную проблему пользователя.'
      },
      {
        question: 'В Дзене пользователь читает статью про путешествия и находится в конце материала.',
        options: [
          'Показать подборку статей о похожих маршрутах',
          'Попросить оценить материал и оставить комментарий',
          'Предложить купить тур в партнерском сервисе'
        ],
        answer: 0,
        hint: 'Важно удержать внимание внутри контента.',
        success: 'Релевантная подборка удерживает пользователя и увеличивает глубину просмотра.',
        fail: 'Резкая монетизация может отвернуть аудиторию.'
      }
    ];

    let deck = [];
    let currentRound = 0;
    let score = 0;
    let answered = false;
    const pointsPerRound = 10;
    const maxRounds = 6;

    const shuffleArray = function (array) {
      return array.slice().sort(function () {
        return Math.random() - 0.5;
      });
    };

    const resetButtonsState = function () {
      optionButtons.forEach(function (button) {
        button.disabled = true;
        button.classList.remove('is-correct', 'is-incorrect');
      });
    };

    const updateProgress = function () {
      if (!deck.length) {
        progressBar.style.width = '0%';
        return;
      }
      const percentage = ((currentRound) / deck.length) * 100;
      progressBar.style.width = Math.min(percentage, 100) + '%';
    };

    const setRound = function () {
      const scenario = deck[currentRound];
      questionEl.textContent = scenario.question;
      scenario.options.forEach(function (option, index) {
        if (optionButtons[index]) {
          optionButtons[index].textContent = option;
          optionButtons[index].disabled = false;
          optionButtons[index].classList.remove('is-correct', 'is-incorrect');
        }
      });
      tipEl.textContent = scenario.hint;
      feedbackEl.textContent = 'Выберите вариант ответа.';
      feedbackEl.classList.remove('is-negative');
      optionsContainer.classList.remove('is-hidden');
      tipEl.classList.remove('is-hidden');
      answered = false;
      roundEl.textContent = String(currentRound + 1);
      totalRoundsEl.textContent = String(deck.length);
      updateProgress();
      nextButton.classList.add('is-hidden');
    };

    const finishGame = function () {
      const maxScore = deck.length * pointsPerRound;
      const ratio = Math.round((score / maxScore) * 100);
      let message = 'Отличная работа! Вы уверенно чувствуете продуктовые механики.';
      if (ratio < 40) {
        message = 'Стоит более внимательно читать подсказки и фокусироваться на потребности пользователя.';
      } else if (ratio < 70) {
        message = 'Хороший результат! Попробуйте пройти ещё раз и улучшить стратегию.';
      }
      questionEl.textContent = 'Итог игры';
      feedbackEl.textContent = 'Ваш счёт: ' + score + ' из ' + maxScore + ' возможных. ' + message;
      feedbackEl.classList.remove('is-negative');
      optionsContainer.classList.add('is-hidden');
      tipEl.textContent = 'Совет: обсудите результаты с командой и сравните свои решения.';
      nextButton.classList.add('is-hidden');
      startButton.classList.remove('is-hidden');
      startButton.textContent = 'Сыграть ещё раз';
      progressBar.style.width = '100%';
      roundEl.textContent = String(deck.length);
      answered = false;
    };

    const checkAnswer = function (selectedIndex, button) {
      if (answered) {
        return;
      }
      answered = true;
      const scenario = deck[currentRound];
      optionButtons.forEach(function (btn) {
        btn.disabled = true;
      });

      if (selectedIndex === scenario.answer) {
        score += pointsPerRound;
        feedbackEl.textContent = scenario.success;
        feedbackEl.classList.remove('is-negative');
        button.classList.add('is-correct');
      } else {
        feedbackEl.textContent = scenario.fail;
        feedbackEl.classList.add('is-negative');
        button.classList.add('is-incorrect');
        const correctButton = optionButtons[scenario.answer];
        if (correctButton) {
          correctButton.classList.add('is-correct');
        }
      }

      scoreEl.textContent = String(score);
      progressBar.style.width = ((currentRound + 1) / deck.length) * 100 + '%';
      nextButton.classList.remove('is-hidden');
      nextButton.textContent = currentRound === deck.length - 1 ? 'Завершить игру' : 'Следующий раунд';
    };

    optionButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        const selected = Number(button.getAttribute('data-option'));
        checkAnswer(selected, button);
      });
    });

    if (nextButton) {
      nextButton.addEventListener('click', function () {
        if (!answered) {
          return;
        }
        currentRound += 1;
        if (currentRound < deck.length) {
          setRound();
        } else {
          finishGame();
        }
      });
    }

    if (startButton) {
      startButton.addEventListener('click', function () {
        score = 0;
        currentRound = 0;
        answered = false;
        scoreEl.textContent = '0';
        startButton.classList.add('is-hidden');
        nextButton.classList.add('is-hidden');
        deck = shuffleArray(scenarios).slice(0, Math.min(maxRounds, scenarios.length));
        resetButtonsState();
        optionButtons.forEach(function (button) {
          button.disabled = false;
        });
        setRound();
      });
    }
  }
});