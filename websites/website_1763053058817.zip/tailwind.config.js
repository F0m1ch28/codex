/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        midnight: "#111827",
        slateSurface: "#334155",
        accent: "#3B82F6",
        mist: "#F1F5F9"
      },
      fontFamily: {
        display: ["Satoshi", "Inter", "system-ui", "sans-serif"],
        body: ["Inter", "system-ui", "sans-serif"]
      },
      boxShadow: {
        card: "0 20px 40px rgba(15, 23, 42, 0.25)",
        glow: "0 0 40px rgba(59, 130, 246, 0.35)"
      },
      backgroundImage: {
        "grid-overlay": "linear-gradient(135deg, rgba(148, 163, 184, 0.12) 0%, rgba(89, 94, 204, 0.08) 100%)"
      }
    }
  },
  plugins: []
};