// @ts-check
import React, { Suspense, lazy } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";

const Home = lazy(() => import("./pages/Home"));
const About = lazy(() => import("./pages/About"));
const Services = lazy(() => import("./pages/Services"));
const Contact = lazy(() => import("./pages/Contact"));
const ContactThanks = lazy(() => import("./pages/ContactThanks"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Terms = lazy(() => import("./pages/Terms"));
const Blog = lazy(() => import("./pages/Blog"));
const BlogContextSwitching = lazy(() => import("./pages/BlogWhyContextSwitching"));
const BlogCloudPatterns = lazy(() => import("./pages/BlogCloudPatterns"));
const BlogDevOpsCulture = lazy(() => import("./pages/BlogDevOpsCulture"));
const Workflows = lazy(() => import("./pages/Workflows"));
const Mindset = lazy(() => import("./pages/Mindset"));
const Queue = lazy(() => import("./pages/Queue"));
const Archives = lazy(() => import("./pages/Archives"));
const Notes = lazy(() => import("./pages/Notes"));

const App = () => {
  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen flex flex-col bg-midnight text-mist">
        <Header />
        <main className="flex-1 pt-24 md:pt-28">
          <Suspense
            fallback={
              <div className="flex items-center justify-center py-24 text-center text-lg">
                Loading DevLayer experience…
              </div>
            }
          >
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/services" element={<Services />} />
              <Route path="/workflows" element={<Workflows />} />
              <Route path="/mindset" element={<Mindset />} />
              <Route path="/queue" element={<Queue />} />
              <Route path="/archives" element={<Archives />} />
              <Route path="/notes" element={<Notes />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/blog/why-context-switching-kills-productivity" element={<BlogContextSwitching />} />
              <Route path="/blog/cloud-patterns-for-scale" element={<BlogCloudPatterns />} />
              <Route path="/blog/the-evolution-of-devops-culture" element={<BlogDevOpsCulture />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/contact/thanks" element={<ContactThanks />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/terms" element={<Terms />} />
            </Routes>
          </Suspense>
        </main>
        <Footer />
        <CookieBanner />
      </div>
    </Router>
  );
};

export default App;