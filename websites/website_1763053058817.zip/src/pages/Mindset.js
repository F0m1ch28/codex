// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const Mindset = () => (
  <>
    <Helmet>
      <title>Developer Mindset Essays | DevLayer</title>
      <meta
        name="description"
        content="Dive into DevLayer essays on cognitive processes, burnout signals, communication frameworks, and focus rituals for developers."
      />
    </Helmet>

    <section className="mx-auto max-w-5xl px-4 pb-20 pt-10 sm:px-6 lg:px-8">
      <h1 className="font-display text-4xl font-semibold text-white">Developer Mindset Essays</h1>
      <p className="mt-4 text-lg text-slate-300">
        Essays and dispatches exploring cognitive health, collaboration, and psychological safety in engineering teams.
      </p>

      <div className="mt-12 space-y-10">
        {mindsetEssays.map((essay) => (
          <article key={essay.title} className="rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8 shadow-card">
            <h2 className="font-display text-2xl font-semibold text-white">{essay.title}</h2>
            <p className="mt-3 text-sm text-slate-300">{essay.summary}</p>
            <ul className="mt-6 space-y-3 text-sm text-slate-300">
              {essay.points.map((point) => (
                <li key={point} className="flex items-start space-x-3">
                  <span className="mt-1 h-2 w-2 rounded-full bg-accent/70" />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </section>
  </>
);

const mindsetEssays = [
  {
    title: "Cognitive Drift and Focus Anchors",
    summary:
      "How developers maintain flow amid noisy tooling and distributed collaboration. Focus anchors create shared rituals for regaining momentum.",
    points: [
      "Designing personal and team-level focus anchors using environmental cues.",
      "Mitigating energy drain by scheduling restorative breaks aligned with task complexity.",
      "Encouraging communal check-ins to surface workload imbalances early."
    ]
  },
  {
    title: "Burnout Signals in Slow Motion",
    summary:
      "Subtle indicators of burnout rarely appear in dashboards. We describe narrative signals and how managers can respond with care.",
    points: [
      "Watch for language shifts that hint at detachment or cynicism.",
      "Implement temperature checks that ask how work feels, not just what was accomplished.",
      "Offer decompression spaces where engineers share unfiltered experiences."
    ]
  },
  {
    title: "Communication Frameworks for Deep Teams",
    summary:
      "Common language shortens discovery cycles. We publish frameworks for writing, diagramming, and asynchronous updates.",
    points: [
      "Use empathy-driven templates for design proposals and incident write-ups.",
      "Invest in visual literacy workshops so diagrams communicate intent clearly.",
      "Match communication channels with urgency and cognitive impact."
    ]
  }
];

export default Mindset;