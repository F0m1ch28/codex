// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const Services = () => {
  return (
    <>
      <Helmet>
        <title>DevLayer Services | Editorial Programs for Engineering Teams</title>
        <meta
          name="description"
          content="Discover DevLayer’s editorial programs, workflow mapping studios, and platform research services tailored for engineering organisations."
        />
      </Helmet>

      <section className="mx-auto max-w-6xl px-4 pb-20 pt-10 sm:px-6 lg:px-8">
        <header className="text-center">
          <h1 className="font-display text-4xl font-semibold text-white sm:text-5xl">
            Editorial programs designed for engineering organisations.
          </h1>
          <p className="mt-4 text-lg text-slate-300">
            We combine research, narrative craft, and platform expertise to illuminate how your teams build and ship.
          </p>
        </header>

        <div className="mt-16 grid gap-10 md:grid-cols-2">
          {servicePackages.map((service) => (
            <motion.div
              key={service.title}
              className="relative overflow-hidden rounded-3xl border border-slate-800/70 bg-slate-900/60 p-10 shadow-card"
              whileHover={{ y: -8, borderColor: "rgba(59,130,246,0.6)" }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-transparent to-transparent opacity-40" />
              <div className="relative">
                <span className="text-xs uppercase tracking-[0.3em] text-slate-500">{service.type}</span>
                <h2 className="mt-4 font-display text-3xl font-semibold text-white">{service.title}</h2>
                <p className="mt-4 text-sm leading-relaxed text-slate-300">{service.description}</p>
                <ul className="mt-6 space-y-3 text-sm text-slate-200">
                  {service.inclusions.map((item) => (
                    <li key={item} className="flex items-start space-x-3">
                      <svg className="mt-1 h-4 w-4 text-accent" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <p className="mt-6 text-xs uppercase tracking-[0.3em] text-slate-500">
                  Engagement length: {service.duration}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <section className="mt-16 rounded-3xl border border-slate-800/70 bg-slate-900/60 p-10">
          <h2 className="font-display text-2xl font-semibold text-white">Collaboration rhythm</h2>
          <div className="mt-6 grid gap-8 md:grid-cols-3">
            {collaborationRhythm.map((item) => (
              <div key={item.title} className="rounded-2xl border border-slate-800/70 bg-slate-900/70 p-6">
                <h3 className="font-display text-xl font-semibold text-white">{item.title}</h3>
                <p className="mt-4 text-sm text-slate-300">{item.description}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-16 rounded-3xl border border-accent/30 bg-slate-900/70 p-10 text-center shadow-glow">
          <h2 className="font-display text-3xl font-semibold text-white">Ready to begin?</h2>
          <p className="mt-4 text-lg text-slate-300">
            Tell us about your workflows, systems, and the stories you want to publish. We will schedule a discovery
            conversation with the DevLayer editorial team.
          </p>
          <a href="/contact" className="btn-primary mt-6 inline-flex">
            Start a conversation
          </a>
        </section>
      </section>
    </>
  );
};

const servicePackages = [
  {
    type: "Discovery",
    title: "Workflow Mapping Studio",
    description:
      "Short, intensive engagements that surface developer friction, alignment gaps, and narrative opportunities across your toolchain.",
    inclusions: [
      "Context interviews with engineers, product, and design voices",
      "Shadowing of key rituals like standups, incident reviews, and planning sessions",
      "Experience report summarising insights, anti-patterns, and potential storylines"
    ],
    duration: "2–4 weeks"
  },
  {
    type: "Immersive",
    title: "Platform Playbook Lab",
    description:
      "A collaborative residency where we co-design platform roadmaps, playbooks, and stakeholder narratives grounded in research.",
    inclusions: [
      "Co-facilitated workshops synthesising existing artefacts and metrics",
      "Playbook drafts with diagrams, dashboard guidance, and communication plans",
      "Capability scorecard with short, medium, and long-term recommendations"
    ],
    duration: "6–8 weeks"
  },
  {
    type: "Publication",
    title: "Editorial Residency",
    description:
      "Partner with DevLayer editors to write essays, case studies, or documentary-style pieces highlighting your engineering practice.",
    inclusions: [
      "Story architecture sessions to define arc, audience, and evidence sources",
      "Full editorial support including drafting, revision, and narrative design",
      "Publication plan including visual assets, landing pages, and promotion strategy"
    ],
    duration: "8–12 weeks"
  },
  {
    type: "Research",
    title: "Cloud Patterns Observatory",
    description:
      "Longitudinal research measuring how your cloud infrastructure evolves, focusing on reliability, governance, and developer experience.",
    inclusions: [
      "Telemetry analysis aligned with qualitative interviews",
      "Quarterly briefs tracking signals, risks, and emerging opportunities",
      "Executive summary distilling findings for leadership alignment"
    ],
    duration: "Quarterly"
  }
];

const collaborationRhythm = [
  {
    title: "Listening",
    description: "We begin by understanding existing narratives, gathering artefacts, and building trust with contributors."
  },
  {
    title: "Co-creation",
    description: "Editors, researchers, and your core team work together to map signals and iterate on insight."
  },
  {
    title: "Publication",
    description: "Deliverables are crafted with clarity, reviewed for accuracy, and published with your approval."
  }
];

export default Services;