// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const Workflows = () => (
  <>
    <Helmet>
      <title>Workflow Library | DevLayer</title>
      <meta
        name="description"
        content="Explore DevLayer’s workflow library covering CI/CD, build pipelines, IDE ergonomics, and team rituals."
      />
    </Helmet>

    <section className="mx-auto max-w-5xl px-4 pb-20 pt-10 sm:px-6 lg:px-8">
      <h1 className="font-display text-4xl font-semibold text-white">Workflow Library</h1>
      <p className="mt-4 text-lg text-slate-300">
        A growing collection of workflow patterns, playbooks, and diagnostic tools distilled from DevLayer fieldwork.
      </p>

      <div className="mt-12 space-y-10">
        {workflowTopics.map((topic) => (
          <article key={topic.title} className="rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8 shadow-card">
            <h2 className="font-display text-2xl font-semibold text-white">{topic.title}</h2>
            <p className="mt-3 text-sm text-slate-300">{topic.summary}</p>
            <ul className="mt-6 space-y-3 text-sm text-slate-300">
              {topic.points.map((point) => (
                <li key={point} className="flex items-start space-x-3">
                  <span className="mt-1 h-2 w-2 rounded-full bg-accent/70" />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </section>
  </>
);

const workflowTopics = [
  {
    title: "CI/CD",
    summary:
      "Guides for context-aware gating, progressive delivery, and bridging automated pipelines with human decision points.",
    points: [
      "Adaptive pipeline stages that respond to risk profiles and service maturity.",
      "Playbooks for aligning release cadences with product and support expectations.",
      "Metrics dashboards that highlight flow efficiency without fuelling burnout."
    ]
  },
  {
    title: "Build pipelines",
    summary: "Instrumented build systems that surface clarity, resilience, and developer experience signals.",
    points: [
      "Techniques for rebuilding confidence in slow or flaky pipelines with targeted instrumentation.",
      "Strategies for pairing build results with narrative summaries engineers can act upon.",
      "Blueprints for developer portals exposing build insights without overwhelming teams."
    ]
  },
  {
    title: "IDE ergonomics",
    summary:
      "Research-backed practices for shaping local developer environments that reinforce consistent, humane workflows.",
    points: [
      "Shared configuration baselines maintained like code, with change logs and onboarding guides.",
      "Focus modes that modulate notifications, linting noise, and formatting triggers.",
      "Knowledge sharing systems capturing IDE tips, keyboard choreography, and plugin evaluations."
    ]
  },
  {
    title: "Team rituals",
    summary:
      "Retrospectives, planning sessions, and asynchronous updates designed through the lens of cognitive load and inclusion.",
    points: [
      "Retrospective frameworks tuned for remote-first teams with narrative prompts.",
      "Planning cadences that respect discovery work, engineering spikes, and rest cycles.",
      "Communication contracts establishing expectations for feedback windows and documentation."
    ]
  }
];

export default Workflows;