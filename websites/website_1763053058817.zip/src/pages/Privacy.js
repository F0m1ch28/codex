// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | DevLayer</title>
      <meta
        name="description"
        content="Read how DevLayer handles cookies, analytics, data processing, third-party services, and user rights."
      />
    </Helmet>

    <section className="mx-auto max-w-4xl px-4 pb-20 pt-10 sm:px-6 lg:px-8">
      <h1 className="font-display text-4xl font-semibold text-white">Privacy Policy</h1>
      <p className="mt-4 text-sm text-slate-400">Effective January 2024</p>

      <article className="prose prose-invert mt-8">
        <h2>Overview</h2>
        <p>
          DevLayer respects your privacy. This policy explains how we collect, use, and safeguard information
          in connection with the DevLayer editorial platform (“Platform”).
        </p>

        <h2>Cookies</h2>
        <p>
          We use essential cookies to enable site functionality and preference cookies to remember choices such
          as language. Analytics cookies help us understand aggregate browsing patterns. You can manage cookies
          via your browser settings.
        </p>

        <h2>Analytics</h2>
        <p>
          We employ privacy-conscious analytics tools to measure page views, engagement, and navigation flows.
          Data is collected in aggregate form without personally identifying information.
        </p>

        <h2>Data processing</h2>
        <p>
          Contact form submissions include your name, email, organisation, and message. This information is used
          solely to respond to your inquiry and is stored securely. You may request deletion by emailing our team.
        </p>

        <h2>Third-party services</h2>
        <p>
          We may use third-party service providers for infrastructure hosting, email delivery, and analytics.
          Each provider is vetted to ensure compliance with Canadian privacy legislation and industry standards.
        </p>

        <h2>User rights</h2>
        <p>
          You can request access to personal data we hold, ask for corrections, or request deletion. To exercise
          these rights, contact us using the details on the Contact page.
        </p>

        <h2>Policy updates</h2>
        <p>
          We may update this policy periodically. Significant changes will be announced on this page with a revised
          effective date.
        </p>
      </article>
    </section>
  </>
);

export default Privacy;