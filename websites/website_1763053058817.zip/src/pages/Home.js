// @ts-check
import React, { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Helmet } from "react-helmet-async";
import { Link, useLocation, useNavigate } from "react-router-dom";

const heroImage = "https://picsum.photos/1600/900?random=1";
const contextImage = "https://picsum.photos/800/600?random=2";

const Home = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [projectFilter, setProjectFilter] = useState("All");
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [newsletterStatus, setNewsletterStatus] = useState("idle");
  const [openFaq, setOpenFaq] = useState(0);

  useEffect(() => {
    if (location.state && location.state.scrollTo) {
      const target = location.state.scrollTo;
      const element = document.getElementById(target);
      if (element) {
        window.requestAnimationFrame(() => {
          element.scrollIntoView({ behavior: "smooth", block: "start" });
        });
      }
      navigate(location.pathname, { replace: true, state: null });
    }
  }, [location, navigate]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => window.clearInterval(timer);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === "All") return projects;
    return projects.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const email = new FormData(form).get("email");
    if (!email || typeof email !== "string" || !email.includes("@")) {
      setNewsletterStatus("error");
      return;
    }
    setNewsletterStatus("submitted");
    form.reset();
  };

  return (
    <>
      <Helmet>
        <title>DevLayer | Editorial Platform for Developer Workflows</title>
        <meta
          name="description"
          content="DevLayer maps developer workflows, software systems, and cloud infrastructure narratives through essays, research, and editorial programs."
        />
        <script type="application/ld+json">{JSON.stringify(organizationSchema)}</script>
      </Helmet>

      <div className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 bg-grid-overlay opacity-70" aria-hidden="true" />
        <HeroSection />
        <StatsSection />
        <WhatWeExplore />
        <FeaturedEssays />
        <WorkflowPatterns />
        <ToolingSignals />
        <DeveloperMindset />
        <CodeHistory />
        <EditorialHighlights />
        <ReadingQueueSection />
        <ServicesSection />
        <ProcessSection />
        <TestimonialsSection currentTestimonial={currentTestimonial} />
        <TeamSection />
        <ProjectsSection
          projectFilter={projectFilter}
          setProjectFilter={setProjectFilter}
          filteredProjects={filteredProjects}
        />
        <FAQSection openFaq={openFaq} setOpenFaq={setOpenFaq} />
        <BlogPreview />
        <NewsletterCTA status={newsletterStatus} handleSubmit={handleNewsletterSubmit} />
        <DisclaimerSection />
      </div>
    </>
  );
};

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "DevLayer",
  url: "https://www.devlayer.ca",
  description:
    "DevLayer documents developer workflows, software systems, and cloud infrastructure stories for the engineering community.",
  logo: "https://www.devlayer.ca/logo.png",
  address: {
    "@type": "PostalAddress",
    streetAddress: "333 Bay St",
    addressLocality: "Toronto",
    addressRegion: "ON",
    postalCode: "M5H 2R2",
    addressCountry: "Canada"
  },
  contactPoint: {
    "@type": "ContactPoint",
    telephone: "+1-416-905-6621",
    contactType: "Editorial",
    areaServed: "CA",
    availableLanguage: ["English"]
  },
  sameAs: [
    "https://github.com/devlayer",
    "https://www.linkedin.com/company/devlayer"
  ]
};

const stats = [
  { label: "Editorial cycles analyzed", value: 128 },
  { label: "Systems blueprints published", value: 64 },
  { label: "Cloud patterns benchmarked", value: 42 },
  { label: "Workflow interviews completed", value: 86 }
];

const exploreAreas = [
  {
    title: "Systems",
    description: "Architectural forensics of distributed platforms, integration patterns, and runtime behaviours.",
    color: "from-accent/20 via-accent/10 to-transparent"
  },
  {
    title: "Workflows",
    description: "Real-world developer journeys through CI/CD, deployment ergonomics, and collaborative rituals.",
    color: "from-indigo-500/20 via-indigo-400/10 to-transparent"
  },
  {
    title: "Cognition",
    description: "Engineering psychology, focus mechanics, and sense-making tools that sustain complex problem solving.",
    color: "from-sky-500/20 via-sky-400/10 to-transparent"
  }
];

const featuredEssays = [
  {
    title: "Workflow Gravity in Distributed Teams",
    excerpt: "Designing rituals that align shipping velocity with cognitive resilience.",
    link: "/blog/why-context-switching-kills-productivity"
  },
  {
    title: "Cartography for Cloud Platforms",
    excerpt: "Narratives from Canadian platform engineers navigating rapid scale in regulated environments.",
    link: "/blog/cloud-patterns-for-scale"
  },
  {
    title: "Signals from DevOps Culture",
    excerpt: "A retrospective on practice, posture, and patterns that still matter for multi-cloud program design.",
    link: "/blog/the-evolution-of-devops-culture"
  }
];

const workflowPatterns = [
  {
    title: "Context-aware CI/CD",
    points: [
      "Gate adaptors that respect domain context before promoting builds.",
      "Progressive profiling of pipeline telemetry for feedback loops.",
      "Service handoffs that honour human constraints in on-call rotation."
    ]
  },
  {
    title: "IDE Ergonomics Blueprint",
    points: [
      "Layered linting with psychological pacing to prevent alert fatigue.",
      "Pairing heuristics for remote sessions grounded in cognitive load.",
      "Tactile shortcuts anchored in team rituals, not only personal taste."
    ]
  },
  {
    title: "Team Ritual Chronicles",
    points: [
      "Asynchronous standups shaped by narrative instead of metrics alone.",
      "Steady-state runbooks co-authored with design and product voices.",
      "Retro formats tuned to energy, not just agenda completeness."
    ]
  }
];

const toolingSignals = [
  {
    title: "Observability Patterns",
    description:
      "From high-fidelity traces to human-readable summaries, we decode signals that help teams steward complex systems.",
    indicators: ["Slow-burn incidents", "Runtime empathy", "Time-to-diagnose"]
  },
  {
    title: "Developer Experience Benchmarks",
    description:
      "An evidence-based look at CLI affordances, developer portals, and automation that accelerates flow while reducing toil.",
    indicators: ["CLI noise ratio", "Portal discoverability", "Automation trust"]
  },
  {
    title: "Platform Stewardship",
    description:
      "How platform engineering teams balance product thinking, roadmaps, and stakeholder storytelling across cloud estates.",
    indicators: ["Service maturity arcs", "Stakeholder coverage", "Lifecycle alignment"]
  }
];

const developerMindset = [
  {
    title: "Cognitive Field Notes",
    text: "Dispatches from developers actively untangling complexity, including rituals for handling ambiguity."
  },
  {
    title: "Burnout Early Warnings",
    text: "Pacing cues, energy audits, and rest architecture that help teams sustain demanding build seasons."
  },
  {
    title: "Communication Patterns",
    text: "Frameworks for writing, speaking, and diagramming so ideas carry across disciplines and timezones."
  }
];

const codeHistory = [
  {
    period: "1970s–1980s",
    insight: "Tracing the origins of RFC culture and the birth of collaborative specification writing."
  },
  {
    period: "1990s–2000s",
    insight: "From dial-up deployments to modern staging: lessons from legacy change management."
  },
  {
    period: "2010s–Now",
    insight: "Platform engineering ascendant—combining product craft, automation, and behavioural research."
  }
];

const editorialHighlights = [
  {
    title: "Platform Field Labs",
    description: "Embedded research with Canadian engineers implementing playbooks for zero-downtime migrations."
  },
  {
    title: "Workflow Listening Sessions",
    description: "Monthly interviews capturing narrative data points from SREs, staff engineers, and DX leads."
  },
  {
    title: "Cloud Morphology Index",
    description: "A longitudinal study benchmarking service maturity against organisational pacing signals."
  }
];

const readingQueue = [
  {
    title: "Cognition Under Load",
    author: "DevLayer Editors",
    tags: ["focus", "ritual design"]
  },
  {
    title: "Practical Platform Storytelling",
    author: "Guest Contributor: Maya O.",
    tags: ["platform engineering", "stakeholder narratives"]
  },
  {
    title: "Runtime Sensemaking",
    author: "DevLayer Research",
    tags: ["observability", "incident review"]
  },
  {
    title: "Living Documentation Patterns",
    author: "Guest Contributor: Leon C.",
    tags: ["knowledge systems", "team learning"]
  }
];

const services = [
  {
    title: "Workflow Mapping Studio",
    description:
      "Collaborative research sprints that surface friction points, narrative arcs, and improvement hypotheses.",
    features: ["Contextual interviews", "Flow instrumentation", "Experience reports"]
  },
  {
    title: "Platform Playbook Lab",
    description:
      "Scenario-based facilitation to align platform initiatives with developer experience metrics and ethics.",
    features: ["Pattern catalogues", "Stakeholder dialogues", "Roadmap synthesis"]
  },
  {
    title: "Editorial Residency",
    description:
      "Partner with DevLayer editors to craft publishable essays capturing systems insight and cultural nuance.",
    features: ["Story architecture", "Evidence review", "Publication coaching"]
  }
];

const processSteps = [
  {
    title: "Signal Capture",
    description: "Ethnographic interviews, telemetry reviews, and artifact audits to build situational awareness."
  },
  {
    title: "Pattern Mapping",
    description: "Synthesis workshops align team language, highlight recurring system moves, and surface leverage points."
  },
  {
    title: "Narrative Publication",
    description: "Final essays, playbooks, and visualisations broadcast insight to teams, stakeholders, and leadership."
  }
];

const testimonials = [
  {
    quote:
      "DevLayer captured how our platform team actually works. The editorial framing helped leadership fund sequencing without diluting nuance.",
    name: "Jasmit Dhillon",
    role: "Director of Platform Engineering, Toronto"
  },
  {
    quote:
      "Their workflow interviews uncovered hidden rituals keeping our release train healthy. We now treat those rituals like system dependencies.",
    name: "Aveline Brooks",
    role: "Staff Software Engineer, Vancouver"
  },
  {
    quote:
      "The mix of cognitive research and systems thinking changed how we approach retrospectives. DevLayer gave us a new vocabulary.",
    name: "Jordan Hill",
    role: "Engineering Manager, Montreal"
  }
];

const teamMembers = [
  {
    name: "Noor Tanaka",
    role: "Editor-in-Chief",
    focus: "Platform narratives and developer anthropology.",
    image: "https://picsum.photos/400/400?random=3"
  },
  {
    name: "Marcel Roy",
    role: "Principal Researcher",
    focus: "Infrastructure ethnography and observability practices.",
    image: "https://picsum.photos/400/400?random=5"
  },
  {
    name: "Iris Almeida",
    role: "Design Strategist",
    focus: "Information architecture, diagrams, and story craft.",
    image: "https://picsum.photos/400/400?random=7"
  }
];

const projectFilters = ["All", "Platform Research", "Workflow Studies", "Cultural Notes"];

const projects = [
  {
    title: "Capacity Planning Atlas",
    category: "Platform Research",
    description: "A layered atlas mapping microservice evolution with business cadence for a national fintech team.",
    image: "https://picsum.photos/1200/800?random=4"
  },
  {
    title: "Focus Ritual Inventory",
    category: "Workflow Studies",
    description: "Qualitative research documenting 200+ developer focus rituals across Canadian remote teams.",
    image: "https://picsum.photos/1200/800?random=8"
  },
  {
    title: "Incident Storywork Series",
    category: "Cultural Notes",
    description: "Narrative analysis of incident reviews and the language teams use to describe reliability posture.",
    image: "https://picsum.photos/1200/800?random=9"
  }
];

const faqItems = [
  {
    question: "Who contributes to DevLayer essays?",
    answer:
      "Engineers, product partners, designers, and DevLayer editors. Every piece is co-created with practitioners to preserve fidelity."
  },
  {
    question: "How do you select topics?",
    answer:
      "We track signals from interviews, workshop data, and archival research. Topics are chosen where workflows, systems, and cognition intersect."
  },
  {
    question: "Can organisations participate in field labs?",
    answer:
      "Yes. We collaborate with engineering groups across Canada. Each engagement begins with discovery conversations to confirm editorial fit."
  },
  {
    question: "What languages do you publish in?",
    answer:
      "DevLayer currently publishes in English while amplifying Canadian perspectives across regions and sectors."
  }
];

const blogPreview = [
  {
    title: "Maintaining Living Documentation in High-Change Environments",
    link: "/blog/why-context-switching-kills-productivity",
    date: "January 12, 2024"
  },
  {
    title: "Platform Engineering as Narrative Infrastructure",
    link: "/blog/the-evolution-of-devops-culture",
    date: "December 30, 2023"
  },
  {
    title: "Cloud Patterns That Respect Team Rhythms",
    link: "/blog/cloud-patterns-for-scale",
    date: "December 2, 2023"
  }
];

const HeroSection = () => {
  return (
    <section id="hero" className="relative overflow-hidden pt-24 md:pt-32">
      <div className="mx-auto flex max-w-7xl flex-col-reverse gap-12 px-4 pb-20 sm:px-6 lg:flex-row lg:items-center lg:px-8">
        <motion.div
          className="max-w-3xl"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: "easeOut" }}
        >
          <span className="inline-flex items-center rounded-full border border-slate-700 bg-slate-900/70 px-4 py-2 text-xs font-semibold uppercase tracking-[0.3em] text-slate-300">
            Every Layer Tells a Story
          </span>
          <h1 className="mt-6 font-display text-4xl font-semibold leading-tight text-white sm:text-5xl lg:text-6xl">
            Editorial intelligence for developer workflows, software systems, and cloud infrastructure.
          </h1>
          <p className="mt-6 text-lg leading-relaxed text-slate-300 md:text-xl">
            DevLayer is a Canadian platform documenting how engineers navigate complexity. We publish essays,
            maps, and playbooks that help teams steward resilient systems while protecting human focus.
          </p>
          <div className="mt-8 flex flex-col gap-4 sm:flex-row">
            <Link to="/services" className="btn-primary w-full sm:w-auto">
              Explore Programs
            </Link>
            <a href="#insights" className="btn-secondary w-full sm:w-auto">
              Browse Insights
            </a>
          </div>
          <dl className="mt-10 grid grid-cols-2 gap-6 text-left text-sm text-slate-400 sm:flex sm:space-x-10">
            <div>
              <dt className="text-slate-500">Founded</dt>
              <dd className="font-medium text-slate-100">Toronto, 2019</dd>
            </div>
            <div>
              <dt className="text-slate-500">Focus</dt>
              <dd className="font-medium text-slate-100">Systems, Workflows, Cognition</dd>
            </div>
          </dl>
        </motion.div>

        <motion.div
          className="relative w-full overflow-hidden rounded-3xl border border-slate-800/60 bg-slate-900/50 shadow-glow"
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <ImageWithLoader src={heroImage} alt="Developers collaborating in a modern workspace" />
          <div className="absolute inset-0 bg-gradient-to-tr from-slate-900/60 via-slate-900/20 to-transparent" />
          <div className="absolute bottom-4 left-4 rounded-xl bg-slate-900/70 p-4 text-sm text-slate-300 backdrop-blur">
            Field notes from Canadian engineers shipping platform scale stories.
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const StatsSection = () => {
  return (
    <section className="relative">
      <div className="mx-auto -mt-10 max-w-6xl rounded-3xl border border-slate-800/70 bg-slate-900/60 px-6 py-12 shadow-card sm:px-10 lg:px-16">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label} className="space-y-3">
              <StatCounter target={stat.value} />
              <p className="text-sm uppercase tracking-wide text-slate-400">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const WhatWeExplore = () => (
  <section id="insights" className="mx-auto mt-20 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
      <div className="max-w-2xl">
        <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
          What we explore
        </h2>
        <p className="mt-4 text-lg text-slate-300">
          Our editorial radar spans platform engineering, developer experience, and engineering psychology.
          We publish artefacts that help teams build context maps, not just dashboards.
        </p>
      </div>
    </div>
    <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
      {exploreAreas.map((area) => (
        <motion.div
          key={area.title}
          className="group relative overflow-hidden rounded-3xl border border-slate-800/80 bg-slate-900/60 p-8 shadow-card"
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.7 }}
        >
          <div className={`absolute inset-0 bg-gradient-to-br ${area.color} opacity-60 transition group-hover:opacity-90`} />
          <div className="relative">
            <h3 className="font-display text-2xl font-semibold text-white">{area.title}</h3>
            <p className="mt-4 text-sm leading-relaxed text-slate-300">{area.description}</p>
          </div>
        </motion.div>
      ))}
    </div>
  </section>
);

const FeaturedEssays = () => (
  <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
          Featured essays
        </h2>
        <p className="mt-4 text-lg text-slate-300">
          Essays capturing the choreography of systems and the humans guiding them. Each piece blends
          technical detail with narrative context.
        </p>
      </div>
      <Link to="/blog" className="btn-secondary self-start">
        View all essays
      </Link>
    </div>
    <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {featuredEssays.map((essay) => (
        <motion.div
          key={essay.title}
          className="card-surface h-full"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true, amount: 0.3 }}
        >
          <h3 className="font-display text-xl font-semibold text-white">{essay.title}</h3>
          <p className="mt-3 text-sm text-slate-300">{essay.excerpt}</p>
          <Link
            to={essay.link}
            className="mt-6 inline-flex items-center text-sm font-semibold text-accent"
          >
            Read essay
            <svg className="ml-2 h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 12h14m-7-7l7 7-7 7" />
            </svg>
          </Link>
        </motion.div>
      ))}
    </div>
  </section>
);

const WorkflowPatterns = () => (
  <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="grid gap-10 lg:grid-cols-3">
      {workflowPatterns.map((pattern) => (
        <motion.div
          key={pattern.title}
          className="relative overflow-hidden rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8 shadow-card"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
        >
          <h3 className="font-display text-2xl font-semibold text-white">{pattern.title}</h3>
          <ul className="mt-6 space-y-4 text-sm leading-relaxed text-slate-300">
            {pattern.points.map((point) => (
              <li key={point} className="flex space-x-3">
                <span className="mt-1 h-2.5 w-2.5 rounded-full bg-accent/70" />
                <span>{point}</span>
              </li>
            ))}
          </ul>
        </motion.div>
      ))}
    </div>
  </section>
);

const ToolingSignals = () => (
  <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="rounded-3xl border border-slate-800/60 bg-slate-900/50 p-8 shadow-card md:p-12">
      <div className="grid gap-8 md:grid-cols-3">
        {toolingSignals.map((signal) => (
          <motion.div
            key={signal.title}
            className="rounded-2xl border border-slate-800/70 bg-slate-900/70 p-6"
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="font-display text-xl font-semibold text-white">{signal.title}</h3>
            <p className="mt-4 text-sm text-slate-300">{signal.description}</p>
            <div className="mt-6">
              <span className="text-xs uppercase tracking-widest text-slate-500">
                Indicators
              </span>
              <ul className="mt-3 space-y-2 text-sm text-slate-300">
                {signal.indicators.map((indicator) => (
                  <li key={indicator} className="flex items-center space-x-2">
                    <span className="h-1.5 w-6 rounded-full bg-accent/60" />
                    <span>{indicator}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const DeveloperMindset = () => (
  <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="grid gap-8 lg:grid-cols-2">
      <div>
        <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
          Developer mindset field notes
        </h2>
        <p className="mt-4 text-lg text-slate-300">
          We study how developers think, rest, and communicate. Insights are distilled into essays,
          workshops, and tools designed to protect depth of focus.
        </p>
        <div className="mt-8 overflow-hidden rounded-3xl border border-slate-800/70 bg-slate-900/60">
          <ImageWithLoader src={contextImage} alt="Developer working within a thoughtful environment" />
        </div>
      </div>
      <div className="space-y-8">
        {developerMindset.map((item) => (
          <motion.div
            key={item.title}
            className="rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8 shadow-card"
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h3 className="font-display text-2xl font-semibold text-white">{item.title}</h3>
            <p className="mt-4 text-sm leading-relaxed text-slate-300">{item.text}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const CodeHistory = () => (
  <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="rounded-3xl border border-slate-800/60 bg-slate-900/50 p-8 md:p-12">
      <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
        Code history timelines
      </h2>
      <p className="mt-4 max-w-2xl text-lg text-slate-300">
        We trace the lineages of computer science decisions that echo through current infrastructures and
        workflows, connecting archival artifacts to modern practice.
      </p>
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {codeHistory.map((item) => (
          <div key={item.period} className="rounded-2xl border border-slate-800/70 bg-slate-900/70 p-6">
            <span className="text-xs uppercase tracking-widest text-slate-500">
              {item.period}
            </span>
            <p className="mt-4 text-sm leading-relaxed text-slate-300">{item.insight}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const EditorialHighlights = () => (
  <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="grid gap-8 lg:grid-cols-3">
      {editorialHighlights.map((highlight) => (
        <motion.div
          key={highlight.title}
          className="card-surface"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h3 className="font-display text-2xl font-semibold text-white">{highlight.title}</h3>
          <p className="mt-4 text-sm leading-relaxed text-slate-300">{highlight.description}</p>
        </motion.div>
      ))}
    </div>
  </section>
);

const ReadingQueueSection = () => (
  <section id="reading-queue" className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="rounded-3xl border border-slate-800/60 bg-slate-900/60 p-8 md:p-12">
      <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
            Reading queue
          </h2>
          <p className="mt-4 text-lg text-slate-300">
            Curated essays, papers, and field reports we are currently sharing with technologists across Canada.
          </p>
        </div>
        <Link to="/queue" className="btn-secondary self-start">
          View full queue
        </Link>
      </div>
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        {readingQueue.map((item) => (
          <motion.div
            key={item.title}
            className="rounded-2xl border border-slate-800/70 bg-slate-900/70 p-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h3 className="font-display text-xl font-semibold text-white">{item.title}</h3>
            <p className="mt-2 text-sm text-slate-400">By {item.author}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {item.tags.map((tag) => (
                <span
                  key={tag}
                  className="rounded-full border border-accent/40 px-3 py-1 text-xs font-semibold text-accent"
                >
                  {tag}
                </span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ServicesSection = () => (
  <section id="services" className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
          Platform services
        </h2>
        <p className="mt-4 text-lg text-slate-300">
          DevLayer programs help teams map complexity, align stakeholders, and publish actionable insight.
        </p>
      </div>
      <Link to="/services" className="btn-primary self-start">
        All services
      </Link>
    </div>
    <div className="mt-10 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
      {services.map((service) => (
        <motion.div
          key={service.title}
          className="card-surface"
          whileHover={{ y: -8, borderColor: "rgba(59, 130, 246, 0.7)" }}
          transition={{ type: "spring", stiffness: 220, damping: 20 }}
        >
          <h3 className="font-display text-2xl font-semibold text-white">{service.title}</h3>
          <p className="mt-4 text-sm text-slate-300">{service.description}</p>
          <ul className="mt-6 space-y-3 text-sm text-slate-300">
            {service.features.map((feature) => (
              <li key={feature} className="flex items-center space-x-2">
                <span className="h-2 w-2 rounded-full bg-accent/70" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </motion.div>
      ))}
    </div>
  </section>
);

const ProcessSection = () => (
  <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="rounded-3xl border border-slate-800/60 bg-slate-900/60 p-8 md:p-12">
      <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
        Editorial process
      </h2>
      <p className="mt-4 max-w-3xl text-lg text-slate-300">
        Every engagement follows a structured yet adaptive editorial workflow anchored in research ethics and
        collaborative craft.
      </p>
      <div className="mt-10 grid gap-8 md:grid-cols-3">
        {processSteps.map((step, index) => (
          <div key={step.title} className="relative rounded-2xl border border-slate-800/70 bg-slate-900/70 p-6">
            <span className="absolute -top-5 left-6 flex h-10 w-10 items-center justify-center rounded-full bg-accent text-base font-bold text-white shadow-glow">
              {index + 1}
            </span>
            <h3 className="mt-6 font-display text-xl font-semibold text-white">{step.title}</h3>
            <p className="mt-4 text-sm leading-relaxed text-slate-300">{step.description}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const TestimonialsSection = ({ currentTestimonial }) => (
  <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="rounded-3xl border border-slate-800/60 bg-slate-900/50 p-8 md:p-12">
      <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
            Voices from the field
          </h2>
          <p className="mt-4 text-lg text-slate-300">
            Teams across Canada share how DevLayer helped them see their systems, workflows, and culture with new clarity.
          </p>
        </div>
      </div>
      <div className="mt-10 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentTestimonial}
            initial={{ opacity: 0, x: 60 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -60 }}
            transition={{ duration: 0.6 }}
            className="rounded-3xl border border-slate-800/70 bg-slate-900/70 p-8"
          >
            <blockquote className="text-lg leading-relaxed text-slate-200">
              “{testimonials[currentTestimonial].quote}”
            </blockquote>
            <div className="mt-6 text-sm font-semibold text-accent">
              {testimonials[currentTestimonial].name}
            </div>
            <div className="text-xs uppercase tracking-widest text-slate-500">
              {testimonials[currentTestimonial].role}
            </div>
          </motion.div>
        </AnimatePresence>
        <div className="mt-6 flex space-x-2">
          {testimonials.map((_, index) => (
            <span
              key={index}
              className={`h-2.5 w-8 rounded-full transition ${
                index === currentTestimonial ? "bg-accent" : "bg-slate-700"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  </section>
);

const TeamSection = () => (
  <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
          Editorial team
        </h2>
        <p className="mt-4 text-lg text-slate-300">
          A multidisciplinary group blending software engineering, research, and narrative craft.
        </p>
      </div>
      <Link to="/about" className="btn-secondary self-start">
        Meet the team
      </Link>
    </div>
    <div className="mt-10 grid gap-8 md:grid-cols-3">
      {teamMembers.map((member) => (
        <motion.div
          key={member.name}
          className="group overflow-hidden rounded-3xl border border-slate-800/70 bg-slate-900/60 shadow-card"
          whileHover={{ y: -8 }}
        >
          <div className="relative">
            <ImageWithLoader src={member.image} alt={`${member.name} portrait`} />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-80 transition group-hover:opacity-100" />
          </div>
          <div className="p-6">
            <h3 className="font-display text-xl font-semibold text-white">{member.name}</h3>
            <p className="text-sm uppercase tracking-widest text-accent">{member.role}</p>
            <p className="mt-4 text-sm text-slate-300">{member.focus}</p>
          </div>
        </motion.div>
      ))}
    </div>
  </section>
);

const ProjectsSection = ({ projectFilter, setProjectFilter, filteredProjects }) => (
  <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
          Projects and fieldwork
        </h2>
        <p className="mt-4 text-lg text-slate-300">
          Research, cartography, and editorial collaborations that illuminate the software stack as a living system.
        </p>
      </div>
      <div className="flex flex-wrap gap-3">
        {projectFilters.map((filter) => (
          <button
            key={filter}
            onClick={() => setProjectFilter(filter)}
            className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${
              projectFilter === filter
                ? "border-accent bg-accent text-white"
                : "border-slate-700 text-slate-300 hover:border-accent/60 hover:text-accent"
            }`}
          >
            {filter}
          </button>
        ))}
      </div>
    </div>
    <div className="mt-10 grid gap-8 md:grid-cols-2">
      {filteredProjects.map((project) => (
        <motion.div
          key={project.title}
          className="overflow-hidden rounded-3xl border border-slate-800/70 bg-slate-900/60 shadow-card"
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
        >
          <ImageWithLoader src={project.image} alt={`${project.title} project abstract visual`} />
          <div className="p-6">
            <span className="text-xs uppercase tracking-[0.3em] text-slate-500">
              {project.category}
            </span>
            <h3 className="mt-4 font-display text-2xl font-semibold text-white">{project.title}</h3>
            <p className="mt-4 text-sm text-slate-300">{project.description}</p>
          </div>
        </motion.div>
      ))}
    </div>
  </section>
);

const FAQSection = ({ openFaq, setOpenFaq }) => (
  <section className="mx-auto mt-24 max-w-4xl px-4 sm:px-6 lg:px-8">
    <div className="rounded-3xl border border-slate-800/60 bg-slate-900/60 p-8 md:p-12">
      <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
        Questions we hear often
      </h2>
      <div className="mt-10 space-y-4">
        {faqItems.map((faq, index) => {
          const isOpen = openFaq === index;
          return (
            <div key={faq.question} className="rounded-2xl border border-slate-800/70 bg-slate-900/70 p-6">
              <button
                onClick={() => setOpenFaq(isOpen ? -1 : index)}
                className="flex w-full items-center justify-between text-left"
              >
                <span className="font-display text-lg font-semibold text-white">{faq.question}</span>
                <svg
                  className={`h-5 w-5 transform transition ${isOpen ? "rotate-180 text-accent" : "text-slate-500"}`}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.p
                    className="mt-4 text-sm text-slate-300"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                  >
                    {faq.answer}
                  </motion.p>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </div>
  </section>
);

const BlogPreview = () => (
  <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="rounded-3xl border border-slate-800/60 bg-slate-900/60 p-8 md:p-12">
      <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
            Latest from the blog
          </h2>
          <p className="mt-4 text-lg text-slate-300">
            Essays and updates exploring developer workflows, platform engineering, and culture.
          </p>
        </div>
        <Link to="/blog" className="btn-secondary self-start">
          Visit blog
        </Link>
      </div>
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {blogPreview.map((post) => (
          <div key={post.title} className="rounded-2xl border border-slate-800/70 bg-slate-900/70 p-6">
            <span className="text-xs uppercase tracking-[0.3em] text-slate-500">{post.date}</span>
            <h3 className="mt-4 font-display text-xl font-semibold text-white">{post.title}</h3>
            <Link to={post.link} className="mt-4 inline-flex items-center text-sm font-semibold text-accent">
              Read update
              <svg className="ml-2 h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 12h14m-7-7l7 7-7 7" />
              </svg>
            </Link>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const NewsletterCTA = ({ status, handleSubmit }) => (
  <section id="newsletter" className="mx-auto mt-24 max-w-5xl px-4 sm:px-6 lg:px-8">
    <div className="rounded-3xl border border-accent/40 bg-slate-900/80 p-8 text-center shadow-glow md:p-12">
      <h2 className="font-display text-3xl font-semibold text-white sm:text-4xl">
        Join the DevLayer signal
      </h2>
      <p className="mt-4 text-lg text-slate-300">
        Monthly dispatches featuring workflow archetypes, platform insights, and engineering psychology research.
      </p>
      <form onSubmit={handleSubmit} className="mx-auto mt-8 flex flex-col gap-4 sm:max-w-2xl sm:flex-row sm:items-center">
        <input
          type="email"
          name="email"
          required
          placeholder="you@example.com"
          className="w-full rounded-full border border-slate-700 bg-slate-900 px-6 py-3 text-sm text-white placeholder-slate-500 focus:border-accent focus:outline-none"
        />
        <button type="submit" className="btn-primary w-full sm:w-auto">
          Subscribe
        </button>
      </form>
      {status === "submitted" && (
        <p className="mt-4 text-sm text-accent">
          Added to the queue. Watch for upcoming Editorial Signals from DevLayer.
        </p>
      )}
      {status === "error" && (
        <p className="mt-4 text-sm text-rose-400">
          Please provide a valid email address so we can send you the dispatch.
        </p>
      )}
      <p className="mt-6 text-xs text-slate-500">
        Emails respect our privacy policy. Unsubscribe anytime by responding to the dispatch.
      </p>
    </div>
  </section>
);

const DisclaimerSection = () => (
  <section className="mx-auto mt-16 max-w-4xl px-4 pb-20 text-center text-xs uppercase tracking-[0.3em] text-slate-500">
    DevLayer content is for educational use only.
  </section>
);

const StatCounter = ({ target }) => {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let current = 0;
    const duration = 1600;
    const frameRate = 24;
    const totalFrames = Math.round((duration / 1000) * frameRate);
    const increment = target / totalFrames;
    const interval = window.setInterval(() => {
      current += increment;
      if (current >= target) {
        current = target;
        window.clearInterval(interval);
      }
      setValue(Math.round(current));
    }, duration / totalFrames);
    return () => window.clearInterval(interval);
  }, [target]);

  return (
    <div className="text-3xl font-semibold text-white sm:text-4xl">
      {value}
    </div>
  );
};

const ImageWithLoader = ({ src, alt }) => {
  const [loaded, setLoaded] = useState(false);
  return (
    <div className="relative h-full w-full overflow-hidden">
      {!loaded && (
        <div className="absolute inset-0 animate-pulse bg-slate-800/70" aria-hidden="true" />
      )}
      <img
        src={src}
        alt={alt}
        onLoad={() => setLoaded(true)}
        className={`h-full w-full object-cover transition duration-700 ${loaded ? "opacity-100" : "opacity-0"}`}
      />
    </div>
  );
};

export default Home;