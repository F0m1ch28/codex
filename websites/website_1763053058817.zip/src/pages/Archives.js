// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const Archives = () => (
  <>
    <Helmet>
      <title>Archives &amp; Standards | DevLayer</title>
      <meta
        name="description"
        content="Browse DevLayer’s archive of historical computing resources, RFCs, legacy documentation, and open standards."
      />
    </Helmet>

    <section className="mx-auto max-w-5xl px-4 pb-20 pt-10 sm:px-6 lg:px-8">
      <h1 className="font-display text-4xl font-semibold text-white">Archives &amp; Standards</h1>
      <p className="mt-4 text-lg text-slate-300">
        A curated collection of historic documents, RFCs, and standards that continue to influence modern software systems.
      </p>

      <div className="mt-12 space-y-8">
        {archiveSections.map((section) => (
          <div key={section.title} className="rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8 shadow-card">
            <h2 className="font-display text-2xl font-semibold text-white">{section.title}</h2>
            <p className="mt-3 text-sm text-slate-300">{section.description}</p>
            <ul className="mt-6 space-y-3 text-sm text-accent">
              {section.links.map((link) => (
                <li key={link.title}>
                  <a href={link.url} target="_blank" rel="noreferrer">
                    {link.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  </>
);

const archiveSections = [
  {
    title: "Historic computing references",
    description: "Foundational documents that shaped networking, programming languages, and human-computer interaction.",
    links: [
      { title: "RFC 675 - Specification of Internet Transmission Control Program", url: "https://www.rfc-editor.org/rfc/rfc675" },
      { title: "The Xerox Alto User Guide", url: "http://bitsavers.org/pdf/xerox/alto/" }
    ]
  },
  {
    title: "Legacy documentation",
    description: "Manuals and guides from influential systems whose lessons remain relevant.",
    links: [
      { title: "The original Unix Programmer's Manual", url: "https://s3.amazonaws.com/plan9-bell-labs/doc/unix7th/unix7th.pdf" },
      { title: "Smalltalk-80: The Language and Its Implementation", url: "http://stephane.ducasse.free.fr/FreeBooks/BlueBook/Bluebook.pdf" }
    ]
  },
  {
    title: "Open standards",
    description: "Specifications that continue to guide interoperability, web architecture, and system design.",
    links: [
      { title: "HTML Living Standard", url: "https://html.spec.whatwg.org/multipage/" },
      { title: "OpenAPI Specification", url: "https://spec.openapis.org/oas/latest.html" }
    ]
  }
];

export default Archives;