// @ts-check
import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import { useNavigate } from "react-router-dom";

const Contact = () => {
  const navigate = useNavigate();
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle");

  const handleSubmit = (event) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const values = Object.fromEntries(formData.entries());
    const currentErrors = {};

    if (!values.name || values.name.trim().length < 2) {
      currentErrors.name = "Please share your full name.";
    }
    if (!values.email || typeof values.email !== "string" || !values.email.includes("@")) {
      currentErrors.email = "Provide a valid email so we can respond.";
    }
    if (!values.message || values.message.trim().length < 20) {
      currentErrors.message = "Tell us more about your workflows or editorial needs (minimum 20 characters).";
    }

    if (Object.keys(currentErrors).length > 0) {
      setErrors(currentErrors);
      setStatus("error");
      return;
    }

    setErrors({});
    setStatus("submitting");
    window.setTimeout(() => {
      navigate("/contact/thanks");
    }, 600);
  };

  return (
    <>
      <Helmet>
        <title>Contact DevLayer | Start an Editorial Conversation</title>
        <meta
          name="description"
          content="Connect with DevLayer to discuss editorial collaborations, workflow research, or platform storytelling needs."
        />
        <script type="application/ld+json">{JSON.stringify(contactSchema)}</script>
      </Helmet>

      <section className="mx-auto max-w-6xl px-4 pb-20 pt-10 sm:px-6 lg:px-8">
        <header className="text-center">
          <h1 className="font-display text-4xl font-semibold text-white sm:text-5xl">
            Let’s map your story together.
          </h1>
          <p className="mt-4 text-lg text-slate-300">
            Share your context, questions, and goals. A DevLayer editor will respond within two business days.
          </p>
        </header>

        <div className="mt-16 grid gap-10 lg:grid-cols-2">
          <section className="rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8 shadow-card">
            <h2 className="font-display text-2xl font-semibold text-white">Contact details</h2>
            <ul className="mt-6 space-y-4 text-sm text-slate-300">
              <li>
                <strong className="text-white">Address:</strong> 333 Bay St, Toronto, ON M5H 2R2, Canada
              </li>
              <li>
                <strong className="text-white">Phone:</strong>{" "}
                <a className="text-accent" href="tel:+14169056621">
                  +1 (416) 905-6621
                </a>
              </li>
              <li>
                <strong className="text-white">Email:</strong> routed via contact form until dedicated inbox is published.
              </li>
              <li>
                <strong className="text-white">GitHub:</strong>{" "}
                <a className="text-accent" href="https://github.com/devlayer" target="_blank" rel="noreferrer">
                  github.com/devlayer
                </a>
              </li>
              <li>
                <strong className="text-white">LinkedIn:</strong>{" "}
                <a className="text-accent" href="https://www.linkedin.com/company/devlayer" target="_blank" rel="noreferrer">
                  linkedin.com/company/devlayer
                </a>
              </li>
            </ul>

            <div className="mt-8 overflow-hidden rounded-2xl border border-slate-800">
              <iframe
                title="DevLayer Toronto Office"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2886.467928422094!2d-79.38087322324668!3d43.64874485397781!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d8f9da0fb7%3A0x7e5227b0b83a19b1!2s333%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202R2%2C%20Canada!5e0!3m2!1sen!2sca!4v1704849447853!5m2!1sen!2sca"
                width="100%"
                height="260"
                style={{ border: 0 }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>

            <p className="mt-6 text-xs text-slate-500">
              In-person meetings are by appointment only. Virtual sessions are available across Canada.
            </p>
          </section>

          <form
            onSubmit={handleSubmit}
            className="rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8 shadow-card"
          >
            <h2 className="font-display text-2xl font-semibold text-white">Send a message</h2>
            <div className="mt-6 grid gap-5">
              <div>
                <label className="block text-xs uppercase tracking-[0.3em] text-slate-500">
                  Name
                </label>
                <input
                  name="name"
                  type="text"
                  className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-3 text-sm text-white focus:border-accent focus:outline-none"
                  placeholder="Your full name"
                />
                {errors.name && <p className="mt-2 text-xs text-rose-400">{errors.name}</p>}
              </div>
              <div>
                <label className="block text-xs uppercase tracking-[0.3em] text-slate-500">
                  Email
                </label>
                <input
                  name="email"
                  type="email"
                  className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-3 text-sm text-white focus:border-accent focus:outline-none"
                  placeholder="your@organisation.com"
                />
                {errors.email && <p className="mt-2 text-xs text-rose-400">{errors.email}</p>}
              </div>
              <div>
                <label className="block text-xs uppercase tracking-[0.3em] text-slate-500">
                  Organisation
                </label>
                <input
                  name="company"
                  type="text"
                  className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-3 text-sm text-white focus:border-accent focus:outline-none"
                  placeholder="Company or team name"
                />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-[0.3em] text-slate-500">
                  How can we help?
                </label>
                <textarea
                  name="message"
                  rows={6}
                  className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950/70 px-4 py-3 text-sm text-white focus:border-accent focus:outline-none"
                  placeholder="Tell us about your workflows, systems, or editorial goals."
                />
                {errors.message && <p className="mt-2 text-xs text-rose-400">{errors.message}</p>}
              </div>
            </div>
            <button
              type="submit"
              className="btn-primary mt-6 w-full"
              disabled={status === "submitting"}
            >
              {status === "submitting" ? "Sending..." : "Send message"}
            </button>
            <p className="mt-4 text-xs text-slate-500">
              A confirmation message will be routed to the email you provide. We never share personal contact details.
            </p>
          </form>
        </div>
      </section>
    </>
  );
};

const contactSchema = {
  "@context": "https://schema.org",
  "@type": "ContactPage",
  name: "Contact DevLayer",
  description:
    "Reach DevLayer to discuss editorial collaborations focused on developer workflows, software systems, and cloud infrastructure.",
  publisher: {
    "@type": "Organization",
    name: "DevLayer",
    url: "https://www.devlayer.ca"
  }
};

export default Contact;