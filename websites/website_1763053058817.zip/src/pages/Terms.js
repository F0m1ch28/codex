// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Use | DevLayer</title>
      <meta
        name="description"
        content="Understand DevLayer’s terms of use, intellectual property guidelines, liability disclaimers, and jurisdiction."
      />
    </Helmet>

    <section className="mx-auto max-w-4xl px-4 pb-20 pt-10 sm:px-6 lg:px-8">
      <h1 className="font-display text-4xl font-semibold text-white">Terms of Use</h1>
      <p className="mt-4 text-sm text-slate-400">Effective January 2024</p>

      <article className="prose prose-invert mt-8">
        <h2>Acceptance of terms</h2>
        <p>
          By accessing the DevLayer platform, you agree to these Terms of Use. If you disagree, please discontinue
          use of the site.
        </p>

        <h2>Intellectual property</h2>
        <p>
          All content, including text, graphics, diagrams, and code examples, is owned by DevLayer or our contributors.
          You may reference content with attribution, but redistribution requires written consent.
        </p>

        <h2>Disclaimer</h2>
        <p>
          Content is provided for educational purposes only. DevLayer is not liable for decisions made based on
          information presented on the platform.
        </p>

        <h2>Jurisdiction</h2>
        <p>
          These Terms are governed by the laws of the Province of Ontario and the federal laws of Canada applicable therein.
        </p>

        <h2>Changes</h2>
        <p>
          We may update these Terms at any time. Revisions will be posted with an updated effective date.
        </p>
      </article>
    </section>
  </>
);

export default Terms;