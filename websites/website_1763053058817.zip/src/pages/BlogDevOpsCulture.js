// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";

const BlogDevOpsCulture = () => (
  <>
    <Helmet>
      <title>The Evolution of DevOps Culture | DevLayer</title>
      <meta
        name="description"
        content="DevLayer traces the evolution of DevOps culture, highlighting the behaviours and rituals sustaining platform success."
      />
      <script type="application/ld+json">{JSON.stringify(schema)}</script>
    </Helmet>

    <article className="mx-auto max-w-3xl px-4 pb-20 pt-10 sm:px-6 lg:px-8">
      <header className="mb-10">
        <Link to="/blog" className="text-sm text-accent">&larr; Back to blog overview</Link>
        <h1 className="mt-4 font-display text-4xl font-semibold text-white">
          The Evolution of DevOps Culture
        </h1>
        <p className="mt-3 text-sm uppercase tracking-[0.3em] text-slate-500">
          Culture · November 18, 2023 · 14 min read
        </p>
      </header>

      <div className="prose prose-invert">
        <p>
          DevOps began as a conversation between developers and operations professionals in Ghent, 2009. Since then, it has
          evolved into a cultural movement influencing tooling, hiring, and leadership philosophies.
        </p>
        <h2>From philosophy to practice</h2>
        <p>
          Early DevOps emphasised collaboration and empathy. Canadian teams adopted it to bridge siloed groups, initially
          through joint retrospectives and shared on-call rotations.
        </p>
        <h2>Platform engineering emerges</h2>
        <p>
          As cloud complexity grew, organisations formed platform engineering teams. These teams design shared services and
          developer experiences rooted in DevOps principles while adding product thinking.
        </p>
        <h2>Rituals that endure</h2>
        <ul>
          <li>Blameless post-incident reviews that focus on learning.</li>
          <li>Shadow programs where developers experience operations contexts firsthand.</li>
          <li>Documentation sprints to keep runbooks and playbooks living and collaborative.</li>
        </ul>
        <h2>A culture of stewardship</h2>
        <p>
          Modern DevOps culture is about stewardship. Teams hold shared responsibility for reliability, quality, and
          psychological safety. Rituals are constantly inspected, tuned, and reimagined as systems evolve.
        </p>
      </div>
    </article>
  </>
);

const schema = {
  "@context": "https://schema.org",
  "@type": "Article",
  headline: "The Evolution of DevOps Culture",
  description:
    "A DevLayer essay exploring how DevOps culture matured into platform engineering practices grounded in stewardship and collaboration.",
  author: { "@type": "Organization", name: "DevLayer Editorial Team" },
  publisher: {
    "@type": "Organization",
    name: "DevLayer",
    logo: { "@type": "ImageObject", url: "https://www.devlayer.ca/logo.png" }
  },
  datePublished: "2023-11-18",
  dateModified: "2023-11-18",
  image: "https://picsum.photos/1200/630?random=13",
  mainEntityOfPage: "https://www.devlayer.ca/blog/the-evolution-of-devops-culture"
};

export default BlogDevOpsCulture;