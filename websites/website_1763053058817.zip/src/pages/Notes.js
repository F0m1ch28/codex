// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const Notes = () => (
  <>
    <Helmet>
      <title>Editorial Notes | DevLayer</title>
      <meta
        name="description"
        content="Short editorial notes and platform updates from the DevLayer team."
      />
    </Helmet>

    <section className="mx-auto max-w-4xl px-4 pb-20 pt-10 sm:px-6 lg:px-8">
      <h1 className="font-display text-4xl font-semibold text-white">Editorial Notes</h1>
      <p className="mt-4 text-lg text-slate-300">
        Brief updates, behind-the-scenes commentary, and internal reflections from the DevLayer studio.
      </p>

      <div className="mt-12 space-y-6">
        {notes.map((note) => (
          <article key={note.title} className="rounded-3xl border border-slate-800/70 bg-slate-900/60 p-6">
            <span className="text-xs uppercase tracking-[0.3em] text-slate-500">{note.date}</span>
            <h2 className="mt-3 font-display text-2xl font-semibold text-white">{note.title}</h2>
            <p className="mt-3 text-sm text-slate-300">{note.summary}</p>
          </article>
        ))}
      </div>
    </section>
  </>
);

const notes = [
  {
    date: "January 8, 2024",
    title: "New workflow interviews underway",
    summary:
      "We are speaking with DevOps leaders in Atlantic Canada to capture stories about scaling observability practices with small teams."
  },
  {
    date: "December 14, 2023",
    title: "Editor residency applications",
    summary:
      "Our editorial residency is now open for Spring 2024. We’re especially interested in voices from public sector digital teams."
  },
  {
    date: "November 21, 2023",
    title: "Diagram system refresh",
    summary:
      "The information design team is updating our diagram library to better represent hybrid cloud topologies and governance layers."
  }
];

export default Notes;