// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";

const ContactThanks = () => (
  <>
    <Helmet>
      <title>Message Received | DevLayer</title>
      <meta
        name="description"
        content="Thank you for contacting DevLayer. We will respond shortly about your editorial or workflow inquiry."
      />
    </Helmet>

    <section className="mx-auto max-w-3xl px-4 pb-20 pt-20 text-center sm:px-6 lg:px-8">
      <div className="rounded-3xl border border-accent/40 bg-slate-900/70 p-10 shadow-glow">
        <h1 className="font-display text-4xl font-semibold text-white">Thank you.</h1>
        <p className="mt-4 text-lg text-slate-300">
          Your message is on its way to the DevLayer editorial team. Expect a response within two business days.
          Forms are processed via the Sendler PHP integration we use for secure delivery.
        </p>
        <div className="mt-6 space-x-4">
          <Link to="/" className="btn-primary">
            Return home
          </Link>
          <Link to="/blog" className="btn-secondary">
            Explore essays
          </Link>
        </div>
      </div>
    </section>
  </>
);

export default ContactThanks;