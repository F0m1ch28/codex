// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const Queue = () => (
  <>
    <Helmet>
      <title>Reading Queue | DevLayer</title>
      <meta
        name="description"
        content="DevLayer’s curated reading queue featuring essays, research papers, and external resources for developer workflows."
      />
    </Helmet>

    <section className="mx-auto max-w-5xl px-4 pb-20 pt-10 sm:px-6 lg:px-8">
      <h1 className="font-display text-4xl font-semibold text-white">Reading Queue</h1>
      <p className="mt-4 text-lg text-slate-300">
        A rotating list of pieces we’re reading, citing, and sharing with teams beyond the DevLayer studio.
      </p>

      <div className="mt-12 space-y-6">
        {readingItems.map((item) => (
          <article key={item.title} className="rounded-3xl border border-slate-800/70 bg-slate-900/60 p-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h2 className="font-display text-2xl font-semibold text-white">{item.title}</h2>
                <p className="mt-2 text-sm text-slate-400">By {item.author}</p>
                <p className="mt-3 text-sm text-slate-300">{item.summary}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                {item.tags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-accent/50 px-3 py-1 text-xs font-semibold text-accent"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

const readingItems = [
  {
    title: "Infrastructure as Narrative",
    author: "DevLayer Research",
    summary: "A working paper connecting cloud automation decisions with storytelling strategies for leadership updates.",
    tags: ["cloud infrastructure", "storytelling"]
  },
  {
    title: "The Quiet Influence of Runbooks",
    author: "Guest Contributor: Haleema K.",
    summary: "Runbooks as living communication tools that encode empathy for future responders.",
    tags: ["operations", "knowledge management"]
  },
  {
    title: "Focus Stewardship Handbook",
    author: "DevLayer Editors",
    summary: "A set of principles for teams protecting deep work in distributed environments.",
    tags: ["focus", "remote work"]
  },
  {
    title: "Platform Product Mindsets",
    author: "Guest Contributor: Rafael D.",
    summary: "How platform teams borrow product techniques to build experiences developers trust.",
    tags: ["platform engineering", "product thinking"]
  }
];

export default Queue;