// @ts-check
import React, { useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";

const categories = ["All", "Workflow", "Systems", "Tooling", "Culture"];

const posts = [
  {
    title: "Why Context Switching Kills Productivity",
    slug: "why-context-switching-kills-productivity",
    category: "Workflow",
    excerpt:
      "A look at cognitive costs, team dynamics, and practical strategies to protect focus in modern engineering teams.",
    date: "January 12, 2024",
    readTime: "10 min",
    link: "/blog/why-context-switching-kills-productivity"
  },
  {
    title: "Cloud Patterns for Scale",
    slug: "cloud-patterns-for-scale",
    category: "Systems",
    excerpt:
      "Pattern language for scaling cloud platforms responsibly, balancing automation with human oversight.",
    date: "December 2, 2023",
    readTime: "12 min",
    link: "/blog/cloud-patterns-for-scale"
  },
  {
    title: "The Evolution of DevOps Culture",
    slug: "the-evolution-of-devops-culture",
    category: "Culture",
    excerpt:
      "Tracing the lineage of DevOps principles and the cultural shifts that sustain them in Canadian organisations.",
    date: "November 18, 2023",
    readTime: "14 min",
    link: "/blog/the-evolution-of-devops-culture"
  }
];

const Blog = () => {
  const [filter, setFilter] = useState("All");
  const filteredPosts = useMemo(() => {
    if (filter === "All") {
      return posts;
    }
    return posts.filter((post) => post.category === filter);
  }, [filter]);

  return (
    <>
      <Helmet>
        <title>DevLayer Blog | Essays on Workflows, Systems, and Culture</title>
        <meta
          name="description"
          content="Read DevLayer blog essays covering developer workflows, software systems, cloud infrastructure, and DevOps culture."
        />
      </Helmet>

      <section className="mx-auto max-w-5xl px-4 pb-20 pt-10 sm:px-6 lg:px-8">
        <header className="text-center">
          <h1 className="font-display text-4xl font-semibold text-white sm:text-5xl">
            Essays and editorial updates.
          </h1>
          <p className="mt-4 text-lg text-slate-300">
            Field research, opinionated essays, and pattern libraries for engineers exploring the layers beneath their systems.
          </p>
        </header>

        <div className="mt-10 flex flex-wrap justify-center gap-3">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setFilter(category)}
              className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${
                filter === category
                  ? "border-accent bg-accent text-white"
                  : "border-slate-700 text-slate-300 hover:border-accent/70 hover:text-accent"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="mt-12 space-y-8">
          {filteredPosts.map((post) => (
            <article key={post.slug} className="rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8 shadow-card">
              <span className="text-xs uppercase tracking-[0.3em] text-slate-500">{post.category}</span>
              <h2 className="mt-4 font-display text-2xl font-semibold text-white">{post.title}</h2>
              <p className="mt-3 text-sm text-slate-300">{post.excerpt}</p>
              <div className="mt-4 flex flex-wrap items-center gap-4 text-xs uppercase tracking-[0.3em] text-slate-500">
                <span>{post.date}</span>
                <span>{post.readTime} read</span>
              </div>
              <Link to={post.link} className="mt-6 inline-flex items-center text-sm font-semibold text-accent">
                Read essay
                <svg className="ml-2 h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 12h14m-7-7 7 7-7 7" />
                </svg>
              </Link>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Blog;