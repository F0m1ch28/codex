// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const About = () => {
  return (
    <>
      <Helmet>
        <title>About DevLayer | Mission, Methodology, Editorial Team</title>
        <meta
          name="description"
          content="Learn about DevLayer’s mission, editorial values, research methodology, and the team behind our developer workflow stories."
        />
        <script type="application/ld+json">{JSON.stringify(aboutSchema)}</script>
      </Helmet>

      <section className="mx-auto max-w-5xl px-4 pb-20 pt-10 sm:px-6 lg:px-8">
        <header className="text-center">
          <span className="rounded-full border border-slate-800 px-4 py-2 text-xs uppercase tracking-[0.4em] text-slate-500">
            About DevLayer
          </span>
          <h1 className="mt-6 font-display text-4xl font-semibold text-white sm:text-5xl">
            Mission, methodology, and the editors stewarding DevLayer.
          </h1>
          <p className="mt-4 text-lg leading-relaxed text-slate-300">
            DevLayer exists to document the human and technical choreography behind software systems. We surface
            workflows, rituals, and infrastructures that often remain unpublished yet shape the resilience of
            modern teams.
          </p>
        </header>

        <div className="mt-16 grid gap-12 lg:grid-cols-2">
          <motion.div
            className="rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="font-display text-2xl font-semibold text-white">Editorial values</h2>
            <ul className="mt-6 space-y-4 text-sm leading-relaxed text-slate-300">
              <li>
                <strong className="text-white">Evidence before opinion:</strong> Research interviews, field observations,
                and archival documentation underpin every story.
              </li>
              <li>
                <strong className="text-white">Human-centered systems thinking:</strong> We connect infrastructure
                decisions with developer focus, collaboration, and wellbeing.
              </li>
              <li>
                <strong className="text-white">Ethical storytelling:</strong> Consent-driven publishing protects
                confidentiality while honouring practitioner voices.
              </li>
            </ul>
          </motion.div>

          <motion.div
            className="rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            <h2 className="font-display text-2xl font-semibold text-white">Methodology</h2>
            <ol className="mt-6 space-y-4 text-sm leading-relaxed text-slate-300">
              <li>
                <strong className="text-white">Discovery:</strong> Context interviews with platform, product, and design
                teams to understand objectives and constraints.
              </li>
              <li>
                <strong className="text-white">Immersion:</strong> Shadowing rituals, observing tools in use, and mapping
                socio-technical flows.
              </li>
              <li>
                <strong className="text-white">Synthesis:</strong> Patterns are translated into essays, diagrams,
                playbooks, and photographic documentation.
              </li>
            </ol>
          </motion.div>
        </div>

        <section className="mt-16 rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8">
          <h2 className="font-display text-2xl font-semibold text-white">Editorial ethics</h2>
          <ul className="mt-6 space-y-3 text-sm leading-relaxed text-slate-300">
            <li>Informed consent and review cycles for every contributor.</li>
            <li>Neutral language that favours clarity over hype.</li>
            <li>Transparency about limitations and the context of every insight.</li>
            <li>Alignment with Canadian privacy standards and research ethics guidelines.</li>
          </ul>
        </section>

        <section className="mt-16 rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8">
          <h2 className="font-display text-2xl font-semibold text-white">History</h2>
          <p className="mt-4 text-sm leading-relaxed text-slate-300">
            DevLayer began in 2019 as a small publication curating interviews with engineering leaders across Toronto.
            As our readership expanded to Vancouver, Montreal, and Atlantic Canada, the platform evolved into a research
            collective and editorial studio. Today we operate as an independent, Canada-based publisher collaborating
            with public and private organisations to share responsible, rigorously reviewed stories.
          </p>
        </section>

        <section className="mt-16 rounded-3xl border border-slate-800/70 bg-slate-900/60 p-8">
          <h2 className="font-display text-2xl font-semibold text-white">Contributors</h2>
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            <ContributorCard
              name="Noor Tanaka"
              role="Editor-in-Chief"
              focus="Leads platform storytelling, ensures editorial standards, and shapes the mission."
            />
            <ContributorCard
              name="Marcel Roy"
              role="Principal Researcher"
              focus="Designs fieldwork studies focused on developer workflows and cloud infrastructure."
            />
            <ContributorCard
              name="Iris Almeida"
              role="Design Strategist"
              focus="Builds visual systems, diagrams, and reading experiences for DevLayer publications."
            />
            <ContributorCard
              name="External Fellows"
              role="Guest Contributors"
              focus="Engineers, designers, and product leaders who co-author essays with DevLayer editors."
            />
          </div>
        </section>
      </section>
    </>
  );
};

const ContributorCard = ({ name, role, focus }) => (
  <div className="rounded-2xl border border-slate-800/70 bg-slate-900/70 p-6">
    <h3 className="font-display text-xl font-semibold text-white">{name}</h3>
    <p className="text-xs uppercase tracking-[0.3em] text-accent">{role}</p>
    <p className="mt-4 text-sm text-slate-300">{focus}</p>
  </div>
);

const aboutSchema = {
  "@context": "https://schema.org",
  "@type": "AboutPage",
  name: "About DevLayer",
  description:
    "DevLayer is an editorial platform documenting developer workflows, software systems, and cloud infrastructure stories.",
  publisher: {
    "@type": "Organization",
    name: "DevLayer",
    url: "https://www.devlayer.ca"
  }
};

export default About;