// @ts-check
import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const COOKIE_KEY = "devlayer-cookie-consent";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem(COOKIE_KEY);
    if (!storedConsent) {
      const timer = window.setTimeout(() => setVisible(true), 1200);
      return () => window.clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(COOKIE_KEY, "accepted");
    setVisible(false);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed inset-x-4 bottom-4 z-50 rounded-2xl border border-slate-700 bg-slate-900/95 p-5 text-sm text-slate-200 shadow-lg backdrop-blur"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 16 }}
        >
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
            <p className="flex-1 text-sm leading-relaxed">
              DevLayer uses cookies to understand browsing patterns and improve editorial experience.
              Analytics data remains aggregated and does not track personal identifiers. Continuing means
              you agree to this usage.
            </p>
            <button
              onClick={handleAccept}
              className="rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white transition hover:bg-accent/90"
            >
              Accept
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CookieBanner;