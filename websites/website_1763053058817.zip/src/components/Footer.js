// @ts-check
import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="border-t border-slate-800 bg-slate-950">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-4 lg:px-8">
        <div>
          <div className="flex items-center space-x-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10 text-accent">
              DL
            </div>
            <span className="font-display text-xl font-semibold text-mist">DevLayer</span>
          </div>
          <p className="mt-4 text-sm leading-relaxed text-slate-400">
            DevLayer is a Canadian editorial platform examining the invisible grammar of software systems,
            developer workflows, and cloud infrastructure stories that shape engineering practice.
          </p>
          <p className="mt-6 text-xs uppercase tracking-widest text-slate-500">
            For educational use only.
          </p>
        </div>

        <div>
          <h3 className="font-display text-lg font-semibold text-mist">Explore</h3>
          <ul className="mt-4 space-y-2 text-sm text-slate-400">
            <li>
              <Link to="/services" className="transition hover:text-accent">
                Programs &amp; Services
              </Link>
            </li>
            <li>
              <Link to="/workflows" className="transition hover:text-accent">
                Workflow Library
              </Link>
            </li>
            <li>
              <Link to="/mindset" className="transition hover:text-accent">
                Engineering Mindset Essays
              </Link>
            </li>
            <li>
              <Link to="/archives" className="transition hover:text-accent">
                Archives &amp; Standards
              </Link>
            </li>
            <li>
              <Link to="/notes" className="transition hover:text-accent">
                Editorial Notes
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="font-display text-lg font-semibold text-mist">Resources</h3>
          <ul className="mt-4 space-y-2 text-sm text-slate-400">
            <li>
              <Link to="/blog" className="transition hover:text-accent">
                Blog Overview
              </Link>
            </li>
            <li>
              <Link to="/privacy" className="transition hover:text-accent">
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link to="/terms" className="transition hover:text-accent">
                Terms of Use
              </Link>
            </li>
            <li>
              <a
                href="https://github.com/devlayer"
                target="_blank"
                rel="noreferrer"
                className="transition hover:text-accent"
              >
                GitHub
              </a>
            </li>
            <li>
              <a
                href="https://www.linkedin.com/company/devlayer"
                target="_blank"
                rel="noreferrer"
                className="transition hover:text-accent"
              >
                LinkedIn
              </a>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="font-display text-lg font-semibold text-mist">Contact</h3>
          <ul className="mt-4 space-y-3 text-sm text-slate-400">
            <li>333 Bay St, Toronto, ON M5H 2R2, Canada</li>
            <li>
              Phone:{" "}
              <a className="transition hover:text-accent" href="tel:+14169056621">
                +1 (416) 905-6621
              </a>
            </li>
            <li>Email: routed via contact form</li>
            <li>
              <Link to="/contact" className="transition hover:text-accent">
                Contact DevLayer
              </Link>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-slate-800 bg-slate-950/80">
        <div className="mx-auto flex max-w-7xl flex-col space-y-2 px-4 py-6 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between sm:space-y-0 sm:px-6 lg:px-8">
          <p>&copy; {new Date().getFullYear()} DevLayer. All rights reserved.</p>
          <p className="max-w-xl text-right">
            Crafted in Canada for engineers and readers committed to deep technical exploration.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;