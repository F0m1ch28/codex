// @ts-check
import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

/** @type {{ label: string; to: string; type: "section" | "route"; }} */
const navItems = [
  { label: "Insights", to: "/#insights", type: "section" },
  { label: "Workflow", to: "/workflows", type: "route" },
  { label: "Mindset", to: "/mindset", type: "route" },
  { label: "Reading Queue", to: "/queue", type: "route" },
  { label: "Blog", to: "/blog", type: "route" },
  { label: "Contact", to: "/contact", type: "route" }
];

const Header = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isScrolled, setIsScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 16);
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  const isActivePath = (to) => {
    if (to === "/") {
      return location.pathname === "/";
    }
    if (to.startsWith("/#")) {
      return location.pathname === "/";
    }
    return location.pathname === to;
  };

  const handleSectionNavigation = (event, hash) => {
    event.preventDefault();
    setMenuOpen(false);
    const targetId = hash.replace("#", "");
    if (location.pathname !== "/") {
      navigate("/", { state: { scrollTo: targetId } });
      return;
    }
    const element = document.getElementById(targetId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-all duration-300 ${
        isScrolled ? "bg-slate-950/90 backdrop-blur-md shadow-lg" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center space-x-3">
          <span className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10 text-accent">
            <motion.span
              className="text-xl font-semibold"
              animate={{ rotate: 360 }}
              transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
            >
              D
            </motion.span>
          </span>
          <span className="font-display text-xl font-semibold tracking-wide text-mist">
            DevLayer
          </span>
        </Link>

        <nav className="hidden items-center space-x-2 lg:flex">
          {navItems.map((item) =>
            item.type === "section" ? (
              <button
                key={item.label}
                onClick={(event) => handleSectionNavigation(event, item.to.split("#")[1] || "")}
                className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                  isActivePath(item.to) ? "bg-accent text-white" : "text-slate-200 hover:bg-slate-800/70"
                }`}
              >
                {item.label}
              </button>
            ) : (
              <Link
                key={item.label}
                to={item.to}
                className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                  isActivePath(item.to) ? "bg-accent text-white" : "text-slate-200 hover:bg-slate-800/70"
                }`}
              >
                {item.label}
              </Link>
            )
          )}
        </nav>

        <div className="flex items-center space-x-3">
          <Link
            to="/services"
            className="hidden rounded-full border border-accent/50 px-4 py-2 text-sm font-medium text-accent transition hover:border-accent hover:bg-accent hover:text-white lg:inline-flex"
          >
            Programs
          </Link>
          <button
            className="inline-flex items-center justify-center rounded-full border border-slate-700 p-2 text-slate-200 transition hover:border-accent hover:text-accent lg:hidden"
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-label="Toggle navigation"
          >
            <svg className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              {menuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden"
          >
            <div className="space-y-1 border-t border-slate-800 bg-slate-950/95 px-4 pb-6 pt-2">
              {navItems.map((item) =>
                item.type === "section" ? (
                  <button
                    key={item.label}
                    onClick={(event) => handleSectionNavigation(event, item.to.split("#")[1] || "")}
                    className="block w-full rounded-lg px-4 py-3 text-left text-base font-medium text-slate-200 transition hover:bg-slate-800/70"
                  >
                    {item.label}
                  </button>
                ) : (
                  <Link
                    key={item.label}
                    to={item.to}
                    className="block rounded-lg px-4 py-3 text-base font-medium text-slate-200 transition hover:bg-slate-800/70"
                  >
                    {item.label}
                  </Link>
                )
              )}
              <Link
                to="/services"
                className="mt-2 block rounded-lg border border-accent/40 px-4 py-3 text-center text-base font-semibold text-accent transition hover:border-accent hover:bg-accent hover:text-white"
              >
                Explore Programs
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;