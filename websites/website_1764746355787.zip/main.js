document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      navLinks.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', navLinks.classList.contains('open'));
    });

    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const COOKIE_KEY = 'autoImportCookieConsent';
  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
    const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
    const stored = localStorage.getItem(COOKIE_KEY);

    if (!stored) {
      setTimeout(() => cookieBanner.classList.add('active'), 600);
    }

    const handleConsent = value => {
      localStorage.setItem(COOKIE_KEY, value);
      cookieBanner.classList.remove('active');
    };

    acceptBtn?.addEventListener('click', () => handleConsent('accepted'));
    declineBtn?.addEventListener('click', () => handleConsent('declined'));
  }

  const estimatorForm = document.querySelector('#estimate-form');
  const estimatorResult = document.querySelector('#estimate-result');
  if (estimatorForm && estimatorResult) {
    const formatCurrency = value =>
      new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(value);

    const calculate = () => {
      const prixUSD = parseFloat(estimatorForm.prix.value) || 0;
      const transport = parseFloat(estimatorForm.transport.value) || 0;
      const assurance = parseFloat(estimatorForm.assurance.value) || 0;

      const tauxChange = 0.92;
      const prixEuro = prixUSD * tauxChange;
      const douane = prixEuro * 0.10;
      const tva = (prixEuro + douane + transport) * 0.20;
      const homologation = 950;
      const service = 1250;

      const total = prixEuro + transport + assurance + douane + tva + homologation + service;

      estimatorResult.querySelector('[data-prix-europe]').textContent = formatCurrency(prixEuro);
      estimatorResult.querySelector('[data-douane]').textContent = formatCurrency(douane);
      estimatorResult.querySelector('[data-tva]').textContent = formatCurrency(tva);
      estimatorResult.querySelector('[data-ligne-fixe]').textContent = formatCurrency(homologation + service + assurance);
      estimatorResult.querySelector('[data-total]').textContent = formatCurrency(total);
    };

    estimatorForm.addEventListener('input', calculate);
    calculate();
  }
});