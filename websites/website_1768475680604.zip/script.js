document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !isExpanded);
            navMenu.classList.toggle('active');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('active')) {
                    navMenu.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptButton = document.querySelector('.cookie-button.accept');
    const declineButton = document.querySelector('.cookie-button.decline');
    const consentKey = 'stjCookieConsent';

    if (cookieBanner) {
        const existingConsent = localStorage.getItem(consentKey);
        if (!existingConsent) {
            setTimeout(() => {
                cookieBanner.classList.add('show');
            }, 800);
        }

        if (acceptButton) {
            acceptButton.addEventListener('click', () => {
                localStorage.setItem(consentKey, 'accepted');
                cookieBanner.classList.remove('show');
            });
        }

        if (declineButton) {
            declineButton.addEventListener('click', () => {
                localStorage.setItem(consentKey, 'declined');
                cookieBanner.classList.remove('show');
            });
        }
    }

    if (window.mermaid) {
        mermaid.initialize({
            startOnLoad: true,
            theme: 'neutral',
            securityLevel: 'loose',
            flowchart: {
                useMaxWidth: true,
                htmlLabels: true,
                curve: 'basis'
            }
        });
    }
});