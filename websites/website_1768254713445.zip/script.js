document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            siteNav.classList.toggle('active');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-banner a[data-action]');
    const consentKey = 'todaarylCookieConsent';

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);

        if (!storedConsent) {
            cookieBanner.classList.add('active');
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', (event) => {
                const action = button.getAttribute('data-action');
                localStorage.setItem(consentKey, action);
                cookieBanner.classList.remove('active');
                event.preventDefault();
                window.open('cookies.html', '_blank');
            });
        });
    }
});