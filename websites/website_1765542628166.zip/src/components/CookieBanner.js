import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('languageMasteryCookieConsent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('languageMasteryCookieConsent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie usage notice">
      <p>
        We use analytical cookies to understand how our website is used and to improve your learning journey.
        By clicking accept, you agree to our cookie policy.
      </p>
      <button type="button" onClick={handleAccept} className={styles.button} aria-label="Accept cookies">
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;