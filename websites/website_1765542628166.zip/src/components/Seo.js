import { useEffect } from 'react';

const defaultTitle = 'Learn Languages with Effortless Mastery';
const defaultDescription =
  'Immerse yourself in proficiency-driven language learning with Learn Languages with Effortless Mastery. Discover courses for international languages and regional dialects across the Netherlands.';

const ensureMetaTag = (name) => {
  let tag = document.querySelector(`meta[name="${name}"]`);
  if (!tag) {
    tag = document.createElement('meta');
    tag.setAttribute('name', name);
    document.head.appendChild(tag);
  }
  return tag;
};

const Seo = ({ title, description = defaultDescription, keywords }) => {
  useEffect(() => {
    document.title = title ? `${title} | ${defaultTitle}` : defaultTitle;

    const descriptionTag = ensureMetaTag('description');
    descriptionTag.setAttribute('content', description);

    if (keywords) {
      const keywordsTag = ensureMetaTag('keywords');
      keywordsTag.setAttribute('content', keywords);
    }
  }, [title, description, keywords]);

  return null;
};

export default Seo;