import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={styles.inner}>
      <div className={styles.brandColumn}>
        <div className={styles.logo}>
          Learn Languages
          <span>with Effortless Mastery</span>
        </div>
        <p className={styles.tagline}>
          Empowering learners across the Netherlands to master languages with confidence through immersive,
          proficiency-led training.
        </p>
        <p className={styles.address}>
          Language Mastery Center, Keizersgracht 123, Amsterdam, Netherlands
        </p>
        <p className={styles.contact}>
          <strong>Phone:</strong> <a href="tel:+3120XXXXXXX">+31 20 XXX XXXX</a>
          <br />
          <strong>Email:</strong>{' '}
          <a href="mailto:info@languageMastery.nl">info@languageMastery.nl</a>
        </p>
      </div>

      <div className={styles.navColumn}>
        <h3 className={styles.title}>Explore</h3>
        <ul className={styles.linkList}>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/courses">Courses</Link>
          </li>
          <li>
            <Link to="/methodology">Methodology</Link>
          </li>
          <li>
            <Link to="/instructors">Instructors</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
      </div>

      <div className={styles.navColumn}>
        <h3 className={styles.title}>Policies</h3>
        <ul className={styles.linkList}>
          <li>
            <Link to="/terms-of-service">Terms of Service</Link>
          </li>
          <li>
            <Link to="/privacy-policy">Privacy Policy</Link>
          </li>
          <li>
            <Link to="/cookie-policy">Cookie Policy</Link>
          </li>
        </ul>
      </div>

      <div className={styles.newsColumn}>
        <h3 className={styles.title}>Stay informed</h3>
        <p className={styles.tagline}>
          Receive curated language learning insights, success stories, and program highlights.
        </p>
        <form className={styles.form} onSubmit={(event) => event.preventDefault()}>
          <label htmlFor="footer-email" className="sr-only">
            Email address
          </label>
          <input
            id="footer-email"
            type="email"
            name="email"
            placeholder="you@example.com"
            aria-label="Email address for updates"
            required
          />
          <button type="submit" aria-label="Subscribe for updates">
            Subscribe
          </button>
        </form>
      </div>
    </div>
    <div className={styles.bottomBar}>
      <p>© {new Date().getFullYear()} Learn Languages with Effortless Mastery. All rights reserved.</p>
      <p>Crafted in Amsterdam with a passion for communication.</p>
    </div>
  </footer>
);

export default Footer;