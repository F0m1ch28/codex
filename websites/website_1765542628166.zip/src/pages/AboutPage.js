import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './AboutPage.module.css';

const AboutPage = () => {
  return (
    <>
      <Seo
        title="About"
        description="Learn Languages with Effortless Mastery blends linguistic expertise, cultural intelligence, and personalised mentoring to help learners thrive in multilingual environments."
      />
      <section className={styles.hero} aria-labelledby="about-heading">
        <div className={styles.heroContent}>
          <h1 id="about-heading">Language mastery powered by human connection</h1>
          <p>
            Since our founding in Amsterdam, we have partnered with learners, organisations, and communities to
            transform language goals into lived experiences. Our faculty of linguists, coaches, and cultural
            strategists build programmes that celebrate diversity while achieving measurable fluency results.
          </p>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/seed/about-language-team/900/600"
            alt="Language learners collaborating during a workshop"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.valuesSection} aria-labelledby="values-heading">
        <div className={styles.sectionIntro}>
          <p className={styles.eyebrow}>Our DNA</p>
          <h2 id="values-heading">Principles that shape every learning experience</h2>
          <p>
            Our team combines decades of academic research, global teaching experience, and heartfelt curiosity
            about language and culture. Together, we translated those experiences into core principles that guide
            how we design, deliver, and refine our programmes.
          </p>
        </div>
        <div className={styles.valuesGrid}>
          <article className={styles.valueCard}>
            <h3>Proficiency with purpose</h3>
            <p>
              We focus on the language you need for the communities, industries, and conversations you care
              about. Every session connects to real contexts you will encounter outside the classroom.
            </p>
          </article>
          <article className={styles.valueCard}>
            <h3>Inclusive, human-first approach</h3>
            <p>
              Learning thrives when you feel seen. We honour identities, neuro-diversity, and unique motivations,
              creating safe and dynamic environments for experimentation.
            </p>
          </article>
          <article className={styles.valueCard}>
            <h3>Evidence-led innovation</h3>
            <p>
              Our methodology weaves together cognitive science, CEFR-aligned assessment, design thinking, and
              continuous learner feedback to drive sustainable progress.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.timelineSection} aria-labelledby="timeline-heading">
        <div className={styles.sectionIntro}>
          <p className={styles.eyebrow}>Our journey</p>
          <h2 id="timeline-heading">Milestones from a decade of language leadership</h2>
        </div>
        <ol className={styles.timeline}>
          <li>
            <span className={styles.year}>2014</span>
            <div>
              <h3>Founded in Amsterdam</h3>
              <p>
                Our first studio opened along the canals, specialising in Dutch immersion for international
                professionals settling in the Netherlands.
              </p>
            </div>
          </li>
          <li>
            <span className={styles.year}>2017</span>
            <div>
              <h3>Expanded to multilingual programmes</h3>
              <p>
                Partnerships with universities and corporate clients led to bespoke English, French, and German
                offerings across the country.
              </p>
            </div>
          </li>
          <li>
            <span className={styles.year}>2020</span>
            <div>
              <h3>Hybrid learning ecosystem launched</h3>
              <p>
                We launched an interactive virtual campus that mirrors in-person quality, ensuring continuity for
                global learners.
              </p>
            </div>
          </li>
          <li>
            <span className={styles.year}>2023</span>
            <div>
              <h3>Community outreach and regional dialects</h3>
              <p>
                Collaborations with cultural foundations expanded our portfolio to include Frisian, Limburgish,
                and other regional dialects.
              </p>
            </div>
          </li>
        </ol>
      </section>

      <section className={styles.teamSection} aria-labelledby="team-heading">
        <div className={styles.sectionIntro}>
          <p className={styles.eyebrow}>Team</p>
          <h2 id="team-heading">A collective of linguists, educators, and cultural advocates</h2>
        </div>
        <div className={styles.teamGrid}>
          {[
            {
              name: 'Eva Janssen',
              title: 'Director of Language Innovation',
              description:
                'Designer of the proficiency-first curriculum and advocate for inclusive language education policies.',
              image: 'https://picsum.photos/seed/about-team-1/520/520'
            },
            {
              name: 'Lucas Martins',
              title: 'Head of Executive Coaching',
              description:
                'Works with leaders to develop persuasive multilingual communication for cross-border teams.',
              image: 'https://picsum.photos/seed/about-team-2/520/520'
            },
            {
              name: 'Aisha Rahman',
              title: 'Cultural Integration Specialist',
              description:
                'Guides heritage and regional language programmes, aligning cultural narratives with language growth.',
              image: 'https://picsum.photos/seed/about-team-3/520/520'
            }
          ].map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={member.name} loading="lazy" />
              <div className={styles.teamContent}>
                <h3>{member.name}</h3>
                <p className={styles.role}>{member.title}</p>
                <p>{member.description}</p>
              </div>
            </article>
          ))}
        </div>
        <Link to="/instructors" className={styles.linkButton}>
          Meet the full instructor faculty
        </Link>
      </section>

      <section className={styles.ctaSection} aria-labelledby="about-cta-heading">
        <div className={styles.ctaCard}>
          <h2 id="about-cta-heading">We’re here to design your next language chapter</h2>
          <p>
            Speak with our programme advisors to co-create a learning plan aligned to your aspirations, timeframe,
            and preferred delivery mode.
          </p>
          <div className={styles.actions}>
            <Link to="/contact" className={styles.primaryCta}>
              Start a conversation
            </Link>
            <Link to="/methodology" className={styles.secondaryCta}>
              Explore our methodology
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;