import React, { useMemo, useState } from 'react';
import Seo from '../components/Seo';
import styles from './CoursesPage.module.css';

const CoursesPage = () => {
  const courses = useMemo(
    () => [
      {
        id: 1,
        title: 'Dutch Foundations & Integration',
        category: 'Beginner Foundations',
        level: 'A1 – B1',
        duration: '12 weeks',
        format: 'Hybrid (Amsterdam & online)',
        description:
          'Master everyday Dutch with scenario-based practice for relocation, study, or family life in the Netherlands.',
        languages: ['Dutch'],
        image: 'https://picsum.photos/seed/course-dutch/820/520'
      },
      {
        id: 2,
        title: 'Executive English Mastery',
        category: 'Professional Fluency',
        level: 'B2 – C2',
        duration: '8 weeks',
        format: 'Bespoke coaching',
        description:
          'High-impact coaching focused on negotiation, presentations, and stakeholder communication for senior leaders.',
        languages: ['English'],
        image: 'https://picsum.photos/seed/course-english/820/520'
      },
      {
        id: 3,
        title: 'Spanish Cultural Immersion Labs',
        category: 'Cultural Immersion',
        level: 'A2 – C1',
        duration: '6 weeks',
        format: 'Weekend intensives',
        description:
          'Experience Spain and Latin America through culinary narratives, storytelling, and interactive workshops.',
        languages: ['Spanish'],
        image: 'https://picsum.photos/seed/course-spanish/820/520'
      },
      {
        id: 4,
        title: 'French for Academic Excellence',
        category: 'Academic Pathways',
        level: 'B1 – C1',
        duration: '10 weeks',
        format: 'Virtual classroom',
        description:
          'Prepare for university life with academic writing labs, debate clubs, and research presentation coaching.',
        languages: ['French'],
        image: 'https://picsum.photos/seed/course-french/820/520'
      },
      {
        id: 5,
        title: 'German for Technical Professionals',
        category: 'Professional Fluency',
        level: 'B1 – C1',
        duration: '9 weeks',
        format: 'On-site or online',
        description:
          'Communicate confidently in technical environments with terminology labs and client-facing simulations.',
        languages: ['German'],
        image: 'https://picsum.photos/seed/course-german/820/520'
      },
      {
        id: 6,
        title: 'Mandarin Heritage Conversations',
        category: 'Cultural Immersion',
        level: 'A2 – B2',
        duration: '8 weeks',
        format: 'Small group sessions',
        description:
          'Reconnect with heritage through conversational circles, cultural storytelling, and family-focused scenarios.',
        languages: ['Mandarin'],
        image: 'https://picsum.photos/seed/course-mandarin/820/520'
      }
    ],
    []
  );

  const categories = ['All', 'Beginner Foundations', 'Professional Fluency', 'Academic Pathways', 'Cultural Immersion'];
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredCourses =
    activeCategory === 'All' ? courses : courses.filter((course) => course.category === activeCategory);

  return (
    <>
      <Seo
        title="Courses"
        description="Browse tailored language courses designed for relocation, career excellence, academic success, and cultural immersion throughout the Netherlands."
      />
      <section className={styles.hero} aria-labelledby="courses-heading">
        <div className={styles.heroContent}>
          <h1 id="courses-heading">Courses aligned with your language ambitions</h1>
          <p>
            Whether you are relocating to the Netherlands, leading multilingual teams, or deepening heritage roots,
            our programmes blend immersive practice, personalised mentoring, and data-backed progress tracking.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/seed/courses-hero-language/900/560"
            alt="Interactive language class in progress"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.filterSection} aria-label="Filter courses by category">
        <div className={styles.filterControls}>
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              className={`${styles.filterButton} ${
                activeCategory === category ? styles.filterButtonActive : ''
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
      </section>

      <section className={styles.coursesGrid} aria-label="Course catalogue">
        {filteredCourses.map((course) => (
          <article key={course.id} className={styles.courseCard}>
            <div className={styles.courseImageWrapper}>
              <img src={course.image} alt={course.title} loading="lazy" />
            </div>
            <div className={styles.courseContent}>
              <span className={styles.courseCategory}>{course.category}</span>
              <h2>{course.title}</h2>
              <p>{course.description}</p>
              <ul className={styles.courseMeta}>
                <li>
                  <strong>Level:</strong> {course.level}
                </li>
                <li>
                  <strong>Duration:</strong> {course.duration}
                </li>
                <li>
                  <strong>Format:</strong> {course.format}
                </li>
                <li>
                  <strong>Languages:</strong> {course.languages.join(', ')}
                </li>
              </ul>
              <button type="button" className={styles.detailsButton} aria-label={`Enquire about ${course.title}`}>
                Request syllabus
              </button>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.experienceSection} aria-labelledby="experience-heading">
        <div className={styles.sectionIntro}>
          <p className={styles.eyebrow}>Learning experience</p>
          <h2 id="experience-heading">What makes our language programmes different</h2>
          <p>
            Every course is part of a wider learning ecosystem where you receive coaching, analytics, and the
            accountability needed to progress steadily and confidently.
          </p>
        </div>
        <div className={styles.experienceGrid}>
          {[
            {
              title: 'Diagnostic onboarding',
              description:
                'Begin with a conversational assessment, proficiency analysis, and goal mapping session to tailor the roadmap.'
            },
            {
              title: 'Immersive labs',
              description:
                'Scenario-based labs mimic real situations—client meetings, university seminars, cultural ceremonies—to prepare you for the real world.'
            },
            {
              title: 'Mentor feedback & analytics',
              description:
                'Track speaking, listening, reading, and writing progress with in-depth mentor feedback and micro learning recommendations.'
            },
            {
              title: 'Community practice',
              description:
                'Join conversation circles, pronunciation clinics, and cultural events to cement learning and expand your network.'
            }
          ].map((item) => (
            <article key={item.title} className={styles.experienceCard}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default CoursesPage;