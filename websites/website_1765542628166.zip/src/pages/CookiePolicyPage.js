import React from 'react';
import Seo from '../components/Seo';
import styles from './PolicyPages.module.css';

const CookiePolicyPage = () => (
  <>
    <Seo
      title="Cookie Policy"
      description="Understand how Learn Languages with Effortless Mastery uses cookies and similar technologies."
    />
    <section className={styles.policySection} aria-labelledby="cookie-heading">
      <h1 id="cookie-heading">Cookie Policy</h1>
      <p>Effective date: 8 May 2024</p>

      <h2>1. What are cookies?</h2>
      <p>
        Cookies are small text files placed on your device to support website functionality, analytics, and
        personalised experiences.
      </p>

      <h2>2. Cookies we use</h2>
      <ul>
        <li>
          <strong>Essential cookies:</strong> Enable core features such as secure sign-in and request handling.
        </li>
        <li>
          <strong>Analytics cookies:</strong> Provide aggregated insights into how visitors interact with the
          website so we can improve the experience.
        </li>
      </ul>

      <h2>3. Managing cookies</h2>
      <p>
        Upon visiting our website you are invited to accept cookies. You can adjust browser settings to refuse or
        delete cookies. Please note that some services may not function optimally without essential cookies.
      </p>

      <h2>4. Updates</h2>
      <p>
        Any changes to this Cookie Policy will be published on this page with an updated effective date.
      </p>

      <h2>5. Contact</h2>
      <p>
        For questions about this policy, contact{' '}
        <a href="mailto:info@languageMastery.nl">info@languageMastery.nl</a>.
      </p>
    </section>
  </>
);

export default CookiePolicyPage;