import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    message: '',
    programme: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formState.name.trim()) {
      newErrors.name = 'Please share your name.';
    }
    if (!formState.email.trim()) {
      newErrors.email = 'We would love to send a response—please add your email.';
    } else if (!/\S+@\S+\.\S+/.test(formState.email)) {
      newErrors.email = 'That email address seems incomplete.';
    }
    if (!formState.message.trim()) {
      newErrors.message = 'Let us know how we can help you.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const newErrors = validate();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    setErrors({});
    setSubmitted(true);
    setFormState({
      name: '',
      email: '',
      message: '',
      programme: ''
    });
  };

  return (
    <>
      <Seo
        title="Contact"
        description="Contact Learn Languages with Effortless Mastery to design your personalised language programme or explore corporate partnerships."
      />
      <section className={styles.hero} aria-labelledby="contact-heading">
        <div className={styles.heroText}>
          <h1 id="contact-heading">Let’s design your language mastery journey</h1>
          <p>
            Share your aspirations, timelines, and contexts. Our programme advisors will respond within one
            working day with a tailored proposal and next steps.
          </p>
          <div className={styles.contactDetails}>
            <p>
              <strong>Visit:</strong> Language Mastery Center, Keizersgracht 123, Amsterdam, Netherlands
            </p>
            <p>
              <strong>Call:</strong> <a href="tel:+3120XXXXXXX">+31 20 XXX XXXX</a>
            </p>
            <p>
              <strong>Email:</strong>{' '}
              <a href="mailto:info@languageMastery.nl">info@languageMastery.nl</a>
            </p>
            <p>
              <strong>Office hours:</strong> Monday – Friday, 09:00 – 18:00 CET
            </p>
          </div>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/seed/contact-language/900/560"
            alt="Advisor welcoming language learners in the studio"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.formSection} aria-labelledby="contact-form-heading">
        <div className={styles.formCard}>
          <h2 id="contact-form-heading">Share your goals</h2>
          <p>Complete the form and we’ll craft a personalised learning blueprint for you or your organisation.</p>
          {submitted && (
            <div className={styles.successMessage} role="status">
              Thank you! We will respond shortly with tailored recommendations.
            </div>
          )}
          <form onSubmit={handleSubmit} noValidate>
            <div className={styles.formGroup}>
              <label htmlFor="name">Name</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formState.name}
                onChange={handleChange}
                aria-invalid={errors.name ? 'true' : 'false'}
                aria-describedby={errors.name ? 'name-error' : undefined}
                required
              />
              {errors.name && (
                <span id="name-error" className={styles.error}>
                  {errors.name}
                </span>
              )}
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formState.email}
                onChange={handleChange}
                aria-invalid={errors.email ? 'true' : 'false'}
                aria-describedby={errors.email ? 'email-error' : undefined}
                required
              />
              {errors.email && (
                <span id="email-error" className={styles.error}>
                  {errors.email}
                </span>
              )}
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="programme">Primary interest</label>
              <select id="programme" name="programme" value={formState.programme} onChange={handleChange}>
                <option value="">Choose an option</option>
                <option value="Relocation">Relocation & integration</option>
                <option value="Executive">Executive coaching</option>
                <option value="Academic">Academic readiness</option>
                <option value="Heritage">Heritage & cultural programmes</option>
                <option value="Corporate">Corporate partnerships</option>
              </select>
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="message">How can we help?</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formState.message}
                onChange={handleChange}
                aria-invalid={errors.message ? 'true' : 'false'}
                aria-describedby={errors.message ? 'message-error' : undefined}
                required
              />
              {errors.message && (
                <span id="message-error" className={styles.error}>
                  {errors.message}
                </span>
              )}
            </div>

            <button type="submit" className={styles.submitButton}>
              Submit enquiry
            </button>
          </form>
        </div>
      </section>
    </>
  );
};

export default ContactPage;