import React from 'react';
import Seo from '../components/Seo';
import styles from './InstructorsPage.module.css';

const instructors = [
  {
    id: 1,
    name: 'Eva Janssen',
    specialisation: 'Dutch for global professionals, intercultural intelligence',
    experience: '12 years guiding expats, founders, and families through Dutch integration.',
    languages: ['Dutch', 'English', 'German'],
    image: 'https://picsum.photos/seed/instructor-eva/480/480'
  },
  {
    id: 2,
    name: 'Lucas Martins',
    specialisation: 'Executive English, persuasive communication',
    experience: 'Former speechwriter and debate coach helping leaders communicate with clarity.',
    languages: ['English', 'Portuguese', 'Spanish'],
    image: 'https://picsum.photos/seed/instructor-lucas/480/480'
  },
  {
    id: 3,
    name: 'Aisha Rahman',
    specialisation: 'Arabic heritage programmes, cultural mediation',
    experience: 'Supports families and diplomats in navigating language and cultural transitions.',
    languages: ['Arabic', 'Dutch', 'English'],
    image: 'https://picsum.photos/seed/instructor-aisha/480/480'
  },
  {
    id: 4,
    name: 'Pierre Dubois',
    specialisation: 'French academic pathways, exam preparation',
    experience: 'University lecturer who brings practical strategies for research, debate, and writing.',
    languages: ['French', 'English'],
    image: 'https://picsum.photos/seed/instructor-pierre/480/480'
  },
  {
    id: 5,
    name: 'Sofia Alvarez',
    specialisation: 'Spanish cultural immersions, community engagement',
    experience: 'Designs storytelling and cultural experiences for learners exploring their heritage.',
    languages: ['Spanish', 'Dutch', 'English'],
    image: 'https://picsum.photos/seed/instructor-sofia/480/480'
  },
  {
    id: 6,
    name: 'Jonas Eriksson',
    specialisation: 'Nordic languages for relocation and work',
    experience: 'Supports professionals relocating to Scandinavia with contextual language coaching.',
    languages: ['Swedish', 'Norwegian', 'English'],
    image: 'https://picsum.photos/seed/instructor-jonas/480/480'
  }
];

const InstructorsPage = () => {
  return (
    <>
      <Seo
        title="Instructors"
        description="Meet the multilingual facilitators behind Effortless Mastery. Explore their expertise, language combinations, and passions for helping learners thrive."
      />
      <section className={styles.hero} aria-labelledby="instructors-heading">
        <div className={styles.heroText}>
          <h1 id="instructors-heading">The multilingual experts behind your journey</h1>
          <p>
            Our instructors combine deep linguistic knowledge with coaching, leadership, and cultural expertise.
            They mentor learners through real-world challenges while celebrating every milestone.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/seed/instructors-hero/900/560"
            alt="Instructors collaborating on lesson plans"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.gridSection} aria-label="Instructor directory">
        <div className={styles.grid}>
          {instructors.map((instructor) => (
            <article key={instructor.id} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={instructor.image} alt={instructor.name} loading="lazy" />
              </div>
              <div className={styles.cardContent}>
                <h2>{instructor.name}</h2>
                <p className={styles.specialisation}>{instructor.specialisation}</p>
                <p className={styles.experience}>{instructor.experience}</p>
                <div className={styles.languages}>
                  {instructor.languages.map((language) => (
                    <span key={language}>{language}</span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default InstructorsPage;