import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './HomePage.module.css';

const HomePage = () => {
  const statsData = useMemo(
    () => [
      { label: 'Learners empowered', value: 4200 },
      { label: 'Hours of immersive coaching', value: 16800 },
      { label: 'Corporate & academic partners', value: 65 },
      { label: 'Languages delivered', value: 18 }
    ],
    []
  );

  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [activeStoryFilter, setActiveStoryFilter] = useState('All');
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [expandedFaq, setExpandedFaq] = useState(null);

  useEffect(() => {
    let animationFrame;
    const duration = 1400;
    const startTime = performance.now();

    const animate = (currentTime) => {
      const progress = Math.min((currentTime - startTime) / duration, 1);
      const updated = statsData.map((stat) => Math.floor(stat.value * progress));
      setCounters(updated);
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [statsData]);

  const testimonials = [
    {
      name: 'Marieke van den Berg',
      role: 'Mechanical Engineer relocated to Rotterdam',
      quote:
        'The immersive Dutch program helped me connect with my team and clients in a matter of weeks. The focus on proficiency over rote memorisation made the entire journey surprisingly natural.',
      image: 'https://picsum.photos/seed/language-testimonial-1/200/200'
    },
    {
      name: 'Daniel Thompson',
      role: 'Finance Leader, Amsterdam',
      quote:
        'I needed native-level English for international board meetings. The personalised coaching and pronunciation labs were game changers. Every session was relevant to my professional reality.',
      image: 'https://picsum.photos/seed/language-testimonial-2/200/200'
    },
    {
      name: 'Sofia Alvarez',
      role: 'Cultural Ambassador, Utrecht',
      quote:
        'The Spanish heritage track combined cultural nuances with advanced communication drills. I now lead workshops in my mother tongue with renewed confidence and clarity.',
      image: 'https://picsum.photos/seed/language-testimonial-3/200/200'
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const successStories = [
    {
      id: 1,
      title: 'Accelerated Dutch for Global Tech Teams',
      category: 'Corporate',
      description:
        'Designed a blended Dutch immersion for an Eindhoven-based scale-up, enabling teams to collaborate bilingually within 10 weeks.',
      image: 'https://picsum.photos/seed/language-project-1/800/520'
    },
    {
      id: 2,
      title: 'Heritage Language Revival',
      category: 'Community',
      description:
        'Partnered with local cultural centres to revive Frisian dialect proficiency for younger speakers through storytelling workshops.',
      image: 'https://picsum.photos/seed/language-project-2/800/520'
    },
    {
      id: 3,
      title: 'English for Executive Leadership',
      category: 'Corporate',
      description:
        'Curated bespoke executive English coaching focusing on persuasive communication and board-level clarity for financial leaders.',
      image: 'https://picsum.photos/seed/language-project-3/800/520'
    },
    {
      id: 4,
      title: 'University Readiness French',
      category: 'Academic',
      description:
        'Supported international students entering French-speaking programmes with intensive academic writing and debate labs.',
      image: 'https://picsum.photos/seed/language-project-4/800/520'
    }
  ];

  const blogPosts = [
    {
      id: 1,
      title: 'How intentional immersion accelerates language proficiency',
      excerpt:
        'Explore how mindful exposure, reflective practice, and cultural cues combine to cement long-term language confidence.',
      image: 'https://picsum.photos/seed/language-blog-1/680/420',
      link: '/methodology'
    },
    {
      id: 2,
      title: 'Designing multilingual teams for inclusive innovation',
      excerpt:
        'Practical steps for empowering diverse teams with shared linguistic frameworks that enhance collaboration and empathy.',
      image: 'https://picsum.photos/seed/language-blog-2/680/420',
      link: '/courses'
    },
    {
      id: 3,
      title: 'Five micro-habits of fluent speakers',
      excerpt:
        'From pronounced shadowing to micro journaling, discover small daily rituals that compound into impressive fluency gains.',
      image: 'https://picsum.photos/seed/language-blog-3/680/420',
      link: '/methodology'
    }
  ];

  const languages = [
    'Dutch',
    'English',
    'Spanish',
    'French',
    'German',
    'Italian',
    'Mandarin',
    'Frisian',
    'Arabic',
    'Portuguese',
    'Swedish',
    'Norwegian'
  ];

  const processSteps = [
    {
      title: 'Discover',
      description:
        'We map your goals, contexts, and motivations to create a personalised proficiency blueprint.',
      icon: '🧭'
    },
    {
      title: 'Immerse',
      description:
        'Dynamic sessions pair live coaching with interactive labs to build reflexive language use.',
      icon: '🌐'
    },
    {
      title: 'Activate',
      description:
        'Scenario-based drills simulate real conversations, presentations, and cross-cultural exchanges.',
      icon: '💬'
    },
    {
      title: 'Sustain',
      description:
        'Ongoing mentoring, micro-learning, and analytics ensure continuous progress and retention.',
      icon: '📈'
    }
  ];

  const faqs = [
    {
      question: 'How are the courses tailored to individual proficiency levels?',
      answer:
        'Each learner begins with a discovery consultation and dynamic assessment. We combine goal mapping, workplace or academic context, and preferred learning modalities to craft a personalised roadmap aligned with the CEFR framework.'
    },
    {
      question: 'Do you offer hybrid or fully online learning experiences?',
      answer:
        'Yes. Learners can attend in-person sessions in Amsterdam, join live virtual classrooms, or blend both. Our platform synchronises progress, homework, and mentor feedback regardless of delivery mode.'
    },
    {
      question: 'Can organisations request bespoke corporate language programmes?',
      answer:
        'Absolutely. We co-design programmes with HR and leadership teams to reflect brand tone, industry terminology, and cross-cultural competencies—including executive coaching, onboarding, and relocation pathways.'
    }
  ];

  const instructorHighlights = [
    {
      id: 1,
      name: 'Eva Janssen',
      speciality: 'Dutch for global professionals',
      image: 'https://picsum.photos/seed/language-instructor-1/420/420'
    },
    {
      id: 2,
      name: 'Lucas Martins',
      speciality: 'Business English & presentation coaching',
      image: 'https://picsum.photos/seed/language-instructor-2/420/420'
    },
    {
      id: 3,
      name: 'Aisha Rahman',
      speciality: 'Arabic cultural immersion journeys',
      image: 'https://picsum.photos/seed/language-instructor-3/420/420'
    }
  ];

  const filteredStories =
    activeStoryFilter === 'All'
      ? successStories
      : successStories.filter((story) => story.category === activeStoryFilter);

  const toggleFaq = (index) => {
    setExpandedFaq((prev) => (prev === index ? null : index));
  };

  const formatStat = (index) => {
    const value = counters[index];
    if (statsData[index].label === 'Hours of immersive coaching') {
      return `${value.toLocaleString()}+`;
    }
    if (statsData[index].label === 'Corporate & academic partners') {
      return `${value}+`;
    }
    return value.toLocaleString();
  };

  return (
    <>
      <Seo
        title="Home"
        description="Discover a modern, proficiency-first approach to language learning in the Netherlands. Explore immersive courses, expert instructors, and tailored programmes."
      />
      <div className={styles.page}>
        <section className={styles.hero} aria-labelledby="hero-heading">
          <div className={styles.heroOverlay} />
          <div className={styles.heroContent}>
            <p className={styles.heroLabel}>Amsterdam · Rotterdam · Online Worldwide</p>
            <h1 id="hero-heading">Learn Languages with Effortless Mastery</h1>
            <p className={styles.heroSubtitle}>
              Immerse yourself in language experiences designed for lasting proficiency. Our adaptive coaching,
              cultural intelligence, and real-life simulations help you speak with clarity and confidence.
            </p>
            <div className={styles.heroActions}>
              <Link to="/courses" className={styles.primaryCta}>
                Explore Our Courses
              </Link>
              <Link to="/methodology" className={styles.secondaryCta}>
                How we teach
              </Link>
            </div>
            <div className={styles.heroStats} role="group" aria-label="Key impact metrics">
              {statsData.map((stat, index) => (
                <div className={styles.heroStat} key={stat.label}>
                  <span className={styles.heroStatValue}>{formatStat(index)}</span>
                  <span className={styles.heroStatLabel}>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.intro} aria-labelledby="intro-heading">
          <div className={styles.sectionHeader}>
            <p className={styles.eyebrow}>Our Promise</p>
            <h2 id="intro-heading">Purposeful language experiences grounded in human connection</h2>
          </div>
          <div className={styles.introGrid}>
            <p>
              At Learn Languages with Effortless Mastery, we see language as a living bridge between people,
              careers, and cultures. Our programmes blend research-backed methodology, compassionate coaching,
              and personalised pathways that adapt to your context. From international assignments to local
              community engagement, we help you speak with nuance and authenticity.
            </p>
            <div className={styles.introCard}>
              <h3>Why learners trust us</h3>
              <ul>
                <li>Proficiency-first curriculum mapped to the CEFR framework</li>
                <li>Expert facilitators blending linguistic mastery with cultural insight</li>
                <li>Flexible delivery across Amsterdam hubs, on-site, and virtual classrooms</li>
                <li>Progress analytics and mentoring to sustain long-term fluency</li>
              </ul>
              <Link to="/about" className={styles.linkButton}>
                Discover our story
              </Link>
            </div>
          </div>
        </section>

        <section className={styles.features} aria-labelledby="features-heading">
          <div className={styles.sectionHeader}>
            <p className={styles.eyebrow}>Learning advantages</p>
            <h2 id="features-heading">Built to unlock fluent, confident communication</h2>
          </div>
          <div className={styles.featureGrid}>
            {[
              {
                title: 'Proficiency-driven design',
                description:
                  'We align to real-life objectives and measure progress through authentic tasks, moving beyond memorisation into habitual fluency.'
              },
              {
                title: 'Personalised learning paths',
                description:
                  'Adaptive roadmaps consider your schedule, motivations, and learning style, ensuring every session feels relevant and energising.'
              },
              {
                title: 'Expert instructors',
                description:
                  'Our linguists, coaches, and cultural consultants bring international experience and mentor-style guidance to every interaction.'
              },
              {
                title: 'Flexible scheduling',
                description:
                  'Blend in-person, live online, and on-demand modules to build a learning rhythm that fits around work, study, and life commitments.'
              }
            ].map((feature) => (
              <article key={feature.title} className={styles.featureCard}>
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.languagesSection} aria-labelledby="languages-heading">
          <div className={styles.sectionHeader}>
            <p className={styles.eyebrow}>Languages & dialects</p>
            <h2 id="languages-heading">A spectrum of languages tailored to your goals</h2>
            <p>
              From globally spoken languages to treasured regional dialects, we curate pathways that honour the
              linguistic diversity of the Netherlands and beyond.
            </p>
          </div>
          <div className={styles.languagesGrid}>
            {languages.map((language) => (
              <div className={styles.languageCard} key={language}>
                <span>{language}</span>
              </div>
            ))}
          </div>
        </section>

        <section className={styles.processSection} aria-labelledby="process-heading">
          <div className={styles.sectionHeader}>
            <p className={styles.eyebrow}>Learning journey</p>
            <h2 id="process-heading">A guided path from discovery to mastery</h2>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.title} className={styles.processCard}>
                <div className={styles.processIcon} aria-hidden="true">
                  {step.icon}
                </div>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.successStories} aria-labelledby="success-heading">
          <div className={styles.sectionHeader}>
            <p className={styles.eyebrow}>Success stories</p>
            <h2 id="success-heading">Real-world impact across sectors</h2>
          </div>
          <div className={styles.filters} role="group" aria-label="Filter success stories by category">
            {['All', 'Corporate', 'Academic', 'Community'].map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${
                  activeStoryFilter === category ? styles.filterButtonActive : ''
                }`}
                onClick={() => setActiveStoryFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.storiesGrid}>
            {filteredStories.map((story) => (
              <article key={story.id} className={styles.storyCard}>
                <div className={styles.storyImageWrapper}>
                  <img src={story.image} alt={story.title} loading="lazy" />
                </div>
                <div className={styles.storyContent}>
                  <span className={styles.storyCategory}>{story.category}</span>
                  <h3>{story.title}</h3>
                  <p>{story.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.instructorsPreview} aria-labelledby="instructors-heading">
          <div className={styles.sectionHeader}>
            <p className={styles.eyebrow}>Mentors</p>
            <h2 id="instructors-heading">Meet the minds guiding your growth</h2>
            <p>
              Our multilingual team unites linguistics, coaching, and cultural intelligence to shape enriching,
              human-centric learning experiences.
            </p>
          </div>
          <div className={styles.instructorGrid}>
            {instructorHighlights.map((instructor) => (
              <article key={instructor.id} className={styles.instructorCard}>
                <img src={instructor.image} alt={instructor.name} loading="lazy" />
                <div className={styles.instructorInfo}>
                  <h3>{instructor.name}</h3>
                  <p>{instructor.speciality}</p>
                </div>
              </article>
            ))}
          </div>
          <Link to="/instructors" className={styles.linkButton}>
            Explore all instructors
          </Link>
        </section>

        <section className={styles.testimonialsSection} aria-labelledby="testimonials-heading">
          <div className={styles.sectionHeader}>
            <p className={styles.eyebrow}>Testimonials</p>
            <h2 id="testimonials-heading">Stories from learners who now speak with confidence</h2>
          </div>
          <div className={styles.testimonialCarousel} role="region" aria-live="polite">
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  activeTestimonial === index ? styles.testimonialActive : ''
                }`}
              >
                <img src={testimonial.image} alt={`${testimonial.name}`} loading="lazy" />
                <blockquote>
                  <p>“{testimonial.quote}”</p>
                </blockquote>
                <div className={styles.testimonialMeta}>
                  <span className={styles.testimonialName}>{testimonial.name}</span>
                  <span className={styles.testimonialRole}>{testimonial.role}</span>
                </div>
              </article>
            ))}
            <div className={styles.carouselControls} role="group" aria-label="Testimonials controls">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  aria-label={`Show testimonial ${index + 1}`}
                  className={`${styles.carouselDot} ${
                    activeTestimonial === index ? styles.carouselDotActive : ''
                  }`}
                  onClick={() => setActiveTestimonial(index)}
                />
              ))}
            </div>
          </div>
        </section>

        <section className={styles.faqSection} aria-labelledby="faq-heading">
          <div className={styles.sectionHeader}>
            <p className={styles.eyebrow}>FAQ</p>
            <h2 id="faq-heading">Answers to common language learning questions</h2>
          </div>
          <div className={styles.faqList}>
            {faqs.map((faq, index) => (
              <article key={faq.question} className={styles.faqItem}>
                <button
                  type="button"
                  onClick={() => toggleFaq(index)}
                  aria-expanded={expandedFaq === index}
                  className={styles.faqTrigger}
                >
                  <span>{faq.question}</span>
                  <span aria-hidden="true">{expandedFaq === index ? '−' : '+'}</span>
                </button>
                <div
                  className={`${styles.faqContent} ${expandedFaq === index ? styles.faqOpen : ''}`}
                  role="region"
                  aria-hidden={expandedFaq === index ? 'false' : 'true'}
                >
                  <p>{faq.answer}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.blogSection} aria-labelledby="blog-heading">
          <div className={styles.sectionHeader}>
            <p className={styles.eyebrow}>Insights</p>
            <h2 id="blog-heading">Latest perspectives on language mastery</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <div className={styles.blogImageWrapper}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.blogContent}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.blogLink}>
                    Continue reading →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.ctaSection} aria-labelledby="cta-heading">
          <div className={styles.ctaCard}>
            <h2 id="cta-heading">Ready to design your language mastery journey?</h2>
            <p>
              Book a discovery call, meet the facilitators, and receive a tailored blueprint to launch your next
              level of linguistic confidence.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/contact" className={styles.primaryCta}>
                Start the conversation
              </Link>
              <Link to="/courses" className={styles.secondaryCta}>
                View all courses
              </Link>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default HomePage;