import React from 'react';
import Seo from '../components/Seo';
import styles from './PolicyPages.module.css';

const TermsOfServicePage = () => (
  <>
    <Seo
      title="Terms of Service"
      description="Review the Terms of Service for Learn Languages with Effortless Mastery."
    />
    <section className={styles.policySection} aria-labelledby="terms-heading">
      <h1 id="terms-heading">Terms of Service</h1>
      <p>Effective date: 8 May 2024</p>

      <h2>1. Introduction</h2>
      <p>
        These Terms of Service govern participation in programmes operated by Learn Languages with Effortless
        Mastery (“we”, “our”, “us”). By enrolling in our courses, coaching, or events, you agree to these terms.
      </p>

      <h2>2. Programme enrolment</h2>
      <ul>
        <li>Enrolment becomes final once confirmation and payment arrangements have been received.</li>
        <li>Participants agree to provide accurate information for placement and administrative purposes.</li>
        <li>
          Access to online platforms is for individual use only and may not be shared without prior written
          consent.
        </li>
      </ul>

      <h2>3. Scheduling and attendance</h2>
      <p>
        We collaborate with participants to schedule sessions that align with mutually agreed timetables. Missed
        sessions require at least 24 hours’ notice; otherwise, the session may be considered delivered.
      </p>

      <h2>4. Fees and payment</h2>
      <p>
        Programme fees are communicated during proposal stages and may vary depending on delivery format, group
        size, and customisation. Invoices are payable within the terms indicated. All prices are stated in euros
        and inclusive of VAT where applicable.
      </p>

      <h2>5. Intellectual property</h2>
      <p>
        Course materials, digital resources, and recorded sessions are protected by intellectual property laws.
        Participants may not reproduce, distribute, or sell materials without written permission.
      </p>

      <h2>6. Code of conduct</h2>
      <p>
        We provide supportive learning spaces. Discriminatory, abusive, or disruptive behaviour is not tolerated
        and may result in removal from the programme without refund.
      </p>

      <h2>7. Liability</h2>
      <p>
        While we tailor programmes to specific goals, we do not guarantee specific examination results or career
        outcomes. Our liability is limited to the amount paid for the services in question.
      </p>

      <h2>8. Changes to terms</h2>
      <p>
        We may update these terms to reflect changes in services or regulations. The revised terms will be posted
        on this page with an updated effective date.
      </p>

      <h2>9. Contact</h2>
      <p>
        Questions about these Terms of Service can be directed to{' '}
        <a href="mailto:info@languageMastery.nl">info@languageMastery.nl</a>.
      </p>
    </section>
  </>
);

export default TermsOfServicePage;