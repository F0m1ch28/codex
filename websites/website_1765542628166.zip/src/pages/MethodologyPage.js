import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './MethodologyPage.module.css';

const MethodologyPage = () => {
  const [activeAccordion, setActiveAccordion] = useState(null);

  const toggleAccordion = (index) => {
    setActiveAccordion((prev) => (prev === index ? null : index));
  };

  const pillars = [
    {
      title: 'Proficiency-first design',
      description:
        'We reverse engineer every module from the communicative outcomes you seek—presenting in Dutch, leading negotiations, or weaving heritage stories with family.'
    },
    {
      title: 'Contextual immersion',
      description:
        'Sessions integrate real documents, recordings, and scenarios from your world, ensuring vocabulary, intonation, and customs align with how you live and work.'
    },
    {
      title: 'Adaptive mentoring',
      description:
        'Our facilitators track micro-progress across listening, speaking, reading, and writing, adjusting activities weekly to maintain challenge and motivation.'
    }
  ];

  const learningMoments = [
    'Diagnostic conversation & CEFR baseline',
    'Personalised roadmap & milestone mapping',
    'Immersive scenario labs with feedback loops',
    'Reflective journals & pronunciation clinics',
    'Analytics review & sustaining strategies'
  ];

  const faqs = [
    {
      question: 'Do you provide assessments aligned with international standards?',
      answer:
        'Yes. We align with CEFR descriptors, and upon request we provide progress reports that map learning outcomes to recognised certification levels.'
    },
    {
      question: 'How is technology integrated into the learning journey?',
      answer:
        'Our digital campus hosts recordings, interactive exercises, and mentor notes. Learners can submit audio reflections, track weekly focus points, and access cultural briefings.'
    },
    {
      question: 'Can I combine courses to build a customised pathway?',
      answer:
        'Absolutely. Work with our advisors to combine foundational, professional, and cultural modules. We will stitch them into a cohesive roadmap with consistent mentoring.'
    }
  ];

  return (
    <>
      <Seo
        title="Methodology"
        description="Explore the Effortless Mastery methodology: personalised diagnostics, immersive practice, adaptive mentoring, and analytics that turn goals into fluent communication."
      />
      <section className={styles.hero} aria-labelledby="methodology-heading">
        <div className={styles.heroText}>
          <h1 id="methodology-heading">The Effortless Mastery methodology</h1>
          <p>
            Our framework merges cognitive science, design thinking, and intercultural intelligence. The result is
            a learning journey that feels natural, purposeful, and data-informed—helping you activate proficiency
            in meaningful contexts.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/seed/methodology-language/900/560"
            alt="Instructor guiding learners through immersive language practice"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.pillarsSection} aria-labelledby="pillars-heading">
        <div className={styles.sectionIntro}>
          <p className={styles.eyebrow}>Core pillars</p>
          <h2 id="pillars-heading">What makes Effortless Mastery truly effective</h2>
        </div>
        <div className={styles.pillarsGrid}>
          {pillars.map((pillar) => (
            <article key={pillar.title} className={styles.pillarCard}>
              <h3>{pillar.title}</h3>
              <p>{pillar.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.processSection} aria-labelledby="process-heading">
        <div className={styles.sectionIntro}>
          <p className={styles.eyebrow}>Our process</p>
          <h2 id="process-heading">A clear pathway from discovery to sustained fluency</h2>
        </div>
        <ol className={styles.processList}>
          {learningMoments.map((moment, index) => (
            <li key={moment}>
              <span className={styles.stepNumber}>{index + 1}</span>
              <div className={styles.stepContent}>
                <h3>{moment}</h3>
                <p>
                  We anchor each stage with measurable indicators, reflective prompts, and mentor feedback. This
                  ensures you always understand what success looks like and how to maintain momentum.
                </p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section className={styles.labsSection} aria-labelledby="labs-heading">
        <div className={styles.labsGrid}>
          <div>
            <p className={styles.eyebrow}>Immersive labs</p>
            <h2 id="labs-heading">Learning spaces where language comes alive</h2>
            <p>
              Beyond structured lessons, our labs simulate real-world contexts, enabling spontaneous language use.
              Learners test ideas, make mistakes safely, and receive immediate coaching while building cultural
              agility.
            </p>
            <ul className={styles.labList}>
              <li>Conversation studios for dynamic role-play and pronunciation mastery</li>
              <li>Presentation theatre with video replay and vocal coaching</li>
              <li>Cultural immersion workshops featuring guest speakers and community partners</li>
            </ul>
          </div>
          <div className={styles.labImage}>
            <img
              src="https://picsum.photos/seed/methodology-lab/720/520"
              alt="Learners collaborating in a language lab"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.accordionSection} aria-labelledby="methodology-faq-heading">
        <div className={styles.sectionIntro}>
          <p className={styles.eyebrow}>FAQ</p>
          <h2 id="methodology-faq-heading">Your methodology questions answered</h2>
        </div>
        <div className={styles.accordion}>
          {faqs.map((faq, index) => (
            <article key={faq.question} className={styles.accordionItem}>
              <button
                type="button"
                className={styles.accordionTrigger}
                onClick={() => toggleAccordion(index)}
                aria-expanded={activeAccordion === index}
              >
                {faq.question}
                <span aria-hidden="true">{activeAccordion === index ? '−' : '+'}</span>
              </button>
              <div
                className={`${styles.accordionContent} ${
                  activeAccordion === index ? styles.open : ''
                }`}
              >
                <p>{faq.answer}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default MethodologyPage;