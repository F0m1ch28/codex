import React from 'react';
import Seo from '../components/Seo';
import styles from './PolicyPages.module.css';

const PrivacyPolicyPage = () => (
  <>
    <Seo
      title="Privacy Policy"
      description="Learn how Learn Languages with Effortless Mastery collects, uses, and safeguards personal information."
    />
    <section className={styles.policySection} aria-labelledby="privacy-heading">
      <h1 id="privacy-heading">Privacy Policy</h1>
      <p>Effective date: 8 May 2024</p>

      <h2>1. Overview</h2>
      <p>
        This Privacy Policy explains how Learn Languages with Effortless Mastery processes personal data related to
        our language programmes, events, and online platforms in accordance with applicable EU and Dutch privacy
        legislation.
      </p>

      <h2>2. Data we collect</h2>
      <ul>
        <li>Contact details such as name, email address, phone number, and organisation.</li>
        <li>Information about language goals, proficiency levels, and course preferences.</li>
        <li>
          Usage data from digital learning platforms to monitor progress, personalise content, and improve services.
        </li>
      </ul>

      <h2>3. How we use data</h2>
      <ul>
        <li>To deliver, coordinate, and evaluate language programmes.</li>
        <li>To communicate updates, schedules, and relevant learning resources.</li>
        <li>To comply with legal obligations and maintain the security of our services.</li>
      </ul>

      <h2>4. Sharing data</h2>
      <p>
        We do not sell personal data. We may share information with trusted service providers (e.g., learning
        platforms, payment processors) who operate under strict confidentiality agreements. Data may also be shared
        where required by law.
      </p>

      <h2>5. Retention</h2>
      <p>
        Personal data is retained only as long as necessary for programme delivery, compliance obligations, and
        legitimate business interests. You may request deletion subject to regulatory requirements.
      </p>

      <h2>6. Your rights</h2>
      <p>
        You have the right to access, rectify, or request deletion of your personal data. You may withdraw consent
        for communications at any time via the unsubscribe option or by contacting us directly.
      </p>

      <h2>7. Security</h2>
      <p>
        We implement technical and organisational measures—encryption, access controls, staff training—to protect
        personal data against loss, misuse, or unauthorised access.
      </p>

      <h2>8. Contact</h2>
      <p>
        For privacy enquiries, data requests, or concerns, please contact{' '}
        <a href="mailto:info@languageMastery.nl">info@languageMastery.nl</a>.
      </p>
    </section>
  </>
);

export default PrivacyPolicyPage;