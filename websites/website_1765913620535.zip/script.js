const cookieBanner = document.getElementById('cookieBanner');
const cookieAccept = document.getElementById('cookieAccept');
const cookieDecline = document.getElementById('cookieDecline');
const cookieChoice = localStorage.getItem('cookieChoice');

if (cookieBanner && !cookieChoice) {
    setTimeout(() => {
        cookieBanner.classList.add('active');
    }, 600);
}

const handleCookieDecision = (decision) => {
    localStorage.setItem('cookieChoice', decision);
    if (cookieBanner) {
        cookieBanner.classList.remove('active');
    }
};

if (cookieAccept) {
    cookieAccept.addEventListener('click', () => handleCookieDecision('accepted'));
}

if (cookieDecline) {
    cookieDecline.addEventListener('click', () => handleCookieDecision('declined'));
}

if (cookieChoice && cookieBanner) {
    cookieBanner.classList.remove('active');
}

const gameRoundEl = document.getElementById('gameRound');
const gameScoreEl = document.getElementById('gameScore');
const gameStreakEl = document.getElementById('gameStreak');
const questionTextEl = document.getElementById('questionText');
const optionsListEl = document.getElementById('optionsList');
const startGameBtn = document.getElementById('startGame');
const skipQuestionBtn = document.getElementById('skipQuestion');
const resetGameBtn = document.getElementById('resetGame');
const gameLogEl = document.getElementById('gameLog');

const gameState = {
    active: false,
    round: 0,
    score: 0,
    streak: 0,
    currentQuestion: null,
    lock: false
};

const questions = [
    {
        prompt: 'Какой запрос вырос в понедельник утром в Москве?',
        options: [
            { text: 'Пробки на МКАД сейчас', score: 120, correct: true },
            { text: 'Где блины рядом', score: 65, correct: false },
            { text: 'Новый клип Моргенштерна', score: 40, correct: false },
            { text: 'Солнечное затмение декабрь', score: 50, correct: false }
        ],
        insight: 'Утренние пробки в мегаполисах стабильно в топе, особенно в начале рабочей недели.'
    },
    {
        prompt: 'Что искали в день премьеры нового фильма MARVEL?',
        options: [
            { text: 'Купить билеты в кино', score: 110, correct: true },
            { text: 'Расписание электричек', score: 20, correct: false },
            { text: 'Как приготовить пасту', score: 30, correct: false },
            { text: 'Гороскоп на завтра', score: 45, correct: false }
        ],
        insight: 'Премьеры блокбастеров всегда сопровождаются всплеском интереса к билетам и отзывам.'
    },
    {
        prompt: 'Что вызывает рост в регионе Сочи в жаркий день?',
        options: [
            { text: 'Температура Чёрного моря сегодня', score: 105, correct: true },
            { text: 'Сценарий деловой встречи', score: 25, correct: false },
            { text: 'Рецепт шоколадного торта', score: 18, correct: false },
            { text: 'Новости сахалинского туризма', score: 30, correct: false }
        ],
        insight: 'Сезонный интерес к погоде и морю в курортных регионах достигает пиков летом.'
    },
    {
        prompt: 'Какой запрос усиливается во время неожиданного снегопада?',
        options: [
            { text: 'ЦОД в Ленобласти', score: 15, correct: false },
            { text: 'Снегоуборочные службы рядом', score: 130, correct: true },
            { text: 'Игра престолов пересказ', score: 22, correct: false },
            { text: 'Эфиопский кофе купить', score: 28, correct: false }
        ],
        insight: 'Погодные аномалии моментально влияют на запросы о коммунальных и дорожных службах.'
    },
    {
        prompt: 'Что выбирают пользователи в пятничный вечер?',
        options: [
            { text: 'Карта пробок Санкт-Петербург', score: 70, correct: false },
            { text: 'Бары с живой музыкой', score: 115, correct: true },
            { text: 'Оформить ОСАГО онлайн', score: 32, correct: false },
            { text: 'Удалить аккаунт', score: 12, correct: false }
        ],
        insight: 'После окончания рабочей недели усиливается интерес к развлечениям и вечерним активностям.'
    },
    {
        prompt: 'Что чаще всего спрашивают родители школьников в августе?',
        options: [
            { text: 'Список учебников 5 класс', score: 125, correct: true },
            { text: 'Зимние куртки распродажа', score: 20, correct: false },
            { text: 'Восстановление водительских прав', score: 18, correct: false },
            { text: 'Как выращивать лавр дома', score: 12, correct: false }
        ],
        insight: 'Август — сезон подготовки к школе, отчего запросы учебных материалов вырастают кратно.'
    },
    {
        prompt: 'Что чаще выбирают пользователи при запуске крупной распродажи?',
        options: [
            { text: 'Промокоды маркетплейс', score: 140, correct: true },
            { text: 'Прослушать новую аудиокнигу', score: 45, correct: false },
            { text: 'Пересадка помидоров в теплице', score: 18, correct: false },
            { text: 'Расписание спортивных матчей', score: 32, correct: false }
        ],
        insight: 'Скидочные акции провоцируют всплеск поиска промокодов, купонов и условий акций.'
    },
    {
        prompt: 'Какой запрос растёт во время крупного спортивного финала?',
        options: [
            { text: 'Где смотреть матч онлайн', score: 138, correct: true },
            { text: 'Вязание крючком схемы', score: 16, correct: false },
            { text: 'Рецепт гаспачо', score: 24, correct: false },
            { text: 'Карта метро Екатеринбург', score: 35, correct: false }
        ],
        insight: 'В дни финальных матчей наблюдается резкий рост онлайн-поиска трансляций.'
    }
];

const randomQuestion = () => {
    const index = Math.floor(Math.random() * questions.length);
    return JSON.parse(JSON.stringify(questions[index]));
};

const logMessage = (message) => {
    if (!gameLogEl) return;
    const time = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    const entry = document.createElement('p');
    entry.textContent = `[${time}] ${message}`;
    gameLogEl.prepend(entry);
};

const updateStatus = () => {
    if (gameRoundEl) gameRoundEl.textContent = gameState.round;
    if (gameScoreEl) gameScoreEl.textContent = gameState.score;
    if (gameStreakEl) gameStreakEl.textContent = gameState.streak;
};

const clearOptions = () => {
    if (!optionsListEl) return;
    optionsListEl.innerHTML = '';
};

const renderQuestion = (question) => {
    if (!questionTextEl || !optionsListEl) return;
    questionTextEl.textContent = question.prompt;
    clearOptions();
    question.options.forEach((option) => {
        const button = document.createElement('button');
        button.className = 'option-button';
        button.textContent = option.text;
        button.addEventListener('click', () => handleAnswer(option, button));
        optionsListEl.appendChild(button);
    });
};

const handleAnswer = (option, button) => {
    if (gameState.lock) return;
    gameState.lock = true;

    const otherButtons = optionsListEl ? optionsListEl.querySelectorAll('.option-button') : [];
    otherButtons.forEach((btn) => btn.disabled = true);

    if (option.correct) {
        button.classList.add('correct');
        gameState.score += option.score;
        gameState.streak += 1;
        logMessage(`Верно! Вы получили ${option.score} очков. Инсайт: ${gameState.currentQuestion.insight}`);
    } else {
        button.classList.add('incorrect');
        gameState.streak = 0;
        logMessage(`Мимо! Тренд: ${gameState.currentQuestion.options.find(opt => opt.correct).text}.`);
    }

    updateStatus();
};

const nextRound = () => {
    gameState.currentQuestion = randomQuestion();
    renderQuestion(gameState.currentQuestion);
    gameState.round += 1;
    gameState.lock = false;
    updateStatus();
    logMessage(`Новый раунд №${gameState.round}. Категория: тренды поиска.`);
};

const startGame = () => {
    if (gameState.active) {
        nextRound();
        return;
    }
    gameState.active = true;
    gameState.round = 0;
    gameState.score = 0;
    gameState.streak = 0;
    logMessage('Старт игры. Удачи!');
    nextRound();
};

const skipQuestion = () => {
    if (!gameState.active) {
        logMessage('Нельзя пропустить до старта игры.');
        return;
    }
    logMessage('Вы пропустили текущий вопрос. Без изменения счёта.');
    nextRound();
};

const resetGame = () => {
    gameState.active = false;
    gameState.round = 0;
    gameState.score = 0;
    gameState.streak = 0;
    gameState.currentQuestion = null;
    gameState.lock = false;
    updateStatus();
    clearOptions();
    if (questionTextEl) {
        questionTextEl.textContent = 'Прогресс сброшен. Нажмите «Старт», чтобы начать заново.';
    }
    logMessage('Прогресс очищен по запросу игрока.');
};

if (startGameBtn) {
    startGameBtn.addEventListener('click', startGame);
}

if (skipQuestionBtn) {
    skipQuestionBtn.addEventListener('click', skipQuestion);
}

if (resetGameBtn) {
    resetGameBtn.addEventListener('click', resetGame);
}