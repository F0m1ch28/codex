document.documentElement.classList.add('js');

document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.getElementById('primary-menu');
  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('is-open');
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const cookieAccept = document.getElementById('cookie-accept');
  const cookieDecline = document.getElementById('cookie-decline');
  const cookieChoice = localStorage.getItem('dis-cookie-preference');

  if (cookieBanner) {
    if (cookieChoice) {
      cookieBanner.classList.add('is-hidden');
    }

    if (cookieAccept) {
      cookieAccept.addEventListener('click', () => {
        localStorage.setItem('dis-cookie-preference', 'accepted');
        cookieBanner.classList.add('is-hidden');
      });
    }

    if (cookieDecline) {
      cookieDecline.addEventListener('click', () => {
        localStorage.setItem('dis-cookie-preference', 'declined');
        cookieBanner.classList.add('is-hidden');
      });
    }
  }

  document.querySelectorAll('[data-tab-group]').forEach((group) => {
    const tabs = group.querySelectorAll('[role="tab"]');
    const panels = group.querySelectorAll('[role="tabpanel"]');

    if (!tabs.length || !panels.length) return;

    const setActiveTab = (newTab) => {
      tabs.forEach((tab) => {
        const isActive = tab === newTab;
        tab.setAttribute('aria-selected', String(isActive));
        tab.setAttribute('tabindex', isActive ? '0' : '-1');
      });

      panels.forEach((panel) => {
        panel.hidden = panel.id !== newTab.getAttribute('aria-controls');
      });
    };

    tabs.forEach((tab) => {
      tab.addEventListener('click', () => setActiveTab(tab));
      tab.addEventListener('keydown', (event) => {
        const currentIndex = Array.from(tabs).indexOf(tab);
        if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
          event.preventDefault();
          const next = tabs[(currentIndex + 1) % tabs.length];
          next.focus();
          setActiveTab(next);
        }
        if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
          event.preventDefault();
          const previous = tabs[(currentIndex - 1 + tabs.length) % tabs.length];
          previous.focus();
          setActiveTab(previous);
        }
      });
    });

    setActiveTab(tabs[0]);
  });

  document.querySelectorAll('.accordion').forEach((accordion) => {
    const button = accordion.querySelector('.accordion-button');
    const content = accordion.querySelector('.accordion-content');

    if (button && content) {
      content.hidden = true;
      button.setAttribute('aria-expanded', 'false');

      button.addEventListener('click', () => {
        const isExpanded = button.getAttribute('aria-expanded') === 'true';
        button.setAttribute('aria-expanded', String(!isExpanded));
        accordion.classList.toggle('is-open', !isExpanded);
        content.hidden = isExpanded;
      });
    }
  });

  document.querySelectorAll('[data-case-toggle]').forEach((button) => {
    const targetId = button.getAttribute('data-case-toggle');
    const target = document.getElementById(targetId);

    if (target) {
      target.hidden = true;
      button.setAttribute('aria-expanded', 'false');

      button.addEventListener('click', () => {
        const isExpanded = button.getAttribute('aria-expanded') === 'true';
        button.setAttribute('aria-expanded', String(!isExpanded));
        target.hidden = isExpanded;
        button.classList.toggle('is-active', !isExpanded);
      });
    }
  });

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    const formMessage = document.getElementById('form-message');
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const formData = new FormData(contactForm);

      const name = (formData.get('name') || '').trim();
      const email = (formData.get('email') || '').trim();
      const company = (formData.get('company') || '').trim();
      const message = (formData.get('message') || '').trim();
      const consent = contactForm.querySelector('input[name="consent"]:checked');

      const errors = [];
      if (!name) errors.push('Name is required.');
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('A valid email address is required.');
      if (!company) errors.push('Company name is required.');
      if (message.length < 20) errors.push('Please provide a message with at least 20 characters so we can prepare a relevant response.');
      if (!consent) errors.push('Consent for Dominion Insight Services to contact you is required.');

      if (errors.length) {
        formMessage.textContent = errors.join(' ');
        formMessage.className = 'form-message is-error';
        formMessage.setAttribute('role', 'alert');
        return;
      }

      formMessage.textContent = 'Thank you for connecting with Dominion Insight Services. A strategist will respond within one Canadian business day.';
      formMessage.className = 'form-message is-success';
      formMessage.setAttribute('role', 'status');
      contactForm.reset();
    });
  }
});