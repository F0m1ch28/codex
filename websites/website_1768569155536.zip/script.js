document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const navLinks = document.querySelectorAll(".nav-link");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const isOpen = siteNav.classList.toggle("open");
            navToggle.setAttribute("aria-expanded", isOpen.toString());
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (siteNav.classList.contains("open")) {
                    siteNav.classList.remove("open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-button.accept");
    const declineBtn = document.querySelector(".cookie-button.decline");
    const cookieConsent = localStorage.getItem("placedhnqf_cookie_pref");

    if (!cookieConsent && cookieBanner) {
        cookieBanner.classList.add("active");
    }

    const handleCookieChoice = (choice) => {
        localStorage.setItem("placedhnqf_cookie_pref", choice);
        if (cookieBanner) {
            cookieBanner.classList.remove("active");
        }
    };

    if (acceptBtn) {
        acceptBtn.addEventListener("click", () => handleCookieChoice("accepted"));
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", () => handleCookieChoice("declined"));
    }
});