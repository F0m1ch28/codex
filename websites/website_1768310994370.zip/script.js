document.addEventListener("DOMContentLoaded", () => {
    const header = document.querySelector(".site-header");
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const navLinks = document.querySelectorAll(".site-nav a");
    const fadeBlocks = document.querySelectorAll(".fade-in");
    const faqButtons = document.querySelectorAll(".faq-question");
    const cookieBanner = document.getElementById("cookie-banner");
    const acceptBtn = document.querySelector(".cookie-btn.accept");
    const declineBtn = document.querySelector(".cookie-btn.decline");

    if (header) {
        const onScroll = () => {
            if (window.scrollY > 20) {
                header.classList.add("scrolled");
            } else {
                header.classList.remove("scrolled");
            }
        };
        window.addEventListener("scroll", onScroll);
        onScroll();
    }

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            siteNav.classList.toggle("open");
        });

        navLinks.forEach(link => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 960) {
                    siteNav.classList.remove("open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    if (fadeBlocks.length > 0) {
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("visible");
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.2 });

        fadeBlocks.forEach(block => observer.observe(block));
    }

    if (faqButtons.length > 0) {
        faqButtons.forEach(button => {
            button.addEventListener("click", () => {
                const item = button.closest(".faq-item");
                const expanded = item.classList.contains("expanded");
                document.querySelectorAll(".faq-item.expanded").forEach(openItem => {
                    if (openItem !== item) {
                        openItem.classList.remove("expanded");
                    }
                });
                item.classList.toggle("expanded", !expanded);
            });
        });
    }

    const consentKey = "cookieConsent";
    const savedConsent = localStorage.getItem(consentKey);

    if (!savedConsent && cookieBanner) {
        cookieBanner.classList.add("show");
    }

    const handleConsent = decision => {
        localStorage.setItem(consentKey, decision);
        if (cookieBanner) {
            cookieBanner.classList.remove("show");
        }
    };

    if (acceptBtn) {
        acceptBtn.addEventListener("click", () => handleConsent("accepted"));
    }
    if (declineBtn) {
        declineBtn.addEventListener("click", () => handleConsent("declined"));
    }
});