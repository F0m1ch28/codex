import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isOpen, setIsOpen] = React.useState(false);

  const toggleMenu = () => setIsOpen((prev) => !prev);
  const closeMenu = () => setIsOpen(false);

  return (
    <header className={styles.header} role="banner">
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Brivantera Startseite">
          <span className={styles.logoMark}>B</span>
          <span className={styles.logoText}>Brivantera</span>
        </NavLink>
        <button
          className={styles.menuButton}
          aria-label="Menü öffnen"
          onClick={toggleMenu}
          aria-expanded={isOpen}
          aria-controls="hauptnavigation"
        >
          <span className={styles.menuIcon} />
        </button>
        <nav
          id="hauptnavigation"
          className={`${styles.navigation} ${isOpen ? styles.open : ''}`}
          aria-label="Hauptnavigation"
        >
          <NavLink to="/" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Start
          </NavLink>
          <NavLink to="/kategorien" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Kategorien
          </NavLink>
          <NavLink to="/experten" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Expert:innen
          </NavLink>
          <NavLink to="/projekt" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Projektablauf
          </NavLink>
          <NavLink to="/use-cases" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Use Cases
          </NavLink>
          <NavLink to="/preise" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Leistungsumfang
          </NavLink>
          <NavLink to="/blog" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Blog
          </NavLink>
          <NavLink to="/kontakt" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Kontakt
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;