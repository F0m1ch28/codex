import React from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem('brivantera-consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('brivantera-consent', 'accepted');
    setVisible(false);
  };

  const handleSettings = () => {
    localStorage.setItem('brivantera-consent', 'customized');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie Hinweis">
      <div className={styles.content}>
        <p>
          Wir nutzen Cookies, um Funktionen wie Analytics und Personalisierung für Ihren Markenaufbau bereitzustellen.
          Sie können jederzeit Ihre Einwilligung im Datenschutzbereich anpassen.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={handleAccept} className={styles.primary}>
            Alles akzeptieren
          </button>
          <button type="button" onClick={handleSettings} className={styles.secondary}>
            Einstellungen merken
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;