import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={styles.grid}>
      <div className={styles.brand}>
        <div className={styles.logo}>
          <span className={styles.logoMark}>B</span>
          <span className={styles.logoText}>Brivantera</span>
        </div>
        <p>
          Brivantera ist Ihr kuratierter SaaS-Marktplatz für Personal Branding, Positionierung und
          Content Produktion mit Fokus auf DSGVO-konforme Zusammenarbeit.
        </p>
      </div>
      <div className={styles.column}>
        <h4>Navigation</h4>
        <NavLink to="/kategorien">Kategorien</NavLink>
        <NavLink to="/experten">Expert:innen</NavLink>
        <NavLink to="/use-cases">Use Cases</NavLink>
        <NavLink to="/projekt">Projektablauf</NavLink>
      </div>
      <div className={styles.column}>
        <h4>Ressourcen</h4>
        <NavLink to="/preise">Leistungsumfang</NavLink>
        <NavLink to="/blog">Insights</NavLink>
        <NavLink to="/services">Serviceübersicht</NavLink>
        <NavLink to="/kontakt">Kontakt</NavLink>
      </div>
      <div className={styles.column}>
        <h4>Rechtliches</h4>
        <NavLink to="/impressum">Impressum</NavLink>
        <NavLink to="/datenschutz">Datenschutz</NavLink>
        <NavLink to="/agb">AGB</NavLink>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>&copy; {new Date().getFullYear()} Brivantera. Alle Rechte vorbehalten.</p>
      <span>Kurfürstendamm 26, 10719 Berlin, Deutschland · +49 30 1234 5678</span>
    </div>
  </footer>
);

export default Footer;