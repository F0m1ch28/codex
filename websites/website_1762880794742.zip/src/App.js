import React from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollButton from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Kategorien from './pages/Kategorien';
import Experten from './pages/Experten';
import UseCases from './pages/UseCases';
import Preise from './pages/Preise';
import Blog from './pages/Blog';
import Contact from './pages/Contact';
import Impressum from './pages/Impressum';
import Privacy from './pages/Privacy';
import Terms from './pages/Terms';

function ScrollToTopOnRoute() {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
}

function AppContent() {
  return (
    <>
      <Header />
      <ScrollToTopOnRoute />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/projekt" element={<About />} />
          <Route path="/kategorien" element={<Kategorien />} />
          <Route path="/experten" element={<Experten />} />
          <Route path="/use-cases" element={<UseCases />} />
          <Route path="/preise" element={<Preise />} />
          <Route path="/services" element={<Services />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/kontakt" element={<Contact />} />
          <Route path="/impressum" element={<Impressum />} />
          <Route path="/datenschutz" element={<Privacy />} />
          <Route path="/agb" element={<Terms />} />
        </Routes>
      </main>
      <Footer />
      <ScrollButton />
      <CookieBanner />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}