import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PageCommon.module.css';

const articles = [
  {
    title: 'Personal Branding KPIs: Qualitative und quantitative Messpunkte',
    summary:
      'Welche Messgrößen helfen wirklich, den Erfolg von Positionierung und Content Produktion zu bewerten?'
  },
  {
    title: 'DSGVO in der Content Produktion',
    summary:
      'So gestalten Sie Freigaben, Datenflüsse und Collaboration Tools regelkonform für Ihr Personal Branding.'
  },
  {
    title: 'Design Visual Identity für internationale Teams',
    summary:
      'Wie Sie eine visuelle Identität schaffen, die in mehreren Märkten und Sprachen funktioniert.'
  },
  {
    title: 'PR Platzierung als Multiplikator',
    summary:
      'Von Story Mining bis Medienbriefing – unser Framework für nachhaltige Beziehungen zu Journalist:innen.'
  }
];

const Blog = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Blog &amp; Insights | Brivantera</title>
      <meta
        name="description"
        content="Insights zu Personal Branding, Positionierung, Content Produktion, LinkedIn Branding und DSGVO."
      />
      <link rel="canonical" href="https://www.brivantera.de/blog" />
    </Helmet>
    <header className={styles.pageHeader}>
      <h1>Blog &amp; Insights</h1>
      <p>
        Aktuelles Wissen für Ihren Markenaufbau. Wir teilen Best Practices, Frameworks und Interviews mit Expert:innen aus
        dem Brivantera Netzwerk.
      </p>
    </header>
    <div className={styles.list}>
      {articles.map((article) => (
        <article key={article.title}>
          <h2>{article.title}</h2>
          <p>{article.summary}</p>
          <span className={styles.badge}>Demnächst verfügbar</span>
        </article>
      ))}
    </div>
  </div>
);

export default Blog;