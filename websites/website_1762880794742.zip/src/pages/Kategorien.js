import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PageCommon.module.css';

const Kategorien = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Kategorien | Brivantera Marktplatz</title>
      <meta
        name="description"
        content="Erkunden Sie Kategorien wie Positionierung, Content Produktion, LinkedIn Branding und Social Media Management."
      />
      <link rel="canonical" href="https://www.brivantera.de/kategorien" />
    </Helmet>
    <header className={styles.pageHeader}>
      <h1>Kategorien</h1>
      <p>
        Wählen Sie aus kuratierten Kategorien, um Ihren Personal Branding Prozess in Phasen zu strukturieren. Jedes Modul
        beinhaltet spezialisierte Expert:innen, Tools und Methoden.
      </p>
    </header>
    <ul className={styles.list}>
      <li>
        <h2>Strategische Positionierung</h2>
        <p>
          Analyse, Persona Mapping, Messaging Frameworks und Markenkernentwicklung – Grundlage für jedes Personal Branding.
        </p>
      </li>
      <li>
        <h2>Content Produktion</h2>
        <p>
          Redaktion, Audio, Video, Visual Storytelling – maßgeschneiderte Content-Formate für thought leadership.
        </p>
      </li>
      <li>
        <h2>LinkedIn Branding</h2>
        <p>
          Profil-Optimierung, Content Plan, Netzwerkaufbau und Social Selling – alles für nachhaltige Präsenz.
        </p>
      </li>
      <li>
        <h2>PR Platzierung</h2>
        <p>
          Storylines, Medienkontakte, Gastartikel und Speaker Opportunities – Sichtbarkeit in relevanten Medien.
        </p>
      </li>
      <li>
        <h2>Social Media Management</h2>
        <p>
          Kanalsteuerung, Community Building, Monitoring und Reporting für Ihre digitale Kommunikation.
        </p>
      </li>
      <li>
        <h2>Design Visual Identity</h2>
        <p>
          Visual Guidelines, Templates, Brand Motion und Stilbibliotheken – konsistent und markenstark.
        </p>
      </li>
    </ul>
  </div>
);

export default Kategorien;