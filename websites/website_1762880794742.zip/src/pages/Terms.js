import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PageCommon.module.css';

const Terms = () => (
  <div className={styles.page}>
    <Helmet>
      <title>AGB | Brivantera</title>
      <meta name="description" content="Allgemeine Geschäftsbedingungen der Brivantera GmbH." />
      <link rel="canonical" href="https://www.brivantera.de/agb" />
    </Helmet>
    <header className={styles.pageHeader}>
      <h1>Allgemeine Geschäftsbedingungen</h1>
    </header>
    <section className={styles.section}>
      <h2>1. Geltungsbereich</h2>
      <p>
        Diese Bedingungen gelten für sämtliche Leistungen der Brivantera GmbH im Rahmen des SaaS-Marktplatzes für
        Personal Branding Services.
      </p>
    </section>
    <section className={styles.section}>
      <h2>2. Vertragsabschluss</h2>
      <p>
        Verträge entstehen durch schriftliche Beauftragung oder digitale Bestätigung über unsere Plattform. Der konkrete
        Leistungsumfang wird in einem individuellen Leistungsdokument festgehalten.
      </p>
    </section>
    <section className={styles.section}>
      <h2>3. Leistungsumfang</h2>
      <p>
        Brivantera stellt kuratierte Expert:innen bereit und koordiniert Leistungen wie Positionierung, Content
        Produktion, LinkedIn Branding, PR Platzierung sowie Social Media Management. Änderungen bedürfen einer
        schriftlichen Bestätigung.
      </p>
    </section>
    <section className={styles.section}>
      <h2>4. Vergütung</h2>
      <p>
        Die Vergütung richtet sich nach dem vereinbarten Leistungsdokument. Rechnungen sind innerhalb der dort genannten
        Fristen auszugleichen.
      </p>
    </section>
    <section className={styles.section}>
      <h2>5. Mitwirkungspflichten</h2>
      <p>
        Auftraggebende stellen relevante Informationen, Freigaben und Zugänge rechtzeitig bereit. Verzögerungen aufgrund
        fehlender Mitwirkung verlängern vereinbarte Timelines.
      </p>
    </section>
    <section className={styles.section}>
      <h2>6. Vertraulichkeit</h2>
      <p>
        Beide Parteien verpflichten sich zur Vertraulichkeit über sämtliche Geschäfts- und Projektdaten. Diese Pflicht
        gilt auch nach Beendigung der Zusammenarbeit.
      </p>
    </section>
    <section className={styles.section}>
      <h2>7. Haftung</h2>
      <p>
        Brivantera haftet nur bei Vorsatz oder grober Fahrlässigkeit. Für einfache Fahrlässigkeit wird nur bei
        Verletzung wesentlicher Vertragspflichten gehaftet.
      </p>
    </section>
    <section className={styles.section}>
      <h2>8. Schlussbestimmungen</h2>
      <p>
        Es gilt deutsches Recht. Gerichtsstand ist Berlin. Änderungen dieser AGB bedürfen der Schriftform.
      </p>
    </section>
  </div>
);

export default Terms;