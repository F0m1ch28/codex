import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PageCommon.module.css';

const Impressum = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Impressum | Brivantera</title>
      <meta name="description" content="Impressum der Brivantera GmbH in Berlin." />
      <link rel="canonical" href="https://www.brivantera.de/impressum" />
    </Helmet>
    <header className={styles.pageHeader}>
      <h1>Impressum</h1>
    </header>
    <section className={styles.section}>
      <h2>Angaben gemäß § 5 TMG</h2>
      <p>
        Brivantera GmbH<br />
        Kurfürstendamm 26<br />
        10719 Berlin<br />
        Deutschland
      </p>
      <p>
        Vertreten durch die Geschäftsführung: <br />
        Lea Marquardt
      </p>
      <p>
        Kontakt: <br />
        Telefon: +49 30 1234 5678<br />
        E-Mail: hello@brivantera.de
      </p>
      <p>
        Registereintrag: <br />
        Amtsgericht Berlin-Charlottenburg<br />
        Registernummer: HRB 123456
      </p>
      <p>Umsatzsteuer-ID: DE123456789</p>
    </section>
    <section className={styles.section}>
      <h2>Haftung für Inhalte</h2>
      <p>
        Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten nach den allgemeinen
        Gesetzen verantwortlich. Nach §§ 8 bis 10 TMG sind wir als Diensteanbieter jedoch nicht verpflichtet,
        übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach Umständen zu forschen, die auf eine
        rechtswidrige Tätigkeit hinweisen.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Haftung für Links</h2>
      <p>
        Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb
        können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist
        stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Urheberrecht</h2>
      <p>
        Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen
        Urheberrecht. Beiträge Dritter sind als solche gekennzeichnet. Die Vervielfältigung, Bearbeitung,
        Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen
        Zustimmung.
      </p>
    </section>
  </div>
);

export default Impressum;