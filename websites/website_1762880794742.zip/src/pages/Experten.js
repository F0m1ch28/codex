import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PageCommon.module.css';

const experts = [
  {
    name: 'Elena Bach',
    specialty: 'Personal Branding Strategie',
    focus: 'Executive Positionierung, Thought Leadership Content'
  },
  {
    name: 'Jonas Frey',
    specialty: 'LinkedIn Branding',
    focus: 'Community Management, Kampagnenkonzeption'
  },
  {
    name: 'Amelia Kowa',
    specialty: 'PR Platzierung',
    focus: 'Medienarbeit, Podcast Booking, Ghostwriting'
  },
  {
    name: 'Philipp Mertens',
    specialty: 'Design Visual Identity',
    focus: 'Brand Systems, Templates, Motion Design'
  },
  {
    name: 'Celine Bader',
    specialty: 'Content Produktion',
    focus: 'Redaktion, Video, Audio Storytelling'
  },
  {
    name: 'Tariq Hassan',
    specialty: 'Social Media Management',
    focus: 'Performance Monitoring, Community Care'
  }
];

const Experten = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Expertenverzeichnis | Brivantera</title>
      <meta
        name="description"
        content="Kuratierte Expert:innen für Personal Branding, Positionierung, Content Produktion und Social Media."
      />
      <link rel="canonical" href="https://www.brivantera.de/experten" />
    </Helmet>
    <header className={styles.pageHeader}>
      <h1>Expert:innenverzeichnis</h1>
      <p>
        Lernen Sie die Spezialist:innen kennen, die Ihren Markenaufbau begleiten. Jedes Profil wurde anhand von Referenzen,
        Case Studies und Soft Skills ausgewählt.
      </p>
    </header>
    <div className={styles.grid}>
      {experts.map((expert) => (
        <article key={expert.name} className={styles.tile}>
          <h2>{expert.name}</h2>
          <p className={styles.meta}>{expert.specialty}</p>
          <p>{expert.focus}</p>
          <span className={styles.badge}>Verfügbar</span>
        </article>
      ))}
    </div>
  </div>
);

export default Experten;