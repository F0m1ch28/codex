import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PageCommon.module.css';

const UseCases = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Use Cases | Brivantera Personal Branding</title>
      <meta
        name="description"
        content="Use Cases für Markenaufbau: Scale-ups, Executive Branding, Employer Branding, Investor Relations."
      />
      <link rel="canonical" href="https://www.brivantera.de/use-cases" />
    </Helmet>
    <header className={styles.pageHeader}>
      <h1>Use Cases</h1>
      <p>
        Brivantera unterstützt Marken in unterschiedlichen Phasen – vom Start-up bis zum etablierten Unternehmen.
        Entdecken Sie Use Cases, die zeigen, wie Personal Branding neue Sichtbarkeit schafft.
      </p>
    </header>
    <div className={styles.list}>
      <article>
        <h2>Scale-up Launch</h2>
        <p>
          Positionierung, Content Produktion und PR Platzierung für Start-ups kurz vor der Series B. Fokus auf Investor
          Updates, Product Narrative und CEO-Branding.
        </p>
      </article>
      <article>
        <h2>Executive Repositioning</h2>
        <p>
          C-Level Personal Branding mit Signature Content, Keynote-Entwicklung und LinkedIn Thought Leadership. Ideal für
          Übergaben, Rebrands oder neue Märkte.
        </p>
      </article>
      <article>
        <h2>Employer Branding Stories</h2>
        <p>
          Social Media Management, Employee-Spotlights und Design Visual Identity für Recruiting Kampagnen mit starker Kultur.
        </p>
      </article>
      <article>
        <h2>Investor Relations Narrative</h2>
        <p>
          Storytelling Frameworks, Report Content und PR Platzierung für Finanz- und Innovationsmedien mit klaren Kernbotschaften.
        </p>
      </article>
    </div>
  </div>
);

export default UseCases;