import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsConfig = [
  { label: 'Strategische Markenprojekte', value: 186 },
  { label: 'Zertifizierte Expert:innen', value: 42 },
  { label: 'Erfolgreiche LinkedIn Kampagnen', value: 95 }
];

const testimonials = [
  {
    quote:
      'Brivantera hat unsere Positionierung geschärft und einen konsistenten Markenauftritt für alle Touchpoints gestaltet.',
    name: 'Nina Voigt',
    role: 'CMO, GrowthWave GmbH'
  },
  {
    quote:
      'Die Kombination aus Content Produktion, PR Platzierung und Social Media Management hat unseren Markenaufbau massiv beschleunigt.',
    name: 'Dr. Julian Stein',
    role: 'CEO, MediaLab Innovations'
  },
  {
    quote:
      'Von der Design Visual Identity bis zur Thought Leadership Strategie – Brivantera liefert messbaren Mehrwert.',
    name: 'Maya Keller',
    role: 'Head of Communications, Urban Impact'
  }
];

const faq = [
  {
    question: 'Wie funktioniert die Auswahl der Personal Branding Expert:innen?',
    answer:
      'Alle Expert:innen werden anhand ihrer Referenzen, Branchenkenntnisse und Soft Skills sorgfältig kuratiert. Nach Ihrer Anfrage erhalten Sie ein Matching mit passenden Profilen inklusive Case Studies.'
  },
  {
    question: 'Welche Services umfasst der Marktplatz?',
    answer:
      'Von Positionierung und Messaging über Content Produktion, LinkedIn Branding und PR Platzierung bis hin zu Social Media Management und Design Visual Identity. Sie wählen die Bausteine, wir orchestrieren den Prozess.'
  },
  {
    question: 'Wie stellt Brivantera DSGVO-Konformität sicher?',
    answer:
      'Alle Prozesse sind auf DSGVO ausgerichtet: AV-Verträge, Datensparsamkeit, sichere Kollaborations-Tools und transparente Dokumentation sorgen für rechtssichere Zusammenarbeit.'
  }
];

const Home = () => {
  const [stats, setStats] = React.useState(statsConfig.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = React.useState(0);
  const [openFaq, setOpenFaq] = React.useState(null);

  React.useEffect(() => {
    const duration = 1600;
    const steps = 40;
    const interval = duration / steps;
    let currentStep = 0;

    const intervalId = setInterval(() => {
      currentStep += 1;
      setStats(
        statsConfig.map((stat) =>
          Math.min(
            stat.value,
            Math.floor((stat.value / steps) * currentStep)
          )
        )
      );
      if (currentStep >= steps) {
        clearInterval(intervalId);
      }
    }, interval);

    return () => clearInterval(intervalId);
  }, []);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const toggleFaq = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  const schemaData = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Brivantera',
    url: 'https://www.brivantera.de',
    logo: 'https://www.brivantera.de/logo.png',
    sameAs: [
      'https://www.linkedin.com/company/brivantera',
      'https://twitter.com/brivantera'
    ],
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Kurfürstendamm 26',
      addressLocality: 'Berlin',
      postalCode: '10719',
      addressCountry: 'DE'
    },
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: '+49 30 1234 5678',
      contactType: 'customer service',
      areaServed: 'DE'
    },
    makesOffer: [
      {
        '@type': 'Product',
        name: 'Personal Branding Orchestrierung',
        description:
          'Kuratierte Projekte für Positionierung, Content Produktion, LinkedIn Branding und PR Platzierung.',
        brand: 'Brivantera'
      }
    ],
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': 'https://www.brivantera.de/'
    }
  };

  const faqSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faq.map((item) => ({
      '@type': 'Question',
      name: item.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: item.answer
      }
    }))
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Brivantera | Personal Branding neu gedacht</title>
        <meta
          name="description"
          content="Brivantera ist der SaaS-Marktplatz für Personal Branding, Positionierung, Content Produktion und Social Media Management."
        />
        <meta
          name="keywords"
          content="Personal Branding, Positionierung, Content Produktion, Markenaufbau, LinkedIn Branding, PR Platzierung, Social Media Management, Design Visual Identity, DSGVO"
        />
        <meta property="og:title" content="Brivantera | Personal Branding neu gedacht" />
        <meta
          property="og:description"
          content="Kuratierter Marktplatz für Personal Branding Services – von Positionierung über Content bis PR."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.brivantera.de/" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=21" />
        <meta name="twitter:card" content="summary_large_image" />
        <script type="application/ld+json">{JSON.stringify(schemaData)}</script>
        <script type="application/ld+json">{JSON.stringify(faqSchema)}</script>
        <link rel="canonical" href="https://www.brivantera.de/" />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>
            Personal Branding mit Signalwirkung
            <span>für Menschen und Marken, die vorausdenken.</span>
          </h1>
          <p>
            Brivantera vereint Positionierung, Content Produktion, LinkedIn Branding, PR Platzierung und Design Visual
            Identity in einer orchestrierten Plattform. DSGVO-konform, skalierbar und mit Fokus auf messbare Wirkung.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakt" className={styles.primaryCta}>
              Anfrage starten
            </Link>
            <Link to="/use-cases" className={styles.secondaryCta}>
              Use Cases entdecken
            </Link>
          </div>
          <div className={styles.heroStatus}>
            <span>Kuratiert · Sicher · Wirkungsvoll</span>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Professionelles Team beim Markenstrategie-Workshop"
            className={styles.heroImage}
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.stats} aria-label="Leistungskennzahlen">
        {statsConfig.map((stat, index) => (
          <div key={stat.label} className={styles.statCard}>
            <span className={styles.statValue} aria-live="polite">
              {stats[index]}+
            </span>
            <p>{stat.label}</p>
          </div>
        ))}
      </section>

      <section className={styles.benefits}>
        <div className={styles.sectionHeader}>
          <h2>Warum Brivantera?</h2>
          <p>
            Wir verbinden Personal Branding Expert:innen mit ambitionierten Entscheider:innen und schaffen Strukturen,
            die Markenaufbau, Content Produktion und Social Media Management präzise aussteuern.
          </p>
        </div>
        <div className={styles.cardGrid}>
          <article className={styles.card}>
            <h3>Positionierung mit Tiefenschärfe</h3>
            <p>
              Strateg:innen analysieren Markt, Persona und Narrative und formen ein klares Positionierungsstatement mit
              hoher Relevanz für Ihr Publikum.
            </p>
          </article>
          <article className={styles.card}>
            <h3>Content Engine Ready</h3>
            <p>
              Editorial Teams planen Thought Leadership, Serienformate und kurze Social Snippets, abgestimmt auf
              LinkedIn Branding und PR Platzierung.
            </p>
          </article>
          <article className={styles.card}>
            <h3>Design Visual Identity</h3>
            <p>
              Design-Squads verankern Ihre Marke visuell – inklusive Templates, Motion Snippets und Asset Guidelines im
              Einklang mit Ihrer Markenstrategie.
            </p>
          </article>
          <article className={styles.card}>
            <h3>DSGVO verankert</h3>
            <p>
              Compliance-Workflows, AV-Verträge und dokumentierte Freigaben sorgen für Rechtssicherheit und
              Transparenz in jeder Projektphase.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <h2>So läuft Ihr Markenaufbau mit Brivantera</h2>
          <p>
            Der gesamte Journey wird durch unsere Plattform orchestriert – von der Erstdiagnose bis zur monatlichen
            Content Distribution.
          </p>
        </div>
        <div className={styles.timeline}>
          <div className={styles.step}>
            <span className={styles.stepNumber}>1</span>
            <h3>Discovery &amp; Persona Mapping</h3>
            <p>
              Tiefgehende Interviews und Datenanalyse formen die Ausgangsbasis für Ihre Positionierung und Messaging.
            </p>
          </div>
          <div className={styles.step}>
            <span className={styles.stepNumber}>2</span>
            <h3>Brand Narrative &amp; Signature Content</h3>
            <p>
              Content Produktion für LinkedIn, Podcasts und PR-Platzierungen – inklusive Redaktionsplanung und
              Freigabeschleifen.
            </p>
          </div>
          <div className={styles.step}>
            <span className={styles.stepNumber}>3</span>
            <h3>Social Media Management &amp; Distribution</h3>
            <p>
              Automatisierte Distribution, Community Management und Monitoring der Resonanzdaten in einem Dashboard.
            </p>
          </div>
          <div className={styles.step}>
            <span className={styles.stepNumber}>4</span>
            <h3>Review &amp; Iteration</h3>
            <p>
              Monatliche Retros, KPI-Auswertung und kreative Iteration sichern nachhaltigen Markenaufbau.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.categories}>
        <div className={styles.sectionHeader}>
          <h2>Kategorien im Überblick</h2>
          <p>
            Wählen Sie die Module, die Ihre Personal Branding Reise beschleunigen – modular kombinierbar und auf Ihre
            Ziele abgestimmt.
          </p>
        </div>
        <div className={styles.categoryGrid}>
          {[
            'Strategische Positionierung',
            'Content Produktion & Storytelling',
            'LinkedIn Branding & Community',
            'PR Platzierung & Thought Leadership',
            'Social Media Management',
            'Design Visual Identity'
          ].map((category) => (
            <Link key={category} to="/kategorien" className={styles.categoryCard}>
              <span>{category}</span>
              <span aria-hidden="true">→</span>
            </Link>
          ))}
        </div>
      </section>

      <section className={styles.experts}>
        <div className={styles.sectionHeader}>
          <h2>Top Expert:innen der Woche</h2>
          <p>
            Sorgfältig ausgewählte Personal Branding Spezialist:innen mit nachweisbaren Erfolgen in Markenaufbau,
            Content Produktion und PR.
          </p>
        </div>
        <div className={styles.expertGrid}>
          {[
            {
              name: 'Lena Richter',
              focus: 'Positionierung & Executive Messaging',
              rating: 5,
              image: 'https://picsum.photos/400/400?random=3'
            },
            {
              name: 'Marco Nguyen',
              focus: 'LinkedIn Branding & Community Growth',
              rating: 5,
              image: 'https://picsum.photos/400/400?random=33'
            },
            {
              name: 'Sarah Henning',
              focus: 'Design Visual Identity & Motion',
              rating: 4,
              image: 'https://picsum.photos/400/400?random=34'
            }
          ].map((expert) => (
            <article key={expert.name} className={styles.expertCard}>
              <img src={expert.image} alt={`Portrait von ${expert.name}`} loading="lazy" />
              <div className={styles.expertInfo}>
                <h3>{expert.name}</h3>
                <p>{expert.focus}</p>
                <div className={styles.rating} aria-label={`Bewertung ${expert.rating} von 5 Sternen`}>
                  {'★'.repeat(expert.rating)}
                  <span className={styles.badge}>Kuratiert</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Stimmen unserer Kund:innen">
        <div className={styles.sectionHeader}>
          <h2>Markenstimmen aus der Community</h2>
          <p>
            Entscheider:innen teilen ihre Erfahrungen mit Brivantera und beschreiben, wie Personal Branding sie im Markt
            sichtbar gemacht hat.
          </p>
        </div>
        <div className={styles.testimonialSlider}>
          {testimonials.map((item, index) => (
            <blockquote
              key={item.name}
              className={`${styles.testimonial} ${index === activeTestimonial ? styles.testimonialActive : ''}`}
            >
              <p>“{item.quote}”</p>
              <footer>
                <strong>{item.name}</strong>
                <span>{item.role}</span>
              </footer>
            </blockquote>
          ))}
          <div className={styles.dots} role="tablist">
            {testimonials.map((_, index) => (
              <button
                type="button"
                key={index}
                onClick={() => setActiveTestimonial(index)}
                className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                aria-label={`Testimonial ${index + 1} anzeigen`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.usecases}>
        <div className={styles.sectionHeader}>
          <h2>Use Cases für nachhaltigen Markenaufbau</h2>
          <p>
            Von Investor Relations über Employer Branding bis hin zu nachhaltigen Thought Leadership Programmen –
            Brivantera liefert individuelle Blaupausen.
          </p>
        </div>
        <div className={styles.usecaseGrid}>
          {[
            {
              title: 'Scale-up Sichtbarkeit',
              description:
                'Kombination aus PR Platzierung, Content Produktion und LinkedIn Branding für B2B-Scale-ups.',
              image: 'https://picsum.photos/1200/800?random=4'
            },
            {
              title: 'Executive Personal Branding',
              description:
                'C-Level Positionierung mit Signature Content, Keynote-Entwicklung und Social Media Management.',
              image: 'https://picsum.photos/1200/800?random=41'
            },
            {
              title: 'Employer Branding Stories',
              description:
                'Storytelling Kampagnen für HR-Kommunikation mit Fokus auf Design Visual Identity und Community Management.',
              image: 'https://picsum.photos/1200/800?random=42'
            }
          ].map((usecase) => (
            <article key={usecase.title} className={styles.usecaseCard}>
              <img src={usecase.image} alt={`${usecase.title} Projektbeispiel`} loading="lazy" />
              <div>
                <h3>{usecase.title}</h3>
                <p>{usecase.description}</p>
                <Link to="/use-cases" className={styles.link}>
                  Mehr erfahren
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className={styles.sectionHeader}>
          <h2>Aktuelle Insights</h2>
          <p>
            News, Frameworks und Analysen rund um Personal Branding, Positionierung, Content Produktion und DSGVO
            konforme Kommunikation.
          </p>
        </div>
        <div className={styles.blogGrid}>
          {[
            {
              title: 'LinkedIn Branding: Playbook für Thought Leader',
              excerpt:
                'Wie Entscheider:innen LinkedIn nutzen, um Community und Reputation aufzubauen – inklusive Content Formate.',
              link: '/blog'
            },
            {
              title: 'Design Visual Identity für hybride Marken',
              excerpt:
                'Guidelines für ein visuelles System, das auf Social, PR und Event gleichermaßen funktioniert.',
              link: '/blog'
            },
            {
              title: 'PR Platzierung mit datenbasiertem Storytelling',
              excerpt:
                'So arbeiten unsere Expert:innen mit Redaktionen und Podcasts zusammen, um Narrative zu platzieren.',
              link: '/blog'
            }
          ].map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <Link to={post.link} className={styles.link}>
                Beitrag lesen
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.sectionHeader}>
          <h2>Häufige Fragen</h2>
          <p>Antworten rund um Onboarding, Zusammenarbeit und DSGVO-konforme Abwicklung.</p>
        </div>
        <div className={styles.accordion}>
          {faq.map((item, index) => (
            <div key={item.question} className={styles.accordionItem}>
              <button
                type="button"
                onClick={() => toggleFaq(index)}
                className={styles.accordionButton}
                aria-expanded={openFaq === index}
              >
                {item.question}
                <span aria-hidden="true">{openFaq === index ? '−' : '+'}</span>
              </button>
              {openFaq === index && <p className={styles.accordionContent}>{item.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaInner}>
          <h2>Bereit für Ihren nächsten Schritt im Markenaufbau?</h2>
          <p>
            Starten Sie mit einer maßgeschneiderten Analyse. Wir matchen Sie mit den passenden Expert:innen und bauen
            eine Personal Branding Roadmap für Ihr Zielbild.
          </p>
          <Link to="/kontakt" className={styles.primaryCta}>
            Anfrage starten
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;