import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PageCommon.module.css';

const About = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Projektablauf | Brivantera Personal Branding</title>
      <meta
        name="description"
        content="Projektablauf bei Brivantera: Vom Onboarding über Strategieworkshops bis zur Content Distribution."
      />
      <link rel="canonical" href="https://www.brivantera.de/projekt" />
    </Helmet>
    <header className={styles.pageHeader}>
      <h1>Projektablauf mit Brivantera</h1>
      <p>
        Unser orchestrierter Workflow führt Sie von der Diagnose bis zur kontinuierlichen Markenpflege. Transparente
        Milestones, klare Verantwortlichkeiten und DSGVO-konforme Prozesse sind unser Standard.
      </p>
    </header>
    <section className={styles.section}>
      <h2>Onboarding &amp; Kick-off</h2>
      <p>
        Wir starten mit einem Discovery-Workshop, analysieren bestehende Markenassets und definieren Zielgruppen,
        Plattformen und Ambitionen. Anschließend integrieren wir Ihre Stakeholder in unser Projektboard.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Strategische Phase</h2>
      <p>
        Strateg:innen entwickeln Positionierung, Messaging-Framework und Content Roadmap. Sie erhalten individuelle
        Narrative, Tonalitätsleitfäden sowie einen modularen Themenplan für LinkedIn Branding und PR Platzierung.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Produktion &amp; Design</h2>
      <p>
        Spezialist:innen für Content Produktion, Social Media Management und Design Visual Identity setzen
        multimediale Formate um – von Artikeln über Podcasts bis hin zu Motion Visuals, inklusive Freigabe-Workflow.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Distribution &amp; Community</h2>
      <p>
        Social Teams orchestrieren die Veröffentlichung, koordinieren Community Management und messen Resonanzdaten. Sie
        erhalten klare Reports und Ableitungen für die nächste Iteration.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Review &amp; Growth</h2>
      <p>
        Monatliche Reviews verbinden quantitative Daten mit qualitativen Insights. Gemeinsam schärfen wir Content,
        Kampagnen und die Markenstory – flexibel anpassbar für jede Wachstumsphase.
      </p>
    </section>
  </div>
);

export default About;