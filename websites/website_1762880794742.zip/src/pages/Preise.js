import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PageCommon.module.css';

const packages = [
  {
    title: 'Launch Roadmap',
    description:
      'Ideal für Start-ups: Positionierung, Messaging Framework, Kick-off Content Assets, Monitoring Setup.',
    features: [
      'Discovery Workshop & Persona Mapping',
      'Narrative Canvas & Messaging Kit',
      'Content Starterkit (3 Formate)',
      'DSGVO Check & Dokumentation'
    ]
  },
  {
    title: 'Momentum Suite',
    description:
      'Für wachsende Marken: Kontinuierliche Content Produktion, Social Media Management und PR Outreach.',
    features: [
      'Redaktionsplanung & Produktion',
      'LinkedIn Branding & Community Care',
      'PR Pitching & Thought Leadership Slots',
      'Performance Review & Optimierung'
    ]
  },
  {
    title: 'Signature Presence',
    description:
      'Für etablierte Führungskräfte: Executive Coaching, Keynote Development, Design Visual Identity Refresh.',
    features: [
      'Executive Positioning & Story Coaching',
      'Design Visual Identity Toolkit',
      'Podcast & Speaking Placements',
      'Quarterly Strategy Labs'
    ]
  }
];

const Preise = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Leistungsumfang | Brivantera</title>
      <meta
        name="description"
        content="Überblick über die Leistungsumfänge der Brivantera Personal Branding Pakete."
      />
      <link rel="canonical" href="https://www.brivantera.de/preise" />
    </Helmet>
    <header className={styles.pageHeader}>
      <h1>Leistungsumfänge</h1>
      <p>
        Unsere Pakete sind modular aufgebaut und lassen sich jederzeit erweitern. Nach Ihrer Anfrage stellen wir die für
        Sie passende Kombination zusammen.
      </p>
    </header>
    <div className={styles.grid}>
      {packages.map((item) => (
        <article key={item.title} className={styles.tile}>
          <h2>{item.title}</h2>
          <p>{item.description}</p>
          <ul>
            {item.features.map((feature) => (
              <li key={feature}>{feature}</li>
            ))}
          </ul>
        </article>
      ))}
    </div>
  </div>
);

export default Preise;