import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PageCommon.module.css';

const Services = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Serviceübersicht | Brivantera</title>
      <meta
        name="description"
        content="Services von Brivantera: Positionierung, Content Produktion, Social Media Management und mehr."
      />
      <link rel="canonical" href="https://www.brivantera.de/services" />
    </Helmet>
    <header className={styles.pageHeader}>
      <h1>Serviceübersicht</h1>
      <p>
        Unsere Services decken den gesamten Markenaufbau ab – von strategischer Positionierung über Content Produktion
        bis zu Social Media Management. Modular kombinierbar, präzise gesteuert.
      </p>
    </header>
    <div className={styles.grid}>
      <article className={styles.tile}>
        <h2>Strategie &amp; Positionierung</h2>
        <p>
          Entwicklung von Markenkern, Value Proposition und Differenzierungsmerkmalen. Workshops, Persona Mapping und
          Messaging Guides.
        </p>
      </article>
      <article className={styles.tile}>
        <h2>Content Produktion</h2>
        <p>
          Redaktion, Copywriting, Podcasting und Video-Snippets. Wir bauen eine Content Engine, die Thought Leadership
          sichtbar macht.
        </p>
      </article>
      <article className={styles.tile}>
        <h2>LinkedIn Branding</h2>
        <p>
          Profiloptimierung, Kampagnenplanung, Postings und Community Care. Fokus auf Interaktion und nachhaltige Reichweite.
        </p>
      </article>
      <article className={styles.tile}>
        <h2>PR Platzierung</h2>
        <p>
          Strategische Storylines, Outreach zu Medien, Podcast-Platzierungen und Redaktionsbriefings mit hoher Relevanz.
        </p>
      </article>
      <article className={styles.tile}>
        <h2>Social Media Management</h2>
        <p>
          Kanalübergreifende Planung, Publishing, Monitoring und Reporting mit klaren Verantwortlichkeiten.
        </p>
      </article>
      <article className={styles.tile}>
        <h2>Design Visual Identity</h2>
        <p>
          Markenhandbuch, Templates, Motion Elements und Guidelines für konsistente visuelle Kommunikation.
        </p>
      </article>
    </div>
  </div>
);

export default Services;