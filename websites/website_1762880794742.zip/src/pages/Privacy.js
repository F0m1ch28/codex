import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PageCommon.module.css';

const Privacy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Datenschutz | Brivantera</title>
      <meta
        name="description"
        content="Datenschutzerklärung von Brivantera – Informationen zur Verarbeitung personenbezogener Daten."
      />
      <link rel="canonical" href="https://www.brivantera.de/datenschutz" />
    </Helmet>
    <header className={styles.pageHeader}>
      <h1>Datenschutzerklärung</h1>
    </header>
    <section className={styles.section}>
      <h2>1. Verantwortliche Stelle</h2>
      <p>
        Brivantera GmbH<br />
        Kurfürstendamm 26, 10719 Berlin<br />
        hello@brivantera.de
      </p>
    </section>
    <section className={styles.section}>
      <h2>2. Erhebung und Verwendung von Daten</h2>
      <p>
        Wir verarbeiten personenbezogene Daten ausschließlich zur Bereitstellung unserer Services rund um Personal
        Branding, Positionierung, Content Produktion und Social Media Management. Rechtsgrundlage ist Art. 6 Abs. 1 lit.
        b DSGVO.
      </p>
    </section>
    <section className={styles.section}>
      <h2>3. Weitergabe von Daten</h2>
      <p>
        Eine Weitergabe erfolgt nur an vertraglich gebundene Expert:innen, die im Rahmen der Projektumsetzung beteiligt
        sind. Alle Partner unterzeichnen AV-Verträge gemäß Art. 28 DSGVO.
      </p>
    </section>
    <section className={styles.section}>
      <h2>4. Speicherdauer</h2>
      <p>
        Daten werden nur so lange aufbewahrt, wie es zur Erfüllung der Projektvereinbarung erforderlich ist. Nach
        Abschluss des Projekts werden Informationen gemäß gesetzlichen Aufbewahrungsfristen archiviert oder gelöscht.
      </p>
    </section>
    <section className={styles.section}>
      <h2>5. Rechte der betroffenen Personen</h2>
      <p>
        Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Widerspruch sowie
        Datenübertragbarkeit. Kontaktieren Sie uns unter hello@brivantera.de.
      </p>
    </section>
    <section className={styles.section}>
      <h2>6. Cookies &amp; Tracking</h2>
      <p>
        Wir verwenden Cookies zur Analyse und Personalisierung. Sie können Ihre Einwilligung jederzeit über die
        Cookie-Einstellungen widerrufen.
      </p>
    </section>
    <section className={styles.section}>
      <h2>7. Sicherheit</h2>
      <p>
        Technische und organisatorische Maßnahmen stellen sicher, dass Ihre Daten vor Verlust, Manipulation und
        unbefugtem Zugriff geschützt sind.
      </p>
    </section>
  </div>
);

export default Privacy;