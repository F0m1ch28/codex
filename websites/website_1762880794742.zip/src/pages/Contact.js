import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formState, setFormState] = React.useState({
    name: '',
    company: '',
    email: '',
    message: '',
    consent: false
  });
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formState.name.trim()) newErrors.name = 'Bitte geben Sie Ihren Namen ein.';
    if (!formState.email.trim()) {
      newErrors.email = 'Bitte geben Sie Ihre E-Mail-Adresse ein.';
    } else if (!/\S+@\S+\.\S+/.test(formState.email)) {
      newErrors.email = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    }
    if (!formState.message.trim()) newErrors.message = 'Bitte beschreiben Sie Ihr Anliegen.';
    if (!formState.consent) newErrors.consent = 'Bitte bestätigen Sie die Datenschutzhinweise.';
    return newErrors;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormState((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Kontakt | Brivantera</title>
        <meta
          name="description"
          content="Kontaktieren Sie Brivantera für Personal Branding, Positionierung, Content Produktion und Social Media Management."
        />
        <link rel="canonical" href="https://www.brivantera.de/kontakt" />
      </Helmet>
      <header className={styles.header}>
        <h1>Kontakt</h1>
        <p>
          Erzählen Sie uns von Ihrer Marke. Wir stellen ein kuratiertes Team zusammen, das Ihren Personal Branding Prozess
          begleitet.
        </p>
      </header>
      <div className={styles.grid}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label>
            Name*
            <input
              type="text"
              name="name"
              value={formState.name}
              onChange={handleChange}
              aria-invalid={!!errors.name}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </label>
          <label>
            Unternehmen
            <input
              type="text"
              name="company"
              value={formState.company}
              onChange={handleChange}
            />
          </label>
          <label>
            E-Mail*
            <input
              type="email"
              name="email"
              value={formState.email}
              onChange={handleChange}
              aria-invalid={!!errors.email}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </label>
          <label>
            Projektbeschreibung*
            <textarea
              name="message"
              rows="5"
              value={formState.message}
              onChange={handleChange}
              aria-invalid={!!errors.message}
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </label>
          <label className={styles.checkbox}>
            <input
              type="checkbox"
              name="consent"
              checked={formState.consent}
              onChange={handleChange}
            />
            <span>
              Ich bin einverstanden, dass meine Daten zur Bearbeitung der Anfrage genutzt werden und habe die{' '}
              <a href="/datenschutz">Datenschutzerklärung</a> gelesen.
            </span>
          </label>
          {errors.consent && <span className={styles.error}>{errors.consent}</span>}
          <button type="submit" className={styles.submit}>
            Anfrage senden
          </button>
          {submitted && (
            <div className={styles.success} role="status" aria-live="polite">
              Vielen Dank für Ihre Nachricht. Wir melden uns zeitnah bei Ihnen.
            </div>
          )}
        </form>
        <div className={styles.info}>
          <h2>Kontaktinformationen</h2>
          <p>Kurfürstendamm 26, 10719 Berlin, Deutschland</p>
          <p>
            Telefon: <a href="tel:+493012345678">+49 30 1234 5678</a>
          </p>
          <p>
            E-Mail: <a href="mailto:hello@brivantera.de">hello@brivantera.de</a>
          </p>
          <div className={styles.mapWrapper}>
            <iframe
              title="Brivantera Standort Berlin"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.749275321843!2d13.325067776718409!3d52.50399167205732!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851cacd955555%3A0x3b18eb9add4ef95a!2sKurfürstendamm%2026%2C%2010719%20Berlin!5e0!3m2!1sde!2sde!4v1700000000000!5m2!1sde!2sde"
              loading="lazy"
              allowFullScreen
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;