import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const AGB = () => (
  <>
    <Helmet>
      <title>AGB | FamilienFinanz Planer</title>
      <meta name="description" content="Allgemeine Geschäftsbedingungen von FamilienFinanz Planer." />
    </Helmet>
    <section className={`${styles.section} section`}>
      <h1>Allgemeine Geschäftsbedingungen</h1>
      <p>Stand: Februar 2024</p>
      <h2>1. Geltungsbereich</h2>
      <p>
        Diese AGB gelten für alle Beratungs- und Serviceleistungen der FamilienFinanz Planer mit Sitz in Friedrichstraße 89, 10117 Berlin,
        Deutschland.
      </p>
      <h2>2. Leistungen</h2>
      <p>
        Wir erbringen Beratungsleistungen rund um Haushalts- und Finanzplanung. Der Umfang ergibt sich aus dem jeweiligen Angebot oder Vertrag.
      </p>
      <h2>3. Vergütung</h2>
      <p>
        Die Abrechnung erfolgt auf Basis des vereinbarten Honorars. Rechnungen sind innerhalb von 14 Tagen ohne Abzug zahlbar. Bei
        Zahlungsverzug behalten wir uns Verzugszinsen in gesetzlicher Höhe vor.
      </p>
      <h2>4. Mitwirkungspflichten</h2>
      <p>
        Kundinnen und Kunden stellen alle erforderlichen Unterlagen bereit und informieren uns über Änderungen ihrer finanziellen Situation.
      </p>
      <h2>5. Haftung</h2>
      <p>
        Wir haften bei Vorsatz und grober Fahrlässigkeit. Bei leichter Fahrlässigkeit haften wir nur für die Verletzung wesentlicher
        Vertragspflichten, begrenzt auf den vorhersehbaren Schaden.
      </p>
      <h2>6. Datenschutz</h2>
      <p>
        Die Verarbeitung personenbezogener Daten erfolgt gemäß unserer Datenschutzerklärung. Wir verpflichten uns zur Einhaltung der DSGVO.
      </p>
      <h2>7. Schlussbestimmungen</h2>
      <p>Es gilt deutsches Recht. Gerichtsstand ist Berlin, soweit gesetzlich zulässig.</p>
    </section>
  </>
);

export default AGB;