import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookieRichtlinie = () => (
  <>
    <Helmet>
      <title>Cookie-Richtlinie | FamilienFinanz Planer</title>
      <meta name="description" content="Cookie-Richtlinie von FamilienFinanz Planer." />
    </Helmet>
    <section className={`${styles.section} section`}>
      <h1>Cookie-Richtlinie</h1>
      <p>Stand: Februar 2024</p>
      <h2>Was sind Cookies?</h2>
      <p>
        Cookies sind kleine Textdateien, die auf Ihrem Gerät gespeichert werden. Sie helfen uns, unsere Website nutzerfreundlich zu
        gestalten und Statistiken zu erheben.
      </p>
      <h2>Arten von Cookies</h2>
      <ul>
        <li>Technisch notwendige Cookies: erforderlich für grundlegende Funktionen.</li>
        <li>Analyse-Cookies: dienen der Performance-Auswertung und Optimierung.</li>
      </ul>
      <h2>Verwaltung von Cookies</h2>
      <p>
        Sie können Cookies in Ihrem Browser deaktivieren. Bitte beachten Sie, dass einige Funktionen der Website dadurch eingeschränkt sein
        können.
      </p>
      <h2>Kontakt</h2>
      <p>Bei Fragen zur Cookie-Nutzung kontaktieren Sie uns unter cookies@finanzplaner-familie.de.</p>
    </section>
  </>
);

export default CookieRichtlinie;