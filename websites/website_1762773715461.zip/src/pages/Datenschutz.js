import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Datenschutz = () => (
  <>
    <Helmet>
      <title>Datenschutz | FamilienFinanz Planer</title>
      <meta name="description" content="Datenschutzerklärung von FamilienFinanz Planer nach DSGVO." />
    </Helmet>
    <section className={`${styles.section} section`}>
      <h1>Datenschutzerklärung</h1>
      <p>Stand: Februar 2024</p>
      <h2>1. Verantwortlicher</h2>
      <p>FamilienFinanz Planer, Friedrichstraße 89, 10117 Berlin, Deutschland, Telefon: +49 30 9876 5432</p>
      <h2>2. Verarbeitung personenbezogener Daten</h2>
      <p>
        Wir verarbeiten personenbezogene Daten ausschließlich zur Erfüllung unserer Beratungsleistungen sowie zur Kommunikation mit unseren
        Kundinnen und Kunden. Rechtsgrundlage ist Art. 6 Abs. 1 lit. b DSGVO.
      </p>
      <h2>3. Cookies</h2>
      <p>
        Wir verwenden Cookies zur Analyse und Optimierung unseres Angebots. Weitere Informationen finden Sie in unserer Cookie-Richtlinie.
      </p>
      <h2>4. Speicherdauer</h2>
      <p>Personenbezogene Daten werden nur so lange gespeichert, wie es für die Zwecke der Verarbeitung erforderlich ist.</p>
      <h2>5. Rechte der Betroffenen</h2>
      <p>
        Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit und Widerspruch.
        Bitte richten Sie Ihre Anfragen an die oben genannte Adresse.
      </p>
      <h2>6. Datensicherheit</h2>
      <p>
        Wir setzen technische und organisatorische Maßnahmen ein, um Ihre Daten gegen Verlust, Manipulation und unberechtigten Zugriff zu
        schützen.
      </p>
      <h2>7. Kontakt Datenschutz</h2>
      <p>
        Für datenschutzbezogene Fragen erreichen Sie uns unter datenschutz@finanzplaner-familie.de oder telefonisch unter +49 30 9876 5432.
      </p>
    </section>
  </>
);

export default Datenschutz;