import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Haushaltsplanung',
    description:
      'Wir entwickeln ein klares Haushaltsbudget, das fixe und variable Kosten strukturiert, Puffer einplant und flexible Anpassungen erlaubt.',
    features: ['Monatliche Budget-Reviews', 'Visualisierung von Ausgabenkategorien', 'Alerts bei Abweichungen'],
  },
  {
    title: 'Finanzielle Zielplanung',
    description:
      'Ob Familienurlaub, Bildung oder langfristige Vorsorge – wir übersetzen Ihre Ziele in messbare Meilensteine mit konkreten Kennzahlen.',
    features: ['Zeitachsen und Prioritäten', 'Simulation verschiedener Szenarien', 'Dokumentation von Zwischenzielen'],
  },
  {
    title: 'Analyse & Optimierung',
    description:
      'Unsere Analysten prüfen Versicherungen, Abonnements und Finanzprodukte auf Effektivität und schlagen Optimierungen vor.',
    features: ['Kosten-Nutzen-Vergleich', 'Risikoprofil-Abgleich', 'Verhandlung mit Partnern'],
  },
  {
    title: 'FamilienFinanz Akademie',
    description:
      'Workshops, Webinare und Lernmodule vermitteln Finanzkompetenz – abgestimmt auf unterschiedliche Lebensphasen und Altersgruppen.',
    features: ['Praxisnahe Module', 'Zertifizierte Trainer*innen', 'Begleitmaterialien für Zuhause'],
  },
];

const Services = () => (
  <>
    <Helmet>
      <title>Dienstleistungen | FamilienFinanz Planer</title>
      <meta
        name="description"
        content="Überblick über alle Dienstleistungen von FamilienFinanz Planer: Haushaltsplanung, Zielsetzung, Optimierung und Finanzbildung."
      />
      <meta
        name="keywords"
        content="Dienstleistungen Finanzplanung, Haushaltsplanung Familien, Finanzielle Ziele Familie, Finanzberatung Berlin, Familienbudget Service"
      />
    </Helmet>
    <section className={`${styles.hero} section`}>
      <div className="section-header">
        <span className="eyebrow">Unsere Leistungen</span>
        <h1>Struktur, Orientierung und Motivation für Ihre Finanzen</h1>
        <p>
          Jedes Familienmitglied, jede Lebensphase und jedes Ziel wird in unsere Planung integriert. Wir liefern klar strukturierte Maßnahmen
          und begleiten die Umsetzung.
        </p>
      </div>
    </section>

    <section className={`${styles.services} section`}>
      <div className={styles.serviceGrid}>
        {services.map((service) => (
          <article key={service.title} className={styles.serviceCard}>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
            <ul>
              {service.features.map((feature) => (
                <li key={feature}>{feature}</li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </section>

    <section className={`${styles.education} section`}>
      <div className={styles.educationContent}>
        <h2>Wissen, das wirkt</h2>
        <p>
          Unsere Bildungsformate kombinieren Fachwissen mit alltagstauglichen Übungen. Familien lernen, Verantwortung zu teilen, Entscheidungen
          zu treffen und gemeinsam finanzielle Ziele zu verfolgen.
        </p>
        <div className={styles.educationHighlights}>
          <div>
            <strong>Online-Sessions</strong>
            <span>Live oder on-demand mit Materialien für Familiengespräche</span>
          </div>
          <div>
            <strong>Workshops vor Ort</strong>
            <span>In Berlin und bundesweit mit lokalen Partnern</span>
          </div>
          <div>
            <strong>1:1-Coaching</strong>
            <span>Individuelle Fragestellungen und tiefgehende Analysen</span>
          </div>
        </div>
      </div>
      <div className={styles.educationImage}>
        <img src="https://picsum.photos/800/600?random=22" alt="Workshop bei FamilienFinanz Planer" loading="lazy" />
      </div>
    </section>
  </>
);

export default Services;