import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Kontakt.module.css';

const Kontakt = () => {
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      setError('Bitte füllen Sie alle Pflichtfelder aus.');
      return;
    }
    if (!/\S+@\S+\.\S+/.test(form.email)) {
      setError('Bitte geben Sie eine gültige E-Mail-Adresse ein.');
      return;
    }
    setError('');
    setSubmitted(true);
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | FamilienFinanz Planer</title>
        <meta
          name="description"
          content="Kontaktieren Sie FamilienFinanz Planer in Berlin. Vereinbaren Sie ein Beratungsgespräch oder besuchen Sie unser Büro in der Friedrichstraße."
        />
        <meta
          name="keywords"
          content="Kontakt Finanzberater Berlin, FamilienFinanz Planer Adresse, Beratungsgespräch Finanzplanung Familie"
        />
      </Helmet>
      <section className={`${styles.hero} section`}>
        <div className="section-header">
          <span className="eyebrow">Kontakt</span>
          <h1>Wir freuen uns auf Ihre Nachricht</h1>
          <p>Ob Erstgespräch oder konkrete Frage – unser Team antwortet innerhalb von zwei Werktagen.</p>
        </div>
      </section>

      <section className={`${styles.contact} section`}>
        <div className={styles.contactGrid}>
          <form onSubmit={handleSubmit} className={styles.form} aria-label="Kontaktformular">
            <h2>Schreiben Sie uns</h2>
            <label htmlFor="name">
              Name<span aria-hidden="true">*</span>
            </label>
            <input id="name" name="name" type="text" value={form.name} onChange={handleChange} required />
            <label htmlFor="email">
              E-Mail<span aria-hidden="true">*</span>
            </label>
            <input id="email" name="email" type="email" value={form.email} onChange={handleChange} required />
            <label htmlFor="phone">Telefon</label>
            <input id="phone" name="phone" type="tel" value={form.phone} onChange={handleChange} />
            <label htmlFor="message">
              Ihr Anliegen<span aria-hidden="true">*</span>
            </label>
            <textarea id="message" name="message" value={form.message} onChange={handleChange} rows="5" required />
            {error && <p className={styles.error} role="alert">{error}</p>}
            {submitted && <p className={styles.success}>Vielen Dank! Wir melden uns zeitnah bei Ihnen.</p>}
            <button type="submit">Nachricht senden</button>
          </form>
          <div className={styles.info}>
            <h2>Besuchen Sie uns</h2>
            <p>
              FamilienFinanz Planer<br />
              Friedrichstraße 89<br />
              10117 Berlin, Deutschland
            </p>
            <a href="tel:+493098765432" className={styles.phone}>
              +49 30 9876 5432
            </a>
            <p className={styles.domain}>finanzplaner-familie.de</p>
            <div className={styles.map} role="img" aria-label="Karte von Berlin mit Markierung an der Friedrichstraße 89">
              <iframe
                title="FamilienFinanz Planer Standort"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.969374310019!2d13.388859076873226!3d52.51281577222838!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851c905bd9c47%3A0x7b3bef955a192d08!2sFriedrichstra%C3%9Fe%2089%2C%2010117%20Berlin!5e0!3m2!1sde!2sde!4v1709668200000!5m2!1sde!2sde"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            <div className={styles.faq}>
              <h3>FAQ</h3>
              <details>
                <summary>Wie vereinbare ich ein Erstgespräch?</summary>
                <p>Nutzen Sie unser Formular oder rufen Sie uns an. Wir senden Ihnen Terminvorschläge innerhalb von zwei Werktagen.</p>
              </details>
              <details>
                <summary>Kann die Beratung online stattfinden?</summary>
                <p>Ja, wir bieten alle Formate auch digital an – inklusive sicherem Dokumentenaustausch.</p>
              </details>
              <details>
                <summary>Welche Unterlagen benötige ich?</summary>
                <p>Wir sprechen dies individuell ab. In der Regel genügen Kontoauszüge der letzten drei Monate und aktuelle Vertragsunterlagen.</p>
              </details>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Kontakt;