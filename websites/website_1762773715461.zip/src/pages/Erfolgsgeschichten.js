import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Erfolgsgeschichten.module.css';

const stories = [
  {
    family: 'Familie Hartmann, Leipzig',
    challenge: 'Intransparente Ausgaben nach Hauskauf',
    solution:
      'Wir analysierten laufende Kosten, re-strukturierten Kredite und erstellten einen 5-Jahres-Plan inklusive Energiesparmaßnahmen.',
    result: '20 % mehr Liquidität im Monat und ein Polster für Renovierungen innerhalb von 14 Monaten aufgebaut.',
    image: 'https://picsum.photos/800/600?random=61',
  },
  {
    family: 'Familie Alvarez, München',
    challenge: 'Kindergarten, Weiterbildung und berufliche Veränderung gleichzeitig',
    solution:
      'Prioritäten-Workshop, Szenario-Pläne und Einführung eines Wochenbudgets. Begleitung mit monatlichen Reviews.',
    result: 'Klarer Plan, welche Ausgaben wann getätigt werden und wirksame Sparmechanismen für Weiterbildungskosten.',
    image: 'https://picsum.photos/800/600?random=62',
  },
  {
    family: 'Familie Schneider, Hamburg',
    challenge: 'Schuldenabbau und Reserve aufbauen',
    solution:
      'Gläubigerverhandlungen, Ausgabenscreening und Aufbau eines Minimalbudgets. Schrittweise Erhöhung der Sparquote.',
    result: 'Kompletter Schuldenabbau nach 18 Monaten, plus Notgroschen für drei Monatsgehälter.',
    image: 'https://picsum.photos/800/600?random=63',
  },
];

const Erfolgsgeschichten = () => (
  <>
    <Helmet>
      <title>Erfolgsgeschichten | FamilienFinanz Planer</title>
      <meta
        name="description"
        content="Lesen Sie reale Erfolgsgeschichten von Familien, die mit FamilienFinanz Planer ihre finanzielle Situation nachhaltig verbessert haben."
      />
      <meta
        name="keywords"
        content="Erfolgsgeschichten FamilienFinanz, Finanzplanung Beispiele, Haushaltsplanung Erfolg, Familienbudget Referenzen"
      />
    </Helmet>
    <section className={`${styles.hero} section`}>
      <div className="section-header">
        <span className="eyebrow">Success Cases</span>
        <h1>Jede Familie schreibt ihre eigene Erfolgsgeschichte</h1>
        <p>
          Wir dürfen Familien in ganz Deutschland begleiten – vom ersten Coaching bis zur langfristigen Wegbegleitung. Hier finden Sie
          inspirierende Beispiele.
        </p>
      </div>
    </section>

    <section className={`${styles.stories} section`}>
      <div className={styles.storyGrid}>
        {stories.map((story) => (
          <article key={story.family} className={styles.storyCard}>
            <img src={story.image} alt={`Erfolgsgeschichte: ${story.family}`} loading="lazy" />
            <div className={styles.storyContent}>
              <h2>{story.family}</h2>
              <div>
                <strong>Ausgangssituation</strong>
                <p>{story.challenge}</p>
              </div>
              <div>
                <strong>Unser Ansatz</strong>
                <p>{story.solution}</p>
              </div>
              <div>
                <strong>Ergebnis</strong>
                <p>{story.result}</p>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Erfolgsgeschichten;