import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Julia Mertens',
    role: 'Leitung Finanzplanung',
    bio: 'Zertifizierte Finanzplanerin mit über 12 Jahren Erfahrung in Familienhaushalten, Spezialistin für langfristige Bildungsfinanzierung.',
    image: 'https://picsum.photos/400/400?random=51',
  },
  {
    name: 'Dr. Elias Braun',
    role: 'Senior Analyst Haushalt',
    bio: 'Promovierter Volkswirt und Data Scientist. Entwickelt datenbasierte Modelle zur Ausgabenanalyse und Forecasts für Familienbudgets.',
    image: 'https://picsum.photos/400/400?random=52',
  },
  {
    name: 'Maya Kessler',
    role: 'Coach Familienkommunikation',
    bio: 'Systemische Coachin mit Fokus auf Kommunikation rund um Finanzen. Moderiert Entscheidungsprozesse und Ziel-Workshops.',
    image: 'https://picsum.photos/400/400?random=53',
  },
  {
    name: 'Timur Schneider',
    role: 'Leiter Digitale Tools',
    bio: 'UX-Spezialist, verantwortet die Entwicklung unserer interaktiven Plattformen und die Integration sicherer Datenprozesse.',
    image: 'https://picsum.photos/400/400?random=54',
  },
];

const milestones = [
  { year: '2016', text: 'Gründung in Berlin mit Fokus auf Familienhaushalte und Budgettransparenz.' },
  { year: '2018', text: 'Einführung der ersten digitalen Analyseplattform für Echtzeit-Ausgabenberichte.' },
  { year: '2020', text: 'Deutschlandweite Expansion mit Partnernetzwerk aus Bildung und Vorsorge.' },
  { year: '2023', text: 'Launch der FamilienFinanz Akademie mit zertifizierten Workshops und Webinaren.' },
];

const values = [
  {
    title: 'Empathie & Respekt',
    description: 'Wir schaffen Räume für offene Gespräche und berücksichtigen individuelle Lebensrealitäten jeder Familie.',
  },
  {
    title: 'Transparenz & Fakten',
    description: 'Klare Visualisierungen und verständliche Auswertungen machen Entscheidungen greifbar.',
  },
  {
    title: 'Sicherheit & Vertrauen',
    description: 'Wir arbeiten DSGVO-konform und halten uns an höchste Standards in Daten- und Informationssicherheit.',
  },
];

const About = () => (
  <>
    <Helmet>
      <title>Über FamilienFinanz Planer | Team, Vision & Geschichte</title>
      <meta
        name="description"
        content="Lernen Sie die Menschen hinter FamilienFinanz Planer kennen, erfahren Sie mehr über unsere Vision, Geschichte und Werte."
      />
      <meta
        name="keywords"
        content="FamilienFinanz Planer Team, Finanzberatung Berlin, Familienbudget Experten, Finanzplanung Deutschland, Haushaltsplanung Vision"
      />
    </Helmet>
    <section className={`${styles.hero} section`}>
      <div className="section-header">
        <span className="eyebrow">Unsere Geschichte</span>
        <h1>Von Berlin aus Familien in ganz Deutschland stärken</h1>
        <p>
          FamilienFinanz Planer entstand aus der Vision, finanzielle Entscheidungen für Familien intuitiv und gleichzeitig fundiert zu
          gestalten. Wir verbinden exzellente Beratung mit digitalen Tools und einer starken Gemeinschaft.
        </p>
      </div>
    </section>

    <section className={`${styles.story} section`}>
      <div className={styles.storyContent}>
        <h2>Unser Weg</h2>
        <p>
          Seit unserer Gründung arbeiten wir cross-funktional: Finanzexpertinnen, Pädagogen, Analystinnen und Coaches entwickeln Lösungen,
          die den Alltag vereinfachen. Wir nutzen Daten, um Trends frühzeitig zu erkennen, und kombinieren diese Erkenntnisse mit menschlicher
          Erfahrung.
        </p>
        <p>
          Heute begleiten wir Familien in allen Bundesländern – ob beim Start in die Elternzeit, bei der Finanzierung von Bildungswegen oder
          beim Vermögensaufbau Richtung Ruhestand. Unsere Workshops, Online-Module und persönlichen Beratungen schaffen Orientierung, Klarheit
          und Vorfreude auf die nächsten Schritte.
        </p>
      </div>
      <div className={styles.storyImage}>
        <img src="https://picsum.photos/800/600?random=21" alt="Teammeeting von FamilienFinanz Planer" loading="lazy" />
      </div>
    </section>

    <section className={`${styles.milestones} section`} aria-label="Meilensteine">
      <h2>Meilensteine</h2>
      <div className={styles.timeline}>
        {milestones.map((milestone) => (
          <div key={milestone.year} className={styles.milestone}>
            <span>{milestone.year}</span>
            <p>{milestone.text}</p>
          </div>
        ))}
      </div>
    </section>

    <section className={`${styles.values} section`} aria-label="Unsere Werte">
      <div className="section-header">
        <span className="eyebrow">Werte</span>
        <h2>Was uns leitet</h2>
      </div>
      <div className={styles.valueGrid}>
        {values.map((value) => (
          <article key={value.title}>
            <h3>{value.title}</h3>
            <p>{value.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={`${styles.team} section`} aria-label="Team">
      <div className="section-header">
        <span className="eyebrow">Team</span>
        <h2>Expertinnen und Experten an Ihrer Seite</h2>
      </div>
      <div className={styles.teamGrid}>
        {teamMembers.map((member) => (
          <article key={member.name} className={styles.teamCard}>
            <img src={member.image} alt={`Porträt von ${member.name}`} loading="lazy" />
            <div>
              <h3>{member.name}</h3>
              <span>{member.role}</span>
              <p>{member.bio}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default About;