import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const Tools = () => {
  const [budget, setBudget] = useState({ income: '', expenses: '', result: null });
  const [savings, setSavings] = useState({ goal: '', months: '', amount: null });
  const [analysis, setAnalysis] = useState({ groceries: '', leisure: '', mobility: '', total: null, share: null });
  const [goals, setGoals] = useState({ description: '', timeframe: '', monthly: null });

  const handleBudget = (e) => {
    e.preventDefault();
    const income = Number(budget.income);
    const expenses = Number(budget.expenses);
    if (!income || !expenses) return;
    setBudget((prev) => ({
      ...prev,
      result: income - expenses,
    }));
  };

  const handleSavings = (e) => {
    e.preventDefault();
    const goal = Number(savings.goal);
    const months = Number(savings.months);
    if (!goal || !months) return;
    setSavings((prev) => ({
      ...prev,
      amount: goal / months,
    }));
  };

  const handleAnalysis = (e) => {
    e.preventDefault();
    const groceries = Number(analysis.groceries);
    const leisure = Number(analysis.leisure);
    const mobility = Number(analysis.mobility);
    const total = groceries + leisure + mobility;
    if (!total) return;
    setAnalysis((prev) => ({
      ...prev,
      total,
      share: {
        groceries: ((groceries / total) * 100).toFixed(1),
        leisure: ((leisure / total) * 100).toFixed(1),
        mobility: ((mobility / total) * 100).toFixed(1),
      },
    }));
  };

  const handleGoals = (e) => {
    e.preventDefault();
    const timeframe = Number(goals.timeframe);
    if (!timeframe || !goals.description) return;
    const average = (Math.random() * 800 + 200).toFixed(0);
    setGoals((prev) => ({
      ...prev,
      monthly: Number(average),
    }));
  };

  return (
    <>
      <Helmet>
        <title>Tools | FamilienFinanz Planer</title>
        <meta
          name="description"
          content="Nutzen Sie die interaktiven Tools von FamilienFinanz Planer: Haushaltsbudget-Rechner, Sparplan-Kalkulator, Ausgabenanalyse und Ziele-Planer."
        />
        <meta
          name="keywords"
          content="Haushaltsbudget-Rechner, Sparplan Kalkulator, Ausgaben Analyse Tool, Finanzielle Ziele Planer, FamilienFinanz Tools"
        />
      </Helmet>
      <section className={`${styles.hero} section`}>
        <div className="section-header">
          <span className="eyebrow">Digitale Tools</span>
          <h1>Ihre Finanzplanung auf einen Blick</h1>
          <p>Mit unseren interaktiven Rechnern treffen Sie Entscheidungen auf Basis fundierter Daten und klarer Visualisierungen.</p>
        </div>
      </section>

      <section className={`${styles.tools} section`}>
        <div className={styles.toolGrid}>
          <form className={styles.toolCard} onSubmit={handleBudget}>
            <h2>Haushaltsbudget-Rechner</h2>
            <label htmlFor="income">Monatliche Einnahmen (€)</label>
            <input
              id="income"
              type="number"
              value={budget.income}
              onChange={(e) => setBudget((prev) => ({ ...prev, income: e.target.value }))}
              required
            />
            <label htmlFor="expenses">Monatliche Ausgaben (€)</label>
            <input
              id="expenses"
              type="number"
              value={budget.expenses}
              onChange={(e) => setBudget((prev) => ({ ...prev, expenses: e.target.value }))}
              required
            />
            <button type="submit">Saldo berechnen</button>
            {budget.result !== null && (
              <div className={styles.resultBox} role="status">
                <span>Ergebnis</span>
                <strong className={budget.result >= 0 ? styles.positive : styles.negative}>
                  {budget.result >= 0 ? 'Überschuss' : 'Defizit'}: {budget.result.toLocaleString('de-DE')} €
                </strong>
              </div>
            )}
          </form>

          <form className={styles.toolCard} onSubmit={handleSavings}>
            <h2>Sparplan-Kalkulator</h2>
            <label htmlFor="goal">Sparziel (€)</label>
            <input
              id="goal"
              type="number"
              value={savings.goal}
              onChange={(e) => setSavings((prev) => ({ ...prev, goal: e.target.value }))}
              required
            />
            <label htmlFor="months">Monate</label>
            <input
              id="months"
              type="number"
              value={savings.months}
              onChange={(e) => setSavings((prev) => ({ ...prev, months: e.target.value }))}
              required
            />
            <button type="submit">Monatsbetrag anzeigen</button>
            {savings.amount && (
              <div className={styles.resultBox} role="status">
                <span>Monatlich nötig</span>
                <strong>{Number(savings.amount).toLocaleString('de-DE', { maximumFractionDigits: 2 })} €</strong>
              </div>
            )}
          </form>

          <form className={styles.toolCard} onSubmit={handleAnalysis}>
            <h2>Ausgaben-Analyse</h2>
            <label htmlFor="groceries">Lebensmittel (€)</label>
            <input
              id="groceries"
              type="number"
              value={analysis.groceries}
              onChange={(e) => setAnalysis((prev) => ({ ...prev, groceries: e.target.value }))}
              required
            />
            <label htmlFor="leisure">Freizeit & Kultur (€)</label>
            <input
              id="leisure"
              type="number"
              value={analysis.leisure}
              onChange={(e) => setAnalysis((prev) => ({ ...prev, leisure: e.target.value }))}
              required
            />
            <label htmlFor="mobility">Mobilität (€)</label>
            <input
              id="mobility"
              type="number"
              value={analysis.mobility}
              onChange={(e) => setAnalysis((prev) => ({ ...prev, mobility: e.target.value }))}
              required
            />
            <button type="submit">Verteilung berechnen</button>
            {analysis.share && (
              <div className={styles.chartBox} aria-label="Ausgabenverteilung">
                <div className={styles.chartRow}>
                  <span>Lebensmittel</span>
                  <div style={{ width: `${analysis.share.groceries}%` }} />
                  <strong>{analysis.share.groceries}%</strong>
                </div>
                <div className={styles.chartRow}>
                  <span>Freizeit & Kultur</span>
                  <div style={{ width: `${analysis.share.leisure}%`, background: '#4a90a4' }} />
                  <strong>{analysis.share.leisure}%</strong>
                </div>
                <div className={styles.chartRow}>
                  <span>Mobilität</span>
                  <div style={{ width: `${analysis.share.mobility}%`, background: '#2ecc71' }} />
                  <strong>{analysis.share.mobility}%</strong>
                </div>
                <p>Gesamt: {analysis.total.toLocaleString('de-DE')} €</p>
              </div>
            )}
          </form>

          <form className={styles.toolCard} onSubmit={handleGoals}>
            <h2>Finanzielle Ziele Planer</h2>
            <label htmlFor="description">Zielbeschreibung</label>
            <input
              id="description"
              type="text"
              value={goals.description}
              onChange={(e) => setGoals((prev) => ({ ...prev, description: e.target.value }))}
              required
            />
            <label htmlFor="timeframe">Zeitrahmen (Monate)</label>
            <input
              id="timeframe"
              type="number"
              value={goals.timeframe}
              onChange={(e) => setGoals((prev) => ({ ...prev, timeframe: e.target.value }))}
              required
            />
            <button type="submit">Empfehlung generieren</button>
            {goals.monthly && (
              <div className={styles.resultBox} role="status">
                <span>Empfehlung</span>
                <strong>{goals.monthly.toLocaleString('de-DE')} € monatlich zurücklegen</strong>
                <p>Wir empfehlen, alle 3 Monate ein Review einzuplanen.</p>
              </div>
            )}
          </form>
        </div>
      </section>
    </>
  );
};

export default Tools;