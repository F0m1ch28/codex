import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Familien begleitet', value: 1250 },
  { label: 'Monatliche Budgetanalysen', value: 4820 },
  { label: 'Zielpläne umgesetzt', value: 940 },
  { label: 'Workshops jährlich', value: 65 },
];

const serviceCards = [
  {
    title: 'Haushaltsbudget gestalten',
    description:
      'Strukturierte, familienfreundliche Budgetplanung mit klaren Prioritäten und flexiblen Szenarien für jede Lebenslage.',
    icon: '📊',
  },
  {
    title: 'Langfristige Finanzplanung',
    description:
      'Strategische Planung Ihrer finanziellen Zukunft: von Bildung bis Ruhestand, abgestimmt auf Ihre Ziele.',
    icon: '🧭',
  },
  {
    title: 'Digitale Monitoring-Tools',
    description:
      'Transparente Kontrolle von Einnahmen, Ausgaben und Sparquoten mit intuitiven dashboards und Alerts.',
    icon: '💡',
  },
];

const steps = [
  {
    title: 'Analyse & Kennenlernen',
    text: 'Wir besprechen Ihre familiäre Situation, Ziele und Erwartungshaltungen detailliert.',
  },
  {
    title: 'Finanzielle Bestandsaufnahme',
    text: 'Alle relevanten Daten werden strukturiert erfasst und mit Benchmarks verglichen.',
  },
  {
    title: 'Planung & Umsetzung',
    text: 'Gemeinsam erstellen wir einen realistischen Plan mit klaren Prioritäten und Verantwortlichkeiten.',
  },
  {
    title: 'Monitoring & Anpassung',
    text: 'Wir begleiten Sie kontinuierlich mit Analysen, Updates und Impulsen für nachhaltigen Erfolg.',
  },
];

const advantages = [
  'Persönliche Beratung mit zertifizierten Finanzplanern',
  'Transparente Berichte und anschauliche Visualisierungen',
  'Sichere Datenverarbeitung gemäß DSGVO',
  'Netzwerk aus Bildungspartnern, Versicherern und Banken',
];

const testimonials = [
  {
    quote:
      'Dank FamilienFinanz Planer verstehen wir unsere monatlichen Ausgaben endlich im Detail. Wir konnten innerhalb eines Jahres einen soliden Notgroschen bilden.',
    name: 'Familie Schneider aus Köln',
  },
  {
    quote:
      'Die Kombination aus digitalem Tool und persönlicher Begleitung hat uns geholfen, klare Prioritäten für die Ausbildung unserer Kinder zu setzen.',
    name: 'Familie Berger aus Stuttgart',
  },
  {
    quote:
      'Wir haben unsere Schulden strukturiert abgebaut und gleichzeitig einen Sparplan für Familienreisen erstellt. Ein echter Motivationsschub.',
    name: 'Familie Nguyen aus Hamburg',
  },
];

const projects = [
  { id: 1, title: 'Bildungsfonds für Kinder', category: 'Zukunft', image: 'https://picsum.photos/1200/800?random=41' },
  { id: 2, title: 'Nachhaltige Haushaltsoptimierung', category: 'Budget', image: 'https://picsum.photos/1200/800?random=42' },
  { id: 3, title: 'Familienurlaub planen', category: 'Ziele', image: 'https://picsum.photos/1200/800?random=43' },
  { id: 4, title: 'Ruhestandsstrategie entwickeln', category: 'Zukunft', image: 'https://picsum.photos/1200/800?random=44' },
  { id: 5, title: 'Ausgaben-Priorisierung', category: 'Budget', image: 'https://picsum.photos/1200/800?random=45' },
  { id: 6, title: 'Sparplan für Eigenheim', category: 'Ziele', image: 'https://picsum.photos/1200/800?random=46' },
];

const teamPreview = [
  { name: 'Julia Mertens', role: 'Leitung Finanzplanung', image: 'https://picsum.photos/400/400?random=31' },
  { name: 'Dr. Elias Braun', role: 'Senior Analyst Haushalt', image: 'https://picsum.photos/400/400?random=32' },
  { name: 'Maya Kessler', role: 'Coach Familienkommunikation', image: 'https://picsum.photos/400/400?random=33' },
];

const faqItems = [
  {
    question: 'Wie startet die Zusammenarbeit mit FamilienFinanz Planer?',
    answer:
      'Wir beginnen mit einem unverbindlichen Erstgespräch, analysieren Ihre Ausgangssituation und definieren gemeinsam die Ziele. Anschließend erhalten Sie einen individuellen Fahrplan.',
  },
  {
    question: 'Sind unsere Daten sicher?',
    answer:
      'Ja. Alle Informationen werden ausschließlich auf Servern in Deutschland gespeichert und gemäß DSGVO verarbeitet. Zugriff erhalten nur autorisierte Teammitglieder.',
  },
  {
    question: 'Welche Tools stehen uns zur Verfügung?',
    answer:
      'Sie erhalten Zugriff auf Haushaltsbudget-Rechner, Sparziel-Planer, Ausgabenanalyse sowie individuelle Dashboards mit Benachrichtigungen.',
  },
  {
    question: 'Wie oft erfolgt ein Review?',
    answer:
      'Standardmäßig vierteljährlich. Bei Bedarf planen wir monatliche Reviews oder verknüpfen die Termine mit wichtigen Lebensereignissen.',
  },
];

const blogPosts = [
  {
    title: '5 Schritte zur resilienten Haushaltsplanung in turbulenten Zeiten',
    date: '12. Februar 2024',
    excerpt:
      'Wie Familien ihre Finanzen flexibel gestalten, um auf unerwartete Veränderungen vorbereitet zu sein.',
    link: '/ratgeber',
  },
  {
    title: 'Sparstrategien für Familien mit Teenagern',
    date: '28. Januar 2024',
    excerpt:
      'Budgettipps und Gesprächsanlässe, um Jugendliche frühzeitig in Finanzentscheidungen einzubeziehen.',
    link: '/ratgeber',
  },
  {
    title: 'Finanzielle Meilensteine rund um Geburt und Elternzeit',
    date: '18. Dezember 2023',
    excerpt:
      'Welche Kosten entstehen, wie Förderungen genutzt werden und wie der Cashflow stabil bleibt.',
    link: '/ratgeber',
  },
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [filter, setFilter] = useState('Alle');
  const [counters, setCounters] = useState(statsData.map(() => 0));

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const steps = statsData.map((stat, index) => {
      const increment = Math.ceil(stat.value / 60);
      return setInterval(() => {
        setCounters((prev) => {
          const next = [...prev];
          next[index] = Math.min(next[index] + increment, stat.value);
          return next;
        });
      }, 30);
    });
    const timer = setTimeout(() => steps.forEach((interval) => clearInterval(interval)), 2000);
    return () => {
      steps.forEach((interval) => clearInterval(interval));
      clearTimeout(timer);
    };
  }, []);

  const categories = ['Alle', 'Budget', 'Ziele', 'Zukunft'];
  const filteredProjects = filter === 'Alle' ? projects : projects.filter((p) => p.category === filter);

  return (
    <>
      <Helmet>
        <title>FamilienFinanz Planer | Ihre finanzielle Zukunft beginnt heute</title>
        <meta
          name="description"
          content="FamilienFinanz Planer begleitet Familien in Deutschland bei Haushaltsplanung, Sparzielen und nachhaltiger Finanzstrategie – digital, persönlich und transparent."
        />
        <meta
          name="keywords"
          content="Haushaltsplanung Deutschland, Familienbudget erstellen, Finanzplanung Tipps, Budgetierung Werkzeuge, persönliche Finanzen verwalten, Sparplan Familie, Finanzberater Berlin, Haushaltsbuch führen, Ausgaben kontrollieren, finanzielle Ziele erreichen, Vermögensaufbau Familie, Finanzbildung Deutschland"
        />
      </Helmet>
      <section className={`${styles.hero} section`}>
        <div className={styles.heroContent}>
          <h1>Ihre finanzielle Zukunft beginnt heute</h1>
          <p>
            FamilienFinanz Planer unterstützt Sie mit präziser Analyse, smarten Tools und empathischer Begleitung – damit Ihre Pläne für
            morgen heute Gestalt annehmen.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakt" className={styles.primaryCta}>
              Beratung anfragen
            </Link>
            <Link to="/tools" className={styles.secondaryCta}>
              Tools entdecken
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.mission} section`}>
        <div className="section-header">
          <span className="eyebrow">Unsere Mission</span>
          <h2>Finanzielle Klarheit für jede Familienphase</h2>
          <p>
            Wir glauben, dass finanzielle Planung auf Augenhöhe die Basis für Stabilität, Vertrauen und mutige Entscheidungen ist. Deshalb
            verbinden wir fachliche Expertise mit familiärer Empathie.
          </p>
        </div>
        <div className={styles.missionGrid}>
          <article>
            <h3>Verstehen</h3>
            <p>Wir hören zu, erkennen Muster und schaffen Transparenz über Ihr aktuelles Budget sowie den Handlungsspielraum.</p>
          </article>
          <article>
            <h3>Strukturieren</h3>
            <p>Gemeinsam entwickeln wir umsetzbare Pläne, die Raum für Flexibilität lassen und Ihre Werte abbilden.</p>
          </article>
          <article>
            <h3>Begleiten</h3>
            <p>Wir bleiben an Ihrer Seite, monitoren Kennzahlen und geben Impulse für die nächste Etappe Ihrer Reise.</p>
          </article>
        </div>
      </section>

      <section className={`${styles.stats} section`} aria-label="Kennzahlen">
        <div className={styles.statsGrid}>
          {statsData.map((stat, index) => (
            <div key={stat.label} className={styles.statCard}>
              <span className={styles.statValue}>{counters[index].toLocaleString('de-DE')}</span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.services} section`} id="services">
        <div className="section-header">
          <span className="eyebrow">Leistungsspektrum</span>
          <h2>Individuelle Lösungen für Ihren Familienhaushalt</h2>
          <p>
            Ob grundlegendes Budget, mittelfristige Ziele oder langfristige Vision – wir entwickeln das passende Konzept samt Monitoring.
          </p>
        </div>
        <div className={styles.serviceGrid}>
          {serviceCards.map((card) => (
            <article key={card.title} className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">
                {card.icon}
              </span>
              <h3>{card.title}</h3>
              <p>{card.description}</p>
              <Link to="/dienstleistungen" className={styles.serviceLink}>
                Mehr erfahren →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.process} section`}>
        <div className="section-header">
          <span className="eyebrow">Ablauf</span>
          <h2>So arbeiten wir zusammen</h2>
        </div>
        <div className={styles.processGrid}>
          {steps.map((step, idx) => (
            <div key={step.title} className={styles.processStep}>
              <span className={styles.stepNumber}>{idx + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.advantages} section`}>
        <div className="section-header">
          <span className="eyebrow">Ihre Vorteile</span>
          <h2>Warum Familien uns vertrauen</h2>
        </div>
        <ul className={styles.advantageList}>
          {advantages.map((advantage) => (
            <li key={advantage}>
              <span>✓</span>
              {advantage}
            </li>
          ))}
        </ul>
      </section>

      <section className={`${styles.testimonials} section`} aria-label="Erfahrungsberichte">
        <div className="section-header">
          <span className="eyebrow">Erfahrungen</span>
          <h2>Erfolgsgeschichten aus ganz Deutschland</h2>
        </div>
        <div className={styles.testimonialCarousel}>
          {testimonials.map((item, index) => (
            <article
              key={item.name}
              className={`${styles.testimonialCard} ${index === activeTestimonial ? styles.testimonialActive : ''}`}
            >
              <p>„{item.quote}“</p>
              <span>{item.name}</span>
            </article>
          ))}
          <div className={styles.carouselDots} role="tablist" aria-label="Testimonial Auswahl">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={index === activeTestimonial ? styles.dotActive : ''}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Testimonial ${index + 1}`}
                aria-selected={index === activeTestimonial}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.teamPreview} section`}>
        <div className="section-header">
          <span className="eyebrow">Team</span>
          <h2>Menschen hinter FamilienFinanz Planer</h2>
          <p>Vernetzte Expertinnen und Experten aus Finanzplanung, Pädagogik und Datenanalyse begleiten Ihre Familie ganzheitlich.</p>
        </div>
        <div className={styles.teamGrid}>
          {teamPreview.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`Porträt von ${member.name}`} loading="lazy" />
              <div>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
              </div>
            </article>
          ))}
        </div>
        <Link to="/ueber-uns" className={styles.teamLink}>
          Mehr über unser Team
        </Link>
      </section>

      <section className={`${styles.projects} section`}>
        <div className="section-header">
          <span className="eyebrow">Projektbeispiele</span>
          <h2>Inspiration aus realen Finanzprojekten</h2>
        </div>
        <div className={styles.filterBar} role="tablist" aria-label="Projektfilter">
          {categories.map((category) => (
            <button
              key={category}
              className={filter === category ? styles.filterActive : ''}
              onClick={() => setFilter(category)}
              aria-pressed={filter === category}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <img src={project.image} alt={`Projekt: ${project.title}`} loading="lazy" />
              <div className={styles.projectContent}>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
                <Link to="/erfolgsgeschichten">Details ansehen →</Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.faq} section`} aria-label="Häufige Fragen">
        <div className="section-header">
          <span className="eyebrow">FAQ</span>
          <h2>Antworten auf häufige Fragen</h2>
        </div>
        <div className={styles.faqItems}>
          {faqItems.map((item, index) => (
            <details key={item.question}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={`${styles.blog} section`}>
        <div className="section-header">
          <span className="eyebrow">Insights</span>
          <h2>Aktuelle Impulse aus unserem Ratgeber</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <div className={styles.blogMeta}>
                <span>{post.date}</span>
              </div>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <Link to={post.link} className={styles.blogLink}>
                Zum Artikel →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.cta} section`}>
        <div className={styles.ctaCard}>
          <h2>Starten Sie jetzt Ihre Finanzplanung</h2>
          <p>
            Vereinbaren Sie ein Gespräch mit unseren Expertinnen und Experten und erhalten Sie innerhalb von 48 Stunden Ihren personalisierten
            Projektplan.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/kontakt" className={styles.ctaPrimary}>
              Gespräch vereinbaren
            </Link>
            <Link to="/dienstleistungen" className={styles.ctaSecondary}>
              Leistungen ansehen
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;