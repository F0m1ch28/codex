import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Ratgeber.module.css';

const articles = [
  {
    title: 'Budgetstrategie für junge Familien',
    date: '05. März 2024',
    excerpt: 'Wie Sie Kindergeld, Elterngeld und Teilzeitmodelle optimal im Haushaltsplan verankern.',
  },
  {
    title: 'Notgroschen aufbauen ohne Verzichtsgefühl',
    date: '18. Februar 2024',
    excerpt: 'Pragmatische Ideen, um Rücklagen Schritt für Schritt zu etablieren und Gewohnheiten zu transformieren.',
  },
  {
    title: 'Finanzen im Patchwork-Haushalt koordinieren',
    date: '10. Februar 2024',
    excerpt: 'Transparente Kommunikation, faire Kostenverteilung und gemeinsame Ziele schaffen Sicherheit.',
  },
  {
    title: 'Bafög, Bildungskonto & Co: Optionen vergleichen',
    date: '31. Januar 2024',
    excerpt: 'Welche Förderungen für Bildung Ihnen offenstehen und wie Sie einen Mix zusammenstellen.',
  },
  {
    title: 'Inflation im Blick behalten',
    date: '22. Januar 2024',
    excerpt: 'Wie Preissteigerungen den Alltag betreffen und mit welchen Stellschrauben Sie gegensteuern.',
  },
  {
    title: 'Vorsorge für Selbstständige Familien',
    date: '12. Januar 2024',
    excerpt: 'Buffer, Versicherungen und Absicherungen für unregelmäßige Einkommen.',
  },
];

const Ratgeber = () => (
  <>
    <Helmet>
      <title>Ratgeber | FamilienFinanz Planer</title>
      <meta
        name="description"
        content="Der Ratgeber von FamilienFinanz Planer bietet praxisnahe Artikel zu Budgetierung, Sparstrategien und Finanzwissen für Familien."
      />
      <meta
        name="keywords"
        content="Ratgeber Familienfinanzen, Budget Tipps Familie, Finanzwissen Deutschland, Haushaltsführung Artikel"
      />
    </Helmet>
    <section className={`${styles.hero} section`}>
      <div className="section-header">
        <span className="eyebrow">Ratgeber</span>
        <h1>Aktuelle Impulse für Ihren Familienhaushalt</h1>
        <p>Praxisnah, verständlich und sofort umsetzbar – unser Redaktionsteam liefert Ihnen regelmäßig frische Inspiration.</p>
      </div>
    </section>

    <section className={`${styles.articles} section`}>
      <div className={styles.articleGrid}>
        {articles.map((article) => (
          <article key={article.title} className={styles.articleCard}>
            <span>{article.date}</span>
            <h2>{article.title}</h2>
            <p>{article.excerpt}</p>
            <button type="button" className={styles.readMore} aria-label={`Mehr über ${article.title} lesen`}>
              Kompletter Beitrag erscheint demnächst
            </button>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Ratgeber;