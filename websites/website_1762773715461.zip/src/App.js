import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Tools from './pages/Tools';
import Ratgeber from './pages/Ratgeber';
import Erfolgsgeschichten from './pages/Erfolgsgeschichten';
import Kontakt from './pages/Kontakt';
import AGB from './pages/AGB';
import Datenschutz from './pages/Datenschutz';
import CookieRichtlinie from './pages/CookieRichtlinie';

function App() {
  return (
    <div className="app">
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ueber-uns" element={<About />} />
          <Route path="/dienstleistungen" element={<Services />} />
          <Route path="/tools" element={<Tools />} />
          <Route path="/ratgeber" element={<Ratgeber />} />
          <Route path="/erfolgsgeschichten" element={<Erfolgsgeschichten />} />
          <Route path="/kontakt" element={<Kontakt />} />
          <Route path="/agb" element={<AGB />} />
          <Route path="/datenschutz" element={<Datenschutz />} />
          <Route path="/cookie-richtlinie" element={<CookieRichtlinie />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
}

export default App;