import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-labelledby="footer-heading">
    <div className={styles.container}>
      <div className={styles.brand}>
        <h2 id="footer-heading">FamilienFinanz Planer</h2>
        <p>
          Verlässliche Finanzplanung für Familien in ganz Deutschland. Unsere Expertenteams kombinieren datenbasierte Analysen mit
          persönlichem Verständnis für Ihre Lebenssituation.
        </p>
      </div>
      <div className={styles.columns}>
        <div>
          <h3>Navigation</h3>
          <ul>
            <li><NavLink to="/">Startseite</NavLink></li>
            <li><NavLink to="/ueber-uns">Über uns</NavLink></li>
            <li><NavLink to="/dienstleistungen">Dienstleistungen</NavLink></li>
            <li><NavLink to="/tools">Tools</NavLink></li>
            <li><NavLink to="/ratgeber">Ratgeber</NavLink></li>
          </ul>
        </div>
        <div>
          <h3>Rechtliches</h3>
          <ul>
            <li><NavLink to="/agb">AGB</NavLink></li>
            <li><NavLink to="/datenschutz">Datenschutz</NavLink></li>
            <li><NavLink to="/cookie-richtlinie">Cookie-Richtlinie</NavLink></li>
          </ul>
        </div>
        <div>
          <h3>Kontakt</h3>
          <address>
            FamilienFinanz Planer<br />
            Friedrichstraße 89<br />
            10117 Berlin, Deutschland
          </address>
          <a href="tel:+493098765432" className={styles.phoneLink}>
            +49 30 9876 5432
          </a>
          <p className={styles.domain}>finanzplaner-familie.de</p>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} FamilienFinanz Planer. Alle Rechte vorbehalten.</p>
    </div>
  </footer>
);

export default Footer;