import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`} aria-label="Hauptnavigation">
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          FamilienFinanz <span>Planer</span>
        </NavLink>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}>
          <NavLink to="/" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Startseite
          </NavLink>
          <NavLink to="/ueber-uns" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Über uns
          </NavLink>
          <NavLink to="/dienstleistungen" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Dienstleistungen
          </NavLink>
          <NavLink to="/tools" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Tools
          </NavLink>
          <NavLink to="/ratgeber" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Ratgeber
          </NavLink>
          <NavLink to="/erfolgsgeschichten" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Erfolgsgeschichten
          </NavLink>
          <NavLink to="/kontakt" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Kontakt
          </NavLink>
        </nav>
        <button
          className={`${styles.burger} ${menuOpen ? styles.burgerOpen : ''}`}
          onClick={toggleMenu}
          aria-label="Menü öffnen"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;