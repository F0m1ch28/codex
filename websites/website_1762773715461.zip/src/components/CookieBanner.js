import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';
import { Link } from 'react-router-dom';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('ffp_cookie_consent');
    if (!consent) {
      setTimeout(() => setVisible(true), 1200);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('ffp_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie Hinweis">
      <div className={styles.content}>
        <p>
          Wir verwenden Cookies, um Ihre Nutzererfahrung zu verbessern und unsere Services fortlaufend zu optimieren. Weitere Informationen
          finden Sie in unserer <Link to="/datenschutz">Datenschutzerklärung</Link> und der{' '}
          <Link to="/cookie-richtlinie">Cookie-Richtlinie</Link>.
        </p>
        <button onClick={handleAccept} className={styles.button} aria-label="Cookies akzeptieren">
          Zustimmen
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;