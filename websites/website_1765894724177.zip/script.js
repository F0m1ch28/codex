document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      primaryNav.classList.toggle("open");
    });

    primaryNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        primaryNav.classList.remove("open");
      });
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (event) {
      const targetId = this.getAttribute("href");
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        event.preventDefault();
        targetElement.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });
  });

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".cookie-accept");
  const declineBtn = document.querySelector(".cookie-decline");
  const consentKey = "cookieConsentChoice";

  if (cookieBanner && acceptBtn && declineBtn) {
    const storedChoice = localStorage.getItem(consentKey);
    if (!storedChoice) {
      cookieBanner.classList.add("show");
    }

    acceptBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "accepted");
      cookieBanner.classList.remove("show");
    });

    declineBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "declined");
      cookieBanner.classList.remove("show");
    });
  }

  const contactForm = document.querySelector("#contact-form");
  if (contactForm) {
    const successMessage = contactForm.querySelector(".success-message");

    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();

      let formValid = true;

      const formFields = contactForm.querySelectorAll("[data-validate]");
      formFields.forEach((field) => {
        const errorContainer = field.parentElement.querySelector(".error-message");
        let errorText = "";

        if (!field.value.trim()) {
          errorText = "Поле обязательно для заполнения.";
        } else if (field.dataset.validate === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value.trim())) {
          errorText = "Введите корректный адрес электронной почты.";
        } else if (field.dataset.validate === "phone" && !/^\+?[0-9\s\-()]{7,}$/.test(field.value.trim())) {
          errorText = "Введите корректный номер телефона.";
        } else if (field.dataset.validate === "message" && field.value.trim().length < 10) {
          errorText = "Сообщение должно содержать минимум 10 символов.";
        }

        if (errorContainer) {
          errorContainer.textContent = errorText;
        }

        if (errorText) {
          formValid = false;
        }
      });

      if (formValid && successMessage) {
        successMessage.style.display = "block";
        contactForm.reset();
        setTimeout(() => {
          successMessage.style.display = "none";
        }, 5000);
      }
    });
  }
});