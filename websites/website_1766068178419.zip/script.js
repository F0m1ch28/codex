(function () {
  const storageKey = "stellarForgeCookieConsent";

  const ready = (fn) => {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn);
    } else {
      fn();
    }
  };

  const setYear = () => {
    const elements = document.querySelectorAll("#year");
    const year = String(new Date().getFullYear());
    elements.forEach((el) => {
      if (el.textContent !== year) {
        el.textContent = year;
      }
    });
  };

  const initNavigation = () => {
    const toggle = document.querySelector(".nav__toggle");
    const nav = document.querySelector(".nav");
    if (!toggle || !nav) return;

    toggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", String(isOpen));
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (nav.classList.contains("is-open")) {
          nav.classList.remove("is-open");
          toggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  };

  const handleConsent = () => {
    const banner = document.querySelector("[data-banner]");
    if (!banner) return;

    const acceptBtn = banner.querySelector("[data-accept]");
    const rejectBtn = banner.querySelector("[data-reject]");
    const customizeBtn = banner.querySelector("[data-customize]");
    const saveBtn = banner.querySelector("[data-save]");
    const preferencesPanel = banner.querySelector("[data-preferences]");
    const toggles = banner.querySelectorAll("[data-toggle]");

    const setBannerHidden = (hidden) => {
      banner.classList.toggle("is-hidden", hidden);
      if (hidden) {
        banner.setAttribute("aria-hidden", "true");
      } else {
        banner.removeAttribute("aria-hidden");
      }
    };

    const syncToggles = (consent) => {
      toggles.forEach((toggle) => {
        const type = toggle.dataset.toggle;
        toggle.checked = Boolean(consent[type]);
      });
    };

    const saveConsent = (consent) => {
      localStorage.setItem(storageKey, JSON.stringify(consent));
      syncToggles(consent);
      setBannerHidden(true);
    };

    const hydrate = () => {
      try {
        const stored = localStorage.getItem(storageKey);
        if (!stored) {
          setBannerHidden(false);
          return;
        }
        const consent = JSON.parse(stored);
        syncToggles(consent);
        setBannerHidden(true);
      } catch (error) {
        console.warn("Consent parsing error:", error);
        setBannerHidden(false);
      }
    };

    acceptBtn?.addEventListener("click", () => {
      saveConsent({ necessary: true, analytics: true, marketing: true });
    });

    rejectBtn?.addEventListener("click", () => {
      saveConsent({ necessary: true, analytics: false, marketing: false });
    });

    customizeBtn?.addEventListener("click", () => {
      preferencesPanel?.classList.toggle("is-visible");
    });

    saveBtn?.addEventListener("click", () => {
      const consent = { necessary: true };
      toggles.forEach((toggle) => {
        consent[toggle.dataset.toggle] = toggle.checked;
      });
      saveConsent(consent);
    });

    hydrate();
  };

  ready(() => {
    setYear();
    initNavigation();
    handleConsent();
  });
})();