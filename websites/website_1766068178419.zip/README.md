# Stellar Forge Labs Website

This repository contains the multi-page Stellar Forge Labs experience featuring:
- Visionary landing page, Innovation Pipeline, Solutions Suite, Insights Hub, Privacy, Terms, and FAQ.
- Responsive design with adaptive typography, gradient theming, and reusable components.
- Fully responsive `<picture>` elements with unique Pexels imagery per page.
- Persistent cookies banner powered by `script.js`, leveraging localStorage consent.
- Additional data assets (`data/` and `content/`) for extended references.

## Structure
- `index.html` — Primary landing experience.
- `innovation.html`, `solutions.html`, `insights.html` — Core mission pages.
- `policy.html`, `terms.html`, `faq.html` — Compliance and knowledge base.
- `styles.css` — Global styles with modular utility classes.
- `script.js` — Navigation toggle, dynamic year injection, and cookies management.
- `data/*` and `content/*` — Supplementary resources.
- `site.webmanifest`, `robots.txt`, `sitemap.xml`, `favicon.ico` — Supporting assets.

## Development
Open `index.html` in a modern browser. All pages rely on relative paths. No external build steps required.

## Licensing
All rights reserved © Stellar Forge Labs. Images sourced from Pexels under their free-to-use license.