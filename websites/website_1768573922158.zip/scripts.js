document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.getElementById('primaryNavigation');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function () {
            const isOpen = navLinks.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('is-open')) {
                    navLinks.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAccept = document.getElementById('cookieAccept');
    const cookieDecline = document.getElementById('cookieDecline');
    const consentKey = 'lovelywdcw-cookie-consent';

    if (cookieBanner && cookieAccept && cookieDecline) {
        const storedConsent = localStorage.getItem(consentKey);
        if (storedConsent) {
            cookieBanner.classList.add('is-hidden');
        }

        cookieAccept.addEventListener('click', function () {
            localStorage.setItem(consentKey, 'accepted');
            cookieBanner.classList.add('is-hidden');
        });

        cookieDecline.addEventListener('click', function () {
            localStorage.setItem(consentKey, 'declined');
            cookieBanner.classList.add('is-hidden');
        });
    }
});