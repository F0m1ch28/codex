document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector("[data-nav-toggle]");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = siteNav.classList.toggle("nav-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (siteNav.classList.contains("nav-open")) {
          siteNav.classList.remove("nav-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  if (cookieBanner) {
    const storedChoice = localStorage.getItem("mm8w8_cookie_choice");
    if (!storedChoice) {
      cookieBanner.classList.add("show");
    }
    cookieBanner.querySelectorAll(".cookie-btn").forEach((button) => {
      button.addEventListener("click", () => {
        const choice = button.getAttribute("data-choice");
        localStorage.setItem("mm8w8_cookie_choice", choice);
        cookieBanner.classList.add("hide");
        setTimeout(() => {
          cookieBanner.classList.remove("show");
        }, 300);
      });
    });
  }

  const forms = document.querySelectorAll("form[data-redirect]");
  const toast = document.getElementById("form-toast");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const redirectUrl = form.dataset.redirect || "thank-you.html";
      const toastMessage = form.dataset.toast || "Bericht succesvol verzonden.";
      if (toast) {
        toast.textContent = toastMessage;
        toast.classList.add("show");
      }
      setTimeout(() => {
        if (toast) {
          toast.classList.remove("show");
        }
        window.location.href = redirectUrl;
      }, 1600);
    });
  });

  const yearEls = document.querySelectorAll("[data-year]");
  const currentYear = new Date().getFullYear();
  yearEls.forEach((el) => {
    el.textContent = currentYear;
  });
});