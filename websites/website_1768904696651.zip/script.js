document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.querySelector(".primary-nav");
    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!isExpanded));
            primaryNav.classList.toggle("is-open");
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-accept");
    const rejectBtn = document.querySelector(".cookie-reject");
    const cookieStorageKey = "publicOverviewCookieConsent";

    const hideBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.remove("is-visible");
        }
    };

    const showBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.add("is-visible");
        }
    };

    if (cookieBanner) {
        const storedChoice = localStorage.getItem(cookieStorageKey);
        if (!storedChoice) {
            setTimeout(showBanner, 600);
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => {
                localStorage.setItem(cookieStorageKey, "accepted");
                hideBanner();
            });
        }

        if (rejectBtn) {
            rejectBtn.addEventListener("click", () => {
                localStorage.setItem(cookieStorageKey, "rejected");
                hideBanner();
            });
        }
    }
});