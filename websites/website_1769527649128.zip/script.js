const I18N = {
  fr: {
    "meta.index.title": "Comunidad IA Salud-Énergie – Réseau de Professionnels",
    "meta.index.description": "Plateforme collaborative reliant les acteurs espagnols de l’IA appliquée à la santé et à l’énergie. Forums thématiques, groupes régionaux, projets partagés et bibliothèque de cas.",
    "meta.servicios.title": "Services informationnels – Comunidad IA Salud-Énergie",
    "meta.servicios.description": "Aperçu des forums, groupes régionaux, événements professionnels, tableau de projets et bibliothèque de connaissances de la Comunidad IA Salud-Énergie.",
    "meta.acerca.title": "À propos du réseau – Comunidad IA Salud-Énergie",
    "meta.acerca.description": "Historique, mission et équipe de coordination de la Comunidad IA Salud-Énergie. Une coopération interdisciplinaire au service des acteurs espagnols de la santé et de l’énergie.",
    "meta.blog.title": "Blog technique – Comunidad IA Salud-Énergie",
    "meta.blog.description": "Analyses techniques et retours d’expérience sur l’IA pour la santé et l’énergie en Espagne. Articles signés par les membres de la Comunidad IA Salud-Énergie.",
    "meta.post1.title": "Méthodologies couplées pour l’efficacité énergétique hospitalière",
    "meta.post1.description": "Analyse approfondie des approches intégrées mêlant IA, simulation énergétique et pilotage clinique dans les hôpitaux espagnols.",
    "meta.post2.title": "Cadre de gouvernance pour l’IA santé-énergie",
    "meta.post2.description": "Référentiel de gouvernance pour aligner performance énergétique et exigences cliniques au sein des projets d’IA en santé.",
    "meta.post3.title": "Interopérabilité des données santé-énergie en Espagne",
    "meta.post3.description": "Guide technique sur l’interopérabilité des données entre systèmes de santé et infrastructures énergétiques intelligentes.",
    "meta.post4.title": "Maintenance prédictive des infrastructures hospitalières",
    "meta.post4.description": "Étude approfondie de la maintenance prédictive assistée par IA pour les installations énergétiques hospitalières.",
    "meta.post5.title": "Simulation multi-agent pour la gestion des urgences",
    "meta.post5.description": "Exploration des simulations multi-agent combinant flux énergétiques et gestion des urgences hospitalières en Espagne.",
    "meta.contacto.title": "Contact et localisation – Comunidad IA Salud-Énergie",
    "meta.contacto.description": "Coordonnées, formulaire sécurisé et localisation de la Comunidad IA Salud-Énergie à Madrid.",
    "meta.faq.title": "FAQ – Comunidad IA Salud-Énergie",
    "meta.faq.description": "Réponses aux questions fréquentes sur l’adhésion, les forums, les événements et la gouvernance des données.",
    "meta.terminos.title": "Conditions d’utilisation – Comunidad IA Salud-Énergie",
    "meta.terminos.description": "Conditions d’utilisation complètes de la plateforme Comunidad IA Salud-Énergie destinées aux professionnels espagnols.",
    "meta.privacidad.title": "Politique de confidentialité – Comunidad IA Salud-Énergie",
    "meta.privacidad.description": "Politique de confidentialité détaillant la collecte, l’usage et la conservation des données au sein du réseau.",
    "meta.cookies.title": "Politique de cookies – Comunidad IA Salud-Énergie",
    "meta.cookies.description": "Description transparente des cookies utilisés sur la plateforme Comunidad IA Salud-Énergie.",
    "meta.reembolso.title": "Politique de remboursement – Comunidad IA Salud-Énergie",
    "meta.reembolso.description": "Politique de remboursement décrivant les procédures applicables aux services informatifs du réseau.",
    "meta.descargo.title": "Avis de non-responsabilité – Comunidad IA Salud-Énergie",
    "meta.descargo.description": "Avis de non-responsabilité couvrant les limites de responsabilité de la Comunidad IA Salud-Énergie.",
    "meta.gracias.title": "Merci pour votre message – Comunidad IA Salud-Énergie",
    "meta.gracias.description": "Confirmation de réception : la Comunidad IA Salud-Énergie prendra contact après examen des informations transmises.",
    "meta.404.title": "Page non trouvée – Comunidad IA Salud-Énergie",
    "meta.404.description": "La ressource demandée est introuvable. Suivez les liens proposés pour revenir à l’accueil.",
    "meta.miembros.title": "Communauté de membres – Comunidad IA Salud-Énergie",
    "meta.miembros.description": "Présentation des profils collaboratifs et espaces de co-création de la Comunidad IA Salud-Énergie.",
    "meta.foros.title": "Forums thématiques – Comunidad IA Salud-Énergie",
    "meta.foros.description": "Aperçu des forums thématiques sur l’IA appliquée à la santé et à l’énergie en Espagne.",
    "meta.grupos.title": "Groupes régionaux – Comunidad IA Salud-Énergie",
    "meta.grupos.description": "Panorama des groupes régionaux et lignes d’action territoriales de la Comunidad IA Salud-Énergie.",
    "meta.proyectos.title": "Tableau de projets – Comunidad IA Salud-Énergie",
    "meta.proyectos.description": "Projets collaboratifs et opportunités de coopération au sein du réseau Comunidad IA Salud-Énergie.",
    "meta.eventos.title": "Calendrier d’événements – Comunidad IA Salud-Énergie",
    "meta.eventos.description": "Calendrier des rencontres, ateliers et séminaires techniques du réseau.",
    "meta.biblioteca.title": "Bibliothèque de connaissances – Comunidad IA Salud-Énergie",
    "meta.biblioteca.description": "Ressources documentaires et cas d’usage partagés par les membres.",
    "meta.expertos.title": "Annuaire d’experts – Comunidad IA Salud-Énergie",
    "meta.expertos.description": "Compétences clés des experts en IA, santé et énergie réunis par le réseau.",
    "meta.noticias.title": "Actualités – Comunidad IA Salud-Énergie",
    "meta.noticias.description": "Actualités et veille stratégique autour de l’IA santé-énergie en Espagne.",
    "meta.empresas.title": "Partenaires institutionnels – Comunidad IA Salud-Énergie",
    "meta.empresas.description": "Panorama des organisations collaborant avec la Comunidad IA Salud-Énergie.",
    "meta.unirse.title": "Rejoindre la communauté – Comunidad IA Salud-Énergie",
    "meta.unirse.description": "Processus d’adhésion et valeurs partagées de la Comunidad IA Salud-Énergie.",
    "meta.perfil.title": "Profil créé – Comunidad IA Salud-Énergie",
    "meta.perfil.description": "Confirmation de création de profil sur la Comunidad IA Salud-Énergie.",
    "header.logo": "Comunidad IA Salud-Énergie",
    "nav.home": "Accueil",
    "nav.services": "Services",
    "nav.about": "À propos",
    "nav.blog": "Blog",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "language.fr": "FR",
    "language.en": "EN",
    "nav.toggle": "Ouvrir le menu de navigation",
    "footer.description": "Réseau espagnol réunissant praticiens, ingénieurs et chercheurs autour de l’IA appliquée à la santé et à l’énergie.",
    "footer.phone": "+34 91 555 7844",
    "footer.email": "contact@comunidad-iaenergiahealthspain.com",
    "footer.address": "Calle Innovación 1000, Madrid, Espagne",
    "footer.rights": "Tous droits réservés.",
    "footer.manageCookies": "Gérer les cookies",
    "footer.terms": "Conditions d’utilisation",
    "footer.privacy": "Politique de confidentialité",
    "footer.cookies": "Politique de cookies",
    "footer.refund": "Politique de remboursement",
    "footer.disclaimer": "Avis de non-responsabilité",
    "index.hero.tag": "Réseau interdisciplinaire",
    "index.hero.title": "Connecter l’intelligence artificielle, la santé et l’énergie en Espagne",
    "index.hero.subtitle": "La Comunidad IA Salud-Énergie fédère médecins, ingénieurs, chercheurs et décideurs pour identifier des réponses communes aux défis énergétiques et cliniques. La plateforme facilite l’analyse collective, le partage de cas et la coordination de projets pilotes dans les hôpitaux espagnols.",
    "index.hero.primary": "Explorer la communauté",
    "index.hero.secondary": "Consulter les services",
    "index.hero.alt": "Vue intérieure d’un hôpital moderne avec panneaux énergétiques et données analytiques",
    "index.features.title": "Espaces collaboratifs structurés",
    "index.features.subtitle": "Chaque canal de la Comunidad IA Salud-Énergie est conçu pour soutenir une pratique professionnelle responsable, documentée et ouverte aux retours d’expérience.",
    "index.features.card1title": "Forums spécialisés",
    "index.features.card1text": "Discussions modérées sur l’IA appliquée aux soins intensifs, à la gestion énergétique des blocs opératoires et aux réseaux hospitaliers intelligents.",
    "index.features.card2title": "Projets en co-développement",
    "index.features.card2text": "Tableau partagé évaluant les besoins, jalons et indicateurs d’impact pour chaque initiative interdisciplinaire.",
    "index.features.card3title": "Veille structurée",
    "index.features.card3text": "Résumé bimensuel des publications scientifiques, cadres réglementaires et rapports techniques espagnols et européens.",
    "index.highlight.title": "Piloter la transformation",
    "index.highlight.subtitle": "Le réseau apporte des repères concrets pour équilibrer performance énergétique, résilience clinique et innovation responsable.",
    "index.highlight.point1": "Observatoire hospitalier : suivi des indicateurs de consommation, qualité de l’air et continuité des soins.",
    "index.highlight.point2": "Parcours d’expérimentation : retours d’expérience détaillés sur les cas d’usage IA soutenant l’ingénierie clinique.",
    "index.highlight.point3": "Communautés régionales : alignement entre stratégies nationales et spécificités territoriales grâce à des rencontres régulières.",
    "index.stats.label1": "Professionnels actifs",
    "index.stats.value1": "1 250",
    "index.stats.label2": "Cas documentés",
    "index.stats.value2": "184",
    "index.stats.label3": "Groupes régionaux",
    "index.stats.value3": "11",
    "index.stats.label4": "Partenariats académiques",
    "index.stats.value4": "27",
    "index.recommendations.title": "Recommandations d’exploration",
    "index.recommendations.subtitle": "Quelques pistes pour découvrir rapidement les ressources prioritaires de la Comunidad IA Salud-Énergie.",
    "index.recommendations.card1quote": "Commencez par la bibliothèque partagée : les fiches synthétiques permettent d’identifier les architectures techniques déployées dans les hôpitaux espagnols.",
    "index.recommendations.card1meta": "Coordination documentaire",
    "index.recommendations.card2quote": "Consultez la cartographie des capteurs énergétiques hospitaliers. Elle facilite le dialogue entre responsables techniques et équipes soignantes.",
    "index.recommendations.card2meta": "Groupe infrastructures Madrid",
    "index.recommendations.card3quote": "Participez à un entretien collectif sur la gouvernance. Les livrables incluent des matrices de décision et des plans de contingence.",
    "index.recommendations.card3meta": "Cellule gouvernance IA",
    "index.testimonials.title": "Retours de membres",
    "index.testimonials.subtitle": "Des témoignages représentatifs de la collaboration interdisciplinaire au sein du réseau.",
    "index.testimonials.card1quote": "L’analyse croisée entre bio-ingénieurs et responsables énergie a apporté une compréhension fine des arbitrages nécessaires pour nos plans de rénovation.",
    "index.testimonials.card1meta": "Responsable technique – Hôpital universitaire de Valence",
    "index.testimonials.card2quote": "La communauté nous aide à structurer nos protocoles d’essais cliniques intégrant des algorithmes énergétiques. Les retours sont précis et exploitables.",
    "index.testimonials.card2meta": "Coordinateur innovation – Réseau hospitalier Andalous",
    "index.testimonials.card3quote": "Les ateliers thématiques nous ont permis de cadencer le travail entre équipes de recherche IA, services d’ingénierie et directions médicales.",
    "index.testimonials.card3meta": "Chercheuse principale – Institut national d’énergie renouvelable",
    "index.section.resources.title": "Ressources essentielles",
    "index.section.resources.subtitle": "Une sélection de modules favorisant la mise en œuvre de projets IA santé-énergie.",
    "index.section.resources.card1title": "Laboratoire ouvert",
    "index.section.resources.card1text": "Jeux de données validés, procédures d’anonymisation et scripts d’évaluation mis à disposition par les partenaires académiques.",
    "index.section.resources.card2title": "Table ronde mensuelle",
    "index.section.resources.card2text": "Rencontre hybride sur les usages IA pour optimiser la continuité énergétique et la sécurité clinique.",
    "index.section.resources.card3title": "Observatoire réglementaire",
    "index.section.resources.card3text": "Analyse collaborative des normes espagnoles et européennes liées à la gestion technique et aux systèmes d’aide à la décision.",
    "index.section.callout.title": "Prendre part aux travaux collectifs",
    "index.section.callout.subtitle": "Les contributions sont structurées par axes thématiques afin de consolider des livrables partagés.",
    "index.section.callout.point1": "Documentation standardisée des cas d’usage",
    "index.section.callout.point2": "Référentiels d’indicateurs énergie-santé",
    "index.section.callout.point3": "Plans de résilience technique et clinique",
    "common.sectionTitle": "Titre de section",
    "services.hero.title": "Panorama des services collaboratifs",
    "services.hero.subtitle": "Forums thématiques, groupes régionaux, événements professionnels, tableau de projets et bibliothèque partagée structurent la coopération interdisciplinaire.",
    "services.hero.alt": "Professionnels collaborant autour d’écrans analytiques dans un espace de travail moderne",
    "services.item1.title": "Forums thématiques",
    "services.item1.text": "Chaque forum est modéré par un binôme santé-énergie, garantissant la qualité des discussions et la consolidation de résumés analytiques.",
    "services.item2.title": "Groupes régionaux",
    "services.item2.text": "Onze groupes diffusent les initiatives territoriales, mutualisent les inventaires d’équipements et partagent leurs plans d’optimisation.",
    "services.item3.title": "Événements professionnels",
    "services.item3.text": "Ateliers méthodologiques, visites techniques et séminaires hybrides favorisent l’alignement entre décideurs clinique et ingénierie.",
    "services.item4.title": "Tableau de projets",
    "services.item4.text": "Les porteurs décrivent objectifs, gouvernance, jalons et besoins en expertise, facilitant l’implication rapide de nouveaux contributeurs.",
    "services.item5.title": "Bibliothèque partagée",
    "services.item5.text": "Rapports d’essais, protocoles d’analyse et retours d’expérience comparables constituent une base de connaissance vivante.",
    "services.process.title": "Organisation des contributions",
    "services.process.point1": "Référents thématiques chargés de valider les publications.",
    "services.process.point2": "Calendrier commun des livrables, mis à jour mensuellement.",
    "services.process.point3": "Outils de suivi qualitatif et indicateurs énergie-santé partagés.",
    "about.hero.title": "Une initiative portée par la coopération interdisciplinaire",
    "about.hero.subtitle": "La Comunidad IA Salud-Énergie est née de la convergence entre hôpitaux publics, universités techniques et opérateurs énergétiques espagnols.",
    "about.hero.alt": "Salle de conférence avec participants et grand écran de visualisation de données",
    "about.mission.title": "Mission",
    "about.mission.text": "Créer un cadre durable de collaboration pour articuler innovation clinique, sobriété énergétique et résilience des infrastructures critiques.",
    "about.vision.title": "Vision",
    "about.vision.text": "Favoriser des solutions IA transparentes, auditables et alignées avec les besoins opérationnels des professionnels de santé en Espagne.",
    "about.values.title": "Valeurs partagées",
    "about.values.point1": "Interopérabilité et documentation continue.",
    "about.values.point2": "Éthique, robustesse et évaluation permanente.",
    "about.values.point3": "Solidarité territoriale et mutualisation des ressources.",
    "about.timeline.title": "Étapes clés",
    "about.timeline.item1": "2019 – Lancement d’un premier groupe de travail santé-énergie à Madrid.",
    "about.timeline.item2": "2021 – Intégration des équipes de recherche IA des universités publiques espagnoles.",
    "about.timeline.item3": "2022 – Déploiement de la bibliothèque partagée et des indicateurs communs.",
    "about.timeline.item4": "2023 – Structuration des onze groupes régionaux et mise en place des forums modérés.",
    "about.team.title": "Coordination",
    "about.team.text": "La coordination est assurée par un comité transversal associant directions hospitalières, responsables énergétiques et chercheurs. Chaque axe dispose d’une équipe dédiée pour accompagner les membres dans l’utilisation des outils collaboratifs.",
    "blog.hero.title": "Analyses et retours d’expérience",
    "blog.hero.subtitle": "Le blog rassemble des contributions techniques pour documenter méthodologies, cadres de gouvernance et indicateurs pertinents.",
    "blog.hero.alt": "Personne consultant un tableau de bord de données énergétiques sur un écran large",
    "blog.list.post1.title": "Modèles couplés pour l’efficacité énergétique hospitalière",
    "blog.list.post1.excerpt": "Comment les modèles énergétiques, les données cliniques et l’IA temps réel s’articulent dans les hôpitaux espagnols.",
    "blog.list.post1.link": "Lire l’analyse",
    "blog.list.post2.title": "Cadre de gouvernance IA santé-énergie",
    "blog.list.post2.excerpt": "Aligner conformité clinique, gestion énergétique et responsabilité algorithmique.",
    "blog.list.post2.link": "Explorer le cadre",
    "blog.list.post3.title": "Interopérabilité des données critiques",
    "blog.list.post3.excerpt": "Méthodes pour synchroniser SI hospitaliers et plateformes énergétiques.",
    "blog.list.post3.link": "Comprendre les options",
    "blog.list.post4.title": "Maintenance prédictive intégrée",
    "blog.list.post4.excerpt": "Observabilité des actifs énergétiques et assistance clinique.",
    "blog.list.post4.link": "Étudier le dossier",
    "blog.list.post5.title": "Simulation multi-agent des urgences",
    "blog.list.post5.excerpt": "Rapprocher flux énergétiques et coordination médicale.",
    "blog.list.post5.link": "Analyser le scénario",
    "post1.h1": "Modèles couplés pour l’efficacité énergétique hospitalière en Espagne",
    "post1.h2": "Contextualiser l’intégration entre systèmes cliniques et énergétiques",
    "post1.p1": "Les hôpitaux espagnols combinent désormais données cliniques, télémétrie des équipements et historiques énergétiques afin d’anticiper les pics de charge et de maintenir des environnements stables. Cette approche nécessite la création de référentiels communs où ingénieurs, responsables biomédicaux et cliniciens définissent des contraintes partagées. L’IA intervient alors pour détecter les dérives d’usage et proposer des scénarios d’ajustement compatibles avec les circuits de soins.",
    "post1.p2": "La convergence repose sur des ensembles de données harmonisés. Les flux provenant des automates de ventilation, des capteurs d’éclairage ou des systèmes de refroidissement sont synchronisés avec les plannings opératoires et l’occupation des services critiques. Cette cartographie micro-temporelle permet d’éviter les effets de seuil : les algorithmes identifient les périodes de transition où les ajustements énergétiques ne doivent pas compromettre l’activité clinique.",
    "post1.h3": "Élaborer des modèles hybrides et mesurer les impacts",
    "post1.p3": "Les équipes techniques développent des jumeaux numériques couplant modèles thermiques, simulations d’usage et projections d’activité médicale. Chaque itération est validée avec les référents cliniques pour s’assurer que les recommandations respectent les protocoles de sécurité. Les résultats sont partagés dans la Comunidad IA Salud-Énergie via des fiches synthétiques contenant hypothèses, limites, métriques d’impact et plan de déploiement.",
    "post1.p4": "La mesure des résultats s’appuie sur trois familles d’indicateurs : stabilité des environnements critiques, consommation énergétique spécifique par zone fonctionnelle et perception des équipes soignantes. Les retours d’expérience montrent que la réduction des variations thermiques contribue à diminuer les alarmes techniques et facilite la maintenance préventive. Les tableaux de suivi partagés permettent de capitaliser ces apprentissages pour d’autres centres hospitaliers.",
    "post1.p5": "Le cadre espagnol encourage une documentation fine des décisions algorithmiques. Chaque ajustement proposé par le modèle est associé à une justification énergétique et clinique. Les comités de gouvernance vérifient ainsi la cohérence avec les règles nationales. Cette transparence renforce la confiance entre disciplines et ouvre la voie à des coopérations transversales durables.",
    "post1.p6": "Enfin, la communauté a mis en place un dispositif de formation continue afin que les utilisateurs interprètent correctement les tableaux de bord intelligents. Les ateliers associent exercices pratiques, retours terrain et scénarios d’incident. L’objectif est de consolider une culture commune de l’IA hospitalière où la performance énergétique devient un indicateur partagé, sans jamais compromettre la qualité des soins.",
    "post2.h1": "Cadre de gouvernance pour l’IA santé-énergie dans les hôpitaux espagnols",
    "post2.h2": "Structurer les responsabilités",
    "post2.p1": "La mise en œuvre de l’IA à l’interface santé-énergie multiplie les interactions entre directions médicales, ingénierie clinique, exploitants de bâtiments et services numériques. La Comunidad IA Salud-Énergie propose un cadre de gouvernance articulé autour de quatre comités : conformité réglementaire, sûreté opérationnelle, supervision algorithmique et accompagnement des utilisateurs. Chaque comité documente ses décisions et les publie sur la plateforme afin d’assurer une traçabilité complète.",
    "post2.p2": "Les responsabilités sont réparties selon un principe de coresponsabilité. Les médecins garantissent l’alignement avec les protocoles de soins, tandis que les responsables énergie évaluent l’impact sur les infrastructures critiques. Les équipes numériques s’assurent de la cybersécurité et de l’intégrité des données. Ce modèle favorise un dialogue constant visant à équilibrer performance énergétique et continuité clinique.",
    "post2.h3": "Procédures, audits et amélioration continue",
    "post2.p3": "Le cadre inclut des procédures d’homologation avant déploiement. Les scénarios d’usage sont testés dans des environnements simulés associant charges énergétiques réelles et flux patients. Des rapports d’audit documentent les hypothèses de modèle, les limites observées et les conditions d’utilisation. Ils sont déposés dans la bibliothèque partagée pour permettre aux autres membres d’adapter ces retours d’expérience.",
    "post2.p4": "Des revues trimestrielles évaluent la pertinence des modèles en service. Elles examinent les indicateurs d’efficacité énergétique, les incidents remontés par les utilisateurs et les ajustements apportés aux algorithmes. Les conclusions sont résumées sous forme de bulletins accessibles aux membres. Cette transparence nourrit la confiance entre disciplines et permet d’identifier rapidement les besoins de recalibrage.",
    "post2.p5": "Le cadre de gouvernance accorde une place centrale à l’accompagnement des utilisateurs finaux. Les professionnels de santé reçoivent des guides contextualisés décrivant les variables suivies, les seuils critiques et les actions recommandées. Les exploitants énergétiques disposent de plans de contingence détaillant la conduite à tenir en cas de rupture de communication avec les systèmes IA.",
    "post2.p6": "Cette approche systémique renforce la capacité des hôpitaux espagnols à intégrer l’IA sans fragiliser la gouvernance des risques. Les membres du réseau mettent à jour collectivement les référentiels afin d’anticiper les évolutions réglementaires et technologiques.",
    "post3.h1": "Interopérabilité des données santé-énergie : référentiel pour la Comunidad IA",
    "post3.h2": "Cartographier les flux critiques",
    "post3.p1": "L’interopérabilité est devenue un enjeu central pour l’IA appliquée conjointement à la santé et à l’énergie. Chaque hôpital gère des systèmes hétérogènes : dossiers patients, plateformes de supervision énergétique, solutions de maintenance assistée. La Comunidad IA Salud-Énergie a élaboré un référentiel listant six familles de flux prioritaires, dont les données environnementales des blocs opératoires, les informations biomédicales anonymisées et les états de fonctionnement des centrales thermiques.",
    "post3.p2": "Cette cartographie s’accompagne d’une grille d’évaluation qualitative. Les membres analysent la profondeur historique disponible, la fréquence d’actualisation, les protocoles de sécurité associés et la sensibilité des données. Les résultats orientent les priorités de standardisation et de mise en qualité.",
    "post3.h3": "Standards d’échange et gouvernance des métadonnées",
    "post3.p3": "Le référentiel encourage l’usage combiné de standards ouverts. Les échanges énergétiques s’appuient sur des ontologies sectorielles, tandis que les données cliniques suivent les cadres HL7 FHIR ou openEHR. Un dictionnaire commun des terminologies permet de maintenir la cohérence sémantique : chaque champ est documenté, assorti de règles de validation et de contextes d’utilisation.",
    "post3.p4": "Les hôpitaux membres publient leurs plans de mapping dans la bibliothèque partagée. Les documents décrivent les transformations appliquées, la gestion des valeurs manquantes et les contrôles de cohérence. Les retours d’expérience montrent que cette documentation accélère l’intégration de nouveaux sites et limite les efforts de rétro-ingénierie.",
    "post3.p5": "Les équipes ont mis en place un mécanisme de catalogage collaboratif. Chaque jeu de données est référencé avec des métadonnées décrivant les conditions d’acquisition, la granularité temporelle, les restrictions d’usage et les contacts techniques. Cette démarche facilite la recherche de corpus adaptés à chaque projet IA.",
    "post3.p6": "Enfin, la communauté propose un mécanisme de revue croisée : avant toute mise en production d’un connecteur, un binôme santé-énergie examine la conformité aux protocoles de sécurité et la pertinence des champs exposés. Cette vérification croisée renforce la confiance et prévient les divulgations involontaires.",
    "post4.h1": "Maintenance prédictive des infrastructures hospitalières : approche intégrée",
    "post4.h2": "Combiner supervision énergétique et contexte clinique",
    "post4.p1": "Les infrastructures hospitalières espagnoles s’appuient sur des réseaux d’équipements critiques : unités de traitement d’air, groupes électrogènes, systèmes de stérilisation. La maintenance prédictive vise à anticiper les défaillances en exploitant les mesures temps réel et les historiques d’intervention. La Comunidad IA Salud-Énergie coordonne un cadre commun pour garantir l’alignement entre impératifs cliniques et opérations techniques.",
    "post4.p2": "Chaque composant dispose d’un profil de criticité. Les algorithmes évaluent la probabilité de dégradation en tenant compte des conditions d’usage : charge énergétique, durée d’exposition et contraintes climatiques. Les résultats sont contextualisés avec les plannings de soins afin de programmer les interventions hors des périodes sensibles.",
    "post4.h3": "Chaîne de valeur et retours terrain",
    "post4.p3": "La chaîne de maintenance prédictive comprend quatre phases : collecte des données, standardisation, modélisation et restitution. Les membres documentent les protocoles de capteurs, les stratégies de nettoyage de données et les indicateurs de fiabilité. Les tableaux de bord partagés affichent des scénarios d’intervention avec justification détaillée.",
    "post4.p4": "Les retours terrain montrent que l’association de données énergétiques et cliniques améliore la précision des alertes. Par exemple, l’analyse de la consommation électrique des pompes à vide couplée aux cycles opératoires permet d’anticiper les pertes de performance. Les équipes de maintenance peuvent planifier un remplacement ciblé sans perturber les services critiques.",
    "post4.p5": "La communauté encourage une documentation rigoureuse des incidents résolus. Chaque fiche comporte les symptômes, la détection par IA, la validation humaine et les leçons apprises. Ces informations nourrissent la bibliothèque de connaissances et alimentent les programmes de formation continue.",
    "post4.p6": "Enfin, les groupes régionaux comparent leurs référentiels de maintenance. Les échanges favorisent l’harmonisation des contrats d’entretien et la mutualisation d’indicateurs. Cette approche collective réduit les disparités entre établissements et renforce la résilience des infrastructures hospitalières espagnoles.",
    "post5.h1": "Simulation multi-agent pour la gestion des urgences hospitalières",
    "post5.h2": "Relier flux énergétiques et coordination clinique",
    "post5.p1": "La gestion des urgences repose sur une coordination fine entre disponibilité des ressources médicales et résilience énergétique. Pour anticiper les situations complexes, plusieurs hôpitaux espagnols expérimentent des simulations multi-agent. Elles modélisent les interactions entre équipes médicales, infrastructures énergétiques et flux de patients. La Comunidad IA Salud-Énergie fournit un cadre de partage des scénarios et des paramètres utilisés.",
    "post5.p2": "Chaque agent représente une entité opérationnelle : salle d’opération, unité mobile, transformateur électrique ou station de production d’eau glacée. Les interactions sont régies par des règles inspirées des protocoles d’urgence. Les simulations évaluent la capacité du système à absorber des pics d’activité tout en maintenant une qualité d’air et une température conformes.",
    "post5.h3": "Exploitation et transfert des résultats",
    "post5.p3": "Les sorties des simulations sont traduites en plans d’action. Les équipes identifient des configurations critiques, par exemple la perte temporaire d’un groupe électrogène pendant un afflux massif de patients. Les recommandations détaillent les actions prioritaires, les acteurs impliqués et les indicateurs de suivi.",
    "post5.p4": "Les membres de la communauté mutualisent les scripts de simulation, les hypothèses de calibration et les données d’entrée. Une attention particulière est portée à l’anonymisation des événements cliniques pour respecter les cadres de protection. Les ateliers collaboratifs permettent de comparer différents outils de modélisation et d’enrichir les bibliothèques de scénarios.",
    "post5.p5": "Les retours d’expérience soulignent l’intérêt de coupler les simulations avec des exercices pratiques. Les équipes mettent en œuvre les plans dans des environnements contrôlés et ajustent les procédures selon les observations. Cette boucle d’amélioration renforce la coordination interdisciplinaire.",
    "post5.p6": "À terme, la Comunidad IA Salud-Énergie envisage de constituer un référentiel national de scénarios multi-agent. Il servirait de base aux formations des nouveaux membres et faciliterait la comparaison entre régions. Cette démarche collective consolide la préparation des hôpitaux espagnols face aux situations extrêmes.",
    "contact.hero.title": "Entrer en relation avec la Comunidad IA Salud-Énergie",
    "contact.hero.subtitle": "Le secrétariat reçoit les demandes de collaboration, questions techniques et propositions de projets. Chaque message est relu par l’équipe correspondant à la thématique.",
    "contact.hero.alt": "Personne envoyant un message via un ordinateur portable dans un espace de travail moderne",
    "contact.info.title": "Coordonnées",
    "contact.info.phone": "Téléphone",
    "contact.info.email": "Courriel",
    "contact.info.address": "Adresse",
    "contact.info.schedule": "Disponibilité",
    "contact.info.scheduleText": "Du lundi au vendredi, 09:00 - 18:00 (CET).",
    "contact.map.caption": "Localisation de la Comunidad IA Salud-Énergie à Madrid",
    "contact.form.title": "Formulaire sécurisé",
    "contact.form.subtitle": "Merci de décrire votre besoin avec précision afin que nous puissions mobiliser les bons interlocuteurs.",
    "contact.form.name": "Nom complet",
    "contact.form.org": "Organisation",
    "contact.form.email": "Adresse électronique",
    "contact.form.phone": "Téléphone professionnel",
    "contact.form.topic": "Thématique principale",
    "contact.form.topic.option1": "Synthèse documentaire",
    "contact.form.topic.option2": "Rejoint un groupe régional",
    "contact.form.topic.option3": "Tableau de projets",
    "contact.form.topic.option4": "Contribution scientifique",
    "contact.form.message": "Message détaillé",
    "contact.form.submit": "Envoyer la demande",
    "contact.form.reset": "Réinitialiser",
    "faq.hero.title": "Questions fréquentes",
    "faq.hero.subtitle": "Conditions d’adhésion, fonctionnement des forums, confidentialité et support technique regroupés dans une foire aux questions.",
    "faq.hero.alt": "Illustration de questions et réponses sur fond numérique",
    "faq.q1": "Qui peut rejoindre la Comunidad IA Salud-Énergie ?",
    "faq.a1": "Le réseau s’adresse aux professionnels et chercheuses et chercheurs basés en Espagne impliqués dans des projets liant santé, énergie et intelligence artificielle. Chaque candidature est examinée par le comité d’admission afin de vérifier l’alignement avec les valeurs collectives.",
    "faq.q2": "Comment sont structurés les forums thématiques ?",
    "faq.a2": "Chaque forum est animé par un binôme clinico-technique. Les discussions sont archivées et synthétisées mensuellement. Des règles de modération assurent la qualité et évitent la duplication de contenus.",
    "faq.q3": "Quels types de données peuvent être partagés ?",
    "faq.a3": "Seules les données anonymisées ou agrégées sont acceptées. Les membres doivent respecter les cadres réglementaires espagnols et européens, tout en documentant les traitements appliqués.",
    "faq.q4": "Comment accéder aux événements ?",
    "faq.a4": "Les événements sont annoncés dans le calendrier partagé. Les personnes inscrites reçoivent les modalités de participation, le programme détaillé et les documents préparatoires.",
    "faq.q5": "Existe-t-il un support technique ?",
    "faq.a5": "Oui, une cellule d’assistance accompagne les membres pour la gestion des accès, l’utilisation du tableau de projets et le dépôt de documents dans la bibliothèque partagée.",
    "faq.q6": "Comment sont prises les décisions de gouvernance ?",
    "faq.a6": "Les décisions sont prises collectivement lors de réunions trimestrielles associant représentants des groupes régionaux, comité scientifique et coordination énergétique. Les résumés sont publiés dans la bibliothèque.",
    "terms.hero.title": "Conditions d’utilisation",
    "terms.hero.subtitle": "Les conditions suivantes régissent l’usage de la plateforme Comunidad IA Salud-Énergie. Merci de les lire attentivement.",
    "terms.section1.title": "1. Objet",
    "terms.section1.text": "La présente charte encadre l’accès et l’utilisation de la plateforme collaborative Comunidad IA Salud-Énergie par des professionnels situés en Espagne.",
    "terms.section2.title": "2. Définitions",
    "terms.section2.text": "On entend par « Plateforme » l’espace numérique comunidad-iaenergiahealthspain.com ; par « Membre » toute personne disposant d’un compte validé ; par « Contenu » toute information publiée sur la plateforme.",
    "terms.section3.title": "3. Acceptation",
    "terms.section3.text": "L’accès à la plateforme implique l’acceptation sans réserve des présentes conditions. En cas de désaccord, l’utilisateur doit cesser toute utilisation.",
    "terms.section4.title": "4. Admissibilité",
    "terms.section4.text": "Les membres doivent justifier d’une activité en lien avec l’IA, la santé ou l’énergie. La coordination peut refuser une demande si elle ne respecte pas ces critères.",
    "terms.section5.title": "5. Comptes",
    "terms.section5.text": "Les membres sont responsables de la confidentialité de leurs identifiants et de l’exactitude des informations fournies lors de l’inscription.",
    "terms.section6.title": "6. Utilisation permise",
    "terms.section6.text": "La plateforme doit être utilisée pour des échanges professionnels, la documentation de projets et le partage de ressources conformes au mandat du réseau.",
    "terms.section7.title": "7. Contenus",
    "terms.section7.text": "Les contributeurs s’engagent à publier des contenus exacts, licites et respectueux. Ils conservent leurs droits mais accordent une licence non exclusive pour la diffusion interne.",
    "terms.section8.title": "8. Propriété intellectuelle",
    "terms.section8.text": "Les marques, logos, interfaces et contenus structurants restent la propriété de la Comunidad IA Salud-Énergie ou de ses partenaires et ne peuvent être reproduits sans autorisation.",
    "terms.section9.title": "9. Modération",
    "terms.section9.text": "La coordination peut retirer tout contenu qui ne respecte pas les règles éditoriales ou compromet la sécurité des données.",
    "terms.section10.title": "10. Événements",
    "terms.section10.text": "Les participants aux événements doivent respecter les règles de conduite communiquées. La coordination peut adapter le programme selon les contraintes techniques.",
    "terms.section11.title": "11. Ressources tierces",
    "terms.section11.text": "La plateforme peut contenir des liens vers des ressources externes. La coordination ne saurait être tenue responsable de leur contenu ou de leur disponibilité.",
    "terms.section12.title": "12. Données personnelles",
    "terms.section12.text": "Le traitement des données personnelles est décrit dans la politique de confidentialité. Les membres conservent leurs droits d’accès, de rectification et d’effacement.",
    "terms.section13.title": "13. Limitation",
    "terms.section13.text": "La plateforme est fournie sans assurance de disponibilité continue. La coordination met en œuvre des moyens raisonnables pour assurer la sécurité et la stabilité.",
    "terms.section14.title": "14. Droit applicable",
    "terms.section14.text": "Les présentes conditions sont régies par le droit espagnol. Les litiges seront soumis aux juridictions compétentes de Madrid, après tentative de résolution amiable.",
    "privacy.hero.title": "Politique de confidentialité",
    "privacy.hero.subtitle": "Cette politique décrit les traitements des données personnelles réalisés par la Comunidad IA Salud-Énergie.",
    "privacy.section1.title": "1. Responsable du traitement",
    "privacy.section1.text": "Le responsable du traitement est Comunidad IA Salud-Énergie, Calle Innovación 1000, Madrid, Espagne.",
    "privacy.section2.title": "2. Données collectées",
    "privacy.section2.text": "Nous collectons des données d’identification, informations professionnelles, métadonnées de connexion, contributions publiées et interactions avec les services.",
    "privacy.section3.title": "3. Finalités",
    "privacy.section3.text": "Les données sont utilisées pour gérer les comptes, sécuriser les accès, modérer les contenus, organiser les événements et produire des statistiques agrégées.",
    "privacy.section4.title": "4. Base légale",
    "privacy.section4.text": "Les traitements reposent sur l’exécution des engagements contractuels, l’intérêt légitime de coordination du réseau et, le cas échéant, le consentement explicite.",
    "privacy.section5.title": "5. Conservation",
    "privacy.section5.text": "Les données sont conservées pendant la durée d’adhésion augmentée d’un an pour la gestion administrative et la traçabilité des contributions.",
    "privacy.section6.title": "6. Partage",
    "privacy.section6.text": "Les données peuvent être partagées avec des partenaires académiques et techniques pour la bonne marche du réseau, dans la limite des finalités annoncées.",
    "privacy.section7.title": "7. Sécurité",
    "privacy.section7.text": "Des mesures organisationnelles et techniques protègent les données : contrôle d’accès, chiffrement des communications et revue régulière des habilitations.",
    "privacy.section8.title": "8. Droits",
    "privacy.section8.text": "Vous disposez de droits d’accès, rectification, effacement, limitation, opposition et portabilité. Toute demande peut être adressée via le formulaire de contact.",
    "privacy.section9.title": "9. Sous-traitance",
    "privacy.section9.text": "Les sous-traitants sont sélectionnés pour leur conformité et s’engagent contractuellement à protéger les informations traitées.",
    "privacy.section10.title": "10. Actualisation",
    "privacy.section10.text": "Cette politique peut être mise à jour pour refléter l’évolution des pratiques. Les membres seront informés des modifications substantielles.",
    "cookies.hero.title": "Politique de cookies",
    "cookies.hero.subtitle": "Cette page décrit les cookies utilisés sur comunidad-iaenergiahealthspain.com et vos options de gestion.",
    "cookies.intro": "Nous utilisons des cookies nécessaires au fonctionnement du site et, sous réserve de votre consentement, des cookies de préférences, d’analyse et de communication.",
    "cookies.table.name": "Nom",
    "cookies.table.provider": "Fournisseur",
    "cookies.table.type": "Type",
    "cookies.table.purpose": "Finalité",
    "cookies.table.duration": "Durée",
    "cookies.row1.name": "session_id",
    "cookies.row1.provider": "Comunidad IA",
    "cookies.row1.type": "Nécessaire",
    "cookies.row1.purpose": "Maintien de la session et protection contre les accès non autorisés.",
    "cookies.row1.duration": "24 heures",
    "cookies.row2.name": "lang_pref",
    "cookies.row2.provider": "Comunidad IA",
    "cookies.row2.type": "Préférence",
    "cookies.row2.purpose": "Mémorisation de la langue sélectionnée par l’utilisateur.",
    "cookies.row2.duration": "12 mois",
    "cookies.row3.name": "analytics_scope",
    "cookies.row3.provider": "Comunidad IA",
    "cookies.row3.type": "Analyse",
    "cookies.row3.purpose": "Mesure agrégée des parcours et compréhension de l’usage des contenus.",
    "cookies.row3.duration": "6 mois",
    "cookies.row4.name": "campaign_context",
    "cookies.row4.provider": "Comunidad IA",
    "cookies.row4.type": "Communication",
    "cookies.row4.purpose": "Suivi de l’efficacité des communications institutionnelles internes.",
    "cookies.row4.duration": "3 mois",
    "refund.hero.title": "Politique de remboursement",
    "refund.hero.subtitle": "Modalités appliquées en cas d’ajustement lié aux services informatifs fournis par la Comunidad IA Salud-Énergie.",
    "refund.section1": "1. Portée : cette politique couvre les contributions logistiques ou documentaires demandées pour l’accès à certains services informatifs.",
    "refund.section2": "2. Demandes : toute requête doit être adressée via le formulaire de contact en précisant la référence de l’événement ou du service.",
    "refund.section3": "3. Délais : les demandes sont examinées sous quinze jours ouvrés.",
    "refund.section4": "4. Éligibilité : seules les situations liées à un empêchement majeur, un report ou une modification substantielle du service sont éligibles.",
    "refund.section5": "5. Évaluation : un comité analyse les justificatifs fournis et contacte la personne pour compléter les informations si nécessaire.",
    "refund.section6": "6. Modalité : la coordination privilégie un avoir sur un service équivalent. Un remboursement peut être envisagé lorsque l’avoir n’est pas pertinent.",
    "refund.section7": "7. Notifications : la décision est communiquée par courriel avec mention des motifs.",
    "refund.section8": "8. Délais de versement : lorsqu’un remboursement est accordé, le versement intervient sous trente jours ouvrés.",
    "refund.section9": "9. Litiges : toute contestation est examinée par la coordination. Une médiation peut être proposée.",
    "refund.section10": "10. Révision : la politique est révisée annuellement et publiée sur le site.",
    "disclaimer.hero.title": "Avis de non-responsabilité",
    "disclaimer.hero.subtitle": "Conditions dans lesquelles les informations de la Comunidad IA Salud-Énergie sont mises à disposition.",
    "disclaimer.section1": "Les informations publiées sur ce site sont fournies à titre informatif. Elles ne constituent ni un conseil médical, ni une prescription énergétique.",
    "disclaimer.section2": "La Comunidad IA Salud-Énergie met en œuvre des efforts raisonnables pour garantir l’exactitude des contenus, sans certitude absolue quant à leur exhaustivité.",
    "disclaimer.section3": "Les membres restent responsables des décisions prises sur la base des informations consultées. Toute mise en œuvre doit respecter les cadres réglementaires applicables.",
    "disclaimer.section4": "Les liens externes sont fournis pour convenance. La Comunidad IA Salud-Énergie n’exerce aucun contrôle sur ces ressources et décline toute responsabilité quant à leur contenu.",
    "disclaimer.section5": "La plateforme peut être suspendue pour maintenance ou mise à jour. La coordination s’efforce de limiter la durée des interruptions.",
    "gracias.hero.title": "Message reçu",
    "gracias.hero.subtitle": "Merci pour votre contribution. L’équipe de la Comunidad IA Salud-Énergie examinera votre demande et vous répondra dans les meilleurs délais.",
    "gracias.hero.alt": "Icône de confirmation sur fond lumineux",
    "gracias.back": "Retour à l’accueil",
    "404.hero.title": "Ressource introuvable",
    "404.hero.subtitle": "La page demandée n’existe plus ou a été déplacée. Utilisez les liens ci-dessous pour retrouver votre chemin.",
    "404.hero.alt": "Illustration d’une boussole dans un environnement numérique",
    "404.action.primary": "Revenir à l’accueil",
    "404.action.secondary": "Accéder au blog",
    "members.hero.title": "Communauté de membres",
    "members.hero.subtitle": "La Comunidad IA Salud-Énergie rassemble des profils variés : médecins spécialistes, ingénieurs énergéticiens, data scientists et responsables de la transformation hospitalière.",
    "members.hero.alt": "Groupe de professionnels discutant autour d’un mur de données",
    "members.section1.title": "Profils représentatifs",
    "members.section1.item1": "Ingénieurs en efficacité énergétique hospitalière participant à la définition des plans de modernisation.",
    "members.section1.item2": "Cliniciens référents pilotant l’intégration des algorithmes dans les parcours de soins.",
    "members.section1.item3": "Chercheurs en sciences des données développant des modèles explicables et auditables.",
    "members.section1.item4": "Gestionnaires territoriaux coordonnant les stratégies inter-hospitalières.",
    "members.section2.title": "Engagements partagés",
    "members.section2.item1": "Documenter chaque expérimentation et en partager les résultats.",
    "members.section2.item2": "Respecter la confidentialité des informations sensibles.",
    "members.section2.item3": "Contribuer aux groupes régionaux et aux forums thématiques.",
    "forums.hero.title": "Forums thématiques",
    "forums.hero.subtitle": "Espaces de discussions modérées pour analyser des cas, comparer des outils et élaborer des documents de référence.",
    "forums.hero.alt": "Salle de réunion avec écrans affichant des graphiques et participants concentrés",
    "forums.section1.title": "Structure des forums",
    "forums.section1.item1": "Bloc opératoire intelligent : suivi énergétique et soutien aux anesthésistes.",
    "forums.section1.item2": "Résilience des infrastructures critiques : centrales de secours, micro-réseaux et stockage.",
    "forums.section1.item3": "Qualité de l’air et IA préventive dans les services sensibles.",
    "forums.section1.item4": "Interopérabilité des données entre systèmes hospitaliers et plateformes énergétiques.",
    "forums.section2.title": "Modalités de participation",
    "forums.section2.item1": "Inscription validée par les modérateurs en fonction de l’expertise déclarée.",
    "forums.section2.item2": "Synthèses partagées mensuellement dans la bibliothèque.",
    "forums.section2.item3": "Webinaires dédiés aux retours d’expérience majeurs.",
    "groups.hero.title": "Groupes régionaux",
    "groups.hero.subtitle": "Onze groupes couvrent l’ensemble du territoire espagnol afin de prendre en compte les spécificités climatiques, énergétiques et sanitaires.",
    "groups.hero.alt": "Carte stylisée de l’Espagne avec zones lumineuses",
    "groups.section1.title": "Axes de travail",
    "groups.section1.item1": "Audit énergétique des établissements publics.",
    "groups.section1.item2": "Déploiement des capteurs IoT et standards de données.",
    "groups.section1.item3": "Plans de continuité et coordination avec les autorités locales.",
    "groups.section1.item4": "Partage des modèles économiques et des cadres contractuels.",
    "projects.hero.title": "Tableau de projets collaboratifs",
    "projects.hero.subtitle": "Un panorama des initiatives en cours, avec leurs jalons, besoins en expertise et livrables attendus.",
    "projects.hero.alt": "Tableau de suivi de projets affiché sur un écran avec des indicateurs lumineux",
    "projects.section1.title": "Projets phares",
    "projects.section1.item1": "Optimisation énergétique des blocs opératoires dans trois hôpitaux madrilènes, avec suivi de la qualité de l’air.",
    "projects.section1.item2": "Plateforme de maintenance prédictive pour les centrales thermiques hospitalières en Catalogne.",
    "projects.section1.item3": "Programme de simulation multi-agent pour la gestion des urgences en Andalousie.",
    "projects.section2.title": "Contributions recherchées",
    "projects.section2.item1": "Analystes de données pour l’annotation de séries temporelles.",
    "projects.section2.item2": "Spécialistes cybersécurité pour auditer les architectures connectées.",
    "projects.section2.item3": "Responsables cliniques pour valider les scénarios d’usage.",
    "events.hero.title": "Calendrier d’événements",
    "events.hero.subtitle": "Rencontres techniques, ateliers méthodologiques et visites de terrain organisés par la Comunidad IA Salud-Énergie.",
    "events.hero.alt": "Auditorium avec public assistant à une présentation technique",
    "events.section1.title": "Événements à venir",
    "events.section1.item1": "Atelier sur l’optimisation énergétique des unités de soins intensifs – Madrid.",
    "events.section1.item2": "Rencontre régionale sur les micro-réseaux hospitaliers – Bilbao.",
    "events.section1.item3": "Session d’échanges sur la gouvernance des données – Séville.",
    "events.section2.title": "Participation",
    "events.section2.item1": "Inscription via le tableau de projets ou le formulaire de contact.",
    "events.section2.item2": "Synthèse systématique disponible dans la bibliothèque.",
    "events.section2.item3": "Sessions hybrides combinant présentiel et diffusion sécurisée.",
    "library.hero.title": "Bibliothèque de connaissances",
    "library.hero.subtitle": "Documentation technique structurée : jeux de données, guides méthodologiques, retours d’expérience et analyses réglementaires.",
    "library.hero.alt": "Étagère numérique avec dossiers et documents organisés",
    "library.section1.title": "Catégories principales",
    "library.section1.item1": "Architecture des systèmes IA santé-énergie.",
    "library.section1.item2": "Guides d’interopérabilité et dictionnaires de données.",
    "library.section1.item3": "Études d’impact énergétique et climatique.",
    "library.section1.item4": "Cadres de gouvernance et matrices de responsabilités.",
    "experts.hero.title": "Annuaire d’experts",
    "experts.hero.subtitle": "Identifier les référents techniques, cliniques et académiques prêts à partager leur expérience.",
    "experts.hero.alt": "Portraits de professionnels affichés sur un mur numérique",
    "experts.section1.title": "Compétences clés",
    "experts.section1.item1": "Optimisation énergétique hospitalière et analyse des charges.",
    "experts.section1.item2": "Développement de modèles IA explicables et auditables.",
    "experts.section1.item3": "Gestion du changement et accompagnement des équipes cliniques.",
    "experts.section1.item4": "Sécurité des infrastructures critiques et résilience cyber.",
    "news.hero.title": "Actualités",
    "news.hero.subtitle": "Veille stratégique, synthèses réglementaires et retours d’expérimentation des membres.",
    "news.hero.alt": "Flux d’actualités affiché sur un écran transparent",
    "news.section1.title": "Dernières publications",
    "news.section1.item1": "Publication d’un dossier sur la résilience énergétique des blocs opératoires.",
    "news.section1.item2": "Analyse des mesures espagnoles relatives à la décarbonation hospitalière.",
    "news.section1.item3": "Retour sur l’atelier gouvernance IA organisé à Barcelone.",
    "companies.hero.title": "Partenaires institutionnels",
    "companies.hero.subtitle": "Organisations accompagnant la Comunidad IA Salud-Énergie dans ses travaux de recherche et de diffusion.",
    "companies.hero.alt": "Logotypes d’organisations présentés sur un fond lumineux",
    "companies.section1.title": "Partenaires principaux",
    "companies.section1.item1": "Réseau national d’hôpitaux publics espagnols.",
    "companies.section1.item2": "Instituts de recherche en énergie durable.",
    "companies.section1.item3": "Universités techniques partenaires.",
    "join.hero.title": "Rejoindre la Comunidad IA Salud-Énergie",
    "join.hero.subtitle": "Processus en trois étapes : candidature, validation et intégration dans les groupes thématiques.",
    "join.hero.alt": "Personne remplissant un formulaire numérique sur une tablette",
    "join.section1.title": "Étapes d’adhésion",
    "join.section1.item1": "Soumettre une candidature décrivant l’expérience professionnelle et les motivations.",
    "join.section1.item2": "Entretien avec le comité de coordination pour préciser les attentes.",
    "join.section1.item3": "Intégration dans un groupe régional et attribution d’un parcours de familiarisation.",
    "join.section2.title": "Formulaire de candidature",
    "join.form.name": "Nom complet",
    "join.form.email": "Adresse électronique professionnelle",
    "join.form.role": "Fonction actuelle",
    "join.form.region": "Région d’activité principale",
    "join.form.focus": "Axes d’intérêt",
    "join.form.message": "Présentation succincte",
    "join.form.submit": "Envoyer la candidature",
    "join.form.reset": "Effacer",
    "profile.hero.title": "Profil enregistré",
    "profile.hero.subtitle": "Votre profil a été créé. L’équipe de la Comunidad IA Salud-Énergie vous contactera pour finaliser votre parcours d’intégration.",
    "profile.hero.alt": "Icône de profil validé sur un fond lumineux",
    "profile.action": "Explorer les ressources",
    "cookie.title": "Gestion des cookies",
    "cookie.description": "Nous utilisons des cookies pour assurer le bon fonctionnement du site et améliorer nos services. Vous pouvez adapter vos préférences à tout moment.",
    "cookie.necessary": "Nécessaires",
    "cookie.preferences": "Préférences",
    "cookie.analytics": "Analyse",
    "cookie.marketing": "Communication",
    "cookie.accept": "Tout accepter",
    "cookie.decline": "Tout refuser",
    "cookie.save": "Enregistrer les préférences",
    "cookie.manage": "Modifier les préférences",
    "cookie.notice": "Ces paramètres seront mémorisés pendant douze mois.",
    "toast.formSent": "Votre message a été pris en compte.",
    "toast.preferencesSaved": "Vos préférences de cookies ont été enregistrées.",
    "toast.declined": "Les cookies optionnels ont été désactivés.",
    "toast.accepted": "Merci d’avoir activé les cookies optionnels.",
    "contact.placeholder.name": "Saisissez votre nom complet",
    "contact.placeholder.org": "Saisissez le nom de l’organisation",
    "contact.placeholder.email": "exemple@organisation.es",
    "contact.placeholder.phone": "+34 ...",
    "contact.placeholder.message": "Décrivez votre demande",
    "join.placeholder.role": "Fonction ou responsabilité",
    "join.placeholder.region": "Sélectionnez la région",
    "join.placeholder.focus": "Domaines d’intérêt",
    "join.placeholder.message": "Expliquez votre motivation",
    "footer.contactLink": "Contacter l’équipe"
  },
  en: {
    "meta.index.title": "Comunidad IA Salud-Energía – Professional Network",
    "meta.index.description": "Collaborative platform connecting Spanish experts working on AI for health and energy. Thematic forums, regional groups, shared projects and a case library.",
    "meta.servicios.title": "Informational services – Comunidad IA Salud-Energía",
    "meta.servicios.description": "Overview of the forums, regional groups, professional gatherings, project board and shared library offered by Comunidad IA Salud-Energía.",
    "meta.acerca.title": "About the network – Comunidad IA Salud-Energía",
    "meta.acerca.description": "History, mission and coordination team behind Comunidad IA Salud-Energía. Interdisciplinary cooperation supporting Spanish health and energy professionals.",
    "meta.blog.title": "Technical blog – Comunidad IA Salud-Energía",
    "meta.blog.description": "Technical insights and field feedback about AI for health and energy in Spain, written by network members.",
    "meta.post1.title": "Coupled methodologies for hospital energy efficiency",
    "meta.post1.description": "In-depth analysis of integrated approaches combining AI, energy simulation and clinical operations in Spanish hospitals.",
    "meta.post2.title": "Governance framework for health-energy AI",
    "meta.post2.description": "Governance reference aligning energy performance and clinical requirements within AI projects in health systems.",
    "meta.post3.title": "Health-energy data interoperability in Spain",
    "meta.post3.description": "Technical guide covering interoperability between healthcare systems and smart energy infrastructures.",
    "meta.post4.title": "Predictive maintenance of hospital infrastructures",
    "meta.post4.description": "Comprehensive overview of AI-assisted predictive maintenance for hospital energy installations.",
    "meta.post5.title": "Multi-agent simulation for emergency management",
    "meta.post5.description": "Exploring multi-agent simulations bridging energy flows and hospital emergency coordination in Spain.",
    "meta.contacto.title": "Contact and location – Comunidad IA Salud-Energía",
    "meta.contacto.description": "Contact details, secure form and office location for Comunidad IA Salud-Energía in Madrid.",
    "meta.faq.title": "FAQ – Comunidad IA Salud-Energía",
    "meta.faq.description": "Answers to frequent questions about membership, forums, events and data governance.",
    "meta.terminos.title": "Terms of use – Comunidad IA Salud-Energía",
    "meta.terminos.description": "Comprehensive terms of use for the Comunidad IA Salud-Energía platform dedicated to professionals in Spain.",
    "meta.privacidad.title": "Privacy policy – Comunidad IA Salud-Energía",
    "meta.privacidad.description": "Privacy policy detailing data collection, usage and retention within the network.",
    "meta.cookies.title": "Cookie policy – Comunidad IA Salud-Energía",
    "meta.cookies.description": "Transparent description of the cookies used across the Comunidad IA Salud-Energía platform.",
    "meta.reembolso.title": "Refund policy – Comunidad IA Salud-Energía",
    "meta.reembolso.description": "Refund policy describing procedures for informational services provided by the network.",
    "meta.descargo.title": "Disclaimer – Comunidad IA Salud-Energía",
    "meta.descargo.description": "Disclaimer covering liability limitations of Comunidad IA Salud-Energía.",
    "meta.gracias.title": "Thank you – Comunidad IA Salud-Energía",
    "meta.gracias.description": "Confirmation message: the Comunidad IA Salud-Energía team will review the submitted information and reply shortly.",
    "meta.404.title": "Page not found – Comunidad IA Salud-Energía",
    "meta.404.description": "The requested resource could not be found. Use the suggested links to return to the homepage.",
    "meta.miembros.title": "Member community – Comunidad IA Salud-Energía",
    "meta.miembros.description": "Overview of collaborative profiles and co-creation spaces within Comunidad IA Salud-Energía.",
    "meta.foros.title": "Thematic forums – Comunidad IA Salud-Energía",
    "meta.foros.description": "Overview of the thematic forums dedicated to AI for health and energy in Spain.",
    "meta.grupos.title": "Regional groups – Comunidad IA Salud-Energía",
    "meta.grupos.description": "Landscape of regional groups and territorial action plans within the network.",
    "meta.proyectos.title": "Project board – Comunidad IA Salud-Energía",
    "meta.proyectos.description": "Collaborative initiatives and cooperation opportunities in the Comunidad IA Salud-Energía network.",
    "meta.eventos.title": "Events calendar – Comunidad IA Salud-Energía",
    "meta.eventos.description": "Calendar of meetings, workshops and technical seminars organised by the network.",
    "meta.biblioteca.title": "Knowledge library – Comunidad IA Salud-Energía",
    "meta.biblioteca.description": "Documented resources and use cases shared by network members.",
    "meta.expertos.title": "Expert directory – Comunidad IA Salud-Energía",
    "meta.expertos.description": "Key competences of AI, health and energy experts gathered by the network.",
    "meta.noticias.title": "News – Comunidad IA Salud-Energía",
    "meta.noticias.description": "News and strategic watch about AI for health and energy in Spain.",
    "meta.empresas.title": "Institutional partners – Comunidad IA Salud-Energía",
    "meta.empresas.description": "Overview of organisations collaborating with Comunidad IA Salud-Energía.",
    "meta.unirse.title": "Join the community – Comunidad IA Salud-Energía",
    "meta.unirse.description": "Membership process and shared values of Comunidad IA Salud-Energía.",
    "meta.perfil.title": "Profile created – Comunidad IA Salud-Energía",
    "meta.perfil.description": "Confirmation that the Comunidad IA Salud-Energía profile has been created.",
    "header.logo": "Comunidad IA Salud-Energía",
    "nav.home": "Home",
    "nav.services": "Services",
    "nav.about": "About",
    "nav.blog": "Blog",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "language.fr": "FR",
    "language.en": "EN",
    "nav.toggle": "Open navigation menu",
    "footer.description": "Spanish network bringing together practitioners, engineers and researchers around AI applied to health and energy.",
    "footer.phone": "+34 91 555 7844",
    "footer.email": "contact@comunidad-iaenergiahealthspain.com",
    "footer.address": "Calle Innovación 1000, Madrid, Spain",
    "footer.rights": "All rights reserved.",
    "footer.manageCookies": "Manage cookies",
    "footer.terms": "Terms of use",
    "footer.privacy": "Privacy policy",
    "footer.cookies": "Cookie policy",
    "footer.refund": "Refund policy",
    "footer.disclaimer": "Disclaimer",
    "index.hero.tag": "Interdisciplinary network",
    "index.hero.title": "Connecting artificial intelligence, health and energy across Spain",
    "index.hero.subtitle": "Comunidad IA Salud-Energía unites physicians, engineers, researchers and decision-makers to co-design responses to clinical and energy challenges. The platform enables collective analysis, case sharing and the coordination of pilot projects for Spanish hospitals.",
    "index.hero.primary": "Explore the community",
    "index.hero.secondary": "Review the services",
    "index.hero.alt": "Modern hospital interior with energy panels and analytical data overlays",
    "index.features.title": "Structured collaborative spaces",
    "index.features.subtitle": "Each area within Comunidad IA Salud-Energía supports responsible professional practice, knowledge sharing and actionable feedback loops.",
    "index.features.card1title": "Specialised forums",
    "index.features.card1text": "Moderated discussions on AI for intensive care, energy management in operating theatres and intelligent hospital networks.",
    "index.features.card2title": "Co-development projects",
    "index.features.card2text": "Shared board assessing needs, milestones and impact indicators for every interdisciplinary initiative.",
    "index.features.card3title": "Structured watch",
    "index.features.card3text": "Biweekly digest covering scientific publications, regulatory frameworks and Spanish or European technical reports.",
    "index.highlight.title": "Steering transformation",
    "index.highlight.subtitle": "The network delivers concrete guidelines to balance energy performance, clinical resilience and responsible innovation.",
    "index.highlight.point1": "Hospital observatory: monitoring consumption, air quality and continuity of care indicators.",
    "index.highlight.point2": "Experimentation tracks: detailed feedback on AI use cases supporting clinical engineering.",
    "index.highlight.point3": "Regional communities: alignment between national strategies and territorial specificities through regular meetings.",
    "index.stats.label1": "Active professionals",
    "index.stats.value1": "1,250",
    "index.stats.label2": "Documented cases",
    "index.stats.value2": "184",
    "index.stats.label3": "Regional groups",
    "index.stats.value3": "11",
    "index.stats.label4": "Academic partnerships",
    "index.stats.value4": "27",
    "index.recommendations.title": "Exploration tips",
    "index.recommendations.subtitle": "Suggested entry points to quickly discover the most relevant resources within Comunidad IA Salud-Energía.",
    "index.recommendations.card1quote": "Start with the shared library: concise briefs help identify technical architectures already deployed in Spanish hospitals.",
    "index.recommendations.card1meta": "Document management team",
    "index.recommendations.card2quote": "Check the energy sensor mapping for hospitals. It fosters dialogue between technical managers and clinical teams.",
    "index.recommendations.card2meta": "Madrid infrastructure group",
    "index.recommendations.card3quote": "Join a governance roundtable. Deliverables include decision matrices and contingency plans.",
    "index.recommendations.card3meta": "AI governance unit",
    "index.testimonials.title": "Member feedback",
    "index.testimonials.subtitle": "Testimonials illustrating interdisciplinary collaboration within the network.",
    "index.testimonials.card1quote": "Cross-analysis between bioengineers and energy leads brought clarity to the trade-offs needed for our renovation plans.",
    "index.testimonials.card1meta": "Technical manager – University Hospital of Valencia",
    "index.testimonials.card2quote": "The community helps us structure clinical trial protocols that integrate energy-focused algorithms. Feedback is precise and actionable.",
    "index.testimonials.card2meta": "Innovation coordinator – Andalusian Hospital Network",
    "index.testimonials.card3quote": "The thematic workshops helped us schedule joint work between AI research teams, engineering services and medical leadership.",
    "index.testimonials.card3meta": "Lead researcher – National Renewable Energy Institute",
    "index.section.resources.title": "Essential resources",
    "index.section.resources.subtitle": "Selected modules supporting the deployment of health-energy AI projects.",
    "index.section.resources.card1title": "Open lab",
    "index.section.resources.card1text": "Validated datasets, anonymisation procedures and evaluation scripts released by academic partners.",
    "index.section.resources.card2title": "Monthly roundtable",
    "index.section.resources.card2text": "Hybrid meeting about AI use cases for energy continuity and clinical safety.",
    "index.section.resources.card3title": "Regulatory observatory",
    "index.section.resources.card3text": "Collaborative analysis of Spanish and European standards for technical management and decision-support systems.",
    "index.section.callout.title": "Contribute to collective workstreams",
    "index.section.callout.subtitle": "Contributions are organised by thematic axes delivering shared outputs for the whole community.",
    "index.section.callout.point1": "Standardised documentation for use cases",
    "index.section.callout.point2": "Shared health-energy indicator frameworks",
    "index.section.callout.point3": "Technical and clinical resilience plans",
    "services.hero.title": "Overview of collaborative services",
    "services.hero.subtitle": "Thematic forums, regional groups, professional events, project board and joint library structure interdisciplinary cooperation.",
    "services.hero.alt": "Professionals collaborating around analytical screens in a modern workspace",
    "services.item1.title": "Thematic forums",
    "services.item1.text": "Each forum is moderated by a health-energy duo, ensuring discussion quality and monthly analytical summaries.",
    "services.item2.title": "Regional groups",
    "services.item2.text": "Eleven groups highlight territorial initiatives, share equipment inventories and discuss optimisation plans.",
    "services.item3.title": "Professional events",
    "services.item3.text": "Methodological workshops, technical visits and hybrid seminars foster alignment between clinical and engineering leaders.",
    "services.item4.title": "Project board",
    "services.item4.text": "Project owners describe objectives, governance, milestones and expertise needs, enabling swift involvement from contributors.",
    "services.item5.title": "Shared library",
    "services.item5.text": "Trial reports, analytical procedures and comparable feedback form a living knowledge base.",
    "services.process.title": "Contribution workflow",
    "services.process.point1": "Topic leads validating publications collaboratively.",
    "services.process.point2": "Common schedule of deliverables updated monthly.",
    "services.process.point3": "Shared quality monitoring and health-energy indicators.",
    "about.hero.title": "An initiative driven by interdisciplinary cooperation",
    "about.hero.subtitle": "Comunidad IA Salud-Energía emerged from Spanish public hospitals, technical universities and energy operators joining forces.",
    "about.hero.alt": "Conference room with participants and a large data visualization screen",
    "about.mission.title": "Mission",
    "about.mission.text": "Provide a lasting collaborative framework aligning clinical innovation, energy sobriety and resilient critical infrastructures.",
    "about.vision.title": "Vision",
    "about.vision.text": "Promote transparent, auditable AI solutions aligned with the operational needs of healthcare professionals in Spain.",
    "about.values.title": "Shared values",
    "about.values.point1": "Interoperability and continuous documentation.",
    "about.values.point2": "Ethics, robustness and ongoing assessment.",
    "about.values.point3": "Territorial solidarity and resource pooling.",
    "about.timeline.title": "Key milestones",
    "about.timeline.item1": "2019 – Launch of the first health-energy working group in Madrid.",
    "about.timeline.item2": "2021 – Integration of AI research teams from Spanish public universities.",
    "about.timeline.item3": "2022 – Deployment of the shared library and joint indicator framework.",
    "about.timeline.item4": "2023 – Structuring of eleven regional groups and moderated forums.",
    "about.team.title": "Coordination",
    "about.team.text": "Coordination is ensured by a transversal committee representing hospital leadership, energy managers and researchers. Each axis has a dedicated team helping members use the collaborative tools effectively.",
    "blog.hero.title": "Analyses and field reports",
    "blog.hero.subtitle": "The blog consolidates technical contributions documenting methodologies, governance frameworks and relevant indicators.",
    "blog.hero.alt": "Person viewing an energy dashboard on a large screen",
    "blog.list.post1.title": "Coupled models for hospital energy efficiency",
    "blog.list.post1.excerpt": "How energy models, clinical data and real-time AI combine in Spanish hospitals.",
    "blog.list.post1.link": "Read the analysis",
    "blog.list.post2.title": "Health-energy AI governance framework",
    "blog.list.post2.excerpt": "Aligning clinical compliance, energy management and algorithmic responsibility.",
    "blog.list.post2.link": "Explore the framework",
    "blog.list.post3.title": "Critical data interoperability",
    "blog.list.post3.excerpt": "Methods to synchronise hospital information systems and energy platforms.",
    "blog.list.post3.link": "Understand the options",
    "blog.list.post4.title": "Integrated predictive maintenance",
    "blog.list.post4.excerpt": "Observability of energy assets supporting clinical operations.",
    "blog.list.post4.link": "Review the briefing",
    "blog.list.post5.title": "Multi-agent emergency simulation",
    "blog.list.post5.excerpt": "Connecting energy flows and medical coordination.",
    "blog.list.post5.link": "Analyse the scenario",
    "post1.h1": "Coupled models for hospital energy efficiency in Spain",
    "post1.h2": "Framing the integration between clinical and energy systems",
    "post1.p1": "Spanish hospitals are now combining clinical datasets, equipment telemetry and energy histories to anticipate load peaks while maintaining stable environments. Achieving this goal requires shared repositories where engineers, biomedical leads and clinicians define common constraints. AI is then used to detect usage drifts and suggest adjustments compatible with clinical workflows.",
    "post1.p2": "Convergence relies on harmonised datasets. Streams from ventilation units, lighting sensors or cooling systems are synchronised with surgical schedules and occupancy figures for critical wards. This micro-temporal mapping prevents threshold effects: algorithms identify transition periods when energy adjustments must not disrupt care pathways.",
    "post1.h3": "Building hybrid models and measuring impact",
    "post1.p3": "Technical teams develop digital twins coupling thermal models, usage simulations and projections of medical activity. Each iteration is validated with clinical leads to ensure recommendations respect safety protocols. Results are shared through Comunidad IA Salud-Energía using concise briefs detailing assumptions, limits, impact metrics and deployment roadmaps.",
    "post1.p4": "Impact assessment relies on three indicator families: stability of critical environments, energy consumption per functional area and staff perception. Field feedback shows that reducing thermal fluctuations cuts technical alarms and simplifies preventive maintenance. Shared dashboards help transfer these lessons to other hospitals.",
    "post1.p5": "Spanish regulatory frameworks encourage thorough documentation of algorithmic decisions. Every adjustment proposed by the model includes an energy and clinical justification. Governance committees verify compliance with national rules. This transparency strengthens trust across disciplines and paves the way for durable cooperation.",
    "post1.p6": "The community also set up continuous training so users correctly interpret intelligent dashboards. Workshops combine hands-on exercises, field testimonials and incident scenarios. The goal is to build a shared culture of hospital AI where energy performance becomes a mutual indicator without undermining quality of care.",
    "post2.h1": "Governance framework for health-energy AI in Spanish hospitals",
    "post2.h2": "Structuring responsibilities",
    "post2.p1": "Deploying AI at the health-energy interface multiplies interactions between medical leadership, clinical engineering, facility operators and IT departments. Comunidad IA Salud-Energía offers a governance framework built around four committees: regulatory compliance, operational safety, algorithm oversight and user support. Decisions are documented and published on the platform to ensure full traceability.",
    "post2.p2": "Responsibilities follow a co-accountability principle. Physicians guarantee alignment with clinical protocols, while energy managers evaluate the impact on critical infrastructures. Digital teams secure data integrity and cybersecurity. This model fosters continual dialogue to balance energy performance and clinical continuity.",
    "post2.h3": "Procedures, audits and continuous improvement",
    "post2.p3": "The framework includes approval procedures prior to deployment. Usage scenarios are tested in simulated environments combining actual energy loads and patient flows. Audit reports capture modelling assumptions, observed limitations and usage conditions. They are stored in the shared library to help other members adapt the findings.",
    "post2.p4": "Quarterly reviews assess the relevance of live models. They monitor energy efficiency indicators, user-reported incidents and algorithm updates. Summaries are shared as bulletins accessible to all members. Transparency strengthens interdisciplinary trust and helps identify recalibration needs.",
    "post2.p5": "User support is central to the framework. Healthcare teams receive contextual guides describing monitored variables, critical thresholds and recommended actions. Energy operators get detailed contingency plans outlining the steps to follow if AI systems become unavailable.",
    "post2.p6": "This systemic approach empowers Spanish hospitals to integrate AI without weakening risk governance. Network members continuously update reference documents to anticipate regulatory and technological changes.",
    "post3.h1": "Data interoperability for health-energy integration: Comunidad IA reference",
    "post3.h2": "Mapping critical flows",
    "post3.p1": "Interoperability is a key challenge for AI spanning health and energy domains. Each hospital manages heterogeneous systems: electronic medical records, energy supervision platforms and assisted maintenance solutions. Comunidad IA Salud-Energía produced a reference outlining six priority data flows, including operating theatre environmental metrics, anonymised biomedical data and status logs for thermal plants.",
    "post3.p2": "The mapping is paired with a qualitative assessment grid. Members review available history depth, refresh frequency, associated security protocols and data sensitivity. Outcomes guide standardisation and data quality priorities.",
    "post3.h3": "Exchange standards and metadata governance",
    "post3.p3": "The reference encourages combined use of open standards. Energy exchanges rely on sector ontologies, while clinical data adopt HL7 FHIR or openEHR frameworks. A shared terminology dictionary keeps semantic coherence: each field is documented with validation rules and usage contexts.",
    "post3.p4": "Member hospitals publish their mapping plans in the shared library. Documents describe transformations, missing value handling and consistency checks. Field feedback confirms that documentation accelerates onboarding of new sites and reduces reverse engineering.",
    "post3.p5": "Teams have introduced collaborative cataloguing. Every dataset is referenced with metadata describing acquisition conditions, temporal granularity, usage restrictions and technical contacts. This approach makes it easier to locate corpora suited to each AI project.",
    "post3.p6": "Finally, the community runs cross-review sessions: before deploying any connector, a health-energy duo checks compliance with security protocols and the relevance of exposed fields. This peer review fosters trust and prevents unintended disclosures.",
    "post4.h1": "Integrated predictive maintenance for hospital infrastructures",
    "post4.h2": "Combining energy supervision and clinical context",
    "post4.p1": "Spanish hospital infrastructures rely on critical assets such as air handling units, generators and sterilisation systems. Predictive maintenance aims to anticipate failures using real-time metrics and intervention histories. Comunidad IA Salud-Energía coordinates a shared framework ensuring alignment between clinical needs and technical operations.",
    "post4.p2": "Each component gets a criticality profile. Algorithms estimate degradation probabilities considering usage conditions: energy load, exposure time and climate constraints. Results are contextualised with care schedules so interventions occur outside sensitive periods.",
    "post4.h3": "Value chain and field feedback",
    "post4.p3": "The predictive maintenance chain comprises four phases: data collection, standardisation, modelling and delivery. Members document sensor protocols, data cleaning strategies and reliability indicators. Shared dashboards display intervention scenarios with detailed justification.",
    "post4.p4": "Field reports show that blending energy and clinical data improves alert accuracy. For example, analysing vacuum pump consumption alongside surgical cycles helps anticipate performance loss. Maintenance teams can plan targeted replacements without disrupting critical services.",
    "post4.p5": "The community encourages thorough documentation of resolved incidents. Each case note includes symptoms, AI detection, human validation and lessons learned. This knowledge feeds the shared library and continuous training programmes.",
    "post4.p6": "Regional groups compare their maintenance references. Exchanges support harmonised service contracts and shared indicators. This collective approach reduces disparities across facilities and strengthens resilience of Spanish hospital infrastructures.",
    "post5.h1": "Multi-agent simulation for hospital emergency management",
    "post5.h2": "Linking energy flows with clinical coordination",
    "post5.p1": "Emergency management depends on synchronised clinical resources and resilient energy systems. To anticipate complex situations, several Spanish hospitals are experimenting with multi-agent simulations. They model interactions between clinical teams, energy infrastructures and patient flows. Comunidad IA Salud-Energía provides a framework to share scenarios and parameter sets.",
    "post5.p2": "Each agent represents an operational entity: operating room, mobile unit, electrical transformer or chilled water plant. Interactions follow rules inspired by emergency protocols. Simulations evaluate system capability to absorb surges while keeping air quality and temperature within acceptable ranges.",
    "post5.h3": "Using and transferring insights",
    "post5.p3": "Simulation outputs are translated into action plans. Teams identify critical configurations, such as temporary generator loss during massive patient inflow. Recommendations outline priority steps, involved actors and monitoring indicators.",
    "post5.p4": "Community members share simulation scripts, calibration assumptions and input data. Particular attention is paid to anonymising clinical events to respect protection frameworks. Collaborative workshops compare modelling tools and enrich scenario libraries.",
    "post5.p5": "Field feedback highlights the benefits of coupling simulations with drills. Teams implement the plans in controlled environments and adjust procedures according to observations. This improvement loop strengthens interdisciplinary coordination.",
    "post5.p6": "Ultimately, Comunidad IA Salud-Energía plans to build a national repository of multi-agent scenarios. It would support member training and help benchmark regional approaches. This joint initiative enhances preparedness of Spanish hospitals facing extreme situations.",
    "contact.hero.title": "Get in touch with Comunidad IA Salud-Energía",
    "contact.hero.subtitle": "The coordination office receives collaboration requests, technical questions and project proposals. Each submission is reviewed by the relevant team.",
    "contact.hero.alt": "Person sending a message from a laptop in a modern workspace",
    "contact.info.title": "Contact details",
    "contact.info.phone": "Phone",
    "contact.info.email": "Email",
    "contact.info.address": "Address",
    "contact.info.schedule": "Availability",
    "contact.info.scheduleText": "Monday to Friday, 09:00 - 18:00 (CET).",
    "contact.map.caption": "Location of Comunidad IA Salud-Energía in Madrid",
    "contact.form.title": "Secure form",
    "contact.form.subtitle": "Please describe your request precisely so we can involve the appropriate contacts.",
    "contact.form.name": "Full name",
    "contact.form.org": "Organisation",
    "contact.form.email": "Email address",
    "contact.form.phone": "Business phone",
    "contact.form.topic": "Main topic",
    "contact.form.topic.option1": "Document synthesis",
    "contact.form.topic.option2": "Join a regional group",
    "contact.form.topic.option3": "Project board access",
    "contact.form.topic.option4": "Scientific contribution",
    "contact.form.message": "Detailed message",
    "contact.form.submit": "Send request",
    "contact.form.reset": "Reset",
    "faq.hero.title": "Frequently asked questions",
    "faq.hero.subtitle": "Membership conditions, forum operations, confidentiality and support grouped into a single FAQ.",
    "faq.hero.alt": "Illustration of questions and answers over a digital background",
    "faq.q1": "Who can join Comunidad IA Salud-Energía?",
    "faq.a1": "The network welcomes professionals and researchers based in Spain who work on projects linking health, energy and artificial intelligence. Each application is reviewed by the admission committee to ensure alignment with shared values.",
    "faq.q2": "How are thematic forums organised?",
    "faq.a2": "Each forum is run by a clinical-technical duo. Discussions are archived and summarised monthly. Moderation rules ensure quality and avoid duplicate content.",
    "faq.q3": "What data types may be shared?",
    "faq.a3": "Only anonymised or aggregated data are accepted. Members must comply with Spanish and European frameworks and document the processing applied.",
    "faq.q4": "How to access events?",
    "faq.a4": "Events are announced in the shared calendar. Registered participants receive participation details, agenda and preparatory materials.",
    "faq.q5": "Is there technical support?",
    "faq.a5": "Yes, a support cell assists members with account management, project board usage and document uploads to the shared library.",
    "faq.q6": "How are governance decisions taken?",
    "faq.a6": "Decisions are made collectively during quarterly meetings gathering regional representatives, the scientific committee and energy coordination. Summaries are published in the library.",
    "terms.hero.title": "Terms of use",
    "terms.hero.subtitle": "The following terms govern usage of the Comunidad IA Salud-Energía platform. Please read them carefully.",
    "terms.section1.title": "1. Purpose",
    "terms.section1.text": "These terms set the rules for accessing and using the Comunidad IA Salud-Energía collaborative platform by professionals located in Spain.",
    "terms.section2.title": "2. Definitions",
    "terms.section2.text": "\"Platform\" refers to the digital space comunidad-iaenergiahealthspain.com; \"Member\" refers to any user with a validated account; \"Content\" refers to any information published on the platform.",
    "terms.section3.title": "3. Acceptance",
    "terms.section3.text": "By accessing the platform, users accept these terms without reservation. Users who disagree must stop using the services.",
    "terms.section4.title": "4. Eligibility",
    "terms.section4.text": "Members must demonstrate activity connected with AI, health or energy. Coordination may refuse a request if it does not meet these criteria.",
    "terms.section5.title": "5. Accounts",
    "terms.section5.text": "Members are responsible for keeping their credentials confidential and ensuring the accuracy of information provided during registration.",
    "terms.section6.title": "6. Permitted use",
    "terms.section6.text": "The platform must be used for professional exchanges, project documentation and sharing resources aligned with the network’s mandate.",
    "terms.section7.title": "7. Content",
    "terms.section7.text": "Contributors agree to publish accurate, lawful and respectful content. They retain their rights while granting a non-exclusive licence for internal dissemination.",
    "terms.section8.title": "8. Intellectual property",
    "terms.section8.text": "Trademarks, logos, interfaces and core content remain the property of Comunidad IA Salud-Energía or its partners and cannot be reproduced without permission.",
    "terms.section9.title": "9. Moderation",
    "terms.section9.text": "Coordination may remove any content that breaches editorial rules or compromises data security.",
    "terms.section10.title": "10. Events",
    "terms.section10.text": "Event participants must follow the code of conduct provided. Coordination may adapt programmes according to technical constraints.",
    "terms.section11.title": "11. Third-party resources",
    "terms.section11.text": "The platform may include links to external resources. Coordination is not responsible for their content or availability.",
    "terms.section12.title": "12. Personal data",
    "terms.section12.text": "Personal data processing is described in the privacy policy. Members retain rights of access, rectification and erasure.",
    "terms.section13.title": "13. Limitation",
    "terms.section13.text": "The platform is provided without assurance of continuous availability. Coordination undertakes reasonable efforts to ensure security and stability.",
    "terms.section14.title": "14. Governing law",
    "terms.section14.text": "These terms are governed by Spanish law. Disputes fall under the jurisdiction of Madrid courts after an attempt at amicable resolution.",
    "privacy.hero.title": "Privacy policy",
    "privacy.hero.subtitle": "This policy describes the personal data processing carried out by Comunidad IA Salud-Energía.",
    "privacy.section1.title": "1. Controller",
    "privacy.section1.text": "The controller is Comunidad IA Salud-Energía, Calle Innovación 1000, Madrid, Spain.",
    "privacy.section2.title": "2. Data collected",
    "privacy.section2.text": "We collect identification data, professional information, connection metadata, published contributions and service interactions.",
    "privacy.section3.title": "3. Purposes",
    "privacy.section3.text": "Data are used to manage accounts, secure access, moderate content, organise events and produce aggregated statistics.",
    "privacy.section4.title": "4. Lawful basis",
    "privacy.section4.text": "Processing relies on contractual commitments, the network’s legitimate interest in coordination and, where relevant, explicit consent.",
    "privacy.section5.title": "5. Retention",
    "privacy.section5.text": "Data are retained for the membership duration plus one year for administrative management and contribution traceability.",
    "privacy.section6.title": "6. Sharing",
    "privacy.section6.text": "Data may be shared with academic and technical partners strictly within the announced purposes.",
    "privacy.section7.title": "7. Security",
    "privacy.section7.text": "Organisational and technical measures protect data: access control, encrypted communications and regular access reviews.",
    "privacy.section8.title": "8. Rights",
    "privacy.section8.text": "You have rights of access, rectification, erasure, restriction, objection and portability. Requests can be sent via the contact form.",
    "privacy.section9.title": "9. Processors",
    "privacy.section9.text": "Processors are selected for compliance and contractually commit to protecting the processed information.",
    "privacy.section10.title": "10. Updates",
    "privacy.section10.text": "This policy may evolve to reflect practice changes. Members will be informed of substantial updates.",
    "cookies.hero.title": "Cookie policy",
    "cookies.hero.subtitle": "This page explains the cookies used on comunidad-iaenergiahealthspain.com and your management options.",
    "cookies.intro": "We use cookies required for the site to operate and, subject to your consent, preference, analytics and communication cookies.",
    "cookies.table.name": "Name",
    "cookies.table.provider": "Provider",
    "cookies.table.type": "Type",
    "cookies.table.purpose": "Purpose",
    "cookies.table.duration": "Duration",
    "cookies.row1.name": "session_id",
    "cookies.row1.provider": "Comunidad IA",
    "cookies.row1.type": "Necessary",
    "cookies.row1.purpose": "Maintain session continuity and protect against unauthorised access.",
    "cookies.row1.duration": "24 hours",
    "cookies.row2.name": "lang_pref",
    "cookies.row2.provider": "Comunidad IA",
    "cookies.row2.type": "Preference",
    "cookies.row2.purpose": "Store the language selected by the user.",
    "cookies.row2.duration": "12 months",
    "cookies.row3.name": "analytics_scope",
    "cookies.row3.provider": "Comunidad IA",
    "cookies.row3.type": "Analytics",
    "cookies.row3.purpose": "Aggregate journey measurement and understanding of content usage.",
    "cookies.row3.duration": "6 months",
    "cookies.row4.name": "campaign_context",
    "cookies.row4.provider": "Comunidad IA",
    "cookies.row4.type": "Communication",
    "cookies.row4.purpose": "Track internal institutional communication effectiveness.",
    "cookies.row4.duration": "3 months",
    "refund.hero.title": "Refund policy",
    "refund.hero.subtitle": "Procedures applied when adjustments are required for informational services provided by Comunidad IA Salud-Energía.",
    "refund.section1": "1. Scope: this policy covers logistical or documentation contributions requested for access to specific informational services.",
    "refund.section2": "2. Requests: submit any request via the contact form including the event or service reference.",
    "refund.section3": "3. Timeframe: requests are reviewed within fifteen business days.",
    "refund.section4": "4. Eligibility: only situations related to major impediment, postponement or substantial service change qualify.",
    "refund.section5": "5. Assessment: a committee reviews provided documents and contacts the requester if additional information is needed.",
    "refund.section6": "6. Option: coordination favours a credit for an equivalent service. A refund may be considered when a credit is not appropriate.",
    "refund.section7": "7. Notification: the decision is communicated by email with a summary of reasons.",
    "refund.section8": "8. Payment timeframe: when granted, refunds are issued within thirty business days.",
    "refund.section9": "9. Disputes: any dispute is examined by coordination. Mediation may be proposed.",
    "refund.section10": "10. Review: the policy is reviewed annually and published on the site.",
    "disclaimer.hero.title": "Disclaimer",
    "disclaimer.hero.subtitle": "Conditions under which Comunidad IA Salud-Energía information is provided.",
    "disclaimer.section1": "Information published on this site is for informational purposes. It does not represent medical advice nor an energy prescription.",
    "disclaimer.section2": "Comunidad IA Salud-Energía makes reasonable efforts to ensure accuracy, without absolute certainty regarding completeness.",
    "disclaimer.section3": "Members remain responsible for decisions based on consulted information. Any implementation must comply with applicable regulations.",
    "disclaimer.section4": "External links are provided for convenience. Comunidad IA Salud-Energía has no control over these resources and declines responsibility for their content.",
    "disclaimer.section5": "The platform may be suspended for maintenance or updates. Coordination strives to keep interruptions short.",
    "gracias.hero.title": "Message received",
    "gracias.hero.subtitle": "Thank you for your contribution. The Comunidad IA Salud-Energía team will review your request and get back to you shortly.",
    "gracias.hero.alt": "Confirmation icon glowing on a dark background",
    "gracias.back": "Back to homepage",
    "404.hero.title": "Resource not found",
    "404.hero.subtitle": "The page you requested no longer exists or has been moved. Use the links below to find your way back.",
    "404.hero.alt": "Illustration of a compass in a digital environment",
    "404.action.primary": "Return to homepage",
    "404.action.secondary": "Visit the blog",
    "members.hero.title": "Member community",
    "members.hero.subtitle": "Comunidad IA Salud-Energía gathers diverse profiles: medical specialists, energy engineers, data scientists and transformation managers.",
    "members.hero.alt": "Group of professionals discussing in front of a data wall",
    "members.section1.title": "Representative profiles",
    "members.section1.item1": "Engineers in hospital energy efficiency working on modernisation plans.",
    "members.section1.item2": "Clinical leads guiding the integration of algorithms into care pathways.",
    "members.section1.item3": "Data scientists developing explainable and auditable models.",
    "members.section1.item4": "Territorial managers coordinating inter-hospital strategies.",
    "members.section2.title": "Shared commitments",
    "members.section2.item1": "Document every experiment and share the outcomes.",
    "members.section2.item2": "Respect confidentiality of sensitive information.",
    "members.section2.item3": "Contribute to regional groups and thematic forums.",
    "forums.hero.title": "Thematic forums",
    "forums.hero.subtitle": "Moderated discussion spaces to analyse cases, compare tools and build reference documents.",
    "forums.hero.alt": "Meeting room with screens showing charts and focused participants",
    "forums.section1.title": "Forum structure",
    "forums.section1.item1": "Intelligent operating theatres: energy monitoring and anaesthesia support.",
    "forums.section1.item2": "Critical infrastructure resilience: backup plants, microgrids and storage.",
    "forums.section1.item3": "Air quality and preventive AI in sensitive wards.",
    "forums.section1.item4": "Data interoperability between hospital systems and energy platforms.",
    "forums.section2.title": "Participation rules",
    "forums.section2.item1": "Access validated by moderators according to declared expertise.",
    "forums.section2.item2": "Monthly summaries shared through the library.",
    "forums.section2.item3": "Dedicated webinars for major field reports.",
    "groups.hero.title": "Regional groups",
    "groups.hero.subtitle": "Eleven groups cover the entire Spanish territory to address climate, energy and health specificities.",
    "groups.hero.alt": "Stylised map of Spain with illuminated regions",
    "groups.section1.title": "Workstreams",
    "groups.section1.item1": "Energy audits for public healthcare facilities.",
    "groups.section1.item2": "IoT sensor deployment and data standards.",
    "groups.section1.item3": "Continuity plans and coordination with local authorities.",
    "groups.section1.item4": "Sharing business models and contractual frameworks.",
    "projects.hero.title": "Collaborative project board",
    "projects.hero.subtitle": "Overview of ongoing initiatives with milestones, expertise needs and expected deliverables.",
    "projects.hero.alt": "Project tracking board displayed on a screen with glowing indicators",
    "projects.section1.title": "Flagship projects",
    "projects.section1.item1": "Operating theatre energy optimisation across three Madrid hospitals with air quality monitoring.",
    "projects.section1.item2": "Predictive maintenance platform for hospital thermal plants in Catalonia.",
    "projects.section1.item3": "Multi-agent emergency simulation programme in Andalusia.",
    "projects.section2.title": "Contributions sought",
    "projects.section2.item1": "Data analysts for time-series annotation.",
    "projects.section2.item2": "Cybersecurity specialists to audit connected architectures.",
    "projects.section2.item3": "Clinical leaders to validate usage scenarios.",
    "events.hero.title": "Events calendar",
    "events.hero.subtitle": "Technical meetings, methodological workshops and site visits organised by Comunidad IA Salud-Energía.",
    "events.hero.alt": "Auditorium with attendees listening to a technical presentation",
    "events.section1.title": "Upcoming events",
    "events.section1.item1": "Workshop on energy optimisation for intensive care units – Madrid.",
    "events.section1.item2": "Regional meeting on hospital microgrids – Bilbao.",
    "events.section1.item3": "Session on data governance – Seville.",
    "events.section2.title": "Participation",
    "events.section2.item1": "Register via the project board or the contact form.",
    "events.section2.item2": "Systematic summary available in the library.",
    "events.section2.item3": "Hybrid sessions combining onsite and secure streaming.",
    "library.hero.title": "Knowledge library",
    "library.hero.subtitle": "Structured technical documentation: datasets, methodological guides, case studies and regulatory analyses.",
    "library.hero.alt": "Digital shelf with organised files and documents",
    "library.section1.title": "Main categories",
    "library.section1.item1": "Architectures for health-energy AI systems.",
    "library.section1.item2": "Interoperability guides and data dictionaries.",
    "library.section1.item3": "Energy and climate impact assessments.",
    "library.section1.item4": "Governance frameworks and responsibility matrices.",
    "experts.hero.title": "Expert directory",
    "experts.hero.subtitle": "Identify technical, clinical and academic leaders willing to share their experience.",
    "experts.hero.alt": "Portraits of professionals displayed on a digital wall",
    "experts.section1.title": "Key skills",
    "experts.section1.item1": "Hospital energy optimisation and load analysis.",
    "experts.section1.item2": "Development of explainable and auditable AI models.",
    "experts.section1.item3": "Change management and clinical team support.",
    "experts.section1.item4": "Critical infrastructure security and cyber resilience.",
    "news.hero.title": "News",
    "news.hero.subtitle": "Strategic watch, regulatory summaries and member field reports.",
    "news.hero.alt": "News feed displayed on a translucent screen",
    "news.section1.title": "Latest publications",
    "news.section1.item1": "Release of a dossier on energy resilience in operating theatres.",
    "news.section1.item2": "Analysis of Spanish measures on hospital decarbonisation.",
    "news.section1.item3": "Review of the AI governance workshop hosted in Barcelona.",
    "companies.hero.title": "Institutional partners",
    "companies.hero.subtitle": "Organisations supporting Comunidad IA Salud-Energía in research and dissemination efforts.",
    "companies.hero.alt": "Organisation logos presented on a glowing background",
    "companies.section1.title": "Key partners",
    "companies.section1.item1": "Spanish public hospital network.",
    "companies.section1.item2": "Sustainable energy research institutes.",
    "companies.section1.item3": "Partner technical universities.",
    "join.hero.title": "Join Comunidad IA Salud-Energía",
    "join.hero.subtitle": "Three-step process: application, validation and integration into thematic groups.",
    "join.hero.alt": "Person filling a digital form on a tablet",
    "join.section1.title": "Membership steps",
    "join.section1.item1": "Submit an application outlining professional background and motivations.",
    "join.section1.item2": "Interview with the coordination committee to clarify expectations.",
    "join.section1.item3": "Integration into a regional group and assignment of an onboarding path.",
    "join.section2.title": "Application form",
    "join.form.name": "Full name",
    "join.form.email": "Professional email",
    "join.form.role": "Current role",
    "join.form.region": "Primary region of activity",
    "join.form.focus": "Areas of interest",
    "join.form.message": "Brief presentation",
    "join.form.submit": "Submit application",
    "join.form.reset": "Clear",
    "profile.hero.title": "Profile recorded",
    "profile.hero.subtitle": "Your profile has been created. The Comunidad IA Salud-Energía team will contact you to finalise onboarding.",
    "profile.hero.alt": "Validated profile icon on a glowing background",
    "profile.action": "Browse resources",
    "cookie.title": "Cookie management",
    "cookie.description": "We use cookies to ensure the site runs properly and to enhance our services. You can adjust your preferences at any time.",
    "cookie.necessary": "Necessary",
    "cookie.preferences": "Preferences",
    "cookie.analytics": "Analytics",
    "cookie.marketing": "Communication",
    "cookie.accept": "Accept all",
    "cookie.decline": "Decline all",
    "cookie.save": "Save preferences",
    "cookie.manage": "Adjust preferences",
    "cookie.notice": "These settings will be stored for twelve months.",
    "toast.formSent": "Your message has been recorded.",
    "toast.preferencesSaved": "Your cookie preferences were saved.",
    "toast.declined": "Optional cookies have been disabled.",
    "toast.accepted": "Thank you for enabling optional cookies.",
    "contact.placeholder.name": "Enter your full name",
    "contact.placeholder.org": "Enter your organisation name",
    "contact.placeholder.email": "example@organisation.es",
    "contact.placeholder.phone": "+34 ...",
    "contact.placeholder.message": "Describe your request",
    "join.placeholder.role": "Role or responsibility",
    "join.placeholder.region": "Select the region",
    "join.placeholder.focus": "Domains of interest",
    "join.placeholder.message": "Explain your motivation",
    "footer.contactLink": "Contact the team"
  }
};
const DEFAULT_LANG = "fr";

function getStoredLanguage() {
  const stored = localStorage.getItem("site_lang");
  if (stored && Object.prototype.hasOwnProperty.call(I18N, stored)) {
    return stored;
  }
  return DEFAULT_LANG;
}

function setStoredLanguage(lang) {
  localStorage.setItem("site_lang", lang);
}

function translatePage(lang) {
  const dict = I18N[lang];
  if (!dict) return;
  document.documentElement.setAttribute("lang", lang);

  const titleKey = document.querySelector("[data-i18n-title]");
  if (titleKey) {
    const val = dict[titleKey.dataset.i18nTitle];
    if (val) {
      document.title = val;
    }
  }

  document.querySelectorAll("[data-i18n-meta]").forEach((meta) => {
    const key = meta.dataset.i18nMeta;
    const val = dict[key];
    if (val) {
      meta.setAttribute("content", val);
    }
  });

  document.querySelectorAll("[data-i18n]").forEach((node) => {
    const key = node.dataset.i18n;
    const val = dict[key];
    if (val) {
      node.textContent = val;
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((node) => {
    const key = node.dataset.i18nPlaceholder;
    const val = dict[key];
    if (val) {
      node.setAttribute("placeholder", val);
    }
  });

  document.querySelectorAll("[data-i18n-alt]").forEach((node) => {
    const key = node.dataset.i18nAlt;
    const val = dict[key];
    if (val) {
      node.setAttribute("alt", val);
    }
  });

  document.querySelectorAll("[data-i18n-aria-label]").forEach((node) => {
    const key = node.dataset.i18nAriaLabel;
    const val = dict[key];
    if (val) {
      node.setAttribute("aria-label", val);
    }
  });

  document.querySelectorAll("[data-i18n-value]").forEach((node) => {
    const key = node.dataset.i18nValue;
    const val = dict[key];
    if (val) {
      node.setAttribute("value", val);
    }
  });

  updateLanguageToggle(lang);
}

function updateLanguageToggle(activeLang) {
  document.querySelectorAll(".language-toggle button").forEach((btn) => {
    const btnLang = btn.dataset.lang;
    const isActive = btnLang === activeLang;
    btn.setAttribute("aria-pressed", isActive ? "true" : "false");
  });
}

function setupLanguageToggle() {
  document.querySelectorAll(".language-toggle button").forEach((button) => {
    button.addEventListener("click", () => {
      const lang = button.dataset.lang;
      if (lang && Object.prototype.hasOwnProperty.call(I18N, lang)) {
        setStoredLanguage(lang);
        translatePage(lang);
        updateCookieTexts(lang);
      }
    });
  });
}

function setupNavigationToggle() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".main-nav");
  if (!toggle || !nav) return;

  toggle.addEventListener("click", () => {
    const expanded = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", expanded ? "false" : "true");
    nav.classList.toggle("is-open");
  });

  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      toggle.setAttribute("aria-expanded", "false");
      nav.classList.remove("is-open");
    });
  });
}

function setupScrollAnimations() {
  const animated = document.querySelectorAll("[data-animate]");
  if (!("IntersectionObserver" in window)) {
    animated.forEach((el) => el.classList.add("is-visible"));
    return;
  }
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );
  animated.forEach((el) => observer.observe(el));
}

function showToast(messageKey) {
  const lang = getStoredLanguage();
  const dict = I18N[lang];
  const container = document.getElementById("toast-container");
  if (!container) return;
  const message = dict[messageKey];
  if (!message) return;
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  container.appendChild(toast);
  requestAnimationFrame(() => {
    toast.classList.add("is-visible");
  });
  setTimeout(() => {
    toast.classList.remove("is-visible");
    setTimeout(() => {
      container.removeChild(toast);
    }, 320);
  }, 4000);
}

function setupForms() {
  document.querySelectorAll("form[data-toast]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const toastKey = form.dataset.toast;
      if (toastKey) {
        showToast(toastKey);
      }
      setTimeout(() => {
        form.submit();
      }, 1200);
    });
  });
}

function getCookieState() {
  try {
    const stored = localStorage.getItem("cookie_consent");
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.error("Cookie consent parse error", error);
  }
  return null;
}

function saveCookieState(state) {
  localStorage.setItem("cookie_consent", JSON.stringify(state));
}

function applyCookieStateToUI(state) {
  document.querySelectorAll("[data-cookie-toggle]").forEach((toggle) => {
    const category = toggle.dataset.cookieToggle;
    if (category === "necessary") {
      toggle.checked = true;
      toggle.disabled = true;
      return;
    }
    if (state && typeof state[category] === "boolean") {
      toggle.checked = state[category];
    } else {
      toggle.checked = false;
    }
  });
}

function readCookieStateFromUI() {
  const state = { necessary: true };
  document.querySelectorAll("[data-cookie-toggle]").forEach((toggle) => {
    const category = toggle.dataset.cookieToggle;
    if (category === "necessary") {
      state.necessary = true;
      return;
    }
    state[category] = toggle.checked;
  });
  return state;
}

function showCookieBanner() {
  const banner = document.getElementById("cookie-banner");
  if (!banner) return;
  banner.classList.add("is-visible");
}

function hideCookieBanner() {
  const banner = document.getElementById("cookie-banner");
  if (!banner) return;
  banner.classList.remove("is-visible");
}

function updateCookieTexts(lang) {
  const dict = I18N[lang];
  document.querySelectorAll("#cookie-banner [data-i18n]").forEach((node) => {
    const key = node.dataset.i18n;
    const val = dict[key];
    if (val) node.textContent = val;
  });
}

function setupCookieBanner() {
  const banner = document.getElementById("cookie-banner");
  if (!banner) return;

  const acceptBtn = banner.querySelector("[data-cookie-action='accept']");
  const declineBtn = banner.querySelector("[data-cookie-action='decline']");
  const saveBtn = banner.querySelector("[data-cookie-action='save']");
  const manageLinks = document.querySelectorAll("[data-cookie-manage]");

  const state = getCookieState();
  if (state) {
    applyCookieStateToUI(state);
  } else {
    showCookieBanner();
  }

  const lang = getStoredLanguage();
  updateCookieTexts(lang);

  acceptBtn?.addEventListener("click", () => {
    const consent = { necessary: true, preferences: true, analytics: true, marketing: true };
    saveCookieState(consent);
    applyCookieStateToUI(consent);
    hideCookieBanner();
    showToast("toast.accepted");
  });

  declineBtn?.addEventListener("click", () => {
    const consent = { necessary: true, preferences: false, analytics: false, marketing: false };
    saveCookieState(consent);
    applyCookieStateToUI(consent);
    hideCookieBanner();
    showToast("toast.declined");
  });

  saveBtn?.addEventListener("click", () => {
    const consent = readCookieStateFromUI();
    saveCookieState(consent);
    hideCookieBanner();
    showToast("toast.preferencesSaved");
  });

  manageLinks.forEach((link) => {
    link.addEventListener("click", () => {
      applyCookieStateToUI(getCookieState());
      showCookieBanner();
    });
  });

  document.querySelectorAll("[data-cookie-toggle]").forEach((toggle) => {
    const category = toggle.dataset.cookieToggle;
    toggle.addEventListener("change", () => {
      const current = readCookieStateFromUI();
      saveCookieState(current);
    });
    if (category === "necessary") {
      toggle.checked = true;
      toggle.disabled = true;
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const lang = getStoredLanguage();
  translatePage(lang);
  setupLanguageToggle();
  setupNavigationToggle();
  setupScrollAnimations();
  setupForms();
  setupCookieBanner();
});