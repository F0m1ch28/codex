document.addEventListener('DOMContentLoaded', function () {
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookiesButton = document.getElementById('accept-cookies');
    const declineCookiesButton = document.getElementById('decline-cookies');
    const consentStatus = localStorage.getItem('gt_cookie_consent');

    function hideCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.remove('active');
        }
    }

    if (!consentStatus && cookieBanner) {
        cookieBanner.classList.add('active');
    }

    if (acceptCookiesButton) {
        acceptCookiesButton.addEventListener('click', function () {
            localStorage.setItem('gt_cookie_consent', 'accepted');
            hideCookieBanner();
        });
    }

    if (declineCookiesButton) {
        declineCookiesButton.addEventListener('click', function () {
            localStorage.setItem('gt_cookie_consent', 'declined');
            hideCookieBanner();
        });
    }

    const savingsForm = document.getElementById('savings-form');
    if (savingsForm) {
        const resultAnnualYield = document.getElementById('result-annual-yield');
        const resultSavings = document.getElementById('result-savings');
        const resultCo2 = document.getElementById('result-co2');

        const inputs = savingsForm.querySelectorAll('input');
        inputs.forEach(function (input) {
            input.addEventListener('input', calculateSavings);
        });

        savingsForm.addEventListener('submit', function (event) {
            event.preventDefault();
            calculateSavings();
        });

        function calculateSavings() {
            const area = parseFloat(document.getElementById('input-area').value) || 0;
            const irradiation = parseFloat(document.getElementById('input-irradiation').value) || 0;
            const efficiency = parseFloat(document.getElementById('input-efficiency').value) || 0;
            const energyPrice = parseFloat(document.getElementById('input-price').value) || 0;

            const annualYield = area * irradiation * (efficiency / 100);
            const savings = annualYield * energyPrice;
            const co2Factor = 0.4; // kg CO2 pro kWh
            const co2Reduction = annualYield * co2Factor / 1000;

            if (resultAnnualYield) {
                resultAnnualYield.textContent = annualYield > 0
                    ? annualYield.toFixed(0) + ' kWh/Jahr'
                    : '0 kWh/Jahr';
            }
            if (resultSavings) {
                resultSavings.textContent = savings > 0
                    ? savings.toFixed(2) + ' € Einsparung/Jahr'
                    : '0,00 € Einsparung/Jahr';
            }
            if (resultCo2) {
                resultCo2.textContent = co2Reduction > 0
                    ? co2Reduction.toFixed(2) + ' t CO₂-Ersparnis/Jahr'
                    : '0,00 t CO₂-Ersparnis/Jahr';
            }
        }

        calculateSavings();
    }

    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        const feedback = document.querySelector('.form-feedback');

        contactForm.addEventListener('submit', function (event) {
            let isValid = true;
            const nameField = contactForm.querySelector('input[name="name"]');
            const emailField = contactForm.querySelector('input[name="email"]');
            const phoneField = contactForm.querySelector('input[name="phone"]');
            const messageField = contactForm.querySelector('textarea[name="message"]');

            if (nameField && nameField.value.trim().length < 3) {
                isValid = false;
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (emailField && !emailPattern.test(emailField.value.trim())) {
                isValid = false;
            }

            const phonePattern = /^[0-9+\-\s()]{6,}$/;
            if (phoneField && !phonePattern.test(phoneField.value.trim())) {
                isValid = false;
            }

            if (messageField && messageField.value.trim().length < 10) {
                isValid = false;
            }

            if (!isValid) {
                event.preventDefault();
                if (feedback) {
                    feedback.textContent = 'Bitte überprüfen Sie Ihre Eingaben. Alle Felder müssen korrekt ausgefüllt sein.';
                    feedback.style.color = '#C62828';
                }
            } else if (feedback) {
                feedback.textContent = 'Vielen Dank! Ihre Anfrage wird übermittelt.';
                feedback.style.color = 'var(--color-primary)';
            }
        });
    }
});