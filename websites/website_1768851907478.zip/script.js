document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.getElementById("site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", function () {
      const isOpen = siteNav.classList.toggle("is-open");
      navToggle.classList.toggle("is-active", isOpen);
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    siteNav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", () => {
        if (siteNav.classList.contains("is-open")) {
          siteNav.classList.remove("is-open");
          navToggle.classList.remove("is-active");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }
  const cookieBanner = document.getElementById("cookie-banner");
  if (cookieBanner) {
    const consentKey = "finconCookiesConsent";
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      cookieBanner.classList.add("is-visible");
    }
    cookieBanner.querySelectorAll("[data-cookie-action]").forEach(function (button) {
      button.addEventListener("click", function () {
        const action = button.getAttribute("data-cookie-action");
        localStorage.setItem(consentKey, action);
        cookieBanner.classList.remove("is-visible");
      });
    });
  }
});