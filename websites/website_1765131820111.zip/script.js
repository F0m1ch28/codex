document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('[data-nav-toggle]');
  const nav = document.querySelector('[data-nav]');
  const cookieBanner = document.querySelector('[data-cookie-banner]');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');
  const consentKey = 'shepherd-cookie-consent';

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const open = nav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', open);
    });
  }

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      requestAnimationFrame(() => cookieBanner.classList.add('is-visible'));
    }

    const handleConsent = (value) => {
      localStorage.setItem(consentKey, value);
      cookieBanner.classList.remove('is-visible');
    };

    acceptBtn?.addEventListener('click', () => handleConsent('accepted'));
    declineBtn?.addEventListener('click', () => handleConsent('declined'));
  }
});