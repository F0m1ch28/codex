document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const navLinks = document.querySelectorAll(".site-nav a");
    const cookieBanner = document.getElementById("cookie-banner");
    const acceptBtn = document.querySelector(".cookie-btn.accept");
    const declineBtn = document.querySelector(".cookie-btn.decline");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            siteNav.classList.toggle("is-open");
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (siteNav.classList.contains("is-open")) {
                    siteNav.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    if (cookieBanner) {
        const cookieStatus = localStorage.getItem("preferthvlCookies");
        if (!cookieStatus) {
            cookieBanner.classList.add("is-visible");
        }

        const handleCookieChoice = (event) => {
            event.preventDefault();
            const choice = event.currentTarget.dataset.choice || "dismissed";
            localStorage.setItem("preferthvlCookies", choice);
            cookieBanner.classList.remove("is-visible");
        };

        if (acceptBtn) {
            acceptBtn.addEventListener("click", handleCookieChoice);
        }
        if (declineBtn) {
            declineBtn.addEventListener("click", handleCookieChoice);
        }
    }
});