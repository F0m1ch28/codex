document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const cookieBanner = document.getElementById("cookie-banner");
    const acceptCookieButton = document.getElementById("cookie-accept");
    const declineCookieButton = document.getElementById("cookie-decline");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            siteNav.classList.toggle("nav-open");
            navToggle.classList.toggle("is-active");
        });

        siteNav.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                siteNav.classList.remove("nav-open");
                navToggle.classList.remove("is-active");
            });
        });
    }

    if (cookieBanner && acceptCookieButton && declineCookieButton) {
        const consentStatus = localStorage.getItem("salsolyyarCookieConsent");

        if (consentStatus === "accepted" || consentStatus === "declined") {
            cookieBanner.classList.add("hidden");
        }

        acceptCookieButton.addEventListener("click", () => {
            localStorage.setItem("salsolyyarCookieConsent", "accepted");
            cookieBanner.classList.add("hidden");
        });

        declineCookieButton.addEventListener("click", () => {
            localStorage.setItem("salsolyyarCookieConsent", "declined");
            cookieBanner.classList.add("hidden");
        });
    }
});