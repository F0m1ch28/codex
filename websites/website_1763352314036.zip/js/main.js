document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const mainNav = document.querySelector(".main-nav");
    const navLinks = document.querySelectorAll(".nav-link");
    const currentYearEl = document.getElementById("current-year");
    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.getElementById("cookie-accept");
    const declineBtn = document.getElementById("cookie-decline");
    const testimonials = document.querySelectorAll(".testimonial");
    const prevBtn = document.querySelector(".slider-prev");
    const nextBtn = document.querySelector(".slider-next");
    const form = document.getElementById("contact-form");

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    const toggleNav = () => {
        const isOpen = mainNav.classList.toggle("open");
        navToggle.setAttribute("aria-expanded", isOpen);
    };

    if (navToggle) {
        navToggle.addEventListener("click", toggleNav);
    }

    navLinks.forEach(link => {
        if (link.href === window.location.href) {
            link.classList.add("active");
        }
        link.addEventListener("click", () => {
            mainNav.classList.remove("open");
            navToggle.setAttribute("aria-expanded", "false");
        });
    });

    // Cookie banner
    const cookieKey = "polarion-cookie-consent";
    const consent = localStorage.getItem(cookieKey);

    if (!consent) {
        cookieBanner?.classList.add("show");
    }

    const handleConsent = (value) => {
        localStorage.setItem(cookieKey, value);
        cookieBanner?.classList.remove("show");
    };

    acceptBtn?.addEventListener("click", () => handleConsent("accepted"));
    declineBtn?.addEventListener("click", () => handleConsent("declined"));

    // Testimonials slider
    let currentSlide = 0;
    let sliderInterval;

    const showSlide = (index) => {
        testimonials.forEach((testimonial, idx) => {
            testimonial.classList.toggle("active", idx === index);
        });
    };

    const nextSlide = () => {
        currentSlide = (currentSlide + 1) % testimonials.length;
        showSlide(currentSlide);
    };

    const prevSlideFunc = () => {
        currentSlide = (currentSlide - 1 + testimonials.length) % testimonials.length;
        showSlide(currentSlide);
    };

    if (testimonials.length > 0) {
        sliderInterval = setInterval(nextSlide, 6000);
        nextBtn?.addEventListener("click", () => {
            nextSlide();
            clearInterval(sliderInterval);
        });
        prevBtn?.addEventListener("click", () => {
            prevSlideFunc();
            clearInterval(sliderInterval);
        });
    }

    // Contact form validation
    if (form) {
        form.addEventListener("submit", (e) => {
            e.preventDefault();
            const responseEl = form.querySelector(".form-response");
            const name = form.name.value.trim();
            const email = form.email.value.trim();
            const service = form.service.value.trim();
            const message = form.message.value.trim();

            if (!name || !email || !service || !message) {
                responseEl.textContent = "Please complete all required fields.";
                responseEl.style.color = "#ff6b81";
                return;
            }

            const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
            if (!emailValid) {
                responseEl.textContent = "Enter a valid email address.";
                responseEl.style.color = "#ff6b81";
                return;
            }

            responseEl.textContent = "Thank you. Our engineering team will respond soon.";
            responseEl.style.color = "#15e0d5";
            form.reset();
        });
    }
});