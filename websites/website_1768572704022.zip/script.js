document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".primary-nav");
    if (navToggle && nav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            navToggle.classList.toggle("is-active");
            nav.classList.toggle("is-open");
        });

        nav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                if (nav.classList.contains("is-open")) {
                    nav.classList.remove("is-open");
                    navToggle.classList.remove("is-active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-accept");
    const declineBtn = document.querySelector(".cookie-decline");
    const consentKey = "mm-cookie-consent";

    function setConsent(value) {
        localStorage.setItem(consentKey, value);
    }

    function getConsent() {
        return localStorage.getItem(consentKey);
    }

    if (cookieBanner) {
        const currentConsent = getConsent();
        if (!currentConsent) {
            cookieBanner.classList.add("active");
        }

        acceptBtn?.addEventListener("click", () => {
            setConsent("accepted");
            cookieBanner.classList.remove("active");
        });

        declineBtn?.addEventListener("click", () => {
            setConsent("declined");
            cookieBanner.classList.remove("active");
        });
    }
});