document.addEventListener('DOMContentLoaded', () => {
    const nav = document.querySelector('.primary-nav');
    const menuToggle = document.querySelector('.menu-toggle');
    const scrollBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAcceptBtn = document.getElementById('cookieAcceptBtn');
    const contactForm = document.getElementById('contactForm');
    const formFeedback = document.getElementById('formFeedback');
    const currentYear = document.getElementById('currentYear');
    const navLinks = document.querySelectorAll('.primary-nav a, .footer-nav a');

    // Mobile navigation toggle
    if (menuToggle && nav) {
        menuToggle.addEventListener('click', () => {
            const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
            menuToggle.setAttribute('aria-expanded', (!expanded).toString());
            nav.classList.toggle('open');
        });
    }

    // Close mobile menu on navigation
    navLinks.forEach(link => {
        link.addEventListener('click', event => {
            const href = link.getAttribute('href');
            if (menuToggle && nav && nav.classList.contains('open')) {
                menuToggle.setAttribute('aria-expanded', 'false');
                nav.classList.remove('open');
            }

            if (!href) return;

            const [page, hash] = href.split('#');

            // Smooth scroll for on-page links
            if (hash) {
                const currentPath = window.location.pathname;
                const normalizedPage = page ? page.replace('./', '') : '';
                const isSamePage =
                    (!normalizedPage && currentPath.includes('home.html')) ||
                    (!normalizedPage && (currentPath === '/' || currentPath.endsWith('/'))) ||
                    (normalizedPage && currentPath.endsWith(normalizedPage));

                if (isSamePage) {
                    event.preventDefault();
                    const target = document.getElementById(hash);
                    if (target) {
                        target.scrollIntoView({ behavior: 'smooth' });
                    }
                }
            }
        });
    });

    // Scroll-to-top button visibility
    const toggleScrollButton = () => {
        if (window.scrollY > 280) {
            scrollBtn.classList.add('visible');
        } else {
            scrollBtn.classList.remove('visible');
        }
    };

    if (scrollBtn) {
        window.addEventListener('scroll', toggleScrollButton);
        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Cookie banner
    if (cookieBanner && cookieAcceptBtn) {
        const consent = localStorage.getItem('ccaCookieConsent');
        if (consent === 'accepted') {
            cookieBanner.classList.add('hidden');
        }

        cookieAcceptBtn.addEventListener('click', () => {
            localStorage.setItem('ccaCookieConsent', 'accepted');
            cookieBanner.classList.add('hidden');
        });
    }

    // Contact form handler
    if (contactForm && formFeedback) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();

            const formData = new FormData(contactForm);
            const name = formData.get('name').trim();
            const email = formData.get('email').trim();
            const message = formData.get('message').trim();

            if (!name || !email || !message) {
                formFeedback.textContent = 'Please complete all required fields before submitting.';
                formFeedback.style.color = '#C3423F';
                return;
            }

            formFeedback.textContent = 'Thank you. Our team will respond shortly.';
            formFeedback.style.color = '#2B4C7E';
            contactForm.reset();
        });
    }

    // Dynamic year in footer
    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }
});