import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'joyful-toys-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1400);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem(COOKIE_KEY, 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem(COOKIE_KEY, 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Love for cookies 🍪</h4>
        <p>
          Joyful Toys uses cookies to personalise content and ensure a smooth browsing experience.
          By allowing cookies we can keep your playtime recommendations relevant and fun.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" onClick={handleDecline} className={styles.secondary}>
          Manage Later
        </button>
        <button type="button" onClick={handleAccept} className={styles.primary}>
          Accept Cookies
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;