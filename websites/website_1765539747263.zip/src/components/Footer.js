import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const currentYear = new Date().getFullYear();

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.column}>
        <div className={styles.brand}>
          <span className={styles.brandIcon}>🎁</span>
          <span className={styles.brandText}>Joyful Toys</span>
        </div>
        <p className={styles.description}>
          Joyful Toys is an online playground of imagination, carefully curating high-quality toys
          that spark curiosity, learning, and laughter for families across the Netherlands.
        </p>
        <p className={styles.address}>Based in the Netherlands</p>
      </div>

      <div className={styles.column}>
        <h4>Explore</h4>
        <ul className={styles.linkList}>
          <li>
            <Link to="/products">Product Collection</Link>
          </li>
          <li>
            <Link to="/guide">Buying Guide</Link>
          </li>
          <li>
            <Link to="/blog">Play Journal</Link>
          </li>
          <li>
            <Link to="/about">About Joyful Toys</Link>
          </li>
          <li>
            <Link to="/contact">Contact & Support</Link>
          </li>
        </ul>
      </div>

      <div className={styles.column}>
        <h4>Legals & Policies</h4>
        <ul className={styles.linkList}>
          <li>
            <Link to="/terms">Terms of Service</Link>
          </li>
          <li>
            <Link to="/privacy">Privacy Policy</Link>
          </li>
          <li>
            <Link to="/cookie-policy">Cookie Policy</Link>
          </li>
        </ul>
      </div>

      <div className={styles.column}>
        <h4>Stay in the Loop</h4>
        <p>Receive play inspiration, seasonal highlights, and learning tips.</p>
        <form className={styles.form} onSubmit={(event) => event.preventDefault()}>
          <label htmlFor="footer-email" className="visually-hidden">
            Email address
          </label>
          <input
            id="footer-email"
            type="email"
            placeholder="Enter your email"
            aria-label="Email address"
            required
          />
          <button type="submit">Get Inspired</button>
        </form>
        <div className={styles.social}>
          <a
            href="https://www.instagram.com"
            target="_blank"
            rel="noreferrer"
            aria-label="Joyful Toys on Instagram"
          >
            Instagram
          </a>
          <a
            href="https://www.facebook.com"
            target="_blank"
            rel="noreferrer"
            aria-label="Joyful Toys on Facebook"
          >
            Facebook
          </a>
          <a
            href="https://www.pinterest.com"
            target="_blank"
            rel="noreferrer"
            aria-label="Joyful Toys on Pinterest"
          >
            Pinterest
          </a>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {currentYear} Joyful Toys. Crafted with joy in the Netherlands.</p>
    </div>
  </footer>
);

export default Footer;