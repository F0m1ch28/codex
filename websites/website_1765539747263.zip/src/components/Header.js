import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <div className={styles.inner}>
        <Link to="/" className={styles.brand} aria-label="Joyful Toys home">
          <span className={styles.brandIcon}>🎠</span>
          <span className={styles.brandText}>Joyful Toys</span>
        </Link>

        <button
          className={styles.menuButton}
          type="button"
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Toggle main navigation"
        >
          <span className={styles.menuIcon} />
        </button>

        <nav
          id="primary-navigation"
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
        >
          <NavLink
            to="/"
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
            onClick={closeMenu}
          >
            Home
          </NavLink>
          <NavLink
            to="/products"
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
            onClick={closeMenu}
          >
            Products
          </NavLink>
          <NavLink
            to="/guide"
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
            onClick={closeMenu}
          >
            Buying Guide
          </NavLink>
          <NavLink
            to="/blog"
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
            onClick={closeMenu}
          >
            Blog
          </NavLink>
          <NavLink
            to="/about"
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
            onClick={closeMenu}
          >
            About
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
            onClick={closeMenu}
          >
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;