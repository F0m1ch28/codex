const products = [
  {
    id: 1,
    name: 'Aurora Sensory Discovery Set',
    image: 'https://images.unsplash.com/photo-1549921296-3b4a6bfe9b04?auto=format&fit=crop&w=1200&q=80',
    ageRange: '0-2 years',
    category: 'Sensory',
    tags: ['featured'],
    description:
      'A calming bundle of textured spheres, crinkle cloths, and musical rattles designed to stimulate newborn senses.',
    highlights: [
      'Gentle pastel palette with tactile contrast',
      'Machine-washable and BPA-free materials',
      'Includes parent guide with sensory play routines',
    ],
  },
  {
    id: 2,
    name: 'Little Architects Magnetic Tiles',
    image: 'https://images.unsplash.com/photo-1500043201570-14f0cf744064?auto=format&fit=crop&w=1200&q=80',
    ageRange: '3-5 years',
    category: 'Building',
    tags: ['featured', 'bestseller'],
    description:
      'Magnetic tiles in bold translucent colours that inspire imaginative structures and collaborative play.',
    highlights: [
      '64-piece set with geometric shapes',
      'Encourages STEM thinking and spatial awareness',
      'Storage-friendly stackable design',
    ],
  },
  {
    id: 3,
    name: 'Storytellers Puppet Theatre',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=80',
    ageRange: '4-6 years',
    category: 'Imaginative',
    tags: ['new'],
    description:
      'A foldable theatre with whimsical puppets that fuels storytelling, empathy, and language skills.',
    highlights: [
      'Includes 5 handcrafted puppets',
      'Reusable story cards with prompts',
      'Lightweight and easily stored',
    ],
  },
  {
    id: 4,
    name: 'Eco Adventurers Outdoor Kit',
    image: 'https://images.unsplash.com/photo-1529694157878-94ec89ec2a2a?auto=format&fit=crop&w=1200&q=80',
    ageRange: '5-8 years',
    category: 'Outdoor',
    tags: ['featured', 'new'],
    description:
      'A nature exploration kit with binoculars, plant press, and eco-friendly field journal for curious explorers.',
    highlights: [
      'Made from recycled materials',
      'Includes Dutch flora checklist',
      'Weather-resistant carry bag',
    ],
  },
  {
    id: 5,
    name: 'Rhythm & Rhyme Music Studio',
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80',
    ageRange: '3-5 years',
    category: 'Educational',
    tags: ['bestseller'],
    description:
      'An interactive music set featuring percussion instruments and a guided songbook for rhythmic play.',
    highlights: [
      'Teaches tempo, counting, and creative expression',
      'Includes QR code for guided music sessions',
      'Soft edges for safe group play',
    ],
  },
  {
    id: 6,
    name: 'Galaxy Explorers STEM Lab',
    image: 'https://images.unsplash.com/photo-1524567497308-04bbd690b66c?auto=format&fit=crop&w=1200&q=80',
    ageRange: '6-8 years',
    category: 'Educational',
    tags: ['featured'],
    description:
      'Hands-on experiments that teach children about solar systems, constellations, and simple circuitry.',
    highlights: [
      'Includes glow-in-the-dark star map',
      'Guided activities developed with science educators',
      'Reusable components for repeated experiments',
    ],
  },
  {
    id: 7,
    name: 'Mindful Moments Yoga Cards',
    image: 'https://images.unsplash.com/photo-1520880867055-1e30d1cb001c?auto=format&fit=crop&w=1200&q=80',
    ageRange: '4-6 years',
    category: 'Wellbeing',
    tags: ['new'],
    description:
      'Beautifully illustrated yoga and breathing cards designed to help children relax and build body awareness.',
    highlights: [
      '24 pose cards with playful affirmations',
      'Developed with children’s yoga teachers',
      'Includes parent guide for mindful routines',
    ],
  },
  {
    id: 8,
    name: 'Colour Splash Art Studio',
    image: 'https://images.unsplash.com/photo-1501644898242-cfea317dcd4c?auto=format&fit=crop&w=1200&q=80',
    ageRange: '5-8 years',
    category: 'Creative',
    tags: ['bestseller'],
    description:
      'A portable art station packed with eco-friendly paints, stencils, and texture tools for endless creativity.',
    highlights: [
      'Non-toxic, washable art supplies',
      'Foldable case for on-the-go creativity',
      'Project guide with Dutch & English prompts',
    ],
  },
  {
    id: 9,
    name: 'Seaside Sensory Sand Set',
    image: 'https://images.unsplash.com/photo-1477764250597-c3c8c5f7b2c2?auto=format&fit=crop&w=1200&q=80',
    ageRange: '2-4 years',
    category: 'Sensory',
    tags: ['new'],
    description:
      'Soft kinetic sand, shells, and sculpting tools bring the beach indoors—perfect for tactile exploration.',
    highlights: [
      'Non-sticky sand suitable for indoor play',
      'Promotes fine motor skills and sensory regulation',
      'Reusable container and play mat included',
    ],
  },
];

export default products;