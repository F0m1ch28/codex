const blogPosts = [
  {
    slug: 'the-importance-of-sensory-play',
    title: 'The Importance of Sensory Play for Early Childhood Development',
    excerpt:
      'Discover how sensory-rich experiences support brain development, emotional regulation, and confident exploration for little learners.',
    image: 'https://images.unsplash.com/photo-1480072724459-b34217f5f220?auto=format&fit=crop&w=1200&q=80',
    category: 'Sensory Play',
    author: 'Joyful Toys Play Advisors',
    date: 'Published February 2024',
    readTime: '6 min',
    sections: [
      {
        heading: 'Why sensory play matters',
        paragraphs: [
          'Sensory play helps children interpret the world through touch, sound, taste, sight, and smell. Each sensory experience builds new neural pathways, strengthening cognitive development.',
          'When toddlers squish, splash, or sift, they are learning how their actions influence their surroundings, a foundation for scientific reasoning and language growth.',
        ],
        list: [
          'Enhances mindfulness and emotional resilience',
          'Supports fine motor development and coordination',
          'Encourages social interaction through shared play',
        ],
      },
      {
        heading: 'Creating a sensory-friendly space at home',
        paragraphs: [
          'Start small with a dedicated tray and rotate sensory materials weekly. Offer a mix of textures, temperatures, and resistances for full-body engagement.',
          'Remember to include calming elements such as lavender-scented playdough or a gentle rainstick. These tools help children reset when feeling overwhelmed.',
        ],
      },
      {
        heading: 'Joyful Toys sensory picks',
        paragraphs: [
          'Our Aurora Sensory Discovery Set and Seaside Sensory Sand Set are designed with occupational therapists to support sensory seekers safely.',
          'Look out for our PlayCue cards tucked inside each set—they provide 10-minute activity ideas curated for Dutch family routines.',
        ],
      },
    ],
  },
  {
    slug: 'top-5-toys-for-toddlers-2024',
    title: 'Top 5 Toys for Toddlers in 2024',
    excerpt:
      'From interactive music kits to eco-conscious builders, discover the toddler toys captivating families across the Netherlands this year.',
    image: 'https://images.unsplash.com/photo-1533119408463-b0f487583ff6?auto=format&fit=crop&w=1200&q=80',
    category: 'Toy Guides',
    author: 'Mila Janssen',
    date: 'Published March 2024',
    readTime: '5 min',
    sections: [
      {
        heading: 'Curating with curiosity',
        paragraphs: [
          'Toddlers thrive on repetition and novelty together. The best toys blend open-ended exploration with familiar rituals, allowing children to feel safe while testing new ideas.',
        ],
        list: [
          'Little Architects Magnetic Tiles',
          'Rhythm & Rhyme Music Studio',
          'Storytellers Puppet Theatre',
          'Mindful Moments Yoga Cards',
          'Seaside Sensory Sand Set',
        ],
      },
      {
        heading: 'How we test our favourites',
        paragraphs: [
          'Each shortlisted toy goes through a play lab session with real families in Utrecht. We observe durability, clean-up ease, and how children respond to sounds, colours, and textures.',
          'Only toys that encourage shared play and independent focus make it into our final top five.',
        ],
      },
    ],
  },
  {
    slug: 'building-creativity-with-open-ended-toys',
    title: 'Building Creativity with Open-Ended Toys',
    excerpt:
      'Open-ended play empowers children to tell their own stories. Learn how to stock your playroom with versatile pieces that grow with your child.',
    image: 'https://images.unsplash.com/photo-1500336624523-d727130c3328?auto=format&fit=crop&w=1200&q=80',
    category: 'Creative Play',
    author: 'Anika Vermeer',
    date: 'Published January 2024',
    readTime: '7 min',
    sections: [
      {
        heading: 'What makes a toy open-ended?',
        paragraphs: [
          'Open-ended toys are those without a single “correct” outcome. Think magnetic tiles, loose parts, scarves, and wooden blocks—items that adapt to your child’s imagination.',
        ],
        list: [
          'Encourage experimentation and resilience',
          'Support different developmental stages',
          'Foster collaboration between siblings and friends',
        ],
      },
      {
        heading: 'Starter kit for creative playrooms',
        paragraphs: [
          'Begin with a foundation of building materials, add sensory textures, and incorporate props for storytelling. Mixing these elements keeps the play environment dynamic.',
          'Remember to include simple storage solutions so children can access pieces independently, strengthening autonomy.',
        ],
      },
      {
        heading: 'Beyond the toy shelf',
        paragraphs: [
          'Creative play flourishes when children see adults modeling curiosity. Join their building sessions, ask open-ended questions, and celebrate process over product.',
          'Share your creations with the Joyful Toys community—we love featuring family-made masterpieces in our newsletter.',
        ],
      },
    ],
  },
];

export default blogPosts;