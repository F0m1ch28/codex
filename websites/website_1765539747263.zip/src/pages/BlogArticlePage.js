import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import blogPosts from '../data/blogPosts';
import styles from './BlogArticlePage.module.css';

const BlogArticlePage = () => {
  const { slug } = useParams();
  const post = blogPosts.find((item) => item.slug === slug);

  if (!post) {
    return (
      <section className={styles.notFound}>
        <Helmet>
          <title>Article Not Found | Joyful Toys Blog</title>
        </Helmet>
        <div className={styles.notFoundCard}>
          <h1>Article not found</h1>
          <p>
            We couldn’t find the article you’re looking for. Head back to the blog overview to
            continue exploring joyful stories.
          </p>
          <Link to="/blog" className="btn-primary">
            Back to Joyful Journal
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} | Joyful Toys Blog</title>
        <meta name="description" content={post.excerpt} />
      </Helmet>

      <article className={styles.article}>
        <header className={styles.header}>
          <span className="badge">{post.category}</span>
          <h1>{post.title}</h1>
          <p className={styles.excerpt}>{post.excerpt}</p>
          <div className={styles.meta}>
            <span>By {post.author}</span>
            <span>{post.date}</span>
            <span>{post.readTime} read</span>
          </div>
          <img src={post.image} alt={post.title} className={styles.heroImage} />
        </header>

        <div className={styles.body}>
          {post.sections.map((section) => (
            <section key={section.heading} className={styles.section}>
              <h2>{section.heading}</h2>
              {section.paragraphs.map((paragraph) => (
                <p key={paragraph.slice(0, 40)}>{paragraph}</p>
              ))}
              {section.list && (
                <ul>
                  {section.list.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              )}
            </section>
          ))}
        </div>

        <footer className={styles.footer}>
          <div className={styles.callout}>
            <h3>Continue your play journey</h3>
            <p>
              Explore our collection to find toys that turn today’s inspiration into tomorrow’s
              playtime adventure.
            </p>
            <div className={styles.links}>
              <Link to="/products" className="btn-primary">
                Browse toys
              </Link>
              <Link to="/blog" className="btn-secondary">
                Back to blog
              </Link>
            </div>
          </div>
        </footer>
      </article>
    </>
  );
};

export default BlogArticlePage;