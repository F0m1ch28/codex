import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './GuidePage.module.css';

const GuidePage = () => (
  <>
    <Helmet>
      <title>Joyful Toys Buying Guide | Choose the Perfect Toy</title>
      <meta
        name="description"
        content="Discover expert tips from Joyful Toys on selecting safe, inspiring toys for every age group, developmental stage, and interest."
      />
    </Helmet>

    <section className={styles.guideHero}>
      <div className={styles.heroContent}>
        <span className="badge">Expert Play Advice</span>
        <h1>Your Trusted Buying Guide</h1>
        <p>
          Choosing the right toy is an investment in joyful memories and lifelong skills. Our guide
          helps you navigate age-appropriate play, developmental milestones, and personality-driven
          interests with confidence.
        </p>
      </div>
      <img
        className={styles.heroImage}
        src="https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=1200&q=80"
        alt="Parent guiding child through educational toys"
      />
    </section>

    <section className={styles.contentSection}>
      <h2>Age-based Play Recommendations</h2>
      <div className={styles.grid}>
        <article className={styles.card}>
          <h3>Babies (0-12 months)</h3>
          <ul>
            <li>Soft textures and contrasting colours stimulate sensory discovery.</li>
            <li>Toys with gentle sounds encourage auditory recognition and self-soothing.</li>
            <li>Ensure materials are BPA-free and washable for hygienic play.</li>
          </ul>
        </article>
        <article className={styles.card}>
          <h3>Toddlers (1-3 years)</h3>
          <ul>
            <li>Look for push-and-pull toys to support confident walking and balance.</li>
            <li>Chunky puzzles and stacking sets boost problem-solving and fine motor control.</li>
            <li>Embrace cause-and-effect toys to fuel curiosity and experimentation.</li>
          </ul>
        </article>
        <article className={styles.card}>
          <h3>Pre-schoolers (3-5 years)</h3>
          <ul>
            <li>Pretend play sets help build language, empathy, and storytelling skills.</li>
            <li>Arts & crafts kits nurture self-expression and mindful focus.</li>
            <li>STEM-friendly building sets encourage spatial awareness and logic.</li>
          </ul>
        </article>
        <article className={styles.card}>
          <h3>Early learners (6-8 years)</h3>
          <ul>
            <li>Board games foster patience, collaboration, and numeracy.</li>
            <li>Science kits combine hands-on experiments with real-world concepts.</li>
            <li>Outdoor adventure gear keeps play active and boosts self-confidence.</li>
          </ul>
        </article>
      </div>
    </section>

    <section className={styles.contentSection}>
      <h2>Four Pillars of Joyful Toy Selection</h2>
      <ol className={styles.pillars}>
        <li>
          <strong>Safety and durability:</strong> All toys should be non-toxic, sturdy, and certified
          for the relevant age group. Always check for small parts and perform regular inspections.
        </li>
        <li>
          <strong>Learning potential:</strong> Seek toys that encourage open-ended exploration,
          inviting children to problem-solve, imagine stories, and practice new skills.
        </li>
        <li>
          <strong>Sensory balance:</strong> Mix tactile, auditory, and visual experiences. Sensory
          play helps children regulate emotions and develop body awareness.
        </li>
        <li>
          <strong>Sustainable choices:</strong> Eco-conscious materials and ethically produced toys
          teach respect for the planet while lasting through multiple play cycles.
        </li>
      </ol>
    </section>

    <section className={styles.checklistSection}>
      <div className={styles.checklistCard}>
        <h2>Quick Checklist Before You Buy</h2>
        <ul>
          <li>Is the toy aligned with my child’s current interests?</li>
          <li>Does it match their motor and cognitive stage?</li>
          <li>Can the toy grow with my child or be enjoyed in multiple ways?</li>
          <li>Have I balanced indoor, outdoor, quiet, and active play?</li>
          <li>Do I have space to store the toy safely when not in use?</li>
        </ul>
      </div>
      <div className={styles.checklistVisual}>
        <img
          src="https://images.unsplash.com/photo-1611599536271-0cf2940f8206?auto=format&fit=crop&w=1100&q=80"
          alt="Selection of colourful educational toys and blocks"
        />
      </div>
    </section>

    <section className={styles.tipSection}>
      <h2>Pro Tips from Our Play Advisors</h2>
      <div className={styles.tipGrid}>
        <div className={styles.tip}>
          <h3>Rotate Play Zones</h3>
          <p>
            Introduce small rotations of toys every two weeks. Fresh novelty keeps curiosity alive
            without overwhelming your child or storage.
          </p>
        </div>
        <div className={styles.tip}>
          <h3>Read the Instructions Together</h3>
          <p>
            Turning assembly into a collaborative project ensures safe setup and models patient,
            mindful behaviour.
          </p>
        </div>
        <div className={styles.tip}>
          <h3>Document Milestones</h3>
          <p>
            Capture short videos or notes when your child masters a new skill—a delightful record of
            growth that informs future toy choices.
          </p>
        </div>
      </div>
    </section>

    <section className={styles.cta}>
      <div>
        <h2>Need personalised guidance?</h2>
        <p>
          Share your child’s interests with our Joyful Play Advisors, and we’ll curate a toy capsule
          tailored to their stage and personality.
        </p>
      </div>
      <Link to="/contact" className="btn-primary">
        Send Your Joyful Message
      </Link>
    </section>
  </>
);

export default GuidePage;