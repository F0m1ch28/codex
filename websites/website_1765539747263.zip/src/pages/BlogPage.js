import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import blogPosts from '../data/blogPosts';
import styles from './BlogPage.module.css';

const BlogPage = () => (
  <>
    <Helmet>
      <title>Joyful Toys Blog | Playful Parenting & Toy Insights</title>
      <meta
        name="description"
        content="Stay updated with Joyful Toys. Explore expert articles on sensory play, STEM toys, and creative parenting ideas to enrich family life."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <span className="badge">Joyful Journal</span>
        <h1>Stories to spark play & connection</h1>
        <p>
          From sensory adventures to sustainable toy care, our play specialists share tips to fill
          your home with creativity, learning, and laughter.
        </p>
      </div>
      <img
        src="https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1200&q=80"
        alt="Parent and child reading a book together"
      />
    </section>

    <section className={styles.listSection}>
      <div className={styles.grid}>
        {blogPosts.map((post) => (
          <article key={post.slug} className={styles.card}>
            <div className={styles.imageWrapper}>
              <img src={post.image} alt={post.title} />
              <span className="badge">{post.category}</span>
            </div>
            <div className={styles.content}>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <Link to={`/blog/${post.slug}`} className={styles.link}>
                Read more →
              </Link>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default BlogPage;