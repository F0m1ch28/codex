import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './AboutPage.module.css';

const AboutPage = () => (
  <>
    <Helmet>
      <title>About Joyful Toys | Our Story & Promise</title>
      <meta
        name="description"
        content="Learn about Joyful Toys, the Netherlands-based online toy store dedicated to high-quality, safe, and imaginative play experiences for children."
      />
    </Helmet>

    <section className={styles.hero}>
      <div>
        <span className="badge">Our Story</span>
        <h1>Nurturing joyful play across the Netherlands</h1>
        <p>
          Joyful Toys began as a family passion project, inspiring children to explore, question,
          and create. Every toy we curate celebrates childhood wonder while supporting parents with
          thoughtful guidance.
        </p>
      </div>
      <img
        src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=1200&q=80"
        alt="Children playing with building blocks at Joyful Toys"
      />
    </section>

    <section className={styles.values}>
      <h2>Our guiding promises</h2>
      <div className={styles.grid}>
        <article className={styles.card}>
          <h3>Safety first</h3>
          <p>
            All toys are EU-certified, non-toxic, and durability tested. We work closely with brands
            that champion child safety and transparent production.
          </p>
        </article>
        <article className={styles.card}>
          <h3>Purposeful play</h3>
          <p>
            Each collection is selected with educators and therapists to foster creativity,
            communication, and problem-solving.
          </p>
        </article>
        <article className={styles.card}>
          <h3>Sustainable future</h3>
          <p>
            We collaborate with eco-conscious makers, prioritising recycled materials, minimal
            packaging, and carbon-smart delivery routes.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.story}>
      <div className={styles.storyContent}>
        <h2>How Joyful Toys came to life</h2>
        <p>
          Founded in Utrecht by two play enthusiasts, Joyful Toys emerged from a simple observation:
          families wanted toys that combined quality, educational value, and storytelling magic.
        </p>
        <p>
          We started hosting neighbourhood play afternoons, where we tested toys with kids, parents,
          and educators. Those lively sessions informed our curated catalogues, inspired our PlayCue
          idea cards, and formed a caring community around purposeful playtime.
        </p>
      </div>
      <img
        src="https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?auto=format&fit=crop&w=1200&q=80"
        alt="Founders of Joyful Toys collaborating in a playful workspace"
      />
    </section>

    <section className={styles.timeline}>
      <h2>Milestones that shape us</h2>
      <div className={styles.timelineGrid}>
        <div className={styles.timelineItem}>
          <span className={styles.year}>2018</span>
          <p>Launched Joyful Toys with 25 carefully tested products and local delivery.</p>
        </div>
        <div className={styles.timelineItem}>
          <span className={styles.year}>2020</span>
          <p>Introduced PlayCue cards and partnered with child therapists for curated guidance.</p>
        </div>
        <div className={styles.timelineItem}>
          <span className={styles.year}>2022</span>
          <p>Expanded to nationwide Netherlands shipping with carbon-neutral options.</p>
        </div>
        <div className={styles.timelineItem}>
          <span className={styles.year}>2024</span>
          <p>Launched our Joyful Journal and digital toy-matching quiz for families.</p>
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <h2>Meet the Joyful team</h2>
      <div className={styles.teamGrid}>
        <article className={styles.member}>
          <img
            src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=500&q=80"
            alt="Portrait of Mila, Joyful Toys play curator"
          />
          <h3>Mila Janssen</h3>
          <p>Head of Play Curation</p>
        </article>
        <article className={styles.member}>
          <img
            src="https://images.unsplash.com/photo-1521579971123-1192931a1452?auto=format&fit=crop&w=500&q=80"
            alt="Portrait of Jasper, Joyful Toys logistics lead"
          />
          <h3>Jasper Van Dijk</h3>
          <p>Logistics & Sustainability Lead</p>
        </article>
        <article className={styles.member}>
          <img
            src="https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=500&q=80"
            alt="Portrait of Anika, Joyful Toys community manager"
          />
          <h3>Anika Vermeer</h3>
          <p>Community & Events Manager</p>
        </article>
      </div>
    </section>

    <section className={styles.cta}>
      <div>
        <h2>Let’s build joyful moments together</h2>
        <p>
          We love hearing from families, teachers, and play therapists. Share your ideas, feedback,
          or dream toys—we’re always listening.
        </p>
      </div>
      <Link to="/contact" className="btn-primary">
        Send Your Joyful Message
      </Link>
    </section>
  </>
);

export default AboutPage;