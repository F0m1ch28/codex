import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PrivacyPage.module.css';

const PrivacyPage = () => (
  <>
    <Helmet>
      <title>Privacy Policy | Joyful Toys</title>
      <meta
        name="description"
        content="Understand how Joyful Toys collects, uses, and protects your personal information when you explore our online store."
      />
    </Helmet>

    <section className={styles.page}>
      <div className={styles.card}>
        <h1>Privacy Policy</h1>
        <p>
          Joyful Toys respects your privacy and is committed to protecting your personal data. This
          policy explains how we collect, use, and safeguard information when you interact with our
          website.
        </p>

        <h2>1. Data we collect</h2>
        <p>
          We collect personal information that you voluntarily provide, such as your name and email
          address when you join our newsletter or submit a contact form. For analytics, we collect
          non-identifiable data including device type, browser, and browsing behaviour.
        </p>

        <h2>2. How we use your data</h2>
        <p>
          Data helps us personalise recommendations, respond to inquiries, and improve website
          performance. We may send relevant updates or promotions if you opt in to receive them.
        </p>

        <h2>3. Data sharing</h2>
        <p>
          We do not sell your personal data. We may share information with trusted partners who
          assist with website hosting, analytics, or customer support, ensuring they maintain
          appropriate safeguards.
        </p>

        <h2>4. Cookies</h2>
        <p>
          Joyful Toys uses cookies to remember preferences and analyse website traffic. You can
          update cookie preferences or disable them in your browser settings. Learn more in our
          Cookie Policy.
        </p>

        <h2>5. Security</h2>
        <p>
          We implement technical and organisational measures to secure your data. While we strive for
          high security standards, no online transmission is completely risk-free.
        </p>

        <h2>6. Your rights</h2>
        <p>
          You may request access, correction, or deletion of personal data. Contact us to exercise
          your rights or to ask questions about our privacy practices.
        </p>

        <h2>7. Policy updates</h2>
        <p>
          We may update this policy to reflect changes in operations or legal obligations. Updated
          versions will be posted with a revised effective date.
        </p>
      </div>
    </section>
  </>
);

export default PrivacyPage;