import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [formValues, setFormValues] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [submissionStatus, setSubmissionStatus] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmissionStatus('Thank you! Your joyful message has been received.');
    setFormValues({ name: '', email: '', subject: '', message: '' });
    setTimeout(() => setSubmissionStatus(''), 4000);
  };

  return (
    <>
      <Helmet>
        <title>Contact Joyful Toys | We’d Love to Hear From You</title>
        <meta
          name="description"
          content="Reach out to Joyful Toys for toy recommendations, collaboration ideas, or playful feedback. We’re ready to help your family create joyful memories."
        />
      </Helmet>

      <section className={styles.hero}>
        <div>
          <span className="badge">Let’s talk playtime</span>
          <h1>Send Your Joyful Message</h1>
          <p>
            Whether you’re searching for the perfect sensory kit or curious about our sustainable
            practices, our team is here to help.
          </p>
        </div>
        <img
          src="https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=1200&q=80"
          alt="Joyful Toys customer support assisting parents"
        />
      </section>

      <section className={styles.contactSection}>
        <form className={styles.form} onSubmit={handleSubmit}>
          <div className={styles.field}>
            <label htmlFor="contact-name">Name</label>
            <input
              id="contact-name"
              type="text"
              name="name"
              value={formValues.name}
              onChange={handleChange}
              required
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="contact-email">Email</label>
            <input
              id="contact-email"
              type="email"
              name="email"
              value={formValues.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="contact-subject">Subject</label>
            <input
              id="contact-subject"
              type="text"
              name="subject"
              value={formValues.subject}
              onChange={handleChange}
              required
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="contact-message">Message</label>
            <textarea
              id="contact-message"
              name="message"
              rows="6"
              value={formValues.message}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className="btn-primary">
            Send Your Joyful Message
          </button>
          {submissionStatus && <p className={styles.status}>{submissionStatus}</p>}
        </form>

        <div className={styles.infoCard}>
          <h2>Where to find us</h2>
          <p>
            Based in the Netherlands, Joyful Toys is a digital-first store with a vibrant community
            of families, teachers, and therapists.
          </p>
          <div className={styles.infoBlock}>
            <h3>Business hours</h3>
            <p>Monday to Friday · 09:00 – 17:00 CET</p>
            <p>Weekends · 10:00 – 15:00 CET</p>
          </div>
          <div className={styles.infoBlock}>
            <h3>Need toy inspiration?</h3>
            <p>
              Share your child’s interests and our play advisors will reply with a curated list
              within 48 hours.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;