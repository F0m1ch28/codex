import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './HomePage.module.css';
import blogPosts from '../data/blogPosts';

const carouselSlides = [
  {
    id: 1,
    title: 'STEM Wonder Lab',
    description:
      'Spark scientific curiosity with interactive experiment kits, perfect for budding inventors and little explorers.',
    image: 'https://images.unsplash.com/photo-1529257414771-1960ab1f5f9c?auto=format&fit=crop&w=1400&q=80',
    badge: 'Featured',
  },
  {
    id: 2,
    title: 'Soft & Musical Friends',
    description:
      'Huggable plush pals that sing lullabies, teach rhythm, and create calming nighttime routines with gentle melodies.',
    image: 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=1400&q=80',
    badge: 'New Arrival',
  },
  {
    id: 3,
    title: 'Creative Builders Club',
    description:
      'Imaginative block sets that develop fine motor skills and creative problem solving for fearless architects.',
    image: 'https://images.unsplash.com/photo-1511456747560-088e4df54eb1?auto=format&fit=crop&w=1400&q=80',
    badge: 'Editor’s Pick',
  },
];

const categories = [
  { label: 'Ages 0-2', icon: '🍼', filter: { age: '0-2 years' } },
  { label: 'Early Learning', icon: '📚', filter: { category: 'Educational' } },
  { label: 'Building Blocks', icon: '🧱', filter: { category: 'Building' } },
  { label: 'Pretend Play', icon: '🎭', filter: { category: 'Imaginative' } },
  { label: 'Outdoor Fun', icon: '🌈', filter: { category: 'Outdoor' } },
];

const stats = [
  { number: '2,500+', label: 'Happy families across NL', icon: '💛' },
  { number: '180+', label: 'Curated toy varieties', icon: '🎯' },
  { number: '35', label: 'Partnered sustainable brands', icon: '🌱' },
  { number: '4.9/5', label: 'Average playtime satisfaction', icon: '🌟' },
];

const newArrivals = [
  {
    id: 1,
    title: 'Rainbow Sensory Tunnel',
    image: 'https://images.unsplash.com/photo-1504150558240-0b4fd8946624?auto=format&fit=crop&w=1200&q=80',
    description:
      'A foldable sensory tunnel with multicolour textures, perfect for tummy time adventures and imaginative obstacle courses.',
    tag: '0-3 years',
  },
  {
    id: 2,
    title: 'Eco Explorer Discovery Kit',
    image: 'https://images.unsplash.com/photo-1510563800747-9a3172dcd66f?auto=format&fit=crop&w=1200&q=80',
    description:
      'Solar-powered gadgets and magnifying tools that invite children to explore nature responsibly and creatively.',
    tag: '5-8 years',
  },
  {
    id: 3,
    title: 'Cosmic Storytime Projector',
    image: 'https://images.unsplash.com/photo-1604881988758-f76ad6747361?auto=format&fit=crop&w=1200&q=80',
    description:
      'Project animated bedtime stories that promote mindfulness, empathy, and big dreams among young listeners.',
    tag: '3-6 years',
  },
];

const testimonials = [
  {
    id: 1,
    quote:
      'The curated bundles from Joyful Toys keep my twins engaged for hours. I love how each toy includes ideas for playful learning!',
    name: 'Lotte, Utrecht',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80',
  },
  {
    id: 2,
    quote:
      'Fast delivery, thoughtful packaging, and incredible toy quality. Our sensory play corner has never looked better.',
    name: 'Sven, Rotterdam',
    image: 'https://images.unsplash.com/photo-1521119989659-a83eee488004?auto=format&fit=crop&w=400&q=80',
  },
  {
    id: 3,
    quote:
      'My daughter absolutely adores the music workshop set. Joyful Toys makes it effortless to discover unique gifts.',
    name: 'Noor, Eindhoven',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80',
  },
];

const HomePage = () => {
  const [activeSlide, setActiveSlide] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const interval = setInterval(
      () => setActiveSlide((prev) => (prev + 1) % carouselSlides.length),
      6000
    );
    return () => clearInterval(interval);
  }, []);

  const handleCategoryClick = (categoryFilter) => {
    navigate('/products', { state: { filter: categoryFilter } });
  };

  const latestPosts = blogPosts.slice(0, 3);

  return (
    <>
      <Helmet>
        <title>Joyful Toys | Playful & Educational Toys in the Netherlands</title>
        <meta
          name="description"
          content="Discover Joyful Toys, the vibrant online toy store in the Netherlands delivering imaginative, sustainable, and educational toys that inspire endless playtime."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className="badge">Playtime, leveled up</span>
          <h1>
            Ignite Imagination with <span>Joyful Toys</span>
          </h1>
          <p>
            Curated toys that champion creativity, STEM thinking, and sensory development. Delivered
            with love across the Netherlands, ready to transform every day into a joyful discovery.
          </p>
          <div className={styles.heroActions}>
            <Link to="/products" className="btn-primary">
              Browse the Collection
            </Link>
            <Link to="/guide" className="btn-secondary">
              Explore Buying Guide
            </Link>
          </div>
          <ul className={styles.heroHighlights}>
            <li>✔️ Carefully vetted, child-safe brands</li>
            <li>✔️ Playful learning tips with every order</li>
            <li>✔️ Carbon-conscious delivery options</li>
          </ul>
        </div>
        <div className={styles.heroVisual}>
          <div className={styles.heroImageWrapper}>
            <img
              src="https://images.unsplash.com/photo-1604950202113-692713f919ec?auto=format&fit=crop&w=1300&q=80"
              alt="Children playing with colourful educational toys"
            />
            <div className={styles.heroCard}>
              <p>
                “Playtime is where confidence grows. Joyful Toys makes it easy to nurture every
                milestone with the right toy.” – Emma, Amsterdam
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.carouselSection} section-spacing`}>
        <div className={styles.sectionHeading}>
          <h2>Spotlight toys that spark wonder</h2>
          <p>
            Discover weekly highlights chosen by our play experts to encourage imaginative stories,
            sensory adventures, and collaborative playdates.
          </p>
        </div>
        <div className={styles.carousel}>
          {carouselSlides.map((slide, index) => (
            <article
              key={slide.id}
              className={`${styles.slide} ${index === activeSlide ? styles.slideActive : ''}`}
              aria-hidden={index !== activeSlide}
            >
              <div className={styles.slideImage}>
                <img src={slide.image} alt={`${slide.title} highlight toy`} />
                <span className="badge">{slide.badge}</span>
              </div>
              <div className={styles.slideContent}>
                <h3>{slide.title}</h3>
                <p>{slide.description}</p>
                <button
                  type="button"
                  className={styles.learnMore}
                  onClick={() => navigate('/products', { state: { filter: { tag: slide.badge } } })}
                >
                  Learn more
                </button>
              </div>
            </article>
          ))}
          <div className={styles.carouselDots}>
            {carouselSlides.map((slide, index) => (
              <button
                key={slide.id}
                type="button"
                className={`${styles.dot} ${index === activeSlide ? styles.dotActive : ''}`}
                onClick={() => setActiveSlide(index)}
                aria-label={`Show slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.categories} section-spacing`}>
        <h2>Quick access to your playtime heroes</h2>
        <p>
          Dive into curated categories designed for developmental stages, interests, and joyful
          family moments.
        </p>
        <div className={`${styles.categoryGrid} grid`}>
          {categories.map((category) => (
            <button
              key={category.label}
              type="button"
              className={styles.categoryCard}
              onClick={() => handleCategoryClick(category.filter)}
            >
              <span className={styles.categoryIcon}>{category.icon}</span>
              <span className={styles.categoryLabel}>{category.label}</span>
              <span className={styles.categoryAction}>Shop now ↗</span>
            </button>
          ))}
        </div>
      </section>

      <section className={`${styles.stats} section-spacing`}>
        <div className={styles.statsIntro}>
          <h2>The Joyful difference in numbers</h2>
          <p>
            We blend expert curation with heartfelt storytelling, so every delivery feels like a
            celebration waiting to happen.
          </p>
        </div>
        <div className={`${styles.statsGrid} grid`}>
          {stats.map((item) => (
            <div key={item.label} className={styles.statCard}>
              <span className={styles.statIcon}>{item.icon}</span>
              <strong>{item.number}</strong>
              <span>{item.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.newArrivals} section-spacing`}>
        <div className={styles.sectionHeading}>
          <h2>Fresh arrivals to amplify playtime</h2>
          <p>
            Newly added treasures, crafted with bold colours, mindful materials, and hours of joyful
            possibilities.
          </p>
        </div>
        <div className={`${styles.arrivalGrid} grid-three grid`}>
          {newArrivals.map((item) => (
            <article key={item.id} className={styles.arrivalCard}>
              <div className={styles.arrivalImage}>
                <img src={item.image} alt={item.title} />
                <span className="badge">{item.tag}</span>
              </div>
              <div className={styles.arrivalContent}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
                <Link to="/products" className={styles.inlineLink}>
                  View product insights →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.journey} section-spacing`}>
        <div className={styles.journeyIntro}>
          <span className="badge">Playful learning blueprint</span>
          <h2>Our Joyful Learning Journey</h2>
          <p>
            Each Joyful Toy is paired with a PlayCue card, guiding families through purposeful play.
            From sensory sparks to confident storytelling, here is how we support every milestone.
          </p>
        </div>
        <div className={`${styles.journeySteps} grid`}>
          <div className={styles.step}>
            <span className={styles.stepNumber}>1</span>
            <h3>Discover</h3>
            <p>Begin with curated quizzes that reveal your child’s interests and learning style.</p>
          </div>
          <div className={styles.step}>
            <span className={styles.stepNumber}>2</span>
            <h3>Play</h3>
            <p>
              Receive tactile toys with activity prompts, encouraging STEAM thinking and joyful
              collaboration.
            </p>
          </div>
          <div className={styles.step}>
            <span className={styles.stepNumber}>3</span>
            <h3>Reflect</h3>
            <p>
              Track milestones with guidance from child development specialists and share proud
              moments with the community.
            </p>
          </div>
        </div>
      </section>

      <section className={`${styles.testimonials} section-spacing`}>
        <div className={styles.sectionHeading}>
          <h2>Families who play with joy</h2>
          <p>
            Our community of Dutch families share how Joyful Toys brings sparkle, creativity, and
            connection to everyday play.
          </p>
        </div>
        <div className={`${styles.testimonialGrid} grid-three grid`}>
          {testimonials.map((testimonial) => (
            <blockquote key={testimonial.id} className={styles.testimonialCard}>
              <div className={styles.testimonialImage}>
                <img src={testimonial.image} alt={`${testimonial.name}`} />
              </div>
              <p>“{testimonial.quote}”</p>
              <footer>— {testimonial.name}</footer>
            </blockquote>
          ))}
        </div>
      </section>

      <section className={`${styles.blogPreview} section-spacing`}>
        <div className={styles.sectionHeading}>
          <h2>Fresh stories from the Joyful Journal</h2>
          <p>
            Dive into play-based learning tips, toy care advice, and seasonal guides crafted by our
            child development writers.
          </p>
        </div>
        <div className={`${styles.blogGrid} grid-three grid`}>
          {latestPosts.map((post) => (
            <article key={post.slug} className={styles.blogCard}>
              <div className={styles.blogImage}>
                <img src={post.image} alt={post.title} />
              </div>
              <div className={styles.blogContent}>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={`/blog/${post.slug}`} className={styles.inlineLink}>
                  Read the full story →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.cta} section-spacing`}>
        <div className={styles.ctaContent}>
          <h2>Ready to design days filled with joyful play?</h2>
          <p>
            Join the Joyful Toys community to receive curated toy recommendations, downloadable play
            ideas, and early access to limited drops.
          </p>
          <div className={styles.heroActions}>
            <Link to="/products" className="btn-primary">
              Start Exploring Toys
            </Link>
            <Link to="/contact" className="btn-secondary">
              Send a Joyful Message
            </Link>
          </div>
        </div>
        <div className={styles.ctaVisual}>
          <img
            src="https://images.unsplash.com/photo-1498079022511-d15614cb1c02?auto=format&fit=crop&w=1200&q=80"
            alt="Parent and child playing with colourful blocks together"
          />
        </div>
      </section>
    </>
  );
};

export default HomePage;