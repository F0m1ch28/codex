import React, { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import products from '../data/products';
import styles from './ProductsPage.module.css';

const getUniqueValues = (items, key) => ['All', ...new Set(items.map((item) => item[key]))];

const ProductsPage = () => {
  const location = useLocation();
  const [selectedAge, setSelectedAge] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedTag, setSelectedTag] = useState('All');

  useEffect(() => {
    if (location.state?.filter) {
      const { filter } = location.state;
      if (filter.age) setSelectedAge(filter.age);
      if (filter.category) setSelectedCategory(filter.category);
      if (filter.tag) setSelectedTag(filter.tag === 'New Arrival' ? 'New' : 'Featured');
    }
  }, [location.state]);

  const ageOptions = useMemo(() => getUniqueValues(products, 'ageRange'), []);
  const categoryOptions = useMemo(() => getUniqueValues(products, 'category'), []);

  const filteredProducts = products.filter((product) => {
    const ageMatch = selectedAge === 'All' || product.ageRange === selectedAge;
    const categoryMatch = selectedCategory === 'All' || product.category === selectedCategory;
    const tagMatch =
      selectedTag === 'All' ||
      product.tags.includes(selectedTag === 'Featured' ? 'featured' : 'new');
    return ageMatch && categoryMatch && tagMatch;
  });

  return (
    <>
      <Helmet>
        <title>Joyful Toys Collection | Explore Playful Products</title>
        <meta
          name="description"
          content="Browse Joyful Toys’ curated collection of creative, educational, and sustainable toys for every age group. Discover sensory, STEM, and imaginative play favourites."
        />
      </Helmet>

      <section className={styles.hero}>
        <div>
          <span className="badge">The Joyful Collection</span>
          <h1>Playful treasures for every milestone</h1>
          <p>
            Explore a curated catalogue of toys shaped by child development experts, educators, and
            the Joyful Toys family community.
          </p>
        </div>
        <img
          src="https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1200&q=80"
          alt="Selection of colourful children toys displayed on a table"
        />
      </section>

      <section className={styles.controlsSection}>
        <h2>Refine your search</h2>
        <div className={styles.filters}>
          <div className={styles.field}>
            <label htmlFor="filter-age">Age range</label>
            <select
              id="filter-age"
              value={selectedAge}
              onChange={(event) => setSelectedAge(event.target.value)}
            >
              {ageOptions.map((option) => (
                <option key={option}>{option}</option>
              ))}
            </select>
          </div>
          <div className={styles.field}>
            <label htmlFor="filter-category">Category</label>
            <select
              id="filter-category"
              value={selectedCategory}
              onChange={(event) => setSelectedCategory(event.target.value)}
            >
              {categoryOptions.map((option) => (
                <option key={option}>{option}</option>
              ))}
            </select>
          </div>
          <div className={styles.field}>
            <label htmlFor="filter-tag">Spotlight</label>
            <select
              id="filter-tag"
              value={selectedTag}
              onChange={(event) => setSelectedTag(event.target.value)}
            >
              <option value="All">All</option>
              <option value="Featured">Featured</option>
              <option value="New">New</option>
            </select>
          </div>
        </div>
      </section>

      <section className={styles.productsSection}>
        <div className={styles.productsHeader}>
          <h2>Discover {filteredProducts.length} joyful toys</h2>
          <p>
            Each product combines thoughtful materials with joyful storytelling, helping children
            build confidence, creativity, and connection.
          </p>
        </div>

        <div className={styles.grid}>
          {filteredProducts.map((product) => (
            <article key={product.id} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={product.image} alt={product.name} />
                <div className={styles.badges}>
                  <span className="badge">{product.ageRange}</span>
                  <span className={styles.category}>{product.category}</span>
                </div>
              </div>
              <div className={styles.content}>
                <h3>{product.name}</h3>
                <p>{product.description}</p>
                <ul>
                  {product.highlights.map((highlight) => (
                    <li key={highlight}>{highlight}</li>
                  ))}
                </ul>
                <div className={styles.tags}>
                  {product.tags.includes('featured') && <span>⭐ Featured</span>}
                  {product.tags.includes('new') && <span>🆕 New Arrival</span>}
                  {product.tags.includes('bestseller') && <span>💙 Community Favourite</span>}
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default ProductsPage;