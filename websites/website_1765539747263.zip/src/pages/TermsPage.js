import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './TermsPage.module.css';

const TermsPage = () => (
  <>
    <Helmet>
      <title>Terms of Service | Joyful Toys</title>
      <meta
        name="description"
        content="Review the Joyful Toys Terms of Service covering website use, intellectual property, and customer responsibilities."
      />
    </Helmet>

    <section className={styles.page}>
      <div className={styles.card}>
        <h1>Terms of Service</h1>
        <p>
          Welcome to Joyful Toys. These Terms of Service describe the rules and conditions that
          govern your access to and use of our website and services. By visiting our site, you
          indicate that you accept these terms and agree to abide by them.
        </p>

        <h2>1. Website usage</h2>
        <p>
          Joyful Toys provides digital content for informational purposes and to support your toy
          discovery journey. You agree not to misuse the site, attempt unauthorised access, or
          interfere with website functionality.
        </p>

        <h2>2. Intellectual property</h2>
        <p>
          All content, including copy, imagery, branding, and design elements, is owned or licensed
          by Joyful Toys. You may not reproduce, distribute, or create derivative works without our
          written permission.
        </p>

        <h2>3. Product information</h2>
        <p>
          We do our best to present accurate product descriptions, images, and availability. However,
          toy specifications may evolve. If you notice a discrepancy, please contact us so we can
          address it promptly.
        </p>

        <h2>4. Third-party links</h2>
        <p>
          Our website may include links to third-party resources. Joyful Toys is not responsible for
          the content or privacy practices of these external sites. Visiting them is at your own
          discretion.
        </p>

        <h2>5. Limitation of liability</h2>
        <p>
          Joyful Toys is not liable for indirect or consequential damages that may arise from the use
          of our website or content. We encourage safe play practices and adult supervision where
          appropriate.
        </p>

        <h2>6. Changes to the terms</h2>
        <p>
          We may revise these terms to reflect updates to our services or legal requirements.
          Continued use of the website after changes take effect constitutes acceptance of the
          revised terms.
        </p>

        <h2>7. Contact</h2>
        <p>
          If you have questions about these Terms of Service, please reach out via our contact form.
        </p>
      </div>
    </section>
  </>
);

export default TermsPage;