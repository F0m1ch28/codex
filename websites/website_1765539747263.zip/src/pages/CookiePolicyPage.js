import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Joyful Toys</title>
      <meta
        name="description"
        content="Learn how Joyful Toys uses cookies to enhance your browsing experience and personalise content."
      />
    </Helmet>

    <section className={styles.page}>
      <div className={styles.card}>
        <h1>Cookie Policy</h1>
        <p>
          This Cookie Policy explains how Joyful Toys uses cookies and similar technologies to
          provide, improve, and protect our services. By continuing to browse, you consent to our use
          of cookies in accordance with this policy.
        </p>

        <h2>1. What are cookies?</h2>
        <p>
          Cookies are small text files stored on your device when you visit a website. They allow the
          site to recognise your device and remember your preferences to improve usability.
        </p>

        <h2>2. Types of cookies we use</h2>
        <ul>
          <li>
            <strong>Essential cookies:</strong> Required for core website functionality such as page
            navigation.
          </li>
          <li>
            <strong>Performance cookies:</strong> Help us understand how visitors interact with our
            site via anonymised analytics.
          </li>
          <li>
            <strong>Functionality cookies:</strong> Remember choices such as preferred categories or
            accessibility settings.
          </li>
        </ul>

        <h2>3. Managing cookies</h2>
        <p>
          You can manage cookie settings through your browser preferences. Disabling cookies may
          affect some features. Our cookie banner allows you to accept or decline non-essential
          cookies.
        </p>

        <h2>4. Updates to this policy</h2>
        <p>
          Joyful Toys may update this policy to reflect changes in technology or regulation. Any
          updates will be posted on this page with an updated effective date.
        </p>

        <h2>5. Contact</h2>
        <p>If you have questions about our cookie usage, please reach out via the contact form.</p>
      </div>
    </section>
  </>
);

export default CookiePolicyPage;