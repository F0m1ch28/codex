document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('.nav-toggle');
    var siteNav = document.getElementById('primary-navigation');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            var expanded = this.getAttribute('aria-expanded') === 'true' || false;
            this.setAttribute('aria-expanded', String(!expanded));
            siteNav.classList.toggle('active');
        });

        var navLinks = siteNav.querySelectorAll('a');
        navLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.innerWidth < 768) {
                    siteNav.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    var yearSpan = document.getElementById('year');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    var cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        var storedConsent = localStorage.getItem('cookieConsent');
        if (storedConsent) {
            cookieBanner.classList.add('is-hidden');
        }

        var cookieButtons = cookieBanner.querySelectorAll('.cookie-btn');
        cookieButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                var action = button.getAttribute('data-cookie-action');
                localStorage.setItem('cookieConsent', action);
                cookieBanner.classList.add('is-hidden');
            });
        });
    }
});