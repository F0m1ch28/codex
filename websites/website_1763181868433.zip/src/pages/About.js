import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

function About() {
  return (
    <>
      <Helmet>
        <title>About TechSolutions | Cloud Strategy & Digital Transformation Experts</title>
        <meta
          name="description"
          content="Learn about TechSolutions, our mission, leadership team, and approach to guiding enterprises through cloud strategy, modern engineering, and digital transformation."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="layout">
          <h1>We design and deliver the cloud strategies that power modern business.</h1>
          <p>
            TechSolutions is an IT consulting firm headquartered in San Francisco, dedicated to helping enterprises harness cloud technologies, accelerate innovation, and create resilient customer experiences.
          </p>
        </div>
      </section>

      <section className={styles.story}>
        <div className="layout">
          <div className={styles.storyGrid}>
            <div>
              <h2>Our mission</h2>
              <p>
                We exist to empower organizations to innovate faster, scale smarter, and operate securely in the cloud. With a team of seasoned architects, engineers, and change leaders, we bridge technology and people to deliver meaningful business transformation.
              </p>
            </div>
            <div>
              <h2>How we work</h2>
              <p>
                Our engagements are built on partnership, transparency, and measurable outcomes. We co-create solutions with your teams, align to your strategic goals, and ensure the right capabilities are in place so transformations endure long after implementation.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="layout">
          <div className={styles.sectionHeader}>
            <h2>Guiding principles</h2>
            <p>
              These values shape our culture, inform our decisions, and ensure we deliver excellence at every stage.
            </p>
          </div>
          <div className={styles.valuesGrid}>
            <article>
              <h3>Integrity</h3>
              <p>
                We uphold honesty and accountability—always recommending solutions that are right for your business, not just the latest trend.
              </p>
            </article>
            <article>
              <h3>Curiosity</h3>
              <p>
                We stay ahead of emerging technologies and industry shifts, bringing fresh ideas and continuous learning to every engagement.
              </p>
            </article>
            <article>
              <h3>Collaboration</h3>
              <p>
                We believe in shared success. Our multidisciplinary teams work seamlessly with your stakeholders to drive aligned outcomes.
              </p>
            </article>
            <article>
              <h3>Impact</h3>
              <p>
                We measure our effectiveness by the tangible value we deliver. Every initiative is tied to strategic metrics that matter.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="layout">
          <div className={styles.sectionHeader}>
            <h2>Leadership team</h2>
            <p>
              Our leaders bring decades of experience guiding enterprise transformations across technology, finance, healthcare, and retail sectors.
            </p>
          </div>
          <div className={styles.teamGrid}>
            <article className={styles.member}>
              <img
                src="https://picsum.photos/seed/leader1/420/420"
                alt="Portrait of Emma Clarke, CEO TechSolutions"
              />
              <h3>Emma Clarke</h3>
              <p className={styles.role}>Chief Executive Officer</p>
              <p>
                Emma leads the strategic vision of TechSolutions, bringing 20 years of experience in enterprise cloud adoption and organizational change leadership.
              </p>
            </article>
            <article className={styles.member}>
              <img
                src="https://picsum.photos/seed/leader2/420/420"
                alt="Portrait of Daniel Reed, CTO TechSolutions"
              />
              <h3>Daniel Reed</h3>
              <p className={styles.role}>Chief Technology Officer</p>
              <p>
                Daniel architects complex multi-cloud solutions and oversees our engineering practices, ensuring every solution is secure, scalable, and future-ready.
              </p>
            </article>
            <article className={styles.member}>
              <img
                src="https://picsum.photos/seed/leader3/420/420"
                alt="Portrait of Priya Patel, VP of Client Services TechSolutions"
              />
              <h3>Priya Patel</h3>
              <p className={styles.role}>VP, Client Services</p>
              <p>
                Priya is responsible for client delivery excellence, aligning cross-functional teams to meet strategic goals and foster long-term partnerships.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
}

export default About;