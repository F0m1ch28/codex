document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector("[data-nav-toggle]");
    const navLinks = document.querySelector("[data-nav-links]");
    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navLinks.classList.toggle("active");
        });
        navLinks.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 768 && navLinks.classList.contains("active")) {
                    navLinks.classList.remove("active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.querySelector("[data-cookie-banner]");
    const cookieButtons = document.querySelectorAll("[data-consent]");
    const consentKey = "nobleWTcookieConsent";
    if (cookieBanner) {
        const existingConsent = localStorage.getItem(consentKey);
        if (!existingConsent) {
            setTimeout(() => cookieBanner.classList.add("show"), 600);
        }
        cookieButtons.forEach(button => {
            button.addEventListener("click", () => {
                const decision = button.getAttribute("data-consent");
                localStorage.setItem(consentKey, decision || "dismissed");
                cookieBanner.classList.remove("show");
            });
        });
    }
});