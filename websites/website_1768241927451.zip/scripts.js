(function () {
    document.addEventListener('DOMContentLoaded', function () {
        const navToggle = document.querySelector('.nav-toggle');
        const navigation = document.querySelector('.main-navigation');

        if (navToggle && navigation) {
            navToggle.addEventListener('click', function () {
                const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
                navToggle.setAttribute('aria-expanded', String(!isExpanded));
                navigation.classList.toggle('is-open');
            });
        }

        const cookieBanner = document.querySelector('.cookie-banner');
        if (cookieBanner) {
            const storedChoice = localStorage.getItem('practilnakCookie');
            if (storedChoice) {
                cookieBanner.classList.add('hidden');
            }
            cookieBanner.querySelectorAll('[data-cookie-choice]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const choice = button.getAttribute('data-cookie-choice');
                    localStorage.setItem('practilnakCookie', choice || 'undecided');
                    cookieBanner.classList.add('hidden');
                });
            });
        }

        const filterButtons = document.querySelectorAll('[data-filter]');
        const destinationCards = document.querySelectorAll('[data-category]');
        if (filterButtons.length && destinationCards.length) {
            filterButtons.forEach(function (button) {
                button.addEventListener('click', function () {
                    const value = button.getAttribute('data-filter');
                    filterButtons.forEach(function (btn) {
                        btn.classList.toggle('is-active', btn === button);
                    });
                    destinationCards.forEach(function (card) {
                        const categoryValue = card.getAttribute('data-category') || '';
                        const categories = categoryValue.split(' ');
                        const shouldShow = value === 'all' || categories.includes(value);
                        card.style.display = shouldShow ? '' : 'none';
                    });
                });
            });
        }

        const carousels = document.querySelectorAll('[data-carousel]');
        if (carousels.length) {
            carousels.forEach(function (carousel) {
                const slides = carousel.querySelectorAll('.carousel-slide');
                let index = 0;
                function updateSlides() {
                    slides.forEach(function (slide, slideIndex) {
                        slide.classList.toggle('is-active', slideIndex === index);
                    });
                }
                updateSlides();
                const prevButton = carousel.querySelector('[data-carousel-prev]');
                const nextButton = carousel.querySelector('[data-carousel-next]');
                if (prevButton) {
                    prevButton.addEventListener('click', function () {
                        index = (index - 1 + slides.length) % slides.length;
                        updateSlides();
                    });
                }
                if (nextButton) {
                    nextButton.addEventListener('click', function () {
                        index = (index + 1) % slides.length;
                        updateSlides();
                    });
                }
            });
        }

        const tipTabs = document.querySelectorAll('[data-tips-tab]');
        const tipPanels = document.querySelectorAll('[data-tips-panel]');
        if (tipTabs.length && tipPanels.length) {
            tipTabs.forEach(function (tab) {
                tab.addEventListener('click', function () {
                    const target = tab.getAttribute('data-tips-tab');
                    tipTabs.forEach(function (btn) {
                        btn.classList.toggle('is-active', btn === tab);
                    });
                    tipPanels.forEach(function (panel) {
                        panel.classList.toggle('is-active', panel.getAttribute('data-tips-panel') === target);
                    });
                });
            });
        }
    });
})();