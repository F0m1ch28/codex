document.addEventListener("DOMContentLoaded", function () {
    const banner = document.getElementById("cookieBanner");
    const acceptBtn = document.getElementById("cookieAccept");
    const declineBtn = document.getElementById("cookieDecline");
    const consentKey = "cachedkug_cookie_consent";

    if (!banner || !acceptBtn || !declineBtn) {
        return;
    }

    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
        banner.classList.add("active");
    }

    function handleConsent(value) {
        localStorage.setItem(consentKey, value);
        banner.classList.remove("active");
    }

    acceptBtn.addEventListener("click", () => handleConsent("accepted"));
    declineBtn.addEventListener("click", () => handleConsent("declined"));
});