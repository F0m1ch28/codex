import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`${styles.footerInner} container`}>
      <div className={styles.brandBlock}>
        <div className={styles.logo}>ArtVista</div>
        <p className={styles.tagline}>
          Творческая студия визуального искусства и дизайна полного цикла.
        </p>
        <div className={styles.contact}>
          <a href="tel:+74951234567">+7 (495) 123-45-67</a>
          <a href="mailto:hello@artstudio.ru">hello@artstudio.ru</a>
          <address className={styles.address}>
            ул. Творческая, 15, Москва, Россия
          </address>
        </div>
      </div>
      <div className={styles.linksBlock}>
        <h3>Навигация</h3>
        <ul>
          <li>
            <NavLink to="/services">Услуги</NavLink>
          </li>
          <li>
            <NavLink to="/portfolio">Портфолио</NavLink>
          </li>
          <li>
            <NavLink to="/blog">Блог</NavLink>
          </li>
          <li>
            <NavLink to="/about">О студии</NavLink>
          </li>
          <li>
            <NavLink to="/contact">Контакты</NavLink>
          </li>
        </ul>
      </div>
      <div className={styles.linksBlock}>
        <h3>Юридическая информация</h3>
        <ul>
          <li>
            <NavLink to="/privacy">Политика конфиденциальности</NavLink>
          </li>
          <li>
            <NavLink to="/terms">Условия использования</NavLink>
          </li>
          <li>
            <NavLink to="/cookie-policy">Политика Cookie</NavLink>
          </li>
        </ul>
      </div>
    </div>
    <div className={styles.footerBottom}>
      <div className="container">
        <p>© {new Date().getFullYear()} ArtVista. Все права защищены.</p>
      </div>
    </div>
  </footer>
);

export default Footer;