import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Projects.module.css";

const projectCategories = ["All", "Upstream", "Midstream", "Industrial", "Renewable"];

const projectDetails = [
  {
    title: "Arctic Modular Platform",
    category: "Upstream",
    description:
      "Produced modular platform designed for permafrost conditions with thermal protection, redundant power distribution, and ice-resistant load-bearing elements.",
    image: "https://picsum.photos/1200/700?random=901",
    alt: "Modular platform with cranes operating in Arctic environment",
    highlights: [
      "Thermal modelling for sub-zero operations",
      "Integrated crane logistics with heated staging yards",
      "Safety management system tailored to remote crews",
    ],
  },
  {
    title: "Pipeline Control Modernization",
    category: "Midstream",
    description:
      "Retrofit of control systems for a provincial pipeline network, combining SCADA upgrades, cybersecurity hardening, and predictive analytics for anomaly detection.",
    image: "https://picsum.photos/1200/700?random=902",
    alt: "Pipeline control room with engineers monitoring systems",
    highlights: [
      "Digital twin deployment for operational insights",
      "Coordinated cutover with zero downtime events",
      "Cross-provincial regulatory reporting alignment",
    ],
  },
  {
    title: "High-Capacity Crane Program",
    category: "Industrial",
    description:
      "Heavy lift coordination for a coastal LNG facility involving synchronized cranes, marine deliveries, and compact site logistics.",
    image: "https://picsum.photos/1200/700?random=903",
    alt: "Cranes performing heavy lift operations near water",
    highlights: [
      "Engineered lift studies and load path analysis",
      "Marine, rail, and road logistics integration",
      "Onsite supervision and safety leadership",
    ],
  },
  {
    title: "Hybrid Microgrid Integration",
    category: "Renewable",
    description:
      "Hybrid renewable integration for northern communities blending solar, wind, and diesel backup with smart storage.",
    image: "https://picsum.photos/1200/700?random=904",
    alt: "Renewable energy microgrid with wind turbines and solar panels",
    highlights: [
      "Microgrid control strategy with adaptive storage",
      "Community engagement and training programs",
      "Emissions monitoring and reporting dashboards",
    ],
  },
  {
    title: "Refinery Turnaround Support",
    category: "Industrial",
    description:
      "Comprehensive turnaround planning including crane routing, scaffolding coordination, and QA/QC oversight for critical path activities.",
    image: "https://picsum.photos/1200/700?random=905",
    alt: "Industrial refinery with scaffolding and cranes",
    highlights: [
      "Integrated schedule management with contractors",
      "Real-time risk monitoring tools for field teams",
      "Post-turnaround performance validation",
    ],
  },
];

const Projects = () => {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredProjects =
    activeCategory === "All"
      ? projectDetails
      : projectDetails.filter((project) => project.category === activeCategory);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Projects | Aurion Energy Advisory</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Projects delivered with precision</h1>
          <p>
            Explore a selection of projects where Aurion Energy Advisory combined consulting, engineering, and field leadership to deliver measurable results across Canada.
          </p>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.filterBar} role="tablist" aria-label="Project categories">
            {projectCategories.map((category) => (
              <button
                key={category}
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.active : ""
                }`}
                onClick={() => setActiveCategory(category)}
                role="tab"
                aria-selected={activeCategory === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.grid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.card}>
                <div className={styles.imageWrap}>
                  <img src={project.image} alt={project.alt} loading="lazy" />
                </div>
                <div className={styles.content}>
                  <span className={styles.category}>{project.category}</span>
                  <h2>{project.title}</h2>
                  <p>{project.description}</p>
                  <ul>
                    {project.highlights.map((highlight) => (
                      <li key={highlight}>{highlight}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Projects;