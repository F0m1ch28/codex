import React, { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const statsData = [
  { label: "Major Deployments", value: 68 },
  { label: "Field Specialists", value: 45 },
  { label: "Renewable Integrations", value: 23 },
  { label: "Incident-Free Years", value: 12 },
];

const services = [
  {
    title: "Energy Consulting",
    description:
      "Strategic analysis, regulatory navigation, and scenario planning to inform resilient energy portfolios.",
    icon: "🧭",
  },
  {
    title: "Oilfield Research",
    description:
      "Subsurface evaluations, compliance documentation, and production forecasting tailored to Canadian basins.",
    icon: "🛢️",
  },
  {
    title: "Engineering Solutions",
    description:
      "Crane coordination, modular installations, and commissioning support for complex infrastructure.",
    icon: "🏗️",
  },
];

const processSteps = [
  {
    step: "01",
    title: "Discovery & Alignment",
    text: "We collaborate with multidisciplinary stakeholders to define the technical and operational objectives.",
  },
  {
    step: "02",
    title: "Field Intelligence",
    text: "Our research teams collect and synthesize data sets that guide safe deployment in demanding environments.",
  },
  {
    step: "03",
    title: "Design & Simulation",
    text: "Engineers model scenarios, refine logistics plans, and validate performance before onsite execution.",
  },
  {
    step: "04",
    title: "Execution & Assurance",
    text: "Integrated oversight ensures standards are met, documentation is complete, and teams stay aligned.",
  },
];

const testimonials = [
  {
    quote:
      "Aurion mapped a clear route through a challenging regulatory landscape and orchestrated a flawless commissioning phase.",
    name: "Lina Karev",
    role: "Director of Operations, Northern Grid Co.",
  },
  {
    quote:
      "Their oilfield research team unearthed insights that compressed our timeline while strengthening environmental stewardship.",
    name: "Marcus Doyle",
    role: "VP Exploration, Canyon Horizons",
  },
  {
    quote:
      "With Aurion, we had precise crane logistics, disciplined safety protocols, and responsive communication at every milestone.",
    name: "Isabella Chen",
    role: "Project Executive, Harborline Resources",
  },
];

const projectsGallery = [
  {
    id: 1,
    category: "Upstream",
    title: "Arctic Modular Platform",
    description: "Rapid-response modular platform engineered for Arctic permafrost with heated transport corridors.",
    image: "https://picsum.photos/1200/800?random=401",
    alt: "Modular Arctic energy platform with cranes operating at twilight",
  },
  {
    id: 2,
    category: "Midstream",
    title: "Pipeline Control Modernization",
    description: "Supervisory control retrofit integrating predictive analytics for Alberta midstream network.",
    image: "https://picsum.photos/1200/800?random=402",
    alt: "Control room with engineers managing pipeline operations",
  },
  {
    id: 3,
    category: "Industrial",
    title: "High-Capacity Crane Program",
    description: "Coordinated crane lifts and heavy haul logistics for coastal LNG facility modules.",
    image: "https://picsum.photos/1200/800?random=403",
    alt: "Industrial cranes lifting large modules at a coastal facility",
  },
  {
    id: 4,
    category: "Renewable",
    title: "Hybrid Microgrid Integration",
    description: "Wind and solar blended with diesel backup using adaptive storage strategies for remote communities.",
    image: "https://picsum.photos/1200/800?random=404",
    alt: "Hybrid microgrid site with wind turbines and solar panels",
  },
];

const faqItems = [
  {
    question: "How do you ensure regulatory compliance across provinces?",
    answer:
      "Our regulatory advisors maintain active relationships with federal and provincial agencies, align project documentation with current standards, and build compliance checkpoints into every project stage.",
  },
  {
    question: "What distinguishes your crane and logistics support?",
    answer:
      "We coordinate end-to-end crane and lifting operations with precise sequencing, engineering review, and onsite supervision to safeguard people and equipment.",
  },
  {
    question: "Do you support sustainability reporting?",
    answer:
      "Yes. Our sustainability team captures data for carbon accounting, ESG narratives, and performance dashboards aligned with recognized disclosure frameworks.",
  },
  {
    question: "Can Aurion integrate with in-house project teams?",
    answer:
      "We tailor collaboration models to each client, embedding specialists alongside internal leads or providing independent oversight with structured reporting.",
  },
];

const blogPosts = [
  {
    title: "Adaptive Energy Planning for Northern Sites",
    date: "February 12, 2024",
    excerpt:
      "How layered scenario planning and weatherized engineering keep large-scale projects moving through Canadian winters.",
    link: "/services",
  },
  {
    title: "Crane Fleet Synchronization in Coastal Facilities",
    date: "January 24, 2024",
    excerpt:
      "A look at crane choreography, digital twins, and permitting disciplines that de-risk heavy lifts.",
    link: "/projects",
  },
  {
    title: "Embedding Sustainability in Brownfield Upgrades",
    date: "December 14, 2023",
    excerpt:
      "Strategies for combining refurbishment with emissions reduction, stakeholder engagement, and transparent reporting.",
    link: "/about",
  },
];

const Home = () => {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [filter, setFilter] = useState("All");
  const filteredProjects = useMemo(() => {
    if (filter === "All") return projectsGallery;
    return projectsGallery.filter((project) => project.category === filter);
  }, [filter]);

  useEffect(() => {
    const observers = counters.map((_, index) => ({
      targetValue: statsData[index].value,
      currentValue: 0,
    }));

    const interval = setInterval(() => {
      setCounters((prev) =>
        prev.map((value, index) => {
          if (value >= observers[index].targetValue) {
            return observers[index].targetValue;
          }
          return value + Math.ceil(observers[index].targetValue / 40);
        })
      );
    }, 80);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const slider = setInterval(() => {
      setActiveTestimonial((prev) =>
        prev === testimonials.length - 1 ? 0 : prev + 1
      );
    }, 6000);
    return () => clearInterval(slider);
  }, []);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Aurion Energy Advisory | Engineering the Future of Energy</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <p className={styles.heroEyebrow}>Engineering the Future of Energy</p>
            <h1 className={styles.heroTitle}>
              Precision consulting and engineering to power complex energy transformations.
            </h1>
            <p className={styles.heroSubtitle}>
              Aurion Energy Advisory partners with operators, utilities, and infrastructure developers to plan, design, and deliver projects that balance performance, safety, and sustainability.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contact" className={styles.primaryButton}>
                Partner with Aurion
              </Link>
              <Link to="/projects" className={styles.secondaryButton}>
                View Recent Projects
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>{counters[index]}+</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.intro}>
        <div className="container">
          <div className={styles.introGrid}>
            <div>
              <h2 className="section-title">Aurion Energy Advisory</h2>
              <p>
                From exploration planning to crane-lift commissioning, Aurion Energy Advisory delivers integrated consulting and engineering services across the Canadian energy landscape. We pair high-calibre technical teams with frontline experience to guide projects through every milestone.
              </p>
            </div>
            <div>
              <p>
                Our multidisciplinary practice covers upstream, midstream, industrial, and renewable initiatives. We navigate regulatory frameworks, optimize field logistics, and embed sustainability measurements while keeping safety as a core value.
              </p>
              <Link to="/about" className={styles.linkArrow}>
                Learn about our approach
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <p className={styles.sectionEyebrow}>Our Expertise</p>
              <h2 className="section-title">Strategic insight and hands-on engineering</h2>
            </div>
            <p>
              Aurion specialists support feasibility studies, field research, engineered installations, and environmental stewardship, ensuring every project delivers lasting value to stakeholders and communities.
            </p>
          </div>
          <div className={styles.serviceCards}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className={styles.linkArrow}>
                  Explore service details
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.oilfield}>
        <div className="container">
          <div className={styles.oilfieldGrid}>
            <div className={styles.oilfieldImageWrap}>
              <img
                src="https://picsum.photos/800/600?random=502"
                alt="Engineers evaluating oilfield data on digital displays"
                loading="lazy"
              />
            </div>
            <div className={styles.oilfieldContent}>
              <h2 className="section-title">Oilfield Research & Compliance</h2>
              <p>
                Our research teams execute in-depth reservoir analysis, seismic interpretation, and operational benchmarking specific to Canadian formations. Deliverables include compliance-ready documentation and clear action plans for investment committees.
              </p>
              <ul className={styles.list}>
                <li>Reservoir modelling and decline-curve assessments</li>
                <li>Environmental and social impact documentation</li>
                <li>Stakeholder alignment across provincial authorities</li>
              </ul>
              <Link to="/services" className={styles.primaryButtonAlt}>
                See research services
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.engineering}>
        <div className="container">
          <div className={styles.engineeringHeader}>
            <h2 className="section-title">Engineering Solutions & Crane Logistics</h2>
            <p>
              Precise lifting strategies, equipment sequencing, and execution oversight give your project the stability it requires. Aurion provides engineered lift plans, certified supervision, and integrated logistics across rail, marine, and road corridors.
            </p>
          </div>
          <div className={styles.engineeringImageWrap}>
            <img
              src="https://picsum.photos/1200/700?random=503"
              alt="Cranes managing heavy lift operations at an industrial site"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <p className={styles.sectionEyebrow}>Process</p>
          <h2 className="section-title">A structured path from concept to execution</h2>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <div key={step.step} className={styles.processCard}>
                <span className={styles.processStep}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <p className={styles.sectionEyebrow}>Projects</p>
              <h2 className="section-title">Field-proven delivery across disciplines</h2>
            </div>
            <p>
              Explore a selection of our projects spanning upstream development, midstream optimization, industrial integration, and renewable systems. Each engagement reflects Aurion’s commitment to precision, collaboration, and measurable outcomes.
            </p>
          </div>
          <div className={styles.filterBar} role="tablist" aria-label="Project categories">
            {["All", "Upstream", "Midstream", "Industrial", "Renewable"].map((category) => (
              <button
                key={category}
                className={`${styles.filterButton} ${
                  filter === category ? styles.filterActive : ""
                }`}
                onClick={() => setFilter(category)}
                role="tab"
                aria-selected={filter === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img src={project.image} alt={project.alt} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/projects" className={styles.linkArrow}>
                    Discover more projects
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.testimonialHeader}>
            <p className={styles.sectionEyebrow}>Testimonials</p>
            <h2 className="section-title">Voices from our partners</h2>
          </div>
          <div className={styles.testimonialSlider}>
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.activeSlide : styles.inactiveSlide
                }`}
              >
                <p className={styles.quote}>&ldquo;{testimonial.quote}&rdquo;</p>
                <div className={styles.person}>
                  <span className={styles.personName}>{testimonial.name}</span>
                  <span className={styles.personRole}>{testimonial.role}</span>
                </div>
              </div>
            ))}
          </div>
          <div className={styles.sliderControls} role="group" aria-label="Testimonial controls">
            <button
              onClick={() =>
                setActiveTestimonial((prev) =>
                  prev === 0 ? testimonials.length - 1 : prev - 1
                )
              }
              className={styles.sliderButton}
              aria-label="Previous testimonial"
            >
              ←
            </button>
            <button
              onClick={() =>
                setActiveTestimonial((prev) =>
                  prev === testimonials.length - 1 ? 0 : prev + 1
                )
              }
              className={styles.sliderButton}
              aria-label="Next testimonial"
            >
              →
            </button>
          </div>
        </div>
      </section>

      <section className={styles.sustainability}>
        <div className="container">
          <div className={styles.sustainabilityGrid}>
            <div className={styles.sustainabilityContent}>
              <p className={styles.sectionEyebrow}>Sustainability</p>
              <h2 className="section-title">Green innovation, measured impact</h2>
              <p>
                Aurion helps clients align decarbonization pathways with industrial reliability. We build emissions inventories, develop transition roadmaps, and integrate low-carbon technologies while balancing cost, schedule, and performance.
              </p>
              <ul className={styles.list}>
                <li>Lifecycle carbon assessments and reduction roadmaps</li>
                <li>Hybrid microgrid and storage integration strategies</li>
                <li>Transparent ESG reporting and stakeholder engagement</li>
              </ul>
            </div>
            <div className={styles.sustainabilityImageWrap}>
              <img
                src="https://picsum.photos/900/700?random=504"
                alt="Technicians monitoring renewable energy infrastructure"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.faqHeader}>
            <p className={styles.sectionEyebrow}>FAQ</p>
            <h2 className="section-title">Frequently asked questions</h2>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>
                  <span>{item.question}</span>
                  <span aria-hidden="true">{index % 2 === 0 ? "+" : "−"}</span>
                </summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <p className={styles.sectionEyebrow}>Insights</p>
              <h2 className="section-title">Latest perspectives</h2>
            </div>
            <p>
              Stay updated with insights from our consultants and engineers as they explore emerging trends, field innovations, and strategic thinking for the Canadian energy sector.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.linkArrow}>
                  Continue reading
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Ready to accelerate your next energy initiative?</h2>
            <p>
              Connect with Aurion Energy Advisory to align strategy, engineering, and execution for your upcoming project. Our teams are prepared to meet you onsite or virtually.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/contact" className={styles.primaryButton}>
                Schedule a consultation
              </Link>
              <Link to="/team" className={styles.secondaryButton}>
                Meet our experts
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;