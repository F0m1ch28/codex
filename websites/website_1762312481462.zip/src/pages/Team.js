import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Team.module.css";

const teamMembers = [
  {
    name: "Olivia Hart",
    role: "Chief Executive Officer",
    bio: "Leads strategic direction, stakeholder engagement, and long-term partnerships across the energy sector.",
    image: "https://picsum.photos/400/400?random=1001",
    alt: "Portrait of Olivia Hart",
  },
  {
    name: "Daniel Moreau",
    role: "Chief Engineer",
    bio: "Oversees engineering disciplines and ensures designs translate into resilient field execution.",
    image: "https://picsum.photos/400/400?random=1002",
    alt: "Portrait of Daniel Moreau",
  },
  {
    name: "Maya Desjardins",
    role: "Director of Sustainability",
    bio: "Guides ESG strategy, environmental assessments, and community engagement programs.",
    image: "https://picsum.photos/400/400?random=1003",
    alt: "Portrait of Maya Desjardins",
  },
  {
    name: "Avery Singh",
    role: "Principal Consultant, Energy Strategy",
    bio: "Specializes in market analysis, scenario planning, and regulatory navigation across provinces.",
    image: "https://picsum.photos/400/400?random=1004",
    alt: "Portrait of Avery Singh",
  },
  {
    name: "Declan Wright",
    role: "Director, Field Operations",
    bio: "Leads crane logistics, heavy lift execution, and site commissioning with a safety-first approach.",
    image: "https://picsum.photos/400/400?random=1005",
    alt: "Portrait of Declan Wright",
  },
  {
    name: "Chantal Roy",
    role: "Lead Geoscientist",
    bio: "Delivers subsurface interpretation, basin analysis, and exploration planning insights.",
    image: "https://picsum.photos/400/400?random=1006",
    alt: "Portrait of Chantal Roy",
  },
  {
    name: "Ethan Park",
    role: "Project Controls Manager",
    bio: "Integrates scheduling, cost tracking, and risk analytics to maintain project alignment.",
    image: "https://picsum.photos/400/400?random=1007",
    alt: "Portrait of Ethan Park",
  },
  {
    name: "Sofia Martinez",
    role: "Environmental Compliance Lead",
    bio: "Coordinates environmental assessments, monitoring programs, and reporting frameworks.",
    image: "https://picsum.photos/400/400?random=1008",
    alt: "Portrait of Sofia Martinez",
  },
];

const Team = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Team | Aurion Energy Advisory</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Meet the Aurion team</h1>
          <p>
            Our consultants, engineers, and field leaders share a commitment to precision, safety, and sustainable energy development.
          </p>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.grid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.card}>
                <div className={styles.imageWrap}>
                  <img src={member.image} alt={member.alt} loading="lazy" />
                </div>
                <div className={styles.info}>
                  <h2>{member.name}</h2>
                  <span className={styles.role}>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Team;