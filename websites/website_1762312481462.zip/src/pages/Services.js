import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const serviceList = [
  {
    title: "Energy Consulting",
    description:
      "Market analysis, energy portfolio planning, and scenario modelling help clients navigate Canada’s evolving energy landscape. Our advisory teams deliver policy insights, grid impact studies, and strategic roadmaps aligned with stakeholder expectations.",
    points: [
      "Resource planning workshops and decision frameworks",
      "Regulatory impact assessments and permit strategies",
      "Operational readiness and change management support",
    ],
    image: "https://picsum.photos/900/600?random=801",
    alt: "Energy consultants reviewing strategy reports in a boardroom",
  },
  {
    title: "Oilfield Research",
    description:
      "We deploy geologists, reservoir engineers, and data scientists to synthesize subsurface data, benchmark analogs, and document compliance. Our deliverables guide safe exploration, production planning, and stakeholder communication.",
    points: [
      "Reservoir characterization and decline analysis",
      "Regulatory submissions and reporting packages",
      "Digital field data acquisition and visualization",
    ],
    image: "https://picsum.photos/900/600?random=802",
    alt: "Oilfield researchers analyzing seismic data on digital screens",
  },
  {
    title: "Installation & Commissioning",
    description:
      "Aurion coordinates complex installations, from crane lifts to instrumentation hook-ups. We integrate engineering review, site supervision, and safety oversight to keep schedules on track.",
    points: [
      "Engineered lift planning and rigging supervision",
      "Mechanical, electrical, and instrumentation commissioning",
      "Quality documentation and turnover packages",
    ],
    image: "https://picsum.photos/900/600?random=803",
    alt: "Industrial crane installation taking place at a facility",
  },
  {
    title: "Environmental Assessment",
    description:
      "Our environmental specialists assess ecological impacts, compile baselines, and develop mitigation measures. We partner with communities and regulators to ensure transparent reporting and monitoring.",
    points: [
      "Baseline studies and habitat evaluations",
      "Impact mitigation and reclamation planning",
      "ESG data management and disclosures",
    ],
    image: "https://picsum.photos/900/600?random=804",
    alt: "Environmental engineers conducting assessment near wetlands",
  },
  {
    title: "Project Management",
    description:
      "Program controls, field coordination, and stakeholder communication keep complex projects aligned. We integrate risk management, budget tracking, and reporting to deliver predictable outcomes.",
    points: [
      "Integrated master schedules and resource allocation",
      "Risk identification and mitigation planning",
      "Stakeholder dashboards and governance support",
    ],
    image: "https://picsum.photos/900/600?random=805",
    alt: "Project managers reviewing logistics plans on a digital screen",
  },
];

const Services = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Services | Aurion Energy Advisory</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Services engineered for energy complexity</h1>
          <p>
            Aurion Energy Advisory combines strategic consulting, technical research, and engineered delivery to support projects across the Canadian energy value chain.
          </p>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          {serviceList.map((service, index) => (
            <article
              key={service.title}
              className={`${styles.service} ${
                index % 2 === 1 ? styles.reverse : ""
              }`}
            >
              <div className={styles.imageWrap}>
                <img src={service.image} alt={service.alt} loading="lazy" />
              </div>
              <div className={styles.content}>
                <h2>{service.title}</h2>
                <p>{service.description}</p>
                <ul>
                  {service.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <h2>Looking for a tailored service package?</h2>
            <p>
              Contact our team to design a program that aligns with your project milestones, safety requirements, and stakeholder commitments.
            </p>
            <a className="button" href="/contact">
              Start the conversation
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;