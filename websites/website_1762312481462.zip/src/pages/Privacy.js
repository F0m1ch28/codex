import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Privacy.module.css";

const Privacy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Privacy Policy | Aurion Energy Advisory</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Privacy Policy</h1>
          <p>Effective date: January 5, 2024</p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <article className={styles.card}>
            <h2>1. Overview</h2>
            <p>
              Aurion Energy Advisory is committed to protecting the privacy of individuals whose personal information we collect. This Privacy Policy explains how we gather, use, disclose, and safeguard personal information.
            </p>

            <h2>2. Information we collect</h2>
            <p>
              We collect personal information that you voluntarily provide, such as your name, email address, phone number, organization, and project details when you submit forms, subscribe to updates, or communicate with us.
            </p>

            <h2>3. Use of information</h2>
            <p>
              We use personal information to respond to inquiries, deliver services, improve our website, and send communications relevant to your requests. We may also analyze aggregated data to enhance user experience.
            </p>

            <h2>4. Sharing of information</h2>
            <p>
              Aurion Energy Advisory does not sell personal information. We may share personal data with trusted service providers who support our operations, provided they adhere to privacy commitments. We may disclose information if required by law.
            </p>

            <h2>5. Data security</h2>
            <p>
              We implement administrative, technical, and physical safeguards to protect personal information against unauthorized access, disclosure, or misuse.
            </p>

            <h2>6. International transfers</h2>
            <p>
              Personal information may be processed outside of your jurisdiction. We ensure that protections consistent with applicable privacy laws are in place for such transfers.
            </p>

            <h2>7. Retention</h2>
            <p>
              We retain personal information only as long as necessary to fulfill the purposes outlined in this policy or as required by law.
            </p>

            <h2>8. Your choices</h2>
            <p>
              You may request access to, correction of, or deletion of your personal information by contacting us. You can also opt out of marketing emails at any time.
            </p>

            <h2>9. Contact</h2>
            <p>
              For privacy inquiries, please email{" "}
              <a href="mailto:privacy@aurionenergyadvisory.com">
                privacy@aurionenergyadvisory.com
              </a>{" "}
              or call +1 (416) 792-4583.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default Privacy;