import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>About Aurion Energy Advisory | Engineering Leadership</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>About Aurion Energy Advisory</h1>
          <p>
            A Canadian consulting and engineering firm bringing clarity, rigor, and safety-first delivery to energy projects for more than a decade.
          </p>
        </div>
      </section>

      <section className={styles.story}>
        <div className="container">
          <div className={styles.storyGrid}>
            <div>
              <h2 className="section-title">Our story</h2>
              <p>
                Aurion Energy Advisory was founded in Toronto in 2011 by field engineers and consultants who shared a vision for energy projects rooted in technical depth and collaborative leadership. From the beginning, Aurion championed the idea that successful energy infrastructure depends on meticulous planning, agile engineering, and uncompromising safety.
              </p>
              <p>
                Today, our team supports operators and developers across Canada, combining research, design, and execution support under one firm. We thrive at the intersection of data, engineering disciplines, and stakeholder engagement.
              </p>
            </div>
            <div className={styles.imageWrap}>
              <img
                src="https://picsum.photos/900/600?random=602"
                alt="Aurion Energy Advisory engineers collaborating in a control room"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div className={styles.missionCard}>
              <h3>Mission</h3>
              <p>
                Empower energy organizations to deliver responsible infrastructure by providing evidence-based consulting, precise engineering, and project leadership that inspires trust.
              </p>
            </div>
            <div className={styles.missionCard}>
              <h3>Values</h3>
              <ul>
                <li>Safety as the non-negotiable foundation</li>
                <li>Integrity in every assessment and recommendation</li>
                <li>Collaboration with clients, communities, and regulators</li>
                <li>Innovation grounded in practical execution</li>
              </ul>
            </div>
            <div className={styles.missionCard}>
              <h3>Safety Culture</h3>
              <p>
                Aurion’s Safety Management System embeds hazard identification, toolbox briefings, and continuous improvement in every project. We champion proactive reporting, close-call learning, and third-party audits to protect people and assets.
              </p>
            </div>
            <div className={styles.missionCard}>
              <h3>Sustainable Development</h3>
              <p>
                Our sustainability specialists integrate environmental stewardship into project designs, lifecycle planning, and supplier engagement. We help clients set actionable emissions targets and track results with transparent reporting.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.leadership}>
        <div className="container">
          <h2 className="section-title">Leadership team</h2>
          <div className={styles.leadershipGrid}>
            <article className={styles.card}>
              <img
                src="https://picsum.photos/400/400?random=701"
                alt="Portrait of Olivia Hart, CEO of Aurion Energy Advisory"
              />
              <div>
                <h3>Olivia Hart</h3>
                <span className={styles.role}>Chief Executive Officer</span>
                <p>
                  Olivia leads Aurion’s strategic direction, drawing on 20 years of experience in energy consulting and change management. She champions integrated project delivery and stakeholder collaboration.
                </p>
              </div>
            </article>
            <article className={styles.card}>
              <img
                src="https://picsum.photos/400/400?random=702"
                alt="Portrait of Daniel Moreau, Chief Engineer of Aurion Energy Advisory"
              />
              <div>
                <h3>Daniel Moreau</h3>
                <span className={styles.role}>Chief Engineer</span>
                <p>
                  Daniel oversees engineering disciplines, including structures, mechanical systems, and advanced simulations. His teams ensure design intent translates into safe, efficient field execution.
                </p>
              </div>
            </article>
            <article className={styles.card}>
              <img
                src="https://picsum.photos/400/400?random=703"
                alt="Portrait of Maya Desjardins, Director of Sustainability at Aurion Energy Advisory"
              />
              <div>
                <h3>Maya Desjardins</h3>
                <span className={styles.role}>Director of Sustainability</span>
                <p>
                  Maya drives Aurion’s environmental initiatives, guiding clients through carbon planning, ESG reporting, and community engagement to build resilient and responsible projects.
                </p>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className="container">
          <h2 className="section-title">Milestones</h2>
          <div className={styles.timelineGrid}>
            <div className={styles.milestone}>
              <span className={styles.year}>2011</span>
              <p>Aurion Energy Advisory is founded in Toronto by a group of engineers and consultants.</p>
            </div>
            <div className={styles.milestone}>
              <span className={styles.year}>2014</span>
              <p>Expanded into oilfield research services with a dedicated reservoir analysis unit.</p>
            </div>
            <div className={styles.milestone}>
              <span className={styles.year}>2017</span>
              <p>Launched crane logistics and heavy lift coordination practice supporting major industrial builds.</p>
            </div>
            <div className={styles.milestone}>
              <span className={styles.year}>2020</span>
              <p>Introduced sustainability advisory and ESG reporting services across client engagements.</p>
            </div>
            <div className={styles.milestone}>
              <span className={styles.year}>2023</span>
              <p>Achieved 12 consecutive years with zero lost-time incidents on managed projects.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;