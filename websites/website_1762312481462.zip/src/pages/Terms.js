import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Terms.module.css";

const Terms = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Terms of Use | Aurion Energy Advisory</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Terms of Use</h1>
          <p>Effective date: January 5, 2024</p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <article className={styles.card}>
            <h2>1. Acceptance of terms</h2>
            <p>
              By accessing or using the Aurion Energy Advisory website, you agree to comply with and be bound by these Terms of Use. If you do not agree with any part of these terms, please discontinue use of this website.
            </p>

            <h2>2. Informational purpose</h2>
            <p>
              The content on this website is provided for general informational purposes. While Aurion Energy Advisory strives for accuracy, the information presented may change without notice and should not be relied upon as professional advice without consultation.
            </p>

            <h2>3. Intellectual property</h2>
            <p>
              All text, graphics, logos, images, and other materials on this site are the property of Aurion Energy Advisory or its licensors and are protected by copyright and trademark laws. You may not reproduce, distribute, or create derivative works without prior written consent.
            </p>

            <h2>4. User conduct</h2>
            <p>
              You agree to use the site only for lawful purposes. You must not attempt to gain unauthorized access to any portion of the site or interfere with its operation.
            </p>

            <h2>5. External links</h2>
            <p>
              This website may contain links to external sites for convenience. Aurion Energy Advisory is not responsible for the content or practices of third-party websites.
            </p>

            <h2>6. Limitation of liability</h2>
            <p>
              Aurion Energy Advisory will not be liable for any direct, indirect, incidental, or consequential damages arising from your use of the site or reliance on its content.
            </p>

            <h2>7. Governing law</h2>
            <p>
              These terms are governed by the laws of the Province of Ontario and the applicable laws of Canada. Any disputes will be resolved in the courts of Ontario.
            </p>

            <h2>8. Updates</h2>
            <p>
              We may update these Terms of Use periodically. Continued use of the site after changes indicates acceptance of the revised terms.
            </p>

            <h2>Contact</h2>
            <p>
              For questions about these Terms of Use, contact us at{" "}
              <a href="mailto:contact@aurionenergyadvisory.com">
                contact@aurionenergyadvisory.com
              </a>{" "}
              or call +1 (416) 792-4583.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default Terms;