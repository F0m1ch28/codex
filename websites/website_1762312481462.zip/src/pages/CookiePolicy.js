import React from "react";
import { Helmet } from "react-helmet";
import styles from "./CookiePolicy.module.css";

const CookiePolicy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Cookie Policy | Aurion Energy Advisory</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Cookie Policy</h1>
          <p>Effective date: January 5, 2024</p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <article className={styles.card}>
            <h2>1. What are cookies?</h2>
            <p>
              Cookies are small text files placed on your device when you visit a website. They help us remember your preferences and understand how the site is being used.
            </p>

            <h2>2. Types of cookies we use</h2>
            <ul>
              <li>
                <strong>Essential cookies:</strong> Required for the website to function, such as enabling navigation and access to secure areas.
              </li>
              <li>
                <strong>Analytics cookies:</strong> Help us understand how visitors interact with the site so we can improve the user experience.
              </li>
            </ul>

            <h2>3. Managing cookies</h2>
            <p>
              You can control cookies through your browser settings. Most browsers allow you to block or delete cookies. Please note that disabling essential cookies may impact site functionality.
            </p>

            <h2>4. Updates</h2>
            <p>
              We may update this Cookie Policy periodically to reflect changes in technology or legal requirements. Any updates will be posted on this page with a revised effective date.
            </p>

            <h2>Contact</h2>
            <p>
              For questions about this Cookie Policy, contact us at{" "}
              <a href="mailto:privacy@aurionenergyadvisory.com">
                privacy@aurionenergyadvisory.com
              </a>{" "}
              or call +1 (416) 792-4583.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default CookiePolicy;