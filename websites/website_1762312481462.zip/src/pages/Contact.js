import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

const Contact = () => {
  const [form, setForm] = useState({
    name: "",
    email: "",
    organization: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const formErrors = {};
    if (!form.name.trim()) formErrors.name = "Please enter your name.";
    if (!form.email.trim()) {
      formErrors.email = "Please enter your email address.";
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      formErrors.email = "Please provide a valid email address.";
    }
    if (!form.message.trim()) formErrors.message = "Tell us more about your project.";
    return formErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const formErrors = validate();
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      return;
    }
    setSubmitted(true);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact | Aurion Energy Advisory</title>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Contact Aurion Energy Advisory</h1>
          <p>
            Let’s discuss your upcoming project or request more information about our consulting and engineering services.
          </p>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>Get in touch</h2>
              <p>
                Share your project goals, timelines, or questions and our team will respond within one business day.
              </p>
              <div className={styles.contactBlock}>
                <h3>Office</h3>
                <address>
                  460 Bay St<br />
                  Toronto, ON M5H 2Y4<br />
                  Canada
                </address>
              </div>
              <div className={styles.contactBlock}>
                <h3>Phone</h3>
                <a href="tel:+14167924583">+1 (416) 792-4583</a>
              </div>
              <div className={styles.contactBlock}>
                <h3>Email</h3>
                <a href="mailto:contact@aurionenergyadvisory.com">
                  contact@aurionenergyadvisory.com
                </a>
              </div>
              <div className={styles.contactBlock}>
                <h3>LinkedIn</h3>
                <a
                  href="https://www.linkedin.com/company/aurion-energy-advisory"
                  target="_blank"
                  rel="noreferrer"
                >
                  linkedin.com/company/aurion-energy-advisory
                </a>
              </div>
            </div>
            <div className={styles.formWrap}>
              {submitted ? (
                <div className={styles.success}>
                  <h2>Thank you for reaching out.</h2>
                  <p>
                    We’ve received your message and will respond shortly with next steps tailored to your inquiry.
                  </p>
                </div>
              ) : (
                <form className={styles.form} onSubmit={handleSubmit} noValidate>
                  <div className={styles.field}>
                    <label htmlFor="name">Full name*</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      aria-invalid={errors.name ? "true" : "false"}
                    />
                    {errors.name && <span className={styles.error}>{errors.name}</span>}
                  </div>
                  <div className={styles.field}>
                    <label htmlFor="email">Email*</label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={form.email}
                      onChange={handleChange}
                      aria-invalid={errors.email ? "true" : "false"}
                    />
                    {errors.email && <span className={styles.error}>{errors.email}</span>}
                  </div>
                  <div className={styles.field}>
                    <label htmlFor="organization">Organization</label>
                    <input
                      type="text"
                      id="organization"
                      name="organization"
                      value={form.organization}
                      onChange={handleChange}
                    />
                  </div>
                  <div className={styles.field}>
                    <label htmlFor="message">How can we support you?*</label>
                    <textarea
                      id="message"
                      name="message"
                      rows="5"
                      value={form.message}
                      onChange={handleChange}
                      aria-invalid={errors.message ? "true" : "false"}
                    />
                    {errors.message && <span className={styles.error}>{errors.message}</span>}
                  </div>
                  <button type="submit" className={styles.submit}>
                    Submit inquiry
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.mapSection}>
        <div className="container">
          <div className={styles.mapCard}>
            <iframe
              title="Aurion Energy Advisory office location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2886.4016476452147!2d-79.38493622368219!3d43.6515618711058!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d2e98935c9%3A0xa6da84dd2b8b0d86!2s460%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202Y4%2C%20Canada!5e0!3m2!1sen!2sca!4v1707674500000!5m2!1sen!2sca"
              loading="lazy"
              allowFullScreen
              aria-label="Map showing the location of Aurion Energy Advisory office in Toronto"
            ></iframe>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;