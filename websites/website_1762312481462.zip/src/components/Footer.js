import React from "react";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <footer className={styles.footer} id="footer">
      <div className={`container ${styles.grid}`}>
        <div className={styles.brand}>
          <h2 className={styles.title}>Aurion Energy Advisory</h2>
          <p className={styles.subtitle}>
            Integrated consulting and engineering support to accelerate safe, sustainable energy infrastructure across Canada.
          </p>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Visit</h3>
          <address className={styles.address}>
            460 Bay St<br />
            Toronto, ON M5H 2Y4<br />
            Canada
          </address>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Connect</h3>
          <ul className={styles.links}>
            <li>
              <a href="tel:+14167924583" className={styles.link}>
                +1 (416) 792-4583
              </a>
            </li>
            <li>
              <a href="mailto:contact@aurionenergyadvisory.com" className={styles.link}>
                contact@aurionenergyadvisory.com
              </a>
            </li>
            <li>
              <a
                href="https://www.linkedin.com/company/aurion-energy-advisory"
                className={styles.link}
                target="_blank"
                rel="noreferrer"
              >
                LinkedIn
              </a>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Explore</h3>
          <ul className={styles.links}>
            <li><a className={styles.link} href="/services">Services</a></li>
            <li><a className={styles.link} href="/projects">Projects</a></li>
            <li><a className={styles.link} href="/team">Team</a></li>
            <li><a className={styles.link} href="/contact">Contact</a></li>
            <li><a className={styles.link} href="/terms">Terms</a></li>
            <li><a className={styles.link} href="/policy">Privacy</a></li>
            <li><a className={styles.link} href="/cookie-policy">Cookie Policy</a></li>
          </ul>
        </div>
      </div>
      <div className={styles.bottomRow}>
        <p className={styles.copy}>© {new Date().getFullYear()} Aurion Energy Advisory. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;