import React, { useState, useEffect } from "react";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("aurion_cookie_consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 600);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("aurion_cookie_consent", "accepted");
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem("aurion_cookie_consent", "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p className={styles.text}>
          We use cookies to enhance your browsing experience, analyze usage, and support our digital services. You can manage your preferences below.
        </p>
        <div className={styles.actions}>
          <a className={styles.link} href="/cookie-policy">
            Learn more
          </a>
          <button className={styles.buttonSecondary} onClick={handleDecline}>
            Decline
          </button>
          <button className={styles.buttonPrimary} onClick={handleAccept}>
            Accept
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;