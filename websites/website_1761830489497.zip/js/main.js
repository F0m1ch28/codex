document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.site-nav');
    const body = document.body;

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('is-open');
            body.classList.toggle('nav-open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('is-open');
                body.classList.remove('nav-open');
                navToggle.setAttribute('aria-expanded', 'false');
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    }

    const scrollBtn = document.querySelector('.scroll-to-top');
    if (scrollBtn) {
        const toggleScrollButton = () => {
            if (window.scrollY > 300) {
                scrollBtn.classList.add('is-visible');
            } else {
                scrollBtn.classList.remove('is-visible');
            }
        };
        toggleScrollButton();
        window.addEventListener('scroll', toggleScrollButton);

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookiesBtn = document.querySelector('.js-accept-cookies');
    if (cookieBanner && acceptCookiesBtn) {
        const consent = localStorage.getItem('pipCookiesAccepted');
        if (consent === 'true') {
            cookieBanner.classList.add('is-hidden');
        }

        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('pipCookiesAccepted', 'true');
            cookieBanner.classList.add('is-hidden');
            cookieBanner.setAttribute('aria-hidden', 'true');
        });
    }
});