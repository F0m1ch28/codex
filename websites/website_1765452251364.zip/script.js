document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      siteNav.classList.toggle('is-open');
      document.body.classList.toggle('nav-open', !expanded);
    });

    siteNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (siteNav.classList.contains('is-open')) {
          siteNav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
          document.body.classList.remove('nav-open');
        }
      });
    });
  }

  const activePage = document.body.dataset.page;
  if (activePage) {
    const activeLink = document.querySelector(`.site-nav a[data-nav="${activePage}"]`);
    if (activeLink) {
      activeLink.classList.add('is-active');
    }
  }

  const revealElements = document.querySelectorAll('.reveal');
  if (revealElements.length) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );

    revealElements.forEach((el) => observer.observe(el));
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const consent = localStorage.getItem('geohrCookieConsent');
    if (!consent) {
      cookieBanner.classList.add('is-visible');
    }
    const acceptBtn = cookieBanner.querySelector('.cookie-accept');
    const declineBtn = cookieBanner.querySelector('.cookie-decline');

    const setConsent = (value) => {
      localStorage.setItem('geohrCookieConsent', value);
      cookieBanner.classList.remove('is-visible');
    };

    acceptBtn?.addEventListener('click', () => setConsent('accepted'));
    declineBtn?.addEventListener('click', () => setConsent('declined'));
  }
});