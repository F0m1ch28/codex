document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!isExpanded).toString());
            navMenu.classList.toggle('active');
        });

        navMenu.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                navMenu.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const cookieButtons = document.querySelectorAll('[data-cookie-choice]');

    if (cookieBanner) {
        const storedChoice = localStorage.getItem('vernCookieChoice');
        if (!storedChoice) {
            cookieBanner.classList.add('active');
        }

        cookieButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                const choice = button.getAttribute('data-cookie-choice');
                localStorage.setItem('vernCookieChoice', choice);
                cookieBanner.classList.remove('active');
            });
        });
    }
});