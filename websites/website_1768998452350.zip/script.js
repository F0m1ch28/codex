(function () {
    const redirectRoutes = {
        "/history": "archives.html",
        "/infrastructure": "maps.html",
        "/systems": "signals.html",
        "/resilience": "contexts.html"
    };
    const currentPath = window.location.pathname.toLowerCase();
    const pathOnly = currentPath.replace(window.location.origin.toLowerCase(), "");
    if (redirectRoutes[pathOnly]) {
        window.location.replace(redirectRoutes[pathOnly]);
    }
})();

document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav-list');
    if (navToggle && navList) {
        navToggle.addEventListener('click', function () {
            navList.classList.toggle('open');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieAccept = document.querySelector('.cookie-accept');
    const cookieDecline = document.querySelector('.cookie-decline');

    if (cookieBanner) {
        const consent = localStorage.getItem('northlyxCookieConsent');
        if (!consent) {
            cookieBanner.classList.add('active');
        }
        if (cookieAccept) {
            cookieAccept.addEventListener('click', function () {
                localStorage.setItem('northlyxCookieConsent', 'accepted');
                cookieBanner.classList.remove('active');
            });
        }
        if (cookieDecline) {
            cookieDecline.addEventListener('click', function () {
                localStorage.setItem('northlyxCookieConsent', 'declined');
                cookieBanner.classList.remove('active');
            });
        }
    }

    const heroCanvas = document.getElementById('hero-signal-canvas');
    if (heroCanvas) {
        const ctx = heroCanvas.getContext('2d');
        let width, height, animationFrame;

        const resizeCanvas = () => {
            width = heroCanvas.width = heroCanvas.clientWidth;
            height = heroCanvas.height = heroCanvas.clientHeight;
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        const particles = Array.from({ length: 45 }).map(() => ({
            x: Math.random() * width,
            y: Math.random() * height,
            radius: Math.random() * 2 + 1,
            speed: Math.random() * 0.8 + 0.2,
            angle: Math.random() * Math.PI * 2
        }));

        function drawRadar() {
            ctx.clearRect(0, 0, width, height);
            ctx.save();
            ctx.translate(width / 2, height / 2);
            const rings = 5;
            for (let i = 1; i <= rings; i++) {
                ctx.beginPath();
                ctx.strokeStyle = `rgba(56, 189, 248, ${0.12 * i})`;
                ctx.lineWidth = 1;
                ctx.arc(0, 0, (Math.min(width, height) / 2) * (i / rings), 0, Math.PI * 2);
                ctx.stroke();
            }
            ctx.restore();

            particles.forEach((particle) => {
                particle.x += Math.cos(particle.angle) * particle.speed;
                particle.y += Math.sin(particle.angle) * particle.speed;
                particle.angle += (Math.random() - 0.5) * 0.05;

                if (particle.x < 0 || particle.x > width || particle.y < 0 || particle.y > height) {
                    particle.x = Math.random() * width;
                    particle.y = Math.random() * height;
                }

                ctx.beginPath();
                ctx.fillStyle = 'rgba(168, 85, 247, 0.8)';
                ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
                ctx.fill();
            });

            animationFrame = requestAnimationFrame(drawRadar);
        }
        drawRadar();
        window.addEventListener('beforeunload', function () {
            cancelAnimationFrame(animationFrame);
        });
    }

    const layerButtons = document.querySelectorAll('.map-layer-control button');
    const layerOutputs = document.querySelectorAll('[data-layer-output]');
    if (layerButtons.length && layerOutputs.length) {
        layerButtons.forEach((btn) => {
            btn.addEventListener('click', function () {
                layerButtons.forEach((b) => b.classList.remove('active'));
                btn.classList.add('active');
                const target = btn.getAttribute('data-layer');
                layerOutputs.forEach((out) => {
                    if (out.getAttribute('data-layer-output') === target) {
                        out.removeAttribute('hidden');
                    } else {
                        out.setAttribute('hidden', 'hidden');
                    }
                });
            });
        });
    }

    const forms = document.querySelectorAll('form');
    forms.forEach((form) => {
        form.addEventListener('submit', function () {
            form.querySelectorAll('button[type="submit"]').forEach((button) => {
                button.disabled = true;
                button.textContent = 'Transmitting…';
            });
        });
    });
});