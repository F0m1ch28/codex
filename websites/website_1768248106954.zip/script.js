(function () {
    const banner = document.getElementById("cookieBanner");
    if (!banner) return;
    const consent = localStorage.getItem("gc-cookie-consent");
    if (!consent) {
        banner.classList.add("visible");
    }
    const buttons = banner.querySelectorAll("[data-consent]");
    buttons.forEach((btn) => {
        btn.addEventListener("click", (event) => {
            const value = btn.getAttribute("data-consent");
            localStorage.setItem("gc-cookie-consent", value);
            banner.classList.remove("visible");
            const target = btn.getAttribute("href");
            if (target) {
                event.preventDefault();
                window.location.href = target;
            }
        });
    });
})();