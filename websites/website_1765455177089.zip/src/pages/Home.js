```javascript
import React, { useEffect, useMemo, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsConfig = [
  { label: 'Curated itineraries delivered', value: 128 },
  { label: 'Local experts in our network', value: 42 },
  { label: 'Traveller satisfaction score', value: 96, suffix: '%' }
];

const attractions = [
  {
    name: 'Keukenhof Gardens',
    description: 'Wander through seven million blooming tulips and innovative floral exhibits in Lisse, a seasonal spectacle that defines Dutch spring.',
    image: 'https://images.unsplash.com/photo-1495379806175-765d7e32d73a?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Kinderdijk Windmills',
    description: 'Step into the UNESCO-listed polder landscape and uncover centuries-old water management traditions shaped by 19 windmills.',
    image: 'https://images.unsplash.com/photo-1561094889-76b7b01df0f7?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Rijksmuseum',
    description: 'Immerse yourself in masterpieces by Rembrandt, Vermeer, and Dutch Golden Age artists inside Amsterdam’s landmark national museum.',
    image: 'https://images.unsplash.com/photo-1508057198894-247b23fe5ade?auto=format&fit=crop&w=1200&q=80'
  }
];

const newsItems = [
  {
    title: 'New multimedia experience opens at Van Gogh Museum',
    date: 'April 22, 2024',
    summary: 'Interactive projections and personal letters take centre stage in a refreshed permanent exhibition that guides visitors through Vincent’s creative evolution.'
  },
  {
    title: 'Historic canal houses introduce sustainable visitor hours',
    date: 'April 12, 2024',
    summary: 'Amsterdam canal house museums coordinate new time-slot reservations to balance neighbourhood wellbeing with heritage appreciation.'
  },
  {
    title: 'Leeuwarden celebrates European Capital of Culture legacy',
    date: 'March 28, 2024',
    summary: 'The Frisian capital launches a year-long programme highlighting language, design, and community-driven art projects across the province.'
  },
  {
    title: 'Rotterdam rooftop routes expand for summer season',
    date: 'March 05, 2024',
    summary: 'Architectural rooftops across Rotterdam open with guided tours, showcasing skyline views and urban sustainability initiatives.'
  }
];

const testimonials = [
  {
    quote: 'The depth of cultural context in every itinerary helped us look beyond postcard moments and genuinely understand Dutch daily life.',
    name: 'Priya Desai',
    origin: 'Travel journalist, Mumbai',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80'
  },
  {
    quote: 'Tour Guide NL clarified public transport options, local etiquette, and hidden neighbourhood cafés that defined our family trip.',
    name: 'Andreas Müller',
    origin: 'Architect, Berlin',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e2?auto=format&fit=crop&w=400&q=80'
  },
  {
    quote: 'From art openings to cycling detours, the team curated authentic experiences that matched our pace and curiosity.',
    name: 'Camille Nguyen',
    origin: 'Cultural curator, Singapore',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653f0?auto=format&fit=crop&w=400&q=80'
  }
];

const programs = [
  {
    title: 'Week of Tulips',
    detail: 'Seasonal journey through flower fields, horticultural studios, and culinary workshops celebrating Dutch spring traditions.',
    image: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Van Gogh’s Netherlands',
    detail: 'Trace Vincent’s footsteps across Brabant and Drenthe with guided access to studios, landscapes, and intimate archival collections.',
    image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Design & Architecture Circuit',
    detail: 'Explore contemporary Dutch design across Rotterdam, Eindhoven, and Utrecht with workshops, rooftop tours, and studio visits.',
    image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=800&q=80'
  }
];

const quickLinks = [
  { path: '/guide', label: 'City-by-city guide' },
  { path: '/programs', label: 'Signature programs' },
  { path: '/tools', label: 'Essential travel tools' },
  { path: '/blog', label: 'Latest stories & tips' }
];

function HomePage() {
  const [statValues, setStatValues] = useState(statsConfig.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  useEffect(() => {
    const durations = statsConfig.map(() => 1200);
    const start = performance.now();

    const tick = now => {
      const elapsed = now - start;
      setStatValues(
        statsConfig.map((stat, index) => {
          const progress = Math.min(elapsed / durations[index], 1);
          return Math.floor(progress * stat.value);
        })
      );
      if (elapsed < Math.max(...durations)) {
        requestAnimationFrame(tick);
      }
    };

    requestAnimationFrame(tick);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex(prev => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(interval);
  }, []);

  const activeTestimonial = testimonials[testimonialIndex];

  const processSteps = useMemo(
    () => [
      {
        title: 'Discover',
        description: 'Share your travel style, time frame, and curious questions about the Netherlands so we can tune our research.',
        icon: '🔍'
      },
      {
        title: 'Design',
        description: 'We assemble layered itineraries with optional add-ons, mindful travel tips, and practical briefings for each city.',
        icon: '🗺️'
      },
      {
        title: 'Experience',
        description: 'Arrive confident with day-by-day guidance, verified reservations, and real-time support from Dutch specialists.',
        icon: '🚲'
      }
    ],
    []
  );

  return (
    <>
      <Helmet>
        <title>Tour Guide NL | Your Essential Compass to the Netherlands</title>
        <meta
          name="description"
          content="Tour Guide NL helps you experience the Netherlands with confidence through curated itineraries, cultural insights, and smart travel tools crafted by local experts."
        />
        <meta
          name="keywords"
          content="Netherlands travel guide, Dutch attractions, Holland tourism, Netherlands itinerary, Tour Guide NL"
        />
      </Helmet>
      <article className={styles.page}>
        <section
          className={styles.hero}
          style={{
            backgroundImage: 'linear-gradient(102deg, rgba(15, 23, 42, 0.55), rgba(15, 23, 42, 0.15)), url(https://images.unsplash.com/photo-1491557345352-5929e343eb89?auto=format&fit=crop&w=1600&q=80)'
          }}
        >
          <div className={styles.heroContent}>
            <p className={styles.promoTag}>Curated journeys across the Netherlands</p>
            <h1>Navigate Dutch cities with insider confidence</h1>
            <p className={styles.heroSubtitle}>
              From canal-side strolls to contemporary design trails, Tour Guide NL layers practical guidance with cultural storytelling so every day in the Netherlands feels effortless.
            </p>
            <div className={styles.heroActions}>
              <NavLink to="/programs" className={styles.ctaButton}>Explore signature programs</NavLink>
              <NavLink to="/guide" className={styles.secondaryButton}>Browse the full city guide</NavLink>
            </div>
          </div>
        </section>

        <section className={styles.intro}>
          <div>
            <h2>Local knowledge, thoughtfully delivered</h2>
            <p>
              We are a collective of Dutch travel specialists, museum docents, and culinary storytellers passionate about showcasing the Netherlands beyond clichés. Our mission is to connect travellers with the people, places, and ideas shaping the country today, while honouring its layered heritage.
            </p>
          </div>
          <div>
            <p>
              Through in-depth research, meaningful partnerships, and a real-time understanding of local rhythms, Tour Guide NL helps you design experiences that are insightful, sustainable, and surprisingly seamless.
            </p>
          </div>
        </section>

        <section className={styles.stats}>
          {statsConfig.map((stat, index) => (
            <div key={stat.label} className={styles.statCard}>
              <span className={styles.statValue}>
                {statValues[index]}
                {stat.suffix || '+'}
              </span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </section>

        <section className={styles.attractions}>
          <header className={styles.sectionHeader}>
            <h2>Featured Dutch highlights</h2>
            <p>Iconic landmarks and immersive experiences that define the Netherlands—curated by those who know them intimately.</p>
          </header>
          <div className={styles.attractionGrid}>
            {attractions.map(attraction => (
              <article key={attraction.name} className={styles.attractionCard}>
                <img src={attraction.image} alt={attraction.name} loading="lazy" />
                <div className={styles.attractionBody}>
                  <h3>{attraction.name}</h3>
                  <p>{attraction.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.programs}>
          <header className={styles.sectionHeader}>
            <h2>Signature journeys crafted for you</h2>
            <p>Each program blends renowned attractions with personal encounters, seasonal events, and comfortable pacing.</p>
          </header>
          <div className={styles.programGrid}>
            {programs.map(program => (
              <article key={program.title} className={styles.programCard}>
                <img src={program.image} alt={program.title} loading="lazy" />
                <div className={styles.programBody}>
                  <h3>{program.title}</h3>
                  <p>{program.detail}</p>
                  <NavLink to="/programs" className={styles.linkArrow} aria-label={`Discover ${program.title}`}>
                    Discover more →
                  </NavLink>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.process}>
          <header className={styles.sectionHeader}>
            <h2>How we design your Dutch adventure</h2>
            <p>Enjoy a collaborative planning process supported by local experts at every step.</p>
          </header>
          <div className={styles.processGrid}>
            {processSteps.map(step => (
              <article key={step.title} className={styles.processCard}>
                <span className={styles.processIcon} aria-hidden="true">{step.icon}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.news}>
          <header className={styles.sectionHeader}>
            <h2>Fresh from the Netherlands</h2>
            <p>Stay ahead with cultural openings, design highlights, and sustainability initiatives shaping Dutch travel.</p>
          </header>
          <div className={styles.newsGrid}>
            {newsItems.map(item => (
              <article key={item.title} className={styles.newsCard}>
                <div>
                  <span className={styles.newsDate}>{item.date}</span>
                  <h3>{item.title}</h3>
                  <p>{item.summary}</p>
                </div>
                <NavLink to="/blog" className={styles.linkArrow} aria-label={`Read more about ${item.title}`}>
                  Read more →
                </NavLink>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.testimonials}>
          <header className={styles.sectionHeader}>
            <h2>Words from curious travellers</h2>
            <p>We are grateful for the explorers who trust us to reveal the Netherlands through an authentic lens.</p>
          </header>
          <div className={styles.testimonialWrapper}>
            <aside className={styles.testimonialPortrait}>
              <img src={activeTestimonial.image} alt={`Portrait of ${activeTestimonial.name}`} />
            </aside>
            <blockquote className={styles.testimonialQuote}>
              <p>“{activeTestimonial.quote}”</p>
              <footer>
                <strong>{activeTestimonial.name}</strong>
                <span>{activeTestimonial.origin}</span>
              </footer>
            </blockquote>
          </div>
          <div className={styles.testimonialControls}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                onClick={() => setTestimonialIndex(index)}
                className={`${styles.dot} ${testimonialIndex === index ? styles.dotActive : ''}`}
                aria-label={`Show testimonial ${index + 1}`}
              />
            ))}
          </div>
        </section>

        <section className={styles.quickLinks}>
          <h2>Quick access to essential resources</h2>
          <div className={styles.quickGrid}>
            {quickLinks.map(link => (
              <NavLink key={link.path} to={link.path} className={styles.quickCard}>
                <h3>{link.label}</h3>
                <span>Open section →</span>
              </NavLink>
            ))}
          </div>
        </section>

        <section className={styles.blogPreview}>
          <div className={styles.blogContent}>
            <h2>Insights from our latest stories</h2>
            <p>Practical advice, cultural anecdotes, and thoughtful interviews with locals to deepen your understanding of Dutch life.</p>
            <NavLink to="/blog" className={styles.ctaButtonSecondary}>
              Visit the blog
            </NavLink>
          </div>
          <div className={styles.blogVisual} role="presentation">
            <img
              src="https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=80"
              alt="Dutch cyclist crossing a canal bridge"
              loading="lazy"
            />
          </div>
        </section>

        <section className={styles.cta}>
          <div className={styles.ctaInner}>
            <h2>Ready to craft your Netherlands itinerary?</h2>
            <p>
              Share your travel dreams and let Tour Guide NL translate them into an itinerary that balances discovery, comfort, and local connection. Our team responds within one business day.
            </p>
            <div className={styles.ctaActions}>
              <NavLink to="/contact" className={styles.ctaButton}>Start planning</NavLink>
              <NavLink to="/about" className={styles.secondaryButton}>Meet the team</NavLink>
            </div>
          </div>
        </section>
      </article>
    </>
  );
}

export default HomePage;
```