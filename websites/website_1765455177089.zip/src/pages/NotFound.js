```javascript
import React from 'react';
import { NavLink } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './NotFound.module.css';

function NotFoundPage() {
  return (
    <>
      <Helmet>
        <title>Tour Guide NL | Page Not Found</title>
        <meta
          name="description"
          content="The page you are looking for could not be found. Return to the Tour Guide NL homepage for travel inspiration."
        />
      </Helmet>
      <section className={styles.page}>
        <h1>Page not found</h1>
        <p>We cannot locate the content you were seeking. Let us guide you back to our latest travel inspiration.</p>
        <NavLink to="/" className={styles.homeLink}>
          Return to homepage
        </NavLink>
      </section>
    </>
  );
}

export default NotFoundPage;
```