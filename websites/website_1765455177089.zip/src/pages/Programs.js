```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programs.module.css';

const programList = [
  {
    title: 'Week of Tulips',
    duration: '7 days',
    focus: 'Seasonal floriculture, horticultural craftsmanship, culinary pairings',
    description:
      'Trace the bloom calendar from the bulb fields of Lisse to private greenhouse tours in Flevoland. Enjoy hands-on workshops with growers, photography walks at sunrise, and a chef-led tasting celebrating Dutch spring produce.',
    highlights: [
      'Exclusive sunrise access at Keukenhof Gardens with a floral designer.',
      'Farm-to-table dinner hosted by a Noordoostpolder tulip grower.',
      'Private boat trip through Haarlem’s hidden canals.'
    ],
    image: 'https://images.unsplash.com/photo-1454275777323-1c402f4fd837?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Van Gogh’s Netherlands',
    duration: '5 days',
    focus: 'Art history, rural landscapes, intimate museum experiences',
    description:
      'Visit Vincent’s early studios in Zundert, the rewilded Drenthe heathlands that inspired his landscapes, and the Van Gogh Museum’s conservation lab. Guided by art historians, you will see how the Netherlands shaped his perspective.',
    highlights: [
      'Behind-the-scenes tour at the Van Gogh Museum conservation studio.',
      'Cycling route through Nuenen’s rural scenes with augmented reality stops.',
      'Curated gallery evening with contemporary Dutch artists influenced by Van Gogh.'
    ],
    image: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Design & Architecture Circuit',
    duration: '6 days',
    focus: 'Contemporary architecture, design studios, urban innovation',
    description:
      'Experience Rotterdam’s skyline, Eindhoven’s design labs, and Utrecht’s adaptive reuse projects. Perfect for creatives, this itinerary combines studio visits, rooftop tours, and collaborative workshops with Dutch designers.',
    highlights: [
      'Guided Rotterdam rooftop trail highlighting climate-proof urban planning.',
      'Studio visit with Dutch Design Week alumni in Eindhoven’s Strijp-S district.',
      'Interactive session at Utrecht’s Railway Museum on mobility innovation.'
    ],
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Culinary Netherlands',
    duration: '4 days',
    focus: 'Regional flavours, sustainable dining, market experiences',
    description:
      'Discover the evolution of Dutch cuisine with market tours, zero-waste restaurants, and coastal seafood tastings. Learn about local producers championing sustainability and heritage ingredients.',
    highlights: [
      'Chef-led tasting at De Librije’s test kitchen in Zwolle.',
      'Cheese aging workshop in Gouda with a fifth-generation affineur.',
      'Seafood expedition with a Scheveningen fisher aboard a traditional vessel.'
    ],
    image: 'https://images.unsplash.com/photo-1525755662778-989d0524087e?auto=format&fit=crop&w=1200&q=80'
  }
];

function ProgramsPage() {
  return (
    <>
      <Helmet>
        <title>Tour Guide NL | Signature Travel Programs in the Netherlands</title>
        <meta
          name="description"
          content="From tulip seasons to architecture immersions, explore Tour Guide NL’s signature travel programs tailored for meaningful journeys across the Netherlands."
        />
        <meta
          name="keywords"
          content="Netherlands itinerary, tulip tour, Van Gogh tour, Dutch design tour, culinary Netherlands"
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.intro}>
          <h1>Signature programs designed around your curiosity</h1>
          <p>
            Each Tour Guide NL program blends landmark experiences with intimate encounters, ensuring your time in the Netherlands reflects your interests, pace, and values. All programs can be fine-tuned with additional destinations, expert hosts, and flexible travel services.
          </p>
        </header>

        <div className={styles.grid}>
          {programList.map(program => (
            <article key={program.title} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={program.image} alt={`${program.title} program`} loading="lazy" />
              </div>
              <div className={styles.content}>
                <h2>{program.title}</h2>
                <div className={styles.meta}>
                  <span>Duration: {program.duration}</span>
                  <span>Focus: {program.focus}</span>
                </div>
                <p>{program.description}</p>
                <ul>
                  {program.highlights.map(item => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
                <button type="button" className={styles.inquiryBtn} aria-label={`Inquire about ${program.title}`}>
                  Request personalised edition
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

export default ProgramsPage;
```