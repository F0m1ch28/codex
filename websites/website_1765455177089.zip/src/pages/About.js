```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const values = [
  {
    title: 'Local collaboration',
    description: 'We work with museum curators, neighbourhood entrepreneurs, and cultural institutions to ensure every recommendation supports the community.'
  },
  {
    title: 'Thoughtful travel',
    description: 'Our itineraries prioritise slow exploration, sustainable transport, and responsible storytelling that respects Dutch heritage.'
  },
  {
    title: 'Continuous discovery',
    description: 'We revisit destinations regularly, attending events and speaking with locals so our guidance stays current and authentic.'
  }
];

const team = [
  {
    name: 'Sanne Jansen',
    role: 'Founder & Cultural Strategist',
    bio: 'Former museum educator with a passion for interweaving art history and contemporary Dutch culture.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'David Bakker',
    role: 'Lead Travel Designer',
    bio: 'Maps bespoke itineraries that harmonise transport logistics, local events, and personalised experiences.',
    image: 'https://images.unsplash.com/photo-1531891437562-4301cf35b7e4?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Lotte de Vries',
    role: 'Culinary Curator',
    bio: 'Researches regional producers and chefs to showcase Dutch cuisine through immersive tastings and workshops.',
    image: 'https://images.unsplash.com/photo-1552374196-c4e7ffc6e126?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Mateo van Rijn',
    role: 'Logistics & Sustainability Lead',
    bio: 'Ensures every program aligns with low-impact travel, smart routing, and accessible experiences.',
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=400&q=80'
  }
];

function AboutPage() {
  return (
    <>
      <Helmet>
        <title>Tour Guide NL | About Our Mission and Team</title>
        <meta
          name="description"
          content="Learn about Tour Guide NL’s mission, values, and expert team dedicated to crafting meaningful travel experiences across the Netherlands."
        />
        <meta
          name="keywords"
          content="Tour Guide NL team, Netherlands travel experts, Dutch travel company, sustainable tourism Netherlands"
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.hero}>
          <h1>Meet the minds behind Tour Guide NL</h1>
          <p>
            Tour Guide NL began with a simple belief: travelling the Netherlands becomes unforgettable when guided by people who live, work, and dream here. We are a multidisciplinary team committed to connecting travellers with authentic Dutch stories.
          </p>
        </header>

        <section className={styles.values}>
          {values.map(value => (
            <article key={value.title} className={styles.valueCard}>
              <h2>{value.title}</h2>
              <p>{value.description}</p>
            </article>
          ))}
        </section>

        <section className={styles.team}>
          <header className={styles.teamIntro}>
            <h2>The team guiding your journey</h2>
            <p>
              Our backgrounds span arts education, hospitality, urban planning, and culinary heritage. Together, we create itineraries that are insightful, inclusive, and rooted in local expertise.
            </p>
          </header>
          <div className={styles.teamGrid}>
            {team.map(member => (
              <article key={member.name} className={styles.memberCard}>
                <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                <div className={styles.memberContent}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </section>
      </section>
    </>
  );
}

export default AboutPage;
```