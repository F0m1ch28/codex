```javascript
import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const rates = {
  USD: { label: 'United States Dollar', rate: 1.08 },
  GBP: { label: 'British Pound Sterling', rate: 0.87 },
  AUD: { label: 'Australian Dollar', rate: 1.63 },
  CAD: { label: 'Canadian Dollar', rate: 1.47 },
  JPY: { label: 'Japanese Yen', rate: 163.25 }
};

const phrases = [
  { dutch: 'Goedemorgen', english: 'Good morning' },
  { dutch: 'Dank u wel', english: 'Thank you very much' },
  { dutch: 'Kunt u mij helpen?', english: 'Could you help me?' },
  { dutch: 'Waar is het station?', english: 'Where is the station?' },
  { dutch: 'Mag ik de rekening alstublieft?', english: 'May I have the bill please?' },
  { dutch: 'Een koffie graag', english: 'A coffee please' }
];

function ToolsPage() {
  const [amount, setAmount] = useState(100);
  const [currency, setCurrency] = useState('USD');

  const converted = useMemo(() => {
    const selected = rates[currency];
    if (!selected) return 0;
    return (amount * selected.rate).toFixed(2);
  }, [amount, currency]);

  return (
    <>
      <Helmet>
        <title>Tour Guide NL | Essential Travel Tools for the Netherlands</title>
        <meta
          name="description"
          content="Use Tour Guide NL tools: a EUR currency converter, Dutch phrasebook, and interactive map to prepare for your Netherlands adventure."
        />
        <meta
          name="keywords"
          content="EUR currency converter, Dutch phrases, Netherlands map, travel tools"
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.intro}>
          <h1>Travel tools for a confident Dutch adventure</h1>
          <p>
            Prepare with practical utilities designed by Tour Guide NL. Convert budgeting figures, master everyday Dutch phrases, and visualise the regions you will explore.
          </p>
        </header>

        <div className={styles.grid}>
          <article className={styles.card}>
            <h2>EUR currency converter</h2>
            <p className={styles.cardIntro}>
              Enter your budget in euros to estimate costs abroad. Exchange rates are indicative and refreshed weekly.
            </p>
            <form className={styles.converter}>
              <label>
                <span>Amount in EUR</span>
                <input
                  type="number"
                  min="0"
                  value={amount}
                  onChange={event => setAmount(Number(event.target.value))}
                />
              </label>
              <label>
                <span>Convert to</span>
                <select value={currency} onChange={event => setCurrency(event.target.value)}>
                  {Object.entries(rates).map(([code, info]) => (
                    <option key={code} value={code}>
                      {code} — {info.label}
                    </option>
                  ))}
                </select>
              </label>
              <div className={styles.result} aria-live="polite">
                <span>Indicative amount</span>
                <strong>
                  {converted} {currency}
                </strong>
              </div>
            </form>
            <p className={styles.disclaimer}>
              Exchange rates are approximations sourced from the European Central Bank and may differ from live rates. Confirm precise amounts with your payment provider.
            </p>
          </article>

          <article className={styles.card}>
            <h2>On-the-go phrasebook</h2>
            <p className={styles.cardIntro}>
              Dutch locals appreciate small efforts in their language. Practise these phrases for greetings, gratitude, and daily interactions.
            </p>
            <table className={styles.table}>
              <caption className="sr-only">Dutch phrases with English translations</caption>
              <thead>
                <tr>
                  <th scope="col">Dutch</th>
                  <th scope="col">English</th>
                </tr>
              </thead>
              <tbody>
                {phrases.map(phrase => (
                  <tr key={phrase.dutch}>
                    <td>{phrase.dutch}</td>
                    <td>{phrase.english}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </article>

          <article className={`${styles.card} ${styles.mapCard}`}>
            <h2>Interactive map of the Netherlands</h2>
            <p className={styles.cardIntro}>
              Discover major regions, transportation hubs, and natural landscapes. Use the map to plan day trips and multi-city routes.
            </p>
            <div className={styles.mapWrapper}>
              <iframe
                title="Netherlands interactive map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1954087.0984505555!2d4.645523942855468!3d52.21299188304009!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c63c60588be92d%3A0xca8cc4aa22602bd9!2sNetherlands!5e0!3m2!1sen!2sus!4v1713700000000!5m2!1sen!2sus"
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            <ul className={styles.mapTips}>
              <li>
                <strong>Randstad:</strong> Cluster of Amsterdam, Rotterdam, The Hague, and Utrecht—linked by high-frequency trains.
              </li>
              <li>
                <strong>Friesland:</strong> Lakes, language, and UNESCO-protected Wadden Sea islands perfect for cycling escapes.
              </li>
              <li>
                <strong>Limburg:</strong> Rolling hills, castles, and culinary craftsmanship near the Belgian and German borders.
              </li>
            </ul>
          </article>
        </div>
      </section>
    </>
  );
}

export default ToolsPage;
```