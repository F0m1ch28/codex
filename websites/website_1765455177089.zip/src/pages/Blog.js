```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Cycling etiquette on Amsterdam’s busiest routes',
    excerpt: 'Practical advice for navigating bike lanes, signalling properly, and sharing the road with locals during peak hours.',
    date: 'April 16, 2024',
    image: 'https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Where Dutch designers gather after hours',
    excerpt: 'From Eindhoven’s Strijp-S to Rotterdam’s creative docks, discover inspiring places to meet the minds shaping Dutch design.',
    date: 'April 3, 2024',
    image: 'https://images.unsplash.com/photo-1479839672679-a46483c0e7c8?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Beyond Gouda: exploring regional cheese traditions',
    excerpt: 'Travel through North Holland, Friesland, and Limburg to taste cheeses that reflect the landscape and heritage of each region.',
    date: 'March 22, 2024',
    image: 'https://images.unsplash.com/photo-1511690743698-d9d85f2fbf38?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'A guide to Netherlands UNESCO treasures',
    excerpt: 'Plan a route through windmills, beemster polder, and the Wadden Sea with tips on conservation-minded visits.',
    date: 'March 9, 2024',
    image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Seasonal markets worth the detour',
    excerpt: 'From Maastricht’s winter fair to Alkmaar’s cheese market, plot your travels to coincide with festive local gatherings.',
    date: 'February 27, 2024',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Sustainable stays in the Dutch countryside',
    excerpt: 'Eco-friendly farm retreats, energy-neutral lodges, and riverboats that make rural escapes restorative.',
    date: 'February 12, 2024',
    image: 'https://images.unsplash.com/photo-1528906236041-8867ed72abff?auto=format&fit=crop&w=1200&q=80'
  }
];

function BlogPage() {
  return (
    <>
      <Helmet>
        <title>Tour Guide NL | Travel Stories and Insights</title>
        <meta
          name="description"
          content="Read the Tour Guide NL blog for practical travel advice, cultural highlights, and seasonal inspiration for exploring the Netherlands."
        />
        <meta
          name="keywords"
          content="Netherlands travel blog, Dutch culture insights, travel tips, Tour Guide NL stories"
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.hero}>
          <h1>Stories, insights, and seasonal inspiration</h1>
          <p>
            Our editorial team collaborates with cultural insiders, historians, and local hosts to bring you thoughtful perspectives on the Netherlands. Browse recent highlights below.
          </p>
        </header>

        <div className={styles.grid}>
          {posts.map(post => (
            <article key={post.title} className={styles.card}>
              <img src={post.image} alt={post.title} loading="lazy" />
              <div className={styles.content}>
                <span className={styles.date}>{post.date}</span>
                <h2>{post.title}</h2>
                <p>{post.excerpt}</p>
                <button type="button" className={styles.readMore}>
                  Continue reading
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

export default BlogPage;
```