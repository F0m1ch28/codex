```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  subject: '',
  message: ''
};

function ContactPage() {
  const [formData, setFormData] = useState(initialState);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const nextErrors = {};
    if (!formData.name.trim()) nextErrors.name = 'Please enter your name.';
    if (!formData.email.trim()) {
      nextErrors.email = 'Please enter your email.';
    } else if (!/^[\w.%+-]+@[\w.-]+\.[A-Za-z]{2,}$/.test(formData.email)) {
      nextErrors.email = 'Please enter a valid email.';
    }
    if (!formData.subject.trim()) nextErrors.subject = 'Add a brief subject.';
    if (formData.message.trim().length < 10) {
      nextErrors.message = 'Message should be at least 10 characters.';
    }
    return nextErrors;
  };

  const handleChange = event => {
    const { name, value } = event.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = event => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <>
      <Helmet>
        <title>Tour Guide NL | Contact Our Travel Specialists</title>
        <meta
          name="description"
          content="Contact Tour Guide NL for tailored travel planning across the Netherlands. Email info@tourguidenl.com or call +31 20 123 4567."
        />
        <meta
          name="keywords"
          content="Contact Tour Guide NL, Netherlands travel planner, Dutch travel support"
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.hero}>
          <h1>We would love to hear about your plans</h1>
          <p>
            Tell us about your upcoming Netherlands journey. Whether you are seeking cultural depth, family-friendly adventures, or corporate retreat planning, Tour Guide NL can craft an experience that fits.
          </p>
        </header>

        <div className={styles.grid}>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <h2>Send us a message</h2>
            <label htmlFor="name">
              Name
              <input
                id="name"
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && <span id="name-error" className={styles.error}>{errors.name}</span>}
            </label>

            <label htmlFor="email">
              Email
              <input
                id="email"
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && <span id="email-error" className={styles.error}>{errors.email}</span>}
            </label>

            <label htmlFor="subject">
              Subject
              <input
                id="subject"
                type="text"
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                aria-invalid={Boolean(errors.subject)}
                aria-describedby={errors.subject ? 'subject-error' : undefined}
              />
              {errors.subject && <span id="subject-error" className={styles.error}>{errors.subject}</span>}
            </label>

            <label htmlFor="message">
              Message
              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && <span id="message-error" className={styles.error}>{errors.message}</span>}
            </label>

            <button type="submit" className={styles.submitButton}>Submit message</button>
            {submitted && (
              <p className={styles.success} role="status">
                Thank you! Our team will review your message and respond within one business day.
              </p>
            )}
          </form>

          <aside className={styles.details}>
            <h2>Contact details</h2>
            <ul>
              <li>
                <strong>Email:</strong>
                <a href="mailto:info@tourguidenl.com">info@tourguidenl.com</a>
              </li>
              <li>
                <strong>Support line:</strong>
                <a href="tel:+31201234567">+31 20 123 4567</a>
              </li>
              <li>
                <strong>Address:</strong>
                <address>
                  Keizersgracht 123<br />
                  1015 CJ Amsterdam<br />
                  Netherlands
                </address>
              </li>
            </ul>

            <div className={styles.infoBox}>
              <h3>Office hours</h3>
              <p>Monday to Friday: 09:00–18:00 CET<br />Saturday: 10:00–14:00 CET<br />Sunday: Closed (on-call support for travelling guests)</p>
            </div>

            <div className={styles.infoBox}>
              <h3>Media & partnerships</h3>
              <p>
                For press features or partnership proposals, write to{' '}
                <a href="mailto:press@tourguidenl.com">press@tourguidenl.com</a>.
              </p>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}

export default ContactPage;
```