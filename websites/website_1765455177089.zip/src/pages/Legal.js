```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function TermsOfService() {
  return (
    <div className={styles.policyContent}>
      <h2 id="terms">Terms of Service</h2>
      <p>
        Tour Guide NL provides curated travel information and consultative planning support for visitors to the Netherlands. By accessing our website or requesting our services, you agree to use the information responsibly and acknowledge that final travel arrangements remain your responsibility unless formally confirmed through a bespoke agreement.
      </p>
      <p>
        All itineraries, recommendations, and materials produced by Tour Guide NL are for personal use. Redistribution or resale without written consent is prohibited. Availability of specific activities and venues may change; we therefore advise confirming details directly with providers before travel. We retain the right to update content, suspend access, or modify services at any time.
      </p>
      <p>
        When collaborating on travel planning, you are expected to provide accurate personal information and respect the booking conditions of third-party partners. Tour Guide NL is not liable for delays, closures, weather events, or other circumstances beyond our control, though we will offer timely support to help you adjust plans.
      </p>
      <p>
        Dutch law governs these terms. Should a dispute arise, parties will first seek an amicable resolution. If unresolved, the competent courts of Amsterdam will have jurisdiction.
      </p>
    </div>
  );
}

function PrivacyPolicy() {
  return (
    <div className={styles.policyContent}>
      <h2 id="privacy">Privacy Policy</h2>
      <p>
        Tour Guide NL collects limited personal data necessary to craft personalised itineraries and respond to enquiries. This may include your name, contact details, travel preferences, and relevant accessibility or dietary considerations voluntarily shared with us.
      </p>
      <p>
        We store data securely within the European Union and restrict access to team members who require it to deliver services. We never sell personal information. When collaborating with trusted partners—such as museums, guides, or accommodation providers—we only share details essential to confirm your arrangements and always with your prior approval.
      </p>
      <p>
        You can request a copy of your data, corrections, or deletion at any time by contacting privacy@tourguidenl.com. We retain information only as long as required to provide services or meet legal obligations. Aggregated, anonymised analytics help us improve the website. These analytics never identify individual visitors.
      </p>
      <p>
        If you believe your data has been handled improperly, you may contact the Dutch Data Protection Authority. We appreciate the opportunity to resolve concerns directly whenever possible.
      </p>
    </div>
  );
}

function CookiePolicy() {
  return (
    <div className={styles.policyContent}>
      <h2 id="cookies">Cookie Policy</h2>
      <p>
        Our website uses essential cookies to ensure navigation works correctly and to remember your cookie preferences. We also rely on privacy-friendly analytics cookies to learn which pages resonate most with travellers. These analytics collect anonymised traffic information and do not track individual behaviour across other websites.
      </p>
      <p>
        You can manage cookie preferences via your browser settings at any time. Declining non-essential cookies may limit certain features, but the core travel information remains accessible. For enquiries about our cookie practices, please write to cookies@tourguidenl.com.
      </p>
    </div>
  );
}

function LegalPage() {
  const [activeTab, setActiveTab] = useState('terms');

  return (
    <>
      <Helmet>
        <title>Tour Guide NL | Legal Information</title>
        <meta
          name="description"
          content="Review Tour Guide NL’s terms of service, privacy policy, and cookie policy to understand how we operate and protect your information."
        />
        <meta
          name="keywords"
          content="Tour Guide NL legal, terms of service, privacy policy, cookie policy"
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.hero}>
          <h1>Legal information</h1>
          <p>
            Transparency is essential to our work. Review how Tour Guide NL approaches service agreements, personal data, and cookies while helping travellers explore the Netherlands.
          </p>
        </header>

        <div className={styles.tabs} role="tablist" aria-label="Legal documents">
          <button
            type="button"
            className={`${styles.tab} ${activeTab === 'terms' ? styles.tabActive : ''}`}
            onClick={() => setActiveTab('terms')}
            role="tab"
            aria-selected={activeTab === 'terms'}
            aria-controls="terms-panel"
            id="terms-tab"
          >
            Terms of Service
          </button>
          <button
            type="button"
            className={`${styles.tab} ${activeTab === 'privacy' ? styles.tabActive : ''}`}
            onClick={() => setActiveTab('privacy')}
            role="tab"
            aria-selected={activeTab === 'privacy'}
            aria-controls="privacy-panel"
            id="privacy-tab"
          >
            Privacy Policy
          </button>
          <button
            type="button"
            className={`${styles.tab} ${activeTab === 'cookies' ? styles.tabActive : ''}`}
            onClick={() => setActiveTab('cookies')}
            role="tab"
            aria-selected={activeTab === 'cookies'}
            aria-controls="cookies-panel"
            id="cookies-tab"
          >
            Cookie Policy
          </button>
        </div>

        <div className={styles.panels}>
          <div
            id="terms-panel"
            role="tabpanel"
            aria-labelledby="terms-tab"
            hidden={activeTab !== 'terms'}
          >
            <TermsOfService />
          </div>
          <div
            id="privacy-panel"
            role="tabpanel"
            aria-labelledby="privacy-tab"
            hidden={activeTab !== 'privacy'}
          >
            <PrivacyPolicy />
          </div>
          <div
            id="cookies-panel"
            role="tabpanel"
            aria-labelledby="cookies-tab"
            hidden={activeTab !== 'cookies'}
          >
            <CookiePolicy />
          </div>
        </div>
      </section>
    </>
  );
}

export default LegalPage;
```