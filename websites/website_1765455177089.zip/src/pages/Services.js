```javascript
// Alias file provided to satisfy requested project structure.
// Tour Guide NL focuses on curated programs; this component reuses the ProgramsPage layout.

import ProgramsPage from './Programs';

export default ProgramsPage;
```