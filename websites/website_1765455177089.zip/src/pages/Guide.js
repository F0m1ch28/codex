```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Guide.module.css';

const cities = [
  {
    name: 'Amsterdam',
    summary: 'The Dutch capital blends UNESCO-listed canals, progressive design, and world-renowned art institutions within a compact network of neighbourhoods.',
    image: 'https://images.unsplash.com/photo-1529429617124-aee0814b3c8e?auto=format&fit=crop&w=1200&q=80',
    highlights: [
      'Start early at the Jordaan for boutique shopping and canal-side cafés before the crowds arrive.',
      'Reserve timed entry for the Anne Frank House and Rijksmuseum to maximise your day.',
      'Cycle to the vibrant Oost district for local breweries, creative hubs, and leafy parks.'
    ],
    dining: [
      'Dignita Hoftuin for all-day brunch inside a serene garden near the Hermitage.',
      'Foodhallen for a curated mix of Dutch and international street food vendors.',
      'De Kas for seasonal fine dining in a greenhouse setting with produce harvested on-site.'
    ],
    transport: [
      'Purchase an OV-chipkaart for seamless tram, metro, ferry, and train travel across the city.',
      'Dedicated cycle lanes make biking intuitive—remember to keep right and signal turns.',
      'Canal ferries between Noord and Central Station operate frequently and are free to board.'
    ]
  },
  {
    name: 'Rotterdam',
    summary: 'Bold architecture and a global port define Rotterdam’s skyline, while its creative quarters reveal cutting-edge design, gastronomy, and nightlife.',
    image: 'https://images.unsplash.com/photo-1496483648148-47c686dc86a8?auto=format&fit=crop&w=1200&q=80',
    highlights: [
      'Admire the Cube Houses and visit the Kijk-Kubus museum to experience life inside a tilted home.',
      'Walk the Rotterdam Rooftop Walk or cross Erasmus Bridge for sweeping city views.',
      'Explore historic Delfshaven for canal-side breweries and maritime heritage.'
    ],
    dining: [
      'Markthal for global flavours under a spectacular ceiling mural.',
      'FG Food Labs for Michelin-starred creativity inside a former railway station.',
      'Fenix Food Factory for craft beers, cheeses, and harbour views on Katendrecht peninsula.'
    ],
    transport: [
      'Rotterdam’s metro and tram system connects major attractions; QR tickets can be purchased via mobile apps.',
      'Water taxis provide rapid and scenic transfers across the Maas river.',
      'Consider a day trip by train to Delft or The Hague—both under 20 minutes away.'
    ]
  },
  {
    name: 'The Hague',
    summary: 'Seat of the Dutch government and home to the royal family, The Hague pairs diplomatic elegance with beachside relaxation in nearby Scheveningen.',
    image: 'https://images.unsplash.com/photo-1500043201634-cb4a6f0f98f3?auto=format&fit=crop&w=1200&q=80',
    highlights: [
      'Visit Mauritshuis to lock eyes with Vermeer’s Girl with a Pearl Earring.',
      'Tour Binnenhof’s inner courtyard and the Peace Palace visitor centre.',
      'Take tram 1 to Scheveningen for coastal walks, seafood, and the Pier’s observation deck.'
    ],
    dining: [
      'MingleMush food hall next to Central Station for global comfort dishes.',
      'Restaurant Calla’s for refined farm-to-table cuisine with a Michelin star.',
      'Simonis aan de Haven for fresh fish in the Scheveningen harbour.'
    ],
    transport: [
      'HTM trams cover the city and beach; day tickets are ideal for short stays.',
      'Rent a bike to access dunes and the royal estate of Clingendael.',
      'Trains connect quickly to Rotterdam (20 min) and Amsterdam (50 min).'
    ]
  },
  {
    name: 'Utrecht',
    summary: 'A youthful university city with medieval canals, wharf cellars, and a thriving café culture, Utrecht offers a relaxed counterpart to the capital.',
    image: 'https://images.unsplash.com/photo-1586596388644-95bbe9c3486b?auto=format&fit=crop&w=1200&q=80',
    highlights: [
      'Climb the 465 steps of Dom Tower for panoramic views across the province.',
      'Explore Museum Speelklok for self-playing musical instruments dating back centuries.',
      'Cruise the Oudegracht canals to appreciate wharf terraces and artisan workshops.'
    ],
    dining: [
      'Broodje Mario for classic Utrecht street food on the Oudegracht.',
      'The Streetfood Club for vibrant interiors and flavourful global dishes.',
      'De Rechtbank for fine dining within a former courthouse.'
    ],
    transport: [
      'OV-fietsen (public bikes) are available directly from Central Station.',
      'Use trams to access the university science park and suburban sites.',
      'Regular trains connect Utrecht with Amsterdam in under 30 minutes.'
    ]
  }
];

function GuidePage() {
  return (
    <>
      <Helmet>
        <title>Tour Guide NL | Detailed City Guides Across the Netherlands</title>
        <meta
          name="description"
          content="Discover city-by-city guides for Amsterdam, Rotterdam, The Hague, Utrecht, and more. Find highlights, recommended dining, and transport tips curated by Tour Guide NL."
        />
        <meta
          name="keywords"
          content="Amsterdam guide, Rotterdam attractions, The Hague travel tips, Utrecht highlights, Netherlands city guide"
        />
      </Helmet>
      <section className={styles.page}>
        <header className={styles.hero}>
          <div>
            <h1>City guides tailored for curious explorers</h1>
            <p>
              Navigate Dutch cities with confidence thanks to first-hand recommendations, logistical tips, and cultural context. Each guide is refreshed regularly to reflect new openings, seasonal events, and grassroots discoveries.
            </p>
          </div>
        </header>

        <div className={styles.cityList}>
          {cities.map(city => (
            <article key={city.name} className={styles.cityCard}>
              <img src={city.image} alt={`${city.name} city view`} loading="lazy" />
              <div className={styles.cityContent}>
                <h2>{city.name}</h2>
                <p className={styles.citySummary}>{city.summary}</p>

                <section className={styles.citySection}>
                  <h3>Essential highlights</h3>
                  <ul>
                    {city.highlights.map(item => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </section>

                <section className={styles.citySection}>
                  <h3>Where to eat & drink</h3>
                  <ul>
                    {city.dining.map(item => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </section>

                <section className={styles.citySection}>
                  <h3>Transport insights</h3>
                  <ul>
                    {city.transport.map(item => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </section>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

export default GuidePage;
```