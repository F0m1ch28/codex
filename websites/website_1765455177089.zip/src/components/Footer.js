```javascript
import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.grid}>
        <div>
          <h3 className={styles.logo}>
            <span>Tour Guide</span>
            <span className={styles.logoAccent}>NL</span>
          </h3>
          <p className={styles.description}>
            Your trusted companion for exploring the Netherlands with carefully curated insights, cultural context, and practical advice for every journey.
          </p>
        </div>
        <div>
          <h4 className={styles.heading}>Explore</h4>
          <ul className={styles.list}>
            <li><NavLink to="/guide">City Guide</NavLink></li>
            <li><NavLink to="/programs">Signature Programs</NavLink></li>
            <li><NavLink to="/tools">Travel Tools</NavLink></li>
            <li><NavLink to="/blog">Travel Stories</NavLink></li>
          </ul>
        </div>
        <div>
          <h4 className={styles.heading}>Company</h4>
          <ul className={styles.list}>
            <li><NavLink to="/about">About Tour Guide NL</NavLink></li>
            <li><NavLink to="/contact">Get in Touch</NavLink></li>
            <li><NavLink to="/legal">Legal Information</NavLink></li>
            <li><a href="https://www.holland.com/global/tourism.htm" target="_blank" rel="noreferrer">Official Tourism Partners</a></li>
          </ul>
        </div>
        <div>
          <h4 className={styles.heading}>Stay Connected</h4>
          <p className={styles.description}>Subscribe to our monthly insights for curated itineraries, cultural events, and local tips straight from Dutch insiders.</p>
          <form className={styles.form}>
            <label htmlFor="newsletter-email" className="sr-only">Email address</label>
            <input id="newsletter-email" type="email" placeholder="Email address" aria-label="Email address" required />
            <button type="submit">Join newsletter</button>
          </form>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© {new Date().getFullYear()} Tour Guide NL. All rights reserved.</p>
        <div className={styles.bottomLinks}>
          <NavLink to="/legal#terms">Terms</NavLink>
          <NavLink to="/legal#privacy">Privacy</NavLink>
          <NavLink to="/legal#cookies">Cookies</NavLink>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
```