document.addEventListener("DOMContentLoaded", function () {
    var banner = document.querySelector(".cookie-banner");
    if (!banner) return;
    var acceptBtn = banner.querySelector("[data-cookie-accept]");
    var declineBtn = banner.querySelector("[data-cookie-decline]");
    var storedConsent = localStorage.getItem("cookieConsentStatus");

    if (storedConsent !== "accepted" && storedConsent !== "declined") {
        banner.classList.add("active");
    }

    acceptBtn.addEventListener("click", function () {
        localStorage.setItem("cookieConsentStatus", "accepted");
        banner.classList.remove("active");
    });

    declineBtn.addEventListener("click", function () {
        localStorage.setItem("cookieConsentStatus", "declined");
        banner.classList.remove("active");
    });
});