document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.site-nav');

    if (navToggle && nav) {
        navToggle.addEventListener('click', () => {
            nav.classList.toggle('open');
        });

        nav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                nav.classList.remove('open');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieChoice = localStorage.getItem('handaxavvmCookieChoice');

    if (cookieBanner && !cookieChoice) {
        setTimeout(() => {
            cookieBanner.classList.add('visible');
        }, 600);
    }

    if (cookieBanner) {
        cookieBanner.querySelectorAll('[data-cookie-choice]').forEach(anchor => {
            anchor.addEventListener('click', () => {
                const choice = anchor.getAttribute('data-cookie-choice');
                localStorage.setItem('handaxavvmCookieChoice', choice);
                cookieBanner.classList.remove('visible');
            });
        });
    }

    const contactForm = document.querySelector('#contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function (event) {
            event.preventDefault();
            window.location.href = 'thanks.html';
        });
    }

    const postFilters = document.querySelectorAll('[data-filter]');
    const postSearch = document.querySelector('#post-search');
    const postCards = document.querySelectorAll('[data-category]');

    if (postFilters.length && postCards.length) {
        let activeFilter = 'all';

        function filterPosts() {
            const query = postSearch ? postSearch.value.toLowerCase().trim() : '';
            postCards.forEach(card => {
                const categories = card.getAttribute('data-category').split(',');
                const title = card.querySelector('.card-title') ? card.querySelector('.card-title').textContent.toLowerCase() : '';
                const excerpt = card.querySelector('.card-excerpt') ? card.querySelector('.card-excerpt').textContent.toLowerCase() : '';
                const matchesFilter = activeFilter === 'all' || categories.includes(activeFilter);
                const matchesSearch = title.includes(query) || excerpt.includes(query);
                if (matchesFilter && matchesSearch) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        postFilters.forEach(button => {
            button.addEventListener('click', () => {
                postFilters.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                activeFilter = button.getAttribute('data-filter');
                filterPosts();
            });
        });

        if (postSearch) {
            postSearch.addEventListener('input', filterPosts);
        }
    }
});