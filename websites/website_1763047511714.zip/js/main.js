document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.mobile-nav-toggle');
    const navMenu = document.querySelector('.main-nav');
    const scrollBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAccept = document.getElementById('cookieAccept');
    const contactForm = document.getElementById('kontaktForm');
    const formFeedback = document.getElementById('formFeedback');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('show');
        });
    }

    window.addEventListener('scroll', () => {
        if (!scrollBtn) return;
        if (window.scrollY > 300) {
            scrollBtn.classList.add('show');
        } else {
            scrollBtn.classList.remove('show');
        }
    });

    if (scrollBtn) {
        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && cookieAccept) {
        const consent = localStorage.getItem('rovintaCookieConsent');
        if (consent === 'accepted') {
            cookieBanner.classList.add('hidden');
        } else {
            cookieBanner.classList.remove('hidden');
        }

        cookieAccept.addEventListener('click', () => {
            localStorage.setItem('rovintaCookieConsent', 'accepted');
            cookieBanner.classList.add('hidden');
        });
    }

    if (contactForm && formFeedback) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            formFeedback.textContent = 'Vielen Dank! Ihre Nachricht wurde übermittelt.';
            contactForm.reset();
            setTimeout(() => {
                formFeedback.textContent = '';
            }, 6000);
        });
    }
});