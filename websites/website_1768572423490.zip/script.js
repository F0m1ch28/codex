document.addEventListener("DOMContentLoaded", function () {
    const header = document.querySelector(".site-header");
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");
    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-accept");
    const declineBtn = document.querySelector(".cookie-decline");

    if (header) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 12) {
                header.classList.add("scrolled");
            } else {
                header.classList.remove("scrolled");
            }
        });
    }

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navLinks.classList.toggle("active");
        });

        navLinks.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                navToggle.setAttribute("aria-expanded", "false");
                navLinks.classList.remove("active");
            });
        });
    }

    const cookieStatus = localStorage.getItem("johnwepnvt_cookie_pref");
    if (!cookieStatus && cookieBanner) {
        cookieBanner.classList.add("active");
    }

    const handleCookiePreference = (value) => {
        localStorage.setItem("johnwepnvt_cookie_pref", value);
        if (cookieBanner) {
            cookieBanner.classList.remove("active");
        }
    };

    if (acceptBtn) {
        acceptBtn.addEventListener("click", () => handleCookiePreference("accepted"));
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", () => handleCookiePreference("declined"));
    }
});