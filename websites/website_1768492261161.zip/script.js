document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", function () {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", (!expanded).toString());
            navLinks.classList.toggle("is-open");
            document.body.classList.toggle("is-locked");
        });

        navLinks.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                navLinks.classList.remove("is-open");
                navToggle.setAttribute("aria-expanded", "false");
                document.body.classList.remove("is-locked");
            });
        });

        window.addEventListener("resize", function () {
            if (window.innerWidth >= 1024) {
                navLinks.classList.remove("is-open");
                navToggle.setAttribute("aria-expanded", "false");
                document.body.classList.remove("is-locked");
            }
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    if (cookieBanner) {
        const storedChoice = localStorage.getItem("acquaiurirCookieChoice");
        if (!storedChoice) {
            cookieBanner.classList.remove("is-hidden");
        }

        cookieBanner.querySelectorAll(".cookie-choice").forEach(function (choiceButton) {
            choiceButton.addEventListener("click", function (event) {
                event.preventDefault();
                const decision = choiceButton.dataset.choice || "undecided";
                localStorage.setItem("acquaiurirCookieChoice", decision);
                cookieBanner.classList.add("is-hidden");
                const target = choiceButton.getAttribute("href") || "cookies.html";
                try {
                    window.open(target, "_blank", "noopener");
                } catch (error) {
                    window.location.href = target;
                }
            });
        });
    }
});