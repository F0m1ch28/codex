document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    if (navToggle) {
        navToggle.addEventListener('click', function () {
            document.body.classList.toggle('nav-open');
        });
    }

    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', () => document.body.classList.remove('nav-open'));
    });

    const filterControls = document.querySelectorAll('.filter-control');
    const blogCards = document.querySelectorAll('.blog-card');
    if (filterControls.length && blogCards.length) {
        filterControls.forEach(control => {
            control.addEventListener('click', event => {
                const target = event.currentTarget;
                const filter = target.getAttribute('data-filter');

                filterControls.forEach(btn => btn.classList.remove('active'));
                target.classList.add('active');

                blogCards.forEach(card => {
                    const categories = card.getAttribute('data-category').split(',');
                    if (filter === 'all' || categories.includes(filter)) {
                        card.classList.remove('is-hidden');
                    } else {
                        card.classList.add('is-hidden');
                    }
                });
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('swampatbwkCookieChoice');
        if (storedChoice) {
            cookieBanner.classList.add('hidden');
        }

        const cookieButtons = cookieBanner.querySelectorAll('.cookie-button');
        cookieButtons.forEach(btn => {
            btn.addEventListener('click', event => {
                event.preventDefault();
                const action = btn.getAttribute('data-action');
                localStorage.setItem('swampatbwkCookieChoice', action);
                cookieBanner.classList.add('hidden');
                window.location.href = btn.getAttribute('href');
            });
        });
    }

    const destinationTabs = document.querySelectorAll('.destination-tab');
    const mapFrame = document.getElementById('destination-map');
    const highlightTitle = document.getElementById('destination-highlight-title');
    const highlightText = document.getElementById('destination-highlight-text');
    if (destinationTabs.length && mapFrame && highlightTitle && highlightText) {
        destinationTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                destinationTabs.forEach(item => item.classList.remove('active'));
                tab.classList.add('active');
                mapFrame.src = tab.getAttribute('data-map');
                highlightTitle.textContent = tab.getAttribute('data-title');
                highlightText.textContent = tab.getAttribute('data-description');
            });
        });

        const activeTab = document.querySelector('.destination-tab.active') || destinationTabs[0];
        if (activeTab) {
            activeTab.click();
        }
    }

    const carousel = document.querySelector('.story-carousel');
    if (carousel) {
        const track = carousel.querySelector('.carousel-track');
        const slides = carousel.querySelectorAll('.story-slide');
        const prevBtn = carousel.querySelector('.carousel-button.prev');
        const nextBtn = carousel.querySelector('.carousel-button.next');
        let index = 0;

        const updateCarousel = () => {
            const offset = index * -100;
            track.style.transform = `translateX(${offset}%)`;
        };

        if (nextBtn) {
            nextBtn.addEventListener('click', () => {
                index = (index + 1) % slides.length;
                updateCarousel();
            });
        }

        if (prevBtn) {
            prevBtn.addEventListener('click', () => {
                index = (index - 1 + slides.length) % slides.length;
                updateCarousel();
            });
        }

        if (slides.length > 1) {
            setInterval(() => {
                index = (index + 1) % slides.length;
                updateCarousel();
            }, 6000);
        }
    }
});