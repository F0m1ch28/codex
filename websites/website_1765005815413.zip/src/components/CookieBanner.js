import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const consent = window.localStorage.getItem("apexvision_cookie_consent");
      if (!consent) {
        const timer = setTimeout(() => setIsVisible(true), 1200);
        return () => clearTimeout(timer);
      }
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem("apexvision_cookie_consent", "accepted");
    }
    setIsVisible(false);
  };

  const handleDecline = () => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem("apexvision_cookie_consent", "declined");
    }
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <h4>Cookie Notice</h4>
        <p>
          We use cookies to personalize content, measure performance, and deliver a superior consulting experience.
          You can accept or decline at any time.
        </p>
      </div>
      <div className="cookie-actions">
        <button className="btn btn-outline" onClick={handleDecline}>
          Decline
        </button>
        <button className="btn btn-primary" onClick={handleAccept}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;