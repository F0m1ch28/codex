import React from "react";
import { NavLink } from "react-router-dom";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <div className="logo footer-logo">
            <span className="logo-mark">A</span>
            <span className="logo-text">ApexVision</span>
          </div>
          <p>
            ApexVision Consulting delivers strategic clarity, digital transformation, and sustainable growth for ambitious
            enterprises worldwide.
          </p>
          <div className="footer-social">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
              LinkedIn
            </a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
              Twitter
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
              YouTube
            </a>
          </div>
        </div>

        <div className="footer-column">
          <h4>Company</h4>
          <NavLink to="/about">About</NavLink>
          <NavLink to="/services">Services</NavLink>
          <NavLink to="/contact">Contact</NavLink>
        </div>

        <div className="footer-column">
          <h4>Resources</h4>
          <a href="#blog">Insights</a>
          <a href="#faq">FAQs</a>
          <a href="#projects">Case Studies</a>
        </div>

        <div className="footer-column">
          <h4>Legal</h4>
          <NavLink to="/privacy">Privacy Policy</NavLink>
          <NavLink to="/terms">Terms of Use</NavLink>
          <a href="mailto:hello@apexvisionconsulting.com">hello@apexvisionconsulting.com</a>
          <p className="footer-address">1200 Innovation Drive<br />New York, NY 10012</p>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {currentYear} ApexVision Consulting. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;