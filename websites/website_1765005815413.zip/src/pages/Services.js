import React from "react";

const Services = () => {
  const services = [
    {
      title: "Strategic Advisory",
      description:
        "Future-proof your organization with scenario planning, competitive intelligence, and positioning strategies that capture market opportunity.",
      deliverables: ["Market Intelligence", "Vision & Roadmaps", "Board Facilitation", "Scenario Planning"],
    },
    {
      title: "Digital Transformation",
      description:
        "Activate technology ecosystems that connect data, automate operations, and deliver adaptive customer experiences at scale.",
      deliverables: ["Digital Blueprint", "Platform Modernization", "Data Strategy", "Experience Innovation"],
    },
    {
      title: "Revenue Acceleration",
      description:
        "Unlock new revenue engines through integrated go-to-market frameworks, dynamic pricing, and loyalty design.",
      deliverables: ["Go-to-Market Motion", "Sales Enablement", "Lifecycle Marketing", "Partner Strategy"],
    },
    {
      title: "Change Enablement",
      description:
        "Empower teams with change leadership, capability building, and agile governance for transformation that lasts.",
      deliverables: ["Change Strategy", "Leadership Coaching", "Capability Academies", "Communications"],
    },
  ];

  const accelerators = [
    {
      title: "Momentum Dashboard",
      description: "A real-time performance cockpit aligning metrics, accountability, and predictive insights.",
    },
    {
      title: "Customer Journey Lab",
      description: "Immersive prototyping environment to test and scale breakthrough customer experiences.",
    },
    {
      title: "Sustainability Navigator",
      description: "Framework aligning ESG commitments with operational roadmaps and stakeholder reporting.",
    },
  ];

  return (
    <div className="services-page">
      <section className="sub-hero">
        <div className="container sub-hero-grid">
          <div>
            <span className="eyebrow">Services</span>
            <h1>End-to-end consulting tailored to your transformation journey.</h1>
            <p>
              From C-suite advisory to in-market execution, ApexVision Consulting equips organizations to thrive amid
              disruption and deliver meaningful value to customers, employees, and shareholders.
            </p>
          </div>
        </div>
      </section>

      <section className="services-detail">
        <div className="container services-detail-grid">
          {services.map((service) => (
            <article className="service-detail-card" key={service.title}>
              <div className="service-detail-header">
                <h2>{service.title}</h2>
                <p>{service.description}</p>
              </div>
              <div className="service-deliverables">
                <h4>Key Deliverables</h4>
                <ul>
                  {service.deliverables.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="accelerators-section">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">Proprietary accelerators</span>
            <h2>Purpose-built toolkits accelerating value creation.</h2>
            <p>
              Our accelerators combine proven methodologies, data frameworks, and collaborative platforms to speed up
              transformation while reducing risk.
            </p>
          </div>
          <div className="accelerator-grid">
            {accelerators.map((accelerator) => (
              <div className="accelerator-card" key={accelerator.title}>
                <h3>{accelerator.title}</h3>
                <p>{accelerator.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="services-cta">
        <div className="container services-cta-card">
          <div>
            <h2>Not sure where to begin?</h2>
            <p>
              Let’s map your transformation vision and design a roadmap aligned to momentum, capability, and measurable
              outcomes.
            </p>
          </div>
          <a className="btn btn-primary" href="/contact">
            Book a Strategy Session
          </a>
        </div>
      </section>
    </div>
  );
};

export default Services;