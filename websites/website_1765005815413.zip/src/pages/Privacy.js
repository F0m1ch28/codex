import React from "react";

const Privacy = () => {
  return (
    <div className="legal-page">
      <section className="sub-hero">
        <div className="container sub-hero-grid">
          <div>
            <span className="eyebrow">Privacy Policy</span>
            <h1>We safeguard your data with transparency and care.</h1>
          </div>
        </div>
      </section>

      <section className="legal-content">
        <div className="container legal-grid">
          <article>
            <h2>1. Information We Collect</h2>
            <p>
              We collect personal information voluntarily provided by you, including contact details, company
              information, and project-related context. We also gather anonymized analytics to improve site performance.
            </p>
          </article>

          <article>
            <h2>2. How We Use Data</h2>
            <p>
              Information is used to respond to inquiries, deliver services, personalize experiences, and share updates
              about ApexVision Consulting. We do not sell personal data to third parties.
            </p>
          </article>

          <article>
            <h2>3. Cookies & Tracking</h2>
            <p>
              Cookies enhance functionality and help us understand usage patterns. You can adjust or disable cookies via
              your browser settings. Declining cookies may impact site performance.
            </p>
          </article>

          <article>
            <h2>4. Data Security</h2>
            <p>
              We implement administrative, technical, and physical safeguards to protect your information against
              unauthorized access, disclosure, or loss.
            </p>
          </article>

          <article>
            <h2>5. Your Rights</h2>
            <p>
              Depending on your jurisdiction, you may request access, correction, or deletion of personal information. To
              exercise these rights, contact us at{" "}
              <a href="mailto:privacy@apexvisionconsulting.com">privacy@apexvisionconsulting.com</a>.
            </p>
          </article>

          <article>
            <h2>6. Data Retention</h2>
            <p>
              We retain information as long as necessary to fulfill engagements, comply with legal obligations, and
              support legitimate business interests.
            </p>
          </article>

          <article>
            <h2>7. Updates</h2>
            <p>
              We may update this policy periodically. Changes will be posted with an updated effective date. Continued
              use of our services constitutes acceptance of the revised policy.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default Privacy;