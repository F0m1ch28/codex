import React from "react";

const Terms = () => {
  return (
    <div className="legal-page">
      <section className="sub-hero">
        <div className="container sub-hero-grid">
          <div>
            <span className="eyebrow">Terms of Use</span>
            <h1>Understanding your use of ApexVision Consulting digital properties.</h1>
          </div>
        </div>
      </section>

      <section className="legal-content">
        <div className="container legal-grid">
          <article>
            <h2>1. Agreement Overview</h2>
            <p>
              By accessing our website and digital resources, you agree to these Terms of Use. ApexVision Consulting may
              update these terms at any time, with revisions effective upon publication.
            </p>
          </article>

          <article>
            <h2>2. Intellectual Property</h2>
            <p>
              All content, trademarks, and materials provided on this site are owned or licensed by ApexVision Consulting.
              You may not reproduce, distribute, or create derivative works without explicit written permission.
            </p>
          </article>

          <article>
            <h2>3. Acceptable Use</h2>
            <p>
              You agree not to misuse the site, including attempting unauthorized access, distributing malware, or
              engaging in activity that interferes with the platform’s security or performance.
            </p>
          </article>

          <article>
            <h2>4. Disclaimer of Warranties</h2>
            <p>
              The information provided is for general guidance. ApexVision Consulting disclaims warranties regarding
              completeness, accuracy, and availability of content and is not liable for decisions made in reliance on the
              material provided.
            </p>
          </article>

          <article>
            <h2>5. Limitation of Liability</h2>
            <p>
              ApexVision Consulting is not liable for direct or indirect damages resulting from use of our site. This
              includes loss of data, profits, or business interruption, to the maximum extent permitted by law.
            </p>
          </article>

          <article>
            <h2>6. Governing Law</h2>
            <p>
              These terms are governed by the laws of the State of New York, without regard to conflict-of-law principles.
              Disputes will be resolved in the state or federal courts located in New York County, New York.
            </p>
          </article>

          <article>
            <h2>7. Contact</h2>
            <p>
              For questions regarding these terms, please contact us at{" "}
              <a href="mailto:legal@apexvisionconsulting.com">legal@apexvisionconsulting.com</a>.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default Terms;