import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";

const Home = () => {
  const statsData = useMemo(
    () => [
      { label: "Projects Delivered", value: 180, suffix: "+" },
      { label: "Client Satisfaction", value: 98, suffix: "%" },
      { label: "Markets Navigated", value: 26, suffix: "" },
      { label: "Growth Accelerated", value: 320, suffix: "%" },
    ],
    []
  );
  const [counts, setCounts] = useState(statsData.map(() => 0));
  const [animateStats, setAnimateStats] = useState(false);
  const statsRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setAnimateStats(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.3 }
    );
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!animateStats) return;
    let animationFrame;
    const start = performance.now();
    const duration = 1600;
    const easeOut = (t) => 1 - Math.pow(1 - t, 3);

    const step = (timestamp) => {
      const progress = Math.min((timestamp - start) / duration, 1);
      const easedProgress = easeOut(progress);
      setCounts(statsData.map((stat) => Math.round(stat.value * easedProgress)));
      if (progress < 1) {
        animationFrame = requestAnimationFrame(step);
      } else {
        setCounts(statsData.map((stat) => stat.value));
      }
    };

    animationFrame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(animationFrame);
  }, [animateStats, statsData]);

  const serviceHighlights = [
    {
      title: "Strategic Advisory",
      description: "Comprehensive market intelligence and positioning strategies tailored to your growth ambitions.",
    },
    {
      title: "Digital Transformation",
      description: "Future-proof technology roadmaps that connect operations, analytics, and customer experiences.",
    },
    {
      title: "Revenue Acceleration",
      description: "Integrated go-to-market programs that scale revenue and build enduring customer loyalty.",
    },
  ];

  const processSteps = [
    {
      title: "Discover",
      description: "Deep-dive workshops uncover insights, goals, and constraints to shape your transformation.",
    },
    {
      title: "Design",
      description: "We co-design adaptive strategies, experience journeys, and technology architectures.",
    },
    {
      title: "Activate",
      description: "Cross-functional squads implement roadmaps with accountable execution and agile governance.",
    },
    {
      title: "Amplify",
      description: "Continuous optimization drives measurable performance and long-term growth resiliency.",
    },
  ];

  const testimonials = [
    {
      quote:
        "ApexVision reimagined our entire operating model. Revenue grew 140% and customer NPS climbed to record highs within 12 months.",
      name: "Elena Morales",
      role: "Chief Growth Officer, NovaTech Labs",
    },
    {
      quote:
        "The team’s insight, empathy, and execution discipline were unmatched. They transformed our culture and accelerated innovation.",
      name: "James Walker",
      role: "CEO, Horizon Retail Group",
    },
    {
      quote:
        "From diagnostic to delivery, ApexVision became a true partner. Their data-driven approach unlocked new markets globally.",
      name: "Sara Patel",
      role: "VP Strategy, Lumina Health",
    },
  ];
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const goToTestimonial = (index) => {
    setCurrentTestimonial(index);
  };

  const teamMembers = [
    {
      name: "Maya Chen",
      role: "Principal Partner, Strategy",
      image: "https://picsum.photos/400/400?random=103",
      bio: "Designs resilient growth models informed by real-time market intelligence and behavioral insights.",
    },
    {
      name: "André Thompson",
      role: "Chief Innovation Officer",
      image: "https://picsum.photos/400/400?random=104",
      bio: "Leads digital reinvention programs that humanize technology and scale impact across global teams.",
    },
    {
      name: "Priya Singh",
      role: "Director of Client Success",
      image: "https://picsum.photos/400/400?random=105",
      bio: "Champions integrated delivery and measurable outcomes through data transparency and co-creation.",
    },
  ];

  const projects = [
    {
      title: "Connected Commerce Evolution",
      category: "Digital",
      image: "https://picsum.photos/1200/800?random=106",
      description: "Unified data, storefront, and supply-chain experiences to unlock 3x growth in omnichannel sales.",
    },
    {
      title: "AI-Driven Health Insights",
      category: "Innovation",
      image: "https://picsum.photos/1200/800?random=107",
      description: "Delivered predictive analytics platform empowering clinicians with proactive care recommendations.",
    },
    {
      title: "Global Market Expansion",
      category: "Strategy",
      image: "https://picsum.photos/1200/800?random=108",
      description: "Orchestrated entry into 5 new markets via tailored positioning and localized partner ecosystems.",
    },
    {
      title: "Sustainable Operations Blueprint",
      category: "Transformation",
      image: "https://picsum.photos/1200/800?random=109",
      description: "Reduced emissions by 36% while increasing supply resilience through circular economy design.",
    },
  ];
  const [activeCategory, setActiveCategory] = useState("All");
  const filteredProjects =
    activeCategory === "All" ? projects : projects.filter((project) => project.category === activeCategory);
  const categories = ["All", "Strategy", "Digital", "Innovation", "Transformation"];

  const faqItems = [
    {
      question: "How do you tailor solutions for different industries?",
      answer:
        "We combine industry-specific benchmarks with proprietary research, co-designing programs alongside your teams to accommodate regulatory, cultural, and market nuances.",
    },
    {
      question: "What is the typical engagement length?",
      answer:
        "Engagements range from rapid diagnostics (4–6 weeks) to multi-year transformations. Each roadmap includes milestones, success metrics, and governance cadence.",
    },
    {
      question: "Do you support implementation or only strategy?",
      answer:
        "We go end-to-end. ApexVision embeds cross-functional squads, enabling technology integrations, training, and change enablement to ensure lasting adoption.",
    },
    {
      question: "How do you measure success?",
      answer:
        "Impact metrics span financial performance, operational efficiency, customer experiences, and employee enablement. We establish dashboards with your leadership from day one.",
    },
  ];
  const [activeFaq, setActiveFaq] = useState(0);

  const blogPosts = [
    {
      title: "Designing Intelligent Enterprises for the Next Decade",
      excerpt: "How adaptive operating models align leadership, data, and culture to stay ahead of disruption.",
      date: "February 12, 2024",
      image: "https://picsum.photos/800/600?random=110",
    },
    {
      title: "The Future of Customer Journeys Is Orchestrated in Real Time",
      excerpt: "Why brands must coordinate experiences across channels with predictive analytics and human empathy.",
      date: "January 28, 2024",
      image: "https://picsum.photos/800/600?random=111",
    },
    {
      title: "Building Sustainable Growth Flywheels",
      excerpt: "A framework for compounding value creation across product, ecosystem, and purpose-driven innovation.",
      date: "January 8, 2024",
      image: "https://picsum.photos/800/600?random=112",
    },
  ];

  return (
    <div className="home-page">
      <section
        className="hero"
        style={{ backgroundImage: "url('https://picsum.photos/1600/900?random=101')" }}
      >
        <div className="hero-overlay" />
        <div className="container hero-content">
          <div className="hero-text">
            <span className="eyebrow">Strategic Growth Partners</span>
            <h1>Transforming ambition into measurable, sustainable outcomes.</h1>
            <p>
              ApexVision Consulting empowers visionary leaders to orchestrate strategy, technology, and human potential—
              delivering breakthroughs that redefine markets.
            </p>
            <div className="hero-actions">
              <Link to="/contact" className="btn btn-primary">
                Schedule an Immersion
              </Link>
              <Link to="/services" className="btn btn-outline">
                Explore Our Services
              </Link>
            </div>
          </div>
          <div className="hero-card">
            <h3>Why brands choose ApexVision</h3>
            <ul>
              <li>Integrated strategy and execution squads</li>
              <li>Customer-first design backed by analytics</li>
              <li>Momentum models that compound over time</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="stats" ref={statsRef}>
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <div className="stat-card" key={stat.label}>
              <span className="stat-number">
                {counts[index]}
                <span className="stat-suffix">{stat.suffix}</span>
              </span>
              <p>{stat.label}</p>
              <span className="stat-bar" />
            </div>
          ))}
        </div>
      </section>

      <section className="services-section" id="services">
        <div className="container section-intro">
          <div>
            <span className="eyebrow">Expertise</span>
            <h2>Integrated consulting that accelerates what matters most.</h2>
          </div>
          <p>
            Our multidisciplinary teams activate your vision through strategy, design, data science, and engineering—
            ensuring holistic transformation and resilient growth.
          </p>
        </div>
        <div className="container services-grid">
          {serviceHighlights.map((service) => (
            <div className="service-card" key={service.title}>
              <div className="service-icon" aria-hidden="true">
                <span />
              </div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/services" className="service-link">
                Discover more →
              </Link>
            </div>
          ))}
        </div>
      </section>

      <section className="process-section" id="process">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">How we work</span>
            <h2>Co-creating momentum with a proven, adaptive framework.</h2>
          </div>
          <div className="process-steps">
            {processSteps.map((step, index) => (
              <div className="process-step" key={step.title}>
                <div className="process-index">{String(index + 1).padStart(2, "0")}</div>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials">
        <div className="container testimonial-wrapper">
          <div className="section-heading">
            <span className="eyebrow">Testimonials</span>
            <h2>Leaders trust ApexVision to orchestrate change with confidence.</h2>
          </div>
          <div className="testimonial-card" key={testimonials[currentTestimonial].name}>
            <p className="testimonial-quote">“{testimonials[currentTestimonial].quote}”</p>
            <div className="testimonial-meta">
              <span className="testimonial-name">{testimonials[currentTestimonial].name}</span>
              <span className="testimonial-role">{testimonials[currentTestimonial].role}</span>
            </div>
          </div>
          <div className="testimonial-controls">
            {testimonials.map((testimonial, index) => (
              <button
                key={testimonial.name}
                className={index === currentTestimonial ? "dot active" : "dot"}
                onClick={() => goToTestimonial(index)}
                aria-label={`Show testimonial from ${testimonial.name}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="team-section" id="team">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">Leadership</span>
            <h2>Seasoned strategists, designers, and technologists aligned to your mission.</h2>
          </div>
          <div className="team-grid">
            {teamMembers.map((member) => (
              <article className="team-card" key={member.name}>
                <div className="team-image">
                  <img src={member.image} alt={`${member.name} - ${member.role}`} loading="lazy" />
                </div>
                <div className="team-info">
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="projects-section" id="projects">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">Case studies</span>
            <h2>Scaling impact across industries and customer ecosystems.</h2>
          </div>
          <div className="project-filters">
            {categories.map((category) => (
              <button
                key={category}
                className={activeCategory === category ? "filter-btn active" : "filter-btn"}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="project-grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.title}>
                <div className="project-image">
                  <img src={project.image} alt={`${project.title} project showcase`} loading="lazy" />
                </div>
                <div className="project-content">
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/contact" className="project-link">
                    Discuss similar outcomes →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq-section" id="faq">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">FAQ</span>
            <h2>Your questions, answered.</h2>
          </div>
          <div className="faq-grid">
            {faqItems.map((item, index) => (
              <div className={`faq-item ${activeFaq === index ? "open" : ""}`} key={item.question}>
                <button
                  className="faq-question"
                  onClick={() => setActiveFaq(activeFaq === index ? -1 : index)}
                  aria-expanded={activeFaq === index}
                >
                  {item.question}
                  <span className="faq-icon">{activeFaq === index ? "−" : "+"}</span>
                </button>
                <div className="faq-answer">
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="blog-section" id="blog">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">Insights</span>
            <h2>Latest perspectives from our strategy desk.</h2>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.title}>
                <div className="blog-image">
                  <img src={post.image} alt={`${post.title} insight`} loading="lazy" />
                </div>
                <div className="blog-content">
                  <span className="blog-date">{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/contact" className="blog-link">
                    Request full report →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-card">
          <div>
            <span className="eyebrow">Ready to accelerate?</span>
            <h2>Let’s architect the next era of growth together.</h2>
            <p>
              Partner with ApexVision Consulting to ignite transformation that balances bold innovation with measurable,
              sustainable results.
            </p>
          </div>
          <Link to="/contact" className="btn btn-primary">
            Start the Conversation
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;