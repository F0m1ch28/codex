import React from "react";

const About = () => {
  const values = [
    {
      title: "Purpose with Precision",
      description: "We convert big-picture vision into executable roadmaps backed by data, empathy, and unwavering rigor.",
    },
    {
      title: "Co-Creation",
      description: "We embed with your teams, fostering knowledge transfer and lasting capabilities that outlive engagements.",
    },
    {
      title: "Impact First",
      description: "Outcomes drive every decision. We measure success by the momentum and value we unlock together.",
    },
  ];

  const leaders = [
    {
      name: "Amelia Brooks",
      role: "Founder & Chief Strategist",
      image: "https://picsum.photos/400/400?random=113",
      statement:
        "Amelia founded ApexVision to help organizations reimagine value creation and future-fit leadership at scale.",
    },
    {
      name: "Luca Romano",
      role: "Head of Experience Design",
      image: "https://picsum.photos/400/400?random=114",
      statement:
        "Luca orchestrates brand, product, and service ecosystems that elevate customer impact from first touch to renewal.",
    },
    {
      name: "Zara Mitchell",
      role: "Director of Transformation",
      image: "https://picsum.photos/400/400?random=115",
      statement:
        "Zara ensures transformation programs stay resilient, inclusive, and measurable across global workforces.",
    },
  ];

  return (
    <div className="about-page">
      <section className="sub-hero">
        <div className="container sub-hero-grid">
          <div>
            <span className="eyebrow">About ApexVision Consulting</span>
            <h1>We unite strategy, creativity, and technology to accelerate what’s next.</h1>
            <p>
              ApexVision Consulting is a collective of strategists, technologists, designers, and human-centered change
              leaders. Together, we co-create transformative experiences that align purpose with performance.
            </p>
          </div>
          <div className="sub-hero-image">
            <img
              src="https://picsum.photos/800/600?random=102"
              alt="ApexVision consulting workshop session"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="mission-section">
        <div className="container mission-grid">
          <div>
            <span className="eyebrow">Our mission</span>
            <h2>Ignite inclusive innovation and measurable growth, everywhere.</h2>
          </div>
          <p>
            We believe the next generation of market leaders will harmonize human insight with intelligent technology. Our
            mission is to empower bold organizations with the tools, talent, and trust to deliver meaningful change—at
            pace, and with integrity. Our teams have guided transformations across finance, retail, healthcare, and
            emerging digital ecosystems in 26 countries.
          </p>
        </div>
      </section>

      <section className="values-section">
        <div className="container values-grid">
          {values.map((value) => (
            <div className="value-card" key={value.title}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="team-section">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">Leadership</span>
            <h2>Global experts with a shared commitment to progress.</h2>
          </div>
          <div className="team-grid">
            {leaders.map((leader) => (
              <article className="team-card" key={leader.name}>
                <div className="team-image">
                  <img src={leader.image} alt={`${leader.name} portrait`} loading="lazy" />
                </div>
                <div className="team-info">
                  <h3>{leader.name}</h3>
                  <span>{leader.role}</span>
                  <p>{leader.statement}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="culture-section">
        <div className="container culture-grid">
          <div>
            <h2>Our culture thrives on curiosity, empathy, and bold experimentation.</h2>
            <p>
              We cultivate multidisciplinary teams that embrace learning loops, design thinking, and inclusive collaboration.
              Every engagement is an opportunity to elevate our clients and empower our people to do their best work.
            </p>
          </div>
          <ul className="culture-highlights">
            <li>Dedicated innovation labs exploring AI, Web3, and climate-positive operations.</li>
            <li>Equity and inclusion programs embedded in every engagement framework.</li>
            <li>Global partner ecosystem spanning research, venture studios, and digital platforms.</li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default About;