import React, { useState } from "react";

const initialFormState = {
  name: "",
  email: "",
  company: "",
  message: "",
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("");

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Please enter your full name.";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Please provide a valid email.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = "Please provide a valid email address.";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Tell us more about your goals or challenges.";
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validateForm();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setStatus("Thank you! Our team will reach out within 24 hours.");
      setFormData(initialFormState);
    } else {
      setStatus("");
    }
  };

  return (
    <div className="contact-page">
      <section className="sub-hero">
        <div className="container sub-hero-grid">
          <div>
            <span className="eyebrow">Contact</span>
            <h1>Let’s build momentum together.</h1>
            <p>
              Share your transformation goals, challenges, or bold ideas. We’ll coordinate a tailored discovery session
              with the right ApexVision experts.
            </p>
          </div>
        </div>
      </section>

      <section className="contact-section">
        <div className="container contact-grid">
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="name">Full name</label>
              <input
                type="text"
                id="name"
                name="name"
                placeholder="Alex Morgan"
                value={formData.name}
                onChange={handleChange}
              />
              {errors.name && <span className="error-message">{errors.name}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="email">Work email</label>
              <input
                type="email"
                id="email"
                name="email"
                placeholder="alex@company.com"
                value={formData.email}
                onChange={handleChange}
              />
              {errors.email && <span className="error-message">{errors.email}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="company">Company</label>
              <input
                type="text"
                id="company"
                name="company"
                placeholder="Organization name"
                value={formData.company}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label htmlFor="message">How can we help?</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                placeholder="Describe your opportunity, challenge, or project timeline."
                value={formData.message}
                onChange={handleChange}
              />
              {errors.message && <span className="error-message">{errors.message}</span>}
            </div>

            <button type="submit" className="btn btn-primary">
              Submit Inquiry
            </button>
            {status && <p className="form-status">{status}</p>}
          </form>

          <div className="contact-details">
            <div className="contact-card">
              <h3>Global HQ</h3>
              <p>
                1200 Innovation Drive<br />
                New York, NY 10012
              </p>
              <p>+1 (212) 555-0198</p>
            </div>
            <div className="contact-card">
              <h3>Email</h3>
              <a href="mailto:hello@apexvisionconsulting.com">hello@apexvisionconsulting.com</a>
            </div>
            <div className="contact-card">
              <h3>Office Hours</h3>
              <p>Monday – Friday: 8:30 AM – 6:00 PM EST</p>
              <p>Virtual sessions by appointment worldwide.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;