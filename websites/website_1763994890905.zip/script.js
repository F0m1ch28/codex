document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.getElementById('menuToggle');
    const navMenu = document.getElementById('navMenu');

    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', () => {
            navMenu.classList.toggle('activo');
            menuToggle.setAttribute('aria-expanded', navMenu.classList.contains('activo'));
        });

        document.addEventListener('click', (event) => {
            if (!navMenu.contains(event.target) && !menuToggle.contains(event.target)) {
                navMenu.classList.remove('activo');
                menuToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    const bannerCookies = document.querySelector('.banner-cookies');
    const aceptarCookies = document.getElementById('aceptarCookies');
    const rechazarCookies = document.getElementById('rechazarCookies');

    if (bannerCookies && aceptarCookies && rechazarCookies) {
        const estadoCookies = localStorage.getItem('svPreferenciaCookies');

        if (estadoCookies === 'aceptadas' || estadoCookies === 'rechazadas') {
            bannerCookies.classList.add('oculto');
        }

        aceptarCookies.addEventListener('click', () => {
            localStorage.setItem('svPreferenciaCookies', 'aceptadas');
            bannerCookies.classList.add('oculto');
        });

        rechazarCookies.addEventListener('click', () => {
            localStorage.setItem('svPreferenciaCookies', 'rechazadas');
            bannerCookies.classList.add('oculto');
        });
    }
});