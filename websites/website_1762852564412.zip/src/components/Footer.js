import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={styles.container}>
        <div className={styles.brand}>
          <h2 id="footer-heading">FamilienFinanz Akademie</h2>
          <p>
            Stärken Sie die finanzielle Zukunft Ihrer Familie mit strukturierten Lernpfaden, praxisnahen Werkzeugen und persönlicher Begleitung.
          </p>
          <div className={styles.socials} aria-label="Soziale Medien">
            <a href="https://www.linkedin.com/company/familienfinanz-akademie" target="_blank" rel="noopener noreferrer">
              LinkedIn
            </a>
            <a href="https://www.xing.com/company/familienfinanz-akademie" target="_blank" rel="noopener noreferrer">
              Xing
            </a>
            <a href="https://www.facebook.com/familienfinanz-akademie" target="_blank" rel="noopener noreferrer">
              Facebook
            </a>
          </div>
        </div>

        <div className={styles.links}>
          <h3>Schnelle Navigation</h3>
          <ul>
            <li><Link to="/">Startseite</Link></li>
            <li><Link to="/ueber-uns">Über uns</Link></li>
            <li><Link to="/kurse">Kurse</Link></li>
            <li><Link to="/programm">Programm</Link></li>
            <li><Link to="/experten">Experten</Link></li>
            <li><Link to="/kontakt">Kontakt</Link></li>
          </ul>
        </div>

        <div className={styles.contact}>
          <h3>Kontakt</h3>
          <p>Friedrichstraße 95<br />10117 Berlin, Deutschland</p>
          <p>Telefon: <a href="tel:+493098765432">+49 30 9876 5432</a></p>
          <p>E-Mail: <a href="mailto:kontakt@finanzplaner-familie.de">kontakt@finanzplaner-familie.de</a></p>
        </div>

        <div className={styles.legal}>
          <h3>Rechtliches</h3>
          <ul>
            <li><Link to="/agb">AGB</Link></li>
            <li><Link to="/datenschutz">Datenschutz</Link></li>
            <li><a href="https://www.finanzplaner-familie.de/impressum" target="_blank" rel="noopener noreferrer">Impressum</a></li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>&copy; {new Date().getFullYear()} FamilienFinanz Akademie. Alle Rechte vorbehalten.</p>
      </div>
    </footer>
  );
};

export default Footer;