import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 24);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} aria-label="Hauptnavigation">
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="FamilienFinanz Akademie Startseite">
          <span className={styles.logoAccent}>FamilienFinanz</span> Akademie
        </Link>
        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Hauptmenü">
          <NavLink to="/" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Start
          </NavLink>
          <NavLink to="/ueber-uns" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Über uns
          </NavLink>
          <NavLink to="/kurse" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Kurse
          </NavLink>
          <NavLink to="/programm" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Programm
          </NavLink>
          <NavLink to="/experten" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Experten
          </NavLink>
          <NavLink to="/kontakt" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Kontakt
          </NavLink>
        </nav>
        <button
          className={`${styles.menuToggle} ${menuOpen ? styles.open : ''}`}
          onClick={toggleMenu}
          aria-label="Menü umschalten"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;