import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('ffa_cookieConsent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('ffa_cookieConsent', 'accepted');
    setVisible(false);
  };

  const declineCookies = () => {
    localStorage.setItem('ffa_cookieConsent', 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Wir verwenden Cookies, um Ihr Lernerlebnis zu verbessern und anonyme Nutzungsstatistiken zu erheben. Ihre Daten bleiben geschützt.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={acceptCookies} className={styles.accept}>
            Akzeptieren
          </button>
          <button type="button" onClick={declineCookies} className={styles.decline}>
            Ablehnen
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;