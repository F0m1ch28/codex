import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Über uns | FamilienFinanz Akademie Berlin</title>
        <meta
          name="description"
          content="Lernen Sie die FamilienFinanz Akademie kennen: Geschichte, Mission, Expertenteam und Lernphilosophie für nachhaltiges Finanzmanagement von Familien in Deutschland."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.text}>
          <span className={styles.pretitle}>Über die Akademie</span>
          <h1>Unsere Mission: Finanzklarheit für jede Familie</h1>
          <p>
            Seit unserer Gründung in Berlin begleiten wir Familien dabei, finanzielle Verantwortung gemeinsam zu gestalten. Die FamilienFinanz Akademie verbindet fundiertes Know-how mit einem empathischen Verständnis für Familienrealitäten.
          </p>
        </div>
        <div className={styles.image}>
          <img
            src="https://picsum.photos/900/600?random=108"
            alt="Team der FamilienFinanz Akademie bei einem Workshop"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.story}>
        <h2>Wie alles begann</h2>
        <div className={styles.timeline}>
          <article>
            <span className={styles.year}>2017</span>
            <h3>Gründung in Berlin</h3>
            <p>
              Unsere Gründerin Jana Hoffmann initiierte die Akademie, nachdem sie in der Finanzberatung immer wieder sah, wie Familien nach verständlichen Lernformaten suchten.
            </p>
          </article>
          <article>
            <span className={styles.year}>2019</span>
            <h3>Erste Online-Module</h3>
            <p>
              Die Nachfrage nach flexiblen Angeboten stieg. Wir entwickelten digitale Lernpfade, die praxisnahe Inhalte mit Live-Austausch kombinierten.
            </p>
          </article>
          <article>
            <span className={styles.year}>2022</span>
            <h3>Deutschlandweite Community</h3>
            <p>
              Mit neuen Kursserien zu Budgetplanung, Sparzielen und Finanztools wuchs unsere Community stark. Wir ergänzten Coaching-Optionen und regionale Events.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.mission}>
        <div>
          <h2>Unsere Werte</h2>
          <p>
            Wir wollen Familien befähigen, finanzielle Entscheidungen souverän und gemeinsam zu treffen. Dazu schaffen wir Lernangebote, die klar strukturiert, alltagstauglich und empathisch gestaltet sind.
          </p>
          <ul>
            <li><strong>Transparenz:</strong> Verständliche Inhalte, klare Abläufe, nachvollziehbare Ergebnisse.</li>
            <li><strong>Empathie:</strong> Wir hören zu und passen Lernpfade an echte Familienrealitäten an.</li>
            <li><strong>Wirksamkeit:</strong> Fokus auf messbare Fortschritte und nachhaltige Routinen.</li>
          </ul>
        </div>
        <div className={styles.method}>
          <h2>Unsere Methodik</h2>
          <p>
            Bei der Entwicklung unserer Kurse kombinieren wir Didaktik, Finanzexpertise und technische Kompetenz. Jedes Modul folgt einem klaren Ablauf:
          </p>
          <ol>
            <li>Analyse des Ausgangspunkts und Definition der Lernziele</li>
            <li>Vermittlung von Wissen über Videos, Lesematerialien und interaktive Aufgaben</li>
            <li>Praxisanwendung mit Worksheets, Templates und Tool-Guides</li>
            <li>Feedback-Schleifen, Q&A und Progress Tracking</li>
          </ol>
        </div>
      </section>

      <section className={styles.impact}>
        <div className={styles.impactText}>
          <h2>Was uns auszeichnet</h2>
          <p>
            Wir begleiten Familien unabhängig von Einkommen, Beruf oder Familienform. Unser Fokus liegt auf Struktur und Klarheit, nicht auf schnellen Versprechen. Wir forschen kontinuierlich zu Finanzbildungsthemen und pflegen Kooperationen mit Bildungsinitiativen.
          </p>
        </div>
        <div className={styles.impactStats}>
          <div>
            <span>87%</span>
            <p>haben innerhalb von drei Monaten ein funktionierendes Haushaltsbuch etabliert.</p>
          </div>
          <div>
            <span>76%</span>
            <p>konnten ihre Sparziele definieren und visualisieren.</p>
          </div>
          <div>
            <span>62%</span>
            <p>nutzen unsere Finanztools-Vorlagen für regelmäßige Review-Meetings.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;