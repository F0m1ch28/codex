import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Familien begleitet', value: 520 },
  { label: 'Zufriedenheitsrate', value: 98, suffix: '%' },
  { label: 'Praxisübungen', value: 180 },
  { label: 'Workshops pro Jahr', value: 42 }
];

const testimonials = [
  {
    quote: 'Die Akademie hat uns geholfen, klare Ziele zu formulieren und unsere Ausgaben strukturiert zu planen. Unser Haushaltsbuch ist jetzt ein echtes Steuerungsinstrument.',
    name: 'Familie Sommer',
    role: 'Eltern von zwei Kindern',
    location: 'Berlin'
  },
  {
    quote: 'Dank der Werkzeuge und Checklisten verstehen wir unsere Zahlen viel besser. Wir treffen Entscheidungen jetzt viel selbstbewusster.',
    name: 'Lena & Markus Weber',
    role: 'Patchwork-Familie',
    location: 'Hamburg'
  },
  {
    quote: 'Der Mix aus Lernvideos, Live-Sessions und persönlichem Feedback ist genau das, was uns gefehlt hat. Besonders die Modulstruktur überzeugt.',
    name: 'Familie Schuster',
    role: 'Angestellte Eltern',
    location: 'München'
  }
];

const faqItems = [
  {
    question: 'Für wen ist die FamilienFinanz Akademie geeignet?',
    answer: 'Unsere Programme richten sich an Familien, Paare und Alleinerziehende, die ihre Finanzen strukturiert organisieren möchten. Sowohl Einsteiger als auch Fortgeschrittene profitieren von klaren Lernpfaden und praktischen Aufgaben.'
  },
  {
    question: 'Wie viel Zeit sollte pro Woche eingeplant werden?',
    answer: 'Die Module sind flexibel angelegt. Durchschnittlich empfehlen wir 2 bis 3 Stunden pro Woche für Videos, Arbeitsblätter und die Umsetzung im Alltag.'
  },
  {
    question: 'Welche Materialien stehen zur Verfügung?',
    answer: 'Sie erhalten Leitfäden, Budget-Vorlagen, Checklisten, Zugang zu Tools, Live-Sessions sowie Feedback unserer Finanzexpertinnen und -experten.'
  },
  {
    question: 'Gibt es persönliche Unterstützung?',
    answer: 'Ja. Unsere Expertinnen und Experten stehen Ihnen in den Q&A-Sprechstunden zur Verfügung. Zusätzlich können individuelle Coaching-Slots gebucht werden.'
  }
];

const blogPosts = [
  {
    id: 1,
    title: '5 Schritte zur transparenten Familienkasse',
    excerpt: 'So bringen Sie Ordnung in Einnahmen, Fixkosten und flexible Ausgaben – inklusive Wochenplan.',
    date: '12. März 2024'
  },
  {
    id: 2,
    title: 'Sparen für gemeinsame Ziele organisieren',
    excerpt: 'Wie Sie Meilensteine definieren, Prioritäten setzen und eine nachhaltige Sparroutine etablieren.',
    date: '28. Februar 2024'
  },
  {
    id: 3,
    title: 'Digitale Finanztools im Vergleich',
    excerpt: 'Welche Apps unterstützen Haushaltsbuch, Planungsübersicht und Reporting am effektivsten?',
    date: '07. Februar 2024'
  }
];

const projectItems = [
  {
    id: 1,
    title: 'Familienbudget Reloaded',
    category: 'Budgetierung',
    description: 'Intensiv-Workshop mit Fokus auf variablen Ausgaben, Deckelungsstrategien und Monatsabschluss.',
    image: 'https://picsum.photos/1200/800?random=104',
    alt: 'Familie, die gemeinsam ein Tablet mit Budgetplan betrachtet'
  },
  {
    id: 2,
    title: 'Zukunftsplan Familie',
    category: 'Finanzplanung',
    description: 'Modularer Fahrplan für Notgroschen, Bildung und Ruhestand mit Szenario-Simulationen.',
    image: 'https://picsum.photos/1200/800?random=105',
    alt: 'Illustration eines Finanzplans mit Markierungen und Diagrammen'
  },
  {
    id: 3,
    title: 'Toolbox Smart Finance',
    category: 'Finanztools',
    description: 'Vergleich digitaler Plattformen, automatisierte Abgleiche und Reporting-Dashboards.',
    image: 'https://picsum.photos/1200/800?random=106',
    alt: 'Laptop mit Finanz-Dashboard und Kennzahlen'
  },
  {
    id: 4,
    title: 'Sparziele im Alltag',
    category: 'Budgetierung',
    description: 'Gemeinsame Planung von Familienzielen mit kreativen Methoden für Motivation und Controlling.',
    image: 'https://picsum.photos/1200/800?random=107',
    alt: 'Notizbuch mit Sparzielen und Marker'
  }
];

const Home = () => {
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Alle');
  const [openFaq, setOpenFaq] = useState(0);

  useEffect(() => {
    const intervals = statsData.map((stat, index) =>
      setInterval(() => {
        setStats((prev) => {
          const updated = [...prev];
          const target = stat.value;
          if (updated[index] < target) {
            const increment = Math.ceil(target / 60);
            updated[index] = Math.min(updated[index] + increment, target);
          }
          return updated;
        });
      }, 40)
    );
    return () => intervals.forEach((interval) => clearInterval(interval));
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    activeCategory === 'Alle'
      ? projectItems
      : projectItems.filter((item) => item.category === activeCategory);

  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'EducationalOrganization',
    name: 'FamilienFinanz Akademie',
    description:
      'Online-Bildungsplattform für Familienfinanzen, Budgetierung und Finanzplanung in Deutschland.',
    url: 'https://finanzplaner-familie.de',
    logo: 'https://finanzplaner-familie.de/logo.png',
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Friedrichstraße 95',
      addressLocality: 'Berlin',
      postalCode: '10117',
      addressCountry: 'DE'
    },
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: '+49-30-9876-5432',
      contactType: 'customer support',
      areaServed: 'DE'
    },
    sameAs: [
      'https://www.linkedin.com/company/familienfinanz-akademie',
      'https://www.xing.com/company/familienfinanz-akademie'
    ]
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>FamilienFinanz Akademie | Finanzwissen für Familien in Deutschland</title>
        <meta
          name="description"
          content="Lernen Sie Budgetierung, Finanzplanung und Finanztools mit der FamilienFinanz Akademie. Praxisorientierte Online-Kurse, Expertenwissen und messbare Ergebnisse für Familien."
        />
        <script type="application/ld+json">{JSON.stringify(structuredData)}</script>
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroImage} role="img" aria-label="Familie plant Finanzen am Esstisch">
          <img
            src="https://picsum.photos/1600/900?random=101"
            alt="Familie arbeitet gemeinsam an einem Finanzplan am Tisch"
            loading="lazy"
          />
        </div>
        <div className={styles.heroContent}>
          <span className={styles.pretitle}>FamilienFinanz Akademie</span>
          <h1>Ihre finanzielle Zukunft beginnt hier</h1>
          <p>
            Wir begleiten Familien in Deutschland auf dem Weg zu klaren Budgets, planbaren Sparzielen und transparenten finanziellen Entscheidungen. Mit modularen Online-Kursen, Werkzeugen und persönlichem Feedback bringen Sie Struktur in jede Lebensphase.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kurse" className={styles.primaryCta}>
              Jetzt Kursübersicht ansehen
            </Link>
            <Link to="/programm" className={styles.secondaryCta}>
              Programm entdecken
            </Link>
          </div>
          <div className={styles.heroStats} aria-label="Erfolgskennzahlen">
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.heroStat}>
                <span className={styles.statValue}>
                  {stats[index]}
                  {stat.suffix || ''}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.intro}>
        <div className={styles.introText}>
          <h2>Finanzwissen, das in Ihren Alltag passt</h2>
          <p>
            Wir verbinden fundierte Finanzbildung mit einem modernen Lernkonzept. Digitale Module, Live-Sessions, Vorlagen und interaktive Aufgaben ermöglichen Ihnen, Wissen direkt anzuwenden – flexibel und messbar.
          </p>
          <div className={styles.highlights}>
            <div>
              <h3>Praxisorientiert</h3>
              <p>Alle Inhalte entstehen gemeinsam mit Familien und Finanzexpertinnen. Ihr Alltag steht im Mittelpunkt.</p>
            </div>
            <div>
              <h3>Modular und flexibel</h3>
              <p>Sie entscheiden, wann und wo Sie lernen. Unsere Micro-Learnings lassen sich leicht in Kalender und Routinen integrieren.</p>
            </div>
            <div>
              <h3>Nachhaltige Umsetzung</h3>
              <p>Mit Checklisten, Review-Terminen und Dashboard-Vorlagen bleibt Ihr Finanzsystem langfristig stabil.</p>
            </div>
          </div>
        </div>
        <div className={styles.introImage}>
          <img
            src="https://picsum.photos/800/600?random=102"
            alt="Finanzunterlagen und Laptop auf einem Schreibtisch"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.services} id="services">
        <div className={styles.sectionHeader}>
          <span className={styles.pretitle}>Unsere Kursschwerpunkte</span>
          <h2>Gezielt lernen, was Familien weiterbringt</h2>
          <p>
            Jedes Modul basiert auf aktuellen Erkenntnissen und Best Practices für Haushaltsplanung, Sparziele und digitale Werkzeuge.
          </p>
        </div>
        <div className={styles.serviceGrid}>
          <article className={styles.serviceCard}>
            <h3>Budgetierung & Haushaltsbuch</h3>
            <p>
              Lernen Sie, Einnahmen, Fixkosten und flexible Budgets zu strukturieren. Sie erhalten Vorlagen, tägliche Routinen und Monatsrückblicke.
            </p>
            <ul>
              <li>Analyse Ihrer Ausgangssituation</li>
              <li>Digitale Haushaltsbuch-Tools im Vergleich</li>
              <li>Review-Methoden für Monatsabschlüsse</li>
            </ul>
            <Link to="/kurse" className={styles.moreLink}>
              Mehr zu Budgetierung
            </Link>
          </article>
          <article className={styles.serviceCard}>
            <h3>Ganzheitliche Finanzplanung</h3>
            <p>
              Wir zeigen Ihnen, wie Sie kurzfristige und langfristige Ziele kombinieren, Puffer aufbauen und Familienziele realistisch planen.
            </p>
            <ul>
              <li>Zieldefinition und Priorisierung</li>
              <li>Strategien für Bildung, Vorsorge und Sicherheit</li>
              <li>Szenario-Planung für verschiedene Lebensphasen</li>
            </ul>
            <Link to="/programm" className={styles.moreLink}>
              Programm ansehen
            </Link>
          </article>
          <article className={styles.serviceCard}>
            <h3>Finanztools & Software</h3>
            <p>
              Wir führen Sie durch kompatible Tools für Haushaltsbuch, Forecasting und Reporting – inklusive konkreter Setups.
            </p>
            <ul>
              <li>Toolchecks und Entscheidungsbaum</li>
              <li>Integration automatisierter Workflows</li>
              <li>Dashboards zur Auswertung im Alltag</li>
            </ul>
            <Link to="/kurse" className={styles.moreLink}>
              Tool-Lernpfad entdecken
            </Link>
          </article>
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <span className={styles.pretitle}>So funktioniert es</span>
          <h2>Strukturierte Lernpfade für nachhaltige Ergebnisse</h2>
        </div>
        <div className={styles.processGrid}>
          <div className={styles.processStep}>
            <span>01</span>
            <h3>Analyse & Zieldefinition</h3>
            <p>Wir starten mit einer Standortbestimmung und definieren realistische Ziele, die zu Ihrer Lebenssituation passen.</p>
          </div>
          <div className={styles.processStep}>
            <span>02</span>
            <h3>Lernmodule & Praxisaufgaben</h3>
            <p>In strukturierten Modulen kombinieren wir Videos, Worksheets und Übungen, die Sie direkt im Alltag anwenden.</p>
          </div>
          <div className={styles.processStep}>
            <span>03</span>
            <h3>Live-Sessions & Feedback</h3>
            <p>Unsere Expertinnen begleiten Sie in Live-Q&As, geben Feedback zu Ihrem Fortschritt und beantworten individuelle Fragen.</p>
          </div>
          <div className={styles.processStep}>
            <span>04</span>
            <h3>Monitoring & Weiterentwicklung</h3>
            <p>Mit regelmäßigen Reviews, Reportings und optionalen Coachings bleibt Ihr Finanzsystem dauerhaft stabil.</p>
          </div>
        </div>
      </section>

      <section className={styles.why}>
        <div className={styles.sectionHeader}>
          <span className={styles.pretitle}>Warum FamilienFinanz?</span>
          <h2>Verlässliche Begleitung und messbare Ergebnisse</h2>
        </div>
        <div className={styles.whyGrid}>
          <div>
            <h3>Deutschlands Familienfokus</h3>
            <p>Wir denken in Familienrollen, Verantwortlichkeiten und Lebensabschnitten. Unsere Inhalte entstehen aus echten Familienprojekten.</p>
          </div>
          <div>
            <h3>Erfahrenes Expertenteam</h3>
            <p>Finanzplanerinnen, Coaches und Pädagoginnen entwickeln gemeinsam Lernpfade, die leicht verständlich und wirkungsvoll sind.</p>
          </div>
          <div>
            <h3>Transparente Lernfortschritte</h3>
            <p>Dashboards zeigen Ihren Status, erledigte Aufgaben und nächste Schritte. Sie behalten Überblick und Motivation.</p>
          </div>
          <div>
            <h3>Community & Austausch</h3>
            <p>In moderierten Gruppen tauschen Sie Erfahrungen aus, erhalten zusätzliche Impulse und bleiben langfristig dran.</p>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <span className={styles.pretitle}>Stimmen unserer Teilnehmerinnen und Teilnehmer</span>
          <h2>Persönliche Erfahrungen mit der Akademie</h2>
        </div>
        <div className={styles.testimonialWrapper}>
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.name}
              className={`${styles.testimonialCard} ${index === activeTestimonial ? styles.active : ''}`}
              role="group"
              aria-roledescription="Testimonial"
              aria-hidden={index !== activeTestimonial}
            >
              <p className={styles.quote}>&ldquo;{testimonial.quote}&rdquo;</p>
              <div className={styles.person}>
                <span className={styles.name}>{testimonial.name}</span>
                <span className={styles.role}>{testimonial.role}</span>
                <span className={styles.location}>{testimonial.location}</span>
              </div>
            </article>
          ))}
        </div>
        <div className={styles.dots} role="tablist">
          {testimonials.map((_, index) => (
            <button
              key={index}
              className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
              onClick={() => setActiveTestimonial(index)}
              aria-label={`Testimonial ${index + 1}`}
              aria-selected={index === activeTestimonial}
            />
          ))}
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.sectionHeader}>
          <span className={styles.pretitle}>Projekte & Lernpfade</span>
          <h2>Erprobte Formate für Ihren Finanzalltag</h2>
        </div>
        <div className={styles.filters} role="tablist" aria-label="Kategorien filtern">
          {['Alle', 'Budgetierung', 'Finanzplanung', 'Finanztools'].map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`${styles.filterButton} ${activeCategory === category ? styles.filterActive : ''}`}
              aria-pressed={activeCategory === category}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <div className={styles.projectImage}>
                <img src={project.image} alt={project.alt} loading="lazy" />
              </div>
              <div className={styles.projectContent}>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <Link to="/programm" className={styles.moreLink}>
                  Details im Programm
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.sectionHeader}>
          <span className={styles.pretitle}>FAQ</span>
          <h2>Antworten auf häufige Fragen</h2>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <div key={item.question} className={styles.faqItem}>
              <button
                className={styles.faqQuestion}
                onClick={() => setOpenFaq((prev) => (prev === index ? -1 : index))}
                aria-expanded={openFaq === index}
              >
                <span>{item.question}</span>
                <span>{openFaq === index ? '−' : '+'}</span>
              </button>
              {openFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blog}>
        <div className={styles.sectionHeader}>
          <span className={styles.pretitle}>Aktuelles aus der Akademie</span>
          <h2>Blog & Insights</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.id} className={styles.blogCard}>
              <span className={styles.blogDate}>{post.date}</span>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <a
                href="https://www.finanzplaner-familie.de/blog"
                target="_blank"
                rel="noopener noreferrer"
                className={styles.moreLink}
              >
                Beitrag lesen
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Bereit für Ihr strukturiertes Finanzsystem?</h2>
          <p>
            Buchen Sie Ihren Platz in der FamilienFinanz Akademie und starten Sie mit einer umfassenden Analyse, klaren Lernpfaden und persönlicher Begleitung.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakt" className={styles.primaryCta}>
              Beratungsgespräch vereinbaren
            </Link>
            <Link to="/kurse" className={styles.secondaryCta}>
              Kursportfolio ansehen
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;