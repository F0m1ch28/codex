import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programm.module.css';

const modules = [
  {
    title: 'Kick-off & Analyse',
    items: [
      'Finanz-Checkup mit strukturierten Fragebögen',
      'Definition Ihrer Familienziele und Prioritäten',
      'Etablierung eines gemeinsamen Kommunikationsrahmens'
    ]
  },
  {
    title: 'Budget-Design & Umsetzung',
    items: [
      'Aufbau eines Haushaltsbuchs mit digitalem Template',
      'Einführung von Budgetregeln und Kontrollmechanismen',
      'Routineplan für Wochen- und Monatsabstimmungen'
    ]
  },
  {
    title: 'Sparziele & Rücklagen',
    items: [
      'Definition von Sparzielen und Zeitplänen',
      'Strategien für automatisierte Einzahlungen',
      'Visualisierung von Fortschritten zur Motivation'
    ]
  },
  {
    title: 'Finanztools & Automation',
    items: [
      'Toolauswahl basierend auf Ihren Anforderungen',
      'Integration von Banking, Dokumenten und Planungssoftware',
      'Automatisierte Alerts, Reports und Dashboards'
    ]
  }
];

const Programm = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Programmstruktur | FamilienFinanz Akademie</title>
        <meta
          name="description"
          content="Lernen Sie die Programmstruktur der FamilienFinanz Akademie kennen: Module, Dauer, Praxisübungen und Zertifikate für nachhaltiges Finanzmanagement."
        />
      </Helmet>

      <section className={styles.hero}>
        <span className={styles.pretitle}>Programmstruktur</span>
        <h1>Ihr roter Faden durch alle Finanzthemen</h1>
        <p>
          Unser Programm führt Sie Schritt für Schritt durch Analyse, Umsetzung und Stabilisierung Ihrer Familienfinanzen. Modulare Inhalte lassen sich kombinieren, verlängern oder vertiefen – je nach Bedarf.
        </p>
      </section>

      <section className={styles.structure}>
        <div className={styles.timeline}>
          {modules.map((module) => (
            <article key={module.title}>
              <h2>{module.title}</h2>
              <ul>
                {module.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
        <aside className={styles.info}>
          <h3>Rahmenbedingungen</h3>
          <ul>
            <li><strong>Lernzeit:</strong> 30 bis 45 Minuten pro Lerneinheit</li>
            <li><strong>Live-Sessions:</strong> Zwei Q&A-Termine pro Modul</li>
            <li><strong>Praxisaufgaben:</strong> Worksheets, Templates, Tool-Setups</li>
            <li><strong>Feedback:</strong> Individuelle Rückmeldungen innerhalb von 48 Stunden</li>
            <li><strong>Begleitung:</strong> Community-Forum, moderierte Austauschgruppen</li>
            <li><strong>Zertifikat:</strong> Abschlusszertifikat mit dokumentiertem Lernfortschritt</li>
          </ul>
        </aside>
      </section>

      <section className={styles.extras}>
        <div>
          <h2>Praxis & Umsetzung</h2>
          <p>
            Jedes Modul endet mit konkreten Ergebnissen: einem strukturierten Haushaltsbuch, einer Sparziel-Matrix oder einem Dashboard für Review-Meetings. Sie arbeiten mit Templates, die Sie langfristig nutzen können.
          </p>
        </div>
        <div>
          <h2>Transfer in den Alltag</h2>
          <p>
            Mit Reflexionsfragen, Routinen und Erinnerungen sorgen wir dafür, dass Finanzthemen fest im Alltag verankert bleiben. Ihre Familie entwickelt ein gemeinsames Verständnis und klare Verantwortlichkeiten.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Programm;