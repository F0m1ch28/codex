import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Datenschutzerklärung | FamilienFinanz Akademie</title>
        <meta
          name="description"
          content="Datenschutzinformationen der FamilienFinanz Akademie zur Verarbeitung personenbezogener Daten gemäß DSGVO. Transparenz über Zwecke, Rechte und Sicherheitsmaßnahmen."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Datenschutzerklärung</h1>
        <p>Der Schutz Ihrer Daten ist uns wichtig. Nachfolgend informieren wir Sie über Art, Umfang und Zweck der Verarbeitung personenbezogener Daten.</p>
      </section>

      <section className={styles.content}>
        <h2>1. Verantwortliche Stelle</h2>
        <p>FamilienFinanz Akademie<br />Friedrichstraße 95<br />10117 Berlin, Deutschland<br />E-Mail: kontakt@finanzplaner-familie.de<br />Telefon: +49 30 9876 5432</p>

        <h2>2. Erhebung und Verarbeitung</h2>
        <p>
          Wir verarbeiten Daten, die Sie uns freiwillig zur Verfügung stellen (z. B. bei Kontaktanfragen, Kursbuchungen, Newsletter-Anmeldungen). Darüber hinaus erheben wir technisch notwendige Daten beim Besuch der Website (z. B. IP-Adresse, Browsertyp), um die Funktionalität sicherzustellen.
        </p>

        <h2>3. Zwecke und Rechtsgrundlagen</h2>
        <ul>
          <li>Vertragsanbahnung und -durchführung gemäß Art. 6 Abs. 1 lit. b DSGVO</li>
          <li>Erfüllung rechtlicher Verpflichtungen gemäß Art. 6 Abs. 1 lit. c DSGVO</li>
          <li>Wahrung berechtigter Interessen gemäß Art. 6 Abs. 1 lit. f DSGVO (Optimierung des Angebots, Sicherheit)</li>
        </ul>

        <h2>4. Weitergabe von Daten</h2>
        <p>
          Eine Weitergabe an Dritte erfolgt ausschließlich, wenn dies zur Vertragserfüllung notwendig ist (z. B. Zahlungsdienstleister) oder gesetzliche Vorgaben bestehen. Dienstleister werden sorgfältig ausgewählt und vertraglich zur Einhaltung der DSGVO verpflichtet.
        </p>

        <h2>5. Speicherdauer</h2>
        <p>
          Wir speichern personenbezogene Daten nur solange, wie es für den jeweiligen Zweck erforderlich ist oder gesetzliche Aufbewahrungspflichten bestehen. Anschließend werden die Daten gelöscht oder anonymisiert.
        </p>

        <h2>6. Ihre Rechte</h2>
        <p>Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit sowie Widerspruch. Bitte wenden Sie sich an kontakt@finanzplaner-familie.de.</p>

        <h2>7. Cookies & Analyse</h2>
        <p>Wir setzen Cookies ein, um Inhalte nutzerfreundlich zu gestalten. Sie können Cookies über die Einstellungen Ihres Browsers deaktivieren. Details finden Sie in unserem Cookie-Hinweis.</p>

        <h2>8. Datensicherheit</h2>
        <p>Wir verwenden technische und organisatorische Maßnahmen, um Ihre Daten vor Verlust, Manipulation oder unbefugtem Zugriff zu schützen. Unsere Sicherheitsmaßnahmen werden regelmäßig überprüft.</p>

        <h2>9. Änderungen</h2>
        <p>Wir behalten uns vor, diese Datenschutzerklärung anzupassen, um sie an geänderte Rechtslagen oder technische Entwicklungen anzupassen. Bitte informieren Sie sich regelmäßig.</p>
      </section>
    </div>
  );
};

export default Privacy;