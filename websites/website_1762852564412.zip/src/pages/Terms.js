import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Allgemeine Geschäftsbedingungen | FamilienFinanz Akademie</title>
        <meta
          name="description"
          content="Allgemeine Geschäftsbedingungen der FamilienFinanz Akademie. Informationen zu Leistungen, Verträgen, Zahlungsmodalitäten und Haftung."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Allgemeine Geschäftsbedingungen</h1>
        <p>Stand: Januar 2024</p>
      </section>

      <section className={styles.content}>
        <h2>1. Geltungsbereich</h2>
        <p>
          Diese Allgemeinen Geschäftsbedingungen (AGB) gelten für sämtliche Dienstleistungen der FamilienFinanz Akademie, abrufbar über die Website finanzplaner-familie.de. Abweichende Bedingungen werden nicht anerkannt, es sei denn, die FamilienFinanz Akademie stimmt ihnen ausdrücklich schriftlich zu.
        </p>

        <h2>2. Vertragspartner</h2>
        <p>
          Vertragspartner sind die FamilienFinanz Akademie, Friedrichstraße 95, 10117 Berlin, Deutschland, und die jeweiligen Kundinnen und Kunden (nachfolgend „Teilnehmende“).
        </p>

        <h2>3. Leistungsbeschreibung</h2>
        <p>
          Die FamilienFinanz Akademie bietet Online-Kurse, Live-Sessions, Beratungen und digitale Materialien zur Finanzbildung für Familien an. Der genaue Leistungsumfang ergibt sich aus der Kursbeschreibung und individuellen Vereinbarungen.
        </p>

        <h2>4. Anmeldung und Vertragsschluss</h2>
        <p>
          Die Anmeldung erfolgt online oder schriftlich. Mit der Bestätigung durch die FamilienFinanz Akademie kommt der Vertrag zustande. Die Teilnehmenden erhalten Zugangsdaten und Informationen zum Kursstart.
        </p>

        <h2>5. Zahlungsbedingungen</h2>
        <p>
          Kursgebühren sind nach Rechnungsstellung innerhalb von 14 Tagen fällig. Ratenzahlungen können nach individueller Absprache vereinbart werden. Alle Preise verstehen sich inklusive der gesetzlichen Mehrwertsteuer.
        </p>

        <h2>6. Stornierung und Umbuchung</h2>
        <p>
          Stornierungen sind bis 14 Tage vor Kursbeginn kostenfrei möglich. Bei späteren Stornierungen werden 50 % der Kursgebühr fällig. Umbuchungen auf einen anderen Termin sind nach Absprache möglich.
        </p>

        <h2>7. Nutzungsrechte</h2>
        <p>
          Kursunterlagen, Videos und Templates sind urheberrechtlich geschützt. Die Nutzung ist auf den persönlichen Gebrauch der Teilnehmenden beschränkt. Weitergabe und Veröffentlichung sind untersagt.
        </p>

        <h2>8. Haftung</h2>
        <p>
          Die FamilienFinanz Akademie haftet nur für Vorsatz und grobe Fahrlässigkeit. Für mittelbare Schäden, entgangene Vorteile oder Folgeprobleme wird keine Haftung übernommen. Verbindliche Entscheidungen liegen bei den Teilnehmenden.
        </p>

        <h2>9. Änderung von Leistungen</h2>
        <p>
          Inhaltliche Anpassungen, die das Lernziel nicht beeinträchtigen, bleiben vorbehalten. Änderungen werden rechtzeitig kommuniziert.
        </p>

        <h2>10. Datenschutz</h2>
        <p>
          Der Schutz personenbezogener Daten ist uns wichtig. Details finden Sie in unserer <a href="/datenschutz">Datenschutzerklärung</a>.
        </p>

        <h2>11. Schlussbestimmungen</h2>
        <p>
          Es gilt deutsches Recht. Gerichtsstand ist Berlin. Sollten einzelne Bestimmungen unwirksam sein, berührt dies nicht die Wirksamkeit der übrigen Regelungen.
        </p>
      </section>
    </div>
  );
};

export default Terms;