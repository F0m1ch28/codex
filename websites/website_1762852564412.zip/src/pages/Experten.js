import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Experten.module.css';

const experts = [
  {
    name: 'Jana Hoffmann',
    role: 'Finanzplanerin & Gründerin',
    experience: '15 Jahre Erfahrung in Finanzberatung und Familiencoaching',
    focus: 'Budgetarchitektur, Familienkommunikation, Lernkonzepte',
    image: 'https://picsum.photos/400/400?random=201'
  },
  {
    name: 'Dr. Tobias Kramer',
    role: 'Senior Finanzanalyst',
    experience: 'Spezialist für Finanzmodelle und Szenario-Analysen',
    focus: 'Langfristige Planung, Vorsorge, Datenanalyse',
    image: 'https://picsum.photos/400/400?random=202'
  },
  {
    name: 'Nina Berger',
    role: 'Tool- und Software-Coach',
    experience: 'Fachwirtin für Finanzmanagement, zertifizierte Tool-Consultant',
    focus: 'Digitale Finanztools, Automatisierung, Dashboards',
    image: 'https://picsum.photos/400/400?random=203'
  },
  {
    name: 'Michael Adler',
    role: 'Kommunikationscoach',
    experience: 'Familienmediator und Trainer für Entscheidungsprozesse',
    focus: 'Familiengespräche, Zielabstimmung, Routinen',
    image: 'https://picsum.photos/400/400?random=204'
  }
];

const Experten = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Unser Expertenteam | FamilienFinanz Akademie</title>
        <meta
          name="description"
          content="Lernen Sie das Expertenteam der FamilienFinanz Akademie kennen: Finanzplanerinnen, Analysten, Coaches und Tool-Spezialistinnen für Familienfinanzen."
        />
      </Helmet>

      <section className={styles.hero}>
        <span className={styles.pretitle}>Expertenteam</span>
        <h1>Kompetenz, Erfahrung und Herz für Familien</h1>
        <p>
          Unsere Expertinnen und Experten bringen vielfältige Hintergründe aus Finanzplanung, Pädagogik, Coaching und Technologie mit. Gemeinsam entwickeln wir Lernpfade, die fachlich fundiert und gleichzeitig alltagstauglich sind.
        </p>
      </section>

      <section className={styles.grid}>
        {experts.map((expert) => (
          <article key={expert.name} className={styles.card}>
            <div className={styles.image}>
              <img src={expert.image} alt={`Portrait von ${expert.name}`} loading="lazy" />
            </div>
            <div className={styles.content}>
              <h2>{expert.name}</h2>
              <p className={styles.role}>{expert.role}</p>
              <p className={styles.experience}>{expert.experience}</p>
              <p className={styles.focus}><strong>Schwerpunkte:</strong> {expert.focus}</p>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.commitment}>
        <div>
          <h2>Unser Versprechen</h2>
          <p>
            Wir arbeiten eng mit Familien zusammen, hören zu und entwickeln passgenaue Lösungen. Dabei achten wir auf klare Sprache, nachvollziehbare Zahlen und nachhaltige Routinen.
          </p>
        </div>
        <div>
          <h2>Weiterbildung & Qualität</h2>
          <p>
            Unser Team aktualisiert Inhalte regelmäßig, besucht Weiterbildungen und pflegt Kooperationen mit Bildungsinitiativen und Beratungsstellen in Deutschland.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Experten;