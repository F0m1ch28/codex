import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Kurse & Lernpfade | FamilienFinanz Akademie</title>
        <meta
          name="description"
          content="Entdecken Sie die Kurse der FamilienFinanz Akademie: Budgetierung & Haushaltsbuch, Finanzplanung mit Zielen sowie Finanztools & Software. Strukturierte Lernpfade für Familien."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.text}>
          <span className={styles.pretitle}>Kurse</span>
          <h1>Unsere Lernpfade für klare Familienfinanzen</h1>
          <p>
            Jedes Kursformat führt Sie strukturiert von Ihrer Ausgangssituation zu einem belastbaren Finanzsystem. Flexible Lernmodule, praxisnahe Aufgaben und Expert:innen-Feedback sorgen für nachvollziehbare Fortschritte.
          </p>
        </div>
      </section>

      <section className={styles.courseList}>
        <article>
          <div className={styles.tag}>Level 1</div>
          <h2>Budgetierung & Haushaltsbuch</h2>
          <p>
            Dieser Kurs vermittelt das Fundament für eine transparente Familienfinanzplanung. Sie lernen, Einnahmen, Ausgaben und Sparziele übersichtlich abzubilden.
          </p>
          <ul>
            <li>Analyse der aktuellen Finanzstruktur und Ausgabenkategorien</li>
            <li>Einführung in digitale Haushaltsbuch-Tools inkl. Setup-Guides</li>
            <li>Monatliche Review-Routinen und Checklisten für Gespräche im Familienkreis</li>
            <li>Vorlagen für Budgetlimits, variable Ausgabentöpfe und Rücklagen</li>
          </ul>
          <div className={styles.duration}>
            <span>Dauer:</span>
            <strong>6 Wochen, 2 Module pro Woche</strong>
          </div>
        </article>

        <article>
          <div className={styles.tag}>Level 2</div>
          <h2>Finanzplanung für Ziele und Zukunft</h2>
          <p>
            Für Familien, die bereits ein Haushaltsbuch führen und strategisch weiterdenken möchten. Wir verbinden kurzfristige Bedürfnisse mit langfristigen Plänen.
          </p>
          <ul>
            <li>Definition und Priorisierung von Familienzielen mit Meilensteinen</li>
            <li>Aufbau eines Sicherheitspuffers und Planung für Bildung, Mobilität, Ruhestand</li>
            <li>Simulation von Szenarien inkl. Sensitivitätsanalysen</li>
            <li>Kommunikationsleitfäden für Familienentscheidungen</li>
          </ul>
          <div className={styles.duration}>
            <span>Dauer:</span>
            <strong>8 Wochen, inkl. zwei Live-Strategie-Sessions</strong>
          </div>
        </article>

        <article>
          <div className={styles.tag}>Level 3</div>
          <h2>Finanztools & Software effizient nutzen</h2>
          <p>
            Lernen Sie, wie Sie digitale Lösungen optimal einsetzen. Wir analysieren Tools, verknüpfen Datenquellen und etablieren Dashboards für regelmäßiges Monitoring.
          </p>
          <ul>
            <li>Tool-Check für Haushaltsbuch, Planungssoftware und Reporting</li>
            <li>Integrationen mit Banking- und Dokumentenplattformen</li>
            <li>Best Practices für Automatisierung, Erinnerungen und Visualisierung</li>
            <li>Praxis-Workshops und Live-Demos für den individuellen Setup</li>
          </ul>
          <div className={styles.duration}>
            <span>Dauer:</span>
            <strong>5 Wochen, begleitet durch Tool-Coaches</strong>
          </div>
        </article>
      </section>

      <section className={styles.benefits}>
        <div className={styles.sectionHeader}>
          <span className={styles.pretitle}>Ihr Vorteil</span>
          <h2>Was alle Kurse gemeinsam haben</h2>
        </div>
        <div className={styles.benefitGrid}>
          <div>
            <h3>Modulare Videos & Audio-Lektionen</h3>
            <p>Kurze Einheiten, die Sie flexibel in den Alltag integrieren können – mit Transkripten, Arbeitsblättern und Zusammenfassungen.</p>
          </div>
          <div>
            <h3>Interaktive Arbeitsräume</h3>
            <p>Digitale Whiteboards, Worksheets und Vorlagen unterstützen die Umsetzung. Sie behalten den Überblick über Aufgaben und Fortschritte.</p>
          </div>
          <div>
            <h3>Community & Austausch</h3>
            <p>Moderierte Gruppen, Peer-Feedback und monatliche Themencalls sorgen für Motivation und gemeinsames Lernen.</p>
          </div>
          <div>
            <h3>Zertifizierter Abschluss</h3>
            <p>Nach erfolgreichem Abschluss erhalten Sie ein Zertifikat mit dokumentierten Lernergebnissen und Handlungsempfehlungen.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;