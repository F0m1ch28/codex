import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  phone: '',
  message: '',
  consent: false
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const formErrors = {};
    if (!formData.name.trim()) formErrors.name = 'Bitte geben Sie Ihren Namen ein.';
    if (!formData.email.trim()) formErrors.email = 'Bitte geben Sie Ihre E-Mail-Adresse ein.';
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) formErrors.email = 'Bitte verwenden Sie eine gültige E-Mail-Adresse.';
    if (!formData.message.trim()) formErrors.message = 'Bitte beschreiben Sie Ihr Anliegen.';
    if (!formData.consent) formErrors.consent = 'Bitte bestätigen Sie die Datenschutzhinweise.';
    return formErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const formErrors = validate();
    setErrors(formErrors);
    if (Object.keys(formErrors).length === 0) {
      setSubmitted(true);
      setFormData(initialFormState);
    }
  };

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Kontakt | FamilienFinanz Akademie Berlin</title>
        <meta
          name="description"
          content="Kontaktieren Sie die FamilienFinanz Akademie in Berlin. Nutzen Sie das Formular, rufen Sie uns an oder schreiben Sie uns eine E-Mail, um Ihr Finanzprojekt zu starten."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Wir freuen uns auf Ihre Nachricht</h1>
        <p>
          Ob Beratungsgespräch, Kursanfrage oder Kooperation – schreiben Sie uns. Wir melden uns werktags innerhalb von 24 Stunden.
        </p>
      </section>

      <section className={styles.grid}>
        <div className={styles.formWrapper}>
          <form onSubmit={handleSubmit} className={styles.form} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Name *</label>
              <input
                id="name"
                name="name"
                type="text"
                placeholder="Vor- und Nachname"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={!!errors.name}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </div>
            <div className={styles.field}>
              <label htmlFor="email">E-Mail *</label>
              <input
                id="email"
                name="email"
                type="email"
                placeholder="Ihre E-Mail-Adresse"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={!!errors.email}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </div>
            <div className={styles.field}>
              <label htmlFor="phone">Telefon</label>
              <input
                id="phone"
                name="phone"
                type="tel"
                placeholder="Optional"
                value={formData.phone}
                onChange={handleChange}
              />
            </div>
            <div className={styles.field}>
              <label htmlFor="message">Nachricht *</label>
              <textarea
                id="message"
                name="message"
                rows="4"
                placeholder="Beschreiben Sie Ihr Anliegen"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={!!errors.message}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </div>
            <div className={styles.checkbox}>
              <input
                id="consent"
                type="checkbox"
                name="consent"
                checked={formData.consent}
                onChange={handleChange}
              />
              <label htmlFor="consent">
                Ich habe die <a href="/datenschutz">Datenschutzhinweise</a> gelesen und stimme der Verarbeitung meiner Angaben zu.
              </label>
            </div>
            {errors.consent && <span className={styles.error}>{errors.consent}</span>}
            <button type="submit" className={styles.submit}>
              Nachricht senden
            </button>
            {submitted && (
              <p className={styles.success} role="status">
                Vielen Dank! Wir haben Ihre Nachricht erhalten und melden uns zeitnah.
              </p>
            )}
          </form>
        </div>
        <div className={styles.info}>
          <div className={styles.contact}>
            <h2>Kontakt</h2>
            <p>Friedrichstraße 95<br />10117 Berlin, Deutschland</p>
            <p>Telefon: <a href="tel:+493098765432">+49 30 9876 5432</a></p>
            <p>E-Mail: <a href="mailto:kontakt@finanzplaner-familie.de">kontakt@finanzplaner-familie.de</a></p>
            <p>Mo–Fr, 9:00–17:00 Uhr</p>
          </div>
          <div className={styles.map} aria-label="Standortkarte Berlin">
            <iframe
              title="FamilienFinanz Akademie Standort Berlin"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2428.822144753934!2d13.38885991580326!3d52.52064577981378!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851c7626be221%3A0x7f6d0c85fa5090fb!2sFriedrichstra%C3%9Fe%2095%2C%2010117%20Berlin!5e0!3m2!1sde!2sde!4v1707214567890!5m2!1sde!2sde"
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
          <div className={styles.social}>
            <h2>Folgen Sie uns</h2>
            <ul>
              <li><a href="https://www.linkedin.com/company/familienfinanz-akademie" target="_blank" rel="noopener noreferrer">LinkedIn</a></li>
              <li><a href="https://www.xing.com/company/familienfinanz-akademie" target="_blank" rel="noopener noreferrer">Xing</a></li>
              <li><a href="https://www.facebook.com/familienfinanz-akademie" target="_blank" rel="noopener noreferrer">Facebook</a></li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;