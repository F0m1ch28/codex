```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  return (
    <div className={styles.home}>
      <Helmet>
        <title>TechSolutions | Guiding Cloud and Digital Journeys</title>
        <meta
          name="description"
          content="Discover how TechSolutions brings clarity to cloud adoption, digital transformation, and sustainable technology change."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={`${styles.heroContent} container`}>
          <div className={styles.heroText}>
            <span className={styles.heroTag}>Cloud-first consulting</span>
            <h1>
              Trusted partners for your cloud and digital transformation goals
            </h1>
            <p>
              We translate business priorities into practical technology
              roadmaps. From cloud strategy to modern platforms, our consultants
              help you move with confidence.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contact" className={styles.primaryAction}>
                Start a conversation
              </Link>
              <Link to="/services" className={styles.secondaryAction}>
                Explore services
              </Link>
            </div>
          </div>
          <div className={styles.heroMedia}>
            <img
              src="https://picsum.photos/seed/cloudteam/640/480"
              alt="Consulting team reviewing a digital strategy roadmap"
            />
          </div>
        </div>
      </section>

      <section className={`${styles.highlights} container`}>
        <div className={styles.highlightCard}>
          <span className={styles.icon}>☁️</span>
          <h3>Cloud solutions</h3>
          <p>
            Design adaptive architectures, optimize workloads, and keep your
            platforms dependable across every phase of growth.
          </p>
        </div>
        <div className={styles.highlightCard}>
          <span className={styles.icon}>🧭</span>
          <h3>Digital direction</h3>
          <p>
            Build digital experiences that align with customer needs while
            maintaining clear governance and measurable outcomes.
          </p>
        </div>
        <div className={styles.highlightCard}>
          <span className={styles.icon}>🤝</span>
          <h3>Collaborative approach</h3>
          <p>
            Partner with consultants who listen first, co-create solutions, and
            guide teams through lasting change.
          </p>
        </div>
      </section>

      <section className={`${styles.impact} container`}>
        <div className={styles.impactText}>
          <h2>Impact first, technology second</h2>
          <p>
            Every project starts with understanding what matters most to your
            organization. By combining human insight with modern technology, we
            create cloud strategies and digital experiences that stay resilient
            as your business evolves.
          </p>
          <div className={styles.metrics}>
            <div>
              <strong>200+</strong>
              <span>Cloud programs accelerated</span>
            </div>
            <div>
              <strong>96%</strong>
              <span>Engagements extended by clients</span>
            </div>
            <div>
              <strong>15 yrs</strong>
              <span>Average consultant experience</span>
            </div>
          </div>
        </div>
        <div className={styles.impactMedia}>
          <img
            src="https://picsum.photos/seed/datavisual/640/520"
            alt="Cloud performance dashboards displayed on multiple screens"
          />
        </div>
      </section>

      <section className={styles.approach}>
        <div className="container">
          <h2>How we deliver clarity</h2>
          <div className={styles.steps}>
            <article>
              <h3>Discover</h3>
              <p>
                We speak with teams, review current tooling, and identify the
                constraints that affect your cloud and digital plans.
              </p>
            </article>
            <article>
              <h3>Design</h3>
              <p>
                Together we map out a practical roadmap, prioritize initiatives,
                and create a clear communication plan for stakeholders.
              </p>
            </article>
            <article>
              <h3>Enable</h3>
              <p>
                Our consultants work side by side with your teams to activate
                cloud platforms, automate processes, and deliver better customer
                experiences.
              </p>
            </article>
            <article>
              <h3>Empower</h3>
              <p>
                We leave teams confident with knowledge transfer, operating
                playbooks, and success measures that keep momentum moving.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.insights} container`}>
        <div className={styles.insightCard}>
          <h4>Cloud readiness assessments</h4>
          <p>
            Gain a balanced view of your current environment and receive
            prioritized actions to unlock value quickly.
          </p>
        </div>
        <div className={styles.insightCard}>
          <h4>Digital workplace modernization</h4>
          <p>
            Equip teams with intuitive tools, secure collaboration, and
            workflows that adapt to hybrid ways of working.
          </p>
        </div>
        <div className={styles.insightCard}>
          <h4>Data-driven decision support</h4>
          <p>
            Turn dispersed data into actionable insights to guide investments,
            customer journeys, and service improvements.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Home;
```