import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';

const App = () => {
  const location = useLocation();

  useEffect(() => {
    const titles = {
      '/': 'КиберКотики — цифровая безопасность через улыбки',
      '/about': 'О проекте | КиберКотики',
      '/services': 'Сервисы | КиберКотики',
      '/contact': 'Связаться | КиберКотики',
      '/thank-you': 'Спасибо! | КиберКотики',
      '/terms': 'Условия использования | КиберКотики',
      '/privacy': 'Политика конфиденциальности | КиберКотики',
      '/cookie-policy': 'Политика использования cookie | КиберКотики'
    };

    const descriptions = {
      '/': 'Откройте для себя цифровую безопасность вместе с милыми котиками и игривыми советами по цифровой гигиене.',
      '/about': 'Узнайте историю проекта КиберКотики и познакомьтесь с нашей командой защитников цифрового мира.',
      '/services': 'Посмотрите, чем могут помочь КиберКотики: аудиты, обучение, игровые симуляции фишинга.',
      '/contact': 'Связаться с КиберКотиками и запросить консультацию по цифровой безопасности.',
      '/thank-you': 'Спасибо за обращение к КиберКотикам! Мы скоро ответим.',
      '/terms': 'Условия использования материалов сайта КиберКотики и правила поведения в сети.',
      '/privacy': 'Политика конфиденциальности КиберКотиков и прозрачное отношение к данным.',
      '/cookie-policy': 'Узнайте, как КиберКотики используют файлы cookie и как вы можете управлять ими.'
    };

    document.title = titles[location.pathname] || 'КиберКотики';
    const descriptionTag = document.querySelector('meta[name="description"]');
    if (descriptionTag) {
      descriptionTag.setAttribute(
        'content',
        descriptions[location.pathname] || descriptions['/']
      );
    }
  }, [location.pathname]);

  return (
    <div className="app">
      <Header />
      <main id="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="/terms" element={<TermsOfService variant="terms" />} />
          <Route path="/cookie-policy" element={<TermsOfService variant="cookies" />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
      <CookieBanner />
    </div>
  );
};

export default App;