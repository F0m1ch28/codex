import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const ImageWithLoader = ({ src, alt, className }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={"image-wrapper ${loaded ? 'image-wrapper--loaded' : ''}"}>
      <img
        src={src}
        alt={alt}
        className={"${className} ${loaded ? 'image-visible' : 'image-hidden'}"}
        onLoad={() => setLoaded(true)}
        loading="lazy"
      />
    </div>
  );
};

const Home = () => {
  useEffect(() => {
    const descriptionTag = document.querySelector('meta[name="description"]');
    if (descriptionTag) {
      descriptionTag.setAttribute(
        'content',
        'Изучи цифровую безопасность вместе с котиками: факты, игры, галерея и полезные советы по защите данных.'
      );
    }
  }, []);

  const factCards = [
    {
      title: 'Не делись рыбкой — делись паролями только с кото-хранителем',
      text: 'Сильные пароли — как запас нервишек: больше символов, меньше шансов их украсть. Используй менеджеры паролей и уникальные комбинации.',
      image: 'https://images.unsplash.com/photo-1606117335583-5e94d0bc82db?auto=format&fit=crop&w=900&q=80'
    },
    {
      title: 'Двухфакторная пушистость',
      text: '2FA — это как двойное мурчание перед входом. Даже если пароль украдут, злоумышленник не пройдет без подтверждения на твоем устройстве.',
      image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80'
    },
    {
      title: 'Обновления — это сон и молочко для системы',
      text: 'Регулярные обновления закрывают уязвимости быстрее, чем котик закрывает глаза на колыбельную. Настрой автоматические апдейты.',
      image: 'https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?auto=format&fit=crop&w=900&q=80'
    }
  ];

  const services = [
    {
      title: 'Кото-аудит безопасности',
      description: 'Глубокий анализ цифровой инфраструктуры с чек-листами, визуальными отчётами и рекомендациями в формате стори с котиками.',
      icon: '🛡️'
    },
    {
      title: 'Игровые симуляции фишинга',
      description: 'Погружаем команду в сюжетные сценарии «ловли рыбки». Выявляем слабые места и учим реагировать на подозрительные письма.',
      icon: '🎮'
    },
    {
      title: 'Обучающие марафоны',
      description: 'Онлайн-курсы с геймификацией: комиксы, реакции котиков и микротесты, которые хочется проходить снова и снова.',
      icon: '📚'
    },
    {
      title: 'Экспресс-консультации',
      description: '30 минут с экспертами-коучами, которые объяснят сложное простым языком и подскажут, как защитить цифровой хвост.',
      icon: '💡'
    }
  ];

  const testimonials = [
    {
      name: 'Мария, руководитель команды',
      quote: 'Команда прошла тренинг от КиберКотиков и теперь ловит фишинговые письма ещё до того, как они успевают замурлыкать!',
      avatar: 'https://images.unsplash.com/photo-1533738363-b7f9aef128ce?auto=format&fit=crop&w=300&q=80'
    },
    {
      name: 'Илья, продуктовый менеджер',
      quote: 'Геймифицированные сценарии — просто восторг. Сотрудники реально хотят повторять тесты, чтобы увидеть новые реакции котиков.',
      avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=300&q=80'
    },
    {
      name: 'Анна, HR-директор',
      quote: 'Cookie-баннер ещё никогда не улыбался так дружелюбно. Наши политики безопасности теперь читают даже самые занятые сотрудники.',
      avatar: 'https://images.unsplash.com/photo-1544723795-6e21e8d41f06?auto=format&fit=crop&w=300&q=80'
    }
  ];

  const gallery = [
    {
      src: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=900&q=80',
      alt: 'Котик внимательно проверяет ноутбук'
    },
    {
      src: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&w=900&q=80',
      alt: 'Котёнок с планшетом'
    },
    {
      src: 'https://images.unsplash.com/photo-1519999482648-25049ddd37b1?auto=format&fit=crop&w=900&q=80',
      alt: 'Кот и его любимые технологии'
    },
    {
      src: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=900&q=80',
      alt: 'Котик выбирает безопасную ссылку'
    }
  ];

  const [selectedLink, setSelectedLink] = useState(null);

  const handleGameChoice = (choice) => {
    setSelectedLink(choice);
  };

  return (
    <div className="home">
      <section className="intro-section" id="intro">
        <div className="container intro-grid">
          <div className="intro-content">
            <p className="intro-overline">Ты что усроил правила безопасности в цифровой среде?</p>
            <h2 className="intro-title">
              Котики следят за безопасностью и мурлычут, когда видят, что ты осторожен.
            </h2>
            <p className="intro-text">
              В мире, где каждая ссылка может оказаться капканом, мы превращаем правила цифровой гигиены в игру.
              Следуй подсказкам хвостатых экспертов и защищай свой киберхвост.
            </p>
            <div className="intro-badges">
              <span className="badge badge--teal">100% игровой формат</span>
              <span className="badge badge--orange">Экспертный контент</span>
            </div>
          </div>
          <div className="intro-visual">
            <ImageWithLoader
              src="https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&w=1100&q=80"
              alt="Белый котик на фоне экрана"
              className="intro-image"
            />
          </div>
        </div>
      </section>

      <section className="hero-section" id="hero">
        <div className="container hero-grid">
          <div className="hero-content">
            <span className="hero-label">Главное правило</span>
            <h1 className="hero-title">ПЕРЕХОДИТЬ ПО НЕПРОВЕРЕННЫМ ССЫЛКАМ НЕБЕЗОПАСНО</h1>
            <p className="hero-subtitle">
              Замри, как кот, увидевший подозрительную мышь. Проверь отправителя, наведи курсор и убедись, что адрес безопасен.
              В сомнении — не кликай и спроси у КиберКотиков.
            </p>
            <div className="hero-actions">
              <Link to="/contact" className="cta-button cta-button--primary">Получить консультацию</Link>
              <a className="cta-link" href="#facts">Узнать факты ↓</a>
            </div>
          </div>
          <div className="hero-visual">
            <ImageWithLoader
              src="https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=1200&q=80"
              alt="Рыжий кот охраняет ноутбук"
              className="hero-image"
            />
          </div>
        </div>
      </section>

      <section className="facts-section" id="facts">
        <div className="container">
          <h2 className="section-title">Факты о цифровой гигиене от котиков</h2>
          <p className="section-subtitle">
            Запомни эти пушистые истины, и никакие кибермыши не проберутся к твоим данным.
          </p>
          <div className="facts-grid">
            {factCards.map((fact) => (
              <article className="fact-card" key={fact.title}>
                <ImageWithLoader src={fact.image} alt={fact.title} className="fact-image" />
                <div className="fact-body">
                  <h3 className="fact-title">{fact.title}</h3>
                  <p className="fact-text">{fact.text}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="services-section">
        <div className="container">
          <h2 className="section-title">Сервисы, которые любят компании и коты</h2>
          <p className="section-subtitle">
            Мы делаем цифровую безопасность понятной, визуальной и невероятно увлекательной.
          </p>
          <div className="services-grid">
            {services.map((service) => (
              <div className="service-card" key={service.title}>
                <div className="service-icon" aria-hidden="true">{service.icon}</div>
                <h3 className="service-title">{service.title}</h3>
                <p className="service-text">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="gallery-section">
        <div className="container">
          <h2 className="section-title">Галерея безопасных котиков</h2>
          <p className="section-subtitle">Посмотри, как наши хвостики учат цифровой осторожности.</p>
          <div className="gallery-grid">
            {gallery.map((item) => (
              <figure className="gallery-item" key={item.src}>
                <ImageWithLoader src={item.src} alt={item.alt} className="gallery-image" />
                <figcaption className="gallery-caption">{item.alt}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className="game-section">
        <div className="container game-grid">
          <div className="game-description">
            <h2 className="section-title">Игра: найди опасную ссылку</h2>
            <p className="section-subtitle">
              Один из котиков попытался кликнуть не туда. Выбери карточку, чтобы узнать, кто прячется за подозрительной ссылкой.
            </p>
            <p className="game-tip">Подсказка: смотри на адрес, грамматику и контекст!</p>
          </div>
          <div className="game-cards">
            <button
              type="button"
              className={"game-card ${selectedLink === 'safe' ? 'game-card--selected' : ''}"}
              onClick={() => handleGameChoice('safe')}
            >
              <h3>«Обновление приложения кото-трекера»</h3>
              <p>https://support.cybercats.ru/update</p>
              {selectedLink === 'safe' && <span className="game-result game-result--safe">Мур! Безопасно.</span>}
            </button>
            <button
              type="button"
              className={"game-card ${selectedLink === 'danger' ? 'game-card--selected' : ''}"}
              onClick={() => handleGameChoice('danger')}
            >
              <h3>«Срочно подтвердите пароль»</h3>
              <p>http://suspicious-login-security.ru</p>
              {selectedLink === 'danger' && <span className="game-result game-result--danger">Фшш! Опасно!</span>}
            </button>
          </div>
        </div>
      </section>

      <section className="testimonials-section">
        <div className="container">
          <h2 className="section-title">Отзывы счастливых команд</h2>
          <div className="testimonials-grid">
            {testimonials.map((testimonial) => (
              <blockquote className="testimonial-card" key={testimonial.name}>
                <ImageWithLoader
                  src={testimonial.avatar}
                  alt={"Фото ${testimonial.name}"}
                  className="testimonial-avatar"
                />
                <p className="testimonial-quote">“{testimonial.quote}”</p>
                <cite className="testimonial-name">{testimonial.name}</cite>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className="about-section">
        <div className="container about-grid">
          <div className="about-text">
            <h2 className="section-title">О команде КиберКотиков</h2>
            <p>
              Мы объединяем экспертов по кибербезопасности, педагогов и иллюстраторов, чтобы превращать сложные темы
              в яркие путешествия. Котики помогают удерживать внимание, а мы — развивать навыки и мышление.
            </p>
            <p>
              Программы КиберКотиков используют методики сторителлинга, микролёрнинга и импровизации, чтобы каждый участник
              почувствовал себя защищённым и смог применить знания в жизни.
            </p>
            <Link to="/about" className="cta-link">Подробнее о команде →</Link>
          </div>
          <div className="about-team">
            <ImageWithLoader
              src="https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?auto=format&fit=crop&w=900&q=80"
              alt="Команда котов на совещании"
              className="about-image"
            />
            <div className="team-highlight">
              <h3>Команда мечты</h3>
              <p>UX-аниматор, аналитик угроз, кототерапевт и мастер сторителлинга работают вместе ради вашей безопасности.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="cta-section" id="retest">
        <div className="container cta-container">
          <p className="cta-text">ну тогда надо пройти тест снова</p>
          <button
            type="button"
            className="cta-button cta-button--secondary"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            Вернуться к началу и повторить
          </button>
        </div>
      </section>
    </div>
  );
};

export default Home;