import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

const ThankYou = () => {
  useEffect(() => {
    const descriptionTag = document.querySelector('meta[name="description"]');
    if (descriptionTag) {
      descriptionTag.setAttribute(
        'content',
        'Спасибо! Команда КиберКотиков получила ваше сообщение и скоро свяжется с вами.'
      );
    }
  }, []);

  return (
    <div className="page thankyou-page">
      <div className="container narrow-container thankyou-content">
        <h1 className="page-title">Спасибо за сообщение!</h1>
        <p>
          КиберКотики уже моргают усами и готовят ответ. Мы свяжемся с вами в ближайшее время, чтобы обсудить детали.
          Пока ждёте, взгляните на наши истории и советы — там много пушистого.
        </p>
        <div className="thankyou-actions">
          <Link to="/" className="cta-button cta-button--primary">На главную</Link>
          <Link to="/services" className="cta-link">Посмотреть сервисы →</Link>
        </div>
      </div>
    </div>
  );
};

export default ThankYou;