import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const initialFormState = {
  name: '',
  email: '',
  message: ''
};

const Contact = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const descriptionTag = document.querySelector('meta[name="description"]');
    if (descriptionTag) {
      descriptionTag.setAttribute(
        'content',
        'Свяжитесь с командой КиберКотиков: задайте вопрос, закажите аудит или игру по цифровой безопасности.'
      );
    }
  }, []);

  const validate = (values) => {
    const newErrors = {};
    if (!values.name.trim()) {
      newErrors.name = 'Пожалуйста, укажите имя.';
    }
    if (!values.email.trim()) {
      newErrors.email = 'Нужен ваш email для ответа.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/u.test(values.email.trim())) {
      newErrors.email = 'Введите корректный email.';
    }
    if (!values.message.trim()) {
      newErrors.message = 'Напишите свой запрос или вопрос.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const sanitized = {
      name: formData.name.trim(),
      email: formData.email.trim(),
      message: formData.message.trim()
    };
    const validationErrors = validate(sanitized);
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setFormData(initialFormState);
      navigate('/thank-you');
    }, 400);
  };

  return (
    <div className="page contact-page">
      <div className="container narrow-container">
        <h1 className="page-title">Связаться с КиберКотиками</h1>
        <p>
          Мы рады помочь с созданием игровых программ по цифровой безопасности, провести аудит или придумать уникальную
          активность для вашей команды. Оставьте свои контакты — мы вернемся с идеями и планом действий.
        </p>

        <div className="contact-info">
          <div>
            <h2>Контакты</h2>
            <p><strong>Телефон:</strong> +7 (999) 123-45-67</p>
            <p><strong>Email:</strong> hello@cybercats.ru</p>
            <p><strong>Адрес:</strong> Москва, ул. Защитная, 7</p>
          </div>
          <div>
            <h2>Часы работы</h2>
            <p>Понедельник — Пятница, 10:00 - 19:00 (GMT+3)</p>
            <p>Ответ в течение одного рабочего дня.</p>
          </div>
        </div>

        <form className="contact-form" onSubmit={handleSubmit} noValidate>
          <div className="form-field">
            <label htmlFor="name">Имя</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              placeholder="Как к вам обращаться?"
              aria-required="true"
              aria-invalid={Boolean(errors.name)}
            />
            {errors.name && <span className="form-error">{errors.name}</span>}
          </div>

          <div className="form-field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="name@example.com"
              aria-required="true"
              aria-invalid={Boolean(errors.email)}
            />
            {errors.email && <span className="form-error">{errors.email}</span>}
          </div>

          <div className="form-field">
            <label htmlFor="message">Сообщение</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              placeholder="Расскажите, чем мы можем помочь."
              aria-required="true"
              aria-invalid={Boolean(errors.message)}
            />
            {errors.message && <span className="form-error">{errors.message}</span>}
          </div>

          <button type="submit" className="cta-button cta-button--primary" disabled={isSubmitting}>
            {isSubmitting ? 'Отправка...' : 'Отправить сообщение'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Contact;