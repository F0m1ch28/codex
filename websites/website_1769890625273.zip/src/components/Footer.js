import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="site-footer">
    <div className="container footer-container">
      <div className="footer-column">
        <h3 className="footer-title">КиберКотики</h3>
        <p className="footer-text">
          Игривые коты, серьезная цифровая защита. Мы обучаем, вовлекаем и вдохновляем на безопасное поведение в сети.
        </p>
        <div className="footer-social">
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a>
          <a href="https://vk.com" target="_blank" rel="noopener noreferrer">VK</a>
          <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer">YouTube</a>
        </div>
      </div>
      <div className="footer-column">
        <h4 className="footer-heading">Навигация</h4>
        <Link to="/" className="footer-link">Главная</Link>
        <Link to="/about" className="footer-link">О проекте</Link>
        <Link to="/services" className="footer-link">Сервисы</Link>
        <Link to="/contact" className="footer-link">Контакты</Link>
      </div>
      <div className="footer-column">
        <h4 className="footer-heading">Юридическая информация</h4>
        <Link to="/terms" className="footer-link">Условия использования</Link>
        <Link to="/privacy" className="footer-link">Политика конфиденциальности</Link>
        <Link to="/cookie-policy" className="footer-link">Политика cookie</Link>
      </div>
      <div className="footer-column">
        <h4 className="footer-heading">Связь</h4>
        <Link to="/contact" className="footer-link footer-link--contact">+7 (999) 123-45-67</Link>
        <Link to="/contact" className="footer-link footer-link--contact">hello@cybercats.ru</Link>
        <p className="footer-text">График: Пн-Пт, 10:00–19:00</p>
      </div>
    </div>
    <div className="footer-bottom">
      <p>© {new Date().getFullYear()} КиберКотики. Все пушистые права защищены.</p>
    </div>
  </footer>
);

export default Footer;