import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => setMenuOpen((prev) => !prev);
  const handleClose = () => setMenuOpen(false);

  return (
    <header className="site-header">
      <div className="container header-container">
        <Link to="/" className="brand" onClick={handleClose}>
          <span className="brand-icon" aria-hidden="true">🐾</span>
          <span className="brand-text">КиберКотики</span>
        </Link>
        <nav className={"nav ${menuOpen ? 'nav--open' : ''}"} aria-label="Главная навигация">
          <NavLink to="/" onClick={handleClose} className="nav__link">
            Главная
          </NavLink>
          <NavLink to="/about" onClick={handleClose} className="nav__link">
            О проекте
          </NavLink>
          <NavLink to="/services" onClick={handleClose} className="nav__link">
            Сервисы
          </NavLink>
          <NavLink to="/contact" onClick={handleClose} className="nav__link">
            Контакты
          </NavLink>
          <a href="/#facts" onClick={handleClose} className="nav__link">
            Факты
          </a>
        </nav>
        <div className="header-actions">
          <Link to="/contact" className="cta-button" onClick={handleClose}>
            Связаться
          </Link>
          <button
            type="button"
            className={"burger ${menuOpen ? 'burger--active' : ''}"}
            onClick={handleToggle}
            aria-expanded={menuOpen}
            aria-label="Переключить меню"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;