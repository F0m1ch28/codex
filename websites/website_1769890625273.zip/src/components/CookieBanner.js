import React, { useEffect, useState } from 'react';

const COOKIE_KEY = 'cyberCatsCookieConsent';

const CookieBanner = () => {
  const [choice, setChoice] = useState(() => {
    if (typeof window === 'undefined') {
      return null;
    }
    return window.localStorage.getItem(COOKIE_KEY);
  });

  useEffect(() => {
    if (choice) {
      window.localStorage.setItem(COOKIE_KEY, choice);
    }
  }, [choice]);

  if (choice) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <p className="cookie-banner__text">
        Этот сайт использует файлы cookie для улучшения опыта. Продолжая, вы соглашаетесь с их использованием.
      </p>
      <div className="cookie-banner__actions">
        <button
          type="button"
          className="cookie-button cookie-button--accept"
          onClick={() => setChoice('accepted')}
        >
          Принять
        </button>
        <button
          type="button"
          className="cookie-button cookie-button--decline"
          onClick={() => setChoice('declined')}
        >
          Отклонить
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;