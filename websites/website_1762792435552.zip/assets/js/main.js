document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('[data-nav-toggle]');
  const navMenu = document.querySelector('[data-nav]');
  const scrollTopBtn = document.getElementById('scrollTopBtn');
  const cookieBanner = document.getElementById('cookieBanner');
  const acceptCookies = document.getElementById('acceptCookies');
  const contactForm = document.getElementById('contactForm');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
      navMenu.classList.toggle('open');
    });
  }

  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'auto' });
      if (navToggle && navMenu) {
        navMenu.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  });

  if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 300) {
        scrollTopBtn.classList.add('visible');
      } else {
        scrollTopBtn.classList.remove('visible');
      }
    });

    scrollTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  if (cookieBanner && acceptCookies) {
    if (localStorage.getItem('mapleCookieConsent') === 'true') {
      cookieBanner.classList.add('hidden');
    } else {
      cookieBanner.classList.add('visible');
    }

    acceptCookies.addEventListener('click', () => {
      localStorage.setItem('mapleCookieConsent', 'true');
      cookieBanner.classList.remove('visible');
      cookieBanner.classList.add('hidden');
    });
  }

  if (contactForm) {
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      const status = contactForm.querySelector('.form-status');
      if (status) {
        status.textContent = 'Thanks for reaching out. A Maple consultant will respond within one business day.';
      }
      contactForm.reset();
    });
  }
});