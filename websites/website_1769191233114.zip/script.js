document.addEventListener('DOMContentLoaded', function () {
  const body = document.body;
  const navToggle = document.querySelector('.nav-toggle');
  const siteHeader = document.querySelector('.site-header');
  if (navToggle && siteHeader) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      body.classList.toggle('nav-open', !expanded);
    });
  }

  document.addEventListener('click', (event) => {
    if (body.classList.contains('nav-open')) {
      const nav = document.querySelector('.site-nav');
      if (nav && !nav.contains(event.target) && !navToggle.contains(event.target)) {
        body.classList.remove('nav-open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    }
  });

  const fadeItems = document.querySelectorAll('.fade-in');
  if (fadeItems.length > 0 && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.25 }
    );
    fadeItems.forEach((item) => observer.observe(item));
  } else {
    fadeItems.forEach((item) => item.classList.add('is-visible'));
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = cookieBanner ? cookieBanner.querySelector('.cookie-accept') : null;
  const declineBtn = cookieBanner ? cookieBanner.querySelector('.cookie-decline') : null;
  const cookieKey = 'evening-spedition-cookie-choice';

  const hideBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.add('is-hidden');
      cookieBanner.setAttribute('aria-hidden', 'true');
    }
  };

  const storedChoice = localStorage.getItem(cookieKey);
  if (storedChoice && cookieBanner) {
    hideBanner();
  }

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => {
      localStorage.setItem(cookieKey, 'accepted');
      hideBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => {
      localStorage.setItem(cookieKey, 'declined');
      hideBanner();
    });
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast-notice';
    toast.textContent = message;
    document.body.appendChild(toast);
    requestAnimationFrame(() => {
      toast.classList.add('active');
    });
    setTimeout(() => {
      toast.classList.remove('active');
    }, 1800);
    setTimeout(() => {
      toast.remove();
    }, 2200);
  }

  const forms = document.querySelectorAll('form[data-redirect]');
  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const redirect = form.dataset.redirect || form.getAttribute('action') || 'thank-you.html';
      showToast('Your submission is noted. Redirecting shortly.');
      setTimeout(() => {
        window.location.href = redirect;
      }, 1200);
    });
  });
});