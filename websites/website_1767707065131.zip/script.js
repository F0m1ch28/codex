document.addEventListener("DOMContentLoaded", function () {
    const banner = document.getElementById("cookieBanner");
    if (!banner) {
        return;
    }

    const acceptBtn = banner.querySelector("[data-cookie-action='accept']");
    const declineBtn = banner.querySelector("[data-cookie-action='decline']");
    const consentKey = "figurewbwfCookieConsent";

    const storedPreference = localStorage.getItem(consentKey);
    if (!storedPreference) {
        banner.classList.add("active");
    }

    const handleChoice = (choice) => {
        localStorage.setItem(consentKey, choice);
        banner.classList.remove("active");
    };

    acceptBtn.addEventListener("click", () => handleChoice("accepted"));
    declineBtn.addEventListener("click", () => handleChoice("declined"));
});