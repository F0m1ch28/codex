document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector("[data-nav-toggle]");
  const siteNav = document.querySelector("[data-site-nav]");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = siteNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        siteNav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  const acceptBtn = document.querySelector("[data-accept-cookies]");
  const declineBtn = document.querySelector("[data-decline-cookies]");
  const consentKey = "gt-cookie-consent";

  if (cookieBanner && acceptBtn && declineBtn) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      cookieBanner.classList.add("is-visible");
    }
    acceptBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "accepted");
      cookieBanner.classList.remove("is-visible");
    });
    declineBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "declined");
      cookieBanner.classList.remove("is-visible");
    });
  }

  const calcForm = document.querySelector("[data-calculator-form]");
  const annualSaving = document.querySelector("[data-annual-saving]");
  const monthlySaving = document.querySelector("[data-monthly-saving]");
  const co2Saving = document.querySelector("[data-co2-saving]");
  const repayment = document.querySelector("[data-repayment-time]");

  if (calcForm && annualSaving && monthlySaving && co2Saving && repayment) {
    calcForm.addEventListener("input", calculateSavings);
    calcForm.addEventListener("submit", (event) => {
      event.preventDefault();
      calculateSavings();
    });
    calculateSavings();
  }

  function calculateSavings() {
    const roofSize = parseFloat(calcForm.querySelector("[name='roofSize']").value) || 0;
    const efficiency = parseFloat(calcForm.querySelector("[name='efficiency']").value) || 0;
    const radiation = parseFloat(calcForm.querySelector("[name='radiation']").value) || 0;
    const consumption = parseFloat(calcForm.querySelector("[name='consumption']").value) || 0;
    const electricityPrice = parseFloat(calcForm.querySelector("[name='price']").value) || 0;
    const investment = parseFloat(calcForm.querySelector("[name='investment']").value) || 0;

    const systemPower = roofSize * (efficiency / 100) * 0.2;
    const annualYield = systemPower * radiation;
    const selfConsumptionRate = consumption > 0 ? Math.min(annualYield / consumption, 1) : 0.8;
    const annualSelfConsumption = annualYield * selfConsumptionRate;
    const annualFeedIn = annualYield - annualSelfConsumption;
    const feedInTariff = 0.082;
    const annualIncome = annualSelfConsumption * electricityPrice + annualFeedIn * feedInTariff;
    const annualCo2 = annualYield * 0.55;
    const monthlyIncome = annualIncome / 12;
    const payback = investment > 0 ? investment / annualIncome : 0;

    annualSaving.textContent = annualIncome.toLocaleString("de-DE", { style: "currency", currency: "EUR" });
    monthlySaving.textContent = monthlyIncome.toLocaleString("de-DE", { style: "currency", currency: "EUR" });
    co2Saving.textContent = `${annualCo2.toLocaleString("de-DE", { maximumFractionDigits: 0 })} kg CO₂`;
    repayment.textContent = payback > 0 ? `${payback.toFixed(1)} Jahre` : "–";
  }
});