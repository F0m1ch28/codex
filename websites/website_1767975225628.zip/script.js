document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const mainNav = document.querySelector(".main-nav");

    if (navToggle && mainNav) {
        navToggle.addEventListener("click", () => {
            mainNav.classList.toggle("open");
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const storedChoice = localStorage.getItem("nbc_cookie_choice");
        if (!storedChoice) {
            cookieBanner.classList.add("active");
        }

        cookieBanner.querySelectorAll("a[data-choice]").forEach((link) => {
            link.addEventListener("click", () => {
                const choice = link.getAttribute("data-choice");
                localStorage.setItem("nbc_cookie_choice", choice);
                cookieBanner.classList.remove("active");
            });
        });
    }

    const contactForm = document.querySelector("form[data-redirect='thanks']");
    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            event.preventDefault();
            window.location.href = "thanks.html";
        });
    }

    const searchInput = document.getElementById("search-posts");
    const categoryButtons = document.querySelectorAll(".category-filter button");
    const articleCards = document.querySelectorAll(".article-card[data-category]");
    const paginationContainer = document.getElementById("pagination");
    const postsPerPage = 6;
    let currentPage = 1;
    let activeCategory = "all";
    let filteredCards = Array.from(articleCards);

    function filterCards() {
        const query = searchInput ? searchInput.value.trim().toLowerCase() : "";
        filteredCards = Array.from(articleCards).filter((card) => {
            const categories = card.dataset.category.toLowerCase();
            const matchesCategory = activeCategory === "all" || categories.includes(activeCategory);
            const textContent = card.innerText.toLowerCase();
            const matchesSearch = !query || textContent.includes(query);
            return matchesCategory && matchesSearch;
        });
        currentPage = 1;
        renderPagination();
        renderVisibleCards();
    }

    function renderPagination() {
        if (!paginationContainer) return;
        paginationContainer.innerHTML = "";
        const totalPages = Math.ceil(filteredCards.length / postsPerPage) || 1;

        for (let i = 1; i <= totalPages; i++) {
            const btn = document.createElement("button");
            btn.textContent = i;
            if (i === currentPage) {
                btn.classList.add("active");
            }
            btn.addEventListener("click", () => {
                currentPage = i;
                renderVisibleCards();
                renderPagination();
                window.scrollTo({ top: 0, behavior: "smooth" });
            });
            paginationContainer.appendChild(btn);
        }
    }

    function renderVisibleCards() {
        articleCards.forEach((card) => {
            card.style.display = "none";
        });
        const start = (currentPage - 1) * postsPerPage;
        const end = start + postsPerPage;
        filteredCards.slice(start, end).forEach((card) => {
            card.style.display = "grid";
        });
    }

    if (articleCards.length && paginationContainer) {
        renderPagination();
        renderVisibleCards();
        if (searchInput) {
            searchInput.addEventListener("input", filterCards);
        }
        categoryButtons.forEach((button) => {
            button.addEventListener("click", () => {
                categoryButtons.forEach((btn) => btn.classList.remove("active"));
                button.classList.add("active");
                activeCategory = button.dataset.category;
                filterCards();
            });
        });
    }
});