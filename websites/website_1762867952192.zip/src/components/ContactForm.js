import React, { useState } from "react";
import styles from "./ContactForm.module.css";

const initialData = {
  name: "",
  email: "",
  company: "",
  message: "",
};

const ContactForm = ({ title = "Запросить консультацию" }) => {
  const [formData, setFormData] = useState(initialData);
  const [status, setStatus] = useState({ state: "idle", message: "" });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateEmail = (value) =>
    /^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(value.toLowerCase());

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      setStatus({ state: "error", message: "Пожалуйста, укажите ваше имя." });
      return;
    }
    if (!validateEmail(formData.email)) {
      setStatus({ state: "error", message: "Введите корректный email." });
      return;
    }
    if (formData.message.trim().length < 10) {
      setStatus({
        state: "error",
        message: "Расскажите чуть подробнее, чтобы мы подготовили ответ.",
      });
      return;
    }
    setStatus({ state: "loading", message: "Отправляем данные..." });
    setTimeout(() => {
      setStatus({
        state: "success",
        message: "Спасибо! Мы свяжемся с вами в течение одного рабочего дня.",
      });
      setFormData(initialData);
    }, 1500);
  };

  return (
    <form className={styles.form} onSubmit={handleSubmit} noValidate>
      <h2>{title}</h2>
      <p className={styles.subtitle}>
        Заполните форму — команда Vensy подберёт подходящее решение обучения для вас и вашей команды.
      </p>
      <div className={styles.grid}>
        <label className={styles.field}>
          <span>Имя и фамилия*</span>
          <input
            type="text"
            name="name"
            placeholder="Анна Иванова"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </label>
        <label className={styles.field}>
          <span>Email*</span>
          <input
            type="email"
            name="email"
            placeholder="anna@company.eu"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </label>
        <label className={`${styles.field} ${styles.full}`}>
          <span>Компания / роль</span>
          <input
            type="text"
            name="company"
            placeholder="COO, Berlin Tech"
            value={formData.company}
            onChange={handleChange}
          />
        </label>
        <label className={`${styles.field} ${styles.full}`}>
          <span>Задача*</span>
          <textarea
            name="message"
            rows="4"
            placeholder="Опишите препятствия и желаемые результаты..."
            value={formData.message}
            onChange={handleChange}
            required
          />
        </label>
      </div>
      <button
        type="submit"
        className={styles.submit}
        disabled={status.state === "loading"}
      >
        {status.state === "loading" ? "Отправка..." : "Отправить заявку"}
      </button>
      {status.state !== "idle" && (
        <p
          className={`${styles.status} ${
            status.state === "success" ? styles.success : styles.error
          }`}
        >
          {status.message}
        </p>
      )}
    </form>
  );
};

export default ContactForm;