import React, { useMemo } from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  const emailUser = "team";
  const emailDomain = "vensy-institute.eu";
  const email = useMemo(() => `${emailUser}@${emailDomain}`, [emailDomain, emailUser]);

  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.inner}`}>
        <div className={styles.col}>
          <div className={styles.brand}>
            <span className={styles.brandMark}>V</span>
            <div>
              <p className={styles.brandTitle}>Vensy Management Institute</p>
              <p className={styles.brandSubtitle}>
                Экосистема развития управленческих компетенций в Европе.
              </p>
            </div>
          </div>
          <p className={styles.legal}>
            © {new Date().getFullYear()} Vensy Management Institute. Все права защищены.
          </p>
        </div>

        <div className={styles.col}>
          <h3 className={styles.heading}>Страницы</h3>
          <ul className={styles.links}>
            <li>
              <NavLink to="/o-nas">О нас</NavLink>
            </li>
            <li>
              <NavLink to="/napravleniya">Направления</NavLink>
            </li>
            <li>
              <NavLink to="/diagnostika">Диагностика</NavLink>
            </li>
            <li>
              <NavLink to="/simulyator">Симулятор</NavLink>
            </li>
            <li>
              <NavLink to="/biblioteka">База знаний</NavLink>
            </li>
            <li>
              <NavLink to="/prepodavateli">Команда</NavLink>
            </li>
            <li>
              <NavLink to="/webinary">Вебинары</NavLink>
            </li>
          </ul>
        </div>

        <div className={styles.col}>
          <h3 className={styles.heading}>Контакты</h3>
          <address className={styles.address}>
            <span>Kurfürstendamm 200, 10719 Berlin, Germany</span>
            <a href="tel:+493078901234" className={styles.phone}>
              +49 30 7890 1234
            </a>
            <a
              href={`mailto:${email}`}
              className={styles.email}
              data-user={emailUser}
              data-domain={emailDomain}
              aria-label="Написать электронное письмо"
            >
              {emailUser} [at] {emailDomain}
            </a>
          </address>
          <div className={styles.policyLinks}>
            <NavLink to="/soglashenie">Пользовательское соглашение</NavLink>
            <NavLink to="/politika">Политика конфиденциальности</NavLink>
            <NavLink to="/cookie-policy">Cookies</NavLink>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;