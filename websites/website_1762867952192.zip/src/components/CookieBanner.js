import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem("vensy-cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem("vensy-cookie-consent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="region" aria-label="Уведомление о cookie">
      <div className={styles.content}>
        <p>
          Мы используем cookies, чтобы адаптировать материалы Vensy Management Institute под ваши задачи и улучшать сервис.
          Подробнее — в <Link to="/cookie-policy">политике использования cookies</Link>.
        </p>
      </div>
      <button className={styles.button} onClick={handleAccept}>
        Согласен
      </button>
    </div>
  );
};

export default CookieBanner;