import React, { useState } from "react";
import styles from "./InteractiveLearningPath.module.css";

const steps = [
  {
    id: 1,
    title: "Диагностика компетенций",
    description:
      "Стартуем с оценки управленческих зон роста по методологии Vensy: анализируем стратегическое мышление, системность и работу с людьми.",
  },
  {
    id: 2,
    title: "Индивидуальный маршрут обучения",
    description:
      "Комбинируем модули по лидерству, стратегии, операционному менеджменту и работе с командами под задачи компании и личные цели.",
  },
  {
    id: 3,
    title: "Практика в бизнес-симуляторе",
    description:
      "Отрабатываем решения в реалистичных сценариях, где каждое действие влияет на устойчивость, удовлетворенность сотрудников и клиентов.",
  },
  {
    id: 4,
    title: "Поддержка экспертов и менторов",
    description:
      "Обратная связь от практиков европейского рынка помогает закрепить навыки и регулярно адаптировать план развития.",
  },
  {
    id: 5,
    title: "Комьюнити и обмен опытом",
    description:
      "Присоединяйтесь к закрытому сообществу лидеров: обсуждаем инструменты, делимся рабочими кейсами и совместно тестируем гипотезы.",
  }
];

const InteractiveLearningPath = () => {
  const [activeStep, setActiveStep] = useState(steps[0].id);

  return (
    <section className={styles.wrapper} aria-labelledby="path-title">
      <div className="container">
        <div className={styles.headline}>
          <h2 id="path-title">Путь обучения Vensy</h2>
          <p>
            Поддерживаем руководителей, строящих бизнес в Европе: помогаем навести порядок в процессах, прокачать лидерство и управлять командами на расстоянии.
          </p>
        </div>
        <div className={styles.grid}>
          <ol className={styles.timeline}>
            {steps.map((step) => (
              <li
                key={step.id}
                className={`${styles.step} ${activeStep === step.id ? styles.active : ""}`}
              >
                <button
                  type="button"
                  onClick={() => setActiveStep(step.id)}
                  aria-expanded={activeStep === step.id}
                >
                  <span className={styles.stepNumber}>{step.id}</span>
                  <span className={styles.stepTitle}>{step.title}</span>
                </button>
              </li>
            ))}
          </ol>
          <div className={styles.detail}>
            {steps
              .filter((step) => step.id === activeStep)
              .map((step) => (
                <article key={step.id} aria-live="polite">
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                  <div className={styles.progressBar} aria-hidden="true">
                    <span style={{ width: `${(step.id / steps.length) * 100}%` }} />
                  </div>
                </article>
              ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default InteractiveLearningPath;