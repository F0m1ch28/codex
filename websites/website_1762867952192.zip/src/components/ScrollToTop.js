import React, { useEffect, useState } from "react";
import styles from "./ScrollToTop.module.css";

const ScrollToTopButton = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handler = () => {
      setVisible(window.scrollY > 400);
    };
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const scrollTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  return (
    <button
      type="button"
      onClick={scrollTop}
      className={`${styles.button} ${visible ? styles.visible : ""}`}
      aria-label="Вернуться наверх страницы"
    >
      ↑
    </button>
  );
};

export default ScrollToTopButton;