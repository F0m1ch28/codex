import React, { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import styles from "./Header.module.css";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handler = () => {
      setIsScrolled(window.scrollY > 12);
    };
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);
  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ""}`}>
      <div className={`container ${styles.inner}`}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          <span className={styles.logoMark}>V</span>
          <span className={styles.logoText}>
            Vensy <span>Management Institute</span>
          </span>
        </NavLink>

        <nav
          className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ""}`}
          aria-label="Основная навигация"
        >
          <NavLink
            to="/o-nas"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ""}`
            }
            onClick={closeMenu}
          >
            О нас
          </NavLink>
          <NavLink
            to="/napravleniya"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ""}`
            }
            onClick={closeMenu}
          >
            Направления
          </NavLink>
          <NavLink
            to="/simulyator"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ""}`
            }
            onClick={closeMenu}
          >
            Симулятор
          </NavLink>
          <NavLink
            to="/biblioteka"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ""}`
            }
            onClick={closeMenu}
          >
            Библиотека
          </NavLink>
          <NavLink
            to="/prepodavateli"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ""}`
            }
            onClick={closeMenu}
          >
            Преподаватели
          </NavLink>
          <NavLink
            to="/webinary"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ""}`
            }
            onClick={closeMenu}
          >
            Вебинары
          </NavLink>
          <NavLink
            to="/community"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ""}`
            }
            onClick={closeMenu}
          >
            Сообщество
          </NavLink>
        </nav>

        <div className={styles.actions}>
          <NavLink to="/diagnostika" className={styles.cta}>
            Диагностика
          </NavLink>
          <button
            className={`${styles.burger} ${isMenuOpen ? styles.burgerOpen : ""}`}
            onClick={toggleMenu}
            aria-label="Меню"
            aria-expanded={isMenuOpen}
            aria-controls="primary-navigation"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;