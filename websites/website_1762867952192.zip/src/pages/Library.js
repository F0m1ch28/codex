import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Library.module.css";

const resources = [
  {
    category: "Кейсы",
    items: [
      "Согласование стратегии между офисами в Берлине и Праге",
      "Перезапуск операционного ритма в производственной компании",
      "Как построить культуру обратной связи в распределённой команде",
    ],
  },
  {
    category: "Статьи",
    items: [
      "Фреймворк Vensy для управления изменениями",
      "Методика синхронизации OKR и операционных встреч",
      "Лидерство в мультикультурной среде: 5 практик",
    ],
  },
  {
    category: "Шаблоны",
    items: [
      "Шаблон стратегической карты",
      "Панель управления для операционных метрик",
      "Скрипт проведения ретроспективы команды",
    ],
  },
  {
    category: "Инструменты",
    items: [
      "Диагностика вовлеченности команды",
      "Калькулятор приоритетов инициатив",
      "Руководство по фасилитации стратегических сессий",
    ],
  },
];

const Library = () => {
  return (
    <>
      <Helmet>
        <title>Библиотека знаний — Vensy Management Institute</title>
        <meta
          name="description"
          content="База знаний Vensy: кейсы, статьи, шаблоны и инструменты по стратегическому менеджменту, управлению командами и операционным процессам."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Библиотека знаний</h1>
          <p>
            Собрали практические материалы, которые помогут руководителям внедрять инструменты Vensy в ежедневную работу.
            Используйте их, чтобы планировать стратегию, развивать команды и настраивать операционные процессы.
          </p>
        </div>
      </section>
      <section className={styles.resources}>
        <div className="container">
          <div className={styles.grid}>
            {resources.map((block) => (
              <article key={block.category} className={styles.card}>
                <h2>{block.category}</h2>
                <ul>
                  {block.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Library;