import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Legal.module.css";

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Политика использования Cookies — Vensy Management Institute</title>
        <meta
          name="description"
          content="Политика Vensy Management Institute по использованию файлов cookies. Узнайте, какие данные мы собираем и как их можно контролировать."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Политика использования Cookies</h1>
          <p>Последнее обновление: 01 января 2024 года</p>
        </div>
      </section>
      <section className={styles.content}>
        <div className="container">
          <article>
            <h2>1. Что такое cookies</h2>
            <p>
              Cookies — небольшие текстовые файлы, которые сохраняются в браузере при посещении сайта. Они помогают запомнить ваши настройки
              и улучшить взаимодействие с платформой.
            </p>
          </article>
          <article>
            <h2>2. Какие cookies мы используем</h2>
            <p>
              Мы применяем функциональные cookies для авторизации и аналитические cookies для понимания использования платформы. Данные обрабатываются анонимно.
            </p>
          </article>
          <article>
            <h2>3. Управление cookies</h2>
            <p>
              Вы можете настроить браузер так, чтобы он блокировал или удалял cookies. Учтите, что это может повлиять на доступ к некоторым функциям сайта.
            </p>
          </article>
          <article>
            <h2>4. Согласие</h2>
            <p>
              Используя сайт Vensy, вы соглашаетесь на применение cookies. Вы можете изменить решение через настройки браузера.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;