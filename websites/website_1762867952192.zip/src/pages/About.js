import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const timeline = [
  {
    year: "2012",
    title: "Запуск Vensy Management Institute",
    text: "Команда практиков управления запустила первые программы для руководителей русскоязычных компаний, выходящих на европейский рынок.",
  },
  {
    year: "2016",
    title: "Развитие корпоративных решений",
    text: "Создали модульные программы по стратегическому менеджменту и операционному управлению, запустили формат проектных лабораторий.",
  },
  {
    year: "2019",
    title: "Онлайн-симулятор для руководителей",
    text: "Разработали бизнес-симулятор, в котором управленцы тренируются принимать решения в изменчивой среде и видеть последствия для команд.",
  },
  {
    year: "2023",
    title: "Сообщество выпускников в Европе",
    text: "Объединили руководителей из 12 стран в закрытое комьюнити для обмена практиками и совместных решений.",
  },
];

const teamMembers = [
  {
    name: "Ирина Герман",
    role: "CEO & сооснователь",
    experience: "13 лет управления международными командами в HR Tech.",
    image: "https://picsum.photos/400/400?random=51",
  },
  {
    name: "Маркус Коглер",
    role: "Academic Director",
    experience: "Эксперт по стратегическому менеджменту, ex-BCG, Вена.",
    image: "https://picsum.photos/400/400?random=52",
  },
  {
    name: "Анна Резникова",
    role: "Head of Leadership Programs",
    experience: "Практик лидерства, ex-Head of People в европейском fintech.",
    image: "https://picsum.photos/400/400?random=53",
  },
  {
    name: "Леонид Грачев",
    role: "Director of Operations",
    experience: "Опыт внедрения операционных систем в производстве и логистике.",
    image: "https://picsum.photos/400/400?random=54",
  },
];

const values = [
  {
    title: "Прагматичность",
    text: "Все инструменты проходят тестирование на реальных управленческих вызовах. Никакой теории ради теории.",
  },
  {
    title: "Партнерство",
    text: "Мы работаем вместе с командой клиента, создавая решения, которые можно поддерживать и развивать самостоятельно.",
  },
  {
    title: "Открытость",
    text: "Разделяем практики, делимся обратной связью и стимулируем обмен опытом в сообществе.",
  },
  {
    title: "Уважение к культуре",
    text: "Учитываем национальный контекст, правовые требования и культурные особенности каждой страны.",
  },
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>О Vensy Management Institute — история, миссия и команда</title>
        <meta
          name="description"
          content="История создания Vensy Management Institute, команда практикующих управленцев и подход к обучению. Узнайте, как мы помогаем руководителям в Европе выстраивать стратегию, операции и команды."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div>
              <h1>История и миссия Vensy Management Institute</h1>
              <p>
                Мы помогаем руководителям строить управленческие системы, которые работают в реальности европейского рынка.
                Наша команда сочетает опыт корпоративного управления, консалтинга и запуска стартапов.
              </p>
            </div>
            <img
              src="https://picsum.photos/800/600?random=61"
              alt="Команда Vensy Management Institute на стратегической сессии"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div>
              <h2>Миссия</h2>
              <p>
                Сделать профессиональное управленческое образование доступным для русскоязычных лидеров, развивающих бизнес в Европе,
                и помочь им соединить стратегическое мышление, лидерство и операционную устойчивость.
              </p>
            </div>
            <div>
              <h2>Наш подход</h2>
              <p>
                Каждая программа начинается с диагностики состояния управленческой системы организации. На её основе мы комбинируем
                образовательные форматы, практику в симуляторе и сопровождение экспертов. Мы не копируем готовые курсы — создаём
                адаптивные маршруты, которые учитывают цели бизнеса, культуру и масштабы команды.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className="container">
          <h2>Ключевые этапы развития</h2>
          <ol className={styles.timelineList}>
            {timeline.map((item) => (
              <li key={item.year}>
                <div className={styles.year}>{item.year}</div>
                <div className={styles.timelineCard}>
                  <h3>{item.title}</h3>
                  <p>{item.text}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2>Наши ценности</h2>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <h2>Команда практикующих управленцев</h2>
          <p className={styles.teamIntro}>
            Мы соединяем опыт стратегического консалтинга, операционного управления, HR и развития лидерских программ.
          </p>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={`${member.name} — ${member.role}`} loading="lazy" />
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <p className={styles.role}>{member.role}</p>
                  <p className={styles.experience}>{member.experience}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default About;