import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import InteractiveLearningPath from "../components/InteractiveLearningPath";
import styles from "./Home.module.css";

const statsData = [
  { value: 12, suffix: " лет", label: "развития управленческих программ" },
  { value: 800, suffix: "+", label: "руководителей прошли обучение" },
  { value: 68, suffix: "", label: "компаний из 11 индустрий доверяют нам" },
  { value: 94, suffix: "%", label: "участников отмечают рост уверенности" },
];

const serviceAreas = [
  {
    title: "Лидерство и влияние",
    description:
      "Развивайте адаптивное лидерство, укрепляйте культуру доверия и формируйте систему обратной связи в международных командах.",
    icon: "🧭",
  },
  {
    title: "Стратегический менеджмент",
    description:
      "Работаем с гибридными стратегическими циклами: от построения карты стратегии до согласования целей на уровне подразделений.",
    icon: "📈",
  },
  {
    title: "Операционное управление",
    description:
      "Находим узкие места, внедряем визуальные панели метрик, выстраиваем дисциплину встреч и обновляем операционные модели.",
    icon: "⚙️",
  },
  {
    title: "Управление командами",
    description:
      "Помогаем распределённым командам синхронизироваться, строим процесс онбординга и поддерживаем высокий уровень вовлеченности.",
    icon: "🤝",
  },
];

const methodology = [
  {
    title: "Единая управленческая логика",
    text: "Все программы основаны на единой методологической рамке: диагностика → обучение → практика → поддержка.",
  },
  {
    title: "Практики европейского рынка",
    text: "С вами работают действующие руководители из международных компаний, понимающие локальный контекст Европы.",
  },
  {
    title: "Комбинация форматов",
    text: "Видео-микролёрнинг, живые воркшопы, симуляции и индивидуальные сессии собираются под ваши цели.",
  },
];

const testimonials = [
  {
    quote:
      "С Vensy мы перестроили работу кросс-функциональных команд и внедрили ритуалы ретроспектив. Команда стала быстрее принимать решения.",
    name: "Алексей Новиков",
    role: "CTO, Berlin SaaS Hub",
    image: "https://picsum.photos/400/400?random=21",
  },
  {
    quote:
      "Программа по стратегическому менеджменту помогла выстроить прозрачный цикл планирования и согласовать цели между офисами в Праге и Мюнхене.",
    name: "Екатерина Михайлова",
    role: "Head of Strategy, Central Europe Retail",
    image: "https://picsum.photos/400/400?random=22",
  },
  {
    quote:
      "Бизнес-симулятор — сильный инструмент. Видно, как решения в управлении людьми и процессами связаны со стабильностью роста компании.",
    name: "Игорь Семёнов",
    role: "COO, Nordic Logistics",
    image: "https://picsum.photos/400/400?random=23",
  },
];

const projects = [
  {
    title: "Трансформация сервисной модели",
    category: "Сервисы",
    description:
      "Сформировали единые стандарты сервиса и создали академию менеджеров в распределённых офисах.",
    image: "https://picsum.photos/1200/800?random=31",
  },
  {
    title: "Операционный апгрейд в производстве",
    category: "Производство",
    description:
      "Внедрили систему визуализации метрик и гибкие операционные совещания, что снизило время реакции отделов.",
    image: "https://picsum.photos/1200/800?random=32",
  },
  {
    title: "Лидерские программы для IT-скейлера",
    category: "Технологии",
    description:
      "Построили маршрут развития Team Lead: оценка компетенций, воркшопы по влиянию, коучинг с менторами.",
    image: "https://picsum.photos/1200/800?random=33",
  },
  {
    title: "Интеграция команд после M&A",
    category: "Сервисы",
    description:
      "Провели диагностику культуры, разработали правила совместной работы и провели серию фасилитированных сессий.",
    image: "https://picsum.photos/1200/800?random=34",
  },
];

const faqItems = [
  {
    question: "Как адаптируется обучение под конкретную компанию?",
    answer:
      "Мы начинаем с диагностики управленческой системы и интервью с ключевыми стейкхолдерами. На основе данных формируем дорожную карту обучения и согласовываем инструменты для внедрения в ежедневную практику.",
  },
  {
    question: "В каком формате проходят занятия?",
    answer:
      "Основные модули комбинируют асинхронный видеоформат, живые воркшопы в Zoom, практику в симуляторе и индивидуальные консультации. Все материалы доступны в личном кабинете.",
  },
  {
    question: "Можно ли подключать отдельные команды?",
    answer:
      "Да. Мы формируем потоки под конкретные роли — руководителей функций, операционных директоров, тимлидов. Есть корпоративные и открытые наборы.",
  },
  {
    question: "Есть ли поддержка после завершения программы?",
    answer:
      "Вы получаете доступ к закрытому сообществу выпускников и ежемесячным экспертным сессиям. Дополнительно можно подключить сопровождение наставника.",
  },
];

const blogPosts = [
  {
    title: "Как построить управленческий ритм в распределённой компании",
    date: "15 января 2024",
    excerpt:
      "Рассматриваем подходы к планированию, прозрачности задач и выстраиванию синхронизаций в мультинациональных командах.",
    link: "/biblioteka#ritm-upravleniya",
  },
  {
    title: "Метрики, которые видят и лидеры, и сотрудники",
    date: "18 декабря 2023",
    excerpt:
      "Делимся шаблонами визуального управления и рассказываем, как договориться о едином наборе показателей.",
    link: "/biblioteka#metriki",
  },
  {
    title: "Что отличает сильного руководителя в Европе",
    date: "27 ноября 2023",
    excerpt:
      "Обсуждаем культурные особенности европейского рынка и ключевые управленческие навыки, востребованные в 2024 году.",
    link: "/biblioteka#liderstvo-v-evrope",
  },
];

const Home = () => {
  const statsRef = useRef(null);
  const [inView, setInView] = useState(false);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState("Все");

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.4 }
    );
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) =>
        prev === testimonials.length - 1 ? 0 : prev + 1
      );
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects = useMemo(() => {
    if (selectedCategory === "Все") return projects;
    return projects.filter((proj) => proj.category === selectedCategory);
  }, [selectedCategory]);

  return (
    <>
      <Helmet>
        <title>
          Vensy Management Institute — обучение управлению и лидерству онлайн
        </title>
        <meta
          name="description"
          content="Современные курсы менеджмента и управленческие программы Vensy Management Institute для русскоязычных руководителей в Европе. Стратегический менеджмент, управление командами онлайн, операционные решения."
        />
        <meta
          name="keywords"
          content="курсы менеджмента Европа, управление командами онлайн, стратегический менеджмент обучение, лидерство курс, операционное управление"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <p className={styles.kicker}>Онлайн-академия для лидеров</p>
            <h1>
              Управляйте профессионально, вдохновляйте команды, укрепляйте позиции
              на европейском рынке.
            </h1>
            <p className={styles.heroSub}>
              Vensy Management Institute — образовательная платформа для руководителей,
              которым нужно объединить стратегию, операции и работу с людьми в условиях
              распределённой команды.
            </p>
            <div className={styles.heroActions}>
              <Link to="/diagnostika" className={styles.primaryCta}>
                Пройти диагностику навыков
              </Link>
              <Link to="/napravleniya" className={styles.secondaryCta}>
                Смотреть направления
              </Link>
            </div>
          </div>
          <div className={styles.heroImageWrapper} aria-hidden="true">
            <img
              src="https://picsum.photos/1600/900?random=101"
              alt="Руководители обсуждают стратегию у доски"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.statsSection} ref={statsRef}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((item, index) => (
              <div key={item.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {inView ? (
                    <AnimatedCounter target={item.value} suffix={item.suffix} />
                  ) : (
                    `0${item.suffix}`
                  )}
                </span>
                <p>{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.intro}>
        <div className="container">
          <div className={styles.introGrid}>
            <div>
              <h2>Почему руководители выбирают Vensy</h2>
              <p>
                Мы работаем с управленцами, которые создают и масштабируют бизнес в Европе.
                Наша программа сочетает стратегический менеджмент, лидерство и операционный
                апгрейд, чтобы ваш менеджмент был адаптивным и устойчивым.
              </p>
            </div>
            <div className={styles.introCard}>
              <h3>Решаем ключевые запросы</h3>
              <ul>
                <li>— Согласование стратегических ориентиров между офисами</li>
                <li>— Повышение ответственности и автономии команд</li>
                <li>— Внедрение операционных ритуалов и метрик</li>
                <li>— Развитие культуры лидерства и обратной связи</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <div className={styles.servicesHeader}>
            <h2>Области обучения</h2>
            <p>
              Сосредотачиваемся на управленческих направлениях, которые напрямую
              влияют на стратегические и операционные результаты: лидерство,
              стратегия, процессы и команды.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {serviceAreas.map((area) => (
              <article key={area.title} className={styles.serviceCard}>
                <span className={styles.icon} aria-hidden="true">
                  {area.icon}
                </span>
                <h3>{area.title}</h3>
                <p>{area.description}</p>
                <Link to="/napravleniya" className={styles.cardLink}>
                  Узнать подробнее
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <InteractiveLearningPath />

      <section className={styles.methodology}>
        <div className="container">
          <div className={styles.methodologyHeader}>
            <h2>Методология Vensy</h2>
            <p>
              Применяем гибридный подход к обучению: соединяем контент, практику
              и сопровождение. Вы получаете инструменты, которые можно внедрить завтра.
            </p>
          </div>
          <div className={styles.methodologyGrid}>
            {methodology.map((item) => (
              <article key={item.title} className={styles.methodCard}>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.testimonialWrapper}>
            <div className={styles.testimonialText}>
              <h2>Истории руководителей</h2>
              <p>
                Реальные кейсы выпускников, которые используют инструменты Vensy
                для управления стратегией и командами в разных странах.
              </p>
              <div className={styles.controls} role="tablist">
                {testimonials.map((item, index) => (
                  <button
                    key={item.name}
                    type="button"
                    className={`${styles.indicator} ${
                      currentTestimonial === index ? styles.indicatorActive : ""
                    }`}
                    onClick={() => setCurrentTestimonial(index)}
                    aria-label={`Показать отзыв ${item.name}`}
                    aria-selected={currentTestimonial === index}
                  />
                ))}
              </div>
            </div>
            <article className={styles.testimonialCard}>
              <img
                src={testimonials[currentTestimonial].image}
                alt={`Отзыв — ${testimonials[currentTestimonial].name}`}
                loading="lazy"
              />
              <blockquote>
                <p>{testimonials[currentTestimonial].quote}</p>
                <footer>
                  <strong>{testimonials[currentTestimonial].name}</strong>
                  <span>{testimonials[currentTestimonial].role}</span>
                </footer>
              </blockquote>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <h2>Кейсы выпускников и проектов</h2>
            <p>
              Посмотрите, как программы Vensy помогают выстраивать стратегию, процессы
              и командное взаимодействие в разных индустриях.
            </p>
            <div className={styles.filters} role="group" aria-label="Фильтр кейсов">
              {["Все", "Технологии", "Производство", "Сервисы"].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  className={`${styles.filterBtn} ${
                    selectedCategory === cat ? styles.filterActive : ""
                  }`}
                  onClick={() => setSelectedCategory(cat)}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img
                    src={project.image}
                    alt={`Кейс: ${project.title}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.processHeader}>
            <h2>Как строится работа</h2>
            <p>
              От данные-ориентированной диагностики до масштабирования практик — сопровождаем
              на каждом этапе пути.
            </p>
          </div>
          <div className={styles.processGrid}>
            <div className={styles.processStep}>
              <h3>1. Анализ и цели</h3>
              <p>
                Интервью, опросы и аудит материалов. Формируем карту компетенций и определяем приоритеты развития.
              </p>
            </div>
            <div className={styles.processStep}>
              <h3>2. Обучение и практика</h3>
              <p>
                Строим образовательный маршрут: мастер-классы, симуляции, рабочие шаблоны и обратная связь от экспертов.
              </p>
            </div>
            <div className={styles.processStep}>
              <h3>3. Внедрение и поддержка</h3>
              <p>
                Помогаем закрепить навыки через рабочие сессии, коучинг и сообщество. Настраиваем контрольные точки.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.faqHeader}>
            <h2>Частые вопросы</h2>
            <p>
              Если не нашли ответ — свяжитесь с командой Vensy, и мы подготовим предложение под ваши задачи.
            </p>
          </div>
          <div className={styles.accordion}>
            {faqItems.map((item, index) => (
              <AccordionItem key={item.question} item={item} defaultOpen={index === 0} />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className="container">
          <div className={styles.blogHeader}>
            <h2>Свежие материалы из библиотеки</h2>
            <p>
              Практические статьи, шаблоны и кейсы по стратегическому менеджменту,
              управлению командами и операционным решениям.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.blogLink}>
                  Читать ➜
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Начните с диагностики управленческих компетенций</h2>
              <p>
                Узнайте сильные стороны и зоны развития команды руководителей. Получите детальный отчёт и персональные рекомендации Vensy.
              </p>
            </div>
            <Link to="/diagnostika" className={styles.ctaButton}>
              Пройти диагностику
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

const AnimatedCounter = ({ target, suffix }) => {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let start = 0;
    const duration = 1200;
    const stepTime = Math.max(Math.floor(duration / target), 17);
    const timer = setInterval(() => {
      start += 1;
      if (start >= target) {
        setValue(target);
        clearInterval(timer);
      } else {
        setValue(start);
      }
    }, stepTime);
    return () => clearInterval(timer);
  }, [target]);
  return (
    <>
      {value}
      {suffix}
    </>
  );
};

const AccordionItem = ({ item, defaultOpen }) => {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className={`${styles.accordionItem} ${open ? styles.open : ""}`}>
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        className={styles.accordionTrigger}
        aria-expanded={open}
      >
        <span>{item.question}</span>
        <span aria-hidden="true" className={styles.accordionIcon}>
          {open ? "−" : "+"}
        </span>
      </button>
      {open && <p className={styles.accordionContent}>{item.answer}</p>}
    </div>
  );
};

export default Home;