import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Legal.module.css";

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Политика конфиденциальности — Vensy Management Institute</title>
        <meta
          name="description"
          content="Политика конфиденциальности Vensy Management Institute. Обработка персональных данных в соответствии с GDPR."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Политика конфиденциальности</h1>
          <p>Последнее обновление: 01 января 2024 года</p>
        </div>
      </section>
      <section className={styles.content}>
        <div className="container">
          <article>
            <h2>1. Общая информация</h2>
            <p>
              Vensy Management Institute обрабатывает персональные данные в соответствии с GDPR и законами Германии. Мы собираем только те данные,
              которые необходимы для предоставления образовательных услуг.
            </p>
          </article>
          <article>
            <h2>2. Сбор и использование данных</h2>
            <p>
              Мы собираем имя, контактные данные и информацию о компании. Данные используются для организации обучения, коммуникации и улучшения сервиса.
            </p>
          </article>
          <article>
            <h2>3. Хранение и безопасность</h2>
            <p>
              Данные хранятся на защищённых серверах в ЕС. Мы применяем технические и организационные меры безопасности, чтобы предотвратить несанкционированный доступ.
            </p>
          </article>
          <article>
            <h2>4. Права пользователей</h2>
            <p>
              Вы можете запросить доступ к данным, их исправление или удаление. Также можно отозвать согласие на обработку в любой момент.
            </p>
          </article>
          <article>
            <h2>5. Контакты</h2>
            <p>
              По вопросам конфиденциальности свяжитесь с нами: Kurfürstendamm 200, 10719 Berlin, Germany, тел. +49 30 7890 1234.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Privacy;