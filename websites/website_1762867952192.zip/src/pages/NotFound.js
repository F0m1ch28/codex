import React from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import styles from "./NotFound.module.css";

const NotFound = () => (
  <>
    <Helmet>
      <title>Страница не найдена — Vensy Management Institute</title>
      <meta
        name="description"
        content="Запрошенная страница не найдена. Вернитесь на главную Vensy Management Institute."
      />
    </Helmet>
    <section className={styles.wrapper}>
      <div className="container">
        <div className={styles.content}>
          <h1>404</h1>
          <p>Похоже, вы попали на страницу, которой нет в нашем маршруте обучения.</p>
          <Link to="/" className={styles.link}>
            На главную
          </Link>
        </div>
      </div>
    </section>
  </>
);

export default NotFound;