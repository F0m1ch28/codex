import React from "react";
import { Helmet } from "react-helmet";
import ContactForm from "../components/ContactForm";
import styles from "./Contacts.module.css";

const Contacts = () => {
  return (
    <>
      <Helmet>
        <title>Контакты — Vensy Management Institute</title>
        <meta
          name="description"
          content="Свяжитесь с Vensy Management Institute. Адрес: Kurfürstendamm 200, 10719 Berlin, Germany. Телефон: +49 30 7890 1234."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <h1>Свяжитесь с Vensy</h1>
              <p>
                Оставьте заявку на консультацию — обсудим задачи вашей команды, подберём программы и расскажем, как проходит обучение.
              </p>
              <div className={styles.info}>
                <div>
                  <h2>Адрес</h2>
                  <p>Kurfürstendamm 200, 10719 Berlin, Germany</p>
                </div>
                <div>
                  <h2>Телефон</h2>
                  <a href="tel:+493078901234">+49 30 7890 1234</a>
                </div>
              </div>
            </div>
            <div className={styles.mapWrapper}>
              <iframe
                title="Vensy Management Institute Berlin"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.6406764986925!2d13.323889515809802!3d52.50264497981008!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851c8823c3a37%3A0x8b70b5887e1d4d77!2sKurfürstendamm%20200%2C%2010719%20Berlin%2C%20Germany!5e0!3m2!1sru!2sde!4v1705516400000!5m2!1sru!2sde"
                loading="lazy"
                allowFullScreen
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.formSection}>
        <div className="container">
          <ContactForm title="Расскажите о ваших задачах" />
        </div>
      </section>
    </>
  );
};

export default Contacts;