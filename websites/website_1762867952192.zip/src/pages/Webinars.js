import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Webinars.module.css";

const webinars = [
  {
    title: "Стратегический менеджмент для распределённых команд",
    date: "5 февраля 2024",
    time: "18:00 CET",
    description:
      "Разбираем практики согласования стратегических целей и визуализации прогресса в международных компаниях.",
  },
  {
    title: "Как поставить операционный ритм в новой стране",
    date: "20 февраля 2024",
    time: "17:00 CET",
    description:
      "Инструменты запуска операционной системы: дневные и недельные циклы, метрики, синхронизации.",
  },
  {
    title: "Лидерство и доверие в гибридной работе",
    date: "7 марта 2024",
    time: "19:00 CET",
    description:
      "Управляем командой, находящейся в разных странах: создаём культуру обратной связи и поддерживаем вовлеченность.",
  },
];

const Webinars = () => {
  return (
    <>
      <Helmet>
        <title>Вебинары и мастер-классы — Vensy Management Institute</title>
        <meta
          name="description"
          content="Расписание открытых вебинаров Vensy Management Institute. Узнайте о стратегическом менеджменте, управлении командами и операционной эффективности."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Открытые вебинары Vensy</h1>
          <p>
            Присоединяйтесь к мастер-классам, чтобы получить практические инсайты и познакомиться с подходом Vensy к управлению.
          </p>
        </div>
      </section>
      <section className={styles.schedule}>
        <div className="container">
          <div className={styles.grid}>
            {webinars.map((webinar) => (
              <article key={webinar.title} className={styles.card}>
                <h2>{webinar.title}</h2>
                <p className={styles.meta}>
                  <span>{webinar.date}</span> · <span>{webinar.time}</span>
                </p>
                <p>{webinar.description}</p>
                <a
                  href="mailto:team@vensy-institute.eu?subject=Регистрация на вебинар Vensy"
                  className={styles.link}
                >
                  Зарегистрироваться
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Webinars;