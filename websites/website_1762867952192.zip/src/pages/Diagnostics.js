import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Diagnostics.module.css";

const steps = [
  {
    title: "Онлайн-тест и сбор данных",
    text: "Участники и их команды заполняют оценочные формы. Анализируем стратегическое мышление, операционные навыки и взаимодействие с людьми.",
  },
  {
    title: "Аналитический отчёт",
    text: "Формируем визуальный отчёт с картой компетенций, сравнением профилей и рекомендациями по развитию.",
  },
  {
    title: "Сессия с экспертом",
    text: "Разбираем результаты вместе с экспертом Vensy, приоритизируем задачи и формируем маршрут обучения.",
  },
];

const Diagnostics = () => {
  return (
    <>
      <Helmet>
        <title>Диагностика управленческих компетенций — Vensy Management Institute</title>
        <meta
          name="description"
          content="Оцените управленческие компетенции команды. Онлайн-диагностика Vensy выявляет сильные стороны и зоны роста в стратегическом менеджменте, лидерстве и операционных процессах."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <h1>Диагностика управленческих компетенций</h1>
              <p>
                Оцените текущий уровень развития управленческих навыков и получите персональные рекомендации по обучению.
                Диагностика помогает выбрать подходящую программу и выстроить дальнейшую поддержку.
              </p>
              <ul className={styles.highlights}>
                <li>Комплексные метрики по стратегии, операциям и лидерству</li>
                <li>Результаты в формате наглядного отчёта</li>
                <li>Рекомендации с расстановкой приоритетов</li>
              </ul>
            </div>
            <div className={styles.heroCard}>
              <h2>Что включено</h2>
              <ul>
                <li> Онлайн-оценка руководителя и 360-градусная обратная связь</li>
                <li> Сопоставление результатов между руководителями</li>
                <li> Индивидуальная консультация с экспертом Vensy</li>
              </ul>
              <a className={styles.cta} href="tel:+493078901234">
                Записаться на диагностику
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.steps}>
        <div className="container">
          <h2>Как проходит диагностика</h2>
          <div className={styles.stepsGrid}>
            {steps.map((step, index) => (
              <article key={step.title} className={styles.stepCard}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.report}>
        <div className="container">
          <div className={styles.reportGrid}>
            <img
              src="https://picsum.photos/800/600?random=81"
              alt="Отчёт по диагностике управленческих компетенций"
              loading="lazy"
            />
            <div>
              <h2>Отчёт с конкретными шагами</h2>
              <p>
                В отчёте вы увидите сильные стороны, зоны роста и конкретный список компетенций с приоритетами.
                Это помогает подготовить план развития и выбрать релевантную программу обучения.
              </p>
              <ul>
                <li>Подробные графики развития компетенций</li>
                <li>Сравнение с профильными группами</li>
                <li>Рекомендации по направлениям обучения</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Diagnostics;