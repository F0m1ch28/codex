import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Community.module.css";

const benefits = [
  "Ежемесячные встреча лидеров с разбором кейсов",
  "Доступ к библиотеке шаблонов и материалов",
  "Закрытый чат и менторские офис-ауэрс",
  "Совместные проекты и обмен опытом между компаниями",
];

const Community = () => {
  return (
    <>
      <Helmet>
        <title>Сообщество выпускников — Vensy Management Institute</title>
        <meta
          name="description"
          content="Закрытое сообщество выпускников Vensy Management Institute: совместные проекты, обмен практиками, менторские сессии и поддержка."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Сообщество Vensy</h1>
          <p>
            После прохождения программ вы присоединяетесь к сообществу управленцев, которые делятся практиками,
            поддерживают друг друга и совместно запускают инициативы.
          </p>
        </div>
      </section>
      <section className={styles.benefits}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.card}>
              <h2>Что получает участник</h2>
              <ul>
                {benefits.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
            <div className={styles.imageWrapper}>
              <img
                src="https://picsum.photos/800/600?random=111"
                alt="Участники сообщества обсуждают проект"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Community;