import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Teachers.module.css";

const teachers = [
  {
    name: "Ольга Шнайдер",
    role: "Эксперт по лидерству",
    background:
      "Более 15 лет в HR и управлении командами в Германии. Сертифицированный executive coach.",
    image: "https://picsum.photos/400/400?random=91",
  },
  {
    name: "Даниэль Вальман",
    role: "Эксперт по стратегическому менеджменту",
    background:
      "Ex-McKinsey, запуск стратегических офисов в компаниях Центральной Европы.",
    image: "https://picsum.photos/400/400?random=92",
  },
  {
    name: "Наталья Смолякова",
    role: "Эксперт по операционному менеджменту",
    background:
      "10 лет внедрения Lean и построения операционных систем в логистике и ритейле.",
    image: "https://picsum.photos/400/400?random=93",
  },
  {
    name: "Франциска Мюллер",
    role: "Эксперт по коммуникациям",
    background:
      "Специалист по трансформационным коммуникациям, работала с технологическими стартапами в Берлине и Амстердаме.",
    image: "https://picsum.photos/400/400?random=94",
  },
  {
    name: "Юрий Ким",
    role: "Эксперт по симуляторам",
    background:
      "Создатель управленческих тренажёров, ex-Product Lead EdTech компании в Варшаве.",
    image: "https://picsum.photos/400/400?random=95",
  },
  {
    name: "Хельга Вайс",
    role: "Ментор по развитию команд",
    background:
      "Работала с распределёнными командами в сфере финтех, помогает выстраивать культуру доверия и обратной связи.",
    image: "https://picsum.photos/400/400?random=96",
  },
];

const Teachers = () => {
  return (
    <>
      <Helmet>
        <title>Команда преподавателей — Vensy Management Institute</title>
        <meta
          name="description"
          content="Команда Vensy Management Institute: эксперты по стратегическому менеджменту, лидерству, управлению командами и операционным решениям."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Преподаватели и менторы</h1>
          <p>
            С вами работают практики — управленцы, которые ежедневно решают задачи в европейских компаниях.
            Они делятся инструментами, проверенными на практике.
          </p>
        </div>
      </section>
      <section className={styles.gridSection}>
        <div className="container">
          <div className={styles.grid}>
            {teachers.map((teacher) => (
              <article key={teacher.name} className={styles.card}>
                <img src={teacher.image} alt={`${teacher.name} — ${teacher.role}`} loading="lazy" />
                <div className={styles.info}>
                  <h2>{teacher.name}</h2>
                  <p className={styles.role}>{teacher.role}</p>
                  <p className={styles.background}>{teacher.background}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Teachers;