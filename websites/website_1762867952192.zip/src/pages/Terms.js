import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Legal.module.css";

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Пользовательское соглашение — Vensy Management Institute</title>
        <meta
          name="description"
          content="Пользовательское соглашение Vensy Management Institute. Правила использования платформы и образовательных материалов."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Пользовательское соглашение</h1>
          <p>Последнее обновление: 01 января 2024 года</p>
        </div>
      </section>
      <section className={styles.content}>
        <div className="container">
          <article>
            <h2>1. Общие положения</h2>
            <p>
              Настоящее соглашение определяет условия использования образовательной платформы Vensy Management Institute. Пользователь подтверждает,
              что ознакомился с документом и принимает изложенные условия.
            </p>
          </article>
          <article>
            <h2>2. Регистрация и доступ</h2>
            <p>
              Для доступа к материалам необходимо создать личный кабинет. Пользователь обязуется предоставить достоверные данные и своевременно их обновлять.
            </p>
          </article>
          <article>
            <h2>3. Использование материалов</h2>
            <p>
              Материалы платформы предназначены для личного профессионального развития и не могут передаваться третьим лицам без письменного согласия Vensy Management Institute.
            </p>
          </article>
          <article>
            <h2>4. Ответственность сторон</h2>
            <p>
              Пользователь самостоятельно отвечает за принятие управленческих решений. Vensy предоставляет образовательные рекомендации и инструменты для анализа.
            </p>
          </article>
          <article>
            <h2>5. Заключительные положения</h2>
            <p>
              Vensy Management Institute оставляет за собой право изменять условия соглашения. Обновленная версия публикуется на официальном сайте.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Terms;