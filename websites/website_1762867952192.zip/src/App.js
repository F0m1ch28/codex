import React, { useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTopButton from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Simulator from "./pages/Simulator";
import Diagnostics from "./pages/Diagnostics";
import Library from "./pages/Library";
import Webinars from "./pages/Webinars";
import Teachers from "./pages/Teachers";
import Community from "./pages/Community";
import Contacts from "./pages/Contacts";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import CookiePolicy from "./pages/CookiePolicy";
import NotFound from "./pages/NotFound";

const App = () => {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [location.pathname]);

  return (
    <div className="app-shell">
      <Header />
      <main id="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/o-nas" element={<About />} />
          <Route path="/napravleniya" element={<Services />} />
          <Route path="/simulyator" element={<Simulator />} />
          <Route path="/diagnostika" element={<Diagnostics />} />
          <Route path="/biblioteka" element={<Library />} />
          <Route path="/webinary" element={<Webinars />} />
          <Route path="/prepodavateli" element={<Teachers />} />
          <Route path="/community" element={<Community />} />
          <Route path="/kontakty" element={<Contacts />} />
          <Route path="/soglashenie" element={<Terms />} />
          <Route path="/politika" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;