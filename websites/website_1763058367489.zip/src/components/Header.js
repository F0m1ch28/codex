```javascript
import { useState } from "react";
import { NavLink } from "react-router-dom";

const navLinks = [
  { to: "/", label: "Главная" },
  { to: "/gallery", label: "Галерея" },
  { to: "/about", label: "О нас" },
  { to: "/contact", label: "Контакты" }
];

function Header() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen((prev) => !prev);
  const closeMenu = () => setIsOpen(false);

  return {
    /* Using JSX fragment to keep structure simple */
  }(
    <header className="header">
      <div className="header__inner">
        <div className="header__logo" aria-label="Логотип галереи">
          Логотип галереи
        </div>
        <button
          className="header__toggle"
          onClick={toggleMenu}
          aria-expanded={isOpen}
          aria-label="Меню"
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`header__nav ${isOpen ? "header__nav--open" : ""}`}>
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              onClick={closeMenu}
              className={({ isActive }) =>
                isActive ? "header__link header__link--active" : "header__link"
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
}

export default Header;
```