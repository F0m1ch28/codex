```javascript
import { useEffect, useState } from "react";

const STORAGE_KEY = "artgallery-cookie-consent";

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <p>Мы используем файлы cookie для улучшения работы сайта.</p>
      <button onClick={acceptCookies} className="button button--accent">
        Принять
      </button>
    </div>
  );
}

export default CookieBanner;
```