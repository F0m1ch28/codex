```javascript
function Footer() {
  return (
    <footer className="footer">
      <div className="footer__inner">
        <div className="footer__column">
          <h4 className="footer__title">Контакты</h4>
          <p>г. Москва, ул. Искусств, д. 15</p>
          <p>Телефон: <a href="tel:+74951234567">+7 (495) 123-45-67</a></p>
          <p>Email: <a href="mailto:info@artgallery.ru">info@artgallery.ru</a></p>
        </div>
        <div className="footer__column">
          <h4 className="footer__title">Социальные сети</h4>
          <ul className="footer__list">
            <li><a href="https://www.instagram.com" target="_blank" rel="noreferrer">Instagram</a></li>
            <li><a href="https://www.facebook.com" target="_blank" rel="noreferrer">Facebook</a></li>
            <li><a href="https://t.me" target="_blank" rel="noreferrer">Telegram</a></li>
          </ul>
        </div>
        <div className="footer__column">
          <p className="footer__note">
            © {new Date().getFullYear()} Современная художественная галерея.
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
```