```javascript
import { useEffect, useState } from "react";

const slides = [
  {
    id: 1,
    title: "Актуальное искусство",
    description:
      "Погрузитесь в атмосферу современной живописи и скульптуры.",
    image:
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80"
  },
  {
    id: 2,
    title: "Экспозиции мирового уровня",
    description:
      "Знакомимся с художниками из разных стран и культур.",
    image:
      "https://images.unsplash.com/photo-1475666675596-cca2035b3d79?auto=format&fit=crop&w=1200&q=80"
  },
  {
    id: 3,
    title: "Новые имена в искусстве",
    description:
      "Открываем талантливых авторов и поддерживаем молодые проекты.",
    image:
      "https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&w=1200&q=80"
  }
];

const exhibitions = [
  { title: "Диалог цвета", date: "Март — Апрель 2024" },
  { title: "Пластика форм", date: "Май 2024" },
  { title: "Свет и тень", date: "Июнь 2024" }
];

const events = [
  { title: "Лекция о современном искусстве", date: "18 апреля" },
  { title: "Творческая встреча с художником", date: "27 апреля" },
  { title: "Музыкальный перформанс", date: "5 мая" }
];

const arrivals = [
  { title: "Серия «Городские ритмы»", author: "Анна Волкова" },
  { title: "Скульптура «Созвучие»", author: "Михаил Смирнов" },
  { title: "Фотоцикл «Времена года»", author: "Екатерина Ли" }
];

const reviews = [
  {
    name: "Ирина П.",
    text: "Прекрасное пространство, тщательно подобранные экспозиции и вдохновляющая атмосфера."
  },
  {
    name: "Андрей С.",
    text: "Понравились экскурсии и внимательное отношение команды. Обязательно приду снова."
  }
];

function Home() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const id = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="home">
      <section className="hero">
        {slides.map((slide, index) => (
          <article
            key={slide.id}
            className={`hero__slide ${
              index === currentSlide ? "hero__slide--active" : ""
            }`}
            style={{ backgroundImage: `url(${slide.image})` }}
            aria-hidden={index !== currentSlide}
          >
            <div className="hero__content">
              <h1>{slide.title}</h1>
              <p>{slide.description}</p>
            </div>
          </article>
        ))}
        <div className="hero__controls">
          {slides.map((slide, index) => (
            <button
              key={slide.id}
              aria-label={`Слайд ${index + 1}`}
              className={`hero__dot ${
                index === currentSlide ? "hero__dot--active" : ""
              }`}
              onClick={() => setCurrentSlide(index)}
            />
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section__header">
          <h2>Популярные выставки</h2>
          <p>Лучшие экспозиции сезона от признанных мастеров и молодых авторов.</p>
        </div>
        <div className="cards">
          {exhibitions.map((item) => (
            <article className="card" key={item.title}>
              <h3>{item.title}</h3>
              <p>{item.date}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section section--alt">
        <div className="section__header">
          <h2>Текущие мероприятия</h2>
          <p>Ежемесячная программа образовательных и культурных событий.</p>
        </div>
        <ul className="timeline">
          {events.map((event) => (
            <li key={event.title}>
              <span className="timeline__date">{event.date}</span>
              <span className="timeline__title">{event.title}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="section">
        <div className="section__header">
          <h2>Новые поступления</h2>
          <p>Свежие работы из коллекции галереи.</p>
        </div>
        <div className="cards cards--compact">
          {arrivals.map((item) => (
            <article className="card card--compact" key={item.title}>
              <h3>{item.title}</h3>
              <p>{item.author}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section section--alt">
        <div className="section__header">
          <h2>Отзывы посетителей</h2>
        </div>
        <div className="reviews">
          {reviews.map((review) => (
            <blockquote className="review" key={review.name}>
              <p>“{review.text}”</p>
              <cite>{review.name}</cite>
            </blockquote>
          ))}
        </div>
      </section>
    </div>
  );
}

export default Home;
```