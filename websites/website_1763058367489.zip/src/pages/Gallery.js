```javascript
import { useMemo, useState } from "react";

const artworks = [
  {
    id: 1,
    title: "Гармония",
    author: "Илья Петров",
    category: "Живопись",
    image:
      "https://images.unsplash.com/photo-1516431885873-2c23f26f15ea?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 2,
    title: "Лёд и пламя",
    author: "София Кузнецова",
    category: "Скульптура",
    image:
      "https://images.unsplash.com/photo-1563132330-251b05c58df7?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 3,
    title: "Городские линии",
    author: "Мария Андреева",
    category: "Фотография",
    image:
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 4,
    title: "Цифровой ландшафт",
    author: "Данила Орлов",
    category: "Цифровое искусство",
    image:
      "https://images.unsplash.com/photo-1533750349088-cd871a92f312?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 5,
    title: "Рассвет",
    author: "Елена Лебедева",
    category: "Живопись",
    image:
      "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=800&q=80"
  }
];

const filters = [
  "Все",
  "Живопись",
  "Скульптура",
  "Фотография",
  "Цифровое искусство"
];

function Gallery() {
  const [activeFilter, setActiveFilter] = useState("Все");

  const filteredArtworks = useMemo(() => {
    if (activeFilter === "Все") {
      return artworks;
    }
    return artworks.filter((art) => art.category === activeFilter);
  }, [activeFilter]);

  return (
    <section className="gallery">
      <div className="section__header">
        <h1>Галерея</h1>
        <p>Исследуйте коллекцию работ в удобном формате.</p>
      </div>

      <div className="filters" role="tablist" aria-label="Фильтры">
        {filters.map((filter) => (
          <button
            key={filter}
            role="tab"
            aria-selected={activeFilter === filter}
            className={`filter ${activeFilter === filter ? "filter--active" : ""}`}
            onClick={() => setActiveFilter(filter)}
          >
            {filter}
          </button>
        ))}
      </div>

      <div className="gallery__grid">
        {filteredArtworks.map((art) => (
          <article className="art-card" key={art.id}>
            <figure>
              <img src={art.image} alt={`${art.title} — ${art.author}`} loading="lazy" />
              <figcaption>
                <h3>{art.title}</h3>
                <p>{art.author}</p>
                <span>{art.category}</span>
              </figcaption>
            </figure>
          </article>
        ))}
      </div>
    </section>
  );
}

export default Gallery;
```