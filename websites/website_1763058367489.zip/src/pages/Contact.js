```javascript
import { useState } from "react";

const initialState = {
  name: "",
  email: "",
  message: ""
};

function Contact() {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Введите имя";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Введите email";
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = "Некорректный email";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Введите сообщение";
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <section className="contact">
      <div className="section__header">
        <h1>Контакты</h1>
        <p>Мы открыты для сотрудничества, вопросов и предложений.</p>
      </div>

      <div className="contact__grid">
        <form className="contact__form" onSubmit={handleSubmit} noValidate>
          <label>
            Имя
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? "name-error" : undefined}
              placeholder="Ваше имя"
            />
            {errors.name && (
              <span className="error" id="name-error">
                {errors.name}
              </span>
            )}
          </label>

          <label>
            Email
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? "email-error" : undefined}
              placeholder="you@example.com"
            />
            {errors.email && (
              <span className="error" id="email-error">
                {errors.email}
              </span>
            )}
          </label>

          <label>
            Сообщение
            <textarea
              name="message"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? "message-error" : undefined}
              placeholder="Ваше сообщение"
            />
            {errors.message && (
              <span className="error" id="message-error">
                {errors.message}
              </span>
            )}
          </label>

          <button type="submit" className="button button--primary">
            Отправить
          </button>

          {submitted && (
            <p className="success">Спасибо! Мы свяжемся с вами в ближайшее время.</p>
          )}
        </form>

        <div className="contact__info">
          <h2>Как нас найти</h2>
          <p>г. Москва, ул. Искусств, д. 15</p>
          <p>Телефон: <a href="tel:+74951234567">+7 (495) 123-45-67</a></p>
          <p>Email: <a href="mailto:info@artgallery.ru">info@artgallery.ru</a></p>
          <p>Режим работы: ежедневно с 10:00 до 20:00</p>

          <div className="contact__map" role="presentation">
            <iframe
              title="Карта проезда"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.585709913781!2d37.620393615935276!3d55.75396098055316!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTXCsDQ1JzE0LjMiTiAzN8KwMzcnMjMuNSJF!5e0!3m2!1sru!2sru!4v1618327571468!5m2!1sru!2sru"
              width="100%"
              height="280"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

export default Contact;
```