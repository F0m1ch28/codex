document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      nav.classList.toggle("active");
    });
  }

  const yearEl = document.getElementById("current-year");
  if (yearEl) {
    yearEl.textContent = String(new Date().getFullYear());
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  document.querySelectorAll(".fade-section").forEach((section) => observer.observe(section));

  const toast = document.getElementById("global-toast");
  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    setTimeout(() => {
      toast.classList.remove("is-visible");
    }, 2400);
  }

  document.querySelectorAll("form[data-redirect]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const redirectUrl = form.getAttribute("data-redirect") || "thank-you.html";
      showToast("Submission received. Redirecting…");
      setTimeout(() => {
        form.submit();
      }, 800);
      setTimeout(() => {
        window.location.href = redirectUrl;
      }, 1600);
    });
  });

  const cookieBanner = document.querySelector("[data-component='cookie-banner']");
  const acceptBtn = cookieBanner?.querySelector("[data-cookie-accept]");
  const declineBtn = cookieBanner?.querySelector("[data-cookie-decline]");
  const cookieKey = "crbtCookieChoice";

  function hideBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove("is-visible");
    }
  }

  function showBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add("is-visible");
    }
  }

  if (!localStorage.getItem(cookieKey)) {
    showBanner();
  }

  acceptBtn?.addEventListener("click", () => {
    localStorage.setItem(cookieKey, "accepted");
    hideBanner();
    showToast("Cookies accepted.");
  });

  declineBtn?.addEventListener("click", () => {
    localStorage.setItem(cookieKey, "declined");
    hideBanner();
    showToast("Cookies declined.");
  });
});