document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    const yearElements = document.querySelectorAll('#currentYear');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieButtons = document.querySelectorAll('[data-cookie-action]');
    const cookieStorageKey = 'polypesruwCookiePreference';

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            const isOpen = navLinks.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('is-open')) {
                    navLinks.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (yearElements.length > 0) {
        const currentYear = new Date().getFullYear();
        yearElements.forEach(element => {
            element.textContent = currentYear;
        });
    }

    if (cookieBanner) {
        const storedPreference = localStorage.getItem(cookieStorageKey);
        if (!storedPreference) {
            setTimeout(() => {
                cookieBanner.classList.add('is-visible');
            }, 800);
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const action = button.getAttribute('data-cookie-action');
                localStorage.setItem(cookieStorageKey, action);
                cookieBanner.classList.remove('is-visible');
            });
        });
    }
});