document.addEventListener('DOMContentLoaded', function () {
  const header = document.querySelector('.site-header');
  const navToggle = document.querySelector('.mobile-nav-toggle');
  const nav = document.querySelector('.site-nav');
  const navLinks = document.querySelectorAll('.site-nav .nav-link');
  const yearSpans = document.querySelectorAll('[id^="current-year"]');
  const currentYear = new Date().getFullYear();

  yearSpans.forEach(function (span) {
    span.textContent = currentYear;
  });

  if (navToggle && nav) {
    navToggle.addEventListener('click', function () {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
      nav.dataset.visible = (!expanded).toString();
    });

    navLinks.forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.innerWidth < 768) {
          nav.dataset.visible = 'false';
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');
  const consentKey = 'auroraCookieConsent';

  if (cookieBanner && acceptBtn && declineBtn) {
    const existingConsent = localStorage.getItem(consentKey);
    if (existingConsent === 'accepted' || existingConsent === 'declined') {
      cookieBanner.setAttribute('hidden', 'hidden');
    } else {
      cookieBanner.removeAttribute('hidden');
    }

    acceptBtn.addEventListener('click', function () {
      localStorage.setItem(consentKey, 'accepted');
      cookieBanner.setAttribute('hidden', 'hidden');
    });

    declineBtn.addEventListener('click', function () {
      localStorage.setItem(consentKey, 'declined');
      cookieBanner.setAttribute('hidden', 'hidden');
    });
  }
});