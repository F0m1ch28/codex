<?php
header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You | Aurora Solar Canada</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow">
  <meta name="theme-color" content="#3498DB">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700&family=Source+Sans+Pro:wght@400;600;700&display=swap">
  <link rel="stylesheet" href="styles.css">
  <link rel="icon" href="favicon.svg" type="image/svg+xml">
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to main content</a>
  <header class="site-header">
    <div class="container">
      <a class="brand" href="index.html">
        <span class="brand-mark" aria-hidden="true">A</span>
        <span class="brand-text">Aurora Solar Canada</span>
      </a>
      <button class="mobile-nav-toggle" aria-controls="primary-navigation" aria-expanded="false">
        <span class="visually-hidden">Toggle navigation</span>
        <span class="toggle-bar"></span>
        <span class="toggle-bar"></span>
        <span class="toggle-bar"></span>
      </button>
      <nav class="site-nav" id="primary-navigation" data-visible="false">
        <ul>
          <li><a class="nav-link" href="index.html">Home</a></li>
          <li><a class="nav-link" href="solutions.html">Solutions</a></li>
          <li><a class="nav-link" href="technology.html">Technology</a></li>
          <li><a class="nav-link" href="projects.html">Projects</a></li>
          <li><a class="nav-link" href="consulting.html">Consulting</a></li>
          <li><a class="nav-link" href="contact.html">Contact</a></li>
          <li><a class="nav-link" href="faq.html">FAQ</a></li>
        </ul>
      </nav>
    </div>
  </header>
  <main id="main-content">
    <section class="page-hero">
      <div class="container hero-layout">
        <div class="hero-text">
          <span class="hero-kicker">Submission Received</span>
          <h1>Thank You</h1>
          <p>Your message has been delivered to Aurora Solar Canada. A member of our advisory team will reach out shortly to continue the conversation.</p>
          <div class="hero-actions">
            <a class="btn btn-primary" href="index.html">Return to Home</a>
            <a class="btn btn-secondary" href="projects.html">Explore Case Studies</a>
          </div>
        </div>
        <div class="hero-visual">
          <img src="https://picsum.photos/seed/aurora-thankyou/1080/760" alt="Aurora Solar Canada team acknowledging inquiry submission" loading="lazy">
        </div>
      </div>
    </section>
  </main>
  <footer class="site-footer">
    <div class="container footer-grid">
      <div class="footer-brand">
        <a class="brand" href="index.html">
          <span class="brand-mark" aria-hidden="true">A</span>
          <span class="brand-text">Aurora Solar Canada</span>
        </a>
        <p>Smart monitoring, analytics, and supervision for Canada’s large-scale solar farms.</p>
      </div>
      <div>
        <h3>Navigation</h3>
        <ul class="footer-nav">
          <li><a href="solutions.html">Solutions</a></li>
          <li><a href="technology.html">Technology</a></li>
          <li><a href="projects.html">Projects</a></li>
          <li><a href="consulting.html">Consulting</a></li>
          <li><a href="contact.html">Contact</a></li>
          <li><a href="faq.html">FAQ</a></li>
          <li><a href="terms.html">Terms</a></li>
          <li><a href="privacy.html">Privacy</a></li>
        </ul>
      </div>
      <div>
        <h3>Connect</h3>
        <ul class="footer-contact">
          <li>Aurora Solar Canada</li>
          <li>Brookfield Place, 181 Bay Street, Suite 2500</li>
          <li>Toronto, ON M5J 2T3, Canada</li>
          <li><a href="tel:+16475550199">+1 647 555 0199</a></li>
          <li><a href="mailto:solutions@aurorasolar.ca">solutions@aurorasolar.ca</a></li>
        </ul>
      </div>
    </div>
    <div class="container footer-meta">
      <span>© <span id="current-year-thanks">2024</span> Aurora Solar Canada. All rights reserved.</span>
      <span>Operating nationwide with headquarters in Toronto, Ontario.</span>
    </div>
  </footer>
  <div class="cookie-banner" id="cookie-banner" role="dialog" aria-live="polite" aria-modal="false" aria-label="Cookie consent">
    <p>We use analytics and functional cookies to enhance solar farm management experiences in Canada. Choose Accept to support advanced insights or Decline to opt out of optional tracking.</p>
    <div class="cookie-actions">
      <button type="button" class="btn btn-secondary" id="cookie-decline">Decline</button>
      <button type="button" class="btn btn-primary" id="cookie-accept">Accept</button>
    </div>
  </div>
  <script src="script.js" defer></script>
</body>
</html>