document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            siteNav.classList.toggle('open');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-btn');
    const cookieKey = 'cbrCookiePreference';

    if (cookieBanner) {
        const preference = localStorage.getItem(cookieKey);
        if (!preference) {
            cookieBanner.classList.add('active');
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', () => {
                const choice = button.dataset.choice;
                localStorage.setItem(cookieKey, choice);
                cookieBanner.classList.remove('active');
            });
        });
    }

    const searchInput = document.querySelector('#post-search');
    const categoryFilters = document.querySelectorAll('.category-filters input[type="checkbox"]');
    const postCards = document.querySelectorAll('[data-post-title]');

    const filterPosts = () => {
        const query = searchInput ? searchInput.value.toLowerCase() : '';
        const activeCategories = Array.from(categoryFilters)
            .filter(input => input.checked)
            .map(input => input.value);

        postCards.forEach(card => {
            const title = card.dataset.postTitle.toLowerCase();
            const categories = card.dataset.categories.split(',');
            const matchesQuery = !query || title.includes(query);
            const matchesCategory = activeCategories.length === 0 || activeCategories.some(cat => categories.includes(cat));
            card.style.display = matchesQuery && matchesCategory ? '' : 'none';
        });
    };

    if (searchInput) {
        searchInput.addEventListener('input', filterPosts);
    }

    categoryFilters.forEach(input => {
        input.addEventListener('change', filterPosts);
    });
});