```javascript
document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".main-navigation");
  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector("[data-cookie='accept']");
  const declineBtn = document.querySelector("[data-cookie='decline']");
  const COOKIE_KEY = "ndm_cookie_consent";

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
      if (isOpen) {
        navToggle.classList.add("is-active");
      } else {
        navToggle.classList.remove("is-active");
      }
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (window.innerWidth < 768) {
          nav.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const consentPreference = localStorage.getItem(COOKIE_KEY);
  if (!consentPreference && cookieBanner) {
    cookieBanner.hidden = false;
    requestAnimationFrame(() => cookieBanner.classList.add("is-visible"));
  }

  const handleConsent = (value) => {
    localStorage.setItem(COOKIE_KEY, value);
    if (cookieBanner) {
      cookieBanner.classList.remove("is-visible");
      setTimeout(() => {
        cookieBanner.hidden = true;
      }, 320);
    }
  };

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => handleConsent("accepted"));
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => handleConsent("declined"));
  }

  const contactForm = document.querySelector("[data-validate='contact']");
  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      let isValid = true;
      const name = formData.get("name")?.trim();
      const email = formData.get("email")?.trim();
      const message = formData.get("message")?.trim();
      const errorContainer = contactForm.querySelector(".error-message");

      if (!name || !email || !message) {
        isValid = false;
        if (errorContainer) {
          errorContainer.textContent = "Please complete the required fields before submitting.";
        }
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        isValid = false;
        if (errorContainer) {
          errorContainer.textContent = "Please enter a valid email address.";
        }
      }

      if (isValid) {
        if (errorContainer) {
          errorContainer.textContent = "";
        }
        contactForm.reset();
        alert("Thank you! Our analytics team will respond within one business day.");
      }
    });
  }
});
```