document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.querySelector(".primary-nav");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      navToggle.classList.toggle("is-active");
      navMenu.classList.toggle("is-open");
    });
  }

  const consentKey = "neurasite-cookie-consent";
  const banners = document.querySelectorAll("[data-cookie-banner]");
  const acceptButtons = document.querySelectorAll("[data-cookie-accept]");
  const declineButtons = document.querySelectorAll("[data-cookie-decline]");
  const storedConsent = localStorage.getItem(consentKey);

  const hideBanners = () => {
    banners.forEach((banner) => banner.classList.add("hidden"));
  };

  if (storedConsent === "accepted" || storedConsent === "declined") {
    hideBanners();
  }

  acceptButtons.forEach((button) => {
    button.addEventListener("click", () => {
      localStorage.setItem(consentKey, "accepted");
      hideBanners();
    });
  });

  declineButtons.forEach((button) => {
    button.addEventListener("click", () => {
      localStorage.setItem(consentKey, "declined");
      hideBanners();
    });
  });

  const simulatorOutput = document.querySelector("[data-simulator-output]");
  const simulateButton = document.querySelector("[data-simulate]");
  if (simulateButton && simulatorOutput) {
    simulateButton.addEventListener("click", () => {
      const industry = document.querySelector("#industry")?.value || "universal";
      const goal = document.querySelector("#goal")?.value || "experience";
      const deadline = document.querySelector("#deadline")?.value || 14;
      const recommendations = {
        ecommerce: "Каталог, персональні рекомендації, чек-аут з AI-пропозиціями.",
        saas: "Сторінки рішень, інтерактивні демо, onboarding та центр ресурсів.",
        consulting: "Портфоліо кейсів, AI-сторітелінг команди, форма запиту консультації.",
        education: "Модулі курсів, прогрес навчання, інтеграція LMS.",
        healthcare: "Сторінки послуг, бронювання, інтеграція телемедицини."
      };
      const goals = {
        sales: "Конверсійні CTA, лендінги для кампаній, AI-лідогенерація.",
        branding: "Іміджеві блоки, анімовані історії, соціальні докази.",
        education: "Нотатки знань, інфографіка та розумний пошук по ресурсам.",
        community: "Платформа спільноти, програма лояльності та рекомендації контенту."
      };
      const industryText = recommendations[industry] || recommendations.ecommerce;
      const goalText = goals[goal] || goals.sales;
      simulatorOutput.textContent = `Фреймворк: ${industryText} Основна стратегія: ${goalText} План впровадження у межах ${deadline} днів з двома ревізіями дизайну та автоматичним SEO-аудитом.`;
    });
  }
});