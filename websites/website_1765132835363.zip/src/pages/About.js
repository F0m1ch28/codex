import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Наталія Коваль',
    role: 'Головний кінолог, спеціаліст з поведінки',
    description:
      '12 років працює з німецькими вівчарками, сертифікована FCI та IAABC. Розробляє програми корекції реактивності.',
    image: 'https://picsum.photos/400/400?random=301',
  },
  {
    name: 'Пйотр Новак',
    role: 'Тренер з підготовки до виставок',
    description:
      'Суддя національних рингів, ділиться лайфхаками щодо презентації вівчарок, пози і рингу.',
    image: 'https://picsum.photos/400/400?random=302',
  },
  {
    name: 'Ірина Шиманська',
    role: 'Кінолог-практик, робота з молодими собаками',
    description:
      'Створює програми для щенят і проводить сімейні воркшопи з комунікації та соціалізації.',
    image: 'https://picsum.photos/400/400?random=303',
  },
  {
    name: 'Міхал Домбровський',
    role: 'Інструктор зі спеціальних навичок',
    description:
      'Колишній тренер службових собак. Відповідає за фокус, витривалість та обстановку підвищеної складності.',
    image: 'https://picsum.photos/400/400?random=304',
  },
];

const values = [
  {
    title: 'Прозорість',
    text: 'Чітко пояснюємо, чому використовуємо ту чи іншу методику, та документуємо прогрес після кожного заняття.',
  },
  {
    title: 'Навчання через довіру',
    text: 'Собака розкриває потенціал, коли відчуває підтримку. Ми будуємо безпечне середовище та дбаємо про баланс навантажень.',
  },
  {
    title: 'Науковий підхід',
    text: 'Аналізуємо поведінку, використовуємо протоколи з етичних джерел і постійно оновлюємо свої знання.',
  },
];

const milestones = [
  {
    year: '2012',
    title: 'Перші групи у Варшаві',
    description: 'Відкрили невеликий авторський курс для вівчарок службового призначення.',
  },
  {
    year: '2016',
    title: 'Розширення до Кракова',
    description: 'Створили майданчик з можливістю тренувань у різних сценаріях міського життя.',
  },
  {
    year: '2019',
    title: 'Сертифікація FCI',
    description: 'Команда отримала міжнародні підтвердження компетенцій та почала брати участь у семінарах ЄС.',
  },
  {
    year: '2023',
    title: 'Програма підтримки власників',
    description: 'Запустили менторські сесії та онлайн-супровід після закінчення базового курсу.',
  },
];

const About = () => {
  usePageMeta({
    title: 'Про нас | Професійне дресирування собак',
    description:
      'Команда сертифікованих кінологів у Варшаві та Кракові. Ми спеціалізуємося на німецьких вівчарках та працюємо за сучасними методиками.',
    keywords:
      'кінолог Варшава, кінолог Краків, команда тренерів, дресирування німецьких вівчарок, професійне дресирування',
  });

  return (
    <div className={styles.about}>
      <section className={styles.intro}>
        <div className={styles.introText}>
          <h1>Створюємо команду людини та німецької вівчарки</h1>
          <p>
            «Професійне дресирування собак» — це команда кінологів, які працюють у Варшаві та Кракові. Ми тренуємо,
            консультуємо й підтримуємо власників, щоб кожна вівчарка почувалася впевненою, соціалізованою та корисною
            для своєї родини чи служби.
          </p>
          <p>
            Наші тренери регулярно проходять навчання, співпрацюють із ветеринарними поведінковими спеціалістами та
            залучають сучасні техніки роботи з собаками робочих порід. Ми глибоко переконані: довіра створює дисципліну,
            а продумана структура — стабільний результат.
          </p>
        </div>
        <div className={styles.introMedia}>
          <img
            src="https://picsum.photos/900/650?random=305"
            alt="Команда кінологів під час тренування з собакою"
          />
        </div>
      </section>

      <section className={styles.values}>
        <div className={styles.sectionHeader}>
          <h2>Наші цінності</h2>
          <p>Три принципи, які ми застосовуємо щодня й передаємо власникам собак.</p>
        </div>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.milestones}>
        <div className={styles.sectionHeader}>
          <h2>Віхи нашого розвитку</h2>
          <p>Кілька важливих моментів, які сформували підхід до роботи з вівчарками.</p>
        </div>
        <div className={styles.timeline}>
          {milestones.map((milestone) => (
            <article key={milestone.year} className={styles.timelineItem}>
              <span className={styles.year}>{milestone.year}</span>
              <h3>{milestone.title}</h3>
              <p>{milestone.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.team}>
        <div className={styles.sectionHeader}>
          <h2>Команда сертифікованих тренерів</h2>
          <p>Ми поєднали різні спеціалізації, щоб покрити всі етапи розвитку німецької вівчарки.</p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={member.name} loading="lazy" />
              <div className={styles.teamContent}>
                <h3>{member.name}</h3>
                <span className={styles.teamRole}>{member.role}</span>
                <p>{member.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.certifications}>
        <div className={styles.certContent}>
          <h2>Міжнародні сертифікації та партнерства</h2>
          <p>
            Ми дотримуємося стандартів FCI та IAABC, беремо участь у міжнародних конференціях, обмінюємося досвідом із
            колегами з Німеччини, Чехії та Швеції. Це дозволяє впроваджувати сучасні підходи до тренувань і поведінкової
            терапії.
          </p>
          <ul>
            <li>Сертифікати FCI для інструкторів та хендлерів.</li>
            <li>Членство у спільноті IAABC (International Association of Animal Behavior Consultants).</li>
            <li>Щорічні семінари з робочими вівчарками та службовими собаками.</li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default About;