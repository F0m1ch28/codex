import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Services.module.css';

const serviceCategories = [
  {
    id: 'obedience',
    title: 'Комплекс базового послуху',
    description:
      'Вчимо слухняності, основних сигналів і контролю поведінки у місті. Програма підходить щенятам і дорослим собакам.',
    highlights: [
      'Команди сидіти/лежати/залишайся у реальних умовах',
      'Робота з повідком і витримкою',
      'Підсилення контакту з власником',
      'Підготовка до сертифікації з послуху',
    ],
  },
  {
    id: 'behaviour',
    title: 'Корекція поведінкових викликів',
    description:
      'Допомагаємо впоратися з агресією з переляку, надмірною настороженістю, гіперактивністю або страхами.',
    highlights: [
      'Аналіз тригерів і тристоронній план (собака-власник-середовище)',
      'Побудова безпечних ритуалів',
      'Методики десенсибілізації та контробумовлення',
      'Підтримка між сесіями у форматі консультацій',
    ],
  },
  {
    id: 'show',
    title: 'Підготовка до виставок та змагань',
    description:
      'Формуємо виступний стиль, тренуємо правильну ходу, пози, контакти та реакцію на шум.',
    highlights: [
      'Моделювання рингової обстановки',
      'Менторство хендлера',
      'Фітнес план для витривалості та балансу',
      'Психоемоційна стабілізація перед виступами',
    ],
  },
  {
    id: 'advanced',
    title: 'Робочі задачі та спецпідготовка',
    description:
      'Тренуємо собак для служби, спорту IPO, Nosework і охоронних функцій, враховуючи вимоги породи.',
    highlights: [
      'Пошукові вправи та побудова витривалості',
      'Чіткі алгоритми охорони і патрулювання',
      'Вправи на концентрацію і буксирування',
      'Співпраця з інструкторами безпеки',
    ],
  },
];

const groupFormats = [
  {
    title: 'Індивідуальні сесії',
    text: 'Персональні заняття з кінологом. Розробляємо стратегію, яка враховує ваш графік і потреби собаки.',
  },
  {
    title: 'Малі групи',
    text: 'Зустрічі до 4 собак з подібними цілями. Практикуємо соціалізацію та роботу у відволікаючих умовах.',
  },
  {
    title: 'Онлайн-супровід',
    text: 'Відеозв’язок між сесіями, аналіз домашніх тренувань, відповіді на запитання у зручний час.',
  },
];

const Services = () => {
  usePageMeta({
    title: 'Послуги з дресирування німецьких вівчарок | Варшава та Краків',
    description:
      'Комплексні програми дресирування: базовий послух, корекція поведінки, підготовка до виставок та спецпідготовка для німецьких вівчарок.',
    keywords:
      'послуги кінолога Варшава, послуги кінолога Краків, дресирування німецьких вівчарок, корекція поведінки собак',
  });

  const [activeCategory, setActiveCategory] = useState(serviceCategories[0].id);

  const activeData = serviceCategories.find((category) => category.id === activeCategory);

  return (
    <div className={styles.services}>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Послуги, які адаптуються до вашого собаки</h1>
          <p>
            Ми працюємо крок за кроком, аналізуємо прогрес після кожної зустрічі та коригуємо програму залежно від
            потреб німецької вівчарки та сім’ї. Виберіть напрямок та зв’яжіться з нами для стартової консультації.
          </p>
        </div>
      </section>

      <section className={styles.categories}>
        <div className={styles.tabs} role="tablist" aria-label="Напрямки послуг">
          {serviceCategories.map((category) => (
            <button
              key={category.id}
              type="button"
              role="tab"
              aria-selected={activeCategory === category.id}
              className={`${styles.tab} ${activeCategory === category.id ? styles.tabActive : ''}`}
              onClick={() => setActiveCategory(category.id)}
            >
              {category.title}
            </button>
          ))}
        </div>
        {activeData && (
          <article className={styles.categoryPanel} role="tabpanel">
            <div className={styles.categoryHeader}>
              <h2>{activeData.title}</h2>
              <p>{activeData.description}</p>
            </div>
            <ul className={styles.highlightList}>
              {activeData.highlights.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>
        )}
      </section>

      <section className={styles.formats}>
        <div className={styles.sectionHeader}>
          <h2>Формати взаємодії</h2>
          <p>Обирайте формат, який найбільше відповідає вашому графіку та стилю навчання.</p>
        </div>
        <div className={styles.formatGrid}>
          {groupFormats.map((format) => (
            <article key={format.title} className={styles.formatCard}>
              <h3>{format.title}</h3>
              <p>{format.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.extra}>
        <div className={styles.extraContent}>
          <h2>Додатково ми пропонуємо</h2>
          <ul>
            <li>
              <strong>Домашні протоколи.</strong> Детальні гіди з кроками для закріплення навичок між сесіями.
            </li>
            <li>
              <strong>Польові тренування.</strong> Проводимо заняття у міському середовищі, щоб собака впевнено реагувала на шум і людей.
            </li>
            <li>
              <strong>Психоемоційна підтримка.</strong> Консультуємо щодо адаптації, стресу, зміни середовища чи появи нових членів родини.
            </li>
            <li>
              <strong>Партнерство з ветспеціалістами.</strong> За потреби координуємо план із ветеринарними поведінковими лікарями.
            </li>
          </ul>
        </div>
        <div className={styles.extraMedia}>
          <img
            src="https://picsum.photos/900/640?random=401"
            alt="Тренер показує власнику техніку дресирування"
          />
        </div>
      </section>
    </div>
  );
};

export default Services;