import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  phone: '',
  city: 'Варшава',
  message: '',
};

const Contact = () => {
  usePageMeta({
    title: 'Контакти | Професійне дресирування собак',
    description:
      'Зв’яжіться з кінологами у Варшаві та Кракові: адреси майданчиків, телефон, email та форма для запиту дресирування німецьких вівчарок.',
    keywords:
      'контакти кінолога Варшава, контакти кінолога Краків, запис на дресирування, собача школа',
  });

  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Вкажіть ім'я";
    if (!formData.email.trim()) {
      newErrors.email = 'Вкажіть email';
    } else if (!/\S+@\S+\.\S+/.test(formData.email.trim())) {
      newErrors.email = 'Перевірте правильність email';
    }
    if (!formData.message.trim()) newErrors.message = 'Опишіть, що вас цікавить';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      setStatus(null);
      return;
    }
    setErrors({});
    setStatus('success');
    setFormData(initialState);
  };

  return (
    <div className={styles.contact}>
      <section className={styles.details}>
        <div className={styles.detailsBox}>
          <h1>Контакти та локації</h1>
          <p>
            Заплануйте стартову зустріч у Варшаві або Кракові. Ми підготуємо індивідуальну програму та розповімо, як
            проходить перша оцінка собаки.
          </p>
          <div className={styles.locations}>
            <div>
              <h2>Варшава</h2>
              <p>вул. Собача, 10</p>
            </div>
            <div>
              <h2>Краків</h2>
              <p>вул. Кінологічна, 5А</p>
            </div>
          </div>
          <ul className={styles.directContacts}>
            <li>
              Телефон: <a href="tel:+48123456789">+48 123 456 789</a>
            </li>
            <li>
              Email: <a href="mailto:info@dresirovka-psy.pl">info@dresirovka-psy.pl</a>
            </li>
          </ul>
        </div>
        <div className={styles.mapBox} aria-hidden="true">
          <img
            src="https://picsum.photos/900/650?random=601"
            alt="Мапа локацій тренувальних майданчиків"
          />
        </div>
      </section>

      <section className={styles.formSection}>
        <div className={styles.formBox}>
          <h2>Напишіть нам</h2>
          <p>
            Розкажіть про вік, досвід та особливості вашої німецької вівчарки. Ми відповімо протягом робочого дня та
            запропонуємо варіанти графіка.
          </p>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.inputGroup}>
              <label htmlFor="name">Ім’я та прізвище *</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && (
                <span id="name-error" className={styles.error}>
                  {errors.name}
                </span>
              )}
            </div>
            <div className={styles.inputGroup}>
              <label htmlFor="email">Email *</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && (
                <span id="email-error" className={styles.error}>
                  {errors.email}
                </span>
              )}
            </div>
            <div className={styles.inputGroup}>
              <label htmlFor="phone">Телефон</label>
              <input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
                placeholder="+48 ..."
              />
            </div>
            <div className={styles.inputGroup}>
              <label htmlFor="city">Місто для тренувань</label>
              <select id="city" name="city" value={formData.city} onChange={handleChange}>
                <option value="Варшава">Варшава</option>
                <option value="Краків">Краків</option>
                <option value="Гібридний формат">Гібридний формат</option>
              </select>
            </div>
            <div className={styles.inputGroup}>
              <label htmlFor="message">Опишіть задачу *</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && (
                <span id="message-error" className={styles.error}>
                  {errors.message}
                </span>
              )}
            </div>
            <button type="submit" className={styles.submitButton}>
              Надіслати запит
            </button>
            {status === 'success' && (
              <p className={styles.success} role="status">
                Дякуємо! Ми отримали ваше повідомлення та зв’яжемося найближчим часом.
              </p>
            )}
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;