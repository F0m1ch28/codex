import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Success.module.css';

const filters = ['Усі', 'Варшава', 'Краків'];

const successStories = [
  {
    title: 'Аякс — стабільність у місті',
    city: 'Варшава',
    description:
      'Пес мав сильну реактивність на велосипедистів. Застосували протокол десенсибілізації, роботу з повідком та ігрові вправи. Через 10 тижнів власник повідомив про повний контроль у парках.',
    result: 'Зменшення стресових реакцій на 90%, стабільний контакт із власником.',
    image: 'https://picsum.photos/1200/800?random=501',
  },
  {
    title: 'Гарда — підготовка до служби',
    city: 'Краків',
    description:
      'Молодій вівчарці потрібно було зміцнити концентрацію та витривалість. Ми розробили комбіновану програму фітнесу й пошукового тренінгу.',
    result: 'Собака успішно пройшла службові випробування та зарахована до підрозділу.',
    image: 'https://picsum.photos/1200/800?random=502',
  },
  {
    title: 'Люма — впевнений виступ на рингу',
    city: 'Варшава',
    description:
      'Готували до виставки: відпрацьовували ходу, пози, реакцію на суддів. Паралельно працювали над спокоєм у транспорті.',
    result: 'Отримано титул Best of Breed на регіональному шоу.',
    image: 'https://picsum.photos/1200/800?random=503',
  },
  {
    title: 'Оскар — домашній улюбленець без агресії',
    city: 'Краків',
    description:
      'Собака проявляв територіальну агресію. Ми впровадили контрольовані знайомства, змінили структуру прогулянок та інструменти посилення.',
    result: 'Власники впевнено приймають гостей, собака поводиться передбачувано.',
    image: 'https://picsum.photos/1200/800?random=504',
  },
];

const highlights = [
  { metric: '87%', label: 'клієнтів відмічають покращення вже після 5-ї сесії' },
  { metric: '54', label: 'вівчарок підготували до виставок за останні 2 роки' },
  { metric: '36', label: 'власників отримали супровід онлайн після курсу' },
  { metric: '0', label: 'випадків травм завдяки системі безпеки та розминок' },
];

const Success = () => {
  usePageMeta({
    title: 'Наші успіхи | Історії клієнтів німецьких вівчарок',
    description:
      'Реальні кейси дресирування німецьких вівчарок у Варшаві та Кракові: корекція поведінки, підготовка до служби і виступів.',
    keywords:
      'історії дресирування, успіхи німецьких вівчарок, відгуки кінолога, Варшава, Краків',
  });

  const [activeFilter, setActiveFilter] = useState('Усі');

  const filteredStories =
    activeFilter === 'Усі'
      ? successStories
      : successStories.filter((story) => story.city === activeFilter);

  return (
    <div className={styles.success}>
      <section className={styles.intro}>
        <h1>Наші успіхи та історії співпраці</h1>
        <p>
          Тут ми ділимося історіями собак і їхніх власників, які пройшли шлях від перших занять до впевнених результатів.
          Кожен кейс унікальний, але всіх їх об’єднує системний підхід та любов до породи.
        </p>
      </section>

      <section className={styles.highlights}>
        <div className={styles.highlightGrid}>
          {highlights.map((item) => (
            <div key={item.metric} className={styles.highlightCard}>
              <span className={styles.metric}>{item.metric}</span>
              <p>{item.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.stories}>
        <div className={styles.filterBar} role="tablist" aria-label="Місто успіху">
          {filters.map((filter) => (
            <button
              key={filter}
              type="button"
              role="tab"
              aria-selected={activeFilter === filter}
              className={`${styles.filterButton} ${activeFilter === filter ? styles.filterActive : ''}`}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>

        <div className={styles.storyGrid}>
          {filteredStories.map((story) => (
            <article key={story.title} className={styles.storyCard}>
              <img src={story.image} alt={story.title} loading="lazy" />
              <div className={styles.storyContent}>
                <span className={styles.storyCity}>{story.city}</span>
                <h3>{story.title}</h3>
                <p>{story.description}</p>
                <div className={styles.storyResult}>
                  <strong>Результат:</strong>
                  <span>{story.result}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Success;