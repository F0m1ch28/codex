import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Home.module.css';

const stats = [
  { number: '12+', label: 'років досвіду професійного дресирування' },
  { number: '240', label: 'підготовлених німецьких вівчарок' },
  { number: '4', label: 'сертифікованих кінологів у команді' },
  { number: '98%', label: 'клієнтів рекомендують нас колегам' },
];

const servicesPreview = [
  {
    title: 'Базове послухняння',
    text: 'Навчаємо чітких команд, контролю імпульсів та безпечної поведінки у місті.',
  },
  {
    title: 'Коригування поведінки',
    text: 'Працюємо з реактивністю, гіперактивністю та небажаними звичками німецьких вівчарок.',
  },
  {
    title: 'Підготовка до виставок',
    text: 'Розробляємо тренувальні плани для рингів, фітнес та витривалість породи.',
  },
  {
    title: 'Супровід власника',
    text: 'Консультативні зустрічі та домашні завдання, щоб досягти стійкого результату.',
  },
];

const principles = [
  {
    title: 'Індивідуальний підхід',
    text: 'Ураховуємо характер собаки, досвід власника і стиль життя сім’ї.',
  },
  {
    title: 'Позитивне підкріплення',
    text: 'Створюємо мотиваційне середовище, де собака навчається із задоволенням.',
  },
  {
    title: 'Партнерство з власником',
    text: 'Навчаємо людей читати сигнали улюбленця та реагувати впевнено.',
  },
  {
    title: 'Безпека і добробут',
    text: 'Дбаємо про фізичне й емоційне здоров’я німецьких вівчарок під час тренувань.',
  },
];

const process = [
  {
    step: '01',
    title: 'Стартова оцінка',
    text: 'Знайомимося, аналізуємо поведінковий профіль собаки, визначаємо головні цілі.',
  },
  {
    step: '02',
    title: 'План тренувань',
    text: 'Розробляємо модульну програму з фокусом на послідовність, мотивацію та контроль.',
  },
  {
    step: '03',
    title: 'Практика на майданчику',
    text: 'Відпрацьовуємо команди у Варшаві чи Кракові, додаємо елементи міського середовища.',
  },
  {
    step: '04',
    title: 'Підтримка вдома',
    text: 'Передаємо алгоритми власнику, супроводжуємо онлайн та офлайн консультаціями.',
  },
];

const testimonials = [
  {
    name: 'Олена, Варшава',
    quote:
      'Після курсу наша вівчарка Люма стала врівноваженою, перестала тягнути повід і реагує на команди навіть у парку. Команда тренерів завжди була на зв’язку.',
  },
  {
    name: 'Марек, Краків',
    quote:
      'Професіонали з великої літери. Вони пояснили, як будувати щоденний ритуал з Гардою, і вже за кілька тижнів ми побачили прогрес.',
  },
  {
    name: 'Анна, Варшава',
    quote:
      'Мої очікування перевершені. Дресирування побудували як гру, і тепер Макс із задоволенням працює та виступає на виставках.',
  },
];

const faqItems = [
  {
    question: 'Коли варто починати дресирування німецької вівчарки?',
    answer:
      'Ми радимо починати з 3-4 місяців, але працюємо також із дорослими собаками. Програма адаптується відповідно до віку та рівня підготовки.',
  },
  {
    question: 'Чи можлива участь у тренуваннях всієї родини?',
    answer:
      'Так, ми заохочуємо долучати всіх, хто контактує з собакою. Це допомагає закріплювати навички послідовно та прискорює результат.',
  },
  {
    question: 'Скільки триває одна сесія тренування?',
    answer:
      'Стандартна сесія триває 60 хвилин. За необхідності ми комбінуємо коротші блоки із теоретичними поясненнями для власника.',
  },
  {
    question: 'Чи проводите ви заняття на виїзді?',
    answer:
      'Так, ми тренуємося як на власних майданчиках у Варшаві та Кракові, так і в узгоджених локаціях клієнта у межах міста.',
  },
];

const blogPosts = [
  {
    title: '5 ключових етапів соціалізації німецької вівчарки',
    excerpt:
      'Соціалізація — фундамент впевненої поведінки. Розповідаємо, як формувати спокійну реакцію на людей, тварин і транспорт.',
    date: '10 квітня 2024',
    link: '/posluhy',
  },
  {
    title: 'Як побудувати систему мотивації для робочої собаки',
    excerpt:
      'Правильна мотивація — це поєднання гри, інтелектуальних задач і чітких правил. Ділимося методиками наших тренерів.',
    date: '22 березня 2024',
    link: '/pro-nas',
  },
  {
    title: 'Підготовка до виставки: чек-лист від тренера',
    excerpt:
      'Від ходи та пози до реакції на шум — готуємо німецьких вівчарок до впевненого виступу на рингу.',
    date: '5 березня 2024',
    link: '/nashi-uspikhy',
  },
];

const Home = () => {
  usePageMeta({
    title: 'Професійне дресирування німецьких вівчарок | Варшава та Краків',
    description:
      'Спеціалізоване дресирування німецьких вівчарок у Варшаві та Кракові. Сертифіковані кінологи, індивідуальні програми, коригування поведінки.',
    keywords:
      'дресирування собак, навчання німецьких вівчарок, кінолог, послуги кінолога, Варшава, Краків, собача школа, коригування поведінки',
  });

  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [openFaqIndex, setOpenFaqIndex] = useState(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  const handleFaqToggle = (index) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.home}>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.heroLabel}>Варшава · Краків</span>
          <h1 className={styles.heroTitle}>Професійне дресирування німецьких вівчарок</h1>
          <p className={styles.heroSubtitle}>
            Виховуємо розумних і слухняних собак через науку, досвід і співпрацю з власником. Розробляємо персональні
            програми, що допомагають вівчаркам розкривати потенціал у місті, на виставках та в роботі.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.heroPrimary}>
              Зв’язатися
            </Link>
            <a className={styles.heroSecondary} href="tel:+48123456789">
              +48 123 456 789
            </a>
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className={styles.sectionHeader}>
          <h2>Наш досвід у цифрах</h2>
          <p>Ми працюємо тільки з німецькими вівчарками та постійно інвестуємо у розвиток команди тренерів.</p>
        </div>
        <div className={styles.statsGrid}>
          {stats.map((item) => (
            <div key={item.label} className={styles.statCard}>
              <span className={styles.statNumber}>{item.number}</span>
              <p className={styles.statLabel}>{item.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.specialization}>
        <div className={styles.specializationText}>
          <h2>Чому німецькі вівчарки — наше покликання</h2>
          <p>
            Ми обрали спеціалізацію на німецьких вівчарках, тому що ця порода поєднує інтелект, безмежну енергію
            та відданість. Вони швидко навчаються, але потребують структурованих задач та постійної взаємодії з людиною.
          </p>
          <ul>
            <li>
              <strong>Високий інтелект.</strong> Вівчарки швидко засвоюють нові навички та люблять вирішувати задачі.
            </li>
            <li>
              <strong>Поширеність породи.</strong> У Варшаві й Кракові багато сімей обирають саме вівчарок для служби й
              захисту.
            </li>
            <li>
              <strong>Необхідність фокусу.</strong> Специфічні складнощі поведінки потребують глибоких знань породи.
            </li>
          </ul>
        </div>
        <div className={styles.specializationMedia}>
          <img
            src="https://picsum.photos/800/600?random=102"
            alt="Тренер працює з німецькою вівчаркою на майданчику"
          />
        </div>
      </section>

      <section className={styles.services}>
        <div className={styles.sectionHeader}>
          <h2>Що ми пропонуємо</h2>
          <p>Оберіть напрямок, що відповідає поточним цілям, та дізнайтеся більше на сторінці послуг.</p>
        </div>
        <div className={styles.serviceGrid}>
          {servicesPreview.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <h3>{service.title}</h3>
              <p>{service.text}</p>
              <Link to="/posluhy" className={styles.serviceLink}>
                Детальніше →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.principles}>
        <div className={styles.sectionHeader}>
          <h2>Наші принципи роботи</h2>
          <p>За роки практики ми виробили стандарти, які гарантують стабільний результат і комфорт собаки.</p>
        </div>
        <div className={styles.principlesGrid}>
          {principles.map((principle) => (
            <article key={principle.title} className={styles.principleCard}>
              <h3>{principle.title}</h3>
              <p>{principle.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <h2>Як відбувається тренування</h2>
          <p>Ми поєднуємо роботу на майданчику та в домашньому середовищі, щоб навички закріплювалися назавжди.</p>
        </div>
        <div className={styles.processGrid}>
          {process.map((item) => (
            <article key={item.step} className={styles.processCard}>
              <span className={styles.processStep}>{item.step}</span>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.geography}>
        <div className={styles.sectionHeader}>
          <h2>Де ми працюємо</h2>
          <p>Обирайте зручну локацію та графік. Ми проводимо особисті і групові заняття у двох містах Польщі.</p>
        </div>
        <div className={styles.geoGrid}>
          <div className={styles.geoCard}>
            <h3>Варшава</h3>
            <p>вул. Собача, 10</p>
            <p>Майданчик у зеленому районі, поруч із метро Natolin.</p>
          </div>
          <div className={styles.geoCard}>
            <h3>Краків</h3>
            <p>вул. Кінологічна, 5А</p>
            <p>Закритий тренувальний простір та зона для соціалізації.</p>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <h2>Відгуки власників</h2>
          <p>Ми цінуємо довіру клієнтів та супроводжуємо їх на кожному етапі становлення собаки.</p>
        </div>
        <div className={styles.testimonialSlider}>
          {testimonials.map((item, index) => (
            <article
              key={item.name}
              className={`${styles.testimonialCard} ${index === activeTestimonial ? styles.active : ''}`}
              aria-hidden={index !== activeTestimonial}
            >
              <p className={styles.testimonialQuote}>“{item.quote}”</p>
              <span className={styles.testimonialAuthor}>{item.name}</span>
            </article>
          ))}
        </div>
        <div className={styles.testimonialControls}>
          {testimonials.map((_, index) => (
            <button
              key={index}
              type="button"
              className={index === activeTestimonial ? styles.dotActive : styles.dot}
              aria-label={`Показати відгук ${index + 1}`}
              onClick={() => setActiveTestimonial(index)}
            />
          ))}
        </div>
        <Link to="/nashi-uspikhy" className={styles.moreLink}>
          Переглянути всі історії успіху →
        </Link>
      </section>

      <section className={styles.faq}>
        <div className={styles.sectionHeader}>
          <h2>Питання, які нам ставлять найчастіше</h2>
          <p>Якщо у вас залишилися інші запитання, напишіть нам — ми залюбки відповімо.</p>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <article key={item.question} className={styles.faqItem}>
              <button
                type="button"
                className={styles.faqButton}
                onClick={() => handleFaqToggle(index)}
                aria-expanded={openFaqIndex === index}
              >
                <span>{item.question}</span>
                <span className={styles.faqIcon}>{openFaqIndex === index ? '−' : '+'}</span>
              </button>
              {openFaqIndex === index && <p className={styles.faqAnswer}>{item.answer}</p>}
            </article>
          ))}
        </div>
      </section>

      <section className={styles.blog}>
        <div className={styles.sectionHeader}>
          <h2>Практичні поради від тренерів</h2>
          <p>Ми ділимося напрацюваннями, щоб власники могли підтримувати навички собаки щодня.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <img
                src={`https://picsum.photos/800/600?random=${120 + Math.random() * 100}`}
                alt={post.title}
                loading="lazy"
              />
              <div className={styles.blogContent}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.blogLink}>
                  Читати →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Запишіть вашого вівчарка на заняття вже зараз</h2>
          <p>
            Розкажіть нам про свого собаку — ми підготуємо індивідуальний план і підберемо зручний графік у Варшаві
            або Кракові.
          </p>
          <div className={styles.ctaActions}>
            <a className={styles.ctaPrimary} href="tel:+48123456789">
              Зателефонувати
            </a>
            <Link to="/kontakty" className={styles.ctaSecondary}>
              Написати повідомлення
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;