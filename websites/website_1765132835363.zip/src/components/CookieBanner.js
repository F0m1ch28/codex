import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const consent = window.localStorage.getItem('dogTrainingCookieConsent');
      if (!consent) {
        setIsVisible(true);
      }
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('dogTrainingCookieConsent', 'true');
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Повідомлення про використання cookie">
      <div className={styles.content}>
        <p className={styles.text}>
          Ми використовуємо cookie-файли, щоб забезпечити безперебійну роботу сайту та аналізувати взаємодію з
          контентом. Деталі у <Link to="/polityka-cookie">Політиці щодо файлів cookie</Link>.
        </p>
        <button type="button" className={styles.button} onClick={handleAccept}>
          Погоджуюсь
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;