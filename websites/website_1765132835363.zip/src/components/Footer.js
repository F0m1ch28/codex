import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.brandColumn}>
          <h2 className={styles.brandTitle}>Професійне дресерування собак</h2>
          <p className={styles.brandText}>
            Допомагаємо німецьким вівчаркам і їхнім власникам створювати гармонійні відносини через
            продуману систему навчання, сучасні методики та турботу про благополуччя тварини.
          </p>
        </div>
        <div className={styles.linksColumn}>
          <h3 className={styles.columnTitle}>Сторінки</h3>
          <ul className={styles.linksList}>
            <li><Link to="/">Головна</Link></li>
            <li><Link to="/posluhy">Послуги</Link></li>
            <li><Link to="/pro-nas">Про нас</Link></li>
            <li><Link to="/nashi-uspikhy">Наші успіхи</Link></li>
            <li><Link to="/kontakty">Контакти</Link></li>
          </ul>
        </div>
        <div className={styles.infoColumn}>
          <h3 className={styles.columnTitle}>Контакти</h3>
          <ul className={styles.contactList}>
            <li>
              <strong>Варшава:</strong> вул. Собача, 10
            </li>
            <li>
              <strong>Краків:</strong> вул. Кінологічна, 5А
            </li>
            <li>
              <a href="tel:+48123456789">+48 123 456 789</a>
            </li>
            <li>
              <a href="mailto:info@dresirovka-psy.pl">info@dresirovka-psy.pl</a>
            </li>
          </ul>
        </div>
        <div className={styles.policyColumn}>
          <h3 className={styles.columnTitle}>Політики</h3>
          <ul className={styles.linksList}>
            <li><Link to="/umovy-vykorystannia">Умови використання</Link></li>
            <li><Link to="/polityka-konfidentsiinosti">Політика конфіденційності</Link></li>
            <li><Link to="/polityka-cookie">Політика щодо файлів cookie</Link></li>
          </ul>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p className={styles.copy}>© {year} Професійне дресерування собак. Усі права захищено.</p>
      </div>
    </footer>
  );
};

export default Footer;