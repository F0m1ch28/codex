import { useEffect } from 'react';

const usePageMeta = ({ title, description, keywords }) => {
  useEffect(() => {
    const previousTitle = document.title;
    const descriptionTag = document.querySelector('meta[name="description"]');
    const previousDescription = descriptionTag ? descriptionTag.getAttribute('content') : '';
    const keywordsTag = document.querySelector('meta[name="keywords"]');
    const previousKeywords = keywordsTag ? keywordsTag.getAttribute('content') : '';

    if (title) {
      document.title = title;
    }

    if (description) {
      if (descriptionTag) {
        descriptionTag.setAttribute('content', description);
      } else {
        const newDescriptionTag = document.createElement('meta');
        newDescriptionTag.setAttribute('name', 'description');
        newDescriptionTag.setAttribute('content', description);
        document.head.appendChild(newDescriptionTag);
      }
    }

    if (keywords) {
      if (keywordsTag) {
        keywordsTag.setAttribute('content', keywords);
      } else {
        const newKeywordsTag = document.createElement('meta');
        newKeywordsTag.setAttribute('name', 'keywords');
        newKeywordsTag.setAttribute('content', keywords);
        document.head.appendChild(newKeywordsTag);
      }
    }

    return () => {
      document.title = previousTitle || document.title;
      if (descriptionTag && previousDescription) {
        descriptionTag.setAttribute('content', previousDescription);
      }
      if (keywordsTag && previousKeywords) {
        keywordsTag.setAttribute('content', previousKeywords);
      }
    };
  }, [title, description, keywords]);
};

export default usePageMeta;