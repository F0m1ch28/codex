import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  return (
    <div className={styles.container}>
      <Helmet>
        <title>Aurion Energy Advisory | Engineering the Future of Energy</title>
        <meta
          name="description"
          content="Aurion Energy Advisory delivers energy consulting, oilfield research, and industrial engineering services across Canada."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.overlay} />
        <div className={styles.heroContent}>
          <h1 className={styles.heroTitle}>Engineering the Future of Energy</h1>
          <p className={styles.heroSubtitle}>
            Integrated consulting and engineering solutions that power Canada&rsquo;s evolving energy landscape.
          </p>
          <a className={styles.heroButton} href="#contact-cta">
            Partner with Aurion
          </a>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2>Guiding energy innovation with industrial precision</h2>
          <p>
            Aurion Energy Advisory is a Canadian consultancy and engineering firm specializing in complex energy assets. From subsurface insight and oilfield research to heavy lift logistics and sustainable infrastructure planning, we align strategy with reliable execution.
          </p>
        </div>
        <div className={styles.expertiseGrid}>
          {[
            {
              title: 'Strategic Energy Consulting',
              description: 'Market intelligence, regulatory guidance, and asset planning to unlock resilient energy infrastructure.'
            },
            {
              title: 'Subsurface & Oilfield Research',
              description: 'Reservoir modeling, compliance assessments, and data-backed recommendations for exploration teams.'
            },
            {
              title: 'Installation & Commissioning',
              description: 'Heavy crane coordination, precision rigging, and commissioning support for industrial facilities.'
            }
          ].map((item) => (
            <div key={item.title} className={styles.card}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.splitSection}>
        <div className={styles.splitImage} style={{ backgroundImage: 'url(https://picsum.photos/800/600?random=11)' }} role="img" aria-label="Oilfield research in Canada" />
        <div className={styles.splitContent}>
          <h2>Oilfield Research & Compliance</h2>
          <p>
            Our specialists deliver integrated research programs, combining geophysical analytics with in-field data capture. We help operators navigate Canadian regulations, mitigate risk, and build a defensible pathway to development approval.
          </p>
          <ul>
            <li>Exploration feasibility studies</li>
            <li>Reservoir engineering reviews</li>
            <li>Regulatory documentation support</li>
            <li>Stakeholder engagement strategies</li>
          </ul>
        </div>
      </section>

      <section className={styles.splitSectionReverse}>
        <div className={styles.splitImage} style={{ backgroundImage: 'url(https://picsum.photos/800/600?random=12)' }} role="img" aria-label="Industrial crane engineering team" />
        <div className={styles.splitContent}>
          <h2>Engineering Solutions & Crane Logistics</h2>
          <p>
            Aurion&rsquo;s engineering teams coordinate high-impact installations from initial concept through field deployment. We deliver crane studies, lift plans, and logistical roadmaps that accelerate schedule performance while maintaining rigorous safety protocols.
          </p>
          <ul>
            <li>Heavy lift simulation and lift plans</li>
            <li>Equipment staging and route studies</li>
            <li>Commissioning and system integration</li>
            <li>Lifecycle maintenance strategies</li>
          </ul>
        </div>
      </section>

      <section className={styles.sectionAlt}>
        <div className={styles.sectionHeader}>
          <h2>Sustainability embedded in every project</h2>
          <p>
            We embed sustainability metrics into project frameworks, helping clients pursue low-carbon innovations and optimize resource performance without sacrificing operational excellence.
          </p>
        </div>
        <div className={styles.metrics}>
          <div className={styles.metricCard}>
            <span className={styles.metricValue}>42%</span>
            <span className={styles.metricLabel}>Average reduction in operational emissions for monitored projects</span>
          </div>
          <div className={styles.metricCard}>
            <span className={styles.metricValue}>15+</span>
            <span className={styles.metricLabel}>Active collaborations with technology providers across Canada</span>
          </div>
          <div className={styles.metricCard}>
            <span className={styles.metricValue}>24/7</span>
            <span className={styles.metricLabel}>Field support coverage for critical infrastructure programs</span>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2>Selected Projects</h2>
          <p>
            We combine analytics, engineering, and field execution to deliver measurable improvements in uptime, safety, and sustainability.
          </p>
        </div>
        <div className={styles.projectGrid}>
          {[
            {
              title: 'Northern Alberta Pipeline Lift Study',
              description: 'Developed crane lift plans and staging logistics for a 120 km gas pipeline upgrade, coordinating multi-disciplinary teams on-site.',
              image: 'https://picsum.photos/600/400?random=13'
            },
            {
              title: 'Offshore Asset Integrity Review',
              description: 'Led a comprehensive oilfield research program integrating geospatial surveys with structural modeling to extend asset life.',
              image: 'https://picsum.photos/600/400?random=14'
            },
            {
              title: 'Toronto District Energy Optimization',
              description: 'Designed sustainability roadmap and commissioning support for an urban district energy network with renewable integration.',
              image: 'https://picsum.photos/600/400?random=15'
            }
          ].map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <img src={project.image} alt={project.title} className={styles.projectImage} />
              <div className={styles.projectContent}>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className={styles.sectionHeader}>
          <h2>Voices from our partners</h2>
        </div>
        <div className={styles.testimonialsGrid}>
          {[
            {
              quote: 'Aurion brought clarity to a complex regulatory process and engineered a path that kept our schedule on track.',
              name: 'Elena Marshall',
              role: 'Director of Projects, Maridian Energy'
            },
            {
              quote: 'Their crane logistics expertise made a significant difference during our refinery turnaround. Safety and precision were evident.',
              name: 'Tom Reynolds',
              role: 'Operations Manager, Northfield Petrochem'
            },
            {
              quote: 'From feasibility to commissioning, the Aurion team consistently delivered insight, rigor, and responsive support.',
              name: 'Simran Kaur',
              role: 'VP Infrastructure, GreenCore Utilities'
            }
          ].map((testimonial) => (
            <blockquote key={testimonial.name} className={styles.testimonial}>
              <p>&ldquo;{testimonial.quote}&rdquo;</p>
              <cite>
                {testimonial.name} <span>— {testimonial.role}</span>
              </cite>
            </blockquote>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection} id="contact-cta">
        <div className={styles.ctaContent}>
          <h2>Partner with Aurion</h2>
          <p>
            Tell us about your energy infrastructure challenge. Our consultants and engineers are ready to design a solution tailored to your asset strategy.
          </p>
          <a className={styles.ctaButton} href="/contact">
            Start the Conversation
          </a>
        </div>
      </section>
    </div>
  );
};

export default Home;