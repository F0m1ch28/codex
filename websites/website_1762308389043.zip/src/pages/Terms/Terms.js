import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => {
  return (
    <div className={styles.container}>
      <Helmet>
        <title>Terms of Use | Aurion Energy Advisory</title>
        <meta name="description" content="Review the terms of use for Aurion Energy Advisory." />
      </Helmet>
      <h1>Terms of Use</h1>
      <p>Last updated: {new Date().toLocaleDateString()}</p>
      <h2>Acceptance of Terms</h2>
      <p>
        By accessing this website, you agree to be bound by these Terms of Use and all applicable laws. If you do not agree, please refrain from using the site.
      </p>
      <h2>Use of Content</h2>
      <p>
        All materials on this site are provided for informational purposes about Aurion Energy Advisory. You may not modify, distribute, or reproduce content without prior written permission.
      </p>
      <h2>Disclaimer</h2>
      <p>
        Information on this site is provided on an &ldquo;as-is&rdquo; basis. Aurion Energy Advisory makes no warranties regarding accuracy or completeness.
      </p>
      <h2>Limitation of Liability</h2>
      <p>
        Aurion Energy Advisory will not be liable for any indirect or consequential damages arising from the use of this website.
      </p>
      <h2>Governing Law</h2>
      <p>
        These Terms of Use are governed by the laws of the Province of Ontario and the federal laws of Canada applicable therein.
      </p>
      <h2>Contact</h2>
      <p>
        Questions about these Terms of Use can be directed to info@aurionenergyadvisory.com.
      </p>
    </div>
  );
};

export default Terms;