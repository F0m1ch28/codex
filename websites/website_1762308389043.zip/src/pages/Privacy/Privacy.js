import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <div className={styles.container}>
      <Helmet>
        <title>Privacy Policy | Aurion Energy Advisory</title>
        <meta name="description" content="Read the privacy policy for Aurion Energy Advisory." />
      </Helmet>
      <h1>Privacy Policy</h1>
      <p>Last updated: {new Date().toLocaleDateString()}</p>

      <h2>Information We Collect</h2>
      <p>
        Aurion Energy Advisory may collect personal information you voluntarily provide through contact forms, email communications, or event registrations.
      </p>

      <h2>How We Use Information</h2>
      <p>
        Information is used to respond to inquiries, deliver services, and provide updates relevant to our business relationship.
      </p>

      <h2>Data Security</h2>
      <p>
        We implement safeguards designed to protect personal information against unauthorized access, disclosure, alteration, or destruction.
      </p>

      <h2>Sharing of Information</h2>
      <p>
        We do not sell personal information. We may share information with trusted service providers who assist us in operating our business, subject to confidentiality obligations.
      </p>

      <h2>Your Rights</h2>
      <p>
        You may request access to or correction of your personal information. To exercise these rights, contact us at info@aurionenergyadvisory.com.
      </p>

      <h2>Contact</h2>
      <p>
        For questions regarding this Privacy Policy, please email info@aurionenergyadvisory.com.
      </p>
    </div>
  );
};

export default Privacy;