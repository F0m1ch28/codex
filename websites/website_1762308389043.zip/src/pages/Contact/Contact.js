import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formState, setFormState] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
    setFormState({
      name: '',
      company: '',
      email: '',
      phone: '',
      message: ''
    });
  };

  return (
    <div className={styles.container}>
      <Helmet>
        <title>Contact Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Connect with Aurion Energy Advisory for energy consulting and engineering services."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Let&rsquo;s shape resilient energy systems together</h1>
        <p>
          Reach out to discuss your upcoming project, asset challenges, or operational goals. We respond within one business day.
        </p>
      </section>

      <section className={styles.contactGrid}>
        <div className={styles.details}>
          <h2>Contact Information</h2>
          <p>Address: 460 Bay St, Toronto, ON M5H 2Y4, Canada</p>
          <p>Phone: <a href="tel:+14167924583">+1 (416) 792-4583</a></p>
          <p>Email: <a href="mailto:info@aurionenergyadvisory.com">info@aurionenergyadvisory.com</a></p>
          <p>
            LinkedIn:{' '}
            <a href="https://www.linkedin.com/company/aurion-energy-advisory/" target="_blank" rel="noopener noreferrer">
              linkedin.com/company/aurion-energy-advisory
            </a>
          </p>
          <div className={styles.mapWrapper} aria-label="Map location of Aurion Energy Advisory">
            <iframe
              title="Aurion Energy Advisory Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.8042131453365!2d-79.38491272362911!3d43.651732753363285!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d1bfddc5a3%3A0x8d1b644ac5ed4a5b!2s460%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202Y4%2C%20Canada!5e0!3m2!1sen!2sca!4v1700000000000!5m2!1sen!2sca"
              allowFullScreen
              loading="lazy"
            />
          </div>
        </div>
        <form className={styles.form} onSubmit={handleSubmit}>
          <h2>Contact Form</h2>
          <div className={styles.field}>
            <label htmlFor="name">Name</label>
            <input
              id="name"
              name="name"
              type="text"
              required
              value={formState.name}
              onChange={handleChange}
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="company">Company</label>
            <input
              id="company"
              name="company"
              type="text"
              value={formState.company}
              onChange={handleChange}
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              required
              value={formState.email}
              onChange={handleChange}
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="phone">Phone</label>
            <input
              id="phone"
              name="phone"
              type="tel"
              value={formState.phone}
              onChange={handleChange}
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="message">How can we help?</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              required
              value={formState.message}
              onChange={handleChange}
            />
          </div>
          <button type="submit" className={styles.button}>
            Submit
          </button>
          {submitted && (
            <p className={styles.success} role="status">
              Thank you. Our team will reach out shortly.
            </p>
          )}
        </form>
      </section>
    </div>
  );
};

export default Contact;