import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  return (
    <div className={styles.container}>
      <Helmet>
        <title>Cookie Policy | Aurion Energy Advisory</title>
        <meta name="description" content="Learn about cookie usage on Aurion Energy Advisory's website." />
      </Helmet>
      <h1>Cookie Policy</h1>
      <p>Last updated: {new Date().toLocaleDateString()}</p>

      <h2>What Are Cookies?</h2>
      <p>
        Cookies are small text files stored on your device that help us deliver a tailored experience and understand how visitors interact with our website.
      </p>

      <h2>Types of Cookies We Use</h2>
      <ul>
        <li>Essential cookies for secure website functionality.</li>
        <li>Performance cookies to analyze site usage and improve user experience.</li>
      </ul>

      <h2>Managing Cookies</h2>
      <p>
        Most web browsers allow you to control cookies through settings. You can accept, refuse, or delete cookies at any time.
      </p>

      <h2>Contact</h2>
      <p>
        Questions regarding this Cookie Policy can be directed to info@aurionenergyadvisory.com.
      </p>
    </div>
  );
};

export default CookiePolicy;