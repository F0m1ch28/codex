import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Energy Consulting',
    description:
      'Strategic advisory for energy infrastructure, including scenario planning, market analysis, and policy alignment tailored to Canadian jurisdictions.'
  },
  {
    title: 'Oilfield Research',
    description:
      'Integrated subsurface studies, data acquisition, and regulatory reporting that de-risk exploration and asset integrity programs.'
  },
  {
    title: 'Installation & Commissioning',
    description:
      'Heavy lift planning, crane operations, and commissioning support ensuring safe deployment of complex industrial systems.'
  },
  {
    title: 'Environmental Assessment',
    description:
      'Baseline studies, emissions profiling, and mitigation frameworks that align with provincial and federal environmental regulations.'
  },
  {
    title: 'Project Management',
    description:
      'Full lifecycle project controls, scheduling, and stakeholder coordination to keep critical energy projects moving forward.'
  }
];

const Services = () => {
  return (
    <div className={styles.container}>
      <Helmet>
        <title>Services | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Aurion Energy Advisory offers consulting, oilfield research, installation, environmental assessment, and project management services."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Energy services built for industrial performance</h1>
        <p>
          We provide end-to-end consulting and engineering services, partnering with owners, operators, and investors to deliver resilient energy infrastructure across Canada.
        </p>
      </section>

      <section className={styles.grid}>
        {services.map((service) => (
          <article key={service.title} className={styles.card}>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
          </article>
        ))}
      </section>
    </div>
  );
};

export default Services;