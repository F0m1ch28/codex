import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Team.module.css';

const teamMembers = [
  {
    name: 'Aiden Sinclair, P.Eng.',
    role: 'Lead Structural Engineer',
    bio: 'Focuses on heavy lift design, structural verification, and construction sequencing for energy infrastructure projects across Canada.',
    image: 'https://picsum.photos/400/400?random=22'
  },
  {
    name: 'Mei Chen, PMP',
    role: 'Senior Project Manager',
    bio: 'Specializes in multi-stakeholder program coordination, project controls, and schedule optimization for industrial developments.',
    image: 'https://picsum.photos/400/400?random=23'
  },
  {
    name: 'Jordan Pelletier',
    role: 'Field Superintendent',
    bio: 'Leads onsite execution, crane operations oversight, and safety compliance for installation campaigns in remote environments.',
    image: 'https://picsum.photos/400/400?random=24'
  },
  {
    name: 'Priya Nair, PhD',
    role: 'Principal Reservoir Analyst',
    bio: 'Delivers reservoir simulation, data integration, and reserves auditing that guide exploration and production strategies.',
    image: 'https://picsum.photos/400/400?random=25'
  },
  {
    name: 'Andre Dupont',
    role: 'Environmental Specialist',
    bio: 'Advises on environmental assessments, emissions profiling, and climate resiliency planning for energy infrastructure.',
    image: 'https://picsum.photos/400/400?random=26'
  },
  {
    name: 'Lena Brooks',
    role: 'Commissioning Lead',
    bio: 'Coordinates commissioning execution, functional testing, and turnover packages for complex process systems.',
    image: 'https://picsum.photos/400/400?random=27'
  }
];

const Team = () => {
  return (
    <div className={styles.container}>
      <Helmet>
        <title>Team | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Meet the consultants and engineers behind Aurion Energy Advisory."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Expertise that spans strategy and field delivery</h1>
        <p>
          Our consultants, engineers, and field supervisors bring a unified approach to solving complex energy challenges.
        </p>
      </section>
      <section className={styles.grid}>
        {teamMembers.map((member) => (
          <article key={member.name} className={styles.card}>
            <img src={member.image} alt={member.name} className={styles.image} />
            <div className={styles.content}>
              <h2>{member.name}</h2>
              <p className={styles.role}>{member.role}</p>
              <p>{member.bio}</p>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};

export default Team;