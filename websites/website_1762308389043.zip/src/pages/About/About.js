import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  return (
    <div className={styles.container}>
      <Helmet>
        <title>About Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Discover the history, leadership, and sustainability commitments of Aurion Energy Advisory."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Beyond consultancy, we engineer outcomes</h1>
        <p>
          Aurion Energy Advisory was founded to provide Canadian energy operators with a single partner capable of combining strategy, engineering, and field execution. Our teams bring decades of project delivery experience across upstream, midstream, and industrial power systems.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Our Story</h2>
        <p>
          Established in Toronto, Aurion originated from a collaborative group of engineers, geoscientists, and policy advisors who had led major energy programs across North America. We recognized the need for integrated teams that can translate vision into measurable performance in the field. Today we advise clients nationwide, supporting assets from the Western Canadian Sedimentary Basin to urban power networks.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Leadership</h2>
        <div className={styles.grid}>
          <article className={styles.card}>
            <h3>Danielle Fraser, P.Eng.</h3>
            <p>Managing Director</p>
            <p>Danielle leads Aurion&rsquo;s strategic direction and major accounts. With 18 years of industrial engineering experience, she has managed multi-billion-dollar upgrades for energy infrastructure across Canada.</p>
          </article>
          <article className={styles.card}>
            <h3>Dr. Malik Rahman</h3>
            <p>Director, Oilfield Research</p>
            <p>Malik oversees reservoir modeling, compliance reports, and research partnerships. His background in geophysics ensures every project is grounded in precise subsurface insight.</p>
          </article>
          <article className={styles.card}>
            <h3>Janelle Moreau</h3>
            <p>Director, Project Services</p>
            <p>Janelle manages project controls, installation logistics, and commissioning teams. She champions collaborative frameworks that keep safety at the forefront.</p>
          </article>
        </div>
      </section>

      <section className={styles.section}>
        <h2>Mission</h2>
        <p>
          We deliver actionable intelligence and engineering capability to help Canadian energy operators meet demand, reduce environmental impact, and achieve regulatory certainty.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Commitment to Safety</h2>
        <p>
          Safety drives every decision we make. Our field teams undergo advanced training, adhere to ISO-aligned procedures, and document every operation through digital field reports. Clients receive transparent visibility from planning through commissioning.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Sustainability</h2>
        <p>
          Aurion integrates lifecycle assessments, emissions tracking, and climate resilience scenarios across our portfolio. Our advisory services accelerate the transition to efficient, low-carbon energy systems while safeguarding asset performance.
        </p>
      </section>
    </div>
  );
};

export default About;