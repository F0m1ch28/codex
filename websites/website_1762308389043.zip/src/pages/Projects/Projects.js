import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Projects.module.css';

const projects = [
  {
    title: 'Western Canada Modular Plant Commissioning',
    image: 'https://picsum.photos/600/400?random=16',
    description:
      'Delivered commissioning strategy for a modular processing facility, integrating digital workflows and training programs for site personnel.'
  },
  {
    title: 'Atlantic Offshore Platform Review',
    image: 'https://picsum.photos/600/400?random=17',
    description:
      'Conducted structural integrity analysis and asset life extension planning for an offshore platform servicing the Atlantic basin.'
  },
  {
    title: 'Prairie Wind Integration Study',
    image: 'https://picsum.photos/600/400?random=18',
    description:
      'Analyzed cross-provincial grid integration for a wind generation portfolio, aligning infrastructure upgrades with regional demand forecasts.'
  },
  {
    title: 'Urban Energy Storage Pilot',
    image: 'https://picsum.photos/600/400?random=19',
    description:
      'Provided engineering design and safety management for a lithium-ion storage pilot supporting peak load mitigation in downtown Toronto.'
  },
  {
    title: 'LNG Terminal Crane Optimization',
    image: 'https://picsum.photos/600/400?random=20',
    description:
      'Developed crane lift studies, route planning, and onsite supervision for LNG terminal balancing and maintenance activities.'
  },
  {
    title: 'Carbon Capture Retrofit Program',
    image: 'https://picsum.photos/600/400?random=21',
    description:
      'Supported feasibility, permitting, and implementation roadmap for a carbon capture retrofit at a midstream processing facility.'
  }
];

const Projects = () => {
  return (
    <div className={styles.container}>
      <Helmet>
        <title>Projects | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Explore sample projects delivered by Aurion Energy Advisory across Canada."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Trusted partners to Canada&rsquo;s energy assets</h1>
        <p>
          Our project portfolio covers upstream, midstream, and industrial power systems. Each engagement pairs strategy with rigorous field execution.
        </p>
      </section>
      <section className={styles.grid}>
        {projects.map((project) => (
          <article key={project.title} className={styles.card}>
            <img src={project.image} alt={project.title} className={styles.image} />
            <div className={styles.content}>
              <h2>{project.title}</h2>
              <p>{project.description}</p>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};

export default Projects;