import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div>
          <h2 className={styles.title}>Aurion Energy Advisory</h2>
          <p className={styles.text}>
            460 Bay St, Toronto, ON M5H 2Y4, Canada
          </p>
          <p className={styles.text}>
            Phone: <a href="tel:+14167924583">+1 (416) 792-4583</a>
          </p>
          <p className={styles.text}>
            Email: <a href="mailto:info@aurionenergyadvisory.com">info@aurionenergyadvisory.com</a>
          </p>
          <a
            href="https://www.linkedin.com/company/aurion-energy-advisory/"
            className={styles.link}
            target="_blank"
            rel="noopener noreferrer"
          >
            LinkedIn
          </a>
        </div>
        <div>
          <h3 className={styles.subtitle}>Company</h3>
          <nav aria-label="Footer navigation" className={styles.footerNav}>
            <NavLink to="/about" className={styles.link}>About</NavLink>
            <NavLink to="/services" className={styles.link}>Services</NavLink>
            <NavLink to="/projects" className={styles.link}>Projects</NavLink>
            <NavLink to="/team" className={styles.link}>Team</NavLink>
            <NavLink to="/contact" className={styles.link}>Contact</NavLink>
          </nav>
        </div>
        <div>
          <h3 className={styles.subtitle}>Legal</h3>
          <nav aria-label="Legal navigation" className={styles.footerNav}>
            <NavLink to="/terms" className={styles.link}>Terms of Use</NavLink>
            <NavLink to="/privacy" className={styles.link}>Privacy Policy</NavLink>
            <NavLink to="/cookie-policy" className={styles.link}>Cookie Policy</NavLink>
          </nav>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p className={styles.copy}>© {new Date().getFullYear()} Aurion Energy Advisory. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;