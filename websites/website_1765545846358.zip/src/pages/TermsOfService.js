import React from 'react';
import { Helmet } from 'react-helmet-async';
import shared from '../styles/Shared.module.css';
import styles from './Legal.module.css';

const TermsOfService = () => (
  <>
    <Helmet>
      <title>Пользовательское соглашение — TechSolutions Inc.</title>
      <meta name="robots" content="noindex" />
    </Helmet>

    <section className={shared.section} aria-labelledby="terms-title">
      <div className={shared.container}>
        <article className={styles.legalCard}>
          <h1 id="terms-title">Пользовательское соглашение</h1>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur ullamcorper, lorem vitae ultrices interdum, ipsum augue efficitur odio, vitae iaculis lacus mauris in dolor. Praesent ipsum urna, vehicula eget elementum vitae, pharetra et tortor.
          </p>
          <p>
            Quisque mattis fermentum risus sit amet sodales. Sed rhoncus, metus id bibendum tincidunt, nulla nibh rhoncus neque, id vestibulum quam nulla nec nisi. Integer ac dui elementum, malesuada nulla vitae, fermentum augue. Pellentesque habitant morbi tristique senectus et netus.
          </p>
          <p>
            Nam cursus eros et lacus volutpat, ac volutpat nibh tincidunt. Donec non sapien cursus, sodales nunc id, finibus massa. Mauris eleifend risus quis nisl tristique, nec facilisis felis gravida. Sed id diam non metus rutrum viverra a nec mauris.
          </p>
        </article>
      </div>
    </section>
  </>
);

export default TermsOfService;