import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import shared from '../styles/Shared.module.css';
import styles from './Home.module.css';

const statsConfig = [
  { label: 'Реализованных проектов', value: 120 },
  { label: 'Экспертов в команде', value: 85 },
  { label: 'Лет на рынке', value: 12 },
  { label: 'Удовлетворённость клиентов', value: 98, suffix: '%' }
];

const services = [
  {
    title: 'IT-консалтинг',
    description:
      'Анализируем текущие процессы, формируем стратегию цифровой трансформации и сопровождаем внедрение изменений.',
    icon: '🧭'
  },
  {
    title: 'Веб-разработка',
    description:
      'Создаём корпоративные порталы, высоконагруженные платформы и интерактивные сайты, адаптированные под любые устройства.',
    icon: '💻'
  },
  {
    title: 'Мобильные приложения',
    description:
      'Проектируем и развиваем мобильные решения для iOS и Android — от MVP до масштабных систем с безопасной интеграцией.',
    icon: '📱'
  },
  {
    title: 'Интеграция систем',
    description:
      'Объединяем разрозненные сервисы в единую архитектуру, автоматизируем процессы и обеспечиваем прозрачную аналитику.',
    icon: '🔗'
  }
];

const advantages = [
  {
    title: 'Глубокая экспертиза',
    text: 'Понимаем специфику отраслей — от нефтегазового сектора до финтеха, поэтому решения не требуют доработок после запуска.'
  },
  {
    title: 'Прозрачные процессы',
    text: 'Работаем по Agile и PMI стандартах, обеспечиваем полный контроль за сроками и бюджетом через регулярные отчёты.'
  },
  {
    title: 'Технологическое лидерство',
    text: 'Используем современные стеки и архитектуру, выбираем инструменты, которые помогают масштабировать бизнес.'
  }
];

const processSteps = [
  {
    title: 'Диагностика и стратегия',
    description: 'Исследуем бизнес-процессы, определяем точки роста и формируем дорожную карту цифровой трансформации.'
  },
  {
    title: 'Проектирование и дизайн',
    description: 'Создаём пользовательские сценарии, прототипы и архитектуру будущего решения вместе с командой клиента.'
  },
  {
    title: 'Разработка и интеграции',
    description: 'Настраиваем окружение, внедряем сервисы и интегрируем систему с существующей инфраструктурой компании.'
  },
  {
    title: 'Запуск и развитие',
    description: 'Проводим тестирование, обучаем команду, обеспечиваем поддержку и регулярные улучшения продукта.'
  }
];

const blogPosts = [
  {
    title: 'Тренды в веб-разработке 2024',
    excerpt: 'Гайд по ключевым трендам: микрофронтенды, WebAssembly, serverless и умные системы персонализации.',
    date: '12 марта 2024'
  },
  {
    title: 'Как выбрать IT-подрядчика',
    excerpt: 'Рассказываем, на что обращать внимание при выборе партнёра, чтобы не потерять время и бюджет.',
    date: '28 февраля 2024'
  },
  {
    title: 'Преимущества Agile-методологии',
    excerpt: 'Почему гибкий подход помогает быстрее выводить продукты на рынок и снижать риски.',
    date: '15 февраля 2024'
  }
];

const testimonials = [
  {
    name: 'Алексей Петров',
    position: 'Директор по цифровому развитию, ГазПромНефть',
    quote:
      'Команда TechSolutions Inc. продемонстрировала глубокое понимание наших внутренних процессов и помогла запустить портал, который стал центральной платформой коммуникаций для нескольких тысяч сотрудников.',
    avatar: 'https://picsum.photos/200/200?random=231'
  },
  {
    name: 'Елена Орлова',
    position: 'Руководитель продукта, СберБанк',
    quote:
      'Мы ценим скорость и качество разработки. Мобильное приложение было запущено без задержек, а метрики вовлечённости клиентов выросли на 37% уже в первые месяцы.',
    avatar: 'https://picsum.photos/200/200?random=232'
  },
  {
    name: 'Игорь Смирнов',
    position: 'IT-директор, Леруа Мерлен',
    quote:
      'Ребята взяли на себя интеграцию сложной экосистемы — от складских систем до CRM. Всё было сделано прозрачно, с понятными этапами и документацией.',
    avatar: 'https://picsum.photos/200/200?random=233'
  }
];

const clients = [
  { name: 'ГазПромНефть', logo: 'https://dummyimage.com/160x70/1a56db/ffffff&text=ГазПромНефть' },
  { name: 'СберБанк', logo: 'https://dummyimage.com/160x70/0b5fff/ffffff&text=СберБанк' },
  { name: 'Леруа Мерлен', logo: 'https://dummyimage.com/160x70/10b981/ffffff&text=Леруа+Мерлен' },
  { name: 'Росатом', logo: 'https://dummyimage.com/160x70/6366f1/ffffff&text=Росатом' },
  { name: 'Аэрофлот', logo: 'https://dummyimage.com/160x70/f97316/ffffff&text=Аэрофлот' }
];

const Home = () => {
  const [animatedStats, setAnimatedStats] = useState(statsConfig.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setAnimatedStats((prev) =>
        prev.map((value, index) => {
          const target = statsConfig[index].value;
          if (value >= target) {
            return target;
          }
          const increment = Math.ceil(target / 35);
          return Math.min(value + increment, target);
        })
      );
    }, 60);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const rotation = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(rotation);
  }, []);

  return (
    <>
      <Helmet>
        <title>TechSolutions Inc. — IT-консалтинг и разработка ПО</title>
        <meta
          name="description"
          content="TechSolutions Inc. помогает компаниям проходить цифровую трансформацию: IT-консалтинг, веб- и мобильная разработка, интеграция систем."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="hero-title">
        <div className={`${shared.container} ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <h1 id="hero-title">
              Стратегический IT-партнёр для цифровой трансформации бизнеса
            </h1>
            <p>
              Объединяем консалтинг, разработку и интеграцию систем, чтобы создавать технологичные решения, которые ускоряют рост компаний по всей России и СНГ.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className={shared.primaryButton}>
                Обсудить проект
              </Link>
              <Link to="/portfolio" className={shared.secondaryButton}>
                Посмотреть кейсы
              </Link>
            </div>
            <div className={styles.heroBadges}>
              <span>12+ лет опыта</span>
              <span>Сертифицированные Scrum-команды</span>
              <span>ISO 27001</span>
            </div>
          </div>
          <div className={styles.heroMedia} role="presentation">
            <img
              src="https://picsum.photos/960/640?random=201"
              alt="Команда TechSolutions Inc. обсуждает архитектуру проекта"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={`${shared.section} ${styles.statsSection}`} aria-label="Ключевые показатели">
        <div className={shared.container}>
          <div className={styles.statsGrid}>
            {statsConfig.map((item, index) => (
              <article key={item.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {animatedStats[index]}
                  {item.suffix ? item.suffix : '+'}
                </span>
                <span className={styles.statLabel}>{item.label}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={shared.section} aria-labelledby="services-title">
        <div className={shared.container}>
          <div className={shared.sectionHeader}>
            <h2 id="services-title">Наши ключевые услуги</h2>
            <p>
              От первых гипотез до масштабирования готового продукта — берём на себя всю технологическую экспертизу, чтобы ваш бизнес мог развиваться быстрее.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceIcon} aria-hidden="true">{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/uslugi" className={styles.serviceLink}>
                  Узнать подробнее →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${shared.section} ${styles.advantagesSection}`} aria-labelledby="advantages-title">
        <div className={`${shared.container} ${styles.advantagesWrapper}`}>
          <div className={styles.advantagesIntro}>
            <h2 id="advantages-title">Почему с нами работают лидеры отрасли</h2>
            <p>
              TechSolutions Inc. — это команда инженеров, архитекторов и аналитиков, которые берут ответственность за результат. Мы говорим на языке бизнеса и заботимся о том, чтобы технология помогала достигать стратегических целей.
            </p>
            <Link to="/o-kompanii" className={shared.primaryButton}>
              Узнать о компании
            </Link>
          </div>
          <div className={styles.advantagesList}>
            {advantages.map((advantage) => (
              <article key={advantage.title} className={styles.advantageItem}>
                <h3>{advantage.title}</h3>
                <p>{advantage.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${shared.section} ${styles.processSection}`} aria-labelledby="process-title">
        <div className={shared.container}>
          <div className={shared.sectionHeader}>
            <h2 id="process-title">Путь от идеи до масштабирования</h2>
            <p>
              Мы сопровождаем проект на каждом этапе, подстраиваясь под скорость бизнеса и требования отраслевых регуляторов.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processCard}>
                <span className={styles.processStep}>0{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${shared.section} ${styles.blogSection}`} aria-labelledby="blog-title">
        <div className={shared.container}>
          <div className={shared.sectionHeader}>
            <h2 id="blog-title">Из нашего блога</h2>
            <p>Актуальные идеи и практические рекомендации, как внедрять цифровые продукты и выстраивать эффективные команды.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogMeta}>{post.date}</div>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/blog" className={styles.blogLink}>Читать в блоге →</Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${shared.section} ${styles.clientsSection}`} aria-labelledby="clients-title">
        <div className={shared.container}>
          <div className={styles.clientsHeader}>
            <div>
              <h2 id="clients-title">Нам доверяют</h2>
              <p>Работаем с крупными корпорациями и быстрорастущими технологичными компаниями по всей России и СНГ.</p>
            </div>
            <Link to="/portfolio" className={shared.secondaryButton}>
              Все кейсы →
            </Link>
          </div>
          <div className={styles.clientsGrid}>
            {clients.map((client) => (
              <div key={client.name} className={styles.clientCard}>
                <img src={client.logo} alt={`Логотип компании ${client.name}`} />
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${shared.section} ${styles.testimonialsSection}`} aria-labelledby="testimonials-title">
        <div className={shared.container}>
          <div className={shared.sectionHeader}>
            <h2 id="testimonials-title">Отзывы клиентов</h2>
            <p>Мы строим долгосрочные партнёрства и берёмся за проекты, в которых можем принести максимальную ценность.</p>
          </div>
          <div className={styles.testimonialCarousel}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === currentTestimonial ? styles.testimonialActive : styles.testimonialHidden
                }`}
                aria-hidden={index !== currentTestimonial}
              >
                <div className={styles.testimonialProfile}>
                  <img src={testimonial.avatar} alt={`Отзыв от ${testimonial.name}`} />
                  <div>
                    <h3>{testimonial.name}</h3>
                    <span>{testimonial.position}</span>
                  </div>
                </div>
                <p>“{testimonial.quote}”</p>
              </article>
            ))}
            <div className={styles.carouselControls} role="group" aria-label="Переключение отзывов">
              <button
                type="button"
                onClick={() =>
                  setCurrentTestimonial(
                    (currentTestimonial - 1 + testimonials.length) % testimonials.length
                  )
                }
                aria-label="Предыдущий отзыв"
              >
                ←
              </button>
              <button
                type="button"
                onClick={() =>
                  setCurrentTestimonial((currentTestimonial + 1) % testimonials.length)
                }
                aria-label="Следующий отзыв"
              >
                →
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className={`${shared.section} ${styles.contactCta}`} aria-labelledby="contact-title">
        <div className={`${shared.container} ${styles.contactCard}`}>
          <div>
            <h2 id="contact-title">Готовы обсудить ваш следующий проект?</h2>
            <p>
              Расскажите нам о задаче, и мы предложим оптимальный формат сотрудничества, команду и план запуска. Начните с консультации — это бесплатно.
            </p>
          </div>
          <Link to="/kontakty" className={shared.primaryButton}>
            Связаться с нами
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;