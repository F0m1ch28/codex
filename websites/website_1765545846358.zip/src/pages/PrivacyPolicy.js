import React from 'react';
import { Helmet } from 'react-helmet-async';
import shared from '../styles/Shared.module.css';
import styles from './Legal.module.css';

const PrivacyPolicy = () => (
  <>
    <Helmet>
      <title>Политика конфиденциальности — TechSolutions Inc.</title>
      <meta name="robots" content="noindex" />
    </Helmet>

    <section className={shared.section} aria-labelledby="privacy-title">
      <div className={shared.container}>
        <article className={styles.legalCard}>
          <h1 id="privacy-title">Политика конфиденциальности</h1>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in enim id nisl malesuada suscipit. Aenean volutpat erat id interdum ultricies. Morbi sollicitudin gravida ex, sed lobortis neque elementum ac. Integer luctus, dolor sed sodales luctus, lorem lorem finibus mauris.
          </p>
          <p>
            Suspendisse potenti. Morbi sollicitudin vehicula est, non bibendum lacus porta dignissim. Donec et fringilla nisl. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Phasellus posuere lectus id justo elementum suscipit.
          </p>
          <p>
            Pellentesque a justo id purus ultricies aliquam. Nullam facilisis ante eget augue gravida, vitae interdum turpis porta. Ut sed viverra massa. Cras euismod felis sit amet erat ornare, vitae convallis turpis tincidunt.
          </p>
        </article>
      </div>
    </section>
  </>
);

export default PrivacyPolicy;