import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import shared from '../styles/Shared.module.css';
import styles from './Portfolio.module.css';

const projects = [
  {
    title: 'Корпоративный портал для ГазПромНефть',
    category: 'Корпоративные решения',
    description:
      'Создали единую платформу коммуникаций для 45 000 сотрудников, интегрировали BI-сервисы и персонализированную ленту новостей.',
    result: 'Сокращение времени на поиск информации на 42%, рост вовлечённости персонала.',
    image: 'https://picsum.photos/1200/800?random=501'
  },
  {
    title: 'Мобильное приложение для СберБанк',
    category: 'Финтех',
    description:
      'Разработали мобильный продукт для сегмента малого бизнеса с расширенной аналитикой и функциями управления финансами.',
    result: 'MAU вырос на 37%, средний чек увеличился на 18%.',
    image: 'https://picsum.photos/1200/800?random=502'
  },
  {
    title: 'Система автоматизации для Леруа Мерлен',
    category: 'Ритейл',
    description:
      'Запустили платформу управления цепочкой поставок, интегрировали ERP и WMS, внедрили predictive analytics.',
    result: 'Оптимизация складских запасов на 23%, сокращение времени логистики на 18%.',
    image: 'https://picsum.photos/1200/800?random=503'
  },
  {
    title: 'Портал лояльности для страховой компании',
    category: 'InsurTech',
    description:
      'Создали омниканальную систему лояльности с персональными офферами и автоматической сегментацией клиентов.',
    result: 'Повышение уровня удержания клиентов на 21%, средняя конверсия выросла в 2,4 раза.',
    image: 'https://picsum.photos/1200/800?random=504'
  },
  {
    title: 'Цифровой кабинет клиента для телеком-оператора',
    category: 'Телеком',
    description:
      'Разработали web и mobile-кабинет с поддержкой self-service, интегрировали биллинг, CRM и платежные шлюзы.',
    result: 'Сократили нагрузку на call-центр на 35%, повысили NPS на 12 пунктов.',
    image: 'https://picsum.photos/1200/800?random=505'
  }
];

const categories = ['Все', 'Корпоративные решения', 'Финтех', 'Ритейл', 'InsurTech', 'Телеком'];

const Portfolio = () => {
  const [activeFilter, setActiveFilter] = useState('Все');

  const filteredProjects =
    activeFilter === 'Все'
      ? projects
      : projects.filter((project) => project.category === activeFilter);

  return (
    <>
      <Helmet>
        <title>Портфолио — TechSolutions Inc.</title>
        <meta
          name="description"
          content="Кейсы TechSolutions Inc.: корпоративные порталы, мобильные приложения, системы автоматизации и интеграции."
        />
      </Helmet>

      <section className={`${shared.section} ${styles.hero}`} aria-labelledby="portfolio-title">
        <div className={shared.container}>
          <h1 id="portfolio-title">Портфолио</h1>
          <p>
            Мы реализуем проекты любой сложности — от MVP до масштабных корпоративных платформ с интеграцией во внутреннюю инфраструктуру.
          </p>
          <div className={styles.filters} role="tablist" aria-label="Категории проектов">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={activeFilter === category}
                className={activeFilter === category ? styles.activeFilter : undefined}
                onClick={() => setActiveFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={shared.section} aria-labelledby="projects-title">
        <div className={shared.container}>
          <h2 className={styles.sectionTitle} id="projects-title">Реализованные проекты</h2>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectBody}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <div className={styles.projectResult}>
                    <strong>Результат:</strong> {project.result}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Portfolio;