import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import shared from '../styles/Shared.module.css';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Пожалуйста, укажите ваше имя.';
    if (!formData.email.trim()) {
      newErrors.email = 'Пожалуйста, укажите email.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Введите корректный email.';
    }
    if (!formData.message.trim()) newErrors.message = 'Расскажите о задаче или проекте.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setIsSubmitted(true);
      setFormData({ name: '', email: '', company: '', message: '' });
    }
  };

  return (
    <>
      <Helmet>
        <title>Контакты — TechSolutions Inc.</title>
        <meta
          name="description"
          content="Свяжитесь с TechSolutions Inc.: адрес, телефон, email и форма для запроса консультации."
        />
      </Helmet>

      <section className={`${shared.section} ${styles.hero}`} aria-labelledby="contact-title">
        <div className={shared.container}>
          <h1 id="contact-title">Свяжитесь с командой TechSolutions Inc.</h1>
          <p>
            Оставьте запрос — мы подготовим предложение по проекту и предложим оптимальную команду. Ответим в течение одного рабочего дня.
          </p>
        </div>
      </section>

      <section className={shared.section} aria-label="Форма обратной связи">
        <div className={shared.container}>
          <div className={styles.layout}>
            <div className={styles.formWrapper}>
              <h2>Запросить консультацию</h2>
              <p>Заполните форму, и мы свяжемся с вами для уточнения деталей.</p>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label htmlFor="name">Имя*</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  aria-invalid={Boolean(errors.name)}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}

                <label htmlFor="email">Email*</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  aria-invalid={Boolean(errors.email)}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}

                <label htmlFor="company">Компания</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                />

                <label htmlFor="message">Сообщение*</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  aria-invalid={Boolean(errors.message)}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}

                <button type="submit" className={shared.primaryButton}>
                  Отправить запрос
                </button>

                {isSubmitted && (
                  <div className={styles.success}>
                    Спасибо! Мы получили ваш запрос и свяжемся с вами в ближайшее время.
                  </div>
                )}
              </form>
            </div>
            <div className={styles.infoCard}>
              <h2>Контактные данные</h2>
              <ul>
                <li>
                  <strong>Адрес:</strong> 123060, г. Москва, ул. 1905 года, д. 7, БЦ «Серебряный город», офис 405
                </li>
                <li>
                  <strong>Телефон:</strong> <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </li>
                <li>
                  <strong>Email:</strong> <a href="mailto:info@techsolutions.ru">info@techsolutions.ru</a>
                </li>
              </ul>
              <div className={styles.mapWrapper}>
                <iframe
                  title="Офис TechSolutions Inc."
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2243.406884568786!2d37.5475401766475!3d55.763322992777834!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46b54978c8cf8a17%3A0x52b3e39fb8bcbac2!2z0YPQuy4gMTkwNSBnb2RhLCDQnNCw0YjQutC-0LPQvtCyLCDQnNC-0YHQutCy0LAsIDExMTEzMg!5e0!3m2!1sru!2sru!4v1709812345678!5m2!1sru!2sru"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;