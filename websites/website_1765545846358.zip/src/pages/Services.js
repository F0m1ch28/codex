import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import shared from '../styles/Shared.module.css';
import styles from './Services.module.css';

const servicesDetails = [
  {
    title: 'IT-консалтинг',
    description:
      'Проводим аудит IT-ландшафта, разрабатываем стратегию цифровой трансформации, формируем дорожную карту внедрения.',
    benefits: [
      'Диагностика архитектуры и процессов',
      'Проектирование целевой модели',
      'Экономическая оценка инициатив',
      'Подготовка к внедрению'
    ],
    image: 'https://picsum.photos/800/600?random=321'
  },
  {
    title: 'Веб-разработка',
    description:
      'Создаём web-решения: от корпоративных порталов и CRM до маркетинговых платформ с персонализацией.',
    benefits: [
      'Архитектура и UX-дизайн',
      'Разработка на современных фреймворках',
      'Интеграции с внутренними системами',
      'Автоматизированное тестирование'
    ],
    image: 'https://picsum.photos/800/600?random=322'
  },
  {
    title: 'Мобильные приложения',
    description:
      'Проектируем нативные мобильные приложения для iOS и Android, учитывая требования безопасности и UX.',
    benefits: [
      'Продуктовая аналитика и CJM',
      'UI/UX дизайн и брендирование',
      'Нативная разработка и QA',
      'Пострелизная поддержка'
    ],
    image: 'https://picsum.photos/800/600?random=323'
  },
  {
    title: 'Интеграция систем',
    description:
      'Соединяем внутренние и внешние сервисы в единую экосистему компании и обеспечиваем стабильный обмен данными.',
    benefits: [
      'Схемы интеграции и API',
      'Настройка шины данных',
      'Миграция и синхронизация',
      'Мониторинг и поддержка'
    ],
    image: 'https://picsum.photos/800/600?random=324'
  }
];

const faqItems = [
  {
    question: 'С какими технологиями вы работаете?',
    answer:
      'Мы используем широкий стек: Java, .NET, Python, Node.js, React, Angular, Kotlin, Swift, Flutter, Kubernetes, Docker и другие технологии в зависимости от задачи.'
  },
  {
    question: 'Как строится взаимодействие в проектах?',
    answer:
      'Выделяем кросс-функциональную Scrum-команду, проводим регулярные демо и планирования, предоставляем прозрачные отчёты, фиксируем SLA на поддержку.'
  },
  {
    question: 'Можно ли начать с небольшой пилотной фазы?',
    answer:
      'Да, мы часто стартуем с Discovery-этапа или пилотного проекта, чтобы сформировать гипотезы, проверить техническую реализуемость и рассчитать экономику.'
  },
  {
    question: 'Вы работаете с госзаказчиками?',
    answer:
      'Да, у нас есть опыт проектов в государственном секторе, соблюдаем требования по безопасности и регуляторные стандарты.'
  }
];

const Services = () => {
  const [activeService, setActiveService] = useState(servicesDetails[0]);
  const [openedFaq, setOpenedFaq] = useState(0);

  return (
    <>
      <Helmet>
        <title>Услуги — TechSolutions Inc.</title>
        <meta
          name="description"
          content="IT-консалтинг, веб-разработка, мобильные приложения и интеграция систем от TechSolutions Inc."
        />
      </Helmet>

      <section className={`${shared.section} ${styles.introSection}`} aria-labelledby="services-page-title">
        <div className={shared.container}>
          <header className={styles.introHeader}>
            <h1 id="services-page-title">Комплексные IT-услуги</h1>
            <p>
              Мы соединяем стратегический консалтинг, продуктовый подход и инженерную экспертизу, чтобы бизнес быстрее выходил на рынок с новыми цифровыми решениями.
            </p>
          </header>
          <div className={styles.servicesLayout}>
            <ul className={styles.servicesNav} role="tablist">
              {servicesDetails.map((service) => (
                <li key={service.title}>
                  <button
                    type="button"
                    role="tab"
                    aria-selected={activeService.title === service.title}
                    className={
                      activeService.title === service.title ? styles.serviceTabActive : undefined
                    }
                    onClick={() => setActiveService(service)}
                  >
                    {service.title}
                  </button>
                </li>
              ))}
            </ul>
            <article className={styles.serviceDetails} role="tabpanel">
              <img src={activeService.image} alt={activeService.title} loading="lazy" />
              <div>
                <h2>{activeService.title}</h2>
                <p>{activeService.description}</p>
                <ul>
                  {activeService.benefits.map((benefit) => (
                    <li key={benefit}>{benefit}</li>
                  ))}
                </ul>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={shared.section} aria-labelledby="faq-title">
        <div className={shared.container}>
          <div className={shared.sectionHeader}>
            <h2 id="faq-title">Частые вопросы</h2>
            <p>Если вы не нашли ответ, свяжитесь с нами — мы подготовим персональную консультацию.</p>
          </div>
          <div className={styles.accordion}>
            {faqItems.map((item, index) => (
              <div key={item.question} className={styles.accordionItem}>
                <button
                  type="button"
                  className={styles.accordionControl}
                  onClick={() => setOpenedFaq(index === openedFaq ? -1 : index)}
                  aria-expanded={openedFaq === index}
                >
                  <span>{item.question}</span>
                  <span className={styles.accordionIcon}>{openedFaq === index ? '−' : '+'}</span>
                </button>
                {openedFaq === index && (
                  <div className={styles.accordionContent}>
                    <p>{item.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;