import React from 'react';
import { Helmet } from 'react-helmet-async';
import shared from '../styles/Shared.module.css';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Политика cookie — TechSolutions Inc.</title>
      <meta name="robots" content="noindex" />
    </Helmet>

    <section className={shared.section} aria-labelledby="cookie-title">
      <div className={shared.container}>
        <article className={styles.legalCard}>
          <h1 id="cookie-title">Политика использования cookie</h1>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec finibus, sapien id accumsan semper, metus elit bibendum lorem, at interdum lorem augue nec lorem. Nunc maximus erat vel posuere dictum. Aliquam eget diam vitae elit consectetur consequat eget sed massa.
          </p>
          <p>
            Integer in felis nec mi efficitur mattis. Donec sed pretium enim. Etiam porta justo quis dolor imperdiet tristique. Pellentesque nec lectus et sapien suscipit ultrices. Fusce tincidunt, est non pretium volutpat, lacus eros tincidunt libero, a suscipit elit urna et ligula.
          </p>
          <p>
            Cras varius arcu in mattis condimentum. Vivamus velit purus, iaculis ac magna non, sodales fermentum dolor. Nulla quis interdum enim. Suspendisse non pharetra tortor. Sed in purus id arcu sodales ullamcorper sed at erat.
          </p>
        </article>
      </div>
    </section>
  </>
);

export default CookiePolicy;