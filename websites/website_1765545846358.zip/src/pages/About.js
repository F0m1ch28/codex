import React from 'react';
import { Helmet } from 'react-helmet-async';
import shared from '../styles/Shared.module.css';
import styles from './About.module.css';

const team = [
  {
    name: 'Мария Крылова',
    role: 'CEO & Сооснователь',
    bio: '12 лет в стратегическом консалтинге, помогает клиентам запускать крупные цифровые программы трансформации.',
    photo: 'https://picsum.photos/400/400?random=401'
  },
  {
    name: 'Андрей Волков',
    role: 'CTO',
    bio: 'Эксперт по архитектуре высоконагруженных систем. Ранее — архитектор в международных финтех-компаниях.',
    photo: 'https://picsum.photos/400/400?random=402'
  },
  {
    name: 'Полина Соколова',
    role: 'Head of Delivery',
    bio: 'Организует работу кросс-функциональных команд и следит за качеством и сроками всех проектов TechSolutions Inc.',
    photo: 'https://picsum.photos/400/400?random=403'
  },
  {
    name: 'Дмитрий Лебедев',
    role: 'Lead Solution Architect',
    bio: 'Построил десятки интеграционных ландшафтов для крупных корпораций, специализируется на микросервисной архитектуре.',
    photo: 'https://picsum.photos/400/400?random=404'
  }
];

const technologies = [
  'Java, Kotlin, Spring Boot',
  '.NET, C#, Azure',
  'JavaScript, TypeScript, React',
  'Kubernetes, Docker, Helm',
  'AWS, Yandex Cloud, GCP',
  'PostgreSQL, ClickHouse, MongoDB',
  'Kafka, RabbitMQ, gRPC',
  'CI/CD: GitLab, Jenkins, ArgoCD'
];

const partners = [
  'Microsoft Partner',
  'AWS Select Partner',
  'JetBrains Partner',
  'Atlassian Solution Partner'
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>О компании — TechSolutions Inc.</title>
        <meta
          name="description"
          content="Команда TechSolutions Inc. — эксперты в IT-консалтинге, разработке программного обеспечения и цифровой трансформации."
        />
      </Helmet>

      <section className={`${shared.section} ${styles.hero}`} aria-labelledby="about-title">
        <div className={`${shared.container} ${styles.heroContent}`}>
          <div>
            <h1 id="about-title">Мы создаём технологические решения, которые работают на бизнес</h1>
            <p>
              TechSolutions Inc. — команда инженеров, аналитиков и консультантов, объединённых целью переводить бизнес на цифровые рельсы. Мы помогаем компаниям выбирать правильные технологии, быстро внедрять инновации и управлять изменениями.
            </p>
          </div>
          <img
            src="https://picsum.photos/900/620?random=405"
            alt="Команда TechSolutions Inc. на стратегической сессии"
            loading="lazy"
          />
        </div>
      </section>

      <section className={shared.section} aria-labelledby="mission-title">
        <div className={`${shared.container} ${styles.mission}`}>
          <div className={shared.sectionHeader}>
            <h2 id="mission-title">Наша миссия</h2>
            <p>
              Помогать компаниям превращать идеи в масштабируемые технологичные продукты, формируя устойчивые преимущества.
            </p>
          </div>
          <div className={styles.missionGrid}>
            <article>
              <h3>Ценность для бизнеса</h3>
              <p>
                Мы оцениваем эффект каждого решения, чтобы технология усиливала стратегию: ускоряла вывод продуктов на рынок, повышала лояльность клиентов и оптимизировала процессы.
              </p>
            </article>
            <article>
              <h3>Команды полного цикла</h3>
              <p>
                Создаём самоорганизующиеся команды с аналитиками, архитекторами, разработчиками, дизайнерами и QA — всё, что нужно для быстрого запуска продукта.
              </p>
            </article>
            <article>
              <h3>Безопасность и качество</h3>
              <p>
                Работаем по международным стандартам, уделяем внимание DevSecOps-подходу, автоматизируем тестирование и внедряем мониторинг на всех этапах.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${shared.section} ${styles.teamSection}`} aria-labelledby="team-title">
        <div className={shared.container}>
          <div className={shared.sectionHeader}>
            <h2 id="team-title">Команда экспертов</h2>
            <p>
              За каждым проектом стоят люди, которые любят сложные задачи и умеют доводить их до результата.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.photo} alt={member.name} loading="lazy" />
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${shared.section} ${styles.techSection}`} aria-labelledby="tech-title">
        <div className={shared.container}>
          <div className={shared.sectionHeader}>
            <h2 id="tech-title">Технологии и партнёры</h2>
            <p>Мы выбираем инструменты, которые помогают масштабироваться и поддерживать высокий уровень безопасности.</p>
          </div>
          <div className={styles.techGrid}>
            <div className={styles.techStack}>
              <h3>Технологический стек</h3>
              <ul>
                {technologies.map((tech) => (
                  <li key={tech}>{tech}</li>
                ))}
              </ul>
            </div>
            <div className={styles.partners}>
              <h3>Партнёрские статусы</h3>
              <ul>
                {partners.map((partner) => (
                  <li key={partner}>{partner}</li>
                ))}
              </ul>
              <img
                src="https://picsum.photos/700/420?random=406"
                alt="Партнёрские сертификаты TechSolutions Inc."
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;