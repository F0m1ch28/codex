import React from 'react';
import { Helmet } from 'react-helmet-async';
import shared from '../styles/Shared.module.css';
import styles from './Blog.module.css';

const articles = [
  {
    title: 'Тренды в веб-разработке 2024',
    date: '12 марта 2024',
    image: 'https://picsum.photos/960/720?random=601',
    excerpt:
      'Микрофронтенды, WebAssembly, Headless CMS и искусственный интеллект меняют правила игры. Разбираемся, как использовать тренды с пользой.',
    readTime: '8 минут'
  },
  {
    title: 'Как выбрать IT-подрядчика',
    date: '28 февраля 2024',
    image: 'https://picsum.photos/960/720?random=602',
    excerpt:
      'Чек-лист критериев: техническая экспертиза, процессы управления, прозрачность коммуникаций и совместимость культур.',
    readTime: '6 минут'
  },
  {
    title: 'Преимущества Agile-методологии',
    date: '15 февраля 2024',
    image: 'https://picsum.photos/960/720?random=603',
    excerpt:
      'Agile помогает быстро реагировать на изменения рынка и снижает риски провала проектов благодаря коротким итерациям и обратной связи.',
    readTime: '7 минут'
  }
];

const Blog = () => {
  return (
    <>
      <Helmet>
        <title>Блог — TechSolutions Inc.</title>
        <meta
          name="description"
          content="Экспертные материалы от TechSolutions Inc. о трендах в веб-разработке, Agile и выборе IT-подрядчика."
        />
      </Helmet>

      <section className={`${shared.section} ${styles.hero}`} aria-labelledby="blog-title">
        <div className={shared.container}>
          <h1 id="blog-title">Экспертный блог</h1>
          <p>
            Делимся практическими рекомендациями, кейсами и обзорами технологий, которые помогают компаниям ускорять цифровую трансформацию.
          </p>
        </div>
      </section>

      <section className={shared.section} aria-label="Статьи блога">
        <div className={shared.container}>
          <div className={styles.articlesGrid}>
            {articles.map((article) => (
              <article key={article.title} className={styles.articleCard}>
                <img src={article.image} alt={article.title} loading="lazy" />
                <div className={styles.articleBody}>
                  <div className={styles.articleMeta}>
                    <span>{article.date}</span>
                    <span>·</span>
                    <span>{article.readTime}</span>
                  </div>
                  <h2>{article.title}</h2>
                  <p>{article.excerpt}</p>
                  <a href="#!" className={styles.articleLink} onClick={(e) => e.preventDefault()}>
                    Читать полностью (скоро) →
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;