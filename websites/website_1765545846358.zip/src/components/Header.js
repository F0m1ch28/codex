import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';
import shared from '../styles/Shared.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.headerScrolled : ''}`} role="banner">
      <div className={`${shared.container} ${styles.wrapper}`}>
        <Link to="/" className={styles.logo} aria-label="TechSolutions Inc.">
          <span className={styles.logoPrimary}>Tech</span>
          <span className={styles.logoAccent}>Solutions</span>
          <span className={styles.logoSuffix}>Inc.</span>
        </Link>
        <nav
          className={`${styles.navigation} ${isMenuOpen ? styles.navigationOpen : ''}`}
          aria-label="Основная навигация"
        >
          <NavLink to="/" className={({ isActive }) => (isActive ? styles.activeLink : undefined)} end>
            Главная
          </NavLink>
          <NavLink to="/uslugi" className={({ isActive }) => (isActive ? styles.activeLink : undefined)}>
            Услуги
          </NavLink>
          <NavLink to="/o-kompanii" className={({ isActive }) => (isActive ? styles.activeLink : undefined)}>
            О компании
          </NavLink>
          <NavLink to="/portfolio" className={({ isActive }) => (isActive ? styles.activeLink : undefined)}>
            Портфолио
          </NavLink>
          <NavLink to="/blog" className={({ isActive }) => (isActive ? styles.activeLink : undefined)}>
            Блог
          </NavLink>
          <NavLink to="/kontakty" className={({ isActive }) => (isActive ? styles.activeLink : undefined)}>
            Контакты
          </NavLink>
        </nav>
        <div className={styles.actions}>
          <a className={styles.phone} href="tel:+74951234567">
            +7 (495) 123-45-67
          </a>
          <button
            className={styles.burger}
            type="button"
            onClick={() => setIsMenuOpen((prev) => !prev)}
            aria-label="Переключить меню"
            aria-expanded={isMenuOpen}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;