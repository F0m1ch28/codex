import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';
import shared from '../styles/Shared.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={`${shared.container} ${styles.footerContent}`}>
        <div className={styles.brand}>
          <div className={styles.logo}>
            TechSolutions <span>Inc.</span>
          </div>
          <p>
            Мы помогаем компаниям по всей России и СНГ проходить цифровую трансформацию: от стратегии до внедрения сложных IT-решений.
          </p>
          <div className={styles.contacts}>
            <a href="mailto:info@techsolutions.ru">info@techsolutions.ru</a>
            <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            <address>123060, г. Москва, ул. 1905 года, д. 7, БЦ «Серебряный город», офис 405</address>
          </div>
        </div>
        <div className={styles.linksGroup}>
          <h4>Навигация</h4>
          <ul>
            <li><Link to="/">Главная</Link></li>
            <li><Link to="/uslugi">Услуги</Link></li>
            <li><Link to="/o-kompanii">О компании</Link></li>
            <li><Link to="/portfolio">Портфолио</Link></li>
            <li><Link to="/blog">Блог</Link></li>
            <li><Link to="/kontakty">Контакты</Link></li>
          </ul>
        </div>
        <div className={styles.linksGroup}>
          <h4>Правовая информация</h4>
          <ul>
            <li><Link to="/usloviya">Пользовательское соглашение</Link></li>
            <li><Link to="/konfidencialnost">Политика конфиденциальности</Link></li>
            <li><Link to="/politika-cookie">Политика использования cookie</Link></li>
          </ul>
        </div>
        <div className={styles.newsletter}>
          <h4>Подписка на новости</h4>
          <p>Получайте инсайты о цифровой трансформации и практические рекомендации от наших экспертов.</p>
          <form className={styles.form} onSubmit={(e) => e.preventDefault()}>
            <label htmlFor="footer-email" className="visually-hidden">Email</label>
            <input id="footer-email" type="email" placeholder="Ваш email" required />
            <button type="submit">Подписаться</button>
          </form>
        </div>
      </div>
      <div className={styles.bottom}>
        <div className={shared.container}>
          <span>© {new Date().getFullYear()} TechSolutions Inc. Все права защищены.</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;