import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_STORAGE_KEY = 'techsolutions-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleChoice = (choice) => {
    window.localStorage.setItem(COOKIE_STORAGE_KEY, choice);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Мы используем cookie, чтобы сделать сайт удобнее, анализировать трафик и улучшать сервис. Подробнее — в нашей
          <a href="/politika-cookie"> политике cookie</a>.
        </p>
        <div className={styles.actions}>
          <button onClick={() => handleChoice('accepted')} className={styles.acceptButton}>
            Принять
          </button>
          <button onClick={() => handleChoice('declined')} className={styles.declineButton}>
            Отклонить
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;