document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.site-nav');
  if (navToggle && navMenu) {
    navToggle.addEventListener('click', function () {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      navMenu.classList.toggle('is-open');
    });

    navMenu.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (navMenu.classList.contains('is-open')) {
          navMenu.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptButton = cookieBanner.querySelector('.cookie-accept');
    const declineButton = cookieBanner.querySelector('.cookie-decline');
    const storedConsent = localStorage.getItem('fs-cookie-consent');

    if (storedConsent === 'accepted' || storedConsent === 'declined') {
      cookieBanner.classList.add('is-hidden');
    }

    if (acceptButton) {
      acceptButton.addEventListener('click', function () {
        localStorage.setItem('fs-cookie-consent', 'accepted');
        cookieBanner.classList.add('is-hidden');
      });
    }

    if (declineButton) {
      declineButton.addEventListener('click', function () {
        localStorage.setItem('fs-cookie-consent', 'declined');
        cookieBanner.classList.add('is-hidden');
      });
    }
  }
});