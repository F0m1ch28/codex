document.addEventListener('DOMContentLoaded', function () {
    var cookieBanner = document.getElementById('cookie-banner');
    if (!cookieBanner) {
        return;
    }

    var storedConsent = localStorage.getItem('cookieConsent');
    if (storedConsent) {
        cookieBanner.classList.add('cookie-hidden');
    } else {
        cookieBanner.classList.remove('cookie-hidden');
    }

    cookieBanner.addEventListener('click', function (event) {
        var target = event.target;
        if (!target.matches('button[data-consent]')) {
            return;
        }
        var choice = target.getAttribute('data-consent');
        localStorage.setItem('cookieConsent', choice);
        cookieBanner.classList.add('cookie-hidden');
    });
});