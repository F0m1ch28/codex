```javascript
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FiMail,
  FiPhone,
  FiMapPin,
  FiSend,
  FiClock,
  FiCheckCircle
} from 'react-icons/fi';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const fadeIn = {
  hidden: { opacity: 0, y: 42 },
  visible: (index = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: index * 0.12 }
  })
};

const Contact = () => {
  const [values, setValues] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');

  const validate = () => {
    const nextErrors = {};
    if (!values.name.trim()) nextErrors.name = 'Введите ваше имя';
    if (!values.email.trim()) {
      nextErrors.email = 'Укажите почту';
    } else if (!/^\S+@\S+\.\S+$/.test(values.email)) {
      nextErrors.email = 'Неверный формат e-mail';
    }
    if (!values.message.trim()) nextErrors.message = 'Напишите кратко о проекте';
    return nextErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setErrors({});
    setStatus('loading');

    setTimeout(() => {
      setStatus('success');
      setValues(initialState);
    }, 1200);
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
  };

  const contactCards = [
    {
      icon: <FiMail />,
      title: 'Почта',
      value: 'hello@aperture.studio',
      href: 'mailto:hello@aperture.studio'
    },
    {
      icon: <FiPhone />,
      title: 'Телефон',
      value: '+7 (495) 123-45-67',
      href: 'tel:+74951234567'
    },
    {
      icon: <FiMapPin />,
      title: 'Офис',
      value: 'Москва, Большая Никитская, 12',
      href: 'https://maps.google.com'
    },
    {
      icon: <FiClock />,
      title: 'Онлайн-встречи',
      value: 'Пн–Пт, 09:00–20:00 (UTC+3)'
    }
  ];

  return (
    <div className={styles.page}>
      <motion.section
        className={styles.hero}
        initial="hidden"
        animate="visible"
        variants={fadeIn}
      >
        <h1>Расскажите о задаче — соберем roadmap уже на первой встрече</h1>
        <p>
          Заполните форму, и мы вернемся с предложением по формату сотрудничества и
          результатам, которых достигнем вместе.
        </p>
      </motion.section>

      <motion.section
        className={styles.layout}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        <motion.form
          className={styles.form}
          onSubmit={handleSubmit}
          variants={fadeIn}
          custom={0}
        >
          <label className={styles.field}>
            <span>Имя</span>
            <input
              type="text"
              name="name"
              placeholder="Как к вам обращаться?"
              value={values.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
            />
            {errors.name && <small>{errors.name}</small>}
          </label>

          <label className={styles.field}>
            <span>E-mail</span>
            <input
              type="email"
              name="email"
              placeholder="name@company.com"
              value={values.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
            />
            {errors.email && <small>{errors.email}</small>}
          </label>

          <label className={styles.field}>
            <span>Компания</span>
            <input
              type="text"
              name="company"
              placeholder="Название компании (опционально)"
              value={values.company}
              onChange={handleChange}
            />
          </label>

          <label className={styles.field}>
            <span>Описание проекта</span>
            <textarea
              name="message"
              placeholder="Какие цели стоят перед продуктом, сроки, бюджет?"
              value={values.message}
              onChange={handleChange}
              rows={5}
              aria-invalid={Boolean(errors.message)}
            />
            {errors.message && <small>{errors.message}</small>}
          </label>

          <button type="submit" disabled={status === 'loading'}>
            <FiSend />
            {status === 'loading' ? 'Отправляем...' : 'Отправить запрос'}
          </button>

          <AnimatePresence>
            {status === 'success' && (
              <motion.div
                className={styles.success}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
              >
                <FiCheckCircle />
                <div>
                  <strong>Спасибо!</strong>
                  <span>Мы свяжемся с вами в течение рабочего дня.</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.form>

        <motion.aside
          className={styles.info}
          variants={fadeIn}
          custom={1}
        >
          <div className={styles.map}>
            <img
              src="https://images.pexels.com/photos/3184357/pexels-photo-3184357.jpeg?auto=compress&cs=tinysrgb&w=1600"
              alt="Команда за работой"
              loading="lazy"
            />
          </div>

          <div className={styles.cards}>
            {contactCards.map((card, index) => (
              <motion.a
                variants={fadeIn}
                custom={index + 0.5}
                key={card.title}
                className={styles.card}
                href={card.href || undefined}
                target={card.href?.startsWith('http') ? '_blank' : undefined}
                rel={card.href?.startsWith('http') ? 'noopener noreferrer' : undefined}
              >
                <span className={styles.icon}>{card.icon}</span>
                <div>
                  <strong>{card.title}</strong>
                  <p>{card.value}</p>
                </div>
              </motion.a>
            ))}
          </div>
        </motion.aside>
      </motion.section>
    </div>
  );
};

export default Contact;
```