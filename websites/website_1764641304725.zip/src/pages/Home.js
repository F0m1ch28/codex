```javascript
import React from 'react';
import { motion } from 'framer-motion';
import {
  FiTrendingUp,
  FiLayers,
  FiCompass,
  FiShield,
  FiZap,
  FiUsers,
  FiSearch,
  FiPenTool,
  FiCpu,
  FiArrowUpRight,
  FiQuote
} from 'react-icons/fi';
import styles from './Home.module.css';

const fadeIn = {
  hidden: { opacity: 0, y: 48 },
  visible: (index = 0) => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: [0.16, 1, 0.3, 1],
      delay: index * 0.1
    }
  })
};

const features = [
  {
    icon: <FiLayers />,
    title: 'Цифровая экосистема',
    description:
      'Комплексно проектируем интерфейсы: исследования, дизайн, продуктовая стратегия и запуск разработки.'
  },
  {
    icon: <FiCompass />,
    title: 'Стратегия роста 360°',
    description:
      'Помогаем гибко масштабироваться — от писательских UX-воркфлоу до построения data-driven процессов.'
  },
  {
    icon: <FiShield />,
    title: 'Безопасность и доверие',
    description:
      'Внедряем архитектуры с высоким уровнем кибербезопасности и соблюдаем мировые стандарты compliance.'
  }
];

const services = [
  {
    title: 'Востребованные цифровые продукты',
    description:
      'Создаем веб- и мобильные сервисы, которые соединяют данные, интеграции и пользовательский опыт в единую платформу.',
    image:
      'https://images.pexels.com/photos/3183198/pexels-photo-3183198.jpeg?auto=compress&cs=tinysrgb&w=1600',
    tags: ['UX-исследования', 'Product Design', 'React / Node', 'CI/CD']
  },
  {
    title: 'Брендинг и визуальная коммуникация',
    description:
      'Разрабатываем дизайн-системы, айдентику, анимацию и презентационные материалы с высокой узнаваемостью.',
    image:
      'https://images.pexels.com/photos/3130810/pexels-photo-3130810.jpeg?auto=compress&cs=tinysrgb&w=1600',
    tags: ['Design System', 'Motion', 'AI-ассистенты', 'Маркетинг']
  },
  {
    title: 'Интеллектуальная автоматизация',
    description:
      'Оптимизируем бизнес-процессы, внедряя ML-модели, чат-боты, RPA и умные аналитические панели.',
    image:
      'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1600',
    tags: ['Data Science', 'ML Ops', 'BI Dashboard', 'Automation']
  }
];

const process = [
  {
    icon: <FiSearch />,
    title: '01. Дискавери & инсайты',
    description: 'Интервью, Customer Journey, анализ метрик, карта возможностей.'
  },
  {
    icon: <FiPenTool />,
    title: '02. Прототипирование',
    description: 'CX-концепции, интерактивные прототипы, тестирование гипотез.'
  },
  {
    icon: <FiZap />,
    title: '03. Продуктовый запуск',
    description: 'Design system, React-разработка, DevOps и QA-оркестрация.'
  },
  {
    icon: <FiTrendingUp />,
    title: '04. Growth & support',
    description: 'Product analytics, A/B тесты, постоянное развитие и SLA-поддержка.'
  }
];

const testimonials = [
  {
    quote:
      'За 12 недель мы полностью переупаковали цифровую платформу. Поток заявок вырос на 68%, а команда стала работать быстрее благодаря единой дизайн-системе.',
    name: 'Анна Черкасова',
    role: 'Head of Digital, Mercury Bank',
    avatar: 'https://images.pexels.com/photos/1181681/pexels-photo-1181681.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    quote:
      'Aperture внедрили для нас автоматизацию на базе AI. Освободили 600+ часов ручного труда и ускорили обработку сделок на 35%.',
    name: 'Олег Панкратов',
    role: 'COO, Nova Logistics',
    avatar: 'https://images.pexels.com/photos/2777898/pexels-photo-2777898.jpeg?auto=compress&cs=tinysrgb&w=800'
  }
];

const metrics = [
  { value: '85%', label: 'Клиентов приходят по рекомендациям' },
  { value: '20+', label: 'Отраслей в нашем портфолио' },
  { value: '12 нед.', label: 'Средний таймлайн запуска' }
];

const Home = () => {
  return (
    <div className={styles.page}>
      <motion.section
        id="hero"
        className={styles.hero}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        <motion.div variants={fadeIn} className={styles.heroContent}>
          <span className={styles.pulseTag}>
            <FiTrendingUp />
            Партнер по цифровой трансформации
          </span>
          <h1>
            Создаем продукты,
            <span> которые любят пользователи</span>
          </h1>
          <p>
            Мы соединяем стратегию, дизайн и технологии, чтобы создавать цифровые
            продукты с сильной визуальной эстетикой и измеримым бизнес-эффектом.
          </p>
          <div className={styles.heroButtons}>
            <a href="/#cases" className={styles.primary}>
              Смотреть кейсы <FiArrowUpRight />
            </a>
            <a href="/contact" className={styles.secondary}>
              Запланировать встречу
            </a>
          </div>
          <div className={styles.metrics}>
            {metrics.map((item, index) => (
              <motion.div
                key={item.label}
                className={styles.metricCard}
                variants={fadeIn}
                custom={index + 1}
              >
                <strong>{item.value}</strong>
                <span>{item.label}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div variants={fadeIn} custom={1.4} className={styles.heroVisual}>
          <div className={styles.visualCard}>
            <img
              src="https://images.pexels.com/photos/3184306/pexels-photo-3184306.jpeg?auto=compress&cs=tinysrgb&w=1600"
              alt="Команда за работой"
              loading="lazy"
            />
            <div className={styles.visualOverlay}>
              <div>
                <p>Дизайн, который масштабируется</p>
                <span>Design system · Motion · No-code</span>
              </div>
              <div className={styles.avatarGroup}>
                <motion.div
                  className={styles.avatar}
                  animate={{ y: [0, -4, 0] }}
                  transition={{ repeat: Infinity, duration: 4, ease: 'easeInOut' }}
                >
                  <img
                    src="https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=200"
                    alt="Сотрудник"
                    loading="lazy"
                  />
                </motion.div>
                <motion.div
                  className={styles.avatar}
                  animate={{ y: [0, 4, 0] }}
                  transition={{ repeat: Infinity, duration: 4, ease: 'easeInOut', delay: 0.6 }}
                >
                  <img
                    src="https://images.pexels.com/photos/1036622/pexels-photo-1036622.jpeg?auto=compress&cs=tinysrgb&w=200"
                    alt="Сотрудник"
                    loading="lazy"
                  />
                </motion.div>
              </div>
            </div>
          </div>

          <div className={styles.floatingCard}>
            <FiCpu />
            Интеграция AI, аналитики и геймификации в одной экосистеме.
          </div>
        </motion.div>
      </motion.section>

      <motion.section
        id="features"
        className={`${styles.section} ${styles.features}`}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        <motion.div variants={fadeIn} className={styles.sectionHeader}>
          <span>Наш фокус</span>
          <h2>Стратегические преимущества студии</h2>
          <p>
            Мы работаем как кросс-функциональная команда, обеспечивая полный цикл —
            от discovery до product growth.
          </p>
        </motion.div>
        <div className={styles.featureGrid}>
          {features.map((feature, index) => (
            <motion.article
              key={feature.title}
              className={styles.featureCard}
              variants={fadeIn}
              custom={index + 1}
              whileHover={{ translateY: -8, transition: { duration: 0.35, ease: 'easeOut' } }}
            >
              <div className={styles.icon}>{feature.icon}</div>
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
            </motion.article>
          ))}
        </div>
      </motion.section>

      <motion.section
        id="services"
        className={`${styles.section} ${styles.services}`}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        <motion.div variants={fadeIn} className={styles.sectionHeader}>
          <span>Решения</span>
          <h2>Комплексные услуги для амбициозных брендов</h2>
        </motion.div>
        <div className={styles.serviceGrid}>
          {services.map((service, index) => (
            <motion.article
              key={service.title}
              className={styles.serviceCard}
              variants={fadeIn}
              custom={index}
              whileHover={{ translateY: -10 }}
            >
              <div className={styles.serviceImage}>
                <img src={service.image} alt={service.title} loading="lazy" />
              </div>
              <div className={styles.serviceContent}>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <ul>
                  {service.tags.map((tag) => (
                    <li key={tag}>{tag}</li>
                  ))}
                </ul>
              </div>
            </motion.article>
          ))}
        </div>
      </motion.section>

      <motion.section
        id="process"
        className={`${styles.section} ${styles.process}`}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        <motion.div variants={fadeIn} className={styles.sectionHeader}>
          <span>Методология</span>
          <h2>Прозрачный процесс с измеримым результатом</h2>
        </motion.div>
        <div className={styles.processGrid}>
          {process.map((step, index) => (
            <motion.div
              key={step.title}
              className={styles.processStep}
              variants={fadeIn}
              custom={index + 1}
            >
              <div className={styles.processIcon}>{step.icon}</div>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </motion.div>
          ))}
        </div>
      </motion.section>

      <motion.section
        id="cases"
        className={`${styles.section} ${styles.testimonials}`}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        <motion.div variants={fadeIn} className={styles.sectionHeader}>
          <span>Отзывы</span>
          <h2>Избранные истории клиентов</h2>
        </motion.div>
        <div className={styles.testimonialGrid}>
          {testimonials.map((item, index) => (
            <motion.article
              key={item.name}
              className={styles.testimonialCard}
              variants={fadeIn}
              custom={index}
            >
              <FiQuote />
              <p>{item.quote}</p>
              <div className={styles.person}>
                <img src={item.avatar} alt={item.name} loading="lazy" />
                <div>
                  <strong>{item.name}</strong>
                  <span>{item.role}</span>
                </div>
              </div>
            </motion.article>
          ))}
          <motion.div
            className={styles.sideCard}
            variants={fadeIn}
            custom={1.4}
            whileHover={{ scale: 1.02 }}
          >
            <FiUsers />
            <p>
              32 эксперта по продукту, дизайну, данным и AI работают на ваш результат в единой
              команде.
            </p>
            <a href="/services">
              Отьти к услугам <FiArrowUpRight />
            </a>
          </motion.div>
        </div>
      </motion.section>

      <motion.section
        id="cta"
        className={`${styles.section} ${styles.cta}`}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        <motion.div variants={fadeIn} className={styles.ctaContent}>
          <span>Готовы ускорить рост?</span>
          <h2>
            Давайте соберём roadmap, который превратит ваш продукт в магнит для пользователей.
          </h2>
          <p>
            Запишитесь на стратегическую сессию — за 45 минут соберем карту возможностей и план
            запуска.
          </p>
          <div className={styles.ctaActions}>
            <a href="/contact" className={styles.primary}>
              Назначить встречу <FiArrowUpRight />
            </a>
            <a href="/#features" className={styles.secondary}>
              Посмотреть подход
            </a>
          </div>
        </motion.div>
      </motion.section>
    </div>
  );
};

export default Home;
```