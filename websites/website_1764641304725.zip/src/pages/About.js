```javascript
import React from 'react';
import { motion } from 'framer-motion';
import { FiTarget, FiHeart, FiGlobe, FiAward } from 'react-icons/fi';
import styles from './About.module.css';

const fadeIn = {
  hidden: { opacity: 0, y: 40 },
  visible: (index = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: index * 0.12 }
  })
};

const values = [
  {
    icon: <FiTarget />,
    title: 'Бизнес-результат превыше всего',
    description:
      'Мы начинаем с четкой гипотезы и метрик. Спорим не о красоте пикселей, а о росте ключевых показателей.'
  },
  {
    icon: <FiHeart />,
    title: 'Человекоцентричный подход',
    description:
      'Вовлекаем пользователей на этапах discovery, тестируем каждое решение и создаем опыт, основанный на эмпатии.'
  },
  {
    icon: <FiGlobe />,
    title: 'Гибкость и распределенные команды',
    description:
      'Работаем в гибридном формате, подключаем экспертов из Лондона, Берлина и Сингапура под конкретный проект.'
  },
  {
    icon: <FiAward />,
    title: 'Качество и прозрачность',
    description:
      'Weekly review, Miro-доски, открытые roadmaps и понятные бюджеты. Вы всегда в курсе прогресса.'
  }
];

const About = () => {
  return (
    <div className={styles.page}>
      <motion.section
        className={styles.hero}
        initial="hidden"
        animate="visible"
        variants={fadeIn}
      >
        <span>О студии</span>
        <h1>
          Команда, которая берет ответственность за продукт от идеи до масштабирования.
        </h1>
        <p>
          Aperture Studio — международное агентство цифрового продукта и брендинга. Мы
          объединяем стратегов, дизайнеров, разработчиков и аналитиков в единую команду,
          чтобы искать неожиданные инсайты и создавать экосистемы, которые остаются
          актуальными в динамичном мире.
        </p>
      </motion.section>

      <motion.section
        className={styles.stats}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        <motion.div variants={fadeIn} custom={0}>
          <strong>50+</strong>
          <span>запущенных продуктов за последние три года</span>
        </motion.div>
        <motion.div variants={fadeIn} custom={1}>
          <strong>4.9/5</strong>
          <span>средняя оценка клиентов по итогам сотрудничества</span>
        </motion.div>
        <motion.div variants={fadeIn} custom={2}>
          <strong>7</strong>
          <span>часовых поясов — мы покрываем проекты 24/7</span>
        </motion.div>
      </motion.section>

      <motion.section
        className={styles.grid}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        <motion.div variants={fadeIn} className={styles.textBlock}>
          <h2>Как мы работаем</h2>
          <p>
            Мы сторонники прозрачности и синхронизации. В начале каждого проекта формируем
            единый roadmap, определяем метрики успеха и собираем кросс-функциональную команду.
            Каждую неделю проводим демо, тестируем гипотезы и фиксируем прогресс в Notion.
          </p>
          <p>
            Для нас важна совместная работа с заказчиком. Мы интегрируемся в ваши процессы, а
            не работаем в изоляции. Это позволяет получать быстрый фидбек и ускорять релизы.
          </p>
        </motion.div>

        <motion.div variants={fadeIn} custom={1} className={styles.imageBlock}>
          <img
            src="https://images.pexels.com/photos/3861958/pexels-photo-3861958.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Команда Aperture Studio"
            loading="lazy"
          />
          <div className={styles.badge}>
            «Мы создаем опыт, в который хочется возвращаться снова и снова».
          </div>
        </motion.div>
      </motion.section>

      <motion.section
        className={styles.values}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        <motion.h2 variants={fadeIn}>Наши ценности</motion.h2>
        <div className={styles.valueGrid}>
          {values.map((item, index) => (
            <motion.article
              key={item.title}
              className={styles.valueCard}
              variants={fadeIn}
              custom={index}
            >
              <span className={styles.icon}>{item.icon}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </motion.article>
          ))}
        </div>
      </motion.section>

      <motion.section
        className={styles.mission}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        <motion.div variants={fadeIn}>
          <h2>Миссия</h2>
          <p>
            Помогать технологичным компаниям создавать продукты, которые ценят люди. Мы
            верим, что сильный дизайн и умные технологии способны трансформировать бизнес и
            улучшать жизнь пользователей.
          </p>
        </motion.div>
        <motion.div variants={fadeIn} custom={1}>
          <h2>Подбор команды</h2>
          <p>
            Мы формируем dedicated-команды под каждый проект. Внутри — product-менеджер,
            UX-исследователь, дизайнеры, разработчики, инженеры по данным, QA и motion. Так мы
            обеспечиваем быстрые итерации и глубокую экспертизу.
          </p>
        </motion.div>
      </motion.section>
    </div>
  );
};

export default About;
```