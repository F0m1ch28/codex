```javascript
import React from 'react';
import { motion } from 'framer-motion';
import {
  FiTrendingUp,
  FiLayers,
  FiPieChart,
  FiCloud,
  FiAnchor,
  FiSmartphone
} from 'react-icons/fi';
import styles from './Services.module.css';

const fadeIn = {
  hidden: { opacity: 0, y: 36 },
  visible: (index = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: index * 0.12 }
  })
};

const offerings = [
  {
    icon: <FiLayers />,
    title: 'Product Discovery',
    description:
      'Глубокие исследования аудитории, карта CJM, workshop 2-day, приоритизация гипотез и продуктовый roadmap.',
    deliverables: ['CX Vision', 'Портреты пользователей', 'Product Strategy Deck', 'Prioritised Backlog']
  },
  {
    icon: <FiTrendingUp />,
    title: 'Digital Product Design',
    description:
      'Проектируем веб- и мобильные интерфейсы. Строим дизайн-системы с компонентами и документацией.',
    deliverables: ['Design System', 'UI Kit', 'Prototype', 'Motion & Microinteraction Spec']
  },
  {
    icon: <FiPieChart />,
    title: 'Analytics & Experimentation',
    description:
      'Настраиваем продуктовую аналитику, строим дашборды, запускаем A/B тесты и модели удержания.',
    deliverables: ['KPI Dashboard', 'Experiments Pipeline', 'Cohort Analysis', 'Retention Framework']
  },
  {
    icon: <FiCloud />,
    title: 'Full-stack Engineering',
    description:
      'Frontend на React/Next, Backend на Node/Nest, микросервисы в Kubernetes, CI/CD и QA автоматизация.',
    deliverables: ['Продуктовый релиз', 'Тестовое покрытие', 'DevOps Pipeline', 'Документация']
  },
  {
    icon: <FiSmartphone />,
    title: 'Mobile Excellence',
    description:
      'От нативных приложений до гибридных решений. Используем Swift/Kotlin и React Native.',
    deliverables: ['UX Architecture', 'App Store Launch', 'Growth Kit', 'Release Management']
  },
  {
    icon: <FiAnchor />,
    title: 'Brand & Communication',
    description:
      'Айдентика, tone of voice, контент-стратегия и визуальные системы для маркетинговых каналов.',
    deliverables: ['Brand Book', 'Content Engine', 'Campaign Assets', 'Narrative Toolkit']
  }
];

const Services = () => {
  return (
    <div className={styles.page}>
      <motion.section
        className={styles.hero}
        initial="hidden"
        animate="visible"
        variants={fadeIn}
      >
        <h1>Пакеты услуг, настроенные под ваш рост</h1>
        <p>
          Сочетаем стратегию, дизайн и инжиниринг. Наша сила — в скорости и глубине: строим
          мощные продукты, сохраняя эстетику и внимание к деталям.
        </p>
      </motion.section>

      <motion.section
        className={styles.offers}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.25 }}
      >
        {offerings.map((item, index) => (
          <motion.article
            key={item.title}
            className={styles.card}
            variants={fadeIn}
            custom={index}
            whileHover={{ translateY: -8 }}
          >
            <div className={styles.icon}>{item.icon}</div>
            <h3>{item.title}</h3>
            <p>{item.description}</p>
            <ul>
              {item.deliverables.map((deliverable) => (
                <li key={deliverable}>{deliverable}</li>
              ))}
            </ul>
          </motion.article>
        ))}
      </motion.section>

      <motion.section
        className={styles.note}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.25 }}
        variants={fadeIn}
      >
        <h2>Не нашли нужный формат?</h2>
        <p>
          Мы собираем кастомные команды и гибкие модели сотрудничества: discovery-спринты,
          продуктовые ретейнеры, venture builder или наставничество для in-house команды.
        </p>
        <a href="/contact">Обсудить задачу →</a>
      </motion.section>
    </div>
  );
};

export default Services;
```