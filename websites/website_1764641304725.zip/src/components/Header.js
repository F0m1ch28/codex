```javascript
import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { FiMenu, FiX, FiArrowUpRight } from 'react-icons/fi';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => {
      setIsScrolled(window.scrollY > 24);
      document.body.style.setProperty('--scroll-position', `${window.scrollY}px`);
    };

    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  const goHome = () => {
    if (location.pathname === '/' && !location.hash) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      navigate('/');
    }
  };

  const handleHashNavigation = (path) => {
    const hash = path.split('#')[1];
    if (location.pathname === '/' && location.hash === `#${hash}`) {
      const target = document.getElementById(hash);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    } else {
      navigate(path);
    }
  };

  const navItems = [
    { label: 'Главная', path: '/' },
    { label: 'Услуги', path: '/#services', anchor: true },
    { label: 'Подход', path: '/#process', anchor: true },
    { label: 'Кейсы', path: '/#cases', anchor: true },
    { label: 'О компании', path: '/about' }
  ];

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`}>
      <div className={styles.container}>
        <button
          type="button"
          className={styles.logo}
          onClick={goHome}
          aria-label="Перейти на главную страницу"
        >
          <span className={styles.logoMark}>Δ</span>
          <span className={styles.logoText}>Aperture Studio</span>
        </button>

        <nav className={styles.navDesktop}>
          {navItems.map((item) =>
            item.anchor ? (
              <button
                key={item.label}
                type="button"
                className={styles.navLink}
                onClick={() => handleHashNavigation(item.path)}
              >
                <span>{item.label}</span>
              </button>
            ) : (
              <NavLink
                key={item.label}
                to={item.path}
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.active : ''}`
                }
              >
                <span>{item.label}</span>
              </NavLink>
            )
          )}
          <NavLink
            to="/services"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
          >
            <span>Решения</span>
          </NavLink>
        </nav>

        <div className={styles.actions}>
          <NavLink to="/contact" className={styles.ctaButton}>
            <span>Связаться</span>
            <FiArrowUpRight />
          </NavLink>
          <button
            className={styles.menuToggle}
            type="button"
            onClick={() => setIsMenuOpen((prev) => !prev)}
            aria-label="Открыть меню"
            aria-expanded={isMenuOpen}
          >
            {isMenuOpen ? <FiX /> : <FiMenu />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isMenuOpen && (
          <motion.nav
            className={styles.navMobile}
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.24, ease: [0.25, 1, 0.5, 1] }}
          >
            {navItems.map((item) =>
              item.anchor ? (
                <button
                  key={item.label}
                  type="button"
                  className={styles.navLinkMobile}
                  onClick={() => handleHashNavigation(item.path)}
                >
                  {item.label}
                </button>
              ) : (
                <NavLink
                  key={item.label}
                  to={item.path}
                  className={({ isActive }) =>
                    `${styles.navLinkMobile} ${isActive ? styles.active : ''}`
                  }
                >
                  {item.label}
                </NavLink>
              )
            )}
            <NavLink
              to="/services"
              className={({ isActive }) =>
                `${styles.navLinkMobile} ${isActive ? styles.active : ''}`
              }
            >
              Решения
            </NavLink>
            <NavLink to="/contact" className={`${styles.navLinkMobile} ${styles.mobileAccent}`}>
              Консультация
            </NavLink>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;
```