```javascript
import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  FiArrowUpRight,
  FiInstagram,
  FiLinkedin,
  FiDribbble,
  FiTwitter
} from 'react-icons/fi';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <section className={styles.brandArea}>
          <div className={styles.brandBadge}>
            <span>Δ</span>
          </div>
          <div>
            <h3 className={styles.headline}>
              Создаем цифровые экосистемы, которые ускоряют рост бизнеса.
            </h3>
            <p className={styles.subline}>
              От стратегии до продукта — команда Aperture Studio отвечает за
              все точки контакта с вашим брендом.
            </p>
          </div>
          <NavLink to="/contact" className={styles.primaryLink}>
            Забронировать созвон
            <FiArrowUpRight />
          </NavLink>
        </section>

        <section className={styles.grid}>
          <div className={styles.column}>
            <h4>Навигация</h4>
            <nav>
              <NavLink to="/">Главная</NavLink>
              <NavLink to="/#services">Услуги</NavLink>
              <NavLink to="/#cases">Кейсы</NavLink>
              <NavLink to="/about">О компании</NavLink>
              <NavLink to="/services">Решения</NavLink>
            </nav>
          </div>

          <div className={styles.column}>
            <h4>Контакты</h4>
            <ul>
              <li>
                <a href="mailto:hello@aperture.studio">hello@aperture.studio</a>
              </li>
              <li>
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </li>
              <li>Москва, ул. Большая Никитская 12</li>
            </ul>
          </div>

          <div className={styles.column}>
            <h4>Социальные сети</h4>
            <div className={styles.socials}>
              <a href="https://www.linkedin.com" aria-label="LinkedIn">
                <FiLinkedin />
              </a>
              <a href="https://www.instagram.com" aria-label="Instagram">
                <FiInstagram />
              </a>
              <a href="https://www.dribbble.com" aria-label="Dribbble">
                <FiDribbble />
              </a>
              <a href="https://www.twitter.com" aria-label="Twitter">
                <FiTwitter />
              </a>
            </div>
            <p className={styles.smallNote}>
              Подписывайтесь, чтобы следить за инсайтами и лайв-шотами из студии.
            </p>
          </div>

          <div className={styles.column}>
            <h4>Эксклюзивная рассылка</h4>
            <p className={styles.smallNote}>
              Кейсы, аналитика и практические гайды каждую пятницу.
            </p>
            <form
              className={styles.form}
              onSubmit={(e) => {
                e.preventDefault();
                e.currentTarget.reset();
              }}
            >
              <input type="email" placeholder="Электронная почта" required />
              <button type="submit">Подписаться</button>
            </form>
          </div>
        </section>

        <section className={styles.bottom}>
          <p>© {year} Aperture Studio. Все права защищены.</p>
          <div className={styles.links}>
            <a href="/#">Конфиденциальность</a>
            <a href="/#">Cookies</a>
            <a href="/#">Партнеры</a>
          </div>
        </section>
      </div>
    </footer>
  );
};

export default Footer;
```