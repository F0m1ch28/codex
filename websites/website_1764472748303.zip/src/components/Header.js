import React, { useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";

const Header = () => {
  const [navOpen, setNavOpen] = useState(false);
  const location = useLocation();

  const toggleNav = () => setNavOpen((prev) => !prev);
  const closeNav = () => setNavOpen(false);

  return (
    <header className="site-header" data-shadow={location.pathname !== "/"}>
      <div className="header-inner">
        <Link to="/" className="brand" onClick={closeNav} aria-label="Tu Progreso Hoy home">
          <span className="brand-mark" aria-hidden="true">TPH</span>
          <span className="brand-text">
            Tu Progreso <strong>Hoy</strong>
          </span>
        </Link>

        <button
          className="menu-toggle"
          onClick={toggleNav}
          aria-expanded={navOpen}
          aria-controls="primary-navigation"
        >
          <span className="sr-only">{navOpen ? "Close menu" : "Open menu"}</span>
          <span aria-hidden="true" />
          <span aria-hidden="true" />
          <span aria-hidden="true" />
        </button>

        <nav
          id="primary-navigation"
          className={`primary-nav ${navOpen ? "open" : ""}`}
          aria-label="Primary navigation"
        >
          <NavLink to="/inflation" onClick={closeNav}>
            Inflation Watch
          </NavLink>
          <NavLink to="/course" onClick={closeNav}>
            Course
          </NavLink>
          <NavLink to="/resources" onClick={closeNav}>
            Resources
          </NavLink>
          <NavLink to="/faq" onClick={closeNav}>
            FAQ
          </NavLink>
          <NavLink to="/contact" onClick={closeNav}>
            Contact
          </NavLink>
          <span className="lang-switch" aria-label="Languages">
            EN / <span lang="es">ES</span>
          </span>
        </nav>
      </div>
    </header>
  );
};

export default Header;
```

```javascript