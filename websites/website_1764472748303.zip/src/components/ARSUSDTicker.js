import React, { useEffect, useState } from "react";

const ARSUSDTicker = () => {
  const [rate, setRate] = useState(null);
  const [timestamp, setTimestamp] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const controller = new AbortController();
    const fetchRate = async () => {
      try {
        const response = await fetch(
          "https://api.exchangerate.host/latest?base=ARS&symbols=USD",
          { signal: controller.signal }
        );
        if (!response.ok) throw new Error("Network response was not ok");
        const data = await response.json();
        if (data && data.rates && data.rates.USD) {
          setRate(1 / data.rates.USD);
          setTimestamp(data.date);
        } else {
          throw new Error("Unexpected data format");
        }
      } catch (err) {
        setError("Live rate temporarily unavailable. Using last known value: ARS 900 = USD 1.00");
        setRate(900);
        setTimestamp("reference");
      }
    };
    fetchRate();
    return () => controller.abort();
  }, []);

  return (
    <div className="ticker-card" aria-live="polite">
      <h3>ARS → USD tracker</h3>
      <div className="ticker-value" aria-label="Peso to Dollar rate">
        {rate ? (
          <>
            <span className="ticker-number">{rate.toFixed(2)}</span>
            <span className="ticker-unit">ARS per USD</span>
          </>
        ) : (
          <span className="ticker-loading">Updating rate…</span>
        )}
      </div>
      <p className="ticker-caption">
        {error ? error : timestamp ? `Last updated: ${timestamp}` : "Connecting to market sources…"}
      </p>
    </div>
  );
};

export default ARSUSDTicker;
```

```javascript