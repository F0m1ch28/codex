import React from "react";
import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="site-footer">
    <div className="footer-grid">
      <div>
        <h3>Tu Progreso Hoy</h3>
        <p>
          Datos verificados para planificar tu presupuesto.<br />
          Decisiones responsables, objetivos nítidos.
        </p>
        <p className="footer-caption">
          Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
        </p>
        <p className="footer-caption">
          Tel: <a href="tel:+541155551234">+54 11 5555-1234</a>
        </p>
      </div>
      <div>
        <h4>Explore</h4>
        <ul>
          <li>
            <Link to="/inflation">Inflation methodology</Link>
          </li>
          <li>
            <Link to="/course">Course syllabus</Link>
          </li>
          <li>
            <Link to="/resources">Knowledge resources</Link>
          </li>
          <li>
            <Link to="/faq">FAQ</Link>
          </li>
        </ul>
      </div>
      <div>
        <h4>Legal</h4>
        <ul>
          <li>
            <Link to="/privacy">Privacy Policy</Link>
          </li>
          <li>
            <Link to="/cookies">Cookies</Link>
          </li>
          <li>
            <Link to="/terms">Terms of Service</Link>
          </li>
        </ul>
      </div>
      <div>
        <h4>Connect</h4>
        <ul>
          <li>Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a></li>
          <li>
            LinkedIn:{" "}
            <a href="https://linkedin.com/company/tuprogresohoy" target="_blank" rel="noreferrer">
              /tuprogresohoy
            </a>
          </li>
          <li>
            Instagram:{" "}
            <a href="https://instagram.com/tuprogresohoy" target="_blank" rel="noreferrer">
              @tuprogresohoy
            </a>
          </li>
        </ul>
      </div>
    </div>
    <p className="footer-bottom">
      © {new Date().getFullYear()} Tu Progreso Hoy · Plataforma educativa con datos esenciales, sin asesoría financiera directa.
    </p>
  </footer>
);

export default Footer;
```

```javascript