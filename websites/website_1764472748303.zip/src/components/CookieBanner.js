import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedChoice = window.localStorage.getItem("tph-cookie-consent");
    if (!storedChoice) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (value) => {
    window.localStorage.setItem("tph-cookie-consent", value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie consent">
      <div>
        <h4>Cookies & preferences</h4>
        <p>
          We use analytical cookies to improve learning experiences. You can accept or decline.
        </p>
      </div>
      <div className="cookie-actions">
        <button className="btn-secondary" onClick={() => handleChoice("declined")}>
          Decline
        </button>
        <button className="btn-primary" onClick={() => handleChoice("accepted")}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;
```

```javascript