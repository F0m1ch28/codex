import React, { useEffect, useState } from "react";

const DisclaimerModal = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const acknowledged = window.localStorage.getItem("tph-disclaimer-ack");
    if (!acknowledged) {
      const timer = setTimeout(() => setVisible(true), 600);
      return () => clearTimeout(timer);
    }
  }, []);

  const acknowledge = () => {
    window.localStorage.setItem("tph-disclaimer-ack", "true");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
      <div className="modal-card">
        <h2 id="disclaimer-title">Important notice</h2>
        <p>
          Мы не предоставляем финансовые услуги / <strong>We do not provide financial services.</strong>
        </p>
        <p>
          Tu Progreso Hoy shares educational content and transparent market data so you can form your own
          viewpoints. Always evaluate decisions with independent analysis.
        </p>
        <button className="btn-primary" onClick={acknowledge}>
          I understand
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;
```

```javascript