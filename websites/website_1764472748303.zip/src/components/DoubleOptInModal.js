import React from "react";

const DoubleOptInModal = ({ isOpen, onConfirm, onCancel, email }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="optin-title">
      <div className="modal-card">
        <h2 id="optin-title">Confirm your subscription</h2>
        <p>
          Step 2/2 — We sent a confirmation email to <strong>{email}</strong>. Please click the link in that message
          to activate your free trial. Tap “Email confirmed” once done.
        </p>
        <div className="modal-actions">
          <button className="btn-secondary" onClick={onCancel}>
            Cancel
          </button>
          <button className="btn-primary" onClick={onConfirm}>
            Email confirmed
          </button>
        </div>
      </div>
    </div>
  );
};

export default DoubleOptInModal;
```

```javascript