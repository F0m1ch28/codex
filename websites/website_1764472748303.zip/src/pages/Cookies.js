import React from "react";
import useScrollReveal from "../hooks/useScrollReveal";

const Cookies = () => {
  const revealRef = useScrollReveal();
  return (
    <div className="page legal-page">
      <section className="legal-section reveal" ref={revealRef}>
        <h1>Cookie Policy</h1>
        <p>
          Tu Progreso Hoy uses cookies to deliver essential functionality and optional analytics. You may accept or
          decline optional cookies using the banner.
        </p>
        <h2>Types of cookies</h2>
        <ul>
          <li>
            <strong>Essential:</strong> required for site performance and security.
          </li>
          <li>
            <strong>Analytics:</strong> anonymized usage insights to refine our educational experience.
          </li>
        </ul>
        <h2>Managing cookies</h2>
        <p>
          You can control cookies via browser settings or by updating your preferences through the banner. Declining
          analytics cookies will not limit access to the course content.
        </p>
        <h2>Contact</h2>
        <p>
          Questions? Email <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>.
        </p>
      </section>
    </div>
  );
};

export default Cookies;
```

```javascript