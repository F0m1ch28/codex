import React from "react";
import { Link } from "react-router-dom";
import useScrollReveal from "../hooks/useScrollReveal";

const NotFound = () => {
  const revealRef = useScrollReveal();

  return (
    <div className="page notfound-page">
      <section className="notfound-section reveal" ref={revealRef}>
        <h1>Page not found</h1>
        <p>The page you’re looking for might have been moved or renamed.</p>
        <Link className="btn-primary" to="/">
          Return home
        </Link>
      </section>
    </div>
  );
};

export default NotFound;
```

```css