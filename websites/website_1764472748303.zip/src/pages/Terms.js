import React from "react";
import useScrollReveal from "../hooks/useScrollReveal";

const Terms = () => {
  const revealRef = useScrollReveal();

  return (
    <div className="page legal-page">
      <section className="legal-section reveal" ref={revealRef}>
        <h1>Terms of Service</h1>
        <p>Welcome to Tu Progreso Hoy. By using our site and services, you agree to the following terms.</p>
        <h2>1. Purpose</h2>
        <p>
          Tu Progreso Hoy provides educational content focused on responsible financial literacy in Argentina.
          We do not provide financial, investment, or legal advice.
        </p>
        <h2>2. Use of content</h2>
        <p>
          Content is for personal, non-commercial use. Reproduction or redistribution requires prior written consent.
        </p>
        <h2>3. User responsibilities</h2>
        <p>
          Users are responsible for maintaining accurate contact information, protecting credentials, and using the
          information responsibly.
        </p>
        <h2>4. Subscription and payments</h2>
        <p>
          Some course modules may require payment. Fees are disclosed before purchase. Refund requests are evaluated
          according to our refund policy communicated during enrollment.
        </p>
        <h2>5. Disclaimer</h2>
        <p>
          We strive for accuracy but cannot guarantee completeness of information. You should exercise independent
          judgment and consult licensed professionals when making financial decisions.
        </p>
        <h2>6. Limitation of liability</h2>
        <p>
          Tu Progreso Hoy is not liable for losses resulting from reliance on content, interruptions, or third-party
          services.
        </p>
        <h2>7. Governing law</h2>
        <p>These terms are governed by the laws of Argentina. Disputes shall be resolved in the courts of Buenos Aires.</p>
        <h2>Contact</h2>
        <p>
          For inquiries, contact <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>.
        </p>
      </section>
    </div>
  );
};

export default Terms;
```

```javascript