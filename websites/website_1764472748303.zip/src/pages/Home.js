import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import ARSUSDTicker from "../components/ARSUSDTicker";
import DoubleOptInModal from "../components/DoubleOptInModal";
import useScrollReveal from "../hooks/useScrollReveal";

const Home = () => {
  const [formData, setFormData] = useState({ name: "", email: "", goal: "" });
  const [showOptIn, setShowOptIn] = useState(false);
  const navigate = useNavigate();

  const heroRef = useScrollReveal();
  const promiseRef = useScrollReveal();
  const insightRef = useScrollReveal();
  const courseRef = useScrollReveal();
  const testimonialsRef = useScrollReveal();
  const journeyRef = useScrollReveal();
  const formRef = useScrollReveal();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setShowOptIn(true);
  };

  const handleConfirm = () => {
    setShowOptIn(false);
    navigate("/thank-you");
  };

  const handleCancel = () => {
    setShowOptIn(false);
  };

  return (
    <div className="page home-page">
      <section className="hero-section reveal" ref={heroRef}>
        <div className="hero-gradient" aria-hidden="true" />
        <div className="hero-content">
          <p className="hero-eyebrow">
            Argentina · Financial learning for resilient planning
          </p>
          <h1>
            Navigate Argentina's evolving economy with clarity and{" "}
            <span className="accent">confidence</span>.
          </h1>
          <p className="hero-subtitle">
            Conocimiento financiero impulsado por tendencias. Información confiable que respalda elecciones responsables sobre tu dinero.
          </p>
          <div className="hero-actions">
            <Link className="btn-primary" to="/inflation">
              Explore inflation insights
            </Link>
            <Link className="btn-outline" to="/course">
              View course syllabus
            </Link>
          </div>
          <div className="hero-caption">
            Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. <br />
            Pasos acertados hoy, mejor futuro mañana.
          </div>
        </div>
        <ARSUSDTicker />
      </section>

      <section className="promise-section reveal" ref={promiseRef}>
        <header>
          <h2>Our commitment to responsible learning</h2>
          <p>
            De la información al aprendizaje: fortalece tu criterio financiero paso a paso con historias,
            análisis y métricas que respetan tu contexto argentino.
          </p>
        </header>
        <div className="promise-grid">
          <article className="promise-card">
            <h3>Market transparency</h3>
            <p>Análisis transparentes y datos de mercado para decidir con seguridad.</p>
          </article>
          <article className="promise-card">
            <h3>Budget clarity</h3>
            <p>Datos verificados para planificar tu presupuesto y sostener tus metas vitales.</p>
          </article>
          <article className="promise-card">
            <h3>Future-ready mindset</h3>
            <p>Decisiones responsables, objetivos nítidos para progresar con intención.</p>
          </article>
          <article className="promise-card">
            <h3>Educational guardrails</h3>
            <p>Plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
          </article>
        </div>
      </section>

      <section className="insight-section reveal" ref={insightRef}>
        <div className="insight-copy">
          <h2>Conscious insights driven by timely indicators</h2>
          <p>
            We blend local consumer price dynamics, FX behavior, and policy narratives to contextualize
            what every peso means today. Información confiable que respalda elecciones responsables sobre tu dinero.
          </p>
          <ul className="insight-list">
            <li>
              <strong>CPI pulse:</strong> segmented inflation clusters across the AMBA region.
            </li>
            <li>
              <strong>FX sensitivity:</strong> understand ARS drift versus USD and regional baskets.
            </li>
            <li>
              <strong>Household basket lens:</strong> how staple costs reposition saving capacity.
            </li>
          </ul>
          <Link className="btn-link" to="/inflation">
            Dive into the methodology →
          </Link>
        </div>
        <div className="insight-visual" aria-hidden="true">
          <div className="chart-mock">
            <div className="chart-title">Household resilience index</div>
            <div className="chart-bars">
              {[72, 88, 64, 91, 77].map((value, index) => (
                <div key={index} className="bar" style={{ height: `${value}%` }}>
                  <span>{value}</span>
                </div>
              ))}
            </div>
            <p className="chart-caption">Composite index blending wages, CPI, and FX adjustments.</p>
          </div>
        </div>
      </section>

      <section className="course-section reveal" ref={courseRef}>
        <header>
          <h2>The Tu Progreso Hoy course path</h2>
          <p>
            From the first peso tracked to constructing a resilient spending plan: the syllabus evolves with Argentina’s momentum so you can act thoughtfully.
          </p>
        </header>
        <div className="course-grid">
          <article>
            <h3>Module 1 · Landscape</h3>
            <p>Macro snapshots, inflation mechanisms, and FX dynamics explained with approachable visuals.</p>
          </article>
          <article>
            <h3>Module 2 · Everyday budget</h3>
            <p>Segment household costs, detect price drift, and redesign savings categories that suit daily life.</p>
          </article>
          <article>
            <h3>Module 3 · Strategic action</h3>
            <p>Scenario planning, anchors for long-term goals, and habit systems tuned to Argentine volatility.</p>
          </article>
        </div>
        <Link className="btn-outline" to="/course">
          Explore the complete syllabus
        </Link>
      </section>

      <section className="testimonial-section reveal" ref={testimonialsRef}>
        <header>
          <h2>Voices from our learners</h2>
          <p>
            We curate stories to reinforce that conscious finance is attainable, relatable, and human-centered.
          </p>
        </header>
        <div className="testimonial-grid">
          <figure>
            <blockquote>
              “The weekly CPI digest nudged me to renegotiate supplier contracts before price spikes hit.
              Conocimiento financiero impulsado por tendencias.”
            </blockquote>
            <figcaption>Brenda · Mendoza</figcaption>
          </figure>
          <figure>
            <blockquote>
              “I transformed scattered spreadsheets into a plan that tracks what truly matters. Pasos acertados hoy, mejor futuro mañana.”
            </blockquote>
            <figcaption>Luciano · Córdoba</figcaption>
          </figure>
          <figure>
            <blockquote>
              “The ARS→USD tracker with context helped me pause and assess risk, instead of reacting impulsively.”
            </blockquote>
            <figcaption>Ivana · Buenos Aires</figcaption>
          </figure>
        </div>
      </section>

      <section className="journey-section reveal" ref={journeyRef}>
        <div>
          <h2>Build financial literacy with empathy and data</h2>
          <p>
            Our cohort-based rhythm keeps motivation high. Weekly live labs, recorded walkthroughs, and bilingual summaries (EN / ES) make every concept tangible.
          </p>
        </div>
        <div className="journey-pillars">
          <article>
            <h3>Contextual dashboards</h3>
            <p>Cross-layers of CPI, FX, wages, and spending habits to understand trade-offs.</p>
          </article>
          <article>
            <h3>Community reflections</h3>
            <p>Share learnings with peers aligning to responsible decisions with local realities.</p>
          </article>
          <article>
            <h3>Action templates</h3>
            <p>Scenario sheets, budgeting boards, and monthly check-ins for personal accountability.</p>
          </article>
        </div>
      </section>

      <section className="form-section reveal" ref={formRef} id="course-form">
        <header>
          <h2>Start your journey with a complimentary lesson</h2>
          <p>
            De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
          </p>
        </header>
        <form className="cta-form" onSubmit={handleSubmit}>
          <div className="form-field">
            <label htmlFor="name">Full name</label>
            <input
              id="name"
              name="name"
              type="text"
              required
              value={formData.name}
              onChange={handleChange}
              placeholder="Sofía Gómez"
            />
          </div>
          <div className="form-field">
            <label htmlFor="email">Email address</label>
            <input
              id="email"
              name="email"
              type="email"
              required
              value={formData.email}
              onChange={handleChange}
              placeholder="sofia@example.com"
            />
          </div>
          <div className="form-field">
            <label htmlFor="goal">
              What financial goal feels most urgent? <span className="optional">(optional)</span>
            </label>
            <textarea
              id="goal"
              name="goal"
              value={formData.goal}
              onChange={handleChange}
              rows="3"
              placeholder="Stabilize monthly expenses, build emergency buffer..."
            />
          </div>
          <button type="submit" className="btn-primary">
            Получить бесплатный пробный урок
          </button>
        </form>
        <p className="form-disclaimer">
          Información confiable que respalda elecciones responsables sobre tu dinero. Materials are educational; please consult independent professionals before making financial decisions.
        </p>
      </section>

      <DoubleOptInModal
        isOpen={showOptIn}
        onConfirm={handleConfirm}
        onCancel={handleCancel}
        email={formData.email}
      />
    </div>
  );
};

export default Home;
```

```javascript