import React from "react";
import useScrollReveal from "../hooks/useScrollReveal";

const Faq = () => {
  const revealRef = useScrollReveal();

  return (
    <div className="page faq-page">
      <section className="faq-hero reveal" ref={revealRef}>
        <h1>Frequently Asked Questions</h1>
        <p>
          Answers to common questions about Tu Progreso Hoy, our course, and how we approach financial education in Argentina.
        </p>
      </section>

      <section className="faq-content">
        <article>
          <h2>Is the program suitable for beginners?</h2>
          <p>
            Absolutely. We start with foundational concepts, visuals, and bilingual summaries. Every learner can
            build knowledge step by step.
          </p>
        </article>
        <article>
          <h2>How often will I receive updates?</h2>
          <p>
            Weekly, with additional alerts when significant CPI or FX movements occur. Emails include actionable insights
            and course reminders.
          </p>
        </article>
        <article>
          <h2>Do you offer live sessions?</h2>
          <p>
            Yes. We host monthly live labs to debrief economic shifts, practice scenarios, and answer participant questions.
          </p>
        </article>
        <article>
          <h2>Is there a certificate?</h2>
          <p>
            Learners completing all modules receive a certificate of completion celebrating their commitment to responsible
            financial learning.
          </p>
        </article>
        <article>
          <h2>Can I access materials offline?</h2>
          <p>
            Downloadable workbooks and transcripts are provided in both English and Spanish for offline review.
          </p>
        </article>
        <article>
          <h2>How do you protect my data?</h2>
          <p>
            We comply with privacy regulations, use secure storage, and never sell personal information. See our Privacy Policy for details.
          </p>
        </article>
      </section>
    </div>
  );
};

export default Faq;
```

```javascript