import React, { useState } from "react";
import useScrollReveal from "../hooks/useScrollReveal";

const Contact = () => {
  const [submitted, setSubmitted] = useState(false);
  const introRef = useScrollReveal();
  const formRef = useScrollReveal();
  const mapRef = useScrollReveal();

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="page contact-page">
      <section className="page-hero reveal" ref={introRef}>
        <h1>Contact</h1>
        <p>
          Tu Progreso Hoy · Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina. Teléfono: +54 11 5555-1234.
          Email: hola@tuprogresohoy.com
        </p>
      </section>

      <section className="contact-section reveal" ref={formRef}>
        <div className="contact-info">
          <h2>Write to us</h2>
          <p>
            We reply within 48 business hours. Let us know how we can support your learning journey.
          </p>
          <p>
            <strong>Email:</strong>{" "}
            <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
          </p>
          <p>
            <strong>Phone:</strong>{" "}
            <a href="tel:+541155551234">+54 11 5555-1234</a>
          </p>
          <p className="contact-caption">
            Plataforma educativa con datos esenciales, sin asesoría financiera directa. Мы не предоставляем финансовые услуги.
          </p>
        </div>
        <form className="contact-form" onSubmit={handleSubmit}>
          <div className="form-field">
            <label htmlFor="contact-name">Name</label>
            <input id="contact-name" name="name" type="text" required />
          </div>
          <div className="form-field">
            <label htmlFor="contact-email">Email</label>
            <input id="contact-email" name="email" type="email" required />
          </div>
          <div className="form-field">
            <label htmlFor="contact-message">Message</label>
            <textarea id="contact-message" name="message" rows="5" required />
          </div>
          <button className="btn-primary" type="submit">
            Send message
          </button>
          {submitted && (
            <p className="form-feedback">
              Thank you! Please check your inbox for a confirmation email to finalize your request.
            </p>
          )}
        </form>
      </section>

      <section className="map-section reveal" ref={mapRef}>
        <h2>Visit our learning studio</h2>
        <div className="map-wrapper">
          <iframe
            title="Map of Tu Progreso Hoy in Buenos Aires"
            src="https://www.openstreetmap.org/export/embed.html?bbox=-58.386%2C-34.609%2C-58.373%2C-34.602&amp;layer=mapnik"
            loading="lazy"
          />
        </div>
      </section>
    </div>
  );
};

export default Contact;
```

```javascript