import React from "react";
import useScrollReveal from "../hooks/useScrollReveal";

const Resources = () => {
  const introRef = useScrollReveal();
  const articlesRef = useScrollReveal();
  const glossaryRef = useScrollReveal();

  const articles = [
    {
      title: "Reading CPI releases without overwhelm",
      excerpt:
        "Step-by-step guide in English and Spanish to decode inflation tables and focus on what impacts your daily basket.",
      language: "EN / ES",
      link: "#"
    },
    {
      title: "FX scenarios explained for household budgets",
      excerpt:
        "Why ARS fluctuations matter to rent, salaries, and emergency funds, plus actions you can take responsibly.",
      language: "EN / ES",
      link: "#"
    },
    {
      title: "Designing your monthly retro",
      excerpt:
        "Templates, reflective questions, and conversation prompts to track progress with your partner or family.",
      language: "ES",
      link: "#"
    }
  ];

  const glossary = [
    { term: "Inflación núcleo / Core inflation", desc: "Measures price movements excluding volatile items." },
    {
      term: "Tipo de cambio MEP",
      desc: "Market-set exchange rate derived from buying/selling bonds in pesos and dollars."
    },
    {
      term: "Canasta básica total",
      desc: "Basket defining poverty threshold, covering goods and services essential for households."
    }
  ];

  return (
    <div className="page resources-page">
      <section className="page-hero reveal" ref={introRef}>
        <h1>Resources & glossaries</h1>
        <p>
          Learn at your pace with bilingual explainers, practical templates, and terms that respect the
          Argentine reality.
        </p>
      </section>

      <section className="article-section reveal" ref={articlesRef}>
        <h2>Featured articles</h2>
        <div className="article-grid">
          {articles.map((article) => (
            <article key={article.title}>
              <h3>{article.title}</h3>
              <p>{article.excerpt}</p>
              <p className="article-meta">Language: {article.language}</p>
              <a className="btn-link" href={article.link}>
                Read more →
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className="glossary-section reveal" ref={glossaryRef}>
        <h2>Glossary · Glosario</h2>
        <dl className="glossary-list">
          {glossary.map((entry) => (
            <div key={entry.term}>
              <dt>{entry.term}</dt>
              <dd>{entry.desc}</dd>
            </div>
          ))}
        </dl>
      </section>
    </div>
  );
};

export default Resources;
```

```javascript