import React from "react";
import { Link } from "react-router-dom";
import useScrollReveal from "../hooks/useScrollReveal";

const ThankYou = () => {
  const revealRef = useScrollReveal();

  return (
    <div className="page thankyou-page">
      <section className="thanks-section reveal" ref={revealRef}>
        <h1>Thank you!</h1>
        <p>
          Step complete — check your email inbox (and spam folder) to confirm your subscription. Once confirmed,
          you'll receive access to the free lesson and weekly insights.
        </p>
        <Link className="btn-primary" to="/">
          Back to home
        </Link>
      </section>
    </div>
  );
};

export default ThankYou;
```

```javascript