import React from "react";
import { Link } from "react-router-dom";
import useScrollReveal from "../hooks/useScrollReveal";

const Course = () => {
  const introRef = useScrollReveal();
  const moduleRef = useScrollReveal();
  const audienceRef = useScrollReveal();
  const callRef = useScrollReveal();

  const modules = [
    {
      title: "Module 1 · Argentina’s macro map",
      details: [
        "Inflation, FX, and policy guardrails in plain language (EN / ES).",
        "Data literacy: reading CPI tables and monetary bulletins with confidence.",
        "Mini-project: build your own trend brief using our templates."
      ]
    },
    {
      title: "Module 2 · Budget lenses",
      details: [
        "Household basket reconstruction with real Buenos Aires price tags.",
        "Identify non-negotiables vs. flexible expenses; create adjustment tiers.",
        "Mini-project: scenario planning for 5%, 7%, and 10% monthly inflation."
      ]
    },
    {
      title: "Module 3 · Action lab",
      details: [
        "Decision frameworks to prioritize goals responsibly.",
        "Stress-testing savings and emergency buffers amid ARS volatility.",
        "Mini-project: design your monthly checkpoint dashboard."
      ]
    },
    {
      title: "Module 4 · Habits and accountability",
      details: [
        "Build rituals for tracking, reflecting, and communicating finances at home.",
        "Community conversations: celebrate small wins and recalibrate plans.",
        "Graduation session with bilingual toolkit to sustain progress."
      ]
    }
  ];

  return (
    <div className="page course-page">
      <section className="page-hero reveal" ref={introRef}>
        <h1>Course syllabus</h1>
        <p>
          Designed for Argentines seeking resilient decision-making without noise. Every module delivers
          actionable knowledge backed by responsible storytelling.
        </p>
      </section>

      <section className="module-section reveal" ref={moduleRef}>
        <h2>Modules in depth</h2>
        <div className="module-grid">
          {modules.map((module) => (
            <article key={module.title}>
              <h3>{module.title}</h3>
              <ul>
                {module.details.map((detail) => (
                  <li key={detail}>{detail}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className="audience-section reveal" ref={audienceRef}>
        <h2>Who thrives in this course?</h2>
        <div className="audience-grid">
          <article>
            <h3>Household planners</h3>
            <p>
              Parents or caregivers who track grocery tickets, school fees, and transportation costs,
              ready to build calm into monthly routines.
            </p>
          </article>
          <article>
            <h3>Early-career professionals</h3>
            <p>
              Individuals confronting their first salary negotiations and savings plans, seeking clarity to
              anchor medium-term goals.
            </p>
          </article>
          <article>
            <h3>Small business owners</h3>
            <p>
              Entrepreneurs who juggle supplier inflation and payroll resilience, needing structured insights
              to communicate with their teams.
            </p>
          </article>
        </div>
      </section>

      <section className="callout-section reveal" ref={callRef}>
        <div>
          <h2>Ready to experience the first lesson?</h2>
          <p>
            Conocimiento financiero impulsado por tendencias, con tacto humano y responsabilidad. Join
            the next cohort and receive bilingual materials tailored to Argentina.
          </p>
        </div>
        <Link className="btn-primary" to="/#course-form">
          Save your seat
        </Link>
      </section>
    </div>
  );
};

export default Course;
```

```javascript