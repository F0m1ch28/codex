import React from "react";
import useScrollReveal from "../hooks/useScrollReveal";

const Privacy = () => {
  const revealRef = useScrollReveal();

  return (
    <div className="page legal-page">
      <section className="legal-section reveal" ref={revealRef}>
        <h1>Privacy Policy</h1>
        <p>
          Tu Progreso Hoy (“TPH”, “we”) is committed to protecting your privacy. This policy describes how we
          collect, use, and safeguard personal information obtained through our website and services.
        </p>
        <h2>Information we collect</h2>
        <ul>
          <li>
            <strong>Contact data:</strong> name, email, and preferred language collected via forms.
          </li>
          <li>
            <strong>Usage data:</strong> anonymized analytics to understand learning engagement (if cookies accepted).
          </li>
          <li>
            <strong>Communications:</strong> messages sent to our support channels.
          </li>
        </ul>
        <h2>Purpose of processing</h2>
        <p>We process data to deliver educational materials, manage subscriptions, and improve user experience.</p>
        <h2>Data retention</h2>
        <p>
          Personal data is retained as long as your subscription is active or required for regulatory compliance.
          You may request deletion at any time by writing to hola@tuprogresohoy.com.
        </p>
        <h2>Your rights</h2>
        <p>
          You have the right to access, rectify, or delete your personal data. You may also object to processing or
          withdraw consent for marketing communications.
        </p>
        <h2>International transfers</h2>
        <p>
          Some service providers may operate outside Argentina. We ensure adequate safeguards and contractual clauses
          to protect your information.
        </p>
        <h2>Updates</h2>
        <p>
          We may update this policy to reflect legal or operational changes. Updates will be posted on this page with
          revised effective dates.
        </p>
        <p>
          For questions, contact <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>.
        </p>
      </section>
    </div>
  );
};

export default Privacy;
```

```javascript