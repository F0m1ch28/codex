import React from "react";
import useScrollReveal from "../hooks/useScrollReveal";

const Inflation = () => {
  const topRef = useScrollReveal();
  const methodRef = useScrollReveal();
  const chartRef = useScrollReveal();
  const faqRef = useScrollReveal();

  const inflationData = [
    { month: "Jan", value: 5.6 },
    { month: "Feb", value: 6.1 },
    { month: "Mar", value: 6.8 },
    { month: "Apr", value: 7.4 },
    { month: "May", value: 7.9 },
    { month: "Jun", value: 7.1 },
    { month: "Jul", value: 6.3 },
    { month: "Aug", value: 6.7 },
    { month: "Sep", value: 8.2 },
    { month: "Oct", value: 7.5 },
    { month: "Nov", value: 6.9 },
    { month: "Dec", value: 7.2 }
  ];

  const points = inflationData
    .map((entry, index) => {
      const x = 40 + (index * 320) / (inflationData.length - 1);
      const y = 240 - (entry.value / 10) * 200;
      return `${x},${y}`;
    })
    .join(" ");

  return (
    <div className="page inflation-page">
      <section className="page-hero reveal" ref={topRef}>
        <h1>Inflation watch · AR context</h1>
        <p>
          Análisis transparentes y datos de mercado para decidir con seguridad. Our methodology translates
          CPI releases, FX swings, and policy signals into tangible narratives for your household planning.
        </p>
      </section>

      <section className="methodology-section reveal" ref={methodRef}>
        <h2>Methodology overview</h2>
        <div className="methodology-grid">
          <article>
            <h3>Data aggregation</h3>
            <p>
              We source CPI data from INDEC releases, cross-check with provincial statistics, and use weighted
              averages to reflect AMBA, Cuyo, and Patagonia realities.
            </p>
          </article>
          <article>
            <h3>FX normalization</h3>
            <p>
              ARS reference rates incorporate BCRA official quotes, MEP signals, and retail averages.
              We present them with context to avoid misleading spikes.
            </p>
          </article>
          <article>
            <h3>Household basket lens</h3>
            <p>
              Segmented baskets for food, transportation, utilities, and education show how inflation
              impacts real families beyond headline percentages.
            </p>
          </article>
          <article>
            <h3>Scenario narratives</h3>
            <p>
              We craft short narratives combining economic events with actionable reflections for budgeting,
              always emphasizing responsibility over speculation.
            </p>
          </article>
        </div>
      </section>

      <section className="chart-section reveal" ref={chartRef}>
        <h2>Monthly CPI trend 2024 (percentage)</h2>
        <div className="chart-wrapper" role="img" aria-label="Line chart of monthly CPI trend for 2024">
          <svg viewBox="0 0 400 260" preserveAspectRatio="xMidYMid meet">
            <defs>
              <linearGradient id="lineGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#2563EB" stopOpacity="0.9" />
                <stop offset="100%" stopColor="#2563EB" stopOpacity="0.1" />
              </linearGradient>
            </defs>
            <polyline
              fill="none"
              stroke="#2563EB"
              strokeWidth="4"
              strokeLinejoin="round"
              strokeLinecap="round"
              points={points}
            />
            <polygon
              fill="url(#lineGradient)"
              points={`40,240 ${points} 360,240`}
              opacity="0.5"
            />
            {inflationData.map((entry, index) => {
              const cx = 40 + (index * 320) / (inflationData.length - 1);
              const cy = 240 - (entry.value / 10) * 200;
              return (
                <g key={entry.month}>
                  <circle cx={cx} cy={cy} r="4" fill="#1F3A6F" />
                  <text x={cx} y={cy - 10} className="chart-label">
                    {entry.value}%
                  </text>
                  <text x={cx} y="255" className="chart-month">
                    {entry.month}
                  </text>
                </g>
              );
            })}
            <line x1="40" y1="40" x2="40" y2="240" className="chart-axis" />
            <line x1="40" y1="240" x2="360" y2="240" className="chart-axis" />
          </svg>
        </div>
        <p className="chart-footnote">
          The trend indicates persistent inflationary pressure above 6% monthly. Scenario planning in the course
          shows how to cushion volatility in household finances.
        </p>
      </section>

      <section className="faq-section reveal" ref={faqRef}>
        <h2>Inflation FAQ</h2>
        <div className="faq-grid">
          <article>
            <h3>How frequently do you update CPI insights?</h3>
            <p>
              We publish rapid reactions within 24 hours of the official INDEC release, then follow up with
              deep dives connecting FX movements, wage renegotiations, and household impact.
            </p>
          </article>
          <article>
            <h3>What makes your FX tracker unique?</h3>
            <p>
              Beyond quoting rates, we contextualize spreads between official, MEP, and informal references.
              Our aim is to inform, not to speculate, reinforcing responsible financial conduct.
            </p>
          </article>
          <article>
            <h3>Do you suggest financial products?</h3>
            <p>
              No. We provide educational insights. Always evaluate options independently or with licensed
              advisors. Nuestra misión es educativa y responsable.
            </p>
          </article>
          <article>
            <h3>Is the content available in Spanish?</h3>
            <p>
              Sí. All methodological documents include Spanish translations and Argentine case studies so every
              learner can connect with familiar narratives.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default Inflation;
```

```javascript