document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            navToggle.classList.toggle('is-active');
            navMenu.classList.toggle('is-open');
        });

        navMenu.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (navMenu.classList.contains('is-open')) {
                    navMenu.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        let storageAvailable = true;
        try {
            const testKey = '__plushumgl_test__';
            localStorage.setItem(testKey, testKey);
            localStorage.removeItem(testKey);
        } catch (error) {
            storageAvailable = false;
        }

        const consentKey = 'plushumgl-cookie-consent';
        const storedConsent = storageAvailable ? localStorage.getItem(consentKey) : null;

        if (storedConsent) {
            cookieBanner.classList.add('is-hidden');
        }

        cookieBanner.addEventListener('click', function (event) {
            const target = event.target.closest('[data-cookie-consent]');
            if (!target) return;

            const action = target.getAttribute('data-cookie-consent');

            if (storageAvailable && action !== 'customize') {
                localStorage.setItem(consentKey, action);
            }

            if (action === 'accept' || action === 'decline') {
                cookieBanner.classList.add('is-hidden');
            }

            if (action === 'customize') {
                if (storageAvailable) {
                    localStorage.setItem(consentKey, 'customize');
                }
                window.location.href = 'cookies.html#preferences';
            }
        });
    }
});