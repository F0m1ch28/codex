document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('open');
            navMenu.classList.toggle('open');
            document.body.classList.toggle('nav-open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('open')) {
                    navMenu.classList.remove('open');
                    navToggle.classList.remove('open');
                    document.body.classList.remove('nav-open');
                }
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 1024) {
                navMenu.classList.remove('open');
                navToggle.classList.remove('open');
                document.body.classList.remove('nav-open');
            }
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('hkqCookieConsent');
        if (storedConsent) {
            cookieBanner.classList.add('hidden');
        }

        cookieBanner.querySelectorAll('.cookie-btn').forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const choice = button.dataset.choice || 'dismissed';
                localStorage.setItem('hkqCookieConsent', choice);
                cookieBanner.classList.add('hidden');

                const target = button.getAttribute('href');
                if (target) {
                    if (choice === 'accept') {
                        window.open(target, '_blank', 'noopener');
                    } else {
                        window.location.href = target;
                    }
                }
            });
        });
    }
});