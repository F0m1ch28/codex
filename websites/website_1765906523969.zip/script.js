document.addEventListener('DOMContentLoaded', function () {
  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptCookies = document.querySelector('#acceptCookies');
  const declineCookies = document.querySelector('#declineCookies');

  if (cookieBanner) {
    const storedPreference = localStorage.getItem('ner_cookie_preference');
    if (!storedPreference) {
      setTimeout(() => cookieBanner.classList.add('show'), 600);
    }

    if (acceptCookies) {
      acceptCookies.addEventListener('click', () => {
        localStorage.setItem('ner_cookie_preference', 'accepted');
        cookieBanner.classList.remove('show');
      });
    }

    if (declineCookies) {
      declineCookies.addEventListener('click', () => {
        localStorage.setItem('ner_cookie_preference', 'declined');
        cookieBanner.classList.remove('show');
      });
    }
  }

  const contactForm = document.querySelector('#contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function (event) {
      const fields = [
        { id: 'fullName', message: 'Please provide your name.' },
        { id: 'email', message: 'A valid email address is required.' },
        { id: 'message', message: 'Please add a message outlining your inquiry.' }
      ];

      let isValid = true;

      fields.forEach(field => {
        const input = document.getElementById(field.id);
        const errorField = document.querySelector(`[data-error-for="${field.id}"]`);
        if (!input.value.trim()) {
          isValid = false;
          errorField.textContent = field.message;
        } else if (field.id === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value.trim())) {
          isValid = false;
          errorField.textContent = 'Please enter an email address in the correct format.';
        } else {
          errorField.textContent = '';
        }
      });

      if (!isValid) {
        event.preventDefault();
      }
    });
  }

  const categoryButtons = document.querySelectorAll('[data-filter]');
  const postCards = document.querySelectorAll('[data-category]');
  const searchInput = document.querySelector('#postSearch');

  function applyFilters() {
    const activeButton = document.querySelector('[data-filter][aria-pressed="true"]');
    const activeCategory = activeButton ? activeButton.dataset.filter : 'all';
    const query = searchInput ? searchInput.value.trim().toLowerCase() : '';

    postCards.forEach(card => {
      const matchesCategory = activeCategory === 'all' || card.dataset.category === activeCategory;
      const matchesQuery = !query || card.dataset.title.includes(query);
      card.style.display = matchesCategory && matchesQuery ? '' : 'none';
    });
  }

  if (categoryButtons.length) {
    categoryButtons.forEach(button => {
      button.addEventListener('click', () => {
        categoryButtons.forEach(btn => btn.setAttribute('aria-pressed', 'false'));
        button.setAttribute('aria-pressed', 'true');
        applyFilters();
      });
    });
  }

  if (searchInput) {
    postCards.forEach(card => {
      const titleText = card.querySelector('.card-title');
      card.dataset.title = titleText ? titleText.textContent.trim().toLowerCase() : '';
    });

    searchInput.addEventListener('input', applyFilters);
  }
});