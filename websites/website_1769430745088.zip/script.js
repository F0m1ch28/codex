document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const navToggle = document.querySelector('.nav-toggle');
  const yearTargets = document.querySelectorAll('[data-year]');
  const animateTargets = document.querySelectorAll('[data-animate]');
  const cookieBanner = document.querySelector('[data-cookie-banner]');
  const toast = document.querySelector('[data-toast]');
  const forms = document.querySelectorAll('form[data-form]');
  const navigation = document.querySelector('.site-nav');

  const setYear = () => {
    const year = new Date().getFullYear();
    yearTargets.forEach(target => {
      target.textContent = year;
    });
  };
  setYear();

  if (navToggle) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      body.classList.toggle('nav-open', !expanded);
    });
  }

  if (navigation) {
    navigation.addEventListener('click', event => {
      if (event.target.closest('a')) {
        body.classList.remove('nav-open');
        navToggle?.setAttribute('aria-expanded', 'false');
      }
    });
  }

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.18 });
    animateTargets.forEach(element => observer.observe(element));
  } else {
    animateTargets.forEach(element => element.classList.add('is-visible'));
  }

  const cookieStorageKey = 'dpc-cookie-choice';
  if (cookieBanner) {
    try {
      const storedChoice = localStorage.getItem(cookieStorageKey);
      if (!storedChoice) {
        cookieBanner.classList.add('active');
      }
    } catch (error) {
      cookieBanner.classList.add('active');
    }
    cookieBanner.addEventListener('click', event => {
      const acceptBtn = event.target.closest('[data-cookie-accept]');
      const declineBtn = event.target.closest('[data-cookie-decline]');
      if (acceptBtn || declineBtn) {
        try {
          localStorage.setItem(cookieStorageKey, acceptBtn ? 'accepted' : 'declined');
        } catch (error) {
          // ignore storage errors
        }
        cookieBanner.classList.remove('active');
      }
    });
  }

  const showToast = message => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
    }, 1600);
  };

  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const message = form.getAttribute('data-toast-message') || 'Message prepared. Redirecting…';
      showToast(message);
      const action = form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        window.location.href = action;
      }, 1200);
    });
  });
});