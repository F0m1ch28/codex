import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'company_cookie_consent';

function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedValue = localStorage.getItem(STORAGE_KEY);
    if (!storedValue) {
      const timer = setTimeout(() => setIsVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem(STORAGE_KEY, value);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о файлах cookie">
      <div className={styles.content}>
        <h3>Мы используем cookies</h3>
        <p>
          Cookies помогают сделать использование сайта удобнее, анализировать трафик и адаптировать контент.
          Подробнее в <Link to="/cookie-policy">политике использования файлов cookie</Link>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" onClick={() => handleConsent('accepted')} className={styles.accept}>
          Принять
        </button>
        <button type="button" onClick={() => handleConsent('declined')} className={styles.decline}>
          Отклонить
        </button>
      </div>
    </div>
  );
}

export default CookieBanner;