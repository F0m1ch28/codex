import React, { useState, useEffect } from 'react';
import styles from './ScrollToTopButton.module.css';

function ScrollToTopButton() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setIsVisible(window.scrollY > 280);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!isVisible) {
    return null;
  }

  return (
    <button type="button" onClick={handleClick} className={styles.button} aria-label="Вернуться наверх">
      ↑
    </button>
  );
}

export default ScrollToTopButton;