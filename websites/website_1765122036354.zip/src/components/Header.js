import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { to: '/', label: 'Главная' },
  { to: '/uslugi', label: 'Услуги' },
  { to: '/o-kompanii', label: 'О компании' },
  { to: '/kontakty', label: 'Контакты' },
];

function Header() {
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`}>
      <div className="container">
        <div className={styles.inner}>
          <NavLink to="/" className={styles.logo} aria-label="Компания — на главную">
            <span className={styles.logoMark}>К</span>
            <span className={styles.logoText}>Компания</span>
          </NavLink>

          <nav className={`${styles.nav} ${isMobileMenuOpen ? styles.open : ''}`} aria-label="Главная навигация">
            {navLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.activeLink : ''}`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </nav>

          <button
            className={styles.mobileToggle}
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-expanded={isMobileMenuOpen}
            aria-controls="primary-navigation"
            aria-label="Меню"
          >
            <span className={styles.burger} />
            <span className="visually-hidden">Меню</span>
          </button>
        </div>
      </div>
    </header>
  );
}

export default Header;