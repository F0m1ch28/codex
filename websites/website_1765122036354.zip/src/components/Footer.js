import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.inner}>
          <div className={styles.columnWide}>
            <div className={styles.logo}>
              <span className={styles.logoMark}>К</span>
              <span className={styles.logoText}>Компания</span>
            </div>
            <p className={styles.description}>
              Мы объединяем стратегию, технологии и человеческий подход, чтобы создавать устойчивые решения для бизнеса любой сложности.
            </p>
            <div className={styles.socials} aria-label="Социальные сети">
              <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
                <span>in</span>
              </a>
              <a href="https://www.facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook">
                <span>fb</span>
              </a>
              <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram">
                <span>ig</span>
              </a>
            </div>
          </div>

          <div className={styles.column}>
            <h3 className={styles.heading}>Навигация</h3>
            <ul className={styles.list}>
              <li><Link to="/">Главная</Link></li>
              <li><Link to="/uslugi">Услуги</Link></li>
              <li><Link to="/o-kompanii">О компании</Link></li>
              <li><Link to="/kontakty">Контакты</Link></li>
            </ul>
          </div>

          <div className={styles.column}>
            <h3 className={styles.heading}>Правовая информация</h3>
            <ul className={styles.list}>
              <li><Link to="/terms">Условия использования</Link></li>
              <li><Link to="/privacy">Политика конфиденциальности</Link></li>
              <li><Link to="/cookie-policy">Cookies</Link></li>
            </ul>
          </div>

          <div className={styles.column}>
            <h3 className={styles.heading}>Контакты</h3>
            <ul className={styles.list}>
              <li>г. Москва, ул. Примерная, д. 1</li>
              <li><a href="tel:+74951234567">+7 (495) 123-45-67</a></li>
              <li><a href="mailto:info@kompaniya.ru">info@kompaniya.ru</a></li>
            </ul>
          </div>
        </div>

        <div className={styles.bottom}>
          <p>© {year} Компания. Все права защищены.</p>
          <p>Создаем решения сегодня, чтобы ваш бизнес рос завтра.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;