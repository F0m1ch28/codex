import React from 'react';
import Meta from '../components/Meta';
import styles from './Legal.module.css';

function CookiePolicyPage() {
  return (
    <>
      <Meta
        title="Политика использования файлов cookie — Компания"
        description="Политика использования файлов cookie на сайте компании Компания."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Политика использования файлов cookie</h1>
          <p>Последнее обновление: 1 апреля 2024 года</p>
        </div>
      </section>
      <section className={styles.content}>
        <div className="container">
          <article className={styles.article}>
            <h2>1. Что такое файлы cookie</h2>
            <p>
              Файлы cookie — это небольшие текстовые файлы, которые сохраняются на вашем устройстве при посещении сайта.
              Они помогают нам улучшать работу сайта и предоставлять персонализированный опыт.
            </p>

            <h2>2. Как мы используем cookies</h2>
            <ul>
              <li>Аналитические cookies: позволяют анализировать поведение пользователей и улучшать интерфейс.</li>
              <li>Функциональные cookies: запоминают ваши настройки и предпочтения на сайте.</li>
              <li>Технические cookies: необходимы для корректной работы отдельных функций сайта.</li>
            </ul>

            <h2>3. Управление cookies</h2>
            <p>
              Вы можете управлять cookies через настройки вашего браузера. Обратите внимание, что отключение некоторых cookies может повлиять на функциональность сайта.
            </p>

            <h2>4. Контакты</h2>
            <p>Если у вас есть вопросы, свяжитесь с нами: info@kompaniya.ru или +7 (495) 123-45-67.</p>
          </article>
        </div>
      </section>
    </>
  );
}

export default CookiePolicyPage;