import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Meta from '../components/Meta';
import styles from './Home.module.css';

const statsData = [
  { value: '15+', label: 'лет экспертизы на рынке' },
  { value: '240+', label: 'завершённых проектов за прошлый год' },
  { value: '98%', label: 'уровень удовлетворенности клиентов' },
  { value: '12', label: 'отраслей, с которыми мы работаем' },
];

const services = [
  {
    title: 'Стратегическое развитие',
    description: 'Помогаем выстроить ясную стратегию роста, опираясь на аналитику рынков и ожидания клиентов.',
    icon: '📈',
  },
  {
    title: 'Инновации и технологии',
    description: 'Внедряем цифровые решения и автоматизацию, чтобы освободить время команды для ключевых задач.',
    icon: '💡',
  },
  {
    title: 'Операционная эффективность',
    description: 'Общая оптимизация процессов: от логистики и закупок до клиентского сервиса и поддержки.',
    icon: '⚙️',
  },
  {
    title: 'Бренд и коммуникация',
    description: 'Создаем целостный бренд-опыт, усиливаем репутацию и помогаем уверенно выходить на новые рынки.',
    icon: '🗣️',
  },
];

const advantages = [
  'Междисциплинарная команда с реальным опытом в бизнесе.',
  'Прозрачные процессы и вовлечение заказчика в ключевые этапы.',
  'Гибкие форматы взаимодействия: от консультаций до полного сопровождения.',
  'Непрерывная экспертиза: исследуем тренды, тестируем идеи, делимся знаниями.',
  'Собственные методики диагностики и измеримые KPI.',
  'Безопасное обращение с данными и защита ваших интересов.',
];

const processSteps = [
  {
    title: 'Диагностика и цели',
    text: 'Изучаем контекст, погружаемся в вызовы и формируем измеримые цели проекта совместно с командой клиента.',
  },
  {
    title: 'Дизайн решения',
    text: 'Создаём дорожную карту, прототипы, правила и сценарии; тестируем гипотезы на целевой аудитории.',
  },
  {
    title: 'Внедрение и обучение',
    text: 'Проводим запуск в несколько итераций, передаем компетенции вашему персоналу, сопровождаем изменения.',
  },
  {
    title: 'Поддержка и развитие',
    text: 'Отслеживаем показатели, корректируем решения и развиваем результаты, опираясь на аналитику.',
  },
];

const testimonials = [
  {
    name: 'Анна Петрова',
    role: 'Директор по развитию, Globex',
    quote:
      'Команда “Компания” помогла нам построить системный клиентский опыт. Уже через три месяца клиенты начали рекомендовать нас значительно чаще.',
  },
  {
    name: 'Игорь Соколов',
    role: 'CEO, DeltaLog',
    quote:
      'Высокий уровень вовлеченности и дисциплины. Мы получили не просто рекомендации, а рабочие инструменты, которые масштабируются в других филиалах.',
  },
  {
    name: 'Екатерина Громова',
    role: 'Сооснователь, StartPoint',
    quote:
      'Эксперты быстро погрузились в наш продукт и построили ясный план вывода на рынок. Особенно ценим внимание к деталям и прозрачность коммуникации.',
  },
];

const projectData = [
  {
    title: 'Цифровая экосистема продаж',
    category: 'Технологии',
    description: 'Разработали модульную CRM-платформу для омниканальных продаж.',
    image: 'https://picsum.photos/1200/800?random=31',
  },
  {
    title: 'Перезапуск бренда b2b-сервиса',
    category: 'Маркетинг',
    description: 'Сформировали новую платформу бренда и обновили коммуникации на всех точках контакта.',
    image: 'https://picsum.photos/1200/800?random=32',
  },
  {
    title: 'Операционная трансформация',
    category: 'Стратегия',
    description: 'Оптимизировали процесс поставок, сократив время цикла на 28%.',
    image: 'https://picsum.photos/1200/800?random=33',
  },
  {
    title: 'Внедрение продуктовой аналитики',
    category: 'Технологии',
    description: 'Настроили систему сквозной аналитики и обучили команду клиента работать с инсайтами.',
    image: 'https://picsum.photos/1200/800?random=34',
  },
  {
    title: 'Выход на международный рынок',
    category: 'Стратегия',
    description: 'Исследовали четыре страны, адаптировали оффер и локализовали продукт.',
    image: 'https://picsum.photos/1200/800?random=35',
  },
];

const faqData = [
  {
    question: 'С чего начинается сотрудничество с компанией?',
    answer:
      'Мы начинаем с диагностической сессии, чтобы погрузиться в ваши задачи. После анализа предлагаем формат работы, команду и план результатов.',
  },
  {
    question: 'Как вы работаете с конфиденциальной информацией?',
    answer:
      'Заключаем договор и NDA, определяем регламент обмена данными, используем защищенные каналы и хранилища. Доступ к информации получают только ключевые специалисты.',
  },
  {
    question: 'Можно ли обратиться за разовой консультацией?',
    answer:
      'Да, у нас есть экспресс-форматы. Мы проведём экспертную сессию, поделимся рекомендациями и помогут сформировать план действий.',
  },
  {
    question: 'Кого вы привлекаете для проектов?',
    answer:
      'В ядре команды — наши штатные эксперты. При необходимости подключаем проверенных партнеров и узкопрофильных специалистов под проектные задачи.',
  },
];

const blogPosts = [
  {
    title: 'Новое партнерство с технологической экосистемой',
    date: '12 апреля 2024',
    excerpt: 'Объединяем усилия для создания цифровых продуктов с максимально быстрым выходом на рынок.',
    to: '/novosti/novye-partnerstva',
  },
  {
    title: 'Как подготовиться к инновационному прорыву в 2024 году',
    date: '5 апреля 2024',
    excerpt: 'Собрали практические шаги, которые помогут укрепить устойчивость и готовность компании к изменениям.',
    to: '/novosti/innovacii-2024',
  },
  {
    title: 'Клиентские кейсы: рост благодаря данным',
    date: '29 марта 2024',
    excerpt: 'Рассказываем, как аналитика помогает клиентам принимать решения в режиме реального времени.',
    to: '/novosti/klientskie-keisy',
  },
];

const partners = ['Aurora', 'Northwind', 'Globex', 'Fusion', 'DeltaLog', 'StartPoint', 'Vista', 'Innova'];

const categories = ['Все', 'Стратегия', 'Технологии', 'Маркетинг'];

function HomePage() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeFilter, setActiveFilter] = useState('Все');
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    activeFilter === 'Все'
      ? projectData
      : projectData.filter((project) => project.category === activeFilter);

  const toggleFaq = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Meta
        title="Компания — Комплексные бизнес-решения и стратегическое развитие"
        description="Компания предлагает стратегическое сопровождение, технологические решения и развитие бренда. Современный подход, экспертиза в 12 отраслях, поддержка на каждом этапе роста."
      />

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div className={styles.heroContent}>
              <span className="tag">Вместе создаём устойчивый рост</span>
              <h1>Комплексные решения для уверенного развития бизнеса</h1>
              <p>
                Мы соединяем стратегию, технологии и человеческий опыт, чтобы ваши идеи быстрее становились результатом.
                Выстраиваем устойчивые процессы и поддерживаем команду на каждом этапе пути.
              </p>
              <div className={styles.heroActions}>
                <Link to="/uslugi" className={styles.primaryButton}>
                  Наши услуги
                </Link>
                <Link to="/kontakty" className={styles.secondaryButton}>
                  Связаться с нами
                </Link>
              </div>
              <div className={styles.heroHighlights}>
                <div>
                  <strong>1 200+</strong>
                  <span>идей протестировано вместе с клиентами</span>
                </div>
                <div>
                  <strong>4.9/5</strong>
                  <span>средняя оценка партнеров по итогам проектов</span>
                </div>
              </div>
            </div>
            <div className={styles.heroVisual} role="presentation">
              <img
                src="https://picsum.photos/1600/900?random=21"
                alt="Команда профессионалов обсуждает бизнес-стратегию"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>{stat.value}</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.aboutPreview}>
        <div className="container">
          <div className={styles.aboutCard}>
            <div className={styles.aboutContent}>
              <h2>О компании</h2>
              <p>
                Компания — это команда экспертов в стратегии, цифровой трансформации, операционном развитии и брендинге.
                Мы работаем с крупными холдингами, технологическими стартапами и отраслевыми лидерами, помогая им находить новые точки роста.
              </p>
              <p>
                Мы верим в партнёрство: строим отношения на доверии, прозрачности и совместной ответственности за результат.
              </p>
              <Link to="/o-kompanii" className={styles.linkButton}>
                Подробнее о нас
              </Link>
            </div>
            <div className={styles.aboutImage}>
              <img
                src="https://picsum.photos/800/600?random=22"
                alt="Совместная работа над проектом"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.servicesSection} id="services">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Что мы делаем</span>
            <h2>Ключевые направления работы</h2>
            <p>
              Соединяем глубокую экспертизу, современные технологии и прагматичный подход, чтобы сделать ваш бизнес гибким и устойчивым.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <span className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/uslugi" className={styles.serviceLink}>
                  Узнать больше →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.advantagesSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Преимущества</span>
            <h2>Почему клиенты выбирают нас</h2>
            <p>
              Наш подход — это сочетание экспертизы, ответственности и ориентации на достижение измеримых результатов.
            </p>
          </div>
          <div className={styles.advantagesGrid}>
            {advantages.map((item) => (
              <div key={item} className={styles.advantageCard}>
                <span className={styles.tick} aria-hidden="true">
                  ✔
                </span>
                <p>{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Как мы работаем</span>
            <h2>Путь проекта — от идеи до устойчивого результата</h2>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processCard}>
                <div className={styles.stepNumber}>{index + 1}</div>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaHighlight}>
        <div className="container">
          <div className={styles.ctaBox}>
            <div>
              <h2>Готовы обсудить ваш проект?</h2>
              <p>
                Расскажите нам о своих задачах — вместе найдем оптимальный формат сотрудничества и первый шаг, который даст результат.
              </p>
            </div>
            <Link to="/kontakty" className={styles.primaryButton}>
              Запланировать встречу
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.partnersSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Партнеры и клиенты</span>
            <h2>Нам доверяют команды по всему миру</h2>
            <p>Работаем с компаниями из финансового, производственного, телекоммуникационного, логистического и других секторов.</p>
          </div>
          <div className={styles.partnersGrid}>
            {partners.map((partner) => (
              <div key={partner} className={styles.partnerCard} aria-label={`Партнер ${partner}`}>
                {partner}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Отзывы</span>
            <h2>Что говорят наши клиенты</h2>
          </div>
          <div className={styles.testimonialCard}>
            <blockquote>
              “{testimonials[activeTestimonial].quote}”
            </blockquote>
            <div className={styles.testimonialAuthor}>
              <span className={styles.authorName}>{testimonials[activeTestimonial].name}</span>
              <span className={styles.authorRole}>{testimonials[activeTestimonial].role}</span>
            </div>
            <div className={styles.testimonialDots}>
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  aria-label={`Показать отзыв ${index + 1}`}
                  className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                  onClick={() => setActiveTestimonial(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Реализованные проекты</span>
            <h2>Практические результаты для разных отраслей</h2>
          </div>
          <div className={styles.filterRow}>
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${activeFilter === category ? styles.filterActive : ''}`}
                onClick={() => setActiveFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Команда</span>
            <h2>Эксперты, которые ведут проекты</h2>
          </div>
          <div className={styles.teamGrid}>
            {[
              {
                name: 'Мария Ильина',
                role: 'Партнер по стратегии',
                quote: 'Слушаем, предлагаем, проверяем и запускаем — пока решение не станет работать устойчиво.',
                image: 'https://picsum.photos/400/400?random=41',
              },
              {
                name: 'Дмитрий Крылов',
                role: 'Руководитель направления технологий',
                quote: 'Технологии ценны, когда они решают задачи людей и бизнеса, а не заменяют их.',
                image: 'https://picsum.photos/400/400?random=42',
              },
              {
                name: 'Ольга Романова',
                role: 'Лидер клиентского сервиса',
                quote: 'Поддерживаем клиента на каждом этапе и делаем сложное простым.',
                image: 'https://picsum.photos/400/400?random=43',
              },
            ].map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.quote}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">FAQ</span>
            <h2>Частые вопросы</h2>
          </div>
          <div className={styles.faqList}>
            {faqData.map((item, index) => (
              <div key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  onClick={() => toggleFaq(index)}
                  aria-expanded={openFaq === index}
                  className={styles.faqButton}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>{openFaq === index ? '−' : '+'}</span>
                </button>
                {openFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Новости и аналитика</span>
            <h2>Свежие материалы команды</h2>
            <p>Делимся инсайтами, наблюдениями и практиками, которые помогают бизнесу адаптироваться к изменениям.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.to} className={styles.blogCard}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.to} className={styles.blogLink}>
                  Читать далее →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.finalCta}>
        <div className="container">
          <div className={styles.finalCtaBox}>
            <h2>Давайте двигаться вперёд вместе</h2>
            <p>
              Оставьте заявку — мы свяжемся в течение рабочего дня, обсудим задачу и предложим первые шаги.
            </p>
            <Link to="/kontakty" className={styles.primaryButton}>
              Оставить заявку
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

export default HomePage;