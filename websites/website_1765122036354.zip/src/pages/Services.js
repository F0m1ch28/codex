import React from 'react';
import Meta from '../components/Meta';
import styles from './Services.module.css';

const serviceGroups = [
  {
    title: 'Стратегия и рост',
    description:
      'Помогаем понять потенциал бизнеса, выбираем приоритеты и формируем долгосрочный план развития.',
    services: [
      'Долгосрочная и продуктовая стратегия',
      'Диверсификация и проверка гипотез роста',
      'Финансовое и операционное моделирование',
      'Организация процессов управления изменениями',
    ],
  },
  {
    title: 'Цифровая трансформация',
    description:
      'Внедряем технологии, которые масштабируют бизнес-процессы и улучшают клиентский опыт.',
    services: [
      'Оценка цифровой зрелости и дорожные карты',
      'Построение архитектуры и внедрение платформ',
      'Интеграция аналитики и данных в процессы',
      'Автоматизация и сценарии роботизации (RPA)',
    ],
  },
  {
    title: 'Маркетинг и бренд',
    description:
      'Выстраиваем последовательную коммуникацию и сильный бренд-опыт на каждом этапе пути клиента.',
    services: [
      'Позиционирование и платформа бренда',
      'Разработка цифровых каналов и контент-стратегий',
      'Маркетинговая аналитика и измерение эффективности',
      'Customer journey, дизайн сервисов и продуктов',
    ],
  },
  {
    title: 'Операционная эффективность',
    description:
      'Оптимизируем процессы, сокращаем издержки и создаем ключевые метрики для контроля и роста.',
    services: [
      'Диагностика процессов и CX-аудит',
      'Управление цепочкой поставок и логистикой',
      'Lean/Six Sigma, Agile-подходы, OKR',
      'Внедрение систем управления знаниями и обучением',
    ],
  },
];

const benefits = [
  {
    title: 'Сборка команды под задачу',
    text: 'Формируем проектную команду из экспертов разных направлений. На каждом этапе отвечает человек с релевантным опытом.',
  },
  {
    title: 'Цифровые инструменты контроля',
    text: 'Используем единый проектный офис, прозрачные дашборды и регулярные отчеты — вы видите прогресс в реальном времени.',
  },
  {
    title: 'Обучение и поддержка',
    text: 'Передаем компетенции вашей команде, обучаем и остаемся рядом до устойчивого результата.',
  },
];

const formats = [
  {
    name: 'Экспресс-диагностика',
    details: 'Формат до 3 недель, точечный анализ, быстрые рекомендации и план дальнейших шагов.',
  },
  {
    name: 'Проектное сопровождение',
    details: 'Полный цикл от исследования до внедрения решений, выделенная команда и проектный офис.',
  },
  {
    name: 'Аутсорсинг функций',
    details: 'Передача операционных процессов или определенной функции нашей команде с SLA и KPI.',
  },
  {
    name: 'Корпоративные программы',
    details: 'Обучение, воркшопы, программа повышения зрелости и создание внутренних культурных изменений.',
  },
];

function ServicesPage() {
  return (
    <>
      <Meta
        title="Услуги — Стратегия, технологии, маркетинг и операционное развитие"
        description="Компания предлагает стратегическое планирование, цифровую трансформацию, маркетинг и операционную эффективность. Узнайте, какие задачи мы решаем."
      />

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Сервисы</span>
            <h1>Комплексная поддержка бизнеса на всех этапах роста</h1>
            <p>
              Мы берем на себя задачи от аналитики и проектирования до внедрения и управления изменениями.
              Формируем команды под ваши вызовы и сопровождаем до достижения результата.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.servicesList}>
        <div className="container">
          <div className={styles.servicesGrid}>
            {serviceGroups.map((group) => (
              <article key={group.title} className={styles.serviceGroup}>
                <h2>{group.title}</h2>
                <p>{group.description}</p>
                <ul>
                  {group.services.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Преимущества</span>
            <h2>Что получает ваш бизнес</h2>
          </div>
          <div className={styles.benefitsGrid}>
            {benefits.map((benefit) => (
              <article key={benefit.title} className={styles.benefitCard}>
                <h3>{benefit.title}</h3>
                <p>{benefit.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.formats}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Форматы работы</span>
            <h2>Выбирайте удобный формат сотрудничества</h2>
          </div>
          <div className={styles.formatGrid}>
            {formats.map((format) => (
              <article key={format.name} className={styles.formatCard}>
                <h3>{format.name}</h3>
                <p>{format.details}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaBox}>
            <h2>Нужна консультация по конкретной задаче?</h2>
            <p>
              Свяжитесь с нами — подготовим предложение, формат проекта и расскажем, какие команды подключим к задаче.
            </p>
            <a href="mailto:info@kompaniya.ru" className={styles.ctaButton}>
              Написать на info@kompaniya.ru
            </a>
          </div>
        </div>
      </section>
    </>
  );
}

export default ServicesPage;