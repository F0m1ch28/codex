import React from 'react';
import { useParams, Link } from 'react-router-dom';
import Meta from '../components/Meta';
import styles from './ArticlePlaceholder.module.css';

function ArticlePlaceholder() {
  const { slug } = useParams();
  const formattedTitle = slug
    .split('-')
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');

  return (
    <>
      <Meta
        title={`${formattedTitle} — Новости компании`}
        description="Материал находится в подготовке. Скоро мы поделимся подробной информацией."
      />
      <section className={styles.wrapper}>
        <div className="container">
          <div className={styles.card}>
            <span className="tag">Материал скоро появится</span>
            <h1>{formattedTitle}</h1>
            <p>
              Мы готовим подробный материал по этой теме. Чтобы не пропустить обновление, заглядывайте позже или напишите нам —
              мы поделимся новостями первыми.
            </p>
            <Link to="/" className={styles.button}>
              Вернуться на главную
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

export default ArticlePlaceholder;