import React, { useState } from 'react';
import Meta from '../components/Meta';
import styles from './Contact.module.css';

function ContactsPage() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateEmail = (email) => /\S+@\S+\.\S+/.test(email);

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setStatus({ type: 'error', message: 'Пожалуйста, заполните все обязательные поля.' });
      return;
    }
    if (!validateEmail(formData.email)) {
      setStatus({ type: 'error', message: 'Проверьте корректность адреса электронной почты.' });
      return;
    }

    setStatus({ type: 'success', message: 'Спасибо! Мы получили ваше сообщение и скоро свяжемся.' });
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <>
      <Meta
        title="Контакты — Свяжитесь с командой Компания"
        description="Свяжитесь с командой Компания: Москва, ул. Примерная, д. 1. Телефон +7 (495) 123-45-67, email info@kompaniya.ru."
      />

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Контакты</span>
            <h1>Давайте обсудим вашу задачу</h1>
            <p>
              Заполните форму или напишите нам напрямую — подготовим ответ, подходящий формат и команду под ваш запрос.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.infoCard}>
              <h2>Связаться с нами</h2>
              <ul className={styles.contactList}>
                <li>
                  <strong>Адрес:</strong>
                  <span>г. Москва, ул. Примерная, д. 1</span>
                </li>
                <li>
                  <strong>Телефон:</strong>
                  <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </li>
                <li>
                  <strong>Email:</strong>
                  <a href="mailto:info@kompaniya.ru">info@kompaniya.ru</a>
                </li>
              </ul>
              <div className={styles.mapWrapper}>
                <iframe
                  title="Офис Компания"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.2845299399453!2d37.62039347686714!3d55.75393067304388!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46b54a5a7cba4adb%3A0x63e8b54915a43b44!2z0JzQvtGB0LrQstCw0YAg0KDQtdC80YbQuNC-0L0!5e0!3m2!1sru!2sru!4v1680978941000!5m2!1sru!2sru"
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>

            <div className={styles.formCard}>
              <h2>Напишите нам</h2>
              <p>Мы ответим в течение одного рабочего дня.</p>
              <form onSubmit={handleSubmit} className={styles.form}>
                <label htmlFor="name">
                  Имя*
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Ваше имя"
                    required
                  />
                </label>
                <label htmlFor="email">
                  Email*
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="name@example.com"
                    required
                  />
                </label>
                <label htmlFor="message">
                  Сообщение*
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Опишите задачу или вопрос"
                    required
                  />
                </label>
                {status.message && (
                  <div
                    className={`${styles.status} ${
                      status.type === 'success' ? styles.success : styles.error
                    }`}
                    role="alert"
                  >
                    {status.message}
                  </div>
                )}
                <button type="submit" className={styles.submitButton}>
                  Отправить сообщение
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default ContactsPage;