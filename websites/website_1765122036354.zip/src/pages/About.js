import React from 'react';
import Meta from '../components/Meta';
import styles from './About.module.css';

function AboutPage() {
  return (
    <>
      <Meta
        title="О компании — Команда экспертов, которая помогает бизнесу расти"
        description="Компания объединяет стратегов, аналитиков и технологов, чтобы создавать устойчивые решения. Узнайте о миссии, ценностях и подходе команды."
      />

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">О нас</span>
            <h1>Мы создаем среды, в которых бизнес растёт уверенно</h1>
            <p>
              Компания — мультидисциплинарная команда стратегов, технологов, исследователей и проджект-менеджеров.
              Мы работаем с компаниями, которые стремятся к устойчивому развитию, гибкости и прозрачности.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.doubleGrid}>
            <div className={styles.card}>
              <h2>Наша миссия</h2>
              <p>
                Помогать компаниям находить и воплощать идеи, которые делают их продукт и сервис ценнее для клиентов.
                Мы верим, что сильные коммуникации и цифровые инструменты должны работать на общую цель — устойчивость бизнеса.
              </p>
            </div>
            <div className={styles.card}>
              <h2>Ценности команды</h2>
              <ul>
                <li><strong>Ответственность:</strong> фиксируем обязательства и выполняем их без компромиссов.</li>
                <li><strong>Открытость:</strong> делимся знаниями, поддерживаем честный диалог и прозрачность процессов.</li>
                <li><strong>Партнерство:</strong> движемся вместе с клиентом и делим результат.</li>
                <li><strong>Развитие:</strong> постоянно учимся, экспериментируем и находим новые решения.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.story}>
        <div className="container">
          <div className={styles.timeline}>
            <div className={styles.timelineItem}>
              <span className={styles.year}>2009</span>
              <div>
                <h3>Начало пути</h3>
                <p>Сфокусировались на стратегическом консалтинге и поддержке компаний в период изменений.</p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.year}>2014</span>
              <div>
                <h3>Расширение экспертизы</h3>
                <p>Добавили цифровую трансформацию и клиентский опыт, сформировали первую технологическую команду.</p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.year}>2018</span>
              <div>
                <h3>Международные проекты</h3>
                <p>Вышли на новые рынки, создали партнерскую сеть и выстроили процессы дистанционной работы.</p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.year}>2023</span>
              <div>
                <h3>Синергия возможностей</h3>
                <p>Собрали продуктовую, исследовательскую и маркетинговую команды для комплексных проектов.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamCulture}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Команда и культура</span>
            <h2>Создаем среду, где рождаются сильные решения</h2>
            <p>
              Мы строим культуру обмена знаниями и честного диалога. Регулярно проводим внутренние воркшопы, изучаем новые методологии,
              поддерживаем инициативы команды и внедряем инструменты, которые делают работу осмысленной и удобной.
            </p>
          </div>

          <div className={styles.valuesGrid}>
            <article className={styles.valueCard}>
              <h3>Обучение без пауз</h3>
              <p>Каждый месяц проводим внутренние экспертизы, разборы кейсов и обмен практиками между командами.</p>
            </article>
            <article className={styles.valueCard}>
              <h3>Ответственность за результат</h3>
              <p>Каждый проект сопровождает выделенный лидер — он контролирует сроки, качество и коммуникацию.</p>
            </article>
            <article className={styles.valueCard}>
              <h3>Прозрачность</h3>
              <p>Все решения, показатели и изменения доступны команде. Клиенты видят прогресс в реальном времени.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.teamGallery}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="tag">Эксперты</span>
            <h2>Лидеры практик компании</h2>
          </div>
          <div className={styles.leadersGrid}>
            {[
              {
                name: 'Алексей Кравцов',
                role: 'Управляющий партнер',
                bio: 'Отвечает за стратегию и развитие бизнеса клиентов, наставляет партнеров и курирует ключевые проекты.',
                image: 'https://picsum.photos/420/420?random=51',
              },
              {
                name: 'Юлия Назарова',
                role: 'Руководитель исследовательской практики',
                bio: 'Разрабатывает сценарии исследований, помогает клиентам принимать решения на основе данных и инсайтов.',
                image: 'https://picsum.photos/420/420?random=52',
              },
              {
                name: 'Руслан Бекетов',
                role: 'Директор по технологическим решениям',
                bio: 'Руководит внедрением цифровых инструментов, отвечает за архитектуру решений и безопасность данных.',
                image: 'https://picsum.photos/420/420?random=53',
              },
            ].map((leader) => (
              <article key={leader.name} className={styles.leaderCard}>
                <img src={leader.image} alt={leader.name} loading="lazy" />
                <h3>{leader.name}</h3>
                <span>{leader.role}</span>
                <p>{leader.bio}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.commitments}>
        <div className="container">
          <div className={styles.commitmentsCard}>
            <h2>Что мы обещаем партнерам</h2>
            <ul>
              <li><strong>Обоснованность решений.</strong> Каждая рекомендация подтверждается данными и практикой.</li>
              <li><strong>Инклюзивность.</strong> Мы создаем команды, где слышат и учитывают разные точки зрения.</li>
              <li><strong>Устойчивость.</strong> Смотрим на долгосрочный эффект и помогаем укрепить внутреннюю экспертизу клиента.</li>
              <li><strong>Инновации.</strong> Тестируем новые подходы, создаем пилоты, масштабируем успешные практики.</li>
            </ul>
          </div>
        </div>
      </section>
    </>
  );
}

export default AboutPage;