document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.getElementById("primary-navigation");

    if (navToggle && nav) {
        navToggle.addEventListener("click", function () {
            const isOpen = nav.classList.toggle("is-open");
            navToggle.setAttribute("aria-expanded", isOpen);
        });

        nav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                nav.classList.remove("is-open");
                navToggle.setAttribute("aria-expanded", false);
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const acceptBtn = document.getElementById("cookie-accept");
    const declineBtn = document.getElementById("cookie-decline");
    const consentKey = "livingoCookieConsent";

    if (cookieBanner) {
        const existingConsent = localStorage.getItem(consentKey);
        if (!existingConsent) {
            cookieBanner.classList.add("show");
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => {
                localStorage.setItem(consentKey, "accepted");
                cookieBanner.classList.remove("show");
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", () => {
                localStorage.setItem(consentKey, "declined");
                cookieBanner.classList.remove("show");
            });
        }
    }
});