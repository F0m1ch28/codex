document.addEventListener("DOMContentLoaded", function () {
    const header = document.querySelector(".site-header");
    const navToggle = document.querySelector(".nav-toggle");
    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieButtons = document.querySelectorAll(".cookie-btn");
    const storedConsent = localStorage.getItem("bgiCookieConsent");

    if (navToggle) {
        navToggle.addEventListener("click", () => {
            header.classList.toggle("nav-open");
            navToggle.setAttribute("aria-expanded", header.classList.contains("nav-open"));
        });

        document.addEventListener("click", (event) => {
            if (!header.contains(event.target)) {
                header.classList.remove("nav-open");
                navToggle.setAttribute("aria-expanded", "false");
            }
        });
    }

    if (cookieBanner && storedConsent) {
        cookieBanner.classList.add("hidden");
    }

    if (cookieBanner && cookieButtons.length) {
        cookieButtons.forEach((button) => {
            button.addEventListener("click", (event) => {
                const consentChoice = event.currentTarget.dataset.consent;
                localStorage.setItem("bgiCookieConsent", consentChoice);
                cookieBanner.classList.add("hidden");
                event.preventDefault();
                const targetUrl = event.currentTarget.getAttribute("href");
                setTimeout(() => {
                    window.location.href = targetUrl;
                }, 120);
            });
        });
    }

    const searchInput = document.querySelector("#search-input");
    const topicCheckboxes = document.querySelectorAll(".filter-chip input[type='checkbox']");
    const articleCards = document.querySelectorAll(".article-card");

    function filterArticles() {
        if (!articleCards.length) {
            return;
        }
        const query = searchInput ? searchInput.value.trim().toLowerCase() : "";
        const selectedTopics = Array.from(topicCheckboxes)
            .filter((checkbox) => checkbox.checked)
            .map((checkbox) => checkbox.value);

        articleCards.forEach((card) => {
            const title = card.querySelector("h2")?.textContent.toLowerCase() || "";
            const excerpt = card.querySelector("p")?.textContent.toLowerCase() || "";
            const topics = (card.dataset.topics || "").split(",");

            const matchesQuery = !query || title.includes(query) || excerpt.includes(query);
            const matchesTopic =
                !selectedTopics.length || selectedTopics.some((topic) => topics.includes(topic));
            const shouldShow = matchesQuery && matchesTopic;

            card.style.display = shouldShow ? "" : "none";
        });
    }

    if (searchInput) {
        searchInput.addEventListener("input", filterArticles);
    }

    if (topicCheckboxes.length) {
        topicCheckboxes.forEach((checkbox) => {
            checkbox.addEventListener("change", filterArticles);
        });
    }
});