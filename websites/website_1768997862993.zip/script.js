document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            primaryNav.classList.toggle('is-open');
        });
        primaryNav.querySelectorAll('a').forEach((link) => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 980) {
                    primaryNav.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const banner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-accept');
    const declineBtn = document.querySelector('.cookie-decline');
    const consentKey = 'northlyxCookieConsent';

    if (banner) {
        const savedConsent = localStorage.getItem(consentKey);
        if (!savedConsent) {
            banner.classList.add('active');
        }
        const setConsent = (value) => {
            localStorage.setItem(consentKey, value);
            banner.classList.remove('active');
        };
        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => setConsent('accepted'));
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', () => setConsent('declined'));
        }
    }

    const path = window.location.pathname.replace(/\/+$/, '').toLowerCase();
    const redirects = {
        '/history': 'archives.html',
        '/infrastructure': 'maps.html',
        '/systems': 'signals.html',
        '/resilience': 'contexts.html'
    };
    if (redirects[path]) {
        window.location.replace(redirects[path]);
    }

    const canvas = document.getElementById('signalCanvas');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        const resizeCanvas = () => {
            canvas.width = canvas.clientWidth;
            canvas.height = canvas.clientHeight;
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        let pulse = 0;
        const emitters = Array.from({ length: 8 }, () => ({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            speed: 0.4 + Math.random() * 0.8,
            hue: 170 + Math.random() * 120
        }));

        const draw = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = 'rgba(7, 11, 20, 0.8)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            ctx.strokeStyle = 'rgba(56, 189, 248, 0.2)';
            ctx.lineWidth = 1;
            for (let r = 60; r < Math.max(canvas.width, canvas.height); r += 60) {
                ctx.beginPath();
                ctx.arc(canvas.width / 2, canvas.height / 2, r, 0, Math.PI * 2);
                ctx.stroke();
            }

            for (let i = 0; i < emitters.length; i++) {
                const emitter = emitters[i];
                const radius = (pulse * emitter.speed) % Math.max(canvas.width, canvas.height);
                const gradient = ctx.createRadialGradient(emitter.x, emitter.y, radius * 0.2, emitter.x, emitter.y, radius);
                gradient.addColorStop(0, `hsla(${emitter.hue}, 80%, 60%, 0.35)`);
                gradient.addColorStop(1, `hsla(${emitter.hue}, 80%, 60%, 0)`);
                ctx.beginPath();
                ctx.fillStyle = gradient;
                ctx.arc(emitter.x, emitter.y, radius, 0, Math.PI * 2);
                ctx.fill();

                ctx.beginPath();
                ctx.fillStyle = `hsla(${emitter.hue}, 80%, 60%, 0.9)`;
                ctx.arc(emitter.x, emitter.y, 4, 0, Math.PI * 2);
                ctx.fill();
            }

            pulse += 1.2;
            requestAnimationFrame(draw);
        };
        draw();
    }
});