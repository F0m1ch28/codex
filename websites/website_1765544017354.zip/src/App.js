import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import ScrollToTopButton from './components/ScrollToTopButton';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage from './pages/Services';
import ShopPage from './pages/Shop';
import ProductDetailPage from './pages/ProductDetail';
import BlogPage from './pages/Blog';
import BlogArticlePage from './pages/BlogArticle';
import ContactPage from './pages/Contact';
import TermsOfServicePage from './pages/Terms';
import PrivacyPolicyPage from './pages/Privacy';
import CookiePolicyPage from './pages/CookiePolicy';

const NotFoundPage = () => (
  <div className="not-found page-wrapper">
    <div className="page-container">
      <h1>Page Not Found</h1>
      <p>
        The page you are looking for can’t be found. Please use the navigation above to explore Imagination Unleashed.
      </p>
    </div>
  </div>
);

function App() {
  return (
    <div className="app-shell">
      <Header />
      <ScrollToTop />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/shop" element={<ShopPage />} />
          <Route path="/shop/:productId" element={<ProductDetailPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/blog/:articleSlug" element={<BlogArticlePage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/terms" element={<TermsOfServicePage />} />
          <Route path="/privacy" element={<PrivacyPolicyPage />} />
          <Route path="/cookie-policy" element={<CookiePolicyPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;