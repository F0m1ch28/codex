import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.brand}>
        <h2>Imagination Unleashed</h2>
        <p>
          Premium quality toys that encourage creativity, resilience, and joyful play. Shipping across the Netherlands from our Amsterdam hub.
        </p>
        <div className={styles.social}>
          <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
            <span aria-hidden="true">📘</span>
          </a>
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
            <span aria-hidden="true">📸</span>
          </a>
          <a href="https://www.pinterest.com" target="_blank" rel="noopener noreferrer" aria-label="Pinterest">
            <span aria-hidden="true">📌</span>
          </a>
        </div>
      </div>
      <div className={styles.column}>
        <h3>Quick Links</h3>
        <ul>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/shop">Shop</Link></li>
          <li><Link to="/services">Services</Link></li>
          <li><Link to="/blog">Imagination Corner</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3>Support</h3>
        <ul>
          <li><Link to="/about">About Us</Link></li>
          <li><Link to="/contact">Contact</Link></li>
          <li><Link to="/terms">Terms of Service</Link></li>
          <li><Link to="/privacy">Privacy Policy</Link></li>
          <li><Link to="/cookie-policy">Cookie Policy</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3>Contact</h3>
        <p>Toy Street 123<br />1011 AA Amsterdam<br />Netherlands</p>
        <p>Phone: +31 20 123 4567<br />Email: info@imaginationplaystore.nl</p>
      </div>
    </div>
    <div className={styles.copy}>
      © {new Date().getFullYear()} Imagination Unleashed. All rights reserved.
    </div>
  </footer>
);

export default Footer;