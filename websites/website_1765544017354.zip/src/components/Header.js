import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleToggle = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className={styles.header} aria-label="Main navigation">
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} onClick={closeMenu} aria-label="Imagination Unleashed Home">
          <span className={styles.logoAccent}>Imagination</span>
          <span>Unleashed</span>
        </Link>
        <button
          className={styles.menuToggle}
          onClick={handleToggle}
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
          aria-label={isMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          id="primary-navigation"
          className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`}
        >
          <NavLink to="/" end className={({ isActive }) => (isActive ? styles.activeLink : '')} onClick={closeMenu}>
            Home
          </NavLink>
          <NavLink to="/shop" className={({ isActive }) => (isActive ? styles.activeLink : '')} onClick={closeMenu}>
            Shop
          </NavLink>
          <NavLink to="/services" className={({ isActive }) => (isActive ? styles.activeLink : '')} onClick={closeMenu}>
            Services
          </NavLink>
          <NavLink to="/blog" className={({ isActive }) => (isActive ? styles.activeLink : '')} onClick={closeMenu}>
            Blog
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => (isActive ? styles.activeLink : '')} onClick={closeMenu}>
            About
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => (isActive ? styles.activeLink : '')} onClick={closeMenu}>
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;