import React from 'react';
import { Link, useParams } from 'react-router-dom';
import styles from './BlogArticle.module.css';
import usePageMetadata from '../hooks/usePageMetadata';
import { blogPosts } from '../data/blogPosts';

const BlogArticlePage = () => {
  const { articleSlug } = useParams();
  const article = blogPosts.find((post) => post.slug === articleSlug);

  usePageMetadata({
    title: article ? article.title : 'Article Not Found',
    description: article ? article.summary : 'Article not found in Imagination Corner.'
  });

  if (!article) {
    return (
      <div className={styles.notFound}>
        <h1>Article Not Found</h1>
        <p>
          This story is no longer available. Return to the <Link to="/blog">Imagination Corner</Link> for more inspiration.
        </p>
      </div>
    );
  }

  return (
    <article className={styles.page}>
      <header className={styles.header}>
        <span className={styles.meta}>
          {new Date(article.date).toLocaleDateString('en-NL', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          })}{' '}
          • {article.author}
        </span>
        <h1>{article.title}</h1>
        <div className={styles.tags}>
          {article.tags.map((tag) => (
            <span key={tag}>{tag}</span>
          ))}
        </div>
      </header>
      <div className={styles.hero}>
        <img src={article.heroImage} alt={article.title} />
      </div>
      <div className={styles.content}>
        {article.sections.map((section) => (
          <section key={section.heading}>
            <h2>{section.heading}</h2>
            <p>{section.body}</p>
          </section>
        ))}
      </div>
      <footer className={styles.footer}>
        <Link to="/blog">← Back to Imagination Corner</Link>
      </footer>
    </article>
  );
};

export default BlogArticlePage;