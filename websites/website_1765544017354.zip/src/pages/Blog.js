import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Blog.module.css';
import usePageMetadata from '../hooks/usePageMetadata';
import { blogPosts } from '../data/blogPosts';

const BlogPage = () => {
  usePageMetadata({
    title: 'Imagination Corner Blog',
    description:
      'Explore Imagination Unleashed blog articles with parenting tips, learning through play ideas, and inspiration for Dutch families.'
  });

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>Imagination Corner: Tips &amp; Stories</h1>
        <p>
          Dive into play prompts, safety checklists, and inspiring stories from families across the Netherlands. These articles are crafted by educators, parents, and play experts.
        </p>
      </header>
      <div className={styles.grid}>
        {blogPosts.map((post) => (
          <article key={post.slug} className={styles.card}>
            <img src={post.heroImage} alt={post.title} loading="lazy" />
            <div className={styles.cardBody}>
              <span className={styles.date}>
                {new Date(post.date).toLocaleDateString('en-NL', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </span>
              <h2>{post.title}</h2>
              <p>{post.summary}</p>
              <div className={styles.tags}>
                {post.tags.map((tag) => (
                  <span key={tag}>{tag}</span>
                ))}
              </div>
              <Link to={`/blog/${post.slug}`} className={styles.link}>
                Read More
              </Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default BlogPage;