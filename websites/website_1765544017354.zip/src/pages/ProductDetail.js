import React, { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import styles from './ProductDetail.module.css';
import { products } from '../data/products';
import usePageMetadata from '../hooks/usePageMetadata';

const ProductDetailPage = () => {
  const { productId } = useParams();
  const product = products.find((item) => item.slug === productId);
  const [activeImage, setActiveImage] = useState(product ? product.gallery[0] : '');

  usePageMetadata({
    title: product ? product.name : 'Toy Not Found',
    description: product
      ? product.shortDescription
      : 'The toy you are looking for could not be found in the Imagination Unleashed catalogue.'
  });

  if (!product) {
    return (
      <div className={styles.notFound}>
        <h1>Toy Not Found</h1>
        <p>
          We could not find the toy you were searching for. Explore our <Link to="/shop">toy collection</Link> for more play inspiration.
        </p>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <section className={styles.gallery}>
        <div className={styles.mainImage}>
          <img src={activeImage} alt={product.name} />
        </div>
        <div className={styles.thumbnails}>
          {product.gallery.map((image) => (
            <button
              key={image}
              type="button"
              onClick={() => setActiveImage(image)}
              className={activeImage === image ? styles.activeThumb : ''}
              aria-label={`View ${product.name}`}
            >
              <img src={image} alt={`${product.name} alternate view`} />
            </button>
          ))}
        </div>
      </section>

      <section className={styles.info}>
        <p className={styles.category}>{product.category}</p>
        <h1>{product.name}</h1>
        <p className={styles.description}>{product.description}</p>
        <div className={styles.meta}>
          <span>Recommended age: {product.ageRangeLabel}</span>
          <span>Tags: {product.tags.join(', ')}</span>
        </div>

        <div className={styles.detailGroup}>
          <h2>What’s Inside</h2>
          <ul>
            {product.features.map((feature) => (
              <li key={feature}>{feature}</li>
            ))}
          </ul>
        </div>

        <div className={styles.detailGroup}>
          <h2>Developmental Benefits</h2>
          <ul>
            {product.developmentalBenefits.map((benefit) => (
              <li key={benefit}>{benefit}</li>
            ))}
          </ul>
        </div>

        <div className={styles.detailGrid}>
          <article>
            <h3>Materials</h3>
            <p>{product.materials}</p>
          </article>
          <article>
            <h3>Safety</h3>
            <p>{product.safety}</p>
          </article>
          <article>
            <h3>Care</h3>
            <p>{product.careInstructions}</p>
          </article>
        </div>

        <Link to="/contact" className={styles.inquireButton}>
          Inquire About This Toy
        </Link>
      </section>
    </div>
  );
};

export default ProductDetailPage;