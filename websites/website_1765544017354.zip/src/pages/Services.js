import React from 'react';
import styles from './Services.module.css';
import usePageMetadata from '../hooks/usePageMetadata';

const services = [
  {
    title: 'Toy Match Consultation',
    description:
      'Share your child’s interests and we will curate a personalised shortlist of toys that fits their age, developmental stage, and your family’s values.',
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Playroom Styling',
    description:
      'From small Amsterdam flats to family homes in Eindhoven, we plan versatile play zones with storage, displays, and toy rotations that keep children engaged.',
    image: 'https://images.unsplash.com/photo-1523419409543-0c1df022bddb?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'School & Daycare Partnerships',
    description:
      'We collaborate with Dutch schools and childcare centres to create resource libraries, STEM corners, and sensory spaces that enrich learning.',
    image: 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?auto=format&fit=crop&w=1200&q=80'
  }
];

const ServicesPage = () => {
  usePageMetadata({
    title: 'Toy Services',
    description:
      'Discover bespoke services from Imagination Unleashed including toy consultations, playroom styling, and partnerships for schools across the Netherlands.'
  });

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>Services to Support Joyful Play</h1>
        <p>
          Beyond our online shop, we offer bespoke services that empower families, educators, and childcare providers to redesign play in meaningful ways across the Netherlands.
        </p>
      </header>
      <div className={styles.serviceGrid}>
        {services.map((service) => (
          <article key={service.title} className={styles.card}>
            <img src={service.image} alt={service.title} loading="lazy" />
            <div className={styles.cardBody}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default ServicesPage;