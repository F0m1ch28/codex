import React, { useState } from 'react';
import styles from './Contact.module.css';
import usePageMetadata from '../hooks/usePageMetadata';

const ContactPage = () => {
  usePageMetadata({
    title: 'Contact Imagination Unleashed',
    description:
      'Reach out to Imagination Unleashed for toy inquiries, partnerships, or play consultations. Based in Amsterdam and shipping across the Netherlands.'
  });

  const [formStatus, setFormStatus] = useState(null);

  const handleSubmit = (event) => {
    event.preventDefault();
    setFormStatus('Thank you! We will get back to you within two working days.');
    event.target.reset();
  };

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>Get in Touch</h1>
        <p>
          Ask about a toy, request a personalised consultation, or collaborate with us. We are excited to help your family or organisation spark joyful play.
        </p>
      </header>
      <div className={styles.grid}>
        <section className={styles.details}>
          <h2>Contact Information</h2>
          <div className={styles.detailGroup}>
            <h3>Address</h3>
            <p>Toy Street 123<br />1011 AA Amsterdam<br />Netherlands</p>
          </div>
          <div className={styles.detailGroup}>
            <h3>Phone</h3>
            <p>+31 20 123 4567</p>
          </div>
          <div className={styles.detailGroup}>
            <h3>Email</h3>
            <p>info@imaginationplaystore.nl</p>
          </div>
          <div className={styles.detailGroup}>
            <h3>Opening Hours</h3>
            <p>Monday – Friday: 09:00 – 17:00 CET<br />Saturday: 10:00 – 14:00 CET</p>
          </div>
        </section>
        <section className={styles.formSection}>
          <h2>Send a Message</h2>
          <form onSubmit={handleSubmit} className={styles.form}>
            <label htmlFor="name">Name</label>
            <input id="name" name="name" type="text" required placeholder="Your name" />
            <label htmlFor="email">Email</label>
            <input id="email" name="email" type="email" required placeholder="you@example.com" />
            <label htmlFor="subject">Subject</label>
            <input id="subject" name="subject" type="text" required placeholder="Subject" />
            <label htmlFor="message">Message</label>
            <textarea id="message" name="message" rows="5" required placeholder="How can we help you?" />
            <button type="submit">Send Message</button>
            {formStatus && <p className={styles.formStatus}>{formStatus}</p>}
          </form>
        </section>
      </div>
      <section className={styles.mapSection} aria-label="Location map">
        <iframe
          title="Imagination Unleashed location in Amsterdam"
          src="https://www.openstreetmap.org/export/embed.html?bbox=4.8926%2C52.3702%2C4.9026%2C52.3752&layer=mapnik&marker=52.3727%2C4.8976"
          loading="lazy"
        />
      </section>
    </div>
  );
};

export default ContactPage;