import React from 'react';
import styles from './About.module.css';
import usePageMetadata from '../hooks/usePageMetadata';

const AboutPage = () => {
  usePageMetadata({
    title: 'About Imagination Unleashed',
    description:
      'Learn about Imagination Unleashed, our mission to nurture creativity through safe, premium toys, and the team curating joyful play across the Netherlands.'
  });

  const values = [
    {
      title: 'Purposeful Play',
      description:
        'Every toy is chosen for its ability to nurture curiosity, emotional resilience, and collaborative skills.'
    },
    {
      title: 'Safety First',
      description:
        'We partner with brands that meet or exceed EU standards, ensuring peace of mind for Dutch families.'
    },
    {
      title: 'Planet-Friendly',
      description:
        'From recyclable packaging to long-lasting materials, sustainability guides each decision we make.'
    }
  ];

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroText}>
          <h1>Rooted in Play, Guided by Heart</h1>
          <p>
            Imagination Unleashed began in Amsterdam with a dream: to give every child in the Netherlands access to toys that celebrate creativity, kindness, and courage. Our founders, Eva and Ravi, met while co-leading a neighbourhood playgroup and saw an opportunity to champion toys that inspire open-ended exploration.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80"
            alt="Team of educators selecting toys together"
          />
        </div>
      </section>

      <section className={styles.mission}>
        <h2>Our Mission</h2>
        <p>
          To curate premium, safe, and inclusive toys that enrich playtime, celebrate Dutch culture, and build bridges between families. Every product is tested by educators, parents, and children before it arrives at your door.
        </p>
      </section>

      <section className={styles.values}>
        <h2>The Values That Guide Us</h2>
        <div className={styles.valueGrid}>
          {values.map((value) => (
            <article key={value.title}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.journey}>
        <div className={styles.journeyContent}>
          <h2>From Local Playgroup to Nationwide Delivery</h2>
          <p>
            Our journey started with weekend pop-ups in Amsterdam’s Jordaan district. Word spread quickly, and soon families from Utrecht, Eindhoven, and Groningen asked for our toy recommendations. Today we deliver to every province, but we still maintain that community spirit—listening closely to what children love and what parents need.
          </p>
          <p>
            We believe in co-creating with families. Share your playtime stories and you might find them featured in our Imagination Corner blog to inspire others across the Netherlands.
          </p>
        </div>
        <img
          src="https://images.unsplash.com/photo-1471286174890-9c112ffca5b4?auto=format&fit=crop&w=1200&q=80"
          alt="Child playing with colourful educational toys"
        />
      </section>
    </div>
  );
};

export default AboutPage;