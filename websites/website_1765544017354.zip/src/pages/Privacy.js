import React from 'react';
import styles from './Legal.module.css';
import usePageMetadata from '../hooks/usePageMetadata';

const PrivacyPolicyPage = () => {
  usePageMetadata({
    title: 'Privacy Policy',
    description:
      'Imagination Unleashed privacy policy detailing how we collect, store, and protect personal data for customers in the Netherlands.'
  });

  return (
    <div className={styles.page}>
      <h1>Privacy Policy</h1>
      <p>Last updated: January 2024</p>
      <p>
        Imagination Unleashed respects your privacy and is committed to protecting your personal data. This policy explains what information we collect, how we use it, and your rights under the General Data Protection Regulation (GDPR).
      </p>

      <h2>1. Data We Collect</h2>
      <p>
        We collect personal details you provide voluntarily, such as name, email address, delivery address, and any information submitted through our contact forms or newsletter sign-up.
      </p>

      <h2>2. How We Use Data</h2>
      <p>
        We use your data to respond to enquiries, fulfil toy consultations, process orders, and send updates when you opt-in. We do not sell or share your data with third parties except trusted service providers who support our operations.
      </p>

      <h2>3. Data Security</h2>
      <p>
        We implement appropriate technical and organisational measures to secure personal data against unauthorised access, alteration, or disclosure.
      </p>

      <h2>4. Your Rights</h2>
      <p>
        You have the right to access, correct, or delete your personal data. Please email info@imaginationplaystore.nl to submit a request. We will respond within 30 days.
      </p>

      <h2>5. Cookies</h2>
      <p>
        We use cookies to enhance browsing and analyse site traffic. You may manage cookie preferences via your browser settings. For more information read our Cookie Policy.
      </p>

      <h2>6. Contact</h2>
      <p>
        If you have questions about this policy, contact our Data Protection Lead at info@imaginationplaystore.nl.
      </p>
    </div>
  );
};

export default PrivacyPolicyPage;