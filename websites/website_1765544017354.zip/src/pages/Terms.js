import React from 'react';
import styles from './Legal.module.css';
import usePageMetadata from '../hooks/usePageMetadata';

const TermsOfServicePage = () => {
  usePageMetadata({
    title: 'Terms of Service',
    description:
      'Read the Imagination Unleashed terms of service outlining conditions for using our website and purchasing toys in the Netherlands.'
  });

  return (
    <div className={styles.page}>
      <h1>Terms of Service</h1>
      <p>Last updated: January 2024</p>
      <p>
        Welcome to Imagination Unleashed. These Terms of Service govern your use of our website www.imaginationplaystore.nl and all related services we provide to families and organisations across the Netherlands.
      </p>

      <h2>1. Acceptance of Terms</h2>
      <p>
        By accessing or using our site, you agree to these Terms and to comply with all applicable Dutch and EU regulations. If you do not agree, please discontinue use of the site.
      </p>

      <h2>2. Services</h2>
      <p>
        Imagination Unleashed provides curated toy recommendations, online content, and playroom consultancy services. We reserve the right to modify or discontinue any aspect of our services at any time with reasonable notice.
      </p>

      <h2>3. Intellectual Property</h2>
      <p>
        All content, including text, images, and graphics, is owned or licensed by Imagination Unleashed and protected under Dutch copyright law. You may not reproduce or reuse our materials without written permission.
      </p>

      <h2>4. User Conduct</h2>
      <p>
        You agree not to use the site for unlawful purposes, to attempt to gain unauthorised access to our systems, or to interfere with the experience of other users.
      </p>

      <h2>5. Liability</h2>
      <p>
        We take great care to ensure the accuracy of information on our site. However, Imagination Unleashed is not liable for indirect or consequential losses arising from the use of our website.
      </p>

      <h2>6. Governing Law</h2>
      <p>
        These Terms are governed by the laws of the Netherlands. Any disputes shall be handled by the competent courts in Amsterdam.
      </p>

      <h2>7. Contact</h2>
      <p>
        For questions about these Terms, please email info@imaginationplaystore.nl.
      </p>
    </div>
  );
};

export default TermsOfServicePage;