import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';
import usePageMetadata from '../hooks/usePageMetadata';
import { products } from '../data/products';
import { blogPosts } from '../data/blogPosts';

const HomePage = () => {
  usePageMetadata({
    title: 'Premium Quality Toys for Kids',
    description:
      'Imagination Unleashed curates premium quality toys for children across the Netherlands. Discover educational toys, toddler games, and creative playsets that spark imagination.',
    keywords:
      'kids toys, children games, educational toys, Netherlands toy store, premium quality toys, toddler toys, toys online, learning toys, baby games, imagination play'
  });

  const testimonials = [
    {
      quote:
        'The Rainbow Learning Blocks transformed rainy afternoons! My twins collaborate, negotiate, and build entire Dutch cities together.',
      parent: 'Marije, Utrecht',
      child: 'Noor (5) & Bram (5)',
      image: 'https://images.unsplash.com/photo-1503457574464-376fbd89c08b?auto=format&fit=crop&w=400&q=80'
    },
    {
      quote:
        'We love the Ocean Friends Bath Playset. Bath time is joyful and our toddler now names the marine animals in both Dutch and English.',
      parent: 'Fatima, Rotterdam',
      child: 'Yara (3)',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80'
    },
    {
      quote:
        'The Little Explorer Science Kit sparked so many questions. The guided journal helps us track each experiment with ease.',
      parent: 'Lars, Den Haag',
      child: 'Milan (7)',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80'
    }
  ];

  const teamMembers = [
    {
      name: 'Eva Bakker',
      role: 'Head of Play Curation',
      bio: 'Former early years teacher selecting toys that nurture creativity and emotional resilience.',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=500&q=80'
    },
    {
      name: 'Ravi Visser',
      role: 'Safety & Sustainability Lead',
      bio: 'Ensures every toy meets EU standards while embracing eco-friendly materials and packaging.',
      image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=500&q=80'
    },
    {
      name: 'Sanne de Vries',
      role: 'Playtime Storyteller',
      bio: 'Writes guides and play prompts that families across the Netherlands adore.',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=500&q=80'
    }
  ];

  const processSteps = [
    {
      title: 'Curate',
      description: 'We scout brands that align with Dutch safety standards and our creativity-first philosophy.'
    },
    {
      title: 'Play-Test',
      description: 'Families in Amsterdam, Rotterdam, and beyond test every toy for joy, durability, and inclusivity.'
    },
    {
      title: 'Deliver',
      description: 'Fast, carbon-conscious delivery to every province in the Netherlands, beautifully packaged.'
    }
  ];

  const faqItems = [
    {
      question: 'Do you ship across the Netherlands?',
      answer: 'Yes! We deliver to every province with eco-conscious partners. Most orders arrive within 2-3 working days.'
    },
    {
      question: 'How do you select the toys?',
      answer: 'Each toy goes through an educator review, safety assessment, and parent testing to ensure it sparks meaningful play.'
    },
    {
      question: 'Can I request a personalised recommendation?',
      answer: 'Absolutely. Visit our Services page to learn about our Toy Match Consultations tailored to your child’s interests.'
    }
  ];

  const stats = [
    { value: '1,200+', label: 'Play Ideas Curated' },
    { value: '98%', label: 'Families Recommend Us' },
    { value: '12', label: 'Provinces We Deliver To' }
  ];

  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [newsletterStatus, setNewsletterStatus] = useState(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const handleNewsletter = (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);
    const email = formData.get('email');
    if (email) {
      setNewsletterStatus('Thank you! We will send playful updates soon.');
      event.target.reset();
    }
  };

  const featuredProducts = products.slice(0, 4);
  const featuredArticles = blogPosts.slice(0, 3);

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroTag}>Shipping across the Netherlands</p>
          <h1>Premium Quality Toys for Kids</h1>
          <p className={styles.heroText}>
            Discover imaginative toys curated by educators and parents to nurture creativity, curiosity, and confidence. From newborn snuggles to adventurous inventors, we bring joyful play into every Dutch home.
          </p>
          <div className={styles.heroActions}>
            <Link to="/shop" className={styles.primaryCta}>Explore Toys</Link>
            <Link to="/services" className={styles.secondaryCta}>Book a Toy Match</Link>
          </div>
          <div className={styles.stats}>
            {stats.map((stat) => (
              <div key={stat.label} className={styles.statItem}>
                <span className={styles.statValue}>{stat.value}</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://images.unsplash.com/photo-1516627145497-ae6968895b74?auto=format&fit=crop&w=900&q=80"
            alt="Joyful kids playing with colourful toys"
          />
        </div>
      </section>

      <section className={styles.featuredCategories}>
        <div className={styles.sectionHeader}>
          <h2>Featured Categories</h2>
          <p>Curated collections that encourage creativity for every age and stage.</p>
        </div>
        <div className={styles.categoryGrid}>
          <Link to="/shop?category=Educational" className={`${styles.categoryCard} ${styles.categoryBlue}`}>
            <span role="img" aria-label="Books">📚</span>
            <h3>Educational Toys</h3>
            <p>STEM sets, language builders, and discovery kits designed by teachers.</p>
          </Link>
          <Link to="/shop?category=Creative" className={`${styles.categoryCard} ${styles.categoryPink}`}>
            <span role="img" aria-label="Art palette">🎨</span>
            <h3>Creative Playsets</h3>
            <p>Craft, build, and design worlds that grow with your child’s imagination.</p>
          </Link>
          <Link to="/shop?category=Baby" className={`${styles.categoryCard} ${styles.categoryYellow}`}>
            <span role="img" aria-label="Baby">👶</span>
            <h3>Baby &amp; Sensory</h3>
            <p>Gentle textures and soothing companions perfect for the smallest explorers.</p>
          </Link>
          <Link to="/shop?category=Games" className={`${styles.categoryCard} ${styles.categoryGreen}`}>
            <span role="img" aria-label="Puzzle piece">🧩</span>
            <h3>Toddler Games</h3>
            <p>Co-operative games and rhythm sets made for giggles and growth.</p>
          </Link>
        </div>
      </section>

      <section className={styles.whyUs}>
        <div className={styles.sectionHeader}>
          <h2>Why Dutch Families Choose Us</h2>
          <p>Every toy is thoughtfully selected to keep little ones engaged, safe, and inspired.</p>
        </div>
        <div className={styles.whyGrid}>
          <div className={styles.whyCard}>
            <h3>Premium Quality</h3>
            <p>Only durable, beautifully crafted toys that can be cherished and passed along.</p>
          </div>
          <div className={styles.whyCard}>
            <h3>Safe &amp; Durable</h3>
            <p>Independently tested to EU standards, featuring non-toxic finishes and sturdy designs.</p>
          </div>
          <div className={styles.whyCard}>
            <h3>Sparks Creativity</h3>
            <p>Curated to encourage open-ended play, collaborative storytelling, and confidence.</p>
          </div>
          <div className={styles.whyCard}>
            <h3>Nationwide Delivery</h3>
            <p>Fast, reliable shipping across the Netherlands with planet-friendly packaging.</p>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <h2>Our Playful Process</h2>
          <p>Thoughtful steps to ensure every box that arrives at your home is filled with joy.</p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step, index) => (
            <div key={step.title} className={styles.processCard}>
              <div className={styles.processNumber}>{index + 1}</div>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.popular}>
        <div className={styles.sectionHeader}>
          <h2>Popular Picks</h2>
          <p>Family favourites that receive rave reviews from Amsterdam to Groningen.</p>
        </div>
        <div className={styles.popularGrid}>
          {featuredProducts.map((product) => (
            <article key={product.id} className={styles.popularCard}>
              <img src={product.gallery[0]} alt={product.name} loading="lazy" />
              <div className={styles.cardBody}>
                <h3>{product.name}</h3>
                <p>{product.shortDescription}</p>
                <div className={styles.cardMeta}>
                  <span>{product.ageRangeLabel}</span>
                  <span>{product.category}</span>
                </div>
                <Link to={`/shop/${product.slug}`} className={styles.cardLink}>
                  View Details
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className={styles.sectionHeader}>
          <h2>Playtime Stories</h2>
          <p>Parents across the Netherlands share how their children imagine without limits.</p>
        </div>
        <div className={styles.testimonialWrapper}>
          {testimonials.map((item, index) => (
            <div
              key={item.parent}
              className={`${styles.testimonialCard} ${index === currentTestimonial ? styles.activeTestimonial : ''}`}
              aria-hidden={index !== currentTestimonial}
            >
              <div className={styles.testimonialImage}>
                <img src={item.image} alt={`${item.child} smiling`} loading="lazy" />
              </div>
              <blockquote>
                <p>{item.quote}</p>
                <footer>
                  <strong>{item.parent}</strong>
                  <span>{item.child}</span>
                </footer>
              </blockquote>
            </div>
          ))}
          <div className={styles.sliderControls}>
            <button
              type="button"
              onClick={() =>
                setCurrentTestimonial((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1))
              }
              aria-label="Previous testimonial"
            >
              ←
            </button>
            <button
              type="button"
              onClick={() =>
                setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
              }
              aria-label="Next testimonial"
            >
              →
            </button>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className={styles.sectionHeader}>
          <h2>Meet the Play Pioneers</h2>
          <p>Our Amsterdam-based team curates joyful moments for families from Friesland to Limburg.</p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <div key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </div>
          ))}
        </div>
        <Link to="/about" className={styles.teamLink}>
          Learn more about our story
        </Link>
      </section>

      <section className={styles.faqSection}>
        <div className={styles.sectionHeader}>
          <h2>Playtime FAQs</h2>
          <p>Everything you need to know before choosing your next loved toy.</p>
        </div>
        <div className={styles.faqGrid}>
          {faqItems.map((item) => (
            <details key={item.question}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className={styles.sectionHeader}>
          <h2>Imagination Corner</h2>
          <p>Fresh tips, play prompts, and behind-the-scenes stories from our toy scouts.</p>
        </div>
        <div className={styles.blogGrid}>
          {featuredArticles.map((article) => (
            <article key={article.slug} className={styles.blogCard}>
              <img src={article.heroImage} alt={article.title} loading="lazy" />
              <div className={styles.blogBody}>
                <span className={styles.blogDate}>{new Date(article.date).toLocaleDateString('en-NL', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}</span>
                <h3>{article.title}</h3>
                <p>{article.summary}</p>
                <Link to={`/blog/${article.slug}`} className={styles.blogLink}>
                  Read More
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.newsletter}>
        <div className={styles.newsletterCard}>
          <div>
            <h2>Join the Fun!</h2>
            <p>Subscribe for seasonal toy guides, exclusive play prompts, and early access to new arrivals.</p>
          </div>
          <form onSubmit={handleNewsletter} className={styles.newsletterForm}>
            <label htmlFor="newsletter-email" className="sr-only">
              Email address
            </label>
            <input
              id="newsletter-email"
              name="email"
              type="email"
              placeholder="Enter your email"
              aria-label="Email address"
              required
            />
            <button type="submit">Join the Fun!</button>
          </form>
          {newsletterStatus && <p className={styles.newsletterMessage}>{newsletterStatus}</p>}
        </div>
      </section>
    </div>
  );
};

export default HomePage;