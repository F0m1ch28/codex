import React from 'react';
import styles from './Legal.module.css';
import usePageMetadata from '../hooks/usePageMetadata';

const CookiePolicyPage = () => {
  usePageMetadata({
    title: 'Cookie Policy',
    description:
      'Imagination Unleashed cookie policy explaining how and why cookies are used on our Dutch toy store website.'
  });

  return (
    <div className={styles.page}>
      <h1>Cookie Policy</h1>
      <p>Last updated: January 2024</p>
      <p>
        This Cookie Policy explains how Imagination Unleashed uses cookies and similar technologies when you visit www.imaginationplaystore.nl.
      </p>

      <h2>1. What Are Cookies?</h2>
      <p>
        Cookies are small text files stored on your device when you browse our site. They help us remember your preferences and gather statistics to improve our services.
      </p>

      <h2>2. Types of Cookies We Use</h2>
      <ul>
        <li><strong>Essential cookies:</strong> Required for core website functionality such as navigation.</li>
        <li><strong>Performance cookies:</strong> Allow us to measure site usage and improve the experience.</li>
        <li><strong>Preference cookies:</strong> Remember your language and region selections.</li>
      </ul>

      <h2>3. Managing Cookies</h2>
      <p>
        You can accept or decline cookies in the banner shown on your first visit. You can also control cookies through your browser settings at any time.
      </p>

      <h2>4. Updates</h2>
      <p>
        We may update this policy to reflect changes in technology or regulations. We encourage you to review it regularly.
      </p>

      <h2>5. Contact</h2>
      <p>
        Questions about cookies? Email info@imaginationplaystore.nl.
      </p>
    </div>
  );
};

export default CookiePolicyPage;