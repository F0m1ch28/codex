import React, { useEffect, useMemo, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import styles from './Shop.module.css';
import usePageMetadata from '../hooks/usePageMetadata';
import { products } from '../data/products';

const categories = ['All', 'Educational', 'Creative', 'Toddler', 'Baby', 'Games'];
const ageGroups = ['All', '0-2 years', '2-4 years', '3-5 years', '5-7 years'];

const ShopPage = () => {
  usePageMetadata({
    title: 'Our Toy Collection',
    description:
      'Browse the Imagination Unleashed toy collection featuring educational kits, toddler games, baby toys, and creative playsets curated for Dutch families.'
  });

  const location = useLocation();
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [ageFilter, setAgeFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const categoryParam = params.get('category');
    const ageParam = params.get('age');
    if (categoryParam && categories.includes(categoryParam)) {
      setCategoryFilter(categoryParam);
    }
    if (ageParam && ageGroups.includes(ageParam)) {
      setAgeFilter(ageParam);
    }
  }, [location.search]);

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const matchesCategory =
        categoryFilter === 'All' || product.category === categoryFilter;
      const matchesAge = ageFilter === 'All' || product.ageRangeLabel === ageFilter;
      const matchesSearch =
        searchTerm.trim().length === 0 ||
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.tags.join(' ').toLowerCase().includes(searchTerm.toLowerCase());
      return matchesCategory && matchesAge && matchesSearch;
    });
  }, [categoryFilter, ageFilter, searchTerm]);

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>Our Toy Collection</h1>
        <p>
          Discover thoughtfully curated toys that grow with your child. Filter by category or age group to find the perfect companion for imaginative adventures.
        </p>
      </header>
      <div className={styles.layout}>
        <aside className={styles.filters} aria-label="Shop filters">
          <div className={styles.filterGroup}>
            <h2>Search</h2>
            <input
              type="search"
              placeholder="Search by name or tag"
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              aria-label="Search toys"
            />
          </div>
          <div className={styles.filterGroup}>
            <h2>Category</h2>
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={categoryFilter === category ? styles.activeFilter : ''}
                onClick={() => setCategoryFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.filterGroup}>
            <h2>Age Range</h2>
            {ageGroups.map((age) => (
              <button
                key={age}
                type="button"
                className={ageFilter === age ? styles.activeFilter : ''}
                onClick={() => setAgeFilter(age)}
              >
                {age}
              </button>
            ))}
          </div>
        </aside>
        <section className={styles.results} aria-live="polite">
          {filteredProducts.length === 0 ? (
            <div className={styles.emptyState}>
              <h3>No toys match your filters just yet.</h3>
              <p>Try adjusting your selection to discover more joyful play ideas.</p>
            </div>
          ) : (
            <div className={styles.grid}>
              {filteredProducts.map((product) => (
                <article key={product.id} className={styles.card}>
                  <img src={product.gallery[0]} alt={product.name} loading="lazy" />
                  <div className={styles.cardBody}>
                    <h3>{product.name}</h3>
                    <p>{product.shortDescription}</p>
                    <div className={styles.meta}>
                      <span>{product.ageRangeLabel}</span>
                      <span>{product.category}</span>
                    </div>
                    <div className={styles.tags}>
                      {product.tags.slice(0, 3).map((tag) => (
                        <span key={tag}>{tag}</span>
                      ))}
                    </div>
                    <Link to={`/shop/${product.slug}`} className={styles.detailsLink}>
                      View Details
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

export default ShopPage;