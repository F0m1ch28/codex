import { useEffect } from 'react';

const defaultTitle = 'Imagination Unleashed';
const defaultDescription =
  'Browse premium quality toys that nurture creativity, imagination, and joyful playtime across the Netherlands.';
const defaultKeywords =
  'kids toys, children games, educational toys, Netherlands toy store, premium quality toys, toddler toys, toys online, learning toys, baby games, imagination play';

const ensureMetaTag = (name, content) => {
  if (!content) return;
  let element = document.querySelector(`meta[name="${name}"]`);
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute('name', name);
    document.head.appendChild(element);
  }
  element.setAttribute('content', content);
};

const usePageMetadata = ({ title, description, keywords }) => {
  useEffect(() => {
    const fullTitle = title ? `${title} | Imagination Unleashed` : defaultTitle;
    document.title = fullTitle;
    ensureMetaTag('description', description || defaultDescription);
    ensureMetaTag('keywords', keywords || defaultKeywords);
  }, [title, description, keywords]);
};

export default usePageMetadata;