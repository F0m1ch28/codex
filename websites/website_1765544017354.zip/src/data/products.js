export const products = [
  {
    id: 'rainbow-learning-blocks',
    slug: 'rainbow-learning-blocks',
    name: 'Rainbow Learning Blocks',
    category: 'Educational',
    ageGroup: '3-5 years',
    ageRangeLabel: '3-5 years',
    shortDescription: 'Vibrant wooden blocks designed to boost early STEM skills and imaginative structures.',
    description:
      'Our Rainbow Learning Blocks are crafted to inspire open-ended play while nurturing colour recognition, numeracy, and fine-motor skills. The rounded edges and silky finish make stacking effortless for little hands.',
    features: [
      '48 colour-coded wooden blocks in four shapes',
      'Double-sided activity guide designed by Dutch educators',
      'Stackable storage tray for easy tidy-ups',
      'Non-toxic water-based finishes for safe play'
    ],
    developmentalBenefits: [
      'Enhances spatial reasoning and early engineering concepts',
      'Promotes collaborative play and turn-taking',
      'Strengthens fine-motor control and dexterity',
      'Encourages storytelling and imaginative builds'
    ],
    materials: 'FSC-certified beech wood finished with non-toxic water-based paint.',
    safety: 'Independently tested to EN71 standards. Edges are rounded and smooth.',
    careInstructions: 'Wipe clean with a damp cloth. Air dry completely before storing.',
    tags: ['Educational', 'Creative', 'Building'],
    gallery: [
      'https://images.unsplash.com/photo-1520170352430-624d5b81c9d0?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1513676788054-b0c72bbc8d43?auto=format&fit=crop&w=1200&q=80'
    ]
  },
  {
    id: 'little-explorer-science-kit',
    slug: 'little-explorer-science-kit',
    name: 'Little Explorer Science Kit',
    category: 'Educational',
    ageGroup: '5-7 years',
    ageRangeLabel: '5-7 years',
    shortDescription: 'Hands-on experiments that nurture curiosity about the world around us.',
    description:
      'The Little Explorer Science Kit introduces budding scientists to simple chemistry and physics experiments with easy-to-follow Dutch and English instructions.',
    features: [
      '12 guided experiments curated by child psychologists',
      'Reusable lab tools sized for small hands',
      'Experiment journal to document discoveries',
      'QR codes linking to bonus experiment videos'
    ],
    developmentalBenefits: [
      'Builds confidence through safe trial-and-error',
      'Encourages scientific thinking and observation',
      'Promotes vocabulary expansion and literacy',
      'Strengthens patience and focus during experiments'
    ],
    materials: 'BPA-free plastics, recycled paper journal, natural dye powders.',
    safety: 'All components meet EU Toy Safety Directive 2009/48/EC.',
    careInstructions: 'Hand wash lab tools with warm soapy water. Store powders in a cool, dry place.',
    tags: ['STEM', 'Educational', 'Experiment'],
    gallery: [
      'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1554475901-4538ddfbccc5?auto=format&fit=crop&w=1200&q=80'
    ]
  },
  {
    id: 'cozy-storytime-plush-set',
    slug: 'cozy-storytime-plush-set',
    name: 'Cozy Storytime Plush Set',
    category: 'Baby',
    ageGroup: '0-2 years',
    ageRangeLabel: '0-2 years',
    shortDescription: 'Huggable characters with sensory textures to enrich bedtime bonding.',
    description:
      'Meet Luna the Bunny, Finn the Fox, and Miko the Bear—three plush friends designed to support early sensory exploration and language development during storytime.',
    features: [
      'Set of three plush characters with embroidered details',
      'Removable sensory scarves with crinkle sounds',
      'Illustrated story cards in Dutch and English',
      'Machine-washable covers for easy care'
    ],
    developmentalBenefits: [
      'Supports tactile stimulation and soothing routines',
      'Encourages early communication through storytelling',
      'Fosters secure attachment during bedtime snuggles',
      'Introduces gentle contrasts to support visual tracking'
    ],
    materials: 'Organic cotton outer layer, recycled polyester fill, OEKO-TEX certified dyes.',
    safety: 'Suitable from birth. No loose parts. Compliant with EN71 and REACH regulations.',
    careInstructions: 'Remove scarves before washing. Machine wash cold, air dry flat.',
    tags: ['Baby', 'Sensory', 'Comfort'],
    gallery: [
      'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1596891790762-7ad0d44daa58?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1586105251261-72a756497a12?auto=format&fit=crop&w=1200&q=80'
    ]
  },
  {
    id: 'melody-makers-percussion-pack',
    slug: 'melody-makers-percussion-pack',
    name: 'Melody Makers Percussion Pack',
    category: 'Games',
    ageGroup: '3-5 years',
    ageRangeLabel: '3-5 years',
    shortDescription: 'Colourful percussion instruments that spark rhythm, coordination, and joy.',
    description:
      'Invite mini musicians to explore beats with a curated percussion collection featuring child-safe designs and gentle tones perfect for family jam sessions.',
    features: [
      'Includes tambourine, hand drum, shakers, and tone blocks',
      'Colour-coded rhythm cards with Dutch nursery songs',
      'Soft carry bag for easy storage and travel',
      'Volume-conscious design for indoor play'
    ],
    developmentalBenefits: [
      'Boosts auditory discrimination and pattern recognition',
      'Develops gross and fine motor coordination',
      'Promotes self-expression through movement',
      'Encourages collaboration and turn-taking'
    ],
    materials: 'Rubberwood, natural leather, BPA-free plastic details.',
    safety: 'All instruments comply with EN71-1/-2/-3. Small parts are securely fastened.',
    careInstructions: 'Wipe surfaces with a dry cloth. Avoid prolonged moisture exposure.',
    tags: ['Music', 'Games', 'Creative'],
    gallery: [
      'https://images.unsplash.com/photo-1511385348-a52b4a160dc2?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1526662092594-e98c1e356d6a?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1527182273015-bffb4fef61c8?auto=format&fit=crop&w=1200&q=80'
    ]
  },
  {
    id: 'adventure-builders-train-set',
    slug: 'adventure-builders-train-set',
    name: 'Adventure Builders Train Set',
    category: 'Creative',
    ageGroup: '4-7 years',
    ageRangeLabel: '4-7 years',
    shortDescription: 'Magnetic trains and tracks that let designers craft new routes every day.',
    description:
      'The Adventure Builders Train Set combines magnetised locomotives with modular track pieces, encouraging storytelling and problem-solving as children connect Dutch city landmarks.',
    features: [
      '36-piece track system with elevated bridges and tunnels',
      'Magnetic trains with interchangeable cargo',
      'Story cards featuring Dutch cities like Utrecht and Rotterdam',
      'Fold-out play mat with rivers and canals'
    ],
    developmentalBenefits: [
      'Improves planning and sequencing skills',
      'Strengthens fine-motor coordination and bilateral movement',
      'Encourages geographic awareness and storytelling',
      'Promotes perseverance through design challenges'
    ],
    materials: 'Responsibly sourced wood, ABS plastic connectors, recycled paper play mat.',
    safety: 'Magnets are embedded and comply with EN71 magnetic toy standards.',
    careInstructions: 'Store pieces in the provided canvas bag. Spot clean with a damp cloth.',
    tags: ['Creative', 'STEM', 'Transport'],
    gallery: [
      'https://images.unsplash.com/photo-1571266755208-dbf18c0d6f76?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1527368911044-56469c19ee03?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1509221961660-7c18b629e9c9?auto=format&fit=crop&w=1200&q=80'
    ]
  },
  {
    id: 'ocean-friends-bath-playset',
    slug: 'ocean-friends-bath-playset',
    name: 'Ocean Friends Bath Playset',
    category: 'Toddler',
    ageGroup: '2-4 years',
    ageRangeLabel: '2-4 years',
    shortDescription: 'Floating friends that transform bath time into a splashy learning adventure.',
    description:
      'Discover the wonders of the North Sea with soft-touch marine characters that pour, sprinkle, and float. Each friend shares a playful fact to spark curiosity about aquatic life.',
    features: [
      'Six squeeze-and-squirt ocean animals',
      'Colour-changing temperature-safe boat',
      'Storyboard bath stickers that cling to tiles',
      'Mesh drying bag to keep toys fresh'
    ],
    developmentalBenefits: [
      'Develops hand strength and coordination',
      'Supports sensory play with warm and cool water',
      'Encourages early science vocabulary',
      'Transforms routines into playful bonding moments'
    ],
    materials: 'Phthalate-free PVC, silicone, breathable mesh bag.',
    safety: 'Mould-resistant design. Meets EU safety standards for bath toys.',
    careInstructions: 'Rinse after each bath. Hang the mesh bag to air dry.',
    tags: ['Water play', 'Toddler', 'Sensory'],
    gallery: [
      'https://images.unsplash.com/photo-1584448098682-354c1c3c63f9?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1507668077129-56e32842fceb?auto=format&fit=crop&w=1200&q=80'
    ]
  }
];