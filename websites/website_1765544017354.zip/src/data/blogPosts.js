export const blogPosts = [
  {
    slug: 'inspire-open-ended-play-at-home',
    title: 'How to Inspire Open-Ended Play at Home',
    date: '2023-11-18',
    author: 'Sanne de Vries',
    summary:
      'Discover practical ways to set up play corners that nurture creativity, independence, and joyful discovery for young explorers.',
    tags: ['Parenting Tips', 'Learning Through Play'],
    heroImage: 'https://images.unsplash.com/photo-1596464716127-f0c2146b6fde?auto=format&fit=crop&w=1400&q=80',
    sections: [
      {
        heading: 'Create Invitations to Play',
        body:
          'Arrange materials in simple, accessible baskets so children can select what fascinates them. Rotating items every few weeks keeps curiosity high without overwhelming your space.'
      },
      {
        heading: 'Mix Textures and Tools',
        body:
          'Combining wooden blocks with silk scarves, nature treasures, or toy animals encourages storytelling and experimentation. Offer a gentle prompt, then step back and observe the magic unfold.'
      },
      {
        heading: 'Observe and Reflect',
        body:
          'Keep a small journal to note play patterns. Are they building, sorting, or narrating? These observations help you select future toys that extend their interests and skills.'
      }
    ]
  },
  {
    slug: 'safe-toy-checklist-for-busy-parents',
    title: 'A Safe Toy Checklist for Busy Parents',
    date: '2023-12-02',
    author: 'Lotte van Dijk',
    summary:
      'A handy guide to ensure every toy in your home meets Dutch and EU safety standards while staying engaging and durable.',
    tags: ['Safety', 'Parenting Tips'],
    heroImage: 'https://images.unsplash.com/photo-1601758003122-58c07a3a0f90?auto=format&fit=crop&w=1400&q=80',
    sections: [
      {
        heading: 'Check the Labels',
        body:
          'Look for CE markings, EN71 compliance, and age recommendations. Quality certifications mean the toy has passed mechanical, chemical, and flammability tests.'
      },
      {
        heading: 'Inspect the Materials',
        body:
          'Prefer natural fibres, BPA-free plastics, and sustainably sourced woods. Avoid sharp edges or detachable small parts for toddlers under three.'
      },
      {
        heading: 'Review Care Instructions',
        body:
          'Durable toys last longer when cared for properly. Quick cleaning routines can keep toys fresh, safe, and ready for imaginative play every day.'
      }
    ]
  },
  {
    slug: 'montessori-corner-in-small-spaces',
    title: 'Designing a Montessori Corner in Small Dutch Homes',
    date: '2024-01-10',
    author: 'Imran Jacobs',
    summary:
      'Smart storage, multifunctional furniture, and curated toys can transform even the cosiest Amsterdam apartment into a learning haven.',
    tags: ['Learning Through Play', 'Home Inspiration'],
    heroImage: 'https://images.unsplash.com/photo-1528742830110-5f4625e98093?auto=format&fit=crop&w=1400&q=80',
    sections: [
      {
        heading: 'Choose Multi-Use Furniture',
        body:
          'Opt for open shelving at child height and foldable tables. Each piece should invite independence and make tidying intuitive for youngsters.'
      },
      {
        heading: 'Limit the Choice, Increase the Joy',
        body:
          'Display 6-8 toys at a time, rotating bi-weekly. This approach prevents overstimulation and invites children to dive deeper into meaningful play.'
      },
      {
        heading: 'Celebrate Dutch Living',
        body:
          'Include cultural touchpoints: maps of the Netherlands, wooden tulips, or books in Dutch and English. Children thrive when their environment reflects their community.'
      }
    ]
  }
];