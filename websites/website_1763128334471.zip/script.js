document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    const scrollButton = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookiesBtn = document.getElementById('accept-cookies');
    const contactForm = document.getElementById('contact-form');
    const successMessage = document.getElementById('contact-success');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !expanded);
            navLinks.classList.toggle('open');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    }

    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollButton.classList.add('show');
        } else {
            scrollButton.classList.remove('show');
        }
    });

    if (scrollButton) {
        scrollButton.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const cookieConsent = localStorage.getItem('impulsoCookieConsent');
    if (!cookieConsent && cookieBanner) {
        cookieBanner.classList.add('show');
    }

    if (acceptCookiesBtn && cookieBanner) {
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('impulsoCookieConsent', 'true');
            cookieBanner.classList.remove('show');
        });
    }

    if (contactForm && successMessage) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            successMessage.textContent = 'Gracias por tu mensaje. Te contactaremos para avanzar en tu estrategia digital.';
            contactForm.reset();
        });
    }
});