document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.querySelector(".nav-menu");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      const isOpen = navMenu.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen);
    });
  }

  const planCards = document.querySelectorAll(".plan-card");
  planCards.forEach((card) => {
    card.addEventListener("click", () => {
      planCards.forEach((item) => item.classList.remove("is-active"));
      card.classList.add("is-active");
    });

    card.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        planCards.forEach((item) => item.classList.remove("is-active"));
        card.classList.add("is-active");
      }
    });
  });

  const walletText = document.querySelector("[data-wallet-address]");
  const copyButton = document.querySelector("[data-copy-wallet]");
  if (walletText && copyButton) {
    copyButton.addEventListener("click", async () => {
      const address = walletText.textContent.trim();
      try {
        await navigator.clipboard.writeText(address);
        copyButton.textContent = "Copied!";
        copyButton.classList.add("copied");
        setTimeout(() => {
          copyButton.textContent = "Copy Address";
          copyButton.classList.remove("copied");
        }, 2500);
      } catch (error) {
        copyButton.textContent = "Copy failed";
        setTimeout(() => {
          copyButton.textContent = "Copy Address";
        }, 2500);
      }
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".cookie-accept");
  const declineBtn = document.querySelector(".cookie-decline");
  const consentKey = "ccx_cookie_consent";

  const storedConsent = localStorage.getItem(consentKey);
  if (!storedConsent && cookieBanner) {
    cookieBanner.classList.add("is-visible");
  }

  const handleConsent = (value) => {
    localStorage.setItem(consentKey, value);
    if (cookieBanner) {
      cookieBanner.classList.remove("is-visible");
    }
  };

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => handleConsent("accepted"));
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => handleConsent("declined"));
  }
});