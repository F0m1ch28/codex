document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".nav");
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      navToggle.classList.toggle("open");
      nav.classList.toggle("open");
    });
  }

  const sections = document.querySelectorAll(".fade-in");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    sections.forEach(section => observer.observe(section));
  } else {
    sections.forEach(section => section.classList.add("visible"));
  }

  const toast = document.querySelector(".toast");
  const forms = document.querySelectorAll("form[data-redirect]");
  forms.forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      if (toast) {
        toast.textContent = "Solicitud enviada. Preparando confirmación...";
        toast.classList.add("show");
        setTimeout(() => {
          toast.classList.remove("show");
        }, 2800);
      }
      setTimeout(() => {
        window.location.href = form.getAttribute("data-redirect");
      }, 1800);
    });
  });

  const cookieBanner = document.querySelector(".cookie-banner");
  const cookieAccept = document.querySelector(".cookie-accept");
  const cookieDecline = document.querySelector(".cookie-decline");
  const cookieStorageKey = "ia-hospitalaria-cookie-choice";

  const storedChoice = localStorage.getItem(cookieStorageKey);
  if (!storedChoice && cookieBanner) {
    cookieBanner.style.display = "block";
  }

  const handleCookie = value => {
    localStorage.setItem(cookieStorageKey, value);
    if (cookieBanner) {
      cookieBanner.style.display = "none";
    }
  };

  if (cookieAccept) {
    cookieAccept.addEventListener("click", () => handleCookie("accepted"));
  }
  if (cookieDecline) {
    cookieDecline.addEventListener("click", () => handleCookie("declined"));
  }
});