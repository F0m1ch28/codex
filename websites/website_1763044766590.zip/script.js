document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".primary-nav");
    const navLinks = document.querySelectorAll(".primary-nav a");
    const backToTopButtons = document.querySelectorAll(".section-top");
    const scrollTopButton = document.getElementById("scrollTopButton");
    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieAcceptButton = document.querySelector(".cookie-accept-button");
    const contactForm = document.getElementById("contact-form");
    const currentYear = document.getElementById("current-year");

    // Current year in footer
    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }

    // Mobile navigation toggle
    if (navToggle && nav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            nav.classList.toggle("open");
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", (event) => {
                const targetId = link.getAttribute("href");
                if (targetId && targetId.startsWith("#")) {
                    event.preventDefault();
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        targetElement.scrollIntoView({ behavior: "smooth" });
                    }
                }
                navToggle.setAttribute("aria-expanded", "false");
                nav.classList.remove("open");
            });
        });
    }

    // Section back-to-top buttons
    backToTopButtons.forEach((button) => {
        button.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    });

    // Floating scroll-to-top button
    if (scrollTopButton) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 400) {
                scrollTopButton.classList.add("show");
            } else {
                scrollTopButton.classList.remove("show");
            }
        });

        scrollTopButton.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    // Cookie banner management
    const cookieStorageKey = "tilonixCookieConsent";
    if (cookieBanner && cookieAcceptButton) {
        const consent = localStorage.getItem(cookieStorageKey);
        if (!consent) {
            cookieBanner.classList.add("show");
        }

        cookieAcceptButton.addEventListener("click", () => {
            localStorage.setItem(cookieStorageKey, "accepted");
            cookieBanner.classList.remove("show");
        });
    }

    // Contact form handling
    if (contactForm) {
        const statusField = contactForm.querySelector(".form-status");
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get("name");
            const email = formData.get("email");
            const message = formData.get("message");

            if (!name || !email || !message) {
                if (statusField) {
                    statusField.textContent = "Bitte füllen Sie alle Pflichtfelder aus.";
                    statusField.style.color = "#d14334";
                }
                return;
            }

            if (statusField) {
                statusField.textContent = "Vielen Dank! Ihre Nachricht wurde lokal gespeichert. Wir melden uns zeitnah.";
                statusField.style.color = "#00a5b8";
            }
            contactForm.reset();
        });
    }
});