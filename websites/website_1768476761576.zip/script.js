document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            siteNav.classList.toggle("is-active");
        });

        const navLinks = siteNav.querySelectorAll("a");
        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 1024) {
                    siteNav.classList.remove("is-active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector("[data-cookie='accept']");
        const declineBtn = cookieBanner.querySelector("[data-cookie='decline']");
        const storedConsent = localStorage.getItem("cr-cookie-consent");

        if (storedConsent) {
            cookieBanner.classList.add("is-hidden");
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => {
                localStorage.setItem("cr-cookie-consent", "accepted");
                cookieBanner.classList.add("is-hidden");
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", () => {
                localStorage.setItem("cr-cookie-consent", "declined");
                cookieBanner.classList.add("is-hidden");
            });
        }
    }
});