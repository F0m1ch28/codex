document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector("[data-nav-toggle]");
  const navLinks = document.querySelector(".nav-links");

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      navLinks.classList.toggle("active");
    });
  }

  const videoSearchInput = document.querySelector("[data-video-search]");
  const videoCards = document.querySelectorAll("[data-video-card]");

  if (videoSearchInput && videoCards.length) {
    videoSearchInput.addEventListener("input", () => {
      const query = videoSearchInput.value.toLowerCase();
      videoCards.forEach((card) => {
        const title = card.getAttribute("data-title") || "";
        const isMatch = title.toLowerCase().includes(query);
        card.style.display = isMatch ? "" : "none";
      });
    });
  }

  const cookieBanner = document.getElementById("cookieBanner");
  const acceptButton = document.querySelector("[data-cookie-accept]");
  const declineButton = document.querySelector("[data-cookie-decline]");
  const consentKey = "aov-cookie-preference";

  const storedConsent = localStorage.getItem(consentKey);
  if (!storedConsent && cookieBanner) {
    requestAnimationFrame(() => {
      cookieBanner.classList.add("visible");
    });
  }

  if (acceptButton) {
    acceptButton.addEventListener("click", () => {
      localStorage.setItem(consentKey, "accepted");
      if (cookieBanner) {
        cookieBanner.classList.remove("visible");
      }
    });
  }

  if (declineButton) {
    declineButton.addEventListener("click", () => {
      localStorage.setItem(consentKey, "declined");
      if (cookieBanner) {
        cookieBanner.classList.remove("visible");
      }
    });
  }
});