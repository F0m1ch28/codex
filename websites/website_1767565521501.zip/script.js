document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelector(".nav-links");

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      navToggle.classList.toggle("is-active");
      navLinks.classList.toggle("is-open");
    });

    navLinks.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.classList.remove("is-active");
        navLinks.classList.remove("is-open");
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const cookieAccept = document.querySelector(".cookie-accept");
  const cookieDecline = document.querySelector(".cookie-decline");
  const cookieStorageKey = "gt-cookie-preference";

  if (cookieBanner && cookieAccept && cookieDecline) {
    const preference = localStorage.getItem(cookieStorageKey);
    if (!preference) {
      cookieBanner.style.display = "flex";
    }

    const handleDecision = (decision) => {
      localStorage.setItem(cookieStorageKey, decision);
      cookieBanner.style.display = "none";
    };

    cookieAccept.addEventListener("click", () => handleDecision("accepted"));
    cookieDecline.addEventListener("click", () => handleDecision("declined"));
  }

  const calculatorForm = document.getElementById("calculator-form");
  if (calculatorForm) {
    calculatorForm.addEventListener("submit", function (event) {
      event.preventDefault();
      const verbrauch = parseFloat(calculatorForm.verbrauch.value) || 0;
      const dachflaeche = parseFloat(calculatorForm.dachflaeche.value) || 0;
      const sonnenstunden = parseFloat(calculatorForm.sonnenstunden.value) || 0;
      const strompreis = parseFloat(calculatorForm.strompreis.value) || 0;
      const investition = parseFloat(calculatorForm.investition.value) || 0;

      const leistungProM2 = 0.2; // kWp pro m²
      const systemWirkungsgrad = 0.85;
      const co2Faktor = 0.401; // kg CO2 pro kWh
      const autarkieCap = Math.max(verbrauch, 1);

      const anlagenleistung = dachflaeche * leistungProM2; // kWp
      const jahresproduktion = anlagenleistung * sonnenstunden * systemWirkungsgrad;
      const eigenverbrauch = Math.min(jahresproduktion, verbrauch);
      const einsparung = eigenverbrauch * strompreis;
      const amortisation = einsparung > 0 ? investition / einsparung : 0;
      const co2Ersparnis = eigenverbrauch * co2Faktor;
      const autarkiegrad = (eigenverbrauch / autarkieCap) * 100;

      document.getElementById("produktion-display").textContent = `${Math.round(jahresproduktion).toLocaleString("de-DE")} kWh`;
      document.getElementById("einsparung-display").textContent = `${Math.round(einsparung).toLocaleString("de-DE")} € jährliche Einsparung`;
      document.getElementById("amortisation-display").textContent = `Geschätzte Amortisationszeit: ${amortisation > 0 ? amortisation.toFixed(1).replace(".", ",") : "–"} Jahre`;
      document.getElementById("co2-display").textContent = `${Math.round(co2Ersparnis).toLocaleString("de-DE")} kg`;
      document.getElementById("autarkie-display").textContent = `${Math.min(autarkiegrad, 100).toFixed(1).replace(".", ",")} %`;
      document.getElementById("calculator-note").textContent = "Berechnung basiert auf Erfahrungswerten und ersetzt keine technische Detailplanung.";
    });
  }

  const newsletterForms = document.querySelectorAll(".newsletter-form");
  newsletterForms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const input = form.querySelector("input[type='email']");
      if (input) {
        input.value = "";
        alert("Vielen Dank für Ihre Anmeldung zum Newsletter!");
      }
    });
  });

  const contactForm = document.getElementById("contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();
      const feedback = document.getElementById("contact-feedback");
      if (feedback) {
        feedback.textContent = "Vielen Dank für Ihre Nachricht. Wir melden uns zeitnah bei Ihnen.";
        feedback.style.color = "#2e7d32";
      }
      contactForm.reset();
    });
  }
});