import React from 'react';
import { Routes, Route, Outlet, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import SleepOptimization from './pages/SleepOptimization';
import Tagesrhythmus from './pages/Tagesrhythmus';
import HealthBasics from './pages/HealthBasics';
import Privacy from './pages/Privacy';
import Impressum from './pages/Impressum';
import Terms from './pages/Terms';
import NotFound from './pages/NotFound';
import styles from './App.module.css';

const ScrollToTopOnRoute = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

const AppLayout = () => (
  <div className={styles.layout}>
    <Header />
    <div className={styles.mainWrapper}>
      <main className={styles.main} id="hauptinhalt">
        <Outlet />
      </main>
    </div>
    <Footer />
    <CookieBanner />
    <ScrollToTop />
  </div>
);

const App = () => (
  <div className={styles.app}>
    <ScrollToTopOnRoute />
    <Routes>
      <Route element={<AppLayout />}>
        <Route index element={<Home />} />
        <Route path="leistungen" element={<Services />} />
        <Route path="schlaf-optimierung" element={<SleepOptimization />} />
        <Route path="tagesrhythmus" element={<Tagesrhythmus />} />
        <Route path="gesundheitsgrundlagen" element={<HealthBasics />} />
        <Route path="ueber-uns" element={<About />} />
        <Route path="kontakt" element={<Contact />} />
        <Route path="datenschutz" element={<Privacy />} />
        <Route path="impressum" element={<Impressum />} />
        <Route path="agb" element={<Terms />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  </div>
);

export default App;