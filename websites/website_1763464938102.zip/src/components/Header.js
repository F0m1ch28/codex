import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { to: '/', label: 'Start' },
  { to: '/leistungen', label: 'Leistungen' },
  { to: '/schlaf-optimierung', label: 'Schlafoptimierung' },
  { to: '/tagesrhythmus', label: 'Tagesrhythmus' },
  { to: '/gesundheitsgrundlagen', label: 'Gesundheitsgrundlagen' },
  { to: '/ueber-uns', label: 'Über uns' },
  { to: '/kontakt', label: 'Kontakt' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 24);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className={`container ${styles.inner}`}>
        <NavLink to="/" className={styles.logo} aria-label="Raventolira Startseite">
          <span className={styles.logoPrimary}>Raventolira</span>
          <span className={styles.logoTagline}>Natürliche Gesundheit</span>
        </NavLink>

        <nav
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Hauptnavigation"
        >
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.to} className={styles.navItem}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <div className={styles.actions}>
          <NavLink to="/kontakt" className="btnPrimary">
            Termin anfragen
          </NavLink>
          <button
            type="button"
            className={`${styles.menuToggle} ${menuOpen ? styles.menuOpen : ''}`}
            aria-expanded={menuOpen}
            aria-label={menuOpen ? 'Hauptmenü schließen' : 'Hauptmenü öffnen'}
            onClick={() => setMenuOpen((prev) => !prev)}
          >
            <span className={styles.menuIcon} aria-hidden="true" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;