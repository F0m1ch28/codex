import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'raventolira-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  const declineCookies = () => {
    window.localStorage.setItem(STORAGE_KEY, 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div
      className={styles.banner}
      role="dialog"
      aria-live="polite"
      aria-label="Cookie-Hinweis"
    >
      <div className={styles.content}>
        <p className={styles.text}>
          Wir verwenden ausschließlich essenzielle Cookies, um Ihren Besuch nutzerfreundlich zu gestalten.
          Es werden keine Tracking- oder Marketing-Cookies gesetzt.
        </p>
        <div className={styles.actions}>
          <button type="button" className="btnSecondary" onClick={declineCookies}>
            Ablehnen
          </button>
          <button type="button" className="btnPrimary" onClick={acceptCookies}>
            Akzeptieren
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;