import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.grid}`}>
        <div className={styles.brand}>
          <h3 className={styles.brandTitle}>Raventolira</h3>
          <p className={styles.brandText}>
            Wir begleiten Menschen dabei, Schlaf, Rhythmus und grundlegende Gesundheit mit natürlichen Methoden
            zu stärken – sanft, individuell und alltagsnah.
          </p>
          <p className={styles.contactLine}>
            <strong>E-Mail:</strong>{' '}
            <a href="mailto:hello@raventolira.site">hello@raventolira.site</a>
          </p>
          <p className={styles.contactLine}>
            <strong>Telefon:</strong>{' '}
            <a href="tel:+491234567890">+49 123 456 7890</a>
          </p>
        </div>

        <div className={styles.column}>
          <h4 className={styles.columnTitle}>Navigation</h4>
          <ul className={styles.linkList}>
            <li><NavLink to="/">Startseite</NavLink></li>
            <li><NavLink to="/leistungen">Leistungen</NavLink></li>
            <li><NavLink to="/ueber-uns">Über uns</NavLink></li>
            <li><NavLink to="/kontakt">Kontakt</NavLink></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4 className={styles.columnTitle}>Servicebereiche</h4>
          <ul className={styles.linkList}>
            <li><NavLink to="/schlaf-optimierung">Schlafoptimierung</NavLink></li>
            <li><NavLink to="/tagesrhythmus">Tagesrhythmus</NavLink></li>
            <li><NavLink to="/gesundheitsgrundlagen">Gesundheitsgrundlagen</NavLink></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4 className={styles.columnTitle}>Rechtliches</h4>
          <ul className={styles.linkList}>
            <li><NavLink to="/datenschutz">Datenschutz</NavLink></li>
            <li><NavLink to="/impressum">Impressum</NavLink></li>
            <li><NavLink to="/agb">AGB</NavLink></li>
          </ul>
        </div>
      </div>

      <div className={styles.bottom}>
        <div className={`container ${styles.bottomInner}`}>
          <p>© {currentYear} Raventolira. Alle Rechte vorbehalten.</p>
          <div className={styles.badges}>
            <span className={styles.badge}>Made for Balance</span>
            <span className={styles.badge}>Natürliche Ansätze</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;