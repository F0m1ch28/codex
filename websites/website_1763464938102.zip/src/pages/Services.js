import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './Services.module.css';

const serviceBundles = [
  {
    title: 'Schlafreise',
    description:
      'Begleitung über mehrere Wochen, in der wir Schlafgewohnheiten beobachten, Abendrituale entwickeln und Erholungsräume bewusst gestalten.',
    highlights: [
      'Individuelle Schlafanalyse & Habit-Tracking',
      'Audioübungen für Abendentspannung und Morgenaktivierung',
      'Reflexionsgespräche und Alltagstransfer'
    ],
    link: '/schlaf-optimierung'
  },
  {
    title: 'Rhythmus-Studio',
    description:
      'Strukturierte Sessions zur Gestaltung von Tagesrhythmen – vom energiespendenden Morgen bis zum ausgleichenden Abend.',
    highlights: [
      'Chronotyp-Screening & Lichtplanung',
      'Pausensysteme und Aktivitätsfenster',
      'Werkzeuge für hybride und remote Arbeit'
    ],
    link: '/tagesrhythmus'
  },
  {
    title: 'Gesundheitsfundament',
    description:
      'Workshops und Coachings rund um Ernährung, Bewegung und mentale Hygiene – mit Fokus auf natürliche Regeneration.',
    highlights: [
      'Mikrogewohnheiten für Immunsystem und Verdauung',
      'Atem- und Bewegungsimpulse',
      'Reflexionsmethoden für Selbstfürsorge'
    ],
    link: '/gesundheitsgrundlagen'
  }
];

const Services = () => (
  <>
    <Helmet>
      <title>Leistungen – Raventolira</title>
      <meta
        name="description"
        content="Entdecken Sie die Leistungen von Raventolira: Schlafreisen, Rhythmus-Studios und Gesundheitsfundamente – für natürliche Balance ohne Medikamente."
      />
    </Helmet>

    <section className={`${styles.section} container`}>
      <header className={styles.header}>
        <p className={styles.pretitle}>Leistungen</p>
        <h1>Begleitungen, die zu Ihrem Alltag passen</h1>
        <p>
          Wir verbinden individuelles Coaching, Gruppenformate und digitale Ressourcen. So können Sie
          genau dort ansetzen, wo Sie gerade stehen – mit sanften, machbaren Schritten.
        </p>
      </header>

      <div className={styles.grid}>
        {serviceBundles.map((bundle) => (
          <article key={bundle.title} className={styles.card}>
            <h2>{bundle.title}</h2>
            <p>{bundle.description}</p>
            <ul>
              {bundle.highlights.map((highlight) => (
                <li key={highlight}>{highlight}</li>
              ))}
            </ul>
            <Link to={bundle.link} className={styles.link}>
              Mehr erfahren <span aria-hidden="true">→</span>
            </Link>
          </article>
        ))}
      </div>
    </section>

    <section className={`${styles.section} ${styles.formatSection}`}>
      <div className="container">
        <div className={styles.formatGrid}>
          <div>
            <h2>Formate & Module</h2>
            <p>
              Jede Begleitung lässt sich kombinieren: von punktuellen Impulsen über
              mehrteilige Workshop-Reihen bis zu individuellen Coachings. Wir beraten Sie,
              welche Kombination Sinn ergibt.
            </p>
          </div>
          <ul className={styles.formatList}>
            <li>
              <strong>Einzelcoaching:</strong> Vertiefte Arbeit an persönlichen Gewohnheiten,
              Reflexion und Umsetzung im Alltag.
            </li>
            <li>
              <strong>Team-Sessions:</strong> Interaktive Workshops für Teams, die gesunde Kultur leben wollen.
            </li>
            <li>
              <strong>Live-Online-Formate:</strong> Mikro-Impulse in 60 Minuten – in Pausen integrierbar.
            </li>
            <li>
              <strong>Retreats & Fokus-Tage:</strong> Intensive Erlebnisse zum Auftanken und Neuausrichten.
            </li>
          </ul>
        </div>
      </div>
    </section>
  </>
);

export default Services;