import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialForm = {
  name: '',
  email: '',
  topic: '',
  message: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialForm);
  const [formErrors, setFormErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const errors = {};
    if (!formData.name.trim()) {
      errors.name = 'Bitte geben Sie Ihren Namen ein.';
    }
    if (!formData.email.trim()) {
      errors.email = 'Bitte E-Mail-Adresse angeben.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(formData.email)) {
      errors.email = 'Bitte eine gültige E-Mail-Adresse verwenden.';
    }
    if (!formData.message.trim()) {
      errors.message = 'Wie können wir helfen? Bitte Nachricht ergänzen.';
    }
    return errors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    setFormErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const errors = validate();
    setFormErrors(errors);
    if (Object.keys(errors).length === 0) {
      setSubmitted(true);
      setFormData(initialForm);
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt – Raventolira</title>
        <meta
          name="description"
          content="Nehmen Sie Kontakt mit Raventolira auf. Wir freuen uns auf Ihre Fragen rund um Schlaf, Tagesrhythmus und natürliche Gesundheitsbalance."
        />
      </Helmet>

      <section className={`${styles.section} container`}>
        <div className={styles.header}>
          <p className={styles.pretitle}>Kontakt</p>
          <h1>Wir freuen uns auf Ihre Nachricht</h1>
          <p>
            Erzählen Sie uns ein wenig über Ihre Situation, Ihre Ziele oder Ihr Team.
            Wir melden uns innerhalb von zwei Werktagen zurück.
          </p>
        </div>

        <div className={styles.grid}>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Name*</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(formErrors.name)}
                aria-describedby={formErrors.name ? 'name-error' : undefined}
              />
              {formErrors.name && (
                <span id="name-error" className={styles.error}>
                  {formErrors.name}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="email">E-Mail*</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(formErrors.email)}
                aria-describedby={formErrors.email ? 'email-error' : undefined}
              />
              {formErrors.email && (
                <span id="email-error" className={styles.error}>
                  {formErrors.email}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="topic">Thema</label>
              <select id="topic" name="topic" value={formData.topic} onChange={handleChange}>
                <option value="">Bitte auswählen</option>
                <option value="schlaf">Schlafoptimierung</option>
                <option value="rhythmus">Tagesrhythmus</option>
                <option value="gesundheit">Gesundheitsgrundlagen</option>
                <option value="team">Team & Workshops</option>
                <option value="sonstiges">Sonstiges</option>
              </select>
            </div>

            <div className={styles.field}>
              <label htmlFor="message">Nachricht*</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(formErrors.message)}
                aria-describedby={formErrors.message ? 'message-error' : undefined}
              />
              {formErrors.message && (
                <span id="message-error" className={styles.error}>
                  {formErrors.message}
                </span>
              )}
            </div>

            <button type="submit" className="btnPrimary">
              Nachricht senden
            </button>
            {submitted && (
              <p className={styles.success}>
                Danke für Ihre Nachricht! Wir melden uns in Kürze.
              </p>
            )}
          </form>

          <aside className={styles.info}>
            <div className={styles.infoCard}>
              <h2>Direktkontakt</h2>
              <p>
                E-Mail:{' '}
                <a href="mailto:hello@raventolira.site">hello@raventolira.site</a>
                <br />
                Telefon:{' '}
                <a href="tel:+491234567890">+49 123 456 7890</a>
              </p>
              <p>Wir sind montags bis freitags von 9–17 Uhr erreichbar.</p>
            </div>

            <div className={styles.infoCard}>
              <h2>Standort & Räume</h2>
              <p>
                Unsere Sessions finden virtuell oder in unseren Räumen in Berlin-Prenzlauer
                Berg statt – eine Oase für achtsame Begegnungen.
              </p>
              <img
                src="https://picsum.photos/800/600?random=61"
                alt="Beratungsraum von Raventolira"
                loading="lazy"
              />
            </div>
          </aside>
        </div>
      </section>
    </>
  );
};

export default Contact;