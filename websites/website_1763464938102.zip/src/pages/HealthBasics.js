import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ServiceDetail.module.css';

const HealthBasics = () => (
  <>
    <Helmet>
      <title>Gesundheitsgrundlagen – Raventolira</title>
      <meta
        name="description"
        content="Gesundheitsgrundlagen bei Raventolira: Natürliche Gewohnheiten für Ernährung, Bewegung, Atmung und mentale Hygiene."
      />
    </Helmet>

    <section className={`${styles.section} container`}>
      <div className={styles.header}>
        <h1>Gesundheitsgrundlagen</h1>
        <p>
          Gesundheit entsteht aus vielen kleinen Entscheidungen. Wir vermitteln verständliches Wissen,
          das Sie sofort anwenden können – für ein stabiles Fundament aus Ernährung, Bewegung, Atmung
          und mentaler Hygiene.
        </p>
      </div>

      <div className={styles.grid}>
        <article className={styles.card}>
          <h2>Schwerpunkte</h2>
          <ul>
            <li>Natürliche Energiequellen & stabile Mahlzeitenrhythmen</li>
            <li>Körperwahrnehmung, Atmung und sanfte Bewegungseinheiten</li>
            <li>Stressbalance und mentale Erholung</li>
            <li>Reflexion, Journaling und Selbstfürsorge</li>
          </ul>
        </article>
        <article className={`${styles.card} ${styles.highlight}`}>
          <h2>Materialien</h2>
          <p>
            Rezeptkarten, Bewegungsflows, Atemmeditationen, Reflexionshefte und Micro-Challenges
            für jeden Alltag.
          </p>
        </article>
      </div>
    </section>

    <section className={`${styles.section} ${styles.sectionAlt}`}>
      <div className="container">
        <h2>Natürliche Evolution</h2>
        <p>
          Wir fördern eine Haltung, die Neugier und Selbstwirksamkeit stärkt. Kleine Experimente
          zeigen, wie viel Kraft in einfachen Routinen steckt.
        </p>
        <ul className={styles.list}>
          <li>
            <strong>Resilienz-Rituale:</strong> Kurze Übungen zur Stressentlastung im Alltag.
          </li>
          <li>
            <strong>Ernährungs-Impulse:</strong> Struktur für Mahlzeiten ohne starre Regeln.
          </li>
          <li>
            <strong>Selbstfürsorge-Pläne:</strong> Individuell gestaltete Wochenübersichten.
          </li>
        </ul>
      </div>
    </section>
  </>
);

export default HealthBasics;