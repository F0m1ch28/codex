import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Allgemeine Geschäftsbedingungen – Raventolira</title>
      <meta
        name="description"
        content="Allgemeine Geschäftsbedingungen von Raventolira für Coaching- und Workshopangebote."
      />
    </Helmet>

    <section className={`${styles.section} container`}>
      <h1>Allgemeine Geschäftsbedingungen</h1>

      <article className={styles.block}>
        <h2>1. Geltungsbereich</h2>
        <p>
          Diese AGB gelten für alle Leistungen von Raventolira, einschließlich Coaching, Workshops und digitalen Formaten.
        </p>
      </article>

      <article className={styles.block}>
        <h2>2. Leistungen & Durchführung</h2>
        <p>
          Umfang, Art und Dauer der Leistungen richten sich nach individuellen Vereinbarungen und Angebotsbeschreibungen.
          Unsere Arbeit ersetzt keine medizinische oder therapeutische Behandlung.
        </p>
      </article>

      <article className={styles.block}>
        <h2>3. Teilnahmevoraussetzungen</h2>
        <p>
          Die Teilnahme erfolgt eigenverantwortlich. Teilnehmende verpflichten sich, relevante gesundheitliche Einschränkungen
          im Vorfeld mitzuteilen.
        </p>
      </article>

      <article className={styles.block}>
        <h2>4. Terminabsagen</h2>
        <p>
          Vereinbarte Termine können bis 24 Stunden vor Beginn kostenfrei verschoben werden. Danach behalten wir uns vor,
          den Termin vollumfänglich in Rechnung zu stellen.
        </p>
      </article>

      <article className={styles.block}>
        <h2>5. Haftung</h2>
        <p>
          Raventolira haftet nur für Schäden, die auf vorsätzlichem oder grob fahrlässigem Verhalten beruhen.
        </p>
      </article>

      <article className={styles.block}>
        <h2>6. Schlussbestimmungen</h2>
        <p>
          Es gilt deutsches Recht. Gerichtsstand ist Berlin. Änderungen dieser AGB werden in Textform mitgeteilt.
        </p>
      </article>
    </section>
  </>
);

export default Terms;