import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './NotFound.module.css';

const NotFound = () => (
  <>
    <Helmet>
      <title>Seite nicht gefunden – Raventolira</title>
    </Helmet>

    <section className={styles.section}>
      <div className="container">
        <div className={styles.wrapper}>
          <span className={styles.code}>404</span>
          <h1>Diese Seite konnten wir leider nicht finden.</h1>
          <p>
            Vielleicht haben Sie sich vertippt oder die Seite wurde verschoben. Kehren Sie zur Startseite zurück
            oder entdecken Sie unsere Leistungen.
          </p>
          <div className={styles.actions}>
            <Link to="/" className="btnPrimary">
              Zur Startseite
            </Link>
            <Link to="/leistungen" className="btnGhost">
              Leistungen ansehen
            </Link>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default NotFound;