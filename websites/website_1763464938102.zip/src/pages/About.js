import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const milestones = [
  {
    year: '2018',
    title: 'Gründung von Raventolira',
    description:
      'Aus persönlichen Schlafreisen und Beratungen wuchs der Wunsch, nachhaltige, natürliche Methoden zugänglich zu machen.'
  },
  {
    year: '2020',
    title: 'Erweiterung um Teamformate',
    description:
      'Wir entwickelten kollektive Lernformate für Organisationen, die gesundheitsorientierte Kultur leben möchten.'
  },
  {
    year: '2022',
    title: 'Digitale Lernbibliothek',
    description:
      'Entstehung einer Sammlung aus Audioübungen, Reflexionskarten und Mikrogewohnheiten für den Alltag.'
  }
];

const values = [
  {
    title: 'Achtsamkeit & Mitgefühl',
    text: 'Wir respektieren persönliche Grenzen und schaffen Raum, um eigene Bedürfnisse neu kennenzulernen.'
  },
  {
    title: 'Wissenschaft & Intuition',
    text: 'Moderne Erkenntnisse aus Chronobiologie und Neurowissenschaft verbinden wir mit Körpergefühl und Intuition.'
  },
  {
    title: 'Nachhaltigkeit & Alltagstauglichkeit',
    text: 'Veränderungen sollen bleiben. Deshalb gestalten wir kleine Schritte, die in Ihren Alltag passen.'
  }
];

const About = () => (
  <>
    <Helmet>
      <title>Über uns – Raventolira</title>
      <meta
        name="description"
        content="Lernen Sie das Team von Raventolira kennen. Wir begleiten Menschen und Teams dabei, Schlaf, Rhythmus und Gesundheit mit natürlichen Methoden zu balancieren."
      />
    </Helmet>

    <section className={`${styles.section} container`}>
      <div className={styles.intro}>
        <p className={styles.pretitle}>Über Raventolira</p>
        <h1>Wir glauben an natürliche Balance.</h1>
        <p>
          Raventolira wurde aus der Überzeugung geboren, dass Schlaf, Tagesrhythmus und
          Gesundheit untrennbar miteinander verbunden sind. Wir sehen jede Person als
          Expert:in ihres eigenen Lebens und ergänzen dieses Wissen mit sanften Impulsen,
          beobachtender Begleitung und einem Fokus auf Regeneration.
        </p>
      </div>

      <div className={styles.grid}>
        <article className={styles.card}>
          <h2>Unsere Mission</h2>
          <p>
            Wir gestalten sichere Räume, in denen Menschen ihre Bedürfnisse erkunden,
            Ressourcen entdecken und Routinen etablieren, die ohne Medikamente auskommen
            und trotzdem realistisch im Alltag funktionieren.
          </p>
        </article>

        <article className={styles.card}>
          <h2>Unsere Expertise</h2>
          <ul>
            <li>Schlafcoaching, Chronobiologie & Stresskompetenz</li>
            <li>Körperarbeit, Atmung und sensorische Regulation</li>
            <li>New-Work-Strukturen und gesundheitsorientierte Teamführung</li>
            <li>Design von Lernreisen & Habit-Design</li>
          </ul>
        </article>
      </div>
    </section>

    <section className={`${styles.section} ${styles.timelineSection}`}>
      <div className="container">
        <h2 className={styles.sectionTitle}>Meilensteine</h2>
        <div className={styles.timeline}>
          {milestones.map((milestone) => (
            <article key={milestone.year} className={styles.timelineItem}>
              <span className={styles.timelineYear}>{milestone.year}</span>
              <h3>{milestone.title}</h3>
              <p>{milestone.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`${styles.section} container`}>
      <h2 className={styles.sectionTitle}>Unsere Werte</h2>
      <div className={styles.valuesGrid}>
        {values.map((value) => (
          <article key={value.title} className={styles.valueCard}>
            <h3>{value.title}</h3>
            <p>{value.text}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={`${styles.section} ${styles.approachSection}`}>
      <div className="container">
        <div className={styles.approachGrid}>
          <div>
            <h2 className={styles.sectionTitle}>Unsere Haltung</h2>
            <p>
              Wir begleiten Menschen, keine Projekte. Deshalb hören wir zu, stellen Fragen
              und beobachten, wie Körper und Geist auf kleine Veränderungen reagieren. Wir
              arbeiten ressourcenorientiert, vielfältig und frei von Normen.
            </p>
          </div>
          <div className={styles.approachList}>
            <div>
              <h3>Co-Kreation</h3>
              <p>
                Wir entwickeln Lösungswege gemeinsam – angepasst an Lebensrealitäten, Bedürfnisse
                und Ziele.
              </p>
            </div>
            <div>
              <h3>Transparenz</h3>
              <p>
                Jede Übung, jede Empfehlung begründen wir. So verstehen Sie, warum etwas wirkt
                und können langfristig selbstständig agieren.
              </p>
            </div>
            <div>
              <h3>Reflexion</h3>
              <p>
                Regelmäßige Check-ins helfen, Fortschritte sichtbar zu machen und Feinjustierungen
                vorzunehmen.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default About;