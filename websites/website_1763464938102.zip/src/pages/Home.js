import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const statsData = [
  { label: 'zufriedene Teilnehmer:innen', value: 280 },
  { label: 'stabilisierte Schlafroutinen', value: 450 },
  { label: 'Workshops pro Jahr', value: 38 }
];

const services = [
  {
    title: 'Schlafoptimierung',
    description:
      'Strukturierte Routinen, Reflexion von Schlafgewohnheiten und bewusste Entspannungspausen bringen Ruhe in Ihre Nacht.',
    to: '/schlaf-optimierung'
  },
  {
    title: 'Tagesrhythmus',
    description:
      'Achtsame Planung von Tageszyklen, Aktivitätsfenstern und Pausen stärkt Ihren inneren Kompass für Energie und Gelassenheit.',
    to: '/tagesrhythmus'
  },
  {
    title: 'Gesundheitsgrundlagen',
    description:
      'Verstehen Sie natürliche Bedürfnisse, bauen Sie Rituale auf und lernen Sie, Regeneration bewusst zu gestalten.',
    to: '/gesundheitsgrundlagen'
  }
];

const processSteps = [
  {
    title: 'Ankommen & Beobachten',
    text: 'Wir sammeln Eindrücke, sprechen über Ihren Alltag und identifizieren Muster, die Ihren Schlaf und Ihren Rhythmus beeinflussen.'
  },
  {
    title: 'Struktur & Rituale',
    text: 'Auf Basis der Analyse gestalten wir neue Routinen, die sich organisch in Ihren Tag einfügen und Ihren Körper respektieren.'
  },
  {
    title: 'Integration & Feinschliff',
    text: 'Durch achtsame Reflexion, Monitoring und kleine Anpassungen bleiben Ihre neuen Gewohnheiten nachhaltig.'
  }
];

const testimonials = [
  {
    quote:
      'Die sanfte Vorgehensweise half mir, meine Schlafgewohnheiten zu verstehen, ohne mich unter Druck zu setzen. Ich schlafe wieder ruhig und wache erfrischt auf.',
    name: 'Leonie M.',
    role: 'Freiberufliche Designerin'
  },
  {
    quote:
      'Unser Team hat gelernt, Pausen bewusster einzubauen. Die Workshops waren praxisnah, empathisch und haben langfristig gewirkt.',
    name: 'Henrik M.',
    role: 'Teamleitung Softwareentwicklung'
  },
  {
    quote:
      'Mein Tagesrhythmus ist heute klar strukturiert. Besonders schätze ich die realistischen Schritte, die sich gut mit Familie und Job vereinbaren lassen.',
    name: 'Sven M.',
    role: 'Projektmanager'
  }
];

const teamMembers = [
  {
    name: 'Mara Kieser',
    role: 'Gründerin & Schlafcoach',
    focus: 'Schlafbiografien verstehen und nächtliche Regeneration fördern.',
    image: 'https://picsum.photos/400/400?random=31'
  },
  {
    name: 'Jonas Feld',
    role: 'Rhythmusberater',
    focus: 'Achtsame Tagesstrukturen und natürliche Zeitanker etablieren.',
    image: 'https://picsum.photos/400/400?random=32'
  },
  {
    name: 'Carla Nguyen',
    role: 'Balance Trainerin',
    focus: 'Mikropausen, Atmung und körperliche Ausrichtung im Alltag.',
    image: 'https://picsum.photos/400/400?random=33'
  }
];

const projects = [
  {
    title: 'Abendrituale in Start-ups',
    category: 'Teams',
    description:
      'Einführung ruhiger Abschlussrituale in einem wachsenden Tech-Unternehmen zur Entlastung nach intensiven Sprints.',
    image: 'https://picsum.photos/1200/800?random=41'
  },
  {
    title: 'Familienfreundlicher Morgen',
    category: 'Familien',
    description:
      'Strukturierter Morgenplan, der Eltern und Kindern gleichermaßen Sicherheit und Zeit für sich selbst schenkt.',
    image: 'https://picsum.photos/1200/800?random=42'
  },
  {
    title: 'Achtsame Schichtarbeit',
    category: 'Pflege',
    description:
      'Begleitung eines Pflege-Teams zur Stabilisierung von Schlafrhythmen trotz wechselnder Arbeitszeiten.',
    image: 'https://picsum.photos/1200/800?random=43'
  },
  {
    title: 'Remote Balance Guide',
    category: 'Teams',
    description:
      'Digitales Coaching für remote Teams, um Pausen, Licht und Bewegung bewusst in den Alltag einzubauen.',
    image: 'https://picsum.photos/1200/800?random=44'
  }
];

const faqItems = [
  {
    question: 'Brauche ich medizinisches Vorwissen für die Zusammenarbeit?',
    answer:
      'Nein. Wir vermitteln verständliche Grundlagen, reflektieren Ihren Alltag und unterstützen Sie dabei, passende Routinen aufzubauen. Medizinische Beratung ersetzen wir nicht.'
  },
  {
    question: 'Wie lange dauert ein Begleitprozess?',
    answer:
      'Je nach Zielsetzung gestalten wir kurze Intensivphasen von wenigen Wochen oder längere Begleitungen über mehrere Monate. Wir entwickeln gemeinsame Meilensteine.'
  },
  {
    question: 'Kann ich auch nur einzelne Workshops buchen?',
    answer:
      'Ja. Unsere Lernformate sind modular aufgebaut. Einzelne Workshops geben Impulse, wiederkehrende Sessions sichern nachhaltige Veränderungen.'
  },
  {
    question: 'Sind die Inhalte auch digital verfügbar?',
    answer:
      'Viele Übungen sind digital abrufbar. Ergänzend erhalten Sie Checklisten, Audioübungen und Reflexionsvorlagen für Ihren Alltag.'
  }
];

const blogPosts = [
  {
    title: '7 Impulse für mehr Abendruhe ohne Geräteverzicht',
    excerpt:
      'Wie Sie Ihr Nervensystem im Abendverlauf beruhigen können, ohne starre Regeln zu befolgen – mit kleinen, machbaren Ideen.',
    date: '12. März 2024',
    image: 'https://picsum.photos/800/600?random=51',
    to: '/schlaf-optimierung'
  },
  {
    title: 'Chronotypen verstehen und den Tag bewusst strukturieren',
    excerpt:
      'Warum Ihr Energiegefühl schwankt und wie persönliche Zeitfenster helfen, Leistung und Pausen in Einklang zu bringen.',
    date: '22. Februar 2024',
    image: 'https://picsum.photos/800/600?random=52',
    to: '/tagesrhythmus'
  },
  {
    title: 'Die Kraft von Mikrogewohnheiten',
    excerpt:
      'Wie kleine, natürliche Rituale Ihr Immunsystem, die Verdauung und die Stressbalance positiv beeinflussen können.',
    date: '6. Januar 2024',
    image: 'https://picsum.photos/800/600?random=53',
    to: '/gesundheitsgrundlagen'
  }
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [statsValues, setStatsValues] = useState(statsData.map(() => 0));
  const [statsAnimated, setStatsAnimated] = useState(false);
  const [projectFilter, setProjectFilter] = useState('Alle');
  const [heroLoaded, setHeroLoaded] = useState(false);
  const statsRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !statsAnimated) {
          setStatsAnimated(true);
        }
      },
      { threshold: 0.4 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => {
      if (statsRef.current) {
        observer.unobserve(statsRef.current);
      }
    };
  }, [statsAnimated]);

  useEffect(() => {
    if (!statsAnimated) return undefined;

    let animationFrame;
    const duration = 2200;
    const start = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - start) / duration, 1);
      const updatedValues = statsData.map((stat) =>
        Math.round(stat.value * progress)
      );
      setStatsValues(updatedValues);
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      } else {
        setStatsValues(statsData.map((stat) => stat.value));
      }
    };

    animationFrame = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame);
  }, [statsAnimated]);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    projectFilter === 'Alle'
      ? projects
      : projects.filter((project) => project.category === projectFilter);

  return (
    <>
      <Helmet>
        <title>Raventolira – Gesunder Schlaf & natürliche Balance</title>
        <meta
          name="description"
          content="Raventolira begleitet Sie dabei, Schlaf, Tagesrhythmus und grundlegende Gesundheit auf natürliche Weise zu stärken – ohne Medikamente, dafür mit Achtsamkeit und Struktur."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroMedia}>
          <img
            src="https://picsum.photos/1600/900?random=11"
            alt="Menschen genießen einen entspannten Morgen im natürlichen Licht"
            className={`${styles.heroImage} ${heroLoaded ? styles.loaded : ''}`}
            onLoad={() => setHeroLoaded(true)}
          />
          {!heroLoaded && <div className={styles.heroSkeleton} aria-hidden="true" />}
          <span className={styles.heroOverlay} aria-hidden="true" />
        </div>
        <div className={`container ${styles.heroContent}`}>
          <p className={styles.pretitle}>Ruhig. Natürlich. Verbunden.</p>
          <h1 className={styles.heroTitle}>
            Gesunder Schlaf & natürliche Gesundheit – ganz ohne Medizin.
          </h1>
          <p className={styles.heroSubtitle}>
            Wir zeigen Ihnen, wie achtsame Routinen, Licht, Bewegung und Pausen Ihren
            Schlaf vertiefen, den Tagesrhythmus harmonisieren und Ihre Grundgesundheit stärken.
          </p>

          <div className={styles.heroActions}>
            <Link to="/kontakt" className="btnPrimary" aria-label="Kontakt aufnehmen">
              Jetzt Gespräch vereinbaren
            </Link>
            <Link to="/ueber-uns" className="btnGhost">
              Mehr über Raventolira
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.statsSection} ref={statsRef}>
        <div className="container">
          <div className={styles.statsGrid} role="list" aria-label="Ergebnisse unserer Arbeit">
            {statsData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard} role="listitem">
                <span className={styles.statNumber}>{statsValues[index]}+</span>
                <p className={styles.statLabel}>{stat.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} container`} id="leistungen">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionPretitle}>Leistungen</p>
          <h2 className={styles.sectionTitle}>Natürliche Wege zu Ruhe, Rhythmus und Balance</h2>
          <p className={styles.sectionText}>
            Unsere Angebote bauen auf wissenschaftlich fundierten Erkenntnissen über Schlaf,
            chronobiologische Rhythmen und Regeneration – umgesetzt in alltagstaugliche Rituale
            und lebendige Lernformate.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <div className={styles.serviceIcon} aria-hidden="true">✶</div>
              <h3 className={styles.serviceTitle}>{service.title}</h3>
              <p className={styles.serviceDescription}>{service.description}</p>
              <Link to={service.to} className={styles.serviceLink}>
                Mehr erfahren
                <span aria-hidden="true">→</span>
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.methodsSection}`}>
        <div className="container">
          <div className={styles.methodsGrid}>
            <div className={styles.methodsIntro}>
              <p className={styles.sectionPretitle}>Methoden</p>
              <h2 className={styles.sectionTitle}>Natürliche Ansätze ohne Medizin</h2>
              <p className={styles.sectionText}>
                Wir arbeiten mit Körperwissen, Chronobiologie, achtsamer Bewegung und wirksamen
                Reflexionsmethoden. So entsteht ein persönlicher Werkzeugkoffer, der frei von
                Medikamenten funktioniert und sich flexibel in Ihr Leben einfügt.
              </p>
              <ul className={styles.methodList}>
                <li>Individuelle Tageslicht- und Pausenplanung</li>
                <li>Mikrogewohnheiten für erholsame Übergänge</li>
                <li>Atemarbeit, sanfte Mobilisation und sensorische Erdung</li>
                <li>Journaling & Reflexionsfragen für Selbstwahrnehmung</li>
              </ul>
            </div>
            <div className={styles.processWrapper}>
              <div className={styles.processCards}>
                {processSteps.map((step, index) => (
                  <article key={step.title} className={styles.processCard}>
                    <span className={styles.processIndex}>{index + 1}</span>
                    <h3>{step.title}</h3>
                    <p>{step.text}</p>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} container`} id="erfahrungen">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionPretitle}>Erfahrungen</p>
          <h2 className={styles.sectionTitle}>Worte unserer Begleitungen</h2>
        </div>
        <div className={styles.testimonialCarousel}>
          <div
            className={styles.testimonialSlides}
            style={{ transform: `translateX(-${activeTestimonial * 100}%)` }}
          >
            {testimonials.map((testimonial) => (
              <blockquote key={testimonial.name} className={styles.testimonialCard}>
                <p className={styles.testimonialQuote}>“{testimonial.quote}”</p>
                <footer className={styles.testimonialMeta}>
                  <span className={styles.testimonialName}>{testimonial.name}</span>
                  <span className={styles.testimonialRole}>{testimonial.role}</span>
                </footer>
              </blockquote>
            ))}
          </div>
          <div className={styles.carouselControls} role="tablist" aria-label="Testimonials auswählen">
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                type="button"
                className={`${styles.carouselDot} ${idx === activeTestimonial ? styles.dotActive : ''}`}
                onClick={() => setActiveTestimonial(idx)}
                aria-label={`Erfahrung ${idx + 1} anzeigen`}
                aria-selected={idx === activeTestimonial}
                role="tab"
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.teamSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionPretitle}>Team</p>
            <h2 className={styles.sectionTitle}>Menschen hinter Raventolira</h2>
            <p className={styles.sectionText}>
              Ein interdisziplinäres Team aus Schlafcoaching, Ritualgestaltung und Körpersensibilität
              begleitet Sie durch Ihren Transformationsprozess.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img
                    src={member.image}
                    alt={`${member.name} – ${member.role}`}
                    loading="lazy"
                    className={styles.teamImage}
                  />
                  <span className={styles.teamOverlay} aria-hidden="true" />
                </div>
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p className={styles.teamFocus}>{member.focus}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.projectsSection}`}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <div>
              <p className={styles.sectionPretitle}>Projekte</p>
              <h2 className={styles.sectionTitle}>Praxisbeispiele & Lernreisen</h2>
            </div>
            <div className={styles.projectFilters} role="group" aria-label="Projektkategorien filtern">
              {['Alle', 'Teams', 'Familien', 'Pflege'].map((filter) => (
                <button
                  key={filter}
                  type="button"
                  className={`${styles.filterButton} ${projectFilter === filter ? styles.filterActive : ''}`}
                  onClick={() => setProjectFilter(filter)}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img
                    src={project.image}
                    alt={`${project.title} – Projekt von Raventolira`}
                    loading="lazy"
                    className={styles.projectImage}
                  />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.faqSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionPretitle}>FAQ</p>
            <h2 className={styles.sectionTitle}>Häufige Fragen & Antworten</h2>
          </div>
          <div className={styles.faqAccordion}>
            {faqItems.map((item, index) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>
                  <span>{item.question}</span>
                  <span aria-hidden="true">+</span>
                </summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.blogSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionPretitle}>Insights</p>
            <h2 className={styles.sectionTitle}>Aktuelle Impulse & Artikel</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImageWrapper}>
                  <img
                    src={post.image}
                    alt={post.title}
                    loading="lazy"
                    className={styles.blogImage}
                  />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.to} className={styles.blogLink}>
                    Weiterlesen <span aria-hidden="true">→</span>
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaContent}>
            <div>
              <h2>Bereit für ruhige Nächte und einen klaren Rhythmus?</h2>
              <p>
                In einem unverbindlichen Gespräch prüfen wir gemeinsam, welche Schritte
                Sie jetzt unterstützen – von individuellen Sessions bis zu Team-Workshops.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <Link to="/kontakt" className="btnPrimary">
                Kontakt aufnehmen
              </Link>
              <Link to="/leistungen" className="btnGhost">
                Leistungen entdecken
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;