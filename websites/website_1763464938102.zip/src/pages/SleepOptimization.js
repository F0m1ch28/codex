import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ServiceDetail.module.css';

const SleepOptimization = () => (
  <>
    <Helmet>
      <title>Schlafoptimierung – Raventolira</title>
      <meta
        name="description"
        content="Entdecken Sie die Schlafoptimierung von Raventolira. Lernen Sie, wie natürliche Routinen und sanfte Rituale Ihren Schlaf vertiefen."
      />
    </Helmet>

    <section className={`${styles.section} container`}>
      <div className={styles.header}>
        <h1>Schlafoptimierung</h1>
        <p>
          Schlaf ist kein Zufall, sondern das Ergebnis aus Rhythmen, Übergängen und innerer Sicherheit.
          Wir analysieren gemeinsam Ihre Abende, Nachtverläufe und Morgen, um neue Gewohnheiten
          aufzubauen, die beruhigen und erneuern.
        </p>
      </div>

      <div className={styles.grid}>
        <article className={styles.card}>
          <h2>Fokus der Begleitung</h2>
          <ul>
            <li>Analyse von Schlafmilieu, Routinen und individuellen Bedürfnissen</li>
            <li>Entwicklung beruhigender Ritualfolgen für Abend und Nacht</li>
            <li>Bewusstes Morgen-Design für einen klaren Start</li>
            <li>Achtsame Reflexion von Gedankenmustern rund um Schlaf</li>
          </ul>
        </article>
        <article className={`${styles.card} ${styles.highlight}`}>
          <h2>Formate</h2>
          <p>
            Individuelle Sessions, Schlafreisen für Paare, Mikroimpulse für Teams, digitale
            Audio- und Journal-Module zum Nachspüren.
          </p>
        </article>
      </div>
    </section>

    <section className={`${styles.section} ${styles.sectionAlt}`}>
      <div className="container">
        <h2>Was Sie mitnehmen</h2>
        <p>
          Tools, Strategien und Routinen, die Ihnen helfen, Abendruhe zu kultivieren, beruhigende
          Rituale zu verankern und Ihren Körper wieder als Verbündeten zu erleben.
        </p>
        <ul className={styles.list}>
          <li>
            <strong>Schlafjournal & Habit-Tracking:</strong> Bewusstes Wahrnehmen von Mustern
            und Fortschritten.
          </li>
          <li>
            <strong>Sensorische Impulse:</strong> Atemübungen, Körperreisen und sanfte Dehnungen.
          </li>
          <li>
            <strong>Morgenaktivierung:</strong> Licht, Bewegung und Mikroziele für einen stabilen Start.
          </li>
        </ul>
      </div>
    </section>
  </>
);

export default SleepOptimization;