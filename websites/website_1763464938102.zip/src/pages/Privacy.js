import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Datenschutz – Raventolira</title>
      <meta
        name="description"
        content="Datenschutzinformationen von Raventolira. Erfahren Sie, wie wir mit personenbezogenen Daten umgehen."
      />
    </Helmet>

    <section className={`${styles.section} container`}>
      <h1>Datenschutzerklärung</h1>
      <p className={styles.updated}>Zuletzt aktualisiert: 10. März 2024</p>

      <article className={styles.block}>
        <h2>1. Verantwortliche Stelle</h2>
        <p>
          Raventolira<br />
          Musterstraße 12<br />
          10405 Berlin<br />
          E-Mail: hello@raventolira.site
        </p>
      </article>

      <article className={styles.block}>
        <h2>2. Allgemeine Hinweise zur Datenverarbeitung</h2>
        <p>
          Wir verarbeiten personenbezogene Daten ausschließlich im Einklang mit den geltenden Datenschutzbestimmungen.
          Daten werden nur gespeichert, wenn dies zur Bereitstellung der Website, zur Kommunikation oder zur Erfüllung
          vertraglicher Pflichten erforderlich ist.
        </p>
      </article>

      <article className={styles.block}>
        <h2>3. Logfiles</h2>
        <p>
          Beim Aufruf unserer Website werden technische Informationen (z. B. IP-Adresse, Browser, Datum und Uhrzeit des Abrufs)
          vorübergehend gespeichert. Diese Daten dienen der Stabilität und Sicherheit der Website und werden nach spätestens
          14 Tagen gelöscht.
        </p>
      </article>

      <article className={styles.block}>
        <h2>4. Kontaktaufnahme</h2>
        <p>
          Wenn Sie uns kontaktieren, verarbeiten wir Ihre Angaben (z. B. Name, E-Mail-Adresse, Nachricht) zur Bearbeitung Ihres Anliegens.
          Die Daten werden gelöscht, sobald Ihr Anliegen abschließend beantwortet ist, sofern keine gesetzlichen Aufbewahrungspflichten bestehen.
        </p>
      </article>

      <article className={styles.block}>
        <h2>5. Ihre Rechte</h2>
        <ul>
          <li>Auskunft über die gespeicherten Daten</li>
          <li>Berichtigung unrichtiger Daten</li>
          <li>Löschung oder Einschränkung der Verarbeitung</li>
          <li>Widerspruch gegen Datenverarbeitung</li>
          <li>Datenübertragbarkeit</li>
        </ul>
        <p>
          Sie haben außerdem das Recht, sich bei einer Datenschutzaufsichtsbehörde zu beschweren.
        </p>
      </article>
    </section>
  </>
);

export default Privacy;