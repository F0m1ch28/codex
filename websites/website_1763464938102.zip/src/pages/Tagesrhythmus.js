import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ServiceDetail.module.css';

const Tagesrhythmus = () => (
  <>
    <Helmet>
      <title>Tagesrhythmus – Raventolira</title>
      <meta
        name="description"
        content="Stärken Sie Ihren Tagesrhythmus mit Raventolira: Strukturierte Tageszyklen, Pausen und Lichtgestaltung für natürliche Energie."
      />
    </Helmet>

    <section className={`${styles.section} container`}>
      <div className={styles.header}>
        <h1>Tagesrhythmus</h1>
        <p>
          Ihr innerer Takt entscheidet darüber, wie Sie Energie nutzen, regenerieren und fokussiert bleiben.
          Wir gestalten Tagesstrukturen, die mit Ihrem Chronotyp harmonieren und Raum für Regeneration lassen.
        </p>
      </div>

      <div className={styles.grid}>
        <article className={styles.card}>
          <h2>Inhalte</h2>
          <ul>
            <li>Chronotypen-Analyse & persönliche Leistungsfenster</li>
            <li>Lichtmanagement, Bewegung und Pausenrituale</li>
            <li>Digitale Hygiene & Fokusblöcke für konzentriertes Arbeiten</li>
            <li>Integration von Erholung in Familien- und Teamkontexte</li>
          </ul>
        </article>
        <article className={`${styles.card} ${styles.highlight}`}>
          <h2>Umsetzung</h2>
          <p>
            Workshops, Teamtrainings und 1:1-Begleitungen – ergänzt durch Routinen-Pläne, Check-ins
            und Reflexionsimpulse für zu Hause.
          </p>
        </article>
      </div>
    </section>

    <section className={`${styles.section} ${styles.sectionAlt}`}>
      <div className="container">
        <h2>Ergebnisse</h2>
        <p>
          Ein klarer Tageskompass, bewusste Pausezeichen und Selbstmanagement-Werkzeuge, die Stressresilienz
          fördern und langfristig tragfähig bleiben.
        </p>
        <ul className={styles.list}>
          <li>
            <strong>Rhythmusboards:</strong> Visualisierungen Ihrer Tageszyklen mit Fokus- und Ruhezeiten.
          </li>
          <li>
            <strong>Pausenbibliothek:</strong> Mikro-Übungen für verschiedene Situationen.
          </li>
          <li>
            <strong>Check-in-Fragen:</strong> Reflexionstools für Teams und Einzelpersonen.
          </li>
        </ul>
      </div>
    </section>
  </>
);

export default Tagesrhythmus;