import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const Impressum = () => (
  <>
    <Helmet>
      <title>Impressum – Raventolira</title>
      <meta
        name="description"
        content="Impressum von Raventolira. Anbieterkennzeichnung gemäß §5 TMG."
      />
    </Helmet>

    <section className={`${styles.section} container`}>
      <h1>Impressum</h1>
      <article className={styles.block}>
        <h2>Angaben gemäß § 5 TMG</h2>
        <p>
          Raventolira<br />
          Mara Kieser<br />
          Musterstraße 12<br />
          10405 Berlin
        </p>
      </article>

      <article className={styles.block}>
        <h2>Kontakt</h2>
        <p>
          Telefon: +49 123 456 7890<br />
          E-Mail: hello@raventolira.site
        </p>
      </article>

      <article className={styles.block}>
        <h2>Umsatzsteuer-ID</h2>
        <p>Umsatzsteuer-Identifikationsnummer gemäß §27 a Umsatzsteuergesetz: DE123456789</p>
      </article>

      <article className={styles.block}>
        <h2>Berufsbezeichnung</h2>
        <p>
          Gesundheitscoach (nichtärztlich). Es erfolgt keine medizinische Beratung, Diagnose oder Behandlung.
        </p>
      </article>

      <article className={styles.block}>
        <h2>Haftung für Inhalte</h2>
        <p>
          Wir bemühen uns um aktuelle und richtige Informationen. Für Inhalte externer Links übernehmen wir keine Haftung;
          für den Inhalt der verlinkten Seiten sind ausschließlich deren Betreiber verantwortlich.
        </p>
      </article>
    </section>
  </>
);

export default Impressum;