import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'consonragp_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p className={styles.message}>
          We use cookies to optimise your experience, analyse traffic, and ensure compliance with Belgian and EU privacy laws. Read our{' '}
          <a href="/cookie-policy" className={styles.link}>Cookie Policy</a>.
        </p>
        <button type="button" className={styles.button} onClick={acceptCookies}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;