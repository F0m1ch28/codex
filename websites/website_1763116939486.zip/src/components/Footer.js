import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.column}>
          <p className={styles.brand}>Consonragp Legal Partners</p>
          <p className={styles.text}>
            Avenue Louise 250<br />
            1050 Brussels, Belgium
          </p>
          <p className={styles.text}>
            <a className={styles.link} href="tel:+3221234567">
              +32 2 123 4567
            </a>
            <br />
            <a className={styles.link} href="mailto:contact@consonragp.com">
              contact@consonragp.com
            </a>
          </p>
          <p className={styles.text}>
            Registered attorneys serving corporate clients across Belgium and the European Union.
          </p>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Navigation</h3>
          <ul className={styles.list}>
            <li><Link to="/" className={styles.link}>Home</Link></li>
            <li><Link to="/services" className={styles.link}>Services</Link></li>
            <li><Link to="/about" className={styles.link}>About</Link></li>
            <li><Link to="/contact" className={styles.link}>Contact</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Legal</h3>
          <ul className={styles.list}>
            <li><Link to="/terms" className={styles.link}>Terms of Service</Link></li>
            <li><Link to="/privacy" className={styles.link}>Privacy Policy</Link></li>
            <li><Link to="/cookie-policy" className={styles.link}>Cookie Policy</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Professional Memberships</h3>
          <ul className={styles.list}>
            <li>Brussels Bar Association</li>
            <li>International Bar Association</li>
            <li>European Employment Lawyers Association</li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        © {new Date().getFullYear()} Consonragp Legal Partners. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;