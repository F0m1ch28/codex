import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import Home from './pages/Home';
import Services from './pages/Services';
import About from './pages/About';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import styles from './App.module.css';

const App = () => {
  return (
    <div className={styles.app}>
      <Helmet>
        <html lang="en" />
        <title>Consonragp Legal Partners | Law Firm Belgium</title>
        <meta
          name="description"
          content="Consonragp Legal Partners is a Brussels-based law firm delivering corporate counsel, commercial litigation, employment law, and contract advisory services across Belgium and Europe."
        />
      </Helmet>
      <Header />
      <main id="mainContent" className={styles.main}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
};

export default App;