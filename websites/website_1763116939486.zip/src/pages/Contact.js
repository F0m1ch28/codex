import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact Consonragp Legal Partners | Brussels Attorneys</title>
        <meta
          name="description"
          content="Contact Consonragp Legal Partners in Brussels for corporate law, commercial litigation, employment law, and contract advisory services."
        />
      </Helmet>
      <header className={styles.hero}>
        <h1>Contact Us</h1>
        <p>
          Engage with our Brussels legal team to discuss corporate counsel, commercial litigation strategy, employment law matters, or contract advisory needs. We respond promptly to requests from corporate clients across Belgium and Europe.
        </p>
      </header>

      <section className={styles.content}>
        <div className={styles.formWrapper}>
          <h2>Send a Message</h2>
          <form onSubmit={handleSubmit} className={styles.form}>
            <label htmlFor="name">Full Name</label>
            <input id="name" name="name" type="text" required placeholder="Your full name" />

            <label htmlFor="email">Email Address</label>
            <input id="email" name="email" type="email" required placeholder="you@company.com" />

            <label htmlFor="company">Company / Organisation</label>
            <input id="company" name="company" type="text" placeholder="Company or organisation name" />

            <label htmlFor="message">How can we assist you?</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              required
              placeholder="Briefly describe your legal priorities."
            />

            <button type="submit" className={styles.submitButton}>
              Submit
            </button>

            {submitted && (
              <p className={styles.successMessage}>
                Thank you for contacting Consonragp Legal Partners. A member of our team will reach out shortly.
              </p>
            )}
          </form>
        </div>

        <div className={styles.details}>
          <div className={styles.card}>
            <h2>Office Details</h2>
            <p>
              Avenue Louise 250<br />
              1050 Brussels, Belgium
            </p>
            <p>
              <a href="tel:+3221234567" className={styles.link}>
                +32 2 123 4567
              </a>
              <br />
              <a href="mailto:contact@consonragp.com" className={styles.link}>
                contact@consonragp.com
              </a>
            </p>
            <p>
              Business hours: Monday – Friday, 09:00 to 18:00 CET
            </p>
          </div>
          <div className={styles.card}>
            <h2>Map</h2>
            <div className={styles.mapWrapper}>
              <iframe
                title="Consonragp Legal Partners Office Location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2519.396467235082!2d4.356277515747712!3d50.82545297952833!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c3c49a16f5f60d%3A0x497176f2f47cb4aa!2sAvenue%20Louise%20250%2C%201050%20Bruxelles%2C%20Belgique!5e0!3m2!1sen!2sbe!4v1688289600000!5m2!1sen!2sbe"
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
          <div className={styles.card}>
            <h2>Key Contacts</h2>
            <ul>
              <li>
                Claire Demeester, Managing Partner<br />
                <a href="mailto:claire.demeester@consonragp.com" className={styles.link}>
                  claire.demeester@consonragp.com
                </a>
              </li>
              <li>
                Thomas Verbruggen, Litigation Partner<br />
                <a href="mailto:thomas.verbruggen@consonragp.com" className={styles.link}>
                  thomas.verbruggen@consonragp.com
                </a>
              </li>
              <li>
                Sofia Lemaire, Employment Law Partner<br />
                <a href="mailto:sofia.lemaire@consonragp.com" className={styles.link}>
                  sofia.lemaire@consonragp.com
                </a>
              </li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;