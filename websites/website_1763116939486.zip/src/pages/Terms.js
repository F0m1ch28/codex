import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Terms of Service | Consonragp Legal Partners</title>
        <meta
          name="description"
          content="Terms of service for Consonragp Legal Partners' legal services in Belgium and Europe."
        />
      </Helmet>
      <h1>Terms of Service</h1>
      <p>Last updated: 1 July 2024</p>

      <section>
        <h2>1. Introduction</h2>
        <p>
          These terms govern the use of the website consonragp.com and the professional services provided by Consonragp Legal Partners, Avenue Louise 250, 1050 Brussels, Belgium. By accessing our website or engaging with our attorneys, you agree to comply with the following conditions in accordance with Belgian legislation and applicable EU directives.
        </p>
      </section>

      <section>
        <h2>2. Professional Services</h2>
        <p>
          Legal services are rendered in accordance with the ethical rules of the Brussels Bar Association. Engagements are confirmed through an engagement letter specifying the scope of work, responsible attorneys, and applicable general terms.
        </p>
      </section>

      <section>
        <h2>3. Confidentiality</h2>
        <p>
          All information shared by clients is treated as confidential and protected by attorney-client privilege under Belgian law. We maintain secure systems and internal protocols to safeguard client material.
        </p>
      </section>

      <section>
        <h2>4. Liability</h2>
        <p>
          Professional liability is insured in accordance with the mandatory coverage required by the Brussels Bar. Our liability is limited to the amount covered by our insurance policy, except in cases where Belgian legislation prohibits such limitation.
        </p>
      </section>

      <section>
        <h2>5. Intellectual Property</h2>
        <p>
          Content published on this website, including articles, briefings, and design elements, is protected by intellectual property laws. Any reproduction requires prior written consent from Consonragp Legal Partners.
        </p>
      </section>

      <section>
        <h2>6. Governing Law and Jurisdiction</h2>
        <p>
          These terms are governed by Belgian law. Any dispute arising from these terms shall be submitted to the courts of Brussels, without prejudice to mandatory applicable rules of European law.
        </p>
      </section>

      <section>
        <h2>7. Updates</h2>
        <p>
          We may update these terms to reflect changes in legislation or our internal policies. The revised version will be indicated by the updated date and will be effective immediately upon publication.
        </p>
      </section>

      <section>
        <h2>8. Contact</h2>
        <p>
          Questions regarding these terms may be directed to Consonragp Legal Partners, Avenue Louise 250, 1050 Brussels, Belgium, or via email at contact@consonragp.com.
        </p>
      </section>
    </div>
  );
};

export default Terms;