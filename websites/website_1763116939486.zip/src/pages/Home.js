import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const services = [
  {
    title: 'Corporate Law',
    description:
      'Strategic corporate counsel covering governance, mergers and acquisitions, restructuring, and compliance with Belgian legislation and EU regulations.',
    link: '/services#corporate-law',
  },
  {
    title: 'Commercial Litigation',
    description:
      'Robust representation for complex cross-border disputes, arbitration, and enforcement actions across Belgian and European courts.',
    link: '/services#commercial-litigation',
  },
  {
    title: 'Employment Law',
    description:
      'Advisory and advocacy on employment law in Brussels, workforce restructuring, executive mobility, and collective bargaining matters.',
    link: '/services#employment-law',
  },
  {
    title: 'Contract Advisory',
    description:
      'Precision drafting, negotiation, and lifecycle management of high-value commercial agreements tailored to international business.',
    link: '/services#contract-advisory',
  },
];

const testimonials = [
  {
    quote:
      'Consonragp Legal Partners navigated sensitive competition law issues across multiple EU jurisdictions with clarity and discipline.',
    author: 'Chief Legal Officer, European Manufacturing Group',
  },
  {
    quote:
      'Their Brussels attorneys provided decisive dispute resolution strategy that safeguarded our operations and reputation.',
    author: 'General Counsel, Global Logistics Network',
  },
];

const Home = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Consonragp Legal Partners | Strategic Corporate Law Firm in Brussels</title>
        <meta
          name="description"
          content="Consonragp Legal Partners is a Brussels law firm delivering corporate law, commercial litigation, employment law, and contract advisory services to businesses in Belgium and across Europe."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.kicker}>Strategic Legal Counsel for Business Success</p>
          <h1 className={styles.title}>
            Brussels attorneys guiding corporations through Belgian and European law.
          </h1>
          <p className={styles.subtitle}>
            Consonragp Legal Partners provides corporate counsel, commercial litigation support, and employment law solutions for multinational enterprises and emerging innovators operating in Belgium.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contact" className={styles.primaryButton}>
              Arrange a Legal Consultation
            </Link>
            <Link to="/services" className={styles.secondaryButton}>
              Explore Legal Services
            </Link>
          </div>
          <div className={styles.heroBadges}>
            <span>Corporate Law</span>
            <span>International Dispute Resolution</span>
            <span>EU Regulatory Insight</span>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/seed/consonragp-hero/900/600"
            alt="Corporate legal professionals collaborating in a Brussels office"
            className={styles.heroImage}
          />
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Legal Services for Ambitious Businesses</h2>
          <p className={styles.sectionDescription}>
            Our Brussels law firm integrates sector knowledge with rigorous legal analysis, ensuring every matter aligns with Belgian legislation, European law directives, and global corporate objectives.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to={service.link} className={styles.serviceLink}>
                Learn more
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.aboutSection}>
        <div className={styles.aboutContent}>
          <h2>Dedicated to Excellence in Belgian and EU Law</h2>
          <p>
            Founded in Brussels, Consonragp Legal Partners advises boards, in-house counsel, and investors navigating sophisticated corporate transitions and regulatory scrutiny. Our multilingual attorneys operate in English, French, Dutch, and German, enabling seamless communication with stakeholders across Europe.
          </p>
          <p>
            We combine proactive risk assessment with responsive dispute resolution, ensuring continuity for businesses working within Belgium&rsquo;s dynamic market. From corporate restructurings to European competition law compliance, our team provides practical legal advisory aligned with strategic priorities.
          </p>
          <Link to="/about" className={styles.aboutLink}>
            Discover our firm
          </Link>
        </div>
        <img
          src="https://picsum.photos/seed/consonragp-boardroom/800/640"
          alt="Boardroom meeting at Consonragp Legal Partners office in Brussels"
          className={styles.aboutImage}
        />
      </section>

      <section className={styles.teamSection}>
        <h2>Leadership Team</h2>
        <div className={styles.teamGrid}>
          <div className={styles.teamCard}>
            <img
              src="https://picsum.photos/seed/consonragp-partner1/400/400"
              alt="Portrait of Claire Demeester, Managing Partner"
            />
            <h3>Claire Demeester</h3>
            <p>Managing Partner · Corporate Law &amp; Governance</p>
          </div>
          <div className={styles.teamCard}>
            <img
              src="https://picsum.photos/seed/consonragp-partner2/400/400"
              alt="Portrait of Thomas Verbruggen, Litigation Partner"
            />
            <h3>Thomas Verbruggen</h3>
            <p>Partner · Commercial Litigation &amp; Arbitration</p>
          </div>
          <div className={styles.teamCard}>
            <img
              src="https://picsum.photos/seed/consonragp-partner3/400/400"
              alt="Portrait of Sofia Lemaire, Employment Law Partner"
            />
            <h3>Sofia Lemaire</h3>
            <p>Partner · Employment Law &amp; Collective Relations</p>
          </div>
        </div>
        <p className={styles.teamNote}>
          Our attorneys are qualified before the Brussels Bar and collaborate with a trusted network of European law specialists.
        </p>
      </section>

      <section className={styles.testimonialsSection}>
        <h2>Trusted by Corporate Counsel Across Europe</h2>
        <div className={styles.testimonialsGrid}>
          {testimonials.map((testimonial) => (
            <blockquote key={testimonial.author} className={styles.testimonial}>
              <p>&ldquo;{testimonial.quote}&rdquo;</p>
              <footer>— {testimonial.author}</footer>
            </blockquote>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2>Advance Your Legal Strategy in Belgium</h2>
          <p>
            Engage with experienced Brussels attorneys for corporate law, commercial litigation, employment law, and contract advisory tailored to international operations. Our team provides actionable legal consultation for every stage of growth.
          </p>
          <Link to="/contact" className={styles.primaryButton}>
            Contact Consonragp Legal Partners
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;