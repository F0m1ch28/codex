import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    id: 'corporate-law',
    title: 'Corporate Law',
    summary:
      'Holistic corporate and commercial advisory to support strategic decision-making in Belgium and across the European Union.',
    points: [
      'Corporate governance, board advisory, and shareholder relations',
      'Mergers, acquisitions, joint ventures, and restructuring transactions',
      'Corporate secretarial services ensuring compliance with Belgian legislation',
      'Regulatory filings and coordination with European supervisory authorities',
    ],
  },
  {
    id: 'commercial-litigation',
    title: 'Commercial Litigation',
    summary:
      'Resolute dispute resolution strategies tailored to complex cross-border litigation and arbitration.',
    points: [
      'Representation before Belgian courts and the Court of Justice of the European Union',
      'Arbitration under ICC, CEPANI, LCIA, and UNCITRAL rules',
      'Urgent interim relief, injunctions, and enforcement proceedings',
      'Settlement negotiation and alternative dispute resolution strategies',
    ],
  },
  {
    id: 'employment-law',
    title: 'Employment Law',
    summary:
      'Comprehensive employment law support in Brussels for employers managing local and international workforces.',
    points: [
      'Employment contracts, executive mobility, and expatriate frameworks',
      'Workforce restructuring, collective bargaining, and social dialogue',
      'Compliance with Belgian labour codes and European directives',
      'Representation in employment litigation and workplace investigations',
    ],
  },
  {
    id: 'contract-advisory',
    title: 'Contract Advisory',
    summary:
      'Precise contract drafting and negotiation safeguarding business-critical relationships.',
    points: [
      'Commercial, licensing, and distribution agreements',
      'Supply chain and outsourcing arrangements spanning multiple jurisdictions',
      'Contract lifecycle management and risk mitigation',
      'Legal advisory integrating Belgian law with international contract standards',
    ],
  },
];

const Services = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Legal Services | Consonragp Legal Partners Brussels</title>
        <meta
          name="description"
          content="Discover Consonragp Legal Partners' corporate law, commercial litigation, employment law, and contract advisory services for businesses in Belgium and across Europe."
        />
      </Helmet>
      <header className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Legal Services Anchored in Corporate Strategy</h1>
          <p>
            Consonragp Legal Partners delivers proactive counsel and decisive representation for businesses operating across Belgium and Europe. Our Brussels attorneys combine sector insight with rigorous legal analysis to deliver measurable outcomes.
          </p>
        </div>
      </header>
      <section className={styles.services}>
        {services.map((service) => (
          <article key={service.id} id={service.id} className={styles.card}>
            <h2>{service.title}</h2>
            <p>{service.summary}</p>
            <ul>
              {service.points.map((point) => (
                <li key={point}>{point}</li>
              ))}
            </ul>
          </article>
        ))}
      </section>
      <section className={styles.consultation}>
        <div className={styles.consultationContent}>
          <h2>Corporate Counsel with International Reach</h2>
          <p>
            Our legal advisory team partners with executives, in-house counsel, and investors to address regulatory shifts, cross-border disputes, and complex negotiations. We deliver tailored strategies grounded in Belgian law and harmonised with European legal frameworks.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Services;