import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Privacy Policy | Consonragp Legal Partners</title>
        <meta
          name="description"
          content="Privacy policy for Consonragp Legal Partners, outlining data protection practices in line with GDPR."
        />
      </Helmet>
      <h1>Privacy Policy</h1>
      <p>Last updated: 1 July 2024</p>

      <section>
        <h2>1. Introduction</h2>
        <p>
          Consonragp Legal Partners is committed to safeguarding personal data in accordance with the General Data Protection Regulation (GDPR), Belgian legislation, and professional secrecy obligations. This policy explains how we collect, use, and secure personal data.
        </p>
      </section>

      <section>
        <h2>2. Data Controller</h2>
        <p>
          Consonragp Legal Partners, Avenue Louise 250, 1050 Brussels, Belgium, is the data controller responsible for processing personal data collected through this website or during client engagements.
        </p>
      </section>

      <section>
        <h2>3. Data We Collect</h2>
        <ul>
          <li>Identification details such as name, job title, and contact information;</li>
          <li>Communications and documents shared with our attorneys;</li>
          <li>Website usage analytics collected through cookies (see Cookie Policy);</li>
          <li>Compliance information required by anti-money laundering regulations.</li>
        </ul>
      </section>

      <section>
        <h2>4. Purpose of Processing</h2>
        <p>
          We process personal data to provide legal services, manage client relationships, comply with regulatory obligations, and maintain secure communications. Any processing is grounded in legitimate interest, contractual necessity, or legal obligation.
        </p>
      </section>

      <section>
        <h2>5. Data Sharing</h2>
        <p>
          Personal data may be shared with authorised partners or service providers assisting with legal mandates, subject to confidentiality and data protection agreements. International transfers occur only with adequate safeguards in place.
        </p>
      </section>

      <section>
        <h2>6. Data Retention</h2>
        <p>
          We retain personal data for the duration required by professional rules and statutory limitation periods. Retention periods are periodically reviewed to ensure compliance with Belgian and EU obligations.
        </p>
      </section>

      <section>
        <h2>7. Security Measures</h2>
        <p>
          We maintain technical and organisational measures to protect personal data against unauthorised access, alteration, or disclosure. These include secure servers, controlled access protocols, and regular audits.
        </p>
      </section>

      <section>
        <h2>8. Your Rights</h2>
        <p>
          Individuals have the right to access, rectify, erase, restrict, or object to the processing of their personal data, and to request data portability. Requests may be submitted to privacy@consonragp.com. You also have the right to lodge a complaint with the Belgian Data Protection Authority.
        </p>
      </section>

      <section>
        <h2>9. Updates</h2>
        <p>
          We may revise this policy to reflect changes in legal requirements or our practices. Updates will be published on this page with a revised effective date.
        </p>
      </section>
    </div>
  );
};

export default Privacy;