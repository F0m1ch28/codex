import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Cookie Policy | Consonragp Legal Partners</title>
        <meta
          name="description"
          content="Cookie policy outlining how Consonragp Legal Partners uses cookies on consonragp.com."
        />
      </Helmet>
      <h1>Cookie Policy</h1>
      <p>Last updated: 1 July 2024</p>

      <section>
        <h2>1. Introduction</h2>
        <p>
          This Cookie Policy explains how Consonragp Legal Partners uses cookies and similar technologies on consonragp.com. We comply with Belgian and EU regulations governing electronic communications and data protection.
        </p>
      </section>

      <section>
        <h2>2. What Are Cookies?</h2>
        <p>
          Cookies are small text files stored on your device when you visit a website. They help us remember preferences, enhance security, and analyse website usage.
        </p>
      </section>

      <section>
        <h2>3. Types of Cookies We Use</h2>
        <ul>
          <li><strong>Essential cookies</strong> ensure basic site functionality and security.</li>
          <li><strong>Analytics cookies</strong> provide anonymised insights into website usage patterns to improve navigation and content.</li>
          <li><strong>Preference cookies</strong> remember language or accessibility settings you may select.</li>
        </ul>
      </section>

      <section>
        <h2>4. Managing Cookies</h2>
        <p>
          Upon your first visit, our cookie banner allows you to consent to non-essential cookies. You can adjust settings in your browser to block or delete cookies. Please note that disabling certain cookies may affect your browsing experience.
        </p>
      </section>

      <section>
        <h2>5. Third-Party Services</h2>
        <p>
          We may use third-party analytics providers bound by contractual obligations to handle data responsibly. Any transfer of data outside the European Economic Area occurs only with appropriate safeguards.
        </p>
      </section>

      <section>
        <h2>6. Updates</h2>
        <p>
          We may update this policy to reflect changes in technology or legal requirements. Please review this page periodically for the latest information.
        </p>
      </section>

      <section>
        <h2>7. Contact</h2>
        <p>
          For questions about our use of cookies, contact Consonragp Legal Partners at contact@consonragp.com.
        </p>
      </section>
    </div>
  );
};

export default CookiePolicy;