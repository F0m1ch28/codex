import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>About Consonragp Legal Partners | Brussels Law Firm</title>
        <meta
          name="description"
          content="Learn about Consonragp Legal Partners, a Brussels-based law firm delivering corporate counsel, commercial litigation, employment law, and contract advisory services."
        />
      </Helmet>
      <header className={styles.hero}>
        <h1>Our Story</h1>
        <p>
          Consonragp Legal Partners was established in Brussels to deliver decisive corporate legal services that align with board-level priorities. We believe in combining rigorous analysis with pragmatic implementation, empowering businesses to thrive within Belgian and European regulatory frameworks.
        </p>
      </header>

      <section className={styles.history}>
        <h2>History and Vision</h2>
        <p>
          Since our founding, we have advised multinational groups, scale-up innovators, sovereign entities, and financial institutions. Our firm is recognised for handling complex corporate transitions and guiding clients through European competition, regulatory, and employment landscapes.
        </p>
        <p>
          We operate from Avenue Louise, an international business district in Brussels, enabling immediate dialogue with EU institutions, regulators, and professional networks. Our attorneys are admitted to the Brussels Bar and maintain strong relationships with partner firms worldwide.
        </p>
      </section>

      <section className={styles.values}>
        <h2>Values that Define Us</h2>
        <div className={styles.valuesGrid}>
          <article>
            <h3>Strategic Partnership</h3>
            <p>
              We work alongside executive teams, integrating legal advisory into broader corporate strategy to safeguard governance and shareholder value.
            </p>
          </article>
          <article>
            <h3>International Perspective</h3>
            <p>
              Our multilingual team collaborates in English, French, Dutch, and German, ensuring seamless engagement with stakeholders across European jurisdictions.
            </p>
          </article>
          <article>
            <h3>Integrity and Accountability</h3>
            <p>
              Transparent communication, proactive risk assessment, and disciplined execution underpin every mandate we undertake.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.team}>
        <h2>Leadership Team</h2>
        <div className={styles.teamGrid}>
          <article>
            <h3>Claire Demeester</h3>
            <p>Managing Partner · Corporate Law &amp; Governance</p>
            <p>
              Claire leads our corporate practice, advising on mergers, joint ventures, and regulatory compliance. She has guided numerous cross-border restructurings involving Belgian and EU competition law considerations.
            </p>
          </article>
          <article>
            <h3>Thomas Verbruggen</h3>
            <p>Partner · Commercial Litigation &amp; Arbitration</p>
            <p>
              Thomas represents clients in complex disputes before Belgian courts and international tribunals. His experience spans construction, energy, and technology sectors with a focus on high-stakes arbitration.
            </p>
          </article>
          <article>
            <h3>Sofia Lemaire</h3>
            <p>Partner · Employment Law &amp; Collective Relations</p>
            <p>
              Sofia advises on workforce strategy, collective bargaining, and executive mobility. She frequently handles employment investigations and counsel for multinational employers expanding in Brussels.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.approach}>
        <h2>Integrated Approach</h2>
        <p>
          Our legal services combine corporate law, commercial litigation, employment law, and contract advisory into a cohesive offering. We collaborate closely with in-house counsel to deliver actionable legal consultation that anticipates issues before they escalate.
        </p>
        <p>
          Through continuous education and involvement in professional associations, our attorneys remain at the forefront of Belgian legislation, European law, and international developments impacting business lawyers.
        </p>
      </section>
    </div>
  );
};

export default About;