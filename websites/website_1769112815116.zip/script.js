(function () {
  const preferred = localStorage.getItem('jtpayPreferredLang');
  if (!preferred) {
    return;
  }
  const segments = window.location.pathname.split('/').filter(Boolean);
  if (segments.length === 0) {
    return;
  }
  const currentLang = segments[0];
  if ((currentLang === 'nl' || currentLang === 'en') && preferred !== currentLang) {
    const rest = segments.slice(1).join('/');
    const target = `/${preferred}/${rest || 'index.html'}`;
    window.location.replace(target);
  }
})();

document.addEventListener('DOMContentLoaded', () => {
  const root = document.documentElement;
  const lang = root.getAttribute('lang') === 'en' ? 'en' : 'nl';

  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');
  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      primaryNav.classList.toggle('is-active');
      navToggle.setAttribute('aria-expanded', primaryNav.classList.contains('is-active'));
    });
    primaryNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        primaryNav.classList.remove('is-active');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  document.querySelectorAll('.current-year').forEach((el) => {
    el.textContent = new Date().getFullYear();
  });

  const languageLinks = document.querySelectorAll('.language-switcher a');
  languageLinks.forEach((link) => {
    if (link.dataset.lang === lang) {
      link.classList.add('is-active');
      link.setAttribute('aria-current', 'true');
    }
    link.addEventListener('click', () => {
      const chosen = link.dataset.lang;
      if (chosen) {
        localStorage.setItem('jtpayPreferredLang', chosen);
      }
    });
  });

  const copy = {
    nl: {
      cookieMessage:
        'JT Pay gebruikt analytische cookies om bezoekersstromen te begrijpen en inhoud te verbeteren. Kies zelf of je daarmee instemt.',
      accept: 'Accepteren',
      decline: 'Weigeren',
      learnMore: 'Bekijk het cookiebeleid',
      toast: 'Bedankt voor je inzending. Je wordt nu doorgestuurd.',
    },
    en: {
      cookieMessage:
        'JT Pay applies analytical cookies to understand visitor patterns and enhance content quality. You decide whether to allow them.',
      accept: 'Accept',
      decline: 'Decline',
      learnMore: 'Review the cookie policy',
      toast: 'Thanks for your message. You will be redirected shortly.',
    },
  };

  const banner = document.querySelector('.cookie-banner');
  if (banner) {
    const messageEl = banner.querySelector('.cookie-message');
    const acceptBtn = banner.querySelector('.cookie-accept');
    const declineBtn = banner.querySelector('.cookie-decline');
    const linkEl = banner.querySelector('.cookie-link');
    const storedChoice = localStorage.getItem('jtpayCookieConsent');
    if (messageEl) {
      messageEl.textContent = copy[lang].cookieMessage;
    }
    if (linkEl) {
      linkEl.textContent = copy[lang].learnMore;
    }
    if (!storedChoice) {
      banner.classList.add('is-visible');
    }
    const handleChoice = (value) => {
      localStorage.setItem('jtpayCookieConsent', value);
      banner.classList.remove('is-visible');
    };
    if (acceptBtn) {
      acceptBtn.textContent = copy[lang].accept;
      acceptBtn.addEventListener('click', () => handleChoice('accepted'));
    }
    if (declineBtn) {
      declineBtn.textContent = copy[lang].decline;
      declineBtn.addEventListener('click', () => handleChoice('declined'));
    }
  }

  const toast = document.querySelector('.toast');
  const forms = document.querySelectorAll('.js-form');
  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      if (toast) {
        toast.textContent = copy[lang].toast;
        toast.classList.add('is-visible');
      }
      const redirectTarget = form.dataset.redirect || form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        if (toast) {
          toast.classList.remove('is-visible');
        }
        window.location.href = redirectTarget;
      }, 1300);
    });
  });

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );

  document.querySelectorAll('.animate-on-scroll').forEach((element) => {
    observer.observe(element);
  });
});