document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const cookieBanner = document.getElementById("cookie-banner");
    const acceptCookies = document.getElementById("cookie-accept");
    const declineCookies = document.getElementById("cookie-decline");
    const preferenceKey = "cg-cookie-preference";

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            siteNav.classList.toggle("is-open");
        });
    }

    if (cookieBanner && acceptCookies && declineCookies) {
        const preference = localStorage.getItem(preferenceKey);
        if (!preference) {
            setTimeout(() => {
                cookieBanner.classList.add("active");
            }, 600);
        }

        acceptCookies.addEventListener("click", () => {
            localStorage.setItem(preferenceKey, "accepted");
            cookieBanner.classList.remove("active");
        });

        declineCookies.addEventListener("click", () => {
            localStorage.setItem(preferenceKey, "declined");
            cookieBanner.classList.remove("active");
        });
    }

    if (window.mermaid) {
        mermaid.initialize({
            startOnLoad: true,
            theme: "dark",
            themeVariables: {
                primaryColor: "#1D4ED8",
                secondaryColor: "#0B1D2A",
                tertiaryColor: "#F59E0B",
                primaryTextColor: "#F8FAFC",
                lineColor: "#F59E0B",
                borderRadius: 8
            }
        });
    }
});