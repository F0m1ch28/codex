(function () {
  const storageKey = "nazvanie-cookie-consent";
  const banners = document.querySelectorAll(".cookie-banner");

  if (!banners.length) {
    return;
  }

  const state = localStorage.getItem(storageKey);

  if (state === "accepted" || state === "declined") {
    banners.forEach((banner) => {
      banner.classList.add("hidden");
    });
    return;
  }

  banners.forEach((banner) => {
    const acceptBtn = banner.querySelector(".cookie-btn.accept");
    const declineBtn = banner.querySelector(".cookie-btn.decline");

    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => {
        localStorage.setItem(storageKey, "accepted");
        banner.classList.add("hidden");
      });
    }

    if (declineBtn) {
      declineBtn.addEventListener("click", () => {
        localStorage.setItem(storageKey, "declined");
        banner.classList.add("hidden");
      });
    }
  });
})();