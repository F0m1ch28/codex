document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-menu a');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptAllBtn = document.querySelector('[data-cookie="accept-all"]');
    const acceptNecessaryBtn = document.querySelector('[data-cookie="accept-necessary"]');
    const declineBtn = document.querySelector('[data-cookie="decline"]');
    const consentKey = 'gc-cookie-consent';

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            this.setAttribute('aria-expanded', String(!isExpanded));
            navMenu.classList.toggle('open');
        });

        navLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                if (navMenu.classList.contains('open')) {
                    navMenu.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });

        document.addEventListener('click', function (event) {
            if (!navMenu.contains(event.target) && !navToggle.contains(event.target)) {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (storedConsent) {
            cookieBanner.classList.add('hidden');
        }

        function handleConsent(value) {
            localStorage.setItem(consentKey, value);
            cookieBanner.classList.add('hidden');
        }

        if (acceptAllBtn) {
            acceptAllBtn.addEventListener('click', function () {
                handleConsent('all');
            });
        }

        if (acceptNecessaryBtn) {
            acceptNecessaryBtn.addEventListener('click', function () {
                handleConsent('necessary');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                handleConsent('declined');
            });
        }
    }
});