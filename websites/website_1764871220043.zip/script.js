document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector("[data-nav-toggle]");
  const body = document.body;
  const navList = document.querySelector("[data-nav-list]");

  if (navToggle && navList) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      body.classList.toggle("nav-open");
    });

    navList.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", () => {
        body.classList.remove("nav-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const yearEl = document.getElementById("year");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  const cookieBanner = document.getElementById("cookie-banner");
  const acceptBtn = document.querySelector("[data-cookie-accept]");
  const declineBtn = document.querySelector("[data-cookie-decline]");
  const storageKey = "ndsCookieConsent";

  const hideBanner = () => {
    if (cookieBanner) {
      cookieBanner.setAttribute("hidden", "");
    }
  };

  if (cookieBanner) {
    const consent = localStorage.getItem(storageKey);
    if (!consent) {
      cookieBanner.removeAttribute("hidden");
    }

    acceptBtn?.addEventListener("click", () => {
      localStorage.setItem(storageKey, "accepted");
      hideBanner();
    });

    declineBtn?.addEventListener("click", () => {
      localStorage.setItem(storageKey, "declined");
      hideBanner();
    });
  }
});