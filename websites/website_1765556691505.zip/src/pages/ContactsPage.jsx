```javascript
import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./ContactsPage.module.css";

const ContactsPage = () => (
  <>
    <Helmet>
      <title>Контакты — 🎨 Сколько вариантов сайта создать?</title>
      <meta
        name="description"
        content="Свяжитесь со студией: hello@skolko-variantov.ru, телефон +7 (999) 123-45-67. Работаем по всему миру удаленно."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Контакты</h1>
      <p>Расскажите, зачем вам новый сайт, и мы предложим сценарии развития продукта на старте.</p>
    </section>

    <section className={styles.content}>
      <div className={styles.card}>
        <h2>Мы на связи</h2>
        <ul className={styles.list}>
          <li>
            Email: <a href="mailto:hello@skolko-variantov.ru">hello@skolko-variantov.ru</a>
          </li>
          <li>
            Телефон: <a href="tel:+79991234567">+7 (999) 123-45-67</a>
          </li>
          <li>Работаем по всему миру удаленно</li>
        </ul>
        <p>
          Для оценки стоимости пришлите презентацию, ТЗ или ссылку на текущий продукт. Ответим в течение одного
          рабочего дня.
        </p>
      </div>
      <div className={styles.card}>
        <h2>Как мы стартуем</h2>
        <ol className={styles.steps}>
          <li>Знакомимся и уточняем задачу созвоном (30 минут).</li>
          <li>Формируем эстимейт с вариантами бюджетов и сроков.</li>
          <li>Собираем команду и начинаем исследование.</li>
        </ol>
        <p className={styles.note}>
          Проект можно запускать по спринтам или фиксированному контракту — обсудим удобный формат.
        </p>
      </div>
    </section>
  </>
);

export default ContactsPage;
```