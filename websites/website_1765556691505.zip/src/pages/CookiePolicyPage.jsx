```javascript
import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./LegalPages.module.css";

const CookiePolicyPage = () => (
  <>
    <Helmet>
      <title>Политика использования cookies — 🎨 Сколько вариантов сайта создать?</title>
      <meta name="description" content="Правила использования cookies на сайте студии." />
    </Helmet>
    <section className={styles.page}>
      <h1>Политика использования cookies</h1>
      <p>Последнее обновление: {new Date().toLocaleDateString("ru-RU")}</p>

      <h2>1. Что такое cookies</h2>
      <p>
        Cookies — это маленькие файлы, которые сохраняются браузером и помогают нам понимать, как вы используете сайт,
        чтобы делать его удобнее.
      </p>

      <h2>2. Какие cookies мы применяем</h2>
      <p>
        На сайте используются технические cookies для работы форм и аналитические cookies для оценки эффективности
        контента. Третьи лица не получают прямого доступа к этим данным.
      </p>

      <h2>3. Управление cookies</h2>
      <p>
        Вы можете ограничить или отключить cookies в настройках браузера. Однако часть функциональности сайта может
        работать некорректно.
      </p>

      <h2>4. Контакты</h2>
      <p>
        Если у вас есть вопросы по cookies, напишите нам на <a href="mailto:hello@skolko-variantov.ru">hello@skolko-variantov.ru</a>.
      </p>
    </section>
  </>
);

export default CookiePolicyPage;
```