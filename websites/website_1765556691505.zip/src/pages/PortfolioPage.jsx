```javascript
import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./PortfolioPage.module.css";

const projects = [
  {
    title: "Project Aurora",
    description: "Премиальный сайт для экосистемы умного дома. Создали интерактивные 3D-переходы и ночной режим.",
    image: "/images/project-aurora.jpg",
    tags: ["UI/UX", "Frontend", "React"]
  },
  {
    title: "Atelier Forma",
    description: "Интернет-магазин дизайнерской мебели: концепции для каталога, фильтров и мобильного опыта.",
    image: "/images/atelier-forma.jpg",
    tags: ["Концепция", "UI", "E-commerce"]
  },
  {
    title: "Nordic Flow",
    description: "Платформа для онлайн-курсов. Разработали дизайн-систему, дашборды и лейаут уроков.",
    image: "/images/nordic-flow.jpg",
    tags: ["Прототип", "UI-Kit", "Design System"]
  },
  {
    title: "Glow Clinic",
    description: "Сайт клиники эстетической медицины с записью, интеграцией CRM и личным кабинетом пациента.",
    image: "/images/glow-clinic.jpg",
    tags: ["UX", "Интеграции", "Верстка"]
  },
  {
    title: "Fintellect",
    description: "Финтех-сервис с калькуляторами и банковскими продуктами. Основной акцент — чистая типографика.",
    image: "/images/fintellect.jpg",
    tags: ["UX", "UI", "Анимация"]
  },
  {
    title: "Museo Art",
    description: "Онлайн-галерея современного искусства. Создали эмоциональную визуальную концепцию и каталог.",
    image: "/images/museo-art.jpg",
    tags: ["Концепция", "UI", "Контент"]
  }
];

const PortfolioPage = () => (
  <>
    <Helmet>
      <title>Портфолио — 🎨 Сколько вариантов сайта создать?</title>
      <meta
        name="description"
        content="Портфолио дизайн-студии: сайты для технологических стартапов, e-commerce, образовательных платформ и сервисов."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Портфолио</h1>
      <p>
        Здесь собраны проекты, где мы тестировали несколько концепций, добивались wow-эффекта и делали интерфейсы более
        понятными. По запросу покажем дополнительные работы под NDA.
      </p>
    </section>
    <section className={styles.grid}>
      {projects.map((project) => (
        <article key={project.title} className={styles.card}>
          <div className={styles.imageWrapper}>
            <img src={project.image} alt={project.title} loading="lazy" />
          </div>
          <div className={styles.content}>
            <h2>{project.title}</h2>
            <p>{project.description}</p>
            <ul className={styles.tags}>
              {project.tags.map((tag) => (
                <li key={tag}>{tag}</li>
              ))}
            </ul>
          </div>
        </article>
      ))}
    </section>
  </>
);

export default PortfolioPage;
```