```javascript
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import styles from "./HomePage.module.css";

const services = [
  {
    title: "Дизайн-концепции",
    description: "Разрабатываем минимум три визуальных направления, чтобы вы увидели, как может говорить ваш бренд.",
    icon: "✨"
  },
  {
    title: "UI/UX дизайн",
    description: "Фокус на сценариях пользователя: прототипы, дизайн-системы и дизайн экранов, готовых к разработке.",
    icon: "🧭"
  },
  {
    title: "Веб-разработка",
    description: "Верстаем адаптивные сайты на современных технологиях и интегрируем с нужными сервисами.",
    icon: "⚙️"
  },
  {
    title: "Аудит и улучшение",
    description: "Анализируем текущий сайт, обнаруживаем точки роста и формируем roadmap улучшений.",
    icon: "🔍"
  }
];

const portfolioPreview = [
  {
    title: "Project Aurora",
    description: "Премиальный лендинг для технологического стартапа с интерактивной анимацией.",
    image: "/images/project-aurora.jpg"
  },
  {
    title: "Atelier Forma",
    description: "Серия концептов интернет-магазина дизайнерской мебели с акцентом на UX.",
    image: "/images/atelier-forma.jpg"
  },
  {
    title: "Nordic Flow",
    description: "Редизайн платформы для онлайн-обучения с системой компонентов и тёмной темой.",
    image: "/images/nordic-flow.jpg"
  },
  {
    title: "Glow Clinic",
    description: "Сайт клиники эстетической медицины с расписанием и интеграцией CRM.",
    image: "/images/glow-clinic.jpg"
  }
];

const approachSteps = [
  {
    title: "Исследуем и считываем задачу",
    text: "Назначаем интервью, изучаем аналитику и формируем гипотезы, которые влияют на каркас и визуальный язык."
  },
  {
    title: "Создаём несколько нарративов",
    text: "Вместо одной идеи показываем разные стилистические сценарии, чтобы можно было выбрать лучшее решение."
  },
  {
    title: "Прототипируем и тестируем",
    text: "Фиксируем выбранное направление и собираем клик-прообраз для проверки гипотез до разработки."
  }
];

const HomePage = () => {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState("");

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus("Спасибо! Мы свяжемся с вами в течение рабочего дня.");
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <>
      <Helmet>
        <title>🎨 Сколько вариантов сайта создать? — креативное веб-агентство</title>
        <meta
          name="description"
          content="Дизайн-студия, которая предлагает несколько вариантов сайта на старте и помогает выбрать идеальный. Веб-дизайн, UI/UX, разработка."
        />
      </Helmet>
      <div className={styles.hero}>
        <div className={styles.heroContent}>
          <h1 className={styles.heroTitle}>
            🎨 Сколько вариантов сайта создать? Столько, сколько нужно, чтобы ваш бренд звучал уверенно.
          </h1>
          <p className={styles.heroSubtitle}>
            Мы превращаем идеи в понятные интерфейсы. Вместо одной концепции показываем вам разные стилистические
            решения, оцениваем их по метрикам и собираем тот самый идеальный вариант.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.primaryButton} aria-label="Перейти на страницу контактов">
              Обсудить проект
            </Link>
            <Link to="/portfolio" className={styles.secondaryButton} aria-label="Перейти в портфолио">
              Смотреть портфолио
            </Link>
          </div>
        </div>
        <div className={styles.heroCard} aria-hidden="true">
          <p className={styles.heroCardTitle}>Вариант А — смелый</p>
          <p className={styles.heroCardSubtitle}>Градиенты, динамика и запоминающаяся типографика</p>
          <div className={styles.heroCardDivider} />
          <p className={styles.heroCardTitle}>Вариант B — рациональный</p>
          <p className={styles.heroCardSubtitle}>Система, модульная сетка и универсальные паттерны</p>
        </div>
      </div>

      <section className={styles.aboutSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>О студии</span>
          <h2 className={styles.sectionTitle}>Мы проектируем цифровой опыт, который облегчает выбор пользователя</h2>
        </div>
        <p className={styles.aboutText}>
          Команда дизайнеров и разработчиков работает как единый продуктовый юнит. Мы не диктуем единственный путь —
          мы показываем варианты, анализируем вместе с вами и сопровождаем реализацию. Результат — не просто красивый
          сайт, а понятная экосистема страниц, которая помогает бизнесу расти.
        </p>
      </section>

      <section className={styles.servicesSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Услуги</span>
          <h2 className={styles.sectionTitle}>Что мы умеем</h2>
          <Link to="/uslugi" className={styles.sectionLink}>
            Полный список услуг →
          </Link>
        </div>
        <div className={styles.cardsGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">
                {service.icon}
              </span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.approachSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Наш подход</span>
          <h2 className={styles.sectionTitle}>Почему у нас всегда несколько вариантов</h2>
          <Link to="/process" className={styles.sectionLink}>
            Узнать подробнее →
          </Link>
        </div>
        <div className={styles.approachGrid}>
          {approachSteps.map((step, index) => (
            <article key={step.title} className={styles.approachCard}>
              <div className={styles.stepNumber}>{String(index + 1).padStart(2, "0")}</div>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.portfolioSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Работы</span>
          <h2 className={styles.sectionTitle}>Любимые проекты команды</h2>
          <Link to="/portfolio" className={styles.sectionLink}>
            Смотреть все кейсы →
          </Link>
        </div>
        <div className={styles.portfolioGrid}>
          {portfolioPreview.map((project) => (
            <article key={project.title} className={styles.portfolioCard}>
              <div className={styles.imageWrapper}>
                <img src={project.image} alt={project.title} loading="lazy" />
              </div>
              <div className={styles.portfolioContent}>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2>Расскажите нам про задачу — мы предложим варианты уже на первой созвонке</h2>
          <p>
            Заполните форму: важно знать, как вы измеряете успех и какой опыт был до этого. В ответ пришлём подборку
            референсов и план действий.
          </p>
          <form className={styles.form} onSubmit={handleSubmit}>
            <label className={styles.label}>
              Имя
              <input
                type="text"
                name="name"
                placeholder="Как к вам обращаться?"
                required
                value={formData.name}
                onChange={handleChange}
              />
            </label>
            <label className={styles.label}>
              Email
              <input
                type="email"
                name="email"
                placeholder="name@company.com"
                required
                value={formData.email}
                onChange={handleChange}
              />
            </label>
            <label className={styles.label}>
              Расскажите коротко о проекте
              <textarea
                name="message"
                rows="4"
                placeholder="Что за продукт, какие сроки, есть ли уже сайт?"
                value={formData.message}
                onChange={handleChange}
              />
            </label>
            <button type="submit" className={styles.submitButton} aria-label="Отправить сообщение студии">
              Отправить запрос
            </button>
            {status && <p className={styles.status}>{status}</p>}
          </form>
        </div>
      </section>
    </>
  );
};

export default HomePage;
```