```javascript
import React from "react";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.brand}>
        <p className={styles.brandTitle}>🎨 Сколько вариантов сайта создать?</p>
        <p className={styles.brandText}>
          Мы придумываем несколько ярких дизайн-концепций и помогаем выбрать ту, что превращает пользователей в
          клиентов.
        </p>
      </div>
      <div className={styles.columns}>
        <div className={styles.column}>
          <h3 className={styles.heading}>Навигация</h3>
          <ul className={styles.list}>
            <li>
              <Link to="/">Главная</Link>
            </li>
            <li>
              <Link to="/uslugi">Услуги</Link>
            </li>
            <li>
              <Link to="/process">Процесс</Link>
            </li>
            <li>
              <Link to="/portfolio">Портфолио</Link>
            </li>
            <li>
              <Link to="/kontakty">Контакты</Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Документы</h3>
          <ul className={styles.list}>
            <li>
              <Link to="/terms">Условия оказания услуг</Link>
            </li>
            <li>
              <Link to="/privacy">Политика конфиденциальности</Link>
            </li>
            <li>
              <Link to="/cookie-policy">Использование cookies</Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.heading}>Связь</h3>
          <ul className={styles.list}>
            <li>Email: <a href="mailto:hello@skolko-variantov.ru">hello@skolko-variantov.ru</a></li>
            <li>Телефон: <a href="tel:+79991234567">+7 (999) 123-45-67</a></li>
            <li>Работаем по всему миру удаленно</li>
          </ul>
          <div className={styles.socials} aria-label="Социальные сети">
            <a href="#!" aria-label="Behance">
              <span aria-hidden="true">Behance</span>
            </a>
            <a href="#!" aria-label="Dribbble">
              <span aria-hidden="true">Dribbble</span>
            </a>
            <a href="#!" aria-label="Instagram">
              <span aria-hidden="true">Instagram</span>
            </a>
          </div>
        </div>
      </div>
      <p className={styles.copy}>© {new Date().getFullYear()} «Сколько вариантов сайта создать?» Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;
```