```javascript
import React, { useEffect, useState } from "react";
import styles from "./CookieBanner.module.css";

const COOKIE_STORAGE_KEY = "cookie_consent";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(COOKIE_STORAGE_KEY, "accepted");
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.text}>
        Мы используем cookies, чтобы сделать взаимодействие с сайтом комфортным и безопасным. Продолжая работу, вы
        подтверждаете согласие с{" "}
        <a href="/cookie-policy">Политикой использования cookies</a>.
      </p>
      <button className={styles.button} type="button" onClick={handleAccept} aria-label="Принять использование cookies">
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;
```