document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const navLinks = document.querySelectorAll(".nav-list a");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", function () {
            const isActive = siteNav.classList.toggle("is-active");
            navToggle.classList.toggle("is-active", isActive);
            navToggle.setAttribute("aria-expanded", isActive);
        });

        navLinks.forEach(function (link) {
            link.addEventListener("click", function () {
                if (siteNav.classList.contains("is-active")) {
                    siteNav.classList.remove("is-active");
                    navToggle.classList.remove("is-active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    if (cookieBanner) {
        const storedChoice = localStorage.getItem("upskill_cookie_choice");
        if (storedChoice) {
            cookieBanner.classList.add("is-hidden");
        }

        const cookieButtons = cookieBanner.querySelectorAll("[data-cookie-choice]");
        cookieButtons.forEach(function (button) {
            button.addEventListener("click", function (event) {
                event.preventDefault();
                const choice = button.getAttribute("data-cookie-choice");
                localStorage.setItem("upskill_cookie_choice", choice);
                cookieBanner.classList.add("is-hidden");
                window.open("cookies.html", "_blank");
            });
        });
    }
});