import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={`${styles.inner} container`}>
        <div className={styles.col}>
          <div className={styles.logo}>Education in Paris Review</div>
          <p className={styles.description}>
            L’édition propose une lecture structurée de l’écosystème éducatif parisien en privilégiant des analyses vérifiables et
            des perspectives croisées.
          </p>
        </div>
        <div className={styles.col}>
          <h3 className={styles.heading}>Navigation</h3>
          <ul className={styles.list}>
            <li>
              <Link to="/">Accueil</Link>
            </li>
            <li>
              <Link to="/analyses">Analyses</Link>
            </li>
            <li>
              <Link to="/interviews">Interviews</Link>
            </li>
            <li>
              <Link to="/ressources">Ressources</Link>
            </li>
            <li>
              <Link to="/a-propos">À Propos</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </div>
        <div className={styles.col}>
          <h3 className={styles.heading}>Cadre éditorial</h3>
          <ul className={styles.list}>
            <li>
              <Link to="/mentions-legales">Mentions Légales</Link>
            </li>
            <li>
              <Link to="/confidentialite">Politique de Confidentialité</Link>
            </li>
              <Link to="/cookies">Politique de Cookies</Link>
            </li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        © {currentYear} Education in Paris Review. Tous droits réservés.
      </div>
    </footer>
  );
};

export default Footer;