import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact | Education in Paris Review</title>
        <meta
          name="description"
          content="Contacter la rédaction d’Education in Paris Review pour des échanges académiques, des informations documentaires ou des contributions institutionnelles."
        />
      </Helmet>

      <section className="container">
        <header className={styles.header}>
          <h1>Contact</h1>
          <p>
            Le contact est réservé aux échanges académiques, à la transmission d’études et aux demandes d’information institutionnelle. Education in Paris Review ne propose aucune activité commerciale, ne vend pas d’espaces publicitaires et n’offre pas de services payants.
          </p>
        </header>

        <div className={styles.card} aria-labelledby="contact-coordinates">
          <h2 id="contact-coordinates">Coordonnées vérifiées</h2>
          <div className={styles.info}>
            <div>
              <span className={styles.label}>Email</span>
              <p className={styles.value}>redaction@education-paris-review.fr</p>
            </div>
            <div>
              <span className={styles.label}>Adresse postale</span>
              <p className={styles.value}>
                Education in Paris Review<br />
                Boîte Postale 75011<br />
                75011 Paris, France
              </p>
            </div>
          </div>
          <p className={styles.notice}>
            Les institutions éducatives, centres de recherche ou associations peuvent partager leurs publications et observations en utilisant les coordonnées ci-dessus.
            Les messages à caractère promotionnel ne sont pas traités.
          </p>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;