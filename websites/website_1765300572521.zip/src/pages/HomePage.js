import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './HomePage.module.css';

const latestArticles = [
  {
    id: 1,
    category: 'Politiques éducatives',
    title: 'Évaluation des zones d’éducation prioritaire à Paris',
    date: '12 septembre 2023',
    excerpt:
      'Une analyse des indicateurs de réussite scolaire et de continuité pédagogique au sein des collèges classés en réseau prioritaire renforcé.',
  },
  {
    id: 2,
    category: 'Transformation numérique',
    title: 'Outils digitaux et accompagnement pédagogique dans les lycées parisiens',
    date: '5 septembre 2023',
    excerpt:
      'Cartographie des usages numériques au sein des lycées publics et privés sous contrat, avec un focus sur la formation des équipes éducatives.',
  },
  {
    id: 3,
    category: 'Diversité scolaire',
    title: 'Mixité sociale et sectorisation au collège : état des lieux 2023',
    date: '28 août 2023',
    excerpt:
      'Lecture croisée des données de sectorisation, des dispositifs Affelnet et des initiatives locales soutenant l’équité d’accès aux établissements.',
  },
  {
    id: 4,
    category: 'Enseignement supérieur',
    title: 'Mutations des parcours étudiants à l’université Paris 1 Panthéon-Sorbonne',
    date: '18 août 2023',
    excerpt:
      'Étude qualitative et quantitative de l’orientation post-licence et des leviers de soutien méthodologique proposés aux étudiants.',
  },
];

const researchThemes = [
  {
    id: 'politiques',
    title: 'Politiques éducatives',
    description: 'Analyse des décisions publiques parisiennes, de leur mise en œuvre et de leurs impacts sur les trajectoires scolaires.',
  },
  {
    id: 'diversite',
    title: 'Diversité scolaire',
    description: 'Suivi des actions dédiées à la mixité sociale, à l’inclusion et à la lutte contre les ruptures de parcours.',
  },
  {
    id: 'numerique',
    title: 'Transformation numérique',
    description: 'Étude des environnements numériques d’apprentissage, de la formation enseignante et des usages étudiants.',
  },
];

const HomePage = () => {
  return (
    <div className={styles.home}>
      <Helmet>
        <title>Education in Paris Review | Analyses sur l’éducation parisienne</title>
        <meta
          name="description"
          content="Education in Paris Review propose des analyses neutres et structurées sur les politiques éducatives, la diversité scolaire et les innovations pédagogiques à Paris."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={`${styles.heroInner} container`}>
          <p className={styles.heroLabel}>Observation indépendante</p>
          <h1 className={styles.heroTitle}>Education in Paris Review documente les dynamiques éducatives parisiennes</h1>
          <p className={styles.heroDescription}>
            La publication offre une lecture contextualisée des politiques publiques, des pratiques pédagogiques et des parcours d’élèves,
            en privilégiant des informations vérifiables et une approche comparative.
          </p>
          <div className={styles.heroLinks}>
            <Link to="/analyses" className={styles.heroLink}>
              Consulter les analyses
            </Link>
            <Link to="/interviews" className={styles.heroLinkSecondary}>
              Parcourir les entretiens
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.latest}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Dernières publications</h2>
            <p className="sectionSubtitle">
              Sélection d’analyses récentes mettant en perspective les données publiques, les témoignages d’acteurs de terrain et les cadres réglementaires.
            </p>
          </div>
          <div className={styles.articlesGrid}>
            {latestArticles.map((article) => (
              <article key={article.id} className={styles.articleCard}>
                <span className="tag">{article.category}</span>
                <h3>{article.title}</h3>
                <time dateTime="2023-09-12">{article.date}</time>
                <p>{article.excerpt}</p>
                <Link to="/analyses" className={styles.cardLink} aria-label={`Lire l'analyse : ${article.title}`}>
                  Lire l’analyse
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.themes}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Thématiques de recherche</h2>
            <p className="sectionSubtitle">
              Les investigations menées par Education in Paris Review s’articulent autour de trois axes d’observation complémentaires.
            </p>
          </div>
          <div className={styles.themeGrid}>
            {researchThemes.map((theme) => (
              <div key={theme.id} className={styles.themeCard}>
                <div className={styles.themeIcon} aria-hidden="true">
                  {theme.title.charAt(0)}
                </div>
                <h3>{theme.title}</h3>
                <p>{theme.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.featured}>
        <div className="container">
          <div className={styles.featuredInner}>
            <div className={styles.featuredContent}>
              <span className="tag">À la Une</span>
              <h2>Une cartographie des innovations pédagogiques dans les écoles élémentaires parisiennes</h2>
              <p>
                Une série d’enquêtes conduit à identifier les dispositifs pédagogiques différenciés déployés dans les écoles du centre et de la périphérie parisienne.
                L’étude combine observations de terrain, entretiens avec les équipes éducatives et analyse des indicateurs de réussite.
              </p>
              <Link to="/analyses" className="buttonLink">
                Découvrir la série d’articles
              </Link>
            </div>
            <div className={styles.featuredMedia}>
              <img
                src="https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=900&q=80"
                alt="Salle de classe parisienne moderne avec tableaux numériques"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.approach}>
        <div className="container">
          <h2 className="sectionTitle">Notre approche</h2>
          <div className={styles.approachGrid}>
            <div className={styles.approachCard}>
              <h3>Indépendance analytique</h3>
              <p>
                La rédaction s’appuie sur une méthodologie de vérification systématique des informations en croisant sources publiques, bases statistiques et travaux académiques.
              </p>
            </div>
            <div className={styles.approachCard}>
              <h3>Perspectives croisées</h3>
              <p>
                Les analyses associent données quantitatives et témoignages d’acteurs éducatifs afin d’éclairer les enjeux locaux et métropolitains de manière nuancée.
              </p>
            </div>
            <div className={styles.approachCard}>
              <h3>Transparence des sources</h3>
              <p>
                Chaque publication précise les sources consultées, les limites méthodologiques rencontrées et les pistes de recherche à approfondir.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;