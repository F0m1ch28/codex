import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './LegalPage.module.css';

const LegalPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Mentions légales | Education in Paris Review</title>
        <meta
          name="description"
          content="Informations légales concernant l’édition numérique Education in Paris Review."
        />
      </Helmet>

      <section className="container">
        <header className={styles.header}>
          <h1>Mentions légales</h1>
        </header>
        <article className={styles.content}>
          <h2>Éditeur</h2>
          <p>
            Education in Paris Review est une publication numérique consacrée à l’analyse des politiques et pratiques éducatives parisiennes.
            L’édition est assurée par un collectif de journalistes et de chercheurs spécialisés dans l’éducation.
          </p>

          <h2>Hébergement</h2>
          <p>
            Le site est hébergé par un prestataire européen respectant la réglementation relative à la protection des données personnelles.
          </p>

          <h2>Propriété intellectuelle</h2>
          <p>
            L’ensemble des contenus (textes, analyses, visuels) est protégé par le Code de la propriété intellectuelle.
            Toute reproduction partielle ou totale nécessite l’autorisation écrite de la rédaction.
          </p>

          <h2>Responsabilité éditoriale</h2>
          <p>
            Les informations publiées sont vérifiées avec soin. La rédaction s’efforce de corriger toute erreur signalée.
            Les contributions externes sont relues avant publication afin de garantir leur conformité à la ligne éditoriale.
          </p>
        </article>
      </section>
    </div>
  );
};

export default LegalPage;