document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isActive = navMenu.classList.toggle('active');
            navToggle.classList.toggle('active', isActive);
            navToggle.setAttribute('aria-expanded', isActive ? 'true' : 'false');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('active')) {
                    navMenu.classList.remove('active');
                    navToggle.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const tabControls = document.querySelectorAll('[data-tab-target]');
    tabControls.forEach(button => {
        button.addEventListener('click', () => {
            const targetSelector = button.getAttribute('data-tab-target');
            const target = document.querySelector(targetSelector);

            if (!target) return;

            const siblings = button.parentElement.querySelectorAll('[aria-selected]');
            siblings.forEach(sibling => sibling.setAttribute('aria-selected', 'false'));
            button.setAttribute('aria-selected', 'true');

            const panels = target.parentElement.querySelectorAll('.tab-panel');
            panels.forEach(panel => panel.classList.remove('active'));
            target.classList.add('active');
        });
    });

    const accordionButtons = document.querySelectorAll('[data-accordion-button]');
    accordionButtons.forEach(button => {
        button.addEventListener('click', () => {
            const item = button.parentElement;
            item.classList.toggle('active');

            const content = item.querySelector('.accordion-content');
            if (item.classList.contains('active')) {
                content.style.maxHeight = content.scrollHeight + 'px';
                content.style.paddingBottom = '1.5rem';
            } else {
                content.style.maxHeight = null;
                content.style.paddingBottom = '0';
            }
        });
    });

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptButton = document.querySelector('.cookie-accept');
    const declineButton = document.querySelector('.cookie-decline');
    const storageKey = 'mccartwqra-cookie-consent';

    const showCookieBanner = () => {
        if (cookieBanner && !localStorage.getItem(storageKey)) {
            cookieBanner.classList.add('active');
        }
    };

    const hideCookieBanner = (choice, link) => {
        localStorage.setItem(storageKey, choice);
        if (cookieBanner) {
            cookieBanner.classList.remove('active');
        }
        if (link) {
            window.open(link, '_blank', 'noopener');
        }
    };

    if (acceptButton) {
        acceptButton.addEventListener('click', () => {
            hideCookieBanner('accepted', acceptButton.dataset.link || 'cookies.html');
        });
    }

    if (declineButton) {
        declineButton.addEventListener('click', () => {
            hideCookieBanner('declined', declineButton.dataset.link || 'cookies.html');
        });
    }

    showCookieBanner();
});