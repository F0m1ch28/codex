document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navCollapse = document.querySelector('.nav-collapse');

    if (navToggle && navCollapse) {
        navToggle.addEventListener('click', () => {
            navCollapse.classList.toggle('active');
        });

        navCollapse.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navCollapse.classList.remove('active');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptButton = document.getElementById('cookieAccept');
    const declineButton = document.getElementById('cookieDecline');

    if (cookieBanner && acceptButton && declineButton) {
        const cookieChoice = localStorage.getItem('somatiatztCookieChoice');
        if (cookieChoice) {
            cookieBanner.style.display = 'none';
        }

        acceptButton.addEventListener('click', () => {
            localStorage.setItem('somatiatztCookieChoice', 'accepted');
            cookieBanner.style.display = 'none';
        });

        declineButton.addEventListener('click', () => {
            localStorage.setItem('somatiatztCookieChoice', 'declined');
            cookieBanner.style.display = 'none';
        });
    }
});