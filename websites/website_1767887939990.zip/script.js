document.addEventListener('DOMContentLoaded', function () {
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-btn.accept');
    const declineBtn = document.querySelector('.cookie-btn.decline');
    const accordionHeaders = document.querySelectorAll('.accordion-header');
    const tabButtons = document.querySelectorAll('.tab-button');

    if (cookieBanner) {
        const preference = localStorage.getItem('discargtwjCookiePreference');
        if (!preference) {
            cookieBanner.classList.add('active');
        }

        const hideBanner = (choice) => {
            localStorage.setItem('discargtwjCookiePreference', choice);
            cookieBanner.classList.remove('active');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => hideBanner('accepted'));
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', () => hideBanner('declined'));
        }
    }

    accordionHeaders.forEach((header) => {
        header.addEventListener('click', () => {
            const item = header.closest('.accordion-item');
            const content = item.querySelector('.accordion-content');
            const icon = header.querySelector('.icon');

            const isOpen = content.classList.contains('open');

            document.querySelectorAll('.accordion-content').forEach((panel) => {
                panel.classList.remove('open');
                panel.style.maxHeight = null;
            });
            document.querySelectorAll('.accordion-header .icon').forEach((ic) => {
                ic.style.transform = 'rotate(0deg)';
            });

            if (!isOpen) {
                content.classList.add('open');
                content.style.maxHeight = content.scrollHeight + 'px';
                if (icon) {
                    icon.style.transform = 'rotate(45deg)';
                }
            }
        });
    });

    if (tabButtons.length > 0) {
        const tabPanels = document.querySelectorAll('.tab-panel');

        tabButtons.forEach((button) => {
            button.addEventListener('click', () => {
                const target = button.getAttribute('data-tab');

                tabButtons.forEach((btn) => btn.classList.remove('active'));
                button.classList.add('active');

                tabPanels.forEach((panel) => {
                    if (panel.getAttribute('data-tab') === target) {
                        panel.classList.add('active');
                    } else {
                        panel.classList.remove('active');
                    }
                });
            });
        });
    }
});