document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const body = document.body;

    if (navToggle) {
        navToggle.addEventListener('click', function () {
            body.classList.toggle('nav-open');
        });
    }

    document.querySelectorAll('.nav-links a').forEach(function (link) {
        link.addEventListener('click', function () {
            body.classList.remove('nav-open');
        });
    });

    const cookieBanner = document.getElementById('cookie-banner');
    const cookieActions = document.querySelectorAll('[data-cookie-action]');

    if (cookieBanner) {
        const storedPreference = localStorage.getItem('corkjawehlCookiePreference');
        if (storedPreference) {
            cookieBanner.classList.add('hidden');
        }

        cookieActions.forEach(function (actionButton) {
            actionButton.addEventListener('click', function (event) {
                event.preventDefault();
                const action = actionButton.getAttribute('data-cookie-action');
                localStorage.setItem('corkjawehlCookiePreference', action);
                cookieBanner.classList.add('hidden');
            });
        });
    }
});