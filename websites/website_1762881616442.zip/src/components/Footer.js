import React from 'react';
import { Link } from 'react-router-dom';
import styles from '../styles/Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="fusszeile">
      <div className={`container ${styles.footerGrid}`}>
        <div>
          <h2 id="fusszeile" className={styles.footerTitle}>
            Tredifynix
          </h2>
          <p className={styles.footerText}>
            Präzise Prognosen für Markttrends auf dem deutschen Markt – datenbasiert,
            nachvollziehbar und in bestehende Prozesse integrierbar.
          </p>
          <ul className={styles.contactList}>
            <li>Neuer Wall 50, 20354 Hamburg, Deutschland</li>
            <li>
              <a href="tel:+494098765432" className={styles.contactLink}>
                +49 40 98765432
              </a>
            </li>
            <li>
              <a href="mailto:info@tredifynix.com" className={styles.contactLink}>
                info@tredifynix.com
              </a>
            </li>
          </ul>
        </div>
        <div>
          <h3 className={styles.columnTitle}>Unternehmen</h3>
          <ul className={styles.footerLinks}>
            <li>
              <Link to="/ueber-uns">Über uns</Link>
            </li>
            <li>
              <Link to="/loesungen">Lösungen</Link>
            </li>
            <li>
              <Link to="/integrationen">Integrationen</Link>
            </li>
            <li>
              <Link to="/ressourcen">Ressourcen</Link>
            </li>
          </ul>
        </div>
        <div>
          <h3 className={styles.columnTitle}>Rechtliches</h3>
          <ul className={styles.footerLinks}>
            <li>
              <Link to="/nutzungsbedingungen">Nutzungsbedingungen</Link>
            </li>
            <li>
              <Link to="/datenschutz">Datenschutz</Link>
            </li>
            <li>
              <Link to="/cookie-richtlinie">Cookie-Richtlinie</Link>
            </li>
          </ul>
        </div>
        <div>
          <h3 className={styles.columnTitle}>Verbinden</h3>
          <ul className={styles.socialLinks}>
            <li>
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Tredifynix auf LinkedIn"
              >
                LinkedIn
              </a>
            </li>
            <li>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Tredifynix auf Twitter"
              >
                Twitter
              </a>
            </li>
            <li>
              <a
                href="https://medium.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Tredifynix auf Medium"
              >
                Medium
              </a>
            </li>
          </ul>
          <p className={styles.footerNote}>
            © {new Date().getFullYear()} Tredifynix. Alle Rechte vorbehalten.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;