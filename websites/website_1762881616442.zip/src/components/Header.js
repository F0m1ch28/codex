import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from '../styles/Header.module.css';

const Header = () => {
  const [isNavOpen, setIsNavOpen] = useState(false);

  const toggleMenu = () => {
    setIsNavOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsNavOpen(false);
  };

  return (
    <header className={styles.header}>
      <a href="#hauptinhalt" className={styles.skipLink}>
        Zum Inhalt springen
      </a>
      <div className={`container ${styles.navbar}`}>
        <Link to="/" className={styles.logo} aria-label="Tredifynix Startseite">
          <span className={styles.logoMark}>T</span>
          <span className={styles.logoText}>Tredifynix</span>
        </Link>
        <button
          className={styles.menuButton}
          onClick={toggleMenu}
          aria-expanded={isNavOpen}
          aria-controls="hauptnavigation"
          aria-label="Menü umschalten"
        >
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
        </button>
        <nav
          id="hauptnavigation"
          className={`${styles.navigation} ${isNavOpen ? styles.open : ''}`}
          aria-label="Hauptnavigation"
        >
          <NavLink
            to="/"
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
          >
            Start
          </NavLink>
          <NavLink
            to="/ueber-uns"
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
          >
            Über uns
          </NavLink>
          <NavLink
            to="/funktionen"
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
          >
            Funktionen
          </NavLink>
          <NavLink
            to="/loesungen"
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
          >
            Lösungen
          </NavLink>
          <NavLink
            to="/integrationen"
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
          >
            Integrationen
          </NavLink>
          <NavLink
            to="/ressourcen"
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
          >
            Ressourcen
          </NavLink>
          <NavLink
            to="/sicherheit"
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
          >
            Sicherheit
          </NavLink>
          <NavLink
            to="/kontakt"
            onClick={closeMenu}
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
            }
          >
            Kontakt
          </NavLink>
          <Link
            to="/funktionen"
            onClick={closeMenu}
            className={`${styles.ctaLink} btn btnPrimary`}
          >
            Jetzt starten
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;