import React, { useEffect, useState } from 'react';
import styles from '../styles/CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('tredifynix-cookie-consent');
    if (!consent) {
      setTimeout(() => setIsVisible(true), 800);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('tredifynix-cookie-consent', 'accepted');
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('tredifynix-cookie-consent', 'declined');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <aside className={styles.banner} role="dialog" aria-live="polite">
      <div>
        <h2 className={styles.bannerTitle}>Cookies bei Tredifynix</h2>
        <p className={styles.bannerText}>
          Wir setzen essentielle Cookies ein, um den sicheren Betrieb der Plattform sicherzustellen
          und Nutzungsstatistiken DSGVO-konform zu analysieren. Details finden Sie in unserer{' '}
          <a href="/cookie-richtlinie">Cookie-Richtlinie</a>.
        </p>
      </div>
      <div className={styles.bannerActions}>
        <button className="btn btnSecondary" onClick={handleDecline}>
          Ablehnen
        </button>
        <button className="btn btnPrimary" onClick={handleAccept}>
          Zustimmen
        </button>
      </div>
    </aside>
  );
};

export default CookieBanner;