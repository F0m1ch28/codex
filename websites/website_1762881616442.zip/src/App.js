import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Solutions from './pages/Solutions';
import Integrations from './pages/Integrations';
import Resources from './pages/Resources';
import Security from './pages/Security';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

const AppContent = () => {
  const location = useLocation();

  return (
    <>
      <Header />
      <main id="hauptinhalt" className="main">
        <Routes location={location}>
          <Route path="/" element={<Home />} />
          <Route path="/ueber-uns" element={<About />} />
          <Route path="/funktionen" element={<Services />} />
          <Route path="/loesungen" element={<Solutions />} />
          <Route path="/integrationen" element={<Integrations />} />
          <Route path="/ressourcen" element={<Resources />} />
          <Route path="/sicherheit" element={<Security />} />
          <Route path="/kontakt" element={<Contact />} />
          <Route path="/nutzungsbedingungen" element={<Terms />} />
          <Route path="/datenschutz" element={<Privacy />} />
          <Route path="/cookie-richtlinie" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </>
  );
};

const App = () => {
  return <AppContent />;
};

export default App;