import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from '../styles/Home.module.css';

const Home = () => {
  const statsData = useMemo(
    () => [
      { label: 'Datenquellen angebunden', value: 185 },
      { label: 'Signallatenz in Sekunden', value: 12 },
      { label: 'Stabilität der Modelle (%)', value: 98 },
      { label: 'Individuelle Pipeline-Konfigurationen', value: 74 }
    ],
    []
  );

  const testimonials = useMemo(
    () => [
      {
        quote:
          'Tredifynix hat unsere Absatzplanung verlässlich gemacht. Die Plattform zeigt uns jede Abweichung, bevor sie für den Handel sichtbar wird.',
        name: 'Lena Hartmann',
        role: 'Head of Planning, Nordlicht Retail'
      },
      {
        quote:
          'Die Kombination aus Zeitreihen- und ML-Verfahren liefert uns belastbare Szenarien. Wir nutzen die Signale täglich in unseren Portfolio-Standups.',
        name: 'Dr. Daniel Krämer',
        role: 'Director Market Analytics, Hanse Energie'
      },
      {
        quote:
          'Integration und Governance sind vorbildlich umgesetzt. Mit wenigen Klicks haben wir die Datenflüsse in unser Warehouse gebracht.',
        name: 'Svenja Ullrich',
        role: 'Lead Data Engineer, ElbTech Mobility'
      }
    ],
    []
  );

  const projects = useMemo(
    () => [
      {
        id: 1,
        title: 'Demand Forecasting für Handelsketten',
        description:
          'Mehrstufige Szenarienplanung mit internen POS-Daten und externen Indikatoren für verbesserte Warensteuerung.',
        category: 'E-Commerce & Handel',
        image: 'https://picsum.photos/1200/800?random=4',
        alt: 'Visualisierung eines Dashboard mit Nachfrageprognosen'
      },
      {
        id: 2,
        title: 'Rohstoff-Lieferketten überwachen',
        description:
          'Automatisiertes Monitoring von Lieferzeiten, Preissignalen und Regressionsmodellen zu Produktionskapazitäten.',
        category: 'Rohstoffe',
        image: 'https://picsum.photos/1200/800?random=5',
        alt: 'Diagramme zur Überwachung von Rohstoffkennzahlen'
      },
      {
        id: 3,
        title: 'Netzbelastung in Echtzeit auswerten',
        description:
          'Zeitnahe Prognosen zur regionalen Energienachfrage auf Basis von Consumption- und Wetterdaten.',
        category: 'Energie',
        image: 'https://picsum.photos/1200/800?random=6',
        alt: 'Dashboard mit Energiedaten und Netzbelastung'
      },
      {
        id: 4,
        title: 'Mobilitätsströme modellieren',
        description:
          'Mikrosegmentierte Modelle für Verkehrs- und Sharing-Daten zur Feinsteuerung von Flotten.',
        category: 'Mobilität',
        image: 'https://picsum.photos/1200/800?random=7',
        alt: 'Analyse von Mobilitätsströmen auf einer Stadtkarte'
      },
      {
        id: 5,
        title: 'Medien-Engagement simulieren',
        description:
          'Forecasting von Zuschauerzahlen mit erweiterten Regressoren, Feedbackschleifen und Alerting.',
        category: 'Medien',
        image: 'https://picsum.photos/1200/800?random=8',
        alt: 'Dashboard mit Medien-Engagement Kennzahlen'
      }
    ],
    []
  );

  const faqs = useMemo(
    () => [
      {
        question: 'Welche Datenquellen lassen sich anschließen?',
        answer:
          'Neben ERP- und POS-Systemen unterstützen wir Data Warehouses, Datenströme auf Basis von Kafka sowie REST- und GraphQL-Endpunkte. Individuelle Konnektoren werden über das Integrationsteam bereitgestellt.'
      },
      {
        question: 'Wie validiert Tredifynix Modellqualität?',
        answer:
          'Jede Pipeline durchläuft automatisiertes Backtesting mit rollierenden Fenstern. Wir tracken MAPE, RMSE und driftrelevante Kennzahlen und stellen die Ergebnisse im Kontroll-Center bereit.'
      },
      {
        question: 'Sind DSGVO-Vorgaben erfüllt?',
        answer:
          'Ja. Verarbeitung und Speicherung finden innerhalb EU-zertifizierter Rechenzentren statt. Rollenbasierte Zugriffe, Verschlüsselung sowie Audit-Logs sind standardmäßig aktiv.'
      },
      {
        question: 'Wie erfolgt die Einbindung in bestehende Dashboards?',
        answer:
          'Dashboards lassen sich via Embedded Views einbetten oder über unser API und SDKs direkt in vorhandene BI-Landschaften spiegeln.'
      }
    ],
    []
  );

  const blogPosts = useMemo(
    () => [
      {
        title: 'Forecasting in volatilen Zeiten: Leitplanken für resilientere Pipelines',
        excerpt:
          'Wir zeigen, wie DataOps-Praktiken und Adaptive Models Hand in Hand gehen, um Marktuncertainty früh zu erkennen.',
        date: '12. Februar 2024',
        link: '#'
      },
      {
        title: 'Explainability bei Zeitreihen: Transparente Entscheidungen für Fachbereiche',
        excerpt:
          'Feature-Attribution, kontrafaktische Analysen und Visualisierungstechniken sorgen für Vertrauen in Prognosen.',
        date: '29. Januar 2024',
        link: '#'
      },
      {
        title: 'Signalrouter: Alerts zielgerichtet orchestrieren',
        excerpt:
          'Ein tiefer Einblick in Eskalationspfade, Kapazitätssteuerung und präzise Kollaborationsabläufe.',
        date: '10. Januar 2024',
        link: '#'
      }
    ],
    []
  );

  const [selectedFilter, setSelectedFilter] = useState('Alle');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [statsActive, setStatsActive] = useState(false);
  const statsRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting) {
          setStatsActive(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!statsActive) return;

    const intervals = statsData.map((stat, index) => {
      const duration = 1200;
      const frameRate = 16;
      const totalFrames = duration / frameRate;
      const increment = stat.value / totalFrames;
      return setInterval(() => {
        setAnimatedStats((prev) => {
          const updated = [...prev];
          if (updated[index] < stat.value) {
            updated[index] = Math.min(stat.value, updated[index] + increment);
          }
          return updated;
        });
      }, frameRate);
    });

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, [statsActive, statsData]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const filteredProjects =
    selectedFilter === 'Alle'
      ? projects
      : projects.filter((project) => project.category === selectedFilter);

  const filters = ['Alle', 'E-Commerce & Handel', 'Rohstoffe', 'Energie', 'Mobilität', 'Medien'];

  const organizationSchema = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Tredifynix',
    url: 'https://tredifynix.com',
    logo: 'https://tredifynix.com/logo.png',
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: '+49 40 98765432',
      contactType: 'customer support',
      areaServed: 'DE',
      availableLanguage: ['de', 'en']
    },
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Neuer Wall 50',
      addressLocality: 'Hamburg',
      postalCode: '20354',
      addressCountry: 'DE'
    }
  };

  const softwareSchema = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: 'Tredifynix Plattform',
    applicationCategory: 'BusinessApplication',
    operatingSystem: 'Web',
    offers: {
      '@type': 'Offer',
      availability: 'https://schema.org/InStock'
    },
    url: 'https://tredifynix.com',
    publisher: {
      '@type': 'Organization',
      name: 'Tredifynix'
    }
  };

  return (
    <>
      <Helmet>
        <title>Tredifynix – Markttrend-Prognosen für den deutschen Markt</title>
        <meta
          name="description"
          content="Tredifynix liefert präzise Markttrend-Prognosen für den deutschen Markt. Forecasting, Signale, Dashboards und Integrationen aus einer DSGVO-konformen Plattform."
        />
        <meta property="og:title" content="Tredifynix – Markttrend-Prognosen" />
        <meta
          property="og:description"
          content="Forecasting, Signale, Dashboards und Integrationen für Markttrends in Deutschland."
        />
        <meta property="og:url" content="https://tredifynix.com/" />
        <link rel="canonical" href="https://tredifynix.com/" />
        <script type="application/ld+json">{JSON.stringify(organizationSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(softwareSchema)}</script>
      </Helmet>

      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <div className={styles.heroContent}>
            <div className={styles.heroText}>
              <h1>Erkenne Markttrends frühzeitig</h1>
              <p>
                Tredifynix vereint Zeitreihen- und Machine-Learning-Modelle, um Marktbewegungen auf
                dem deutschen Markt in Echtzeit sichtbar zu machen. Unsere Plattform verbindet
                Datenquellen, trainiert Modelle automatisiert und liefert Signale dorthin, wo sie
                Entscheidungen unterstützen.
              </p>
              <div className={styles.heroActions}>
                <Link to="/kontakt" className="btn btnPrimary">
                  Jetzt starten
                </Link>
                <Link to="/funktionen" className="btn btnGhost">
                  Funktionen ansehen
                </Link>
              </div>
            </div>
            <div className={styles.heroMedia}>
              <img
                src="https://picsum.photos/1600/900?random=1"
                alt="Moderne Visualisierung von Trenddaten und Dashboards"
                className={styles.heroImage}
                loading="lazy"
              />
              <div className={styles.heroBadge}>
                <span>Realtime Insights</span>
                <strong>Signalbereitstellung unter 15 Sekunden</strong>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.introSection}`}>
        <div className="container">
          <div className={styles.introGrid}>
            <div>
              <h2>Was ist Tredifynix?</h2>
              <p>
                Tredifynix ist die deutsche SaaS-Plattform, die Markttrends aus Streaming- und
                historischen Daten herleitet. Wir stellen sicher, dass Analystinnen, Planer und
                Führungskräfte bedarfsgerecht informiert werden – nachvollziehbar, skalierbar und
                stets abgesichert.
              </p>
            </div>
            <div className={styles.introCard}>
              <h3>Unser Fokus</h3>
              <ul>
                <li>Datenanbindung ohne Medienbrüche</li>
                <li>Mehrstufige Forecasting-Modelle</li>
                <li>Signale und Alerts mit Kontext</li>
                <li>Dashboards für Stakeholder in Echtzeit</li>
              </ul>
              <Link to="/ressourcen" className="btn btnSecondary">
                Technische Doku öffnen
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.featuresSection}`}>
        <div className="container">
          <h2>Funktionen, die überzeugen</h2>
          <div className={styles.featureGrid}>
            <article className={styles.featureCard}>
              <div className={styles.featureIcon} aria-hidden="true">
                ⛅
              </div>
              <h3>Forecasting</h3>
              <p>
                Adaptive Zeitreihenmodelle, Ensembles und externe Signale bilden das Herzstück.
                Szenarien werden automatisch aktualisiert.
              </p>
            </article>
            <article className={styles.featureCard}>
              <div className={styles.featureIcon} aria-hidden="true">
                🔔
              </div>
              <h3>Signale</h3>
              <p>
                Konfigurierbare Trigger, Eskalationsketten und Webhooks sorgen für zielgerichtete
                Kommunikation ohne Verzögerung.
              </p>
            </article>
            <article className={styles.featureCard}>
              <div className={styles.featureIcon} aria-hidden="true">
                📊
              </div>
              <h3>Dashboards</h3>
              <p>
                Dynamic Views mit Multi-Asset-Perspektive, flexiblen Zeitfenstern und granularen
                Metriken für jede Perspektive.
              </p>
            </article>
            <article className={styles.featureCard}>
              <div className={styles.featureIcon} aria-hidden="true">
                🔗
              </div>
              <h3>API Integration</h3>
              <p>
                Vollständige REST- und Streaming-Schnittstellen, Authentifizierung via OAuth2 und
                SDKs für Python, TypeScript und Java.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.processSection}`}>
        <div className="container">
          <h2>So funktioniert Tredifynix</h2>
          <div className={styles.processGrid}>
            <div className={styles.processItem}>
              <span className={styles.stepNumber}>01</span>
              <h3>Daten anschließen</h3>
              <p>Interne Systeme und externe Feeds werden standardisiert eingebunden.</p>
            </div>
            <div className={styles.processItem}>
              <span className={styles.stepNumber}>02</span>
              <h3>Modelle trainieren</h3>
              <p>Feature-Engineering, Validierung und Monitoring laufen automatisiert.</p>
            </div>
            <div className={styles.processItem}>
              <span className={styles.stepNumber}>03</span>
              <h3>Signale versenden</h3>
              <p>Alerts gelangen zu Teams oder Anwendungen – priorisiert und nachvollziehbar.</p>
            </div>
            <div className={styles.processItem}>
              <span className={styles.stepNumber}>04</span>
              <h3>Ergebnisse überwachen</h3>
              <p>Dashboards, Audits und Drift-Checks halten jede Pipeline transparent.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.whySection}`}>
        <div className="container">
          <h2>Warum Tredifynix?</h2>
          <div className={styles.whyGrid}>
            <div className={styles.whyCard}>
              <h3>End-to-End Transparenz</h3>
              <p>
                Von der Datenannahme bis zur Nutzung: Jeder Schritt ist dokumentiert, versioniert
                und nachvollziehbar.
              </p>
            </div>
            <div className={styles.whyCard}>
              <h3>DSGVO-konforme Umsetzung</h3>
              <p>
                Daten bleiben in der EU, werden verschlüsselt übertragen und fein granular
                berechtigt.
              </p>
            </div>
            <div className={styles.whyCard}>
              <h3>Flexible Integrationen</h3>
              <p>
                Verbinden Sie Tredifynix mit BI-Tools, Kollaborationsplattformen oder bestehenden
                Datenlandschaften.
              </p>
            </div>
            <div className={styles.whyCard}>
              <h3>Forschungsnaher Ansatz</h3>
              <p>
                Unser Team arbeitet eng mit Forschungseinrichtungen zusammen und überführt aktuelle
                Methoden in produktive Anwendungen.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.statsSection}`} ref={statsRef}>
        <div className="container">
          <h2>Messbare Ergebnisse</h2>
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {Math.round(animatedStats[index])}
                  {stat.label.includes('%') ? '%' : ''}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.successSection}`}>
        <div className="container">
          <h2>Geschichten aus der Praxis</h2>
          <div className={styles.successGrid}>
            <article className={styles.successCard}>
              <h3>Regionale Handelsgruppe</h3>
              <p>
                Steigerung der Absatzplanungstreffsicherheit um 18 Prozentpunkte durch Einbindung
                externer Indikatoren in städtischen Regionen.
              </p>
              <ul>
                <li>KPI: Planungsgenauigkeit +18</li>
                <li>KPI: Reaktionszeit 14 Minuten</li>
                <li>KPI: Modellstabilität 97%</li>
              </ul>
            </article>
            <article className={styles.successCard}>
              <h3>Energieanbieter Nord</h3>
              <p>
                Einführung eines Frühwarnsystems für Lastspitzen inklusive Eskalation an
                Bereitschaftsdienste.
              </p>
              <ul>
                <li>KPI: Forecast-Präzision +12</li>
                <li>KPI: Signallatenz 9 Sekunden</li>
                <li>KPI: Drift-Inzidenz -35%</li>
              </ul>
            </article>
            <article className={styles.successCard}>
              <h3>Mobilitätsprovider</h3>
              <p>
                Aufbau eines Modells zur Flottenpositionierung mit Rolling Windows und Echtzeitdaten
                aus Fahrzeugen.
              </p>
              <ul>
                <li>KPI: Auslastung +15</li>
                <li>KPI: Alert-Zuverlässigkeit 99%</li>
                <li>KPI: Datenabdeckung 92%</li>
              </ul>
            </article>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.testimonialSection}`}>
        <div className="container">
          <div className={styles.testimonialHeader}>
            <h2>Vertrauen aus Fachbereichen und Daten-Teams</h2>
            <div className={styles.testimonialControls}>
              <button
                onClick={() =>
                  setCurrentTestimonial((prev) =>
                    prev === 0 ? testimonials.length - 1 : prev - 1
                  )
                }
                aria-label="Vorheriges Zitat anzeigen"
              >
                ←
              </button>
              <button
                onClick={() =>
                  setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
                }
                aria-label="Nächstes Zitat anzeigen"
              >
                →
              </button>
            </div>
          </div>
          <div className={styles.testimonialCard}>
            <p className={styles.testimonialQuote}>
              “{testimonials[currentTestimonial].quote}”
            </p>
            <p className={styles.testimonialMeta}>
              {testimonials[currentTestimonial].name}{' '}
              <span>· {testimonials[currentTestimonial].role}</span>
            </p>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.projectsSection}`}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <h2>Projekt-Highlights</h2>
            <div className={styles.filterGroup} role="tablist">
              {filters.map((filter) => (
                <button
                  key={filter}
                  onClick={() => setSelectedFilter(filter)}
                  className={`${styles.filterButton} ${
                    selectedFilter === filter ? styles.filterActive : ''
                  }`}
                  role="tab"
                  aria-selected={selectedFilter === filter}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img
                    src={project.image}
                    alt={project.alt}
                    loading="lazy"
                    className={styles.projectImage}
                  />
                  <span className={styles.projectCategory}>{project.category}</span>
                </div>
                <div className={styles.projectContent}>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/kontakt" className={styles.projectLink}>
                    Demo anfragen
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.faqSection}`}>
        <div className="container">
          <h2>Häufige Fragen</h2>
          <div className={styles.faqList}>
            {faqs.map((faq, index) => (
              <details key={faq.question} className={styles.faqItem}>
                <summary>
                  <span>{faq.question}</span>
                  <span aria-hidden="true" className={styles.faqIcon}>
                    +
                  </span>
                </summary>
                <p>{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.blogSection}`}>
        <div className="container">
          <div className={styles.blogHeader}>
            <h2>Insights aus dem Tredifynix Lab</h2>
            <Link to="/ressourcen" className={styles.blogLink}>
              Alle Ressourcen ansehen →
            </Link>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogMeta}>{post.date}</div>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <a href={post.link} className={styles.blogMore} aria-label={`Mehr zu ${post.title}`}>
                  Weiterlesen
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.ctaSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Bereit für präzise Prognosen?</h2>
            <p>
              Verbinden Sie Tredifynix mit Ihren Datenquellen und schaffen Sie ein
              Entscheidungsfundament, das jede Abteilung unterstützt. Unser Team begleitet Sie von
              der Integration bis zur täglichen Anwendung.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/kontakt" className="btn btnPrimary">
                Jetzt starten
              </Link>
              <Link to="/ressourcen" className="btn btnSecondary">
                Demo anfragen
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;