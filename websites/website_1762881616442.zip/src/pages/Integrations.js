import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Integrations.module.css';

const Integrations = () => {
  const integrationGroups = useMemo(
    () => [
      {
        title: 'Data Warehouses',
        description:
          'Anbindung via Konnektoren zu Snowflake, BigQuery, Azure Synapse, AWS Redshift und SQL Server. Inklusive Schema-Mapping und Monitoring.',
        items: ['Versionierte Pipelines', 'Credential Rotation', 'Automatisierte Tests']
      },
      {
        title: 'Streaming & Messaging',
        description:
          'Kafka, AWS Kinesis, Azure Event Hubs und MQTT für Echtzeitströmung. Transformationen mit minimaler Latenz.',
        items: ['Schema Registry Support', 'Backpressure Management', 'Garantie der Reihenfolge']
      },
      {
        title: 'Collaboration & BI',
        description:
          'Integration in Microsoft Teams, Slack, Jira, Tableau, Power BI und Looker. Alerts erscheinen dort, wo Teams arbeiten.',
        items: ['Embeddable Dashboards', 'Adaptive Rollen und Rechte', 'Activity Logs']
      }
    ],
    []
  );

  return (
    <>
      <Helmet>
        <title>Tredifynix Integrationen – Datenflüsse nahtlos verbinden</title>
        <meta
          name="description"
          content="Tredifynix verbindet sich mit Data Warehouses, Streaming-Systemen sowie Collaboration- und BI-Tools. Erleben Sie reibungslose Integrationen."
        />
        <link rel="canonical" href="https://tredifynix.com/integrationen" />
      </Helmet>

      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <h1>Integrationen</h1>
          <p>
            Tredifynix fügt sich in bestehende Architektur ein. Wir unterstützen gängige
            Datenplattformen, Messaging-Systeme und Kollaborationstools – vollständig auditierbar.
          </p>
        </div>
      </section>

      <section className={`${styles.integrationSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.integrationGrid}>
            {integrationGroups.map((group) => (
              <article key={group.title} className={styles.integrationCard}>
                <h2>{group.title}</h2>
                <p>{group.description}</p>
                <ul>
                  {group.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.integrationCTA} sectionSpacing`}>
        <div className="container">
          <h2>Integration starten</h2>
          <p>
            Unsere Engineers begleiten die End-to-End-Integration. Von Credentials über
            Transformationen bis hin zu QA und Monitoring nehmen wir Sie mit in jede Phase.
          </p>
          <a href="/kontakt" className="btn btnPrimary">
            Jetzt starten
          </a>
        </div>
      </section>
    </>
  );
};

export default Integrations;