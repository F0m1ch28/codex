import React from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Legal.module.css';

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Tredifynix Cookie-Richtlinie – Transparente Nutzung</title>
        <meta
          name="description"
          content="Tredifynix informiert über den Einsatz von Cookies. Erfahren Sie, welche Cookies gesetzt werden und wie Sie diese steuern."
        />
        <link rel="canonical" href="https://tredifynix.com/cookie-richtlinie" />
      </Helmet>

      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <h1>Cookie-Richtlinie</h1>
          <p>Stand: 15. Februar 2024</p>
        </div>
      </section>

      <section className={`${styles.legalSection} sectionSpacing`}>
        <div className="container">
          <h2>1. Was sind Cookies?</h2>
          <p>
            Cookies sind kleine Textdateien, die auf Ihrem Endgerät gespeichert werden. Sie helfen,
            die Nutzung der Plattform sicher und komfortabel zu gestalten.
          </p>

          <h2>2. Essenzielle Cookies</h2>
          <p>
            Diese Cookies sind notwendig, um die Plattform zu betreiben. Sie stellen Authentifizierung,
            Session-Handling und Sicherheitsfunktionen bereit.
          </p>

          <h2>3. Analyse-Cookies</h2>
          <p>
            Wir setzen anonymisierte Analyse-Cookies ein, um Nutzungsmuster zu verstehen. Die Daten
            werden aggregiert ausgewertet und dienen der Verbesserung der Plattform.
          </p>

          <h2>4. Verwaltung</h2>
          <p>
            Sie können Ihre Cookie-Präferenzen jederzeit über den Hinweis im Seitenfuß anpassen.
            Zusätzlich lässt sich die Speicherung in Ihrem Browser deaktivieren.
          </p>

          <h2>5. Kontakt</h2>
          <p>
            Bei Fragen zur Cookie-Nutzung wenden Sie sich bitte an info@tredifynix.com.
          </p>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;