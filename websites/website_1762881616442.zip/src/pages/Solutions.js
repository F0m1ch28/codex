import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Solutions.module.css';

const Solutions = () => {
  const solutions = useMemo(
    () => [
      {
        title: 'E-Commerce Nachfrage',
        description:
          'Kombiniert Warenwirtschaft, Kampagnen und externe Indikatoren, um Nachfragekurven, Trendbrüche und saisonale Effekte zu erkennen.',
        benefits: [
          'Rolling Forecasts für Sortimente und Regionen',
          'Alerting bei Abverkaufsanomalien',
          'Planungssicherheit für Beschaffung und Logistik'
        ]
      },
      {
        title: 'Rohstoffmonitoring',
        description:
          'Aggregiert Lieferzeiten, Handelsdaten und Wettereinflüsse für vorausschauende Steuerung von Produktionskapazitäten.',
        benefits: [
          'Früherkennung von Versorgungseinschränkungen',
          'Szenarien für Produktionsplanung',
          'Auditable Reports für Einkauf und Compliance'
        ]
      },
      {
        title: 'Energie',
        description:
          'Prognosen zu Netzbelastung, Verbrauch und Einspeisung auf Basis von Smart Metering, Märkten und Wettermodellen.',
        benefits: [
          'Sekundenschnelle Alerts bei Lastspitzen',
          'Transparenz über Netzstabilität',
          'Integration in Dispatching und Leitstellen'
        ]
      },
      {
        title: 'Mobilität',
        description:
          'Flottensteuerung und Nachfrageprognosen für ÖPNV, Car- und Bike-Sharing mit granularen Geo-Zeit-Modellen.',
        benefits: [
          'Ressourceneinsatz nach Nachfrageprofilen',
          'Predictive Maintenance Signale',
          'Nahtlose Anbindung an operative Systeme'
        ]
      },
      {
        title: 'Medien & Streaming',
        description:
          'Publikumsprognosen, Content-Performance und Kampagnenwirkung mit Regressoren aus Social, CRM und Gerätefeeds.',
        benefits: [
          'Programmpakete zielgerichtet planen',
          'Feinjustierung von Kampagnen in Echtzeit',
          'Distributionsplanung mittels Szenarien'
        ]
      }
    ],
    []
  );

  return (
    <>
      <Helmet>
        <title>Tredifynix Lösungen – Branchenorientierte Markttrends</title>
        <meta
          name="description"
          content="Tredifynix bietet Lösungen für E-Commerce, Rohstoffe, Energie, Mobilität und Medien. Entdecken Sie, wie unsere Plattform Branchenteams unterstützt."
        />
        <link rel="canonical" href="https://tredifynix.com/loesungen" />
      </Helmet>

      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <h1>Lösungen nach Branchen</h1>
          <p>
            In enger Zusammenarbeit mit Fachbereichen entwickeln wir Use Cases, die Daten,
            Algorithmen und Prozesse verlässlich zusammenbringen.
          </p>
        </div>
      </section>

      <section className={`${styles.solutionList} sectionSpacing`}>
        <div className="container">
          {solutions.map((solution) => (
            <article key={solution.title} className={styles.solutionCard}>
              <h2>{solution.title}</h2>
              <p>{solution.description}</p>
              <ul>
                {solution.benefits.map((benefit) => (
                  <li key={benefit}>{benefit}</li>
                ))}
              </ul>
              <a href="/kontakt" className={styles.solutionLink}>
                Kontakt aufnehmen →
              </a>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Solutions;