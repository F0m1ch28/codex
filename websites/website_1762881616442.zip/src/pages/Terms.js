import React from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Legal.module.css';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Tredifynix Nutzungsbedingungen – Rechtliche Hinweise</title>
        <meta
          name="description"
          content="Lesen Sie die Nutzungsbedingungen von Tredifynix. Transparente Regelungen für die Nutzung der Markttrend-Plattform."
        />
        <link rel="canonical" href="https://tredifynix.com/nutzungsbedingungen" />
      </Helmet>

      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <h1>Nutzungsbedingungen</h1>
          <p>Stand: 15. Februar 2024</p>
        </div>
      </section>

      <section className={`${styles.legalSection} sectionSpacing`}>
        <div className="container">
          <h2>1. Geltungsbereich</h2>
          <p>
            Diese Nutzungsbedingungen regeln die Nutzung der Plattform Tredifynix unter
            tredifynix.com. Sie gelten für sämtliche registrierten Organisationen und deren
            autorisierte Nutzerinnen und Nutzer.
          </p>

          <h2>2. Zugang zur Plattform</h2>
          <p>
            Der Zugang erfolgt über individualisierte Accounts. Nutzerinnen und Nutzer sind
            verpflichtet, Zugangsdaten vertraulich zu behandeln und Missbrauch umgehend zu melden.
          </p>

          <h2>3. Leistungsumfang</h2>
          <p>
            Tredifynix stellt Funktionen für Datenintegration, Modellierung, Analyse und Visualisierung
            bereit. Der konkrete Funktionsumfang richtet sich nach dem vereinbarten Leistungsprofil.
          </p>

          <h2>4. Nutzungspflichten</h2>
          <ul>
            <li>
              Es dürfen ausschließlich rechtmäßig erlangte Daten eingebracht werden, für die passende
              Nutzungsrechte vorliegen.
            </li>
            <li>
              Sicherheitsmechanismen der Plattform dürfen nicht umgangen oder beeinträchtigt werden.
            </li>
            <li>
              Ergebnisse der Plattform sind vor kritischen Entscheidungen angemessen zu validieren.
            </li>
          </ul>

          <h2>5. Verfügbarkeit</h2>
          <p>
            Tredifynix bemüht sich um hohe Verfügbarkeit. Wartungsfenster werden nach Möglichkeit
            angekündigt. Ereignisse höherer Gewalt können die Erreichbarkeit einschränken.
          </p>

          <h2>6. Haftung</h2>
          <p>
            Für einfache Fahrlässigkeit haftet Tredifynix nur bei Verletzung wesentlicher Vertragspflichten.
            Die Haftung für Folgeschäden wird ausgeschlossen, soweit gesetzlich zulässig.
          </p>

          <h2>7. Änderungen</h2>
          <p>
            Tredifynix kann diese Bedingungen anpassen. Nutzerinnen und Nutzer werden über Änderungen
            informiert. Widerspruch berechtigt zur Beendigung der Nutzung.
          </p>

          <h2>8. Schlussbestimmungen</h2>
          <p>
            Es gilt deutsches Recht. Gerichtsstand ist, soweit zulässig, Hamburg. Sollte eine
            Bestimmung unwirksam sein, bleibt die Wirksamkeit der übrigen Regelungen unberührt.
          </p>
        </div>
      </section>
    </>
  );
};

export default Terms;