import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Security.module.css';

const Security = () => {
  const principles = useMemo(
    () => [
      {
        title: 'DSGVO-Framework',
        description:
          'Verarbeitung ausschließlich in EU-Rechenzentren, Auftragsverarbeitungsverträge und Datenschutz-Folgenabschätzungen nach Bedarf.'
      },
      {
        title: 'Datenresidenz',
        description:
          'Mandantenbasierte Isolation, Verschlüsselung im Ruhezustand und bei Übertragung, Schlüsselverwaltung via HSM.'
      },
      {
        title: 'Rollen & Rechte',
        description:
          'Feingranulare RBAC, Attribute Based Control und Integration in Identity Provider per SCIM.'
      },
      {
        title: 'Audits & Monitoring',
        description:
          'Lückenlose Audit-Logs, manipulationsgeschützt gespeichert. Security Dashboards mit Echtzeit-Monitoring.'
      }
    ],
    []
  );

  return (
    <>
      <Helmet>
        <title>Tredifynix Sicherheit – Datenschutz und Governance</title>
        <meta
          name="description"
          content="Tredifynix erfüllt höchste Sicherheitsanforderungen: DSGVO, Datenresidenz in der EU, Verschlüsselung, Rollenrechte und Audit Trails."
        />
        <link rel="canonical" href="https://tredifynix.com/sicherheit" />
      </Helmet>

      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <h1>Sicherheit und Governance</h1>
          <p>
            Als Plattform für sensible Prognosen stellen wir Sicherheit, Datenschutz und Auditierbarkeit
            in den Mittelpunkt.
          </p>
        </div>
      </section>

      <section className={`${styles.principles} sectionSpacing`}>
        <div className="container">
          <div className={styles.principlesGrid}>
            {principles.map((principle) => (
              <article key={principle.title} className={styles.principlesCard}>
                <h2>{principle.title}</h2>
                <p>{principle.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.audit} sectionSpacing`}>
        <div className="container">
          <h2>Prüfprozesse</h2>
          <p>
            Wir lassen unsere Kontrollsysteme regelmäßig durch unabhängige Auditoren prüfen, führen
            Penetrationstests durch und halten Richtlinien wie ISO 27001 als Maßstab. Notfallpläne,
            Business Continuity und regelmäßige Schulungen sind fest verankert.
          </p>
        </div>
      </section>
    </>
  );
};

export default Security;