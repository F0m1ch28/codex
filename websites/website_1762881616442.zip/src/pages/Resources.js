import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Resources.module.css';

const Resources = () => {
  const resources = useMemo(
    () => [
      {
        type: 'Blog',
        title: 'Detection von Modell-Drift in volatilen Märkten',
        description:
          'Best Practices für Drift-Metriken, Re-Training und Governance in Enterprise-Umgebungen.',
        link: '#'
      },
      {
        type: 'Guide',
        title: 'Blueprint: Markttrend-Pipelines in 30 Tagen',
        description:
          'Ein Projektplan mit Rollen, Timelines und Kontrollpunkten für die Einführung von Tredifynix.',
        link: '#'
      },
      {
        type: 'Template',
        title: 'Stakeholder-Report Vorlage',
        description:
          'Konsistente Reports für Management und Fachbereiche – inklusive KPI-Definitionen.',
        link: '#'
      },
      {
        type: 'Webinar',
        title: 'Explainability in Echtzeitprozessen',
        description:
          'Live-Demo mit Showcases aus dem Energie- und Mobilitätssektor.',
        link: '#'
      },
      {
        type: 'Changelog',
        title: 'Release Notes Februar 2024',
        description:
          'Neue API-Endpunkte, zusätzliche Alert-Workflows und verbesserte Dashboards.',
        link: '#'
      }
    ],
    []
  );

  return (
    <>
      <Helmet>
        <title>Tredifynix Ressourcen – Wissen, Guides und Updates</title>
        <meta
          name="description"
          content="Greifen Sie auf Tredifynix Ressourcen zu: Blog, Guides, Templates, Webinare und Changelogs. Bleiben Sie über Markttrend-Prognosen informiert."
        />
        <link rel="canonical" href="https://tredifynix.com/ressourcen" />
      </Helmet>

      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <h1>Ressourcen</h1>
          <p>
            Nutzen Sie unser Wissen aus Projekten, Forschung und Produktentwicklung. Die Ressourcen
            helfen bei Planung, Implementierung und Skalierung von Markttrend-Prognosen.
          </p>
        </div>
      </section>

      <section className={`${styles.resourceList} sectionSpacing`}>
        <div className="container">
          <div className={styles.cards}>
            {resources.map((resource) => (
              <article key={resource.title} className={styles.card}>
                <span className={styles.cardType}>{resource.type}</span>
                <h2>{resource.title}</h2>
                <p>{resource.description}</p>
                <a href={resource.link} className={styles.cardLink}>
                  Technische Doku öffnen
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Resources;