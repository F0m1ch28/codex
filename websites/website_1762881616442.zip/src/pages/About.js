import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/About.module.css';

const About = () => {
  const team = useMemo(
    () => [
      {
        name: 'Mira Schultz',
        role: 'CEO & Co-Founder',
        focus:
          'Strategische Ausrichtung und Partnerschaften mit Fokus auf deutsche Industrien.',
        image: 'https://picsum.photos/400/400?random=3',
        alt: 'Portrait von Mira Schultz'
      },
      {
        name: 'Dr. Jonas Weber',
        role: 'Chief Data Scientist',
        focus:
          'Forschung zu Zeitreihen-Ensembles, Feature Stores und Explainability.',
        image: 'https://picsum.photos/400/400?random=9',
        alt: 'Portrait von Dr. Jonas Weber'
      },
      {
        name: 'Helena Vogt',
        role: 'VP Product',
        focus:
          'Produkt- und UX-Strategie mit Schwerpunkt Analyst Experience und Collaboration.',
        image: 'https://picsum.photos/400/400?random=10',
        alt: 'Portrait von Helena Vogt'
      },
      {
        name: 'Ben Ohlendorf',
        role: 'Head of Engineering',
        focus:
          'Leitet Plattformentwicklung, DataOps und Security-Implementierungen.',
        image: 'https://picsum.photos/400/400?random=11',
        alt: 'Portrait von Ben Ohlendorf'
      }
    ],
    []
  );

  const milestones = useMemo(
    () => [
      {
        year: '2019',
        title: 'Gründung',
        description:
          'Tredifynix startet als Spin-off aus einem Hamburger Forschungsverbund für Marktanalysen.'
      },
      {
        year: '2020',
        title: 'Plattform-Launch',
        description:
          'Die erste Version der SaaS-Plattform geht live – mit Fokus auf Zeitreihen und Dashboards.'
      },
      {
        year: '2022',
        title: 'Signalrouter',
        description:
          'Einführung eines umfangreichen Alerting-Frameworks inklusive Eskalationsketten und Webhooks.'
      },
      {
        year: '2023',
        title: 'Explainability-Modul',
        description:
          'Shapley-Analysen, Counterfactuals und Transparenzberichte werden Teil der Kernplattform.'
      }
    ],
    []
  );

  return (
    <>
      <Helmet>
        <title>Tredifynix – Team, Geschichte und Mission</title>
        <meta
          name="description"
          content="Erfahren Sie mehr über das Tredifynix Team, unseren Forschungshintergrund und den Weg zur führenden Plattform für Markttrend-Prognosen in Deutschland."
        />
        <link rel="canonical" href="https://tredifynix.com/ueber-uns" />
      </Helmet>

      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <h1>Über Tredifynix</h1>
          <p>
            Wir entwickeln Tredifynix mit dem Anspruch, komplexe Marktdynamiken frühzeitig
            sichtbar zu machen. Forschung, Engineering und Branchenexpertise werden in Hamburg zu
            einer Plattform vereint, die Planungs- und Operativteams absichert.
          </p>
        </div>
      </section>

      <section className={`${styles.mission} sectionSpacing`}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div>
              <h2>Unsere Mission</h2>
              <p>
                Tredifynix befähigt Unternehmen, Marktbewegungen nicht nur zu beobachten,
                sondern aktiv zu steuern. Wir verbinden Datenwissenschaft mit branchenspezifischem
                Wissen, damit Prognosen zur verlässlichen Entscheidungsgrundlage werden.
              </p>
            </div>
            <div className={styles.missionCard}>
              <h3>Forschungsbasierter Ansatz</h3>
              <p>
                Wir arbeiten mit Hochschulen aus Hamburg, Berlin und München zusammen, testen neue
                Modelle in unseren Labs und überführen die Ergebnisse in produktive Pipelines.
              </p>
              <h3>Commitment zur Transparenz</h3>
              <p>
                Jede Vorhersage erhält Kontext und Erklärbarkeit. Durch strukturierte Reports
                schaffen wir Vertrauen bei Fachabteilungen.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.milestones} sectionSpacing`}>
        <div className="container">
          <h2>Meilensteine</h2>
          <div className={styles.timeline}>
            {milestones.map((milestone) => (
              <div key={milestone.year} className={styles.timelineItem}>
                <div className={styles.timelineYear}>{milestone.year}</div>
                <div className={styles.timelineContent}>
                  <h3>{milestone.title}</h3>
                  <p>{milestone.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.team} sectionSpacing`}>
        <div className="container">
          <h2>Unser Team</h2>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard} tabIndex="0">
                <img src={member.image} alt={member.alt} loading="lazy" />
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p>{member.focus}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.values} sectionSpacing`}>
        <div className="container">
          <h2>Unsere Werte</h2>
          <div className={styles.valuesGrid}>
            <div className={styles.valueCard}>
              <h3>Verbindlichkeit</h3>
              <p>
                Wir geben nur Zusagen, die wir mit belastbaren Daten halten können. Das gilt
                intern wie extern.
              </p>
            </div>
            <div className={styles.valueCard}>
              <h3>Verstehen & Erklären</h3>
              <p>
                Ein Modell ist nur so stark wie seine Verständlichkeit. Darum begleiten wir
                Fachbereiche bei jedem Schritt.
              </p>
            </div>
            <div className={styles.valueCard}>
              <h3>Gemeinsam wachsen</h3>
              <p>
                Wir setzen auf langfristige Partnerschaften, um Branchenanforderungen kontinuierlich
                in Produktentwicklungen zu übersetzen.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;