import React from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Legal.module.css';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Tredifynix Datenschutz – Informationen gemäß DSGVO</title>
        <meta
          name="description"
          content="Erfahren Sie, wie Tredifynix personenbezogene Daten verarbeitet. Alle Informationen zur DSGVO-Konformität und Ihren Rechten."
        />
        <link rel="canonical" href="https://tredifynix.com/datenschutz" />
      </Helmet>

      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <h1>Datenschutzerklärung</h1>
          <p>Stand: 15. Februar 2024</p>
        </div>
      </section>

      <section className={`${styles.legalSection} sectionSpacing`}>
        <div className="container">
          <h2>1. Verantwortlicher</h2>
          <p>
            Verantwortlich im Sinne der DSGVO ist die Tredifynix GmbH, Neuer Wall 50, 20354 Hamburg,
            Deutschland. Kontakt: info@tredifynix.com.
          </p>

          <h2>2. Verarbeitete Daten</h2>
          <p>
            Wir verarbeiten Stammdaten, Nutzungsdaten, Kommunikationsinhalte sowie Protokolldaten,
            soweit dies für Bereitstellung, Sicherheit und Weiterentwicklung erforderlich ist.
          </p>

          <h2>3. Zweck und Rechtsgrundlagen</h2>
          <p>
            Die Verarbeitung erfolgt zur Vertragserfüllung (Art. 6 Abs. 1 lit. b DSGVO), zur
            Verbesserung und Absicherung der Dienste (Art. 6 Abs. 1 lit. f DSGVO) sowie zur Erfüllung
            rechtlicher Verpflichtungen (Art. 6 Abs. 1 lit. c DSGVO).
          </p>

          <h2>4. Auftragsverarbeitung</h2>
          <p>
            Bei Einbindung externer Dienstleister schließen wir Auftragsverarbeitungsverträge gemäß
            Art. 28 DSGVO. Eine Verarbeitung außerhalb der EU erfolgt nicht.
          </p>

          <h2>5. Betroffenenrechte</h2>
          <p>
            Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung,
            Datenübertragbarkeit sowie Widerspruch. Anfragen senden Sie bitte an info@tredifynix.com.
          </p>

          <h2>6. Speicherdauer</h2>
          <p>
            Daten speichern wir nur so lange, wie es für den jeweiligen Zweck erforderlich ist.
            Vertrags- und Abrechnungsdaten werden entsprechend gesetzlicher Aufbewahrungspflichten vorgehalten.
          </p>

          <h2>7. Sicherheit</h2>
          <p>
            Wir setzen technische und organisatorische Maßnahmen wie Verschlüsselung,
            Zugriffskontrollen, Monitoring und Schulungen ein, um Ihre Daten zu schützen.
          </p>

          <h2>8. Beschwerderecht</h2>
          <p>
            Sie können sich bei einer Datenschutzaufsichtsbehörde beschweren. Zuständig für Hamburg
            ist der Hamburgische Beauftragte für Datenschutz und Informationsfreiheit.
          </p>
        </div>
      </section>
    </>
  );
};

export default Privacy;