import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Services.module.css';

const Services = () => {
  const featureBlocks = useMemo(
    () => [
      {
        title: 'Zeitreihen- & ML-Modelle',
        points: [
          'ARIMA, Prophet, Deep Learning Ensembles sowie hybride Ansätze',
          'Feature Store für externe Parameter wie Wetter, Makroindikatoren oder Web-Traffic',
          'Automatisches Hyperparameter-Tuning und kontinuierliche Retrain-Strategien'
        ]
      },
      {
        title: 'Signale & Alerts',
        points: [
          'Konfigurierbare Trigger, Schwellenwerte und Trendbrüche',
          'Eskalationslogik mit Rollen, Bereitschaftsplänen und Quittierungen',
          'Webhook-Integration und Messaging-Connectoren zu Teams, Slack und E-Mail'
        ]
      },
      {
        title: 'Dashboards',
        points: [
          'Multi-Asset-Sichten mit Filter-, Drilldown- und Vergleichsfunktionen',
          'Zeitscheiben von Minuten bis Quartalen, inklusive Rolling Windows',
          'Metriken für Forecast Accuracy, Abweichungen, Drift und Abdeckung'
        ]
      },
      {
        title: 'Backtesting & Evaluation',
        points: [
          'Historische Simulationen mit konfigurierbaren Fenstern',
          'KPIs wie MAPE, RMSE, sMAPE, Pinball Loss und Service Level Agreements',
          'Drift-Erkennung, Bias-Checks und automatische Alerts bei Abweichungen'
        ]
      },
      {
        title: 'API & SDKs',
        points: [
          'REST, GraphQL und Streaming-Endpunkte für Batch und Echtzeit',
          'OAuth2 und Service Accounts, Secret Rotation und IP Allowlisting',
          'SDKs für Python, JavaScript/TypeScript und Java'
        ]
      },
      {
        title: 'Explainability',
        points: [
          'Shapley-Values, Partial Dependence Plots und Counterfactuals',
          'Vergleich von Modellversionen mit automatisierten Reports',
          'Exportierbare Erklärungsprotokolle für Audit und Compliance'
        ]
      }
    ],
    []
  );

  return (
    <>
      <Helmet>
        <title>Tredifynix Funktionen – Forecasting, Signale, Dashboards</title>
        <meta
          name="description"
          content="Erkunden Sie die Kernfunktionen von Tredifynix: Zeitreihen- und ML-Modelle, Signale, Dashboards, Backtesting, APIs und Explainability für den deutschen Markt."
        />
        <link rel="canonical" href="https://tredifynix.com/funktionen" />
      </Helmet>

      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <h1>Funktionen im Überblick</h1>
          <p>
            Tredifynix stellt ein modulares Set an Werkzeugen bereit, das Ihre Marktbeobachtung
            abbildet – von Data Engineering bis zur transparenten Bereitstellung von Prognosen.
          </p>
        </div>
      </section>

      <section className={`${styles.features} sectionSpacing`}>
        <div className="container">
          <div className={styles.featureGrid}>
            {featureBlocks.map((block) => (
              <article key={block.title} className={styles.featureCard}>
                <h2>{block.title}</h2>
                <ul>
                  {block.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.cta} sectionSpacing`}>
        <div className="container">
          <h2>Den gesamten Funktionsumfang nutzen</h2>
          <p>
            Unser Team unterstützt Sie bei der Auswahl der passenden Module und begleitet die
            Implementierung. Gemeinsam bauen wir eine Monitoringschicht auf, die Ihre Prozesse
            stärkt.
          </p>
          <a href="/kontakt" className="btn btnPrimary">
            Demo anfragen
          </a>
        </div>
      </section>
    </>
  );
};

export default Services;