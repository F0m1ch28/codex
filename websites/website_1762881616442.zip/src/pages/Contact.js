import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    topic: 'Technischer Support',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validateEmail = (email) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim().toLowerCase());

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Bitte geben Sie Ihren Namen an.';
    }
    if (!validateEmail(formData.email)) {
      newErrors.email = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Bitte schildern Sie Ihr Anliegen.';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setSubmitted(true);
    setFormData({
      name: '',
      email: '',
      company: '',
      topic: 'Technischer Support',
      message: ''
    });
  };

  return (
    <>
      <Helmet>
        <title>Tredifynix Kontakt – Sprechen Sie mit unserem Team</title>
        <meta
          name="description"
          content="Kontaktieren Sie Tredifynix für technische Fragen, Integrationen oder Partnerschaften. Unser Team in Hamburg unterstützt Sie schnell."
        />
        <link rel="canonical" href="https://tredifynix.com/kontakt" />
      </Helmet>

      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <h1>Kontakt</h1>
          <p>
            Teilen Sie uns Ihr Anliegen mit. Unser Team meldet sich schnellstmöglich mit passenden
            Informationen.
          </p>
        </div>
      </section>

      <section className={`${styles.contactSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.contactGrid}>
            <div className={styles.contactInfo}>
              <h2>Direkter Draht</h2>
              <p>
                Tredifynix GmbH<br />
                Neuer Wall 50<br />
                20354 Hamburg, Deutschland
              </p>
              <p>
                Telefon:{' '}
                <a href="tel:+494098765432" className={styles.contactLink}>
                  +49 40 98765432
                </a>
                <br />
                E-Mail:{' '}
                <a href="mailto:info@tredifynix.com" className={styles.contactLink}>
                  info@tredifynix.com
                </a>
              </p>
              <h3>Anliegen</h3>
              <ul className={styles.topicList}>
                <li>Technischer Support</li>
                <li>Integrationen & Datenflüsse</li>
                <li>Partnerschaften & Kooperationen</li>
              </ul>
            </div>

            <form className={styles.contactForm} onSubmit={handleSubmit} noValidate>
              <div className={styles.formGroup}>
                <label htmlFor="name">Name *</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={errors.name ? 'true' : 'false'}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>

              <div className={styles.formGroup}>
                <label htmlFor="email">E-Mail *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={errors.email ? 'true' : 'false'}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>

              <div className={styles.formGroup}>
                <label htmlFor="company">Unternehmen</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={formData.company}
                  onChange={handleChange}
                />
              </div>

              <div className={styles.formGroup}>
                <label htmlFor="topic">Thema</label>
                <select
                  id="topic"
                  name="topic"
                  value={formData.topic}
                  onChange={handleChange}
                >
                  <option>Technischer Support</option>
                  <option>Integrationen</option>
                  <option>Partnerschaften</option>
                  <option>Allgemeine Anfrage</option>
                </select>
              </div>

              <div className={styles.formGroup}>
                <label htmlFor="message">Nachricht *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={errors.message ? 'true' : 'false'}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>

              <button type="submit" className="btn btnPrimary">
                Nachricht senden
              </button>
              {submitted && (
                <p className={styles.success}>
                  Vielen Dank für Ihre Nachricht. Wir melden uns kurzfristig.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;