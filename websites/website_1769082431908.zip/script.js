document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = siteNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    siteNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (siteNav.classList.contains('is-open')) {
          siteNav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

  const yearElements = document.querySelectorAll('.current-year');
  const currentYear = new Date().getFullYear();
  yearElements.forEach(el => {
    el.textContent = currentYear;
  });

  const banner = document.querySelector('.cookie-banner');
  if (banner) {
    const storedChoice = localStorage.getItem('ecosalud-cookies');
    if (storedChoice) {
      banner.classList.add('is-hidden');
    } else {
      requestAnimationFrame(() => banner.classList.add('is-visible'));
    }

    const acceptBtn = banner.querySelector('.cookie-accept');
    const declineBtn = banner.querySelector('.cookie-decline');

    const setChoice = value => {
      localStorage.setItem('ecosalud-cookies', value);
      banner.classList.remove('is-visible');
      setTimeout(() => banner.classList.add('is-hidden'), 400);
    };

    acceptBtn?.addEventListener('click', () => setChoice('accepted'));
    declineBtn?.addEventListener('click', () => setChoice('declined'));
  }

  const forms = document.querySelectorAll('form[data-redirect]');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const redirectUrl = form.getAttribute('data-redirect') || 'thank-you.html';
      showToast('Mensaje enviado. Serás redirigido en breve.');
      setTimeout(() => {
        window.location.href = redirectUrl;
      }, 1400);
    });
  });

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.setAttribute('role', 'status');
    toast.textContent = message;
    document.body.appendChild(toast);
    requestAnimationFrame(() => {
      toast.classList.add('is-visible');
    });
    setTimeout(() => {
      toast.classList.remove('is-visible');
      setTimeout(() => toast.remove(), 400);
    }, 3000);
  }
});