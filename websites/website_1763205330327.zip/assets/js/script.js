document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = primaryNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });
    }

    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'instant' });
            if (primaryNav) {
                primaryNav.classList.remove('open');
            }
            if (navToggle) {
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    });

    const scrollButton = document.getElementById('scrollTop');
    if (scrollButton) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 200) {
                scrollButton.classList.add('visible');
            } else {
                scrollButton.classList.remove('visible');
            }
        });

        scrollButton.addEventListener('click', (event) => {
            event.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const forms = document.querySelectorAll('.contact-form');
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            event.preventDefault();
            const status = form.querySelector('.form-status');
            if (status) {
                status.textContent = 'Thank you for reaching out to Frontier Data Lab. Our team will respond within one business day.';
            }
            form.reset();
        });
    });

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const acceptButton = cookieBanner.querySelector('.accept-cookies');
        let hasConsent = false;

        try {
            hasConsent = localStorage.getItem('fdlCookieConsent') === 'accepted';
        } catch (error) {
            hasConsent = false;
        }

        if (hasConsent) {
            cookieBanner.classList.add('hidden');
            cookieBanner.setAttribute('aria-hidden', 'true');
        } else {
            cookieBanner.classList.remove('hidden');
            cookieBanner.setAttribute('aria-hidden', 'false');
        }

        if (acceptButton) {
            acceptButton.addEventListener('click', () => {
                try {
                    localStorage.setItem('fdlCookieConsent', 'accepted');
                } catch (error) {
                    // Ignore storage errors
                }
                cookieBanner.classList.add('hidden');
                cookieBanner.setAttribute('aria-hidden', 'true');
            });
        }
    }
});