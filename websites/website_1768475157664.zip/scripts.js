document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && navMenu && siteNav) {
        navToggle.addEventListener('click', function () {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!isExpanded).toString());
            navMenu.classList.toggle('is-open');
            siteNav.classList.toggle('is-visible');
        });

        const navLinks = navMenu.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 1024) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    navMenu.classList.remove('is-open');
                    siteNav.classList.remove('is-visible');
                }
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 1024) {
                navToggle.setAttribute('aria-expanded', 'false');
                navMenu.classList.remove('is-open');
                siteNav.classList.add('is-visible');
            } else {
                siteNav.classList.remove('is-visible');
            }
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookies = document.getElementById('acceptCookies');
    const declineCookies = document.getElementById('declineCookies');

    if (cookieBanner && acceptCookies && declineCookies) {
        const storedConsent = localStorage.getItem('mrhCookieConsent');

        if (storedConsent === 'accepted' || storedConsent === 'declined') {
            cookieBanner.classList.add('is-hidden');
        }

        acceptCookies.addEventListener('click', function () {
            localStorage.setItem('mrhCookieConsent', 'accepted');
            cookieBanner.classList.add('is-hidden');
        });

        declineCookies.addEventListener('click', function () {
            localStorage.setItem('mrhCookieConsent', 'declined');
            cookieBanner.classList.add('is-hidden');
        });
    }

    if (window.mermaid) {
        const mermaidBlocks = document.querySelectorAll('.mermaid');
        if (mermaidBlocks.length > 0) {
            window.mermaid.initialize({
                startOnLoad: false,
                theme: 'neutral',
                securityLevel: 'loose'
            });

            mermaidBlocks.forEach((block, index) => {
                if (!block.id) {
                    block.id = `mermaid-diagram-${index + 1}`;
                }
            });

            window.mermaid.run({
                nodes: mermaidBlocks
            });
        }
    }
});