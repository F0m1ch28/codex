/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html"
  ],
  theme: {
    extend: {
      colors: {
        primary: "#2563EB",
        slateDeep: "#0F172A",
        slateSurface: "#1E293B",
        slateMist: "#F1F5F9"
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        display: ["'Satoshi'", "Inter", "system-ui", "sans-serif"]
      },
      boxShadow: {
        soft: "0 15px 40px rgba(15, 23, 42, 0.12)"
      }
    }
  },
  plugins: []
}