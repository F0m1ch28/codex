import React from "react";
import { Routes, Route, Navigate, Outlet, useLocation } from "react-router-dom";
import { Helmet } from "react-helmet";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";

import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Installation from "./pages/Installation";
import Consulting from "./pages/Consulting";
import CaseStudies from "./pages/CaseStudies";
import Blog from "./pages/Blog";
import BlogArrayGeometry from "./pages/blog/ArrayGeometry";
import BlogInverterFamily from "./pages/blog/InverterFamily";
import BlogTelemetryStack from "./pages/blog/TelemetryStack";
import FAQ from "./pages/FAQ";
import Contact from "./pages/Contact";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import CookiePolicy from "./pages/CookiePolicy";

const PageLayout = () => (
  <div className="flex min-h-screen flex-col bg-slateMist text-slateDeep">
    <Header />
    <main className="flex-1">
      <Outlet />
    </main>
    <Footer />
  </div>
);

const ScrollMeta = () => {
  const location = useLocation();
  return (
    <>
      <Helmet>
        <title>Lift Energy Canada — Solar Installed Like Engineering</title>
        <meta
          name="description"
          content="Lift Energy Canada engineers and installs solar arrays tailored to Canadian roofs, climate loads, and grid coordination."
        />
      </Helmet>
      <ScrollToTop key={location.pathname} />
    </>
  );
};

const App = () => (
  <>
    <ScrollMeta />
    <Routes>
      <Route element={<PageLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/services/installation" element={<Installation />} />
        <Route path="/services/consulting" element={<Consulting />} />
        <Route path="/case-studies" element={<CaseStudies />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/blog/array-geometry-first" element={<BlogArrayGeometry />} />
        <Route path="/blog/inverter-family-pairing" element={<BlogInverterFamily />} />
        <Route path="/blog/telemetry-stack-friction" element={<BlogTelemetryStack />} />
        <Route path="/faq" element={<FAQ />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/cookie-policy" element={<CookiePolicy />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
    <CookieBanner />
  </>
);

export default App;