import React from "react";
import { Helmet } from "react-helmet";

const missionPoints = [
  "Design arrays that respect structure, climate, and electrical code simultaneously.",
  "Document every decision so facility operators and authorities have transparent records.",
  "Deliver telemetry that supports lifecycle operations rather than vanity dashboards."
];

const ethics = [
  "We publish calculations and assumptions in plain technical language.",
  "We decline projects that cannot meet structural or electrical safety thresholds.",
  "We align with CSA, OBC, and utility-specific directives without shortcuts.",
  "We keep manufacturer engagement fully transparent."
];

const constraints = [
  "Projects require accessible structural data or permission to inspect thoroughly.",
  "Roof condition must be sound; otherwise we recommend remediation before installation.",
  "Electrical interconnection must match utility standards and available service.",
  "Telemetry access requires stable network pathways or scoped provisioning."
];

const team = [
  {
    name: "Amelia Lin, P.Eng.",
    role: "Principal Mechanical Engineer",
    bio: "Leads roof structural assessments, racking specifications, and load path validation across snow and wind scenarios.",
    image: "https://picsum.photos/400/400?random=21"
  },
  {
    name: "Jasper O’Neill, CET",
    role: "Electrical Integrations Lead",
    bio: "Coordinates inverter selection, single-line diagrams, and commissioning checklists with utilities and inspectors.",
    image: "https://picsum.photos/400/400?random=22"
  },
  {
    name: "Ritika Banerjee",
    role: "Telemetry Architect",
    bio: "Designs data pipelines, alerting logic, and secure network infrastructure for solar monitoring and maintenance teams.",
    image: "https://picsum.photos/400/400?random=23"
  },
  {
    name: "Noah Tremblay",
    role: "Field Engineering Supervisor",
    bio: "Oversees on-site installation standards, safety, and documentation with bilingual crews across Ontario and Quebec.",
    image: "https://picsum.photos/400/400?random=24"
  }
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>About Lift Energy Canada — Engineering-Led Solar</title>
        <meta
          name="description"
          content="Lift Energy Canada provides engineering-led solar installation and consulting for Canadian roofs, codes, and climate conditions."
        />
      </Helmet>
      <section className="relative bg-slateDeep text-white">
        <img
          src="https://picsum.photos/1600/900?random=25"
          alt="Engineers reviewing structural drawings"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-slateDeep/70" aria-hidden="true" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl sm:text-5xl">Engineering first, installation always accountable</h1>
          <p className="mt-6 max-w-3xl text-base text-white/80">
            Lift Energy Canada was founded by engineers who were asked to sign off on systems without seeing the load calculations, wiring labels, or telemetry plan. We built a team that treats every project like a commissioning exercise for peers who will ask for proof.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl space-y-14 px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <h2 className="section-title">Mission</h2>
            <ul className="mt-6 space-y-4 text-sm text-slate-600">
              {missionPoints.map((point) => (
                <li key={point} className="flex gap-3">
                  <span className="mt-2 inline-flex h-2 w-2 flex-shrink-0 rounded-full bg-primary" aria-hidden="true" />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-3xl bg-slateDeep p-8 text-white shadow-soft">
            <h2 className="section-title text-white">Engineering standpoint</h2>
            <p className="mt-4 text-sm text-white/80">
              We treat roof surfaces as structural systems under varying weather patterns. Our calculations include reduction factors, tributary area adjustments, and hardware tolerances. Electrical design aligns conductor ampacity, breaker pairing, and rapid shutdown messaging without leaving grey areas for future crews.
            </p>
            <p className="mt-4 text-sm text-white/80">
              Compliance means more than passing inspection—it ensures owners can operate confidently for decades. We provide checklists, torque specs, and labeled schematics that satisfy both insurers and maintenance teams.
            </p>
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <h3 className="text-xl font-semibold text-slateDeep">Code alignment</h3>
            <p className="mt-4 text-sm text-slate-600">
              Ontario Electrical Code, CSA structural guidelines, and local jurisdiction add-ons are all baked into our standard procedures. Every permit set includes stamped diagrams, equipment schedules, and labeling notes.
            </p>
          </div>
          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <h3 className="text-xl font-semibold text-slateDeep">Component rationale</h3>
            <p className="mt-4 text-sm text-slate-600">
              We select equipment for resilience, firmware transparency, and supply chain stability. Our bill of materials includes substitution pathways so downtime is minimized if a vendor revises stock.
            </p>
          </div>
          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <h3 className="text-xl font-semibold text-slateDeep">Regional scope</h3>
            <p className="mt-4 text-sm text-slate-600">
              We serve Ontario and nearby provinces where we have structural and electrical partners licensed to seal documents. We extend consulting nationwide, provided local professionals engage for on-site validations.
            </p>
          </div>
        </div>

        <div className="rounded-3xl bg-white p-8 shadow-soft">
          <h2 className="section-title text-slateDeep">Ethical positioning</h2>
          <ul className="mt-6 grid gap-4 md:grid-cols-2">
            {ethics.map((item) => (
              <li key={item} className="rounded-2xl bg-slateMist p-4 text-sm text-slate-600">
                {item}
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-slateMist p-8 shadow-soft">
          <h2 className="section-title text-slateDeep">Engagement constraints</h2>
          <ul className="mt-6 space-y-4 text-sm text-slate-600">
            {constraints.map((item) => (
              <li key={item} className="flex gap-3">
                <span className="mt-1 inline-flex h-2.5 w-2.5 flex-shrink-0 rounded-full bg-primary" aria-hidden="true" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="section-title text-slateDeep">Team</h2>
          <p className="section-body">
            A cross-functional group of engineers, technologists, and field supervisors ensures decisions flow from modeling to the last lug on the roof.
          </p>
          <div className="mt-8 grid gap-8 md:grid-cols-2">
            {team.map((member) => (
              <div key={member.name} className="rounded-3xl bg-white p-6 shadow-soft transition hover:-translate-y-1 hover:shadow-xl">
                <img
                  src={member.image}
                  alt={`${member.name} portrait`}
                  className="h-48 w-full rounded-2xl object-cover"
                  loading="lazy"
                />
                <div className="mt-4">
                  <div className="text-lg font-semibold text-slateDeep">{member.name}</div>
                  <div className="text-sm font-medium text-primary">{member.role}</div>
                  <p className="mt-3 text-sm text-slate-600">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default About;