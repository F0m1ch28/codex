import React from "react";
import { Helmet } from "react-helmet";

const heuristics = [
  "Map loads to roof planes by evaluating structure type, spacing, and allowable spans.",
  "Use interval data or estimates to forecast consumption and align array size with realistic export limits.",
  "Model shading and irradiance by season to determine ideal string segmentation."
];

const insolationLogic = [
  "Insolation estimates leverage NRCan datasets, local weather stations, and project-specific tilt/azimuth adjustments.",
  "Snow coverage factors and albedo contributions are modeled for winter performance.",
  "We provide monthly production bands with confidence intervals rather than single-point estimates."
];

const stringNotes = [
  "String lengths stay within inverter MPPT windows across temperature extremes.",
  "Parallel strings are balanced for voltage and current to avoid nuisance trips.",
  "Rapid shutdown requirements are integrated into string design from day zero."
];

const inverterFamilies = [
  "SolLink 25-60 kW commercial string inverters",
  "ArcWave hybrid inverters for storage-ready projects",
  "MicroGrid QS pod-based modular inverters",
  "Central GS series for large aggregated rooftops"
];

const telemetryChoices = [
  "Grafana + InfluxDB for analytics teams",
  "Inverter native portals hardened with MFA and IP restrictions",
  "Custom middleware for SCADA pipelines",
  "Alerting via email, SMS gateway, or service desks"
];

const wiringModel = [
  "Conductor gauge, derating, and routing diagrams",
  "Conduit fill calculations and rooftop tray layouts",
  "Grounding, bonding, and labeling plans aligned with code",
  "Protection coordination and disconnect placement"
];

const Consulting = () => {
  return (
    <>
      <Helmet>
        <title>Consulting Services — Lift Energy Canada</title>
        <meta
          name="description"
          content="Lift Energy Canada specifies and plans solar systems with detailed heuristics, insolation logic, string design, inverter families, telemetry choices, and wiring models."
        />
      </Helmet>
      <section className="relative bg-slateDeep text-white">
        <img
          src="https://picsum.photos/1600/900?random=51"
          alt="Consulting engineers reviewing solar documentation"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-slateDeep/70" aria-hidden="true" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl sm:text-5xl">We Specify + Plan Your System</h1>
          <p className="mt-6 max-w-3xl text-base text-white/80">
            Our consulting engagements deliver precise design packages, stringing plans, and telemetry architecture so your teams can execute with clarity.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl space-y-14 px-4 py-16 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-white p-8 shadow-soft">
          <h2 className="section-title text-slateDeep">Sizing heuristics</h2>
          <ul className="mt-6 space-y-4 text-sm text-slate-600">
            {heuristics.map((item) => (
              <li key={item} className="flex gap-3">
                <span className="mt-1 inline-flex h-2.5 w-2.5 flex-shrink-0 rounded-full bg-primary" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-3xl bg-slateMist p-8 shadow-soft">
          <h2 className="section-title text-slateDeep">Insolation logic</h2>
          <ul className="mt-6 space-y-4 text-sm text-slate-600">
            {insolationLogic.map((item) => (
              <li key={item} className="flex gap-3">
                <span className="mt-1 inline-flex h-2.5 w-2.5 flex-shrink-0 rounded-full bg-primary" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <h2 className="section-title text-slateDeep">String pairing discipline</h2>
            <ul className="mt-6 space-y-4 text-sm text-slate-600">
              {stringNotes.map((item) => (
                <li key={item} className="flex gap-3">
                  <span className="mt-1 inline-flex h-2.5 w-2.5 flex-shrink-0 rounded-full bg-primary" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-3xl bg-slateMist p-8 shadow-soft">
            <h2 className="section-title text-slateDeep">Inverter families</h2>
            <ul className="mt-6 space-y-4 text-sm text-slate-600">
              {inverterFamilies.map((item) => (
                <li key={item} className="rounded-2xl bg-white p-4 shadow-sm">{item}</li>
              ))}
            </ul>
          </div>
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <h2 className="section-title text-slateDeep">Telemetry stack choices</h2>
            <ul className="mt-6 space-y-4 text-sm text-slate-600">
              {telemetryChoices.map((item) => (
                <li key={item} className="rounded-2xl bg-slateMist p-4 shadow-sm">{item}</li>
              ))}
            </ul>
          </div>
          <div className="rounded-3xl bg-slateMist p-8 shadow-soft">
            <h2 className="section-title text-slateDeep">Wiring model overview</h2>
            <ul className="mt-6 space-y-4 text-sm text-slate-600">
              {wiringModel.map((item) => (
                <li key={item} className="flex gap-3">
                  <span className="mt-1 inline-flex h-2.5 w-2.5 flex-shrink-0 rounded-full bg-primary" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </>
  );
};

export default Consulting;