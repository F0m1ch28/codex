import React from "react";
import { Helmet } from "react-helmet";

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy — Lift Energy Canada</title>
      <meta
        name="description"
        content="Cookie policy describing how Lift Energy Canada uses cookies for analytics and security."
      />
    </Helmet>
    <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl text-slateDeep">Cookie Policy</h1>
      <p className="mt-6 text-sm text-slate-600">
        Lift Energy Canada uses minimal cookies to keep this site secure and to understand aggregate usage patterns.
      </p>
      <h2 className="mt-6 text-lg font-semibold text-slateDeep">Types of cookies</h2>
      <ul className="mt-4 space-y-3 text-sm text-slate-600">
        <li><strong>Essential cookies:</strong> Required for basic site functionality, such as remembering consent preferences.</li>
        <li><strong>Analytics cookies:</strong> Collect anonymized usage data to help improve accessibility and performance.</li>
      </ul>
      <h2 className="mt-6 text-lg font-semibold text-slateDeep">Managing cookies</h2>
      <p className="mt-3 text-sm text-slate-600">
        You can adjust browser settings to block or delete cookies. Essential cookies may be required for certain features to operate correctly.
      </p>
      <h2 className="mt-6 text-lg font-semibold text-slateDeep">Updates</h2>
      <p className="mt-3 text-sm text-slate-600">
        We may update this policy as regulations or site functionality evolves. Check this page periodically for the most current information.
      </p>
    </section>
  </>
);

export default CookiePolicy;