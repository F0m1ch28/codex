import React, { useState } from "react";
import { Helmet } from "react-helmet";

const Contact = () => {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState({ submitted: false, error: "" });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setStatus({ submitted: false, error: "All fields are required for a response." });
      return;
    }
    setStatus({ submitted: true, error: "" });
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <>
      <Helmet>
        <title>Contact Lift Energy Canada</title>
        <meta
          name="description"
          content="Contact Lift Energy Canada for solar engineering, installation, and consulting services."
        />
      </Helmet>
      <section className="relative bg-slateDeep text-white">
        <img
          src="https://picsum.photos/1600/900?random=111"
          alt="City skyline with solar panels"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-slateDeep/70" aria-hidden="true" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl sm:text-5xl">Contact Lift Energy Canada</h1>
          <p className="mt-6 max-w-3xl text-base text-white/80">
            Share drawings, site data, or questions. We respond with technical clarity and next steps.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[1fr,1fr]">
          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <h2 className="text-2xl font-semibold text-slateDeep">Send us project details</h2>
            <form className="mt-6 space-y-6" onSubmit={handleSubmit} noValidate>
              <div>
                <label htmlFor="name" className="text-sm font-semibold text-slateDeep">
                  Name or organization
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  className="mt-2 w-full rounded-2xl border border-slate-200 bg-slateMist px-4 py-3 text-sm text-slate-700 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                  placeholder="Jane Doe • Facilities Manager"
                  required
                />
              </div>
              <div>
                <label htmlFor="email" className="text-sm font-semibold text-slateDeep">
                  Email for reply
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="mt-2 w-full rounded-2xl border border-slate-200 bg-slateMist px-4 py-3 text-sm text-slate-700 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                  placeholder="you@example.com"
                  required
                />
              </div>
              <div>
                <label htmlFor="message" className="text-sm font-semibold text-slateDeep">
                  Project outline or questions
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  className="mt-2 w-full rounded-2xl border border-slate-200 bg-slateMist px-4 py-3 text-sm text-slate-700 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                  placeholder="Structural drawings, desired timeline, utility status, or hurdles."
                  required
                />
              </div>
              {status.error && <p className="text-sm text-red-600">{status.error}</p>}
              {status.submitted && (
                <p className="rounded-2xl bg-primary/10 px-4 py-3 text-sm text-primary">
                  Thank you. We will review and reply with technical next steps shortly.
                </p>
              )}
              <button
                type="submit"
                className="rounded-full bg-primary px-6 py-3 text-sm font-semibold text-white shadow transition hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
              >
                Submit
              </button>
            </form>
          </div>
          <div className="rounded-3xl bg-slateMist p-8 shadow-soft">
            <h2 className="text-2xl font-semibold text-slateDeep">Reach us directly</h2>
            <div className="mt-6 space-y-4 text-sm text-slate-600">
              <div>
                <div className="font-semibold text-slateDeep">Phone</div>
                <p><a href="tel:+14376127840" className="text-primary">+1 (437) 612-7840</a></p>
              </div>
              <div>
                <div className="font-semibold text-slateDeep">Address</div>
                <p>
                  200 Wellington St W<br />
                  Toronto, ON M5V 3C7, Canada
                </p>
              </div>
              <div>
                <div className="font-semibold text-slateDeep">Email</div>
                <p>
                  Shared via confirmation to protect against spam. Use the form and we reply promptly from our engineering queue.
                </p>
              </div>
              <div className="rounded-2xl bg-white p-5 shadow-sm">
                <h3 className="text-sm font-semibold text-slateDeep">Utility coordination</h3>
                <p className="mt-2 text-sm text-slate-600">
                  We regularly work with Hydro One, Toronto Hydro, Alectra Utilities, and other regional providers. Trails of communication are logged for every project.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;