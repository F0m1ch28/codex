import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";

const posts = [
  {
    slug: "array-geometry-first",
    title: "Array Geometry First",
    summary: "Why starting with structural planes and obstructions saves time downstream.",
    image: "https://picsum.photos/800/600?random=81",
    date: "January 12, 2024"
  },
  {
    slug: "inverter-family-pairing",
    title: "Inverter Family Pairing",
    summary: "Matching inverter families to module behaviour and roof segmentation.",
    image: "https://picsum.photos/800/600?random=82",
    date: "February 3, 2024"
  },
  {
    slug: "telemetry-stack-friction",
    title: "Telemetry Stack Friction",
    summary: "How monitoring systems fail when network and data layers stay siloed.",
    image: "https://picsum.photos/800/600?random=83",
    date: "March 8, 2024"
  }
];

const Blog = () => {
  return (
    <>
      <Helmet>
        <title>Blog — Lift Energy Canada</title>
        <meta
          name="description"
          content="Field notes and rationale from Lift Energy Canada engineers covering array geometry, inverter pairing, and telemetry stacks."
        />
      </Helmet>
      <section className="relative bg-slateDeep text-white">
        <img
          src="https://picsum.photos/1600/900?random=84"
          alt="Solar engineers discussing telemetry data"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-slateDeep/70" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl sm:text-5xl">Field Notes + Rationale — Full Article Stream</h1>
          <p className="mt-6 max-w-3xl text-base text-white/80">
            We share the decisions and lessons that shape solar installations across Canadian roofs.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-3">
          {posts.map((post) => (
            <article key={post.slug} className="rounded-3xl bg-white p-6 shadow-soft transition hover:-translate-y-1 hover:shadow-xl">
              <img
                src={post.image}
                alt={`${post.title} cover`}
                className="h-48 w-full rounded-2xl object-cover"
                loading="lazy"
              />
              <div className="mt-4 text-xs uppercase tracking-wide text-primary">{post.date}</div>
              <h2 className="mt-2 text-lg font-semibold text-slateDeep">{post.title}</h2>
              <p className="mt-3 text-sm text-slate-600">{post.summary}</p>
              <Link
                to={`/blog/${post.slug}`}
                className="mt-4 inline-flex items-center text-sm font-semibold text-primary hover:underline"
              >
                Read article →
              </Link>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Blog;