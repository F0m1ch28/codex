import React, { useState } from "react";
import { Helmet } from "react-helmet";

const cases = [
  {
    id: 1,
    title: "Community Centre, Ottawa",
    geometry: "Low-slope roof with 5° tilt frames",
    module: "Alpina 455 Bifacial",
    inverter: "ArcWave 10 kW Hybrid",
    mounting: "Ballasted trays with parapet anchors",
    telemetry: "Hybrid logger + LTE backup",
    category: "Flat roof",
    description: "Integrated snow guards and walkway pads while keeping membrane warranty intact."
  },
  {
    id: 2,
    title: "Manufacturing Plant, Hamilton",
    geometry: "Standing seam roof, 30° south",
    module: "Halo 420 Mono",
    inverter: "SolLink 25 kW",
    mounting: "Rail-free seam clamps",
    telemetry: "Modbus TCP to plant SCADA",
    category: "Metal roof",
    description: "Seam-specific clamp testing with structural engineer sign-off."
  },
  {
    id: 3,
    title: "University Lab, Sudbury",
    geometry: "Sloped roof with snow drift zones",
    module: "Solis 500 Topcon",
    inverter: "MicroGrid QS",
    mounting: "Rails with standoff blocking",
    telemetry: "Module-level analytics",
    category: "Pitched roof",
    description: "Snow sensor integration triggered maintenance alerts for drift removal."
  },
  {
    id: 4,
    title: "Co-op Housing, Toronto",
    geometry: "Multi-plane shingle roof",
    module: "Halo 420 Mono",
    inverter: "ArcWave 10 kW",
    mounting: "Rails with flashing kits",
    telemetry: "Utility meter sync + MQTT",
    category: "Residential"
  },
  {
    id: 5,
    title: "Logistics Hub, Mississauga",
    geometry: "Large flat roof with mechanical obstructions",
    module: "Alpina 455 Bifacial",
    inverter: "SolLink 25 kW",
    mounting: "Hybrid ballast with mechanical anchors",
    telemetry: "SCADA integration",
    category: "Flat roof"
  }
];

const filters = ["All", "Flat roof", "Metal roof", "Pitched roof", "Residential"];

const CaseStudies = () => {
  const [activeFilter, setActiveFilter] = useState("All");

  const filteredCases =
    activeFilter === "All" ? cases : cases.filter((item) => item.category === activeFilter);

  return (
    <>
      <Helmet>
        <title>Case Studies — Lift Energy Canada</title>
        <meta
          name="description"
          content="Building-specific snapshots showing geometry, module choice, inverter pairing, mounting strategy, and telemetry notes."
        />
      </Helmet>
      <section className="relative bg-slateDeep text-white">
        <img
          src="https://picsum.photos/1600/900?random=61"
          alt="Solar array snapshot montage"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-slateDeep/70" aria-hidden="true" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl sm:text-5xl">Building-Specific Snapshots</h1>
          <p className="mt-6 max-w-3xl text-base text-white/80">
            Each project reveals how geometry, structural details, and electrical infrastructure drive solar design choices.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="flex flex-wrap gap-3">
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`rounded-full px-5 py-2 text-sm font-semibold transition ${
                activeFilter === filter ? "bg-primary text-white shadow" : "bg-white text-slateDeep shadow-sm"
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        <div className="mt-10 grid gap-8 md:grid-cols-2">
          {filteredCases.map((item) => (
            <article key={item.id} className="rounded-3xl bg-white p-6 shadow-soft transition hover:-translate-y-1 hover:shadow-xl">
              <img
                src={`https://picsum.photos/800/600?random=${item.id + 70}`}
                alt={`${item.title} solar installation`}
                className="h-52 w-full rounded-2xl object-cover"
                loading="lazy"
              />
              <div className="mt-4 text-sm font-semibold text-primary">{item.category}</div>
              <h2 className="mt-2 text-xl font-semibold text-slateDeep">{item.title}</h2>
              <dl className="mt-4 space-y-2 text-sm text-slate-600">
                <div>
                  <dt className="font-semibold text-slateDeep">Roof geometry</dt>
                  <dd>{item.geometry}</dd>
                </div>
                <div>
                  <dt className="font-semibold text-slateDeep">Module</dt>
                  <dd>{item.module}</dd>
                </div>
                <div>
                  <dt className="font-semibold text-slateDeep">Inverter</dt>
                  <dd>{item.inverter}</dd>
                </div>
                <div>
                  <dt className="font-semibold text-slateDeep">Mounting</dt>
                  <dd>{item.mounting}</dd>
                </div>
                <div>
                  <dt className="font-semibold text-slateDeep">Telemetry</dt>
                  <dd>{item.telemetry}</dd>
                </div>
              </dl>
              {item.description && <p className="mt-4 text-sm text-slate-600">{item.description}</p>}
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default CaseStudies;