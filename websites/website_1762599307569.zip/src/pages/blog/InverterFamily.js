import React from "react";
import { Helmet } from "react-helmet";

const BlogInverterFamily = () => (
  <>
    <Helmet>
      <title>Inverter Family Pairing — Lift Energy Canada</title>
      <meta
        name="description"
        content="Inverter selection is about more than nameplates. Learn how Lift Energy Canada pairs inverter families to module behaviours and site constraints."
      />
    </Helmet>
    <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
      <header className="space-y-4">
        <h1 className="font-display text-4xl text-slateDeep">Inverter Family Pairing</h1>
        <p className="text-sm text-slate-500">February 3, 2024 • Lift Energy Canada Engineering Team</p>
      </header>
      <img
        src="https://picsum.photos/1200/800?random=92"
        alt="Engineers reviewing inverter schematics"
        className="mt-8 rounded-3xl object-cover"
        loading="lazy"
      />
      <section className="prose prose-slate mt-8">
        <p>
          Inverter selection drives string voltage, rapid shutdown hardware, telemetry, and maintenance requirements.
          We treat inverters as control systems that must align with module current-voltage characteristics and site electrical realities.
        </p>
        <h2>String inverters</h2>
        <p>
          Three-phase string inverters excel on large roof planes with minimal shading. They offer high efficiency and simpler maintenance but require careful string balancing within MPPT ranges.
        </p>
        <h2>Hybrid architectures</h2>
        <p>
          Hybrid inverters bridge solar production and storage by providing DC-coupled battery ports. Even when batteries are deferred, choosing a hybrid early avoids future retrofits and ensures rapid shutdown stays compliant.
        </p>
        <h2>Microinverter pods</h2>
        <p>
          For roofs with multiple facets or shading events, microinverters provide module-level control. Their telemetry granularity is invaluable, but they require more branch circuits and coordination around monitoring gateways.
        </p>
        <h2>Commissioning implications</h2>
        <p>
          Each inverter family comes with firmware routines, monitoring platforms, and grid support functions we must configure during commissioning. Documentation covers all setpoints, making utility interactions smoother.
        </p>
      </section>
    </article>
  </>
);

export default BlogInverterFamily;