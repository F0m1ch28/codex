import React from "react";
import { Helmet } from "react-helmet";

const BlogArrayGeometry = () => (
  <>
    <Helmet>
      <title>Array Geometry First — Lift Energy Canada</title>
      <meta
        name="description"
        content="Why Lift Energy Canada starts every solar project with roof geometry, structural evaluation, and obstruction mapping."
      />
    </Helmet>
    <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
      <header className="space-y-4">
        <h1 className="font-display text-4xl text-slateDeep">Array Geometry First</h1>
        <p className="text-sm text-slate-500">January 12, 2024 • Lift Energy Canada Engineering Team</p>
      </header>
      <img
        src="https://picsum.photos/1200/800?random=91"
        alt="Diagram showing array geometry planning"
        className="mt-8 rounded-3xl object-cover"
        loading="lazy"
      />
      <section className="prose prose-slate mt-8">
        <p>
          The roof determines everything. Before equipment lists or energy projections, we need to know rafter spacing,
          sheathing quality, and how snow and wind will behave on each plane. Geometry sets the boundary conditions that protect the structure and inform every downstream decision.
        </p>
        <h2>Structure before electronics</h2>
        <p>
          Structural modeling ensures clamps land on members capable of carrying additional load. For standing seam,
          that includes identifying seam profile and confirming clip strength. For shingle roofs, it means verifying decking thickness and rafter layout to establish safe penetration points.
        </p>
        <h2>Shading and snow drift</h2>
        <p>
          Dormers, vent stacks, nearby trees, and snow drift zones create pockets of reduced production. Geometry-driven simulations allow us to split strings and avoid losses, or to select module-level electronics where obstructions are unavoidable.
        </p>
        <h2>Documentation outputs</h2>
        <p>
          Each geometry study yields CAD overlays, shading charts, and structural notes. These become part of permit submissions and help maintenance teams understand where arrays can be expanded or modified.
        </p>
      </section>
    </article>
  </>
);

export default BlogArrayGeometry;