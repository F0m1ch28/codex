import React from "react";
import { Helmet } from "react-helmet";

const BlogTelemetryStack = () => (
  <>
    <Helmet>
      <title>Telemetry Stack Friction — Lift Energy Canada</title>
      <meta
        name="description"
        content="Telemetry stacks fail when data pathways are fragmented. Learn how Lift Energy Canada builds resilient monitoring architectures."
      />
    </Helmet>
    <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
      <header className="space-y-4">
        <h1 className="font-display text-4xl text-slateDeep">Telemetry Stack Friction</h1>
        <p className="text-sm text-slate-500">March 8, 2024 • Lift Energy Canada Engineering Team</p>
      </header>
      <img
        src="https://picsum.photos/1200/800?random=93"
        alt="Telemetry dashboard with solar performance metrics"
        className="mt-8 rounded-3xl object-cover"
        loading="lazy"
      />
      <section className="prose prose-slate mt-8">
        <p>
          Telemetry friction happens when the inverter portal, utility meter, and facility data systems refuse to talk.
          We mitigate that by designing data pathways with clear ownership and redundancy from the start.
        </p>
        <h2>Edge resilience</h2>
        <p>
          Every site gets a local data logger with buffered storage. That way, internet outages do not erase events, and we can replay data once connectivity returns.
        </p>
        <h2>Security and segmentation</h2>
        <p>
          VPN tunnels, TLS certificates, and regular credential rotation keep telemetry safe. We document procedures so facility IT teams see exactly how systems integrate.
        </p>
        <h2>Alerting that matters</h2>
        <p>
          Alerts should be actionable. We define failure modes with facility staff, set thresholds, and make sure notifications land in systems they already use—maintenance ticketing, email, or messaging platforms.
        </p>
        <h2>Documentation</h2>
        <p>
          The telemetry plan becomes part of the as-built package, detailing device IDs, network diagrams, and data retention policies to satisfy compliance audits.
        </p>
      </section>
    </article>
  </>
);

export default BlogTelemetryStack;