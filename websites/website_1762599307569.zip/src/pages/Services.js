import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";

const mechanicalVsElectrical = [
  {
    title: "Mechanical scope",
    items: [
      "Structural assessment, CAD detail, and stamped reports",
      "Racking, clamps, ballast, and snow guard specification",
      "Penetration layout, flashing selection, torque logs",
      "On-roof supervision and quality assurance documentation"
    ]
  },
  {
    title: "Electrical scope",
    items: [
      "Single-line diagrams, load calculations, and panel schedules",
      "Inverter programming, rapid shutdown design, conduit routing",
      "Utility interconnection packages, ESA coordination",
      "Telemetry configuration and alarm logic sign-off"
    ]
  }
];

const rackingSystems = [
  "Rail-based aluminum with stainless hardware",
  "Rail-free clamp arrays for standing seam",
  "Ballasted trays for flat membrane roofs",
  "Custom standoff grids for heritage rafters"
];

const inverterTopologies = [
  "Three-phase string with DC combiners",
  "Hybrid string with battery-ready ports",
  "Microinverter pods for complex roofs",
  "Central inverters for aggregated arrays"
];

const telemetryMenu = [
  "Native inverter dashboards hardened for operations",
  "SCADA integration via Modbus TCP and MQTT",
  "Snow sensor and irradiance node overlay",
  "Long-term archival with Grafana dashboards"
];

const roofSurfaces = [
  "Asphalt shingle with solid decking",
  "Standing seam metal (snap-lock and mechanical)",
  "Corrugated steel with purlin reinforcement",
  "EPDM/TPO membrane with ballast verification",
  "Slate and tile (requires specialized anchors)"
];

const resultMatrix = [
  {
    mode: "Full install",
    outcome: "Array installed, commissioned, and handed over with documentation packages and telemetry dashboards configured."
  },
  {
    mode: "Consulting only",
    outcome: "Stamped design set, equipment schedules, and commissioning scripts delivered to your preferred contractors."
  },
  {
    mode: "Hybrid",
    outcome: "Lift Energy manages mechanical scope; partner electricians execute electrical work with our supervision and documentation."
  }
];

const Services = () => {
  const [activeSection, setActiveSection] = useState("installation");

  return (
    <>
      <Helmet>
        <title>Lift Energy Canada Services — Installation and Consulting</title>
        <meta
          name="description"
          content="Two working modes: full installation of solar arrays or consulting support for teams needing engineering-grade documentation."
        />
      </Helmet>
      <section className="relative bg-slateDeep text-white">
        <img
          src="https://picsum.photos/1600/900?random=31"
          alt="Solar engineers examining inverters"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-slateDeep/70" aria-hidden="true" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl sm:text-5xl">Two Working Modes — Installation + Consulting</h1>
          <p className="mt-6 max-w-3xl text-base text-white/80">
            We either take arrays from concept through commissioning or embed with your team to deliver engineering documentation and oversight.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              to="/services/installation"
              className="rounded-full bg-primary px-6 py-3 text-sm font-semibold text-white shadow hover:shadow-lg"
            >
              Installation scope
            </Link>
            <Link
              to="/services/consulting"
              className="rounded-full border border-white/70 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white hover:text-slateDeep"
            >
              Consulting scope
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl space-y-16 px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-2">
          {mechanicalVsElectrical.map((block) => (
            <div key={block.title} className="rounded-3xl bg-white p-8 shadow-soft">
              <h2 className="text-2xl font-semibold text-slateDeep">{block.title}</h2>
              <ul className="mt-6 space-y-3 text-sm text-slate-600">
                {block.items.map((item) => (
                  <li key={item} className="flex gap-3">
                    <span className="mt-1 inline-flex h-2 w-2 flex-shrink-0 rounded-full bg-primary" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="rounded-3xl bg-slateMist p-8 shadow-soft">
          <h2 className="section-title text-slateDeep">Menus and selections</h2>
          <div className="mt-8 grid gap-10 lg:grid-cols-2">
            <div>
              <h3 className="text-lg font-semibold text-slateDeep">Mounting systems</h3>
              <ul className="mt-4 space-y-2 text-sm text-slate-600">
                {rackingSystems.map((item) => (
                  <li key={item} className="rounded-2xl bg-white p-4 shadow-sm">{item}</li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slateDeep">Inverter topologies</h3>
              <ul className="mt-4 space-y-2 text-sm text-slate-600">
                {inverterTopologies.map((item) => (
                  <li key={item} className="rounded-2xl bg-white p-4 shadow-sm">{item}</li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slateDeep">Telemetry stack</h3>
              <ul className="mt-4 space-y-2 text-sm text-slate-600">
                {telemetryMenu.map((item) => (
                  <li key={item} className="rounded-2xl bg-white p-4 shadow-sm">{item}</li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slateDeep">Roof surfaces supported</h3>
              <ul className="mt-4 space-y-2 text-sm text-slate-600">
                {roofSurfaces.map((item) => (
                  <li key={item} className="rounded-2xl bg-white p-4 shadow-sm">{item}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="rounded-3xl bg-white p-8 shadow-soft">
          <h2 className="section-title text-slateDeep">Result matrix</h2>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {resultMatrix.map((row) => (
              <div key={row.mode} className="rounded-2xl bg-slateMist p-6 shadow-sm">
                <h3 className="text-lg font-semibold text-slateDeep">{row.mode}</h3>
                <p className="mt-3 text-sm text-slate-600">{row.outcome}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-3xl bg-slateDeep p-8 text-white shadow-soft">
          <h2 className="text-2xl font-semibold">Interactive focus</h2>
          <div className="mt-6 flex flex-wrap gap-4">
            <button
              className={`tab ${activeSection === "installation" ? "tab-active" : ""}`}
              onClick={() => setActiveSection("installation")}
            >
              Installation
            </button>
            <button
              className={`tab ${activeSection === "consulting" ? "tab-active" : ""}`}
              onClick={() => setActiveSection("consulting")}
            >
              Consulting
            </button>
            <button
              className={`tab ${activeSection === "hybrid" ? "tab-active" : ""}`}
              onClick={() => setActiveSection("hybrid")}
            >
              Hybrid delivery
            </button>
          </div>
          <div className="mt-6 rounded-3xl bg-white/10 p-6 text-sm text-white/80">
            {activeSection === "installation" && (
              <p>
                Full mechanical and electrical delivery with our crews, certified subcontractors, and commissioning specialists.
                Expect documented QA, torque logs, and live telemetry before handover.
              </p>
            )}
            {activeSection === "consulting" && (
              <p>
                We produce calculation packages, drawing sets, and review contractor work remotely or on-site, ensuring compliance.
                Ideal for EPCs or builders needing specialized oversight.
              </p>
            )}
            {activeSection === "hybrid" && (
              <p>
                Lift Energy handles structural mounting and coordination while your electrical team executes under our documentation and
                commissioning guidance, aligning schedules and responsibilities clearly.
              </p>
            )}
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;