import React from "react";
import { Helmet } from "react-helmet";

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Use — Lift Energy Canada</title>
      <meta
        name="description"
        content="Terms of use for Lift Energy Canada website and services."
      />
    </Helmet>
    <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl text-slateDeep">Terms of Use</h1>
      <p className="mt-6 text-sm text-slate-600">
        These terms govern your use of the Lift Energy Canada website. By accessing our site, you acknowledge the following conditions:
      </p>
      <ul className="mt-6 space-y-4 text-sm text-slate-600">
        <li>
          Information provided is for educational and planning purposes. Formal proposals require a signed engagement with scope defined.
        </li>
        <li>
          Technical drawings, calculations, or guides shared through the site remain proprietary until a formal agreement states otherwise.
        </li>
        <li>
          We strive to keep content current; however, regulations and equipment availability evolve. Confirm details with our team before taking action.
        </li>
        <li>
          External links are provided as references. Lift Energy Canada is not responsible for third-party content.
        </li>
        <li>
          Use of the contact form must comply with anti-spam legislation. Do not submit unauthorized marketing messages.
        </li>
      </ul>
      <p className="mt-6 text-sm text-slate-600">
        If you have questions regarding these terms, contact us using the information on the Contact page.
      </p>
    </section>
  </>
);

export default Terms;