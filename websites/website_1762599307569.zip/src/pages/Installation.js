import React from "react";
import { Helmet } from "react-helmet";

const installCategories = [
  {
    title: "Roof-mounted pitched arrays",
    notes: "Rails or rail-free systems anchored to rafters or structural blocking. Snow load and uplift adjustments applied per plane."
  },
  {
    title: "Ballasted flat-roof systems",
    notes: "Wind tunnel data informs ballast weight; parapet engagement and slip sheets protect membrane integrity."
  },
  {
    title: "Structural retrofits",
    notes: "Supplemental framing, purlin reinforcement, and engineered brackets keep legacy roofs compliant with new loads."
  }
];

const railNotes = [
  {
    title: "Rail-based systems",
    body: "Provide adjustability and higher load distribution. We specify splice positions and bonding jumpers to maintain continuity."
  },
  {
    title: "Rail-free clamps",
    body: "Reduce roof penetrations on standing seam roofs. Clamps are tested for seam profile and torque values recorded."
  }
];

const penetrationPatterns = [
  "Inline lag bolts centered on rafters with predrilled pilot holes and butyl flashing pads.",
  "Staggered attachment schedule to distribute uplift forces around valleys and hips.",
  "Custom standoff blocks for slate or tile using stainless hardware and compression gaskets."
];

const commissioningSteps = [
  "Mechanical completion inspection with torque log verification.",
  "Electrical continuity testing, insulation resistance checks, and inverter programming.",
  "Utility witness test coordination and interconnection paperwork submission.",
  "Telemetry calibration, data retention configuration, and alert threshold validation."
];

const deliverables = [
  "As-built drawings with conductor labels and equipment serials.",
  "Inspection-ready photo documentation and torque logs.",
  "Commissioning report with performance baselines and alert matrix.",
  "Operation and maintenance manual tailored to facility staff."
];

const Installation = () => {
  return (
    <>
      <Helmet>
        <title>Installation Services — Lift Energy Canada</title>
        <meta
          name="description"
          content="Lift Energy Canada executes physical installation of solar arrays with engineered mounting, electrical coordination, and commissioning deliverables."
        />
      </Helmet>
      <section className="relative bg-slateDeep text-white">
        <img
          src="https://picsum.photos/1600/900?random=41"
          alt="Lift Energy installation team on roof"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-slateDeep/70" aria-hidden="true" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl sm:text-5xl">We Physically Install Arrays</h1>
          <p className="mt-6 max-w-3xl text-base text-white/80">
            Lift Energy Canada’s crews and partner trades execute structurally sound, code-aligned solar installations with the documentation engineers expect.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl space-y-16 px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-3">
          {installCategories.map((item) => (
            <div key={item.title} className="rounded-3xl bg-white p-6 shadow-soft">
              <h2 className="text-lg font-semibold text-slateDeep">{item.title}</h2>
              <p className="mt-3 text-sm text-slate-600">{item.notes}</p>
            </div>
          ))}
        </div>

        <div className="rounded-3xl bg-slateMist p-8 shadow-soft">
          <h2 className="section-title text-slateDeep">Rails vs rail-free considerations</h2>
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            {railNotes.map((note) => (
              <div key={note.title} className="rounded-2xl bg-white p-6 shadow-sm">
                <h3 className="text-sm font-semibold text-slateDeep uppercase tracking-wide">{note.title}</h3>
                <p className="mt-3 text-sm text-slate-600">{note.body}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-3xl bg-white p-8 shadow-soft">
          <h2 className="section-title text-slateDeep">Roof penetration patterns</h2>
          <ul className="mt-6 space-y-4 text-sm text-slate-600">
            {penetrationPatterns.map((item) => (
              <li key={item} className="flex gap-3">
                <span className="mt-1 inline-flex h-2.5 w-2.5 flex-shrink-0 rounded-full bg-primary" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-3xl bg-slateDeep p-8 text-white shadow-soft">
          <h2 className="text-2xl font-semibold">Snow retention and fall protection</h2>
          <p className="mt-4 text-sm text-white/80">
            Snow guards prevent sliding sheets over entrances, while walkways and attachment points keep maintenance crews safe. We integrate anchors and fall arrest pathways into the layout before deployment.
          </p>
        </div>

        <div className="rounded-3xl bg-slateMist p-8 shadow-soft">
          <h2 className="section-title text-slateDeep">Inverter tie-in overview</h2>
          <p className="mt-4 text-sm text-slate-600">
            We coordinate conductor sizing, conduit fill, breaker selection, and rapid shutdown hardware. Connection points to the main service or sub panels are documented with clear labeling, torque specs, and photographs.
          </p>
        </div>

        <div className="rounded-3xl bg-white p-8 shadow-soft">
          <h2 className="section-title text-slateDeep">Commissioning steps</h2>
          <ol className="mt-6 space-y-4 text-sm text-slate-600">
            {commissioningSteps.map((step, index) => (
              <li key={step} className="flex gap-3">
                <span className="mt-1 inline-flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-white">
                  {index + 1}
                </span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
        </div>

        <div className="rounded-3xl bg-slateDeep p-8 text-white shadow-soft">
          <h2 className="text-2xl font-semibold">Deliverable package</h2>
          <ul className="mt-6 space-y-3 text-sm text-white/80">
            {deliverables.map((item) => (
              <li key={item} className="flex gap-3">
                <span className="mt-1 inline-flex h-2.5 w-2.5 flex-shrink-0 rounded-full bg-primary/90" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  );
};

export default Installation;