import React from "react";
import { Helmet } from "react-helmet";

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy — Lift Energy Canada</title>
      <meta
        name="description"
        content="Privacy policy for Lift Energy Canada outlining data collection and usage."
      />
    </Helmet>
    <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl text-slateDeep">Privacy Policy</h1>
      <p className="mt-6 text-sm text-slate-600">
        Lift Energy Canada respects your privacy and protects personal information collected through this website.
      </p>
      <h2 className="mt-6 text-lg font-semibold text-slateDeep">Information we collect</h2>
      <p className="mt-3 text-sm text-slate-600">
        We collect contact details and project information submitted through forms. Basic analytics may track anonymous usage patterns to improve the site.
      </p>
      <h2 className="mt-6 text-lg font-semibold text-slateDeep">How we use information</h2>
      <p className="mt-3 text-sm text-slate-600">
        Submitted information is used to respond to inquiries, prepare proposals, and coordinate engineering activities. We do not sell or share personal information with third parties, except providers supporting our operations under confidentiality agreements.
      </p>
      <h2 className="mt-6 text-lg font-semibold text-slateDeep">Data retention</h2>
      <p className="mt-3 text-sm text-slate-600">
        Project correspondence is retained for compliance and reference. You may request updates or deletion where legally permissible.
      </p>
      <h2 className="mt-6 text-lg font-semibold text-slateDeep">Security</h2>
      <p className="mt-3 text-sm text-slate-600">
        We implement technical and organizational safeguards appropriate for engineering documentation, including access controls and encrypted storage where applicable.
      </p>
      <h2 className="mt-6 text-lg font-semibold text-slateDeep">Contact</h2>
      <p className="mt-3 text-sm text-slate-600">
        Questions about privacy practices can be directed to our team via the Contact page.
      </p>
    </section>
  </>
);

export default Privacy;