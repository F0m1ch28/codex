import React, { useState } from "react";
import { Helmet } from "react-helmet";

const faqItems = [
  {
    question: "How do you connect arrays to the utility service?",
    answer: "We produce single-line diagrams, coordinate breaker sizing with the main panel, and schedule utility inspections. All conductor labels and disconnect signage follow ESA and utility requirements."
  },
  {
    question: "What documentation accompanies installation?",
    answer: "Torque logs, photos, inverter settings, telemetry credentials, and maintenance procedures are provided in a digital binder plus printed quick-reference sheets."
  },
  {
    question: "Do you offer structural engineering stamps?",
    answer: "Yes. Licensed structural engineers review and stamp the racking and attachment drawings where required."
  },
  {
    question: "How is work scheduled during winter?",
    answer: "We phase mechanical and electrical tasks around weather windows, keeping safety paramount and preventing thermal stress on roof materials."
  },
  {
    question: "Can Lift Energy coordinate with your electric utility?",
    answer: "We handle interconnection paperwork, pre-energization testing, and utility witness meetings, ensuring all forms and checklists are current."
  }
];

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <>
      <Helmet>
        <title>FAQ — Lift Energy Canada</title>
        <meta
          name="description"
          content="Answers to frequently asked questions about Lift Energy Canada's solar engineering, installation, and telemetry services."
        />
      </Helmet>
      <section className="relative bg-slateDeep text-white">
        <img
          src="https://picsum.photos/1600/900?random=101"
          alt="Questions and answers concept"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-slateDeep/70" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl sm:text-5xl">Frequently Asked Questions</h1>
          <p className="mt-6 max-w-3xl text-base text-white/80">
            Straightforward answers about engineering, installation, and data stewardship.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="space-y-4">
          {faqItems.map((item, index) => {
            const open = openIndex === index;
            return (
              <div key={item.question} className="rounded-2xl bg-white shadow-soft">
                <button
                  className="flex w-full items-center justify-between px-6 py-5 text-left text-base font-semibold text-slateDeep"
                  onClick={() => setOpenIndex(open ? -1 : index)}
                  aria-expanded={open}
                  aria-controls={`faq-panel-${index}`}
                >
                  {item.question}
                  <span className="ml-4 flex h-8 w-8 items-center justify-center rounded-full bg-slateMist text-primary">
                    {open ? "−" : "+"}
                  </span>
                </button>
                {open && (
                  <div id={`faq-panel-${index}`} className="border-t border-slate-100 px-6 py-4 text-sm text-slate-600">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </>
  );
};

export default FAQ;