import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";

const statsData = [
  { label: "Roof orientations mapped", value: 128 },
  { label: "Structural models executed", value: 312 },
  { label: "Telemetry stacks commissioned", value: 58 },
  { label: "Utility interconnects coordinated", value: 44 }
];

const moduleOptions = [
  {
    id: "halo-420",
    title: "Halo 420 Mono",
    chemistry: "n-type mono PERC",
    winterNote: "Keeps output under diffuse light with tempered glass and black backsheet."
  },
  {
    id: "alpina-455",
    title: "Alpina 455 Bifacial",
    chemistry: "bifacial mono",
    winterNote: "Snow albedo adds 6-9% winter shoulder energy when arrays are elevated."
  },
  {
    id: "solis-500",
    title: "Solis 500 Topcon",
    chemistry: "TOPCon mono",
    winterNote: "Suited for low irradiance mornings; requires tuned clamp pressure."
  }
];

const inverterOptions = [
  {
    id: "sollink-25k",
    title: "SolLink 25 kW",
    type: "3-phase string",
    notes: "Best when roof geometry enables three string groups truncated at equal lengths."
  },
  {
    id: "arcwave-10k",
    title: "ArcWave 10 kW",
    type: "hybrid string",
    notes: "Integrated rapid shutdown and battery-ready DC bus."
  },
  {
    id: "microgrid-qs",
    title: "MicroGrid QS",
    type: "microinverter pod",
    notes: "Roof-by-roof telemetry granularity with module-level optimization."
  }
];

const compatibilityMatrix = {
  "halo-420": {
    "sollink-25k": {
      layout: "4 strings × 16 modules, 680 Vdc nominal",
      telemetry: "String-level via RS485 to Modbus TCP bridge",
      comment: "Requires roof planes within 5° tilt delta for consistent MPPT."
    },
    "arcwave-10k": {
      layout: "3 strings × 11 modules, 495 Vdc nominal",
      telemetry: "Hybrid bus with meter socket gateway",
      comment: "Ideal for mixed load centers; ensure rapid shutdown transceivers under eaves."
    },
    "microgrid-qs": {
      layout: "Module-level, 2.5 kW AC pods per 8 panels",
      telemetry: "API push to supervisory platform through MQTT",
      comment: "Minimal DC routing, suits complex dormers."
    }
  },
  "alpina-455": {
    "sollink-25k": {
      layout: "3 strings × 15 modules, 615 Vdc nominal",
      telemetry: "Native Modbus over shielded CAT6",
      comment: "Adjust torque to account for bifacial frame thickness."
    },
    "arcwave-10k": {
      layout: "2 strings × 12 modules, 510 Vdc nominal",
      telemetry: "Hybrid logger with LTE fallback",
      comment: "Elevation mounts keep rear irradiance; plan for snow shedding gaps."
    },
    "microgrid-qs": {
      layout: "Pod-level pairing, 250 Vac branch circuits",
      telemetry: "Module analytics through RESTful endpoints",
      comment: "Bifacial metrics tracked individually for performance tuning."
    }
  },
  "solis-500": {
    "sollink-25k": {
      layout: "2 strings × 18 modules, 720 Vdc nominal",
      telemetry: "Central logger bridging to SCADA",
      comment: "TOPCon current profile demands thicker copper home-runs."
    },
    "arcwave-10k": {
      layout: "2 strings × 13 modules, 540 Vdc nominal",
      telemetry: "Hybrid DC bus with ethernet aggregator",
      comment: "Keep parallel strings within 1% voltage delta."
    },
    "microgrid-qs": {
      layout: "Pod-level, 3-phase balancing across roof facets",
      telemetry: "Edge analytics at each pod",
      comment: "Superb when mechanical penetrations must stay near hips."
    }
  }
};

const telemetryStack = [
  {
    title: "Array layer",
    items: ["Optimizers or string sensors", "Rapid shutdown compliance hardware", "Snow-shedding monitors"]
  },
  {
    title: "Inverter layer",
    items: ["Native logging bridge", "Heartbeat to cloud", "Firmware pinning schedule"]
  },
  {
    title: "Network layer",
    items: ["Primary ethernet drop", "LTE backup with keep-alive", "Utility meter sync"]
  },
  {
    title: "Data layer",
    items: ["Structured time-series in InfluxDB", "Grafana boards", "Webhook alerts for drift"]
  }
];

const caseStudies = [
  {
    title: "Corrugated steel at Georgian Bay",
    geometry: "35° south-facing ridge with cathedral trusses",
    module: "Halo 420 Mono",
    inverter: "SolLink 25 kW",
    mounting: "Rails with aluminum standoffs",
    telemetry: "Modbus + MQTT bridge",
    summary: "Structural analysis verified purlin spacing with reinforcement brackets in drift zones."
  },
  {
    title: "Heritage shingle downtown Toronto",
    geometry: "Multi-plane roof, dormers on east and west",
    module: "MicroGrid QS pods",
    inverter: "Pod-integrated",
    mounting: "Rail-free clamps with flashing",
    telemetry: "Pod-level REST feed",
    summary: "Electrical reroute to new combiner limiting conduit presence on facade."
  },
  {
    title: "Flat membrane retrofit Waterloo",
    geometry: "Ballasted arrays at 8° tilt",
    module: "Alpina 455 Bifacial",
    inverter: "ArcWave 10 kW hybrids",
    mounting: "Ballast trays + parapet anchors",
    telemetry: "Hybrid logger with LTE",
    summary: "Wind uplift modeled with CSA A123 compliance, snow guards added around parapets."
  }
];

const testimonialData = [
  {
    quote:
      "Lift Energy Canada approached our roof as a structural problem first. Their load calculations and coordination with our envelope consultant made the installation seamless when the snow hit in February.",
    author: "Morgan Patel",
    role: "Facilities Director, Georgian Bay Marine College"
  },
  {
    quote:
      "The team documented every decision, from inverter firmware to breaker labeling. Telemetry dashboards were ready the same day the array energized.",
    author: "Elliot Sinclair",
    role: "Operations Lead, Midtown Co-operative Housing"
  },
  {
    quote:
      "They understood Ontario utility timelines, drafted the single-line diagrams we needed, and kept our electricians in the loop with tightly written notes.",
    author: "Renaud Charbonneau",
    role: "Principal, Renaud Electrical Engineering"
  }
];

const faqPreview = [
  {
    question: "How do you model snow load for panels on pitched roofs?",
    answer: "We rely on OBC-part specific load factors, incorporate drift coefficients, and align racking layout with truss spacing to avoid overstress."
  },
  {
    question: "Do you coordinate rapid shutdown in multi-inverter environments?",
    answer: "Yes. Each string map includes device IDs, conductor routing, and signage packs that satisfy utility inspection checklists."
  },
  {
    question: "How is telemetry secured?",
    answer: "TLS-secured tunnels with rotating API tokens, plus off-site backups of interval data for redundancy."
  }
];

const Home = () => {
  const [selectedModule, setSelectedModule] = useState(moduleOptions[0].id);
  const [selectedInverter, setSelectedInverter] = useState(inverterOptions[0].id);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));

  useEffect(() => {
    const intervals = statsData.map((stat, index) =>
      setInterval(() => {
        setAnimatedStats((prev) => {
          const updated = [...prev];
          if (updated[index] < stat.value) {
            updated[index] = Math.min(updated[index] + Math.ceil(stat.value / 40), stat.value);
          }
          return updated;
        });
      }, 40)
    );

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonialData.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const compatibility = compatibilityMatrix[selectedModule][selectedInverter];

  return (
    <>
      <Helmet>
        <title>Lift Energy Canada — Solar Installed Like Engineering</title>
        <meta
          name="description"
          content="Engineering-grade solar arrays for Canadian roofs, climate loads, and telemetry requirements."
        />
      </Helmet>
      <div className="relative overflow-hidden">
        <section className="relative isolate flex min-h-[80vh] items-center bg-slateDeep text-white">
          <img
            src="https://picsum.photos/1600/900?random=11"
            alt="Aerial view of solar arrays on industrial roof"
            className="absolute inset-0 h-full w-full object-cover opacity-40"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-slateDeep/60" aria-hidden="true" />
          <div className="relative z-10 mx-auto flex max-w-6xl flex-col gap-8 px-4 py-24 sm:px-6 lg:px-8">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-4 py-1 text-xs font-semibold uppercase tracking-widest text-white/80 backdrop-blur">
              Canadian Load-First Solar Engineering
            </div>
            <h1 className="max-w-3xl font-display text-4xl leading-tight sm:text-5xl md:text-6xl">
              Solar Installed Like Engineering — Not Marketing
            </h1>
            <p className="max-w-2xl text-base text-white/80 sm:text-lg">
              We design and install solar arrays that respect structural realities, electrical coordination, and the telemetry each facility needs to run with confidence in a Canadian climate.
            </p>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Link
                to="/contact"
                className="inline-flex items-center justify-center rounded-full bg-primary px-7 py-3 text-sm font-semibold text-white shadow-lg shadow-primary/30 transition hover:translate-y-[-2px] hover:shadow-xl"
              >
                Start a technical review
              </Link>
              <Link
                to="/services"
                className="inline-flex items-center justify-center rounded-full border border-white/70 px-7 py-3 text-sm font-semibold text-white transition hover:bg-white hover:text-slateDeep"
              >
                Explore services
              </Link>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
          <p className="max-w-3xl text-lg text-slate-700">
            Lift Energy Canada aligns mechanical, electrical, and data decisions so solar arrays behave predictably across winter storms, gust events, and grid commissioning. Every project starts with load assumptions and utility language instead of marketing brochures.
          </p>
        </section>

        <section className="bg-white py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-6 rounded-3xl border border-slate-100 bg-slateMist p-6 shadow-soft sm:grid-cols-2 lg:grid-cols-4">
              {statsData.map((stat, index) => (
                <div key={stat.label} className="rounded-2xl bg-white p-6 shadow-sm">
                  <div className="text-3xl font-semibold text-primary transition-transform duration-700 ease-out">
                    {animatedStats[index]}
                  </div>
                  <p className="mt-2 text-sm font-medium text-slate-600">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl space-y-12 px-4 py-16 sm:px-6 lg:px-8">
          <div>
            <h2 className="section-title">What Canadian roofs actually imply</h2>
            <p className="section-lead">
              Roof assemblies vary wildly between steel, shingle, slate, and membrane. We decode truss spacing, sheathing condition, and parapet behaviour to set allowable spans and clamp density. No array moves forward without confirming wind and snow load paths through to structure.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-3">
            <div className="card">
              <h3 className="card-title">Mounting geometry decoded</h3>
              <p className="card-body">
                We model panel tilt, azimuth, and row spacing to see how shadows from chimneys or dormers affect daily harvest. Each plane gets a shading report and snow drifting overlay so connection points stay within acceptable compression on rafters.
              </p>
            </div>
            <div className="card">
              <h3 className="card-title">Snow load translation</h3>
              <p className="card-body">
                CSA S37 interpretations ensure rails and clamps survive 1-in-50 events. Skylight offsets, valley clearances, and structural blocking help drift management, while snow guards or fences protect egress points.
              </p>
            </div>
            <div className="card">
              <h3 className="card-title">Wind uplift controls</h3>
              <p className="card-body">
                We compute corner and edge zones, then adapt standoff spacing, ballast weights, or mechanical anchors accordingly. Each detail ties back to structural calculations you can present to building officials or insurers.
              </p>
            </div>
          </div>

          <div className="grid gap-10 lg:grid-cols-[1.1fr,0.9fr]">
            <div className="rounded-3xl bg-white p-8 shadow-soft">
              <h3 className="text-2xl font-semibold text-slateDeep">Module and inverter alignment matrix</h3>
              <p className="mt-4 text-sm text-slate-600">
                Pick a module and inverter configuration to view stringing, telemetry, and critical implementation notes.
              </p>
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                <label className="flex flex-col text-sm font-semibold text-slateDeep">
                  Module family
                  <select
                    value={selectedModule}
                    onChange={(event) => setSelectedModule(event.target.value)}
                    className="mt-2 w-full rounded-xl border border-slate-200 bg-slateMist px-4 py-3 text-sm text-slate-700 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/40"
                  >
                    {moduleOptions.map((module) => (
                      <option key={module.id} value={module.id}>
                        {module.title}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="flex flex-col text-sm font-semibold text-slateDeep">
                  Inverter architecture
                  <select
                    value={selectedInverter}
                    onChange={(event) => setSelectedInverter(event.target.value)}
                    className="mt-2 w-full rounded-xl border border-slate-200 bg-slateMist px-4 py-3 text-sm text-slate-700 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/40"
                  >
                    {inverterOptions.map((inverter) => (
                      <option key={inverter.id} value={inverter.id}>
                        {inverter.title}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
              <div className="mt-8 space-y-4 rounded-2xl border border-slate-200 bg-slateMist p-6">
                <div>
                  <h4 className="text-sm font-semibold text-slate-700">Stringing plan</h4>
                  <p className="mt-1 text-sm text-slate-600">{compatibility.layout}</p>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-700">Telemetry integration</h4>
                  <p className="mt-1 text-sm text-slate-600">{compatibility.telemetry}</p>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-700">Engineering note</h4>
                  <p className="mt-1 text-sm text-slate-600">{compatibility.comment}</p>
                </div>
              </div>
            </div>
            <div className="rounded-3xl bg-slateDeep p-8 text-white shadow-soft">
              <h3 className="text-2xl font-semibold">Why this inverter?</h3>
              <p className="mt-4 text-sm text-white/80">
                Inverters dictate how strings combine, how rapid shutdown behaves, and how telemetry flows. We evaluate MPPT window, Canadian certification, and firmware cadence. Each selection comes with commissioning scripts and panel labeling so inspectors and maintenance crews know the system state instantly.
              </p>
              <div className="mt-6 space-y-4">
                {inverterOptions.map((inverter) => (
                  <div
                    key={inverter.id}
                    className={`rounded-xl border px-4 py-3 text-sm transition ${
                      inverter.id === selectedInverter
                        ? "border-primary bg-primary/20 text-white"
                        : "border-white/20 bg-white/10 text-white/80"
                    }`}
                  >
                    <div className="font-semibold">{inverter.title}</div>
                    <div className="text-xs uppercase tracking-wide text-white/60">{inverter.type}</div>
                    <p className="mt-2 text-xs text-white/70">{inverter.notes}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid gap-10 lg:grid-cols-2">
            <div className="space-y-6">
              <h2 className="section-title">Diagrams of integration</h2>
              <p className="section-body">
                Each project receives single-line diagrams, racking schematics, and telemetry maps aligned with electrical code and utility expectations. We annotate device IDs, conduit routes, disconnect locations, and bonding paths for rapid inspection sign-off.
              </p>
              <div className="rounded-3xl border border-dashed border-primary/40 bg-white p-6">
                <img
                  src="https://picsum.photos/800/600?random=12"
                  alt="Abstract solar integration diagram"
                  className="rounded-2xl object-cover"
                  loading="lazy"
                />
              </div>
            </div>
            <div className="rounded-3xl bg-white p-8 shadow-soft">
              <h3 className="text-2xl font-semibold text-slateDeep">Telemetry stack overview</h3>
              <p className="mt-3 text-sm text-slate-600">
                Data only helps when each layer trusts the one below it. We build stacks with redundancy and technician-friendly naming so alerts translate into action.
              </p>
              <div className="mt-6 space-y-4">
                {telemetryStack.map((layer) => (
                  <div key={layer.title} className="rounded-2xl border border-slate-200 bg-slateMist p-5">
                    <h4 className="text-sm font-semibold text-slate-700">{layer.title}</h4>
                    <ul className="mt-3 space-y-2 text-sm text-slate-600">
                      {layer.items.map((item) => (
                        <li key={item} className="flex items-start gap-2">
                          <span className="mt-1 inline-flex h-2.5 w-2.5 flex-shrink-0 rounded-full bg-primary" aria-hidden="true" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <h2 className="section-title text-slateDeep">Case snapshots</h2>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {caseStudies.map((project) => (
                <div key={project.title} className="project-card">
                  <img
                    src={`https://picsum.photos/400/300?random=${project.title.length + 13}`}
                    alt={`${project.title} solar installation context`}
                    className="h-40 w-full rounded-2xl object-cover"
                    loading="lazy"
                  />
                  <div className="mt-4 text-sm font-semibold text-primary">{project.title}</div>
                  <dl className="mt-3 space-y-2 text-sm text-slate-600">
                    <div>
                      <dt className="font-semibold text-slateDeep">Roof geometry</dt>
                      <dd>{project.geometry}</dd>
                    </div>
                    <div>
                      <dt className="font-semibold text-slateDeep">Module</dt>
                      <dd>{project.module}</dd>
                    </div>
                    <div>
                      <dt className="font-semibold text-slateDeep">Inverter</dt>
                      <dd>{project.inverter}</dd>
                    </div>
                    <div>
                      <dt className="font-semibold text-slateDeep">Mounting</dt>
                      <dd>{project.mounting}</dd>
                    </div>
                    <div>
                      <dt className="font-semibold text-slateDeep">Telemetry</dt>
                      <dd>{project.telemetry}</dd>
                    </div>
                  </dl>
                  <p className="mt-4 text-sm text-slate-600">{project.summary}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-3xl bg-slateDeep p-10 text-white shadow-soft">
            <h2 className="text-2xl font-semibold">Testimonials grounded in operations</h2>
            <div className="mt-6">
              {testimonialData.map((item, index) => (
                <div
                  key={item.author}
                  className={`space-y-4 transition-opacity duration-700 ${
                    index === activeTestimonial ? "opacity-100" : "hidden opacity-0"
                  }`}
                >
                  <p className="text-lg text-white/90">“{item.quote}”</p>
                  <div className="text-sm font-semibold">{item.author}</div>
                  <div className="text-sm text-white/70">{item.role}</div>
                </div>
              ))}
            </div>
            <div className="mt-6 flex gap-2">
              {testimonialData.map((_, index) => (
                <button
                  key={index}
                  className={`h-2.5 w-8 rounded-full transition ${
                    index === activeTestimonial ? "bg-primary" : "bg-white/30"
                  }`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Show testimonial ${index + 1}`}
                />
              ))}
            </div>
          </div>

          <div>
            <h2 className="section-title">FAQ preview</h2>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {faqPreview.map((item) => (
                <div key={item.question} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                  <h3 className="text-base font-semibold text-slateDeep">{item.question}</h3>
                  <p className="mt-3 text-sm text-slate-600">{item.answer}</p>
                </div>
              ))}
            </div>
            <div className="mt-6">
              <Link to="/faq" className="inline-flex items-center text-sm font-semibold text-primary hover:underline">
                View the full FAQ →
              </Link>
            </div>
          </div>

          <div className="rounded-3xl bg-primary/10 p-10 shadow-soft">
            <h2 className="section-title text-slateDeep">Ready for a technical review?</h2>
            <p className="mt-4 text-sm text-slate-600">
              Provide drawings, interval data, or simply the questions you need answered, and we will schedule a session that ends with action-ready notes.
            </p>
            <div className="mt-6">
              <Link
                to="/contact"
                className="inline-flex items-center rounded-full bg-primary px-6 py-3 text-sm font-semibold text-white shadow hover:shadow-lg"
              >
                Contact Lift Energy Canada
              </Link>
            </div>
          </div>

          <div className="rounded-3xl bg-white p-6 text-xs text-slate-500">
            <p>
              Lift Energy Canada provides engineering-focused design and installation services. All recommendations assume site verification, structural review, and compliance with Canadian Electrical Code and local authority requirements prior to construction.
            </p>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;