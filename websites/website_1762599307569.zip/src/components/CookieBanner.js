import React, { useState, useEffect } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("liftEnergyCookieConsent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("liftEnergyCookieConsent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-4 left-0 right-0 z-[60] px-4">
      <div className="mx-auto flex max-w-5xl flex-col gap-4 rounded-2xl bg-white p-6 shadow-soft ring-1 ring-slate-200 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="font-display text-base text-slateDeep">Cookies for telemetry sanity</h3>
          <p className="mt-2 text-sm text-slate-600">
            We use minimal cookies to maintain session security and anonymized analytics that inform system reliability decisions.
            No marketing funnels, ever.
          </p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <a
            href="/cookie-policy"
            className="text-sm font-semibold text-primary underline-offset-4 hover:underline"
          >
            Review cookie policy
          </a>
          <button
            onClick={handleAccept}
            className="rounded-full bg-primary px-5 py-2 text-sm font-semibold text-white shadow-sm transition hover:shadow-md focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-white"
          >
            Accept and continue
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;