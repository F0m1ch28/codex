import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-slateDeep text-slateMist">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-4">
          <div>
            <h3 className="font-display text-xl text-white">Lift Energy Canada</h3>
            <p className="mt-4 text-sm text-slateMist/70">
              Solar engineered for Canadian conditions: structural loading, electrical quality, and telemetry cohesion.
            </p>
          </div>
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wide text-slateMist/80">
              Navigate
            </h4>
            <ul className="mt-3 space-y-2 text-sm text-slateMist/70">
              <li><Link to="/about" className="hover:text-primary transition-colors">About</Link></li>
              <li><Link to="/services" className="hover:text-primary transition-colors">Services</Link></li>
              <li><Link to="/case-studies" className="hover:text-primary transition-colors">Case Studies</Link></li>
              <li><Link to="/blog" className="hover:text-primary transition-colors">Blog</Link></li>
              <li><Link to="/faq" className="hover:text-primary transition-colors">FAQ</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wide text-slateMist/80">
              Compliance
            </h4>
            <ul className="mt-3 space-y-2 text-sm text-slateMist/70">
              <li><Link to="/terms" className="hover:text-primary transition-colors">Terms of Use</Link></li>
              <li><Link to="/privacy" className="hover:text-primary transition-colors">Privacy Policy</Link></li>
              <li><Link to="/cookie-policy" className="hover:text-primary transition-colors">Cookie Policy</Link></li>
              <li><a href="https://www.liftenergy.ca/sitemap.xml" className="hover:text-primary transition-colors">Sitemap</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wide text-slateMist/80">
              Contact
            </h4>
            <p className="mt-3 text-sm text-slateMist/70">
              200 Wellington St W<br />
              Toronto, ON M5V 3C7, Canada
            </p>
            <p className="mt-2 text-sm text-slateMist/70">
              Phone: <a href="tel:+14376127840" className="hover:text-primary">+1 (437) 612-7840</a>
            </p>
            <p className="mt-2 text-sm text-slateMist/70">
              Email is shared through the contact form for anti-spam control.
            </p>
          </div>
        </div>
        <div className="mt-12 border-t border-white/10 pt-6 text-center text-xs text-slateMist/60">
          © {new Date().getFullYear()} Lift Energy Canada. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;