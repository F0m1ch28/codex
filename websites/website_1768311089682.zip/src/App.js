import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/Home';
import { BreedsPage, AboutPage } from './pages/About';
import {
  CarePage,
  BehaviorPage,
  BlogPage,
  CookiePolicyPage,
} from './pages/Services';
import ContactPage from './pages/Contact';
import ThankYouPage from './pages/ThankYou';
import TermsOfServicePage from './pages/TermsOfService';
import PrivacyPolicyPage from './pages/PrivacyPolicy';
import styles from './App.module.css';

const App = () => (
  <div className={styles.app}>
    <a className={styles.skipLink} href="#main-content">
      Перейти к основному содержанию
    </a>
    <Header />
    <main id="main-content" className={styles.main}>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/breeds" element={<BreedsPage />} />
        <Route path="/care" element={<CarePage />} />
        <Route path="/behavior" element={<BehaviorPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/thank-you" element={<ThankYouPage />} />
        <Route path="/privacy" element={<PrivacyPolicyPage />} />
        <Route path="/terms" element={<TermsOfServicePage />} />
        <Route path="/cookie-policy" element={<CookiePolicyPage />} />
        <Route path="/about" element={<AboutPage />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTop />
  </div>
);

export default App;