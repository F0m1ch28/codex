import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className={styles.footer} aria-label="Футер сайта">
      <div className={styles.container}>
        <div className={styles.brandBlock}>
          <Link to="/" className={styles.logo}>
            <span className={styles.logoAccent}>Мир</span> Кошек
          </Link>
          <p className={styles.tagline}>
            Мы делимся проверенными знаниями, чтобы каждая кошка чувствовала заботу и любовь.
          </p>
        </div>

        <div className={styles.linksBlock}>
          <h3 className={styles.heading}>Навигация</h3>
          <ul className={styles.list}>
            <li><Link to="/" className={styles.link}>Главная</Link></li>
            <li><Link to="/breeds" className={styles.link}>Породы</Link></li>
            <li><Link to="/care" className={styles.link}>Уход и здоровье</Link></li>
            <li><Link to="/behavior" className={styles.link}>Поведение</Link></li>
            <li><Link to="/blog" className={styles.link}>Блог</Link></li>
            <li><Link to="/contact" className={styles.link}>Контакты</Link></li>
          </ul>
        </div>

        <div className={styles.contactBlock}>
          <h3 className={styles.heading}>Контакты</h3>
          <address className={styles.address}>
            <p className={styles.contactLine}>г. Москва, ул. Кошачья, д. 15</p>
            <p className={styles.contactLine}>
              <Link to="/contact" className={styles.link}>Телефон: +7 (495) 123-45-67</Link>
            </p>
            <p className={styles.contactLine}>
              <Link to="/contact" className={styles.link}>Email: info@cat-world.ru</Link>
            </p>
          </address>
          <ul className={styles.socialList} aria-label="Социальные сети">
            <li>
              <a
                className={styles.socialLink}
                href="https://vk.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="ВКонтакте"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
                  <path
                    fill="currentColor"
                    d="M4.5 5h2.7l1.7 3.2L10.7 5H13l-2.4 4 2.7 4.2h-2.7l-2-3.3-2 3.3H4.3l2.7-4.2L4.5 5Zm9.9 0h2.1c3.9 0 5.5 2.4 5.5 7s-1.6 7-5.5 7h-2.1V5Zm2.1 2v10c2.1 0 3.3-1.4 3.3-5s-1.2-5-3.3-5Z"
                  />
                </svg>
              </a>
            </li>
            <li>
              <a
                className={styles.socialLink}
                href="https://t.me"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Telegram"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
                  <path
                    fill="currentColor"
                    d="m9.04 15.38-.14 3.98c.2 0 .29-.09.4-.2l1.93-1.86 4.01 2.95c.73.41 1.24.2 1.43-.67l2.6-12.2.01-.01c.23-1.09-.41-1.52-1.12-1.25L3.84 11.03c-1.07.42-1.05 1.02-.19 1.29l4.02 1.25 9.32-5.88c.44-.28.84-.12.51.16l-8.46 7.53Z"
                  />
                </svg>
              </a>
            </li>
            <li>
              <a
                className={styles.socialLink}
                href="https://www.youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="YouTube"
              >
                <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
                  <path
                    fill="currentColor"
                    d="M21.6 7.2c-.2-1-.9-1.8-1.8-2-1.6-.3-5.8-.3-5.8-.3s-4.2 0-5.8.3c-.9.2-1.6 1-1.8 2C6 8.8 6 12 6 12s0 3.2.4 4.8c.2 1 .9 1.8 1.8 2 1.6.3 5.8.3 5.8.3s4.2 0 5.8-.3c.9-.2 1.6-1 1.8-2 .4-1.6.4-4.8.4-4.8s0-3.2-.4-4.8ZM10.5 15.2V8.8l5.2 3.2-5.2 3.2Z"
                  />
                </svg>
              </a>
            </li>
          </ul>
        </div>

        <div className={styles.policyBlock}>
          <h3 className={styles.heading}>Правовая информация</h3>
          <ul className={styles.list}>
            <li><Link to="/privacy" className={styles.link}>Политика конфиденциальности</Link></li>
            <li><Link to="/terms" className={styles.link}>Условия использования</Link></li>
            <li><Link to="/cookie-policy" className={styles.link}>Политика cookies</Link></li>
          </ul>
        </div>
      </div>

      <div className={styles.bottomLine}>
        <p className={styles.copy}>© {currentYear} Мир Кошек. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;