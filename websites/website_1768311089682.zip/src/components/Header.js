import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { to: '/', label: 'Главная' },
  { to: '/breeds', label: 'Породы' },
  { to: '/care', label: 'Уход' },
  { to: '/behavior', label: 'Поведение' },
  { to: '/blog', label: 'Блог' },
  { to: '/contact', label: 'Контакты' },
];

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMenu = () => setMobileMenuOpen((prev) => !prev);
  const closeMenu = () => setMobileMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} onClick={closeMenu} aria-label="На главную">
          <span className={styles.logoAccent}>Мир</span> Кошек
        </Link>

        <button
          type="button"
          className={styles.menuButton}
          onClick={toggleMenu}
          aria-expanded={mobileMenuOpen}
          aria-controls="primary-navigation"
          aria-label="Открыть меню"
        >
          <span className={styles.menuIcon} />
        </button>

        <nav
          id="primary-navigation"
          className={"${styles.nav} ${mobileMenuOpen ? styles.navOpen : ''}"}
          aria-label="Основное меню"
        >
          <ul className={styles.navList}>
            {navLinks.map(({ to, label }) => (
              <li key={to} className={styles.navItem}>
                <NavLink
                  to={to}
                  className={({ isActive }) =>
                    "${styles.navLink} ${isActive ? styles.active : ''}"
                  }
                  onClick={closeMenu}
                >
                  {label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;