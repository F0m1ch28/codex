import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from '../styles/Home.module.css';

const popularBreeds = [
  {
    name: 'Мейн-кун',
    description:
      'Ласковые гиганты с впечатляющим интеллектом и выразительным взглядом. Отличные компаньоны для семей.',
    image:
      'https://images.unsplash.com/photo-1601758234685-1c1f5232b1d0?auto=format&fit=crop&w=800&q=80',
  },
  {
    name: 'Британская короткошёрстная',
    description:
      'Спокойные и независимые кошки с плюшевой шерстью. Прекрасно адаптируются к жизни в квартире.',
    image:
      'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?auto=format&fit=crop&w=800&q=80',
  },
  {
    name: 'Сфинкс',
    description:
      'Энергичные и дружелюбные кошки без шерсти. Требуют особого ухода за кожей и любят тепло.',
    image:
      'https://images.unsplash.com/photo-1583795128727-6ec3642408f8?auto=format&fit=crop&w=800&q=80',
  },
  {
    name: 'Сиамская кошка',
    description:
      'Общительные и голосистые интеллектуалы. Имеют прекрасный характер и яркую окраску.',
    image:
      'https://images.unsplash.com/photo-1501820488136-72669149e0d4?auto=format&fit=crop&w=800&q=80',
  },
];

const careTips = [
  {
    title: 'Продуманное кормление',
    text: 'Выбирайте качественные полнорационные корма, учитывайте возраст и образ жизни питомца.',
  },
  {
    title: 'Уютный лоток',
    text: 'Содержите лоток в чистоте, ставьте его в тихом месте. Для требовательных кошек попробуйте закрытый вариант.',
  },
  {
    title: 'Когтеточки и игры',
    text: 'Обеспечьте кошке пространство для точения когтей и ежедневные игры для поддержания активности.',
  },
];

const catFacts = [
  'Кошки спят в среднем 14–16 часов в сутки, накапливая энергию для активных игр.',
  'У кошек более 100 различных звуковых сигналов — от мурлыканья до «разговоров».',
  'Сердце кошки сокращается в два раза быстрее человеческого — до 140 ударов в минуту.',
  'Усы помогают кошкам ориентироваться в пространстве и оценивать ширину проходов.',
  'Кошки чувствуют запахи примерно в 14 раз лучше, чем люди.',
];

const HomePage = () => {
  const heroBackground =
    'linear-gradient(135deg, rgba(249, 168, 38, 0.35), rgba(74, 101, 114, 0.35)), url("https://images.unsplash.com/photo-1519052537078-e6302a4968d4?auto=format&fit=crop&w=1600&q=80")';

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Мир Кошек — портал о кошках для заботливых хозяев</title>
        <meta
          name="description"
          content="Добро пожаловать в Мир Кошек! Узнайте о породах, уходе, здоровье и поведении кошек. Советы специалистов и вдохновение для любящих владельцев."
        />
        <meta
          name="keywords"
          content="кошки, породы кошек, уход за кошкой, советы, здоровье кошки, поведение кошки"
        />
      </Helmet>

      <section className={styles.hero} style={{ backgroundImage: heroBackground }}>
        <div className={styles.heroContent}>
          <h1 className={styles.heroTitle}>Добро пожаловать в мир кошек!</h1>
          <p className={styles.heroSubtitle}>
            Все, что вы хотели знать о ваших пушистых друзьях — от ухода и поведения до редких пород.
          </p>
          <div className={styles.heroActions}>
            <Link to="/breeds" className={styles.primaryButton}>
              Исследовать породы
            </Link>
            <Link to="/care" className={styles.secondaryButton}>
              Советы по уходу
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Популярные породы</h2>
          <p className={styles.sectionSubtitle}>
            Узнайте особенности характера и ухода за любимыми породами кошек.
          </p>
        </div>
        <div className={styles.cardsGrid}>
          {popularBreeds.map((breed) => (
            <article key={breed.name} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={breed.image} alt={breed.name} loading="lazy" />
              </div>
              <div className={styles.cardContent}>
                <h3 className={styles.cardTitle}>{breed.name}</h3>
                <p className={styles.cardText}>{breed.description}</p>
                <Link to="/breeds" className={styles.cardLink}>
                  Подробнее о породах
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="tips-heading">
        <div className={styles.sectionHeader}>
          <h2 id="tips-heading" className={styles.sectionTitle}>Советы дня</h2>
          <p className={styles.sectionSubtitle}>
            Применимые рекомендации, которые помогут сделать жизнь питомца здоровой и счастливой.
          </p>
        </div>
        <div className={styles.tipsList}>
          {careTips.map((tip) => (
            <article key={tip.title} className={styles.tipCard}>
              <h3 className={styles.tipTitle}>{tip.title}</h3>
              <p className={styles.tipText}>{tip.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.factSection} aria-labelledby="facts-heading">
        <div className={styles.sectionHeader}>
          <h2 id="facts-heading" className={styles.sectionTitle}>Интересные факты</h2>
        </div>
        <ul className={styles.factList}>
          {catFacts.map((fact) => (
            <li key={fact} className={styles.factItem}>
              <span className={styles.factBullet}>•</span>
              <p>{fact}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2 className={styles.ctaTitle}>Хотите узнать больше?</h2>
          <p className={styles.ctaText}>
            Исследуйте наш портал, чтобы открывать новые знания о кошках и делиться любовью к пушистым друзьям.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/blog" className={styles.primaryButton}>
              Читать блог
            </Link>
            <Link to="/contact" className={styles.secondaryButton}>
              Связаться с нами
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.aboutSection}>
        <div className={styles.aboutContent}>
          <h2 className={styles.sectionTitle}>О нас</h2>
          <p className={styles.aboutText}>
            «Мир Кошек» — это уютное пространство, где каждый владелец может найти проверенную и
            понятную информацию о здоровье, питании, воспитании и эмоциональном благополучии своего
            питомца. Мы собрали знания ветеринаров, фелинологов и опытных хозяев, чтобы помочь вам
            создавать лучшие условия для жизни любимой кошки.
          </p>
          <Link to="/about" className={styles.aboutLink}>
            Узнать о нашей миссии
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;