import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import styles from '../styles/Contact.module.css';

const initialState = {
  name: '',
  email: '',
  message: '',
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const nextErrors = {};
    const trimmedName = formData.name.trim();
    const trimmedEmail = formData.email.trim();
    const trimmedMessage = formData.message.trim();

    if (!trimmedName) {
      nextErrors.name = 'Пожалуйста, представьтесь.';
    }

    if (!trimmedEmail) {
      nextErrors.email = 'Укажите электронную почту.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      nextErrors.email = 'Введите корректный email.';
    }

    if (!trimmedMessage) {
      nextErrors.message = 'Напишите сообщение.';
    } else if (trimmedMessage.length < 10) {
      nextErrors.message = 'Сообщение должно содержать минимум 10 символов.';
    }

    return { nextErrors, trimmedName, trimmedEmail, trimmedMessage };
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const { nextErrors, trimmedName, trimmedEmail, trimmedMessage } = validate();

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    // Имитация отправки формы
    console.info('Сообщение отправлено:', {
      name: trimmedName,
      email: trimmedEmail,
      message: trimmedMessage,
    });

    setFormData(initialState);
    navigate('/thank-you', { state: { name: trimmedName } });
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Связаться с нами — Мир Кошек</title>
        <meta
          name="description"
          content="Свяжитесь с командой «Мир Кошек». Ответим на вопросы о породах, уходе и поведении. Адрес, телефон и форма обратной связи."
        />
        <meta
          name="keywords"
          content="контакты Мир Кошек, обратная связь, адрес кошачья 15, телефон +7 (495) 123-45-67"
        />
      </Helmet>

      <header className={styles.header}>
        <h1 className={styles.title}>Контакты</h1>
        <p className={styles.lead}>
          Мы всегда рады вопросам и предложениям. Напишите нам — и мы с удовольствием поделимся опытом.
        </p>
      </header>

      <div className={styles.grid}>
        <section className={styles.infoCard} aria-label="Контактная информация">
          <h2>Наши реквизиты</h2>
          <ul className={styles.infoList}>
            <li>
              <span className={styles.label}>Адрес:</span>
              <span>г. Москва, ул. Кошачья, д. 15</span>
            </li>
            <li>
              <span className={styles.label}>Телефон:</span>
              <a className={styles.infoLink} href="tel:+74951234567">
                +7 (495) 123-45-67
              </a>
            </li>
            <li>
              <span className={styles.label}>Email:</span>
              <a className={styles.infoLink} href="mailto:info@cat-world.ru">
                info@cat-world.ru
              </a>
            </li>
          </ul>
          <p className={styles.note}>
            Мы отвечаем на письма в рабочие дни с 10:00 до 18:00 (мск). Если хотите предложить тему для статьи,
            расскажите в письме о своём опыте и вопросах.
          </p>
        </section>

        <section className={styles.formCard} aria-label="Форма обратной связи">
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Имя</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Как к вам обращаться?"
                required
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && (
                <p id="name-error" className={styles.error} role="alert">
                  {errors.name}
                </p>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="email">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="name@example.ru"
                required
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && (
                <p id="email-error" className={styles.error} role="alert">
                  {errors.email}
                </p>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="message">Сообщение</label>
              <textarea
                id="message"
                name="message"
                rows={5}
                value={formData.message}
                onChange={handleChange}
                placeholder="Расскажите, чем мы можем помочь."
                required
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && (
                <p id="message-error" className={styles.error} role="alert">
                  {errors.message}
                </p>
              )}
            </div>

            <button type="submit" className={styles.submitButton}>
              Отправить сообщение
            </button>
          </form>
        </section>
      </div>
    </div>
  );
};

export default ContactPage;