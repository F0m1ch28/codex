import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from '../styles/Services.module.css';

const careGuides = [
  {
    topic: 'Питание',
    description:
      'Сбалансированный рацион — основа здоровья. Подбирайте корм по возрасту и активности, соблюдайте режим кормления.',
    tips: [
      'Сочетайте влажный и сухой корм для оптимального водного баланса.',
      'Используйте керамические миски и мойте их ежедневно.',
      'Не давайте кошкам еду со стола — это может привести к аллергии и ожирению.',
    ],
  },
  {
    topic: 'Гигиена',
    description:
      'Уход за шерстью и зубами помогает предотвратить колтуны и стоматологические проблемы.',
    tips: [
      'Вычесывайте длинношёрстных кошек через день, короткошёрстных — раз в неделю.',
      'Используйте специальные салфетки для чистки глаз и ушей.',
      'Проводите профилактику зубного камня с помощью паст и игрушек.',
    ],
  },
  {
    topic: 'Здоровье',
    description:
      'Регулярные визиты к ветеринару и вакцинация — залог долгой и активной жизни питомца.',
    tips: [
      'Планируйте чекапы не реже одного раза в год.',
      'Своевременно проводите обработку от паразитов.',
      'Следите за весом, аппетитом и поведением — любые изменения повод обратиться к врачу.',
    ],
  },
];

const behaviorBlocks = [
  {
    title: 'Понимание сигналов кошки',
    text: 'Поза, уши и хвост — основные индикаторы настроения. Расслабленная поза и медленные моргания означают доверие.',
  },
  {
    title: 'Игровая активность',
    text: 'Занимайтесь интерактивными играми каждый день. Игрушки-удочки и головоломки помогают выпускать энергию без разрушений.',
  },
  {
    title: 'Адаптация к изменениям',
    text: 'Предоставляйте укрытия, используйте феромоны и поддерживайте привычный распорядок, когда в доме происходят изменения.',
  },
];

const blogArticles = [
  {
    title: 'Как подготовить дом к появлению котёнка',
    excerpt:
      'Пошаговая инструкция: безопасное пространство, сбалансированное питание и первые игры, которые помогут встроить питомца в семью.',
    date: '20 марта 2024',
    tag: 'Советы новичкам',
  },
  {
    title: 'Пять признаков здоровой кошки',
    excerpt:
      'Рассказываем, на что обратить внимание: блеск шерсти, активность, аппетит и эмоциональное состояние.',
    date: '12 марта 2024',
    tag: 'Здоровье',
  },
  {
    title: 'Лайфхаки по уходу за шерстью',
    excerpt:
      'Выбираем правильные инструменты, режим ухода и способы помочь кошке справиться с линькой.',
    date: '29 февраля 2024',
    tag: 'Уход',
  },
];

export const CarePage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Уход и здоровье кошек — Мир Кошек</title>
      <meta
        name="description"
        content="Комплексные рекомендации по уходу за кошками: питание, гигиена и профилактика здоровья. Чек-листы и полезные советы экспертов."
      />
      <meta
        name="keywords"
        content="уход за кошками, здоровье кошек, питание кошек, гигиена кошек, ветеринарные советы"
      />
    </Helmet>

    <header className={styles.header}>
      <h1 className={styles.title}>Уход и здоровье</h1>
      <p className={styles.lead}>
        Забота о рационе, гигиене и профилактике заболеваний помогает кошкам сохранять активность и жизнелюбие.
      </p>
    </header>

    <section className={styles.grid}>
      {careGuides.map((guide) => (
        <article key={guide.topic} className={styles.card}>
          <h2 className={styles.cardTitle}>{guide.topic}</h2>
          <p className={styles.cardText}>{guide.description}</p>
          <ul className={styles.tipList}>
            {guide.tips.map((tip) => (
              <li key={tip}>{tip}</li>
            ))}
          </ul>
        </article>
      ))}
    </section>
  </div>
);

export const BehaviorPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Поведение кошек — Мир Кошек</title>
      <meta
        name="description"
        content="Расшифровываем поведение кошек: как понять настроение, настроить гармоничное общение и предотвратить нежелательные привычки."
      />
      <meta
        name="keywords"
        content="поведение кошек, психология кошек, воспитание кошек, советы фелинолога"
      />
    </Helmet>

    <header className={styles.header}>
      <h1 className={styles.title}>Поведение кошек</h1>
      <p className={styles.lead}>
        Кошки — независимые личности. Узнайте, как говорить с ними на одном языке, понимать эмоции и укреплять доверие.
      </p>
    </header>

    <section className={styles.behaviorGrid}>
      {behaviorBlocks.map((block) => (
        <article key={block.title} className={styles.behaviorCard}>
          <h2>{block.title}</h2>
          <p>{block.text}</p>
        </article>
      ))}
    </section>

    <section className={styles.section}>
      <h2 className={styles.sectionTitle}>Календарь настроения</h2>
      <p className={styles.text}>
        Ведите заметки о поведении кошки: время игр, реакции на гостей, изменения в привычках. Это поможет выявить триггеры
         и своевременно скорректировать бытовые условия или обратиться к специалисту.
      </p>
    </section>
  </div>
);

export const BlogPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Блог о кошках — Мир Кошек</title>
      <meta
        name="description"
        content="Актуальные материалы о жизни кошек: советы по воспитанию, идеи для игр, рекомендации ветеринаров и вдохновляющие истории."
      />
      <meta
        name="keywords"
        content="блог о кошках, советы по кошкам, статьи о кошках, истории о кошках"
      />
    </Helmet>

    <header className={styles.header}>
      <h1 className={styles.title}>Блог</h1>
      <p className={styles.lead}>
        Интересные истории, практические подборки и вдохновение для тех, кто делит дом с кошками.
      </p>
    </header>

    <section className={styles.blogGrid}>
      {blogArticles.map((article) => (
        <article key={article.title} className={styles.blogCard}>
          <div className={styles.blogMeta}>
            <span className={styles.blogTag}>{article.tag}</span>
            <span className={styles.blogDate}>{article.date}</span>
          </div>
          <h2 className={styles.blogTitle}>{article.title}</h2>
          <p className={styles.blogExcerpt}>{article.excerpt}</p>
          <a
            className={styles.blogLink}
            href="https://cat-world.ru/blog"
            target="_blank"
            rel="noopener noreferrer"
          >
            Читать полностью
          </a>
        </article>
      ))}
    </section>
  </div>
);

export const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Политика использования cookies — Мир Кошек</title>
      <meta
        name="description"
        content="Условия использования файлов cookies на сайте «Мир Кошек»: какие данные собираются, для чего и как управлять настройками."
      />
      <meta
        name="keywords"
        content="политика cookies, cookies Мир Кошек, согласие на cookies"
      />
    </Helmet>

    <header className={styles.header}>
      <h1 className={styles.title}>Политика использования cookies</h1>
      <p className={styles.lead}>
        Мы используем cookies, чтобы сайт работал корректно, а материалы были полезнее и удобнее для вас.
      </p>
    </header>

    <section className={styles.section}>
      <h2 className={styles.sectionTitle}>Что такое cookies</h2>
      <p className={styles.text}>
        Cookies — это небольшие текстовые файлы, которые сохраняются на вашем устройстве при посещении сайта.
        Они помогают нам запоминать ваши предпочтения, собирать обезличенную статистику и улучшать работу сервиса.
      </p>
    </section>

    <section className={styles.section}>
      <h2 className={styles.sectionTitle}>Какие cookies мы используем</h2>
      <ul className={styles.list}>
        <li>
          <strong>Технические</strong> — обеспечивают доступ к основным функциям сайта.
        </li>
        <li>
          <strong>Аналитические</strong> — позволяют понимать, какие материалы интересуют читателей.
        </li>
        <li>
          <strong>Функциональные</strong> — запоминают выбранный язык и настройки интерфейса.
        </li>
      </ul>
    </section>

    <section className={styles.section}>
      <h2 className={styles.sectionTitle}>Как управлять cookies</h2>
      <p className={styles.text}>
        Вы можете изменить или отключить cookies в настройках браузера. Обратите внимание, что некоторые функции сайта
        могут работать некорректно при полном отключении файлов cookies.
      </p>
    </section>
  </div>
);

export default CarePage;