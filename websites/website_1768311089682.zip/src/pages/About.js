import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from '../styles/About.module.css';

const breedHighlights = [
  {
    name: 'Сибирская кошка',
    origin: 'Россия',
    temperament: 'Спокойная, уравновешенная, привязана к семье.',
    grooming: 'Плотная шерсть требует регулярного расчесывания.',
  },
  {
    name: 'Невская маскарадная',
    origin: 'Россия',
    temperament: 'Общительная, любознательная, отлично ладит с детьми.',
    grooming: 'Умеренный уход за шерстью и контроль питания.',
  },
  {
    name: 'Абиссинская',
    origin: 'Эфиопия',
    temperament: 'Игривая, активная, любит взаимодействовать с человеком.',
    grooming: 'Шерсть короткая, достаточно вычесывать раз в неделю.',
  },
  {
    name: 'Норвежская лесная',
    origin: 'Северная Европа',
    temperament: 'Независимая, но ласковая, любит исследовать пространство.',
    grooming: 'Необходима профилактика колтунов.',
  },
];

const BreedsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Породы кошек — Мир Кошек</title>
      <meta
        name="description"
        content="Породы кошек: описания характера, рекомендации по уходу и советы по выбору. Сибирская, невская маскарадная, абиссинская и другие."
      />
      <meta
        name="keywords"
        content="породы кошек, выбор породы, характер кошки, уход за породой"
      />
    </Helmet>

    <header className={styles.header}>
      <h1 className={styles.title}>О породах</h1>
      <p className={styles.lead}>
        Понимание особенностей характера и ухода помогает найти идеального пушистого друга.
        Естественное происхождение, темперамент и потребности — ключевые критерии при выборе породы.
      </p>
    </header>

    <section className={styles.heroSection}>
      <div className={styles.heroCard}>
        <h2 className={styles.sectionTitle}>Как выбрать породу</h2>
        <p>
          Оцените свой образ жизни, наличие свободного времени и активность семьи. Активным людям подойдут
          игривые и любопытные породы, а тем, кто проводит много времени в офисе, — более независимые и
          спокойные кошки.
        </p>
        <ul className={styles.checklist}>
          <li>Уровень активности и привязанности к владельцу</li>
          <li>Особенности шерсти и потребности в уходе</li>
          <li>Совместимость с детьми и другими животными</li>
          <li>Потребность в пространстве и игрушках</li>
        </ul>
        <Link to="/contact" className={styles.ctaLink}>
          Получить советы по выбору
        </Link>
      </div>
    </section>

    <section className={styles.section} aria-labelledby="breed-highlights">
      <h2 id="breed-highlights" className={styles.sectionTitle}>
        Популярные породы в России
      </h2>
      <div className={styles.grid}>
        {breedHighlights.map((breed) => (
          <article key={breed.name} className={styles.breedCard}>
            <h3 className={styles.cardTitle}>{breed.name}</h3>
            <dl className={styles.cardList}>
              <div>
                <dt>Происхождение</dt>
                <dd>{breed.origin}</dd>
              </div>
              <div>
                <dt>Характер</dt>
                <dd>{breed.temperament}</dd>
              </div>
              <div>
                <dt>Уход</dt>
                <dd>{breed.grooming}</dd>
              </div>
            </dl>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.section} aria-labelledby="resources">
      <h2 id="resources" className={styles.sectionTitle}>Полезные ресурсы</h2>
      <div className={styles.resources}>
        <article className={styles.resourceCard}>
          <h3>Каталог пород</h3>
          <p>Подробные описания пород с фото, рекомендациями по уходу и особенностями поведения.</p>
          <Link to="/blog" className={styles.resourceLink}>
            Читать подборку
          </Link>
        </article>
        <article className={styles.resourceCard}>
          <h3>Консультации экспертов</h3>
          <p>Подготовили чек-листы от фелинологов и ветеринаров для осознанного выбора котёнка.</p>
          <Link to="/contact" className={styles.resourceLink}>
            Задать вопрос
          </Link>
        </article>
      </div>
    </section>
  </div>
);

const AboutPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>О проекте Мир Кошек</title>
      <meta
        name="description"
        content="Миссия проекта «Мир Кошек» — объединить любителей кошек и поделиться проверенными знаниями о заботе и благополучии питомцев."
      />
      <meta
        name="keywords"
        content="о проекте Мир Кошек, команда Мир Кошек, миссия сайта"
      />
    </Helmet>

    <header className={styles.header}>
      <h1 className={styles.title}>О проекте</h1>
      <p className={styles.lead}>
        «Мир Кошек» объединяет любителей животных, экспертов и всех, кто хочет создать лучшую жизнь
        для своего питомца. Мы развиваем информативный и вдохновляющий портал для русскоязычной аудитории.
      </p>
    </header>

    <section className={styles.section}>
      <h2 className={styles.sectionTitle}>Наша философия</h2>
      <p className={styles.text}>
        Мы верим, что забота о кошках начинается с знаний. Поэтому собираем практический опыт, мнения ветеринаров,
        фелинологов и зоопсихологов. Чем больше владельцы знают о потребностях кошек, тем гармоничнее их совместная жизнь.
      </p>
      <p className={styles.text}>
        В основе портала лежит доверие: каждому материалу предшествует проверка фактов и рекомендаций. Мы не размещаем
        коммерческие предложения по продаже животных — наше пространство полностью посвящено ответственному содержанию и любви.
      </p>
    </section>

    <section className={styles.section}>
      <h2 className={styles.sectionTitle}>Команда</h2>
      <ul className={styles.teamList}>
        <li>
          <h3>Анна Соколова — главный редактор</h3>
          <p>Профессиональный журналист, обожает сибирских кошек и курирует рубрики «поведение» и «уход».</p>
        </li>
        <li>
          <h3>Дмитрий Иванов — ветеринарный консультант</h3>
          <p>Ветеринарный врач с 12-летним стажем. Помогает адаптировать рекомендации для домашних условий.</p>
        </li>
        <li>
          <h3>Мария Котова — фелинолог</h3>
          <p>Специалист по породам. Подбирает материалы о происхождении, стандартах и выставках.</p>
        </li>
      </ul>
    </section>
  </div>
);

export { BreedsPage, AboutPage };
export default AboutPage;