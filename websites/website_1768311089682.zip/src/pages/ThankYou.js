import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from '../styles/ThankYou.module.css';

const ThankYouPage = () => {
  const location = useLocation();
  const name = location.state?.name || 'друг';

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Спасибо за обращение — Мир Кошек</title>
        <meta
          name="description"
          content="Ваше сообщение отправлено. Команда «Мир Кошек» свяжется с вами и поделится полезной информацией."
        />
        <meta
          name="keywords"
          content="спасибо за сообщение, обратная связь Мир Кошек"
        />
      </Helmet>

      <div className={styles.card}>
        <h1 className={styles.title}>Спасибо, {name}!</h1>
        <p className={styles.text}>
          Мы получили ваше сообщение и ответим в ближайшее время. Пока вы ждёте, предлагаем почитать свежие советы или
          перейти к подборкам по породам.
        </p>
        <div className={styles.actions}>
          <Link to="/" className={styles.primaryButton}>
            На главную
          </Link>
          <Link to="/blog" className={styles.secondaryButton}>
            Читать блог
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ThankYouPage;