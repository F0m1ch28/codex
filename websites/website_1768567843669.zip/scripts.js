(function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.getElementById('primary-navigation');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navLinks.classList.toggle('is-open');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 900) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    navLinks.classList.remove('is-open');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookies = document.getElementById('accept-cookies');
    const declineCookies = document.getElementById('decline-cookies');

    const consentStatus = localStorage.getItem('imwCookieConsent');

    const hideBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.remove('visible');
        }
    };

    if (!consentStatus && cookieBanner) {
        cookieBanner.classList.add('visible');
    }

    if (acceptCookies) {
        acceptCookies.addEventListener('click', () => {
            localStorage.setItem('imwCookieConsent', 'accepted');
            hideBanner();
        });
    }

    if (declineCookies) {
        declineCookies.addEventListener('click', () => {
            localStorage.setItem('imwCookieConsent', 'declined');
            hideBanner();
        });
    }

    document.querySelectorAll('.faq-item').forEach(item => {
        const question = item.querySelector('.faq-question');
        if (question) {
            question.addEventListener('click', () => {
                item.classList.toggle('open');
            });
        }
    });
})();