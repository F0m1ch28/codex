document.addEventListener("DOMContentLoaded", () => {
    const menuToggle = document.querySelector(".menu-toggle");
    const navLinks = document.querySelector(".nav-links");
    if (menuToggle && navLinks) {
        menuToggle.addEventListener("click", () => {
            const isOpen = navLinks.classList.toggle("is-open");
            menuToggle.classList.toggle("is-active", isOpen);
            menuToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
        });
        navLinks.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                navLinks.classList.remove("is-open");
                menuToggle.classList.remove("is-active");
                menuToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    const yearElements = document.querySelectorAll(".current-year");
    const currentYear = new Date().getFullYear();
    yearElements.forEach((el) => (el.textContent = currentYear));

    const cookieBanner = document.getElementById("cookieBanner");
    const acceptBtn = document.getElementById("acceptCookies");
    const declineBtn = document.getElementById("declineCookies");
    const storageKey = "catchuptq_cookie_choice";

    if (cookieBanner && acceptBtn && declineBtn) {
        const storedPreference = localStorage.getItem(storageKey);
        if (!storedPreference) {
            cookieBanner.classList.add("visible");
        }

        const hideBanner = (choice) => {
            localStorage.setItem(storageKey, choice);
            cookieBanner.classList.remove("visible");
        };

        acceptBtn.addEventListener("click", () => hideBanner("accepted"));
        declineBtn.addEventListener("click", () => hideBanner("declined"));
    }
});