document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = siteNav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
      document.body.classList.toggle("nav-open", isOpen);
    });
  }

  const yearSpan = document.querySelectorAll(".current-year");
  const currentYear = new Date().getFullYear();
  yearSpan.forEach((el) => {
    el.textContent = currentYear;
  });

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  document.querySelectorAll("[data-animate]").forEach((element) => {
    observer.observe(element);
  });

  const cookieBanner = document.getElementById("cookie-banner");
  const acceptButton = document.getElementById("cookie-accept");
  const declineButton = document.getElementById("cookie-decline");
  const cookieKey = "cancunleaving-cookie-choice";

  function hideCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
  }

  if (cookieBanner) {
    const storedChoice = localStorage.getItem(cookieKey);
    if (!storedChoice) {
      cookieBanner.classList.add("active");
    }

    if (acceptButton) {
      acceptButton.addEventListener("click", () => {
        localStorage.setItem(cookieKey, "accepted");
        hideCookieBanner();
      });
    }

    if (declineButton) {
      declineButton.addEventListener("click", () => {
        localStorage.setItem(cookieKey, "declined");
        hideCookieBanner();
      });
    }
  }

  function showToast(message) {
    const existingToast = document.querySelector(".toast");
    if (existingToast) {
      existingToast.remove();
    }
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = message;
    document.body.appendChild(toast);
    return toast;
  }

  document.querySelectorAll('form[data-has-toast="true"]').forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const toast = showToast("Message sent. Redirecting...");
      setTimeout(() => {
        toast.remove();
        window.location.href = form.getAttribute("action");
      }, 2000);
    });
  });
});