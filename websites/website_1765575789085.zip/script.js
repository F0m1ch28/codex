document.addEventListener("DOMContentLoaded",function(){
  const toggle=document.querySelector(".menu-toggle");
  const nav=document.getElementById("primary-navigation");
  if(toggle&&nav){
    const closeNav=()=>{toggle.setAttribute("aria-expanded","false");nav.classList.remove("is-open");};
    toggle.addEventListener("click",()=>{
      const expanded=toggle.getAttribute("aria-expanded")==="true";
      toggle.setAttribute("aria-expanded",String(!expanded));
      nav.classList.toggle("is-open");
    });
    nav.querySelectorAll("a").forEach(link=>{
      link.addEventListener("click",()=>closeNav());
    });
  }
  const yearEl=document.getElementById("current-year");
  if(yearEl){yearEl.textContent=new Date().getFullYear();}
  const banner=document.querySelector(".cookie-banner");
  if(banner){
    const stored=localStorage.getItem("ql-cookie-consent");
    if(!stored){
      requestAnimationFrame(()=>{
        banner.classList.add("is-active");
        banner.setAttribute("aria-hidden","false");
      });
    }else{
      banner.setAttribute("aria-hidden","true");
    }
    const hideBanner=choice=>{
      banner.classList.remove("is-active");
      banner.setAttribute("aria-hidden","true");
      localStorage.setItem("ql-cookie-consent",choice);
    };
    const acceptBtn=banner.querySelector('[data-cookie="accept"]');
    const declineBtn=banner.querySelector('[data-cookie="decline"]');
    acceptBtn&&acceptBtn.addEventListener("click",()=>hideBanner("accepted"));
    declineBtn&&declineBtn.addEventListener("click",()=>hideBanner("declined"));
  }
});