import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Vexoralia – Datenschutz</title>
        <meta
          name="description"
          content="Datenschutzinformationen zur Remote-Plattform Vexoralia gemäß DSGVO."
        />
      </Helmet>

      <div className="container">
        <h1>Datenschutzerklärung</h1>
        <p>Stand: Februar 2024</p>

        <section>
          <h2>1. Verantwortliche Stelle</h2>
          <p>
            Verantwortlich für die Datenverarbeitung ist die Vexoralia Plattform. Fragen zum Datenschutz kannst du über unser Kontaktformular stellen.
          </p>
        </section>

        <section>
          <h2>2. Erhobene Daten</h2>
          <p>
            Wir verarbeiten personenbezogene Daten (z. B. Name, E-Mail, Profilinformationen) für das Matching, die Community und Lernangebote. Technische Daten wie IP-Adressen, Logfiles und Geräteinformationen dienen zur Sicherstellung des Betriebs.
          </p>
        </section>

        <section>
          <h2>3. Zweck der Verarbeitung</h2>
          <p>
            Die Daten werden zur Bereitstellung unserer Services, zur Kommunikation mit Nutzer:innen, zur Verbesserung der Plattform sowie zur Sicherheit verarbeitet. Rechtsgrundlagen sind Art. 6 Abs. 1 lit. b DSGVO (Vertragserfüllung) und lit. f DSGVO (berechtigtes Interesse).
          </p>
        </section>

        <section>
          <h2>4. Cookies & Tracking</h2>
          <p>
            Wir verwenden funktionale Cookies und Analyse-Tools mit anonymisierten Daten. Detaillierte Informationen findest du in unserer Cookie-Richtlinie. Du kannst nicht essenzielle Cookies jederzeit deaktivieren.
          </p>
        </section>

        <section>
          <h2>5. Weitergabe an Dritte</h2>
          <p>
            Daten werden nur an Dienstleister weitergegeben, die uns bei Hosting, Support oder Analysen unterstützen und vertraglich auf Datenschutz verpflichtet sind. Eine Übermittlung in Drittländer erfolgt nur bei Vorliegen geeigneter Garantien.
          </p>
        </section>

        <section>
          <h2>6. Aufbewahrung</h2>
          <p>
            Wir speichern Daten nur solange, wie es für die genannten Zwecke erforderlich ist. Nach Beendigung der Nutzung werden Profile anonymisiert oder gelöscht, sofern keine gesetzlichen Aufbewahrungspflichten bestehen.
          </p>
        </section>

        <section>
          <h2>7. Rechte der Betroffenen</h2>
          <p>
            Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit sowie Widerspruch. Wende dich dazu an unser Team über das Kontaktformular.
          </p>
        </section>
      </div>
    </div>
  );
};

export default Privacy;