import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Jobs.module.css';

const jobList = [
  {
    title: 'Senior Frontend Engineer',
    company: 'Flowgrid Labs',
    location: 'Berlin (remote-first)',
    mode: 'Vollzeit',
    category: 'Engineering',
    languages: ['Deutsch', 'Englisch'],
    description: 'Baue modulare UI-Systeme für eine SaaS-Plattform, arbeite mit React, TypeScript und Design Ops zusammen.',
  },
  {
    title: 'People & Culture Partner',
    company: 'Nordlicht Ventures',
    location: 'Hamburg (remote möglich)',
    mode: 'Teilzeit',
    category: 'People & Operations',
    languages: ['Deutsch'],
    description: 'Begleite verteilte Teams, entwickle Remote-Onboarding-Prozesse und Hybrid-Policies.',
  },
  {
    title: 'UX Research Lead',
    company: 'Studio Arctis',
    location: 'Köln (hybrid)',
    mode: 'Vollzeit',
    category: 'Design',
    languages: ['Deutsch', 'Englisch'],
    description: 'Plane und führe Remote-Studien durch, koordiniere internationale Panels und Insights.',
  },
  {
    title: 'Customer Success Manager',
    company: 'CuraConnect',
    location: 'München (remote)',
    mode: 'Vollzeit',
    category: 'Customer Experience',
    languages: ['Deutsch', 'Englisch'],
    description: 'Unterstütze Kund:innen bei der Implementierung digitaler Prozesse, nutze Community-Feedback für Optimierungen.',
  },
  {
    title: 'Data Analyst',
    company: 'Atlas Insights',
    location: 'Leipzig (remote möglich)',
    mode: 'Projektbasiert',
    category: 'Analytics',
    languages: ['Deutsch', 'Englisch'],
    description: 'Analysiere Remote-Produktnutzung, baue Dashboards auf und entwickle Predictive-Modelle.',
  },
];

const Jobs = () => {
  const [modeFilter, setModeFilter] = useState('Alle');
  const [categoryFilter, setCategoryFilter] = useState('Alle');
  const [languageFilter, setLanguageFilter] = useState('Alle');

  const modes = ['Alle', 'Vollzeit', 'Teilzeit', 'Projektbasiert'];
  const categories = ['Alle', ...new Set(jobList.map((job) => job.category))];
  const languages = ['Alle', 'Deutsch', 'Englisch'];

  const filteredJobs = useMemo(() => {
    return jobList.filter((job) => {
      const matchesMode = modeFilter === 'Alle' || job.mode === modeFilter;
      const matchesCategory = categoryFilter === 'Alle' || job.category === categoryFilter;
      const matchesLanguage =
        languageFilter === 'Alle' || job.languages.includes(languageFilter);
      return matchesMode && matchesCategory && matchesLanguage;
    });
  }, [modeFilter, categoryFilter, languageFilter]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Vexoralia – Kuratierte Remote-Jobs</title>
        <meta
          name="description"
          content="Entdecke ausgewählte Remote-Jobs in Deutschland: filtere nach Teamkultur, Arbeitsmodus und Branche."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Remote-Jobs für Talente in Deutschland</h1>
          <p>
            Finde Rollen, die zu deinen Arbeitsrhythmen, Fähigkeiten und Sprachpräferenzen passen. Jede Ausschreibung wird von uns geprüft und mit Detail-Insights ergänzt.
          </p>
        </div>
      </section>

      <section className={styles.filters}>
        <div className="container">
          <div className={styles.filterGrid} role="group" aria-label="Jobfilter">
            <label>
              <span>Arbeitsmodus</span>
              <select value={modeFilter} onChange={(event) => setModeFilter(event.target.value)}>
                {modes.map((mode) => (
                  <option key={mode} value={mode}>
                    {mode}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span>Bereich</span>
              <select
                value={categoryFilter}
                onChange={(event) => setCategoryFilter(event.target.value)}
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span>Sprache</span>
              <select
                value={languageFilter}
                onChange={(event) => setLanguageFilter(event.target.value)}
              >
                {languages.map((lang) => (
                  <option key={lang} value={lang}>
                    {lang}
                  </option>
                ))}
              </select>
            </label>
          </div>
        </div>
      </section>

      <section className={styles.listings}>
        <div className="container">
          <div className={styles.jobGrid}>
            {filteredJobs.map((job) => (
              <article key={job.title} className={styles.jobCard}>
                <div className={styles.jobHeader}>
                  <h2>{job.title}</h2>
                  <span className={styles.mode}>{job.mode}</span>
                </div>
                <div className={styles.meta}>
                  <span>{job.company}</span>
                  <span>{job.location}</span>
                </div>
                <p>{job.description}</p>
                <div className={styles.tags}>
                  <span>{job.category}</span>
                  {job.languages.map((lang) => (
                    <span key={lang}>{lang}</span>
                  ))}
                </div>
                <button type="button" className={styles.action}>
                  App ausprobieren
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Jobs;