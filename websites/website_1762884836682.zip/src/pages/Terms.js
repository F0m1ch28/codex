import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Vexoralia – Nutzungsbedingungen</title>
        <meta
          name="description"
          content="Nutzungsbedingungen der Vexoralia Plattform für Remote-Arbeit."
        />
      </Helmet>

      <div className="container">
        <h1>Nutzungsbedingungen</h1>
        <p>Stand: Februar 2024</p>

        <section>
          <h2>1. Geltungsbereich</h2>
          <p>
            Diese Nutzungsbedingungen regeln die Nutzung der Plattform Vexoralia für Remote-Arbeit in Deutschland. Mit dem Anlegen eines Accounts akzeptierst du die nachfolgenden Bedingungen.
          </p>
        </section>

        <section>
          <h2>2. Leistungen</h2>
          <p>
            Vexoralia bietet digitale Services zur Remote-Zusammenarbeit, darunter Job-Matching, Workflow-Tools, Lernangebote und Community-Formate. Umfang und Verfügbarkeit können angepasst werden, um ein bestmögliches Nutzererlebnis sicherzustellen.
          </p>
        </section>

        <section>
          <h2>3. Registrierung</h2>
          <p>
            Für individuelle Features ist eine Registrierung erforderlich. Du verpflichtest dich, korrekte Angaben zu machen und Zugangsdaten vertraulich zu behandeln. Ein Verstoß kann zur Sperrung des Accounts führen.
          </p>
        </section>

        <section>
          <h2>4. Verantwortlichkeiten</h2>
          <p>
            Nutzer:innen sind für die Inhalte, die sie auf Vexoralia einstellen, selbst verantwortlich. Verboten sind rechtswidrige, diskriminierende oder urheberrechtsverletzende Inhalte. Wir behalten uns vor, Beiträge zu prüfen und zu entfernen.
          </p>
        </section>

        <section>
          <h2>5. Datenschutz</h2>
          <p>
            Die Verarbeitung personenbezogener Daten erfolgt gemäß unserer Datenschutzerklärung. Wir treffen angemessene technische und organisatorische Maßnahmen, um Daten zu schützen.
          </p>
        </section>

        <section>
          <h2>6. Haftung</h2>
          <p>
            Vexoralia haftet nur bei Vorsatz oder grober Fahrlässigkeit sowie bei Verletzung wesentlicher Vertragspflichten. Bei leicht fahrlässiger Verletzung wesentlicher Pflichten ist die Haftung auf typische, vorhersehbare Schäden begrenzt.
          </p>
        </section>

        <section>
          <h2>7. Änderungen</h2>
          <p>
            Wir können diese Nutzungsbedingungen bei Bedarf anpassen. Über Änderungen informieren wir rechtzeitig. Wird die Plattform nach Inkrafttreten weiter genutzt, gelten die neuen Bedingungen als akzeptiert.
          </p>
        </section>
      </div>
    </div>
  );
};

export default Terms;