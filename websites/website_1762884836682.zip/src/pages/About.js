import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Mara Klein',
    role: 'CEO & Remote Strategy',
    bio: 'Expertin für verteilte Organisationsmodelle. Entwickelt Remote-Playbooks für Mittelständler.',
    image: 'https://picsum.photos/400/400?random=3',
  },
  {
    name: 'Daniel Vogt',
    role: 'CTO & Platform Engineering',
    bio: 'Verantwortet die Workflow-Infrastruktur und Tool-Integrationen für skalierbare Teams.',
    image: 'https://picsum.photos/400/400?random=10',
  },
  {
    name: 'Sofia Nguyen',
    role: 'Head of Community',
    bio: 'Aufbau von Mentoring-Netzwerken, Events und Ressourcen für Remote-Talente.',
    image: 'https://picsum.photos/400/400?random=11',
  },
  {
    name: 'Lars Becker',
    role: 'Lead Learning Design',
    bio: 'Konzipiert Lernpfade zu async-first Zusammenarbeit, Führung und Resilienz.',
    image: 'https://picsum.photos/400/400?random=12',
  },
];

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Vexoralia – Über uns und unsere Vision</title>
        <meta
          name="description"
          content="Lerne das Team hinter Vexoralia kennen: unsere Geschichte, Mission und wie wir Remote-Arbeit in Deutschland gestalten."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Unsere Geschichte: Remote-Arbeit gestalten</h1>
            <p>
              Vexoralia entstand aus der Frage, wie Remote-Arbeit in Deutschland strukturiert, verlässlich und menschlich funktioniert. Wir kommen aus Produktentwicklung, Beratung, Community-Management und Didaktik. Gemeinsam bauen wir eine Plattform, die Talente, Teams und Tools zusammenbringt.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Von einer Idee zur Remote-Plattform</h2>
            <p>Schlüsselmomente auf unserem Weg.</p>
          </div>
          <div className={styles.timelineGrid}>
            <article>
              <span className={styles.year}>2019</span>
              <h3>Remote-Lab in Berlin</h3>
              <p>Wir starteten mit Workshops zu Homeoffice-Workflows, interviewten Unternehmen und Testnutzer:innen.</p>
            </article>
            <article>
              <span className={styles.year}>2020</span>
              <h3>Beta für Pilotunternehmen</h3>
              <p>Erste Teams nutzten Vexoralia zur Koordination von Remote-Projekten. Feedback floss direkt in neue Features ein.</p>
            </article>
            <article>
              <span className={styles.year}>2022</span>
              <h3>Community startet</h3>
              <p>Mentor:innen, Lernpfade und Coworking-Treffs brachten Remote-Professionals in Deutschland zusammen.</p>
            </article>
            <article>
              <span className={styles.year}>Heute</span>
              <h3>Skalierte Plattform</h3>
              <p>Vexoralia wächst zu einem Ökosystem mit Job-Matching, Tool-Integrationen und kuratierten Lernreisen.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionCard}>
            <h2>Unsere Mission</h2>
            <p>
              Remote-Arbeit soll ganzheitlich gedacht werden: Menschen, Prozesse und Technologie greifen ineinander. Vexoralia unterstützt Talente und Organisationen, indem wir transparente Daten, smarte Workflows und echte Begegnungen kombinieren. So entsteht ein Arbeitsalltag, der flexibel und gesund strukturiert bleibt.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Lerne unser Kernteam kennen</h2>
            <p>Interdisziplinär, remote-erfahren und nah an den Bedürfnissen unserer Community.</p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.imageWrap}>
                  <img src={`${member.image}`} alt={`${member.name}, ${member.role}`} loading="lazy" />
                </div>
                <div className={styles.info}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Werte, die uns leiten</h2>
            <p>Sie prägen Produktentscheidungen, Community-Programme und Partnerschaften.</p>
          </div>
          <div className={styles.valuesGrid}>
            <article>
              <h3>Transparenz</h3>
              <p>Wir schaffen klare Prozesse, kommunizieren offen und machen Entscheidungswege nachvollziehbar.</p>
            </article>
            <article>
              <h3>Verantwortung</h3>
              <p>Datenschutz, Barrierefreiheit und nachhaltige Workflows stehen im Zentrum unseres Handelns.</p>
            </article>
            <article>
              <h3>Verbundenheit</h3>
              <p>Remote heißt nicht alleine. Wir fördern Austausch, Feedback und gemeinsames Lernen.</p>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;