import React, { useEffect, useRef, useState, useMemo } from 'react';
import { NavLink } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Remote-Stellen', value: 4800, suffix: '+', id: 'jobs' },
  { label: 'Unternehmen', value: 320, suffix: '+', id: 'companies' },
  { label: 'Lernmodule', value: 96, suffix: '', id: 'modules' },
  { label: 'Community-Gruppen', value: 42, suffix: '', id: 'groups' },
];

const features = [
  {
    title: 'Job-Suche',
    description: 'Kuratiere Remote-Angebote nach Branche, Sprache und Teamkultur. Individuelle Filter sorgen für passgenaue Ergebnisse.',
    icon: '🔍',
  },
  {
    title: 'Tool-Kit',
    description: 'Zentrale Integrationen für Kommunikation, Dokumentation und Projektsteuerung in einer einheitlichen Oberfläche.',
    icon: '🧰',
  },
  {
    title: 'Lernpfade',
    description: 'Modulare Trainings für Selbstorganisation, virtuelle Führung und asynchrone Zusammenarbeit.',
    icon: '🎓',
  },
  {
    title: 'Community',
    description: 'Peer-Runden, Mentoring und lokale Coworking-Treffs stärken Austausch und Zugehörigkeit.',
    icon: '🤝',
  },
];

const processSteps = [
  { step: '1', title: 'Anmelden', text: 'Erstelle dein Profil mit Fokus auf Stärken, Arbeitsweise und Verfügbarkeit.' },
  { step: '2', title: 'Profil verfeinern', text: 'Synchronisiere Skills, Portfolio und persönliche Präferenzen für Remote-Teams.' },
  { step: '3', title: 'Jobs & Tools entdecken', text: 'Erhalte intelligente Empfehlungen zu Projekten, Rollen und passenden Workflows.' },
  { step: '4', title: 'Workflow starten', text: 'Koordiniere Bewerbungen, Onboarding und tägliche Zusammenarbeit in einem Flow.' },
];

const benefits = [
  {
    title: 'Transparente Matching-Intelligenz',
    text: 'Wir zeigen dir, warum ein Job zu deinen Prioritäten passt – inklusive Teamrituale, Zeitzonen und Tool-Setup.',
  },
  {
    title: 'Sichere Infrastruktur',
    text: 'DSGVO-konforme Datenräume, verschlüsselte Kommunikation und rollenbasierte Rechteverwaltung sorgen für Vertrauen.',
  },
  {
    title: 'Persönliche Betreuung',
    text: 'Unser Remote-Success-Team begleitet dich bei Fragen zu Verträgen, Tool-Einbindung und Community-Aktivitäten.',
  },
];

const testimonials = [
  {
    name: 'Lea Hoffmann',
    role: 'Product Ownerin, Hamburg',
    quote:
      'Vexoralia hat mir geholfen, ein Team zu finden, das asynchron arbeitet und trotzdem verbunden bleibt. Die Bewerbungsprozesse waren strukturiert und transparent.',
  },
  {
    name: 'Jonas Richter',
    role: 'Data Analyst, Berlin',
    quote:
      'Durch das Tool-Kit konnte ich meine täglichen Routinen vereinheitlichen. Besonders hilfreich sind die Fokus-Timer und die Insights aus der Community.',
  },
  {
    name: 'Aylin Demir',
    role: 'UX Researcherin, München',
    quote:
      'Die Lernpfade zu Remote-Leadership haben mich auf meine erste virtuelle Teamleitung vorbereitet. Praxisnah, greifbar und flexibel.',
  },
];

const projects = [
  {
    id: 1,
    category: 'Produktentwicklung',
    title: 'Remote Sprint Hub',
    description: 'Integrierter Sprint-Space für Produktteams mit User-Feedback Loop, Board-Templates und Sync-Meetings.',
    image: 'https://picsum.photos/1200/800?random=4',
  },
  {
    id: 2,
    category: 'Kundenservice',
    title: 'Customer Care Flow',
    description: 'Mehrsprachige Support-Streams, Wissensdatenbank und Qualitätsmetriken für distributed Teams.',
    image: 'https://picsum.photos/1200/800?random=5',
  },
  {
    id: 3,
    category: 'Beratung',
    title: 'Strategy Collaboration Canvas',
    description: 'Virtuelle Workshop-Boards, Moderationsleitfäden und On-Demand-Analysen für hybride Beratungsteams.',
    image: 'https://picsum.photos/1200/800?random=6',
  },
  {
    id: 4,
    category: 'Produktentwicklung',
    title: 'Design Ops Remote',
    description: 'Bibliotheken, Figma-Handovers und Multi-Zeitonen-Standups in einem Workflow.',
    image: 'https://picsum.photos/1200/800?random=7',
  },
];

const faqItems = [
  {
    question: 'Wie findet Vexoralia passende Remote-Jobs für mich?',
    answer:
      'Unsere Matching-Engine verbindet deine Skills, Soft-Facts und Verfügbarkeiten mit Stellenausschreibungen. Du bekommst Empfehlungen inklusive Teamkultur und Tool-Stack.',
  },
  {
    question: 'Welche Tools kann ich integrieren?',
    answer:
      'Du kannst Videokonferenz- und Projekttools wie Microsoft Teams, Slack, Notion, Jira oder Miro einbinden. Zusätzlich bieten wir native Fokus-Timer und einen Bewerbungs-Tracker.',
  },
  {
    question: 'Gibt es lokale Treffpunkte trotz Remote-Arbeit?',
    answer:
      'Ja. Über die Community organisieren wir Coworking-Days in deutschen Städten sowie virtuelle Networking-Formate, Mentoring und Austauschgruppen.',
  },
  {
    question: 'Wie unterstützt ihr beim Onboarding?',
    answer:
      'Mit unseren Workflow-Guides, Playbooks und Checklisten für Remote-Onboarding. Außerdem begleitet dich unser Support-Team Schritt für Schritt.',
  },
];

const blogPosts = [
  {
    title: 'Async First: Wie Teams ihre Meetings halbieren',
    excerpt: 'Erfahre, wie ein strukturierter Async-Flow die Zusammenarbeit entlastet und Entscheidungswege beschleunigt.',
    link: '/lernen',
    image: 'https://picsum.photos/800/600?random=2',
    date: '12. Februar 2024',
  },
  {
    title: 'Remote Leadership in wachsenden Teams',
    excerpt: 'Welche Rituale helfen Führungskräften, Klarheit und Vertrauen über Distanz aufzubauen? Ein Praxisleitfaden.',
    link: '/lernen',
    image: 'https://picsum.photos/800/600?random=8',
    date: '5. Februar 2024',
  },
  {
    title: 'Community Powered Hiring',
    excerpt: 'Wie Peer-Feedback und Mentoring bessere Matches zwischen Talenten und Unternehmen ermöglichen.',
    link: '/community',
    image: 'https://picsum.photos/800/600?random=9',
    date: '29. Januar 2024',
  },
];

const Home = () => {
  const statsRef = useRef(null);
  const [stats, setStats] = useState(statsData.map((item) => ({ ...item, current: 0 })));
  const [statsActive, setStatsActive] = useState(false);
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Alle');

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setStatsActive(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.4 }
    );
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => {
      if (statsRef.current) observer.unobserve(statsRef.current);
    };
  }, []);

  useEffect(() => {
    if (!statsActive) return;
    const duration = 1600;
    const start = performance.now();

    const animate = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      setStats(
        statsData.map((item) => ({
          ...item,
          current: Math.floor(item.value * progress),
        }))
      );
      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setStats(
          statsData.map((item) => ({
            ...item,
            current: item.value,
          }))
        );
      }
    };
    requestAnimationFrame(animate);
  }, [statsActive]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'Alle') return projects;
    return projects.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  const categories = ['Alle', ...new Set(projects.map((project) => project.category))];

  const structuredData = useMemo(
    () => ({
      '@context': 'https://schema.org',
      '@graph': [
        {
          '@type': 'Organization',
          name: 'Vexoralia',
          url: 'https://www.vexoralia.de',
          logo: 'https://www.vexoralia.de/logo.png',
          sameAs: [
            'https://www.linkedin.com',
            'https://www.twitter.com',
            'https://www.instagram.com'
          ],
          description:
            'Vexoralia ist die mobile und webbasierte Plattform für Remote-Arbeit in Deutschland mit Job-Matching, Tool-Kit, Lernpfaden und Community.',
        },
        {
          '@type': 'WebApplication',
          name: 'Vexoralia Remote Work Plattform',
          applicationCategory: 'BusinessApplication',
          operatingSystem: 'Web, iOS, Android',
          offers: {
            '@type': 'Offer',
            availability: 'https://schema.org/InStock'
          },
          url: 'https://www.vexoralia.de',
          featureList: [
            'Remote Job Matching',
            'Tool-Integrationen',
            'Bewerbungs-Tracker',
            'Fokus-Timer',
            'Community Events'
          ]
        }
      ]
    }),
    []
  );

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Vexoralia – Remote-Arbeit Plattform für Deutschlandweit</title>
        <meta
          name="description"
          content="Vexoralia vernetzt Fachkräfte und Unternehmen für flexible Arbeit aus Deutschland – mit Jobsuche, Tools, Lernpfaden und einer aktiven Community."
        />
        <meta
          name="keywords"
          content="remote jobs, arbeiten von überall, digitale nomaden, homeoffice, flexible arbeit"
        />
        <script type="application/ld+json">{JSON.stringify(structuredData)}</script>
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div className={styles.heroContent}>
              <span className={styles.heroBadge}>Mobile & Web-App Plattform</span>
              <h1>Arbeite von überall – gestalte deinen Arbeitsalltag flexibel</h1>
              <p>
                Vexoralia verbindet Remote-Profis und Unternehmen aus Deutschland. Entdecke kuratierte Jobs, automatisiere Workflows und trete einer Community bei, die Zusammenarbeit über Distanzen wirklich versteht.
              </p>
              <div className={styles.ctaGroup}>
                <NavLink to="/pläne" className={styles.ctaPrimary}>
                  Jetzt starten
                </NavLink>
                <NavLink to="/jobs" className={styles.ctaSecondary}>
                  Remote-Jobs entdecken
                </NavLink>
              </div>
              <div className={styles.heroMeta}>
                <div>
                  <strong>Flexibel</strong>
                  <span>Mobile, Web, Desktop</span>
                </div>
                <div>
                  <strong>Vertrauenswürdig</strong>
                  <span>DSGVO-konform</span>
                </div>
                <div>
                  <strong>Community</strong>
                  <span>Mentor:innen & Events</span>
                </div>
              </div>
            </div>
            <div className={styles.heroImageWrapper}>
              <img
                src="https://picsum.photos/1600/900?random=1"
                alt="Remote-Team arbeitet aus Café, Zug und Coworking-Space"
                className={styles.heroImage}
                loading="lazy"
              />
              <div className={styles.heroOverlayCard}>
                <h3>Remote ready</h3>
                <p>Daily Stand-up in 3 Zeitzonen, synchronisiert mit Fokus-Timer und Projektboards.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats} ref={statsRef} aria-label="Kennzahlen">
        <div className="container">
          <div className={styles.statsGrid}>
            {stats.map((stat) => (
              <div key={stat.id} className={styles.statCard}>
                <span className={styles.statValue}>
                  {stat.current}
                  {stat.suffix}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.intro}>
        <div className="container">
          <div className={styles.introGrid}>
            <div>
              <h2>Wer wir sind</h2>
              <p>
                Wir sind ein interdisziplinäres Team aus Deutschland, das Remote-Arbeit alltagstauglich macht. Mit Vexoralia orchestrierst du Jobsuche, Bewerbung, Tool-Stack und Lernpfade in einem System. Unsere Mission: flexible Arbeit fühlbar einfach gestalten – egal ob du vom Küchentisch, aus dem Zug oder im Coworking bist.
              </p>
            </div>
            <div className={styles.introHighlights}>
              <div>
                <strong>Guided Workflows</strong>
                <p>Von der Stellensuche bis zum täglichen Stand-up – Vexoralia begleitet dich mit klaren Empfehlungen.</p>
              </div>
              <div>
                <strong>Vernetztes Lernen</strong>
                <p>Zertifizierte Coaches, Micro-Learnings und Peer-Gruppen fördern nachhaltige Entwicklung.</p>
              </div>
              <div>
                <strong>Gestärkte Teams</strong>
                <p>Wir bringen Talente und Organisationen zusammen, die Remote-Kultur ernst nehmen.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.features}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Funktionen, die deinen Remote-Alltag führen</h2>
            <p>Von der ersten Suche bis zur täglichen Kollaboration – maßgeschneidert für verteilte Teams in Deutschland.</p>
          </div>
          <div className={styles.featuresGrid}>
            {features.map((feature) => (
              <article key={feature.title} className={styles.featureCard}>
                <span className={styles.featureIcon} aria-hidden="true">
                  {feature.icon}
                </span>
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
                <NavLink to="/funktionen" className={styles.featureLink} aria-label={`${feature.title} im Detail ansehen`}>
                  Mehr erfahren →
                </NavLink>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process} aria-label="Ablauf">
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>So funktioniert Vexoralia</h2>
            <p>Ein klarer Ablauf, damit deine Remote-Reise reibungslos verläuft.</p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <div key={step.step} className={styles.processCard}>
                <span className={styles.processStep}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.why}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Warum Vexoralia?</h2>
            <p>Remote-Arbeit ist mehr als Videocalls. Wir verbinden Menschen, Prozesse und Werkzeuge nahtlos.</p>
          </div>
          <div className={styles.whyGrid}>
            {benefits.map((benefit) => (
              <article key={benefit.title} className={styles.whyCard}>
                <h3>{benefit.title}</h3>
                <p>{benefit.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Erfahrungsberichte">
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Erfolgsgeschichten unserer Community</h2>
            <p>Menschen, die ihren Remote-Alltag mit Vexoralia organisiert haben.</p>
          </div>
          <div className={styles.testimonialCarousel}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${index === testimonialIndex ? styles.visible : styles.hidden}`}
                aria-hidden={index !== testimonialIndex}
              >
                <p className={styles.quote}>“{testimonial.quote}”</p>
                <div className={styles.person}>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </div>
              </article>
            ))}
            <div className={styles.carouselDots} role="tablist" aria-label="Testimonials">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  className={`${styles.dot} ${index === testimonialIndex ? styles.dotActive : ''}`}
                  onClick={() => setTestimonialIndex(index)}
                  aria-label={`Testimonial ${index + 1} anzeigen`}
                  aria-selected={index === testimonialIndex}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Remote Workflows in Aktion</h2>
            <p>Gefilterte Beispiele zeigen, wie Teams ihre Prozesse mit Vexoralia strukturieren.</p>
          </div>
          <div className={styles.filters} role="tablist" aria-label="Projektkategorien">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${activeCategory === category ? styles.filterActive : ''}`}
                onClick={() => setActiveCategory(category)}
                aria-pressed={activeCategory === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img
                    src={`${project.image}&id=${project.id}`}
                    alt={`Projektbeispiel ${project.title}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq} id="faq" aria-labelledby="faq-title">
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 id="faq-title">FAQ: Häufige Fragen</h2>
            <p>Alles, was du vor dem Start wissen möchtest.</p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>
                  <span>{item.question}</span>
                  <span aria-hidden="true">+</span>
                </summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Insights & Remote-Impulse</h2>
            <p>Aktuelle Artikel, Checklisten und Praxisberichte aus der Vexoralia-Community.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImageWrapper}>
                  <img src={`${post.image}`} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <NavLink to={post.link} className={styles.blogLink}>
                    Mehr erfahren →
                  </NavLink>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Bereit für fokussierte Remote-Arbeit?</h2>
              <p>Starte mit Vexoralia, plane deinen nächsten Job und bring dein Team in einen gleichmäßigen Rhythmus.</p>
            </div>
            <div className={styles.ctaButtons}>
              <NavLink to="/pläne" className={styles.ctaPrimary}>
                Jetzt starten
              </NavLink>
              <NavLink to="/kontakt" className={styles.ctaSecondary}>
                Gespräch vereinbaren
              </NavLink>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;