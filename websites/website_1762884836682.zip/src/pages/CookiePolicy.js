import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Vexoralia – Cookie-Richtlinie</title>
        <meta
          name="description"
          content="Informationen zur Verwendung von Cookies und Tracking-Technologien auf der Vexoralia Plattform."
        />
      </Helmet>

      <div className="container">
        <h1>Cookie-Richtlinie</h1>
        <p>Stand: Februar 2024</p>

        <section>
          <h2>1. Allgemeines</h2>
          <p>
            Cookies sind kleine Textdateien, die auf deinem Endgerät gespeichert werden. Sie helfen uns, unsere Plattform nutzerfreundlich, sicher und performant zu gestalten.
          </p>
        </section>

        <section>
          <h2>2. Arten von Cookies</h2>
          <p>
            <strong>Notwendig:</strong> Diese Cookies stellen grundlegende Funktionen wie Login, Session-Management oder Sicherheit bereit.<br />
            <strong>Analyse:</strong> Wir nutzen anonymisierte Tracking-Daten, um die Nutzung der Plattform auszuwerten und Funktionen zu verbessern.<br />
            <strong>Komfort:</strong> Diese Cookies merken sich Einstellungen wie Sprachpräferenzen oder Layouts.
          </p>
        </section>

        <section>
          <h2>3. Verwaltung</h2>
          <p>
            Beim ersten Besuch kannst du wählen, welche Cookies gesetzt werden dürfen. Diese Entscheidung kannst du jederzeit in den Einstellungen deines Browsers oder über den Cookie-Hinweis am Seitenende ändern.
          </p>
        </section>

        <section>
          <h2>4. Speicherfristen</h2>
          <p>
            Die Speicherdauer variiert je nach Cookie. Einige werden nach der Sitzung gelöscht, andere bleiben bis zu zwei Jahren erhalten, sofern sie nicht vorher entfernt werden.
          </p>
        </section>
      </div>
    </div>
  );
};

export default CookiePolicy;