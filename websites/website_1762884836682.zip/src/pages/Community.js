import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Community.module.css';

const events = [
  {
    title: 'Remote Leaders Circle',
    date: 'März 2024',
    format: 'Virtuelles Roundtable',
    description: 'Führungskräfte teilen Strategien zu async Kommunikation, Alignment und Feedback.',
  },
  {
    title: 'Coworking Day München',
    date: 'April 2024',
    format: 'Vor Ort',
    description: 'Tages-Coworking mit Lightning Talks, Mentoring-Slots und Networking.',
  },
  {
    title: 'Mentoring Sprint',
    date: 'Mai 2024',
    format: 'Digital',
    description: 'Vier Wochen Peer-Mentoring mit Fokus auf Remote Onboarding und Team Health.',
  },
];

const groups = [
  'Product & Design Circle',
  'Hybrid HR Network',
  'Remote Developers Stammtisch',
  'Async Ops Lounge',
  'New Work Scouts',
  'Women in Remote Leadership',
];

const Community = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Vexoralia – Community & Mentoring</title>
        <meta
          name="description"
          content="Vernetze dich mit Remote-Profis: Events, Foren, Mentoring und Coworking-Angebote der Vexoralia Community."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Remote Community, die verbindet</h1>
          <p>
            Vexoralia fördert Austausch in digitalen Foren, Mentoring-Programmen und lokalen Coworking-Days. So bleiben Remote-Profis nah am Puls.
          </p>
        </div>
      </section>

      <section className={styles.events}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Bevorstehende Highlights</h2>
            <p>Formate für Austausch, Lernen und Zusammenarbeit.</p>
          </div>
          <div className={styles.eventGrid}>
            {events.map((event) => (
              <article key={event.title} className={styles.eventCard}>
                <div className={styles.eventMeta}>
                  <span>{event.date}</span>
                  <span>{event.format}</span>
                </div>
                <h3>{event.title}</h3>
                <p>{event.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.groups}>
        <div className="container">
          <div className={styles.groupCard}>
            <h2>Community-Foren & Special-Interest-Gruppen</h2>
            <div className={styles.groupList}>
              {groups.map((group) => (
                <span key={group}>{group}</span>
              ))}
            </div>
            <p>
              Jede Gruppe bietet regelmäßige Sessions, Ressourcen und Slack-Channels. Mentoring-Matches und Peer-Bewertungen werden direkt über Vexoralia organisiert.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Community;