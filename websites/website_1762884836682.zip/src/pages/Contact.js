import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
    consent: false,
  });
  const [status, setStatus] = useState(null);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setForm((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!form.name || !form.email || !form.message || !form.consent) {
      setStatus({ type: 'error', message: 'Bitte fülle alle Pflichtfelder aus und bestätige den Datenschutz.' });
      return;
    }
    setStatus({ type: 'success', message: 'Danke für deine Nachricht! Wir melden uns zeitnah bei dir.' });
    setForm({ name: '', email: '', company: '', message: '', consent: false });
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Vexoralia – Kontakt</title>
        <meta
          name="description"
          content="Kontaktiere das Team von Vexoralia für Fragen zu Remote-Jobs, Funktionen, Community oder Partnerschaften."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Wir freuen uns auf deine Nachricht</h1>
          <p>
            Ob Fragen zu Remote-Jobs, Lernpfaden, Community oder Integrationen – unser Team unterstützt dich gerne. Fülle das Formular aus, wir antworten innerhalb von 24 Stunden.
          </p>
        </div>
      </section>

      <section className={styles.formSection}>
        <div className="container">
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.row}>
              <label>
                <span>Vor- und Nachname *</span>
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  required
                  aria-required="true"
                />
              </label>
              <label>
                <span>E-Mail *</span>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  required
                  aria-required="true"
                />
              </label>
            </div>
            <label>
              <span>Unternehmen / Team</span>
              <input type="text" name="company" value={form.company} onChange={handleChange} />
            </label>
            <label>
              <span>Wie können wir helfen? *</span>
              <textarea
                name="message"
                value={form.message}
                onChange={handleChange}
                rows="5"
                required
                aria-required="true"
              />
            </label>
            <label className={styles.checkbox}>
              <input
                type="checkbox"
                name="consent"
                checked={form.consent}
                onChange={handleChange}
                required
                aria-required="true"
              />
              <span>
                Ich stimme zu, dass meine Angaben zur Bearbeitung meiner Anfrage gespeichert werden. Mehr Infos in unserer Datenschutzerklärung.
              </span>
            </label>
            <button type="submit" className={styles.submit}>
              Nachricht senden
            </button>
            {status && (
              <div
                className={`${styles.status} ${
                  status.type === 'success' ? styles.success : styles.error
                }`}
                role="alert"
              >
                {status.message}
              </div>
            )}
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;