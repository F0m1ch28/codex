import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Plans.module.css';

const plans = [
  {
    name: 'Starter Plan',
    tone: 'Für Einzelpersonen',
    highlights: ['Job-Matching', 'Fokus-Timer', 'Community-Zugang', 'Basis-Integrationen'],
    cta: 'App ausprobieren',
  },
  {
    name: 'Team Plan',
    tone: 'Für Teams bis 25 Personen',
    highlights: ['Gemeinsame Workflows', 'Team Analytics', 'Coachings', 'Erweiterte Integrationen'],
    cta: 'Jetzt starten',
  },
  {
    name: 'Enterprise Plan',
    tone: 'Für wachsende Organisationen',
    highlights: ['Skalierbare Rechteverwaltung', 'Dedizierte Beratung', 'API-Zugriff', 'Onboarding-Playbooks'],
    cta: 'Beratung anfragen',
  },
];

const Plans = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Vexoralia – Pläne für Remote-Teams</title>
        <meta
          name="description"
          content="Wähle den passenden Vexoralia Plan: Starter, Team oder Enterprise – mit Fokus auf Remote-Workflows, Integrationen und Betreuung."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Pläne, die zu deinem Remote-Team passen</h1>
          <p>
            Wähle den Modus, der deine Arbeitsweise unterstützt. Alle Pläne enthalten DSGVO-konforme Infrastruktur, Support und Zugang zur Community.
          </p>
        </div>
      </section>

      <section className={styles.plans}>
        <div className="container">
          <div className={styles.grid}>
            {plans.map((plan) => (
              <article key={plan.name} className={styles.card}>
                <h2>{plan.name}</h2>
                <span className={styles.tone}>{plan.tone}</span>
                <ul>
                  {plan.highlights.map((highlight) => (
                    <li key={highlight}>{highlight}</li>
                  ))}
                </ul>
                <button type="button" className={styles.cta}>
                  {plan.cta}
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Plans;