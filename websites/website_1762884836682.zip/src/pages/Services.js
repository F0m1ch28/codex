import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Job-Matching Engine',
    description: 'Mehrschichtige Filter, Matching-Gründe und Insider-Infos zu Teamkultur machen die Stellensuche transparent.',
    details: ['Skill-Map Analyse', 'Zeitzonen-Abgleich', 'Teamrituale als Kriterien'],
  },
  {
    title: 'Bewerbungs-Tracker',
    description: 'Organisiere Bewerbungen, Feedback, Follow-ups und nächste Schritte in einem strukturierten Pipeline-Board.',
    details: ['Automatische Erinnerungen', 'Dokumentenablage', 'Status-Sharing mit Mentor:innen'],
  },
  {
    title: 'Tool-Integrationen',
    description: 'Verbinde Kollaborationstools wie Slack, Teams, Notion, Jira und sichere Dokumentensysteme.',
    details: ['Single Sign-On', 'Rollenbasierte Rechte', 'Automatisierte Updates'],
  },
  {
    title: 'Fokus-Timer & Analytics',
    description: 'Plane Deep-Work-Phasen, reflektiere Energielevel und untersütze dein Team bei nachhaltigen Rhythmen.',
    details: ['Sync mit Kalendern', 'Team-Heatmaps', 'Weekly Retro-Vorlagen'],
  },
  {
    title: 'Wissenshub & Lernpfade',
    description: 'Micro-Learnings, Coachings und Templates für Remote Leadership, Async-Kultur und Resilienz.',
    details: ['Zertifizierte Coaches', 'Lernnudges', 'Peer-Gruppen'],
  },
];

const Services = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Vexoralia – Funktionen für deinen Remote-Workflow</title>
        <meta
          name="description"
          content="Entdecke die Funktionen von Vexoralia: Job-Matching, Bewerbungs-Tracker, Tool-Integrationen, Fokus-Timer und Wissenshub."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Alle Tools für Remote-Arbeit in einer Plattform</h1>
          <p>
            Vexoralia kombiniert kuratierte Jobs, Workflow-Automation und Lernpfade. Jede Funktion ist darauf ausgelegt, distributed Teams in Deutschland effizient zu unterstützen.
          </p>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.grid}>
            {services.map((service) => (
              <article key={service.title} className={styles.card}>
                <h2>{service.title}</h2>
                <p>{service.description}</p>
                <ul>
                  {service.details.map((detail) => (
                    <li key={detail}>{detail}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.integration}>
        <div className="container">
          <div className={styles.integrationCard}>
            <h2>Integrationen & Sicherheit</h2>
            <p>
              Mit offenen APIs und konfigurierbaren Rechten bringst du bestehende Tools zusammen. Datenflüsse sind verschlüsselt, rollenbasiert und DSGVO-konform, damit Teams sicher arbeiten.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;