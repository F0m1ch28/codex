import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Learn.module.css';

const tracks = [
  {
    title: 'Async Collaboration Mastery',
    duration: '6 Wochen',
    focus: 'Kommunikation & Prozesse',
    modules: ['Async Guidelines', 'Meeting Redesign', 'Feedback Rituale', 'Dokumentation'],
  },
  {
    title: 'Remote Leadership Essentials',
    duration: '8 Wochen',
    focus: 'Führung & Kultur',
    modules: ['Team Trust Map', 'Hybrid Entscheidungen', 'Coaching Tools', 'Resilienz'],
  },
  {
    title: 'Productivity & Energy Design',
    duration: '4 Wochen',
    focus: 'Selbstmanagement',
    modules: ['Fokus-Strategien', 'Energie-Check-Ins', 'Grenzen setzen', 'Reflexion'],
  },
];

const microCourses = [
  'Virtuelle Workshops moderieren',
  'Remote Hiring Journey aufsetzen',
  'Inklusion in verteilten Teams fördern',
  'Storytelling für async Updates',
  'Workflows auditieren und verbessern',
  'Remote Onboarding Toolkit',
];

const Learn = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Vexoralia – Lernpfade für Remote-Arbeit</title>
        <meta
          name="description"
          content="Stärke deine Remote-Skills mit Lernpfaden, Micro-Kursen und Mentoring-Angeboten – speziell für Teams in Deutschland."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Lerne, führe und wachse remote</h1>
          <p>
            Unsere Lernpfade verbinden Micro-Learnings, Live-Sessions und Peer-Coaching. Entwickle deine Remote-Skills strukturiert und in deinem Tempo.
          </p>
        </div>
      </section>

      <section className={styles.tracks}>
        <div className="container">
          <div className={styles.trackGrid}>
            {tracks.map((track) => (
              <article key={track.title} className={styles.trackCard}>
                <h2>{track.title}</h2>
                <div className={styles.trackMeta}>
                  <span>{track.duration}</span>
                  <span>{track.focus}</span>
                </div>
                <ul>
                  {track.modules.map((module) => (
                    <li key={module}>{module}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.microSection}>
        <div className="container">
          <div className={styles.microCard}>
            <h2>Micro-Kurse & Live Sessions</h2>
            <p>Kompakte Formate, die dich und dein Team schnell weiterbringen.</p>
            <div className={styles.microList}>
              {microCourses.map((course) => (
                <span key={course}>{course}</span>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Learn;