import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Jobs from './pages/Jobs';
import Services from './pages/Services';
import Learn from './pages/Learn';
import Community from './pages/Community';
import Plans from './pages/Plans';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import styles from './App.module.css';

const App = () => {
  return (
    <div className={styles.app}>
      <Header />
      <main className={styles.content}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/über-uns" element={<About />} />
          <Route path="/jobs" element={<Jobs />} />
          <Route path="/funktionen" element={<Services />} />
          <Route path="/lernen" element={<Learn />} />
          <Route path="/community" element={<Community />} />
          <Route path="/pläne" element={<Plans />} />
          <Route path="/kontakt" element={<Contact />} />
          <Route path="/nutzungsbedingungen" element={<Terms />} />
          <Route path="/datenschutz" element={<Privacy />} />
          <Route path="/cookie-richtlinie" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
};

export default App;