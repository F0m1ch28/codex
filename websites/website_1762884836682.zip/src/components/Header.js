import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 8);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const toggleMenu = () => {
    setOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setOpen(false);
  };

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} aria-label="Hauptnavigation">
      <div className="container">
        <div className={styles.inner}>
          <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Vexoralia Startseite">
            <span className={styles.logoMark}>V</span>
            <span className={styles.logoText}>Vexoralia</span>
          </NavLink>
          <nav className={`${styles.nav} ${open ? styles.open : ''}`} aria-label="Hauptmenü">
            <NavLink
              to="/"
              className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              onClick={closeMenu}
            >
              Start
            </NavLink>
            <NavLink
              to="/über-uns"
              className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              onClick={closeMenu}
            >
              Über uns
            </NavLink>
            <NavLink
              to="/jobs"
              className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              onClick={closeMenu}
            >
              Jobs
            </NavLink>
            <NavLink
              to="/funktionen"
              className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              onClick={closeMenu}
            >
              Funktionen
            </NavLink>
            <NavLink
              to="/lernen"
              className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              onClick={closeMenu}
            >
              Lernen
            </NavLink>
            <NavLink
              to="/community"
              className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              onClick={closeMenu}
            >
              Community
            </NavLink>
            <NavLink
              to="/pläne"
              className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              onClick={closeMenu}
            >
              Pläne
            </NavLink>
            <NavLink
              to="/kontakt"
              className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              onClick={closeMenu}
            >
              Kontakt
            </NavLink>
            <div className={styles.navCta}>
              <NavLink to="/pläne" className={styles.ctaPrimary} onClick={closeMenu}>
                App ausprobieren
              </NavLink>
            </div>
          </nav>
          <button
            className={`${styles.burger} ${open ? styles.burgerOpen : ''}`}
            aria-expanded={open}
            aria-label="Menü umschalten"
            onClick={toggleMenu}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;