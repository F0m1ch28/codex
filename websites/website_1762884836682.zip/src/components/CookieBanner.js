import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem('vexoralia-cookie-consent');
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleChoice = (choice) => {
    window.localStorage.setItem('vexoralia-cookie-consent', choice);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie Hinweis">
      <div className={styles.content}>
        <h2>Cookies & Tracking</h2>
        <p>
          Wir verwenden funktionale Cookies, um deine Nutzererfahrung zu verbessern, anonyme Analysen zu ermöglichen und unsere Remote-Plattform weiterzuentwickeln. Du kannst deine Auswahl jederzeit anpassen.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.secondary} onClick={() => handleChoice('declined')}>
          Ablehnen
        </button>
        <button type="button" className={styles.primary} onClick={() => handleChoice('accepted')}>
          Akzeptieren
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;