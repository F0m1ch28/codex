import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer} aria-label="Fußbereich">
      <div className="container">
        <div className={styles.layout}>
          <div className={styles.brand}>
            <div className={styles.logoBlock}>
              <span className={styles.logoMark}>V</span>
              <span className={styles.logoText}>Vexoralia</span>
            </div>
            <p>
              Vexoralia verbindet Remote-Talente und Unternehmen in Deutschland. Wir schaffen transparente Workflows, verlässliche Tools und eine inspirierende Community für modernes Arbeiten von überall.
            </p>
            <div className={styles.socials} aria-label="Soziale Netzwerke">
              <a href="https://www.linkedin.com" aria-label="LinkedIn" target="_blank" rel="noopener noreferrer">
                <span aria-hidden="true">in</span>
              </a>
              <a href="https://www.twitter.com" aria-label="Twitter" target="_blank" rel="noopener noreferrer">
                <span aria-hidden="true">tw</span>
              </a>
              <a href="https://www.instagram.com" aria-label="Instagram" target="_blank" rel="noopener noreferrer">
                <span aria-hidden="true">ig</span>
              </a>
            </div>
          </div>
          <div className={styles.columns}>
            <div>
              <h3>Produkt</h3>
              <ul>
                <li>
                  <NavLink to="/funktionen">Funktionen</NavLink>
                </li>
                <li>
                  <NavLink to="/pläne">Pläne</NavLink>
                </li>
                <li>
                  <NavLink to="/jobs">Jobs</NavLink>
                </li>
                <li>
                  <NavLink to="/lernen">Lernen</NavLink>
                </li>
              </ul>
            </div>
            <div>
              <h3>Ressourcen</h3>
              <ul>
                <li>
                  <NavLink to="/community">Community</NavLink>
                </li>
                <li>
                  <NavLink to="/über-uns">Über uns</NavLink>
                </li>
                <li>
                  <a href="#faq">FAQ</a>
                </li>
                <li>
                  <NavLink to="/kontakt">Kontakt</NavLink>
                </li>
              </ul>
            </div>
            <div>
              <h3>Rechtliches</h3>
              <ul>
                <li>
                  <NavLink to="/nutzungsbedingungen">Nutzungsbedingungen</NavLink>
                </li>
                <li>
                  <NavLink to="/datenschutz">Datenschutz</NavLink>
                </li>
                <li>
                  <NavLink to="/cookie-richtlinie">Cookie-Richtlinie</NavLink>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>© {currentYear} Vexoralia. Alle Rechte vorbehalten.</p>
          <div className={styles.bottomLinks}>
            <NavLink to="/datenschutz">Datenschutz</NavLink>
            <NavLink to="/nutzungsbedingungen">Nutzungsbedingungen</NavLink>
            <NavLink to="/cookie-richtlinie">Cookies</NavLink>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;