// @ts-check
import React, { Suspense, lazy } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTopButton from "./components/ScrollToTopButton";
import RouteScrollToTop from "./components/RouteScrollToTop";

const Home = lazy(() => import("./pages/Home"));
const About = lazy(() => import("./pages/About"));
const Services = lazy(() => import("./pages/Services"));
const Contact = lazy(() => import("./pages/Contact"));
const ContactThanks = lazy(() => import("./pages/ContactThanks"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Terms = lazy(() => import("./pages/Terms"));
const Blog = lazy(() => import("./pages/Blog"));
const BlogPostContextSwitching = lazy(() => import("./pages/BlogPostContextSwitching"));
const BlogPostCloudPatterns = lazy(() => import("./pages/BlogPostCloudPatterns"));
const BlogPostDevopsCulture = lazy(() => import("./pages/BlogPostDevopsCulture"));
const Workflows = lazy(() => import("./pages/Workflows"));
const Mindset = lazy(() => import("./pages/Mindset"));
const Queue = lazy(() => import("./pages/Queue"));
const Archives = lazy(() => import("./pages/Archives"));
const Notes = lazy(() => import("./pages/Notes"));

const App = () => {
  return (
    <>
      <Helmet>
        <html lang="en" />
        <title>DevLayer | Developer-Focused Editorial Platform</title>
        <meta
          name="description"
          content="DevLayer is a developer-focused editorial platform from Toronto exploring software systems, developer workflows, cloud infrastructure, and engineering culture."
        />
        <link rel="canonical" href="https://www.devlayer.com/" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Organization",
            name: "DevLayer",
            url: "https://www.devlayer.com",
            logo: "https://picsum.photos/400/400?random=8",
            contactPoint: [
              {
                "@type": "ContactPoint",
                telephone: "+1-416-905-6621",
                contactType: "Customer Support",
                areaServed: "CA",
                availableLanguage: ["English"]
              }
            ],
            address: {
              "@type": "PostalAddress",
              streetAddress: "333 Bay St",
              addressLocality: "Toronto",
              addressRegion: "ON",
              postalCode: "M5H 2R2",
              addressCountry: "CA"
            },
            sameAs: [
              "https://github.com/devlayer",
              "https://www.linkedin.com/company/devlayer"
            ]
          })}
        </script>
      </Helmet>
      <Router>
        <RouteScrollToTop />
        <div className="flex min-h-screen flex-col bg-brand-navy text-brand-ivory">
          <Header />
          <Suspense
            fallback={
              <div className="flex flex-1 items-center justify-center bg-brand-deep text-brand-ivory">
                <p className="font-sans text-lg tracking-wide">Loading editorial layers…</p>
              </div>
            }
          >
            <main className="flex-1">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/about" element={<About />} />
                <Route path="/services" element={<Services />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/contact/thanks" element={<ContactThanks />} />
                <Route path="/privacy" element={<Privacy />} />
                <Route path="/terms" element={<Terms />} />
                <Route path="/blog" element={<Blog />} />
                <Route path="/blog/why-context-switching-kills-productivity" element={<BlogPostContextSwitching />} />
                <Route path="/blog/cloud-patterns-for-scale" element={<BlogPostCloudPatterns />} />
                <Route path="/blog/the-evolution-of-devops-culture" element={<BlogPostDevopsCulture />} />
                <Route path="/workflows" element={<Workflows />} />
                <Route path="/mindset" element={<Mindset />} />
                <Route path="/queue" element={<Queue />} />
                <Route path="/archives" element={<Archives />} />
                <Route path="/notes" element={<Notes />} />
              </Routes>
            </main>
          </Suspense>
          <Footer />
        </div>
        <ScrollToTopButton />
        <CookieBanner />
      </Router>
    </>
  );
};

export default App;