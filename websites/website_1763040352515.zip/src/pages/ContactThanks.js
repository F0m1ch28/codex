// @ts-check
import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const ContactThanks = () => {
  return (
    <>
      <Helmet>
        <title>Thank You | DevLayer</title>
        <meta name="robots" content="noindex" />
      </Helmet>
      <section className="mx-auto mt-24 flex max-w-4xl flex-col items-center rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 px-6 py-16 text-center lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
        >
          <h1 className="font-display text-4xl text-white">Thank you for reaching out</h1>
          <p className="mt-4 text-lg leading-relaxed text-brand-ivory/80">
            Your message is in our queue. One of the DevLayer editors will respond shortly with next steps.
          </p>
          <Link
            to="/"
            className="mt-8 inline-flex items-center justify-center rounded-full bg-brand-coral px-6 py-3 font-semibold text-white transition hover:bg-brand-coral/80"
          >
            Return to home
          </Link>
        </motion.div>
      </section>
    </>
  );
};

export default ContactThanks;