// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const notes = [
  {
    title: "Platform Field Study #6",
    date: "March 12, 2024",
    content:
      "Wrapped a field study with a Montreal-based gaming studio experimenting with progressive delivery. Full essay coming soon; highlights include their compass for evaluating feature flips and player trust."
  },
  {
    title: "Newsletter Revamp",
    date: "February 20, 2024",
    content:
      "The Layered Dispatch now includes a systems diagram in every issue. We heard your feedback on wanting more visual anchors."
  },
  {
    title: "Infrastructure Roundtable",
    date: "January 28, 2024",
    content:
      "Hosted a closed-door roundtable with platform engineers discussing multi-region readiness. Findings will inform an upcoming playbook."
  }
];

const Notes = () => {
  return (
    <>
      <Helmet>
        <title>DevLayer Notes | Editorial Updates</title>
        <meta
          name="description"
          content="Short editorial updates, platform announcements, and behind-the-scenes notes from DevLayer."
        />
      </Helmet>
      <section className="mx-auto mt-16 max-w-4xl px-4 lg:px-0">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-8 shadow-ambient"
        >
          <h1 className="font-display text-4xl text-white">Notes from the Editorial Desk</h1>
          <p className="mt-4 text-lg leading-relaxed text-brand-ivory/80">
            Behind-the-scenes snapshots from DevLayer. These notes keep our community informed between major releases.
          </p>
        </motion.div>

        <div className="mt-10 space-y-6">
          {notes.map((note) => (
            <motion.article
              key={note.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-6"
            >
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <h2 className="font-display text-2xl text-white">{note.title}</h2>
                <p className="text-xs uppercase tracking-[0.2em] text-brand-ivory/60">{note.date}</p>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-brand-ivory/80">{note.content}</p>
            </motion.article>
          ))}
        </div>

        <motion.p
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-10 mb-20 text-sm text-brand-ivory/60"
        >
          Want updates in your inbox? Subscribe to the Layered Dispatch from our home page.
        </motion.p>
      </section>
    </>
  );
};

export default Notes;