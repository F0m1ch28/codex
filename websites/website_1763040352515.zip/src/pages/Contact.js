// @ts-check
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const Contact = () => {
  const navigate = useNavigate();
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    company: "",
    topic: "",
    message: ""
  });
  const [errors, setErrors] = useState({});

  const validate = () => {
    const nextErrors = {};
    if (!formState.name.trim()) nextErrors.name = "Please share your name.";
    if (!formState.email.match(/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/)) nextErrors.email = "Enter a valid email.";
    if (!formState.message.trim()) nextErrors.message = "Tell us how we can help.";
    return nextErrors;
  };

  const handleChange = (event) => {
    setFormState((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});
    // Simulate submission and redirect
    navigate("/contact/thanks");
  };

  return (
    <>
      <Helmet>
        <title>Contact DevLayer | Toronto Editorial Platform for Developers</title>
        <meta
          name="description"
          content="Reach DevLayer in Toronto for editorial collaborations, partnerships, and research inquiries. Connect by form, email, or phone."
        />
      </Helmet>
      <section className="mx-auto mt-16 max-w-6xl px-4 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-8 shadow-ambient sm:p-12"
        >
          <div className="grid gap-10 lg:grid-cols-[1.1fr,0.9fr]">
            <div>
              <h1 className="font-display text-4xl text-white">Connect with DevLayer</h1>
              <p className="mt-4 text-lg leading-relaxed text-brand-ivory/80">
                We love hearing from developers, platform teams, and research partners. Share your story, collaboration idea,
                or request for coverage and we will respond within two business days.
              </p>
              <div className="mt-6 space-y-3 text-sm text-brand-ivory/70">
                <p><strong>Email:</strong> info@devlayer.com</p>
                <p><strong>Phone:</strong> +1 (416) 905-6621</p>
                <p><strong>Address:</strong> 333 Bay St, Toronto, ON M5H 2R2, Canada</p>
                <div className="flex gap-4">
                  <a
                    href="https://github.com/devlayer"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-brand-coral hover:underline"
                  >
                    GitHub
                  </a>
                  <a
                    href="https://www.linkedin.com/company/devlayer"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-brand-coral hover:underline"
                  >
                    LinkedIn
                  </a>
                </div>
              </div>
            </div>
            <form
              className="rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-6"
              onSubmit={handleSubmit}
              noValidate
            >
              <div className="space-y-5">
                <div>
                  <label htmlFor="name" className="block text-xs uppercase tracking-[0.2em] text-brand-ivory/60">
                    Name
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formState.name}
                    onChange={handleChange}
                    className="mt-2 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-3 text-sm text-white placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-brand-coral/80"
                    placeholder="Your full name"
                    required
                  />
                  {errors.name && <p className="mt-2 text-xs text-brand-coral">{errors.name}</p>}
                </div>
                <div>
                  <label htmlFor="email" className="block text-xs uppercase tracking-[0.2em] text-brand-ivory/60">
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formState.email}
                    onChange={handleChange}
                    className="mt-2 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-3 text-sm text-white placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-brand-coral/80"
                    placeholder="team@company.com"
                    required
                  />
                  {errors.email && <p className="mt-2 text-xs text-brand-coral">{errors.email}</p>}
                </div>
                <div>
                  <label htmlFor="company" className="block text-xs uppercase tracking-[0.2em] text-brand-ivory/60">
                    Organization
                  </label>
                  <input
                    id="company"
                    name="company"
                    type="text"
                    value={formState.company}
                    onChange={handleChange}
                    className="mt-2 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-3 text-sm text-white placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-brand-coral/80"
                    placeholder="Organization or team"
                  />
                </div>
                <div>
                  <label htmlFor="topic" className="block text-xs uppercase tracking-[0.2em] text-brand-ivory/60">
                    Topic
                  </label>
                  <select
                    id="topic"
                    name="topic"
                    value={formState.topic}
                    onChange={handleChange}
                    className="mt-2 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-brand-coral/80"
                  >
                    <option value="">Select one</option>
                    <option value="editorial">Editorial collaboration</option>
                    <option value="research">Research inquiry</option>
                    <option value="speaking">Speaking engagement</option>
                    <option value="press">Press inquiry</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="message" className="block text-xs uppercase tracking-[0.2em] text-brand-ivory/60">
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    value={formState.message}
                    onChange={handleChange}
                    className="mt-2 w-full rounded-lg border border-white/20 bg-white/10 px-4 py-3 text-sm text-white placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-brand-coral/80"
                    placeholder="Share context, timelines, and goals."
                    required
                  ></textarea>
                  {errors.message && <p className="mt-2 text-xs text-brand-coral">{errors.message}</p>}
                </div>
              </div>
              <button
                type="submit"
                className="mt-6 w-full rounded-full bg-brand-coral px-5 py-3 text-sm font-semibold text-white transition hover:bg-brand-coral/80"
              >
                Send message
              </button>
              <p className="mt-3 text-xs text-brand-ivory/60">
                We respect your inbox. Submissions power editorial planning only.
              </p>
            </form>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-12 mb-20 overflow-hidden rounded-3xl border border-brand-ivory/10 shadow-ambient"
        >
          <iframe
            title="DevLayer Toronto Office Map"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2886.378416146667!2d-79.3806204237578!3d43.64947945499268!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d7c44cccf7%3A0x5c1ac1d7caabc5ba!2s333%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202R2%2C%20Canada!5e0!3m2!1sen!2sca!4v1707260950000!5m2!1sen!2sca"
            loading="lazy"
            className="h-96 w-full border-0"
            allowFullScreen
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </motion.div>
      </section>
    </>
  );
};

export default Contact;