// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import archivalResources from "../data/resources";

const Archives = () => {
  return (
    <>
      <Helmet>
        <title>Historical Archives | DevLayer</title>
        <meta
          name="description"
          content="Explore the DevLayer archives featuring RFCs, legacy documentation, and open standards shaping modern engineering."
        />
      </Helmet>
      <section className="mx-auto mt-16 max-w-6xl px-4 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-10 shadow-ambient"
        >
          <h1 className="font-display text-4xl text-white">Historical Archives</h1>
          <p className="mt-4 text-lg leading-relaxed text-brand-ivory/80">
            A curated index of documents, RFCs, and standards that influenced modern software engineering. Dive into history to
            understand today’s systems.
          </p>
        </motion.div>

        <div className="mt-12 space-y-6">
          {archivalResources.map((resource) => (
            <motion.article
              key={resource.name}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-6"
            >
              <h2 className="font-display text-2xl text-white">{resource.name}</h2>
              <p className="mt-3 text-sm leading-relaxed text-brand-ivory/80">{resource.description}</p>
              <a
                href={resource.link}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 inline-flex items-center text-sm font-semibold text-brand-coral hover:underline"
              >
                Access resource →
              </a>
            </motion.article>
          ))}
        </div>

        <motion.p
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-10 mb-20 text-sm text-brand-ivory/60"
        >
          Have archival materials to share? Email archives@devlayer.com with background and usage permissions.
        </motion.p>
      </section>
    </>
  );
};

export default Archives;