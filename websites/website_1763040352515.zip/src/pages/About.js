// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const About = () => {
  return (
    <>
      <Helmet>
        <title>About DevLayer | Editorial Mission & Methodology</title>
        <meta
          name="description"
          content="Meet the DevLayer team from Toronto, learn about our editorial values, research methodology, and how we tell developer-centered stories."
        />
      </Helmet>
      <section className="mx-auto mt-16 max-w-6xl px-4 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-8 shadow-ambient sm:p-12"
        >
          <h1 className="font-display text-4xl text-white">Our Story</h1>
          <p className="mt-6 text-lg leading-relaxed text-brand-ivory/80">
            DevLayer began as a series of longform notes exchanged among platform engineers in Toronto. We saw teams moving
            faster than their documentation, knowledge trapped in release retros, and a need for narrative bridges between
            research and everyday implementation. Today DevLayer is an editorial platform that blends investigative reporting
            with field interviews, surfacing the lived experience of building resilient software systems.
          </p>
        </motion.div>

        <div className="mt-14 grid gap-8 md:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-8"
          >
            <h2 className="font-display text-2xl text-white">Editorial Values</h2>
            <ul className="mt-5 space-y-3 text-sm text-brand-ivory/80">
              <li>• Evidence-driven: Each story anchors in data, interviews, and practice.</li>
              <li>• Human-centered: We champion the realities of teams, not just tooling.</li>
              <li>• Transparent: Methodologies and biases are published with each piece.</li>
              <li>• Kind: We critique systems, never people.</li>
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-8"
          >
            <h2 className="font-display text-2xl text-white">Methodology</h2>
            <ul className="mt-5 space-y-3 text-sm text-brand-ivory/80">
              <li>• Field research with Canadian and global engineering teams.</li>
              <li>• Qualitative interviews paired with quantitative telemetry analysis.</li>
              <li>• Peer review by practising engineers before publication.</li>
              <li>• Schema.org metadata for discoverability and archival quality.</li>
            </ul>
          </motion.div>
        </div>

        <motion.section
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="mt-14 rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-8"
        >
          <h2 className="font-display text-2xl text-white">Editorial Team</h2>
          <div className="mt-6 grid gap-6 md:grid-cols-3">
            {[
              {
                name: "Maya Lall",
                role: "Founding Editor",
                focus: "Systems reporting, cloud infrastructure, policy."
              },
              {
                name: "Ethan Sorel",
                role: "Research Lead",
                focus: "Developer cognition, human factors, workflow design."
              },
              {
                name: "Priya Singh",
                role: "Platform Editor",
                focus: "Platform engineering, observability, developer experience."
              }
            ].map((member) => (
              <div key={member.name} className="rounded-2xl border border-brand-ivory/10 bg-brand-mid/30 p-6">
                <h3 className="font-display text-xl text-white">{member.name}</h3>
                <p className="text-sm uppercase tracking-[0.2em] text-brand-ivory/60">{member.role}</p>
                <p className="mt-4 text-sm leading-relaxed text-brand-ivory/80">{member.focus}</p>
              </div>
            ))}
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.15 }}
          className="mt-14 rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-8"
        >
          <h2 className="font-display text-2xl text-white">Ethics</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <p className="text-sm leading-relaxed text-brand-ivory/80">
                We anonymize sensitive interviews, obtain explicit consent for attribution, and provide participants with
                pre-publication review to ensure fidelity. When covering incidents, our commitment is to highlight
                remediations and learning culture, not blame.
              </p>
            </div>
            <div>
              <p className="text-sm leading-relaxed text-brand-ivory/80">
                DevLayer is editorially independent. We disclose partnerships, sponsorships, or grants at the top of relevant
                pieces. All recommendations are grounded in practitioner experience and research.
              </p>
            </div>
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mt-14 mb-20 rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-8"
        >
          <h2 className="font-display text-2xl text-white">Timeline</h2>
          <div className="mt-6 space-y-6 border-l border-brand-ivory/20 pl-6">
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-brand-ivory/60">2019</p>
              <p className="text-sm text-brand-ivory/80">DevLayer launches as a Toronto meetup focused on runbooks and tooling.</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-brand-ivory/60">2021</p>
              <p className="text-sm text-brand-ivory/80">We release the first public essays on developer cognition and platform strategy.</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-brand-ivory/60">2023</p>
              <p className="text-sm text-brand-ivory/80">Expansion into a full editorial platform with regular cadence and guest contributors.</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-brand-ivory/60">Today</p>
              <p className="text-sm text-brand-ivory/80">Serving global teams while staying rooted in Canadian engineering communities.</p>
            </div>
          </div>
        </motion.section>
      </section>
    </>
  );
};

export default About;