// @ts-check
import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { motion, AnimatePresence } from "framer-motion";
import blogPosts from "../data/blogPosts";

const categories = ["All", "Workflow", "Systems", "Tooling", "Culture"];

const Blog = () => {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredPosts = useMemo(() => {
    if (activeCategory === "All") return blogPosts;
    return blogPosts.filter((post) => post.categories.includes(activeCategory));
  }, [activeCategory]);

  return (
    <>
      <Helmet>
        <title>DevLayer Blog | Essays on Systems & Culture</title>
        <meta
          name="description"
          content="Browse DevLayer essays covering developer workflows, software systems, cloud patterns, tooling, and engineering culture."
        />
      </Helmet>
      <section className="mx-auto mt-16 max-w-6xl px-4 lg:px-8">
        <div className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-10 shadow-ambient">
          <h1 className="font-display text-4xl text-white">DevLayer Essays</h1>
          <p className="mt-4 text-lg leading-relaxed text-brand-ivory/80">
            Essays, reports, and field notes from the front lines of developer experience. Filter by topic to shape your
            reading queue.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setActiveCategory(category)}
                className={`rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] transition ${
                  activeCategory === category
                    ? "bg-brand-coral text-white"
                    : "border border-brand-ivory/30 text-brand-ivory/70 hover:border-brand-coral hover:text-brand-coral"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2">
          <AnimatePresence>
            {filteredPosts.map((post) => (
              <motion.article
                key={post.id}
                layout
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.4 }}
                className="group rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-6 shadow-ambient"
              >
                <div className="flex flex-wrap gap-2">
                  {post.categories.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-brand-deep/60 px-3 py-1 text-xs uppercase tracking-[0.2em] text-brand-ivory/60"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <h2 className="mt-4 font-display text-2xl text-white">{post.title}</h2>
                <p className="mt-3 text-sm leading-relaxed text-brand-ivory/80">{post.excerpt}</p>
                <div className="mt-6 flex items-center justify-between text-xs uppercase tracking-[0.25em] text-brand-ivory/50">
                  <span>{post.readingTime}</span>
                  <span>{post.date}</span>
                </div>
                <Link
                  to={post.path}
                  className="mt-6 inline-flex items-center text-sm font-semibold text-brand-coral transition group-hover:translate-x-1"
                >
                  Read more →
                </Link>
              </motion.article>
            ))}
          </AnimatePresence>
        </div>
      </section>
    </>
  );
};

export default Blog;