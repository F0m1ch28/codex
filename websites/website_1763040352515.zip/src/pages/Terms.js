// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Use | DevLayer</title>
        <meta
          name="description"
          content="DevLayer terms covering permitted use, intellectual property, disclaimers, and jurisdiction."
        />
      </Helmet>
      <section className="mx-auto mt-16 max-w-5xl rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 px-6 py-10 text-sm leading-relaxed text-brand-ivory/80 lg:px-10">
        <h1 className="font-display text-3xl text-white">Terms of Use</h1>
        <p className="mt-4">
          These terms govern use of the DevLayer editorial platform. By accessing the site you agree to the following
          conditions.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">1. Purpose of Content</h2>
        <p>
          DevLayer provides analysis, research, and commentary for educational use only. Content should not be interpreted as
          professional advice. Readers are responsible for applying insights within their own organizational context.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">2. Intellectual Property</h2>
        <p>
          All articles, graphics, and curated materials are the intellectual property of DevLayer or credited contributors.
          You may share excerpts with attribution and a link to the original source. Republishing full articles requires written
          permission.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">3. Acceptable Use</h2>
        <p>
          Users must not disrupt platform operations, attempt unauthorized access, or misuse contact forms. Automated scraping
          is prohibited without prior consent.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">4. External Links</h2>
        <p>
          DevLayer may reference external resources. We do not control or endorse external sites and are not responsible for
          their content or practices. Follow external links at your discretion.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">5. Liability</h2>
        <p>
          DevLayer strives for accuracy but cannot guarantee completeness of information. We disclaim liability for decisions
          made based on site content. Readers must evaluate and adapt insights responsibly.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">6. Jurisdiction</h2>
        <p>
          These terms are governed by the laws of Ontario, Canada. Disputes shall be addressed in the courts of Ontario.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">7. Changes to Terms</h2>
        <p>
          We may update these terms periodically. Continued use after updates constitutes acceptance of the revised terms.
        </p>

        <p className="mt-10 text-sm text-brand-ivory/60">
          Last updated: January 1, 2024. Questions? Contact legal@devlayer.com.
        </p>
      </section>
    </>
  );
};

export default Terms;