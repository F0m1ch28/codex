// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import queueItems from "../data/queueItems";

const Queue = () => {
  return (
    <>
      <Helmet>
        <title>Curated Reading Queue | DevLayer</title>
        <meta
          name="description"
          content="A regularly updated reading queue curated by DevLayer editors spotlighting research, books, and talks for developers."
        />
      </Helmet>
      <section className="mx-auto mt-16 max-w-5xl px-4 lg:px-0">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-8 shadow-ambient"
        >
          <h1 className="font-display text-4xl text-white">Curated Reading Queue</h1>
          <p className="mt-4 text-lg leading-relaxed text-brand-ivory/80">
            Each month the DevLayer editors compile readings that challenge, inspire, and inform. Expect a blend of research,
            historical documents, and modern essays.
          </p>
        </motion.div>

        <div className="mt-12 space-y-6">
          {queueItems.map((item) => (
            <motion.article
              key={item.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-6"
            >
              <h2 className="font-display text-2xl text-white">{item.title}</h2>
              <p className="mt-3 text-sm leading-relaxed text-brand-ivory/80">{item.annotation}</p>
              <div className="mt-4 flex flex-wrap gap-2 text-xs uppercase tracking-[0.2em] text-brand-ivory/60">
                {item.tags.map((tag) => (
                  <span key={tag} className="rounded-full bg-brand-deep/50 px-3 py-1">
                    {tag}
                  </span>
                ))}
              </div>
            </motion.article>
          ))}
        </div>

        <motion.p
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-10 mb-20 text-sm text-brand-ivory/60"
        >
          Have a recommendation? Reach us at queue@devlayer.com with context on why the piece resonates with builders.
        </motion.p>
      </section>
    </>
  );
};

export default Queue;