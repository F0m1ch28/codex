// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const services = [
  {
    title: "Editorial Tracks",
    description:
      "Commissioned longform pieces and narrative reports tailored to your engineering initiatives, informed by interviews and telemetry analysis.",
    highlights: ["Narrative synthesis", "Custom research briefs", "Stakeholder-ready insights"]
  },
  {
    title: "Workflow Field Studies",
    description:
      "Embedded research sprints studying developer workflows, tooling ergonomics, and delivery rituals to identify high-leverage opportunities.",
    highlights: ["Contextual inquiry", "Observability reviews", "Workflow prototyping"]
  },
  {
    title: "Platform Playbooks",
    description:
      "Collaborative playbooks that guide platform teams through enablement strategies, onboarding, and long-term stewardship.",
    highlights: ["Service catalog design", "Governance rhythms", "Developer onboarding"]
  },
  {
    title: "Editorial Partnerships",
    description:
      "Ongoing collaborations to document platform launches, post-incident learning, and engineering culture evolution with clarity and empathy.",
    highlights: ["Launch documentation", "Community storytelling", "Knowledge garden curation"]
  }
];

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Services | DevLayer Editorial Partnerships</title>
        <meta
          name="description"
          content="Discover DevLayer editorial services: narrative tracks, workflow research, platform playbooks, and ongoing partnerships for engineering teams."
        />
        <link rel="canonical" href="https://www.devlayer.com/services" />
      </Helmet>
      <section className="mx-auto mt-16 max-w-6xl px-4 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-10 shadow-ambient"
        >
          <h1 className="font-display text-4xl text-white">Editorial Services</h1>
          <p className="mt-4 text-lg leading-relaxed text-brand-ivory/80">
            DevLayer partners with engineering leaders to surface the stories hidden inside systems diagrams, incident logs,
            and platform roadmaps. We transform complex technical journeys into narratives that align teams and inspire action.
          </p>
        </motion.div>

        <div className="mt-14 grid gap-8 md:grid-cols-2">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              className="rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-8"
            >
              <h2 className="font-display text-2xl text-white">{service.title}</h2>
              <p className="mt-4 text-sm leading-relaxed text-brand-ivory/80">{service.description}</p>
              <ul className="mt-5 space-y-2 text-xs uppercase tracking-[0.2em] text-brand-ivory/60">
                {service.highlights.map((highlight) => (
                  <li key={highlight}>• {highlight}</li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        <motion.section
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="mt-16 mb-20 rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-8"
        >
          <h2 className="font-display text-2xl text-white">Engagement Approach</h2>
          <div className="mt-6 grid gap-6 md:grid-cols-3">
            {[
              {
                step: "Discover",
                description:
                  "We align on goals, preferred storytelling mediums, and the developer communities most impacted."
              },
              {
                step: "Immerse",
                description:
                  "Our editors embed with your teams, observing rituals and analyzing artifacts to capture nuance."
              },
              {
                step: "Publish",
                description:
                  "Drafts are co-reviewed, shaped into layered narratives, and delivered with supporting visuals and metadata."
              }
            ].map((item) => (
              <div key={item.step} className="rounded-2xl border border-brand-ivory/10 bg-brand-mid/30 p-6">
                <p className="text-xs uppercase tracking-[0.3em] text-brand-ivory/60">{item.step}</p>
                <p className="mt-3 text-sm leading-relaxed text-brand-ivory/80">{item.description}</p>
              </div>
            ))}
          </div>
        </motion.section>
      </section>
    </>
  );
};

export default Services;