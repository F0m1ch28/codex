// @ts-check
import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import blogPosts from "../data/blogPosts";

const Home = () => {
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterSubmitted, setNewsletterSubmitted] = useState(false);

  const featuredEssays = useMemo(
    () => blogPosts.slice(0, 3),
    []
  );

  const workflowPatterns = [
    {
      title: "Runbooks as Living Systems",
      description:
        "Design runbooks that respond to reality with versioned learning loops, not single-author documents.",
      bullets: ["Operational choreography", "Feedback loops", "Collective artifact ownership"]
    },
    {
      title: "Latency Budgets for Collaboration",
      description:
        "Architect queueing models that align communication cadences with service-level intents.",
      bullets: ["Service seams", "Async rituals", "Escalation clarity"]
    },
    {
      title: "Mentorship Lattices",
      description:
        "Pair reflective mentorship structures with technical laddering to reduce cognitive debt.",
      bullets: ["Shadowing arcs", "Narrative reviews", "Capability maps"]
    }
  ];

  const systemsArchitecture = [
    {
      title: "Resilient Mesh Patterns",
      description:
        "Blend mesh gateways and policy engines to keep observability first-class while keeping operator mental load bounded.",
      link: "/blog/cloud-patterns-for-scale"
    },
    {
      title: "API Lifecycles",
      description:
        "Versioning strategy meets psychological safety—shape lifecycles that encourage experimentation with informed guardrails.",
      link: "/workflows"
    },
    {
      title: "Secure Delivery Channels",
      description:
        "Integrate threat modeling into delivery pipelines to keep trust and throughput aligned.",
      link: "/services"
    }
  ];

  const developerCognition = [
    {
      title: "Focus Intervals",
      description:
        "Protect cognitive bandwidth with interval planning, mindful notifications, and respectful rituals.",
      link: "/mindset"
    },
    {
      title: "Cognitive Load Mapping",
      description:
        "Visualize the invisible load across teams by mapping dependencies, modalities, and narrative context.",
      link: "/blog/why-context-switching-kills-productivity"
    },
    {
      title: "Burnout Signals",
      description:
        "Use socio-technical indicators to start conversations before energy debt becomes crisis.",
      link: "/mindset"
    }
  ];

  const toolingInsights = [
    {
      title: "IDE Ergonomics Field Guide",
      description:
        "Audit your IDE ergonomics with heuristics derived from Canadian research labs and global engineering teams.",
      link: "/workflows"
    },
    {
      title: "Observability Sketchbooks",
      description:
        "Turn production incidents into structured sketchbooks that inform platform roadmaps.",
      link: "/notes"
    },
    {
      title: "API Schemas in Motion",
      description:
        "Bring schema evolution into design reviews with visual diffing and dual-track versioning.",
      link: "/services"
    }
  ];

  const handleNewsletterSubmit = (evt) => {
    evt.preventDefault();
    if (!newsletterEmail) return;
    setNewsletterSubmitted(true);
    setNewsletterEmail("");
  };

  return (
    <>
      <Helmet>
        <title>DevLayer | Every Layer Tells a Story</title>
        <meta
          name="description"
          content="DevLayer curates essays and research for developers navigating software systems, workflows, cloud infrastructure, and engineering culture."
        />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebSite",
            name: "DevLayer",
            url: "https://www.devlayer.com",
            inLanguage: "en",
            potentialAction: {
              "@type": "SearchAction",
              target: "https://www.devlayer.com/blog?query={search_term_string}",
              "query-input": "required name=search_term_string"
            }
          })}
        </script>
      </Helmet>
      <article>
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-hero-gradient"></div>
          <div className="relative mx-auto flex min-h-[70vh] max-w-7xl flex-col items-start justify-center gap-10 px-4 py-16 text-brand-ivory lg:flex-row lg:items-center lg:px-8 lg:py-24">
            <motion.div
              initial={{ opacity: 0, y: 32 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="max-w-2xl"
            >
              <span className="rounded-full border border-brand-ivory/30 px-4 py-1 text-xs uppercase tracking-[0.35em] text-brand-ivory/70">
                Every Layer Tells a Story
              </span>
              <h1 className="mt-6 font-display text-4xl leading-tight text-white sm:text-5xl">
                Editorial intelligence for teams building the next generation of software systems.
              </h1>
              <p className="mt-6 max-w-xl font-sans text-lg leading-relaxed text-brand-ivory/80">
                DevLayer is a Canadian editorial platform distilling insights on developer workflows, cloud infrastructure,
                and engineering culture. We translate complex systems into actionable narratives that respect craft, pace,
                and community.
              </p>
              <div className="mt-8 flex flex-col gap-4 sm:flex-row">
                <Link
                  to="/blog"
                  className="inline-flex items-center justify-center rounded-full bg-brand-coral px-6 py-3 font-semibold text-white shadow-ambient transition hover:bg-brand-coral/80"
                >
                  Dive into essays
                </Link>
                <Link
                  to="/about"
                  className="inline-flex items-center justify-center rounded-full border border-brand-ivory/40 px-6 py-3 font-semibold text-brand-ivory transition hover:border-brand-coral hover:text-brand-coral"
                >
                  Explore the mission
                </Link>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.9, ease: "easeOut", delay: 0.2 }}
              className="relative w-full max-w-xl overflow-hidden rounded-3xl border border-white/15"
            >
              <img
                src="https://picsum.photos/1600/900?random=1"
                alt="Developers collaborating around layered diagrams"
                loading="lazy"
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-deep/70 to-transparent"></div>
              <div className="absolute bottom-0 w-full bg-brand-deep/70 px-6 py-4 backdrop-blur">
                <p className="font-sans text-sm uppercase tracking-[0.2em] text-brand-ivory/80">
                  Field Notes from Toronto
                </p>
                <p className="mt-1 font-display text-lg text-white">
                  Observing how teams shape software under real constraints.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="mx-auto mt-20 max-w-6xl px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/50 p-8 shadow-ambient sm:p-12"
          >
            <h2 className="font-display text-3xl text-white">Editorial Mission</h2>
            <p className="mt-4 font-sans text-lg leading-relaxed text-brand-ivory/80">
              Our mission is to help technical leaders and hands-on developers navigate the layered complexity of modern
              software. We investigate the interplay between people, process, and platforms with rigor, curiosity, and respect
              for the craft.
            </p>
            <div className="mt-8 grid gap-6 sm:grid-cols-2">
              <div className="rounded-2xl border border-brand-ivory/10 bg-brand-mid/40 p-6">
                <h3 className="font-display text-xl text-white">Values</h3>
                <ul className="mt-4 space-y-2 text-sm text-brand-ivory/80">
                  <li>• Depth over noise—research before rhetoric.</li>
                  <li>• Systems thinking tied to human-centered delivery.</li>
                  <li>• Transparency around methodology, sources, and bias.</li>
                </ul>
              </div>
              <div className="rounded-2xl border border-brand-ivory/10 bg-brand-mid/40 p-6">
                <h3 className="font-display text-xl text-white">Focus</h3>
                <ul className="mt-4 space-y-2 text-sm text-brand-ivory/80">
                  <li>• Developer workflows and platform stewardship.</li>
                  <li>• Cloud infrastructure patterns that scale responsibly.</li>
                  <li>• Engineering culture, cognition, and collaborative health.</li>
                </ul>
              </div>
            </div>
          </motion.div>
        </section>

        <section className="mx-auto mt-24 max-w-7xl px-4 lg:px-8">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <h2 className="font-display text-3xl text-white">Featured Essays</h2>
            <Link to="/blog" className="text-sm font-semibold text-brand-coral hover:underline">
              View the archive →
            </Link>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {featuredEssays.map((essay) => (
              <motion.div
                key={essay.id}
                whileHover={{ y: -6, scale: 1.01 }}
                transition={{ duration: 0.25 }}
                className="group relative overflow-hidden rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-6 shadow-ambient"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 transition group-hover:opacity-100"></div>
                <div className="relative">
                  <div className="flex flex-wrap gap-2">
                    {essay.categories.map((tag) => (
                      <span
                        key={tag}
                        className="rounded-full bg-brand-mid/60 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-brand-ivory/70"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <h3 className="mt-4 font-display text-xl text-white">{essay.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-brand-ivory/70">{essay.excerpt}</p>
                  <div className="mt-6 flex items-center justify-between text-xs uppercase tracking-[0.25em] text-brand-ivory/50">
                    <span>{essay.readingTime}</span>
                    <span>{essay.date}</span>
                  </div>
                  <Link
                    to={essay.path}
                    className="mt-6 inline-flex items-center text-sm font-semibold text-brand-coral transition group-hover:translate-x-1"
                  >
                    Read the essay →
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="mx-auto mt-24 max-w-6xl px-4 lg:px-8">
          <h2 className="font-display text-3xl text-white">Workflow Patterns</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {workflowPatterns.map((pattern) => (
              <motion.div
                key={pattern.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, ease: "easeOut" }}
                className="rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-6"
              >
                <h3 className="font-display text-xl text-white">{pattern.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-brand-ivory/80">{pattern.description}</p>
                <ul className="mt-4 space-y-2 text-xs uppercase tracking-[0.25em] text-brand-ivory/60">
                  {pattern.bullets.map((bullet) => (
                    <li key={bullet}>• {bullet}</li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="mx-auto mt-24 max-w-6xl px-4 lg:px-8">
          <h2 className="font-display text-3xl text-white">Systems Architecture</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {systemsArchitecture.map((item) => (
              <motion.div
                key={item.title}
                whileHover={{ y: -6 }}
                className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-6"
              >
                <h3 className="font-display text-xl text-white">{item.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-brand-ivory/80">{item.description}</p>
                <Link to={item.link} className="mt-6 inline-flex items-center text-sm font-semibold text-brand-coral">
                  Continue →
                </Link>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="mx-auto mt-24 max-w-6xl px-4 lg:px-8">
          <h2 className="font-display text-3xl text-white">Developer Cognition</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {developerCognition.map((item) => (
              <motion.div
                key={item.title}
                whileHover={{ scale: 1.02 }}
                className="rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-6"
              >
                <h3 className="font-display text-xl text-white">{item.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-brand-ivory/80">{item.description}</p>
                <Link to={item.link} className="mt-6 inline-flex items-center text-sm font-semibold text-brand-coral">
                  Explore →
                </Link>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="mx-auto mt-24 max-w-6xl px-4 lg:px-8">
          <h2 className="font-display text-3xl text-white">Tooling Insights</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {toolingInsights.map((item) => (
              <motion.div
                key={item.title}
                whileHover={{ scale: 1.02 }}
                className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-6"
              >
                <h3 className="font-display text-xl text-white">{item.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-brand-ivory/80">{item.description}</p>
                <Link to={item.link} className="mt-6 inline-flex items-center text-sm font-semibold text-brand-coral">
                  Learn more →
                </Link>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="relative mx-auto mt-24 max-w-5xl overflow-hidden rounded-3xl border border-brand-ivory/10 bg-gradient-to-br from-brand-coral/80 via-brand-mid/80 to-brand-deep/80 px-6 py-12 text-brand-ivory shadow-ambient">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between"
          >
            <div>
              <h2 className="font-display text-3xl text-white">Subscribe to the Layered Dispatch</h2>
              <p className="mt-3 max-w-md text-sm leading-relaxed text-brand-ivory/80">
                A monthly briefing capturing the most resonant systems stories, workflow experiments,
                and cultural research shaping developer teams across Canada and beyond.
              </p>
            </div>
            <form className="flex w-full flex-col gap-3 sm:max-w-sm" onSubmit={handleNewsletterSubmit}>
              <label htmlFor="newsletter" className="sr-only">
                Your email
              </label>
              <input
                id="newsletter"
                type="email"
                required
                placeholder="you@studio.com"
                value={newsletterEmail}
                onChange={(event) => setNewsletterEmail(event.target.value)}
                className="w-full rounded-full border border-white/40 bg-white/10 px-5 py-3 text-sm text-white placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-white/80"
              />
              <button
                type="submit"
                className="rounded-full bg-white px-5 py-3 text-sm font-semibold text-brand-deep transition hover:bg-brand-ivory"
              >
                Join the dispatch
              </button>
              {newsletterSubmitted && (
                <p className="text-xs text-brand-ivory/80">
                  Welcome aboard. Look for layered thinking in your inbox soon.
                </p>
              )}
            </form>
          </motion.div>
        </section>

        <section className="mx-auto mt-16 max-w-5xl px-4 pb-20 lg:px-8">
          <div className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-6 text-sm text-brand-ivory/70">
            <p>
              Disclaimer: DevLayer publishes research and commentary for educational use only. We encourage teams to adapt
              insights to their specific context and to retain human judgment in all critical decisions.
            </p>
          </div>
        </section>
      </article>
    </>
  );
};

export default Home;