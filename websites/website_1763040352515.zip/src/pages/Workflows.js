// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const workflowSections = [
  {
    title: "CI/CD Orchestration",
    description:
      "We benchmark pipelines for feedback loops, deploy confidence, and developer autonomy. This includes branch hygiene, automated quality gates, and release communication.",
    points: [
      "Deployment cadence audits",
      "Progressive delivery strategies",
      "Incident-ready rollback procedures"
    ]
  },
  {
    title: "Pipeline Observability",
    description:
      "Bring observability to the delivery pipeline itself. Track queue times, flaky checks, and staging reliability to guide investment.",
    points: [
      "End-to-end pipeline tracing",
      "Build cache governance",
      "Signal-to-noise dashboards"
    ]
  },
  {
    title: "IDE Ergonomics",
    description:
      "Developers spend most of their time in editors and terminals. We analyze editor setup, extensibility, and automated onboarding to reduce friction.",
    points: [
      "Pairing ergonomics",
      "Snippet libraries and templates",
      "Onboarding workspaces"
    ]
  },
  {
    title: "Team Rituals",
    description:
      "Rituals either protect focus or shatter it. We facilitate retrospectives, stand-ups, and pairing sessions that align with team energy rather than calendar defaults.",
    points: [
      "Cadence design",
      "Async-first communication",
      "Runbook rehearsals"
    ]
  }
];

const Workflows = () => {
  return (
    <>
      <Helmet>
        <title>Developer Workflows | DevLayer</title>
        <meta
          name="description"
          content="DevLayer explores CI/CD orchestration, pipeline observability, IDE ergonomics, and team rituals for sustainable developer workflows."
        />
      </Helmet>
      <section className="mx-auto mt-16 max-w-6xl px-4 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-10 shadow-ambient"
        >
          <h1 className="font-display text-4xl text-white">Developer Workflow Patterns</h1>
          <p className="mt-4 text-lg leading-relaxed text-brand-ivory/80">
            Sustainable speed emerges when pipelines, tools, and rituals reinforce each other. DevLayer documents practices that
            empower developers to move quickly without sacrificing stability or well-being.
          </p>
        </motion.div>

        <div className="mt-14 grid gap-8 md:grid-cols-2">
          {workflowSections.map((section, index) => (
            <motion.section
              key={section.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              className="rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-8"
            >
              <h2 className="font-display text-2xl text-white">{section.title}</h2>
              <p className="mt-4 text-sm leading-relaxed text-brand-ivory/80">{section.description}</p>
              <ul className="mt-5 space-y-2 text-xs uppercase tracking-[0.2em] text-brand-ivory/60">
                {section.points.map((point) => (
                  <li key={point}>• {point}</li>
                ))}
              </ul>
            </motion.section>
          ))}
        </div>

        <motion.section
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="mt-16 mb-20 rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-10"
        >
          <h2 className="font-display text-2xl text-white">CI/CD Scorecard</h2>
          <p className="mt-4 text-sm leading-relaxed text-brand-ivory/80">
            We evaluate delivery pipelines through a scorecard that measures lead time, recovery speed, change fail rate, and
            developer experience. Data is paired with interviews to understand lived reality.
          </p>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <div className="rounded-2xl border border-brand-ivory/10 bg-brand-mid/30 p-5">
              <p className="text-xs uppercase tracking-[0.2em] text-brand-ivory/50">Lead Time</p>
              <p className="mt-2 text-sm text-brand-ivory/80">
                Median hours from merge to production. Highlights bottlenecks in approvals or environments.
              </p>
            </div>
            <div className="rounded-2xl border border-brand-ivory/10 bg-brand-mid/30 p-5">
              <p className="text-xs uppercase tracking-[0.2em] text-brand-ivory/50">Recovery</p>
              <p className="mt-2 text-sm text-brand-ivory/80">
                Time to remediation for incidents triggered by deployments. Exposes observability gaps and runbook clarity.
              </p>
            </div>
            <div className="rounded-2xl border border-brand-ivory/10 bg-brand-mid/30 p-5">
              <p className="text-xs uppercase tracking-[0.2em] text-brand-ivory/50">Change Health</p>
              <p className="mt-2 text-sm text-brand-ivory/80">
                Percentage of changes that require rollback or hotfix. Informs investment in testing and guardrails.
              </p>
            </div>
            <div className="rounded-2xl border border-brand-ivory/10 bg-brand-mid/30 p-5">
              <p className="text-xs uppercase tracking-[0.2em] text-brand-ivory/50">Experience</p>
              <p className="mt-2 text-sm text-brand-ivory/80">
                Developer sentiment and friction mapping gathered via pulse surveys and interviews.
              </p>
            </div>
          </div>
        </motion.section>
      </section>
    </>
  );
};

export default Workflows;