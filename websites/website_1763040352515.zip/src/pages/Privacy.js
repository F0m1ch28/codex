// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | DevLayer</title>
        <meta
          name="description"
          content="DevLayer privacy policy describing cookie usage, analytics, data processing, and user rights."
        />
      </Helmet>
      <section className="mx-auto mt-16 max-w-5xl rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 px-6 py-10 text-sm leading-relaxed text-brand-ivory/80 lg:px-10">
        <h1 className="font-display text-3xl text-white">Privacy Policy</h1>
        <p className="mt-4">
          DevLayer respects the privacy of all visitors. This policy outlines how we collect, use, and safeguard data when you
          engage with our editorial platform.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">1. Information We Collect</h2>
        <ul className="mt-3 space-y-2">
          <li>• Contact details submitted through forms (name, email, organization).</li>
          <li>• Behavioral analytics via privacy-focused tools to understand readership trends.</li>
          <li>• Aggregated technical logs to monitor platform reliability and accessibility.</li>
        </ul>

        <h2 className="mt-8 font-display text-2xl text-white">2. Cookies and Tracking</h2>
        <p className="mt-3">
          We use essential cookies to maintain session state and optional analytics cookies to evaluate content engagement. You
          may decline analytics cookies via browser settings or our cookie banner.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">3. Data Usage</h2>
        <p className="mt-3">
          Submitted information is used to respond to inquiries, customize newsletters, and improve editorial planning. We do
          not sell or rent personal data. We partner with trusted service providers for email and analytics; each provider is
          bound by strict confidentiality agreements.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">4. Data Retention</h2>
        <p className="mt-3">
          Contact submissions are retained for up to 24 months for follow-up and historical reference. Analytics data is stored
          in aggregate form for trend analysis and deleted after 18 months.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">5. User Rights</h2>
        <p className="mt-3">
          Canadian and international visitors may request access, correction, or deletion of their personal data. Please contact
          info@devlayer.com with specific requests. We respond within 30 days.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">6. Third-Party Services</h2>
        <p className="mt-3">
          DevLayer uses reputable third-party services for hosting, analytics, and newsletter distribution. These providers
          meet high security standards. We regularly review their policies to ensure compliance with our privacy commitments.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">7. Security</h2>
        <p className="mt-3">
          We implement encryption in transit, access controls, and monitoring to protect data. While no system is entirely
          immune to risk, we aim to maintain robust safeguards and transparent communication.
        </p>

        <h2 className="mt-8 font-display text-2xl text-white">8. Updates</h2>
        <p className="mt-3">
          We may update this policy to reflect evolving practices or regulatory changes. Significant updates will be announced
          on the DevLayer Notes page and via newsletter.
        </p>

        <p className="mt-8 text-sm text-brand-ivory/60">
          Effective date: January 1, 2024. For questions, contact privacy@devlayer.com.
        </p>
      </section>
    </>
  );
};

export default Privacy;