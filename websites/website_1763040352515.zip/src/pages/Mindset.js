// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const themes = [
  {
    title: "Cognitive Bandwidth",
    description:
      "Identify how psychological load accumulates during feature delivery. Map the hidden queues—notifications, review requests, unprioritized ideas—and design rituals that respect mental recovery."
  },
  {
    title: "Communication Fluency",
    description:
      "Effective engineering organizations cultivate language. Glossaries, storytelling circles, and pairing rotations prevent misunderstandings and start shared narratives."
  },
  {
    title: "Navigating Burnout",
    description:
      "Burnout rarely starts with exhaustion—it begins with isolation. We help teams create feedback loops, energy check-ins, and resource networks that surface stress early."
  },
  {
    title: "Cultivating Focus",
    description:
      "Focus is a shared responsibility. Teams that treat attention as a resource establish norms around meeting load, asynchronous updates, and deep work protection."
  }
];

const Mindset = () => {
  return (
    <>
      <Helmet>
        <title>Developer Mindset | DevLayer</title>
        <meta
          name="description"
          content="DevLayer explores developer cognition, burnout signals, communication fluency, and focus rituals to sustain engineering teams."
        />
      </Helmet>
      <section className="mx-auto mt-16 max-w-6xl px-4 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-10 shadow-ambient"
        >
          <h1 className="font-display text-4xl text-white">Developer Mindset</h1>
          <p className="mt-4 text-lg leading-relaxed text-brand-ivory/80">
            The craft of software development is as cognitive as it is technical. DevLayer documents practices that nurture
            attention, collaboration, and sustainable energy across engineering teams.
          </p>
        </motion.div>

        <div className="mt-14 grid gap-8 md:grid-cols-2">
          {themes.map((theme, index) => (
            <motion.div
              key={theme.title}
              initial={{ opacity: 0, y: 22 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              className="rounded-3xl border border-brand-ivory/10 bg-brand-mid/40 p-8"
            >
              <h2 className="font-display text-2xl text-white">{theme.title}</h2>
              <p className="mt-4 text-sm leading-relaxed text-brand-ivory/80">{theme.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.section
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="mt-16 mb-20 rounded-3xl border border-brand-ivory/10 bg-brand-deep/60 p-10"
        >
          <h2 className="font-display text-2xl text-white">Practices We Recommend</h2>
          <ul className="mt-6 space-y-4 text-sm leading-relaxed text-brand-ivory/80">
            <li>
              <strong>Energy standups:</strong> Incorporate energy forecasting into daily check-ins so teammates can offer
              support or swap responsibilities proactively.
            </li>
            <li>
              <strong>Reflection capsules:</strong> Encourage developers to capture short reflections after major milestones.
              These capsules become an anthology of growth and learning.
            </li>
            <li>
              <strong>Communication hygiene:</strong> Maintain shared guidelines on channel expectations, response times, and
              escalation procedures to protect attention.
            </li>
            <li>
              <strong>Learning sabbaticals:</strong> Structured pauses where engineers explore new ideas, teach peers, or
              document tribal knowledge without delivery pressure.
            </li>
          </ul>
        </motion.section>
      </section>
    </>
  );
};

export default Mindset;