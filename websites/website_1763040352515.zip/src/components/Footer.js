// @ts-check
import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

const Footer = () => {
  return (
    <footer className="relative mt-20 border-t border-white/10 bg-brand-deep/80 pt-16 pb-10">
      <div className="absolute inset-0 -z-10 bg-hero-gradient opacity-60"></div>
      <div className="mx-auto flex max-w-7xl flex-col gap-12 px-4 lg:flex-row lg:justify-between lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="max-w-md"
        >
          <h3 className="font-display text-2xl font-semibold text-white">DevLayer</h3>
          <p className="mt-4 font-sans text-sm leading-relaxed text-brand-ivory/80">
            DevLayer is a developer-focused editorial platform curating analysis across software systems,
            developer workflows, cloud infrastructure, and engineering culture. Based in Toronto and
            connected to builders everywhere.
          </p>
          <div className="mt-6 space-y-1 text-sm">
            <p>333 Bay St, Toronto, ON M5H 2R2, Canada</p>
            <p>+1 (416) 905-6621</p>
            <p>
              <a href="mailto:info@devlayer.com" className="text-brand-coral hover:underline">
                info@devlayer.com
              </a>
            </p>
          </div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.1 }}
          className="grid flex-1 gap-8 text-sm sm:grid-cols-2 lg:grid-cols-3"
        >
          <div>
            <h4 className="font-semibold uppercase tracking-[0.3em] text-brand-ivory/60">Navigation</h4>
            <ul className="mt-4 space-y-2">
              <li><Link className="hover:text-brand-coral" to="/">Home</Link></li>
              <li><Link className="hover:text-brand-coral" to="/about">About</Link></li>
              <li><Link className="hover:text-brand-coral" to="/services">Services</Link></li>
              <li><Link className="hover:text-brand-coral" to="/blog">Blog</Link></li>
              <li><Link className="hover:text-brand-coral" to="/contact">Contact</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold uppercase tracking-[0.3em] text-brand-ivory/60">Editorial Areas</h4>
            <ul className="mt-4 space-y-2">
              <li><Link className="hover:text-brand-coral" to="/workflows">Developer Workflows</Link></li>
              <li><Link className="hover:text-brand-coral" to="/mindset">Developer Cognition</Link></li>
              <li><Link className="hover:text-brand-coral" to="/archives">Historical Archives</Link></li>
              <li><Link className="hover:text-brand-coral" to="/queue">Reading Queue</Link></li>
              <li><Link className="hover:text-brand-coral" to="/notes">Editorial Notes</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold uppercase tracking-[0.3em] text-brand-ivory/60">Policies</h4>
            <ul className="mt-4 space-y-2">
              <li><Link className="hover:text-brand-coral" to="/privacy">Privacy</Link></li>
              <li><Link className="hover:text-brand-coral" to="/terms">Terms</Link></li>
              <li><Link className="hover:text-brand-coral" to="/contact">Press Inquiries</Link></li>
            </ul>
            <div className="mt-6">
              <p className="text-xs uppercase tracking-[0.2em] text-brand-ivory/60">Social</p>
              <div className="mt-3 flex gap-4 text-sm">
                <a
                  href="https://github.com/devlayer"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-brand-coral"
                >
                  GitHub
                </a>
                <a
                  href="https://www.linkedin.com/company/devlayer"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-brand-coral"
                >
                  LinkedIn
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
      <div className="mt-14 border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-6 text-xs text-brand-ivory/70 lg:flex-row lg:items-center lg:justify-between lg:px-8">
          <p>© {new Date().getFullYear()} DevLayer. Crafted for the developer community in Canada and abroad.</p>
          <p className="italic">All content is for educational use only.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;