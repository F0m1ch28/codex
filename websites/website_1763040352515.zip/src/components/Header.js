// @ts-check
import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { motion } from "framer-motion";

const navItems = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Services", to: "/services" },
  { label: "Workflows", to: "/workflows" },
  { label: "Mindset", to: "/mindset" },
  { label: "Blog", to: "/blog" },
  { label: "Queue", to: "/queue" },
  { label: "Archives", to: "/archives" },
  { label: "Notes", to: "/notes" },
  { label: "Contact", to: "/contact" }
];

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  const renderNavLink = (item) => (
    <NavLink
      key={item.to}
      to={item.to}
      onClick={() => setIsOpen(false)}
      className={({ isActive }) =>
        `block rounded-full px-4 py-2 text-sm font-semibold transition-all duration-200 lg:text-base ${
          isActive
            ? "bg-brand-coral text-white shadow-ambient"
            : "text-brand-ivory hover:bg-brand-mid/50 hover:text-white"
        }`
      }
    >
      {item.label}
    </NavLink>
  );

  return (
    <header className="relative z-50 w-full border-b border-white/10 bg-brand-navy/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <Link to="/" className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-coral to-brand-mid shadow-ambient">
              <span className="font-display text-xl font-semibold text-white">DL</span>
            </div>
            <div className="flex flex-col">
              <span className="font-display text-xl font-semibold tracking-wide text-brand-ivory">
                DevLayer
              </span>
              <span className="text-xs font-medium uppercase tracking-[0.3em] text-brand-ivory/60">
                Editorial Platform
              </span>
            </div>
          </Link>
        </motion.div>
        <nav className="hidden items-center gap-1 lg:flex">
          {navItems.map(renderNavLink)}
        </nav>
        <button
          type="button"
          aria-label="Toggle navigation"
          className="flex h-11 w-11 items-center justify-center rounded-full border border-brand-ivory/20 bg-brand-mid text-brand-ivory transition hover:border-brand-coral/60 hover:text-white lg:hidden"
          onClick={() => setIsOpen((prev) => !prev)}
        >
          <span className="sr-only">Menu</span>
          <div className="space-y-1.5">
            <span className="block h-0.5 w-6 rounded bg-current"></span>
            <span className="block h-0.5 w-6 rounded bg-current"></span>
            <span className="block h-0.5 w-6 rounded bg-current"></span>
          </div>
        </button>
      </div>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="border-t border-white/10 bg-brand-deep/95 px-4 py-6 lg:hidden"
        >
          <div className="grid gap-2">{navItems.map(renderNavLink)}</div>
        </motion.div>
      )}
    </header>
  );
};

export default Header;