// @ts-check
import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const storageKey = "devlayer-cookie-consent";
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(storageKey);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(storageKey, "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-[100] border-t border-white/10 bg-brand-deep/95 px-4 py-4 shadow-ambient backdrop-blur">
      <div className="mx-auto flex max-w-5xl flex-col items-start gap-4 text-sm text-brand-ivory lg:flex-row lg:items-center lg:justify-between">
        <p className="leading-relaxed">
          DevLayer uses cookies and analytics to study readership patterns and enhance editorial delivery.
          By continuing to browse, you agree to our{" "}
          <a className="underline decoration-brand-coral decoration-2 underline-offset-4 hover:text-brand-coral" href="/privacy">
            privacy statement
          </a>
          .
        </p>
        <button
          type="button"
          onClick={handleAccept}
          className="rounded-full bg-brand-coral px-5 py-2 text-sm font-semibold text-white transition hover:bg-brand-coral/80"
        >
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;