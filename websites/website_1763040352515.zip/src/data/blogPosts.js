// @ts-check
const blogPosts = [
  {
    id: "context-switching",
    title: "Why Context Switching Kills Productivity",
    path: "/blog/why-context-switching-kills-productivity",
    categories: ["Workflow", "Culture"],
    excerpt:
      "Understand the neurological and systems-level drag introduced by frequent task switching, and shape rituals that protect deep focus.",
    readingTime: "7 min read",
    date: "2024-01-15"
  },
  {
    id: "cloud-patterns",
    title: "Cloud Patterns for Scale",
    path: "/blog/cloud-patterns-for-scale",
    categories: ["Systems", "Tooling"],
    excerpt:
      "Practical cloud-native patterns for scaling across regions, teams, and evolving product surfaces without losing observability.",
    readingTime: "8 min read",
    date: "2024-02-02"
  },
  {
    id: "devops-culture",
    title: "The Evolution of DevOps Culture",
    path: "/blog/the-evolution-of-devops-culture",
    categories: ["Culture", "Workflow"],
    excerpt:
      "Tracing the lineage of DevOps from the early days of release engineering to modern platform stewardship.",
    readingTime: "9 min read",
    date: "2024-03-28"
  }
];

export default blogPosts;