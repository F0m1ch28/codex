// @ts-check
const queueItems = [
  {
    title: "Designing Data-Intensive Applications — Martin Kleppmann",
    annotation: "Foundational patterns for dealing with distributed systems trade-offs and consistency domains.",
    tags: ["Distributed Systems", "Data"]
  },
  {
    title: "Staff Engineer — Will Larson",
    annotation: "A grounded exploration of leadership arcs for senior engineers who still ship architecture.",
    tags: ["Leadership", "Culture"]
  },
  {
    title: "Latency Numbers Every Programmer Should Know — Peter Norvig (revisited)",
    annotation: "A timeless reference anchoring intuition for scale and critical-path budgeting.",
    tags: ["Performance", "Systems"]
  },
  {
    title: "The SPACE of Developer Productivity — Microsoft Research",
    annotation: "A multidimensional framework for discussing productivity without oversimplified dashboards.",
    tags: ["Research", "Workflow"]
  },
  {
    title: "Google SRE Workbook",
    annotation: "Rituals and runbooks illustrating how large-scale reliability is choreographed.",
    tags: ["Reliability", "Operations"]
  }
];

export default queueItems;