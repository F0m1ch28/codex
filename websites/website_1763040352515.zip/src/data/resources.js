// @ts-check
const archivalResources = [
  {
    name: "RFC 959 - File Transfer Protocol",
    description: "A cornerstone document detailing FTP, still relevant for understanding protocol evolution.",
    link: "https://www.rfc-editor.org/rfc/rfc959"
  },
  {
    name: "The Xerox Alto User's Handbook",
    description: "A historical look at early graphical interfaces that shaped modern workstation design.",
    link: "http://bitsavers.org/pdf/xerox/alto"
  },
  {
    name: "The Mythical Man-Month Papers",
    description: "Frederick Brooks' essays on complex software projects and the core fallacies of scaling teams.",
    link: "https://www.cs.unc.edu/~brooks/194"
  },
  {
    name: "Plan 9 Programmer's Manual",
    description: "Explores distributed operating system ideas that influenced contemporary cloud architecture.",
    link: "https://9p.io/plan9/doc/manual.html"
  },
  {
    name: "The C Web Server Benchmark - SPECweb99",
    description: "Historic benchmarking suite for server workloads, useful for contextualizing modern performance baselines.",
    link: "https://www.spec.org/web99/"
  }
];

export default archivalResources;