/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        "brand-navy": "#1a1a2e",
        "brand-deep": "#16213e",
        "brand-mid": "#0f3460",
        "brand-coral": "#e94560",
        "brand-ivory": "#f5f5f5"
      },
      fontFamily: {
        display: ['"Playfair Display"', "serif"],
        sans: ['"Source Sans Pro"', "sans-serif"]
      },
      boxShadow: {
        ambient: "0 20px 45px rgba(14, 24, 64, 0.35)"
      },
      backgroundImage: {
        "hero-gradient": "radial-gradient(circle at 20% 20%, rgba(233,69,96,0.16), transparent 60%), radial-gradient(circle at 80% 0%, rgba(15,52,96,0.45), transparent 55%)"
      }
    }
  },
  plugins: []
};