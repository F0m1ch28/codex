import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.column}>
          <h3 className={styles.title}>TechSolutions Inc.</h3>
          <p className={styles.text}>
            Guiding organizations through cloud adoption and digital transformation with measurable outcomes.
          </p>
        </div>
        <div className={styles.column}>
          <h4 className={styles.subtitle}>Contact</h4>
          <ul className={styles.list}>
            <li>123 Innovation Drive, Tech City, TC 10101</li>
            <li><a href="tel:+15551234567">+1 (555) 123-4567</a></li>
            <li><a href="mailto:info@techsolutions-inc.com">info@techsolutions-inc.com</a></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4 className={styles.subtitle}>Company</h4>
          <ul className={styles.links}>
            <li><Link to="/about">About</Link></li>
            <li><Link to="/services">Services</Link></li>
            <li><Link to="/contact">Contact</Link></li>
            <li><Link to="/terms">Terms of Use</Link></li>
            <li><Link to="/privacy">Privacy Policy</Link></li>
            <li><Link to="/cookie-policy">Cookie Policy</Link></li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} TechSolutions Inc. All rights reserved.</span>
      </div>
    </footer>
  );
};

export default Footer;