import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);
  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="TechSolutions Inc. home">
          <span className={styles.logoMark}>TS</span>
          <div>
            <span className={styles.logoText}>TechSolutions Inc.</span>
            <span className={styles.logoSubtitle}>Cloud & Digital Transformation</span>
          </div>
        </Link>
        <button
          className={styles.burger}
          onClick={toggleMenu}
          aria-expanded={isMenuOpen}
          aria-label="Toggle navigation"
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`${styles.nav} ${isMenuOpen ? styles.open : ''}`}>
          <NavLink onClick={closeMenu} to="/" end className={({ isActive }) => (isActive ? styles.active : '')}>
            Home
          </NavLink>
          <NavLink onClick={closeMenu} to="/services" className={({ isActive }) => (isActive ? styles.active : '')}>
            Services
          </NavLink>
          <NavLink onClick={closeMenu} to="/about" className={({ isActive }) => (isActive ? styles.active : '')}>
            About
          </NavLink>
          <NavLink onClick={closeMenu} to="/contact" className={({ isActive }) => (isActive ? styles.active : '')}>
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;