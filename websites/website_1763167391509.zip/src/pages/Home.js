import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>TechSolutions Inc. | Strategic Cloud & Digital Transformation Consulting</title>
        <meta
          name="description"
          content="TechSolutions Inc. delivers cloud solutions, digital transformation, and IT consulting services that accelerate business optimization and innovation."
        />
        <meta
          name="keywords"
          content="cloud solutions, digital transformation, IT consulting, business optimization, TechSolutions Inc."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.tag}>Your strategic partner in digital evolution</span>
          <h1 className={styles.heading}>
            Transform your enterprise with intelligent cloud-first strategies.
          </h1>
          <p className={styles.subheading}>
            TechSolutions Inc. combines technical mastery, business insight, and human-centered design
            to deliver cloud solutions that accelerate innovation and measurable growth.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contact" className={styles.primaryButton}>
              Schedule a consultation
            </Link>
            <Link to="/services" className={styles.secondaryButton}>
              Explore services
            </Link>
          </div>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/seed/cloudconsult/720/520"
            alt="Team collaborating on cloud strategy"
          />
        </div>
      </section>

      <section className={styles.metrics}>
        <div>
          <span className={styles.metricValue}>250+</span>
          <span className={styles.metricLabel}>Successful digital programs</span>
        </div>
        <div>
          <span className={styles.metricValue}>98%</span>
          <span className={styles.metricLabel}>Client satisfaction rate</span>
        </div>
        <div>
          <span className={styles.metricValue}>20+</span>
          <span className={styles.metricLabel}>Industries empowered</span>
        </div>
      </section>

      <section className={styles.services}>
        <div className={styles.sectionHeader}>
          <span className={styles.kicker}>Services</span>
          <h2>Cloud-first services crafted for future-ready organizations</h2>
          <p>
            We partner with executive teams and technology leaders to orchestrate transformation across people,
            processes, and platforms, delivering sustainable competitive advantage.
          </p>
        </div>
        <div className={styles.serviceGrid}>
          <article>
            <div className={styles.icon}>☁️</div>
            <h3>Cloud Architecture & Migration</h3>
            <p>
              Design modern, secure, and scalable architectures while orchestrating seamless cloud migrations with minimal disruption.
            </p>
            <Link to="/services">Learn more</Link>
          </article>
          <article>
            <div className={styles.icon}>🧠</div>
            <h3>Digital Transformation Advisory</h3>
            <p>
              Align technology investments with business goals through roadmaps, governance frameworks, and change management expertise.
            </p>
            <Link to="/services">Learn more</Link>
          </article>
          <article>
            <div className={styles.icon}>🔒</div>
            <h3>Security & Compliance Enablement</h3>
            <p>
              Implement resilient security architectures, zero trust strategies, and compliance automation for regulated industries.
            </p>
            <Link to="/services">Learn more</Link>
          </article>
        </div>
      </section>

      <section className={styles.showcase}>
        <div className={styles.showcaseImage}>
          <img
            src="https://picsum.photos/seed/transformation/680/480"
            alt="Digital workflow optimization dashboard"
          />
        </div>
        <div className={styles.showcaseContent}>
          <span className={styles.kicker}>Why TechSolutions</span>
          <h2>Integrated teams that blend strategy, engineering, and adoption</h2>
          <ul>
            <li>
              Pragmatic, outcome-driven consulting grounded in enterprise best practices and emerging technology trends.
            </li>
            <li>
              Dedicated success teams aligned to your stakeholders to accelerate adoption and maximize ROI.
            </li>
            <li>
              Proven methodologies that prioritize security, compliance, and resilience at every stage.
            </li>
          </ul>
          <Link to="/about" className={styles.linkButton}>
            Discover our approach →
          </Link>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <span className={styles.kicker}>Client Stories</span>
          <h2>Trusted by leaders across industries</h2>
        </div>
        <div className={styles.testimonialGrid}>
          <figure>
            <blockquote>
              “TechSolutions Inc. delivered a scalable cloud platform that reduced our deployment times by 70%.
              Their collaborative mindset made them an extension of our team.”
            </blockquote>
            <figcaption>
              <strong>Elena Williams</strong>
              <span>CTO, Horizon Retail Group</span>
            </figcaption>
          </figure>
          <figure>
            <blockquote>
              “Their digital transformation roadmap aligned every executive stakeholder. We unlocked new revenue streams
              while keeping compliance at the forefront.”
            </blockquote>
            <figcaption>
              <strong>Marcus Reed</strong>
              <span>VP Operations, FinServe Capital</span>
            </figcaption>
          </figure>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Ready to unlock your next phase of growth?</h2>
          <p>
            Let&apos;s identify the high-impact initiatives that will modernize your technology landscape and elevate your customer experience.
          </p>
        </div>
        <Link to="/contact" className={styles.ctaButton}>
          Talk to our experts
        </Link>
      </section>
    </div>
  );
};

export default Home;