import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your full name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email address.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/i.test(formData.email)) {
      newErrors.email = 'Please enter a valid email.';
    }
    if (!formData.message.trim()) newErrors.message = 'Please describe your inquiry.';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormData(initialFormState);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact TechSolutions Inc. | Schedule a Consultation</title>
        <meta
          name="description"
          content="Contact TechSolutions Inc. to discuss cloud solutions, IT consulting, and digital transformation strategies tailored to your business."
        />
        <meta
          name="keywords"
          content="contact TechSolutions Inc., cloud consulting contact, schedule digital transformation consultation"
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Let&apos;s design your next breakthrough</h1>
        <p>
          Share your goals and challenges—we&apos;ll align the right experts to craft a tailored engagement plan.
          Our team responds within one business day.
        </p>
      </section>

      <section className={styles.content}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Full name *</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={!!errors.name}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>

          <div className={styles.field}>
            <label htmlFor="email">Work email *</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={!!errors.email}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>

          <div className={styles.field}>
            <label htmlFor="company">Company</label>
            <input
              id="company"
              name="company"
              type="text"
              value={formData.company}
              onChange={handleChange}
            />
          </div>

          <div className={styles.field}>
            <label htmlFor="message">How can we help? *</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={!!errors.message}
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </div>

          <button type="submit">Submit</button>
          {submitted && <p className={styles.success}>Thank you! We&apos;ll be in touch shortly.</p>}
        </form>

        <aside className={styles.info}>
          <div className={styles.card}>
            <h2>Contact details</h2>
            <ul>
              <li>
                <strong>Address:</strong> 123 Innovation Drive, Tech City, TC 10101
              </li>
              <li>
                <strong>Phone:</strong> <a href="tel:+15551234567">+1 (555) 123-4567</a>
              </li>
              <li>
                <strong>Email:</strong> <a href="mailto:info@techsolutions-inc.com">info@techsolutions-inc.com</a>
              </li>
            </ul>
          </div>

          <div className={styles.card}>
            <h2>Office hours</h2>
            <p>Monday – Friday: 8:00 AM – 6:00 PM (EST)</p>
            <p>Global delivery support available 24/7 for managed clients.</p>
          </div>

          <div className={styles.card}>
            <h2>Connect with us</h2>
            <p>
              Follow our insights on cloud innovation, platform engineering, and digital transformation best practices.
            </p>
          </div>
        </aside>
      </section>
    </div>
  );
};

export default Contact;