import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Cookie Policy | TechSolutions Inc.</title>
        <meta
          name="description"
          content="Understand how TechSolutions Inc. uses cookies and similar technologies to enhance user experiences and analyze performance."
        />
        <meta
          name="keywords"
          content="cookie policy, TechSolutions cookies, website cookies, analytics cookies"
        />
      </Helmet>

      <h1>Cookie Policy</h1>
      <p>Effective: January 2024</p>

      <section>
        <h2>1. What Are Cookies?</h2>
        <p>
          Cookies are small text files stored on your device when you visit a website. They help us remember your preferences,
          improve site performance, and deliver relevant content.
        </p>
      </section>

      <section>
        <h2>2. Types of Cookies We Use</h2>
        <ul>
          <li><strong>Essential cookies</strong> enable core site functionality such as page navigation and secure areas.</li>
          <li><strong>Analytics cookies</strong> help us understand how visitors interact with our site, enabling performance improvements.</li>
          <li><strong>Preference cookies</strong> store your choices so we can tailor future visits.</li>
        </ul>
      </section>

      <section>
        <h2>3. Managing Cookies</h2>
        <p>
          You can control cookies through your browser settings. Disabling certain cookies may impact your experience on our site.
        </p>
      </section>

      <section>
        <h2>4. Updates</h2>
        <p>
          We may update this policy to reflect changes in technology or regulatory requirements. Please revisit periodically for the latest information.
        </p>
      </section>

      <section>
        <h2>5. Contact</h2>
        <p>
          For questions about our use of cookies, contact us at <a href="mailto:info@techsolutions-inc.com">info@techsolutions-inc.com</a>.
        </p>
      </section>
    </div>
  );
};

export default CookiePolicy;