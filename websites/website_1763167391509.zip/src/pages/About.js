import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>About TechSolutions Inc. | IT Consulting Leadership</title>
        <meta
          name="description"
          content="Learn about TechSolutions Inc., an IT consulting firm focused on cloud solutions, digital transformation, and long-term partnerships."
        />
        <meta
          name="keywords"
          content="TechSolutions Inc. about, IT consulting team, cloud experts, digital transformation specialists"
        />
      </Helmet>

      <section className={styles.intro}>
        <div className={styles.introText}>
          <h1>Purpose-built teams delivering enterprise transformation</h1>
          <p>
            Founded by seasoned technology leaders, TechSolutions Inc. was created to bridge the gap between visionary strategy
            and executable delivery. Our consultants bring decades of experience guiding complex programs for Fortune 500 organizations
            and high-growth disruptors alike.
          </p>
        </div>
        <div className={styles.introImage}>
          <img
            src="https://picsum.photos/seed/team/660/480"
            alt="TechSolutions Inc. leadership collaborating"
          />
        </div>
      </section>

      <section className={styles.values}>
        <h2>Our operating principles</h2>
        <div className={styles.valueGrid}>
          <article>
            <h3>Partnership first</h3>
            <p>
              We embed with your stakeholders, enabling transparent collaboration and shared accountability for outcomes.
            </p>
          </article>
          <article>
            <h3>Outcome obsessed</h3>
            <p>
              Every engagement is anchored in measurable metrics that align to business value, not just technical deliverables.
            </p>
          </article>
          <article>
            <h3>Human centered</h3>
            <p>
              Sustainable transformation prioritizes people. We empower teams through enablement, change management, and design thinking.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.timeline}>
        <h2>A journey shaped by innovation</h2>
        <ul>
          <li>
            <span className={styles.year}>2014</span>
            <p>TechSolutions Inc. launches with a mission to modernize enterprise cloud strategy and governance.</p>
          </li>
          <li>
            <span className={styles.year}>2016</span>
            <p>Introduced comprehensive DevOps and automation practice delivering DevSecOps for regulated industries.</p>
          </li>
          <li>
            <span className={styles.year}>2019</span>
            <p>Expanded global presence with delivery hubs in North America and EMEA supporting 24/7 operations.</p>
          </li>
          <li>
            <span className={styles.year}>2022</span>
            <p>Launched data modernization studio, blending AI, analytics, and governance programs for enterprise clients.</p>
          </li>
        </ul>
      </section>

      <section className={styles.team}>
        <div className={styles.teamText}>
          <h2>Leadership committed to your success</h2>
          <p>
            Our leadership team combines backgrounds in engineering, enterprise architecture, cybersecurity, and organizational change.
            Their collective experience ensures that every engagement is delivered with precision and empathy.
          </p>
        </div>
        <div className={styles.teamCards}>
          <article>
            <img src="https://picsum.photos/seed/leader1/320/320" alt="Portrait of CEO Olivia Chen" />
            <h3>Olivia Chen</h3>
            <span>Chief Executive Officer</span>
          </article>
          <article>
            <img src="https://picsum.photos/seed/leader2/320/320" alt="Portrait of CTO Daniel Brooks" />
            <h3>Daniel Brooks</h3>
            <span>Chief Technology Officer</span>
          </article>
          <article>
            <img src="https://picsum.photos/seed/leader3/320/320" alt="Portrait of COO Priya Patel" />
            <h3>Priya Patel</h3>
            <span>Chief Operating Officer</span>
          </article>
        </div>
      </section>
    </div>
  );
};

export default About;