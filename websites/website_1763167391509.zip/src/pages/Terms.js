import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Terms of Use | TechSolutions Inc.</title>
        <meta
          name="description"
          content="Read the TechSolutions Inc. terms of use governing access to our website, services, and intellectual property."
        />
        <meta
          name="keywords"
          content="TechSolutions terms of use, website terms, consulting engagement terms"
        />
      </Helmet>

      <h1>Terms of Use</h1>
      <p>Effective: January 2024</p>

      <section>
        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing this website, you agree to comply with these Terms of Use and all applicable laws and regulations.
          If you do not agree with any term, you are prohibited from using or accessing this site.
        </p>
      </section>

      <section>
        <h2>2. Intellectual Property</h2>
        <p>
          All content on this site, including text, graphics, logos, and imagery, is the property of TechSolutions Inc. or its licensors.
          You may not reproduce, distribute, or modify materials without prior written consent.
        </p>
      </section>

      <section>
        <h2>3. Use License</h2>
        <p>
          Permission is granted to temporarily download one copy of the materials for personal, non-commercial transitory viewing.
          This license does not allow modifying, copying, or commercial usage of the materials.
        </p>
      </section>

      <section>
        <h2>4. Disclaimer</h2>
        <p>
          Materials on the TechSolutions Inc. website are provided “as is.” We make no warranties, expressed or implied,
          and hereby disclaim all other warranties including implied warranties of merchantability or fitness.
        </p>
      </section>

      <section>
        <h2>5. Limitations</h2>
        <p>
          In no event shall TechSolutions Inc. be liable for any damages arising out of the use or inability to use the materials on our website,
          even if we have been notified of the possibility of such damage.
        </p>
      </section>

      <section>
        <h2>6. Governing Law</h2>
        <p>
          These terms are governed by the laws of the jurisdiction in which TechSolutions Inc. operates, without regard to conflict of law provisions.
        </p>
      </section>
    </div>
  );
};

export default Terms;