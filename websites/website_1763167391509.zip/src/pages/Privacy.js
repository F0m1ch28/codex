import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Privacy Policy | TechSolutions Inc.</title>
        <meta
          name="description"
          content="Review the TechSolutions Inc. privacy policy detailing how we collect, use, and safeguard personal information."
        />
        <meta
          name="keywords"
          content="TechSolutions privacy policy, data protection, personal information, cloud consulting privacy"
        />
      </Helmet>

      <h1>Privacy Policy</h1>
      <p>Last updated: January 2024</p>

      <section>
        <h2>1. Overview</h2>
        <p>
          TechSolutions Inc. is committed to protecting the privacy of our clients, partners, and website visitors. This Privacy Policy outlines
          the types of information we collect, how we use it, and the rights available to you.
        </p>
      </section>

      <section>
        <h2>2. Information We Collect</h2>
        <ul>
          <li>Contact details such as name, email address, phone number, and company information.</li>
          <li>Usage analytics capturing interactions with our website and digital platforms.</li>
          <li>Communications including support inquiries, consultation requests, and feedback.</li>
        </ul>
      </section>

      <section>
        <h2>3. How We Use Information</h2>
        <p>We process personal data to:</p>
        <ul>
          <li>Deliver consulting services and support engagements.</li>
          <li>Respond to inquiries and provide requested resources.</li>
          <li>Improve website performance, security, and user experience.</li>
          <li>Communicate relevant updates, insights, and event invitations.</li>
        </ul>
      </section>

      <section>
        <h2>4. Data Sharing & Transfers</h2>
        <p>
          We do not sell personal information. We may share data with trusted service providers who assist in delivering our services,
          subject to confidentiality agreements and appropriate safeguards.
        </p>
      </section>

      <section>
        <h2>5. Data Retention</h2>
        <p>
          Personal information is retained for as long as necessary to fulfill the purposes outlined in this policy, comply with legal obligations,
          and resolve disputes.
        </p>
      </section>

      <section>
        <h2>6. Your Rights</h2>
        <p>Depending on your jurisdiction, you may have the right to:</p>
        <ul>
          <li>Access, correct, or delete your personal data.</li>
          <li>Opt out of marketing communications at any time.</li>
          <li>Request data portability or restriction of processing.</li>
        </ul>
        <p>
          To exercise these rights, contact us at <a href="mailto:info@techsolutions-inc.com">info@techsolutions-inc.com</a>.
        </p>
      </section>

      <section>
        <h2>7. Security</h2>
        <p>
          We implement administrative, technical, and physical controls designed to safeguard personal information from unauthorized access or misuse.
        </p>
      </section>

      <section>
        <h2>8. Updates</h2>
        <p>
          We may update this policy to reflect new practices or regulatory changes. Material updates will be communicated through our website or direct notification.
        </p>
      </section>
    </div>
  );
};

export default Privacy;