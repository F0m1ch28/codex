import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const servicesData = [
  {
    title: 'Cloud Adoption & Migration',
    description:
      'Assessment-driven strategy, landing zone design, and orchestration of migration waves to modernize infrastructure and applications.',
    bullets: [
      'Cloud readiness assessments & TCO analysis',
      'Landing zone design aligned with governance',
      'Migration factory execution and automation'
    ]
  },
  {
    title: 'Platform Engineering & DevOps',
    description:
      'Build reliable, automated delivery pipelines with infrastructure as code, observability, and continuous improvement.',
    bullets: [
      'Infrastructure as code with Terraform & Bicep',
      'CI/CD pipelines, GitOps, and site reliability',
      'Platform operating model and enablement'
    ]
  },
  {
    title: 'Data Modernization & Analytics',
    description:
      'Unlock real-time insights through modern data platforms, integration patterns, and advanced analytics capabilities.',
    bullets: [
      'Modern data warehousing and lakehouse design',
      'Real-time streaming and integration patterns',
      'AI/ML enablement and data governance'
    ]
  },
  {
    title: 'Security, Risk & Compliance',
    description:
      'Embed security by design with zero trust, identity governance, and automated compliance reporting.',
    bullets: [
      'Security architecture and threat modeling',
      'Zero trust adoption and identity management',
      'Regulatory compliance automation'
    ]
  },
  {
    title: 'Digital Strategy & Transformation',
    description:
      'Develop actionable roadmaps that align business priorities, customer journeys, and operating models.',
    bullets: [
      'Digital vision workshops and stakeholder alignment',
      'Customer experience optimization',
      'Change management and adoption strategies'
    ]
  },
  {
    title: 'Managed Cloud Optimization',
    description:
      'Continuous FinOps, performance optimization, and proactive support that keeps your cloud environment cost-effective and resilient.',
    bullets: [
      'Cost optimization and FinOps governance',
      'Performance tuning and observability',
      'Proactive incident response and support'
    ]
  }
];

const Services = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Cloud Solutions & IT Consulting Services | TechSolutions Inc.</title>
        <meta
          name="description"
          content="Explore TechSolutions Inc. services including cloud migration, DevOps, data modernization, security, and digital transformation consulting."
        />
        <meta
          name="keywords"
          content="cloud migration, DevOps, data modernization, IT consulting services, security compliance, digital strategy"
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Cloud solutions engineered for measurable business outcomes</h1>
        <p>
          Every engagement combines strategic advisory with hands-on expertise. From envisioning transformation to operating high-performing platforms,
          our specialists partner with you at each critical stage.
        </p>
      </section>

      <section className={styles.grid}>
        {servicesData.map((service) => (
          <article key={service.title}>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
            <ul>
              {service.bullets.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>
        ))}
      </section>

      <section className={styles.outcome}>
        <div className={styles.outcomeContent}>
          <h2>Outcomes you can expect</h2>
          <p>
            We measure our success by the impact we create: accelerated delivery cycles, resilient architecture, empowered teams, and elevated customer experiences.
            With TechSolutions Inc., transformation is not a buzzword—it is an orchestrated journey grounded in insights and execution excellence.
          </p>
        </div>
        <div className={styles.outcomeImage}>
          <img
            src="https://picsum.photos/seed/service/640/460"
            alt="Engineers working on digital infrastructure"
          />
        </div>
      </section>
    </div>
  );
};

export default Services;