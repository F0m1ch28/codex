document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const scrollBtn = document.getElementById('scrollTopButton');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAccept = document.getElementById('cookie-accept');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('open');
        });

        document.querySelectorAll('.nav-menu a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 320) {
                scrollBtn.classList.add('show');
            } else {
                scrollBtn.classList.remove('show');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    history.scrollRestoration = 'manual';
    window.scrollTo(0, 0);

    document.querySelectorAll('a.nav-link').forEach(link => {
        link.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'instant' }));
    });

    if (cookieBanner && cookieAccept) {
        const consent = localStorage.getItem('pdlCookieConsent');
        if (!consent) {
            cookieBanner.classList.add('show');
        }

        cookieAccept.addEventListener('click', () => {
            localStorage.setItem('pdlCookieConsent', 'accepted');
            cookieBanner.classList.remove('show');
        });
    }

    const yearSpan = document.getElementById('current-year');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});