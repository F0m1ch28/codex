import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.content}>
      <div className={styles.column}>
        <h3>Maravintolencia</h3>
        <p>
          Acompañamos a profesionales y familias mexicanas a descubrir el potencial práctico de la inteligencia artificial,
          con empatía y rigor.
        </p>
      </div>
      <div className={styles.column}>
        <h4>Explora</h4>
        <ul>
          <li>
            <Link to="/guia">Guía</Link>
          </li>
          <li>
            <Link to="/programas">Programas</Link>
          </li>
          <li>
            <Link to="/herramientas">Herramientas</Link>
          </li>
          <li>
            <Link to="/blog">Blog</Link>
          </li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4>Compañía</h4>
        <ul>
          <li>
            <Link to="/acerca-de">Acerca de</Link>
          </li>
          <li>
            <Link to="/contacto">Contacto</Link>
          </li>
          <li>
            <Link to="/legal">Legal</Link>
          </li>
          <li>
            <Link to="/terminos-de-uso">Términos de Uso</Link>
          </li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4>Privacidad</h4>
        <ul>
          <li>
            <Link to="/politica-de-privacidad">Política de Privacidad</Link>
          </li>
          <li>
            <Link to="/politica-de-cookies">Política de Cookies</Link>
          </li>
        </ul>
        <div className={styles.socials} aria-label="Redes sociales">
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
            in
          </a>
          <a href="https://www.twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
            tx
          </a>
          <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram">
            ig
          </a>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Maravintolencia. Todos los derechos reservados.</p>
    </div>
  </footer>
);

export default Footer;