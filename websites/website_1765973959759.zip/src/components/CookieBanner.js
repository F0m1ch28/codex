import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'maravintolencia_cookie_consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem(STORAGE_KEY, choice);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        Usamos cookies para mejorar tu experiencia. Consulta nuestra{' '}
        <Link to="/politica-de-cookies">Política de Cookies</Link>.
      </p>
      <div className={styles.actions}>
        <button type="button" onClick={() => handleChoice('accepted')} className={styles.accept}>
          Aceptar
        </button>
        <button type="button" onClick={() => handleChoice('rejected')} className={styles.reject}>
          Rechazar
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;