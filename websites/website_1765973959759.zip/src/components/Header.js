import { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  const navLinkClass = ({ isActive }) =>
    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink;

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <Link to="/" className={styles.brand} onClick={closeMenu} aria-label="Ir al inicio">
          <span className={styles.brandIcon}>✶</span>
          <div>
            <span className={styles.brandTitle}>Maravintolencia</span>
            <span className={styles.brandSubtitle}>IA con calidez mexicana</span>
          </div>
        </Link>
        <button
          type="button"
          className={styles.menuToggle}
          aria-controls="navegacion-principal"
          aria-expanded={menuOpen}
          onClick={toggleMenu}
        >
          <span className="sr-only">Abrir menú</span>
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
        </button>
        <nav
          id="navegacion-principal"
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Navegación principal"
        >
          <NavLink to="/guia" className={navLinkClass} onClick={closeMenu}>
            Guía
          </NavLink>
          <NavLink to="/programas" className={navLinkClass} onClick={closeMenu}>
            Programas
          </NavLink>
          <NavLink to="/herramientas" className={navLinkClass} onClick={closeMenu}>
            Herramientas
          </NavLink>
          <NavLink to="/blog" className={navLinkClass} onClick={closeMenu}>
            Blog
          </NavLink>
          <NavLink to="/acerca-de" className={navLinkClass} onClick={closeMenu}>
            Acerca de
          </NavLink>
          <NavLink to="/contacto" className={`${navLinkClass({ isActive: false })} ${styles.ctaLink}`} onClick={closeMenu}>
            Contacto
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;