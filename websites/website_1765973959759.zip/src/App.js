import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import ProgramasPage, { GuiaPage, HerramientasPage, BlogPage, LegalPage } from './pages/Services';
import Contact from './pages/Contact';
import TermsOfUse, { CookiesPolicy } from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';
import styles from './App.module.css';

function App() {
  return (
    <div className={styles.app}>
      <Header />
      <main className={styles.main} id="contenido-principal">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/guia" element={<GuiaPage />} />
          <Route path="/programas" element={<ProgramasPage />} />
          <Route path="/herramientas" element={<HerramientasPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/acerca-de" element={<About />} />
          <Route path="/contacto" element={<Contact />} />
          <Route path="/legal" element={<LegalPage />} />
          <Route path="/terminos-de-uso" element={<TermsOfUse />} />
          <Route path="/politica-de-privacidad" element={<PrivacyPolicy />} />
          <Route path="/politica-de-cookies" element={<CookiesPolicy />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
      <CookieBanner />
    </div>
  );
}

export default App;