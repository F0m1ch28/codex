import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './Programas.module.css';

const ProgramasPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Maravintolencia | Programas</title>
      <meta
        name="description"
        content="Conoce los programas de Maravintolencia para implementar algoritmos y asistentes de IA de forma responsable."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Programas de adopción inteligente</h1>
      <p>
        Diseñamos rutas de aprendizaje y despliegue que combinan algoritmos conversacionales, análisis predictivo y monitoreo
        humano continuo. Cada programa está pensado para crear confianza, medir impacto y evolucionar contigo.
      </p>
    </section>

    <section className={styles.grid}>
      <article className={styles.card}>
        <h3>Programa Amanecer</h3>
        <p>
          Fase inicial para descubrir casos de uso, mapear datos disponibles y establecer indicadores de bienestar digital.
        </p>
        <ul>
          <li>Diagnóstico de procesos clave</li>
          <li>Mapa de tareas asistibles</li>
          <li>Capacitación básica de equipo</li>
        </ul>
      </article>
      <article className={styles.card}>
        <h3>Programa Horizonte</h3>
        <p>
          Implementación de asistentes multicanal con modelos de lenguaje, paneles de control y protocolos de seguridad.
        </p>
        <ul>
          <li>Arquitectura de prompts</li>
          <li>Integración con herramientas existentes</li>
          <li>Monitoreo con comités de ética</li>
        </ul>
      </article>
      <article className={styles.card}>
        <h3>Programa Maíz Azul</h3>
        <p>
          Optimización continua con analítica avanzada, evaluación de impacto social y talleres de actualización trimestral.
        </p>
        <ul>
          <li>Modelos especializados por sector</li>
          <li>Paneles de seguimiento cultural</li>
          <li>Laboratorios creativos</li>
        </ul>
      </article>
    </section>

    <section className={styles.highlight}>
      <div>
        <h2>Valores que guían cada programa</h2>
        <p>
          Cada implementación se sostiene en principios de transparencia, co-creación y respeto por la diversidad lingüística
          y cultural de México.
        </p>
      </div>
      <Link to="/contacto" className={styles.cta}>
        Programa una sesión
      </Link>
    </section>
  </div>
);

export const GuiaPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Maravintolencia | Guía</title>
      <meta
        name="description"
        content="Guía completa de Maravintolencia para integrar asistentes de IA a tu rutina diaria con pasos claros."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Guía esencial de acompañamiento IA</h1>
      <p>
        Esta ruta te lleva desde la comprensión de tus necesidades hasta la medición del impacto que generan los asistentes de
        IA en tus actividades cotidianas.
      </p>
    </section>
    <ol className={styles.steps}>
      <li>
        <strong>Observa tu jornada.</strong> Registra tareas repetitivas, momentos de investigación y espacios creativos.
      </li>
      <li>
        <strong>Define intenciones claras.</strong> ¿Buscas claridad, eficiencia, inspiración o equilibrio? Ajusta la IA a ese
        propósito.
      </li>
      <li>
        <strong>Selecciona herramientas alineadas.</strong> Evalúa políticas de privacidad, soporte en español y facilidad de
        uso.
      </li>
      <li>
        <strong>Prototipa con seguridad.</strong> Empieza con escenarios controlados, documenta resultados y recopila feedback.
      </li>
      <li>
        <strong>Cultiva el aprendizaje continuo.</strong> Agenda revisiones periódicas para ajustar prompts, métricas y roles.
      </li>
    </ol>
    <section className={styles.highlight}>
      <div>
        <h2>Material descargable</h2>
        <p>
          Muy pronto compartiremos plantillas y bitácoras inspiradas en diseños de papel amate y bordados para que documentes tu
          avance con estilo propio.
        </p>
      </div>
      <Link to="/contacto" className={styles.cta}>
        Solicita una mentoría
      </Link>
    </section>
  </div>
);

export const HerramientasPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Maravintolencia | Herramientas</title>
      <meta
        name="description"
        content="Colección curada de herramientas de IA recomendadas por Maravintolencia para diferentes escenarios."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Herramientas seleccionadas con criterio humano</h1>
      <p>
        Evaluamos plataformas por su claridad de uso, respaldo comunitario, soporte en español y compromiso ético. Aquí una
        muestra de nuestras favoritas.
      </p>
    </section>
    <div className={styles.toolsGrid}>
      <article>
        <h3>Organización y agenda</h3>
        <p>
          Asistentes que generan resúmenes, priorizan tareas y envían recordatorios sin invadir tu privacidad.
        </p>
      </article>
      <article>
        <h3>Creatividad multimedia</h3>
        <p>
          Generadores de ideas visuales y sonoras, ideales para campañas que integran folklore, gastronomía o paisajes mexicanos.
        </p>
      </article>
      <article>
        <h3>Bienestar y autocuidado</h3>
        <p>
          Aplicaciones que ofrecen ejercicios de respiración, bitácoras de gratitud y seguimiento de hábitos saludables.
        </p>
      </article>
      <article>
        <h3>Aprendizaje y tutoría</h3>
        <p>
          Plataformas que adaptan explicaciones a distintos niveles educativos y fomentan la curiosidad en familia.
        </p>
      </article>
    </div>
  </div>
);

export const BlogPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Maravintolencia | Blog</title>
      <meta
        name="description"
        content="Publicaciones recientes de Maravintolencia sobre innovación en IA y experiencias mexicanas."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Blog: voces de innovación y comunidad</h1>
      <p>
        Historias, entrevistas y bitácoras de proyectos donde la IA acompaña procesos educativos, creativos y sociales en todo
        México.
      </p>
    </section>
    <div className={styles.blogGrid}>
      <article>
        <span className={styles.blogTag}>Narrativas</span>
        <h3>IA en las aulas rurales de Oaxaca</h3>
        <p>
          Cómo docentes integran asistentes para traducir conceptos científicos a lenguas originarias con apoyo comunitario.
        </p>
        <Link to="/contacto">Conversar con el equipo</Link>
      </article>
      <article>
        <span className={styles.blogTag}>Experiencias</span>
        <h3>Creatividad gastronómica asistida</h3>
        <p>
          Un recorrido por cocinas que combinan recetas tradicionales con generadores de ideas para menús innovadores.
        </p>
        <Link to="/contacto">Solicitar más detalles</Link>
      </article>
      <article>
        <span className={styles.blogTag}>Tendencias</span>
        <h3>Protocolos éticos para pymes mexicanas</h3>
        <p>
          Recomendaciones para resguardar datos sensibles mientras se adoptan asistentes de IA en negocios locales.
        </p>
        <Link to="/contacto">Agendar asesoría</Link>
      </article>
    </div>
  </div>
);

export const LegalPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Maravintolencia | Información Legal</title>
      <meta
        name="description"
        content="Información legal de Maravintolencia sobre uso del sitio, propiedad intelectual y responsabilidad."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Información legal de Maravintolencia</h1>
      <p>
        Este sitio es operado por Maravintolencia S.A.S. de C.V. con sede en Ciudad de México. La información publicada tiene
        fines educativos y busca orientar decisiones informadas sobre asistentes de IA.
      </p>
    </section>
    <div className={styles.legalBody}>
      <h2>Responsabilidad</h2>
      <p>
        Los contenidos se ofrecen como referencia y deben complementarse con la validación profesional adecuada. No nos
        hacemos responsables de decisiones tomadas sin supervisión especializada.
      </p>
      <h2>Propiedad intelectual</h2>
      <p>
        Los textos, ilustraciones y metodologías pertenecen a Maravintolencia. Puedes citarlos con atribución clara y enlace al
        sitio.
      </p>
      <h2>Comunicación</h2>
      <p>
        Para consultas legales escríbenos a <a href="mailto:legal@maravintolencia.site">legal@maravintolencia.site</a>.
      </p>
    </div>
  </div>
);

export default ProgramasPage;