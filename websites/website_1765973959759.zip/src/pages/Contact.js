import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    mensaje: '',
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.nombre.trim()) {
      newErrors.nombre = 'Ingresa tu nombre.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Ingresa tu correo electrónico.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Ingresa un correo válido.';
    }
    if (!formData.telefono.trim()) {
      newErrors.telefono = 'Ingresa tu número telefónico.';
    }
    if (!formData.mensaje.trim()) {
      newErrors.mensaje = 'Comparte cómo podemos ayudarte.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      setFormData({
        nombre: '',
        email: '',
        telefono: '',
        mensaje: '',
      });
    }, 1200);
  };

  return (
    <div className={styles.contact}>
      <Helmet>
        <title>Maravintolencia | Contacto</title>
        <meta
          name="description"
          content="Escríbenos para recibir acompañamiento personalizado en la integración de asistentes de IA."
        />
      </Helmet>
      <section className={styles.hero}>
        <div>
          <span className={styles.tag}>Contacto</span>
          <h1>Conversemos sobre tu próximo paso con la IA</h1>
          <p>
            Cuéntanos tu contexto y diseñaremos juntos un plan con inteligencia artificial que cuide la transparencia, la
            empatía y los resultados.
          </p>
          <ul>
            <li>Correo: hola@maravintolencia.site</li>
            <li>Teléfono: +52 (55) 1234 5678</li>
            <li>Dirección: Av. Revolución 123, CDMX</li>
          </ul>
        </div>
        <img
          src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=800&q=80"
          alt="Personas colaborando en un espacio creativo"
          loading="lazy"
        />
      </section>

      <section className={styles.formSection} aria-labelledby="formulario-contacto">
        <h2 id="formulario-contacto">Formulario de contacto</h2>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="nombre">
            Nombre
            <input
              id="nombre"
              name="nombre"
              type="text"
              placeholder="Tu nombre completo"
              value={formData.nombre}
              onChange={handleChange}
              aria-invalid={Boolean(errors.nombre)}
              aria-describedby={errors.nombre ? 'error-nombre' : undefined}
            />
            {errors.nombre && (
              <span className={styles.error} id="error-nombre">
                {errors.nombre}
              </span>
            )}
          </label>

          <label htmlFor="email">
            Correo electrónico
            <input
              id="email"
              name="email"
              type="email"
              placeholder="nombre@correo.com"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'error-email' : undefined}
            />
            {errors.email && (
              <span className={styles.error} id="error-email">
                {errors.email}
              </span>
            )}
          </label>

          <label htmlFor="telefono">
            Número telefónico
            <input
              id="telefono"
              name="telefono"
              type="tel"
              placeholder="Ej. +52 55 0000 0000"
              value={formData.telefono}
              onChange={handleChange}
              aria-invalid={Boolean(errors.telefono)}
              aria-describedby={errors.telefono ? 'error-telefono' : undefined}
            />
            {errors.telefono && (
              <span className={styles.error} id="error-telefono">
                {errors.telefono}
              </span>
            )}
          </label>

          <label htmlFor="mensaje">
            Mensaje
            <textarea
              id="mensaje"
              name="mensaje"
              rows="5"
              placeholder="Comparte objetivos, dudas o ideas clave."
              value={formData.mensaje}
              onChange={handleChange}
              aria-invalid={Boolean(errors.mensaje)}
              aria-describedby={errors.mensaje ? 'error-mensaje' : undefined}
            />
            {errors.mensaje && (
              <span className={styles.error} id="error-mensaje">
                {errors.mensaje}
              </span>
            )}
          </label>

          <button type="submit" disabled={isSubmitting} className={styles.submitButton}>
            {isSubmitting ? 'Enviando...' : 'Enviar'}
          </button>
          {submitted && <p className={styles.success}>Gracias por tu mensaje. Te contactaremos muy pronto.</p>}
        </form>
      </section>
    </div>
  );
};

export default Contact;