import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './About.module.css';

const About = () => (
  <div className={styles.about}>
    <Helmet>
      <title>Maravintolencia | Acerca de</title>
      <meta
        name="description"
        content="Conoce al equipo de Maravintolencia, nuestra misión y cómo diseñamos experiencias de IA centradas en las personas."
      />
    </Helmet>
    <section className={styles.hero}>
      <div>
        <span className={styles.tag}>Quiénes somos</span>
        <h1>Una casa creativa que abraza la IA con raíces mexicanas</h1>
        <p>
          Maravintolencia nace de la unión entre especialistas en tecnología, comunicadores y diseñadores que crecimos entre
          tradiciones y modernidad. Creemos que la inteligencia artificial puede ser cálida, transparente y profundamente
          humana.
        </p>
      </div>
      <img
        src="https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=800&q=80"
        alt="Equipo colaborando en una mesa"
        loading="lazy"
      />
    </section>

    <section className={styles.values}>
      <h2>Nuestro enfoque</h2>
      <div className={styles.valuesGrid}>
        <article>
          <h3>Curaduría ética</h3>
          <p>
            Seleccionamos herramientas de IA que respetan la privacidad y explicamos cada decisión con transparencia.
          </p>
        </article>
        <article>
          <h3>Diseño centrado en personas</h3>
          <p>
            Nuestros procesos inician siempre con historias de vida. Adaptamos la tecnología a contextos reales y diversos.
          </p>
        </article>
        <article>
          <h3>Cultura viva</h3>
          <p>
            Celebramos símbolos mexicanos como el papel picado o la música tradicional para inspirar experiencias memorables.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.team} aria-labelledby="equipo">
      <h2 id="equipo">Equipo de Maravintolencia</h2>
      <div className={styles.teamGrid}>
        <article className={styles.member}>
          <img
            src="https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80"
            alt="Retrato de Natalia García"
            loading="lazy"
          />
          <h3>Natalia García</h3>
          <p>Directora de Estrategia IA</p>
          <span>Especialista en experiencia de usuario y ética tecnológica.</span>
        </article>
        <article className={styles.member}>
          <img
            src="https://images.unsplash.com/photo-1544723795-3fb4501b3a11?auto=format&fit=crop&w=600&q=80"
            alt="Retrato de Marco Aguilar"
            loading="lazy"
          />
          <h3>Marco Aguilar</h3>
          <p>Arquitecto de Soluciones</p>
          <span>Diseña flujos conversacionales para educación y salud.</span>
        </article>
        <article className={styles.member}>
          <img
            src="https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&w=600&q=80"
            alt="Retrato de Fernanda Ruiz"
            loading="lazy"
          />
          <h3>Fernanda Ruiz</h3>
          <p>Líder de Formación</p>
          <span>Facilita talleres y mentorías con enfoque inclusivo.</span>
        </article>
      </div>
    </section>

    <section className={styles.mission}>
      <div>
        <h2>Nuestra misión</h2>
        <p>
          Empoderar a las personas para que la inteligencia artificial sea una aliada cotidiana, respetuosa y consciente del
          contexto latinoamericano. Queremos que la innovación amplifique tus fortalezas y no que te abrume.
        </p>
      </div>
      <div className={styles.cta}>
        <p>
          ¿Deseas conocer cómo integramos nuestros programas en tu organización o proyecto personal?
        </p>
        <Link to="/contacto">Coordinemos una reunión</Link>
      </div>
    </section>
  </div>
);

export default About;