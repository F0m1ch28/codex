import { Helmet } from 'react-helmet-async';
import styles from './Policies.module.css';

const TermsOfUse = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Maravintolencia | Términos de Uso</title>
      <meta
        name="description"
        content="Términos de uso de Maravintolencia para el acceso y utilización del sitio web y recursos asociados."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Términos de Uso</h1>
      <p>
        Al acceder a Maravintolencia aceptas los siguientes términos. Revisa esta sección periódicamente para mantenerte
        informado sobre cualquier actualización.
      </p>
    </section>
    <div className={styles.body}>
      <h2>Uso permitido</h2>
      <p>
        El contenido está destinado a orientar la integración de asistentes de IA en distintos contextos cotidianos. Puedes
        utilizarlo para fines personales o profesionales siempre que cites la fuente.
      </p>
      <h2>Conducta</h2>
      <p>
        No está permitido reutilizar el contenido para difundir información engañosa, ofrecer servicios fraudulentos o vulnerar
        derechos de terceros.
      </p>
      <h2>Modificaciones</h2>
      <p>
        Maravintolencia puede modificar estos términos en cualquier momento. Te recomendamos revisar esta página antes de usar
        el sitio.
      </p>
    </div>
  </div>
);

export const CookiesPolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Maravintolencia | Política de Cookies</title>
      <meta
        name="description"
        content="Política de cookies de Maravintolencia que detalla el uso de tecnologías de seguimiento y tus opciones."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Política de Cookies</h1>
      <p>
        Usamos cookies para analizar el rendimiento del sitio y personalizar contenidos. Puedes aceptar o rechazar estas
        tecnologías en cualquier momento.
      </p>
    </section>
    <div className={styles.body}>
      <h2>Tipos de cookies</h2>
      <ul>
        <li>
          <strong>Esenciales:</strong> Permiten la navegación y el funcionamiento básico del sitio.
        </li>
        <li>
          <strong>Analíticas:</strong> Nos ayudan a comprender cómo se utilizan las páginas para mejorar la experiencia.
        </li>
      </ul>
      <h2>Gestión</h2>
      <p>
        Puedes ajustar tus preferencias en el banner de cookies o configurando tu navegador. El rechazo puede limitar ciertas
        funcionalidades.
      </p>
      <h2>Contacto</h2>
      <p>
        Escríbenos a privacidad@maravintolencia.site para cualquier consulta vinculada con cookies.
      </p>
    </div>
  </div>
);

export default TermsOfUse;