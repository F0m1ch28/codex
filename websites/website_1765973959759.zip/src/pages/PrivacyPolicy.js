import { Helmet } from 'react-helmet-async';
import styles from './Policies.module.css';

const PrivacyPolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Maravintolencia | Política de Privacidad</title>
      <meta
        name="description"
        content="Política de privacidad de Maravintolencia sobre el tratamiento de datos personales y derechos de los usuarios."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Política de Privacidad</h1>
      <p>
        En Maravintolencia valoramos tu confianza. Esta política explica cómo recopilamos, usamos y protegemos tus datos
        personales.
      </p>
    </section>
    <div className={styles.body}>
      <h2>Datos que recopilamos</h2>
      <p>
        Recopilamos información proporcionada por ti al llenar formularios, como nombre, correo y teléfono, así como datos de
        navegación para mejorar el sitio.
      </p>
      <h2>Tratamiento de datos</h2>
      <p>
        Utilizamos los datos para responder consultas, enviar actualizaciones sobre nuestros programas y realizar análisis
        internos. No compartimos tu información con terceros sin tu consentimiento explícito.
      </p>
      <h2>Tus derechos</h2>
      <p>
        Puedes solicitar acceso, rectificación o eliminación de tus datos enviando un correo a privacidad@maravintolencia.site.
      </p>
      <h2>Conservación</h2>
      <p>
        Conservaremos los datos solo durante el tiempo necesario para los fines descritos o mientras lo exija la legislación
        aplicable.
      </p>
    </div>
  </div>
);

export default PrivacyPolicy;