import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const Home = () => (
  <div className={styles.home}>
    <Helmet>
      <title>Maravintolencia | Inicio</title>
      <meta
        name="description"
        content="Integra asistentes de IA en tu día a día con el acompañamiento cálido y experto de Maravintolencia."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <h1>Tu brújula confiable para asistentes de IA en la vida cotidiana</h1>
        <p>
          En Maravintolencia convertimos la innovación en hábitos humanos. Conectamos tu rutina con asistentes de
          inteligencia artificial que respetan tu estilo, tu cultura y tus objetivos.
        </p>
        <div className={styles.heroActions}>
          <Link className={styles.primaryCta} to="/guia">
            Explorar la Guía
          </Link>
          <Link className={styles.secondaryCta} to="/contacto">
            Agenda una conversación
          </Link>
        </div>
        <ul className={styles.heroHighlights} aria-label="Beneficios clave">
          <li>Metodologías probadas con talento mexicano</li>
          <li>Herramientas seleccionadas y actualizadas</li>
          <li>Casos reales en educación, salud, creatividad y más</li>
        </ul>
      </div>
      <div className={styles.heroImage}>
        <img
          src="https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=900&q=80"
          alt="Profesionales colaborando con tecnología"
          loading="lazy"
        />
      </div>
    </section>

    <section className={styles.intro}>
      <div className={styles.sectionHeading}>
        <span className={styles.sectionTag}>Visión</span>
        <h2>Inteligencia artificial con corazón humano</h2>
      </div>
      <p>
        Nuestra guía nace en México y honra su diversidad. Combinamos enfoques técnicos con referencias de nuestra cultura:
        desde la organización colectiva inspirada en el tejido comunitario hasta el diseño cálido de los talleres con
        tintes artesanales. El resultado es un mapa de ruta para mejorar tu bienestar digital sin perder lo que te hace
        único.
      </p>
    </section>

    <section className={styles.preview} aria-labelledby="resumen-secciones">
      <div className={styles.sectionHeading}>
        <span className={styles.sectionTag}>Descubre</span>
        <h2 id="resumen-secciones">Lo esencial de Maravintolencia</h2>
      </div>
      <div className={styles.previewGrid}>
        <article className={styles.previewCard}>
          <h3>Guía</h3>
          <p>Pasos a seguir para incorporar asistentes de IA en tu jornada desde la primera tarea del día hasta el cierre.</p>
          <Link to="/guia">Leer la guía</Link>
        </article>
        <article className={styles.previewCard}>
          <h3>Programas</h3>
          <p>Arquitecturas de IA, flujos conversacionales y protocolos de adaptación a distintos escenarios cotidianos.</p>
          <Link to="/programas">Revisar programas</Link>
        </article>
        <article className={styles.previewCard}>
          <h3>Herramientas</h3>
          <p>Aplicaciones seleccionadas por su ética, eficacia y facilidad de uso para familias, emprendedores y equipos.</p>
          <Link to="/herramientas">Ver herramientas</Link>
        </article>
        <article className={styles.previewCard}>
          <h3>Blog</h3>
          <p>Historias frescas sobre avances de IA, narradas con vocabulario claro y ejemplos latinoamericanos.</p>
          <Link to="/blog">Ir al blog</Link>
        </article>
      </div>
    </section>

    <section className={styles.benefits}>
      <div className={styles.sectionHeading}>
        <span className={styles.sectionTag}>Beneficios</span>
        <h2>Diseñado para acompañarte paso a paso</h2>
      </div>
      <ul className={styles.benefitList}>
        <li>
          <span className={styles.benefitIcon}>🌅</span>
          <div>
            <h4>Equilibrio humano-tecnológico</h4>
            <p>Protocolos que priorizan el criterio humano y la transparencia en cada decisión asistida.</p>
          </div>
        </li>
        <li>
          <span className={styles.benefitIcon}>🧭</span>
          <div>
            <h4>Rutas personalizadas</h4>
            <p>Diagnósticos que adaptan las herramientas de IA a tu profesión, ritmo de vida y valores personales.</p>
          </div>
        </li>
        <li>
          <span className={styles.benefitIcon}>🪅</span>
          <div>
            <h4>Cultura y pertenencia</h4>
            <p>Contenido inspirado en tradiciones mexicanas para que cada proceso se sienta cercano y lleno de significado.</p>
          </div>
        </li>
      </ul>
    </section>

    <section className={styles.useCases} aria-labelledby="casos-uso">
      <div className={styles.sectionHeading}>
        <span className={styles.sectionTag}>Aplicaciones</span>
        <h2 id="casos-uso">Casos cotidianos que transforman rutinas</h2>
      </div>
      <div className={styles.useCaseGrid}>
        <article>
          <h3>Educación con estructura flexible</h3>
          <p>
            Diseñamos agendas de estudio con asistentes que explican temas complejos en lenguaje sencillo, ideales para
            docentes y familias que acompañan tareas.
          </p>
        </article>
        <article>
          <h3>Productividad con sentido humano</h3>
          <p>
            Automatizamos recordatorios, reportes y resúmenes mientras preservamos el tiempo para la colaboración cara a
            cara.
          </p>
        </article>
        <article>
          <h3>Creatividad y artesanía digital</h3>
          <p>
            Plataformas de ideación que integran texturas inspiradas en tejidos o talavera para campañas con narrativa local.
          </p>
        </article>
        <article>
          <h3>Bienestar y autocuidado</h3>
          <p>
            Asistentes que ayudan a monitorear hábitos saludables, con recomendaciones enfocadas en balance y serenidad.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.testimonials} aria-labelledby="testimonios">
      <div className={styles.sectionHeading}>
        <span className={styles.sectionTag}>Historias reales</span>
        <h2 id="testimonios">Clientes que ya viven la IA con calma</h2>
      </div>
      <div className={styles.testimonialGrid}>
        <figure className={styles.testimonialCard}>
          <img
            src="https://i.pravatar.cc/120?img=32"
            alt="Retrato de Laura"
            loading="lazy"
          />
          <blockquote>
            “El equipo de Maravintolencia tradujo preguntas complejas en acciones sencillas. Nuestro colegio ahora usa IA sin
            perder el toque humano.”
          </blockquote>
          <figcaption>Laura Medina · Directora académica en Puebla</figcaption>
        </figure>
        <figure className={styles.testimonialCard}>
          <img
            src="https://i.pravatar.cc/120?img=12"
            alt="Retrato de Andrés"
            loading="lazy"
          />
          <blockquote>
            “Integramos asistentes conversacionales en nuestra agencia creativa y logramos procesos más ágiles y colaborativos.”
          </blockquote>
          <figcaption>Andrés Torres · Estratega creativo en CDMX</figcaption>
        </figure>
        <figure className={styles.testimonialCard}>
          <img
            src="https://i.pravatar.cc/120?img=47"
            alt="Retrato de Jimena"
            loading="lazy"
          />
          <blockquote>
            “Me guiaron para elegir herramientas accesibles y responsables. Ahora mi emprendimiento artesanal escala sin perder
            autenticidad.”
          </blockquote>
          <figcaption>Jimena Salgado · Fundadora de Casa Textil en Oaxaca</figcaption>
        </figure>
      </div>
    </section>

    <section className={styles.ctaSection}>
      <div className={styles.ctaContent}>
        <h2>Da el siguiente paso hacia una relación serena con la IA</h2>
        <p>
          Nuestro equipo está listo para ayudarte a priorizar procesos, elegir herramientas y formar a tu equipo o familia.
          Construyamos juntos un futuro donde la tecnología enriquezca tu día a día.
        </p>
        <Link to="/contacto" className={styles.ctaButton}>
          Hablemos hoy
        </Link>
      </div>
    </section>
  </div>
);

export default Home;