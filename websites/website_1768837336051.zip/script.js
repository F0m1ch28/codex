document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            const isOpen = navLinks.classList.toggle('is-open');
            document.body.classList.toggle('nav-open', isOpen);
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('is-open');
                document.body.classList.remove('nav-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');
    const consentKey = 'eathedscx-cookie-consent';

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);

        if (!storedConsent) {
            requestAnimationFrame(() => cookieBanner.classList.add('is-visible'));
        }

        const setConsent = (value) => {
            localStorage.setItem(consentKey, value);
            cookieBanner.classList.remove('is-visible');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => setConsent('accepted'));
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => setConsent('declined'));
        }
    }
});