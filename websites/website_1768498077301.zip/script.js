document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");
    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", (!expanded).toString());
            navLinks.classList.toggle("is-open");
        });
        navLinks.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 768) {
                    navLinks.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector(".cookie-accept");
        const declineBtn = cookieBanner.querySelector(".cookie-decline");
        const storedConsent = localStorage.getItem("soilbalingCookieConsent");
        if (storedConsent) {
            cookieBanner.classList.add("is-hidden");
        }

        const handleConsent = (choice, event) => {
            if (event) {
                event.preventDefault();
            }
            localStorage.setItem("soilbalingCookieConsent", choice);
            cookieBanner.classList.add("is-hidden");
        };

        if (acceptBtn) {
            acceptBtn.addEventListener("click", (event) => {
                handleConsent("accepted", event);
            });
        }
        if (declineBtn) {
            declineBtn.addEventListener("click", (event) => {
                handleConsent("declined", event);
            });
        }
    }
});