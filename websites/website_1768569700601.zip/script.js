document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', function () {
            const isOpen = primaryNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
            navToggle.textContent = isOpen ? 'Close Menu' : 'Menu';
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieAccept = document.querySelector('.cookie-accept');
    const cookieDecline = document.querySelector('.cookie-decline');
    const storageKey = 'frequeuhea-cookie-consent';

    if (cookieBanner) {
        const storedPreference = localStorage.getItem(storageKey);

        if (!storedPreference) {
            cookieBanner.classList.add('active');
        }

        const handleConsent = (value) => {
            localStorage.setItem(storageKey, value);
            cookieBanner.classList.remove('active');
        };

        if (cookieAccept) {
            cookieAccept.addEventListener('click', () => handleConsent('accepted'));
        }

        if (cookieDecline) {
            cookieDecline.addEventListener('click', () => handleConsent('declined'));
        }
    }
});