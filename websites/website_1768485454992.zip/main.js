document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!isExpanded).toString());
            navMenu.classList.toggle('is-open', !isExpanded);
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 1024) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    navMenu.classList.remove('is-open');
                }
            });
        });
    }

    const banner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('#cookie-accept');
    const declineBtn = document.querySelector('#cookie-decline');
    const consentStatus = localStorage.getItem('nighttcrrz_cookie_consent');

    if (banner && !consentStatus) {
        banner.classList.add('is-visible');
    }

    const handleConsent = (value) => {
        localStorage.setItem('nighttcrrz_cookie_consent', value);
        if (banner) {
            banner.classList.remove('is-visible');
        }
    };

    if (acceptBtn) {
        acceptBtn.addEventListener('click', () => handleConsent('accepted'));
    }

    if (declineBtn) {
        declineBtn.addEventListener('click', () => handleConsent('declined'));
    }
});