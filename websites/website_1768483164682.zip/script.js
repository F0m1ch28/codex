document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");
    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navMenu.classList.toggle("active");
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const cookieAccept = document.getElementById("cookie-accept");
    const cookieDecline = document.getElementById("cookie-decline");
    const cookieStorageKey = "cronicaCookiesPreference";

    if (cookieBanner && cookieAccept && cookieDecline) {
        const storedPreference = localStorage.getItem(cookieStorageKey);
        if (!storedPreference) {
            cookieBanner.classList.add("active");
        }

        cookieAccept.addEventListener("click", () => {
            localStorage.setItem(cookieStorageKey, "accepted");
            cookieBanner.classList.remove("active");
        });

        cookieDecline.addEventListener("click", () => {
            localStorage.setItem(cookieStorageKey, "declined");
            cookieBanner.classList.remove("active");
        });
    }

    const timelineItems = document.querySelectorAll(".timeline-item");
    if (timelineItems.length > 0) {
        const activateTimeline = () => {
            const triggerPoint = window.innerHeight * 0.8;
            timelineItems.forEach((item) => {
                const rect = item.getBoundingClientRect();
                if (rect.top < triggerPoint) {
                    item.classList.add("active");
                }
            });
        };
        activateTimeline();
        window.addEventListener("scroll", activateTimeline);
    }

    const modalTriggers = document.querySelectorAll("[data-modal-target]");
    const modals = document.querySelectorAll(".modal");
    modalTriggers.forEach((trigger) => {
        trigger.addEventListener("click", () => {
            const target = trigger.getAttribute("data-modal-target");
            const modal = document.querySelector(target);
            if (modal) {
                modal.classList.add("active");
                modal.setAttribute("aria-hidden", "false");
            }
        });
    });

    modals.forEach((modal) => {
        const closeBtn = modal.querySelector(".modal-close");
        if (closeBtn) {
            closeBtn.addEventListener("click", () => {
                modal.classList.remove("active");
                modal.setAttribute("aria-hidden", "true");
            });
        }
        modal.addEventListener("click", (event) => {
            if (event.target === modal) {
                modal.classList.remove("active");
                modal.setAttribute("aria-hidden", "true");
            }
        });
    });

    const faqItems = document.querySelectorAll(".faq-item");
    faqItems.forEach((item) => {
        const question = item.querySelector(".faq-question");
        const answer = item.querySelector(".faq-answer");
        if (question && answer) {
            question.addEventListener("click", () => {
                const isExpanded = question.getAttribute("aria-expanded") === "true";
                question.setAttribute("aria-expanded", String(!isExpanded));
                item.classList.toggle("active");
                if (!isExpanded) {
                    answer.style.maxHeight = answer.scrollHeight + "px";
                } else {
                    answer.style.maxHeight = null;
                }
            });
        }
    });

    const lightboxItems = document.querySelectorAll(".lightbox-item");
    const lightboxViewer = document.getElementById("lightbox-viewer");
    const lightboxImage = document.getElementById("lightbox-image");
    const lightboxCaption = document.getElementById("lightbox-caption");
    const lightboxClose = document.getElementById("lightbox-close");

    if (lightboxItems.length > 0 && lightboxViewer && lightboxImage && lightboxCaption && lightboxClose) {
        lightboxItems.forEach((item) => {
            item.addEventListener("click", () => {
                const img = item.querySelector("img");
                const caption = item.querySelector(".lightbox-caption-text");
                if (img) {
                    lightboxImage.src = img.src;
                    lightboxImage.alt = img.alt || "Elemento visual de IA";
                    lightboxCaption.textContent = caption ? caption.textContent : img.alt;
                    lightboxViewer.classList.add("active");
                }
            });
        });
        lightboxClose.addEventListener("click", () => {
            lightboxViewer.classList.remove("active");
        });
        lightboxViewer.addEventListener("click", (event) => {
            if (event.target === lightboxViewer) {
                lightboxViewer.classList.remove("active");
            }
        });
    }

    const animatedElements = document.querySelectorAll("[data-animate]");
    if ("IntersectionObserver" in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("animated");
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.18 });

        animatedElements.forEach((el) => observer.observe(el));
    } else {
        animatedElements.forEach((el) => el.classList.add("animated"));
    }
});