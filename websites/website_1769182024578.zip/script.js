document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const nav = document.getElementById('primary-navigation');
  const toggle = document.querySelector('.mobile-toggle');
  const toast = document.getElementById('globalToast');
  let toastTimeout;

  const closeNav = () => {
    if (nav) {
      nav.classList.remove('is-open');
    }
    if (toggle) {
      toggle.setAttribute('aria-expanded', 'false');
    }
    body.classList.remove('nav-open');
  };

  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', String(isOpen));
      body.classList.toggle('nav-open', isOpen);
    });

    const navLinks = nav.querySelectorAll('a');
    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        closeNav();
      });
    });
  }

  const revealElements = document.querySelectorAll('.reveal-on-scroll');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in-view');
            obs.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.15,
      }
    );
    revealElements.forEach((el) => observer.observe(el));
  } else {
    revealElements.forEach((el) => el.classList.add('in-view'));
  }

  const cookieBanner = document.getElementById('cookieBanner');
  if (cookieBanner) {
    const storedPreference = localStorage.getItem('cookiePreference');
    if (!storedPreference) {
      cookieBanner.classList.remove('is-hidden');
      cookieBanner.setAttribute('aria-hidden', 'false');
    }
    const cookieButtons = cookieBanner.querySelectorAll('button[data-choice]');
    cookieButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const choice = button.getAttribute('data-choice') || 'decline';
        localStorage.setItem('cookiePreference', choice);
        cookieBanner.classList.add('is-hidden');
        cookieBanner.setAttribute('aria-hidden', 'true');
        showToast('Setarea privind modulele cookie a fost salvată.');
      });
    });
  }

  const forms = document.querySelectorAll('form[data-form="contact"]');
  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      showToast('Mesajul a fost înregistrat. Redirecționăm pagina.');
      const target = form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        window.location.href = target;
      }, 1800);
    });
  });

  const yearSpans = document.querySelectorAll('.current-year');
  const currentYear = new Date().getFullYear();
  yearSpans.forEach((span) => {
    span.textContent = currentYear;
  });

  window.addEventListener('resize', () => {
    if (window.innerWidth >= 992) {
      closeNav();
    }
  });

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('is-visible');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
      toast.classList.remove('is-visible');
    }, 2600);
  }
});