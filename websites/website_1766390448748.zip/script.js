document.addEventListener('DOMContentLoaded', function () {
  const banner = document.querySelector('[data-banner]');
  const acceptBtn = document.querySelector('[data-accept-cookies]');
  const declineBtn = document.querySelector('[data-decline-cookies]');
  const consent = localStorage.getItem('neurosite_cookie_consent');

  if (!consent && banner) {
    requestAnimationFrame(() => banner.classList.add('visible'));
  }

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => {
      localStorage.setItem('neurosite_cookie_consent', 'accepted');
      banner.classList.remove('visible');
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => {
      localStorage.setItem('neurosite_cookie_consent', 'declined');
      banner.classList.remove('visible');
    });
  }

  const rotatingElements = document.querySelectorAll('[data-rotate]');
  rotatingElements.forEach((el) => {
    const phrases = JSON.parse(el.getAttribute('data-rotate') || '[]');
    if (!phrases.length) {
      return;
    }
    let index = 0;
    el.textContent = phrases[index];
    setInterval(() => {
      index = (index + 1) % phrases.length;
      el.textContent = phrases[index];
    }, 2600);
  });
});