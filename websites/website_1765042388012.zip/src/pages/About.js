import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './About.module.css';

const About = () => {
  return (
    <>
      <MetaTags
        title="О компании — эксперты по стратегическому развитию бизнеса"
        description="История компании, миссия, ценности и команда руководителей. Узнайте, почему нам доверяют крупнейшие бренды."
        canonical="https://www.компания.ru/o-kompanii"
        keywords="о компании, команда, миссия, ценности, история"
        openGraph={{
          title: 'О компании',
          description: 'Стратегический партнёр по развитию бизнеса: опыт, команда, ценности.',
          url: 'https://www.компания.ru/o-kompanii',
          image: 'https://picsum.photos/1200/630?random=61'
        }}
      />
      <section className={styles.hero}>
        <div className="container">
          <span className={styles.tag}>О нас</span>
          <h1>Мы создаем условия, в которых бизнес растёт быстрее рынка</h1>
          <p>
            Компания возникла как консалтинговое бюро, объединяющее практиков из индустрии. Сегодня наш портфель включает комплексные проекты по стратегии, цифровизации и маркетингу для клиентов во всей России и странах СНГ.
          </p>
        </div>
      </section>

      <section className={styles.missionSection}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div>
              <h2>Миссия</h2>
              <p>
                Помогать руководителям принимать смелые, но взвешенные решения, которые преобразуют бизнес и создают долгосрочную ценность. Мы верим в силу данных, сильных команд и честного партнерства.
              </p>
            </div>
            <div>
              <h2>Ценности</h2>
              <ul className={styles.valuesList}>
                <li><strong>Ответственность:</strong> доводим проекты до результата и разделяем риски.</li>
                <li><strong>Прозрачность:</strong> работаем открыто, опираемся на цифры, регулярно докладываем о прогрессе.</li>
                <li><strong>Инновации:</strong> тестируем лучшие практики и интегрируем технологии, которые работают.</li>
                <li><strong>Команда:</strong> создаём доверительные отношения и поддерживаем развитие экспертов.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.timelineSection}>
        <div className="container">
          <h2>Этапы развития</h2>
          <div className={styles.timeline}>
            <div className={styles.timelineItem}>
              <span className={styles.timelineYear}>2010</span>
              <p>Основание компании бывшими руководителями стратегических департаментов крупных корпораций.</p>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.timelineYear}>2014</span>
              <p>Выход в сегмент цифровой трансформации: внедрение аналитических платформ и CRM.</p>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.timelineYear}>2018</span>
              <p>Создание отраслевых практик и запуск собственных исследований по рынку.</p>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.timelineYear}>2022</span>
              <p>Формирование проектных офисов и сервисов поддержки изменений у клиентов.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <h2>Руководящая команда</h2>
          <div className={styles.teamGrid}>
            {[
              {
                name: 'Екатерина Логинова',
                role: 'Управляющий партнёр',
                image: 'https://picsum.photos/500/500?random=71',
                description: 'Ранее возглавляла стратегический блок международной консалтинговой компании, запускала программы трансформации для ритейла и финансовых институтов.'
              },
              {
                name: 'Игорь Кравченко',
                role: 'Директор по развитию бизнеса',
                image: 'https://picsum.photos/500/500?random=72',
                description: '15 лет в управлении продажами и маркетингом, специализируется на построении цифрового клиентского опыта и омниканальных стратегиях.'
              },
              {
                name: 'Светлана Михайлова',
                role: 'Партнёр по людям и культуре',
                image: 'https://picsum.photos/500/500?random=73',
                description: 'Эксперт по оргдизайну и разработке корпоративных культур. Создаёт программы обучения и поддержки изменений для команд клиентов.'
              }
            ].map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.factSection}>
        <div className="container">
          <h2>Факты о компании</h2>
          <div className={styles.factsGrid}>
            <div>
              <strong>75%</strong>
              <p>клиентов приходят по рекомендациям партнеров и коллег</p>
            </div>
            <div>
              <strong>40+</strong>
              <p>аналитических исследований в портфеле, которые помогают принимать решения</p>
            </div>
            <div>
              <strong>120</strong>
              <p>экспертов и менеджеров проекта подключаем в зависимости от задач</p>
            </div>
            <div>
              <strong>24/7</strong>
              <p>поддержка ключевых инициатив и оперативных вопросов</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.cultureSection}>
        <div className="container">
          <h2>Корпоративная культура</h2>
          <p>
            Мы поддерживаем культуру открытой обратной связи, развиваем внутри команды компетенции наставничества и кросс-отраслевые комитеты. Особое внимание уделяем развитию молодых специалистов и R&amp;D-направлению, чтобы постоянно пополнять набор инструментов для наших клиентов.
          </p>
        </div>
      </section>
    </>
  );
};

export default About;