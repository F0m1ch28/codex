import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './Legal.module.css';

const CookiePolicy = () => {
  return (
    <>
      <MetaTags
        title="Политика использования cookie"
        description="Информация о применении файлов cookie на сайте компании, целях и способах управления."
        canonical="https://www.компания.ru/politika-cookie"
        keywords="cookie, политика cookie, файлы cookie"
        openGraph={{
          title: 'Политика использования cookie',
          description: 'Узнайте, какие cookie мы используем и как можно управлять настройками.',
          url: 'https://www.компания.ru/politika-cookie',
          image: 'https://picsum.photos/1200/630?random=123'
        }}
      />
      <article className={styles.legal}>
        <div className="container">
          <h1>Политика использования cookie</h1>
          <p>Дата обновления: 20 апреля 2024 года</p>
          <section>
            <h2>1. Что такое cookie</h2>
            <p>
              Cookie — это небольшие файлы, которые сохраняются на устройстве пользователя. Они помогают улучшать работу сайта, анализировать статистику и персонализировать контент.
            </p>
          </section>
          <section>
            <h2>2. Какие cookie мы используем</h2>
            <ul>
              <li>Технические — обеспечивают корректную работу сайта.</li>
              <li>Аналитические — помогают понимать поведение посетителей и улучшать сервис.</li>
              <li>Функциональные — запоминают пользовательские настройки.</li>
            </ul>
          </section>
          <section>
            <h2>3. Как управлять cookie</h2>
            <p>
              Пользователь может изменить настройки cookie в браузере или удалить файлы вручную. Учтите, что отключение cookie может повлиять на функциональность сайта.
            </p>
          </section>
          <section>
            <h2>4. Контакты</h2>
            <p>По вопросам использования cookie напишите на info@компания.ru.</p>
          </section>
        </div>
      </article>
    </>
  );
};

export default CookiePolicy;