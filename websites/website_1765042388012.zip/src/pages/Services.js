import React, { useState } from 'react';
import MetaTags from '../components/MetaTags';
import styles from './Services.module.css';

const servicesData = [
  {
    id: 'strategy',
    title: 'Стратегический консалтинг',
    summary: 'Разработка стратегии, операционных моделей и финансовых сценариев.',
    details: [
      'Диагностика текущей бизнес-модели и конкурентной среды',
      'Проектирование целевой операционной модели и KPI',
      'Финансовое моделирование и сценарный подход',
      'Разработка дорожной карты и контрольных точек'
    ],
    benefits: 'Повышаем управляемость бизнеса, сокращаем издержки и ускоряем рост за счет ясной стратегии.'
  },
  {
    id: 'digital',
    title: 'Цифровая трансформация',
    summary: 'Внедрение цифровых продуктов, аналитики и автоматизация процессов.',
    details: [
      'Оцифровка ключевых процессов и клиентских путешествий',
      'Выбор и внедрение CRM, ERP и BPM-систем',
      'Интеграция BI-платформ, настройка управленческих дашбордов',
      'Подготовка команды и change management'
    ],
    benefits: 'Создаем прозрачность данных и сокращаем время принятия решений, повышаем удовлетворенность клиентов.'
  },
  {
    id: 'marketing',
    title: 'Маркетинг и бренд',
    summary: 'Комплексное позиционирование, коммуникации и performance-маркетинг.',
    details: [
      'Исследование аудитории и конкурентного ландшафта',
      'Разработка платформы бренда и tone of voice',
      'Медиапланирование и performance-кампании',
      'Обучение внутренних команд и передача инструментов'
    ],
    benefits: 'Укрепляем восприятие бренда, увеличиваем лидогенерацию и выстраиваем омниканальный маркетинг.'
  },
  {
    id: 'change',
    title: 'Управление изменениями',
    summary: 'Сопровождение трансформаций, программы обучения и развитие культуры.',
    details: [
      'Анализ зрелости команды и готовности к изменениям',
      'Разработка коммуникационной стратегии изменений',
      'Организация проектного офиса и agile-практик',
      'Наставничество, обучение лидеров и сотрудников'
    ],
    benefits: 'Повышаем вовлеченность и скорость адаптации, формируем культуру непрерывных улучшений.'
  },
  {
    id: 'analytics',
    title: 'Бизнес-аналитика и исследования',
    summary: 'Маркетинговые исследования, прогнозирование и конкурентная разведка.',
    details: [
      'Сбор и анализ отраслевых данных, построение прогнозов',
      'Оценка потенциала рынков и продуктовых ниш',
      'Выявление инсайтов по поведению клиентов',
      'Подготовка аналитических отчетов для руководства'
    ],
    benefits: 'Помогаем принимать решения на основе данных, снижать риски и открывать новые источники дохода.'
  }
];

const Services = () => {
  const [activeServiceId, setActiveServiceId] = useState('strategy');
  const activeService = servicesData.find(({ id }) => id === activeServiceId) || servicesData[0];

  return (
    <>
      <MetaTags
        title="Услуги компании — стратегия, трансформация, маркетинг"
        description="Профессиональные услуги: стратегический консалтинг, цифровая трансформация, маркетинг, управление изменениями и аналитика."
        canonical="https://www.компания.ru/uslugi"
        keywords="услуги, консалтинг, цифровая трансформация, маркетинг, управление изменениями, бизнес-аналитика"
        openGraph={{
          title: 'Услуги компании',
          description: 'Комплексные решения по стратегии, цифровизации, маркетингу и управлению изменениями.',
          url: 'https://www.компания.ru/uslugi',
          image: 'https://picsum.photos/1200/630?random=81'
        }}
      />
      <section className={styles.hero}>
        <div className="container">
          <span className={styles.tag}>Наши услуги</span>
          <h1>Помогаем бизнесу достигать значимых результатов</h1>
          <p>
            Мы подбираем сочетание стратегических, технологических и маркетинговых инструментов, чтобы решить конкретные задачи клиента. Каждый проект сопровождают партнеры и профильные эксперты.
          </p>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <div className={styles.layout}>
            <nav className={styles.sidebar} aria-label="Навигация по услугам">
              <ul>
                {servicesData.map((service) => (
                  <li key={service.id}>
                    <button
                      type="button"
                      className={`${styles.sidebarButton} ${service.id === activeServiceId ? styles.sidebarButtonActive : ''}`}
                      onClick={() => setActiveServiceId(service.id)}
                    >
                      {service.title}
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
            <article className={styles.serviceDetail}>
              <header>
                <h2>{activeService.title}</h2>
                <p className={styles.summary}>{activeService.summary}</p>
              </header>
              <div className={styles.detailGrid}>
                <div>
                  <h3>Что входит</h3>
                  <ul className={styles.detailList}>
                    {activeService.details.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3>Какой результат вы получаете</h3>
                  <p>{activeService.benefits}</p>
                  <div className={styles.ctaBox}>
                    <p>Нужна консультация по этому направлению?</p>
                    <a className="primaryButton" href={`mailto:info@компания.ru?subject=${encodeURIComponent(`Запрос по услуге: ${activeService.title}`)}`}>
                      Обсудить проект
                    </a>
                  </div>
                </div>
              </div>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;