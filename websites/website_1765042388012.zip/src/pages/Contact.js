import React, { useState } from 'react';
import MetaTags from '../components/MetaTags';
import styles from './Contact.module.css';

const Contact = () => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formState.name.trim()) newErrors.name = 'Пожалуйста, укажите ваше имя.';
    if (!formState.email.trim()) {
      newErrors.email = 'Введите email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formState.email)) {
      newErrors.email = 'Укажите корректный email.';
    }
    if (!formState.message.trim()) newErrors.message = 'Напишите, какой вопрос вас интересует.';
    return newErrors;
  };

  const handleChange = (field) => (event) => {
    setFormState((prev) => ({ ...prev, [field]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setIsSubmitted(true);
      setFormState({ name: '', email: '', message: '' });
      setTimeout(() => setIsSubmitted(false), 8000);
    }
  };

  return (
    <>
      <MetaTags
        title="Контакты компании — свяжитесь с нами"
        description="Свяжитесь с командой компании: адрес офиса в Москве, телефон, email. Отправьте запрос через форму и мы ответим в течение рабочего дня."
        canonical="https://www.компания.ru/kontakty"
        keywords="контакты, адрес, телефон, email, форма обратной связи"
        openGraph={{
          title: 'Контакты компании',
          description: 'Напишите или позвоните нам, чтобы обсудить задачи вашего бизнеса.',
          url: 'https://www.компания.ru/kontakty',
          image: 'https://picsum.photos/1200/630?random=91'
        }}
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Связаться с нами</h1>
          <p>Расскажите о цели проекта — мы предложим формат сотрудничества и подключим профильных экспертов.</p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.formWrapper}>
              <h2>Форма обратной связи</h2>
              <p>Ответим в течение одного рабочего дня.</p>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label>
                  Имя
                  <input
                    type="text"
                    name="name"
                    value={formState.name}
                    onChange={handleChange('name')}
                    aria-required="true"
                    aria-invalid={Boolean(errors.name)}
                  />
                  {errors.name && <span className={styles.error}>{errors.name}</span>}
                </label>
                <label>
                  Email
                  <input
                    type="email"
                    name="email"
                    value={formState.email}
                    onChange={handleChange('email')}
                    aria-required="true"
                    aria-invalid={Boolean(errors.email)}
                  />
                  {errors.email && <span className={styles.error}>{errors.email}</span>}
                </label>
                <label>
                  Сообщение
                  <textarea
                    name="message"
                    rows="5"
                    value={formState.message}
                    onChange={handleChange('message')}
                    aria-required="true"
                    aria-invalid={Boolean(errors.message)}
                  />
                  {errors.message && <span className={styles.error}>{errors.message}</span>}
                </label>
                <button type="submit" className="primaryButton">Отправить</button>
                {isSubmitted && <div className={styles.success}>Спасибо! Мы свяжемся с вами в ближайшее время.</div>}
              </form>
            </div>
            <aside className={styles.infoCard}>
              <h2>Контактная информация</h2>
              <ul className={styles.infoList}>
                <li>
                  <strong>Адрес офиса</strong>
                  <span>ул. Примерная, д. 10, Москва, 101000</span>
                </li>
                <li>
                  <strong>Телефон</strong>
                  <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </li>
                <li>
                  <strong>Email</strong>
                  <a href="mailto:info@компания.ru">info@компания.ru</a>
                </li>
                <li>
                  <strong>Работаем</strong>
                  <span>пн—пт: 09:00–19:00</span>
                </li>
              </ul>
              <div className={styles.mapWrapper} aria-hidden="true">
                <iframe
                  title="Карта расположения офиса компании в Москве"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.276663578134!2d37.62039397722544!3d55.7519999730724!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46b54a5a51a1406d%3A0x3a25feadc177a64e!2z0JzQvtGB0LrQstCw0YAg0JzQvtC00L7QuQ!5e0!3m2!1sru!2sru!4v1713615342001!5m2!1sru!2sru"
                  width="100%"
                  height="220"
                  style={{ border: 0 }}
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;