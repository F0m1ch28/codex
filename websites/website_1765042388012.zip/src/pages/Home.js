import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import MetaTags from '../components/MetaTags';
import styles from './Home.module.css';

const Home = () => {
  const stats = [
    { value: '15+', label: 'лет опыта в консалтинге и управлении' },
    { value: '220', label: 'успешных проектов в России и СНГ' },
    { value: '35%', label: 'средний рост эффективности клиентов' },
    { value: '98%', label: 'уровень удовлетворенности партнеров' }
  ];

  const services = [
    {
      title: 'Стратегический консалтинг',
      description: 'Диагностика бизнеса, разработка стратегии роста, модель управления и прозрачные KPI.'
    },
    {
      title: 'Цифровая трансформация',
      description: 'Оцифровка процессов, внедрение CRM и ERP систем, интеграция аналитики в реальном времени.'
    },
    {
      title: 'Маркетинг и бренд',
      description: 'Формирование позиционирования, коммуникационных стратегий и performance-маркетинг.'
    },
    {
      title: 'Управление изменениями',
      description: 'Обучение команд, agile-подходы, сопровождение изменений и поддержка внедрения.'
    }
  ];

  const advantages = [
    'Глубокая экспертиза в 14 отраслях и собственные отраслевые аналитики.',
    'Прозрачные процессы и детализированная отчетность на каждом этапе.',
    'Команда практиков с опытом работы в крупнейших компаниях страны.',
    'Фокус на измеримом результате и долгосрочном партнерстве.'
  ];

  const process = [
    { step: '01', title: 'Исследуем ваш контекст', text: 'Собираем данные, изучаем рынок, определяем ключевые точки роста.' },
    { step: '02', title: 'Формируем стратегию', text: 'Создаем дорожную карту изменений, финансовые модели и показатели успеха.' },
    { step: '03', title: 'Запускаем трансформацию', text: 'Реализуем проект совместно с вашей командой, подключаем экспертов.' },
    { step: '04', title: 'Измеряем результат', text: 'Проводим контрольные замеры, оптимизируем решения, готовим масштабирование.' },
    { step: '05', title: 'Передаём компетенции', text: 'Обучаем сотрудников, создаем регламенты и закрепляем изменения.' }
  ];

  const projects = [
    {
      id: 1,
      title: 'Комплексная трансформация холдинга',
      category: 'Консалтинг',
      description: 'Повышение эффективности операционных процессов и финансовое моделирование.',
      image: 'https://picsum.photos/1200/800?random=41',
      impact: 'ROI +28% за 8 месяцев'
    },
    {
      id: 2,
      title: 'Внедрение цифровой аналитической платформы',
      category: 'Цифровизация',
      description: 'Создание центра данных и подключение BI-аналитики для принятия решений.',
      image: 'https://picsum.photos/1200/800?random=42',
      impact: 'Сокращение управленческих циклов на 35%'
    },
    {
      id: 3,
      title: 'Ребрендинг и перезапуск маркетинга',
      category: 'Маркетинг',
      description: 'Разработка нового позиционирования и запуск интегрированных кампаний.',
      image: 'https://picsum.photos/1200/800?random=43',
      impact: 'Рост узнаваемости бренда на 42%'
    }
  ];

  const testimonials = [
    {
      quote: 'Команда «Компании» провела глубокий аудит наших бизнес-процессов и предложила нестандартные решения. Мы получили понятную стратегию и сопровождение по внедрению — результат превзошёл ожидания.',
      name: 'Ирина Колесникова',
      role: 'Генеральный директор, «СеверСтрой Инвест»'
    },
    {
      quote: 'За счёт внедрения цифровой аналитики мы начали принимать решения быстрее и точнее. Эксперты компании оперативно реагировали на запросы, помогали команде адаптироваться к изменениям.',
      name: 'Алексей Малыгин',
      role: 'Директор по развитию, «ТехноЛаб»'
    },
    {
      quote: 'Структурировали маркетинг и коммуникации, выстроили единый клиентский опыт. Продажи выросли на 24%, а команда научилась работать с данными и KPI.',
      name: 'Виктория Соколова',
      role: 'Руководитель маркетинга, «Retail Prime»'
    }
  ];

  const faqItems = [
    {
      question: 'С какими компаниями вы работаете?',
      answer: 'Нашу экспертизу ценят средние и крупные компании в производстве, девелопменте, финансовом секторе, ритейле и IT. Мы адаптируем решения под отраслевую специфику.'
    },
    {
      question: 'Сколько времени занимает проект?',
      answer: 'Длительность зависит от масштаба: диагностический sprint занимает 3–4 недели, комплексная трансформация — от 4 до 12 месяцев с промежуточными результатами.'
    },
    {
      question: 'Можете ли вы подключиться на отдельный этап?',
      answer: 'Да. Мы можем провести аудит, разработать стратегию, внедрить цифровые инструменты или помочь с управлением изменениями на выбранной стадии.'
    },
    {
      question: 'Как построена работа с вашей командой?',
      answer: 'Назначается проектный офис, согласовывается план и KPI. Проводим регулярные сессии с ключевыми участниками, ведём прозрачную отчетность и передаём документацию.'
    }
  ];

  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [expandedFaq, setExpandedFaq] = useState(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const filteredProjects = useMemo(() => {
    if (selectedCategory === 'Все') {
      return projects;
    }
    return projects.filter((project) => project.category === selectedCategory);
  }, [selectedCategory, projects]);

  const organizationSchema = JSON.stringify({
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Компания',
    url: 'https://www.компания.ru',
    logo: 'https://picsum.photos/200/200?random=99',
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'ул. Примерная, д. 10',
      addressLocality: 'Москва',
      postalCode: '101000',
      addressCountry: 'RU'
    },
    contactPoint: [
      {
        '@type': 'ContactPoint',
        telephone: '+7-495-123-45-67',
        contactType: 'customer service',
        areaServed: 'RU'
      }
    ]
  });

  return (
    <>
      <MetaTags
        title="Компания — бизнес-решения для роста"
        description="Комплексные консалтинговые и цифровые решения для развития бизнеса: стратегия, трансформация, маркетинг и управление изменениями."
        canonical="https://www.компания.ru/"
        keywords="бизнес консалтинг, стратегия, цифровая трансформация, маркетинг, управление изменениями"
        openGraph={{
          title: 'Компания — бизнес-решения для роста',
          description: 'Создаем стратегию, внедряем цифровые инструменты и выводим бизнес на новый уровень.',
          url: 'https://www.компания.ru/',
          image: 'https://picsum.photos/1200/630?random=22'
        }}
        schema={organizationSchema}
      />
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div className={styles.heroTag}>Ваш партнер в устойчивом развитии</div>
            <h1 className={styles.heroTitle}>
              Комплексные бизнес-решения, которые упрощают стратегию и ускоряют рост
            </h1>
            <p className={styles.heroSubtitle}>
              Мы объединяем управленческую экспертизу, аналитику и технологии, чтобы трансформировать бизнес-модель, процессы и клиентский опыт.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className="primaryButton">Консультация эксперта</Link>
              <Link to="/uslugi" className="secondaryButton">Наши направления</Link>
            </div>
            <div className={styles.heroStats}>
              {stats.map((stat) => (
                <div key={stat.label} className={styles.heroStat}>
                  <span className={styles.heroStatValue}>{stat.value}</span>
                  <span className={styles.heroStatLabel}>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.aboutSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>Кто мы</span>
            <h2 className="sectionTitle">Эксперты, которые соединяют стратегию, технологии и людей</h2>
            <p className="sectionSubtitle">
              Мы выстраиваем систему роста: от диагностики и планирования до внедрения изменений и обучения команд. Работаем открыто, опираемся на данные и гарантируем практический результат.
            </p>
          </div>
          <div className={styles.advantagesGrid}>
            {advantages.map((item) => (
              <article key={item} className={styles.advantageCard}>
                <div className={styles.advantageIcon} aria-hidden="true">★</div>
                <p>{item}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>Что мы делаем</span>
            <h2 className="sectionTitle">Ключевые направления работы</h2>
            <p className="sectionSubtitle">
              Формируем индивидуальную команду под задачи клиента, подключаем отраслевых экспертов и обеспечиваем доступ к аналитике рынка.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceIcon} aria-hidden="true">▹</div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/uslugi" className={styles.serviceLink} aria-label={`Подробнее про услугу ${service.title}`}>
                  Подробнее →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>Как мы работаем</span>
            <h2 className="sectionTitle">Прозрачный путь от идеи до результата</h2>
          </div>
          <div className={styles.processTimeline}>
            {process.map((item) => (
              <div key={item.step} className={styles.processStep}>
                <span className={styles.processNumber}>{item.step}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <div>
              <span className={styles.sectionTag}>Кейсы</span>
              <h2 className="sectionTitle">Практический эффект для клиентов</h2>
            </div>
            <div className={styles.filters}>
              {['Все', 'Консалтинг', 'Цифровизация', 'Маркетинг'].map((category) => (
                <button
                  type="button"
                  key={category}
                  className={`${styles.filterButton} ${selectedCategory === category ? styles.filterActive : ''}`}
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <figure className={styles.projectImageWrapper}>
                  <img src={project.image} alt={`Проект: ${project.title}`} loading="lazy" />
                </figure>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <div className={styles.projectImpact}>{project.impact}</div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <div className={styles.testimonialWrapper}>
            <div className={styles.sectionHeader}>
              <span className={styles.sectionTag}>Отзывы</span>
              <h2 className="sectionTitle">Что говорят наши клиенты</h2>
            </div>
            <div className={styles.testimonialCard}>
              <p className={styles.testimonialQuote}>
                “{testimonials[currentTestimonial].quote}”
              </p>
              <div className={styles.testimonialMeta}>
                <strong>{testimonials[currentTestimonial].name}</strong>
                <span>{testimonials[currentTestimonial].role}</span>
              </div>
              <div className={styles.testimonialControls} role="group" aria-label="Навигация по отзывам">
                {testimonials.map((testimonial, index) => (
                  <button
                    key={testimonial.name}
                    type="button"
                    className={`${styles.testimonialDot} ${index === currentTestimonial ? styles.testimonialDotActive : ''}`}
                    aria-label={`Отзыв ${index + 1}`}
                    onClick={() => setCurrentTestimonial(index)}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>Команда</span>
            <h2 className="sectionTitle">Лидеры направлений</h2>
            <p className="sectionSubtitle">
              Мы объединяем опыт топ-менеджмента, стратегического консалтинга и технологического предпринимательства.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {[
              {
                name: 'Антон Васильев',
                role: 'Партнёр по стратегии',
                image: 'https://picsum.photos/400/400?random=31',
                bio: '15 лет в управленческом консалтинге, отвечал за трансформацию федеральных компаний.'
              },
              {
                name: 'Мария Орлова',
                role: 'Партнёр по цифровым решениям',
                image: 'https://picsum.photos/400/400?random=32',
                bio: 'Эксперт по внедрению CRM и BI-платформ, создала центр аналитики в международном банке.'
              },
              {
                name: 'Дмитрий Зуев',
                role: 'Партнёр по маркетингу и CX',
                image: 'https://picsum.photos/400/400?random=33',
                bio: 'В прошлом — директор по маркетингу в ведущей телеком-компании, специализируется на опыте клиентов.'
              }
            ].map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <figure className={styles.teamPhoto}>
                  <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                </figure>
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>FAQ</span>
            <h2 className="sectionTitle">Частые вопросы</h2>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => {
              const isOpen = expandedFaq === index;
              return (
                <div key={item.question} className={`${styles.faqItem} ${isOpen ? styles.faqItemActive : ''}`}>
                  <button
                    type="button"
                    className={styles.faqButton}
                    onClick={() => setExpandedFaq(isOpen ? null : index)}
                    aria-expanded={isOpen}
                  >
                    <span>{item.question}</span>
                    <span className={styles.faqToggle}>{isOpen ? '−' : '+'}</span>
                  </button>
                  {isOpen && <p className={styles.faqAnswer}>{item.answer}</p>}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.blogPreviewSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTag}>Блог</span>
            <h2 className="sectionTitle">Свежие аналитические материалы</h2>
            <p className="sectionSubtitle">
              Делимся кейсами, исследованиями и практическими методиками, которые помогают нашим клиентам развиваться быстрее.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {[
              {
                title: 'Как выбрать стратегического партнера для роста бизнеса',
                link: '/blog/kak-vybrat-partnera',
                image: 'https://picsum.photos/800/600?random=51',
                excerpt: 'Чек-лист факторов при выборе консалтингового партнера и способы выстроить эффективное взаимодействие.'
              },
              {
                title: 'Инновации в бизнесе: как внедрять и измерять эффект',
                link: '/blog/innovacii-v-biznese',
                image: 'https://picsum.photos/800/600?random=52',
                excerpt: 'Переходим от слов к делу: подбираем инструменты инноваций и оцениваем их влияние на P&L.'
              },
              {
                title: 'Цифровая трансформация без боли: дорожная карта',
                link: '/blog/cifrovaya-transformaciya',
                image: 'https://picsum.photos/800/600?random=53',
                excerpt: 'Рассматриваем ключевые этапы, риски и принципы внедрения цифровых решений в традиционных компаниях.'
              }
            ].map((post) => (
              <article key={post.link} className={styles.blogCard}>
                <figure className={styles.blogImage}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </figure>
                <div className={styles.blogContent}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.blogLink}>Читать статью →</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Готовы обсудить ваш следующий шаг?</h2>
              <p>Расскажите нам о целях, и мы предложим формат сотрудничества, который принесёт реальную выгоду.</p>
            </div>
            <div className={styles.ctaActions}>
              <Link to="/kontakty" className="primaryButton">Назначить встречу</Link>
              <a href="tel:+74951234567" className="secondaryButton">Позвонить</a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;