import React from 'react';
import { Link } from 'react-router-dom';
import MetaTags from '../components/MetaTags';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Как выбрать стратегического партнера для роста бизнеса',
    date: '12 апреля 2024',
    excerpt: 'На что обратить внимание при выборе консалтингового партнера: экспертиза, команда, прозрачность и общие ценности.',
    link: '/blog/kak-vybrat-partnera',
    image: 'https://picsum.photos/900/600?random=101'
  },
  {
    title: 'Инновации в бизнесе: как внедрять и измерять эффект',
    date: '4 апреля 2024',
    excerpt: 'Разбираем этапы внедрения инноваций: от поиска идей до расчета ROI и управления портфелем инициатив.',
    link: '/blog/innovacii-v-biznese',
    image: 'https://picsum.photos/900/600?random=102'
  },
  {
    title: 'Цифровая трансформация без боли: дорожная карта',
    date: '27 марта 2024',
    excerpt: 'Как подготовить организацию к цифровизации, избежать сопротивления и получить быстрые победы.',
    link: '/blog/cifrovaya-transformaciya',
    image: 'https://picsum.photos/900/600?random=103'
  }
];

const Blog = () => {
  return (
    <>
      <MetaTags
        title="Блог компании — аналитика, кейсы и практики"
        description="Статьи о стратегии, инновациях и цифровой трансформации. Практические рекомендации от экспертов компании."
        canonical="https://www.компания.ru/blog"
        keywords="блог, аналитика, стратегия, инновации, цифровая трансформация"
        openGraph={{
          title: 'Блог компании',
          description: 'Свежие кейсы и исследования по развитию бизнеса.',
          url: 'https://www.компания.ru/blog',
          image: 'https://picsum.photos/1200/630?random=104'
        }}
      />
      <section className={styles.hero}>
        <div className="container">
          <span className={styles.tag}>Блог</span>
          <h1>Свежие идеи и практики для руководителей</h1>
          <p>Делимся опытом, кейсами и инструментами, которые помогают нашим клиентам добиваться ощутимых результатов.</p>
        </div>
      </section>
      <section className={styles.postsSection}>
        <div className="container">
          <div className={styles.grid}>
            {posts.map((post) => (
              <article key={post.link} className={styles.card}>
                <figure className={styles.image}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </figure>
                <div className={styles.content}>
                  <span className={styles.date}>{post.date}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.link}>Читать далее →</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;