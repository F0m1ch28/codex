import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Blog from './pages/Blog';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import BlogPostPartner from './pages/blog/KakVybratPartnera';
import BlogPostInnovation from './pages/blog/InnovaciiVBiznese';
import BlogPostTransformation from './pages/blog/CifrovayaTransformaciya';

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [pathname]);

  return null;
};

const App = () => {
  return (
    <div className="app">
      <ScrollToTopOnRouteChange />
      <Header />
      <main className="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/uslugi" element={<Services />} />
          <Route path="/o-kompanii" element={<About />} />
          <Route path="/kontakty" element={<Contact />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/kak-vybrat-partnera" element={<BlogPostPartner />} />
          <Route path="/blog/innovacii-v-biznese" element={<BlogPostInnovation />} />
          <Route path="/blog/cifrovaya-transformaciya" element={<BlogPostTransformation />} />
          <Route path="/usloviya" element={<Terms />} />
          <Route path="/politika-konfidencialnosti" element={<Privacy />} />
          <Route path="/politika-cookie" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTopButton />
      <CookieBanner />
    </div>
  );
};

export default App;