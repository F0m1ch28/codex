import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'kompania_cookie_consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h2 className={styles.title}>Мы используем cookie</h2>
        <p className={styles.text}>
          Cookie помогают нам анализировать посещаемость, улучшать функциональность сайта и предлагать более релевантный контент. Продолжая пользоваться сайтом, вы соглашаетесь с обработкой данных.
        </p>
        <button type="button" className={styles.button} onClick={acceptCookies}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;