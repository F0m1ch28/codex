import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Подвал сайта">
      <div className={`container ${styles.top}`}>
        <div className={styles.brandColumn}>
          <span className={styles.logo}>Компания</span>
          <p className={styles.description}>
            Опытная команда консультантов, стратегов и аналитиков помогает бизнесу уверенно двигаться вперёд,
            сочетая экспертизу в управлении, цифровой трансформации и маркетинге.
          </p>
          <p className={styles.copyright}>© {new Date().getFullYear()} Компания. Все права защищены.</p>
        </div>
        <div className={styles.linksColumn}>
          <h3 className={styles.columnTitle}>Навигация</h3>
          <ul className={styles.linksList}>
            <li><NavLink to="/">Главная</NavLink></li>
            <li><NavLink to="/uslugi">Услуги</NavLink></li>
            <li><NavLink to="/o-kompanii">О компании</NavLink></li>
            <li><NavLink to="/blog">Блог</NavLink></li>
            <li><NavLink to="/kontakty">Контакты</NavLink></li>
          </ul>
        </div>
        <div className={styles.linksColumn}>
          <h3 className={styles.columnTitle}>Правовая информация</h3>
          <ul className={styles.linksList}>
            <li><NavLink to="/usloviya">Условия использования</NavLink></li>
            <li><NavLink to="/politika-konfidencialnosti">Политика конфиденциальности</NavLink></li>
            <li><NavLink to="/politika-cookie">Политика использования cookie</NavLink></li>
          </ul>
        </div>
        <div className={styles.contactsColumn}>
          <h3 className={styles.columnTitle}>Контакты</h3>
          <address className={styles.address}>
            ул. Примерная, д. 10<br />
            Москва, 101000<br />
            Россия
          </address>
          <a className={styles.contactLink} href="tel:+74951234567">+7 (495) 123-45-67</a>
          <a className={styles.contactLink} href="mailto:info@компания.ru">info@компания.ru</a>
        </div>
      </div>
      <div className={styles.bottom}>
        <div className="container">
          <span>Создано с заботой о вашем бизнесе.</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;