import { useEffect } from 'react';

const MetaTags = ({ title, description, keywords, canonical, openGraph = {}, schema }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }

    const setMetaName = (name, content) => {
      if (!content) return;
      let element = document.querySelector(`meta[name="${name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('name', name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const setMetaProperty = (property, content) => {
      if (!content) return;
      let element = document.querySelector(`meta[property="${property}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('property', property);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    if (description) {
      setMetaName('description', description);
    }
    if (keywords) {
      setMetaName('keywords', keywords);
    }

    Object.entries(openGraph).forEach(([property, value]) => {
      setMetaProperty(`og:${property}`, value);
    });

    if (canonical) {
      let link = document.querySelector('link[rel="canonical"]');
      if (!link) {
        link = document.createElement('link');
        link.setAttribute('rel', 'canonical');
        document.head.appendChild(link);
      }
      link.setAttribute('href', canonical);
    }

    const schemaId = 'structured-data';
    let schemaEl = document.getElementById(schemaId);

    if (schema) {
      if (!schemaEl) {
        schemaEl = document.createElement('script');
        schemaEl.type = 'application/ld+json';
        schemaEl.id = schemaId;
        document.head.appendChild(schemaEl);
      }
      schemaEl.textContent = schema;
    } else if (schemaEl) {
      schemaEl.remove();
    }

    return () => {};
  }, [title, description, keywords, canonical, openGraph, schema]);

  return null;
};

export default MetaTags;