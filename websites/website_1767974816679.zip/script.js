document.addEventListener("DOMContentLoaded", function () {
    const cookieBanner = document.getElementById("cookieBanner");
    const cookieChoices = document.querySelectorAll(".cookie-choice");
    const cookieKey = "cihCookiePreference";

    if (cookieBanner && !localStorage.getItem(cookieKey)) {
        cookieBanner.classList.add("show");
    }

    cookieChoices.forEach(function (link) {
        link.addEventListener("click", function (event) {
            const choice = event.currentTarget.dataset.choice || "undecided";
            localStorage.setItem(cookieKey, choice);
            cookieBanner.classList.remove("show");
            setTimeout(function () {
                window.location.href = event.currentTarget.getAttribute("href");
            }, 150);
            event.preventDefault();
        });
    });

    const postsGrid = document.getElementById("postsGrid");
    const searchInput = document.getElementById("postSearch");
    const filterButtons = document.querySelectorAll(".filter-btn");

    if (postsGrid && searchInput) {
        function filterPosts() {
            const query = searchInput.value.trim().toLowerCase();
            const activeCategory = document.querySelector(".filter-btn.active")?.dataset.category || "all";
            const cards = postsGrid.querySelectorAll(".post-card");

            cards.forEach(function (card) {
                const category = card.dataset.category;
                const title = card.querySelector("h3").textContent.toLowerCase();
                const excerpt = card.querySelector(".excerpt").textContent.toLowerCase();
                const matchesCategory = activeCategory === "all" || category === activeCategory;
                const matchesQuery = title.includes(query) || excerpt.includes(query);
                card.style.display = matchesCategory && matchesQuery ? "" : "none";
            });
        }

        searchInput.addEventListener("input", filterPosts);

        filterButtons.forEach(function (btn) {
            btn.addEventListener("click", function () {
                filterButtons.forEach(function (button) {
                    button.classList.remove("active");
                });
                btn.classList.add("active");
                filterPosts();
            });
        });
    }

    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const name = document.getElementById("name");
            const email = document.getElementById("email");
            const organization = document.getElementById("organization");
            const topic = document.getElementById("topic");
            const message = document.getElementById("message");

            const nameError = document.getElementById("nameError");
            const emailError = document.getElementById("emailError");
            const organizationError = document.getElementById("organizationError");
            const topicError = document.getElementById("topicError");
            const messageError = document.getElementById("messageError");

            let valid = true;

            if (!name.value.trim()) {
                nameError.style.display = "block";
                valid = false;
            } else {
                nameError.style.display = "none";
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email.value.trim())) {
                emailError.style.display = "block";
                valid = false;
            } else {
                emailError.style.display = "none";
            }

            if (!organization.value.trim()) {
                organizationError.style.display = "block";
                valid = false;
            } else {
                organizationError.style.display = "none";
            }

            if (!topic.value.trim()) {
                topicError.style.display = "block";
                valid = false;
            } else {
                topicError.style.display = "none";
            }

            if (!message.value.trim()) {
                messageError.style.display = "block";
                valid = false;
            } else {
                messageError.style.display = "none";
            }

            if (valid) {
                window.location.href = "thanks.html";
            }
        });
    }
});