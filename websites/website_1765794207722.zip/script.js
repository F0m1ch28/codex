document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', function () {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
      siteNav.classList.toggle('is-open');
    });

    siteNav.querySelectorAll('.nav-link').forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.innerWidth < 768 && siteNav.classList.contains('is-open')) {
          siteNav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const consent = localStorage.getItem('cookieConsent');
    const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');

    if (!consent) {
      window.requestAnimationFrame(function () {
        cookieBanner.classList.add('is-visible');
      });
    }

    const handleChoice = function (value) {
      localStorage.setItem('cookieConsent', value);
      cookieBanner.classList.remove('is-visible');
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        handleChoice('accepted');
      });
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', function () {
        handleChoice('declined');
      });
    }
  }
});