document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navigation = document.querySelector('#primary-navigation');
  if (navToggle && navigation) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
      navigation.classList.toggle('is-open', !expanded);
    });
    navigation.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        navigation.classList.remove('is-open');
      });
    });
  }

  const banner = document.querySelector('.cookie-banner');
  if (banner) {
    const acceptBtn = banner.querySelector('[data-cookie-accept]');
    const declineBtn = banner.querySelector('[data-cookie-decline]');
    const storedChoice = localStorage.getItem('cookieChoice');
    if (storedChoice) {
      banner.classList.add('is-hidden');
    } else {
      requestAnimationFrame(() => banner.classList.add('is-visible'));
    }
    const closeBanner = (choice) => {
      localStorage.setItem('cookieChoice', choice);
      banner.classList.remove('is-visible');
      setTimeout(() => banner.classList.add('is-hidden'), 400);
    };
    acceptBtn?.addEventListener('click', () => closeBanner('accepted'));
    declineBtn?.addEventListener('click', () => closeBanner('declined'));
  }

  const cardForm = document.querySelector('#cardForm');
  if (cardForm) {
    const preview = document.querySelector('[data-card-preview]');
    const previewTo = document.querySelector('[data-card-to]');
    const previewBody = document.querySelector('[data-card-body]');
    const previewFrom = document.querySelector('[data-card-from]');
    const previewBadge = document.querySelector('[data-card-badge]');
    const copyButton = document.querySelector('[data-copy-card]');
    const copyFeedback = document.querySelector('[data-copy-feedback]');

    const updateCard = () => {
      const recipient = cardForm.recipient.value.trim() || 'Құрметті жан';
      const tone = cardForm.tone.value || 'Шын жүректен тілек';
      const message = cardForm.message.value.trim() || 'Сізге мейірім мен шаттық тілейміз!';
      const sender = cardForm.sender.value.trim() || 'Ізгі тілекпен';
      const theme = cardForm.theme.value || 'spring';

      previewTo.textContent = `${recipient}!`;
      previewBadge.textContent = tone;
      previewBody.textContent = message;
      previewFrom.textContent = sender;

      preview.classList.remove('card-theme-spring', 'card-theme-gold', 'card-theme-orchid');
      preview.classList.add(`card-theme-${theme}`);
    };

    cardForm.addEventListener('input', updateCard);
    cardForm.addEventListener('change', updateCard);
    updateCard();

    if (copyButton) {
      copyButton.addEventListener('click', () => {
        const cardText = `${previewBadge.textContent}\n${previewTo.textContent}\n\n${previewBody.textContent}\n\n${previewFrom.textContent}`;
        if (!navigator.clipboard) {
          if (copyFeedback) {
            copyFeedback.textContent = 'Браузер көшіруді қолдамайды, мәтінді қолмен белгілеңіз.';
            copyFeedback.dataset.visible = 'true';
            setTimeout(() => (copyFeedback.dataset.visible = 'false'), 3000);
          }
          return;
        }
        navigator.clipboard.writeText(cardText).then(() => {
          if (copyFeedback) {
            copyFeedback.textContent = 'Хат мәтіні буферге сақталды!';
            copyFeedback.dataset.visible = 'true';
            setTimeout(() => (copyFeedback.dataset.visible = 'false'), 3200);
          }
        }).catch(() => {
          if (copyFeedback) {
            copyFeedback.textContent = 'Көшіру кезінде қате кетті. Тағы бір рет байқап көріңіз.';
            copyFeedback.dataset.visible = 'true';
            setTimeout(() => (copyFeedback.dataset.visible = 'false'), 3200);
          }
        });
      });
    }
  }
});