document.addEventListener('DOMContentLoaded', function () {
  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const acceptButton = cookieBanner.querySelector('[data-cookie-accept]');
    const declineButton = cookieBanner.querySelector('[data-cookie-decline]');
    const consentStatus = localStorage.getItem('crimsonGiftCookies');

    if (!consentStatus) {
      cookieBanner.style.display = 'flex';
    }

    if (acceptButton) {
      acceptButton.addEventListener('click', function () {
        localStorage.setItem('crimsonGiftCookies', 'accepted');
        cookieBanner.style.display = 'none';
      });
    }

    if (declineButton) {
      declineButton.addEventListener('click', function () {
        localStorage.setItem('crimsonGiftCookies', 'declined');
        cookieBanner.style.display = 'none';
      });
    }
  }

  const filterButtons = document.querySelectorAll('[data-filter]');
  const productCards = document.querySelectorAll('[data-category]');
  if (filterButtons.length && productCards.length) {
    filterButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        const filter = button.getAttribute('data-filter');
        filterButtons.forEach(function (btn) {
          btn.classList.toggle('is-active', btn === button);
        });

        productCards.forEach(function (card) {
          const categories = card.getAttribute('data-category').split(' ');
          const shouldShow = filter === 'all' || categories.includes(filter);
          card.style.display = shouldShow ? 'flex' : 'none';
        });
      });
    });
  }

  const customizeForm = document.getElementById('customize-form');
  if (customizeForm) {
    const summaryList = document.getElementById('custom-summary');
    const totalElement = document.getElementById('custom-total');
    const basePrice = parseFloat(customizeForm.dataset.basePrice || '45');

    function updateCustomizationSummary() {
      let total = basePrice;
      const selections = [];

      const boxType = customizeForm.querySelector('select[name="boxType"]');
      if (boxType) {
        const option = boxType.options[boxType.selectedIndex];
        const price = parseFloat(option.dataset.price || '0');
        total += price;
        selections.push('Box: ' + option.text.replace(' (+$' + price + ')', '').trim());
      }

      const sizeOption = customizeForm.querySelector('input[name="size"]:checked');
      if (sizeOption) {
        const price = parseFloat(sizeOption.dataset.price || '0');
        total += price;
        selections.push('Size: ' + sizeOption.value + ' (+' + '$' + price.toFixed(2) + ')');
      }

      const extras = customizeForm.querySelectorAll('input[name="extras"]:checked');
      extras.forEach(function (extra) {
        const price = parseFloat(extra.dataset.price || '0');
        total += price;
        selections.push('Extra: ' + extra.value + ' (+' + '$' + price.toFixed(2) + ')');
      });

      const message = customizeForm.querySelector('textarea[name="message"]');
      if (message && message.value.trim()) {
        selections.push('Personal Message Included');
      }

      if (summaryList) {
        summaryList.innerHTML = '';
        selections.forEach(function (item) {
          const li = document.createElement('li');
          li.textContent = item;
          summaryList.appendChild(li);
        });
      }

      if (totalElement) {
        totalElement.textContent = '$' + total.toFixed(2);
      }
    }

    customizeForm.addEventListener('change', updateCustomizationSummary);
    customizeForm.addEventListener('input', updateCustomizationSummary);
    updateCustomizationSummary();
  }

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (event) {
      const nameInput = contactForm.querySelector('input[name="name"]');
      const emailInput = contactForm.querySelector('input[name="email"]');
      const messageInput = contactForm.querySelector('textarea[name="message"]');
      const errors = [];

      if (!nameInput.value.trim()) {
        errors.push('Please enter your full name.');
      }

      const emailValue = emailInput.value.trim();
      if (!emailValue) {
        errors.push('Please enter your email address.');
      } else {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(emailValue)) {
          errors.push('Please enter a valid email address.');
        }
      }

      if (!messageInput.value.trim()) {
        errors.push('Please add a message so we can assist you.');
      }

      if (errors.length) {
        event.preventDefault();
        alert(errors.join('\n'));
      }
    });
  }

  const newsletterForm = document.getElementById('newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function (event) {
      const emailInput = newsletterForm.querySelector('input[name="newsletter-email"]');
      if (!emailInput.value.trim()) {
        event.preventDefault();
        alert('Please provide your email to subscribe.');
      }
    });
  }
});