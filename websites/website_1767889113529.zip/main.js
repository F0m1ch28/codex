document.addEventListener("DOMContentLoaded", function () {
    const menuToggle = document.querySelector(".menu-toggle");
    const mainNav = document.querySelector(".main-nav");
    if (menuToggle && mainNav) {
        menuToggle.addEventListener("click", function () {
            mainNav.classList.toggle("open");
        });
        mainNav.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                mainNav.classList.remove("open");
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const cookieButtons = cookieBanner.querySelectorAll(".cookie-button");
        const storedChoice = localStorage.getItem("shintoggkxCookieChoice");
        if (storedChoice) {
            cookieBanner.classList.add("hidden");
        }
        cookieButtons.forEach(function (button) {
            button.addEventListener("click", function (event) {
                localStorage.setItem("shintoggkxCookieChoice", button.dataset.choice);
                cookieBanner.classList.add("hidden");
            });
        });
    }
});