document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      mainNav.dataset.open = String(!expanded);
    });

    mainNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        mainNav.dataset.open = 'false';
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const cookieButtons = cookieBanner ? cookieBanner.querySelectorAll('button[data-action]') : [];

  const setCookiePreference = (value) => {
    localStorage.setItem('vitaflow-cookie-consent', value);
    if (cookieBanner) {
      cookieBanner.dataset.visible = 'false';
    }
  };

  if (cookieBanner && !localStorage.getItem('vitaflow-cookie-consent')) {
    setTimeout(() => {
      cookieBanner.dataset.visible = 'true';
    }, 1000);
  }

  cookieButtons.forEach(button => {
    button.addEventListener('click', () => {
      const action = button.dataset.action;
      setCookiePreference(action);
    });
  });

  const parallaxItems = document.querySelectorAll('[data-parallax]');
  if (parallaxItems.length) {
    const updateParallax = () => {
      parallaxItems.forEach(item => {
        const speed = parseFloat(item.dataset.parallax) || 0.12;
        const rect = item.getBoundingClientRect();
        const offset = (rect.top - window.innerHeight / 2) * speed * -0.35;
        item.style.transform = `translateY(${offset}px)`;
      });
    };

    updateParallax();
    document.addEventListener('scroll', () => {
      window.requestAnimationFrame(updateParallax);
    }, { passive: true });
    window.addEventListener('resize', updateParallax);
  }
});