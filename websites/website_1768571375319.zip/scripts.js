document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.getElementById('primary-navigation');
    const body = document.body;

    if (navToggle && navigation) {
        navToggle.addEventListener('click', function () {
            const isVisible = navigation.getAttribute('data-visible') === 'true';
            navigation.setAttribute('data-visible', String(!isVisible));
            navToggle.setAttribute('aria-expanded', String(!isVisible));
            body.classList.toggle('nav-open', !isVisible);
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        try {
            const storedConsent = localStorage.getItem('advantwvonCookieConsent');
            if (storedConsent) {
                cookieBanner.classList.add('is-hidden');
            }

            const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
            const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');

            if (acceptBtn) {
                acceptBtn.addEventListener('click', function () {
                    localStorage.setItem('advantwvonCookieConsent', 'accepted');
                    cookieBanner.classList.add('is-hidden');
                });
            }

            if (declineBtn) {
                declineBtn.addEventListener('click', function () {
                    localStorage.setItem('advantwvonCookieConsent', 'declined');
                    cookieBanner.classList.add('is-hidden');
                });
            }
        } catch (error) {
            cookieBanner.classList.add('is-hidden');
        }
    }
});