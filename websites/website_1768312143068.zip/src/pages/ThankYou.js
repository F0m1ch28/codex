import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link, useLocation } from 'react-router-dom';
import styles from './ThankYou.module.css';

const ThankYouPage = () => {
  const location = useLocation();
  const visitorName = location.state?.name ? location.state.name.split(' ')[0] : null;

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Спасибо за обращение — Мир Кошек</title>
        <meta
          name="description"
          content="Благодарим за сообщение. Команда «Мир Кошек» ответит в ближайшее время."
        />
      </Helmet>
      <div className={styles.card}>
        <h1 className={styles.title}>Спасибо за доверие!</h1>
        <p className={styles.text}>
          {visitorName ? "${visitorName}, " : ''}
          мы получили ваше сообщение и уже передали его профильному специалисту. Ответ придет на указанную почту в
          течение двух рабочих дней.
        </p>
        <Link to="/" className="buttonPrimary">
          Вернуться на главную
        </Link>
      </div>
    </div>
  );
};

export default ThankYouPage;