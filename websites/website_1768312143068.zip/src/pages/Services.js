import React, { useMemo, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Breeds.module.css';
import careStyles from './Care.module.css';
import behaviorStyles from './Behavior.module.css';

const BreedsPage = () => {
  const breedData = useMemo(
    () => [
      {
        name: 'Мейн-кун',
        description:
          'Мягкие гиганты с уравновешенным характером. Любят активные игры и легко осваивают поведение на шлейке.',
        origin: 'США',
        size: 'Крупная',
        tags: ['longhair', 'family'],
        temperament: ['дружелюбная', 'интеллектуальная', 'контактная'],
        image: 'https://picsum.photos/seed/breed-mainecoon/720/520'
      },
      {
        name: 'Невская маскарадная',
        description:
          'Пушистая красавица с выразительной маской и небесными глазами. Требует регулярного ухода за шерстью.',
        origin: 'Россия',
        size: 'Средняя',
        tags: ['longhair'],
        temperament: ['ласковая', 'общительная', 'спокойная'],
        image: 'https://picsum.photos/seed/breed-neva/720/520'
      },
      {
        name: 'Сфинкс',
        description:
          'Голая порода с темпераментом преданного друга. Нуждается в контроле температуры и уходе за кожей.',
        origin: 'Канада',
        size: 'Средняя',
        tags: ['hypoallergenic', 'companion'],
        temperament: ['темпераментная', 'внимательная', 'эмоциональная'],
        image: 'https://picsum.photos/seed/breed-sphinx/720/520'
      },
      {
        name: 'Ориентальная',
        description:
          'Стройная и разговорчивая кошка. Любит интеллектуальные игры и тесный контакт с человеком.',
        origin: 'Таиланд',
        size: 'Средняя',
        tags: ['short-hair', 'active'],
        temperament: ['активная', 'любознательная', 'коммуникативная'],
        image: 'https://picsum.photos/seed/breed-oriental/720/520'
      },
      {
        name: 'Рэгдолл',
        description:
          'Спокойные компаньоны, которые любят быть на руках. Подходят для семей с детьми и людьми спокойного темперамента.',
        origin: 'США',
        size: 'Крупная',
        tags: ['family', 'longhair'],
        temperament: ['нежная', 'адаптивная', 'терпеливая'],
        image: 'https://picsum.photos/seed/breed-ragdoll/720/520'
      },
      {
        name: 'Корниш-рекс',
        description:
          'Волнистая шерсть и удивительная пластика. Подходят активным владельцам, которые готовы к игривому характеру.',
        origin: 'Великобритания',
        size: 'Легкая',
        tags: ['hypoallergenic', 'active'],
        temperament: ['игривая', 'энергичная', 'ласковая'],
        image: 'https://picsum.photos/seed/breed-cornish/720/520'
      }
    ],
    []
  );

  const filters = useMemo(
    () => [
      { id: 'all', label: 'Все породы' },
      { id: 'family', label: 'Для семей' },
      { id: 'longhair', label: 'Длинношерстные' },
      { id: 'hypoallergenic', label: 'Гипоаллергенные' },
      { id: 'active', label: 'Для активных хозяев' }
    ],
    []
  );

  const [query, setQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState(filters[0].id);
  const [filteredBreeds, setFilteredBreeds] = useState(breedData);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const normalizedQuery = query.trim().toLowerCase();

      const results = breedData.filter((breed) => {
        const matchesFilter = activeFilter === 'all' || breed.tags.includes(activeFilter);
        const matchesQuery =
          !normalizedQuery ||
          breed.name.toLowerCase().includes(normalizedQuery) ||
          breed.description.toLowerCase().includes(normalizedQuery) ||
          breed.temperament.some((trait) => trait.toLowerCase().includes(normalizedQuery));
        return matchesFilter && matchesQuery;
      });

      setFilteredBreeds(results);
    }, 200);

    return () => window.clearTimeout(timer);
  }, [query, activeFilter, breedData]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Породы кошек — каталог «Мир Кошек»</title>
        <meta
          name="description"
          content="Познакомьтесь с популярными и редкими породами кошек. Факты о характере, особенностях ухода и советах по общению."
        />
      </Helmet>

      <div className="container">
        <header className={styles.intro}>
          <div>
            <h1 className={styles.pageTitle}>Породы кошек</h1>
            <p className={styles.pageDescription}>
              Подобрали породы с разным темпераментом, длиной шерсти и потребностями. Используйте фильтры и поиск, чтобы
              найти идеального компаньона.
            </p>
          </div>
          <div className={styles.searchPanel}>
            <label className="visually-hidden" htmlFor="breed-search">
              Поиск по породам
            </label>
            <input
              id="breed-search"
              type="search"
              className={styles.searchInput}
              placeholder="Поиск по названию или характеру..."
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
            <div className={styles.filterChips}>
              {filters.map((filter) => (
                <button
                  key={filter.id}
                  type="button"
                  className={
                    activeFilter === filter.id
                      ? "${styles.chip} ${styles.chipActive}"
                      : styles.chip
                  }
                  onClick={() => setActiveFilter(filter.id)}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>
        </header>

        <div className={styles.breedGrid}>
          {filteredBreeds.length > 0 ? (
            filteredBreeds.map((breed) => (
              <article key={breed.name} className={styles.card}>
                <div className={styles.cardMedia}>
                  <img src={breed.image} alt={"Порода ${breed.name}"} loading="lazy" />
                </div>
                <div className={styles.cardBody}>
                  <h2 className={styles.cardTitle}>{breed.name}</h2>
                  <div className={styles.meta}>
                    <span className={styles.metaItem}>Происхождение: {breed.origin}</span>
                    <span className={styles.metaItem}>Размер: {breed.size}</span>
                  </div>
                  <p>{breed.description}</p>
                  <ul className={styles.traits}>
                    {breed.temperament.map((trait) => (
                      <li key={trait}>{trait}</li>
                    ))}
                  </ul>
                  <Link to="/kontakty" className={styles.cardLink}>
                    Задать вопрос эксперту →
                  </Link>
                </div>
              </article>
            ))
          ) : (
            <div className={styles.empty}>
              По вашему запросу пока нет результатов. Попробуйте изменить фильтр или уточнить поисковую фразу.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export const CarePage = () => {
  const categories = useMemo(
    () => [
      {
        id: 'ежедневный уход',
        title: 'Ежедневный уход',
        summary: 'Простые действия, которые формируют привычку к чистоте и спокойствию.',
        tips: [
          {
            title: 'Питание по расписанию',
            text: 'Разделите дневную норму на 3–4 кормления. Это помогает контролировать вес и предотвращает переедание.'
          },
          {
            title: 'Свежая вода',
            text: 'Ставьте несколько мисок или фонтанчики. Меняйте воду дважды в день и мойте посуду, чтобы избежать налета.'
          },
          {
            title: 'Уход за шерстью',
            text: 'Вычесывайте питомца мягкой щеткой, чтобы снизить линьку и укрепить связь. Начинайте с коротких сеансов.'
          }
        ]
      },
      {
        id: 'здоровье',
        title: 'Здоровье',
        summary: 'Профилактика и внимательное наблюдение — основа долгой и активной жизни.',
        tips: [
          {
            title: 'Регулярный ветеринар',
            text: 'Планируйте осмотры раз в год, для возрастных кошек — каждые 6 месяцев. Ведите карточку прививок.'
          },
          {
            title: 'Домашний аптечка',
            text: 'Держите под рукой мягкий ошейник, антисептик, бинты, шприцы без иглы и контакты круглосуточной клиники.'
          },
          {
            title: 'Контроль активности',
            text: 'Следите за аппетитом, поведением, чистотой лотка. Любые изменения — повод для консультации.'
          }
        ]
      },
      {
        id: 'эмоциональный комфорт',
        title: 'Эмоциональный комфорт',
        summary: 'Кошки чувствительны к атмосфере дома. Создайте пространство, где безопасно быть собой.',
        tips: [
          {
            title: 'Зона уединения',
            text: 'Подготовьте укромные места на высоте и внизу, используйте закрытые домики или палатки.'
          },
          {
            title: 'Игровые ритуалы',
            text: 'Выделяйте 15 минут утром и вечером для совместных игр — это снижает тревожность и поддерживает форму.'
          },
          {
            title: 'Обогащение среды',
            text: 'Меняйте игрушки, используйте интерактивные кормушки, создавайте маршруты с полками и мостиками.'
          }
        ]
      }
    ],
    []
  );

  const resources = useMemo(
    () => [
      {
        title: 'Чек-лист ухода за шерстью',
        description: 'Пошаговая инструкция для коротко- и длинношерстных кошек с рекомендациями по инструментам.'
      },
      {
        title: 'План медосмотров',
        description: 'Календарь прививок, обработок и анализов для котят, взрослых и возрастных питомцев.'
      },
      {
        title: 'Курс «Спокойный лоток»',
        description: 'Рассказываем, как приучить котенка, что делать при протестах и как выбрать наполнитель.'
      }
    ],
    []
  );

  const [activeCategory, setActiveCategory] = useState(categories[0].id);

  const active = categories.find((category) => category.id === activeCategory);

  return (
    <div className={careStyles.page}>
      <Helmet>
        <title>Уход и здоровье кошек — рекомендации</title>
        <meta
          name="description"
          content="Практические советы по питанию, ветеринарному сопровождению и эмоциональному комфорту кошек."
        />
      </Helmet>
      <div className="container">
        <header className={careStyles.header}>
          <h1>Уход и здоровье</h1>
          <p>
            Основа благополучия кошки — стабильность и внимание к деталям. Мы собрали проверенные практики, которые
            помогают строить доверительные отношения и сохранять здоровье.
          </p>
          <div className={careStyles.tabs}>
            {categories.map((category) => (
              <button
                key={category.id}
                type="button"
                className={
                  activeCategory === category.id
                    ? "${careStyles.tabButton} ${careStyles.tabButtonActive}"
                    : careStyles.tabButton
                }
                onClick={() => setActiveCategory(category.id)}
              >
                {category.title}
              </button>
            ))}
          </div>
        </header>

        {active && (
          <section className={careStyles.content}>
            <div className={careStyles.highlight}>
              <h2>{active.title}</h2>
              <p>{active.summary}</p>
            </div>
            <ul className={careStyles.tipList}>
              {active.tips.map((tip) => (
                <li key={tip.title} className={careStyles.tipItem}>
                  <span className={careStyles.tipTitle}>{tip.title}</span>
                  <span>{tip.text}</span>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section>
          <h2>Полезные материалы</h2>
          <div className={careStyles.resourceGrid}>
            {resources.map((resource) => (
              <article key={resource.title} className={careStyles.resourceCard}>
                <h3>{resource.title}</h3>
                <p>{resource.description}</p>
                <Link to="/kontakty" className="buttonSecondary">
                  Получить консультацию
                </Link>
              </article>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export const BehaviorPage = () => {
  const moods = useMemo(
    () => [
      {
        id: 'радость',
        title: 'Радость и спокойствие',
        description:
          'Расслабленное тело, мягкая поза, хвост сложен рядом или легко подрагивает. Кошка приглашает к общению.',
        steps: [
          'Говорите мягким голосом, предлагайте руку для знакомства, соблюдая личные границы.',
          'Используйте спокойные игры с удочкой, чтобы поддержать позитивный контакт.',
          'Предложите угощение или массаж щёк — это закрепит приятную эмоцию.'
        ]
      },
      {
        id: 'тревога',
        title: 'Тревога и напряжение',
        description:
          'Уши прижаты, зрачки расширены, дыхание учащенное. Хвост поджат или резко двигается из стороны в сторону.',
        steps: [
          'Уберите раздражители: громкие звуки, незнакомых гостей, резкие запахи.',
          'Дайте кошке безопасное пространство — домик, укрытие на высоте, доступ к носилке.',
          'Используйте феромоны или мягкое укрывание пледом, если питомец привык к этому ритуалу.'
        ]
      },
      {
        id: 'игривость',
        title: 'Игровое настроение',
        description:
          'Хвост поднят трубой, спина дугой, прыжки и «галоп» по квартире. Кошка ищет взаимодействие.',
        steps: [
          'Предлагайте разнообразие игрушек: удочки, мячики, интерактивные тоннели.',
          'Проводите игры по сценарию охоты: наблюдение, преследование, захват и «трофей».',
          'Завершайте игру угощением, чтобы кошка получила удовлетворение от «добычи».'
        ]
      }
    ],
    []
  );

  const behaviorPatterns = useMemo(
    () => [
      {
        title: 'Знакомство с новыми людьми',
        text: 'Позволяйте кошке подходить первой. Гости могут сидеть на полу, не смотреть прямо в глаза и предложить лакомство на вытянутой ладони.'
      },
      {
        title: 'Поездки к ветеринару',
        text: 'Заранее приучайте к переноске: оставляйте её открытой дома, кормите внутри, играйте рядом. Используйте пледы с запахом дома для снижения стресса.'
      },
      {
        title: 'Сосуществование с другими животными',
        text: 'Вводите знакомство постепенно: обмен запахами, короткие встречи под контролем, поощрения за спокойствие. У каждой кошки должна быть собственная зона.'
      }
    ],
    []
  );

  const [activeMood, setActiveMood] = useState(moods[0].id);

  const currentMood = moods.find((mood) => mood.id === activeMood);

  return (
    <div className={behaviorStyles.page}>
      <Helmet>
        <title>Поведение кошек — понимание и советы</title>
        <meta
          name="description"
          content="Разбираем язык тела, эмоции и сценарии поведения кошек. Практика общения с питомцами в различных ситуациях."
        />
      </Helmet>
      <div className="container">
        <section className={behaviorStyles.intro}>
          <h1>Поведение</h1>
          <p>
            Кошки говорят хвостом, ушами и взглядом. Расшифровывая язык тела, мы можем поддерживать доверие и вовремя
            замечать изменения. Выберите настроение, чтобы получить пошаговый сценарий действий.
          </p>
          <div className={behaviorStyles.moodSwitcher}>
            {moods.map((mood) => (
              <button
                key={mood.id}
                type="button"
                className={
                  mood.id === activeMood
                    ? "${behaviorStyles.moodButton} ${behaviorStyles.moodButtonActive}"
                    : behaviorStyles.moodButton
                }
                onClick={() => setActiveMood(mood.id)}
              >
                {mood.title}
              </button>
            ))}
          </div>
        </section>

        {currentMood && (
          <section className={behaviorStyles.behaviorGrid}>
            <article className={behaviorStyles.behaviorCard}>
              <h2>{currentMood.title}</h2>
              <p>{currentMood.description}</p>
              <ol className={behaviorStyles.steps}>
                {currentMood.steps.map((step) => (
                  <li key={step}>{step}</li>
                ))}
              </ol>
            </article>
            <article className={behaviorStyles.behaviorCard}>
              <h2>Подготовка среды</h2>
              <p>
                Создавайте предсказуемость: расставьте укрытия по маршруту, поставьте игрушки или кусочки ковролина,
                которые кошка любит. Следите за освещением и шумами.
              </p>
              <p>
                Если эмоции меняются резко, фиксируйте время и обстоятельства. Это поможет ветеринару или зоопсихологу
                подобрать решения.
              </p>
            </article>
          </section>
        )}

        <section className={behaviorStyles.patterns}>
          <h2>Распространенные сценарии</h2>
          <ul className={behaviorStyles.patternList}>
            {behaviorPatterns.map((pattern) => (
              <li key={pattern.title} className={behaviorStyles.patternItem}>
                <h3>{pattern.title}</h3>
                <p>{pattern.text}</p>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
};

export default BreedsPage;