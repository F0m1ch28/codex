import React, { useState, useRef, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import styles from './Contact.module.css';

const initialForm = {
  name: '',
  email: '',
  message: ''
};

const ContactsPage = () => {
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const timerRef = useRef(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        window.clearTimeout(timerRef.current);
      }
    };
  }, []);

  const validate = () => {
    const newErrors = {};
    const name = formData.name.trim();
    const email = formData.email.trim();
    const message = formData.message.trim();

    if (name.length < 2) {
      newErrors.name = 'Пожалуйста, укажите имя — минимум 2 символа.';
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/u;
    if (!emailPattern.test(email)) {
      newErrors.email = 'Введите корректный адрес электронной почты.';
    }

    if (message.length < 10) {
      newErrors.message = 'Сообщение должно содержать минимум 10 символов.';
    }

    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setErrors({});
    setIsSubmitting(true);

    timerRef.current = window.setTimeout(() => {
      setIsSubmitting(false);
      navigate('/spasibo', { state: { name: formData.name.trim() } });
      setFormData(initialForm);
    }, 900);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Контакты «Мир Кошек»</title>
        <meta
          name="description"
          content="Свяжитесь с редакцией «Мир Кошек». Пишите нам по вопросам сотрудничества, консультаций и предложений."
        />
      </Helmet>

      <div className="container">
        <header className={styles.intro}>
          <h1>Контакты</h1>
          <p>
            Мы открыты для вопросов, историй и предложений о сотрудничестве. Напишите нам, и команда ответит в течение
            двух рабочих дней.
          </p>
          <div className={styles.alert}>
            Уточните тему обращения — так мы быстрее подключим нужного специалиста: фелинолога, ветеринара или редактора.
          </div>
        </header>

        <div className={styles.wrapper}>
          <section className={styles.infoCard}>
            <h2>Редакция «Мир Кошек»</h2>
            <ul className={styles.infoList}>
              <li className={styles.infoItem}>
                <span className={styles.infoIcon} aria-hidden="true">
                  📍
                </span>
                ул. Кошачья, д. 15, г. Мурск, Россия
              </li>
              <li className={styles.infoItem}>
                <span className={styles.infoIcon} aria-hidden="true">
                  ☎️
                </span>
                +7 (495) 123-45-67
              </li>
              <li className={styles.infoItem}>
                <span className={styles.infoIcon} aria-hidden="true">
                  ✉️
                </span>
                info@mir-koshek.ru
              </li>
            </ul>
            <p className={styles.status}>
              График работы редакции: пн–пт с 10:00 до 18:00. В нерабочее время следим за срочными письмами и
              консультациями ветеринаров.
            </p>
          </section>

          <section id="contact-form" className={styles.formCard}>
            <h2>Напишите нам</h2>
            <form onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name" className={styles.label}>
                  Имя
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  className={styles.input}
                  placeholder="Как к вам обращаться?"
                  value={formData.name}
                  onChange={handleChange}
                />
                {errors.name && (
                  <span className={styles.error} role="alert">
                    {errors.name}
                  </span>
                )}
              </div>

              <div className={styles.field}>
                <label htmlFor="email" className={styles.label}>
                  Электронная почта
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  className={styles.input}
                  placeholder="example@mir-koshek.ru"
                  value={formData.email}
                  onChange={handleChange}
                />
                {errors.email && (
                  <span className={styles.error} role="alert">
                    {errors.email}
                  </span>
                )}
              </div>

              <div className={styles.field}>
                <label htmlFor="message" className={styles.label}>
                  Сообщение
                </label>
                <textarea
                  id="message"
                  name="message"
                  className={styles.textarea}
                  placeholder="Расскажите, чем мы можем помочь"
                  value={formData.message}
                  onChange={handleChange}
                />
                {errors.message && (
                  <span className={styles.error} role="alert">
                    {errors.message}
                  </span>
                )}
              </div>

              <button type="submit" className="buttonPrimary" disabled={isSubmitting}>
                {isSubmitting ? 'Отправляем...' : 'Отправить сообщение'}
              </button>
            </form>
          </section>
        </div>

        <section className={styles.map} aria-label="Карта офиса">
          <iframe
            title="Карта офиса Мир Кошек"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d17995.97395297355!2d37.618423866232435!3d55.75582638616171!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46b54a5a61a9ab6f%3A0xba4da8db36894695!2z0JzQvtGB0LrQstCw0YAg0JrRg9C70LjRhtCw0Y8g0JDQstGC0L7RgdC60LjRhSDQstC-0YDRg9C30L3Ri9C5!5e0!3m2!1sru!2sru!4v1681412345678!5m2!1sru!2sru"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            loading="lazy"
            allowFullScreen
            referrerPolicy="no-referrer-when-downgrade"
          />
        </section>
      </div>
    </div>
  );
};

export default ContactsPage;