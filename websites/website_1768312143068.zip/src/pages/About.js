import React, { useMemo, useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const AboutPage = () => {
  const metrics = useMemo(
    () => [
      { value: '450+', label: 'публикаций и гидов' },
      { value: '18', label: 'экспертов и волонтеров' },
      { value: '120 тыс.', label: 'читателей сообщества' }
    ],
    []
  );

  const values = useMemo(
    () => [
      {
        title: 'Осознанная забота',
        description:
          'Мы объясняем, как выстраивать уход без стрессов и крайностей: от питания до профилактики заболеваний.'
      },
      {
        title: 'Достоверность',
        description:
          'Каждый материал проходит проверку у профильных специалистов, чтобы советы были практичными и безопасными.'
      },
      {
        title: 'Сила сообщества',
        description:
          'Объединяем владельцев, приюты и экспертов, чтобы делиться опытом и поддерживать ответственный подход.'
      }
    ],
    []
  );

  const timeline = useMemo(
    () => [
      {
        year: '2015',
        title: 'Появилась идея портала',
        description:
          'Команда выпускников фелинологического клуба решила создать платформу, где опыт и научные данные встречаются.'
      },
      {
        year: '2017',
        title: 'Запуск рубрик по здоровью',
        description:
          'К проекту присоединились ветеринары, появились первые вебинары и регулярная рассылка с рекомендациями.'
      },
      {
        year: '2020',
        title: 'Сообщество и волонтерство',
        description:
          'Открыли раздел с историями спасения и начали совместные проекты с приютами по всей России.'
      },
      {
        year: '2023',
        title: 'Интерактивные гиды',
        description:
          'Добавили чек-листы по адаптации котят, калькуляторы кормления и карту честных заводчиков.'
      }
    ],
    []
  );

  const [highlightedValue, setHighlightedValue] = useState(values[0].title);

  useEffect(() => {
    const interval = window.setInterval(() => {
      setHighlightedValue((current) => {
        const currentIndex = values.findIndex((item) => item.title === current);
        const nextIndex = currentIndex === values.length - 1 ? 0 : currentIndex + 1;
        return values[nextIndex].title;
      });
    }, 5000);

    return () => window.clearInterval(interval);
  }, [values]);

  return (
    <div className={styles.about}>
      <Helmet>
        <title>О портале «Мир Кошек»</title>
        <meta
          name="description"
          content="Познакомьтесь с командой портала «Мир Кошек», нашими ценностями, историей развития и подходом к созданию материалов."
        />
      </Helmet>

      <section className={styles.intro}>
        <div className="container">
          <div className={styles.introContent}>
            <h1 className={styles.title}>О портале</h1>
            <p className={styles.introText}>
              Мы создаем пространство, где есть место заботе, профессиональному опыту и вдохновению. «Мир Кошек» — это
              редакция, врачи и волонтёры, которые ежедневно отвечают на вопросы владельцев: от первых дней с котёнком
              до сопровождения возрастных питомцев.
            </p>
            <div className={styles.keyMetrics}>
              {metrics.map((metric) => (
                <div key={metric.label} className={styles.metricCard}>
                  <span className={styles.metricValue}>{metric.value}</span>
                  <span className={styles.metricLabel}>{metric.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2 className={styles.sectionTitle}>Что для нас важно</h2>
          <div className={styles.valueGrid}>
            {values.map((value) => (
              <article
                key={value.title}
                className={
                  highlightedValue === value.title
                    ? "${styles.valueCard} ${styles.valueActive}"
                    : styles.valueCard
                }
                onMouseEnter={() => setHighlightedValue(value.title)}
              >
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className="container">
          <h2 className={styles.sectionTitle}>Как развивался портал</h2>
          <ul className={styles.timelineList}>
            {timeline.map((item) => (
              <li key={item.year} className={styles.timelineItem}>
                <span className={styles.timelineYear}>{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className={styles.community}>
        <div className="container">
          <h2 className={styles.sectionTitle}>Сообщество и открытые проекты</h2>
          <p>
            Мы проводим онлайн-встречи с ветеринарными специалистами, разбираем нестандартные случаи поведения и
            публикуем подробные истории усыновления. Подписчики получают доступ к чек-листам и персонализированным
            подборкам статей.
          </p>
          <p>
            Если вы хотите предложить тему, поделиться историей или найти экспертное мнение, пишите нам через форму
            контактов. Чем больше голосов сообщества, тем точнее мы подбираем материалы и актуальные вопросы для
            обсуждения.
          </p>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;