import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const HomePage = () => {
  const [introVisible, setIntroVisible] = useState(false);
  const [loadedImages, setLoadedImages] = useState({});

  useEffect(() => {
    const timer = window.setTimeout(() => setIntroVisible(true), 200);
    return () => window.clearTimeout(timer);
  }, []);

  const handleImageLoad = (key) => {
    setLoadedImages((prev) => ({ ...prev, [key]: true }));
  };

  const popularBreeds = [
    {
      name: 'Мейн-кун',
      description:
        'Крупные и дружелюбные питомцы с роскошной шерстью. Легко находят общий язык с детьми и другими животными.',
      image: 'https://picsum.photos/seed/maine-coon-cat/720/520'
    },
    {
      name: 'Британская короткошерстная',
      description:
        'Спокойная аристократка с плюшевой шерстью. Любит уют и размеренный ритм жизни в доме.',
      image: 'https://picsum.photos/seed/british-shorthair-cat/720/520'
    },
    {
      name: 'Сфинкс',
      description:
        'Теплые на ощупь кошки, которые обожают общение. Требуют особого ухода за кожей и регулярных ванн.',
      image: 'https://picsum.photos/seed/sphynx-cat/720/520'
    },
    {
      name: 'Сибирская',
      description:
        'Выносливая и энергичная порода с выразительными глазами. Хорошо чувствует себя в активных семьях.',
      image: 'https://picsum.photos/seed/siberian-cat/720/520'
    }
  ];

  const careTips = [
    {
      icon: '🍽️',
      title: 'Сбалансированное питание',
      text: 'Подбирайте рацион вместе с ветеринаром и следите за режимом кормления, чтобы поддерживать здоровый вес.'
    },
    {
      icon: '🚿',
      title: 'Комфортный лоток',
      text: 'Регулярно очищайте лоток и обеспечьте доступ к чистой воде, чтобы сохранить гигиену и спокойствие питомца.'
    },
    {
      icon: '🪵',
      title: 'Игры и когтеточки',
      text: 'Создавайте сценарии для подвижных игр, добавляйте когтеточки и полки, чтобы кошка могла исследовать пространство.'
    }
  ];

  const facts = [
    'Кошки способны запоминать до 120 команд и жестов, если тренировки построены на заботе и доверии.',
    'Пульсирующее урчание помогает кошкам успокаиваться и даже ускоряет восстановление после травм.',
    'Усы помогают ориентироваться в пространстве, поэтому их нельзя подрезать даже ради эстетики.',
    'Чистота — врожденная привычка: кошки проводят в груминге до 30% бодрствования.'
  ];

  const testimonials = [
    {
      quote:
        '«Когда мы готовили цикл статей о приютских котах, команда «Мира Кошек» помогла нам с проверкой фактов и нашла специалистов для интервью.»',
      name: 'Марина Котова',
      role: 'редактор журнала «Лапы и Хвост»',
      image: 'https://picsum.photos/seed/editor-cat/160/160'
    },
    {
      quote:
        '«Благодаря их советам моя аллергия больше не мешает общению с мурлыками: подсказали подходящие породы и средства ухода.»',
      name: 'Андрей Лапшин',
      role: 'читатель портала',
      image: 'https://picsum.photos/seed/reader-cat/160/160'
    }
  ];

  const teamMembers = [
    {
      name: 'Екатерина Лисичкина',
      role: 'фелинолог и куратор пород',
      image: 'https://picsum.photos/seed/team-cat-1/200/200'
    },
    {
      name: 'Михаил Серый',
      role: 'ветеринарный консультант',
      image: 'https://picsum.photos/seed/team-cat-2/200/200'
    },
    {
      name: 'София Котова',
      role: 'редактор рубрики «Поведение»',
      image: 'https://picsum.photos/seed/team-cat-3/200/200'
    }
  ];

  return (
    <div className={styles.home}>
      <Helmet>
        <title>Мир Кошек — портал о кошках, уходе и породах</title>
        <meta
          name="description"
          content="Узнайте о породах, тонкостях ухода, поведении и здоровье кошек. Мир Кошек — портал, где знания сочетаются с любовью к питомцам."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={"container ${styles.heroInner} ${introVisible ? styles.heroVisible : ''}"}>
          <div className={styles.heroText}>
            <span className={styles.badge}>Портал для тех, кто любит кошек</span>
            <h1 className={styles.heroTitle}>Добро пожаловать в мир кошек</h1>
            <p className={styles.heroSubtitle}>
              Здесь собраны истории, практические рекомендации и экспертные мнения, чтобы ваши усатые друзья жили долго
              и счастливо. Погрузитесь в теплую атмосферу мурлыкающих фактов и заботы.
            </p>
            <div className={styles.heroActions}>
              <Link to="/porody-koshek" className="buttonPrimary">
                Изучить породы
              </Link>
              <Link to="/kontakty" className="buttonSecondary">
                Связаться с редакцией
              </Link>
            </div>
          </div>
          <div className={styles.heroMedia}>
            <div
              className={"${styles.imageWrap} ${loadedImages.hero ? styles.imageLoaded : ''}"}
              aria-hidden="true"
            >
              <img
                src="https://picsum.photos/seed/cat-hero-portal/860/720"
                alt="Светлая студия с пушистым котом на подоконнике"
                loading="lazy"
                onLoad={() => handleImageLoad('hero')}
              />
            </div>
          </div>
        </div>
      </section>

      <section className={"${styles.section} ${styles.aboutSection}"}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>О нас</h2>
            <p className={styles.sectionDescription}>
              «Мир Кошек» — независимый портал, который объединяет специалистов, волонтеров и владельцев кошек. Мы
              рассказываем о породах, делимся лайфхаками по здоровью и помогаем понимать язык хвостов и ушей.
            </p>
          </div>
          <div className={styles.aboutGrid}>
            <p>
              Мы верим, что каждая кошка уникальна. Поэтому каждый материал на портале проходит проверку у фелинологов и
              ветеринаров, а советы адаптированы под разные возрастные группы и условия проживания. От уютной городской
              квартиры до загородного дома — найдутся сценарии для всех.
            </p>
            <div className={styles.teamGrid}>
              {teamMembers.map((member) => (
                <article key={member.name} className={styles.teamCard}>
                  <div
                    className={"${styles.teamAvatarWrap} ${
                      loadedImages[member.name] ? styles.teamAvatarVisible : ''
                    }"}
                  >
                    <img
                      src={member.image}
                      alt={"${member.name} — ${member.role}"}
                      loading="lazy"
                      onLoad={() => handleImageLoad(member.name)}
                    />
                  </div>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Популярные породы</h2>
            <p className={styles.sectionDescription}>
              Подготовили первую подборку пород для знакомства. Внутри карточек — характер, уход и советы по играм.
            </p>
          </div>
          <div className={styles.grid}>
            {popularBreeds.map((breed) => (
              <article key={breed.name} className={styles.card}>
                <div className={styles.cardImage}>
                  <img
                    src={breed.image}
                    alt={"Кошка породы ${breed.name}"}
                    loading="lazy"
                    onLoad={() => handleImageLoad(breed.name)}
                    className={loadedImages[breed.name] ? styles.cardImageLoaded : ''}
                  />
                </div>
                <div className={styles.cardBody}>
                  <h3 className={styles.cardTitle}>{breed.name}</h3>
                  <p className={styles.cardText}>{breed.description}</p>
                  <Link to="/porody-koshek" className={styles.linkUnderline}>
                    Читать подробнее →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Советы по уходу</h2>
            <p className={styles.sectionDescription}>
              Основа благополучия — регулярность. Мы собрали фокусные направления, о которых стоит помнить каждый день.
            </p>
          </div>
          <div className={styles.careGrid}>
            {careTips.map((tip) => (
              <article key={tip.title} className={styles.careCard}>
                <span className={styles.careIcon} aria-hidden="true">
                  {tip.icon}
                </span>
                <h3 className={styles.cardTitle}>{tip.title}</h3>
                <p className={styles.cardText}>{tip.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Интересные факты и голоса читателей</h2>
            <p className={styles.sectionDescription}>
              Немного вдохновения и живые отклики тех, кто уже нашел ответы на вопросы о хвостатых спутниках.
            </p>
          </div>
          <div className={styles.factTestimonial}>
            <ul className={styles.factList}>
              {facts.map((fact) => (
                <li key={fact} className={styles.factItem}>
                  <span role="img" aria-label="лапка">
                    🐾
                  </span>
                  {fact}
                </li>
              ))}
            </ul>
            <div className={styles.testimonialGrid}>
              {testimonials.map((testimonial) => (
                <article key={testimonial.name} className={styles.testimonialCard}>
                  <p className={styles.testimonialQuote}>{testimonial.quote}</p>
                  <div className={styles.testimonialAuthor}>
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      loading="lazy"
                      className={styles.authorAvatar}
                      onLoad={() => handleImageLoad(testimonial.name)}
                    />
                    <div className={styles.authorInfo}>
                      <span className={styles.authorName}>{testimonial.name}</span>
                      <span className={styles.authorRole}>{testimonial.role}</span>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaInner}>
            <div>
              <h2 className={styles.ctaTitle}>Хотите узнать больше о породах и уходе?</h2>
              <p className={styles.ctaText}>
                В каталоге «Породы» вас ждут подробные профили и советы экспертов. А в разделах «Уход и здоровье» и
                «Поведение» — проверенные методики, которые помогут укрепить связь с питомцами.
              </p>
            </div>
            <Link to="/porody-koshek" className="buttonPrimary">
              Исследуйте материалы
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;