import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import BreedsPage, { CarePage, BehaviorPage } from './pages/Services';
import ContactsPage from './pages/Contact';
import ThankYouPage from './pages/ThankYou';
import TermsOfUsePage, { CookiePolicyPage } from './pages/TermsOfService';
import PrivacyPolicyPage from './pages/PrivacyPolicy';

function App() {
  return (
    <div className="app-shell">
      <Header />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/o-portale" element={<AboutPage />} />
          <Route path="/porody-koshek" element={<BreedsPage />} />
          <Route path="/uhod-i-zdorove" element={<CarePage />} />
          <Route path="/povedenie" element={<BehaviorPage />} />
          <Route path="/kontakty" element={<ContactsPage />} />
          <Route path="/politika-konfidencialnosti" element={<PrivacyPolicyPage />} />
          <Route path="/usloviya-ispolzovaniya" element={<TermsOfUsePage />} />
          <Route path="/politika-cookie" element={<CookiePolicyPage />} />
          <Route path="/spasibo" element={<ThankYouPage />} />
          <Route path="*" element={<HomePage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
}

export default App;