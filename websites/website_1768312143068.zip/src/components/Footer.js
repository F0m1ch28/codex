import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.footerInner}>
          <div>
            <h2 className={styles.footerTitle}>Мир Кошек</h2>
            <p className={styles.footerDescription}>
              Портал, где любители кошек находят ответы на вопросы об уходе, здоровье, поведении и особенностях
              разнообразных пород. Мы делимся опытом, историями и практическими рекомендациями.
            </p>
            <div className={styles.socialList}>
              <a
                className={styles.socialLink}
                href="https://www.instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram Мир Кошек"
              >
                🐾
              </a>
              <a
                className={styles.socialLink}
                href="https://vk.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="VK Мир Кошек"
              >
                ВК
              </a>
              <a
                className={styles.socialLink}
                href="https://www.youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="YouTube Мир Кошек"
              >
                ▶
              </a>
            </div>
          </div>
          <div className={styles.columns}>
            <div>
              <h3 className={styles.footerTitle}>Контакты</h3>
              <ul className={styles.contactList}>
                <li>
                  <span>ул. Кошачья, д. 15, г. Мурск, Россия</span>
                </li>
                <li>
                  <Link to="/kontakty#contact-form" className={styles.contactLink}>
                    <span role="img" aria-label="Телефон">
                      📞
                    </span>
                    +7 (495) 123-45-67
                  </Link>
                </li>
                <li>
                  <Link to="/kontakty#contact-form" className={styles.contactLink}>
                    <span role="img" aria-label="Почта">
                      ✉️
                    </span>
                    info@mir-koshek.ru
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className={styles.footerTitle}>Навигация</h3>
              <div className={styles.legalLinks}>
                <Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link>
                <Link to="/usloviya-ispolzovaniya">Условия использования</Link>
                <Link to="/politika-cookie">Политика использования cookie</Link>
              </div>
            </div>
            <div>
              <h3 className={styles.footerTitle}>Сообщество</h3>
              <p>
                Присоединяйтесь к рассылке, участвуйте в онлайн-встречах и делитесь историями о пушистых друзьях в нашей
                группе.
              </p>
            </div>
          </div>
        </div>
        <p className={styles.copy}>© {new Date().getFullYear()} Мир Кошек. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;