import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('mir-koshek-cookie-consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('mir-koshek-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о cookie">
      <p className={styles.text}>
        Мы используем cookie, чтобы сайт «Мир Кошек» работал корректно и помогал подбирать материалы по вашим
        интересам. Продолжая посещение, вы соглашаетесь с <Link to="/politika-cookie">политикой использования cookie</Link>.
      </p>
      <div className={styles.actions}>
        <button type="button" className={styles.acceptButton} onClick={handleAccept}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;