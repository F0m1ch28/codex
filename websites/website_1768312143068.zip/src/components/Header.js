import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMenuOpen]);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  return (
    <header className={styles.header}>
      <div className="container">
        <div className={styles.headerInner}>
          <Link to="/" className={styles.logo}>
            Мир Кошек
          </Link>
          <button
            type="button"
            className={styles.menuButton}
            aria-label={isMenuOpen ? 'Закрыть меню' : 'Открыть меню'}
            aria-expanded={isMenuOpen}
            onClick={toggleMenu}
          >
            <span className={isMenuOpen ? "${styles.menuIcon} ${styles.menuIconActive}" : styles.menuIcon} />
            <span className="visually-hidden">Переключатель меню</span>
          </button>
          <nav className={isMenuOpen ? "${styles.nav} ${styles.navOpen}" : styles.nav}>
            <ul className={styles.navList}>
              <li>
                <NavLink
                  to="/"
                  className={({ isActive }) =>
                    isActive ? "${styles.navLink} ${styles.navLinkActive}" : styles.navLink
                  }
                  end
                >
                  Главная
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/o-portale"
                  className={({ isActive }) =>
                    isActive ? "${styles.navLink} ${styles.navLinkActive}" : styles.navLink
                  }
                >
                  О портале
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/porody-koshek"
                  className={({ isActive }) =>
                    isActive ? "${styles.navLink} ${styles.navLinkActive}" : styles.navLink
                  }
                >
                  Породы кошек
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/uhod-i-zdorove"
                  className={({ isActive }) =>
                    isActive ? "${styles.navLink} ${styles.navLinkActive}" : styles.navLink
                  }
                >
                  Уход и здоровье
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/povedenie"
                  className={({ isActive }) =>
                    isActive ? "${styles.navLink} ${styles.navLinkActive}" : styles.navLink
                  }
                >
                  Поведение
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/kontakty"
                  className={({ isActive }) =>
                    isActive ? "${styles.navLink} ${styles.navLinkActive}" : styles.navLink
                  }
                >
                  Контакты
                </NavLink>
              </li>
            </ul>
            <Link to="/porody-koshek" className={"buttonPrimary ${styles.ctaLink}"}>
              Исследовать породы
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;