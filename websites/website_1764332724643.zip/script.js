document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            siteNav.classList.toggle('open');
            navToggle.classList.toggle('active');
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');

    if (cookieBanner && acceptBtn && declineBtn) {
        const storedPref = localStorage.getItem('tnit_cookie_pref');
        if (!storedPref) {
            cookieBanner.classList.add('show');
        }

        const closeBanner = (value) => {
            localStorage.setItem('tnit_cookie_pref', value);
            cookieBanner.classList.remove('show');
        };

        acceptBtn.addEventListener('click', () => closeBanner('accepted'));
        declineBtn.addEventListener('click', () => closeBanner('declined'));
    }

    const counters = document.querySelectorAll('[data-counter]');
    if (counters.length) {
        const counterObserver = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const el = entry.target;
                    const target = parseInt(el.getAttribute('data-target'), 10);
                    let current = 0;
                    const step = Math.ceil(target / 60);
                    const updateCounter = () => {
                        current += step;
                        if (current > target) current = target;
                        el.textContent = current;
                        if (current < target) {
                            requestAnimationFrame(updateCounter);
                        }
                    };
                    updateCounter();
                    counterObserver.unobserve(el);
                }
            });
        }, { threshold: 0.4 });
        counters.forEach(counter => counterObserver.observe(counter));
    }

    const chartCanvas = document.getElementById('performanceChart');
    if (chartCanvas) {
        const ctx = chartCanvas.getContext('2d');
        const width = chartCanvas.width;
        const height = chartCanvas.height;
        const padding = 40;
        const data = [32, 48, 44, 58, 62, 71, 68, 75];
        const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'];
        const maxValue = Math.max(...data) + 10;

        ctx.clearRect(0, 0, width, height);
        ctx.strokeStyle = 'rgba(255,255,255,0.2)';
        ctx.lineWidth = 1;

        for (let i = 0; i <= 4; i++) {
            const y = padding + ((height - padding * 2) / 4) * i;
            ctx.beginPath();
            ctx.moveTo(padding, y);
            ctx.lineTo(width - padding, y);
            ctx.stroke();
        }

        ctx.strokeStyle = 'rgba(255,255,255,0.4)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        data.forEach((value, index) => {
            const x = padding + ((width - padding * 2) / (data.length - 1)) * index;
            const y = height - padding - ((height - padding * 2) * value) / maxValue;
            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });
        ctx.stroke();

        ctx.fillStyle = 'rgba(255,255,255,0.3)';
        ctx.globalCompositeOperation = 'destination-over';
        ctx.beginPath();
        data.forEach((value, index) => {
            const x = padding + ((width - padding * 2) / (data.length - 1)) * index;
            const y = height - padding - ((height - padding * 2) * value) / maxValue;
            if (index === 0) {
                ctx.moveTo(x, height - padding);
                ctx.lineTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });
        const lastX = padding + ((width - padding * 2) / (data.length - 1)) * (data.length - 1);
        ctx.lineTo(lastX, height - padding);
        ctx.closePath();
        ctx.fill();

        ctx.globalCompositeOperation = 'source-over';
        ctx.fillStyle = 'var(--white)';
        ctx.font = '12px Inter';
        labels.forEach((label, index) => {
            const x = padding + ((width - padding * 2) / (data.length - 1)) * index;
            const y = height - padding + 18;
            ctx.fillText(label, x - 10, y);
        });
    }
});