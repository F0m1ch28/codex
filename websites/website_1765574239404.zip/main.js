document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.main-nav');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      navToggle.classList.toggle('open');
      nav.classList.toggle('open');
      document.body.classList.toggle('nav-open');
    });
    const navLinks = document.querySelectorAll('.main-nav .nav-link');
    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        if (document.body.classList.contains('nav-open')) {
          document.body.classList.remove('nav-open');
          navToggle.classList.remove('open');
          nav.classList.remove('open');
        }
      });
    });
  }

  const yearSpan = document.getElementById('currentYear');
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const storedConsent = localStorage.getItem('qazaqlearnCookieConsent');
  if (cookieBanner && !storedConsent) {
    setTimeout(() => cookieBanner.classList.add('visible'), 500);
  }
  const cookieButtons = document.querySelectorAll('.cookie-btn');
  cookieButtons.forEach(button => {
    button.addEventListener('click', () => {
      localStorage.setItem('qazaqlearnCookieConsent', button.dataset.action || 'decline');
      if (cookieBanner) {
        cookieBanner.classList.remove('visible');
      }
    });
  });
});