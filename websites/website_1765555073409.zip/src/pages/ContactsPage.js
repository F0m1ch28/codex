import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ContactsPage.module.css';

const ContactsPage = () => {
  const [formData, setFormData] = useState({ name: '', company: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Введите имя';
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите email';
    } else if (!/^[\w-.]+@[\w-]+\.[a-z]{2,}$/i.test(formData.email)) {
      newErrors.email = 'Введите корректный email';
    }
    if (!formData.message.trim()) newErrors.message = 'Опишите задачу';
    return newErrors;
  };

  const handleChange = (evt) => {
    const { name, value } = evt.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (evt) => {
    evt.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setSubmitted(true);
    setFormData({ name: '', company: '', email: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Контакты | Сколько вариантов сайта создать?</title>
        <meta
          name="description"
          content="Свяжитесь с агентством «Сколько вариантов сайта создать?». Мы в Москве и работаем со всей Россией. Обсудим ваши задачи и подготовим несколько вариантов сайта."
        />
      </Helmet>

      <section className={styles.hero}>
        <div>
          <h1>Давайте обсудим ваш следующий цифровой проект</h1>
          <p>
            Заполните форму, чтобы получить консультацию, или свяжитесь с нами напрямую через телефон или email. Мы ответим в течение рабочего дня и предложим удобное время для созвона.
          </p>
        </div>
        <div className={styles.contactDetails}>
          <div>
            <h2>Контакты</h2>
            <p>г. Москва, ул. Тверская, д. 7</p>
            <p><a href="tel:+74951234567">+7 (495) 123-45-67</a></p>
            <p><a href="mailto:info@skolko-variantov.ru">info@skolko-variantov.ru</a></p>
          </div>
          <div>
            <h2>График</h2>
            <p>Пн–Пт: 10:00 – 19:00</p>
            <p>Сб–Вс: по согласованию</p>
          </div>
        </div>
      </section>

      <section className={styles.formSection}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.formRow}>
            <label htmlFor="name">Имя *</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Как к вам обращаться?"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'error-name' : undefined}
            />
            {errors.name && <span id="error-name" className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.formRow}>
            <label htmlFor="company">Компания</label>
            <input
              id="company"
              name="company"
              type="text"
              placeholder="Название компании"
              value={formData.company}
              onChange={handleChange}
            />
          </div>
          <div className={styles.formRow}>
            <label htmlFor="email">Email *</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="name@company.ru"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'error-email' : undefined}
            />
            {errors.email && <span id="error-email" className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.formRow}>
            <label htmlFor="message">Опишите задачу *</label>
            <textarea
              id="message"
              name="message"
              placeholder="Расскажите о продукте, сроках и желаемом количестве концепций"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'error-message' : undefined}
            />
            {errors.message && <span id="error-message" className={styles.error}>{errors.message}</span>}
          </div>
          <button type="submit" className={styles.submitButton}>
            Отправить запрос
          </button>
          {submitted && (
            <p className={styles.success} role="status">
              Спасибо! Мы получили ваш запрос и свяжемся с вами в ближайшее время.
            </p>
          )}
        </form>
        <div className={styles.mapWrapper}>
          <iframe
            title="Офис агентства в Москве"
            src="https://yandex.ru/map-widget/v1/?um=constructor%3A2c90ec7a4e2c6b6f0c4aa0d0b348235a0bd7c453ab3d6e32d02f4a0a3c1b13d9&amp;source=constructor"
            width="100%"
            height="100%"
            frameBorder="0"
            aria-label="Карта с расположением офиса"
          />
        </div>
      </section>
    </>
  );
};

export default ContactsPage;