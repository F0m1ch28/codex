import { Helmet } from 'react-helmet-async';
import styles from './AboutPage.module.css';

const team = [
  {
    name: 'Дарья Осетрова',
    role: 'Креативный директор',
    bio: 'Создаёт стратегии и визуальные направления для digital-продуктов, ранее работала с брендами Сбер, Яндекс и Dodo.',
    image: 'https://picsum.photos/400/400?random=801'
  },
  {
    name: 'Алексей Морозов',
    role: 'Руководитель UX-исследований',
    bio: 'Проводит полевые исследования, отвечает за продуктовые гипотезы и модерацию пользовательских тестов.',
    image: 'https://picsum.photos/400/400?random=802'
  },
  {
    name: 'Людмила Грин',
    role: 'Лид-дизайнер',
    bio: 'Куратор дизайн-системы, отвечает за consistency и трансформацию визуального языка брендов.',
    image: 'https://picsum.photos/400/400?random=803'
  },
  {
    name: 'Роман Ким',
    role: 'Хед оф Продакшн',
    bio: 'Контролирует передачу дизайна разработчикам, строит Design Ops и следит за сроками и качеством.',
    image: 'https://picsum.photos/400/400?random=804'
  }
];

const AboutPage = () => (
  <>
    <Helmet>
      <title>О нас | Сколько вариантов сайта создать?</title>
      <meta
        name="description"
        content="Команда креативного агентства из Москвы. Мы объединяем стратегию, дизайн и исследовательские подходы, чтобы создавать несколько вариантов сайта."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <h1>Мы создаём пространство для выбора и роста</h1>
        <p>
          Агентство «Сколько вариантов сайта создать?» появилось как ответ на потребность бизнеса быстро находить эффективные решения. За 6 лет мы собрали команду дизайнеров, исследователей и продуктовых стратегов, которые умеют мыслить шире одного паттерна.
        </p>
      </div>
      <div className={styles.heroImageWrapper}>
        <img
          src="https://picsum.photos/1000/700?random=805"
          alt="Команда агентства в офисе"
          loading="lazy"
        />
      </div>
    </section>

    <section className={styles.valuesSection}>
      <div className={styles.valuesGrid}>
        <article>
          <h2>Наш подход</h2>
          <p>
            Мы создаём дизайн как систему принятия решений. Для нас важна не только эстетика, но и логика, метрики, опыт пользователей. Поэтому мы не ограничиваемся одним вариантом, а исследуем поле возможностей.
          </p>
        </article>
        <article>
          <h2>Команда</h2>
          <p>
            20 специалистов, включая операторов исследований, UX/UI-дизайнеров, арт-директоров и проджект-менеджеров. Мы работаем в гибридном формате: офис в Москве и удалённые эксперты по всей стране.
          </p>
        </article>
        <article>
          <h2>Миссия</h2>
          <p>
            Помочь компаниям расти благодаря смелым цифровым продуктам. Мы внедряем культуру экспериментов, поощряем диалог и открытость к изменениям.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.teamSection}>
      <h2>Команда лидов</h2>
      <div className={styles.teamGrid}>
        {team.map((member) => (
          <article key={member.name} className={styles.teamCard}>
            <img src={member.image} alt={member.name} loading="lazy" />
            <div className={styles.teamContent}>
              <h3>{member.name}</h3>
              <span>{member.role}</span>
              <p>{member.bio}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default AboutPage;