import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PortfolioPage.module.css';

const projects = [
  {
    title: 'Новый цифровой бренд для RetailX',
    category: 'Маркетплейс',
    description:
      'Комбинаторика из пяти визуальных концепций, модульная структура и персонализированные карточки каталога. Рост числа повторных покупок на 29%.',
    image: 'https://picsum.photos/1200/800?random=701',
    tags: ['UX', 'UI', 'Design System']
  },
  {
    title: 'TravelMind — вдохновляющие путешествия',
    category: 'TravelTech',
    description:
      'Рассказываем истории маршрутов через визуальные паттерны и интерактивные прототипы. Конверсия в бронирование увеличилась вдвое.',
    image: 'https://picsum.photos/1200/800?random=702',
    tags: ['UX Research', 'UI', 'Motion']
  },
  {
    title: 'FinPilot — финансовый помощник',
    category: 'Fintech',
    description:
      'Прозрачные дашборды, сценарии визуализации и поддержка accessibility. Среднее время принятия решения сократилось на 37%.',
    image: 'https://picsum.photos/1200/800?random=703',
    tags: ['Product Design', 'Accessibility']
  },
  {
    title: 'Eduverse — платформа обучения',
    category: 'EdTech',
    description:
      'Четыре концепции, основанные на стиле storytelling. Внедрена геймификация и гибкая система заданий. Вовлечённость выросла на 54%.',
    image: 'https://picsum.photos/1200/800?random=704',
    tags: ['UX', 'UI', 'Gamification']
  },
  {
    title: 'CityJoy — городской гид',
    category: 'Media',
    description:
      'Новый UI-кит на 200+ компонентов, ситуативные сценарии и умная лента рекомендаций. Удержание пользователей +23%.',
    image: 'https://picsum.photos/1200/800?random=705',
    tags: ['UX Strategy', 'UI Kit']
  },
  {
    title: 'MediCare — сервис телемедицины',
    category: 'HealthTech',
    description:
      'Создали три безопасных UX-сценария, адаптированных под врачей и пациентов. Сократили путь до консультации на 40%.',
    image: 'https://picsum.photos/1200/800?random=706',
    tags: ['UX', 'Product', 'Design System']
  }
];

const filters = ['Все', 'Маркетплейс', 'TravelTech', 'Fintech', 'EdTech', 'Media', 'HealthTech'];

const PortfolioPage = () => {
  const [activeFilter, setActiveFilter] = useState('Все');

  const filteredProjects =
    activeFilter === 'Все'
      ? projects
      : projects.filter((project) => project.category === activeFilter);

  return (
    <>
      <Helmet>
        <title>Портфолио | Сколько вариантов сайта создать?</title>
        <meta
          name="description"
          content="Портфолио креативного агентства: маркетплейсы, финтех, travel и медиа. Каждому проекту предшествует несколько концепций UX и UI."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Портфолио, в котором каждый проект — набор концепций</h1>
        <p>
          Мы работаем с разными отраслями и масштабами: от стартапов до крупных корпораций. Главное — найти решение, которое сработает именно для вашей аудитории.
        </p>
      </section>

      <section className={styles.filters}>
        {filters.map((filter) => (
          <button
            key={filter}
            type="button"
            className={`${styles.filterButton} ${filter === activeFilter ? styles.active : ''}`}
            onClick={() => setActiveFilter(filter)}
          >
            {filter}
          </button>
        ))}
      </section>

      <section className={styles.gridSection}>
        <div className={styles.grid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.card}>
              <img src={project.image} alt={project.title} loading="lazy" />
              <div className={styles.cardContent}>
                <span className={styles.category}>{project.category}</span>
                <h2>{project.title}</h2>
                <p>{project.description}</p>
                <div className={styles.tags}>
                  {project.tags.map((tag) => (
                    <span key={tag}>{tag}</span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default PortfolioPage;