import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ServicesPage.module.css';

const services = [
  {
    id: 1,
    title: 'Исследования и стратегия',
    excerpt: 'Глубокое понимание аудитории и бизнес-контекста для уверенного старта проекта.',
    description:
      'Проводим качественные и количественные исследования, сегментируем аудиторию, составляем CJM, формируем гипотезы и карту точек контакта. Вы получаете стратегию развития продукта и четкое понимание, какие сценарии необходимо протестировать.',
    highlights: ['Пользовательские интервью', 'Портреты клиентов и сценарии', 'Бенчмаркинг и UX-аудит'],
    image: 'https://picsum.photos/800/600?random=501'
  },
  {
    id: 2,
    title: 'Прототипирование и UX-концепции',
    excerpt: 'Создаём несколько UX-сценариев и проверяем их на реальных пользователях.',
    description:
      'Строим информационную архитектуру, формируем набор прототипов и интерактивных сценариев. Проводим юзабилити-тестирование, собираем обратную связь, улучшаем сценарии. В результате вы выбираете наиболее эффективный UX-подход.',
    highlights: ['Интерактивные прототипы Figma', 'Сессии тестирования', 'Метрики эффективности'],
    image: 'https://picsum.photos/800/600?random=502'
  },
  {
    id: 3,
    title: 'UI-концепции и визуальный язык',
    excerpt: 'От 3 до 6 визуальных направлений — каждый вариант раскрывает уникальную идею бренда.',
    description:
      'Подбираем эмоциональную тональность, создаем moodboard, анимации, 3D-элементы и иллюстрации. Сравниваем концепции с командой, тестируем на целевой аудитории и формируем итоговую дизайн-систему.',
    highlights: ['Moodboard и сторителлинг', 'UI-kit и компоненты', 'Микроанимации и иллюстрации'],
    image: 'https://picsum.photos/800/600?random=503'
  },
  {
    id: 4,
    title: 'Передача и сопровождение разработки',
    excerpt: 'Детализируем спецификации и поддерживаем разработчиков до релиза.',
    description:
      'Готовим гайдлайн по использованию дизайн-системы, описываем состояния и поведение компонентов. Помогаем внедрению, проводим ревью и участвуем в спринтах, чтобы итоговый продукт точно соответствовал выбранной концепции.',
    highlights: ['Figma Inspect', 'Дизайн-ревью', 'QA-поддержка'],
    image: 'https://picsum.photos/800/600?random=504'
  }
];

const ServicesPage = () => {
  const [activeService, setActiveService] = useState(services[0]);

  return (
    <>
      <Helmet>
        <title>Услуги | Сколько вариантов сайта создать?</title>
        <meta
          name="description"
          content="Комплексные услуги по разработке веб-дизайна: исследования, прототипирование, создание нескольких визуальных концепций и сопровождение разработки."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Услуги, которые раскрывают потенциал вашего продукта</h1>
          <p>
            Мы соединяем стратегию, данные и креатив. На каждом проекте готовим несколько решений, чтобы вы могли выбрать лучшее и быть уверенными в результате.
          </p>
        </div>
        <div className={styles.heroImageWrapper}>
          <img src="https://picsum.photos/1000/700?random=505" alt="Работа над дизайн-концепциями" loading="lazy" />
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className={styles.servicesList}>
          {services.map((service) => (
            <button
              key={service.id}
              type="button"
              className={`${styles.serviceButton} ${service.id === activeService.id ? styles.active : ''}`}
              onClick={() => setActiveService(service)}
            >
              <span className={styles.serviceTitle}>{service.title}</span>
              <span className={styles.serviceExcerpt}>{service.excerpt}</span>
            </button>
          ))}
        </div>
        <div className={styles.serviceDetails}>
          <img
            src={activeService.image}
            alt={activeService.title}
            className={styles.serviceImage}
            loading="lazy"
          />
          <div className={styles.detailContent}>
            <h2>{activeService.title}</h2>
            <p>{activeService.description}</p>
            <ul>
              {activeService.highlights.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.stackSection}>
        <div className={styles.stackContent}>
          <h2>Инструменты и подходы, которые мы используем</h2>
          <p>
            От базовых исследований до продвинутых VR-презентаций концепций — мы подбираем инструменты под задачу. Работая в Figma, Miro, Maze, Notion и Linear, мы синхронизируемся с вашей командой и сохраняем прозрачность процессов.
          </p>
          <div className={styles.stackGrid}>
            <span>Design Sprint</span>
            <span>Product Discovery</span>
            <span>Design System</span>
            <span>UX Research</span>
            <span>Figma</span>
            <span>Interactive Prototypes</span>
            <span>Design Ops</span>
            <span>Design Review</span>
          </div>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;