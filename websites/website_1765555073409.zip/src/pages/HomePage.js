import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './HomePage.module.css';

const HomePage = () => {
  const statsData = [
    { label: 'Концепций на проект', target: 5, suffix: '+' },
    { label: 'Проектов завершено', target: 120, suffix: '' },
    { label: 'Средняя скорость запуска (дней)', target: 21, suffix: '' },
    { label: 'Удовлетворенность клиентов', target: 98, suffix: '%' }
  ];

  const [displayedStats, setDisplayedStats] = useState(statsData.map(() => 0));

  useEffect(() => {
    let animationFrame;
    const startTime = performance.now();
    const duration = 1600;

    const animate = (currentTime) => {
      const progress = Math.min((currentTime - startTime) / duration, 1);
      setDisplayedStats(
        statsData.map((stat) => Math.floor(stat.target * progress))
      );
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const testimonials = [
    {
      quote: 'Команда подготовила четыре разных концепции для нашего нового маркетплейса, и каждая была уникальна. В результате мы совместили лучшие элементы и запустили рекордно быстро.',
      name: 'Екатерина Романова',
      role: 'Руководитель Digital-направления, RetailX',
      avatar: 'https://picsum.photos/200/200?random=601'
    },
    {
      quote: 'Редкий случай, когда дизайнеры предлагают настолько продуманные UX-решения. Проектирование, прототипы, визуал — всё на высоте. И никаких шаблонов.',
      name: 'Игорь Соколов',
      role: 'CEO, FinPilot',
      avatar: 'https://picsum.photos/200/200?random=602'
    },
    {
      quote: 'Они помогли нам быстро протестировать концепции для нового сервиса бронирования. Пользователи уже на этапе тестирования ставили высокие оценки интерфейсу.',
      name: 'Марина Волкова',
      role: 'Product Owner, TravelMind',
      avatar: 'https://picsum.photos/200/200?random=603'
    }
  ];

  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const faqItems = [
    {
      question: 'Сколько концепций вы предоставляете на старте проекта?',
      answer: 'Мы готовим от трёх до шести вариантов визуальной концепции и UX-подходов. Количество зависит от масштаба задач, обсуждается на брифинге и фиксируется в техническом задании.'
    },
    {
      question: 'Какие этапы включает сотрудничество?',
      answer: 'Мы начинаем с исследования, затем готовим прототипы и интерактивные сценарии, создаём несколько стилистических направлений и проводим тестирование с фокус-группами. После выбора концепции переходим к дизайн-системе и передаём готовые файлы команде разработки.'
    },
    {
      question: 'Работаете ли вы по готовым брендгайдам?',
      answer: 'Да, мы легко интегрируемся в существующую айдентику. Также можем доработать брендгайд или предложить рекомендации по обновлению визуальной системы.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Главная | Сколько вариантов сайта создать?</title>
        <meta
          name="description"
          content="Креативное агентство из Москвы. Разрабатываем уникальные веб-дизайны, готовим несколько концепций и сопровождаем запуск цифровых продуктов."
        />
        <meta
          name="keywords"
          content="веб-дизайн, варианты дизайна, креативное агентство, UI/UX, прототипирование, индивидуальный дизайн"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <span className={styles.badge}>Digital-проекты с несколькими сценариями</span>
          <h1 className={styles.heroTitle}>
            Больше, чем один вариант.<br />Креативные решения для вашего сайта.
          </h1>
          <p className={styles.heroSubtitle}>
            Мы создаём набор продуманных концепций веб-сайтов и интерфейсов: от исследования и UX-сценариев до полноценного дизайна и передачи в разработку.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.primaryButton}>
              Обсудить проект
            </Link>
            <Link to="/portfolio" className={styles.secondaryButton}>
              Смотреть портфолио
            </Link>
          </div>
          <div className={styles.heroMeta}>
            <div>
              <span className={styles.metaLabel}>Вариантов на выбор</span>
              <span className={styles.metaValue}>от 3</span>
            </div>
            <div>
              <span className={styles.metaLabel}>Найдено инсайтов</span>
              <span className={styles.metaValue}>127+</span>
            </div>
            <div>
              <span className={styles.metaLabel}>Команда</span>
              <span className={styles.metaValue}>20 экспертов</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.introSection}>
        <div className={styles.sectionContainer}>
          <div className={styles.introContent}>
            <h2>Почему мы делаем больше вариантов</h2>
            <p>
              Мы верим, что сильный продукт рождается из столкновения идей. Вместо одного решения мы предлагаем несколько дизайн-направлений,
              которые проходят проверку на аудитории и внутри команды заказчика. Так появляется уверенность в правильном выборе.
            </p>
            <ul className={styles.benefitsList}>
              <li>
                <span className={styles.benefitIcon}>💡</span>
                <div>
                  <h3>Продуманная стратегия</h3>
                  <p>Анализируем пользователей, бизнес-модель и тренды, формируем гипотезы и UX-карты.</p>
                </div>
              </li>
              <li>
                <span className={styles.benefitIcon}>🎯</span>
                <div>
                  <h3>Фокус на результат</h3>
                  <p>Сравниваем концепции по KPI, вовлеченности и экономике, выбираем эффективную.</p>
                </div>
              </li>
              <li>
                <span className={styles.benefitIcon}>🤝</span>
                <div>
                  <h3>Работа в паре с вашей командой</h3>
                  <p>Интегрируемся в процессы, подхватываем задачи продуктовой и маркетинговой команд.</p>
                </div>
              </li>
            </ul>
          </div>
          <div className={styles.introImageWrapper}>
            <img
              src="https://picsum.photos/800/900?random=202"
              alt="Команда дизайнеров за разработкой концепции"
              className={styles.introImage}
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className={styles.sectionContainer}>
          {statsData.map((stat, index) => (
            <div key={stat.label} className={styles.statCard}>
              <span className={styles.statValue}>
                {displayedStats[index]}
                {stat.suffix}
              </span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.servicesPreview}>
        <div className={styles.sectionHeader}>
          <h2>Что мы делаем</h2>
          <p>Комплексный подход: от исследования до подготовки дизайн-системы и передачи концепций разработчикам.</p>
        </div>
        <div className={styles.servicesGrid}>
          <article className={styles.serviceCard}>
            <img
              src="https://picsum.photos/600/400?random=305"
              alt="Команда проводит UX-исследование"
              loading="lazy"
            />
            <div className={styles.cardContent}>
              <h3>Исследование и аналитика</h3>
              <p>Интервью, CJM, конкурентный анализ, карты пользовательских потоков и прототипы.</p>
            </div>
          </article>
          <article className={styles.serviceCard}>
            <img
              src="https://picsum.photos/600/400?random=306"
              alt="Дизайнер создаёт визуальные концепции"
              loading="lazy"
            />
            <div className={styles.cardContent}>
              <h3>Визуальные концепции</h3>
              <p>Готовим несколько стилистических направлений, создаём moodboard, анимации и UI-пакеты.</p>
            </div>
          </article>
          <article className={styles.serviceCard}>
            <img
              src="https://picsum.photos/600/400?random=307"
              alt="UX-проектирование интерфейсов"
              loading="lazy"
            />
            <div className={styles.cardContent}>
              <h3>UX/UI дизайн-системы</h3>
              <p>Собираем эволюционную дизайн-систему: компоненты, библиотека состояний, гайдлайны.</p>
            </div>
          </article>
        </div>
        <div className={styles.sectionFooter}>
          <Link to="/uslugi" className={styles.linkButton}>
            Все услуги
          </Link>
        </div>
      </section>

      <section className={styles.processPreview}>
        <div className={styles.sectionContainer}>
          <div className={styles.processIntro}>
            <h2>Как строится работа</h2>
            <p>Прозрачный поэтапный процесс, в котором вы участвуете на каждом шаге, получая контроль и гибкость.</p>
            <Link to="/process" className={styles.linkInline}>
              Подробнее о процессе →
            </Link>
          </div>
          <div className={styles.processSteps}>
            <div className={styles.step}>
              <span className={styles.stepNumber}>01</span>
              <h3>Диагностика и брифинг</h3>
              <p>Интервью с командой, экспресс-исследование аудитории, фиксация целей и KPI проекта.</p>
            </div>
            <div className={styles.step}>
              <span className={styles.stepNumber}>02</span>
              <h3>UX-концепции и прототипы</h3>
              <p>Готовим сценарии, архитектуру, интерактивные прототипы для тестов и обсуждений.</p>
            </div>
            <div className={styles.step}>
              <span className={styles.stepNumber}>03</span>
              <h3>UI-направления и тестирование</h3>
              <p>Создаём несколько визуальных концепций, тестируем c пользователями, дорабатываем.</p>
            </div>
            <div className={styles.step}>
              <span className={styles.stepNumber}>04</span>
              <h3>Финал и поддержка</h3>
              <p>Собираем дизайн-систему, передаём спецификации и консультируем разработчиков.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.portfolioPreview}>
        <div className={styles.sectionHeader}>
          <h2>Недавние проекты</h2>
          <p>Каждый кейс — это сразу несколько вариантов решения, из которых рождается идеальный продукт.</p>
        </div>
        <div className={styles.portfolioGrid}>
          <article className={styles.portfolioCard}>
            <img
              src="https://picsum.photos/1200/800?random=408"
              alt="Онлайн-маркетплейс для брендов одежды"
              loading="lazy"
            />
            <div className={styles.portfolioContent}>
              <span className={styles.portfolioTag}>Маркетплейс</span>
              <h3>RetailX: новый язык для покупок</h3>
              <p>Четыре стилистических решения, тесты на 60 пользователях и рост конверсии в каталог на 32%.</p>
            </div>
          </article>
          <article className={styles.portfolioCard}>
            <img
              src="https://picsum.photos/1200/800?random=409"
              alt="Финансовое приложение"
              loading="lazy"
            />
            <div className={styles.portfolioContent}>
              <span className={styles.portfolioTag}>Fintech</span>
              <h3>FinPilot: цифровой консультант</h3>
              <p>Три UX-сценария, динамические графики, адаптивная дизайн-система и точность прогнозов +21%.</p>
            </div>
          </article>
          <article className={styles.portfolioCard}>
            <img
              src="https://picsum.photos/1200/800?random=410"
              alt="Платформа для бронирования путешествий"
              loading="lazy"
            />
            <div className={styles.portfolioContent}>
              <span className={styles.portfolioTag}>TravelTech</span>
              <h3>TravelMind: вдохновляющие маршруты</h3>
              <p>Сторителлинг, интерактивные прототипы и инфографика, обеспечившие рост вовлеченности на 45%.</p>
            </div>
          </article>
        </div>
        <div className={styles.sectionFooter}>
          <Link to="/portfolio" className={styles.linkButton}>
            Смотреть все работы
          </Link>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <h2>Что говорят клиенты</h2>
          <p>Мы сопровождаем запуск продукта до первых показателей и помогаем добиться ощутимых результатов.</p>
        </div>
        <div className={styles.testimonialSlider}>
          <button
            type="button"
            className={styles.sliderControl}
            onClick={() => setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)}
            aria-label="Предыдущий отзыв"
          >
            ←
          </button>
          <div className={styles.testimonialCard}>
            <img
              src={testimonials[currentTestimonial].avatar}
              alt={`Портрет клиента ${testimonials[currentTestimonial].name}`}
              className={styles.testimonialAvatar}
              loading="lazy"
            />
            <p className={styles.testimonialQuote}>&ldquo;{testimonials[currentTestimonial].quote}&rdquo;</p>
            <p className={styles.testimonialAuthor}>{testimonials[currentTestimonial].name}</p>
            <span className={styles.testimonialRole}>{testimonials[currentTestimonial].role}</span>
          </div>
          <button
            type="button"
            className={styles.sliderControl}
            onClick={() => setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)}
            aria-label="Следующий отзыв"
          >
            →
          </button>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className={styles.sectionHeader}>
          <h2>Ответы на популярные вопросы</h2>
          <p>Если у вас остались дополнительные вопросы — напишите нам, и мы подготовим детальную консультацию.</p>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <details key={item.question} className={styles.faqItem}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.sectionContainer}>
          <div className={styles.ctaContent}>
            <h2>Готовы создать несколько вариантов будущего вашего сайта?</h2>
            <p>Расскажите нам о задачах и сроках. Мы подготовим бриф, подберём команду и предложим план по запуску нескольких концепций.</p>
            <Link to="/kontakty" className={styles.primaryButton}>
              Назначить встречу
            </Link>
          </div>
          <div className={styles.ctaImageWrapper}>
            <img
              src="https://picsum.photos/800/600?random=211"
              alt="Рабочее обсуждение интерфейса в дизайне-студии"
              loading="lazy"
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;