import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.column}>
        <h3 className={styles.title}>🎨 Сколько вариантов сайта создать?</h3>
        <p className={styles.text}>
          Креативное агентство полного цикла. Придумываем, проектируем и визуализируем несколько концепций цифровых продуктов, чтобы вы могли выбрать идеальное решение.
        </p>
        <p className={styles.legal}>© {new Date().getFullYear()} Сколько вариантов сайта создать? Все права защищены.</p>
      </div>
      <div className={styles.column}>
        <h4 className={styles.subtitle}>Навигация</h4>
        <ul className={styles.list}>
          <li><Link to="/" className={styles.link}>Главная</Link></li>
          <li><Link to="/uslugi" className={styles.link}>Услуги</Link></li>
          <li><Link to="/process" className={styles.link}>Процесс</Link></li>
          <li><Link to="/portfolio" className={styles.link}>Портфолио</Link></li>
          <li><Link to="/o-nas" className={styles.link}>О нас</Link></li>
          <li><Link to="/kontakty" className={styles.link}>Контакты</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4 className={styles.subtitle}>Контакты</h4>
        <ul className={styles.list}>
          <li className={styles.text}>Адрес: г. Москва, ул. Тверская, д. 7</li>
          <li className={styles.text}>Телефон: <a href="tel:+74951234567" className={styles.link}>+7 (495) 123-45-67</a></li>
          <li className={styles.text}>Email: <a href="mailto:info@skolko-variantov.ru" className={styles.link}>info@skolko-variantov.ru</a></li>
        </ul>
        <div className={styles.policyLinks}>
          <Link to="/terms" className={styles.link}>Условия использования</Link>
          <Link to="/privacy" className={styles.link}>Политика конфиденциальности</Link>
          <Link to="/cookie-policy" className={styles.link}>Политика cookie</Link>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;