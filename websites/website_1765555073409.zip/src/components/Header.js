import { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <div className={styles.container}>
        <Link to="/" className={styles.logo} onClick={closeMenu}>
          🎨 Сколько вариантов сайта создать?
        </Link>
        <button
          type="button"
          className={`${styles.navToggle} ${menuOpen ? styles.navToggleActive : ''}`}
          onClick={toggleMenu}
          aria-label={menuOpen ? 'Закрыть меню' : 'Открыть меню'}
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}>
          <NavLink to="/" end className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`} onClick={closeMenu}>
            Главная
          </NavLink>
          <NavLink to="/uslugi" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`} onClick={closeMenu}>
            Услуги
          </NavLink>
          <NavLink to="/process" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`} onClick={closeMenu}>
            Процесс
          </NavLink>
          <NavLink to="/portfolio" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`} onClick={closeMenu}>
            Портфолио
          </NavLink>
          <NavLink to="/o-nas" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`} onClick={closeMenu}>
            О нас
          </NavLink>
          <NavLink to="/kontakty" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`} onClick={closeMenu}>
            Контакты
          </NavLink>
          <Link to="/kontakty" className={styles.ctaLink} onClick={closeMenu}>
            Связаться
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;