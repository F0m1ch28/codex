import { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('cookieConsent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleConsent = (value) => {
    window.localStorage.setItem('cookieConsent', value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о cookie">
      <div className={styles.textWrapper}>
        <p className={styles.text}>
          Мы используем cookie, чтобы анализировать взаимодействие с сайтом и предлагать персонализированные решения. Вы можете принять или отклонить использование cookie.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.accept} onClick={() => handleConsent('accepted')}>
          Принять
        </button>
        <button type="button" className={styles.decline} onClick={() => handleConsent('declined')}>
          Отклонить
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;