document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = mainNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    mainNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        mainNav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('.cookie-accept');
  const declineBtn = document.querySelector('.cookie-decline');
  const consentKey = 'cookieConsent';

  if (cookieBanner && acceptBtn && declineBtn) {
    const consent = localStorage.getItem(consentKey);

    if (!consent) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add('is-visible');
      });
    }

    acceptBtn.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'accepted');
      cookieBanner.classList.remove('is-visible');
    });

    declineBtn.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'declined');
      cookieBanner.classList.remove('is-visible');
    });
  }
});