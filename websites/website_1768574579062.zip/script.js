document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            const isOpen = navLinks.classList.toggle('is-open');
            navToggle.classList.toggle('is-active', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen);
        });

        navLinks.querySelectorAll('a').forEach((link) => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('is-open')) {
                    navLinks.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');

    if (cookieBanner && acceptBtn && declineBtn) {
        const storedPreference = localStorage.getItem('mx_cookie_pref');
        if (!storedPreference) {
            cookieBanner.classList.add('is-visible');
        }

        const handlePreference = (value) => {
            localStorage.setItem('mx_cookie_pref', value);
            cookieBanner.classList.remove('is-visible');
        };

        acceptBtn.addEventListener('click', () => handlePreference('accepted'));
        declineBtn.addEventListener('click', () => handlePreference('declined'));
    }
});