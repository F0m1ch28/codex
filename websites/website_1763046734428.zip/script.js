document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    const mainNav = document.querySelector('.main-nav');
    const scrollTopBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const contactForm = document.getElementById('contactForm');
    const formMessage = document.getElementById('formMessage');

    /* Mobile navigation */
    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            menuToggle.classList.toggle('open');
            if (navLinks) {
                navLinks.classList.toggle('open');
            }
            if (mainNav) {
                mainNav.classList.toggle('open');
            }
            const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
            menuToggle.setAttribute('aria-expanded', (!expanded).toString());
        });
    }

    /* Smooth scrolling for anchor links */
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', event => {
            const targetId = anchor.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                event.preventDefault();
                targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
                if (navLinks) {
                    navLinks.classList.remove('open');
                }
                if (mainNav) {
                    mainNav.classList.remove('open');
                }
                if (menuToggle) {
                    menuToggle.classList.remove('open');
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            }
        });
    });

    /* Scroll to top button */
    const toggleScrollTop = () => {
        if (window.scrollY > 400) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    };

    if (scrollTopBtn) {
        window.addEventListener('scroll', toggleScrollTop);
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    /* Cookie banner */
    if (cookieBanner) {
        const consent = localStorage.getItem('velontrixCookieConsent');
        if (consent === 'accepted') {
            cookieBanner.classList.add('hidden');
        } else {
            cookieBanner.classList.remove('hidden');
        }

        if (acceptCookiesBtn) {
            acceptCookiesBtn.addEventListener('click', () => {
                localStorage.setItem('velontrixCookieConsent', 'accepted');
                cookieBanner.classList.add('hidden');
            });
        }
    }

    /* Contact form handling */
    if (contactForm && formMessage) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get('name')?.trim();
            const email = formData.get('email')?.trim();
            const message = formData.get('message')?.trim();

            if (!name || !email || !message) {
                formMessage.textContent = 'Bitte füllen Sie alle Pflichtfelder aus.';
                formMessage.style.color = '#f39c12';
                return;
            }

            formMessage.textContent = 'Vielen Dank für Ihre Nachricht. Wir melden uns zeitnah.';
            formMessage.style.color = '#00b894';
            contactForm.reset();
        });
    }
});