const casinosData = [
  {
    id: 1,
    name: "LuckySpin Casino",
    slug: "luckyspin-casino",
    logo: "/images/luckyspin.svg",
    rating: 4.6,
    tagline: "Инновационная платформа с мгновенными выплатами",
    description:
      "LuckySpin Casino — международное онлайн-казино с лицензией MGA, более 2 800 игр и прозрачными бонусными условиями. Команда оператора уделяет внимание ответственному гэмблингу и регулярно проходит аудиты независимых лабораторий.",
    founded: 2014,
    license: "Malta Gaming Authority (MGA)",
    owner: "LuckySpin Entertainment Ltd.",
    headquarters: "Сент-Джулианс, Мальта",
    welcomeBonus: "150% на первый депозит + 150 фриспинов",
    noDepositBonus: "25 фриспинов за регистрацию после верификации",
    cashback: "Еженедельный кэшбэк до 15% с динамической шкалой",
    games: {
      slots: "Более 1800 слотов от 37 провайдеров",
      roulette: "16 видов рулетки, включая lightning-форматы",
      blackjack: "12 столов с лимитами для разных игроков",
      poker: "Hold’em, Omaha и турниры Sit&Go",
      live: "Live-студии Evolution, Pragmatic Play Live и Playtech"
    },
    wager: "30x на бонус и фриспины",
    minDeposit: "20 единиц в эквиваленте выбранной валюты",
    wageringPeriod: "15 дней с момента активации",
    paymentMethods: ["Visa", "Mastercard", "Skrill", "Neteller", "Bitcoin", "Ethereum"],
    withdrawalTime: "от 1 до 24 часов после верификации",
    currencies: ["USD", "EUR", "CAD", "AUD", "USDT"],
    support: {
      email: "support@luckyspin.com",
      chat: "Круглосуточный live-чарт",
      languages: ["EN", "RU", "DE", "ES"],
      responseTime: "в среднем 2 минуты"
    },
    responsibleGaming: ["Самоисключение", "Лимиты депозитов", "Тесты самооценки"],
    rtp: "97.1%",
    gameCount: 2800,
    averagePayout: "96.8%",
    focusMarkets: ["Европа", "Канада", "Новая Зеландия"],
    highlights: [
      "Глубокая программа VIP с персональным менеджером",
      "Прозрачная система верификации до 12 часов",
      "Регулярные проверки независимой лабораторией iTech Labs"
    ],
    categories: {
      bonus: "Щедрые приветственные бонусы",
      games: "Максимальная библиотека слотов",
      license: "MGA"
    }
  },
  {
    id: 2,
    name: "GoldFortune Club",
    slug: "goldfortune-club",
    logo: "/images/goldfortune.svg",
    rating: 4.4,
    tagline: "Премиальный сервис с акцентом на VIP-программы",
    description:
      "GoldFortune Club ориентирован на опытных игроков, предлагая гибкие бонусные предложения и продвинутую аналитику ставок. Платформа работает под лицензией Кюрасао и регулярно обновляет линейку live-игр.",
    founded: 2016,
    license: "Antillephone N.V. (Кюрасао)",
    owner: "Aurora Interactive B.V.",
    headquarters: "Виллемстад, Кюрасао",
    welcomeBonus: "200% приветственный пакет на три депозита",
    noDepositBonus: "Бездепозитные миссии для новых клиентов",
    cashback: "Кэшбэк до 18% для статуса Platinum",
    games: {
      slots: "Актуальные релизы и эксклюзивы GoldFortune Originals",
      roulette: "Lightning, Auto, Immersive",
      blackjack: "VIP-столы с расширенной статистикой",
      poker: "Видео-покер и турниры с живыми дилерами",
      live: "Студии от Ezugi, Vivo Gaming и BetGames"
    },
    wager: "35x на бонусные средства",
    minDeposit: "25 единиц в эквиваленте валюты",
    wageringPeriod: "14 дней",
    paymentMethods: ["Visa", "Mastercard", "Paysafecard", "MiFinity", "Skrill"],
    withdrawalTime: "от 2 до 48 часов после подтверждения",
    currencies: ["EUR", "USD", "BRL", "JPY", "BTC"],
    support: {
      email: "help@goldfortune.com",
      chat: "Поддержка 24/7 с отделом VIP",
      languages: ["EN", "RU", "PT", "JP"],
      responseTime: "до 5 минут в live-чате"
    },
    responsibleGaming: ["Настройка сессий", "Напоминания о времени", "Ссылки на службы поддержки"],
    rtp: "96.5%",
    gameCount: 2100,
    averagePayout: "96.1%",
    focusMarkets: ["Европа", "Бразилия", "Япония"],
    highlights: [
      "VIP-программа с индивидуальными лимитами выплат",
      "Отчёты о транзакциях в личном кабинете",
      "Проведение ежемесячных аудитов KPMG"
    ],
    categories: {
      bonus: "Многоуровневый приветственный пакет",
      games: "Эксклюзивные live-шоу",
      license: "Curacao"
    }
  },
  {
    id: 3,
    name: "RoyalAce Lounge",
    slug: "royalace-lounge",
    logo: "/images/royalace.svg",
    rating: 4.7,
    tagline: "Лицензированное казино с акцентом на live-опыт",
    description:
      "RoyalAce Lounge сочетает выдержанный дизайн и сдержанный подход к бонусам с высоким средним RTP. Казино работает по лицензии UKGC и ориентировано на игроков, ценящих высокую надежность и точное соблюдение регуляторных норм.",
    founded: 2012,
    license: "United Kingdom Gambling Commission (UKGC)",
    owner: "RoyalAce Digital Ltd.",
    headquarters: "Лондон, Великобритания",
    welcomeBonus: "100% на первый депозит + live-фриспины",
    noDepositBonus: "Тестовый демо-доступ к новым live-играм",
    cashback: "Персональные офферы для лояльных клиентов",
    games: {
      slots: "Классические и Megaways с высокими лимитами ставок",
      roulette: "Live-рулетки с многокамерной трансляцией",
      blackjack: "Столы с боковыми ставками и статистикой",
      poker: "Партнёрские турниры с лицензированными покер-румами",
      live: "Премиум студии Evolution и Authentic Gaming"
    },
    wager: "25x на приветственный бонус",
    minDeposit: "30 единиц в эквиваленте валюты",
    wageringPeriod: "10 дней",
    paymentMethods: ["Visa", "Mastercard", "Trustly", "Bank Transfer", "Skrill", "Apple Pay"],
    withdrawalTime: "от 24 до 48 часов, банковский перевод до 3 дней",
    currencies: ["GBP", "EUR", "USD", "NOK"],
    support: {
      email: "support@royalace.co.uk",
      chat: "Приём запросов 18/7 с приоритетом для UK",
      languages: ["EN", "NO", "DE"],
      responseTime: "до 3 минут в часы пик"
    },
    responsibleGaming: ["Годовые отчеты UKGC", "Инструменты самоограничения", "Поддержка GamCare"],
    rtp: "97.6%",
    gameCount: 1950,
    averagePayout: "97.3%",
    focusMarkets: ["Великобритания", "Скандинавия"],
    highlights: [
      "Направленная поддержка ответственной игры",
      "Полная соответствие требованиям UKGC",
      "Live-зал с персональными дилерами на ключевых языках"
    ],
    categories: {
      bonus: "Сбалансированный вейджер",
      games: "Фокус на live-дилерах",
      license: "UKGC"
    }
  },
  {
    id: 4,
    name: "MegaWin Station",
    slug: "megawin-station",
    logo: "/images/megawin.svg",
    rating: 4.3,
    tagline: "Многофункциональная платформа с турнирами и миссиями",
    description:
      "MegaWin Station предоставляет обширную библиотеку игр, ежедневные турниры и гибкую систему миссий. Казино сертифицировано в Эстонии (EMTA) и активно развивается в направлении быстрых платежей.",
    founded: 2018,
    license: "Estonian Tax and Customs Board (EMTA)",
    owner: "Nordic Pulse Gaming OÜ",
    headquarters: "Таллин, Эстония",
    welcomeBonus: "Миссия «Старт» с пакетами бонусных вращений",
    noDepositBonus: "Еженедельные фриспины за выполнение заданий",
    cashback: "Динамический кешбэк до 12%",
    games: {
      slots: "Слоты с механикой Cluster Pays и джекпотами",
      roulette: "Рулетки с множителями и side-bet",
      blackjack: "Столы с функцией «ранний выход»",
      poker: "Видео-покер и мультиплеерные турниры",
      live: "Live-игры в коллаборации с OnAir Entertainment"
    },
    wager: "32x на бонусные активы",
    minDeposit: "15 единиц в эквиваленте валюты",
    wageringPeriod: "12 дней",
    paymentMethods: ["Visa", "Mastercard", "Revolut", "Skrill", "Neteller", "USDT"],
    withdrawalTime: "в среднем 6 часов, максимум 24 часа",
    currencies: ["EUR", "USD", "SEK", "USDT"],
    support: {
      email: "team@megawinstation.com",
      chat: "Live-чарт ежедневно 09:00-02:00 CET",
      languages: ["EN", "RU", "EE", "SE"],
      responseTime: "примерно 4 минуты"
    },
    responsibleGaming: ["Лимиты депозитов и проигрышей", "История ставок", "Самоисключение до 1 года"],
    rtp: "96.9%",
    gameCount: 2400,
    averagePayout: "96.4%",
    focusMarkets: ["Балтия", "Центральная Европа"],
    highlights: [
      "Ежедневные турниры с прозрачным лидербордом",
      "Быстрые выплаты через Revolut и SEPA Instant",
      "Сертификация RNG компанией Gaming Laboratories International"
    ],
    categories: {
      bonus: "Геймификация и миссии",
      games: "Турнирные активности",
      license: "EMTA"
    }
  },
  {
    id: 5,
    name: "Prestige Palace",
    slug: "prestige-palace",
    logo: "/images/prestige.svg",
    rating: 4.5,
    tagline: "Лакшери-казино с персонализированной аналитикой",
    description:
      "Prestige Palace предлагает премиальный подход к клиентскому сервису, выделяя персональные рекомендации и аналитические отчёты по играм. Казино регулируется Комиссией Гибралтара и сотрудничает с ведущими провайдерами.",
    founded: 2015,
    license: "Gibraltar Gambling Commissioner",
    owner: "Prestige Leisure Group Ltd.",
    headquarters: "Гибралтар",
    welcomeBonus: "Персональный приветственный пакет до трёх депозитов",
    noDepositBonus: "Инвайт-оферы после ручной проверки аккаунта",
    cashback: "Индивидуальные условия для статусов Gold и Platinum",
    games: {
      slots: "Портфель премиум-слотов с высоким RTP",
      roulette: "Эксклюзивные столы Prestige Live",
      blackjack: "High-roller столы с лимитами по запросу",
      poker: "Турниры с квалификацией на офлайн-события",
      live: "Live-студии с уникальным оформлением и статистикой"
    },
    wager: "28x на приветственные бонусные средства",
    minDeposit: "40 единиц в эквиваленте валюты",
    wageringPeriod: "14 дней",
    paymentMethods: ["Visa", "Mastercard", "Wire Transfer", "Skrill", "Neteller", "CryptoPay"],
    withdrawalTime: "от 6 до 24 часов, при VIP-статусе до 2 часов",
    currencies: ["EUR", "USD", "GBP", "CHF", "AED"],
    support: {
      email: "concierge@prestigepalace.com",
      chat: "Премиальная поддержка 24/7",
      languages: ["EN", "DE", "FR", "AR"],
      responseTime: "до 90 секунд для приоритетных клиентов"
    },
    responsibleGaming: ["Персональные консультанты по ответственной игре", "Лимиты по ставкам", "Оповещения о времени"],
    rtp: "97.3%",
    gameCount: 1750,
    averagePayout: "97.0%",
    focusMarkets: ["Европа", "Ближний Восток"],
    highlights: [
      "Консьерж-служба и персональные отчёты по активности",
      "Многоязычные live-студии с профессиональными дилерами",
      "Интеграция с программой Responsible Gambling Trust"
    ],
    categories: {
      bonus: "Персональные предложения",
      games: "Премиальный live-контент",
      license: "Gibraltar"
    }
  }
];

export default casinosData;