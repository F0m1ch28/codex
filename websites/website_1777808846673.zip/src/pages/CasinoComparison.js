import { useMemo, useState } from "react";
import casinosData from "../data/casinos";
import { Helmet } from "../components/SEOHelmet";

const CasinoComparison = () => {
  const initialSelection = casinosData.slice(0, 3).map((casino) => casino.slug);
  const [selected, setSelected] = useState(initialSelection);

  const toggleCasino = (slug) => {
    setSelected((prev) => {
      if (prev.includes(slug)) {
        return prev.filter((item) => item !== slug);
      }
      if (prev.length >= 3) {
        return prev;
      }
      return [...prev, slug];
    });
  };

  const comparedCasinos = useMemo(
    () => casinosData.filter((casino) => selected.includes(casino.slug)),
    [selected]
  );

  return (
    <>
      <Helmet
        title="Сравнение казино — GamblingReviews"
        description="Сравните бонусы, вейджер, RTP, количество игр и лицензии ведущих онлайн-казино. Интерактивная таблица от GamblingReviews."
        keywords="сравнение казино, рейтинг казино, лучшие казино"
        canonical="https://gamblingreviews.netlify.app/casino-comparison"
      />
      <section aria-labelledby="comparison-heading">
        <div className="container">
          <div className="section-header">
            <h1 id="comparison-heading" className="section-title">
              Интерактивное сравнение казино
            </h1>
            <p className="section-subtitle">
              Выберите до трёх казино, чтобы сравнить приветственные бонусы, вейджер, средний RTP, количество игр и лицензии. Мы рекомендуем фокусироваться на лицензии, прозрачности условий и скорости выплат. Ниже нет нелицензированных операторов.
            </p>
          </div>

          <div className="project-filters" role="group" aria-label="Выбор казино для сравнения">
            {casinosData.map((casino) => {
              const isSelected = selected.includes(casino.slug);
              const limitReached = selected.length >= 3 && !isSelected;
              return (
                <button
                  key={casino.slug}
                  type="button"
                  className={`filter-btn ${isSelected ? "active" : ""}`}
                  onClick={() => toggleCasino(casino.slug)}
                  disabled={limitReached}
                  aria-pressed={isSelected}
                >
                  {casino.name}
                </button>
              );
            })}
          </div>
          <p className="muted" style={{ marginBottom: "24px" }}>
            Можно выбрать до 3 казино одновременно. Снимая отметку, вы освобождаете место для других операторов.
          </p>

          {comparedCasinos.length === 0 ? (
            <p className="muted">
              Выберите казино для сравнения. Мы рекомендуем начать с{" "}
              <button type="button" className="filter-btn" onClick={() => setSelected(initialSelection)}>
                рекомендуемого набора
              </button>
              .
            </p>
          ) : (
            <div className="table-wrapper">
              <table className="comparison-table">
                <thead>
                  <tr>
                    <th>Казино</th>
                    <th>Приветственный бонус</th>
                    <th>Вейджер</th>
                    <th>Средний RTP</th>
                    <th>Количество игр</th>
                    <th>Лицензия</th>
                    <th>Платёжные системы</th>
                    <th>Рейтинг</th>
                  </tr>
                </thead>
                <tbody>
                  {comparedCasinos.map((casino) => (
                    <tr key={casino.slug}>
                      <td>
                        <strong>{casino.name}</strong>
                        <div className="muted">{casino.tagline}</div>
                      </td>
                      <td>{casino.welcomeBonus}</td>
                      <td>{casino.wager}</td>
                      <td>{casino.rtp}</td>
                      <td>{casino.gameCount}+</td>
                      <td>{casino.license}</td>
                      <td>{casino.paymentMethods.slice(0, 4).join(", ")}...</td>
                      <td>
                        <span className="badge badge-gold">{casino.rating.toFixed(1)}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <p className="quote" style={{ marginTop: "32px" }}>
            Помните: ни один бонус не гарантирует прибыль. Всегда изучайте условия, убедитесь в соблюдении локального законодательства и используйте инструменты ответственной игры. Минимальный возраст для участия — 21+.
          </p>
        </div>
      </section>
    </>
  );
};

export default CasinoComparison;