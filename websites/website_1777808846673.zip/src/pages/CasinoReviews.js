import { Link } from "react-router-dom";
import casinosData from "../data/casinos";
import { Helmet } from "../components/SEOHelmet";

const renderStars = (rating) => {
  const fullStars = Math.floor(rating);
  const halfStar = rating - fullStars >= 0.5;
  const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
  return (
    <>
      {Array.from({ length: fullStars }).map((_, index) => (
        <span key={`full-${index}`}>★</span>
      ))}
      {halfStar && <span key="half" style={{ opacity: 0.5 }}>★</span>}
      {Array.from({ length: emptyStars }).map((_, index) => (
        <span key={`empty-${index}`} style={{ opacity: 0.2 }}>★</span>
      ))}
    </>
  );
};

const CasinoReviews = () => {
  return (
    <>
      <Helmet
        title="Обзоры онлайн-казино — GamblingReviews"
        description="Независимые обзоры международных онлайн-казино: лицензии, бонусы, платежные методы, live-игры и инструменты ответственной игры."
        keywords="обзоры казино, рейтинг казино, бонусы казино, лицензия казино"
        canonical="https://gamblingreviews.netlify.app/casino-reviews"
      />
      <section aria-labelledby="reviews-heading">
        <div className="container">
          <div className="section-header">
            <h1 id="reviews-heading" className="section-title">
              Обзоры казино
            </h1>
            <p className="section-subtitle">
              Каждое казино прошло многоуровневую проверку: лицензии, бонусы, платежи, live-контент, службу поддержки и инструменты ответственной игры.
            </p>
          </div>

          <div className="best-casinos-grid">
            {casinosData.map((casino) => (
              <article key={casino.slug} className="casino-card">
                <div className="casino-card-header">
                  <img src={casino.logo} alt={`Логотип ${casino.name}`} className="casino-logo" loading="lazy" />
                  <div>
                    <h2>{casino.name}</h2>
                    <div className="rating-tag">
                      <div className="rating-stars" aria-label={`Рейтинг ${casino.rating} из 5`}>
                        {renderStars(casino.rating)}
                      </div>
                      <span>{casino.rating.toFixed(1)}</span>
                    </div>
                    <span className="chip">{casino.license}</span>
                  </div>
                </div>
                <p className="muted">{casino.description}</p>
                <div className="grid-two">
                  <p><strong>Приветственный бонус:</strong> {casino.welcomeBonus}</p>
                  <p><strong>Вейджер:</strong> {casino.wager}</p>
                  <p><strong>Средний RTP:</strong> {casino.rtp}</p>
                  <p><strong>Методы оплаты:</strong> {casino.paymentMethods.slice(0, 4).join(", ")}...</p>
                </div>
                <Link to={`/casino-reviews/${casino.slug}`} className="btn btn-secondary">
                  Полный обзор
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default CasinoReviews;