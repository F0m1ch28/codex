import { Helmet } from "../components/SEOHelmet";

const CookiePolicy = () => {
  return (
    <>
      <Helmet
        title="Политика cookie — GamblingReviews"
        description="Информация о cookie-файлах, которые использует GamblingReviews, их типах и способах управления."
        canonical="https://gamblingreviews.netlify.app/cookie-policy"
      />
      <section>
        <div className="container">
          <h1 className="section-title">Политика использования Cookie</h1>
          <p className="muted">Последнее обновление: 15 марта 2024</p>

          <h2>1. Что такое cookie?</h2>
          <p className="muted">
            Cookie — небольшие текстовые файлы, которые сохраняются на устройствах пользователей для обеспечения корректной работы сайта и улучшения пользовательского опыта.
          </p>

          <h2>2. Типы cookie, которые мы используем</h2>
          <ul className="muted">
            <li><strong>Функциональные:</strong> необходимы для работы сайта, хранения ваших предпочтений.</li>
            <li><strong>Аналитические:</strong> помогают понять, как посетители используют сайт (анонимно).</li>
            <li><strong>Cookie согласия:</strong> сохраняют ваш выбор относительно использования cookie.</li>
          </ul>

          <h2>3. Управление cookie</h2>
          <p className="muted">
            Вы можете изменить настройки cookie через баннер согласия или в браузере. Отключение функциональных cookie может привести к некорректной работе отдельных разделов.
          </p>

          <h2>4. Сторонние cookie</h2>
          <p className="muted">
            Мы стараемся минимизировать использование сторонних cookie. В случае интеграции аналитики мы информируем пользователей и предоставляем ссылки на политики соответствующих сервисов.
          </p>

          <h2>5. Обновления политики</h2>
          <p className="muted">
            При изменении cookie или интеграций мы обновим эту страницу и уведомим пользователей через баннер.
          </p>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;