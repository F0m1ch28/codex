import { Link } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import casinosData from "../data/casinos";
import { Helmet } from "../components/SEOHelmet";

const Home = () => {
  const statsTargets = useMemo(
    () => [
      { label: "Лицензированные казино", value: 42, description: "Каталог платформ, прошедших независимую проверку лицензий и выплат." },
      { label: "Проверенных бонусов", value: 128, description: "Актуальные приветственные пакеты, верифицированные аналитиками GamblingReviews." },
      { label: "Стран покрытия", value: 27, description: "Глобальная экспертиза с учётом локальных требований и ограничений." },
      { label: "Лет экспертизы", value: 9, description: "Опыт команды в комплаенсе, аудитах и produktu iGaming." }
    ],
    []
  );

  const [statsCounts, setStatsCounts] = useState(statsTargets.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeService, setActiveService] = useState("");
  const [selectedProjectFilter, setSelectedProjectFilter] = useState("Все");
  const [openFaq, setOpenFaq] = useState(null);

  const bestCasinos = useMemo(() => casinosData.slice(0, 4), []);
  const latestReviews = useMemo(() => casinosData.slice(0, 3), []);
  const testimonials = useMemo(
    () => [
      {
        quote:
          "Команда GamblingReviews помогла нашей студии разработать прозрачные бонусные правила для выхода на рынок Канады. Аналитика и рекомендации оказались точными и практичными.",
        name: "Анна Соколова",
        role: "Head of Compliance, EastCloud Gaming",
        location: "Варшава, Польша"
      },
      {
        quote:
          "Мы ценим детализацию обзоров и понятные таблицы сравнения. Это экономит часы работы при выборе новых партнёров и позволяет быстро выявить слабые места оффера.",
        name: "Маркус Линд",
        role: "Affiliate-менеджер, NordPlay Media",
        location: "Стокгольм, Швеция"
      },
      {
        quote:
          "Ответственный подход к проверке лицензий и инструментам безопасной игры — то, что выделяет GamblingReviews. Их выводы помогают игрокам делать взвешенный выбор.",
        name: "Джулиан Картер",
        role: "iGaming Consultant, Carter Advisory",
        location: "Лондон, Великобритания"
      }
    ],
    []
  );

  const services = useMemo(
    () => [
      {
        title: "Комплексный аудит лицензий",
        description: "Проверяем регистрационные данные, соответствие регуляторным требованиям и историю операторов в открытых реестрах.",
        metrics: "Более 60 проверенных регуляторов."
      },
      {
        title: "Мониторинг бонусных условий",
        description: "Анализируем вейджер, сроки отыгрыша и ограничения, формируя понятные выводы и чек-листы для читателей.",
        metrics: "128+ актуальных бонусных пакетов."
      },
      {
        title: "Аналитика игровых портфелей",
        description: "Оцениваем diversity провайдеров, наличие сертифицированных RNG и средний RTP в популярных категориях.",
        metrics: "2800+ протестированных слотов и столов."
      },
      {
        title: "Тестирование платежей",
        description: "Проверяем скорость выплат, лимиты и комиссии, проводим контрольные выводы с разных способов оплаты.",
        metrics: "Средний тестовый вывод — до 12 часов."
      }
    ],
    []
  );

  const categories = useMemo(
    () => [
      {
        title: "По бонусам",
        icon: "🎁",
        description: "Подборки казино с прозрачными приветственными пакетами, гибкими миссиями и реальным кэшбэком."
      },
      {
        title: "По играм",
        icon: "🎲",
        description: "Фильтры по live-играм, слотам с высоким RTP, джекпотам и эксклюзивным релизам от ведущих студий."
      },
      {
        title: "По лицензиям",
        icon: "📜",
        description: "Сегментация по регуляторам MGA, UKGC, EMTA, Кюрасао, Гибралтар и другим международным юрисдикциям."
      }
    ],
    []
  );

  const processSteps = useMemo(
    () => [
      "Сбор данных о лицензии, собственниках и платежной инфраструктуре.",
      "Проверка комплаенса: KYC, AML, ответственная игра, связи с провайдерами.",
      "Тестовые игровые сессии и оценка интерфейса, UX, скорости загрузки.",
      "Контрольные депозиты и выводы с фиксацией сроков и лимитов.",
      "Формирование рейтинга и публикация отчёта с рекомендациями."
    ],
    []
  );

  const projects = useMemo(
    () => [
      {
        id: 1,
        title: "Бенчмарк приветственных бонусов 2024",
        category: "Бонусы",
        description: "Сравнение 50+ бонусных пакетов по вейджеру, срокам и прозрачности условий.",
        metric: "Рейтинг прозрачности: 92/100",
        image: "https://picsum.photos/1200/800?random=111",
        tags: ["Бонусы", "Прозрачность", "Аудит"]
      },
      {
        id: 2,
        title: "Исследование скорости выплат",
        category: "Платежи",
        description: "Полевое тестирование 30 платформ: среднее время вывода, лимиты и комиссии.",
        metric: "Средний вывод: 11 ч.",
        image: "https://picsum.photos/1200/800?random=112",
        tags: ["Платежи", "Вывод средств", "Методы"]
      },
      {
        id: 3,
        title: "Live-казино: качество трансляций",
        category: "Игры",
        description: "Анализ live-портфелей и стабильности видеопотока на разных устройствах.",
        metric: "Средний FPS: 58",
        image: "https://picsum.photos/1200/800?random=113",
        tags: ["Live", "Провайдеры", "UX"]
      },
      {
        id: 4,
        title: "Регуляторный обзор 2024",
        category: "Лицензии",
        description: "Сравнение требований MGA, UKGC, EMTA и Кюрасао по ответственности и AML.",
        metric: "15 ключевых критериев",
        image: "https://picsum.photos/1200/800?random=114",
        tags: ["Лицензии", "Регуляторы", "Комплаенс"]
      }
    ],
    []
  );

  const faq = useMemo(
    () => [
      {
        question: "Как GamblingReviews формирует рейтинги казино?",
        answer:
          "Мы используем многоуровневую методологию: анализ лицензий и собственников, тестирование игр и платежей, проверку бонусных условий, оценку поддержки и инструментов ответственной игры. Каждое казино получает результат по 35+ критериям."
      },
      {
        question: "Можно ли считать обзоры рекламой?",
        answer:
          "Нет. GamblingReviews — независимый обзорный проект. Мы не публикуем предложения нелицензированных операторов, не обещаем выигрыши и не получаем вознаграждение за повышение рейтингов."
      },
      {
        question: "Предоставляете ли вы услуги консультаций игрокам?",
        answer:
          "Мы не консультируем по ставкам и не предоставляем финансовых советов. Наша задача — информировать игроков о лицензированных платформах и их условиях, акцентируя внимание на ответственной игре."
      },
      {
        question: "Как часто обновляются данные о бонусах и выплатах?",
        answer:
          "Мы проверяем ключевые офферы минимум раз в 30 дней. При изменениях условий оператора информация обновляется в обзоре и таблицах сравнения в течение 48 часов."
      },
      {
        question: "Где можно пожаловаться на казино из вашего списка?",
        answer:
          "Если вы столкнулись с проблемой на лицензированном казино из нашего каталога, напишите нам на contact@gamblingreviews.com. Мы предоставим инструкцию для обращения в регуляторный орган и поделимся контактами службы поддержки оператора."
      }
    ],
    []
  );

  const blogPosts = useMemo(
    () => [
      {
        title: "Как выбрать казино с честным вейджером",
        summary: "Разбираем, что учитывать при анализе бонусных правил и как считать эффективный вейджер.",
        date: "12 марта 2024",
        readTime: "6 мин",
        image: "https://picsum.photos/800/600?random=121",
        link: "/casino-reviews"
      },
      {
        title: "Лицензии MGA vs UKGC: в чём разница для игроков",
        summary: "Подробно сравнили требования регуляторов, механизмы защиты и юридические нюансы.",
        date: "26 февраля 2024",
        readTime: "8 мин",
        image: "https://picsum.photos/800/600?random=122",
        link: "/about-us"
      },
      {
        title: "Тренды ответственного гэмблинга в 2024 году",
        summary: "Какие инструменты внедряют казино и какие инициативы поддерживают регуляторы.",
        date: "9 января 2024",
        readTime: "7 мин",
        image: "https://picsum.photos/800/600?random=123",
        link: "/privacy-policy"
      }
    ],
    []
  );

  useEffect(() => {
    setActiveService(services[0]?.title || "");
  }, [services]);

  useEffect(() => {
    let animationFrame;
    const start = performance.now();
    const duration = 1600;

    const animate = (time) => {
      const progress = Math.min((time - start) / duration, 1);
      setStatsCounts(statsTargets.map((stat) => Math.round(stat.value * progress)));
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame);
  }, [statsTargets]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 8000);

    return () => clearInterval(timer);
  }, [testimonials.length]);

  const filteredProjects = useMemo(() => {
    if (selectedProjectFilter === "Все") {
      return projects;
    }
    return projects.filter((project) => project.category === selectedProjectFilter);
  }, [projects, selectedProjectFilter]);

  const handleFaqToggle = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Helmet
        title="GamblingReviews — международные обзоры лицензированных онлайн-казино"
        description="GamblingReviews публикует независимые обзоры лицензированных онлайн-казино, сравнение бонусов, вейджеров и платежей. Ориентируемся на ответственный гэмблинг и прозрачные условия."
        keywords="обзор казино, сравнение казино, бонусы казино, ответственная игра, лицензированные казино"
        canonical="https://gamblingreviews.netlify.app/"
        ogImage="https://picsum.photos/1600/900?random=101"
      />
      <section className="hero">
        <div className="container hero-layout">
          <div className="hero-content">
            <span className="chip">Международный обзор лицензированных казино</span>
            <h1 className="hero-title">
              GamblingReviews: <span className="hero-highlight">объективные рейтинги</span> онлайн-казино для сознательных игроков
            </h1>
            <p className="hero-text">
              Мы анализируем лицензии, бонусы, платежи и live-контент, чтобы вы принимали взвешенные решения. Без рекламных шаблонов, без ложных обещаний — только аналитика, основанная на фактах и тестировании.
            </p>
            <div className="hero-cta">
              <Link to="/casino-comparison" className="btn btn-primary">
                Подобрать казино
              </Link>
              <Link to="/casino-reviews" className="btn btn-secondary">
                Посмотреть обзоры
              </Link>
            </div>
            <div className="hero-meta">
              <span>✔︎ Актуальные лицензии и проверенные регуляторы</span>
              <span>✔︎ Прозрачные условия бонусов и вейджеров</span>
              <span>✔︎ Ответственный подход и возраст 21+</span>
            </div>
          </div>
        </div>
      </section>

      <section aria-labelledby="stats-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="stats-heading" className="section-title">
              Цифры, подтверждающие нашу экспертизу
            </h2>
            <p className="section-subtitle">
              Мы собираем и обновляем данные вручную, проверяем лицензии и выполняем контрольные платежи, чтобы цифры отражали реальные процессы.
            </p>
          </div>
          <div className="stats-grid">
            {statsTargets.map((stat, index) => (
              <article key={stat.label} className="stat-card">
                <div className="stat-value" aria-live="polite">
                  {statsCounts[index]}+
                </div>
                <div className="stat-label">{stat.label}</div>
                <p className="stat-description">{stat.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="best-casinos-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="best-casinos-heading" className="section-title">
              Лучшие казино недели по версии GamblingReviews
            </h2>
            <p className="section-subtitle">
              Отобраны по лицензии, качеству поддержки, скорости выплат и прозрачности бонусных условий. Мы не публикуем те, кто нарушает комплаенс или не прошёл проверку.
            </p>
          </div>
          <div className="best-casinos-grid">
            {bestCasinos.map((casino) => (
              <article key={casino.slug} className="casino-card">
                <div className="casino-card-header">
                  <img src={casino.logo} alt={`Логотип ${casino.name}`} className="casino-logo" loading="lazy" />
                  <div>
                    <h3>{casino.name}</h3>
                    <div className="rating-tag">
                      <span>★</span>
                      <span>{casino.rating}</span>
                    </div>
                    <p className="muted">{casino.tagline}</p>
                  </div>
                </div>
                <p className="muted">{casino.description}</p>
                <ul>
                  <li><strong>Лицензия:</strong> {casino.license}</li>
                  <li><strong>Приветственный бонус:</strong> {casino.welcomeBonus}</li>
                  <li><strong>Вейджер:</strong> {casino.wager}</li>
                </ul>
                <Link to={`/casino-reviews/${casino.slug}`} className="btn btn-secondary">
                  Читать обзор
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="advantages-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="advantages-heading" className="section-title">
              Почему GamblingReviews заслуживает доверия
            </h2>
          </div>
          <div className="advantages-grid">
            <article className="advantage-card">
              <h3>Независимый редакционный подход</h3>
              <p className="muted">
                Рейтинг формирует редакционный совет с опытом в iGaming, комплаенсе и аналитике. Ни один оператор не может купить позицию или запросить скрытие фактов.
              </p>
            </article>
            <article className="advantage-card">
              <h3>Фокус на ответственной игре</h3>
              <p className="muted">
                Публикуем только платформы с инструментами ограничения, самоисключения и партнёрством с программами Responsible Gambling. Возрастная категория — 21+.
              </p>
            </article>
            <article className="advantage-card">
              <h3>Проверка платежей и саппорта</h3>
              <p className="muted">
                Отправляем тестовые депозиты/выводы и общаемся с поддержкой, фиксируя скорость реакции и прозрачность коммуникации.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section aria-labelledby="categories-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="categories-heading" className="section-title">
              Категории выбора казино
            </h2>
            <p className="section-subtitle">
              Настройте подборку под свои приоритеты: от бонусов и турниров до лицензий и премиального live-опыта.
            </p>
          </div>
          <div className="categories-grid">
            {categories.map((category) => (
              <article key={category.title} className="category-card">
                <div className="category-icon" aria-hidden="true">{category.icon}</div>
                <h3>{category.title}</h3>
                <p className="muted">{category.description}</p>
                <Link to="/casino-comparison" className="btn btn-ghost">
                  Смотреть подборку
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="services-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="services-heading" className="section-title">
              Наши ключевые сервисы и экспертиза
            </h2>
            <p className="section-subtitle">
              Глубокая аналитика, тестирование UX и комплаенс-контроль — основы нашей методологии.
            </p>
          </div>
          <div className="services-grid">
            {services.map((service) => (
              <article
                key={service.title}
                className={`service-card ${activeService === service.title ? "active" : ""}`}
                onMouseEnter={() => setActiveService(service.title)}
                onFocus={() => setActiveService(service.title)}
              >
                <h3>{service.title}</h3>
                <p className="muted">{service.description}</p>
                <span className="chip">{service.metrics}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="process-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="process-heading" className="section-title">
              Как мы оцениваем казино: шаг за шагом
            </h2>
            <p className="section-subtitle">
              Методология открыта и воспроизводима — вы можете проверить каждый пункт самостоятельно.
            </p>
          </div>
          <div className="process-grid">
            {processSteps.map((step, index) => (
              <article key={step} className="process-step">
                <div className="process-step-number">{index + 1}</div>
                <p className="muted">{step}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="latest-reviews-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="latest-reviews-heading" className="section-title">
              Последние обновления обзоров
            </h2>
            <p className="section-subtitle">
              Мы обновляем обзоры при каждом изменении условий, чтобы у вас всегда была актуальная информация.
            </p>
          </div>
          <div className="latest-reviews-grid">
            {latestReviews.map((casino) => (
              <article key={casino.slug} className="casino-card">
                <div>
                  <div className="casino-card-header">
                    <img src={casino.logo} alt={`Логотип ${casino.name}`} className="casino-logo" loading="lazy" />
                    <div>
                      <h3>{casino.name}</h3>
                      <div className="rating-tag">
                        <span>★</span>
                        <span>{casino.rating}</span>
                      </div>
                    </div>
                  </div>
                  <p className="muted">{casino.description}</p>
                </div>
                <div className="grid-two">
                  <p><strong>Лицензия:</strong> {casino.license}</p>
                  <p><strong>Игры:</strong> {casino.games.live}</p>
                  <p><strong>Платежи:</strong> {casino.paymentMethods.join(", ")}</p>
                  <p><strong>Средний RTP:</strong> {casino.rtp}</p>
                </div>
                <Link to={`/casino-reviews/${casino.slug}`} className="btn btn-secondary">
                  Читайте полный обзор
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="testimonials-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="testimonials-heading" className="section-title">
              Мнения профессионалов индустрии
            </h2>
            <p className="section-subtitle">
              Вот что говорят о GamblingReviews партнеры, аффилиаты и консультанты, работающие с международными рынками.
            </p>
          </div>
          <div className="testimonial-wrapper">
            <article className="testimonial-card">
              <p className="testimonial-quote">“{testimonials[currentTestimonial].quote}”</p>
              <div className="testimonial-person">
                <strong>{testimonials[currentTestimonial].name}</strong>
                <span className="muted">{testimonials[currentTestimonial].role}</span>
                <span className="muted">{testimonials[currentTestimonial].location}</span>
              </div>
            </article>
          </div>
          <div className="testimonial-controls">
            <button type="button" onClick={() => setCurrentTestimonial((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1))}>
              ←
            </button>
            <button type="button" onClick={() => setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)}>
              →
            </button>
          </div>
        </div>
      </section>

      <section aria-labelledby="team-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="team-heading" className="section-title">
              Команда GamblingReviews
            </h2>
            <p className="section-subtitle">
              Мы объединяем экспертов в лицензировании, UX-анализе и ответственной игре. Все участники команды имеют опыт работы в iGaming-структурах.
            </p>
          </div>
          <div className="team-grid">
            {[
              {
                name: "Ирина Волкова",
                role: "Главный редактор и аналитик лицензий",
                bio: "12 лет опыта в лицензировании iGaming и аудитах MGA/UKGC. Курирует методологию рейтингов.",
                image: "https://picsum.photos/400/400?random=131"
              },
              {
                name: "Лео Маркинен",
                role: "Руководитель тестирования игр",
                bio: "Отвечает за тестовые сессии и UX-ассесменты. Ранее — менеджер игровых портфелей в студии NetStorm.",
                image: "https://picsum.photos/400/400?random=132"
              },
              {
                name: "Наталья Дюпон",
                role: "Эксперт по платежам и AML",
                bio: "Сертифицированный AML-специалист. Отвечает за проверки KYC/AML и безопасность операций.",
                image: "https://picsum.photos/400/400?random=133"
              }
            ].map((member) => (
              <article key={member.name} className="team-card">
                <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                <h3>{member.name}</h3>
                <span className="team-role">{member.role}</span>
                <p className="team-bio">{member.bio}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="projects-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="projects-heading" className="section-title">
              Аналитические проекты и исследования
            </h2>
            <p className="section-subtitle">
              Публикуем регулярные исследования по бонусам, платежам, live-индустрии и регуляторным изменениям.
            </p>
          </div>
          <div className="project-filters">
            {["Все", "Бонусы", "Платежи", "Игры", "Лицензии"].map((filter) => (
              <button
                key={filter}
                type="button"
                className={`filter-btn ${selectedProjectFilter === filter ? "active" : ""}`}
                onClick={() => setSelectedProjectFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className="projects-grid">
            {filteredProjects.map((project) => (
              <article key={project.id} className="project-card">
                <img src={project.image} alt={`Исследование: ${project.title}`} loading="lazy" />
                <div className="project-meta">
                  <span>{project.category}</span>
                  <span>{project.metric}</span>
                </div>
                <h3>{project.title}</h3>
                <p className="muted">{project.description}</p>
                <div className="project-tags">
                  {project.tags.map((tag) => (
                    <span key={tag}>{tag}</span>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="faq-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="faq-heading" className="section-title">
              Часто задаваемые вопросы
            </h2>
          </div>
          <div className="faq-list">
            {faq.map((item, index) => (
              <article
                key={item.question}
                className={`faq-item ${openFaq === index ? "active" : ""}`}
                onClick={() => handleFaqToggle(index)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    handleFaqToggle(index);
                  }
                }}
                role="button"
                tabIndex={0}
                aria-expanded={openFaq === index}
              >
                <div className="faq-question">
                  <span>{item.question}</span>
                  <span>{openFaq === index ? "−" : "+"}</span>
                </div>
                {openFaq === index && <p className="faq-answer">{item.answer}</p>}
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="blog-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="blog-heading" className="section-title">
              Экспертные материалы и гиды
            </h2>
            <p className="section-subtitle">
              Готовим практичные руководства и аналитические заметки для игроков и аффилиатов, работающих на международных рынках.
            </p>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article key={post.title} className="blog-card">
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className="blog-meta">
                  <span>{post.date}</span>
                  <span>{post.readTime}</span>
                </div>
                <h3>{post.title}</h3>
                <p className="muted">{post.summary}</p>
                <Link to={post.link} className="btn btn-ghost">
                  Читать подробнее
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="cta-heading">
        <div className="container">
          <div className="cta-section">
            <h2 id="cta-heading">Сравните условия и найдите своё казино уже сегодня</h2>
            <p>
              Воспользуйтесь инструментом сравнения GamblingReviews, чтобы сопоставить бонусы, вейджеры, RTP и методы оплаты. Играйте ответственно и убедитесь, что выбранная платформа лицензирована в вашей юрисдикции.
            </p>
            <Link to="/casino-comparison" className="btn btn-primary">
              Запустить сравнение
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;