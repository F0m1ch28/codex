import { useParams, Link } from "react-router-dom";
import casinosData from "../data/casinos";
import { Helmet } from "../components/SEOHelmet";

const CasinoDetail = () => {
  const { casinoSlug } = useParams();
  const casino = casinosData.find((item) => item.slug === casinoSlug);

  if (!casino) {
    return (
      <section>
        <div className="container">
          <h1>Казино не найдено</h1>
          <p className="muted">
            Возможно, оно было удалено или обновлено. Перейдите к{" "}
            <Link to="/casino-reviews">списку обзоров</Link>, чтобы выбрать актуальное казино.
          </p>
        </div>
      </section>
    );
  }

  const comparisonCasinos = casinosData.filter((item) => item.slug !== casino.slug).slice(0, 3);

  return (
    <>
      <Helmet
        title={`${casino.name} — подробный обзор казино | GamblingReviews`}
        description={`${casino.name}: лицензия ${casino.license}, бонусы, игры, платежные методы и инструменты ответственной игры. Узнайте все детали перед регистрацией.`}
        keywords={`${casino.name} обзор, ${casino.name} бонусы, ${casino.name} лицензия`}
        canonical={`https://gamblingreviews.netlify.app/casino-reviews/${casino.slug}`}
      />
      <section>
        <div className="container">
          <div className="section-header">
            <span className="chip">Обзор казино</span>
            <h1 className="section-title">{casino.name}</h1>
            <p className="section-subtitle">{casino.description}</p>
          </div>

          <article className="casino-card">
            <div className="casino-card-header">
              <img src={casino.logo} alt={`Логотип ${casino.name}`} className="casino-logo" loading="lazy" />
              <div>
                <h2>{casino.name}</h2>
                <div className="rating-tag">
                  <span>★</span>
                  <span>{casino.rating.toFixed(1)}</span>
                </div>
                <p className="muted">{casino.tagline}</p>
              </div>
            </div>

            <div className="grid-two">
              <p><strong>Год основания:</strong> {casino.founded}</p>
              <p><strong>Лицензия:</strong> {casino.license}</p>
              <p><strong>Владелец:</strong> {casino.owner}</p>
              <p><strong>Штаб-квартира:</strong> {casino.headquarters}</p>
              <p><strong>Средний RTP:</strong> {casino.rtp}</p>
              <p><strong>Количество игр:</strong> {casino.gameCount}+</p>
            </div>

            <h3>Бонусные предложения</h3>
            <ul>
              <li><strong>Приветственный пакет:</strong> {casino.welcomeBonus}</li>
              <li><strong>Бездепозитные опции:</strong> {casino.noDepositBonus}</li>
              <li><strong>Кэшбэк:</strong> {casino.cashback}</li>
            </ul>

            <h3>Категории игр</h3>
            <ul>
              <li><strong>Слоты:</strong> {casino.games.slots}</li>
              <li><strong>Рулетка:</strong> {casino.games.roulette}</li>
              <li><strong>Блэкджек:</strong> {casino.games.blackjack}</li>
              <li><strong>Покер:</strong> {casino.games.poker}</li>
              <li><strong>Live-игры:</strong> {casino.games.live}</li>
            </ul>

            <h3>Условия бонусов</h3>
            <ul>
              <li><strong>Вейджер:</strong> {casino.wager}</li>
              <li><strong>Минимальный депозит:</strong> {casino.minDeposit}</li>
              <li><strong>Срок отыгрыша:</strong> {casino.wageringPeriod}</li>
              <li><strong>Среднее время вывода:</strong> {casino.withdrawalTime}</li>
            </ul>

            <h3>Платёжные системы</h3>
            <p className="muted">{casino.paymentMethods.join(", ")}</p>

            <h3>Поддержка</h3>
            <ul>
              <li><strong>Email:</strong> {casino.support.email}</li>
              <li><strong>Live-чарт:</strong> {casino.support.chat}</li>
              <li><strong>Языки:</strong> {casino.support.languages.join(", ")}</li>
              <li><strong>Среднее время ответа:</strong> {casino.support.responseTime}</li>
            </ul>

            <h3>Инструменты ответственной игры</h3>
            <ul>
              {casino.responsibleGaming.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>

            <h3>Ключевые преимущества</h3>
            <ul>
              {casino.highlights.map((highlight) => (
                <li key={highlight}>{highlight}</li>
              ))}
            </ul>

            <p className="quote">
              GamblingReviews напоминает: вы должны быть старше 21 года, чтобы играть в онлайн-казино в большинстве юрисдикций. Всегда проверяйте локальное законодательство и устанавливайте личные лимиты.
            </p>
          </article>

          <div className="section-header">
            <h2 className="section-title">Сравнение с другими казино</h2>
            <p className="section-subtitle">
              Чтобы оценить позицию {casino.name}, мы подготовили краткую таблицу сравнения с другими популярными платформами из нашего каталога.
            </p>
          </div>

          <div className="table-wrapper">
            <table className="comparison-table">
              <thead>
                <tr>
                  <th>Казино</th>
                  <th>Приветственный бонус</th>
                  <th>Вейджер</th>
                  <th>Средний RTP</th>
                  <th>Лицензия</th>
                  <th>Методы оплаты</th>
                  <th>Рейтинг</th>
                </tr>
              </thead>
              <tbody>
                {[casino, ...comparisonCasinos].map((item) => (
                  <tr key={item.slug}>
                    <td>{item.name}</td>
                    <td>{item.welcomeBonus}</td>
                    <td>{item.wager}</td>
                    <td>{item.rtp}</td>
                    <td>{item.license}</td>
                    <td>{item.paymentMethods.slice(0, 4).join(", ")}...</td>
                    <td>
                      <span className="badge badge-gold">{item.rating.toFixed(1)}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ marginTop: "32px" }}>
            <Link to="/casino-comparison" className="btn btn-primary">
              Расширить сравнение
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default CasinoDetail;