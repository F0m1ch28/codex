import { useState } from "react";
import { Helmet } from "../components/SEOHelmet";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    topic: "",
    message: "",
    consent: false
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("");

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Укажите ваше имя.";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Укажите email.";
    } else if (!/^[\w-.]+@[\w-]+\.[a-z]{2,}$/i.test(formData.email)) {
      newErrors.email = "Введите корректный email.";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Напишите сообщение.";
    }
    if (!formData.consent) {
      newErrors.consent = "Необходимо согласие на обработку данных.";
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setStatus("success");
      setFormData({
        name: "",
        email: "",
        topic: "",
        message: "",
        consent: false
      });
    } else {
      setStatus("error");
    }
  };

  return (
    <>
      <Helmet
        title="Контакты — GamblingReviews"
        description="Свяжитесь с командой GamblingReviews: вопросы, сотрудничество, запросы на аудит."
        canonical="https://gamblingreviews.netlify.app/contact"
      />
      <section>
        <div className="container">
          <h1 className="section-title">Контакты</h1>
          <p className="muted">
            Мы открыты к диалогу с операторами, аффилиатами и читателями. Отвечаем в течение 2 рабочих дней.
          </p>

          <div className="grid-two" style={{ marginTop: "36px" }}>
            <article className="advantage-card">
              <h2>Наши реквизиты</h2>
              <ul className="muted">
                <li><strong>Компания:</strong> GamblingReviews</li>
                <li><strong>Адрес:</strong> 123 Gaming Street, Cyber City, GC 10101</li>
                <li><strong>Телефон:</strong> <a href="tel:+18001234567">+1 800-123-4567</a></li>
                <li><strong>Email:</strong> <a href="mailto:contact@gamblingreviews.com">contact@gamblingreviews.com</a></li>
                <li><strong>Рабочее время:</strong> Пн–Пт, 09:00–18:00 (UTC)</li>
              </ul>
              <p className="muted">
                Не направляйте заявки от операторов без лицензии: мы не рассматриваем нелегальные площадки и не публикуем их промо.
              </p>
            </article>

            <article className="advantage-card">
              <h2>Напишите нам</h2>
              <form onSubmit={handleSubmit} noValidate>
                <div className="form-row">
                  <label htmlFor="name">Имя *</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Как к вам обращаться?"
                  />
                  {errors.name && <span className="form-error">{errors.name}</span>}
                </div>

                <div className="form-row">
                  <label htmlFor="email">Email *</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="Ваш рабочий email"
                  />
                  {errors.email && <span className="form-error">{errors.email}</span>}
                </div>

                <div className="form-row">
                  <label htmlFor="topic">Тема обращения</label>
                  <select
                    id="topic"
                    name="topic"
                    value={formData.topic}
                    onChange={handleChange}
                  >
                    <option value="">Выберите тему</option>
                    <option value="audit">Запрос на аудит казино</option>
                    <option value="partnership">Партнёрство / СМИ</option>
                    <option value="feedback">Замечание по материалам</option>
                    <option value="other">Другое</option>
                  </select>
                </div>

                <div className="form-row">
                  <label htmlFor="message">Сообщение *</label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Опишите вопрос или предложение. Мы не рассматриваем запросы от несовершеннолетних и нелицензированных операторов."
                  />
                  {errors.message && <span className="form-error">{errors.message}</span>}
                </div>

                <div className="form-row">
                  <label>
                    <input
                      type="checkbox"
                      name="consent"
                      checked={formData.consent}
                      onChange={handleChange}
                    />{" "}
                    Я подтверждаю, что ознакомился с{" "}
                    <a href="/privacy-policy">политикой конфиденциальности</a> и даю согласие на обработку данных.
                  </label>
                  {errors.consent && <span className="form-error">{errors.consent}</span>}
                </div>

                <button type="submit" className="btn btn-primary">
                  Отправить запрос
                </button>

                {status === "success" && (
                  <div className="form-feedback success">
                    Спасибо! Сообщение отправлено. Мы свяжемся с вами в ближайшее время.
                  </div>
                )}
                {status === "error" && (
                  <div className="form-feedback error">
                    Проверьте правильность заполнения формы и повторите попытку.
                  </div>
                )}
              </form>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;
```