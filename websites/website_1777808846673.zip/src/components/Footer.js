import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <div className="brand-mark">GR</div>
          <h3>GamblingReviews</h3>
          <p>
            Профессиональный обзорный проект о международных лицензированных онлайн-казино.
            Мы публикуем независимые оценки, сравнения условий и рекомендации ответственной игры.
          </p>
          <p className="footer-disclaimer">
            21+. Играйте ответственно. Проверяйте требования лицензии в вашей юрисдикции.
            Мы не продвигаем нелегальные платформы и не обещаем гарантированного выигрыша.
          </p>
        </div>

        <div className="footer-column">
          <h4>Навигация</h4>
          <ul>
            <li><Link to="/">Главная</Link></li>
            <li><Link to="/casino-reviews">Обзоры казино</Link></li>
            <li><Link to="/casino-comparison">Сравнение</Link></li>
            <li><Link to="/about-us">О нас</Link></li>
            <li><Link to="/contact">Контакты</Link></li>
          </ul>
        </div>

        <div className="footer-column">
          <h4>Правовая информация</h4>
          <ul>
            <li><Link to="/terms-and-conditions">Правила и условия</Link></li>
            <li><Link to="/privacy-policy">Политика конфиденциальности</Link></li>
            <li><Link to="/cookie-policy">Политика использования Cookie</Link></li>
          </ul>
        </div>

        <div className="footer-column">
          <h4>Контакты</h4>
          <ul className="contact-info">
            <li>Адрес: 123 Gaming Street, Cyber City, GC 10101</li>
            <li>Телефон: <a href="tel:+18001234567">+1 800-123-4567</a></li>
            <li>Email: <a href="mailto:contact@gamblingreviews.com">contact@gamblingreviews.com</a></li>
          </ul>
          <div className="footer-social">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn GamblingReviews">
              <span>in</span>
            </a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter GamblingReviews">
              <span>tw</span>
            </a>
            <a href="https://telegram.org" target="_blank" rel="noreferrer" aria-label="Telegram GamblingReviews">
              <span>tg</span>
            </a>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} GamblingReviews. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;