import { useEffect, useState } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 24);
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { to: "/", label: "Главная" },
    { to: "/casino-reviews", label: "Обзоры казино" },
    { to: "/casino-comparison", label: "Сравнение" },
    { to: "/about-us", label: "О нас" },
    { to: "/contact", label: "Контакты" }
  ];

  return (
    <header className={`site-header ${isScrolled ? "scrolled" : ""}`}>
      <div className="container header-inner">
        <Link to="/" className="brand" aria-label="GamblingReviews — на главную">
          <span className="brand-mark">GR</span>
          <div className="brand-text">
            <span className="brand-name">GamblingReviews</span>
            <span className="brand-tagline">Международный обзор лицензированных казино</span>
          </div>
        </Link>

        <nav className={`main-nav ${isMenuOpen ? "open" : ""}`} aria-label="Основная навигация">
          <ul>
            {navLinks.map((link) => (
              <li key={link.to}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) => (isActive ? "active" : "")}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
            <li className="nav-highlight">
              <NavLink to="/casino-comparison">Подобрать казино</NavLink>
            </li>
          </ul>
        </nav>

        <button
          className={`menu-toggle ${isMenuOpen ? "open" : ""}`}
          onClick={toggleMenu}
          aria-label={isMenuOpen ? "Закрыть меню" : "Открыть меню"}
          aria-expanded={isMenuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;