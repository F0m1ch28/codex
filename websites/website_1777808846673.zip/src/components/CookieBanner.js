import { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem("gr_cookie_consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem("gr_cookie_consent", "accepted");
    setVisible(false);
  };

  const declineCookies = () => {
    window.localStorage.setItem("gr_cookie_consent", "declined");
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <h4>Мы используем cookie</h4>
        <p>
          GamblingReviews применяет аналитические и функциональные cookie для персонализации контента и улучшения
          работы сайта. Подробности в{" "}
          <a href="/cookie-policy" aria-label="Перейти к политике cookie">
            политике cookie
          </a>
          .
        </p>
      </div>
      <div className="cookie-actions">
        <button className="btn btn-secondary" onClick={acceptCookies}>
          Принять
        </button>
        <button className="btn btn-ghost" onClick={declineCookies}>
          Отклонить
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;