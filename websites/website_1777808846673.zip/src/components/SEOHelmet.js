import { createContext } from "react";
import { useEffect } from "react";

const HelmetContext = createContext(null);

export const HelmetProvider = ({ children }) => children;

const setOrCreateMeta = (selector, attributes) => {
  let element = document.head.querySelector(selector);
  if (!element) {
    element = document.createElement("meta");
    Object.entries(attributes).forEach(([key, value]) => {
      element.setAttribute(key, value);
    });
    document.head.appendChild(element);
  } else {
    Object.entries(attributes).forEach(([key, value]) => {
      element.setAttribute(key, value);
    });
  }
};

export const Helmet = ({
  title,
  description,
  keywords,
  canonical,
  ogTitle,
  ogDescription,
  ogImage
}) => {
  useEffect(() => {
    if (title) {
      document.title = title;
      setOrCreateMeta('meta[property="og:title"]', { property: "og:title", content: ogTitle || title });
    }
    if (description) {
      setOrCreateMeta('meta[name="description"]', { name: "description", content: description });
      setOrCreateMeta('meta[property="og:description"]', {
        property: "og:description",
        content: ogDescription || description
      });
    }
    if (keywords) {
      setOrCreateMeta('meta[name="keywords"]', { name: "keywords", content: keywords });
    }
    if (canonical) {
      let link = document.head.querySelector('link[rel="canonical"]');
      if (!link) {
        link = document.createElement("link");
        link.setAttribute("rel", "canonical");
        document.head.appendChild(link);
      }
      link.setAttribute("href", canonical);
    }
    if (ogImage) {
      setOrCreateMeta('meta[property="og:image"]', { property: "og:image", content: ogImage });
    }
    setOrCreateMeta('meta[property="og:type"]', { property: "og:type", content: "website" });
    setOrCreateMeta('meta[property="og:locale"]', { property: "og:locale", content: "ru_RU" });
  }, [title, description, keywords, canonical, ogTitle, ogDescription, ogImage]);

  return null;
};

export default HelmetContext;