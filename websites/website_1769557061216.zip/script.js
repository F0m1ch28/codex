const DEFAULT_LANG = "fr";
const STORAGE_LANG_KEY = "site_lang";
const COOKIE_STORAGE_KEY = "cookie_consent";

const I18N = {
  fr: {
    brand: {
      name: "danswholesaleplants",
      tagline: "Analyse et diffusion des pratiques d’orientation spatiale pour les lieux à forte complexité structurelle."
    },
    meta: {
      title: {
        home: "danswholesaleplants | Orientation spatiale et signalétique numérique",
        services: "Services | danswholesaleplants",
        about: "À propos | danswholesaleplants",
        blog: "Blog | danswholesaleplants",
        contact: "Contact | danswholesaleplants",
        faq: "FAQ | danswholesaleplants",
        terms: "Conditions d’utilisation | danswholesaleplants",
        privacy: "Politique de confidentialité | danswholesaleplants",
        cookies: "Politique relative aux cookies | danswholesaleplants",
        refund: "Politique de révision | danswholesaleplants",
        disclaimer: "Avertissement | danswholesaleplants",
        thankyou: "Merci | danswholesaleplants",
        post1: "Cartographie des correspondances multimodales | danswholesaleplants",
        post2: "Conception de signalétique immersive | danswholesaleplants",
        post3: "Modélisation des flux piétons | danswholesaleplants",
        post4: "Accessibilité multisensorielle | danswholesaleplants",
        post5: "Cartographie temporelle des parcours | danswholesaleplants"
      },
      description: {
        home: "Plateforme dédiée à l’orientation spatiale, la signalétique numérique et la cartographie des espaces complexes en Belgique.",
        services: "Panorama des services analytiques et méthodologiques autour de la signalétique numérique et de la navigation intérieure.",
        about: "Présentation de l’expertise de danswholesaleplants sur la mobilité piétonne et le design informationnel.",
        blog: "Articles approfondis sur les pratiques de cartographie intérieure, de guidage visuel et de flux piétons.",
        contact: "Coordonnées, formulaire de contact et localisation de danswholesaleplants à Bruxelles.",
        faq: "Questions fréquentes concernant l’orientation spatiale, la signalétique numérique et la navigation intérieure.",
        terms: "Conditions générales d’utilisation de la plateforme danswholesaleplants.",
        privacy: "Informations sur la collecte, l’utilisation et la conservation des données par danswholesaleplants.",
        cookies: "Détails sur l’utilisation des cookies et la gestion des préférences sur danswholesaleplants.",
        refund: "Politique de révision et de gestion des ajustements éditoriaux de danswholesaleplants.",
        disclaimer: "Avertissement et limites de responsabilité de danswholesaleplants.",
        thankyou: "Confirmation de réception de votre message par danswholesaleplants.",
        post1: "Analyse des dispositifs d’orientation multimodale dans les pôles d’échanges belges.",
        post2: "Signalétique immersive et cartographie intérieure : étude des environnements urbains.",
        post3: "Approche analytique de la modélisation des flux piétons dans les bâtiments publics.",
        post4: "Principes d’accessibilité multisensorielle pour la navigation intérieure.",
        post5: "Temporalités et parcours utilisateurs : étude des cartes dynamiques."
      }
    },
    nav: {
      home: "Accueil",
      services: "Services",
      about: "À propos",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact",
      toggle: "Ouvrir ou fermer le menu principal"
    },
    lang: {
      fr: "FR",
      en: "EN"
    },
    actions: {
      discoverResources: "Explorer les ressources",
      viewServices: "Consulter les services",
      readMore: "Lire l’article",
      contact: "Accéder au contact",
      downloadBrief: "Obtenir la synthèse",
      viewMap: "Afficher la carte",
      sendMessage: "Envoyer le message",
      backHome: "Retour à l’accueil"
    },
    validation: {
      required: "Merci de compléter tous les champs obligatoires.",
      email: "Veuillez fournir une adresse courriel valide."
    },
    toast: {
      success: "Le formulaire a été envoyé. Redirection en cours…",
      error: "Impossible d’enregistrer les préférences. Merci de réessayer."
    },
    footer: {
      heading: "Synthèse spatiale pour les environnements bâtis complexes.",
      phoneLabel: "Téléphone",
      emailLabel: "Courriel",
      phoneValue: "+32 2 318 67 40",
      emailValue: "info@danswholesaleplants.com",
      addressLabel: "Adresse",
      addressValue: "Rue de la Loi 155, 1040 Bruxelles, Belgique",
      copyright: "© {{year}} danswholesaleplants. Tous droits réservés.",
      legalTitle: "Références légales"
    },
    home: {
      hero: {
        kicker: "Orientation spatiale",
        title: "Structurer la lisibilité des environnements complexes.",
        subtitle: "danswholesaleplants étudie la signalétique numérique, la navigation intérieure et la cartographie des espaces publics pour renforcer la lisibilité des parcours utilisateurs en Belgique.",
        primary: "Explorer les ressources",
        secondary: "Consulter les services",
        imageAlt: "Schéma tridimensionnel illustrant un hall public avec signalétique numérique"
      },
      featured: {
        kicker: "Champs d’étude",
        title: "Approches croisées pour la navigation intérieure",
        description: "Nous combinons des modèles de cartographie, des analyses d’usage et des protocoles d’accessibilité pour déployer des parcours lisibles dans les environnements bâtis.",
        card1Title: "Cartographie narrative",
        card1Text: "Construction de scénarios spatiaux reliant signalétique numérique, parcours piétons et flux de circulation à plusieurs niveaux.",
        card2Title: "Guidage adaptatif",
        card2Text: "Évaluation des interactions entre plans interactifs, architecture et facteurs de repérage dans les bâtiments publics.",
        card3Title: "Lisibilité augmentée",
        card3Text: "Mesure de la compréhension des repères graphiques et auditifs pour divers profils d’utilisateurs."
      },
      metrics: {
        card1Value: "36",
        card1Label: "Études de terrains urbains",
        card2Value: "18",
        card2Label: "Matrices de flux comparées",
        card3Value: "24",
        card3Label: "Itinéraires testés in situ",
        card4Value: "12",
        card4Label: "Comptes rendus sur l’accessibilité"
      },
      recommendations: {
        kicker: "Recommandations",
        title: "Pistes opérationnelles pour la signalétique numérique",
        description: "Les observations menées dans les gares, campus et administrations belges ont permis de dégager plusieurs principes prioritaires pour soutenir la mobilité piétonne.",
        item1Title: "Couche d’orientation hiérarchisée",
        item1Text: "Superposer la signalétique numérique avec la trame architecturale afin de maintenir un axe visuel constant entre chaque décision de parcours.",
        item2Title: "Micro-interfaces situées",
        item2Text: "Insérer des points d’information interactifs aux zones de transition pour limiter l’incertitude lors des bifurcations multiples.",
        item3Title: "Visualisation temporelle",
        item3Text: "Indiquer la durée estimée et la densité de flux sur les plans dynamiques pour anticiper la dispersion des visiteurs.",
        item4Title: "Narration inclusive",
        item4Text: "Concevoir des messages textuels et pictographiques s’adaptant aux différents niveaux de littératie et capacités sensorielles."
      },
      testimonials: {
        kicker: "Témoignages",
        title: "Retours d’experts du territoire",
        card1Quote: "Les analyses de danswholesaleplants ont permis de clarifier la correspondance entre la géométrie des bâtiments et les repères numériques. Les usagers circulent désormais avec davantage d’assurance.",
        card1Author: "Maud Lemoine",
        card1Role: "Responsable accessibilité, Ville de Bruxelles",
        card2Quote: "La méthodologie croisant flux piétons et UX spatiale offre des arguments solides pour anticiper les décisions architecturales. Les plans sont devenus plus intuitifs.",
        card2Author: "Jeroen De Wilde",
        card2Role: "Urbaniste, Agence Métropole Durable",
        card3Quote: "Le regard porté sur la signalétique numérique a révélé des lacunes dans nos parcours d’accueil. Les ajustements recommandés ont réduit la désorientation initiale.",
        card3Author: "Sophie Van den Berg",
        card3Role: "Coordinatrice des services publics, Région flamande"
      },
      insights: {
        kicker: "Lectures recommandées",
        title: "Dernières analyses publiées",
        description: "Chaque article documente un volet spécifique de la navigation intérieure, de l’architecture de l’information aux protocoles d’accessibilité.",
        post1Title: "Repenser les correspondances multimodales",
        post1Excerpt: "Comment orchestrer la signalétique numérique dans les hubs de transport belges pour fluidifier les transitions piétonnes.",
        post2Title: "Immersion visuelle dans les campus étendus",
        post2Excerpt: "Approches immersives pour articuler cartographie indoor et repères tangibles sur les sites universitaires.",
        post3Title: "Flux piétons et micro-décisions",
        post3Excerpt: "Analyse des micro-décisions prises à chaque croisement au sein des bâtiments administratifs."
      }
    },
    services: {
      hero: {
        kicker: "Panorama méthodologique",
        title: "Des cadres d’analyse au service de l’orientation spatiale.",
        subtitle: "Nos travaux abordent les environnements belges à forte densité fonctionnelle : hôpitaux, gares, musées, sièges administratifs et quartiers institutionnels.",
        imageAlt: "Vue axonométrique d’un bâtiment public avec parcours lumineux"
      },
      overview: {
        title: "Domaines d’intervention",
        description: "Chaque axe de travail donne lieu à des comptes rendus détaillés, incluant matrices de circulation, cartographies narratives et recommandations structurantes.",
        items: [
          {
            title: "Diagnostic des défis d’orientation",
            text: "Analyser la morphologie des lieux, les ruptures d’alignement et la lisibilité des séquences spatiales."
          },
          {
            title: "Principes de signalétique numérique",
            text: "Élaborer des chartes intégrant écrans, projections et dispositifs interactifs en cohérence avec la signalétique physique."
          },
          {
            title: "Cartographie des parcours utilisateurs",
            text: "Tracer des itinéraires types, détecter les points de friction et aligner les repères tactiles, visuels et sonores."
          },
          {
            title: "Liaison architecture - UX spatiale",
            text: "Confronter les plans architecturaux aux scénarios d’usage pour anticiper les zones de densité et d’attente."
          },
          {
            title: "Normes d’accessibilité numérique",
            text: "Comparer les solutions d’orientation digitale aux référentiels belges et européens d’accessibilité."
          },
          {
            title: "Évaluation de la lisibilité graphique",
            text: "Mesurer la compréhension des pictogrammes, typographies et palettes lumineuses en contexte réel."
          }
        ]
      },
      methodology: {
        title: "Méthodologie",
        description: "Les diagnostics s’appuient sur des observations in situ, des entretiens avec les gestionnaires d’espaces et des protocoles de test utilisateurs.",
        step1Title: "Immersion du terrain",
        step1Text: "Repérage des carrefours, relevé de la signalétique existante et mesure des temps de traversée.",
        step2Title: "Modélisation des flux",
        step2Text: "Simulation des trajectoires avec différents profils d’usagers et scénarios de fréquentation.",
        step3Title: "Restitution opérationnelle",
        step3Text: "Production de plans séquencés, matrices d’actions et supports d’aide à la décision."
      },
      highlight: {
        title: "Focus : structures publiques belges",
        text: "Les pôles multimodaux de Bruxelles, Liège et Anvers servent de laboratoire pour affiner des recommandations applicables à d’autres environnements bâtis."
      }
    },
    about: {
      hero: {
        kicker: "À propos",
        title: "Une plateforme dédiée à la compréhension des espaces complexes.",
        subtitle: "danswholesaleplants croise design informationnel, mobilité piétonne et architecture pour renforcer la lisibilité des infrastructures belges.",
        imageAlt: "Équipe travaillant sur des plans architecturaux et cartes interactives"
      },
      mission: {
        title: "Mission",
        paragraph1: "Approfondir les connaissances liées aux parcours utilisateurs et aux dispositifs numériques de guidage dans les bâtiments publics et espaces urbains.",
        paragraph2: "Diffuser des outils de cartographie et des cadres de lecture pour soutenir les acteurs chargés de l’accueil, de la mobilité et de la communication visuelle."
      },
      approach: {
        title: "Approche",
        item1: "Observation prolongée des comportements piétons dans les zones de transition complexes.",
        item2: "Analyse de la cohérence entre repères physiques, plans interactifs et signalétique digitale.",
        item3: "Production de guides et synthèses alignés sur les normes d’accessibilité et d’inclusion."
      },
      timeline: {
        title: "Étapes clés",
        milestone1Title: "Explorations initiales",
        milestone1Text: "Études qualitatives des parcours dans les gares bruxelloises et identification des ruptures de lisibilité.",
        milestone2Title: "Structuration méthodologique",
        milestone2Text: "Création de matrices de flux piétons et de gabarits d’analyse pour les bâtiments administratifs.",
        milestone3Title: "Diffusion régionale",
        milestone3Text: "Accompagnement de projets dans les villes de Gand, Liège et Namur pour intégrer la signalétique numérique.",
        milestone4Title: "Ouverture internationale",
        milestone4Text: "Partage d’expériences avec des centres de recherche européens sur l’UX spatiale et la cartographie interactive."
      },
      values: {
        title: "Valeurs",
        card1Title: "Rigueur",
        card1Text: "Comparer chaque recommandation à des données tangibles issues des usages et des observations prolongées.",
        card2Title: "Inclusion",
        card2Text: "Prendre en compte la diversité des mobilités et des capacités sensorielles dès les premières esquisses.",
        card3Title: "Lisibilité",
        card3Text: "Clarifier les interactions entre architecture, parcours et information pour favoriser l’autonomie."
      }
    },
    blog: {
      hero: {
        kicker: "Blog analytique",
        title: "Études et retours d’expériences sur la navigation intérieure.",
        subtitle: "Chaque publication documente des cas belges et européens en mettant en regard architecture, signalétique numérique et accessibilité."
      },
      listIntro: "Sélection d’articles pour approfondir la compréhension des environnements bâtis.",
      cards: {
        post1: {
          title: "Cartographier les correspondances multimodales",
          excerpt: "Comment orchestrer des couches d’orientation cohérentes dans les pôles d’échanges belges pour fluidifier les correspondances."
        },
        post2: {
          title: "Signalétique immersive dans les campus",
          excerpt: "Les campus étendus exigent une narration spatiale immersive. Tour d’horizon des solutions numériques et physiques."
        },
        post3: {
          title: "Modéliser les flux piétons",
          excerpt: "Construire des modèles qui traduisent les micro-décisions et anticipent les saturations dans les bâtiments publics."
        },
        post4: {
          title: "Accessibilité multisensorielle",
          excerpt: "Vers une signalétique numérique capable de dialoguer avec divers canaux sensoriels pour guider chaque usager."
        },
        post5: {
          title: "Cartographie temporelle des parcours",
          excerpt: "Étudier la dimension temporelle des itinéraires et des flux pour ajuster la signalétique dynamique."
        }
      }
    },
    contact: {
      hero: {
        kicker: "Contact",
        title: "Coordonner la réflexion autour de vos espaces.",
        subtitle: "Partagez vos enjeux d’orientation, de signalétique numérique ou de mobilité piétonne. Nous revenons vers vous avec des pistes méthodologiques.",
        imageAlt: "Plan de bâtiment avec annotations et repères de circulation"
      },
      detailsTitle: "Coordonnées",
      phoneLabel: "Téléphone",
      emailLabel: "Courriel",
      addressLabel: "Adresse",
      scheduleLabel: "Disponibilité",
      scheduleValue: "Du lundi au vendredi, 9 h - 17 h CET",
      mapCaption: "Localisation de danswholesaleplants à Bruxelles."
    },
    form: {
      title: "Formulaire de contact",
      description: "Indiquez le contexte de votre espace, les publics concernés et les problématiques de navigation observées.",
      nameLabel: "Nom complet",
      namePlaceholder: "Votre nom",
      emailLabel: "Adresse courriel",
      emailPlaceholder: "nom@domaine.be",
      organizationLabel: "Organisation",
      organizationPlaceholder: "Nom de l’organisme",
      messageLabel: "Message",
      messagePlaceholder: "Décrivez les enjeux, les objectifs et les contraintes.",
      submit: "Envoyer le message"
    },
    faq: {
      hero: {
        kicker: "FAQ",
        title: "Questions fréquentes sur la navigation intérieure.",
        subtitle: "Réponses aux interrogations courantes portant sur la signalétique numérique, la cartographie des espaces et l’accessibilité."
      },
      items: [
        {
          question: "Comment démarrez-vous l’analyse d’un bâtiment public ?",
          answer: "Nous commençons par établir une cartographie des flux existants, une observation des points de friction et un inventaire de la signalétique déjà présente."
        },
        {
          question: "Quels outils utilisez-vous pour modéliser la circulation ?",
          answer: "Nous combinons relevés in situ, captations vidéo anonymisées et modélisation schématique pour simuler différents scénarios d’affluence."
        },
        {
          question: "Comment intégrer les besoins des personnes à mobilité réduite ?",
          answer: "Chaque recommandation est comparée aux normes belges et européennes, avec une attention particulière portée aux contrastes, aux repères tactiles et aux itinéraires alternatifs."
        },
        {
          question: "Travaillez-vous uniquement en Belgique ?",
          answer: "La priorité est donnée aux environnements belges, mais les enseignements peuvent être partagés avec d’autres territoires disposant d’infrastructures comparables."
        },
        {
          question: "Combien de temps dure une observation sur site ?",
          answer: "La phase d’immersion dure généralement entre deux et quatre semaines selon la complexité des espaces et la diversité des profils usagers."
        },
        {
          question: "Produisez-vous des supports prêts à l’impression ?",
          answer: "Nous réalisons des gabarits et des maquettes détaillées qui peuvent ensuite être adaptés par des équipes graphiques ou des prestataires spécialisés."
        }
      ]
    },
    terms: {
      hero: {
        title: "Conditions d’utilisation",
        subtitle: "Cadre juridique régissant l’accès et l’utilisation de la plateforme danswholesaleplants."
      },
      sections: [
        {
          title: "1. Objet",
          body: "Les présentes conditions définissent les règles applicables à l’utilisation des contenus et ressources publiés sur le site danswholesaleplants."
        },
        {
          title: "2. Acceptation",
          body: "Toute consultation du site implique l’acceptation sans réserve des conditions présentées dans ce document."
        },
        {
          title: "3. Accès au site",
          body: "Le site est accessible gratuitement. L’éditeur se réserve le droit de suspendre temporairement l’accès pour maintenance."
        },
        {
          title: "4. Propriété intellectuelle",
          body: "Les contenus, textes, images, graphiques et données demeurent la propriété de danswholesaleplants, sauf mention contraire."
        },
        {
          title: "5. Utilisation des contenus",
          body: "Toute reproduction ou diffusion publique doit être précédée d’une autorisation écrite et citer la source."
        },
        {
          title: "6. Sources externes",
          body: "Le site peut contenir des liens sortants. danswholesaleplants n’est pas responsable du contenu de ces ressources."
        },
        {
          title: "7. Responsabilité",
          body: "L’éditeur décline toute responsabilité en cas d’interprétation erronée des informations publiées."
        },
        {
          title: "8. Sécurité",
          body: "Chaque utilisateur doit veiller à la sécurité de ses équipements lors de la consultation du site."
        },
        {
          title: "9. Données personnelles",
          body: "Les données collectées via le formulaire de contact sont traitées conformément à la politique de confidentialité."
        },
        {
          title: "10. Cookies",
          body: "Les cookies sont utilisés pour la mesure d’audience et la personnalisation des préférences, sous réserve du consentement de l’utilisateur."
        },
        {
          title: "11. Évolution du site",
          body: "danswholesaleplants peut modifier le contenu ou la structure du site sans préavis."
        },
        {
          title: "12. Modification des conditions",
          body: "Les présentes conditions peuvent être révisées. La date de dernière mise à jour est indiquée sur la page."
        },
        {
          title: "13. Droit applicable",
          body: "Les conditions sont soumises au droit belge. Tout litige relève des tribunaux compétents de Bruxelles."
        },
        {
          title: "14. Contact",
          body: "Pour toute question, contactez-nous via le formulaire disponible sur la page dédiée."
        }
      ]
    },
    privacy: {
      hero: {
        title: "Politique de confidentialité",
        subtitle: "Transparence sur la collecte, l’utilisation et la conservation des données personnelles."
      },
      sections: [
        {
          title: "1. Responsable du traitement",
          body: "Le responsable du traitement est danswholesaleplants, basé à Bruxelles."
        },
        {
          title: "2. Données collectées",
          body: "Nous collectons les informations fournies volontairement via le formulaire de contact : nom, courriel, organisation et message."
        },
        {
          title: "3. Finalités",
          body: "Les données servent uniquement à répondre aux messages et à documenter les demandes d’information."
        },
        {
          title: "4. Base légale",
          body: "Le traitement s’appuie sur l’intérêt légitime d’assurer le suivi des demandes entrantes."
        },
        {
          title: "5. Conservation",
          body: "Les données sont conservées pendant une durée maximale de vingt-quatre mois, puis archivées de façon anonymisée."
        },
        {
          title: "6. Partage",
          body: "Aucune donnée n’est vendue ou cédée. Des prestataires techniques peuvent accéder aux informations pour assurer l’hébergement et la maintenance."
        },
        {
          title: "7. Droits des personnes",
          body: "Vous disposez d’un droit d’accès, de rectification, d’effacement, de limitation et d’opposition au traitement de vos données."
        },
        {
          title: "8. Exercice des droits",
          body: "Pour exercer ces droits, contactez-nous via le formulaire ou l’adresse courriel indiquée dans les mentions légales."
        },
        {
          title: "9. Cookies",
          body: "Les cookies sont gérés selon les préférences exprimées dans le bandeau de consentement."
        },
        {
          title: "10. Sécurité",
          body: "Des mesures techniques et organisationnelles sont mises en œuvre pour protéger les données contre les accès non autorisés."
        },
        {
          title: "11. Réclamation",
          body: "En cas de désaccord, vous pouvez solliciter l’Autorité de protection des données en Belgique."
        }
      ]
    },
    cookies: {
      hero: {
        title: "Politique relative aux cookies",
        subtitle: "Informations sur les cookies utilisés et gestion de vos préférences."
      },
      intro: "Ce site utilise des cookies pour améliorer la navigation et mesurer l’audience. Vous pouvez ajuster vos préférences à tout moment via le bandeau dédié.",
      tableHeaders: {
        name: "Nom du cookie",
        provider: "Fournisseur",
        type: "Type",
        purpose: "Finalité",
        duration: "Durée"
      },
      rows: [
        {
          name: "cookie_consent",
          provider: "danswholesaleplants",
          type: "Nécessaire",
          purpose: "Mémoriser vos choix en matière de cookies.",
          duration: "12 mois"
        },
        {
          name: "site_lang",
          provider: "danswholesaleplants",
          type: "Préférences",
          purpose: "Conserver votre langue d’affichage sur l’ensemble du site.",
          duration: "12 mois"
        },
        {
          name: "analytics_view",
          provider: "danswholesaleplants",
          type: "Analytique",
          purpose: "Suivre les pages consultées afin d’améliorer les contenus.",
          duration: "13 mois"
        },
        {
          name: "campaign_context",
          provider: "danswholesaleplants",
          type: "Marketing",
          purpose: "Mesurer l’efficacité des contenus partagés sur des canaux externes.",
          duration: "6 mois"
        }
      ],
      preferences: {
        necessaryTitle: "Cookies nécessaires",
        necessaryHint: "Toujours actifs car essentiels au fonctionnement du site.",
        preferencesTitle: "Cookies de préférences",
        preferencesHint: "Enregistrer vos choix d’affichage, notamment la langue.",
        analyticsTitle: "Cookies analytiques",
        analyticsHint: "Mesurer la fréquentation pour améliorer la structure des contenus.",
        marketingTitle: "Cookies marketing",
        marketingHint: "Suivre les interactions avec les supports externes."
      },
      banner: {
        title: "Gestion des cookies",
        description: "Nous utilisons des cookies pour assurer le bon fonctionnement du site et analyser son usage. Vous pouvez personnaliser vos choix.",
        link: "En savoir plus",
        accept: "Tout accepter",
        decline: "Tout refuser",
        save: "Enregistrer les préférences"
      }
    },
    refund: {
      hero: {
        title: "Politique de révision",
        subtitle: "Modalités d’ajustement des livrables éditoriaux et cartographiques."
      },
      sections: [
        {
          title: "1. Champ d’application",
          body: "La présente politique s’applique aux documents analytiques, cartes et synthèses méthodologiques diffusés par danswholesaleplants."
        },
        {
          title: "2. Demandes de correction",
          body: "Les demandes de correction doivent être formulées par écrit via le formulaire de contact dans un délai de trente jours."
        },
        {
          title: "3. Analyse des demandes",
          body: "Chaque demande est examinée afin de déterminer si elle relève d’une mise à jour factuelle ou d’un approfondissement méthodologique."
        },
        {
          title: "4. Corrections mineures",
          body: "Les corrections mineures (terminologie, orthographe, précision de données) sont intégrées dans un délai raisonnable."
        },
        {
          title: "5. Révisions majeures",
          body: "Les révisions impliquant des campagnes de mesure ou de nouvelles observations sont étudiées au cas par cas."
        },
        {
          title: "6. Limitations",
          body: "Les révisions ne couvrent pas les usages détournés ou les interprétations externes des documents fournis."
        },
        {
          title: "7. Formats de livraison",
          body: "Les mises à jour sont communiquées sous le même format que la version initiale, sauf accord spécifique."
        },
        {
          title: "8. Notification",
          body: "Les utilisateurs sont avertis par courriel dès que la version révisée est disponible."
        },
        {
          title: "9. Archivage",
          body: "Les versions originales sont archivées pour assurer la traçabilité des modifications."
        },
        {
          title: "10. Contact",
          body: "Toute demande de précision peut être adressée via la page contact en mentionnant la référence du document concerné."
        }
      ]
    },
    disclaimer: {
      hero: {
        title: "Avertissement",
        subtitle: "Limites de responsabilité relatives aux contenus publiés."
      },
      sections: [
        {
          title: "Information générale",
          body: "Les contenus proposés ont vocation à informer sur les pratiques d’orientation spatiale. Ils ne constituent pas une recommandation exhaustive."
        },
        {
          title: "Absence de garantie",
          body: "danswholesaleplants ne garantit pas l’absence d’erreurs ou l’exhaustivité des informations mises à disposition."
        },
        {
          title: "Utilisation des données",
          body: "Les utilisateurs demeurent responsables de l’usage qu’ils font des informations et des conclusions présentées."
        },
        {
          title: "Contextes spécifiques",
          body: "Les résultats décrits peuvent varier selon les caractéristiques propres à chaque environnement bâti ou territoire."
        },
        {
          title: "Liens externes",
          body: "La présence de liens vers des ressources tierces ne constitue pas une approbation de leur contenu."
        },
        {
          title: "Mise à jour",
          body: "Les informations peuvent être modifiées sans préavis pour refléter l’évolution des recherches et observations."
        }
      ]
    },
    thankyou: {
      title: "Merci pour votre message.",
      paragraph: "Votre demande a été transmise. Nous reviendrons vers vous avec des informations complémentaires sur l’orientation spatiale ou la signalétique numérique."
    },
    posts: {
      post1: {
        metadata: "Étude publiée le 15 février 2024 • Hubs de transport",
        title: "Cartographier les correspondances multimodales dans les pôles d’échanges belges",
        intro: "Les gares et stations belges combinent transports ferroviaires, bus, tram et services urbains. La multiplicité des connexions impose de rendre immédiatement lisibles les trajectoires possibles sans surcharge informationnelle.",
        section1Title: "Cartographie stratifiée des niveaux",
        section1Paragraph1: "L’analyse débute par la superposition des plans des niveaux souterrains, des mezzanines et des accès de surface. Chaque couche est associée à un code couleur cohérent sur les supports physiques et numériques. Cette logique permet de réduire les ruptures de compréhension entre les plans dynamiques consultés sur smartphone et les panneaux de direction situés sur site.",
        section1Paragraph2: "Les correspondances les plus critiques sont identifiées à partir de mesures de temps réel : distance parcourue, temps moyen de marche, points d’attente. En croisant ces données avec les flux d’entrée et de sortie, nous reconstituons les micro-décisions des usagers confrontés à plusieurs bifurcations successives.",
        section2Title: "Signalétique numérique et repères ancrés",
        section2Paragraph1: "Les dispositifs digitaux ne remplacent pas la signalétique statique ; ils l’enrichissent. Nous avons constaté que les écrans dédiés aux correspondances doivent être positionnés avant la zone de décision. Un affichage tardif entraîne un retour en arrière et augmente la densité de piétons. Les repères physiques, tels que les contrastes de matériaux et les éclairages spécifiques, facilitent la mémorisation du parcours.",
        section2Paragraph2: "Une attention particulière est portée aux passagers internationaux, pour lesquels l’apprentissage des codes locaux nécessite un accompagnement visuel et sonore. Des messages courts, disponibles en plusieurs langues, sont diffusés sur les plans interactifs et synchronisés avec la signalétique audio pour éviter la dissonance.",
        section3Title: "Expérimentations et enseignements",
        section3Paragraph1: "Les tests menés dans les gares de Bruxelles-Central, Liège-Guillemins et Anvers-Central ont révélé l’importance d’une articulation claire entre les destinations finales et les services intermédiaires : toilettes, consignes, points d’information. Les parcours expérimentaux montrent que l’ajout de repères temporels, comme la durée estimée avant l’arrivée au quai, réduit l’anxiété des usagers.",
        section3Paragraph2: "La mise en place de cartographies évolutives, capables de signaler les zones temporairement fermées, garantit une expérience cohérente. Les équipes de terrain doivent disposer d’outils simples pour mettre à jour les informations. Un tableau de bord centralisant les modifications et les diffusant sur l’ensemble des supports évite les incohérences.",
        conclusionTitle: "Vers des correspondances lisibles",
        conclusionParagraph: "Une correspondance réussie dépend d’un vocabulaire graphique stable, d’une articulation entre supports numériques et physiques, et d’une anticipation des flux. Les hubs belges qui ont adopté cette approche constatent une baisse des demandes d’assistance et une circulation plus homogène."
      },
      post2: {
        metadata: "Étude publiée le 4 mars 2024 • Campus universitaires",
        title: "Concevoir une signalétique immersive pour les campus étendus",
        intro: "Les campus dispersés sur plusieurs hectares cumulent bâtiments historiques, extensions contemporaines et espaces publics ouverts. Les étudiants et visiteurs alternent entre séquences intérieures et extérieures, ce qui renforce la nécessité d’une narration spatiale continue.",
        section1Title: "Narration spatiale continue",
        section1Paragraph1: "Une signalétique immersive associe éléments graphiques, audio et interactifs. Les parcours sont découpés en chapitres dont chaque entrée est clairement annoncée. Les cartes numériques, intégrées à des bornes tactiles, reprennent les codes graphiques des plans imprimés pour éviter la rupture visuelle.",
        section1Paragraph2: "L’intégration de repères paysagers, tels que les arbres remarquables ou les œuvres d’art, sert de fil conducteur. Les visiteurs peuvent ainsi maintenir leur orientation même lorsqu’ils sortent d’un bâtiment et traversent une esplanade.",
        section2Title: "Plans interactifs et participation",
        section2Paragraph1: "L’expérience utilisateur s’améliore lorsque les plans interactifs permettent de personnaliser l’itinéraire selon la mobilité, le temps disponible et les préférences d’accessibilité. Les étudiants en situation de handicap ont signalé l’importance d’avoir des indications précises sur les ascenseurs, les rampes ou les portes automatiques.",
        section2Paragraph2: "La coconstruction avec les services techniques et les associations étudiantes renforce la pertinence des messages. Les retours recueillis lors des ateliers de cartographie participative nourrissent les mises à jour régulières.",
        section3Title: "Indicateurs de performance",
        section3Paragraph1: "Les campus analysés disposent désormais d’indicateurs : temps moyen pour rejoindre les amphithéâtres, taux de demandes d’information dans les halls, satisfaction des nouveaux étudiants. Ces indicateurs permettent d’ajuster les supports en continu.",
        section3Paragraph2: "La capitalisation sur une base de données centralisée assure la cohérence des différents supports : brochures, applications mobiles, panneaux LED et signalétiques temporaires liées aux événements.",
        conclusionTitle: "Immersion maîtrisée",
        conclusionParagraph: "La signalétique immersive repose sur une combinaison de repères sensoriels et d’outils numériques modulables. En garantissant la cohérence graphique et la participation des usagers, les campus belges renforcent la fluidité de la navigation."
      },
      post3: {
        metadata: "Étude publiée le 28 mars 2024 • Bâtiments administratifs",
        title: "Modéliser les flux piétons pour anticiper les zones de densité",
        intro: "Les bâtiments administratifs accueillent des flux variés : collaborateurs, visiteurs, prestataires. Les pics de fréquentation se concentrent aux heures d’ouverture et lors des événements. Comprendre ces flux est essentiel pour dimensionner la signalétique.",
        section1Title: "Observation multi-échelles",
        section1Paragraph1: "Les premières observations consistent à noter les itinéraires privilégiés, la durée des arrêtés et la densité des croisements. Les schémas produits permettent d’identifier les zones d’attente spontanée où l’information doit être renforcée.",
        section1Paragraph2: "Les capteurs anonymisés complètent les observations humaines. Ils mesurent la vitesse de déplacement et la densité. Ces données alimentent des modèles simulant l’impact de modifications architecturales ou informatives.",
        section2Title: "Matrices de décision",
        section2Paragraph1: "Chaque carrefour interne est traité comme un point de décision. Nous évaluons la qualité de la signalétique, la visibilité des ascenseurs, la cohérence des codes couleur. Une matrice résume les améliorations prioritaires.",
        section2Paragraph2: "Il est essentiel de distinguer les besoins des visiteurs ponctuels et des collaborateurs habitués aux lieux. Les premiers nécessitent une information plus redondante, tandis que les seconds bénéficient d’outils rapides comme les notifications numériques.",
        section3Title: "Recommandations fonctionnelles",
        section3Paragraph1: "Les recommandations couvrent la hiérarchisation des directions, la mise en place de repères volumétriques et l’intégration d’écrans aux points critiques. Des scénarios d’évacuation sont également étudiés pour préserver la lisibilité en situation dégradée.",
        section3Paragraph2: "Les résultats montrent qu’une signalétique cohérente réduit de 18 % les détours moyens et améliore la perception d’accessibilité. Les usagers identifient plus rapidement les zones de services et les salles de réunion.",
        conclusionTitle: "Anticiper pour fluidifier",
        conclusionParagraph: "La modélisation des flux piétons n’est pas un exercice théorique ; elle oriente le positionnement des repères et des plans interactifs. Les organisations belges qui en font un outil de pilotage gagnent en lisibilité et en efficacité."
      },
      post4: {
        metadata: "Étude publiée le 11 avril 2024 • Accessibilité",
        title: "Vers une accessibilité multisensorielle des parcours intérieurs",
        intro: "Les environnements bâtis doivent intégrer tous les profils d’usagers. La combinaison de repères visuels, tactiles et sonores renforce l’autonomie des personnes en situation de handicap.",
        section1Title: "Combiner repères et technologies",
        section1Paragraph1: "Les plans en relief, bandes podotactiles et pictogrammes contrastés constituent la base d’un parcours inclusif. Les dispositifs numériques complètent ces repères en fournissant des informations contextuelles via des balises sonores.",
        section1Paragraph2: "Les tests effectués dans plusieurs musées belges montrent que l’alignement des messages audio avec la signalétique physique réduit les interruptions de parcours et les retours en arrière.",
        section2Title: "Adaptation des supports numériques",
        section2Paragraph1: "Les écrans interactifs doivent proposer des modes à contraste élevé, une navigation via commandes physiques et une lecture audio des contenus. Les QR codes adaptés permettent de recevoir des indications personnalisées sur smartphone.",
        section2Paragraph2: "La qualité de l’expérience dépend également de la formation du personnel et de la maintenance régulière des dispositifs. Un écran éteint ou une balise muette peut compromettre la continuité du parcours.",
        section3Title: "Évaluation participative",
        section3Paragraph1: "Les évaluations sont menées avec des associations représentant différents handicaps. Le recueil de leurs retours garantit que les adaptations ne se limitent pas à une conformité réglementaire, mais répondent à des besoins concrets.",
        section3Paragraph2: "Les indicateurs incluent le temps nécessaire pour rejoindre une zone clé, le nombre de sollicitations d’aide et la satisfaction perçue. Les sites les plus avancés actualisent leurs plans numériques après chaque campagne de mesure.",
        conclusionTitle: "Accessibilité active",
        conclusionParagraph: "L’accessibilité multisensorielle exige un engagement permanent : aligner la signalétique, tester avec les usagers, maintenir les équipements. C’est la condition pour offrir une navigation fiable à chacun."
      },
      post5: {
        metadata: "Étude publiée le 2 mai 2024 • Temporalité des parcours",
        title: "Cartographie temporelle des parcours utilisateurs",
        intro: "Les cartes statiques ne suffisent plus à représenter l’expérience des usagers. Intégrer la dimension temporelle permet d’ajuster la signalétique en fonction des rythmes et des événements.",
        section1Title: "Mesurer la temporalité",
        section1Paragraph1: "Les enquêtes chronométrent le temps passé sur chaque segment de parcours et identifient les variations selon les périodes de la journée. Ces données alimentent des cartes montrant la densité horaire.",
        section1Paragraph2: "Les visualisations dynamiques indiquent les zones où des renforts informatifs sont nécessaires lors des pics. Elles aident les équipes à anticiper les files d’attente et les situations de saturation.",
        section2Title: "Signalétique dynamique",
        section2Paragraph1: "Les écrans et plans interactifs peuvent adapter leurs messages à la temporalité : afficher des itinéraires alternatifs lorsque la densité dépasse un seuil, recommander des entrées secondaires pendant les événements.",
        section2Paragraph2: "Les notifications contextualisées envoyées aux usagers volontaires complètent l’information sur place. Elles précisent les temps d’accès et les zones à éviter momentanément.",
        section3Title: "Pilotage et retours",
        section3Paragraph1: "Les gestionnaires suivent des tableaux de bord croisant la fréquentation et les retours qualitatifs. Ils peuvent ainsi tester plusieurs variantes et mesurer l’impact sur la fluidité.",
        section3Paragraph2: "La capitalisation des données temporelles nourrit les plans directeurs des sites : dimensionnement des espaces, positionnement des points d’accueil, calibrage des horaires d’ouverture.",
        conclusionTitle: "Temps et espace",
        conclusionParagraph: "Introduire la variable temporelle dans la cartographie transforme la manière d’aborder la signalétique. Les sites belges qui l’expérimentent constatent une meilleure répartition des flux et une satisfaction accrue des visiteurs."
      }
    },
    banner: {
      title: "Gestion des cookies",
      description: "Nous utilisons des cookies pour assurer le bon fonctionnement du site et analyser son usage. Vous pouvez personnaliser vos choix.",
      link: "En savoir plus",
      accept: "Tout accepter",
      decline: "Tout refuser",
      save: "Enregistrer les préférences",
      necessary: "Cookies nécessaires",
      preferences: "Cookies de préférences",
      analytics: "Cookies analytiques",
      marketing: "Cookies marketing"
    },
    map: {
      label: "Carte affichant la localisation de danswholesaleplants à Bruxelles."
    },
    thankyoupage: {
      message: "Merci pour votre message. Nous vous contacterons prochainement."
    }
  },
  en: {
    brand: {
      name: "danswholesaleplants",
      tagline: "Analyzing spatial orientation practices for highly intricate built environments."
    },
    meta: {
      title: {
        home: "danswholesaleplants | Spatial Orientation & Digital Wayfinding",
        services: "Services | danswholesaleplants",
        about: "About | danswholesaleplants",
        blog: "Blog | danswholesaleplants",
        contact: "Contact | danswholesaleplants",
        faq: "FAQ | danswholesaleplants",
        terms: "Terms of Use | danswholesaleplants",
        privacy: "Privacy Policy | danswholesaleplants",
        cookies: "Cookie Policy | danswholesaleplants",
        refund: "Revision Policy | danswholesaleplants",
        disclaimer: "Disclaimer | danswholesaleplants",
        thankyou: "Thank You | danswholesaleplants",
        post1: "Mapping multimodal interchanges | danswholesaleplants",
        post2: "Designing immersive signage | danswholesaleplants",
        post3: "Modeling pedestrian flows | danswholesaleplants",
        post4: "Multisensory accessibility | danswholesaleplants",
        post5: "Temporal mapping of journeys | danswholesaleplants"
      },
      description: {
        home: "Platform dedicated to spatial orientation, digital signage and mapping of complex environments in Belgium.",
        services: "Overview of analytical and methodological services related to digital signage and indoor navigation.",
        about: "Presentation of danswholesaleplants’ expertise on pedestrian mobility and information design.",
        blog: "In-depth articles on indoor mapping, visual guidance and pedestrian flow analysis.",
        contact: "Contact details, form and location of danswholesaleplants in Brussels.",
        faq: "Frequently asked questions on spatial orientation, digital signage and indoor navigation.",
        terms: "Terms and conditions governing the use of the danswholesaleplants platform.",
        privacy: "Information on data collection, usage and retention by danswholesaleplants.",
        cookies: "Details about cookie usage and preference management on danswholesaleplants.",
        refund: "Policy for editorial adjustments and revisions provided by danswholesaleplants.",
        disclaimer: "Disclaimer and liability limits of danswholesaleplants.",
        thankyou: "Confirmation that your message has been received by danswholesaleplants.",
        post1: "Analysis of multimodal orientation systems in Belgian transport hubs.",
        post2: "Immersive signage and indoor mapping: study of urban environments.",
        post3: "Analytical approach to modeling pedestrian flows in public buildings.",
        post4: "Principles of multisensory accessibility for indoor navigation.",
        post5: "Temporal journey mapping and dynamic routes."
      }
    },
    nav: {
      home: "Home",
      services: "Services",
      about: "About",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact",
      toggle: "Open or close the main menu"
    },
    lang: {
      fr: "FR",
      en: "EN"
    },
    actions: {
      discoverResources: "Browse resources",
      viewServices: "View services",
      readMore: "Read article",
      contact: "Go to contact",
      downloadBrief: "Get the brief",
      viewMap: "View map",
      sendMessage: "Send message",
      backHome: "Back to home"
    },
    validation: {
      required: "Please complete all required fields.",
      email: "Please provide a valid email address."
    },
    toast: {
      success: "Form submitted. Redirecting…",
      error: "Unable to save your preferences. Please try again."
    },
    footer: {
      heading: "Spatial intelligence for complex built environments.",
      phoneLabel: "Phone",
      emailLabel: "Email",
      phoneValue: "+32 2 318 67 40",
      emailValue: "info@danswholesaleplants.com",
      addressLabel: "Address",
      addressValue: "155 Rue de la Loi, 1040 Brussels, Belgium",
      copyright: "© {{year}} danswholesaleplants. All rights reserved.",
      legalTitle: "Legal references"
    },
    home: {
      hero: {
        kicker: "Spatial orientation",
        title: "Designing clarity for complex environments.",
        subtitle: "danswholesaleplants examines digital signage, indoor navigation and spatial mapping to reinforce the legibility of public journeys across Belgium.",
        primary: "Browse resources",
        secondary: "View services",
        imageAlt: "Three-dimensional scheme showing a public hall with digital signage"
      },
      featured: {
        kicker: "Focus areas",
        title: "Cross-disciplinary approaches to indoor navigation",
        description: "We combine mapping models, usage analysis and accessibility protocols to deliver readable pathways in built environments.",
        card1Title: "Narrative mapping",
        card1Text: "Build spatial scenarios linking digital signage, pedestrian routes and multi-level circulation flows.",
        card2Title: "Adaptive guidance",
        card2Text: "Assess interactions between interactive maps, architecture and wayfinding cues within public buildings.",
        card3Title: "Augmented legibility",
        card3Text: "Measure how graphic and auditory landmarks are understood by diverse user profiles."
      },
      metrics: {
        card1Value: "36",
        card1Label: "Urban sites observed",
        card2Value: "18",
        card2Label: "Flow matrices compared",
        card3Value: "24",
        card3Label: "On-site route tests",
        card4Value: "12",
        card4Label: "Accessibility briefs compiled"
      },
      recommendations: {
        kicker: "Recommendations",
        title: "Operational guidance for digital signage",
        description: "Field investigations across Belgian train stations, campuses and administrations produced actionable principles to support pedestrian mobility.",
        item1Title: "Layered orientation",
        item1Text: "Align digital signage with the architectural grid to maintain a consistent visual axis at every decision point.",
        item2Title: "Located micro-interfaces",
        item2Text: "Place interactive information points near transition zones to reduce uncertainty at complex bifurcations.",
        item3Title: "Temporal visualization",
        item3Text: "Display estimated duration and density indicators on dynamic maps to anticipate visitor dispersion.",
        item4Title: "Inclusive narration",
        item4Text: "Craft textual and pictographic messages that adapt to varying literacy levels and sensory abilities."
      },
      testimonials: {
        kicker: "Testimonials",
        title: "Feedback from territorial experts",
        card1Quote: "danswholesaleplants’ analyses clarified the dialogue between the building geometry and digital cues. People now navigate with greater confidence.",
        card1Author: "Maud Lemoine",
        card1Role: "Accessibility Manager, City of Brussels",
        card2Quote: "By merging pedestrian flow modeling with spatial UX, the methodology provides strong arguments to anticipate architectural decisions.",
        card2Author: "Jeroen De Wilde",
        card2Role: "Urban Planner, Metropolis Agency",
        card3Quote: "The focus on digital signage exposed gaps in our reception pathways. The recommended adjustments reduced first-time orientation issues.",
        card3Author: "Sophie Van den Berg",
        card3Role: "Public Services Coordinator, Flemish Region"
      },
      insights: {
        kicker: "Suggested readings",
        title: "Latest analytical releases",
        description: "Each article documents a specific facet of indoor navigation, from information architecture to accessibility protocols.",
        post1Title: "Rethinking multimodal transfers",
        post1Excerpt: "How to orchestrate digital orientation layers in Belgian hubs to streamline pedestrian transitions.",
        post2Title: "Immersive campus storytelling",
        post2Excerpt: "Immersive approaches linking indoor mapping and tangible cues across university grounds.",
        post3Title: "Pedestrian flows and micro-decisions",
        post3Excerpt: "Analyzing micro-decisions at every junction inside administrative buildings."
      }
    },
    services: {
      hero: {
        kicker: "Method overview",
        title: "Analytical frameworks dedicated to spatial orientation.",
        subtitle: "Our work addresses Belgian environments with high functional density: hospitals, stations, museums, administrative headquarters and institutional districts.",
        imageAlt: "Axonometric view of a public building with illuminated routes"
      },
      overview: {
        title: "Scope of work",
        description: "Each workstream results in detailed briefs covering circulation matrices, narrative maps and structural recommendations.",
        items: [
          {
            title: "Orientation diagnostics",
            text: "Analyze the site morphology, alignment breaks and readability of spatial sequences."
          },
          {
            title: "Digital signage principles",
            text: "Define charters integrating screens, projections and interactive devices aligned with physical signage."
          },
          {
            title: "User journey mapping",
            text: "Outline key itineraries, detect friction points and align tactile, visual and auditory cues."
          },
          {
            title: "Architecture & spatial UX link",
            text: "Compare architectural plans with usage scenarios to anticipate density and waiting areas."
          },
          {
            title: "Digital accessibility standards",
            text: "Benchmark digital orientation tools against Belgian and European accessibility references."
          },
          {
            title: "Graphic legibility review",
            text: "Measure how pictograms, typographies and lighting palettes perform in real contexts."
          }
        ]
      },
      methodology: {
        title: "Method",
        description: "Diagnostics rely on on-site observation, interviews with facility managers and user testing protocols.",
        step1Title: "Field immersion",
        step1Text: "Survey decision points, inventory existing signage and assess walking times.",
        step2Title: "Flow modeling",
        step2Text: "Simulate trajectories for different user profiles and attendance scenarios.",
        step3Title: "Operational briefing",
        step3Text: "Produce sequenced plans, action matrices and decision support material."
      },
      highlight: {
        title: "Focus: Belgian public infrastructures",
        text: "Multimodal hubs in Brussels, Liège and Antwerp act as laboratories to refine recommendations applicable to other built environments."
      }
    },
    about: {
      hero: {
        kicker: "About",
        title: "A platform dedicated to decoding complex spaces.",
        subtitle: "danswholesaleplants blends information design, pedestrian mobility and architecture to reinforce the legibility of Belgian infrastructures.",
        imageAlt: "Team collaborating on architectural plans and interactive maps"
      },
      mission: {
        title: "Mission",
        paragraph1: "Deepen knowledge related to user journeys and digital guidance systems in public buildings and urban spaces.",
        paragraph2: "Share mapping tools and analytical frameworks to support stakeholders in reception, mobility and visual communication."
      },
      approach: {
        title: "Approach",
        item1: "Extended observation of pedestrian behavior within complex transition zones.",
        item2: "Assessment of the coherence between physical cues, interactive maps and digital signage.",
        item3: "Production of guides and briefs aligned with accessibility and inclusion standards."
      },
      timeline: {
        title: "Key steps",
        milestone1Title: "Exploratory phase",
        milestone1Text: "Qualitative studies of Brussels railway stations highlighting legibility disruptions.",
        milestone2Title: "Method structuring",
        milestone2Text: "Creation of pedestrian flow matrices and analysis templates for administrative buildings.",
        milestone3Title: "Regional outreach",
        milestone3Text: "Support for projects in Ghent, Liège and Namur integrating digital signage.",
        milestone4Title: "International dialogue",
        milestone4Text: "Exchange of insights with European research centers on spatial UX and interactive mapping."
      },
      values: {
        title: "Values",
        card1Title: "Rigour",
        card1Text: "Compare every recommendation with tangible data drawn from prolonged observations.",
        card2Title: "Inclusion",
        card2Text: "Address diverse mobilities and sensory abilities from the earliest design stages.",
        card3Title: "Legibility",
        card3Text: "Clarify how architecture, journeys and information interact to foster autonomy."
      }
    },
    blog: {
      hero: {
        kicker: "Analytical blog",
        title: "Studies and field feedback on indoor navigation.",
        subtitle: "Each post documents Belgian and European cases by linking architecture, digital signage and accessibility."
      },
      listIntro: "Selected readings to deepen your understanding of built environments.",
      cards: {
        post1: {
          title: "Mapping multimodal connections",
          excerpt: "How to orchestrate coherent orientation layers within Belgian interchange hubs."
        },
        post2: {
          title: "Immersive signage across campuses",
          excerpt: "Large campuses require immersive storytelling. Overview of digital and physical solutions."
        },
        post3: {
          title: "Modeling pedestrian flows",
          excerpt: "Build models reflecting micro-decisions and anticipating saturation in public buildings."
        },
        post4: {
          title: "Multisensory accessibility",
          excerpt: "Toward digital signage engaging multiple senses to guide every visitor."
        },
        post5: {
          title: "Temporal journey mapping",
          excerpt: "Study the temporal layer of routes and flows to fine-tune dynamic signage."
        }
      }
    },
    contact: {
      hero: {
        kicker: "Contact",
        title: "Coordinate the reflection around your spaces.",
        subtitle: "Share your orientation, digital signage or pedestrian mobility challenges. We will reply with methodological directions.",
        imageAlt: "Building plan with annotations and circulation cues"
      },
      detailsTitle: "Contact details",
      phoneLabel: "Phone",
      emailLabel: "Email",
      addressLabel: "Address",
      scheduleLabel: "Availability",
      scheduleValue: "Monday to Friday, 9 am - 5 pm CET",
      mapCaption: "Location of danswholesaleplants in Brussels."
    },
    form: {
      title: "Contact form",
      description: "Describe your site context, target audiences and the navigation issues you have identified.",
      nameLabel: "Full name",
      namePlaceholder: "Your name",
      emailLabel: "Email address",
      emailPlaceholder: "name@domain.be",
      organizationLabel: "Organization",
      organizationPlaceholder: "Organization name",
      messageLabel: "Message",
      messagePlaceholder: "Outline context, objectives and constraints.",
      submit: "Send message"
    },
    faq: {
      hero: {
        kicker: "FAQ",
        title: "Frequent questions on indoor navigation.",
        subtitle: "Answers to common queries regarding digital signage, spatial mapping and accessibility."
      },
      items: [
        {
          question: "How do you start assessing a public building?",
          answer: "We begin with mapping existing flows, observing friction points and inventorying current signage."
        },
        {
          question: "Which tools do you use to model circulation?",
          answer: "We combine on-site surveys, anonymized video capture and schematic modeling to simulate different attendance scenarios."
        },
        {
          question: "How are mobility needs addressed?",
          answer: "Each recommendation is aligned with Belgian and European standards, with focus on contrast, tactile cues and alternative routes."
        },
        {
          question: "Do you operate only in Belgium?",
          answer: "Belgian environments are our priority, yet the insights can inform other territories with comparable infrastructures."
        },
        {
          question: "How long does on-site observation take?",
          answer: "Immersion usually lasts two to four weeks depending on spatial complexity and user diversity."
        },
        {
          question: "Do you produce print-ready assets?",
          answer: "We create templates and detailed layouts that can be refined by graphic teams or specialized providers."
        }
      ]
    },
    terms: {
      hero: {
        title: "Terms of Use",
        subtitle: "Legal framework governing access to the danswholesaleplants platform."
      },
      sections: [
        {
          title: "1. Purpose",
          body: "These terms define the rules applicable to the use of content and resources published on danswholesaleplants."
        },
        {
          title: "2. Acceptance",
          body: "Accessing the site implies full acceptance of the terms set forth in this document."
        },
        {
          title: "3. Site access",
          body: "The site is accessible free of charge. The publisher may temporarily suspend access for maintenance."
        },
        {
          title: "4. Intellectual property",
          body: "Content, texts, images, graphics and data remain the property of danswholesaleplants unless stated otherwise."
        },
        {
          title: "5. Content usage",
          body: "Any reproduction or public distribution requires prior written authorization and proper credit."
        },
        {
          title: "6. External sources",
          body: "The site may feature outbound links. danswholesaleplants is not responsible for external content."
        },
        {
          title: "7. Liability",
          body: "The publisher declines any liability for misinterpretation of the information provided."
        },
        {
          title: "8. Security",
          body: "Users are responsible for securing their devices while browsing the site."
        },
        {
          title: "9. Personal data",
          body: "Data collected through the contact form is processed according to the privacy policy."
        },
        {
          title: "10. Cookies",
          body: "Cookies are used for metrics and preference storage, subject to user consent."
        },
        {
          title: "11. Site updates",
          body: "danswholesaleplants may update site content or structure without notice."
        },
        {
          title: "12. Changes to terms",
          body: "These terms may be revised. The latest update date is displayed on the page."
        },
        {
          title: "13. Governing law",
          body: "These terms are governed by Belgian law. Any dispute falls under Brussels courts."
        },
        {
          title: "14. Contact",
          body: "For questions, please reach out through the contact form available on the site."
        }
      ]
    },
    privacy: {
      hero: {
        title: "Privacy Policy",
        subtitle: "Transparency regarding the collection, use and retention of personal data."
      },
      sections: [
        {
          title: "1. Controller",
          body: "The data controller is danswholesaleplants based in Brussels."
        },
        {
          title: "2. Data collected",
          body: "We collect information voluntarily provided via the contact form: name, email, organization and message."
        },
        {
          title: "3. Purpose",
          body: "Data is used solely to respond to messages and document information requests."
        },
        {
          title: "4. Legal basis",
          body: "Processing is based on legitimate interest to follow up on incoming requests."
        },
        {
          title: "5. Retention",
          body: "Data is stored for up to twenty-four months before being anonymized."
        },
        {
          title: "6. Sharing",
          body: "No data is sold or transferred. Technical providers may access information to ensure hosting and maintenance."
        },
        {
          title: "7. Rights",
          body: "You may request access, rectification, deletion, restriction or objection to processing."
        },
        {
          title: "8. Exercising rights",
          body: "Contact us via the form or email address listed in the legal notices to exercise your rights."
        },
        {
          title: "9. Cookies",
          body: "Cookies are handled according to your preferences stored in the consent banner."
        },
        {
          title: "10. Security",
          body: "Technical and organizational safeguards protect data against unauthorized access."
        },
        {
          title: "11. Complaints",
          body: "If needed, you may contact the Belgian Data Protection Authority."
        }
      ]
    },
    cookies: {
      hero: {
        title: "Cookie Policy",
        subtitle: "Details about cookies used and how to manage your preferences."
      },
      intro: "This site uses cookies to improve navigation and measure audience metrics. You can adjust your choices at any time through the consent banner.",
      tableHeaders: {
        name: "Cookie name",
        provider: "Provider",
        type: "Type",
        purpose: "Purpose",
        duration: "Duration"
      },
      rows: [
        {
          name: "cookie_consent",
          provider: "danswholesaleplants",
          type: "Necessary",
          purpose: "Store your cookie choices.",
          duration: "12 months"
        },
        {
          name: "site_lang",
          provider: "danswholesaleplants",
          type: "Preferences",
          purpose: "Remember your language selection across the site.",
          duration: "12 months"
        },
        {
          name: "analytics_view",
          provider: "danswholesaleplants",
          type: "Analytics",
          purpose: "Track visited pages to improve content structure.",
          duration: "13 months"
        },
        {
          name: "campaign_context",
          provider: "danswholesaleplants",
          type: "Marketing",
          purpose: "Measure how shared content performs on external channels.",
          duration: "6 months"
        }
      ],
      preferences: {
        necessaryTitle: "Necessary cookies",
        necessaryHint: "Always active because they are essential for the site to operate.",
        preferencesTitle: "Preference cookies",
        preferencesHint: "Store display choices, including language.",
        analyticsTitle: "Analytics cookies",
        analyticsHint: "Measure audience to improve content structure.",
        marketingTitle: "Marketing cookies",
        marketingHint: "Monitor interactions with external communication supports."
      },
      banner: {
        title: "Cookie management",
        description: "We use cookies to run the site properly and analyze its usage. You may customize your choices.",
        link: "Learn more",
        accept: "Accept all",
        decline: "Decline all",
        save: "Save preferences"
      }
    },
    refund: {
      hero: {
        title: "Revision Policy",
        subtitle: "Procedures for adjusting analytical and mapping deliverables."
      },
      sections: [
        {
          title: "1. Scope",
          body: "This policy applies to analytical documents, maps and methodological briefs issued by danswholesaleplants."
        },
        {
          title: "2. Correction requests",
          body: "Requests must be submitted in writing through the contact form within thirty days."
        },
        {
          title: "3. Review process",
          body: "Each request is evaluated to determine whether it involves factual updates or broader methodological work."
        },
        {
          title: "4. Minor edits",
          body: "Minor edits (terminology, spelling, data precision) are integrated within a reasonable timeframe."
        },
        {
          title: "5. Major revisions",
          body: "Revisions requiring new measurement campaigns or observations are reviewed on a case-by-case basis."
        },
        {
          title: "6. Limitations",
          body: "Revisions do not cover improper use or external interpretations of provided documents."
        },
        {
          title: "7. Delivery formats",
          body: "Updates are shared in the same format as the initial version unless otherwise agreed."
        },
        {
          title: "8. Notification",
          body: "Users are notified by email when the revised version becomes available."
        },
        {
          title: "9. Archiving",
          body: "Original versions are archived to maintain a history of changes."
        },
        {
          title: "10. Contact",
          body: "For clarification, please reach out through the contact page and mention the document reference."
        }
      ]
    },
    disclaimer: {
      hero: {
        title: "Disclaimer",
        subtitle: "Liability limits regarding published content."
      },
      sections: [
        {
          title: "General information",
          body: "The content aims to share insights about spatial orientation practices. It is not an exhaustive recommendation."
        },
        {
          title: "No guarantee",
          body: "danswholesaleplants does not guarantee the absence of errors or the completeness of the information provided."
        },
        {
          title: "Data usage",
          body: "Users remain responsible for how they apply the information and insights shared."
        },
        {
          title: "Specific contexts",
          body: "Outcomes may vary depending on the particular characteristics of each built environment or territory."
        },
        {
          title: "External links",
          body: "Links to third-party resources do not imply endorsement of their content."
        },
        {
          title: "Updates",
          body: "Information may be updated without notice to reflect evolving research and observations."
        }
      ]
    },
    thankyou: {
      title: "Thank you for your message.",
      paragraph: "We have received your inquiry and will reply with additional insights on spatial orientation or digital signage."
    },
    posts: {
      post1: {
        metadata: "Published 15 February 2024 • Transport hubs",
        title: "Mapping multimodal interchanges within Belgian transport hubs",
        intro: "Belgian train and metro stations combine rail, bus, tram and urban services. The multitude of connections requires routes to be instantly readable without overwhelming visitors.",
        section1Title: "Layered mapping of levels",
        section1Paragraph1: "The analysis starts by overlaying basement, mezzanine and surface plans. Each layer shares a consistent color code across physical and digital supports. This approach reduces gaps between dynamic maps viewed on mobile devices and directional panels on site.",
        section1Paragraph2: "Trail-critical transfers are identified using real-time measurements: distance walked, average travel time, waiting points. By crossing these indicators with inbound and outbound flows we reconstruct micro-decisions made when facing successive bifurcations.",
        section2Title: "Digital signage anchored by cues",
        section2Paragraph1: "Digital devices do not replace static signage; they enhance it. We observed that dedicated transfer screens must appear before decision zones. Late displays trigger backtracking and increase density. Physical cues such as material contrasts and dedicated lighting help visitors memorize the route.",
        section2Paragraph2: "Special attention is paid to international passengers who need support to interpret local codes. Short multi-language messages broadcast on interactive maps and synchronized audio signage prevent discrepancies.",
        section3Title: "Experiments and lessons",
        section3Paragraph1: "Testing at Brussels-Central, Liège-Guillemins and Antwerp-Central highlighted the need to clearly articulate final destinations and intermediary services: restrooms, lockers, information desks. Experimental routes show that displaying estimated time to reach the platform reduces user anxiety.",
        section3Paragraph2: "Deploying adaptive maps capable of highlighting temporarily closed zones ensures coherence. Staff must access simple tools to update information. A central dashboard broadcasting changes across every support avoids inconsistencies.",
        conclusionTitle: "Toward readable transfers",
        conclusionParagraph: "Successful transfers rely on a stable graphic language, on synergy between digital and physical supports, and on anticipatory flow management. Belgian hubs applying this approach report fewer assistance requests and more homogeneous circulation."
      },
      post2: {
        metadata: "Published 4 March 2024 • University campuses",
        title: "Designing immersive signage for expansive campuses",
        intro: "Campuses spread over several hectares mix historic buildings, contemporary extensions and public spaces. Students and visitors alternate between indoor and outdoor segments, demanding continuous spatial storytelling.",
        section1Title: "Continuous spatial storytelling",
        section1Paragraph1: "Immersive signage integrates graphic, audio and interactive elements. Routes are divided into chapters, each clearly announced. Digital maps embedded in touch kiosks reuse the graphic grammar of printed plans to avoid visual breaks.",
        section1Paragraph2: "Landmarks such as remarkable trees or art pieces become narrative anchors. Visitors maintain orientation even when leaving a building to cross a plaza.",
        section2Title: "Interactive maps and participation",
        section2Paragraph1: "User experience improves when interactive maps let people tailor routes according to mobility, time and accessibility preferences. Students with disabilities pointed out the value of precise information regarding elevators, ramps and automated doors.",
        section2Paragraph2: "Co-design sessions with facility teams and student associations strengthen message relevance. Feedback gathered during participatory mapping workshops feeds continuous updates.",
        section3Title: "Performance indicators",
        section3Paragraph1: "Mapped campuses now monitor indicators: average time to reach lecture halls, information desk requests, newcomer satisfaction. These metrics inform the ongoing adjustment of supports.",
        section3Paragraph2: "Maintaining a centralized data backbone ensures consistency across brochures, mobile apps, LED panels and temporary signage for events.",
        conclusionTitle: "Managed immersion",
        conclusionParagraph: "Immersive signage blends sensory cues with modular digital tools. By guaranteeing graphic coherence and user participation, Belgian campuses foster smooth navigation."
      },
      post3: {
        metadata: "Published 28 March 2024 • Administrative buildings",
        title: "Modeling pedestrian flows to anticipate density hotspots",
        intro: "Administrative buildings host varied flows: employees, visitors, contractors. Peak attendance occurs during opening hours and events. Understanding these flows is essential to size signage properly.",
        section1Title: "Multi-scale observation",
        section1Paragraph1: "Initial observations track preferred routes, stopping durations and crossing density. Resulting diagrams pinpoint spontaneous waiting areas where information should be reinforced.",
        section1Paragraph2: "Anonymized sensors complement human observation by measuring speed and density. Data feeds models that simulate the impact of architectural or informational changes.",
        section2Title: "Decision matrices",
        section2Paragraph1: "Each internal junction is considered a decision point. We rate signage quality, elevator visibility, color-code coherence. A matrix summarizes priority improvements.",
        section2Paragraph2: "Distinguishing the needs of occasional visitors and regular staff is crucial. Visitors require redundancy, whereas staff benefit from quicker digital notifications.",
        section3Title: "Functional guidance",
        section3Paragraph1: "Recommendations address direction hierarchy, volumetric landmarks and screen placement at critical points. Evacuation scenarios are also reviewed to keep routes legible in degraded situations.",
        section3Paragraph2: "Results show that coherent signage cuts average detours by 18% and improves perceived accessibility. Users locate service areas and meeting rooms faster.",
        conclusionTitle: "Plan ahead for fluidity",
        conclusionParagraph: "Pedestrian flow modeling is a practical tool shaping the placement of cues and interactive maps. Belgian organizations using it as a management asset gain clarity and efficiency."
      },
      post4: {
        metadata: "Published 11 April 2024 • Accessibility",
        title: "Toward multisensory accessibility of indoor routes",
        intro: "Built environments must serve every user profile. Combining visual, tactile and auditory cues strengthens autonomy for people with disabilities.",
        section1Title: "Combining cues and technology",
        section1Paragraph1: "Relief maps, tactile paving and high-contrast pictograms form the baseline. Digital devices supplement them with contextual audio triggered by beacons.",
        section1Paragraph2: "Tests conducted in Belgian museums show that aligning audio messages with physical signage reduces route interruptions and backtracking.",
        section2Title: "Adapting digital supports",
        section2Paragraph1: "Interactive screens need high-contrast modes, physical controls and screen-reading features. Accessible QR codes deliver personalized guidance to smartphones.",
        section2Paragraph2: "User experience also depends on trained staff and regular maintenance. A blank screen or silent beacon disrupts continuity.",
        section3Title: "Participatory evaluation",
        section3Paragraph1: "Assessments involve associations representing different disabilities. Their feedback ensures adaptations address concrete needs rather than mere compliance.",
        section3Paragraph2: "Indicators include time to reach key areas, help requests and perceived satisfaction. Leading sites update digital plans after every measurement campaign.",
        conclusionTitle: "Active accessibility",
        conclusionParagraph: "Multisensory accessibility requires ongoing commitment: align signage, test with users, maintain equipment. This is essential to offer reliable navigation to everyone."
      },
      post5: {
        metadata: "Published 2 May 2024 • Temporal journeys",
        title: "Temporal mapping of user journeys",
        intro: "Static maps no longer capture the full experience. Integrating the temporal dimension helps align signage with rhythms and events.",
        section1Title: "Measuring temporal layers",
        section1Paragraph1: "Surveys measure time spent on each route segment and note variations throughout the day. Data feeds maps highlighting hourly density.",
        section1Paragraph2: "Dynamic visualizations reveal areas requiring reinforced information during peaks. They help teams anticipate queues and saturation.",
        section2Title: "Dynamic signage",
        section2Paragraph1: "Screens and interactive maps adapt their messages to time: proposing alternate routes when density exceeds thresholds, suggesting secondary entrances during events.",
        section2Paragraph2: "Opt-in notifications sent to users complement on-site information, sharing access times and temporarily congested zones.",
        section3Title: "Steering and feedback",
        section3Paragraph1: "Managers monitor dashboards combining attendance and qualitative feedback. They test variants and measure impact on fluidity.",
        section3Paragraph2: "Temporal data feeds master plans: positioning of reception points, sizing of spaces, tuning of opening hours.",
        conclusionTitle: "Time and space",
        conclusionParagraph: "Adding the temporal variable transforms signage strategies. Belgian sites embracing it observe better flow distribution and greater visitor satisfaction."
      }
    },
    banner: {
      title: "Cookie management",
      description: "We use cookies to keep the site running smoothly and analyze its usage. You can customize your choices.",
      link: "Learn more",
      accept: "Accept all",
      decline: "Decline all",
      save: "Save preferences",
      necessary: "Necessary cookies",
      preferences: "Preference cookies",
      analytics: "Analytics cookies",
      marketing: "Marketing cookies"
    },
    map: {
      label: "Map showing danswholesaleplants location in Brussels."
    },
    thankyoupage: {
      message: "Thank you for your message. We will contact you shortly."
    }
  }
};

function getTranslation(lang, key) {
  const segments = key.split(".");
  let value = I18N[lang];
  for (const segment of segments) {
    if (value && Object.prototype.hasOwnProperty.call(value, segment)) {
      value = value[segment];
    } else {
      return null;
    }
  }
  return typeof value === "string" ? value : null;
}

function translatePage(lang) {
  const translations = I18N[lang] ? I18N[lang] : I18N[DEFAULT_LANG];
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach((element) => {
    const key = element.getAttribute("data-i18n");
    const text = getTranslation(lang, key);
    if (text !== null) {
      element.innerHTML = text.replace("{{year}}", new Date().getFullYear());
    }
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((element) => {
    const key = element.getAttribute("data-i18n-placeholder");
    const text = getTranslation(lang, key);
    if (text !== null) {
      element.setAttribute("placeholder", text);
    }
  });
  document.querySelectorAll("[data-i18n-alt]").forEach((element) => {
    const key = element.getAttribute("data-i18n-alt");
    const text = getTranslation(lang, key);
    if (text !== null) {
      element.setAttribute("alt", text);
    }
  });
  document.querySelectorAll("[data-i18n-aria]").forEach((element) => {
    const key = element.getAttribute("data-i18n-aria");
    const text = getTranslation(lang, key);
    if (text !== null) {
      element.setAttribute("aria-label", text);
    }
  });
  document.querySelectorAll("[data-i18n-title]").forEach((element) => {
    const key = element.getAttribute("data-i18n-title");
    const text = getTranslation(lang, key);
    if (text !== null) {
      element.textContent = text;
    }
  });
  document.querySelectorAll("[data-i18n-meta]").forEach((element) => {
    const key = element.getAttribute("data-i18n-meta");
    const text = getTranslation(lang, key);
    if (text !== null) {
      element.setAttribute("content", text);
    }
  });
  updateLanguageButtons(lang);
}

function updateLanguageButtons(currentLang) {
  document.querySelectorAll(".language-btn").forEach((btn) => {
    const lang = btn.getAttribute("data-lang");
    if (lang === currentLang) {
      btn.classList.add("is-active");
      btn.setAttribute("aria-pressed", "true");
    } else {
      btn.classList.remove("is-active");
      btn.setAttribute("aria-pressed", "false");
    }
  });
}

function setLanguage(lang) {
  const selected = I18N[lang] ? lang : DEFAULT_LANG;
  localStorage.setItem(STORAGE_LANG_KEY, selected);
  translatePage(selected);
}

function initLanguage() {
  const stored = localStorage.getItem(STORAGE_LANG_KEY);
  const lang = stored && I18N[stored] ? stored : DEFAULT_LANG;
  translatePage(lang);
}

function initNavigation() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  if (!toggle || !nav) return;
  toggle.addEventListener("click", () => {
    nav.classList.toggle("is-open");
    const expanded = nav.classList.contains("is-open");
    toggle.setAttribute("aria-expanded", expanded ? "true" : "false");
  });
  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      nav.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
    });
  });
}

function initLanguageToggle() {
  document.querySelectorAll(".language-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const lang = button.getAttribute("data-lang");
      setLanguage(lang);
    });
  });
}

function initScrollAnimations() {
  const animated = document.querySelectorAll(".animate-on-scroll");
  if (!("IntersectionObserver" in window)) {
    animated.forEach((el) => el.classList.add("in-view"));
    return;
  }
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.18 }
  );
  animated.forEach((el) => observer.observe(el));
}

function showToast(message, type = "success") {
  const toast = document.getElementById("toast");
  if (!toast) return;
  toast.textContent = message;
  toast.className = "toast";
  toast.classList.add("is-visible");
  toast.classList.add(type === "error" ? "toast-error" : "toast-success");
  setTimeout(() => {
    toast.classList.remove("is-visible");
  }, 3800);
}

function initContactForm() {
  const form = document.querySelector("[data-contact-form]");
  if (!form) return;
  form.addEventListener("submit", (event) => {
    const lang = localStorage.getItem(STORAGE_LANG_KEY) || DEFAULT_LANG;
    const requiredMessage = getTranslation(lang, "validation.required");
    const emailMessage = getTranslation(lang, "validation.email");
    const name = form.querySelector("[name='name']");
    const email = form.querySelector("[name='email']");
    const message = form.querySelector("[name='message']");
    if (!name.value.trim() || !email.value.trim() || !message.value.trim()) {
      event.preventDefault();
      showToast(requiredMessage, "error");
      return;
    }
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email.value.trim())) {
      event.preventDefault();
      showToast(emailMessage, "error");
      return;
    }
    const successMessage = getTranslation(lang, "toast.success");
    showToast(successMessage, "success");
  });
}

function loadCookieState() {
  try {
    const stored = localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!stored) return null;
    return JSON.parse(stored);
  } catch (error) {
    return null;
  }
}

function saveCookieState(state) {
  try {
    localStorage.setItem(COOKIE_STORAGE_KEY, JSON.stringify(state));
  } catch (error) {
    console.error("Cookie state could not be saved", error);
  }
}

function updateCookieBannerUI(state) {
  const preferencesToggle = document.getElementById("cookiePreferences");
  const analyticsToggle = document.getElementById("cookieAnalytics");
  const marketingToggle = document.getElementById("cookieMarketing");
  if (state) {
    if (preferencesToggle) preferencesToggle.checked = !!state.preferences;
    if (analyticsToggle) analyticsToggle.checked = !!state.analytics;
    if (marketingToggle) marketingToggle.checked = !!state.marketing;
  }
}

function acceptAllCookies() {
  const state = {
    necessary: true,
    preferences: true,
    analytics: true,
    marketing: true,
    decidedAt: new Date().toISOString()
  };
  saveCookieState(state);
  hideCookieBanner();
}

function declineAllCookies() {
  const state = {
    necessary: true,
    preferences: false,
    analytics: false,
    marketing: false,
    decidedAt: new Date().toISOString()
  };
  saveCookieState(state);
  hideCookieBanner();
}

function saveCookiePreferences() {
  const preferencesToggle = document.getElementById("cookiePreferences");
  const analyticsToggle = document.getElementById("cookieAnalytics");
  const marketingToggle = document.getElementById("cookieMarketing");
  const state = {
    necessary: true,
    preferences: preferencesToggle ? preferencesToggle.checked : false,
    analytics: analyticsToggle ? analyticsToggle.checked : false,
    marketing: marketingToggle ? marketingToggle.checked : false,
    decidedAt: new Date().toISOString()
  };
  saveCookieState(state);
  hideCookieBanner();
}

function hideCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  if (banner) {
    banner.classList.remove("is-visible");
  }
}

function showCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  if (banner) {
    banner.classList.add("is-visible");
  }
}

function initCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  if (!banner) return;
  const lang = localStorage.getItem(STORAGE_LANG_KEY) || DEFAULT_LANG;
  const consent = loadCookieState();
  if (!consent) {
    translatePage(lang);
    showCookieBanner();
  } else {
    updateCookieBannerUI(consent);
  }
  const acceptButton = document.querySelector("[data-cookie-accept]");
  const declineButton = document.querySelector("[data-cookie-decline]");
  const saveButton = document.querySelector("[data-cookie-save]");
  acceptButton?.addEventListener("click", acceptAllCookies);
  declineButton?.addEventListener("click", declineAllCookies);
  saveButton?.addEventListener("click", () => {
    saveCookiePreferences();
    const language = localStorage.getItem(STORAGE_LANG_KEY) || DEFAULT_LANG;
    showToast(getTranslation(language, "toast.success"), "success");
  });
}

function initLanguageObserver() {
  const langSwitchObserver = new MutationObserver(() => {
    const lang = document.documentElement.lang || DEFAULT_LANG;
    translatePage(lang);
  });
  langSwitchObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["lang"] });
}

document.addEventListener("DOMContentLoaded", () => {
  initLanguage();
  initLanguageToggle();
  initNavigation();
  initScrollAnimations();
  initContactForm();
  initCookieBanner();
  initLanguageObserver();
  const storedLang = localStorage.getItem(STORAGE_LANG_KEY) || DEFAULT_LANG;
  translatePage(storedLang);
});

window.addEventListener("load", () => {
  const consent = loadCookieState();
  if (consent) {
    updateCookieBannerUI(consent);
  }
});