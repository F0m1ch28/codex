"use strict";

document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");
    const navLinks = document.querySelectorAll(".nav-link");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const isOpen = navMenu.classList.toggle("is-open");
            navToggle.classList.toggle("is-open", isOpen);
            navToggle.setAttribute("aria-expanded", String(isOpen));
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (navMenu.classList.contains("is-open")) {
                    navMenu.classList.remove("is-open");
                    navToggle.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });

        window.addEventListener("resize", () => {
            if (window.innerWidth >= 768) {
                navMenu.classList.remove("is-open");
                navToggle.classList.remove("is-open");
                navToggle.setAttribute("aria-expanded", "false");
            }
        });
    }

    const cookieBanner = document.getElementById("cookieBanner");
    const cookieButtons = document.querySelectorAll(".cookie-btn");
    const storageKey = "nogoarohjx_cookie_pref";

    if (cookieBanner) {
        const existingPreference = localStorage.getItem(storageKey);
        if (existingPreference) {
            cookieBanner.classList.add("hidden");
        } else {
            cookieBanner.classList.add("active");
        }

        cookieButtons.forEach((button) => {
            button.addEventListener("click", (event) => {
                event.preventDefault();
                const choice = button.dataset.choice || "accept";
                localStorage.setItem(storageKey, choice);
                cookieBanner.classList.remove("active");
                cookieBanner.classList.add("hidden");
                const policyUrl = button.getAttribute("href") || "cookies.html";
                window.open(`${policyUrl}#${choice}`, "_blank", "noopener");
            });
        });
    }
});