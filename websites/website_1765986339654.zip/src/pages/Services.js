import React from 'react';
import Meta from '../components/Meta';
import styles from './Services.module.css';

const programs = [
  {
    title: 'Ruta Integral de Liderazgo Adaptativo',
    description:
      'Programa basado en IA que analiza el contexto de cada líder y sugiere micro-retos, escenarios y mentorías personalizadas para dirigir equipos híbridos.',
    outcomes: [
      'Desarrollar competencias de liderazgo situacional con data accionable.',
      'Dominar herramientas de colaboración inteligente y toma de decisiones aumentada.',
      'Multiplicar la capacidad de inspirar equipos distribuidos con claridad y empatía.'
    ]
  },
  {
    title: 'Academia de Analítica Aplicada',
    description:
      'Trayectoria modular para transformar datos en decisiones estratégicas. Ideal para áreas de operaciones, logística y finanzas.',
    outcomes: [
      'Integrar modelos predictivos en procesos clave.',
      'Automatizar reportes con dashboards personalizados.',
      'Crear cultura data-driven con sesiones guiadas por expertos.'
    ]
  },
  {
    title: 'Certificación en Experiencias Blended',
    description:
      'Entrenamiento para equipos de talento y formación que buscan crear programas híbridos de alto engagement aprovechando IA y aprendizaje social.',
    outcomes: [
      'Diseñar itinerarios blended con evaluación continua.',
      'Implementar analítica de aprendizaje para medir impacto.',
      'Optimizar la facilitación con recursos digitales inteligentes.'
    ]
  },
  {
    title: 'Plan Ejecutivo de Transformación Digital',
    description:
      'Experiencia intensiva para directivos con cápsulas estratégicas, simulaciones y acompañamiento experto, habilitando decisiones ágiles frente a la disrupción tecnológica.',
    outcomes: [
      'Detectar oportunidades digitales alineadas al negocio.',
      'Aplicar marcos de innovación orientados a resultados.',
      'Fomentar cultura ágil y colaboración interdepartamental.'
    ]
  }
];

const Services = () => {
  return (
    <div className={styles.services}>
      <Meta
        title="Programas | Valentor Amicado"
        description="Descubre los programas de Valentor Amicado para impulsar el aprendizaje de adultos: liderazgo adaptativo, analítica aplicada, experiencias blended y más."
        keywords="programas de capacitación, liderazgo adaptativo, analítica aplicada, formación blended, Valentor Amicado"
        canonical="https://valentoramicado.site/programas"
      />

      <section className={styles.hero}>
        <div className="container">
          <h1>Portafolio de Programas Inteligentes</h1>
          <p>
            Diseñamos experiencias que combinan data, mentoring y práctica situada para que cada equipo
            fortalezca habilidades críticas y alcance metas estratégicas.
          </p>
        </div>
      </section>

      <section className={styles.programsSection}>
        <div className="container">
          <div className={styles.programsGrid}>
            {programs.map((program) => (
              <article key={program.title} className={styles.programCard}>
                <h2>{program.title}</h2>
                <p>{program.description}</p>
                <ul className={styles.outcomes}>
                  {program.outcomes.map((outcome) => (
                    <li key={outcome}>{outcome}</li>
                  ))}
                </ul>
                <div className={styles.tags}>
                  <span>Duración flexible</span>
                  <span>Mentores certificados</span>
                  <span>Evaluación continua</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.supportSection}>
        <div className="container">
          <div className={styles.supportCard}>
            <h2>Personalizamos cada experiencia para tu contexto</h2>
            <p>
              Adaptamos objetivos, herramientas y métricas a la realidad de tu organización. Nuestro equipo
              de learning designers crea trayectorias exclusivas, respaldadas por insights de IA.
            </p>
            <a className={styles.contactLink} href="/contacto">
              Hablemos de tu reto →
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;