import React from 'react';
import Meta from '../components/Meta';
import styles from './PrivacyPolicy.module.css';

const PrivacyPolicy = () => {
  return (
    <div className={styles.privacy}>
      <Meta
        title="Política de Privacidad | Valentor Amicado"
        description="Conoce cómo Valentor Amicado protege y gestiona los datos personales de sus usuarios."
        keywords="política de privacidad Valentor Amicado"
        canonical="https://valentoramicado.site/privacidad"
      />
      <section className={styles.section}>
        <div className="container">
          <h1>Política de Privacidad</h1>
          <p>Fecha de última actualización: enero 2024</p>

          <h2>1. Responsable del tratamiento</h2>
          <p>
            Valentor Amicado, con domicilio en Av. Insurgentes Sur 1234, Col. Del Valle, Benito Juárez,
            03100 Ciudad de México, CDMX, México, es responsable del tratamiento de los datos personales recopilados.
          </p>

          <h2>2. Datos que recopilamos</h2>
          <p>
            Obtenemos datos de contacto, información profesional y preferencias de aprendizaje cuando el usuario
            completa formularios o interactúa con nuestros contenidos digitales.
          </p>

          <h2>3. Finalidades</h2>
          <p>
            Utilizamos los datos para ofrecer información sobre nuestros programas, gestionar solicitudes,
            personalizar experiencias educativas y enviar comunicaciones relacionadas con nuestros servicios.
          </p>

          <h2>4. Transferencias</h2>
          <p>
            No compartimos datos personales con terceros ajenos a Valentor Amicado, salvo requerimiento legal
            o consentimiento expreso del titular.
          </p>

          <h2>5. Derechos ARCO</h2>
          <p>
            Puedes ejercer tus derechos de acceso, rectificación, cancelación y oposición enviando un correo a{' '}
            <a href="mailto:hola@valentoramicado.site">hola@valentoramicado.site</a>. Atenderemos tu solicitud en los
            plazos establecidos por la ley.
          </p>

          <h2>6. Medidas de seguridad</h2>
          <p>
            Implementamos medidas técnicas y administrativas para proteger tus datos contra accesos no autorizados,
            pérdida o alteración.
          </p>

          <h2>7. Conservación</h2>
          <p>
            Conservamos la información durante el tiempo necesario para cumplir las finalidades descritas o según
            disposiciones legales aplicables.
          </p>

          <h2>8. Actualizaciones</h2>
          <p>
            Esta Política puede actualizarse periódicamente. Te recomendamos revisarla con regularidad para
            mantenerte informado de cualquier cambio.
          </p>
        </div>
      </section>
    </div>
  );
};

export default PrivacyPolicy;