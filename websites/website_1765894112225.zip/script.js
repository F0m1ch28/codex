document.addEventListener("DOMContentLoaded", function () {
  const banner = document.querySelector("[data-cookie-banner]");
  const acceptBtn = document.querySelector("[data-cookie-accept]");
  const declineBtn = document.querySelector("[data-cookie-decline]");
  const consentKey = "dotConsent";

  if (banner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      requestAnimationFrame(() => {
        banner.classList.add("is-visible");
        banner.setAttribute("aria-hidden", "false");
      });
    }

    function closeBanner(value) {
      localStorage.setItem(consentKey, value);
      banner.classList.remove("is-visible");
      banner.setAttribute("aria-hidden", "true");
    }

    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => closeBanner("accepted"));
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => closeBanner("declined"));
    }
  }

  const paceControl = document.querySelector("[data-pace-control]");
  const paceValue = document.querySelector("[data-pace-value]");
  const meditationSpace = document.querySelector("[data-meditation-space]");
  const meditationDot = document.querySelector("[data-meditation-dot]");

  if (paceControl && paceValue && meditationDot) {
    const root = document.documentElement;

    function updatePace(value) {
      const seconds = Number(value);
      root.style.setProperty("--pulse-duration", `${seconds}s`);
      paceValue.textContent = seconds.toFixed(1);
    }

    updatePace(paceControl.value);

    paceControl.addEventListener("input", (event) => {
      updatePace(event.target.value);
    });
  }

  if (meditationSpace && meditationDot) {
    const defaultPosition = { x: 50, y: 50 };
    let active = false;

    function setDotPosition(xPercent, yPercent) {
      meditationDot.style.transform = `translate(-50%, -50%) translate(${xPercent - 50}%, ${yPercent - 50}%)`;
    }

    setDotPosition(defaultPosition.x, defaultPosition.y);

    meditationSpace.addEventListener("pointerenter", () => {
      active = true;
      meditationSpace.setAttribute("data-active", "true");
    });

    meditationSpace.addEventListener("pointerleave", () => {
      active = false;
      meditationSpace.setAttribute("data-active", "false");
      setDotPosition(defaultPosition.x, defaultPosition.y);
    });

    meditationSpace.addEventListener("pointermove", (event) => {
      if (!active) return;
      const rect = meditationSpace.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width) * 100;
      const y = ((event.clientY - rect.top) / rect.height) * 100;
      const clampedX = Math.min(80, Math.max(20, x));
      const clampedY = Math.min(80, Math.max(20, y));
      setDotPosition(clampedX, clampedY);
    });
  }
});