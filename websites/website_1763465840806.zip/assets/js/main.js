document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            siteNav.classList.toggle('open');
        });
    }

    const navLinks = document.querySelectorAll('.site-nav a, .footer-links a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (siteNav) {
                siteNav.classList.remove('open');
            }
            if (navToggle) {
                navToggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, left: 0 });
        });
    });

    const scrollBtn = document.getElementById('scrollTopBtn');
    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 320) {
                scrollBtn.classList.add('visible');
            } else {
                scrollBtn.classList.remove('visible');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookies = document.getElementById('acceptCookies');
    if (cookieBanner && acceptCookies) {
        const consent = localStorage.getItem('candataCookieConsent');
        if (consent === 'accepted') {
            cookieBanner.classList.add('hidden');
        } else {
            cookieBanner.classList.remove('hidden');
        }

        acceptCookies.addEventListener('click', () => {
            localStorage.setItem('candataCookieConsent', 'accepted');
            cookieBanner.classList.add('hidden');
        });
    }

    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            const response = document.getElementById('formResponse');
            if (response) {
                response.textContent = 'Thank you for reaching out. A CanData Intelligence advisor will connect with you shortly.';
            }
            contactForm.reset();
        });
    }

    const yearElementList = document.querySelectorAll('#currentYear');
    const currentYear = new Date().getFullYear();
    yearElementList.forEach(el => {
        el.textContent = currentYear;
    });
});