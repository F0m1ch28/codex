import React from 'react';
import { Link } from 'react-router-dom';
import styles from '../styles/Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className={styles.footer}>
      <div className={styles.top}>
        <div className={styles.brandBlock}>
          <p className={styles.logo}>Bravino<span className={styles.brandAccent}>Tera</span>Luna</p>
          <p className={styles.description}>
            Fortalecemos la resiliencia digital de México con acompañamiento cercano, recursos claros
            y una comunidad consciente de los riesgos en línea.
          </p>
        </div>
        <div className={styles.columns}>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Explora</h3>
            <ul className={styles.linkList}>
              <li><Link to="/guide" className={styles.link}>Centro de guías</Link></li>
              <li><Link to="/programs" className={styles.link}>Programas</Link></li>
              <li><Link to="/tools" className={styles.link}>Herramientas</Link></li>
              <li><Link to="/blog" className={styles.link}>Blog</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Institucional</h3>
            <ul className={styles.linkList}>
              <li><Link to="/about" className={styles.link}>Sobre nosotros</Link></li>
              <li><Link to="/contact" className={styles.link}>Contacto</Link></li>
              <li><Link to="/legal" className={styles.link}>Información legal</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Contacto</h3>
            <ul className={styles.linkList}>
              <li>[Dirección en México]</li>
              <li><a href="tel:+52XXXXXXXXXX" className={styles.link}>+52 XX XXXX XXXX</a></li>
              <li><a href="mailto:contacto@bravinoteraluna.site" className={styles.link}>contacto@bravinoteraluna.site</a></li>
            </ul>
            <div className={styles.socialGroup} aria-label="Redes sociales">
              <a className={styles.socialLink} href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
                <span aria-hidden="true">in</span>
              </a>
              <a className={styles.socialLink} href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
                <span aria-hidden="true">▶</span>
              </a>
              <a className={styles.socialLink} href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
                <span aria-hidden="true">X</span>
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {currentYear} BravinoTeraLuna. Todos los derechos reservados.</p>
        <div className={styles.bottomLinks}>
          <Link to="/legal/privacidad" className={styles.link}>Privacidad</Link>
          <Link to="/legal/terminos" className={styles.link}>Términos</Link>
          <Link to="/legal/cookies" className={styles.link}>Cookies</Link>
        </div>
      </div>
    </footer>
  );
};

export default Footer;