import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from '../styles/CookieBanner.module.css';

const COOKIE_KEY = 'bravino-cookie-consent';

const CookieConsentBanner = () => {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    try {
      const storedValue = localStorage.getItem(COOKIE_KEY);
      if (!storedValue) {
        setIsOpen(true);
      }
    } catch (error) {
      setIsOpen(true);
    }
  }, []);

  const handleAccept = () => {
    try {
      localStorage.setItem(COOKIE_KEY, 'accepted');
    } catch (error) {
      // eslint-disable-next-line no-console
      console.warn('No se pudo guardar la preferencia de cookies.');
    }
    setIsOpen(false);
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Aviso de cookies">
      <div className={styles.content}>
        <p>
          Utilizamos cookies para mejorar tu experiencia y analizar el uso del sitio. Consulta nuestra{' '}
          <Link to="/legal/cookies" className={styles.link}>política de cookies</Link>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.acceptButton} onClick={handleAccept}>
          Aceptar
        </button>
      </div>
    </div>
  );
};

export default CookieConsentBanner;