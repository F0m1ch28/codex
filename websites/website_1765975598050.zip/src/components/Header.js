import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from '../styles/Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} onClick={closeMenu}>
          Bravino<span className={styles.brandAccent}>Tera</span>Luna
        </Link>
        <button
          type="button"
          className={styles.mobileToggle}
          aria-controls="menu-principal"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span className={styles.toggleLine} />
          <span className={styles.toggleLine} />
          <span className={styles.toggleLine} />
          <span className="sr-only">Alternar navegación</span>
        </button>
        <nav className={styles.nav} aria-label="Menú principal">
          <ul
            id="menu-principal"
            className={`${styles.navList} ${menuOpen ? styles.navListOpen : ''}`}
          >
            <li className={styles.navItem}>
              <NavLink
                to="/"
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.active : ''}`
                }
                onClick={closeMenu}
              >
                Inicio
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/guide"
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.active : ''}`
                }
                onClick={closeMenu}
              >
                Guías
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/programs"
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.active : ''}`
                }
                onClick={closeMenu}
              >
                Programas
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/tools"
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.active : ''}`
                }
                onClick={closeMenu}
              >
                Herramientas
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/blog"
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.active : ''}`
                }
                onClick={closeMenu}
              >
                Blog
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/about"
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.active : ''}`
                }
                onClick={closeMenu}
              >
                Sobre nosotros
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <Link to="/contact" className={styles.ctaButton} onClick={closeMenu}>
                Contacto
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;