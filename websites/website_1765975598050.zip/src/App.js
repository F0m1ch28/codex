import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieConsentBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ContactPage from './pages/Contact';
import PrivacyPolicyPage from './pages/PrivacyPolicy';
import TermsConditionsPage, { LegalPage, CookiePolicyPage } from './pages/TermsOfService';
import { GuidePage, ProgramsPage, ToolsPage, BlogPage } from './pages/Services';

const App = () => (
  <>
    <Helmet>
      <html lang="es" />
      <title>BravinoTeraLuna | Seguridad digital con sentido humano</title>
      <meta
        name="description"
        content="BravinoTeraLuna impulsa la cultura de seguridad digital en México con guías, programas formativos, herramientas y acompañamiento experto."
      />
    </Helmet>
    <a className="skipLink" href="#contenido-principal">
      Saltar al contenido principal
    </a>
    <div className="appShell">
      <Header />
      <main id="contenido-principal" className="mainContent">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/guide" element={<GuidePage />} />
          <Route path="/programs" element={<ProgramsPage />} />
          <Route path="/tools" element={<ToolsPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/legal" element={<LegalPage />} />
          <Route path="/legal/privacidad" element={<PrivacyPolicyPage />} />
          <Route path="/legal/terminos" element={<TermsConditionsPage />} />
          <Route path="/legal/cookies" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieConsentBanner />
      <ScrollToTopButton />
    </div>
  </>
);

export default App;