import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Contact.module.css';

const initialFormData = {
  name: '',
  email: '',
  subject: '',
  message: ''
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialFormData);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Por favor escribe tu nombre completo.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Incluye un correo electrónico válido.';
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        newErrors.email = 'El formato del correo no es válido.';
      }
    }
    if (!formData.subject.trim()) {
      newErrors.subject = 'Cuéntanos brevemente el tema de tu consulta.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Comparte detalles para brindarte una respuesta útil.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => {
        const updated = { ...prev };
        delete updated[name];
        return updated;
      });
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    // eslint-disable-next-line no-console
    console.log('Consulta recibida:', formData);
    setSubmitted(true);
    setFormData(initialFormData);
    setErrors({});
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contacto | BravinoTeraLuna</title>
        <meta
          name="description"
          content="Comunícate con BravinoTeraLuna para recibir asesoría en seguridad digital, programas formativos y herramientas."
        />
      </Helmet>
      <section className={styles.intro}>
        <h1>Conversemos sobre tus retos digitales</h1>
        <p>
          Completa el formulario para coordinar una llamada o recibir información personalizada. Responderemos lo antes posible.
        </p>
      </section>

      <div className={styles.grid}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.fieldGroup}>
            <label htmlFor="name" className={styles.label}>Nombre completo *</label>
            <input
              id="name"
              name="name"
              type="text"
              className={styles.input}
              value={formData.name}
              onChange={handleChange}
              aria-invalid={errors.name ? 'true' : 'false'}
              aria-describedby={errors.name ? 'error-name' : undefined}
              placeholder="Escribe tu nombre"
            />
            {errors.name && <span id="error-name" className={styles.error}>{errors.name}</span>}
          </div>

          <div className={styles.fieldGroup}>
            <label htmlFor="email" className={styles.label}>Correo electrónico *</label>
            <input
              id="email"
              name="email"
              type="email"
              className={styles.input}
              value={formData.email}
              onChange={handleChange}
              aria-invalid={errors.email ? 'true' : 'false'}
              aria-describedby={errors.email ? 'error-email' : undefined}
              placeholder="nombre@ejemplo.com"
            />
            {errors.email && <span id="error-email" className={styles.error}>{errors.email}</span>}
          </div>

          <div className={styles.fieldGroup}>
            <label htmlFor="subject" className={styles.label}>Tema *</label>
            <input
              id="subject"
              name="subject"
              type="text"
              className={styles.input}
              value={formData.subject}
              onChange={handleChange}
              aria-invalid={errors.subject ? 'true' : 'false'}
              aria-describedby={errors.subject ? 'error-subject' : undefined}
              placeholder="Ej. Capacitación para voluntariado"
            />
            {errors.subject && <span id="error-subject" className={styles.error}>{errors.subject}</span>}
          </div>

          <div className={styles.fieldGroup}>
            <label htmlFor="message" className={styles.label}>Mensaje *</label>
            <textarea
              id="message"
              name="message"
              className={styles.textarea}
              rows="5"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={errors.message ? 'true' : 'false'}
              aria-describedby={errors.message ? 'error-message' : undefined}
              placeholder="Comparte contexto, fechas y expectativas."
            />
            {errors.message && <span id="error-message" className={styles.error}>{errors.message}</span>}
          </div>

          <button type="submit" className={styles.submitButton}>
            Enviar mensaje
          </button>
          {submitted && <p className={styles.success}>¡Gracias! Te contactaremos muy pronto.</p>}
        </form>

        <aside className={styles.contactCard}>
          <h2 className={styles.contactTitle}>Datos de contacto</h2>
          <p className={styles.contactInfo}>Dirección: [Dirección en México]</p>
          <p className={styles.contactInfo}>Teléfono: +52 XX XXXX XXXX</p>
          <p className={styles.contactInfo}>Correo: contacto@bravinoteraluna.site</p>
          <p className={styles.contactInfo}>
            Horario de atención: Lunes a viernes 09:00 - 17:00 (GMT-6)
          </p>
        </aside>
      </div>
    </div>
  );
};

export default ContactPage;