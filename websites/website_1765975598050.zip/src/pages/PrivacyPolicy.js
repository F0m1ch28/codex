import React from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Legal.module.css';

const PrivacyPolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Política de privacidad | BravinoTeraLuna</title>
      <meta
        name="description"
        content="Lee la política de privacidad de BravinoTeraLuna y conoce cómo protegemos tus datos personales."
      />
    </Helmet>
    <header className={styles.hero}>
      <h1>Política de privacidad</h1>
      <p className={styles.lastUpdated}>Última actualización: enero 2024</p>
    </header>

    <section className={styles.section}>
      <h2>Datos que recopilamos</h2>
      <p>
        Recabamos información que compartes voluntariamente a través de formularios de contacto, newsletter y participación
        en programas. Solo solicitamos datos mínimos para responder a tus consultas.
      </p>
    </section>

    <section className={styles.section}>
      <h2>Uso de la información</h2>
      <ul className={styles.list}>
        <li className={styles.listItem}>Responder solicitudes de información o soporte.</li>
        <li className={styles.listItem}>Enviar recursos educativos relevantes con tu consentimiento.</li>
        <li className={styles.listItem}>Mejorar el sitio mediante análisis agregados y anónimos.</li>
      </ul>
    </section>

    <section className={styles.section}>
      <h2>Compartición de datos</h2>
      <p>
        No vendemos ni compartimos tus datos personales con terceros. Solo colaboramos con proveedores alineados con nuestra
        política de privacidad y celebramos acuerdos de confidencialidad.
      </p>
    </section>

    <section className={styles.section}>
      <h2>Tus derechos</h2>
      <p>
        Puedes solicitar acceso, rectificación o eliminación de tus datos escribiendo a{' '}
        <a href="mailto:contacto@bravinoteraluna.site">contacto@bravinoteraluna.site</a>. Responderemos en un plazo máximo de 5 días hábiles.
      </p>
    </section>
  </div>
);

export default PrivacyPolicyPage;