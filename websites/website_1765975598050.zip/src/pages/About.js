import React from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/About.module.css';

const AboutPage = () => {
  const values = [
    {
      title: 'Claridad primero',
      description: 'Traducimos conceptos complejos en acciones prácticas que cualquier persona puede aplicar sin miedo a equivocarse.'
    },
    {
      title: 'Comunidad informada',
      description: 'Conectamos a especialistas, docentes y ciudadanía para intercambiar aprendizajes y frenar el fraude digital desde la raíz.'
    },
    {
      title: 'Ética en cada decisión',
      description: 'Evaluamos herramientas, proveedores y mensajes con un enfoque ético y centrado en la protección de datos personales.'
    }
  ];

  const milestones = [
    {
      year: '2017',
      detail: 'Nace BravinoTeraLuna como iniciativa ciudadana para acompañar a familias frente a engaños en línea.'
    },
    {
      year: '2019',
      detail: 'Creamos el primer laboratorio de simulación para organizaciones civiles en Ciudad de México.'
    },
    {
      year: '2021',
      detail: 'Lanzamos la plataforma educativa con rutas personalizadas para equipos híbridos y de campo.'
    },
    {
      year: '2023',
      detail: 'Integramos monitoreo continuo para anticipar nuevos métodos de fraude digital en América Latina.'
    }
  ];

  const team = [
    {
      name: 'Daniela Bravino',
      role: 'Co-fundadora y estratega de seguridad',
      bio: 'Especialista en evaluación de riesgos con más de 12 años acompañando a organizaciones sociales y educativas.',
      image: 'https://picsum.photos/seed/daniela/360/360'
    },
    {
      name: 'Teresa Luna',
      role: 'Directora de aprendizaje',
      bio: 'Diseña experiencias formativas que mezclan storytelling y ejercicios prácticos para todo tipo de participantes.',
      image: 'https://picsum.photos/seed/teresa/360/360'
    },
    {
      name: 'Andrés Bravo',
      role: 'Investigador de amenazas digitales',
      bio: 'Analiza tendencias, colabora con redes de respuesta y mantiene actualizadas las alertas para la comunidad.',
      image: 'https://picsum.photos/seed/andres/360/360'
    }
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Sobre BravinoTeraLuna | Nuestra misión y equipo</title>
        <meta
          name="description"
          content="Conoce la misión, valores y al equipo de BravinoTeraLuna dedicado a fortalecer la seguridad digital en México."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Construimos confianza digital para toda la comunidad</h1>
          <p>
            BravinoTeraLuna nació en México como un proyecto colaborativo de especialistas, educadores y activistas.
            Creemos en la prevención temprana, la empatía y la educación continua para frenar los fraudes en línea.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/seed/equipo/720/480"
            alt="Equipo de BravinoTeraLuna planificando nuevas iniciativas"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.section}>
        <h2>Nuestros valores en acción</h2>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2>Hitos que marcaron el camino</h2>
        <div className={styles.timeline}>
          {milestones.map((milestone) => (
            <article key={milestone.year} className={styles.timelineItem}>
              <span className={styles.timelineYear}>{milestone.year}</span>
              <p>{milestone.detail}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2>Equipo fundador</h2>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img
                src={member.image}
                alt={`Fotografía de ${member.name}`}
                className={styles.teamAvatar}
                loading="lazy"
              />
              <h3 className={styles.teamName}>{member.name}</h3>
              <p className={styles.teamRole}>{member.role}</p>
              <p className={styles.teamBio}>{member.bio}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.storyBlock}>
          <h2>Cómo trabajamos</h2>
          <p>
            Escuchamos tus necesidades, analizamos el contexto y diseñamos soluciones realistas. Nuestro equipo colabora
            con redes de respuesta a incidentes, universidades y organizaciones civiles para mantenerte al tanto de los
            riesgos emergentes sin caer en alarmismos. Impulsamos la transparencia y la participación de toda la comunidad.
          </p>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;