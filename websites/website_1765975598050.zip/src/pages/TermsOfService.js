import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from '../styles/Legal.module.css';

const TermsConditionsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Términos de uso | BravinoTeraLuna</title>
      <meta
        name="description"
        content="Consulta los términos y condiciones de uso del sitio web de BravinoTeraLuna."
      />
    </Helmet>
    <header className={styles.hero}>
      <h1>Términos de uso</h1>
      <p className={styles.lastUpdated}>Última actualización: enero 2024</p>
    </header>

    <section className={styles.section}>
      <h2>1. Aceptación</h2>
      <p>
        Al acceder y utilizar bravinoteraluna.site aceptas los presentes términos. Si no estás de acuerdo con
        alguna parte, te solicitamos abstenerte de utilizar el sitio.
      </p>
    </section>

    <section className={styles.section}>
      <h2>2. Uso responsable</h2>
      <ul className={styles.list}>
        <li className={styles.listItem}>Utilizar la información con fines educativos o preventivos.</li>
        <li className={styles.listItem}>Citar a BravinoTeraLuna cuando se comparta contenido.</li>
        <li className={styles.listItem}>No alterar o redistribuir materiales sin autorización previa.</li>
      </ul>
    </section>

    <section className={styles.section}>
      <h2>3. Limitación de responsabilidad</h2>
      <p>
        Esforzamos por ofrecer información actualizada y precisa, pero no garantizamos la inexistencia de errores.
        Las decisiones tomadas con base en el contenido son responsabilidad de cada persona u organización.
      </p>
    </section>

    <section className={styles.section}>
      <h2>4. Cambios</h2>
      <p>
        Los términos pueden modificarse en cualquier momento. Publicaremos las actualizaciones en esta página y
        la fecha de revisión se mostrará en la parte superior.
      </p>
    </section>
  </div>
);

export const LegalPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Información legal | BravinoTeraLuna</title>
      <meta
        name="description"
        content="Información legal, política de privacidad, términos de uso y política de cookies de BravinoTeraLuna."
      />
    </Helmet>
    <header className={styles.hero}>
      <h1>Información legal</h1>
      <p>
        Transparencia y confianza son esenciales. Consulta nuestras políticas para conocer cómo cuidamos tu información.
      </p>
    </header>

    <section className={styles.section}>
      <div className={styles.linkGrid}>
        <Link to="/legal/privacidad" className={styles.linkCard}>
          <span className={styles.linkLabel}>Política de privacidad</span>
          <p>Descubre cómo recolectamos, usamos y protegemos tus datos personales.</p>
        </Link>
        <Link to="/legal/terminos" className={styles.linkCard}>
          <span className={styles.linkLabel}>Términos de uso</span>
          <p>Condiciones para utilizar el contenido y los servicios del sitio.</p>
        </Link>
        <Link to="/legal/cookies" className={styles.linkCard}>
          <span className={styles.linkLabel}>Política de cookies</span>
          <p>Información sobre cookies necesarias, de análisis y tus preferencias.</p>
        </Link>
      </div>
    </section>
  </div>
);

export const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Política de cookies | BravinoTeraLuna</title>
      <meta
        name="description"
        content="Conoce cómo BravinoTeraLuna utiliza cookies para mejorar tu experiencia y cómo puedes gestionarlas."
      />
    </Helmet>
    <header className={styles.hero}>
      <h1>Política de cookies</h1>
      <p className={styles.lastUpdated}>Última actualización: enero 2024</p>
    </header>

    <section className={styles.section}>
      <h2>¿Qué son las cookies?</h2>
      <p>
        Las cookies son pequeños archivos que se almacenan en tu dispositivo para recordar tus preferencias,
        facilitar la navegación y obtener estadísticas de uso del sitio.
      </p>
    </section>

    <section className={styles.section}>
      <h2>Tipos de cookies que usamos</h2>
      <ul className={styles.list}>
        <li className={styles.listItem}><strong>Esenciales:</strong> necesarias para el funcionamiento del sitio.</li>
        <li className={styles.listItem}><strong>Analíticas:</strong> nos ayudan a comprender qué secciones resultan más útiles.</li>
      </ul>
    </section>

    <section className={styles.section}>
      <h2>Gestión de cookies</h2>
      <p>
        Puedes aceptar o rechazar las cookies opcionales mediante el banner correspondiente o la configuración de tu navegador.
        Las cookies esenciales no pueden deshabilitarse porque garantizan la funcionalidad básica.
      </p>
    </section>
  </div>
);

export default TermsConditionsPage;