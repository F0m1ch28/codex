import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from '../styles/Home.module.css';

const HomePage = () => {
  const stats = [
    { value: '12k+', label: 'Personas capacitadas' },
    { value: '180', label: 'Organizaciones guiadas' },
    { value: '24/7', label: 'Monitoreo de tendencias' }
  ];

  const highlights = [
    {
      id: 1,
      title: 'Alertas clave para proteger tus datos hoy',
      description: 'Resumen semanal de incidentes relevantes y cómo adaptar tus controles internos antes de que el riesgo te alcance.',
      tag: 'Actualidad',
      image: 'https://picsum.photos/seed/alertas/640/420'
    },
    {
      id: 2,
      title: 'Buenas prácticas para equipos híbridos',
      description: 'Checklist descargable para fortalecer accesos remotos, aplicaciones colaborativas y coordinación multicultural.',
      tag: 'Guía esencial',
      image: 'https://picsum.photos/seed/remoto/640/420'
    },
    {
      id: 3,
      title: 'Historias de personas que frenaron un fraude',
      description: 'Casos reales compartidos por nuestra comunidad que demuestran el poder de la prevención y la educación continua.',
      tag: 'Historias',
      image: 'https://picsum.photos/seed/historias/640/420'
    }
  ];

  const guidePreviews = [
    {
      id: 1,
      title: 'Identificación temprana de correos sospechosos',
      steps: ['Verifica dominios y firmas', 'Analiza solicitudes inusuales', 'Activa filtros inteligentes'],
      image: 'https://picsum.photos/seed/correo/520/360'
    },
    {
      id: 2,
      title: 'Gestión segura de contraseñas y accesos',
      steps: ['Crea combinaciones únicas', 'Habilita autenticación múltiple', 'Administra privilegios por roles'],
      image: 'https://picsum.photos/seed/accesos/520/360'
    },
    {
      id: 3,
      title: 'Reacción rápida ante incidentes digitales',
      steps: ['Aísla el equipo afectado', 'Documenta el evento', 'Comunica y sigue el plan de respuesta'],
      image: 'https://picsum.photos/seed/incidente/520/360'
    }
  ];

  const resources = [
    {
      id: 1,
      icon: '🛡️',
      title: 'Mapa de riesgos personalizado',
      description: 'Evalúa tu nivel de exposición con nuestra guía inicial.',
      link: '/guide'
    },
    {
      id: 2,
      icon: '🎓',
      title: 'Programas para equipos',
      description: 'Sesiones modulares para líderes, docentes y profesionistas.',
      link: '/programs'
    },
    {
      id: 3,
      icon: '🧰',
      title: 'Kit de herramientas verificadas',
      description: 'Soluciones confiables para cada etapa de madurez digital.',
      link: '/tools'
    }
  ];

  const testimonials = [
    {
      id: 1,
      quote: 'El enfoque humano de BravinoTeraLuna nos ayudó a traducir políticas técnicas en hábitos cotidianos. Hoy toda la organización participa activamente.',
      name: 'Laura Muñoz',
      role: 'Directora de programas sociales',
      avatar: 'https://picsum.photos/seed/laura/120/120'
    },
    {
      id: 2,
      quote: 'Los talleres prácticos despertaron la curiosidad de nuestro personal y disminuimos en 65% los reportes por intentos de fraude digital.',
      name: 'Ricardo Hernández',
      role: 'Coordinador de TI en educación superior',
      avatar: 'https://picsum.photos/seed/ricardo/120/120'
    },
    {
      id: 3,
      quote: 'La asesoría continua nos permitió crear protocolos claros que fomentan confianza con aliados y ciudadanía.',
      name: 'María del Rosario Torres',
      role: 'Gestora de comunicación pública',
      avatar: 'https://picsum.photos/seed/maria/120/120'
    }
  ];

  return (
    <>
      <Helmet>
        <title>BravinoTeraLuna | Seguridad digital y conciencia antifraude</title>
        <meta
          name="description"
          content="Recursos, guías y programas de BravinoTeraLuna para fortalecer la seguridad digital y la conciencia antifraude en México."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.tagline}>Cultura de seguridad para personas y organizaciones</p>
          <h1>Protege tu mundo digital con guía clara y acompañamiento continuo</h1>
          <p className={styles.heroText}>
            En BravinoTeraLuna unimos experiencia técnica y sensibilidad social para anticipar riesgos,
            frenar intentos de fraude y crear entornos digitales confiables en México.
          </p>
          <div className={styles.heroActions}>
            <Link to="/guide" className={styles.primaryAction}>
              Explorar guías
            </Link>
            <Link to="/contact" className={styles.secondaryAction}>
              Conversemos
            </Link>
          </div>
          <div className={styles.heroStats} aria-label="Indicadores clave">
            {stats.map((stat) => (
              <div className={styles.stat} key={stat.label}>
                <span className={styles.statNumber}>{stat.value}</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/seed/seguridadmx/720/520"
            alt="Profesionales monitoreando datos en una sala segura"
            className={styles.heroImage}
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.section} aria-labelledby="destacados">
        <div className={styles.sectionHeader}>
          <h2 id="destacados" className={styles.sectionTitle}>Lo más relevante esta semana</h2>
          <p className={styles.sectionSubtitle}>
            Información accionable para prevenir fraudes en línea y reforzar tus procedimientos internos.
          </p>
        </div>
        <div className={styles.cardsGrid}>
          {highlights.map((item) => (
            <article className={styles.card} key={item.id}>
              <img
                src={item.image}
                alt={item.title}
                className={styles.cardImage}
                loading="lazy"
              />
              <span className={styles.cardTag}>{item.tag}</span>
              <h3 className={styles.cardTitle}>{item.title}</h3>
              <p className={styles.cardDescription}>{item.description}</p>
              <Link to="/blog" className={styles.cardLink}>
                Leer más en el blog
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="guias">
        <div className={styles.sectionHeader}>
          <h2 id="guias" className={styles.sectionTitle}>Guías paso a paso</h2>
          <p className={styles.sectionSubtitle}>
            Diseñadas para equipos ocupados que necesitan decisiones ágiles y sencillas de implementar.
          </p>
        </div>
        <div className={styles.guidesGrid}>
          {guidePreviews.map((guide) => (
            <article className={styles.guideCard} key={guide.id}>
              <img
                src={guide.image}
                alt={guide.title}
                className={styles.guideImage}
                loading="lazy"
              />
              <div className={styles.guideContent}>
                <h3 className={styles.guideTitle}>{guide.title}</h3>
                <ul className={styles.guideList}>
                  {guide.steps.map((step) => (
                    <li key={step}>{step}</li>
                  ))}
                </ul>
                <Link to="/guide" className={styles.cardLink}>
                  Abrir el centro de guías
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.programBanner}>
        <div className={styles.programContent}>
          <h2>Programas formativos a tu medida</h2>
          <p>
            Sesiones interactivas para líderes, educadores, familias y organizaciones que desean fortalecer
            la confianza digital sin lenguaje complejo.
          </p>
          <div className={styles.programStats}>
            <div className={styles.programStat}>
              <span className={styles.statNumber}>92%</span>
              <span className={styles.statLabel}>Mejora en protocolos</span>
            </div>
            <div className={styles.programStat}>
              <span className={styles.statNumber}>4.8/5</span>
              <span className={styles.statLabel}>Satisfacción promedio</span>
            </div>
            <div className={styles.programStat}>
              <span className={styles.statNumber}>3</span>
              <span className={styles.statLabel}>Niveles de especialización</span>
            </div>
          </div>
          <Link to="/programs" className={styles.primaryAction}>
            Conocer programas
          </Link>
        </div>
        <div className={styles.programIllustration}>
          <img
            src="https://picsum.photos/seed/capacitacion/640/480"
            alt="Sesión formativa sobre seguridad digital"
            className={styles.programImage}
            loading="lazy"
          />
        </div>
      </section>

      <section className={`${styles.section} ${styles.testimonials}`} aria-labelledby="testimonios">
        <div className={styles.sectionHeader}>
          <h2 id="testimonios" className={styles.sectionTitle}>Historias de confianza</h2>
          <p className={styles.sectionSubtitle}>
            Personas que hoy lideran la seguridad digital de sus comunidades con herramientas sencillas
            y decisiones informadas.
          </p>
        </div>
        <div className={styles.testimonialGrid}>
          {testimonials.map((testimonial) => (
            <article className={styles.testimonialCard} key={testimonial.id}>
              <div className={styles.testimonialHeader}>
                <img
                  src={testimonial.avatar}
                  alt={`Fotografía de ${testimonial.name}`}
                  className={styles.testimonialAvatar}
                  loading="lazy"
                />
                <div>
                  <p className={styles.testimonialName}>{testimonial.name}</p>
                  <p className={styles.testimonialRole}>{testimonial.role}</p>
                </div>
              </div>
              <p className={styles.testimonialQuote}>"{testimonial.quote}"</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection} aria-labelledby="cta">
        <div className={styles.ctaContent}>
          <h2 id="cta">¿Listo para elevar la conciencia digital en tu equipo?</h2>
          <p>
            Inicia con los recursos gratuitos del centro BravinoTeraLuna o agenda una conversación personalizada.
          </p>
          <div className={styles.resourceList}>
            {resources.map((resource) => (
              <Link to={resource.link} className={styles.resourceItem} key={resource.id}>
                <span className={styles.resourceIcon} aria-hidden="true">
                  {resource.icon}
                </span>
                <div>
                  <p className={styles.resourceTitle}>{resource.title}</p>
                  <p className={styles.resourceDescription}>{resource.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;