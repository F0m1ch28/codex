import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from '../styles/Services.module.css';

export const GuidePage = () => {
  const guides = [
    {
      title: 'Correo electrónico seguro',
      summary: 'Implementa filtros, verifica dominios y configura alertas para detectar mensajes engañosos.',
      focus: ['Monitoreo de remitentes', 'Educación al usuario', 'Procedimientos de escalamiento']
    },
    {
      title: 'Protección de identidad en redes sociales',
      summary: 'Define criterios para compartir información, valida solicitudes y fortalece autenticación.',
      focus: ['Políticas de publicación', 'Verificación en dos pasos', 'Protocolos ante suplantaciones']
    },
    {
      title: 'Respuesta a incidentes digitales',
      summary: 'Metodología inmediata para contener eventos, documentarlos y aprender de cada experiencia.',
      focus: ['Activación del equipo', 'Registro forense', 'Comunicación con partes interesadas']
    }
  ];

  const checklist = [
    'Mapea los canales oficiales de comunicación para tu equipo.',
    'Actualiza los datos de contacto de quienes lideran la respuesta a incidentes.',
    'Ensaya escenarios realistas con simulaciones trimestrales.',
    'Comparte alertas verificadas de forma clara y sin tecnicismos.',
    'Documenta aprendizajes y refuerza lo que funcionó en cada ejercicio.'
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Guías de seguridad digital | BravinoTeraLuna</title>
        <meta
          name="description"
          content="Guías prácticas de BravinoTeraLuna para prevenir fraudes en línea, proteger identidades y responder incidentes digitales."
        />
      </Helmet>
      <header className={styles.pageHero}>
        <h1 className={styles.pageTitle}>Centro de guías</h1>
        <p className={styles.lead}>
          Diseñamos rutas claras para que cada persona, equipo o institución pueda comprender, prevenir y reaccionar ante
          amenazas digitales con confianza.
        </p>
        <Link to="/contact" className={styles.primaryLink}>
          Solicitar acompañamiento
        </Link>
      </header>

      <section className={styles.section}>
        <h2>Rutas indispensables</h2>
        <div className={styles.cardGrid}>
          {guides.map((guide) => (
            <article key={guide.title} className={styles.card}>
              <span className={styles.badge}>Guía</span>
              <h3 className={styles.cardTitle}>{guide.title}</h3>
              <p className={styles.cardDescription}>{guide.summary}</p>
              <ul className={styles.focusList}>
                {guide.focus.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2>Checklist de preparación</h2>
        <ol className={styles.stepList}>
          {checklist.map((item) => (
            <li key={item} className={styles.stepItem}>{item}</li>
          ))}
        </ol>
      </section>

      <section className={styles.highlight}>
        <h2 className={styles.highlightTitle}>Laboratorios interactivos</h2>
        <p className={styles.highlightText}>
          Complementa cada guía con simulaciones guiadas. Practica el reconocimiento de intentos de fraude, la comunicación
          efectiva y el aprendizaje de incidentes para fortalecer tu cultura de seguridad.
        </p>
      </section>
    </div>
  );
};

export const ProgramsPage = () => {
  const programs = [
    {
      title: 'Fundamentos de prevención',
      focus: 'Sensibiliza a tu organización sobre tácticas comunes de fraude digital y establece políticas claras.',
      duration: '4 sesiones de 90 minutos',
      outcome: 'Manual interno de hábitos seguros y plan de comunicación.'
    },
    {
      title: 'Perfiles guardianes',
      focus: 'Capacita a líderes y enlaces comunitarios para detectar señales tempranas y acompañar casos reales.',
      duration: '6 sesiones + asesoría continua',
      outcome: 'Mapa de actores clave y protocolos de reporte con enfoque humano.'
    },
    {
      title: 'Resiliencia avanzada',
      focus: 'Integra análisis de riesgos, simulaciones personalizadas y métricas para una mejora constante.',
      duration: 'Programa anual modular',
      outcome: 'Tablero de indicadores, cronograma de simulacros y evaluaciones periódicas.'
    }
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Programas formativos | BravinoTeraLuna</title>
        <meta
          name="description"
          content="Programas formativos de BravinoTeraLuna para fortalecer la cultura de seguridad digital y la prevención de fraudes."
        />
      </Helmet>
      <header className={styles.pageHero}>
        <h1 className={styles.pageTitle}>Programas a la medida</h1>
        <p className={styles.lead}>
          Desde sesiones introductorias hasta planes anuales. Acompañamos a organizaciones mexicanas a fortalecer su
          resiliencia digital con estrategias participativas.
        </p>
      </header>

      <section className={styles.section}>
        <div className={styles.timeline}>
          {programs.map((program, index) => (
            <article key={program.title} className={styles.timelineItem}>
              <span className={styles.timelineMarker}>{index + 1}</span>
              <div className={styles.timelineContent}>
                <h3 className={styles.cardTitle}>{program.title}</h3>
                <p className={styles.cardDescription}>{program.focus}</p>
                <p className={styles.meta}><strong>Duración:</strong> {program.duration}</p>
                <p className={styles.meta}><strong>Resultado:</strong> {program.outcome}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.highlight}>
        <h2 className={styles.highlightTitle}>Metodología basada en evidencia</h2>
        <p className={styles.highlightText}>
          Integramos datos de incidentes reales, ejercicios de co-creación y métricas de mejora continua. Cada módulo incluye
          seguimiento posterior para medir impacto y reforzar aprendizajes.
        </p>
        <Link to="/contact" className={styles.secondaryLink}>
          Agendar una sesión informativa
        </Link>
      </section>
    </div>
  );
};

export const ToolsPage = () => {
  const categories = [
    {
      name: 'Protección de identidad',
      description: 'Soluciones enfocadas en resguardar credenciales y vigilar la exposición de datos.',
      tools: [
        { name: 'Monitor de credenciales', purpose: 'Notificaciones cuando tus correos aparecen en filtraciones.' },
        { name: 'Gestor de contraseñas colaborativo', purpose: 'Gestión centralizada con control de roles y auditoría.' },
        { name: 'Alerta de suplantación en redes', purpose: 'Seguimiento automático de cuentas imitadoras y reportes guiados.' }
      ]
    },
    {
      name: 'Comunicación segura',
      description: 'Herramientas para proteger canales oficiales y verificar mensajes antes de responder.',
      tools: [
        { name: 'Verificador de enlaces', purpose: 'Analiza URLs antes de que el equipo haga clic.' },
        { name: 'Plantillas de respuesta', purpose: 'Formatos para responder reportes ciudadanos o aliados con rapidez.' },
        { name: 'Panel de escalamiento', purpose: 'Coordina los pasos a seguir cuando se detecta un intento de fraude.' }
      ]
    },
    {
      name: 'Aprendizaje continuo',
      description: 'Recursos para sostener campañas de sensibilización sin saturar a las personas.',
      tools: [
        { name: 'Micro-mensajes semanales', purpose: 'Recordatorios cortos para mantener hábitos seguros vivos.' },
        { name: 'Biblioteca interactiva', purpose: 'Casos reales narrados y análisis paso a paso.' },
        { name: 'Encuestas de pulso', purpose: 'Midiendo percepción y mejoras tras cada intervención formativa.' }
      ]
    }
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Herramientas recomendadas | BravinoTeraLuna</title>
        <meta
          name="description"
          content="Selección curada de herramientas para fortalecer la seguridad digital, la comunicación y el aprendizaje continuo."
        />
      </Helmet>
      <header className={styles.pageHero}>
        <h1 className={styles.pageTitle}>Herramientas confiables</h1>
        <p className={styles.lead}>
          Probamos soluciones que equilibran facilidad de uso, privacidad y soporte. Aquí encontrarás nuestras
          recomendaciones según tu nivel de madurez.
        </p>
      </header>

      <section className={styles.section}>
        {categories.map((category) => (
          <article key={category.name} className={styles.toolCategory}>
            <div className={styles.toolHeader}>
              <h2>{category.name}</h2>
              <p>{category.description}</p>
            </div>
            <ul className={styles.toolList}>
              {category.tools.map((tool) => (
                <li key={tool.name} className={styles.toolItem}>
                  <span className={styles.badge}>{tool.name}</span>
                  <p>{tool.purpose}</p>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </section>

      <section className={styles.highlight}>
        <h2 className={styles.highlightTitle}>Criterios de evaluación</h2>
        <p className={styles.highlightText}>
          Revisamos políticas de privacidad, soporte en español, accesibilidad y viabilidad presupuestal. Elaboramos
          comparativos neutrales para que tomes decisiones informadas sin sesgos comerciales.
        </p>
        <Link to="/contact" className={styles.secondaryLink}>
          Solicita una evaluación personalizada
        </Link>
      </section>
    </div>
  );
};

export const BlogPage = () => {
  const posts = [
    {
      title: 'Señales para identificar fraudes emocionales en redes sociales',
      category: 'Análisis',
      excerpt: 'Cómo detectar tácticas que buscan manipularte aprovechando la confianza colectiva y la urgencia emocional.'
    },
    {
      title: 'Historias de éxito: escuelas que blindaron su comunidad digital',
      category: 'Historias',
      excerpt: 'Tres instituciones educativas mexicanas comparten su experiencia implementando campañas permanentes.'
    },
    {
      title: 'Preguntas frecuentes que recibimos sobre compras en línea',
      category: 'Preguntas clave',
      excerpt: 'Checklist para validar sitios, métodos de pago y políticas antes de compartir tus datos.'
    }
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Blog de seguridad digital | BravinoTeraLuna</title>
        <meta
          name="description"
          content="Artículos y análisis de BravinoTeraLuna sobre fraudes en línea, educación digital y protección de datos."
        />
      </Helmet>
      <header className={styles.pageHero}>
        <h1 className={styles.pageTitle}>Historias y análisis</h1>
        <p className={styles.lead}>
          Actualizamos el blog cada semana con tendencias, recomendaciones y voces invitadas que inspiran acción.
        </p>
      </header>

      <section className={styles.section}>
        <div className={styles.postList}>
          {posts.map((post) => (
            <article key={post.title} className={styles.post}>
              <span className={styles.postMeta}>{post.category}</span>
              <h2 className={styles.postTitle}>{post.title}</h2>
              <p className={styles.postExcerpt}>{post.excerpt}</p>
              <Link to="/contact" className={styles.resourceLink}>
                Proponer un tema
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.highlight}>
        <h2 className={styles.highlightTitle}>Newsletter mensual</h2>
        <p className={styles.highlightText}>
          Recibe en tu correo un resumen curado de novedades, recursos descargables y alertas verificadas para tu región.
        </p>
        <Link to="/contact" className={styles.primaryLink}>
          Unirme a la lista
        </Link>
      </section>
    </div>
  );
};

export default GuidePage;