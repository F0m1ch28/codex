import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Header from './Header';
import Footer from './Footer';
import CookieBanner from './CookieBanner';
import DisclaimerModal from './DisclaimerModal';

const Layout = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  return (
    <>
      <Helmet>
        <html lang="en" />
        <link
          rel="alternate"
          hrefLang="en"
          href={`https://tuprogresohoy.com${currentPath}`}
        />
        <link
          rel="alternate"
          hrefLang="es-AR"
          href={`https://tuprogresohoy.com/es${currentPath}`}
        />
      </Helmet>
      <Header />
      <main id="main-content" tabIndex="-1">
        <Outlet />
      </main>
      <Footer />
      <CookieBanner />
      <DisclaimerModal />
    </>
  );
};

export default Layout;