import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const toggle = () => setIsMenuOpen((prev) => !prev);
  const close = () => setIsMenuOpen(false);

  return (
    <header className="header" role="banner">
      <div className="container navbar" aria-label="Primary navigation">
        <div>
          <NavLink to="/" className="nav-link brand" onClick={close}>
            <span style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700 }}>
              Tu Progreso Hoy
            </span>
          </NavLink>
          <p className="language-hint">
            Insight-first educational SaaS from Buenos Aires
          </p>
        </div>
        <button
          className="nav-toggle"
          onClick={toggle}
          aria-expanded={isMenuOpen}
          aria-controls="primary-menu"
          aria-label="Toggle navigation menu"
        >
          <svg
            width="26"
            height="26"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#1F3A6F"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <line x1="3" y1="6" x2="21" y2="6" />
            <line x1="3" y1="12" x2="21" y2="12" />
            <line x1="3" y1="18" x2="17" y2="18" />
          </svg>
        </button>
        <nav>
          <div
            id="primary-menu"
            className={`nav-links ${isMenuOpen ? 'open' : ''}`}
            role="navigation"
          >
            <NavLink className="nav-link" to="/" onClick={close} end>
              Home
            </NavLink>
            <NavLink className="nav-link" to="/about" onClick={close}>
              About
            </NavLink>
            <NavLink className="nav-link" to="/services" onClick={close}>
              Services
            </NavLink>
                <NavLink className="nav-link" to="/inflation" onClick={close}>
              Inflation
            </NavLink>
            <NavLink className="nav-link" to="/course" onClick={close}>
              Course
            </NavLink>
            <NavLink className="nav-link" to="/resources" onClick={close}>
              Resources
            </NavLink>
            <NavLink className="nav-link" to="/faq" onClick={close}>
              FAQ
            </NavLink>
            <NavLink className="nav-link" to="/contact" onClick={close}>
              Contact
            </NavLink>
            <NavLink className="btn btn-outline" to="/services" onClick={close}>
              Explore Solutions
            </NavLink>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;