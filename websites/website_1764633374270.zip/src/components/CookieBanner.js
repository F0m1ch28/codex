import React, { useEffect, useState } from 'react';

const CookieBanner = () => {
  const storageKey = 'tph_cookie_consent';
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(storageKey);
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (status) => {
    localStorage.setItem(storageKey, status);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <strong>Cookies & Analytics</strong>
      <p style={{ margin: '0.6rem 0 0' }}>
        We use cookies only after your consent to analyze aggregated usage data
        and improve our educational experience. No financial data is stored.
      </p>
      <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.8rem' }}>
        <button
          type="button"
          className="btn btn-primary"
          onClick={() => handleConsent('accepted')}
        >
          Accept & Continue
        </button>
        <button
          type="button"
          className="btn btn-outline"
          onClick={() => handleConsent('declined')}
        >
          Decline
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;