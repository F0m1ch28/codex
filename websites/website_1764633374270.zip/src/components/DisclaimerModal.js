import React, { useEffect, useRef, useState } from 'react';

const DisclaimerModal = () => {
  const storageKey = 'tph_disclaimer_ack';
  const dialogRef = useRef(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const acknowledged = localStorage.getItem(storageKey);
    if (!acknowledged) {
      setOpen(true);
    }
  }, []);

  useEffect(() => {
    if (open && dialogRef.current) {
      const focusable = dialogRef.current.querySelector('button');
      focusable?.focus();
    }
  }, [open]);

  const handleClose = () => {
    localStorage.setItem(storageKey, 'acknowledged');
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div
      className="modal-backdrop"
      role="dialog"
      aria-modal="true"
      aria-labelledby="disclaimer-heading"
    >
      <div className="modal" ref={dialogRef}>
        <button
          type="button"
          className="close-btn"
          onClick={handleClose}
          aria-label="Close disclaimer"
        >
          ×
        </button>
        <h3 id="disclaimer-heading">Important Educational Disclaimer</h3>
        <p>
          We do not provide financial services. The materials available on Tu
          Progreso Hoy are strictly educational and data-driven. Please consult
          licensed professionals for tailored financial decisions.
        </p>
        <p style={{ fontWeight: 600 }}>
          No brindamos servicios financieros. Todo el contenido es educativo.
        </p>
        <button
          type="button"
          className="btn btn-primary"
          onClick={handleClose}
        >
          I Understand / Comprendo
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;