import React from 'react';
import { NavLink } from 'react-router-dom';

const Footer = () => (
  <footer>
    <div className="container footer-grid">
      <div>
        <h3 style={{ fontFamily: 'DM Sans, sans-serif', marginTop: 0 }}>
          Tu Progreso Hoy
        </h3>
        <p>
          Datos verificados para planificar tu presupuesto. Plataforma educativa
          con datos esenciales, sin asesoría financiera directa.
        </p>
        <div style={{ display: 'flex', gap: '0.6rem', marginTop: '1rem' }}>
          <a
            href="https://www.linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
          >
            <span className="tag">LinkedIn</span>
          </a>
          <a
            href="https://twitter.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Twitter"
          >
            <span className="tag">X / Twitter</span>
          </a>
          <a
            href="https://www.youtube.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="YouTube"
          >
            <span className="tag">YouTube</span>
          </a>
        </div>
      </div>
      <div>
        <h4>Company</h4>
        <ul style={{ listStyle: 'none', padding: 0, margin: 0, lineHeight: 2 }}>
          <li>
            <NavLink to="/about">About</NavLink>
          </li>
          <li>
            <NavLink to="/services">Services</NavLink>
          </li>
          <li>
            <NavLink to="/course">Course</NavLink>
          </li>
          <li>
            <NavLink to="/resources">Resources</NavLink>
          </li>
          <li>
            <NavLink to="/faq">FAQ</NavLink>
          </li>
        </ul>
      </div>
      <div>
        <h4>Legal & Contact</h4>
        <ul style={{ listStyle: 'none', padding: 0, margin: 0, lineHeight: 1.8 }}>
          <li>
            <NavLink to="/privacy">Privacy Policy</NavLink>
          </li>
          <li>
            <NavLink to="/terms">Terms of Use</NavLink>
          </li>
          <li>
            <NavLink to="/cookies">Cookie Policy</NavLink>
          </li>
        </ul>
        <div style={{ marginTop: '1rem', fontSize: '0.95rem' }}>
          <p>Av. 9 de Julio 1000, Buenos Aires, Argentina</p>
          <p>
            Tel: <a href="tel:+541155551234">+54 11 5555-1234</a>
          </p>
          <p>
            Email:{' '}
            <a href="mailto:info@tuprogresohoy.com">
              info@tuprogresohoy.com
            </a>
          </p>
        </div>
      </div>
    </div>
    <div className="container footer-bottom">
      © {new Date().getFullYear()} Tu Progreso Hoy — Tu progreso comienza hoy.
    </div>
  </footer>
);

export default Footer;