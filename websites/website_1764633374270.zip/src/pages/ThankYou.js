import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import Seo from '../components/Seo';

const ThankYou = () => {
  const location = useLocation();
  const source = location.state?.source;

  return (
    <>
      <Seo
        title="Thank You | Tu Progreso Hoy"
        description="Thank you for connecting with Tu Progreso Hoy. Check your inbox for next steps."
        path="/thank-you"
        image="https://picsum.photos/id/720/1200/630"
      />
      <section className="section">
        <div className="container card" style={{ textAlign: 'center' }}>
          <h1>Thank You</h1>
          <p>
            Your confirmation has been received. We will reach out shortly from
            Buenos Aires with tailored next steps.
          </p>
          {source === 'trial' ? (
            <p>
              Expect your onboarding kit and schedule invitation in your inbox
              within the next business day.
            </p>
          ) : (
            <p>
              Our team will respond to your inquiry within one business day.
            </p>
          )}
          <NavLink className="btn btn-primary" to="/">
            Return Home
          </NavLink>
        </div>
      </section>
    </>
  );
};

export default ThankYou;