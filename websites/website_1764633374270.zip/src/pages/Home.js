import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Area,
  AreaChart,
} from 'recharts';
import Seo from '../components/Seo';

const fallbackExchangeData = [
  { date: 'Oct', rate: 0.0029 },
  { date: 'Nov', rate: 0.0026 },
  { date: 'Dec', rate: 0.0024 },
  { date: 'Jan', rate: 0.0022 },
  { date: 'Feb', rate: 0.002 }
];

const fallbackInflationData = [
  { month: 'Oct', CPI: 12.1, FX: 10.3 },
  { month: 'Nov', CPI: 13.2, FX: 12.5 },
  { month: 'Dec', CPI: 22.6, FX: 18.9 },
  { month: 'Jan', CPI: 20.3, FX: 17.5 },
  { month: 'Feb', CPI: 14.8, FX: 11.2 },
  { month: 'Mar', CPI: 11.9, FX: 9.4 }
];

const Home = () => {
  const navigate = useNavigate();
  const [exchangeRate, setExchangeRate] = useState(null);
  const [rateSeries, setRateSeries] = useState(fallbackExchangeData);
  const [formState, setFormState] = useState('idle'); // idle | pending
  const [formData, setFormData] = useState({ name: '', email: '' });

  useEffect(() => {
    const fetchRates = async () => {
      try {
        const today = new Date();
        const isoToday = today.toISOString().slice(0, 10);
        const past = new Date(today);
        past.setMonth(past.getMonth() - 5);
        const isoPast = past.toISOString().slice(0, 10);

        const res = await fetch(
          `https://api.exchangerate.host/timeseries?start_date=${isoPast}&end_date=${isoToday}&base=ARS&symbols=USD`
        );
        if (!res.ok) throw new Error('Network error');
        const data = await res.json();
        const series = Object.entries(data.rates || {}).map(
          ([date, value]) => ({
            date: new Date(date).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric'
            }),
            rate: value.USD
          })
        );
        if (series.length) {
          setRateSeries(series);
          const latest = series[series.length - 1];
          setExchangeRate(latest.rate);
        }
      } catch (error) {
        setRateSeries(fallbackExchangeData);
        setExchangeRate(fallbackExchangeData[fallbackExchangeData.length - 1].rate);
      }
    };
    fetchRates();
  }, []);

  const handleSubmit = (event) => {
    event.preventDefault();
    setFormState('pending');
  };

  const handleConfirm = () => {
    navigate('/thank-you', { state: { source: 'trial' } });
  };

  const formattedRate = useMemo(() => {
    if (typeof exchangeRate !== 'number') return 'Loading…';
    return `ARS 1 = USD ${exchangeRate.toFixed(4)}`;
  }, [exchangeRate]);

  return (
    <>
      <Seo
        title="Tu Progreso Hoy | Inflation Intelligence & Personal Finance Learning"
        description="Track ARS to USD movements, interpret Argentina’s inflation signals, and accelerate your personal finance skills with Tu Progreso Hoy."
        path="/"
        image="https://picsum.photos/id/1027/1200/630"
      />
      <section
        className="section"
        aria-labelledby="hero-heading"
        style={{
          paddingTop: '2rem'
        }}
      >
        <div
          className="container hero"
          style={{
            backgroundImage: 'url("https://picsum.photos/id/1027/1200/600")',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        >
          <div className="flag-overlay" aria-hidden="true" />
          <div className="hero-content">
            <span className="tagline">Argentina · Educational SaaS</span>
            <h1 id="hero-heading">
              Navigate Inflation, Empower Your Personal Finance Decisions
            </h1>
            <p>
              Tu Progreso Hoy translates complex inflation data into actionable
              lessons tailored for Argentine learners preparing their budgets in
              ARS and USD. Datos verificados para planificar tu presupuesto.
            </p>
            <div className="hero-actions">
              <button
                className="btn btn-primary"
                onClick={() => document.getElementById('trial-form')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Request Your Free Trial Lesson
              </button>
              <button
                className="btn btn-outline"
                onClick={() => navigate('/inflation')}
              >
                Explore Inflation Dashboard
              </button>
            </div>
            <p className="language-hint">
              Plataforma educativa con datos esenciales, sin asesoría financiera
              directa.
            </p>
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="promise-heading">
        <div className="container">
          <div className="section-header">
            <span className="badge">Our promise</span>
            <h2 id="promise-heading">Data-Driven Learning for Argentina&apos;s Reality</h2>
            <p>
              We combine live ARS→USD analytics with foundational personal
              finance micro-courses so you can plan across currencies with
              clarity and confidence.
            </p>
          </div>
          <div className="grid grid-3">
            <article className="card" role="article">
              <img
                src="https://picsum.photos/id/1039/600/360"
                alt="Data dashboard visualization"
              />
              <h3>Trusted Inflation Insights</h3>
              <p>
                Our CPI tracker and FX monitor place Argentina&apos;s data in
                context, helping learners interpret monthly shifts responsibly.
              </p>
            </article>
            <article className="card" role="article">
              <img
                src="https://picsum.photos/id/1050/600/360"
                alt="Instructor guiding a learner online"
              />
              <h3>Interactive Learning Journeys</h3>
              <p>
                Experience bilingual modules, practice scenarios, and live
                cohort sessions crafted for professionals and students alike.
              </p>
            </article>
            <article className="card" role="article">
              <img
                src="https://picsum.photos/id/1062/600/360"
                alt="Team collaborating over financial data"
              />
              <h3>Community & Accountability</h3>
              <p>
                Participate in moderated circles where peers exchange budgeting
                tactics, track progress, and uphold informed decision-making.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="tracker-heading">
        <div className="container">
          <div className="grid" style={{ gap: '2.8rem' }}>
            <div>
              <span className="badge">ARS→USD Tracker</span>
              <h2 id="tracker-heading">Live Conversion Lens</h2>
              <p>
                Stay on top of Argentina&apos;s peso movements against the US
                dollar. We translate FX volatility into digestible insights,
                ensuring every learner understands the macro signals before
                making personal finance decisions.
              </p>
              <div className="card" aria-live="polite">
                <h3 style={{ marginTop: 0 }}>Latest Spot Rate</h3>
                <p
                  style={{
                    fontSize: '1.8rem',
                    fontWeight: 700,
                    fontFamily: 'DM Sans, sans-serif'
                  }}
                >
                  {formattedRate}
                </p>
                <p style={{ color: 'rgba(15,23,42,0.7)' }}>
                  Data courtesy of exchangerate.host. Updated intraday; slight
                  delays may occur.
                </p>
              </div>
            </div>
            <div className="card" role="figure" aria-label="ARS to USD historical chart">
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={rateSeries}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis dataKey="date" stroke="#64748B" />
                  <YAxis stroke="#64748B" domain={['auto', 'auto']} />
                  <Tooltip
                    contentStyle={{
                      borderRadius: '12px',
                      border: 'none',
                      boxShadow: '0 10px 25px rgba(15, 23, 42, 0.18)'
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="rate"
                    stroke="#2563EB"
                    strokeWidth={3}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="insight-heading">
        <div className="container">
          <div className="section-header">
            <span className="badge">Analytics meets education</span>
            <h2 id="insight-heading">Monthly Insight Snapshots</h2>
            <p>
              From CPI surprises to exchange-rate adjustments, our analysts
              translate raw data into narratives that fuel better course
              outcomes and personal budgeting choices.
            </p>
          </div>
          <div className="grid grid-2">
            <div className="card">
              <ResponsiveContainer width="100%" height={260}>
                <AreaChart data={fallbackInflationData}>
                  <defs>
                    <linearGradient id="cpi" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2563EB" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#2563EB" stopOpacity={0.1} />
                    </linearGradient>
                    <linearGradient id="fx" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10B981" stopOpacity={0.7} />
                      <stop offset="95%" stopColor="#10B981" stopOpacity={0.05} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="month" stroke="#64748B" />
                  <YAxis stroke="#64748B" />
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <Tooltip
                    contentStyle={{
                      borderRadius: '12px',
                      border: 'none',
                      boxShadow: '0 10px 25px rgba(15, 23, 42, 0.18)'
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="CPI"
                    stroke="#2563EB"
                    fillOpacity={1}
                    fill="url(#cpi)"
                    name="Monthly CPI %"
                  />
                  <Area
                    type="monotone"
                    dataKey="FX"
                    stroke="#10B981"
                    fillOpacity={1}
                    fill="url(#fx)"
                    name="ARS→USD %"
                  />
                </AreaChart>
              </ResponsiveContainer>
              <p style={{ marginTop: '1rem' }}>
                Discover how CPI and FX dynamics interact to shape day-to-day
                purchasing power in Buenos Aires. Cada gráfico viene con
                contexto editorial bilingüe.
              </p>
            </div>
            <div className="card">
              <h3>Course Preview</h3>
              <ul style={{ paddingLeft: '1.1rem', margin: '1rem 0' }}>
                <li>Inflation decoding masterclass with real datasets</li>
                <li>Budgeting playbook: pesos today, dollars tomorrow</li>
                <li>Scenario planning lab for Argentine households</li>
              </ul>
              <blockquote>
                “Tu Progreso Hoy me permitió entender cómo la inflación impacta
                mis objetivos. Aprendí a tomar decisiones informadas.” — Mara,
                Buenos Aires
              </blockquote>
              <button
                className="btn btn-primary"
                onClick={() => navigate('/course')}
              >
                View Complete Syllabus
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="section" id="trial-form" aria-labelledby="trial-heading">
        <div className="container">
          <div className="grid" style={{ gap: '2.5rem' }}>
            <div>
              <span className="badge">Start today</span>
              <h2 id="trial-heading">Claim a Free Trial Lesson</h2>
              <p>
                Enter the double opt-in process to receive our onboarding kit,
                featuring a guided walkthrough of the inflation dashboard and a
                personal finance primer. You will receive a confirmation email
                first — only after you confirm will we schedule your session.
              </p>
              <img
                src="https://picsum.photos/id/1070/640/400"
                alt="Learners studying with digital devices"
              />
            </div>
            <div className="card" role="form">
              <form className="form" onSubmit={handleSubmit}>
                <div>
                  <label htmlFor="trial-name">Full name</label>
                  <input
                    id="trial-name"
                    name="name"
                    type="text"
                    required
                    autoComplete="name"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, name: e.target.value }))
                    }
                  />
                </div>
                <div>
                  <label htmlFor="trial-email">Email</label>
                  <input
                    id="trial-email"
                    name="email"
                    type="email"
                    required
                    autoComplete="email"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, email: e.target.value }))
                    }
                  />
                </div>
                <div>
                  <label htmlFor="trial-goal">Primary learning goal</label>
                  <select
                    id="trial-goal"
                    name="goal"
                    defaultValue="inflation-tracking"
                    aria-label="Primary learning goal"
                  >
                    <option value="inflation-tracking">Inflation tracking</option>
                    <option value="currency-planning">Currency planning</option>
                    <option value="budgeting">Household budgeting</option>
                    <option value="professional">Professional development</option>
                  </select>
                </div>
                {formState === 'idle' && (
                  <button type="submit" className="btn btn-primary">
                    Send confirmation email
                  </button>
                )}
              </form>
              {formState === 'pending' && (
                <div
                  className="alert alert-info"
                  style={{ marginTop: '1.2rem' }}
                  role="status"
                  aria-live="polite"
                >
                  We just sent a confirmation email to {formData.email}. Please
                  confirm your subscription to unlock the trial. If you already
                  confirmed, click below.
                  <button
                    className="btn btn-primary"
                    type="button"
                    style={{ marginTop: '1rem' }}
                    onClick={handleConfirm}
                  >
                    I Confirmed My Email
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <section
        className="section"
        style={{ paddingBottom: '4rem' }}
        aria-labelledby="testimonial-heading"
      >
        <div className="container">
          <div className="section-header">
            <h2 id="testimonial-heading">Voices from Our Learners</h2>
            <p>
              Professionals, entrepreneurs, and students across Argentina rely
              on Tu Progreso Hoy for clarity during inflation cycles.
            </p>
          </div>
          <div className="grid grid-3">
            {[
              {
                name: 'Lucía Fernández',
                role: 'Marketing Lead, Córdoba',
                quote:
                  'La combinación de datos y educación me ayudó a anticipar gastos en dólares sin perder de vista mis ingresos en pesos.'
              },
              {
                name: 'Tomás Ibáñez',
                role: 'Software Engineer, Buenos Aires',
                quote:
                  'The dashboards are sharp, the lessons are pragmatic, and every insight is grounded in verified public data.'
              },
              {
                name: 'Carina Soler',
                role: 'Founder, Mendoza',
                quote:
                  'Aprendí a modelar escenarios realistas para mi emprendimiento. Las herramientas son accesibles y accionables.'
              }
            ].map((item) => (
              <div className="card" key={item.name}>
                <p style={{ fontStyle: 'italic' }}>&ldquo;{item.quote}&rdquo;</p>
                <p style={{ fontWeight: 600, marginBottom: 0 }}>{item.name}</p>
                <p style={{ color: 'rgba(15,23,42,0.65)', marginTop: '0.2rem' }}>
                  {item.role}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;