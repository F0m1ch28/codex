import React from 'react';
import Seo from '../components/Seo';

const Terms = () => (
  <>
    <Seo
      title="Terms of Use | Tu Progreso Hoy"
      description="Understand the terms governing access to Tu Progreso Hoy’s educational SaaS."
      path="/terms"
      image="https://picsum.photos/id/670/1200/630"
    />
    <section className="section" aria-labelledby="terms-heading">
      <div className="container">
        <div className="section-header">
          <h1 id="terms-heading">Terms of Use</h1>
          <p>Effective date: March 2024</p>
        </div>
        <div className="card" style={{ lineHeight: 1.8 }}>
          <h2>1. Acceptance</h2>
          <p>
            By accessing Tu Progreso Hoy, you agree to these Terms. If you disagree, please discontinue use.
          </p>
          <h2>2. Educational Purpose</h2>
          <p>
            All content is intended for educational purposes only. We do not offer financial, investment, or legal advice.
          </p>
          <h2>3. Accounts & Access</h2>
          <p>
            Users must complete a double opt-in process. You are responsible for maintaining account credentials.
          </p>
          <h2>4. Intellectual Property</h2>
          <p>
            All materials, including datasets, videos, and guides, are owned by Tu Progreso Hoy. You may not redistribute without permission.
          </p>
          <h2>5. Acceptable Use</h2>
          <ul>
            <li>Do not exploit the platform to promote speculative schemes.</li>
            <li>Do not attempt to extract or resell proprietary datasets.</li>
            <li>Respect community guidelines in live sessions and forums.</li>
          </ul>
          <h2>6. Limitation of Liability</h2>
          <p>
            Tu Progreso Hoy is not liable for decisions you make based on educational materials. Use professional advice for financial actions.
          </p>
          <h2>7. Termination</h2>
          <p>
            We may suspend access if Terms are violated. You may cancel at any time by contacting our support team.
          </p>
          <h2>8. Governing Law</h2>
          <p>
            These Terms are governed by the laws of Argentina. Disputes are subject to the courts of Buenos Aires.
          </p>
          <h2>9. Updates</h2>
          <p>
            We may revise these Terms periodically. Continued use signifies acceptance of changes.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default Terms;