import React from 'react';
import Seo from '../components/Seo';

const Privacy = () => (
  <>
    <Seo
      title="Privacy Policy | Tu Progreso Hoy"
      description="Read the privacy policy governing the educational services of Tu Progreso Hoy."
      path="/privacy"
      image="https://picsum.photos/id/650/1200/630"
    />
    <section className="section" aria-labelledby="privacy-heading">
      <div className="container">
        <div className="section-header">
          <h1 id="privacy-heading">Privacy Policy</h1>
          <p>Last updated: March 2024</p>
        </div>
        <div className="card" style={{ lineHeight: 1.8 }}>
          <h2>1. Introduction</h2>
          <p>
            Tu Progreso Hoy (&quot;we&quot;, &quot;us&quot;, or &quot;our&quot;) operates educational
            services accessible through tuprogresohoy.com. This Privacy Policy describes how we collect, use,
            disclose, and safeguard your information.
          </p>
          <h2>2. Information We Collect</h2>
          <p>
            We collect information you voluntarily provide via forms, including name, email address, organization, and
            learning goals. Our systems also log analytical metadata (with your consent) such as pages visited and
            device type to improve content relevancy.
          </p>
          <h2>3. How We Use Information</h2>
          <ul>
            <li>Deliver educational content and account features.</li>
            <li>Send confirmation emails as part of our double opt-in workflow.</li>
            <li>Analyze anonymized usage trends to improve curriculum design.</li>
            <li>Communicate updates about courses and resources.</li>
          </ul>
          <h2>4. Data Retention</h2>
          <p>
            Personal data is retained for the duration of your learning relationship, after which it is deleted or
            anonymized within 18 months unless legally required otherwise.
          </p>
          <h2>5. Sharing of Information</h2>
          <p>
            We do not sell personal information. We may share limited data with trusted processors providing hosting,
            email delivery, or analytics services under confidentiality agreements.
          </p>
          <h2>6. International Transfers</h2>
          <p>
            As an Argentina-based company, we host data within the region when feasible. Some processors may operate in
            other jurisdictions, and we ensure appropriate safeguards are in place.
          </p>
          <h2>7. Your Rights</h2>
          <p>
            You may request access, correction, or deletion of your personal data by contacting info@tuprogresohoy.com.
            Argentine residents also have rights under Ley 25.326.
          </p>
          <h2>8. Cookies</h2>
          <p>
            Cookies are only activated after your opt-in via our cookie banner. For details, review our Cookie Policy.
          </p>
          <h2>9. Contact</h2>
          <p>
            Tu Progreso Hoy — Av. 9 de Julio 1000, Buenos Aires. Email: info@tuprogresohoy.com. Phone: +54 11 5555-1234.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default Privacy;