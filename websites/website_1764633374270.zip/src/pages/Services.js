import React from 'react';
import { NavLink } from 'react-router-dom';
import Seo from '../components/Seo';

const Services = () => (
  <>
    <Seo
      title="Services | Tu Progreso Hoy Educational SaaS"
      description="Discover Tu Progreso Hoy services: inflation intelligence dashboards, guided finance curriculum, and enterprise enablement."
      path="/services"
      image="https://picsum.photos/id/300/1200/630"
    />
    <section className="section">
      <div
        className="container hero"
        style={{
          backgroundImage: 'url("https://picsum.photos/id/300/1200/600")',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="hero-content">
          <h1>Premium Educational Services for Inflation Awareness</h1>
          <p>
            From self-guided learners to enterprise cohorts, Tu Progreso Hoy
            delivers structured educational journeys rooted in Argentina&apos;s
            economic landscape.
          </p>
        </div>
      </div>
    </section>

    <section className="section" aria-labelledby="service-heading">
      <div className="container">
        <div className="grid grid-2">
          <div className="card">
            <h2 id="service-heading">Platform Tiers</h2>
            <p>
              Choose the service tier that aligns with your organization or
              personal growth goals. Each tier includes bilingual support and
              double opt-in compliance.
            </p>
            <table className="table table-striped" aria-label="Service tiers">
              <thead>
                <tr>
                  <th>Tier</th>
                  <th>Highlights</th>
                  <th>Ideal for</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Insight</td>
                  <td>Inflation dashboards, weekly briefs, community forums</td>
                  <td>Individuals building financial literacy</td>
                </tr>
                <tr>
                  <td>Navigator</td>
                  <td>Full course access, live mentor sessions, bilingual labs</td>
                  <td>Professionals & university cohorts</td>
                </tr>
                <tr>
                  <td>Enterprise</td>
                  <td>Custom analytics, leader training, compliance workflows</td>
                  <td>Companies & NGOs scaling programs in Argentina</td>
                </tr>
              </tbody>
            </table>
          </div>
          <img
            src="https://picsum.photos/id/1084/900/600"
            alt="Person catching data points"
          />
        </div>
      </div>
    </section>

    <section className="section" aria-labelledby="feature-heading">
      <div className="container">
        <div className="section-header">
          <h2 id="feature-heading">Key Capabilities</h2>
        </div>
        <div className="grid grid-3">
          <div className="card">
            <h3>Inflation Dashboards</h3>
            <p>
              Interactive visualizations covering CPI variations, parallel FX
              benchmarks, and sector-specific price movements.
            </p>
          </div>
          <div className="card">
            <h3>Learning Sprints</h3>
            <p>
              Four-week guided programs blending self-study, quizzes, and live
              cohort discussions to reinforce personal finance strategies.
            </p>
          </div>
          <div className="card">
            <h3>Enterprise Enablement</h3>
            <p>
              Dedicated analyst hours, custom scenario modeling, and HR-friendly
              dashboards to track learning adoption.
            </p>
          </div>
        </div>
        <div
          className="card"
          style={{
            marginTop: '3rem',
            backgroundImage: 'url("https://picsum.photos/id/1091/1200/500")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            color: '#fff',
            minHeight: '220px'
          }}
        >
          <div style={{ backdropFilter: 'blur(6px)', padding: '2rem', borderRadius: '16px' }}>
            <h3>Need a tailored solution?</h3>
            <p>
              Reach out to co-design bilingual curricula and data packs for your
              teams. We align with compliance requirements while maintaining an
              educational focus.
            </p>
            <NavLink className="btn btn-primary" to="/contact">
              Book a discovery call
            </NavLink>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Services;