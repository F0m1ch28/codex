import React from 'react';
import { NavLink } from 'react-router-dom';
import Seo from '../components/Seo';

const NotFound = () => (
  <>
    <Seo
      title="Page Not Found | Tu Progreso Hoy"
      description="The page you were looking for could not be found on Tu Progreso Hoy."
      path="/404"
      image="https://picsum.photos/id/740/1200/630"
    />
    <section className="section">
      <div className="container card" style={{ textAlign: 'center' }}>
        <h1>404 — Página no encontrada</h1>
        <p>
          We searched across our educational hubs but couldn&apos;t find the page
          you requested.
        </p>
        <NavLink className="btn btn-primary" to="/">
          Back to Home
        </NavLink>
      </div>
    </section>
  </>
);

export default NotFound;