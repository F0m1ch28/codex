import React from 'react';
import Seo from '../components/Seo';

const resources = [
  {
    title: 'Interpreting Argentina’s CPI Prints',
    summary: 'A guide to the sources, composition, and monthly rhythms of CPI.',
    language: 'English',
    link: '#'
  },
  {
    title: 'Glosario esencial para inflación y finanzas personales',
    summary: 'Términos clave en español para entender reportes y simulaciones.',
    language: 'Español',
    link: '#'
  },
  {
    title: 'ARS→USD Hedging Basics for Households',
    summary: 'Educational scenarios outlining risk-aware conversion strategies.',
    language: 'English',
    link: '#'
  },
  {
    title: 'Presupuestos flexibles en contextos inflacionarios',
    summary: 'Cómo adaptar categorías de gastos sin perder visibilidad del flujo.',
    language: 'Español',
    link: '#'
  }
];

const Resources = () => (
  <>
    <Seo
      title="Resources Library | Tu Progreso Hoy"
      description="Browse bilingual articles, glossaries, and guides from Tu Progreso Hoy to deepen your inflation and personal finance knowledge."
      path="/resources"
      image="https://picsum.photos/id/450/1200/630"
    />
    <section className="section">
      <div
        className="container hero"
        style={{
          backgroundImage: 'url("https://picsum.photos/id/450/1200/600")',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="hero-content">
          <h1>Bilingual Resources Library</h1>
          <p>
            Explore curated readings, glossaries, and explainers in English and
            Spanish designed for learners across Argentina.
          </p>
        </div>
      </div>
    </section>

    <section className="section" aria-labelledby="resource-heading">
      <div className="container">
        <div className="grid">
          {resources.map((resource) => (
            <article className="card" key={resource.title}>
              <h3>{resource.title}</h3>
              <p>{resource.summary}</p>
              <p>
                <strong>Language:</strong> {resource.language}
              </p>
              <a href={resource.link} className="btn btn-outline">
                Access resource
              </a>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Resources;