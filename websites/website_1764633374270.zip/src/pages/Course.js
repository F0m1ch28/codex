import React from 'react';
import { useNavigate } from 'react-router-dom';
import Seo from '../components/Seo';

const modules = [
  {
    title: 'Module 1 — Inflation Anatomy',
    description: 'Dissect CPI components, leading indicators, and historical cycles.',
  },
  {
    title: 'Module 2 — Currency Planning Across ARS & USD',
    description: 'Learn to build buffers, model conversions, and contextualize FX trends.',
  },
  {
    title: 'Module 3 — Personal Budget Architecture',
    description: 'Design envelopes and cash flow maps resilient to price shifts.',
  },
  {
    title: 'Module 4 — Scenario Labs & Peer Review',
    description: 'Test your plan in interactive labs guided by Tu Progreso Hoy mentors.'
  }
];

const Course = () => {
  const navigate = useNavigate();
  return (
    <>
      <Seo
        title="Course Syllabus | Tu Progreso Hoy"
        description="Explore the Tu Progreso Hoy personal finance course syllabus blending ARS inflation insights with practical budgeting skills."
        path="/course"
        image="https://picsum.photos/id/400/1200/630"
      />
      <section className="section">
        <div
          className="container hero"
          style={{
            backgroundImage: 'url("https://picsum.photos/id/400/1200/600")',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        >
          <div className="hero-content">
            <h1>Your Bilingual Personal Finance Course</h1>
            <p>
              Our 8-week program fuses data literacy with applied finance
              strategies. Spanish and English sessions ensure inclusive access.
            </p>
            <div className="hero-actions">
              <button className="btn btn-primary" onClick={() => navigate('/contact')}>
                Secure your cohort seat
              </button>
              <button className="btn btn-outline" onClick={() => navigate('/resources')}>
                Download sample materials
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="syllabus-heading">
        <div className="container">
          <div className="section-header">
            <h2 id="syllabus-heading">Syllabus at a Glance</h2>
            <p>
              Each module blends asynchronous lessons with live debriefs in small
              groups. Activities emphasize decision-making in inflationary settings.
            </p>
          </div>
          <div className="grid">
            {modules.map((module) => (
              <div className="card" key={module.title}>
                <h3>{module.title}</h3>
                <p>{module.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="audience-heading">
        <div className="container">
          <div className="grid grid-2">
            <div>
              <span className="badge">Who attends?</span>
              <h2 id="audience-heading">Designed for Argentine Professionals & Students</h2>
              <ul style={{ paddingLeft: '1rem' }}>
                <li>Young professionals budgeting across multiple currencies</li>
                <li>Entrepreneurs tracking supply cost volatility</li>
                <li>University students building financial agency</li>
              </ul>
              <p>
                All participants complete a diagnostic and opt in twice to confirm
                their commitment, keeping cohorts engaged and participative.
              </p>
            </div>
            <img
              src="https://picsum.photos/id/1080/900/600"
              alt="Group workshop session"
            />
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="cta-course">
        <div className="container card" style={{ textAlign: 'center' }}>
          <h2 id="cta-course">Ready for the next cohort?</h2>
          <p>
            Submit your interest via our contact form. We follow a double opt-in
            process before unlocking onboarding materials.
          </p>
          <button className="btn btn-primary" onClick={() => navigate('/contact')}>
            Talk to our admissions team
          </button>
        </div>
      </section>
    </>
  );
};

export default Course;