import React from 'react';
import Seo from '../components/Seo';

const teamMembers = [
  {
    name: 'Valentina Ruiz',
    role: 'Head of Curriculum',
    bio: 'Former university lecturer focused on financial literacy for Latin America.',
    img: 'https://picsum.photos/id/501/300/300'
  },
  {
    name: 'Rodrigo Álvarez',
    role: 'Chief Data Officer',
    bio: 'Economist specializing in inflation modeling and FX risk analysis.',
    img: 'https://picsum.photos/id/502/300/300'
  },
  {
    name: 'Emily Watson',
    role: 'Learning Experience Designer',
    bio: 'Crafts bilingual journeys blending data, storytelling, and practical exercises.',
    img: 'https://picsum.photos/id/503/300/300'
  }
];

const About = () => (
  <>
    <Seo
      title="About Tu Progreso Hoy | Mission, Team & Values"
      description="Meet the Tu Progreso Hoy team, born in Buenos Aires to transform inflation data into meaningful educational experiences."
      path="/about"
      image="https://picsum.photos/id/200/1200/630"
    />
    <section className="section">
      <div
        className="container hero"
        style={{
          backgroundImage: 'url("https://picsum.photos/id/200/1200/600")',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="hero-content">
          <h1>Our Story Begins with Argentina&apos;s Economic Pulse</h1>
          <p>
            Tu Progreso Hoy emerged from the need to decode inflation trends for
            everyday citizens. Our founders blended decades of macroeconomic
            research with modern learning design, delivering an educational SaaS
            built in Buenos Aires for Argentines everywhere.
          </p>
        </div>
      </div>
    </section>

    <section className="section" aria-labelledby="mission-heading">
      <div className="container">
        <div className="grid" style={{ gap: '3rem' }}>
          <div>
            <span className="badge">Mission</span>
            <h2 id="mission-heading">Educating with Accountability</h2>
            <p>
              We are committed to democratizing access to inflation intelligence
              without ever offering direct financial advice. Our platform
              empowers communities to interpret price level shifts and craft
              personal finance plans with nuance and diligence.
            </p>
            <div className="timeline" aria-label="Milestones timeline">
              <div className="timeline-item">
                <strong>2020 — Conceptualization.</strong> We interviewed 150+
                professionals across Argentina about their struggles navigating
                inflation.
              </div>
              <div className="timeline-item">
                <strong>2021 — MVP launch.</strong> Introduced the first
                inflation dashboard bilingual content library.
              </div>
              <div className="timeline-item">
                <strong>2023 — SaaS expansion.</strong> Added cohort-based
                courses and interactive simulations to the platform.
              </div>
            </div>
          </div>
          <div>
            <img
              src="https://picsum.photos/id/1043/800/600"
              alt="Buenos Aires skyline at dusk"
            />
          </div>
        </div>
      </div>
    </section>

    <section className="section" aria-labelledby="values-heading">
      <div className="container">
        <div className="section-header">
          <span className="badge">Values</span>
          <h2 id="values-heading">Grounded in Transparency and Empathy</h2>
          <p>
            Cada decisión didáctica equilibra rigor técnico con cercanía humana.
            We design learning experiences that respect users&apos; diversity in
            financial knowledge and backgrounds.
          </p>
        </div>
        <div className="grid grid-3">
          <div className="card">
            <h3>Evidence-first</h3>
            <p>
              Our datasets use trusted public sources and undergo quality checks
              before entering the learning environment.
            </p>
          </div>
          <div className="card">
            <h3>Bilingual accessibility</h3>
            <p>
              Content is produced in English and Spanish (es-AR) to keep
              learners confident regardless of language preference.
            </p>
          </div>
          <div className="card">
            <h3>Community impact</h3>
            <p>
              We collaborate with universities and NGOs to expand financial
              literacy programs across Argentina.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className="section" aria-labelledby="team-heading">
      <div className="container">
        <div className="section-header">
          <h2 id="team-heading">Meet the Team</h2>
          <p>
            Our founders and advisors combine economic research, pedagogy, and
            product design to deliver a premium learning experience.
          </p>
        </div>
        <div className="grid grid-3">
          {teamMembers.map((member) => (
            <div className="card" key={member.name}>
              <img src={member.img} alt={`${member.name} portrait`} />
              <h3>{member.name}</h3>
              <p style={{ fontWeight: 600 }}>{member.role}</p>
              <p>{member.bio}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default About;