import React from 'react';
import Seo from '../components/Seo';

const faqs = [
  {
    question: 'Is Tu Progreso Hoy a financial advisor?',
    answer:
      'No. Tu Progreso Hoy is an educational SaaS. We offer courses, dashboards, and resources to help you understand inflation data responsibly.'
  },
  {
    question: 'How do I access Spanish materials?',
    answer:
      'Every module, dashboard annotation, and resource has an es-AR version. You can toggle language within the platform interface.'
  },
  {
    question: 'What is the double opt-in process?',
    answer:
      'After submitting any form, you receive a confirmation email. Only when you click the confirmation link do we grant access to learning assets.'
  },
  {
    question: 'Can companies enroll multiple learners?',
    answer:
      'Yes. Our enterprise tier includes admin dashboards, progress tracking, and custom onboarding for your teams.'
  },
  {
    question: 'How are datasets updated?',
    answer:
      'We pull from official sources and reconcile anomalies weekly. Updates are logged with timestamps and context notes.'
  }
];

const FAQ = () => (
  <>
    <Seo
      title="Frequently Asked Questions | Tu Progreso Hoy"
      description="Find answers about Tu Progreso Hoy's educational services, language options, and data updates."
      path="/faq"
      image="https://picsum.photos/id/550/1200/630"
    />
    <section className="section">
      <div
        className="container hero"
        style={{
          backgroundImage: 'url("https://picsum.photos/id/550/1200/600")',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="hero-content">
          <h1>Frequently Asked Questions</h1>
          <p>Everything you need to know before enrolling with Tu Progreso Hoy.</p>
        </div>
      </div>
    </section>

    <section className="section" aria-labelledby="faq-heading">
      <div className="container">
        <div className="section-header">
          <h2 id="faq-heading">Common Topics</h2>
        </div>
        <div className="accordion">
          {faqs.map((item) => (
            <details key={item.question}>
              <summary>{item.question}</summary>
              <div>{item.answer}</div>
            </details>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default FAQ;