import React, { useState } from 'react';
import Seo from '../components/Seo';

const Contact = () => {
  const [formState, setFormState] = useState('idle'); // idle | pending | confirmed
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    organization: '',
    message: ''
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    setFormState('pending');
  };

  const handleConfirm = () => {
    setFormState('confirmed');
  };

  return (
    <>
      <Seo
        title="Contact Tu Progreso Hoy | Buenos Aires HQ"
        description="Connect with Tu Progreso Hoy. Visit us on Av. 9 de Julio, Buenos Aires or schedule a discovery call for our educational SaaS."
        path="/contact"
        image="https://picsum.photos/id/500/1200/630"
      />
      <section className="section">
        <div
          className="container hero"
          style={{
            backgroundImage: 'url("https://picsum.photos/id/500/1200/600")',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        >
          <div className="hero-content">
            <h1>Let&apos;s Build Your Learning Roadmap</h1>
            <p>
              Reach our bilingual support team in Buenos Aires for cohort
              admissions, enterprise enablement, or partnership opportunities.
            </p>
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="contact-heading">
        <div className="container">
          <div className="grid grid-2">
            <div>
              <h2 id="contact-heading">Contact details</h2>
              <p>
                <strong>Address:</strong> Av. 9 de Julio 1000, Buenos Aires, AR
              </p>
              <p>
                <strong>Email:</strong>{' '}
                <a href="mailto:info@tuprogresohoy.com">
                  info@tuprogresohoy.com
                </a>
              </p>
              <p>
                <strong>Phone:</strong>{' '}
                <a href="tel:+541155551234">+54 11 5555-1234</a>
              </p>
              <div className="map-wrapper" aria-label="Map to Tu Progreso Hoy office">
                <iframe
                  title="Tu Progreso Hoy Buenos Aires"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.368422157875!2d-58.38414568476862!3d-34.59685408046162!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccaa23c631f31%3A0x6e1b6a4d90ec59d3!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1700000000000"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  aria-hidden="false"
                />
              </div>
            </div>
            <div className="card">
              <h2>Write to us</h2>
              <form className="form" onSubmit={handleSubmit}>
                <div>
                  <label htmlFor="contact-name">Name</label>
                  <input
                    id="contact-name"
                    name="name"
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, name: e.target.value }))
                    }
                  />
                </div>
                <div>
                  <label htmlFor="contact-email">Email</label>
                  <input
                    id="contact-email"
                    name="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, email: e.target.value }))
                    }
                  />
                </div>
                <div>
                  <label htmlFor="contact-org">Organization (optional)</label>
                  <input
                    id="contact-org"
                    name="organization"
                    type="text"
                    value={formData.organization}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, organization: e.target.value }))
                    }
                  />
                </div>
                <div>
                  <label htmlFor="contact-message">Message</label>
                  <textarea
                    id="contact-message"
                    name="message"
                    rows="4"
                    required
                    value={formData.message}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, message: e.target.value }))
                    }
                  />
                </div>
                {formState === 'idle' && (
                  <button type="submit" className="btn btn-primary">
                    Send confirmation email
                  </button>
                )}
              </form>
              {formState === 'pending' && (
                <div
                  className="alert alert-info"
                  role="status"
                  aria-live="polite"
                  style={{ marginTop: '1.2rem' }}
                >
                  Thanks {formData.name}! Check {formData.email} for a confirmation
                  link. Once you confirm, click below.
                  <button
                    className="btn btn-primary"
                    type="button"
                    style={{ marginTop: '1rem' }}
                    onClick={handleConfirm}
                  >
                    I confirmed my email
                  </button>
                </div>
              )}
              {formState === 'confirmed' && (
                <div
                  className="alert alert-success"
                  role="status"
                  aria-live="polite"
                  style={{ marginTop: '1.2rem' }}
                >
                  Confirmation received. Our team will respond within one business
                  day from Buenos Aires.
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;