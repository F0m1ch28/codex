import React from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Area,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import Seo from '../components/Seo';

const cpiSeries = [
  { month: 'Oct 23', cpi: 12.1, fx: 10.3, salaries: 6.8 },
  { month: 'Nov 23', cpi: 13.2, fx: 12.5, salaries: 7.1 },
  { month: 'Dec 23', cpi: 22.6, fx: 18.9, salaries: 8.4 },
  { month: 'Jan 24', cpi: 20.3, fx: 17.5, salaries: 10.2 },
  { month: 'Feb 24', cpi: 14.8, fx: 11.2, salaries: 9.8 },
  { month: 'Mar 24', cpi: 11.9, fx: 9.4, salaries: 11.4 }
];

const Inflation = () => (
  <>
    <Seo
      title="Inflation Methodology | Tu Progreso Hoy"
      description="Understand our inflation methodology, data sourcing, and interpretive context for Argentine CPI and ARS→USD movements."
      path="/inflation"
      image="https://picsum.photos/id/210/1200/630"
    />
    <section className="section">
      <div
        className="container hero"
        style={{
          backgroundImage: 'url("https://picsum.photos/id/210/1200/600")',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="hero-content">
          <h1>Inflation Intelligence Dashboard Methodology</h1>
          <p>
            Tu Progreso Hoy integrates CPI, wage, and FX data streams to provide
            a holistic view of Argentina&apos;s inflation trends. Every chart is
            paired with educational guidance so you can learn, not speculate.
          </p>
        </div>
      </div>
    </section>

    <section className="section" aria-labelledby="method-heading">
      <div className="container">
        <div className="section-header">
          <h2 id="method-heading">Methodology Summary</h2>
          <p>
            We prioritize transparency en la selección de fuentes. Datos oficiales
            del INDEC, BCRA y series complementarias se armonizan para una vista
            integral.
          </p>
        </div>
        <div className="grid grid-2">
          <div className="card">
            <h3>Data Sources</h3>
            <ul style={{ paddingLeft: '1rem' }}>
              <li>INDEC monthly CPI publications</li>
              <li>BCRA reference ARS→USD exchange rates</li>
              <li>Ministry of Labor wage index</li>
              <li>Subnational surveys for complementary context</li>
            </ul>
          </div>
          <div className="card">
            <h3>Quality Controls</h3>
            <ul style={{ paddingLeft: '1rem' }}>
              <li>Automated anomaly detection on time series</li>
              <li>Manual review by Tu Progreso Hoy analysts</li>
              <li>Version history tracked for every adjustment</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section className="section" aria-labelledby="chart-heading">
      <div className="container">
        <div className="card">
          <h2 id="chart-heading">CPI vs FX vs Salaries</h2>
          <ResponsiveContainer width="100%" height={360}>
            <ComposedChart data={cpiSeries}>
              <CartesianGrid stroke="#E2E8F0" strokeDasharray="3 3" />
              <XAxis dataKey="month" stroke="#64748B" />
              <YAxis yAxisId="left" stroke="#64748B" />
              <YAxis yAxisId="right" orientation="right" stroke="#94A3B8" />
              <Tooltip
                contentStyle={{
                  borderRadius: '12px',
                  border: 'none',
                  boxShadow: '0 10px 30px rgba(15, 23, 42, 0.18)'
                }}
              />
              <Area
                yAxisId="left"
                type="monotone"
                dataKey="cpi"
                fill="#2563EB"
                fillOpacity={0.2}
                stroke="#2563EB"
                strokeWidth={3}
                name="CPI %"
              />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="fx"
                stroke="#0EA5E9"
                strokeWidth={3}
                name="FX % change"
              />
              <Bar
                yAxisId="right"
                dataKey="salaries"
                barSize={24}
                fill="#10B981"
                name="Salary index %"
              />
            </ComposedChart>
          </ResponsiveContainer>
          <p style={{ marginTop: '1rem' }}>
            Interpretación: los picos de CPI y FX requieren estrategias de
            presupuesto informadas. Nuestros módulos guía explican cómo ajustar
            reservas en pesos frente a obligaciones en dólares.
          </p>
        </div>
      </div>
    </section>

    <section className="section" aria-labelledby="faq-inflation">
      <div className="container">
        <div className="section-header">
          <h2 id="faq-inflation">FAQ about Inflation</h2>
        </div>
        <div className="accordion">
          <details>
            <summary>How often is CPI data refreshed?</summary>
            <div>
              INDEC publishes CPI monthly. We update dashboards within 48 hours,
              with educational briefs explaining key drivers.
            </div>
          </details>
          <details>
            <summary>Do you include informal market exchange rates?</summary>
            <div>
              We surface official and widely referenced alternative FX series
              with clear labeling, ensuring learners understand context without
              turning insights into financial recommendations.
            </div>
          </details>
          <details>
            <summary>What should learners do if data diverges from reality?</summary>
            <div>
              We encourage learners to cross-check with local price diaries and
              share feedback in our community, enriching collective understanding.
            </div>
          </details>
        </div>
      </div>
    </section>
  </>
);

export default Inflation;