import React from 'react';
import Seo from '../components/Seo';

const Cookies = () => (
  <>
    <Seo
      title="Cookie Policy | Tu Progreso Hoy"
      description="Learn how Tu Progreso Hoy uses cookies and how you can control them."
      path="/cookies"
      image="https://picsum.photos/id/690/1200/630"
    />
    <section className="section" aria-labelledby="cookie-heading">
      <div className="container">
        <div className="section-header">
          <h1 id="cookie-heading">Cookie Policy</h1>
          <p>What you need to know about analytics cookies on Tu Progreso Hoy.</p>
        </div>
        <div className="card" style={{ lineHeight: 1.8 }}>
          <h2>1. Overview</h2>
          <p>
            Cookies help us understand how users engage with our educational services. We activate them only after you opt in.
          </p>
          <h2>2. Types of Cookies</h2>
          <ul>
            <li><strong>Essential:</strong> Required for authentication and session continuity.</li>
            <li><strong>Analytics:</strong> Optional; used to learn how modules perform and improve content.</li>
          </ul>
          <h2>3. Managing Preferences</h2>
          <p>
            Access the cookie banner or browser settings to update your consent at any time.
          </p>
          <h2>4. Third-Party Tools</h2>
          <p>
            We may use privacy-first analytics providers under data processing agreements. No personal financial data is collected.
          </p>
          <h2>5. Contact</h2>
          <p>
            Questions? Contact info@tuprogresohoy.com or call +54 11 5555-1234.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default Cookies;