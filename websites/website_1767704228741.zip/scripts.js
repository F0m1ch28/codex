document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.main-nav-list');

    if (navToggle && navList) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            navList.classList.toggle('is-open');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (!cookieBanner) return;

    const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
    const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
    const storedConsent = localStorage.getItem('siasConsent');

    if (storedConsent === 'accepted' || storedConsent === 'declined') {
        cookieBanner.classList.add('is-hidden');
    }

    const handleConsent = (status) => {
        localStorage.setItem('siasConsent', status);
        cookieBanner.classList.add('is-hidden');
    };

    if (acceptBtn) {
        acceptBtn.addEventListener('click', () => handleConsent('accepted'));
    }

    if (declineBtn) {
        declineBtn.addEventListener('click', () => handleConsent('declined'));
    }
});