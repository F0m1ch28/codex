import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiesPage.module.css';

const CookiesPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Politique de cookies | Education in Paris Review</title>
        <meta
          name="description"
          content="Information détaillée sur l’utilisation des cookies par Education in Paris Review."
        />
      </Helmet>

      <section className="container">
        <header className={styles.header}>
          <h1>Politique de cookies</h1>
        </header>
        <article className={styles.content}>
          <h2>Cookies nécessaires</h2>
          <p>
            Ces cookies assurent le fonctionnement technique du site (sécurité, accessibilité, chargement des pages). Ils sont actifs en permanence car indispensables.
          </p>

          <h2>Cookies analytiques</h2>
          <p>
            Les cookies analytiques sont facultatifs. Ils permettent de mesurer la fréquentation de manière anonymisée. Aucun profil individuel n’est établi
            et les données ne sont jamais cédées à des tiers.
          </p>

          <h2>Gestion du consentement</h2>
          <p>
            Lors de la première visite, une bannière informe l’utilisateur de la présence de cookies. Il est possible d’accepter ou de refuser les cookies analytiques.
            Le choix peut être modifié en vidant les préférences de navigation.
          </p>

          <h2>Durée de conservation</h2>
          <p>
            Les cookies analytiques, lorsqu’ils sont acceptés, sont conservés pour une durée maximale de 13 mois avant d’être automatiquement supprimés.
          </p>
        </article>
      </section>
    </div>
  );
};

export default CookiesPage;