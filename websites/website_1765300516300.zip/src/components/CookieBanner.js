import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_STORAGE_KEY = 'epr-cookie-preferences';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem(COOKIE_STORAGE_KEY, JSON.stringify({ analytics: choice }));
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        Education in Paris Review utilise des cookies essentiels pour assurer le fonctionnement du site et des cookies analytiques
        facultatifs destinés à observer l’audience de manière agrégée. Les données recueillies restent strictement anonymes.
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.reject} onClick={() => handleChoice(false)}>
          Refuser
        </button>
        <button type="button" className={styles.accept} onClick={() => handleChoice(true)}>
          Accepter
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;