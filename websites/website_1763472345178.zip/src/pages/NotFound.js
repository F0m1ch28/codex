import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './NotFound.module.css';

const NotFound = () => (
  <>
    <Helmet>
      <title>Seite nicht gefunden | Kolivareon</title>
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Oops – diese Seite gibt es nicht.</h1>
        <p>Vielleicht bist Du dem falschen Link gefolgt. Zurück zur Startseite?</p>
        <Link to="/" className={styles.link}>
          Zur Startseite
        </Link>
      </div>
    </section>
  </>
);

export default NotFound;