import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Guide.module.css';

const steps = [
  {
    title: 'Schritt 1: Bestandsaufnahme',
    description: 'Welche Aufgaben kosten Dich aktuell die meiste Energie? Wir kartieren Arbeitshäufigkeit, Emotion und Nutzen.'
  },
  {
    title: 'Schritt 2: KI-Setup',
    description: 'Wir wählen Tools, die zu Deiner Infrastruktur passen. Fokus auf Datenschutz, Bedienbarkeit und Skalierung.'
  },
  {
    title: 'Schritt 3: Prompt-Design',
    description: 'Gemeinsam entwickeln wir wiederverwendbare Prompt-Templates und definieren Qualitätssignale.'
  },
  {
    title: 'Schritt 4: Automationen',
    description: 'Wir bauen leichte Automationen mit Sicherheitsnetz. Du entscheidest, welche Schritte KI übernehmen darf.'
  },
  {
    title: 'Schritt 5: Lernschleifen',
    description: 'Mit wöchentlichen Retros reflektieren wir Ergebnisse, schärfen Prompts nach und feiern Fortschritt.'
  }
];

const Guide = () => (
  <>
    <Helmet>
      <title>KI Guide | Kolivareon</title>
      <meta
        name="description"
        content="Dein Schritt-für-Schritt Guide, um KI sinnvoll in Deinen Arbeitsalltag zu integrieren – von Analyse bis Automatisierung."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <span className="badge">Guide</span>
        <h1>Dein Weg zur produktiven KI-Routine</h1>
        <p>Unser Leitfaden begleitet Dich vom ersten Prompt bis zur automatisierten Routine – klar, praxisnah und sicher.</p>
      </div>
    </section>

    <section className={styles.steps}>
      <div className={`${styles.stepGrid} container`}>
        {steps.map((step, index) => (
          <article key={step.title} className={styles.step}>
            <span className={styles.stepNumber}>0{index + 1}</span>
            <h2>{step.title}</h2>
            <p>{step.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.resources}>
      <div className="container">
        <h2>Bonus-Ressourcen</h2>
        <ul>
          <li>Checkliste für nachhaltige KI-Implementierung</li>
          <li>Template: Weekly KI Retro</li>
          <li>Prompt-Bibliothek für Kommunikation &amp; Planung</li>
          <li>Framework: Decision Guardrails</li>
        </ul>
      </div>
    </section>
  </>
);

export default Guide;