import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const offerings = [
  {
    title: 'KI-Fokus-Sprint',
    description: '4 Wochen, um Deine E-Mail-Flut, Content-Schleifen und Planung auf Autopilot zu stellen.',
    details: ['Analyse Deines Ist-Zustands', 'Custom Prompt-Kits & Playbooks', 'Deep-Work-Planung']
  },
  {
    title: 'Team Enablement',
    description: 'Gemeinsam führen wir Dein Team in eine selbstbewusste, verantwortungsvolle KI-Nutzung.',
    details: ['Workshops & Labs', 'Change-Kommunikation', 'Governance-Frameworks']
  },
  {
    title: 'Leadership Advisory',
    description: 'Sounding Board für Führungskräfte, die KI sinnvoll in Strategie und Kultur verankern wollen.',
    details: ['1:1 Sessions', 'Strategie-Reflexion', 'Entscheidungs-Templates']
  }
];

const deepDiveTopics = [
  'Prompt-Architektur für Knowledge Work',
  'KI-gestützte Entscheidungs- und Priorisierungsmodelle',
  'Automationen mit Sicherheitsnetz',
  'Ethik, Governance & Responsible AI',
  'Lernpfade für unterschiedliche Teamrollen'
];

const Services = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <>
      <Helmet>
        <title>Services | Kolivareon Programme &amp; Beratung</title>
        <meta
          name="description"
          content="Entdecke unsere Services – von Fokus-Sprints über Team-Enablement bis Leadership Advisory. Individuell, praxisnah, transparent."
        />
      </Helmet>
      <section className={styles.hero}>
        <div>
          <span className="badge">Services</span>
          <h1>Individuelle Begleitung für Deinen nächsten Produktivitätsschritt.</h1>
          <p>
            Wir verbinden strukturierte Programme mit individueller Begleitung. Du bekommst Klarheit, Tools und Routinen, die Dich weiterbringen – ohne Dich zu überrollen.
          </p>
        </div>
      </section>

      <section className={styles.offerings}>
        <div className="container">
          <div className={styles.tabs} role="tablist" aria-label="Unsere Services">
            {offerings.map((offering, index) => (
              <button
                key={offering.title}
                role="tab"
                aria-selected={activeIndex === index}
                className={`${styles.tab} ${activeIndex === index ? styles.tabActive : ''}`}
                onClick={() => setActiveIndex(index)}
              >
                {offering.title}
              </button>
            ))}
          </div>
          <div className={styles.tabPanel} role="tabpanel">
            <h2>{offerings[activeIndex].title}</h2>
            <p>{offerings[activeIndex].description}</p>
            <ul>
              {offerings[activeIndex].details.map((detail) => (
                <li key={detail}>{detail}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.deepDive}>
        <div className="section-intro">
          <h2>Deep-Dive Themen</h2>
          <p>Du wählst, was Dich weiterbringt. Wir gestalten Sessions, die Deine Lernkurve beschleunigen.</p>
        </div>
        <div className={`${styles.topicGrid} container`}>
          {deepDiveTopics.map((topic) => (
            <div key={topic} className={styles.topicCard}>
              <span>→</span>
              <h3>{topic}</h3>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.finalCta}>
        <div className="container">
          <div className={styles.finalCard}>
            <h2>Welche Option passt für Dich?</h2>
            <p>In einem unverbindlichen Gespräch klären wir Ziele, Möglichkeiten und nächste Schritte.</p>
            <a href="/contact" className={styles.finalButton}>
              Lass uns sprechen
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;