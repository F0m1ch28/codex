import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPages.module.css';

const Imprint = () => (
  <>
    <Helmet>
      <title>Impressum | Kolivareon</title>
      <meta
        name="description"
        content="Impressum von Kolivareon – gesetzliche Angaben gemäß § 5 TMG."
      />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Impressum</h1>
        <p>Angaben gemäß § 5 TMG</p>
        <p>
          Kolivareon<br />
          Platzhalter-Adresse<br />
          10115 Berlin<br />
          Deutschland
        </p>

        <h2>Kontakt</h2>
        <p>
          E-Mail: kontakt@kolivareon.de<br />
          Telefon: +49 (0)30 12345678
        </p>

        <h2>Vertreten durch</h2>
        <p>Lea König</p>

        <h2>Umsatzsteuer-ID</h2>
        <p>DE999999999 (Platzhalter)</p>

        <h2>Aufsichtsbehörde</h2>
        <p>Industrie- und Handelskammer Berlin</p>
      </div>
    </section>
  </>
);

export default Imprint;