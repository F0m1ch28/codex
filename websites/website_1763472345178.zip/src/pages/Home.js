import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';
import Card from '../components/Card';
import Testimonial from '../components/Testimonial';
import ImageWithLoader from '../components/ImageWithLoader';
import blogPosts from '../data/blogPosts';

const statsData = [
  { label: 'E-Mails pro Woche schneller sortiert', value: 68, suffix: '+' },
  { label: 'Teilnehmende in Live-Labs', value: 320, suffix: '' },
  { label: 'Checklisten &amp; Prompts in unserer Bibliothek', value: 95, suffix: '+' },
  { label: 'Prozent fühlten sich nach 6 Wochen fokussierter', value: 84, suffix: '%' }
];

const benefits = [
  {
    title: 'Schnellere E-Mails',
    description:
      'Standardantworten transformierst Du in individuelle Botschaften – mit klaren nächsten Schritten und ehrlichem Ton.',
    icon: '✉️'
  },
  {
    title: 'Bessere Texte',
    description: 'Von LinkedIn-Posts bis Reports: Du entwickelst messerscharfe Argumentationslinien in Deinem Stil.',
    icon: '📝'
  },
  {
    title: 'Weniger Routinekram',
    description: 'Checklisten, Status-Updates und Meeting-Notizen laufen im Hintergrund, während Du fokussiert arbeitest.',
    icon: '⚙️'
  },
  {
    title: 'Mehr Fokuszeit',
    description: 'Wir helfen Dir, Deep-Work-Blöcke zu verteidigen und KI als Schutzschild gegen Störungen einzusetzen.',
    icon: '🎯'
  }
];

const themes = [
  { title: 'E-Mails', text: 'Klar, empathisch und auf den Punkt – in wenigen Minuten statt Stunden.' },
  { title: 'Content', text: 'Strukturierte Inhalte mit Co-Creation. KI als Ideenfeuer, Du als Filter.' },
  { title: 'Recherche', text: 'Hypothesen, Quellen, Synthesen – ohne in Tabs unterzugehen.' },
  { title: 'Planung', text: 'Smartes Priorisieren, Roadmaps und realistische Sprint-Planung.' }
];

const processSteps = [
  {
    step: '01',
    title: 'Analyse & Zielbild',
    description: 'Wir kartieren Deinen Alltag, identifizieren Zeitfresser und formulieren gemeinsam ein realistisches Ziel.'
  },
  {
    step: '02',
    title: 'KI-Playbooks',
    description: 'Du erhältst praxiserprobte Prompt-Kits, klare Automationsregeln und Mini-Übungen für den Transfer.'
  },
  {
    step: '03',
    title: 'Begleitung & Review',
    description: 'Mit wöchentlichen Check-ins, Feedback und Daten-Reflexion verankern wir neue Routinen nachhaltig.'
  }
];

const testimonials = [
  {
    quote:
      'Kolivareon hat uns geholfen, unsere wöchentlichen Statusberichte zu halbieren – in der Zeit und im Stress. Wir sind strukturierter als je zuvor.',
    name: 'Miriam Vogt',
    role: 'Leiterin Kommunikation, TechScale GmbH',
    avatar: 'https://picsum.photos/200/200?random=501'
  },
  {
    quote:
      'Die Kombination aus menschlicher Beratung und KI-Toolbox war genau das, was wir gebraucht haben. Meine Meetings starten jetzt mit Klarheit.',
    name: 'Jonas Keller',
    role: 'Head of Operations, Studio Nord',
    avatar: 'https://picsum.photos/200/200?random=502'
  },
  {
    quote:
      'Nach sechs Wochen hatten wir nicht nur fertige Prompts, sondern auch ein Team, das sich eigenständig weiterentwickelt. Nachhaltige Wirkung.',
    name: 'Sophie Brandt',
    role: 'Teamlead Content, Urban Collective',
    avatar: 'https://picsum.photos/200/200?random=503'
  }
];

const teamMembers = [
  {
    name: 'Lea König',
    role: 'Gründerin & KI-Strategin',
    strengths: 'Storytelling, Change-Kommunikation, Neurodiversität',
    image: 'https://picsum.photos/400/400?random=601'
  },
  {
    name: 'Tarek Abdallah',
    role: 'Workflow-Designer',
    strengths: 'Automationen, Datenethik, OKR-Moderation',
    image: 'https://picsum.photos/400/400?random=602'
  },
  {
    name: 'Sara Hoffmann',
    role: 'Learning Experience Lead',
    strengths: 'Didaktik, Remote-Collaboration, Coaching',
    image: 'https://picsum.photos/400/400?random=603'
  }
];

const projects = [
  {
    id: 1,
    title: 'E-Mail-Intelligenz für ein SaaS-Startup',
    category: 'E-Mail',
    description: 'Reduzierte Antwortzeiten um 45 %, ohne Tonalität zu verlieren.',
    image: 'https://picsum.photos/900/600?random=701'
  },
  {
    id: 2,
    title: 'Content Studio Playbook',
    category: 'Content',
    description: 'Von Ideen zu dreistufigen Content-Serien mit klaren KPIs.',
    image: 'https://picsum.photos/900/600?random=702'
  },
  {
    id: 3,
    title: 'Recherche-Pipeline für NGO',
    category: 'Recherche',
    description: 'Konsistente Faktenlage dank dreistufigem Verifizierungsprozess.',
    image: 'https://picsum.photos/900/600?random=703'
  },
  {
    id: 4,
    title: 'Wöchentliche Planning-Sprints',
    category: 'Planung',
    description: 'Zeitblöcke für Deep Work, automatisierte Status-Updates.',
    image: 'https://picsum.photos/900/600?random=704'
  }
];

const faqItems = [
  {
    question: 'Brauche ich Vorerfahrung mit KI-Tools?',
    answer:
      'Nein. Wir holen Dich dort ab, wo Du stehst. Von Nullstart bis fortgeschrittene Teams – wir passen Tempo und Inhalte individuell an.'
  },
  {
    question: 'Wie viel Zeit muss ich investieren?',
    answer:
      'Unsere Programme sind auf 2–3 Stunden pro Woche ausgelegt. Ziel ist, dass sich die investierte Zeit schnell amortisiert und spürbare Entlastung entsteht.'
  },
  {
    question: 'Wie geht ihr mit Datenschutz um?',
    answer:
      'Wir nutzen datenschutzkonforme Tools, achten auf DSGVO und helfen Dir, eine sichere KI-Governance aufzusetzen. Eigene Daten bleiben immer bei Dir.'
  },
  {
    question: 'Was, wenn sich mein Team schwer tut?',
    answer:
      'Wir begleiten Change-Prozesse empathisch. Durch Mini-Experimente, Peer-Learning und offene Q&A-Sessions entsteht Zuversicht statt Überforderung.'
  }
];

const Home = () => {
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Alle');
  const [openFaq, setOpenFaq] = useState(0);

  useEffect(() => {
    let animationFrame;
    const duration = 1400;
    const startTime = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - startTime) / duration, 1);
      setStats(
        statsData.map((item) => Math.round(item.value * progress))
      );
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'Alle') return projects;
    return projects.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  return (
    <>
      <Helmet>
        <title>Kolivareon | Mit KI 2–3 Stunden täglich sparen</title>
        <meta
          name="description"
          content="Kolivareon hilft Dir, mit KI fokussierter zu arbeiten – mit praxiserprobten Workflows, Guides und Programmen für produktive Teams."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className="badge">Fokus statt Tool-Overload</span>
          <h1>Mit KI 2–3 Stunden täglich sparen – ohne Extra-Stress.</h1>
          <p>
            Wir zeigen Dir, wie Du KI und Neuro-Tools so einsetzt, dass Routineaufgaben verschwinden, Entscheidungen klarer werden und
            mehr Fokuszeit bleibt. Realistisch, menschlich, sofort anwendbar.
          </p>
          <div className={styles.heroActions}>
            <Link className={styles.primaryCta} to="/programs">
              Jetzt starten
            </Link>
            <Link className={styles.secondaryCta} to="/guide">
              Mit KI Zeit sparen
            </Link>
          </div>
          <ul className={styles.heroBullets} aria-label="Kurzübersicht der Vorteile">
            <li>🔒 DSGVO-freundliche Tool-Auswahl</li>
            <li>🧭 Begleitung von Analyse bis Umsetzung</li>
            <li>🌱 Routinen, die zu Deinem Arbeitsstil passen</li>
          </ul>
        </div>
        <div className={styles.heroImage}>
          <ImageWithLoader
            src="https://picsum.photos/1200/900?random=101"
            alt="Fokussierte Person arbeitet mit Laptop und Notizen"
            lazy={false}
          />
        </div>
      </section>

      <section className={styles.stats}>
        <div className="section-intro">
          <h2>Resultate, die greifbar sind</h2>
          <p>Unsere Teilnehmenden berichten von weniger Kontext-Wechseln, klarerer Kommunikation und spürbar mehr Ruhe im Arbeitsalltag.</p>
        </div>
        <div className={`${styles.statsGrid} container`}>
          {statsData.map((stat, index) => (
            <div key={stat.label} className={styles.statCard}>
              <span className={styles.statValue}>
                {stats[index]}
                {stat.suffix}
              </span>
              <span className={styles.statLabel} dangerouslySetInnerHTML={{ __html: stat.label }} />
            </div>
          ))}
        </div>
      </section>

      <section className={styles.benefits}>
        <div className="section-intro">
          <h2>Was KI mit Dir im Alltag bewirken kann</h2>
          <p>Wir setzen auf klare Playbooks, die Du innerhalb weniger Tage in Deinen Workflow integrierst – ohne Dein Team zu überrollen.</p>
        </div>
        <div className={`${styles.benefitGrid} container`}>
          {benefits.map((benefit) => (
            <Card
              key={benefit.title}
              title={benefit.title}
              description={benefit.description}
              icon={benefit.icon}
            />
          ))}
        </div>
      </section>

      <section className={styles.themes}>
        <div className="container">
          <div className={styles.thematicHeader}>
            <h2>Deine Themen, unsere Fokusfelder</h2>
            <p>Von E-Mails bis Planung: Wir arbeiten entlang Deiner konkreten Aufgaben, nicht entlang von Features.</p>
          </div>
          <div className={styles.themesGrid}>
            {themes.map((theme) => (
              <div key={theme.title} className={styles.themeCard}>
                <h3>{theme.title}</h3>
                <p>{theme.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.why}>
        <div className="container">
          <div className={styles.whyGrid}>
            <div>
              <span className="badge">Warum Kolivareon</span>
              <h2>Du bekommst Strategie, Training &amp; Umsetzung aus einer Hand.</h2>
              <p>
                Wir vereinen KI-Kompetenz mit Organisationspsychologie. Unser Anspruch: Lösungen, die zu Menschen passen. Keine Tool-Flut,
                sondern klare Routinen, die Vertrauen schaffen und spürbar entlasten.
              </p>
              <ul className={styles.whyList}>
                <li>Verständnisvoller Change-Prozess statt Druck</li>
                <li>Prompts, Workflows &amp; Checklisten direkt einsatzbereit</li>
                <li>Kontinuierliche Begleitung mit messbaren Zwischenzielen</li>
              </ul>
            </div>
            <ImageWithLoader
              src="https://picsum.photos/1200/900?random=102"
              alt="Team arbeitet gemeinsam an KI-Strategie"
              className={styles.whyImage}
            />
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="section-intro">
          <h2>Unser gemeinsamer Weg</h2>
          <p>In drei Phasen vom ersten Blick auf Deinen Arbeitsalltag zu klaren, stabilen KI-Routinen.</p>
        </div>
        <div className={`${styles.processGrid} container`}>
          {processSteps.map((step) => (
            <div key={step.step} className={styles.processCard}>
              <span className={styles.processStep}>{step.step}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="section-intro">
          <h2>Stimmen aus der Praxis</h2>
          <p>Teams aus Tech, Bildung und Kreativwirtschaft nutzen Kolivareon, um ihre Arbeitsweise nachhaltig zu verändern.</p>
        </div>
        <div className={styles.testimonialCarousel} aria-live="polite">
          <Testimonial {...testimonials[activeTestimonial]} />
          <div className={styles.carouselControls}>
            {testimonials.map((testimonial, index) => (
              <button
                key={testimonial.name}
                type="button"
                className={`${styles.carouselDot} ${index === activeTestimonial ? styles.carouselDotActive : ''}`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Testimonial ${index + 1} anzeigen`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.teamHeader}>
            <h2>Das Team hinter Kolivareon</h2>
            <p>Wir kombinieren Expertise in KI, Organisationsentwicklung und Lernpsychologie – damit Du Dich sicher verändern kannst.</p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <ImageWithLoader src={member.image} alt={`Portrait von ${member.name}`} />
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.strengths}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <h2>Projekteinblicke</h2>
            <div className={styles.projectFilters} role="tablist" aria-label="Projektkategorien">
              {['Alle', 'E-Mail', 'Content', 'Recherche', 'Planung'].map((category) => (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={projectFilter === category}
                  className={`${styles.projectFilter} ${projectFilter === category ? styles.projectFilterActive : ''}`}
                  onClick={() => setProjectFilter(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <ImageWithLoader src={project.image} alt={project.title} />
                <div className={styles.projectBody}>
                  <span className={styles.projectBadge}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="section-intro">
          <h2>Antworten auf häufige Fragen</h2>
          <p>Offene Kommunikation ist uns wichtig. Wenn etwas fehlt, melde Dich jederzeit.</p>
        </div>
        <div className={`${styles.faqList} container`} role="tablist" aria-label="FAQ">
          {faqItems.map((item, index) => (
            <div
              key={item.question}
              className={`${styles.faqItem} ${openFaq === index ? styles.faqItemOpen : ''}`}
            >
              <button
                type="button"
                className={styles.faqButton}
                onClick={() => setOpenFaq(index === openFaq ? -1 : index)}
                aria-expanded={openFaq === index}
              >
                <span>{item.question}</span>
                <span aria-hidden="true">{openFaq === index ? '−' : '+'}</span>
              </button>
              {openFaq === index && <p>{item.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.blogHeader}>
            <div>
              <h2>Neues aus dem Kolivareon Blog</h2>
              <p>Frische Perspektiven, Praxisberichte und Tools, die wirklich funktionieren.</p>
            </div>
            <Link to="/blog" className={styles.blogMore}>
              Alle Beiträge ansehen
            </Link>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.slice(0, 3).map((post) => (
              <article key={post.slug} className={styles.blogCard}>
                <ImageWithLoader src={post.heroImage} alt={post.title} />
                <div className={styles.blogBody}>
                  <span className={styles.blogMeta}>{post.date} • {post.readingTime}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={`/blog/${post.slug}`} className={styles.blogLink}>
                    Weiterlesen
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Bereit für mehr Fokuszeit?</h2>
            <p>
              Lass uns in einem 30-minütigen Gespräch prüfen, wie wir Dich oder Dein Team unterstützen können. Ohne Pitch, mit echtem Interesse.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/contact" className={styles.ctaPrimary}>
                Gespräch anfragen
              </Link>
              <Link to="/guide" className={styles.ctaSecondary}>
                KI-Guide entdecken
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;