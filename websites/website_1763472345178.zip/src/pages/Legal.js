import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPages.module.css';

const Legal = () => (
  <>
    <Helmet>
      <title>Rechtliche Hinweise | Kolivareon</title>
      <meta
        name="description"
        content="Rechtliche Hinweise zur Nutzung der Kolivareon-Website, Haftungsausschlüsse und Urheberrechte."
      />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Rechtliche Hinweise</h1>
        <p>
          Die Inhalte dieser Website wurden mit größter Sorgfalt erstellt. Für die Richtigkeit, Vollständigkeit und Aktualität der Inhalte
          übernehmen wir keine Gewähr.
        </p>

        <h2>Haftung für Inhalte</h2>
        <p>
          Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte verantwortlich. Nach §§ 8 bis 10 TMG sind wir jedoch nicht verpflichtet,
          übermittelte oder gespeicherte fremde Informationen zu überwachen.
        </p>

        <h2>Urheberrecht</h2>
        <p>
          Die von Kolivareon erstellten Inhalte und Werke auf dieser Website unterliegen dem deutschen Urheberrecht. Eine Vervielfältigung,
          Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen Zustimmung.
        </p>

        <h2>Externe Links</h2>
        <p>
          Unser Angebot enthält Links zu externen Websites Dritter. Auf deren Inhalte haben wir keinen Einfluss. Für die Inhalte der verlinkten Seiten
          ist stets der jeweilige Anbieter verantwortlich.
        </p>
      </div>
    </section>
  </>
);

export default Legal;