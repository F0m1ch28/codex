import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialForm = {
  name: '',
  email: '',
  topic: '',
  message: ''
};

const Contact = () => {
  const [formValues, setFormValues] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formValues.name.trim()) newErrors.name = 'Bitte gib Deinen Namen ein.';
    if (!formValues.email.trim()) {
      newErrors.email = 'Bitte trage Deine E-Mail-Adresse ein.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formValues.email)) {
      newErrors.email = 'Bitte verwende eine gültige E-Mail-Adresse.';
    }
    if (!formValues.message.trim()) newErrors.message = 'Was dürfen wir für Dich tun?';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setSubmitted(true);
    setFormValues(initialForm);
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Kolivareon</title>
        <meta
          name="description"
          content="Schreib uns Dein Anliegen: Wir melden uns innerhalb von zwei Werktagen mit klaren nächsten Schritten."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.intro}>
          <span className="badge">Kontakt</span>
          <h1>Lass uns über Deine Ziele sprechen.</h1>
          <p>Wir melden uns innerhalb von zwei Werktagen. Transparente Kommunikation, klare Empfehlungen, kein Verkaufsdruck.</p>
          <ul>
            <li>📅 Kostenfreies Erstgespräch (30 Minuten)</li>
            <li>🧭 Gemeinsames Zielbild &amp; mögliche Wege</li>
            <li>🤝 Menschliche Begleitung auf Augenhöhe</li>
          </ul>
        </div>
        <div className={styles.formCard}>
          <h2>Schreib uns</h2>
          {submitted && (
            <div className={styles.success} role="status">
              Danke für Deine Nachricht! Wir melden uns sehr bald bei Dir.
            </div>
          )}
          <form onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Name*</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formValues.name}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={errors.name ? 'true' : 'false'}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </div>
            <div className={styles.field}>
              <label htmlFor="email">E-Mail*</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formValues.email}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={errors.email ? 'true' : 'false'}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </div>
            <div className={styles.field}>
              <label htmlFor="topic">Thema</label>
              <select id="topic" name="topic" value={formValues.topic} onChange={handleChange}>
                <option value="">Bitte wählen ...</option>
                <option value="beratung">Beratung / Zusammenarbeit</option>
                <option value="training">Training / Teamprogramm</option>
                <option value="vortrag">Vortrag / Event</option>
                <option value="anderes">Anderes Anliegen</option>
              </select>
            </div>
            <div className={styles.field}>
              <label htmlFor="message">Nachricht*</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formValues.message}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={errors.message ? 'true' : 'false'}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </div>
            <button type="submit" className={styles.submit}>
              Nachricht senden
            </button>
          </form>
          <p className={styles.privacyNote}>
            Mit dem Absenden stimmst Du zu, dass wir Deine Angaben zur Beantwortung speichern. Mehr Infos findest Du in unserer{' '}
            <a href="/privacy">Datenschutzerklärung</a>.
          </p>
        </div>
      </section>
    </>
  );
};

export default Contact;