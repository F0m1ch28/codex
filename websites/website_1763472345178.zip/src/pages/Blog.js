import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Blog.module.css';
import blogPosts from '../data/blogPosts';

const Blog = () => (
  <>
    <Helmet>
      <title>Blog | Kolivareon</title>
      <meta
        name="description"
        content="Insights, Erfahrungsberichte und Tools rund um produktive KI-Anwendungen im Arbeitsalltag."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <span className="badge">Blog</span>
        <h1>Insights &amp; Erfahrungen aus der Praxis</h1>
        <p>Wir teilen, was funktioniert – und was nicht. Ehrlich, reflektiert, praxiserprobt.</p>
      </div>
    </section>

    <section className={styles.posts}>
      <div className={`${styles.postGrid} container`}>
        {blogPosts.map((post) => (
          <article key={post.slug} className={styles.postCard}>
            <img src={post.heroImage} alt={post.title} loading="lazy" />
            <div className={styles.postBody}>
              <span className={styles.postMeta}>{post.date} • {post.readingTime}</span>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <Link to={`/blog/${post.slug}`} className={styles.postLink}>
                Weiterlesen
              </Link>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Blog;