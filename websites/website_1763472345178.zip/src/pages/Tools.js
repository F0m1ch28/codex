import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const tools = [
  {
    title: 'Prompt Canvas',
    description: 'Frage, Kontext, Tonalität, Output – strukturiert auf einer Seite.',
    type: 'Template'
  },
  {
    title: 'Decision Guardrails',
    description: 'Leitplanken für verantwortungsvolle KI-Nutzung in Teams.',
    type: 'Framework'
  },
  {
    title: 'Deep Work Planner',
    description: 'Plane Fokusblöcke, schütze Deinen Kalender und halte Fortschritte fest.',
    type: 'Checkliste'
  },
  {
    title: 'Meeting Synth Builder',
    description: 'Generiere strukturierte Meeting-Zusammenfassungen in Minuten.',
    type: 'Promptpaket'
  },
  {
    title: 'KI-Retro Fragen',
    description: 'Reflektionsfragen für Teams, um Lernzyklen zu beschleunigen.',
    type: 'Arbeitsblatt'
  },
  {
    title: 'Content Flow Map',
    description: 'Visualisiere Content-Ideen, Kanäle und Verantwortlichkeiten.',
    type: 'Miro-Board'
  }
];

const Tools = () => (
  <>
    <Helmet>
      <title>Tools &amp; Checklisten | Kolivareon</title>
      <meta
        name="description"
        content="Praxiserprobte Tools, Templates und Checklisten, die Deine KI-Arbeit vereinfachen und strukturieren."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <span className="badge">Tools &amp; Checklisten</span>
        <h1>Deine Tool-Bibliothek für produktive KI-Routinen.</h1>
        <p>Alle Ressourcen sind modular aufgebaut, sofort einsetzbar und lassen sich flexibel auf Dein Team zuschneiden.</p>
      </div>
    </section>

    <section className={styles.tools}>
      <div className={`${styles.toolGrid} container`}>
        {tools.map((tool) => (
          <article key={tool.title} className={styles.toolCard}>
            <span className={styles.toolType}>{tool.type}</span>
            <h2>{tool.title}</h2>
            <p>{tool.description}</p>
            <a href="/contact" className={styles.toolLink}>
              Zugang anfragen
            </a>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Tools;