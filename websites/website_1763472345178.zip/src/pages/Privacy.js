import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPages.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Datenschutz | Kolivareon</title>
      <meta
        name="description"
        content="Erfahre, wie Kolivareon mit personenbezogenen Daten umgeht, welche Rechte Du hast und welche Sicherheitsmaßnahmen wir ergreifen."
      />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Datenschutzerklärung</h1>
        <p>Stand: März 2024</p>

        <h2>1. Verantwortliche Stelle</h2>
        <p>
          Kolivareon<br />
          Platzhalter-Adresse<br />
          10115 Berlin<br />
          E-Mail: kontakt@kolivareon.de
        </p>

        <h2>2. Verarbeitung personenbezogener Daten</h2>
        <p>
          Wir verarbeiten personenbezogene Daten ausschließlich zu legitimen Zwecken und im Rahmen der Datenschutz-Grundverordnung (DSGVO).
          Dazu zählen insbesondere:
        </p>
        <ul>
          <li>Kommunikation via E-Mail oder Kontaktformular</li>
          <li>Vertragsanbahnung und -erfüllung</li>
          <li>Analyse und Verbesserung unseres digitalen Angebots (anonymisiert)</li>
        </ul>

        <h2>3. Rechtsgrundlage</h2>
        <p>
          Die Verarbeitung erfolgt auf Grundlage von Art. 6 Abs. 1 lit. a, b und f DSGVO. Wir holen Einwilligungen transparent ein
          und verarbeiten Daten nur, solange sie für den jeweiligen Zweck erforderlich sind.
        </p>

        <h2>4. Cookies</h2>
        <p>
          Unsere Website setzt ausschließlich technisch notwendige Cookies ein. Sie dienen der Bereitstellung grundlegender Funktionen.
          Tracking- oder Marketing-Cookies verwenden wir nicht.
        </p>

        <h2>5. Speicherdauer</h2>
        <p>
          Daten werden solange gespeichert, wie es für den jeweiligen Zweck erforderlich ist oder gesetzliche Aufbewahrungsfristen bestehen.
          Anschließend werden sie gelöscht oder anonymisiert.
        </p>

        <h2>6. Deine Rechte</h2>
        <p>Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung sowie Datenübertragbarkeit.</p>

        <h2>7. Datensicherheit</h2>
        <p>
          Wir setzen technische und organisatorische Maßnahmen ein, um Deine Daten vor unbefugtem Zugriff zu schützen. Dazu gehören
          verschlüsselte Verbindungen, Zugriffsbeschränkungen und regelmäßige Sicherheitsreviews.
        </p>

        <h2>8. Kontakt für Datenschutzanfragen</h2>
        <p>
          Wenn Du Fragen zum Datenschutz hast oder Deine Rechte ausüben möchtest, schreibe an: datenschutz@kolivareon.de
        </p>
      </div>
    </section>
  </>
);

export default Privacy;