import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';
import ImageWithLoader from '../components/ImageWithLoader';

const About = () => (
  <>
    <Helmet>
      <title>Über Kolivareon | Menschenzentrierte KI-Produktivität</title>
      <meta
        name="description"
        content="Kolivareon begleitet Teams und Soloprofis dabei, KI sinnvoll zu integrieren. Erfahre mehr über unser Team, unsere Werte und unseren Ansatz."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.text}>
        <span className="badge">Unser Warum</span>
        <h1>Wir glauben an produktive Arbeit, die sich gut anfühlt.</h1>
        <p>
          Kolivareon ist aus der Frage entstanden, wie moderne Arbeit klarer, fokussierter und menschlicher werden kann –
          trotz wachsender Anforderungen. Wir verbinden KI-Verständnis mit Empathie, um Dich Schritt für Schritt zu entlasten.
        </p>
      </div>
      <ImageWithLoader
        src="https://picsum.photos/1200/800?random=140"
        alt="Kolivareon Team arbeitet kollaborativ"
        className={styles.heroImage}
      />
    </section>

    <section className={styles.values}>
      <div className="section-intro">
        <h2>Werte, die uns leiten</h2>
        <p>Sie sind unser Kompass für jede Beratung, jedes Training und jede Entscheidung.</p>
      </div>
      <div className={`${styles.valueGrid} container`}>
        <article>
          <h3>Resonanz vor Tempo</h3>
          <p>
            Wir glauben, dass nachhaltige Veränderung nur entsteht, wenn sie zu Dir passt. Deshalb hören wir zuerst zu,
            bevor wir Lösungen vorschlagen.
          </p>
        </article>
        <article>
          <h3>Verantwortung &amp; Transparenz</h3>
          <p>
            KI bringt Chancen, aber auch Risiken. Wir sprechen offen über Grenzen, Datenschutz und ethische Aspekte –
            und schaffen klare Leitplanken.
          </p>
        </article>
        <article>
          <h3>Lernen als Prozess</h3>
          <p>
            Produktivität ist kein Mindset-Sprint. Wir setzen auf iteratives Lernen, spielerische Experimente und strukturierte Reflexion.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.timeline}>
      <div className="container">
        <h2>Unser Weg</h2>
        <div className={styles.timelineGrid}>
          <div>
            <span>2019</span>
            <p>Gründung von Kolivareon als Beratung für produktive Kommunikation &amp; fokussierte Arbeit.</p>
          </div>
          <div>
            <span>2021</span>
            <p>Erste KI-Labs mit Kreativteams, Fokus auf Textqualität und Entscheidungsfindung.</p>
          </div>
          <div>
            <span>2022</span>
            <p>Aufbau unserer KI-Bibliothek mit Templates, Checklisten und Lernpfaden für unterschiedliche Branchen.</p>
          </div>
          <div>
            <span>Heute</span>
            <p>
              Wir begleiten Organisationen in Deutschland, Österreich und der Schweiz auf ihrem Weg zu nachhaltiger KI-Produktivität.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.manifest}>
      <div className="container">
        <h2>Unser Manifest für produktive Arbeit</h2>
        <ul>
          <li>Technologie dient Menschen, nicht anders herum.</li>
          <li>Produktivität ist kein Hustle, sondern Klarheit, Fokus und gute Entscheidungen.</li>
          <li>KI ist ein Werkzeug. Kultur, Empathie und Verantwortung bleiben bei uns Menschen.</li>
          <li>Kleine Schritte sind keine Zeitverschwendung. Sie schaffen Vertrauen und messbare Ergebnisse.</li>
          <li>Wir feiern Fortschritt, nicht Perfektion.</li>
        </ul>
      </div>
    </section>
  </>
);

export default About;