import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPages.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>AGB &amp; Nutzungsbedingungen | Kolivareon</title>
      <meta
        name="description"
        content="Unsere allgemeinen Geschäftsbedingungen regeln Zusammenarbeit, Leistungen und Haftungsfragen transparent und fair."
      />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Allgemeine Geschäftsbedingungen</h1>
        <p>Stand: März 2024</p>

        <h2>1. Geltungsbereich</h2>
        <p>
          Die nachfolgenden Bedingungen gelten für alle Angebote, Leistungen und Verträge zwischen Kolivareon und ihren Kund:innen,
          sofern nicht ausdrücklich schriftlich etwas anderes vereinbart wurde.
        </p>

        <h2>2. Leistungen</h2>
        <p>
          Kolivareon erbringt Beratungs-, Schulungs- und Projektleistungen rund um KI-gestützte Produktivität. Inhalte, Umfang und Ziele
          werden in einem individuellen Angebot festgehalten.
        </p>

        <h2>3. Zusammenarbeit</h2>
        <p>
          Wir arbeiten transparent und iterativ. Kund:innen stellen die für die Zusammenarbeit notwendigen Informationen zur Verfügung
          und schaffen die erforderlichen Voraussetzungen im eigenen Unternehmen.
        </p>

        <h2>4. Vertraulichkeit</h2>
        <p>
          Beide Parteien verpflichten sich zur Vertraulichkeit über sämtliche Informationen, die während der Zusammenarbeit ausgetauscht werden.
        </p>

        <h2>5. Haftung</h2>
        <p>
          Kolivareon haftet für Vorsatz und grobe Fahrlässigkeit. Für leichte Fahrlässigkeit haften wir nur bei Verletzung wesentlicher Vertragspflichten.
          Eine Haftung für mittelbare Schäden wird ausgeschlossen.
        </p>

        <h2>6. Zahlungsbedingungen</h2>
        <p>
          Die Vergütung und Zahlungsmodalitäten ergeben sich aus dem jeweiligen Angebot. Rechnungen sind innerhalb von 14 Tagen ohne Abzug zahlbar.
        </p>

        <h2>7. Schlussbestimmungen</h2>
        <p>
          Es gilt das Recht der Bundesrepublik Deutschland. Gerichtstand ist Berlin. Sollte eine Bestimmung unwirksam sein, bleibt der Vertrag im Übrigen gültig.
        </p>
      </div>
    </section>
  </>
);

export default Terms;