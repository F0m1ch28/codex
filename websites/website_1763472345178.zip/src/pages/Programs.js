import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programs.module.css';

const programs = [
  {
    title: 'Focus Flow',
    duration: '6 Wochen',
    description: 'Schaffe Raum für Deep Work. Du entlastest Dich von Routineaufgaben und definierst klare Fokusblöcke.',
    highlights: ['Wöchentliche Labs', 'Persönlicher Coach', 'Prompts für E-Mails & Meetings']
  },
  {
    title: 'Content Co-Pilot',
    duration: '8 Wochen',
    description: 'Von Ideen zu hochwertigen Stories: Wir bauen gemeinsam Dein KI-gestütztes Content-Studio.',
    highlights: ['Redaktions-Playbook', 'KI-Feedback-Loops', 'Metriken & Lernzyklen']
  },
  {
    title: 'KI-Team-Challenge',
    duration: '4 Wochen',
    description: 'Team-Challenge mit Micro-Learnings, Peer-Sessions und klaren Erfolgsmetriken.',
    highlights: ['Peer-Coaching', 'Governance-Guidelines', 'Quick-Wins & Retros']
  }
];

const Programs = () => (
  <>
    <Helmet>
      <title>Programme &amp; Challenges | Kolivareon</title>
      <meta
        name="description"
        content="Kolivareon Programme kombinieren Praxis, Reflexion und KI-Kompetenz. Wähle Deinen Fokus und erlebe nachhaltige Veränderung."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <span className="badge">Programme</span>
        <h1>Geführte Lernwege für spürbare Ergebnisse.</h1>
        <p>
          Unsere Programme kombinieren Live-Sessions, praxisnahe Aufgaben und persönliche Begleitung. Du wählst den Schwerpunkt,
          wir liefern Struktur, Motivation und Tools.
        </p>
      </div>
    </section>

    <section className={styles.programs}>
      <div className={`${styles.programGrid} container`}>
        {programs.map((program) => (
          <article key={program.title} className={styles.programCard}>
            <span className={styles.duration}>{program.duration}</span>
            <h2>{program.title}</h2>
            <p>{program.description}</p>
            <ul>
              {program.highlights.map((highlight) => (
                <li key={highlight}>{highlight}</li>
              ))}
            </ul>
            <a href="/contact" className={styles.programButton}>
              Platz sichern
            </a>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.outcomes}>
      <div className="container">
        <h2>Was Dich erwartet</h2>
        <div className={styles.outcomeGrid}>
          <div>
            <h3>Reflexion &amp; Fokus</h3>
            <p>Du verschaffst Dir Klarheit über Ziele, Prioritäten und Blockaden. KI hilft beim Strukturieren – Du triffst die Entscheidungen.</p>
          </div>
          <div>
            <h3>Praktische Umsetzung</h3>
            <p>Jede Woche liefert Dir neue Templates, Übungen und Feedback, damit Du in Deinem Kontext vorwärtskommst.</p>
          </div>
          <div>
            <h3>Übertrag in den Alltag</h3>
            <p>Wir legen Wert darauf, dass Du Routinen entwickelst, die sich in Deinen Kalender integrieren lassen – ohne Überforderung.</p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Programs;