import React from 'react';
import { Helmet } from 'react-helmet';
import { Link, useParams } from 'react-router-dom';
import styles from './BlogPost.module.css';

const BlogPost = ({ posts }) => {
  const { slug } = useParams();
  const post = posts.find((p) => p.slug === slug);

  if (!post) {
    return (
      <section className={styles.notFound}>
        <div className="container">
          <h1>Beitrag nicht gefunden</h1>
          <p>Der gesuchte Beitrag existiert nicht mehr oder wurde verschoben.</p>
          <Link to="/blog" className={styles.backLink}>
            Zurück zum Blog
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} | Kolivareon Blog</title>
        <meta name="description" content={post.excerpt} />
      </Helmet>
      <article className={styles.article}>
        <div className="container">
          <Link to="/blog" className={styles.backLink}>
            ← Zurück zum Blog
          </Link>
          <header className={styles.header}>
            <span className={styles.meta}>{post.date} • {post.readingTime}</span>
            <h1>{post.title}</h1>
            <div className={styles.categories}>
              {post.categories.map((category) => (
                <span key={category}>{category}</span>
              ))}
            </div>
          </header>
          <img src={post.heroImage} alt={post.title} className={styles.heroImage} loading="lazy" />
          <div className={styles.content}>
            {post.content.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
        </div>
      </article>
    </>
  );
};

export default BlogPost;