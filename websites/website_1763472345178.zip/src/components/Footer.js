import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`${styles.container} container`}>
      <div className={styles.column}>
        <h3 className={styles.logo}>Kolivareon</h3>
        <p className={styles.tagline}>
          Wir begleiten Dich dabei, produktive KI-Routinen in Deinen Alltag zu integrieren – menschlich, fokussiert und sicher.
        </p>
        <p className={styles.contact}>
          Platzhalter-Adresse<br />
          10115 Berlin<br />
          Deutschland
        </p>
      </div>
      <div className={styles.column}>
        <h4>Navigation</h4>
        <ul>
          <li><Link to="/guide">KI-Guide</Link></li>
          <li><Link to="/programs">Programme &amp; Challenges</Link></li>
          <li><Link to="/tools">Tools &amp; Checklisten</Link></li>
          <li><Link to="/services">Services</Link></li>
          <li><Link to="/blog">Blog</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4>Unternehmen</h4>
        <ul>
          <li><Link to="/about">Über uns</Link></li>
          <li><Link to="/contact">Kontakt</Link></li>
          <li><Link to="/privacy">Datenschutz</Link></li>
          <li><Link to="/terms">AGB &amp; Nutzungsbedingungen</Link></li>
          <li><Link to="/legal">Rechtliche Hinweise</Link></li>
          <li><Link to="/imprint">Impressum</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4>Bleib informiert</h4>
        <p className={styles.newsletterText}>
          Einmal monatlich Inspiration, neue Workflows und reflektierte KI-Einsatzszenarien direkt in Dein Postfach.
        </p>
        <form className={styles.newsletterForm}>
          <label htmlFor="newsletter-email" className="sr-only">E-Mail-Adresse</label>
          <input id="newsletter-email" type="email" placeholder="Deine E-Mail" required aria-required="true" />
          <button type="submit">Anmelden</button>
        </form>
        <span className={styles.newsletterHint}>Du kannst Dich jederzeit wieder abmelden.</span>
      </div>
    </div>
    <div className={styles.bottom}>
      <span>© {new Date().getFullYear()} Kolivareon. Alle Rechte vorbehalten.</span>
      <div className={styles.bottomLinks}>
        <Link to="/privacy">Datenschutz</Link>
        <Link to="/imprint">Impressum</Link>
      </div>
    </div>
  </footer>
);

export default Footer;