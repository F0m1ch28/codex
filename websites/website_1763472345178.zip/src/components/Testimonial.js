import React from 'react';
import styles from './Testimonial.module.css';

const Testimonial = ({ quote, name, role, avatar }) => (
  <figure className={styles.testimonial}>
    <blockquote>“{quote}”</blockquote>
    <figcaption>
      <img src={avatar} alt={`Portrait von ${name}`} loading="lazy" />
      <div>
        <strong>{name}</strong>
        <span>{role}</span>
      </div>
    </figcaption>
  </figure>
);

export default Testimonial;