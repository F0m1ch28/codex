import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [hasShadow, setHasShadow] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setHasShadow(window.scrollY > 12);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${hasShadow ? styles.scrolled : ''}`}>
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Kolivareon Startseite">
          Kolivareon
        </NavLink>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Hauptnavigation">
          <NavLink className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} to="/" onClick={closeMenu}>
            Home
          </NavLink>
          <NavLink className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} to="/guide" onClick={closeMenu}>
            Guide
          </NavLink>
          <NavLink className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} to="/programs" onClick={closeMenu}>
            Programme
          </NavLink>
          <NavLink className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} to="/tools" onClick={closeMenu}>
            Tools
          </NavLink>
          <NavLink className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} to="/blog" onClick={closeMenu}>
            Blog
          </NavLink>
          <NavLink className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} to="/services" onClick={closeMenu}>
            Services
          </NavLink>
          <NavLink className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} to="/about" onClick={closeMenu}>
            Über uns
          </NavLink>
          <NavLink className={styles.contactLink} to="/contact" onClick={closeMenu}>
            Kontakt aufnehmen
          </NavLink>
        </nav>
        <button
          className={`${styles.burger} ${menuOpen ? styles.burgerOpen : ''}`}
          onClick={toggleMenu}
          aria-label="Menü umschalten"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;