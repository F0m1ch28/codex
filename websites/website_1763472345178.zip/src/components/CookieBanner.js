import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'kolivareon_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div>
        <h4>Cookies &amp; Datenschutz</h4>
        <p>
          Wir verwenden technisch notwendige Cookies, um grundlegende Funktionen dieser Plattform zu gewährleisten. Du kannst unsere
          <a href="/privacy"> Datenschutzerklärung</a> jederzeit einsehen.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" onClick={acceptCookies} className={styles.acceptBtn}>
          Einverstanden
        </button>
        <a className={styles.moreLink} href="/privacy">
          Mehr erfahren
        </a>
      </div>
    </div>
  );
};

export default CookieBanner;