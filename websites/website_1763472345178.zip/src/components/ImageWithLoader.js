import React, { useState } from 'react';
import styles from './ImageWithLoader.module.css';

const ImageWithLoader = ({ src, alt, className, lazy = true }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={`${styles.wrapper} ${className || ''}`}>
      {!loaded && <div className={styles.loader} aria-hidden="true" />}
      <img
        src={src}
        alt={alt}
        loading={lazy ? 'lazy' : 'eager'}
        onLoad={() => setLoaded(true)}
        className={`${styles.image} ${loaded ? styles.visible : ''}`}
      />
    </div>
  );
};

export default ImageWithLoader;