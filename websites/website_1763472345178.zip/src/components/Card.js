import React from 'react';
import styles from './Card.module.css';

const Card = ({ title, description, icon, linkLabel, to }) => (
  <div className={styles.card}>
    <div className={styles.icon} aria-hidden="true">
      {icon}
    </div>
    <h3>{title}</h3>
    <p>{description}</p>
    {linkLabel && to && (
      <a className={styles.link} href={to}>
        {linkLabel}
        <span aria-hidden="true">→</span>
      </a>
    )}
  </div>
);

export default Card;