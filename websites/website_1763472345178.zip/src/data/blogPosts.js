const blogPosts = [
  {
    slug: 'zeit-sparen-mit-ki',
    title: 'Mit KI jede Woche mehrere Stunden zurückholen',
    date: '2024-03-20',
    readingTime: '7 Min.',
    categories: ['Produktivität', 'Arbeitsalltag'],
    excerpt:
      'Wie Du mit klaren Prompts, sanften Automationen und realistischem Erwartungsmanagement täglich 2–3 Stunden freischaufeln kannst – ohne Mehrstress.',
    heroImage: 'https://picsum.photos/1200/800?random=401',
    content: [
      'KI soll helfen, nicht noch eine To-do-Liste erzeugen. Unser Ansatz bei Kolivareon: kleine, konsistente Schritte, die sich in Deinen Alltag legen lassen. Wir beginnen mit E-Mail-Entwürfen, Checklisten und Meeting-Vorbereitungen – Aufgaben, die Du sofort spürst.',
      'Starte mit einer klaren Fragestellung: Was kostet Dich aktuell die meiste Zeit? Erstelle anschließend eine kleine Sammlung an Prompt-Templates, die genau diese Aufgabe abbilden. Zum Beispiel: „Schreibe eine wertschätzende Antwort auf diese Anfrage, max. 120 Wörter, mit einer klaren nächsten Aktion.“',
      'Automationen sind kein „Alles-oder-nichts“-Projekt. Schon eine einfache Kombination aus KI-Textbausteinen und Deinem E-Mail-Client spart täglich Minuten. Wichtig: Nachjustieren, Ergebnisse prüfen, Erwartungen realistischer halten als Marketing-Versprechen. So wächst Dein Vertrauen und Du erhöhst schrittweise die Komplexität.',
      'Zum Schluss: Reflektiere jede Woche kurz, welche Routine funktioniert und wo Du nachschärfen musst. KI ist ein Lernpartner – je besser Du Dein Ziel kommunizierst, desto relevanter werden die Ergebnisse.'
    ]
  },
  {
    slug: 'strukturierte-recherche-mit-ki',
    title: 'Strukturierte Recherche mit KI: Von Fragen zu Erkenntnissen',
    date: '2024-02-28',
    readingTime: '6 Min.',
    categories: ['Recherche', 'Wissen'],
    heroImage: 'https://picsum.photos/1200/800?random=402',
    excerpt:
      'Recherche ist mehr als Google-Ergebnisse. Wir zeigen Dir, wie Du mit KI klare Hypothesen formulierst, Quellen prüfst und innerhalb von 30 Minuten ein solides Recherche-Briefing erstellst.',
    content: [
      'Beginne mit einem Recherche-Canvas: Thema, Ziel, vorhandenes Wissen, offene Fragen. Dieses Raster liefert der KI den Kontext, den sie für relevante Vorschläge braucht.',
      'Nutze Rollenwechsel in Deinen Prompts („Du bist eine Fachjournalistin...“) und fordere immer Quellen oder zumindest Strukturierungsvorschläge an. Markiere Bereiche, die Du selbst nachprüfen willst.',
      'Verdichte die Ergebnisse anschließend manuell. KI liefert Inspiration und Muster, Du übernimmst das Fakten-Checking. Wenn Du diese Arbeitsteilung akzeptierst, wird Recherche schneller und bleibt gleichzeitig verlässlich.',
      'Unser Tipp: Speichere erfolgreiche Recherche-Prompts als Vorlagen. So baust Du Dir ein wachsendes Wissensarchiv auf, das Du für zukünftige Projekte wiederverwenden kannst.'
    ]
  },
  {
    slug: 'teams-ki-fit-machen',
    title: 'Teams KI-fit machen – ohne Überforderung',
    date: '2024-01-30',
    readingTime: '8 Min.',
    categories: ['Teamarbeit', 'Change-Management'],
    heroImage: 'https://picsum.photos/1200/800?random=403',
    excerpt:
      'KI-Workflows im Team funktionieren nur, wenn alle das gleiche Verständnis teilen. Wir zeigen Dir, wie Du mit Lernpfaden, Peer-Sessions und transparenten Regeln Vertrauen aufbaust.',
    content: [
      'Der erste Schritt ist immer Orientierung. Schaffe einen gemeinsamen Wissensstand und definiere einen klaren Rahmen: Was dürfen wir mit KI automatisieren? Welche Daten bleiben intern? Wer ist Ansprechpartner:in bei Fragen?',
      'Führe kurze Peer-Trainings ein. Je zwei Personen tauschen eine Aufgabe und testen eine KI-Lösung. Nach 30 Minuten werden Ergebnisse geteilt, Learnings dokumentiert und Prompts in einer Bibliothek hinterlegt.',
      'Setze auf kurze Feedback-Loops. Einmal pro Woche sammelt ihr Quick Wins, Stolpersteine und Ideen. So bleiben alle im Dialog und die Skepsis verliert an Gewicht.',
      'Wichtig: Nimm die emotionale Ebene ernst. Nicht jede Person springt mit Begeisterung in neue Tools. Verständnis, Ruhe und die Betonung, dass es um Entlastung geht, schaffen eine nachhaltige Lernkultur.'
    ]
  }
];

export default blogPosts;