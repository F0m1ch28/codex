document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navToggle.classList.toggle('is-active');
      mainNav.classList.toggle('is-active');
    });
  }

  const cookieBanner = document.getElementById('cookieBanner');
  const consentStatus = localStorage.getItem('raiznativaCookieConsent');

  if (cookieBanner && !consentStatus) {
    cookieBanner.classList.add('is-visible');
  }

  document.querySelectorAll('[data-cookie-action]').forEach(button => {
    button.addEventListener('click', () => {
      const action = button.getAttribute('data-cookie-action');
      localStorage.setItem('raiznativaCookieConsent', action === 'accept' ? 'accepted' : 'declined');
      if (cookieBanner) {
        cookieBanner.classList.remove('is-visible');
      }
    });
  });
});