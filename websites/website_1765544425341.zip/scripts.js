document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navigation = document.getElementById('primary-navigation');
  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');
  const yearTargets = document.querySelectorAll('.current-year');
  const consentKey = 'qazlearnCookieConsent';

  if (navToggle && navigation) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      navigation.classList.toggle('open');
    });
  }

  const currentYear = new Date().getFullYear();
  yearTargets.forEach((el) => {
    el.textContent = currentYear;
  });

  if (cookieBanner) {
    const existingConsent = localStorage.getItem(consentKey);

    if (!existingConsent) {
      cookieBanner.classList.add('visible');
    }

    acceptBtn?.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'accepted');
      cookieBanner.classList.remove('visible');
    });

    declineBtn?.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'declined');
      cookieBanner.classList.remove('visible');
    });
  }
});