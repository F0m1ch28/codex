document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.getElementById('primaryNav');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('open');
        });

        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    // Service detail interactions
    const serviceCards = document.querySelectorAll('.service-card[data-detail]');
    const serviceDetail = document.getElementById('serviceDetail');

    if (serviceCards.length && serviceDetail) {
        const activateCard = card => {
            serviceCards.forEach(c => c.classList.remove('active'));
            card.classList.add('active');
            serviceDetail.textContent = card.dataset.detail;
        };

        serviceCards.forEach(card => {
            card.addEventListener('click', () => activateCard(card));
            card.addEventListener('keypress', event => {
                if (event.key === 'Enter') {
                    activateCard(card);
                }
            });
        });

        activateCard(serviceCards[0]);
    }

    // Project highlight interactions
    const highlightButtons = document.querySelectorAll('.highlight-btn');
    const caseTitle = document.getElementById('caseTitle');
    const caseText = document.getElementById('caseText');
    const caseImage = document.getElementById('caseImage');

    const caseData = {
        smartcity: {
            title: 'Smart City · Азаматтарға арналған цифрлық сервис',
            text: 'Қалалық инфрақұрылымға арналған мобильді қосымшаның UX картасын жаңартып, push-коммуникация сценарийлері арқылы қолданушылардың белсенділігін арттырдық.',
            image: 'https://picsum.photos/800/600?random=108',
            alt: 'AstanaVision Smart City жобасының интерфейсі'
        },
        edtech: {
            title: 'EdTech · Оқушыларға арналған омниарна экожүйесі',
            text: 'Бірнеше платформаны біріктіріп, оқушылар үшін бейімделген білім беру жолын құрдық. Контент автоматтандыру арқылы курстарға жазылу жылдамдады.',
            image: 'https://picsum.photos/800/600?random=109',
            alt: 'AstanaVision әзірлеген EdTech платформасы'
        },
        hospitality: {
            title: 'Hospitality · Қонақжай бренді үшін жаңарту',
            text: 'Визуалды сәйкестік пен storytelling қайта жасалды. Онлайн брондау тәжірибесі жеңілдеп, брендтің әлеуметтік медиа әсері күшейді.',
            image: 'https://picsum.photos/800/600?random=110',
            alt: 'AstanaVision hospitality бренді үшін әзірлеген дизайн'
        }
    };

    if (highlightButtons.length && caseTitle && caseText && caseImage) {
        const activateCase = button => {
            highlightButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            const key = button.dataset.case;
            if (caseData[key]) {
                caseTitle.textContent = caseData[key].title;
                caseText.textContent = caseData[key].text;
                caseImage.src = caseData[key].image;
                caseImage.alt = caseData[key].alt;
            }
        };

        highlightButtons.forEach(button => {
            button.addEventListener('click', () => activateCase(button));
            button.addEventListener('keypress', event => {
                if (event.key === 'Enter') {
                    activateCase(button);
                }
            });
        });

        activateCase(highlightButtons[0]);
    }

    // Scroll to top button
    const scrollButton = document.getElementById('scrollToTop');
    if (scrollButton) {
        const toggleScrollButton = () => {
            if (window.scrollY > 250) {
                scrollButton.classList.add('visible');
            } else {
                scrollButton.classList.remove('visible');
            }
        };
        window.addEventListener('scroll', toggleScrollButton);
        toggleScrollButton();

        scrollButton.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Cookie banner
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');

    if (cookieBanner && acceptCookiesBtn) {
        const consent = localStorage.getItem('av_cookie_consent');
        if (consent) {
            cookieBanner.classList.add('hidden');
        } else {
            cookieBanner.classList.remove('hidden');
        }

        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('av_cookie_consent', 'true');
            cookieBanner.classList.add('hidden');
        });
    }

    // Contact form simulation
    const contactForm = document.getElementById('contactForm');
    const formStatus = document.getElementById('formStatus');

    if (contactForm && formStatus) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            contactForm.reset();
            formStatus.textContent = 'Рақмет! Хабарламаңыз сәтті жіберілді.';
            formStatus.classList.add('visible');
            setTimeout(() => {
                formStatus.classList.remove('visible');
                formStatus.textContent = '';
            }, 5000);
        });
    }
});