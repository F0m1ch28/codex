document.addEventListener('DOMContentLoaded', () => {
  // Mobile navigation
  const navToggle = document.querySelector('.nav-toggle');
  const menu = document.getElementById('menu-principal');

  if (navToggle && menu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
      navToggle.setAttribute('aria-expanded', !expanded);
      menu.style.display = expanded ? 'none' : 'flex';
    });

    // Close menu on link click for mobile
    menu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          menu.style.display = 'none';
          navToggle.setAttribute('aria-expanded', false);
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });
  }

  // Scroll to top button
  const scrollTopBtn = document.getElementById('scrollTop');
  if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 400) {
        scrollTopBtn.style.display = 'block';
      } else {
        scrollTopBtn.style.display = 'none';
      }
    });

    scrollTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // Cookie banner logic
  const cookieBanner = document.getElementById('cookie-banner');
  const acceptCookiesBtn = document.getElementById('acceptCookies');
  const cookiesAccepted = localStorage.getItem('cookiesAccepted');

  if (!cookiesAccepted) {
    cookieBanner.style.display = 'block';
  }

  if (acceptCookiesBtn) {
    acceptCookiesBtn.addEventListener('click', () => {
      localStorage.setItem('cookiesAccepted', 'true');
      cookieBanner.style.display = 'none';
    });
  }

  // Contact form handling
  const contactForm = document.getElementById('contact-form');
  const formMessage = document.getElementById('form-message');

  if (contactForm && formMessage) {
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();

      const nombre = contactForm.nombre.value.trim();
      const email = contactForm.email.value.trim();
      const mensaje = contactForm.mensaje.value.trim();
      const politica = contactForm.politica.checked;

      if (!nombre || !email || !mensaje || !politica) {
        formMessage.textContent = 'Por favor, completa todos los campos requeridos.';
        formMessage.style.color = '#9c2b2b';
        return;
      }

      formMessage.textContent = 'Gracias por tu mensaje. Nos pondremos en contacto contigo muy pronto.';
      formMessage.style.color = '#0f2c4c';
      contactForm.reset();
    });
  }
});