document.addEventListener("DOMContentLoaded", function () {
  const banner = document.getElementById("cookie-banner");
  if (!banner) {
    return;
  }
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  const manageButtons = document.querySelectorAll(".manage-cookies");
  const consentKey = "itEduCookieConsent";

  function hideBanner() {
    banner.setAttribute("hidden", "hidden");
    banner.setAttribute("aria-hidden", "true");
  }

  function showBanner() {
    banner.removeAttribute("hidden");
    banner.setAttribute("aria-hidden", "false");
  }

  function applyStoredConsent() {
    const stored = localStorage.getItem(consentKey);
    if (stored === "accepted" || stored === "declined") {
      hideBanner();
    } else {
      showBanner();
    }
  }

  acceptBtn.addEventListener("click", function () {
    localStorage.setItem(consentKey, "accepted");
    hideBanner();
  });

  declineBtn.addEventListener("click", function () {
    localStorage.setItem(consentKey, "declined");
    hideBanner();
  });

  manageButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      showBanner();
    });
  });

  applyStoredConsent();
});