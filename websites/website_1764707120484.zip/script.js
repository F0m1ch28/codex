document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  if (toggle) {
    toggle.addEventListener('click', () => {
      const expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', (!expanded).toString());
      document.body.classList.toggle('menu-open');
    });
  }

  const mq = window.matchMedia('(min-width: 768px)');
  const handleMq = event => {
    if (event.matches) {
      document.body.classList.remove('menu-open');
      if (toggle) {
        toggle.setAttribute('aria-expanded', 'false');
      }
    }
  };
  if (mq.addEventListener) {
    mq.addEventListener('change', handleMq);
  } else if (mq.addListener) {
    mq.addListener(handleMq);
  }
  handleMq(mq);

  const banner = document.querySelector('.cookie-banner');
  const accept = document.querySelector('[data-cookie-accept]');
  const decline = document.querySelector('[data-cookie-decline]');
  const storageKey = 'altaverino-cookie';
  if (banner) {
    const state = localStorage.getItem(storageKey);
    if (state) {
      banner.classList.remove('show');
      banner.setAttribute('hidden', 'hidden');
    }
    const hideBanner = () => {
      banner.classList.remove('show');
      banner.setAttribute('hidden', 'hidden');
    };
    accept?.addEventListener('click', () => {
      localStorage.setItem(storageKey, 'accepted');
      hideBanner();
    });
    decline?.addEventListener('click', () => {
      localStorage.setItem(storageKey, 'declined');
      hideBanner();
    });
  }
});