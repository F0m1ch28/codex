document.addEventListener("DOMContentLoaded", () => {
  const yearSpan = document.querySelectorAll("[data-year]");
  const currentYear = new Date().getFullYear();
  yearSpan.forEach((span) => (span.textContent = currentYear));

  // Navigation highlight
  const bodyDataPage = document.documentElement.getAttribute("data-page") || document.body.getAttribute("data-page");
  if (bodyDataPage) {
    document.querySelectorAll(".site-nav a").forEach((link) => {
      const href = link.getAttribute("href");
      if (href && href.includes(bodyDataPage)) {
        link.setAttribute("aria-current", "page");
      }
    });
  }

  // Tabs
  const tabButtons = document.querySelectorAll("[data-role='tab']");
  tabButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const targetId = button.getAttribute("aria-controls");
      const tabPanel = document.getElementById(targetId);

      button.parentElement.querySelectorAll("[data-role='tab']").forEach((btn) => {
        btn.setAttribute("aria-selected", btn === button ? "true" : "false");
      });

      const panels = button.closest(".section").querySelectorAll(".tab-panel");
      panels.forEach((panel) => {
        if (panel === tabPanel) {
          panel.hidden = false;
        } else {
          panel.hidden = true;
        }
      });
    });
  });

  // Accordion
  document.querySelectorAll("[data-accordion] .accordion-toggle").forEach((toggle) => {
    toggle.addEventListener("click", () => {
      const expanded = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!expanded));
      const panel = toggle.nextElementSibling;
      if (panel) {
        panel.hidden = expanded;
      }
    });
  });

  // Cookie Banner
  const cookieBanner = document.getElementById("cookie-banner");
  const acceptBtn = cookieBanner?.querySelector("[data-cookie-accept]");
  const declineBtn = cookieBanner?.querySelector("[data-cookie-decline]");

  const COOKIE_KEY = "cis_cookie_choice";

  if (cookieBanner) {
    const storedChoice = localStorage.getItem(COOKIE_KEY);
    if (!storedChoice) {
      cookieBanner.classList.add("active");
    }

    acceptBtn?.addEventListener("click", () => {
      localStorage.setItem(COOKIE_KEY, "accepted");
      cookieBanner.classList.remove("active");
    });

    declineBtn?.addEventListener("click", () => {
      localStorage.setItem(COOKIE_KEY, "declined");
      cookieBanner.classList.remove("active");
    });
  }
});