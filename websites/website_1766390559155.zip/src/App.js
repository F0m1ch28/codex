import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage, { ProcessPage, TechnologiesPage } from './pages/Services';
import ContactPage from './pages/Contact';
import TermsOfServicePage, { CookiePolicyPage } from './pages/TermsOfService';
import PrivacyPolicyPage from './pages/PrivacyPolicy';

function App() {
  return (
    <div className="appWrapper">
      <Header />
      <main className="mainContent" role="main">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/poslugi" element={<ServicesPage />} />
          <Route path="/protses" element={<ProcessPage />} />
          <Route path="/tekhnolohiyi" element={<TechnologiesPage />} />
          <Route path="/pro-nas" element={<AboutPage />} />
          <Route path="/kontakty" element={<ContactPage />} />
          <Route path="/umovy-vykorystannya" element={<TermsOfServicePage />} />
          <Route path="/polityka-konfidentsiinosti" element={<PrivacyPolicyPage />} />
          <Route path="/polityka-cookies" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
}

export default App;