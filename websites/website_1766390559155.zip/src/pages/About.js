import React, { useEffect } from 'react';
import styles from './About.module.css';

const usePageMeta = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) document.title = title;
    const ensureMeta = (name, content) => {
      if (!content) return;
      let tag = document.querySelector("meta[name="${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };
    ensureMeta('description', description);
    ensureMeta('keywords', keywords);
  }, [title, description, keywords]);
};

const AboutPage = () => {
  usePageMeta({
    title: 'Про AI SiteCraft | Команда, що створює цифрове майбутнє',
    description:
      'AI SiteCraft — команда стратегів, дизайнерів та інженерів, що використовують AI для створення швидких та масштабованих сайтів. Дізнайтеся нашу історію та підхід.',
    keywords: 'AI SiteCraft, команда, про нас, цифрові продукти, AI розробка'
  });

  const teamMembers = [
    {
      name: 'Марія Гончар',
      role: 'Chief Product Officer',
      description:
        'Веде discovery-сесії, відповідає за синхронізацію бізнес-цілей з продуктовими рішеннями та AI-воркфлоу.',
      photo: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: 'Іван Чумак',
      role: 'Head of AI Engineering',
      description:
        'Очолює команду, що налаштовує генеративні моделі та інтегрує AI у дизайн, контент і компонентні бібліотеки.',
      photo: 'https://images.unsplash.com/photo-1573497491765-dccce02b29df?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: 'Ольга Кравець',
      role: 'Lead UX Strategist',
      description:
        'Стежить за тим, щоб AI-рішення відповідали очікуванням користувачів, проводить UX-аудити та евристичні оцінки.',
      photo: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80'
    }
  ];

  return (
    <div className="container">
      <section className={styles.hero}>
        <h1>Ми допомагаємо компаніям будувати цифрові продукти через синергію AI та людей</h1>
        <p>
          AI SiteCraft з’явився як відповідь на виклик — як запускати сайти швидше, не жертвуючи якістю.
          Сьогодні ми поєднуємо стратегічний консалтинг, дизайн-мислення та автоматизацію, щоб наші клієнти
          могли зосередитися на розвитку бізнесу, а не процесах виробництва.
        </p>
      </section>

      <section className={styles.values}>
        <h2>Наші принципи роботи</h2>
        <div className={styles.valuesGrid}>
          <article>
            <h3>Спрямованість на результат</h3>
            <p>
              Ми мислимо метриками: від конверсій до швидкості завантаження. Кожне рішення має підтримувати KPI клієнта.
            </p>
          </article>
          <article>
            <h3>Люди і технології разом</h3>
            <p>
              AI генерує ідеї та компоненти, а команда перевіряє їх на релевантність, етику та реальні сценарії використання.
            </p>
          </article>
          <article>
            <h3>Прозорі процеси</h3>
            <p>
              Всі етапи зафіксовані: ви бачите беклог, пріоритети та результати кожного спринту у реальному часі.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.story}>
        <div className={styles.storyContent}>
          <h2>Шлях AI SiteCraft</h2>
          <p>
            Починаючи з невеликої групи ентузіастів штучного інтелекту у Києві, ми виросли у команду, що поєднує стратегію,
            дизайн, дані та розробку. Наші спеціалісти працювали над великими трансформаційними проєктами для фінансового,
            освітнього та e-commerce секторів. Ми розуміємо український ринок, але мислимо глобально.
          </p>
          <p>
            Щороку ми інвестуємо у R&amp;D, тестуємо нові AI-моделі, працюємо з ком’юніті та обмінюємося знаннями на конференціях.
            Це дозволяє нам впроваджувати найкращі практики одразу після їх появи.
          </p>
        </div>
        <div className={styles.storyVisual} aria-hidden="true">
          <img
            src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=700&q=80"
            alt=""
            loading="lazy"
          />
          <div className={styles.metricCard}>
            <strong>40+</strong>
            <span>експертів у команді: AI, UX, інженери, аналітики</span>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <h2>Лідери напрямків</h2>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.photo} alt={member.name} loading="lazy" />
              <div>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default AboutPage;