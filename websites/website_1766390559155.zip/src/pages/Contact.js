import React, { useEffect, useState } from 'react';
import styles from './Contact.module.css';

const usePageMeta = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) document.title = title;
    const ensureMeta = (name, content) => {
      if (!content) return;
      let tag = document.querySelector("meta[name="${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };
    ensureMeta('description', description);
    ensureMeta('keywords', keywords);
  }, [title, description, keywords]);
};

const initialState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const ContactPage = () => {
  usePageMeta({
    title: 'Контакти AI SiteCraft | Запросити консультацію',
    description:
      'Зв’яжіться з AI SiteCraft: консультації, аудит, запуск AI-генерованих сайтів. Телефон, email, форма зворотного зв’язку.',
    keywords: 'контакти, консультація, AI SiteCraft, форма зворотного зв’язку'
  });

  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
    setStatus('');
  };

  const validate = () => {
    const currentErrors = {};
    if (!formData.name || formData.name.trim().length < 2) {
      currentErrors.name = 'Вкажіть ім’я від 2 символів.';
    }
    if (!formData.email || !/^\S+@\S+\.\S+$/.test(formData.email)) {
      currentErrors.email = 'Вкажіть коректний email.';
    }
    if (!formData.message || formData.message.trim().length < 10) {
      currentErrors.message = 'Опишіть запит щонайменше у 10 символів.';
    }
    return currentErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setStatus('Дякуємо! Ми зв’яжемося з вами протягом одного робочого дня.');
    setFormData(initialState);
  };

  return (
    <div className={styles.wrapper}>
      <div className="container">
        <section className={styles.intro}>
          <h1>Поговорімо про ваш наступний цифровий продукт</h1>
          <p>
            Заповніть форму або зв’яжіться з нами напряму. Ми підготуємо індивідуальний план: від discovery-сесії до запуску AI-генерованого сайту.
          </p>
        </section>

        <div className={styles.layout}>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.fieldGroup}>
              <label htmlFor="name">Ім’я</label>
              <input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                type="text"
                placeholder="Як до вас звертатися?"
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </div>

            <div className={styles.fieldGroup}>
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                type="email"
                placeholder="name@company.com"
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </div>

            <div className={styles.fieldGroup}>
              <label htmlFor="company">Компанія (опціонально)</label>
              <input
                id="company"
                name="company"
                value={formData.company}
                onChange={handleChange}
                type="text"
                placeholder="Назва компанії"
              />
            </div>

            <div className={styles.fieldGroup}>
              <label htmlFor="message">Що плануєте створити?</label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows={6}
                placeholder="Опишіть задачу, строк та бажаний результат"
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </div>

            <button type="submit" className={styles.submitButton}>
              Надіслати
            </button>
            {status && <p className={styles.success}>{status}</p>}
            <p className={styles.notice}>
              Надсилаючи форму, ви погоджуєтеся з <a href="/umovy-vykorystannya">умовами використання</a> та{' '}
              <a href="/polityka-konfidentsiinosti">політикою конфіденційності</a>.
            </p>
          </form>

          <aside className={styles.contactCard}>
            <h2>Контактні дані</h2>
            <p>вул. Технологічна, 15, м. Київ, 02000</p>
            <a href="tel:+380441234567" className={styles.contactLink}>
              +380 (44) 123-45-67
            </a>
            <a href="mailto:info@aisitecraft.ua" className={styles.contactLink}>
              info@aisitecraft.ua
            </a>
            <div className={styles.schedule}>
              <h3>Графік роботи</h3>
              <p>Пн-Пт: 09:00 — 19:00</p>
              <p>Субота: за попереднім записом</p>
            </div>
            <div className={styles.mapPreview} aria-hidden="true">
              <img
                src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=500&q=80"
                alt=""
                loading="lazy"
              />
              <span>Команда AI SiteCraft у Києві</span>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;