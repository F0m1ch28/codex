import React, { useEffect } from 'react';
import styles from './Legal.module.css';

const usePageMeta = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) document.title = title;
    const ensureMeta = (name, content) => {
      if (!content) return;
      let tag = document.querySelector("meta[name="${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };
    ensureMeta('description', description);
    ensureMeta('keywords', keywords);
  }, [title, description, keywords]);
};

const TermsOfServicePage = () => {
  usePageMeta({
    title: 'Умови використання | AI SiteCraft',
    description:
      'Ознайомтеся з умовами використання сайту AI SiteCraft: права та обов’язки користувачів, правила конфіденційності, відповідальність.',
    keywords: 'умови використання, правила, AI SiteCraft'
  });

  return (
    <div className={styles.wrapper}>
      <div className="container">
        <h1>Умови використання AI SiteCraft</h1>
        <p className={styles.update}>Останнє оновлення: 12 квітня 2024 року</p>

        <section>
          <h2>1. Загальні положення</h2>
          <p>
            Ці Умови використання (далі — «Умови») регулюють доступ до веб-сайту AI SiteCraft та користування ним. Відвідуючи сайт,
            ви погоджуєтеся дотримуватися Умов та чинного законодавства України.
          </p>
        </section>

        <section>
          <h2>2. Інтелектуальна власність</h2>
          <p>
            Усі матеріали, включно з текстами, візуальними елементами, логотипами, є власністю AI SiteCraft або використовуються на підставі ліцензій.
            Заборонено копіювати, поширювати чи змінювати матеріали без письмової згоди правовласника.
          </p>
        </section>

        <section>
          <h2>3. Обов’язки користувача</h2>
          <ul>
            <li>Надавати достовірну інформацію під час комунікації з AI SiteCraft.</li>
            <li>Не здійснювати дій, що можуть нашкодити роботі сайту або третіх осіб.</li>
            <li>Використовувати інформацію із сайту виключно в законних цілях.</li>
          </ul>
        </section>

        <section>
          <h2>4. Відповідальність</h2>
          <p>
            AI SiteCraft не несе відповідальності за будь-які збитки, спричинені використанням сайту або інформації на ньому. Ми залишаємо за собою право
            змінювати чи оновлювати контент без попереднього повідомлення.
          </p>
        </section>

        <section>
          <h2>5. Зміни Умов</h2>
          <p>
            Ми можемо оновлювати Умови з метою відображення змін у законодавстві та сервісах. Актуальна версія завжди доступна на цій сторінці. Продовження
            користування сайтом після змін означає прийняття нових умов.
          </p>
        </section>

        <section>
          <h2>6. Зв’язок</h2>
          <p>
            Якщо у вас є запитання щодо Умов використання, напишіть нам на <a href="mailto:info@aisitecraft.ua">info@aisitecraft.ua</a> або зателефонуйте за номером{' '}
            <a href="tel:+380441234567">+380 (44) 123-45-67</a>.
          </p>
        </section>
      </div>
    </div>
  );
};

export const CookiePolicyPage = () => {
  usePageMeta({
    title: 'Політика cookies | AI SiteCraft',
    description:
      'Політика використання cookies на сайті AI SiteCraft: які файли ми застосовуємо, для чого вони потрібні та як їх контролювати.',
    keywords: 'cookies, політика, AI SiteCraft'
  });

  return (
    <div className={styles.wrapper}>
      <div className="container">
        <h1>Політика використання cookies</h1>
        <p className={styles.update}>Останнє оновлення: 12 квітня 2024 року</p>

        <section>
          <h2>Що таке cookies?</h2>
          <p>
            Cookies — це невеликі текстові файли, які зберігаються у вашому браузері під час відвідування сайту. Вони допомагають нам забезпечити стабільну
            роботу сервісу та покращувати досвід взаємодії.
          </p>
        </section>

        <section>
          <h2>Які cookies ми використовуємо?</h2>
          <ul>
            <li><strong>Функціональні:</strong> забезпечують базову роботу сайту, збереження налаштувань.</li>
            <li><strong>Аналітичні:</strong> дозволяють розуміти, як користувачі взаємодіють із контентом, щоб удосконалювати його.</li>
            <li><strong>Маркетингові:</strong> використовуються для персоналізації контенту та повідомлень.</li>
          </ul>
        </section>

        <section>
          <h2>Як керувати cookies?</h2>
          <p>
            Ви можете змінити налаштування cookies у своєму браузері. Зверніть увагу, що відключення деяких файлів може вплинути на роботу сайту.
          </p>
        </section>

        <section>
          <h2>Зв’язок із нами</h2>
          <p>
            Питання щодо політики cookies надсилайте на <a href="mailto:info@aisitecraft.ua">info@aisitecraft.ua</a>.
          </p>
        </section>
      </div>
    </div>
  );
};

export default TermsOfServicePage;