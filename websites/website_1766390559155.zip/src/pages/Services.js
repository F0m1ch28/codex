import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './Services.module.css';

const usePageMeta = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) document.title = title;
    const ensureMeta = (name, content) => {
      if (!content) return;
      let tag = document.querySelector("meta[name="${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };
    ensureMeta('description', description);
    ensureMeta('keywords', keywords);
  }, [title, description, keywords]);
};

const ServicesPage = () => {
  usePageMeta({
    title: 'Послуги AI SiteCraft | Генерація веб-сайтів під ключ',
    description:
      'Комплексні послуги AI SiteCraft: AI-генерація дизайнів, контенту та React-компонентів, інтеграції з CRM, SEO-оптимізація та підтримка.',
    keywords: 'послуги, AI генерація, веб-розробка, React, дизайн, автоматизація'
  });

  const services = [
    {
      title: 'AI-дизайн та UX-концепти',
      description:
        'Генеруємо дизайн-систему, UX-фрейми та контентні патерни, адаптовані під бренд і цілі бізнесу. Живі прототипи вже на першому тижні.'
    },
    {
      title: 'Розробка на React',
      description:
        'Збираємо UI-кіти, створюємо компонентну бібліотеку, підключаємо headless CMS та автоматизуємо деплой. Код чистий, масштабований, тестований.'
    },
    {
      title: 'AI-контент і локалізації',
      description:
        'Створюємо мультимовні тексти, мікрокопі та сценарії взаємодії. Застосовуємо AI для адаптації під різні сегменти аудиторії.'
    },
    {
      title: 'Інтеграції та автоматизація',
      description:
        'Підключаємо CRM, маркетингову аналітику, чат-боти, e-commerce модулі. Автоматизуємо ключові процеси через API та сценарії.'
    }
  ];

  const deliverables = [
    'Discovery-воркшоп і Product Vision',
    'AI-генеровані дизайн-системи та UI-компоненти',
    'Розгортання у хмарі, CI/CD пайплайни',
    'SEO, аналітика, продуктивність Lighthouse 90+',
    'Пакет документації та навчання команди'
  ];

  return (
    <div className="container">
      <section className={styles.hero}>
        <h1>Від ідеї до релізу — повна AI-екосистема для вашого сайту</h1>
        <p>
          Ми поєднуємо стратегічний підхід, генеративні AI-алгоритми та ручну експертизу, щоб створювати сайти, які відповідають бізнес-цілям з першого дня.
        </p>
        <Link to="/kontakty" className={styles.heroButton}>
          Обговорити потреби
        </Link>
      </section>

      <section className={styles.servicesSection}>
        <h2>Що ми робимо</h2>
        <div className={styles.servicesGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.deliverables}>
        <div className={styles.deliverablesCard}>
          <h2>Що ви отримуєте</h2>
          <ul>
            {deliverables.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
        <div className={styles.sideVisual} aria-hidden="true">
          <img
            src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=700&q=80"
            alt=""
            loading="lazy"
          />
        </div>
      </section>
    </div>
  );
};

export const ProcessPage = () => {
  usePageMeta({
    title: 'Процес роботи AI SiteCraft | Структура та етапи',
    description:
      'Дізнайтеся про процес AI SiteCraft: discovery, AI-проєктування, реалізація, інтеграції, валідація та підтримка. Прозорість на кожному кроці.',
    keywords: 'процес розробки, етапи, discovery, AI дизайн, реліз'
  });

  const steps = [
    {
      title: 'Дослідження',
      details:
        'Бізнес-інтерв’ю, аудит цифрових активів, аналіз даних. Формуємо дорожню карту та success metrics.'
    },
    {
      title: 'Генеративне проєктування',
      details:
        'Запускаємо AI-воркшопи: дизайн-системи, tone-of-voice, інформаційна архітектура. Перевірка UX-сценаріїв.'
    },
    {
      title: 'Delivery-спринти',
      details:
        'Розробка React-компонентів, інтеграція API, налаштування SEO та контент-менеджменту. Кожні 7 днів — демо.'
    },
    {
      title: 'Запуск і гіпотези',
      details:
        'Перформанс-тести, аналітика, A/B-експерименти, навчання команди та супровід під час масштабування.'
    }
  ];

  return (
    <div className="container">
      <section className={styles.processHero}>
        <h1>Формула співпраці, яка тримає фокус на результаті</h1>
        <p>
          Ми будуємо процес так, щоб рішення народжувалися швидко, але завжди залишалися контрольованими. AI допомагає генерувати,
          люди — валідують, бізнес — отримує цінність.
        </p>
      </section>
      <div className={styles.processTimeline}>
        {steps.map((step, index) => (
          <article key={step.title}>
            <span className={styles.processIndex}>{index + 1}</span>
            <h3>{step.title}</h3>
            <p>{step.details}</p>
          </article>
        ))}
      </div>
    </div>
  );
};

export const TechnologiesPage = () => {
  usePageMeta({
    title: 'Технології AI SiteCraft | Стек для швидких релізів',
    description:
      'Технологічний стек AI SiteCraft: React 18, серверніless-сервіси, headless CMS, AI-інструменти, автоматизація та безпека.',
    keywords: 'технології, React, AI інструменти, headless CMS, CI/CD'
  });

  const stackGroups = [
    {
      title: 'Фронтенд та UI',
      tools: ['React 18', 'TypeScript', 'Vite/Cra Migration', 'Storybook', 'Design Tokens']
    },
    {
      title: 'AI та автоматизація',
      tools: ['OpenAI & Azure OpenAI', 'Midjourney', 'Custom Prompt Pipelines', 'LangChain', 'AI QA bots']
    },
    {
      title: 'Контент та дані',
      tools: ['Headless CMS (Contentful, Strapi)', 'Sanity', 'ElasticSearch', 'GA4 & Looker Studio']
    },
    {
      title: 'Інфраструктура',
      tools: ['Netlify', 'Vercel', 'AWS Amplify', 'Docker', 'GitHub Actions', 'Cloudflare']
    }
  ];

  return (
    <div className="container">
      <section className={styles.techHero}>
        <h1>Стек, який витримує масштаб та складні інтеграції</h1>
        <p>
          Кожна технологія обрана для того, щоб зменшити час до релізу, підвищити безпеку та створити простір для розвитку продукту.
        </p>
      </section>
      <div className={styles.techGrid}>
        {stackGroups.map((group) => (
          <article key={group.title} className={styles.techCard}>
            <h3>{group.title}</h3>
            <ul>
              {group.tools.map((tool) => (
                <li key={tool}>{tool}</li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </div>
  );
};

export default ServicesPage;