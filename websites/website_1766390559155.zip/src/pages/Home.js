import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const usePageMeta = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    const ensureMeta = (name, content) => {
      if (!content) return;
      let tag = document.querySelector("meta[name="${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };
    ensureMeta('description', description);
    ensureMeta('keywords', keywords);
  }, [title, description, keywords]);
};

const HomePage = () => {
  usePageMeta({
    title: 'AI SiteCraft | Генеруємо сайти за допомогою штучного інтелекту',
    description:
      'AI SiteCraft створює сучасні веб-сайти з використанням штучного інтелекту, React та автоматизації. Ми прискорюємо запуск цифрових продуктів для бізнесів в Україні.',
    keywords:
      'AI SiteCraft, генерація сайтів, AI, штучний інтелект, React, веб-розробка, автоматизація'
  });

  const benefits = [
    {
      title: 'AI-дизайн, який адаптується',
      description:
        'Моделі генеративного дизайну підбирають компоненти та стилі під бренд, а команда UX перевіряє кожен сценарій.'
    },
    {
      title: 'Запуск за тижні, а не місяці',
      description:
        'Синхронізовані пайплайни з Git, CI/CD та автоматичними тестами скорочують час від ідеї до релізу.'
    },
    {
      title: 'Персоналізація під реальні дані',
      description:
        'Підключаємо CRM, аналітику та AI-персоналізацію, щоб контент підлаштовувався під аудиторію в реальному часі.'
    },
    {
      title: 'Безпека та масштабованість',
      description:
        'Використовуємо перевірені технології, налаштовуємо захист та готуємо інфраструктуру до високих навантажень.'
    }
  ];

  const processSteps = [
    {
      title: 'Аналітика та цілі',
      description:
        'Проводимо Discovery-сесію, уточнюємо ключові бізнес-показники, формуємо дорожню карту та компоненти для генерації.'
    },
    {
      title: 'AI-проєктування',
      description:
        'Генеруємо дизайн-концепти, UX-флоу та контентні блоки. Далі UX/UI команда проводить стрес-тестування і корекції.'
    },
    {
      title: 'Реалізація та інтеграції',
      description:
        'Збираємо сайт на React, додаємо headless CMS, налаштовуємо SEO, валідуємо на різних пристроях та форматах.'
    },
    {
      title: 'Навчання та підтримка',
      description:
        'Передаємо документацію, навчаємо команду працювати з AI-інструментами, забезпечуємо безперервний моніторинг.'
    }
  ];

  const technologies = [
    'React 18', 'Next Generation AI Models', 'Node & Serverless', 'Headless CMS', 'Figma Tokens', 'CI/CD Pipelines'
  ];

  const audiences = [
    {
      title: 'B2B-компанії',
      description:
        'Швидко створюємо Landing Page та мультисторінкові сайти для лідогенерації, інтегровані з CRM та аналітикою.'
    },
    {
      title: 'Стартапи',
      description:
        'З MVP до масштабування: тестові гіпотези за доби, A/B тестування та адаптація контенту за допомогою AI.'
    },
    {
      title: 'Маркетингові агенції',
      description:
        'Автоматизоване створення сторінок кампаній, білінг через API та кастомні шаблони під клієнтські бренди.'
    }
  ];

  const testimonials = [
    {
      quote:
        'AI SiteCraft допомогли нам перевести продуктову презентацію в інтерактивний сайт за 14 днів. Конверсії зросли на 38%.',
      name: 'Катерина Савчук',
      role: 'CMO, FinTech-стартап',
      avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80'
    },
    {
      quote:
        'Команда побудувала повний генеративний пайплайн. Тепер новий лендинг запускаємо за декілька годин, а не тижнів.',
      name: 'Артем Долинський',
      role: 'Директор маркетингу, SaaS',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80'
    },
    {
      quote:
        'Фокус на безпеці та масштабуванні дозволив нам підготуватися до пікового трафіку без додаткових витрат.',
      name: 'Олена Мельник',
      role: 'COO, eCommerce-платформа',
      avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80'
    }
  ];

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.heroLabel}>AI-генерація сайтів нового покоління</span>
            <h1>Генеруємо сайти, які мислять, аналізують та зростають разом із вашим бізнесом</h1>
            <p>
              Від discovery-сесії до автоматизованого релізу: AI SiteCraft створює цифрові продукти, що поєднують дизайн, контент і
              технології. Ми забезпечуємо швидкість, масштабованість та персоналізацію на кожному етапі.
            </p>
            <div className={styles.heroButtons}>
              <Link to="/kontakty" className={styles.primaryButton}>
                Замовити консультацію
              </Link>
              <Link to="/tekhnolohiyi" className={styles.secondaryButton}>
                Переглянути технології
              </Link>
            </div>
            <div className={styles.heroStats}>
              <div>
                <strong>120+</strong>
                <span>згенерованих сторінок за останні 12 місяців</span>
              </div>
              <div>
                <strong>18 днів</strong>
                <span>середній час від бріфу до першого релізу</span>
              </div>
              <div>
                <strong>97%</strong>
                <span>клієнтів продовжують співпрацю після запуску</span>
              </div>
            </div>
          </div>
          <div className={styles.heroIllustration} aria-hidden="true">
            <div className={styles.sparkCard}>
              <h3>AI SiteCraft Pipeline</h3>
              <ul>
                <li>Генерація дизайн-системи</li>
                <li>Контент на базі LLM</li>
                <li>React-компоненти</li>
                <li>SEO та аналітика</li>
                <li>CI/CD інфраструктура</li>
              </ul>
              <div className={styles.statusBadge}>Результат: готовий сайт</div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className="container">
          <h2>Чому AI SiteCraft?</h2>
          <p className={styles.sectionSubtitle}>
            Поєднуємо штучний інтелект із людським досвідом, щоб ваш цифровий продукт був точним, швидким і безпечним.
          </p>
          <div className={styles.benefitsGrid}>
            {benefits.map((item) => (
              <article key={item.title} className={styles.benefitCard}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Як це працює?</h2>
            <Link to="/protses" className={styles.linkButton}>
              Детальніше про процес
            </Link>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processCard}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.technologies}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Технології, на яких ми будуємо</h2>
            <Link to="/tekhnolohiyi" className={styles.linkButton}>
              Технічні деталі
            </Link>
          </div>
          <div className={styles.techGrid}>
            {technologies.map((tech) => (
              <div key={tech} className={styles.techItem}>
                {tech}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.audience}>
        <div className="container">
          <h2>Для кого наші рішення?</h2>
          <p className={styles.sectionSubtitle}>
            Ми допомагаємо командам, які прагнуть масштабувати цифрові продукти та швидко тестувати ідеї.
          </p>
          <div className={styles.audienceGrid}>
            {audiences.map((audience) => (
              <article key={audience.title} className={styles.audienceCard}>
                <h3>{audience.title}</h3>
                <p>{audience.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <h2>Партнери про співпрацю</h2>
          <div className={styles.testimonialGrid}>
            {testimonials.map((item) => (
              <blockquote key={item.name} className={styles.testimonialCard}>
                <p>“{item.quote}”</p>
                <div className={styles.testimonialFooter}>
                  <img src={item.avatar} alt={item.name} loading="lazy" />
                  <div>
                    <strong>{item.name}</strong>
                    <span>{item.role}</span>
                  </div>
                </div>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaWrapper}>
            <div>
              <h2>Запросіть персоналізовану AI-демонстрацію</h2>
              <p>
                Дізнайтеся, як AI SiteCraft допоможе вашому бізнесу згенерувати сайт, що вирішує конкретні задачі: від лідогенерації до e-commerce.
              </p>
            </div>
            <Link to="/kontakty" className={styles.ctaButton}>
              Забронювати зустріч
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;