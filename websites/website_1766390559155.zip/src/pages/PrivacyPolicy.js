import React, { useEffect } from 'react';
import styles from './Legal.module.css';

const usePageMeta = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) document.title = title;
    const ensureMeta = (name, content) => {
      if (!content) return;
      let tag = document.querySelector("meta[name="${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };
    ensureMeta('description', description);
    ensureMeta('keywords', keywords);
  }, [title, description, keywords]);
};

const PrivacyPolicyPage = () => {
  usePageMeta({
    title: 'Політика конфіденційності | AI SiteCraft',
    description:
      'Політика конфіденційності AI SiteCraft: як ми збираємо, використовуємо та захищаємо персональні дані користувачів.',
    keywords: 'конфіденційність, персональні дані, AI SiteCraft'
  });

  return (
    <div className={styles.wrapper}>
      <div className="container">
        <h1>Політика конфіденційності AI SiteCraft</h1>
        <p className={styles.update}>Останнє оновлення: 12 квітня 2024 року</p>

        <section>
          <h2>1. Мета політики</h2>
          <p>
            Ми цінуємо ваше право на приватність. Ця політика пояснює, які персональні дані ми збираємо, з якою метою та як їх обробляємо відповідно
            до законодавства України.
          </p>
        </section>

        <section>
          <h2>2. Які дані ми збираємо</h2>
          <ul>
            <li>Ім’я, email, номер телефону, якщо ви надсилаєте запит через форму.</li>
            <li>Інформацію про компанію та проект, яку ви добровільно надаєте.</li>
            <li>Технічні дані: IP-адресу, тип браузера, час відвідування.</li>
          </ul>
        </section>

        <section>
          <h2>3. Як ми використовуємо дані</h2>
          <p>
            Дані використовуються для комунікації з вами, надання послуг, покращення досвіду користувача, а також для аналітики та безпеки.
            Ми не продаємо та не передаємо ваші дані третім сторонам без вашої згоди.
          </p>
        </section>

        <section>
          <h2>4. Зберігання та захист</h2>
          <p>
            Ми застосовуємо сучасні технічні та організаційні заходи для захисту даних. Доступ до інформації мають лише уповноважені співробітники.
          </p>
        </section>

        <section>
          <h2>5. Ваші права</h2>
          <p>
            Ви можете звернутися до нас для уточнення, оновлення або видалення персональних даних. Напишіть на{' '}
            <a href="mailto:info@aisitecraft.ua">info@aisitecraft.ua</a>, і ми відповімо протягом 30 днів.
          </p>
        </section>

        <section>
          <h2>6. Зміни політики</h2>
          <p>
            Ми можемо оновлювати цю політику для врахування законодавчих змін чи нових сервісів. Рекомендуємо періодично переглядати сторінку.
          </p>
        </section>
      </div>
    </div>
  );
};

export default PrivacyPolicyPage;