import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={styles.container}>
        <div className={styles.brandColumn}>
          <h2 id="footer-heading" className={styles.logo}>
            AI<span>SiteCraft</span>
          </h2>
          <p className={styles.description}>
            Ми поєднуємо творчість, штучний інтелект та сучасні фреймворки, щоб генерувати сайти, які швидко адаптуються до бізнес-цілей та масштабуються разом із вами.
          </p>
          <div className={styles.socials} aria-label="Соціальні мережі">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
              <svg viewBox="0 0 24 24" role="img" aria-hidden="true">
                <path d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM.4 8.5H4.6V24H.4zM8.1 8.5H12v2.1h.06c.54-1.02 1.86-2.1 3.83-2.1 4.1 0 4.86 2.7 4.86 6.2V24h-4.2v-7.7c0-1.83-.03-4.18-2.55-4.18-2.55 0-2.94 1.99-2.94 4.05V24H8.1z" />
              </svg>
            </a>
            <a href="https://www.facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook">
              <svg viewBox="0 0 24 24" role="img" aria-hidden="true">
                <path d="M22.67 0H1.33A1.33 1.33 0 0 0 0 1.33v21.34A1.33 1.33 0 0 0 1.33 24h11.49V14.7h-3.13v-3.62h3.13V8.41c0-3.1 1.9-4.79 4.66-4.79 1.33 0 2.47.1 2.8.14v3.25h-1.92c-1.5 0-1.8.72-1.8 1.77v2.32h3.6l-.47 3.62h-3.13V24h6.14A1.33 1.33 0 0 0 24 22.67V1.33A1.33 1.33 0 0 0 22.67 0" />
              </svg>
            </a>
            <a href="https://www.twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
              <svg viewBox="0 0 24 24" role="img" aria-hidden="true">
                <path d="M21.54 6.09c.01.17.01.34.01.52 0 5.3-4.03 11.41-11.41 11.41-2.26 0-4.36-.66-6.13-1.81a8.08 8.08 0 0 0 5.95-1.67 4.02 4.02 0 0 1-3.75-2.78c.25.05.51.07.78.07.37 0 .73-.05 1.07-.15a4 4 0 0 1-3.22-3.93v-.05c.54.3 1.16.48 1.82.5A4 4 0 0 1 3.3 4.44a11.4 11.4 0 0 0 8.27 4.2 4.02 4.02 0 0 1 6.84-3.67 8.04 8.04 0 0 0 2.55-.97 4.03 4.03 0 0 1-1.77 2.23 8.02 8.02 0 0 0 2.31-.63 8.17 8.17 0 0 1-2.03 2.08z" />
              </svg>
            </a>
          </div>
        </div>
        <div className={styles.linksColumn}>
          <h3>Навігація</h3>
          <ul>
            <li><Link to="/">Головна</Link></li>
            <li><Link to="/poslugi">Послуги</Link></li>
            <li><Link to="/protses">Процес роботи</Link></li>
            <li><Link to="/tekhnolohiyi">Технології</Link></li>
            <li><Link to="/pro-nas">Про нас</Link></li>
            <li><Link to="/kontakty">Контакти</Link></li>
          </ul>
        </div>
        <div className={styles.linksColumn}>
          <h3>Правова інформація</h3>
          <ul>
            <li><Link to="/umovy-vykorystannya">Умови використання</Link></li>
            <li><Link to="/polityka-konfidentsiinosti">Політика конфіденційності</Link></li>
            <li><Link to="/polityka-cookies">Політика cookies</Link></li>
          </ul>
        </div>
        <div className={styles.contactColumn}>
          <h3>Контакти</h3>
          <p>вул. Технологічна, 15<br />м. Київ, 02000</p>
          <a href="tel:+380441234567">+380 (44) 123-45-67</a>
          <a href="mailto:info@aisitecraft.ua">info@aisitecraft.ua</a>
          <p className={styles.workingHours}>Працюємо з понеділка по п’ятницю, 09:00-19:00</p>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© {new Date().getFullYear()} AI SiteCraft. Усі права захищено.</p>
        <p className={styles.madeBy}>Створено з турботою про майбутнє цифрових продуктів.</p>
      </div>
    </footer>
  );
};

export default Footer;