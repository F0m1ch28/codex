import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'aiSiteCraftCookieConsent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      const timeout = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timeout);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(COOKIE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <strong>Ми використовуємо cookies.</strong> Це допомагає нам зробити взаємодію з AI SiteCraft
        ще зручнішою. Продовжуючи користуватися сайтом, ви погоджуєтеся з нашою{' '}
        <Link to="/polityka-cookies">політикою cookies</Link> та{' '}
        <Link to="/polityka-konfidentsiinosti">політикою конфіденційності</Link>.
      </div>
      <button type="button" className={styles.acceptButton} onClick={handleAccept}>
        Зрозуміло
      </button>
    </div>
  );
};

export default CookieBanner;