import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const renderNavLink = (to, label) => (
    <NavLink
      to={to}
      className={({ isActive }) =>
        "${styles.navLink} ${isActive ? styles.navLinkActive : ''}"
      }
      onClick={() => setMenuOpen(false)}
    >
      {label}
    </NavLink>
  );

  return (
    <header className={styles.header}>
      <div className={styles.topBar}>
        <p className={styles.topBarText}>
          <span>Телефон: <a href="tel:+380441234567">+380 (44) 123-45-67</a></span>
          <span>Email: <a href="mailto:info@aisitecraft.ua">info@aisitecraft.ua</a></span>
          <span>Адреса: вул. Технологічна, 15, м. Київ, 02000</span>
        </p>
      </div>
      <div className={styles.navBar}>
        <NavLink to="/" className={styles.logo} onClick={() => setMenuOpen(false)}>
          <span className={styles.logoMark}>AI</span>
          <span className={styles.logoText}>SiteCraft</span>
        </NavLink>
        <button
          className={styles.mobileToggle}
          aria-label="Перемкнути меню"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={"${styles.nav} ${menuOpen ? styles.navOpen : ''}"} aria-label="Основна навігація">
          {renderNavLink('/', 'Головна')}
          {renderNavLink('/poslugi', 'Послуги')}
          {renderNavLink('/protses', 'Процес роботи')}
          {renderNavLink('/tekhnolohiyi', 'Технології')}
          {renderNavLink('/pro-nas', 'Про нас')}
          {renderNavLink('/kontakty', 'Контакти')}
          {renderNavLink('/umovy-vykorystannya', 'Умови')}
          {renderNavLink('/polityka-konfidentsiinosti', 'Конфіденційність')}
          {renderNavLink('/polityka-cookies', 'Cookies')}
          <NavLink
            to="/kontakty"
            className={styles.ctaButton}
            onClick={() => setMenuOpen(false)}
          >
            Записатися на демо
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;