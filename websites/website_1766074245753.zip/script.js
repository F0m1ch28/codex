(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    initNavigation();
    initHeaderObserver();
    initCounters();
    initSliders();
    initAccordions();
    initFooterYear();
    initCookieBanner();
  });

  function initNavigation() {
    const nav = document.querySelector("[data-nav]");
    const toggle = document.querySelector("[data-nav-toggle]");
    if (!nav || !toggle) return;

    toggle.addEventListener("click", function () {
      const expanded = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!expanded));
      nav.classList.toggle("is-open", !expanded);
    });

    nav.querySelectorAll("[data-nav-link]").forEach(function (link) {
      link.addEventListener("click", function () {
        toggle.setAttribute("aria-expanded", "false");
        nav.classList.remove("is-open");
      });
    });
  }

  function initHeaderObserver() {
    const header = document.querySelector("[data-header]");
    if (!header) return;

    const onScroll = function () {
      header.classList.toggle("is-scrolled", window.scrollY > 12);
    };

    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  function initCounters() {
    const counters = document.querySelectorAll("[data-count]");
    if (!counters.length) return;

    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (prefersReducedMotion) {
      counters.forEach((counter) => {
        const value = Number(counter.getAttribute("data-count"));
        if (!Number.isNaN(value)) {
          counter.textContent = value.toString();
        }
      });
      return;
    }

    const animateCounter = (entry) => {
      const el = entry.target;
      const target = Number(el.getAttribute("data-count"));
      if (Number.isNaN(target)) return;
      const duration = 1600;
      let start;
      const step = (timestamp) => {
        if (!start) start = timestamp;
        const progress = Math.min((timestamp - start) / duration, 1);
        const eased = easeOutCubic(progress);
        el.textContent = Math.floor(eased * target).toString();
        if (progress < 1) {
          requestAnimationFrame(step);
        } else {
          el.textContent = target.toString();
        }
      };
      requestAnimationFrame(step);
      observer.unobserve(el);
    };

    const observer = new IntersectionObserver(
      (entries) => entries.filter((entry) => entry.isIntersecting).forEach(animateCounter),
      { threshold: 0.4 }
    );

    counters.forEach((counter) => observer.observe(counter));
  }

  function easeOutCubic(t) {
    return 1 - Math.pow(1 - t, 3);
  }

  function initSliders() {
    const sliderContainers = document.querySelectorAll("[data-slider]");
    if (!sliderContainers.length) return;

    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    sliderContainers.forEach((container) => {
      const track = container.querySelector(".case-slider-track");
      const slides = Array.from(container.querySelectorAll(".case-slide"));
      if (!track || !slides.length) return;

      const dotsWrapper = container.querySelector("[data-slider-dots]");
      let index = 0;
      const interval = Number(container.getAttribute("data-interval")) || 7000;
      let autoplay;

      if (dotsWrapper) {
        slides.forEach((_, idx) => {
          const dot = document.createElement("button");
          dot.type = "button";
          dot.setAttribute("aria-label", `Show slide ${idx + 1}`);
          dot.addEventListener("click", () => goToSlide(idx, true));
          dotsWrapper.appendChild(dot);
        });
      }

      const updateDots = () => {
        if (!dotsWrapper) return;
        dotsWrapper.querySelectorAll("button").forEach((dot, dotIndex) => {
          dot.setAttribute("aria-current", dotIndex === index ? "true" : "false");
        });
      };

      const goToSlide = (targetIndex, stopAutoplay) => {
        index = (targetIndex + slides.length) % slides.length;
        track.style.transform = `translateX(-${index * 100}%)`;
        updateDots();
        if (stopAutoplay && autoplay) {
          clearInterval(autoplay);
          autoplay = null;
        }
      };

      if (!prefersReducedMotion && slides.length > 1) {
        autoplay = setInterval(() => goToSlide(index + 1, false), interval);
        container.addEventListener("pointerenter", () => {
          if (autoplay) {
            clearInterval(autoplay);
            autoplay = null;
          }
        });
        container.addEventListener("pointerleave", () => {
          if (!autoplay) {
            autoplay = setInterval(() => goToSlide(index + 1, false), interval);
          }
        });
      }

      updateDots();
    });
  }

  function initAccordions() {
    const triggers = document.querySelectorAll("[data-accordion-trigger]");
    if (!triggers.length) return;

    triggers.forEach((trigger) => {
      const item = trigger.closest(".faq-item");
      const panel = item ? item.querySelector("[data-accordion-panel]") : null;
      if (!item || !panel) return;

      trigger.addEventListener("click", () => {
        const expanded = trigger.getAttribute("aria-expanded") === "true";
        trigger.setAttribute("aria-expanded", String(!expanded));
        item.classList.toggle("is-open", !expanded);
        if (!expanded) {
          panel.style.maxHeight = panel.scrollHeight + "px";
        } else {
          panel.style.maxHeight = "";
        }
      });
    });
  }

  function initFooterYear() {
    const yearSpans = document.querySelectorAll("[data-year]");
    const year = new Date().getFullYear();
    yearSpans.forEach((span) => (span.textContent = String(year)));
  }

  function initCookieBanner() {
    const banner = document.querySelector("[data-cookie-banner]");
    if (!banner) return;

    const acceptButton = banner.querySelector("[data-accept]");
    const rejectButton = banner.querySelector("[data-reject]");
    const customizeButton = banner.querySelector("[data-customize]");
    const saveButton = banner.querySelector("[data-save]");
    const cancelButton = banner.querySelector("[data-cancel]");
    const panel = banner.querySelector("[data-cookie-panel]");
    const analyticsToggle = banner.querySelector('[data-preference="analytics"]');
    const marketingToggle = banner.querySelector('[data-preference="marketing"]');
    const storageKey = "luminaforge_cookie_preferences";
    const bannerVisibleClass = "is-visible";
    const expandedClass = "is-expanded";

    const loadPreferences = () => {
      try {
        const saved = localStorage.getItem(storageKey);
        return saved ? JSON.parse(saved) : null;
      } catch (error) {
        console.warn("Unable to read cookie preferences", error);
        return null;
      }
    };

    const persistPreferences = (preferences) => {
      try {
        localStorage.setItem(storageKey, JSON.stringify(preferences));
      } catch (error) {
        console.warn("Unable to save cookie preferences", error);
      }
      syncPreferences(preferences);
    };

    const syncPreferences = (preferences) => {
      fetch("/api/preferences", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          source: "cookie-banner",
          recordedAt: new Date().toISOString(),
          preferences
        })
      }).catch((error) => {
        console.warn("Preference sync failed", error);
      });
    };

    const hideBanner = () => {
      banner.classList.add("is-hidden");
      setTimeout(() => {
        if (banner && banner.parentElement) {
          banner.parentElement.removeChild(banner);
        }
      }, 320);
    };

    const showBanner = () => {
      requestAnimationFrame(() => {
        banner.classList.add(bannerVisibleClass);
      });
    };

    const applyPreferencesToControls = (preferences) => {
      if (analyticsToggle) analyticsToggle.checked = Boolean(preferences.analytics);
      if (marketingToggle) marketingToggle.checked = Boolean(preferences.marketing);
    };

    const stored = loadPreferences();
    if (stored) {
      applyPreferencesToControls(stored);
      hideBanner();
    } else {
      showBanner();
    }

    if (acceptButton) {
      acceptButton.addEventListener("click", () => {
        const preferences = {
          necessary: true,
          analytics: true,
          marketing: true,
          timestamp: new Date().toISOString(),
          version: "1.0.0"
        };
        persistPreferences(preferences);
        hideBanner();
      });
    }

    if (rejectButton) {
      rejectButton.addEventListener("click", () => {
        if (analyticsToggle) analyticsToggle.checked = false;
        if (marketingToggle) marketingToggle.checked = false;
        const preferences = {
          necessary: true,
          analytics: false,
          marketing: false,
          timestamp: new Date().toISOString(),
          version: "1.0.0"
        };
        persistPreferences(preferences);
        hideBanner();
      });
    }

    if (customizeButton && panel) {
      customizeButton.addEventListener("click", () => {
        const isExpanded = banner.classList.toggle(expandedClass);
        customizeButton.setAttribute("aria-expanded", String(isExpanded));
        panel.setAttribute("aria-hidden", String(!isExpanded));
      });
    }

    if (cancelButton && panel) {
      cancelButton.addEventListener("click", () => {
        banner.classList.remove(expandedClass);
        panel.setAttribute("aria-hidden", "true");
      });
    }

    if (saveButton) {
      saveButton.addEventListener("click", () => {
        const preferences = {
          necessary: true,
          analytics: analyticsToggle ? analyticsToggle.checked : false,
          marketing: marketingToggle ? marketingToggle.checked : false,
          timestamp: new Date().toISOString(),
          version: "1.0.0"
        };
        persistPreferences(preferences);
        hideBanner();
      });
    }
  }
})();