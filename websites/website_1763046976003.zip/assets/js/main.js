document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.main-nav');
    const scrollTopBtn = document.getElementById('scrollTop');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAccept = document.getElementById('cookieAccept');
    const contactForm = document.getElementById('contactForm');
    const formMessage = document.getElementById('formMessage');
    const yearSpan = document.getElementById('year');
    const navLinks = document.querySelectorAll('.nav-menu a');

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !expanded);
            navMenu.classList.toggle('open');
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', event => {
            const href = link.getAttribute('href');
            const isSamePageAnchor = href && href.startsWith('#');
            if (navMenu.classList.contains('open')) {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
            if (isSamePageAnchor) {
                event.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                } else {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                }
            } else {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    });

    window.addEventListener('scroll', () => {
        if (window.scrollY > 250) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    });

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const cookieConsentKey = 'tavirnoCookieConsent';
    if (cookieBanner) {
        if (!localStorage.getItem(cookieConsentKey)) {
            cookieBanner.classList.add('show');
        }
    }

    if (cookieAccept) {
        cookieAccept.addEventListener('click', () => {
            localStorage.setItem(cookieConsentKey, new Date().toISOString());
            cookieBanner.classList.remove('show');
        });
    }

    if (contactForm && formMessage) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            let valid = true;
            for (const [key, value] of formData.entries()) {
                if (!value.trim()) {
                    valid = false;
                    break;
                }
            }
            if (!valid) {
                formMessage.textContent = 'Bitte füllen Sie alle Pflichtfelder aus.';
                formMessage.style.color = '#dc2626';
                return;
            }
            formMessage.textContent = 'Vielen Dank! Ihre Nachricht wurde übermittelt.';
            formMessage.style.color = '#16a34a';
            contactForm.reset();
        });
    }
});