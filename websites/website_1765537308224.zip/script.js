document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      siteNav.classList.toggle('is-open');
      document.body.classList.toggle('nav-open');
    });

    siteNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        siteNav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('nav-open');
      });
    });
  }

  const banner = document.querySelector('[data-cookie-banner]');
  if (!banner) return;

  const storageKey = 'croatiaExperienceConsent';
  const storedDecision = localStorage.getItem(storageKey);

  if (!storedDecision) {
    banner.classList.remove('is-hidden');
  }

  const acceptBtn = banner.querySelector('[data-cookie-accept]');
  const declineBtn = banner.querySelector('[data-cookie-decline]');

  const closeBanner = (decision) => {
    localStorage.setItem(storageKey, decision);
    banner.classList.add('is-hidden');
  };

  acceptBtn?.addEventListener('click', () => closeBanner('accepted'));
  declineBtn?.addEventListener('click', () => closeBanner('declined'));
});