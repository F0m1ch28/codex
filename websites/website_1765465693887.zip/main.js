document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = siteNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    siteNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (siteNav.classList.contains('is-open')) {
          siteNav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const filterButtons = document.querySelectorAll('.course-filters [data-filter]');
  const courseCards = document.querySelectorAll('.course-card');

  if (filterButtons.length && courseCards.length) {
    filterButtons.forEach(button => {
      button.addEventListener('click', () => {
        const target = button.dataset.filter;
        filterButtons.forEach(btn => btn.classList.remove('is-active'));
        button.classList.add('is-active');

        courseCards.forEach(card => {
          const categories = card.dataset.category.split(' ');
          if (target === 'all' || categories.includes(target)) {
            card.style.display = 'grid';
            card.classList.remove('is-hidden');
          } else {
            card.style.display = 'none';
            card.classList.add('is-hidden');
          }
        });
      });
    });
  }

  const faqButtons = document.querySelectorAll('.faq-item button');
  if (faqButtons.length) {
    faqButtons.forEach(button => {
      button.addEventListener('click', () => {
        const expanded = button.getAttribute('aria-expanded') === 'true';
        faqButtons.forEach(btn => {
          btn.setAttribute('aria-expanded', 'false');
          const content = btn.nextElementSibling;
          if (content) {
            content.style.maxHeight = null;
          }
        });
        if (!expanded) {
          button.setAttribute('aria-expanded', 'true');
          const content = button.nextElementSibling;
          if (content) {
            content.style.maxHeight = content.scrollHeight + 'px';
          }
        }
      });
    });
  }

  const contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    const status = contactForm.querySelector('.form-status');
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const requiredFields = ['fullName', 'email', 'interest', 'message'];
      let hasError = false;

      requiredFields.forEach(field => {
        const fieldElement = contactForm.querySelector(`[name="${field}"]`);
        if (fieldElement && !fieldElement.value.trim()) {
          hasError = true;
          fieldElement.setAttribute('aria-invalid', 'true');
        } else if (fieldElement) {
          fieldElement.removeAttribute('aria-invalid');
        }
      });

      const email = formData.get('email');
      const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || '');
      if (!emailValid) {
        hasError = true;
        const emailField = contactForm.querySelector('[name="email"]');
        if (emailField) {
          emailField.setAttribute('aria-invalid', 'true');
        }
      }

      if (hasError) {
        status.textContent = 'Please complete the required fields with valid information.';
        status.classList.remove('success');
        status.classList.add('error');
        return;
      }

      status.textContent = 'Thanks! Our learning advisors will contact you shortly.';
      status.classList.remove('error');
      status.classList.add('success');
      contactForm.reset();
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const cookieKey = 'itebCookieChoice';

  if (cookieBanner) {
    const savedChoice = localStorage.getItem(cookieKey);
    if (!savedChoice) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add('is-visible');
        cookieBanner.setAttribute('aria-hidden', 'false');
      });
    }

    cookieBanner.querySelectorAll('[data-cookie-action]').forEach(button => {
      button.addEventListener('click', () => {
        const action = button.dataset.cookieAction;
        localStorage.setItem(cookieKey, action);
        cookieBanner.classList.remove('is-visible');
        cookieBanner.setAttribute('aria-hidden', 'true');
      });
    });
  }
});