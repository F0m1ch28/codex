document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('[data-nav-toggle]');
    var navMenu = document.querySelector('[data-nav-menu]');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            var expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('is-open');
        });
        navMenu.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.innerWidth < 900) {
                    navMenu.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    var cookieBanner = document.querySelector('[data-cookie-banner]');
    var acceptCookie = document.querySelector('[data-cookie-accept]');
    var declineCookie = document.querySelector('[data-cookie-decline]');
    var storageKey = 'parCookieConsent';
    if (cookieBanner) {
        var stored = null;
        try {
            stored = localStorage.getItem(storageKey);
        } catch (err) {
            stored = null;
        }
        if (!stored) {
            cookieBanner.classList.add('is-visible');
        }
        var closeBanner = function (value) {
            cookieBanner.classList.remove('is-visible');
            try {
                localStorage.setItem(storageKey, value);
            } catch (err) {
                /* silent */
            }
        };
        if (acceptCookie) {
            acceptCookie.addEventListener('click', function () {
                closeBanner('accepted');
            });
        }
        if (declineCookie) {
            declineCookie.addEventListener('click', function () {
                closeBanner('declined');
            });
        }
    }

    var postsContainer = document.querySelector('[data-post-list]');
    if (postsContainer) {
        var posts = Array.prototype.slice.call(postsContainer.querySelectorAll('[data-post]'));
        var searchInput = document.querySelector('[data-post-search]');
        var filterButtons = document.querySelectorAll('[data-post-filter]');
        var paginationContainer = document.querySelector('[data-pagination]');
        var prevButton = document.querySelector('[data-pagination-prev]');
        var nextButton = document.querySelector('[data-pagination-next]');
        var currentPageElement = document.querySelector('[data-pagination-current]');
        var totalPagesElement = document.querySelector('[data-pagination-total]');
        var perPage = 6;
        var currentPage = 1;
        var currentCategory = 'toate';
        var currentSearch = '';

        var applyFilters = function () {
            return posts.filter(function (post) {
                var matchesCategory = currentCategory === 'toate' || post.getAttribute('data-category') === currentCategory;
                var matchesSearch = true;
                if (currentSearch.trim() !== '') {
                    var text = post.textContent.toLowerCase();
                    matchesSearch = text.indexOf(currentSearch.toLowerCase()) !== -1;
                }
                return matchesCategory && matchesSearch;
            });
        };

        var renderPosts = function () {
            var filtered = applyFilters();
            var totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
            if (currentPage > totalPages) {
                currentPage = totalPages;
            }
            var startIndex = (currentPage - 1) * perPage;
            var endIndex = startIndex + perPage;
            posts.forEach(function (post) {
                post.style.display = 'none';
            });
            filtered.slice(startIndex, endIndex).forEach(function (post) {
                post.style.display = '';
            });
            if (currentPageElement) {
                currentPageElement.textContent = String(currentPage);
            }
            if (totalPagesElement) {
                totalPagesElement.textContent = String(totalPages);
            }
            if (prevButton) {
                prevButton.disabled = currentPage <= 1;
            }
            if (nextButton) {
                nextButton.disabled = currentPage >= totalPages;
            }
            if (paginationContainer) {
                paginationContainer.style.display = filtered.length > perPage ? 'flex' : 'none';
            }
        };

        if (filterButtons.length) {
            filterButtons.forEach(function (button) {
                button.addEventListener('click', function () {
                    filterButtons.forEach(function (btn) {
                        btn.classList.remove('is-active');
                    });
                    button.classList.add('is-active');
                    currentCategory = button.getAttribute('data-post-filter');
                    currentPage = 1;
                    renderPosts();
                });
            });
        }

        if (searchInput) {
            searchInput.addEventListener('input', function (event) {
                currentSearch = event.target.value;
                currentPage = 1;
                renderPosts();
            });
        }

        if (prevButton) {
            prevButton.addEventListener('click', function () {
                if (currentPage > 1) {
                    currentPage -= 1;
                    renderPosts();
                }
            });
        }

        if (nextButton) {
            nextButton.addEventListener('click', function () {
                currentPage += 1;
                renderPosts();
            });
        }

        renderPosts();
    }
});