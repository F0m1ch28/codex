document.addEventListener('DOMContentLoaded', () => {
    const yearSpan = document.getElementById('year');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.nav');
    if (navToggle && nav) {
        navToggle.addEventListener('click', () => {
            const isOpen = nav.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });
    }

    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-link').forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPage || (currentPage === '' && href === 'index.html')) {
            link.classList.add('is-active');
        }
    });

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.js-cookie-accept');
    const declineBtn = document.querySelector('.js-cookie-decline');
    const cookieKey = 'stromivanta_cookie_pref';

    const hideCookieBanner = () => {
        cookieBanner?.classList.remove('is-visible');
    };

    if (cookieBanner) {
        const storedPref = localStorage.getItem(cookieKey);
        if (!storedPref) {
            setTimeout(() => {
                cookieBanner.classList.add('is-visible');
            }, 500);
        }
        acceptBtn?.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'accepted');
            hideCookieBanner();
        });
        declineBtn?.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'declined');
            hideCookieBanner();
        });
    }

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', (event) => {
            const targetId = anchor.getAttribute('href').substring(1);
            const target = document.getElementById(targetId);
            if (target) {
                event.preventDefault();
                target.scrollIntoView({ behavior: 'smooth' });
                nav?.classList.remove('is-open');
                navToggle?.setAttribute('aria-expanded', 'false');
            }
        });
    });
});