document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.site-header .nav-links');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const isOpen = navLinks.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen);
    });
  }

  const pageKey = document.body.dataset.page;
  if (pageKey) {
    const headerLinks = document.querySelectorAll('.site-header .nav-links a');
    headerLinks.forEach((link) => {
      if (link.dataset.nav === pageKey) {
        link.classList.add('is-active');
        link.setAttribute('aria-current', 'page');
      }
    });

    const footerLinks = document.querySelectorAll('.site-footer .nav-links a');
    footerLinks.forEach((link) => {
      if (link.dataset.nav === pageKey) {
        link.classList.add('is-active');
        link.setAttribute('aria-current', 'page');
      }
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const storedPreference = localStorage.getItem('cc-cookie-preference');
    if (!storedPreference) {
      setTimeout(() => {
        cookieBanner.classList.add('is-visible');
      }, 1000);
    }

    cookieBanner.addEventListener('click', (event) => {
      const action = event.target.dataset.cookieAction;
      if (!action) return;

      if (action === 'accept') {
        localStorage.setItem('cc-cookie-preference', 'accepted');
      } else if (action === 'decline') {
        localStorage.setItem('cc-cookie-preference', 'declined');
      }
      cookieBanner.classList.remove('is-visible');
      setTimeout(() => cookieBanner.remove(), 400);
    });
  }

  const planRadios = document.querySelectorAll('input[name="plan"]');
  const planAmountInput = document.getElementById('planAmount');
  const planHash = document.getElementById('planHash');
  const planSpeed = document.getElementById('planSpeed');
  const planCost = document.getElementById('planCost');
  const planDetail = document.getElementById('planDetail');
  const planName = document.getElementById('planName');

  const baseHash = 25; // GH/s granted as partial hash for registration
  const planDescriptions = {
    starter: 'Ideal for introductions. Doubles your partial hash and unlocks automated monitoring.',
    growth: 'Balances cost and speed for early scaling with predictive load balancing.',
    professional: 'Suited for professional operators needing 8x throughput and API analytics.',
    enterprise: 'Dedicated channels, custom SLA, and priority extraction orchestration.',
    custom: 'Tailor your extraction speed to campaign goals. Higher deposits unlock private clusters.'
  };

  function formatSpeed(value) {
    return `${value.toFixed(1)} GH/s`;
  }

  function updatePlanSummary(dataset, amount, id) {
    if (!planHash || !planSpeed || !planCost || !planDetail || !planName) return;
    const multiplier = parseFloat(dataset.multiplier || 1);
    const bonus = parseFloat(dataset.bonus || 0);
    const effectiveSpeed = baseHash * multiplier + bonus;
    planHash.textContent = `${formatSpeed(baseHash)} base + ${formatSpeed(effectiveSpeed - baseHash)} upgrade`;
    planSpeed.textContent = `${formatSpeed(effectiveSpeed)} total extraction speed`;
    planCost.textContent = `${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT (TRC20)`;
    planDetail.textContent = planDescriptions[id] || '';
    planName.textContent = dataset.planLabel || 'Custom Plan';
  }

  function handlePlanChange(event) {
    const radio = event.target;
    if (!radio || !radio.dataset) return;
    const dataset = radio.dataset;
    const amount = dataset.amount ? parseFloat(dataset.amount) : parseFloat(planAmountInput.value) || 100;
    if (radio.id === 'plan-custom') {
      planAmountInput.removeAttribute('readonly');
      planAmountInput.focus();
    } else {
      planAmountInput.value = amount;
      planAmountInput.setAttribute('readonly', 'readonly');
    }
    updatePlanSummary(dataset, amount, radio.id);
  }

  if (planRadios.length && planAmountInput) {
    planRadios.forEach((radio) => {
      radio.addEventListener('change', handlePlanChange);
    });

    planAmountInput.addEventListener('input', () => {
      const customRadio = document.getElementById('plan-custom');
      if (!customRadio) return;
      const amount = parseFloat(planAmountInput.value) || 0;
      if (amount < 50) {
        planAmountInput.value = '50';
        return;
      }
      const dataset = customRadio.dataset;
      const customMultiplier = 1 + Math.min(amount / 180, 6); // scaling multiplier
      dataset.multiplier = customMultiplier.toString();
      const bonus = Math.min(amount * 2.2, 1800);
      dataset.bonus = bonus.toString();
      updatePlanSummary(dataset, amount, customRadio.id);
    });

    const defaultRadio = document.querySelector('input[name="plan"]:checked') || planRadios[0];
    if (defaultRadio) {
      defaultRadio.checked = true;
      defaultRadio.dispatchEvent(new Event('change'));
    }
  }

  const registrationForm = document.getElementById('registrationForm');
  const registrationMessage = document.getElementById('registrationMessage');

  if (registrationForm && registrationMessage) {
    registrationForm.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!registrationForm.checkValidity()) {
        registrationForm.reportValidity();
        return;
      }
      const selectedPlan = registrationForm.querySelector('input[name="registrationPlan"]:checked');
      if (!selectedPlan) {
        alert('Select a plan to allocate your introductory hash.');
        return;
      }
      registrationMessage.textContent = 'Registration received. Partial hash will be bonded to your account within 12 minutes. A concierge will reach out by email once activation is complete.';
      registrationMessage.classList.add('is-visible');
      registrationForm.reset();
      registrationForm.querySelector('[data-default-plan]').checked = true;
    });
  }

  const copyWalletButton = document.querySelector('[data-copy-wallet]');
  if (copyWalletButton) {
    copyWalletButton.addEventListener('click', async () => {
      const walletAddress = copyWalletButton.dataset.copyWallet;
      try {
        await navigator.clipboard.writeText(walletAddress);
        copyWalletButton.textContent = 'Wallet Copied';
        setTimeout(() => {
          copyWalletButton.textContent = 'Copy Wallet Address';
        }, 2600);
      } catch (error) {
        window.prompt('Copy the wallet address manually:', walletAddress);
      }
    });
  }
});