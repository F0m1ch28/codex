import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('aurion_cookie_consent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('aurion_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          We use essential cookies to improve your browsing experience and analyze our
          energy consulting services. Review our{' '}
          <Link to="/cookie-policy">Cookie Policy</Link> for details.
        </p>
        <button type="button" className={styles.button} onClick={acceptCookies}>
          Accept
        </button>
      </div>
    </div>
  );
}

export default CookieBanner;