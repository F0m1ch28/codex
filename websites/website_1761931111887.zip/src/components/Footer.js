import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.grid}>
          <div>
            <h3 className={styles.footerTitle}>Aurion Energy Advisory</h3>
            <p className={styles.footerText}>
              Engineering-forward consulting firm supporting energy
              infrastructure and sustainable engineering programs across Canada.
            </p>
            <div className={styles.contactDetails}>
              <p>460 Bay St, Toronto, ON M5H 2Y4, Canada</p>
              <p>
                <a href="tel:+14167924583">+1 (416) 792-4583</a>
              </p>
              <p>
                <a href="mailto:hello@aurionenergyadvisory.com">
                  hello@aurionenergyadvisory.com
                </a>
              </p>
            </div>
          </div>
          <div>
            <h4 className={styles.sectionHeading}>Explore</h4>
            <ul className={styles.linkList}>
              <li>
                <NavLink to="/about">About</NavLink>
              </li>
              <li>
                <NavLink to="/services">Services</NavLink>
              </li>
              <li>
                <NavLink to="/projects">Projects</NavLink>
              </li>
              <li>
                <NavLink to="/team">Team</NavLink>
              </li>
              <li>
                <NavLink to="/contact">Contact</NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h4 className={styles.sectionHeading}>Governance</h4>
            <ul className={styles.linkList}>
              <li>
                <NavLink to="/terms">Terms of Use</NavLink>
              </li>
              <li>
                <NavLink to="/privacy">Privacy Policy</NavLink>
              </li>
              <li>
                <NavLink to="/cookie-policy">Cookie Policy</NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h4 className={styles.sectionHeading}>Connect</h4>
            <ul className={styles.socialList}>
              <li>
                <a
                  href="https://www.linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Visit Aurion Energy Advisory on LinkedIn"
                >
                  LinkedIn
                </a>
              </li>
              <li>
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Visit Aurion Energy Advisory on X"
                >
                  X
                </a>
              </li>
              <li>
                <a
                  href="https://www.youtube.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Visit Aurion Energy Advisory on YouTube"
                >
                  YouTube
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className={styles.bottomBar}>
          <p>© {new Date().getFullYear()} Aurion Energy Advisory. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;