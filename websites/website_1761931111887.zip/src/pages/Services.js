import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

function Services() {
  const services = [
    {
      title: 'Energy Consulting',
      summary:
        'Strategic advisory for integrated energy portfolios, asset modernization, and policy compliance across Canada.',
      points: [
        'Grid expansion planning and system studies',
        'Capital project governance and risk mitigation',
        'Digital transformation and performance analytics',
      ],
      image: 'https://picsum.photos/800/600?random=31',
    },
    {
      title: 'Oilfield Research',
      summary:
        'Subsurface insight and regulatory-ready research to guide oil and gas Canada developments.',
      points: [
        'Seismic interpretation and reservoir modelling',
        'Well integrity audits and production optimization',
        'Reporting packages aligned with provincial regulators',
      ],
      image: 'https://picsum.photos/800/600?random=32',
    },
    {
      title: 'Installation & Commissioning',
      summary:
        'Field engineering oversight for crane installation, modular assembly, and commissioning.',
      points: [
        'Heavy-lift planning and rigging supervision',
        'Pre-commissioning and punchlist management',
        'Mechanical completion and turnover documentation',
      ],
      image: 'https://picsum.photos/800/600?random=33',
    },
    {
      title: 'Environmental Assessment',
      summary:
        'Integrated environmental and sustainability assessments that prioritize community impact and compliance.',
      points: [
        'Baseline studies and impact statements',
        'Stakeholder engagement frameworks',
        'Mitigation planning and monitoring programs',
      ],
      image: 'https://picsum.photos/800/600?random=34',
    },
    {
      title: 'Project Management',
      summary:
        'Program controls, schedule stewardship, and multidiscipline coordination for industrial engineering projects.',
      points: [
        'Integrated master scheduling and reporting',
        'Contractor alignment and interface management',
        'Project controls and performance dashboards',
      ],
      image: 'https://picsum.photos/800/600?random=35',
    },
  ];

  return (
    <div className={styles.services}>
      <Helmet>
        <title>Services | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Explore Aurion Energy Advisory services including energy consulting, oilfield research, industrial installation, environmental assessment, and project management."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Services Built for Industrial Momentum</h1>
          <p>
            Aurion delivers structured consulting and engineering services that keep energy
            infrastructure productive, compliant, and sustainable. Whether you need
            oilfield research, crane installation oversight, or ESG integration, our teams
            provide clear pathways forward.
          </p>
        </div>
      </section>

      <section className={styles.serviceList}>
        <div className="container">
          <div className={styles.grid}>
            {services.map((service) => (
              <article key={service.title} className={styles.card}>
                <div className={styles.imageWrap}>
                  <img
                    src={service.image}
                    alt={`${service.title} delivered by Aurion Energy Advisory`}
                  />
                </div>
                <div className={styles.cardBody}>
                  <h2>{service.title}</h2>
                  <p>{service.summary}</p>
                  <ul>
                    {service.points.map((point) => (
                      <li key={point}>{point}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Services;