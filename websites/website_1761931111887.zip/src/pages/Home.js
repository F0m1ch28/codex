import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

function Home() {
  const expertise = [
    {
      title: 'Energy Consulting',
      description:
        'Strategic advisory for complex energy infrastructure, regulatory guidance, and asset optimization throughout Canada.',
    },
    {
      title: 'Oilfield Research',
      description:
        'Reservoir intelligence, seismic interpretation, and compliance-ready reporting for oil and gas programs.',
    },
    {
      title: 'Installation Logistics',
      description:
        'Precision crane installation, heavy lift coordination, and commissioning management for industrial facilities.',
    },
  ];

  const projects = [
    {
      title: 'Northern Grid Expansion',
      description:
        'High-voltage interconnect project connecting remote communities with reliable energy supply.',
      image: 'https://picsum.photos/800/600?random=1',
    },
    {
      title: 'Arctic Pipeline Readiness',
      description:
        'Pre-construction analysis, safety case development, and logistics planning for a cold-weather pipeline corridor.',
      image: 'https://picsum.photos/800/600?random=2',
    },
    {
      title: 'Coastal LNG Terminal Support',
      description:
        'Process engineering and crane installation oversight supporting LNG export infrastructure.',
      image: 'https://picsum.photos/800/600?random=3',
    },
  ];

  const testimonials = [
    {
      quote:
        'Aurion aligned every discipline on our upgrader expansion. Their technical depth and steady communication transformed the delivery timeline.',
      name: 'Elena Murray, Operations Director',
    },
    {
      quote:
        'From environmental approvals to crane sequencing, the Aurion team offered practical answers at every turn.',
      name: 'Mathieu Girard, Project Executive',
    },
  ];

  return (
    <div className={styles.home}>
      <Helmet>
        <title>Aurion Energy Advisory | Engineering the Future of Energy</title>
        <meta
          name="description"
          content="Aurion Energy Advisory offers energy consulting in Canada, oilfield research, industrial engineering, and sustainable project leadership."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={`container ${styles.heroContent}`}>
          <p className={styles.kicker}>Energy Consulting Canada</p>
          <h1>Engineering the Future of Energy</h1>
          <p className={styles.heroText}>
            Aurion Energy Advisory partners with operators, utilities, and infrastructure
            owners to deliver resilient energy systems. From oilfield research to crane
            installation and commissioning, our consultants guide each phase with
            precision.
          </p>
          <div className={styles.heroActions}>
            <Link to="/services" className={styles.primaryBtn}>
              View Services
            </Link>
            <Link to="/contact" className={styles.secondaryBtn}>
              Contact Experts
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.intro}>
        <div className="container">
          <div className={styles.introGrid}>
            <div>
              <h2>Powering Canada&apos;s Energy Transitions</h2>
            </div>
            <div>
              <p>
                Based in Toronto, Aurion Energy Advisory combines engineering insight
                with operational pragmatism. We help organizations evaluate assets, plan
                oil and gas developments, deploy industrial engineering solutions, and
                embed sustainable practices.
              </p>
              <p>
                Our multidisciplinary consultants and field engineers have delivered
                energy consulting programs from the Alberta oil sands to Atlantic Canada.
                We blend regulatory knowledge, advanced analytics, and site-tested
                methodology to keep critical infrastructure performing.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.expertise}>
        <div className="container">
          <h2 className="section-title">Our Expertise</h2>
          <div className={styles.cardGrid}>
            {expertise.map((item) => (
              <div key={item.title} className={styles.card}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.oilfield}>
        <div className="container">
          <div className={styles.splitGrid}>
            <div className={styles.imageWrap}>
              <img
                src="https://picsum.photos/800/600?random=4"
                alt="Aurion specialists reviewing oilfield research data in control room"
              />
            </div>
            <div className={styles.textBlock}>
              <h2>Oilfield Research &amp; Compliance</h2>
              <p>
                Our oilfield research teams integrate seismic interpretation, reservoir
                simulation, and regulatory compliance to inform decision-making. We
                deliver actionable reporting that satisfies provincial and federal
                obligations while equipping operators with practical development roadmaps.
              </p>
              <ul className={styles.list}>
                <li>Reservoir characterization and recovery planning</li>
                <li>Environmental impact documentation and stakeholder mapping</li>
                <li>Operational risk assessments aligned with Canadian standards</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.engineering}>
        <div className="container">
          <div className={styles.splitGridReverse}>
            <div className={styles.textBlock}>
              <h2>Engineering Solutions &amp; Industrial Logistics</h2>
              <p>
                Aurion&apos;s engineering unit oversees crane installation programs,
                modular construction, and heavy-lift logistics for energy infrastructure.
                We coordinate with EPC teams, vendors, and field crews to accelerate safe
                commissioning.
              </p>
              <ul className={styles.list}>
                <li>Crane selection, lift planning, and onsite supervision</li>
                <li>Mechanical completion and pre-commissioning support</li>
                <li>Digital twin monitoring of critical assets</li>
              </ul>
            </div>
            <div className={styles.imageWrap}>
              <img
                src="https://picsum.photos/800/600?random=5"
                alt="Industrial crane installation managed by Aurion engineering team"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.sustainability}>
        <div className="container">
          <h2>Sustainable Engineering in Practice</h2>
          <p>
            We build sustainability into every project, balancing emission reductions and
            operational resilience. From electrification studies to circular material
            plans, Aurion helps organizations meet ESG commitments without compromising
            productivity.
          </p>
          <div className={styles.badgeRow}>
            <span>Carbon Baseline Assessments</span>
            <span>Low-Carbon Technology Roadmaps</span>
            <span>Lifecycle Performance Tracking</span>
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.projectHeader}>
            <h2>Featured Industrial Projects</h2>
            <p>
              Recent engagements spanning energy infrastructure, oilfield research, and
              sustainable engineering initiatives.
            </p>
          </div>
          <div className={styles.projectGrid}>
            {projects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img
                  src={project.image}
                  alt={`${project.title} delivered by Aurion Energy Advisory`}
                />
                <div className={styles.projectContent}>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <h2>Voices from the Field</h2>
          <div className={styles.testimonialGrid}>
            {testimonials.map((item) => (
              <blockquote key={item.name} className={styles.testimonial}>
                <p>“{item.quote}”</p>
                <cite>{item.name}</cite>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <h2>Partner with Aurion</h2>
            <p>
              Let’s plan your next energy infrastructure landmark. Our consultants will
              tailor a program that combines research, engineering, and sustainable
              execution.
            </p>
            <Link to="/contact" className={styles.primaryBtn}>
              Start a Conversation
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;