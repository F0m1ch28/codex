import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function Terms() {
  return (
    <div className={styles.legal}>
      <Helmet>
        <title>Terms of Use | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Review the terms of use governing Aurion Energy Advisory’s website and services."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Terms of Use</h1>
          <p>
            These Terms outline the conditions that apply when you access the Aurion Energy
            Advisory website.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.stack}>
            <article>
              <h2>Acceptance of Terms</h2>
              <p>
                By accessing this website, you agree to comply with these Terms of Use and
                all applicable laws. If you disagree with any part of these terms, please
                discontinue use.
              </p>
            </article>
            <article>
              <h2>Professional Services</h2>
              <p>
                Information on this site is for general guidance. Specific energy consulting
                or engineering services are governed by written agreements executed between
                Aurion Energy Advisory and its clients.
              </p>
            </article>
            <article>
              <h2>Intellectual Property</h2>
              <p>
                All content, including text, graphics, and logos, is owned or licensed by
                Aurion Energy Advisory. You may not reproduce or distribute materials
                without prior written consent.
              </p>
            </article>
            <article>
              <h2>Limitation of Liability</h2>
              <p>
                Aurion Energy Advisory is not liable for damages arising from the use or
                inability to use this website. We make reasonable efforts to ensure accuracy
                but do not warrant completeness of information.
              </p>
            </article>
            <article>
              <h2>Updates</h2>
              <p>
                We may revise these Terms periodically. Continued use of the site after
                changes indicates acceptance of the updated Terms.
              </p>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Terms;