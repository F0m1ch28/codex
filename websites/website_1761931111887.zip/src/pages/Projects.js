import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Projects.module.css';

function Projects() {
  const projects = [
    {
      title: 'Prairie Wind Integration',
      location: 'Saskatchewan',
      description:
        'Grid connection and dispatch modeling for a 180 MW wind portfolio, ensuring reliable integration into provincial systems.',
      image: 'https://picsum.photos/800/600?random=41',
      tags: ['Grid Studies', 'Energy Consulting'],
    },
    {
      title: 'Basin Redevelopment Study',
      location: 'Alberta',
      description:
        'Oilfield research and reservoir analytics guiding redevelopment of mature wells with enhanced recovery strategies.',
      image: 'https://picsum.photos/800/600?random=42',
      tags: ['Oilfield Research', 'Reservoir'],
    },
    {
      title: 'Port Crane Installation',
      location: 'British Columbia',
      description:
        'Heavy-lift crane installation and commissioning for LNG terminal expansion, coordinated with marine operations.',
      image: 'https://picsum.photos/800/600?random=43',
      tags: ['Crane Installation', 'Logistics'],
    },
    {
      title: 'Northern Solar Microgrids',
      location: 'Yukon',
      description:
        'Hybrid microgrid planning and project management for remote communities seeking reliable clean energy.',
      image: 'https://picsum.photos/800/600?random=44',
      tags: ['Sustainable Engineering', 'Project Management'],
    },
    {
      title: 'Upgrader Reliability Program',
      location: 'Alberta',
      description:
        'Industrial engineering program delivering mechanical upgrades, inspection regimes, and long-term asset roadmaps.',
      image: 'https://picsum.photos/800/600?random=45',
      tags: ['Industrial Engineering', 'Asset Strategy'],
    },
    {
      title: 'Atlantic Offshore Assessment',
      location: 'Nova Scotia',
      description:
        'Environmental assessment and stakeholder engagement for offshore platform life extension.',
      image: 'https://picsum.photos/800/600?random=46',
      tags: ['Environmental Assessment', 'Stakeholder'],
    },
  ];

  return (
    <div className={styles.projects}>
      <Helmet>
        <title>Projects | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="See how Aurion Energy Advisory supports energy infrastructure projects, oilfield research, crane installations, and sustainable engineering across Canada."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Industrial Projects Delivered with Precision</h1>
          <p>
            Our portfolio spans grid modernization, oilfield research, crane installation,
            and sustainable engineering initiatives. Each project is underpinned by safety,
            rigorous analytics, and collaborative delivery.
          </p>
        </div>
      </section>

      <section className={styles.gallery}>
        <div className="container">
          <div className={styles.grid}>
            {projects.map((project) => (
              <article key={project.title} className={styles.card}>
                <img
                  src={project.image}
                  alt={`${project.title} project by Aurion Energy Advisory`}
                />
                <div className={styles.cardBody}>
                  <div className={styles.meta}>
                    <span>{project.location}</span>
                    <div className={styles.tagList}>
                      {project.tags.map((tag) => (
                        <span key={tag}>{tag}</span>
                      ))}
                    </div>
                  </div>
                  <h2>{project.title}</h2>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Projects;