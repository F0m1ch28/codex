import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

function Contact() {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
    setFormState({
      name: '',
      email: '',
      company: '',
      message: '',
    });
  };

  return (
    <div className={styles.contact}>
      <Helmet>
        <title>Contact | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Connect with Aurion Energy Advisory in Toronto for energy consulting, oilfield research, engineering, and sustainability projects."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Connect with Aurion</h1>
          <p>
            We’re ready to support energy consulting, oilfield research, industrial
            engineering, and sustainable infrastructure initiatives across Canada.
          </p>
        </div>
      </section>

      <section className={styles.details}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.infoCard}>
              <h2>Toronto Headquarters</h2>
              <ul>
                <li>460 Bay St, Toronto, ON M5H 2Y4, Canada</li>
                <li>
                  <a href="tel:+14167924583">+1 (416) 792-4583</a>
                </li>
                <li>
                  <a href="mailto:hello@aurionenergyadvisory.com">
                    hello@aurionenergyadvisory.com
                  </a>
                </li>
              </ul>
              <div className={styles.mapWrap} aria-label="Aurion Energy Advisory office map">
                <iframe
                  title="Aurion Energy Advisory Toronto office map"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.3968166252106!2d-79.38431142368657!3d43.65149687110574!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34cd3789bdad%3A0x4b4a007fa693596e!2s460%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202Y4%2C%20Canada!5e0!3m2!1sen!2sca!4v1700000000000!5m2!1sen!2sca"
                  loading="lazy"
                  allowFullScreen
                />
              </div>
            </div>

            <div className={styles.formCard}>
              <h2>Request a Consultation</h2>
              <p>
                Share a few details about your energy infrastructure, oilfield research,
                or sustainability goals. Our team will respond within one business day.
              </p>
              <form className={styles.form} onSubmit={handleSubmit}>
                <label htmlFor="name">
                  Full Name
                  <input
                    id="name"
                    name="name"
                    type="text"
                    required
                    value={formState.name}
                    onChange={handleChange}
                    placeholder="Your name"
                  />
                </label>
                <label htmlFor="email">
                  Email
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    value={formState.email}
                    onChange={handleChange}
                    placeholder="you@example.com"
                  />
                </label>
                <label htmlFor="company">
                  Company
                  <input
                    id="company"
                    name="company"
                    type="text"
                    value={formState.company}
                    onChange={handleChange}
                    placeholder="Organization name"
                  />
                </label>
                <label htmlFor="message">
                  Project Overview
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    required
                    value={formState.message}
                    onChange={handleChange}
                    placeholder="Tell us about your project"
                  />
                </label>
                <button type="submit" className={styles.submitBtn}>
                  Submit
                </button>
                {submitted && (
                  <p className={styles.confirmation} role="status">
                    Thank you. An Aurion consultant will reach out shortly.
                  </p>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Contact;