import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

function About() {
  const leadership = [
    {
      name: 'Sonia Patel',
      role: 'Managing Director',
      bio: 'Sonia leads Aurion with two decades of experience in energy consulting Canada programs, specializing in regulatory navigation and capital project governance.',
      image: 'https://picsum.photos/400/400?random=21',
    },
    {
      name: 'Lucas Tremblay, P.Eng.',
      role: 'Director of Engineering',
      bio: 'Lucas oversees industrial engineering, crane installation, and commissioning services with a focus on safety-first execution.',
      image: 'https://picsum.photos/400/400?random=22',
    },
    {
      name: 'Mara Chen',
      role: 'Head of Sustainability',
      bio: 'Mara designs sustainability strategies, carbon baselines, and stakeholder programs for oil and gas Canada projects and renewable transitions.',
      image: 'https://picsum.photos/400/400?random=23',
    },
  ];

  return (
    <div className={styles.about}>
      <Helmet>
        <title>About Aurion Energy Advisory | History & Mission</title>
        <meta
          name="description"
          content="Discover Aurion Energy Advisory's history, leadership, mission, safety philosophy, and sustainable engineering commitments."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Advancing Energy Infrastructure Since 2008</h1>
          <p className={styles.lead}>
            Aurion Energy Advisory began as a small Toronto-based engineering practice
            supporting oilfield research. Today, we unite consultants, engineers, and field
            specialists to help clients navigate evolving energy landscapes.
          </p>
        </div>
      </section>

      <section className={styles.history}>
        <div className="container">
          <div className={styles.historyGrid}>
            <div>
              <h2>Our Story</h2>
              <p>
                Founded by engineers who pioneered modular refinery upgrades, Aurion has
                steadily expanded across Canada. Our teams have delivered emission-reduction
                retrofits, electrification roadmaps, and frontier oil sands support. We
                pair deep technical insight with pragmatic field experience to keep critical
                assets operating safely.
              </p>
              <p>
                Today, we serve operators, utilities, and government agencies seeking
                transformative energy consulting, oilfield research, and industrial
                engineering execution.
              </p>
            </div>
            <div>
              <h2>Mission &amp; Values</h2>
              <ul className={styles.list}>
                <li>
                  Build resilient, efficient energy systems with measurable outcomes.
                </li>
                <li>
                  Uphold uncompromising safety performance on every site and scope.
                </li>
                <li>
                  Embed sustainability and community engagement into project delivery.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.leadership}>
        <div className="container">
          <h2>Leadership Team</h2>
          <div className={styles.leaderGrid}>
            {leadership.map((leader) => (
              <article key={leader.name} className={styles.leaderCard}>
                <img
                  src={leader.image}
                  alt={`${leader.name}, ${leader.role} at Aurion Energy Advisory`}
                />
                <div>
                  <h3>{leader.name}</h3>
                  <p className={styles.role}>{leader.role}</p>
                  <p>{leader.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.safety}>
        <div className="container">
          <div className={styles.safetyGrid}>
            <div>
              <h2>Safety Promise</h2>
              <p>
                Safety stands at the centre of Aurion&apos;s culture. We maintain ISO-based
                management systems, conduct daily toolbox talks, and invest in digital
                monitoring to prevent incidents. Our field supervision teams collaborate
                with clients to embed safety leadership into each work package.
              </p>
            </div>
            <div>
              <h2>Sustainability Commitments</h2>
              <p>
                We support sustainable engineering by integrating carbon reduction ideas,
                water stewardship, and biodiversity protection into design decisions. Aurion
                partners with communities to ensure projects respect local priorities and
                provide long-term value.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default About;