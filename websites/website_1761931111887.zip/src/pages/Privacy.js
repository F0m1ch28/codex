import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function Privacy() {
  return (
    <div className={styles.legal}>
      <Helmet>
        <title>Privacy Policy | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Learn how Aurion Energy Advisory collects, uses, and protects personal information."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Privacy Policy</h1>
          <p>
            Aurion Energy Advisory respects your privacy. This policy explains how we manage
            personal information across our digital channels.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.stack}>
            <article>
              <h2>Information We Collect</h2>
              <p>
                We collect contact details submitted through forms, along with analytical
                data related to website usage. This helps us respond to enquiries and improve
                services.
              </p>
            </article>
            <article>
              <h2>Use of Information</h2>
              <p>
                Personal information is used to communicate with you, provide requested
                energy consulting information, and share updates relevant to Aurion services.
              </p>
            </article>
            <article>
              <h2>Data Protection</h2>
              <p>
                We implement administrative, technical, and physical safeguards to maintain
                the security of personal data. Access is restricted to authorized personnel.
              </p>
            </article>
            <article>
              <h2>Third-Party Sharing</h2>
              <p>
                We do not sell personal information. Data may be shared with trusted service
                providers who support our operations, subject to confidentiality obligations.
              </p>
            </article>
            <article>
              <h2>Your Choices</h2>
              <p>
                You may request access, correction, or deletion of your information by
                contacting hello@aurionenergyadvisory.com. We respond in accordance with
                applicable privacy laws.
              </p>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Privacy;