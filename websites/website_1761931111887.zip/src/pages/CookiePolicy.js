import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function CookiePolicy() {
  return (
    <div className={styles.legal}>
      <Helmet>
        <title>Cookie Policy | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Understand how Aurion Energy Advisory uses cookies and similar technologies."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Cookie Policy</h1>
          <p>
            This Cookie Policy describes how Aurion Energy Advisory uses cookies to enhance
            your experience on our website.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.stack}>
            <article>
              <h2>What Are Cookies?</h2>
              <p>
                Cookies are small text files stored on your device. They help us understand
                how the site is used and support essential functionality.
              </p>
            </article>
            <article>
              <h2>Types of Cookies We Use</h2>
              <ul>
                <li>Essential cookies for secure navigation and session management.</li>
                <li>Analytics cookies to evaluate website performance and improve content.</li>
              </ul>
            </article>
            <article>
              <h2>Managing Cookies</h2>
              <p>
                You can adjust browser settings to block or delete cookies. Please note that
                disabling essential cookies may impact site functionality.
              </p>
            </article>
            <article>
              <h2>Contact</h2>
              <p>
                For questions about this policy, contact us at hello@aurionenergyadvisory.com.
              </p>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
}

export default CookiePolicy;