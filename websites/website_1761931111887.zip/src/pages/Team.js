import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Team.module.css';

function Team() {
  const teamMembers = [
    {
      name: 'Amelia Brooks, P.Eng.',
      role: 'Senior Energy Consultant',
      bio: 'Amelia orchestrates cross-province power system studies and leads carbon reduction audits for utilities.',
      image: 'https://picsum.photos/400/400?random=51',
    },
    {
      name: 'Rajan Joshi',
      role: 'Lead Oilfield Researcher',
      bio: 'Rajan blends reservoir modeling with regulatory compliance to help clients accelerate oilfield approvals.',
      image: 'https://picsum.photos/400/400?random=52',
    },
    {
      name: 'Fiona McKenzie',
      role: 'Project Controls Manager',
      bio: 'Fiona guides scheduling, cost engineering, and reporting for complex industrial engineering programs.',
      image: 'https://picsum.photos/400/400?random=53',
    },
    {
      name: 'Noah Campbell',
      role: 'Field Engineering Supervisor',
      bio: 'Noah manages crane installation crews, lift plans, and site commissioning activities across Canada.',
      image: 'https://picsum.photos/400/400?random=54',
    },
    {
      name: 'Isabella Garza',
      role: 'Environmental Scientist',
      bio: 'Isabella completes environmental assessments, stakeholder engagement, and ESG reporting for projects.',
      image: 'https://picsum.photos/400/400?random=55',
    },
    {
      name: 'Owen Singh',
      role: 'Digital Solutions Architect',
      bio: 'Owen deploys digital twins, remote monitoring, and analytics dashboards that keep assets performing.',
      image: 'https://picsum.photos/400/400?random=56',
    },
  ];

  return (
    <div className={styles.team}>
      <Helmet>
        <title>Team | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Meet the consultants, researchers, and engineers driving Aurion Energy Advisory projects across Canada."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Meet the Aurion Team</h1>
          <p>
            Industry-leading consultants, researchers, engineers, and field supervisors
            who bring energy infrastructure projects to life with precision and purpose.
          </p>
        </div>
      </section>

      <section className={styles.roster}>
        <div className="container">
          <div className={styles.grid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.card}>
                <img
                  src={member.image}
                  alt={`${member.name}, ${member.role} at Aurion Energy Advisory`}
                />
                <div className={styles.cardBody}>
                  <h2>{member.name}</h2>
                  <p className={styles.role}>{member.role}</p>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Team;