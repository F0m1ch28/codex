document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.getElementById('navToggle');
    const mainNav = document.getElementById('mainNav');
    const scrollBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAcceptBtn = document.getElementById('acceptCookies');
    const contactForm = document.getElementById('contactForm');
    const contactResponse = document.getElementById('contactResponse');
    const language = document.documentElement.lang || 'en';

    const successMessages = {
        en: 'Thank you. A RedLeaf Analytics advisor will reach out within two business days.',
        ru: 'Спасибо! Команда RedLeaf Analytics свяжется с вами в течение двух рабочих дней.'
    };

    const errorMessages = {
        en: 'Please complete all required fields before submitting.',
        ru: 'Пожалуйста, заполните все обязательные поля перед отправкой.'
    };

    const navLinks = document.querySelectorAll('.nav-link');

    if (navToggle && mainNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            navToggle.classList.toggle('nav-open');
            mainNav.classList.toggle('nav-open');
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (mainNav.classList.contains('nav-open')) {
                mainNav.classList.remove('nav-open');
                navToggle.classList.remove('nav-open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
            if (link.href.includes('#')) {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    });

    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 260) {
                scrollBtn.classList.add('visible');
            } else {
                scrollBtn.classList.remove('visible');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && cookieAcceptBtn) {
        const storageKey = 'redleafCookiesAccepted';
        if (!localStorage.getItem(storageKey)) {
            cookieBanner.classList.add('show');
        }

        cookieAcceptBtn.addEventListener('click', () => {
            localStorage.setItem(storageKey, 'true');
            cookieBanner.classList.remove('show');
        });
    }

    if (contactForm && contactResponse) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();

            const formData = new FormData(contactForm);
            const isComplete = Array.from(formData.values()).every(value => value.trim() !== '');

            if (!isComplete) {
                contactResponse.textContent = errorMessages[language] || errorMessages.en;
                contactResponse.style.color = '#8B0B28';
                return;
            }

            contactResponse.textContent = successMessages[language] || successMessages.en;
            contactResponse.style.color = '#4C8C6B';
            contactForm.reset();
        });
    }

    const yearSpan = document.getElementById('currentYear');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});