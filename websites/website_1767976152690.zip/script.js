document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".primary-nav");
    if (navToggle && nav) {
        navToggle.addEventListener("click", () => {
            nav.classList.toggle("active");
        });
    }

    const yearHolder = document.getElementById("current-year");
    if (yearHolder) {
        yearHolder.textContent = new Date().getFullYear();
    }

    const consentKey = "infrastructure-north-consent";
    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-accept");
    const declineBtn = document.querySelector(".cookie-decline");

    const setConsent = (value) => {
        localStorage.setItem(consentKey, JSON.stringify({
            status: value,
            timestamp: new Date().toISOString()
        }));
        if (cookieBanner) {
            cookieBanner.classList.remove("active");
        }
    };

    if (cookieBanner) {
        const consent = localStorage.getItem(consentKey);
        if (!consent) {
            cookieBanner.classList.add("active");
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => setConsent("accepted"));
        }
        if (declineBtn) {
            declineBtn.addEventListener("click", () => setConsent("declined"));
        }
    }

    const body = document.body;
    if (body.dataset.page === "posts") {
        initPostsPage();
    }
});

function initPostsPage() {
    const postsContainer = document.querySelector(".posts-list");
    if (!postsContainer) return;

    const searchInput = document.querySelector(".search-field input");
    const filterButtons = document.querySelectorAll(".filter-button");
    const cards = Array.from(postsContainer.querySelectorAll(".post-card"));
    const pagination = document.querySelector(".pagination");
    const prevBtn = pagination?.querySelector(".prev-page");
    const nextBtn = pagination?.querySelector(".next-page");
    const indicator = pagination?.querySelector(".page-indicator");

    const state = {
        currentPage: 1,
        perPage: 6,
        searchTerm: "",
        category: "all"
    };

    const applyFilters = () => {
        const term = state.searchTerm.toLowerCase();
        const category = state.category;
        const matched = cards.filter(card => {
            const matchesCategory = category === "all" || card.dataset.category === category;
            const text = card.textContent.toLowerCase();
            const matchesSearch = text.includes(term);
            return matchesCategory && matchesSearch;
        });
        state.currentPage = 1;
        render(matched);
    };

    const render = (list) => {
        cards.forEach(card => card.style.display = "none");
        const total = list.length;
        const totalPages = Math.max(1, Math.ceil(total / state.perPage));
        state.currentPage = Math.min(state.currentPage, totalPages);
        const start = (state.currentPage - 1) * state.perPage;
        const end = start + state.perPage;
        list.slice(start, end).forEach(card => {
            card.style.display = "flex";
        });

        if (indicator) {
            indicator.textContent = `Page ${state.currentPage} of ${totalPages}`;
        }
        if (prevBtn) {
            prevBtn.classList.toggle("disabled", state.currentPage === 1);
        }
        if (nextBtn) {
            nextBtn.classList.toggle("disabled", state.currentPage >= totalPages);
        }
    };

    filterButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            filterButtons.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            state.category = btn.dataset.category;
            applyFilters();
        });
    });

    if (searchInput) {
        searchInput.addEventListener("input", (event) => {
            state.searchTerm = event.target.value.trim();
            applyFilters();
        });
    }

    if (prevBtn) {
        prevBtn.addEventListener("click", () => {
            if (state.currentPage > 1) {
                state.currentPage -= 1;
                applyFilters();
            }
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener("click", () => {
            state.currentPage += 1;
            applyFilters();
        });
    }

    applyFilters();
}