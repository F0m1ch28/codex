import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';

import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';

import Home from './pages/Home';
import VideoCovers from './pages/VideoCovers';
import Avatars from './pages/Avatars';
import GraphicsElements from './pages/GraphicsElements';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

const ScrollToTopHandler = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'smooth',
    });
  }, [pathname]);

  return null;
};

const AppRoutes = () => (
  <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/oblozhki-dlya-video" element={<VideoCovers />} />
    <Route path="/avatarki" element={<Avatars />} />
    <Route path="/graficheskie-elementy" element={<GraphicsElements />} />
    <Route path="/services" element={<Services />} />
    <Route path="/o-nas" element={<About />} />
    <Route path="/kontakty" element={<Contact />} />
    <Route path="/usloviya-ispolzovaniya" element={<Terms />} />
    <Route path="/politika-konfidencialnosti" element={<Privacy />} />
    <Route path="/politika-cookie" element={<CookiePolicy />} />
  </Routes>
);

function App() {
  return (
    <Router>
      <ScrollToTopHandler />
      <div className="appLayout">
        <Header />
        <main id="content" className="mainContent" tabIndex="-1">
          <AppRoutes />
        </main>
        <Footer />
        <CookieBanner />
        <ScrollToTopButton />
      </div>
    </Router>
  );
}

export default App;