import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const categories = [
  {
    title: 'Обложки для видео',
    description: 'Усилите кликабельность роликов на YouTube, Rutube, VK Видео и других платформах.',
    image: 'https://picsum.photos/seed/digitalcovers-video/800/600',
    link: '/oblozhki-dlya-video',
  },
  {
    title: 'Аватарки и профили',
    description: 'Сильный визуал для блогеров, геймеров, авторов подкастов и брендов.',
    image: 'https://picsum.photos/seed/digitalcovers-avatar/800/600',
    link: '/avatarki',
  },
  {
    title: 'Графические элементы',
    description: 'Наборы элементов, фоны, иконки, оверлеи и UI-паки для ваших проектов.',
    image: 'https://picsum.photos/seed/digitalcovers-graphics/800/600',
    link: '/graficheskie-elementy',
  },
];

const stats = [
  { value: '4.8/5', label: 'Средняя оценка клиентов' },
  { value: '1200+', label: 'готовых цифровых пакетов' },
  { value: '48 ч', label: 'средний срок кастомизации' },
  { value: '35+', label: 'стилей и эстетик' },
];

const popularProducts = [
  {
    title: 'Cinematic Series',
    tags: ['обложки', 'видео', 'кинематографично'],
    image: 'https://picsum.photos/seed/digitalcovers-popular1/900/600',
  },
  {
    title: 'Neon Pulse Pack',
    tags: ['аватарки', 'неон', 'стримеры'],
    image: 'https://picsum.photos/seed/digitalcovers-popular2/900/600',
  },
  {
    title: 'Minimal Flow Set',
    tags: ['графика', 'минимализм', 'корпоратив'],
    image: 'https://picsum.photos/seed/digitalcovers-popular3/900/600',
  },
  {
    title: 'Creator Storyboards',
    tags: ['обложки', 'рассказ', 'серии'],
    image: 'https://picsum.photos/seed/digitalcovers-popular4/900/600',
  },
  {
    title: 'Tech Gradient Icons',
    tags: ['графика', 'UI', 'иконки'],
    image: 'https://picsum.photos/seed/digitalcovers-popular5/900/600',
  },
  {
    title: 'Podcast Identity',
    tags: ['аватарки', 'подкаст', 'бренд'],
    image: 'https://picsum.photos/seed/digitalcovers-popular6/900/600',
  },
];

const benefits = [
  {
    title: 'Дизайн под алгоритмы',
    description:
      'Учитываем особенности площадок: safe-zone, контрастность для мобильных экранов, читаемость миниатюр.',
    icon: '🎯',
  },
  {
    title: 'Честные лицензии',
    description:
      'Каждый продукт сопровождается четкой лицензией и документацией, чтобы вы могли уверенно монетизировать контент.',
    icon: '🛡️',
  },
  {
    title: 'Гибкая кастомизация',
    description:
      'Настроим шаблон под ваши задачи: заменим цвета, шрифты, логотипы, добавим уникальные элементы.',
    icon: '🎨',
  },
  {
    title: 'Поддержка 24/7',
    description:
      'Наша команда дизайнеров и проджектов всегда на связи, помогая внедрить материалы в проекты.',
    icon: '🤝',
  },
];

const processSteps = [
  {
    step: '01',
    title: 'Выбор коллекции',
    description: 'Определите стиль и формат, которые подходят для вашего проекта или платформы.',
  },
  {
    step: '02',
    title: 'Персонализация',
    description: 'Загрузите бриф или укажите параметры: цвета бренда, ключевые слова, желаемый тон.',
  },
  {
    step: '03',
    title: 'Доставка файлов',
    description:
      'Получите готовые пакеты PSD/FIG/PNG/WebP и инструкции по адаптации к различным площадкам.',
  },
  {
    step: '04',
    title: 'Поддержка и апдейты',
    description:
      'Добавляем новые версии и сезонные обновления, чтобы визуал оставался свежим и актуальным.',
  },
];

const testimonials = [
  {
    name: 'Алина Ковалёва',
    role: 'Видео-блогер, 350k подписчиков',
    text:
      'С обложками DigitalCovers моя кликабельность выросла на 27%. Главный плюс — точное попадание в тематику и готовые версии для Shorts.',
    photo: 'https://picsum.photos/seed/digitalcovers-testimonial1/200/200',
  },
  {
    name: 'Игорь Лапшин',
    role: 'Маркетолог онлайн-школы',
    text:
      'Получили целую библиотеку графики для лендингов, вебинаров и соцсетей. Всё в едином стиле, с исходниками и гайды по применению.',
    photo: 'https://picsum.photos/seed/digitalcovers-testimonial2/200/200',
  },
  {
    name: 'Мария Дьякова',
    role: 'Стример и ведущая подкаста',
    text:
      'Аватарки и визуал для стрима выглядят профессионально, а команда помогла интегрировать их в OBS и соцсети без лишних вопросов.',
    photo: 'https://picsum.photos/seed/digitalcovers-testimonial3/200/200',
  },
];

const projects = [
  {
    title: 'YouTube Production Kit',
    category: 'видео',
    description: 'Серия из 16 обложек и lower-third элементов для выпуска видео-сериалов.',
    image: 'https://picsum.photos/seed/digitalcovers-project1/1200/800',
  },
  {
    title: 'Gaming Stream Identity',
    category: 'аватарки',
    description: 'Комплект графики для стримингового канала: от эмблем до анимационных экранов.',
    image: 'https://picsum.photos/seed/digitalcovers-project2/1200/800',
  },
  {
    title: 'Corporate Webinar Pack',
    category: 'графика',
    description: 'Графические шаблоны для презентаций, лид-магнитов и продающих эфиров.',
    image: 'https://picsum.photos/seed/digitalcovers-project3/1200/800',
  },
  {
    title: 'Podcast Launch Suite',
    category: 'аватарки',
    description: 'Фирменный стиль под запуск подкаста: обложка, карточки выпусков, соцсети.',
    image: 'https://picsum.photos/seed/digitalcovers-project4/1200/800',
  },
];

const team = [
  {
    name: 'Антон Лебедев',
    role: 'Креативный директор',
    bio: '10 лет в арт-дирекшене, автор десятков визуальных стратегий для медиа и EdTech.',
    photo: 'https://picsum.photos/seed/digitalcovers-team1/400/400',
  },
  {
    name: 'Ольга Шилова',
    role: 'Lead Motion Designer',
    bio: 'Создает динамичные обложки и анимированные элементы, чтобы визуал был живым.',
    photo: 'https://picsum.photos/seed/digitalcovers-team2/400/400',
  },
  {
    name: 'Данил Пахомов',
    role: 'Head of Support',
    bio: 'Помогает клиентам адаптировать графику под платформы и ускоряет релизы.',
    photo: 'https://picsum.photos/seed/digitalcovers-team3/400/400',
  },
];

const faqs = [
  {
    question: 'Можно ли адаптировать дизайн под мой бренд?',
    answer:
      'Да, мы кастомизируем цветовые схемы, шрифты и визуальные акценты под вашу айдентику. Вы предоставляете брендбук или описываете задачу, а мы подготавливаем готовые слои и стили.',
  },
  {
    question: 'В каких форматах вы отдаёте файлы?',
    answer:
      'По умолчанию вы получаете PNG/WebP для быстрого использования, а также исходники в PSD, Figma или After Effects (по запросу). Все материалы структурированы и подписаны.',
  },
  {
    question: 'Как быстро я получу результат?',
    answer:
      'Готовые пакеты доступны мгновенно после оплаты. Кастомизация занимает от 24 до 72 часов в зависимости от объёма правок и сложности стиля.',
  },
  {
    question: 'Есть ли ограничения по лицензии?',
    answer:
      'Мы предоставляем расширенную лицензию на коммерческое использование. Запрещено перепродавать пакеты в чистом виде, но вы можете применять их в любых собственных проектах.',
  },
];

const blogPosts = [
  {
    title: 'Как увеличить CTR обложек в 2024 году',
    description: 'Проверяем гипотезы и делимся визуальными приемами, которые работают на YouTube и VK.',
    date: '15 января 2024',
    image: 'https://picsum.photos/seed/digitalcovers-blog1/1200/800',
  },
  {
    title: 'Построение визуальной экосистемы бренда',
    description: 'Разбираемся, как объединить обложки, соцсети и презентации в единую историю.',
    date: '28 декабря 2023',
    image: 'https://picsum.photos/seed/digitalcovers-blog2/1200/800',
  },
  {
    title: 'Новые тренды в графике для стриминга',
    description: 'От неоновых акцентов до flat-модулей — что выбирают крупные платформы.',
    date: '10 декабря 2023',
    image: 'https://picsum.photos/seed/digitalcovers-blog3/1200/800',
  },
];

const Home = () => {
  const [activeProjectFilter, setActiveProjectFilter] = useState('all');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [expandedFaq, setExpandedFaq] = useState(null);

  const filteredProjects = useMemo(() => {
    if (activeProjectFilter === 'all') return projects;
    return projects.filter((project) => project.category === activeProjectFilter);
  }, [activeProjectFilter]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const handleFaqToggle = (index) => {
    setExpandedFaq((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Seo
        title="DigitalCovers — цифровые обложки, аватарки и графика для контент-креаторов"
        description="DigitalCovers помогает брендам, блогерам и стримерам создавать кликабельные обложки, запоминающиеся аватарки и графические элементы с кастомизацией."
      />

      <section
        className={styles.hero}
        style={{ backgroundImage: 'url(https://picsum.photos/seed/digitalcovers-hero/1600/900)' }}
      >
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <div className={styles.heroLabel}>DigitalCovers — платформа визуальных решений</div>
          <h1 className={styles.heroTitle}>
            Визуальные истории, которые помогают вашему контенту выигрывать внимание
          </h1>
          <p className={styles.heroSubtitle}>
            Каталоги готовых обложек, авторские аватарки, динамичные графические элементы и гибкая
            кастомизация под ваш бренд. Легко интегрируется в YouTube, Twitch, Rutube, Telegram,
            VK и образовательные платформы.
          </p>
          <div className={styles.heroActions}>
            <Link to="/oblozhki-dlya-video" className={styles.primaryButton}>
              Смотреть каталоги
            </Link>
            <Link to="/kontakty" className={styles.secondaryButton}>
              Обсудить проект
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.stats} aria-label="Ключевые показатели DigitalCovers">
        <div className={styles.statsGrid}>
          {stats.map((item) => (
            <div key={item.label} className={styles.statsCard}>
              <span className={styles.statsValue}>{item.value}</span>
              <span className={styles.statsLabel}>{item.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHead}>
          <div>
            <h2 className={styles.sectionTitle}>Категории цифровых продуктов</h2>
            <p className={styles.sectionSubtitle}>
              Профессиональные наборы, созданные на базе аналитики трендов и опыта наших дизайнеров.
            </p>
          </div>
          <Link to="/services" className={styles.linkButton}>
            Все сервисы
          </Link>
        </div>
        <div className={styles.categoriesGrid}>
          {categories.map((category) => (
            <Link
              to={category.link}
              key={category.title}
              className={styles.categoryCard}
              aria-label={category.title}
            >
              <img src={category.image} alt={category.title} />
              <div className={styles.categoryContent}>
                <h3>{category.title}</h3>
                <p>{category.description}</p>
                <span className={styles.categoryLink}>Перейти →</span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHead}>
          <div>
            <h2 className={styles.sectionTitle}>Популярные продукты</h2>
            <p className={styles.sectionSubtitle}>
              Лучшие коллекции месяца по оценкам дизайнеров и клиентов. Все наборы готовы к
              кастомизации и адаптации под ваш бренд.
            </p>
          </div>
        </div>
        <div className={styles.productsGrid}>
          {popularProducts.map((product) => (
            <article key={product.title} className={styles.productCard}>
              <div className={styles.productImage}>
                <img src={product.image} alt={product.title} loading="lazy" />
              </div>
              <div className={styles.productBody}>
                <h3>{product.title}</h3>
                <div className={styles.productTags}>
                  {product.tags.map((tag) => (
                    <span key={tag}>{tag}</span>
                  ))}
                </div>
                <Link to="/kontakty" className={styles.productAction}>
                  Запросить кастомизацию
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHead}>
          <div>
            <h2 className={styles.sectionTitle}>Почему DigitalCovers</h2>
            <p className={styles.sectionSubtitle}>
              Мы соединяем стратегию, дизайн и технологию, чтобы вы получили результат, а не просто
              «красивую картинку».
            </p>
          </div>
        </div>
        <div className={styles.benefitsGrid}>
          {benefits.map((benefit) => (
            <div key={benefit.title} className={styles.benefitCard}>
              <span className={styles.benefitIcon} aria-hidden="true">
                {benefit.icon}
              </span>
              <h3>{benefit.title}</h3>
              <p>{benefit.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHead}>
          <div>
            <h2 className={styles.sectionTitle}>Как работает платформа</h2>
            <p className={styles.sectionSubtitle}>
              От первого брифа до готовых файлов — структурированный процесс с прозрачными сроками.
            </p>
          </div>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <div key={step.step} className={styles.processCard}>
              <span className={styles.processStep}>{step.step}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.testimonialsSection}`}>
        <div className={styles.sectionHead}>
          <div>
            <h2 className={styles.sectionTitle}>Отзывы создателей</h2>
            <p className={styles.sectionSubtitle}>
              Профессионалы индустрии рассказывают, как визуал влияет на развитие их проектов.
            </p>
          </div>
          <div className={styles.testimonialControls} role="group" aria-label="Управление отзывами">
            {testimonials.map((testimonial, index) => (
              <button
                type="button"
                key={testimonial.name}
                className={`${styles.testimonialDot} ${
                  index === currentTestimonial ? styles.testimonialDotActive : ''
                }`}
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Показать отзыв: ${testimonial.name}`}
                aria-pressed={index === currentTestimonial}
              />
            ))}
          </div>
        </div>
        <div className={styles.testimonialCard}>
          <div className={styles.testimonialAvatar}>
            <img
              src={testimonials[currentTestimonial].photo}
              alt={`Фото: ${testimonials[currentTestimonial].name}`}
            />
          </div>
          <blockquote className={styles.testimonialQuote}>
            “{testimonials[currentTestimonial].text}”
          </blockquote>
          <div className={styles.testimonialMeta}>
            <span className={styles.testimonialName}>{testimonials[currentTestimonial].name}</span>
            <span className={styles.testimonialRole}>{testimonials[currentTestimonial].role}</span>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHead}>
          <div>
            <h2 className={styles.sectionTitle}>Портфолио проектов</h2>
            <p className={styles.sectionSubtitle}>
              Посмотрите, как мы трансформируем визуальные экосистемы контент-креаторов, брендов и
              образовательных платформ.
            </p>
          </div>
          <div className={styles.filterGroup} role="group" aria-label="Фильтр проектов">
            <button
              type="button"
              onClick={() => setActiveProjectFilter('all')}
              className={`${styles.filterButton} ${
                activeProjectFilter === 'all' ? styles.filterButtonActive : ''
              }`}
            >
              Все
            </button>
            <button
              type="button"
              onClick={() => setActiveProjectFilter('видео')}
              className={`${styles.filterButton} ${
                activeProjectFilter === 'видео' ? styles.filterButtonActive : ''
              }`}
            >
              Видео
            </button>
            <button
              type="button"
              onClick={() => setActiveProjectFilter('аватарки')}
              className={`${styles.filterButton} ${
                activeProjectFilter === 'аватарки' ? styles.filterButtonActive : ''
              }`}
            >
              Аватарки
            </button>
            <button
              type="button"
              onClick={() => setActiveProjectFilter('графика')}
              className={`${styles.filterButton} ${
                activeProjectFilter === 'графика' ? styles.filterButtonActive : ''
              }`}
            >
              Графика
            </button>
          </div>
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <img src={project.image} alt={project.title} loading="lazy" />
              <div className={styles.projectBody}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <Link to="/kontakty" className={styles.projectLink}>
                  Обсудить похожий проект →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHead}>
          <div>
            <h2 className={styles.sectionTitle}>Команда DigitalCovers</h2>
            <p className={styles.sectionSubtitle}>
              Мы объединили креатив, motion, маркетинг и клиентский сервис, чтобы создавать
              комплексные решения без лишних барьеров.
            </p>
          </div>
        </div>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <div key={member.name} className={styles.teamCard}>
              <div className={styles.teamAvatar}>
                <img src={member.photo} alt={member.name} loading="lazy" />
              </div>
              <div className={styles.teamBody}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.faqSection}`}>
        <div className={styles.sectionHead}>
          <div>
            <h2 className={styles.sectionTitle}>Частые вопросы</h2>
            <p className={styles.sectionSubtitle}>
              Если вы не нашли ответ — свяжитесь с нами, и менеджер подготовит персональную
              консультацию.
            </p>
          </div>
        </div>
        <div className={styles.faqList}>
          {faqs.map((faq, index) => {
            const isOpen = expandedFaq === index;
            return (
              <div key={faq.question} className={`${styles.faqItem} ${isOpen ? styles.faqOpen : ''}`}>
                <button
                  type="button"
                  className={styles.faqButton}
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={isOpen}
                >
                  <span>{faq.question}</span>
                  <span className={styles.faqToggle} aria-hidden="true">
                    {isOpen ? '−' : '+'}
                  </span>
                </button>
                <div className={styles.faqContent} role="region">
                  <p>{faq.answer}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHead}>
          <div>
            <h2 className={styles.sectionTitle}>Блог и инсайты</h2>
            <p className={styles.sectionSubtitle}>
              Делимся аналитикой трендов, кейсами клиентов и практическими гайдами по визуалу.
            </p>
          </div>
          <Link to="/kontakty" className={styles.linkButton}>
            Подписаться на обновления
          </Link>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <div className={styles.blogImage}>
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.blogBody}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.description}</p>
                <Link to="/kontakty" className={styles.blogLink}>
                  Получить гайд →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2>Запустите новый визуал уже на этой неделе</h2>
          <p>
            Оставьте заявку, и мы предложим три варианта стиля, сформируем пакет под ваши каналы и
            согласуем план внедрения.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/kontakty" className={styles.primaryButton}>
              Назначить консультацию
            </Link>
            <a href="mailto:email@digitalcovers.ru" className={styles.secondaryButton}>
              Написать на почту
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;