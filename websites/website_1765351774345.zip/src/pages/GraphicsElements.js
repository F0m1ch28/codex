import React from 'react';
import Seo from '../components/Seo';
import styles from './GraphicsElements.module.css';

const bundles = [
  {
    title: 'Broadcast Overlay Kit',
    description:
      'Оверлеи, счетчики, lower-third блоки и графика для живых трансляций и вебинаров. Подходит для OBS, vMix и Streamlabs.',
    items: ['108 элементов', '12 цветовых схем', 'SVG/PNG/After Effects'],
    image: 'https://picsum.photos/seed/digitalcovers-graphics1/1100/750',
  },
  {
    title: 'Edu-Content Graphics',
    description:
      'Таймлайны, инфографика, маркеры, таблицы и стикеры для учебных видео и презентаций. Все элементы векторные.',
    items: ['Плагины Figma', 'Комплект иконок', 'Гайды по стилю'],
    image: 'https://picsum.photos/seed/digitalcovers-graphics2/1100/750',
  },
  {
    title: 'Social Carousel Pack',
    description:
      'Набор слайдов для Instagram, VK и LinkedIn: от заглавных кадров до блоков с отзывами и CTA.',
    items: ['24 макета', 'Адаптация под Reels', 'Версии для темной темы'],
    image: 'https://picsum.photos/seed/digitalcovers-graphics3/1100/750',
  },
];

const GraphicsElements = () => (
  <div className={styles.page}>
    <Seo
      title="Графические элементы — DigitalCovers"
      description="Комплексные графические пакеты: оверлеи, инфографика, social-templates и UI-наборы с лицензиями на коммерческое использование."
    />
    <section className={styles.header}>
      <h1>Графические элементы для трансляций, презентаций и соцсетей</h1>
      <p>
        Получите профессиональные наборы графики с продуманной системой применения. Каждый пакет
        содержит исходники, экспортированные версии, гайды по внедрению и техническую поддержку.
      </p>
    </section>

    <section className={styles.bundleGrid}>
      {bundles.map((bundle) => (
        <article key={bundle.title} className={styles.bundleCard}>
          <div className={styles.bundleMedia}>
            <img src={bundle.image} alt={bundle.title} loading="lazy" />
          </div>
          <div className={styles.bundleBody}>
            <h2>{bundle.title}</h2>
            <p>{bundle.description}</p>
            <ul>
              {bundle.items.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <a href="mailto:email@digitalcovers.ru" className={styles.bundleLink}>
              Получить презентацию набора →
            </a>
          </div>
        </article>
      ))}
    </section>
  </div>
);

export default GraphicsElements;