import React from 'react';
import Seo from '../components/Seo';
import styles from './VideoCovers.module.css';

const collections = [
  {
    title: 'Cinematic Impact',
    description:
      'Глубокие тени, драматичная типографика и сюжетные кадры для премиальных видео-проектов и документалок.',
    features: ['5 цветовых схем', 'PSD + Figma', 'Поддержка 2.7K/4K'],
    image: 'https://picsum.photos/seed/digitalcovers-videokit1/1100/700',
  },
  {
    title: 'Viral Shorts Booster',
    description:
      'Динамичные обложки с крупной типографикой, адаптированные под вертикальные форматы Shorts и Clips.',
    features: ['Вертикальные версии', 'Story-safe зоны', 'Адаптация под Reels'],
    image: 'https://picsum.photos/seed/digitalcovers-videokit2/1100/700',
  },
  {
    title: 'Educational Series Master',
    description:
      'Набор обложек для образовательных и экспертных каналов. Светлые тона, удобная структура блоков.',
    features: ['Структура для серий', 'Иконки модулей', 'Гайды по верстке'],
    image: 'https://picsum.photos/seed/digitalcovers-videokit3/1100/700',
  },
];

const VideoCovers = () => (
  <div className={styles.page}>
    <Seo
      title="Обложки для видео — DigitalCovers"
      description="Каталог профессиональных обложек для видео: кинематографичные, вирусные, образовательные и брендированные серии."
    />
    <section className={styles.hero}>
      <div className={styles.heroBadge}>Каталог DigitalCovers</div>
      <h1>Обложки для видео, которые повышают кликабельность</h1>
      <p>
        Мы анализируем тренды YouTube, VK Видео и других платформ, чтобы создавать визуальные
        решения, которые заметно увеличивают CTR и удержание аудитории. Каждый пакет готов к
        кастомизации: от смены цветов до полной перестройки композиции.
      </p>
      <a className={styles.heroAction} href="mailto:email@digitalcovers.ru">
        Получить демо-пакет
      </a>
    </section>

    <section className={styles.collectionSection}>
      {collections.map((collection) => (
        <article key={collection.title} className={styles.collectionCard}>
          <div className={styles.collectionImage}>
            <img src={collection.image} alt={collection.title} loading="lazy" />
          </div>
          <div className={styles.collectionBody}>
            <h2>{collection.title}</h2>
            <p>{collection.description}</p>
            <ul>
              {collection.features.map((feature) => (
                <li key={feature}>{feature}</li>
              ))}
            </ul>
            <a href="mailto:email@digitalcovers.ru" className={styles.collectionLink}>
              Запросить индивидуальный стиль →
            </a>
          </div>
        </article>
      ))}
    </section>

    <section className={styles.features}>
      <div className={styles.featuresContent}>
        <h2>Что входит в пакеты обложек</h2>
        <div className={styles.featureGrid}>
          <div className={styles.featureItem}>
            <h3>Исходники &amp; шрифты</h3>
            <p>
              PSD или Figma со структурированными слоями, подобранные шрифты с лицензиями и файлы
              превью в PNG/WebP.
            </p>
          </div>
          <div className={styles.featureItem}>
            <h3>Гайды по верстке</h3>
            <p>
              Инструкции по адаптации под различные форматы, включая Shorts, Stories и заставки
              трансляций.
            </p>
          </div>
          <div className={styles.featureItem}>
            <h3>Микро-элементы</h3>
            <p>
              Плашки, стрелки, значки CTA, оверлеи и наборы фоновых текстур для расширения визуала.
            </p>
          </div>
        </div>
      </div>
    </section>
  </div>
);

export default VideoCovers;