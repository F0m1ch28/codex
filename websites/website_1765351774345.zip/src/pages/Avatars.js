import React from 'react';
import Seo from '../components/Seo';
import styles from './Avatars.module.css';

const avatarSets = [
  {
    title: 'Creator Persona',
    description:
      'Набор премиальных аватаров с расширенной цветовой палитрой, адаптированных для TikTok, VK, Instagram и Telegram.',
    tones: ['Аcid-pop', 'Soft gradient', 'Deep noir'],
    image: 'https://picsum.photos/seed/digitalcovers-avatar1/1100/750',
  },
  {
    title: 'Gaming Universe',
    description:
      'Разработано для стримеров и геймеров: уникальные маскоты, динамичные рамки, режимы light/dark.',
    tones: ['Neon core', 'Retro RGB', 'Cyber shade'],
    image: 'https://picsum.photos/seed/digitalcovers-avatar2/1100/750',
  },
  {
    title: 'Business Personal Brand',
    description:
      'Стильные портретные решения с аккуратной типографикой и фирменными акцентами для экспертов и коучей.',
    tones: ['Minimal airy', 'Brand gradient', 'Signature mono'],
    image: 'https://picsum.photos/seed/digitalcovers-avatar3/1100/750',
  },
];

const Avatars = () => (
  <div className={styles.page}>
    <Seo
      title="Аватарки и профили — DigitalCovers"
      description="Выразительные аватарки и визуальные профили для блогеров, стримеров и компаний. Каталоги стилей и кастомизация под ваш бренд."
    />
    <section className={styles.intro}>
      <h1>Аватарки, которые формируют узнаваемость с первого клика</h1>
      <p>
        Мы создаем аватарки и визуальные профили с учетом форматов площадок: Telegram, Twitch,
        YouTube, Instagram, VK и подкаст-платформ. Получите готовый набор изображений, версий для
        темной/светлой тем, а также рекомендации по интеграции.
      </p>
    </section>

    <section className={styles.grid}>
      {avatarSets.map((set) => (
        <article key={set.title} className={styles.card}>
          <div className={styles.image}>
            <img src={set.image} alt={set.title} loading="lazy" />
          </div>
          <div className={styles.body}>
            <h2>{set.title}</h2>
            <p>{set.description}</p>
            <div className={styles.tones}>
              {set.tones.map((tone) => (
                <span key={tone}>{tone}</span>
              ))}
            </div>
            <a href="mailto:email@digitalcovers.ru" className={styles.link}>
              Заказать дизайн профиля →
            </a>
          </div>
        </article>
      ))}
    </section>
  </div>
);

export default Avatars;