import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Services.module.css';

const services = [
  {
    title: 'Аудит визуального контента',
    description:
      'Анализ текущих обложек, аватаров и графики, выявление точек роста, рекомендации по улучшению визуальных метрик.',
    deliverables: ['Аудит PDF', 'Чек-лист улучшений', 'Сводка гипотез'],
  },
  {
    title: 'Кастомные коллекции',
    description:
      'Создание уникальных паков обложек, аватаров и графики под бренд. Включены исходники, гайды и консультации.',
    deliverables: ['Moodboard', '3 варианта стиля', 'Исходные файлы'],
  },
  {
    title: 'Постоянная поддержка',
    description:
      'Абонентская модель для регулярного обновления визуала: сезонные кампании, спецпроекты, интеграции.',
    deliverables: ['Пакеты обновлений', 'Экспресс-правки', 'Приоритетный менеджер'],
  },
];

const Services = () => (
  <div className={styles.page}>
    <Seo
      title="Сервисы и решения — DigitalCovers"
      description="Сервисы DigitalCovers: аудит визуального контента, создание кастомных коллекций и абонентское сопровождение для брендов."
    />
    <section className={styles.header}>
      <h1>Сервисы DigitalCovers</h1>
      <p>
        Мы работаем с креаторами, стримерами, брендами и образовательными платформами, обеспечивая
        полный цикл визуальной поддержки: от стратегии до финальных файлов и внедрения.
      </p>
    </section>

    <section className={styles.cards}>
      {services.map((service) => (
        <article key={service.title} className={styles.card}>
          <h2>{service.title}</h2>
          <p>{service.description}</p>
          <ul>
            {service.deliverables.map((deliverable) => (
              <li key={deliverable}>{deliverable}</li>
            ))}
          </ul>
          <Link to="/kontakty" className={styles.cardLink}>
            Получить коммерческое предложение →
          </Link>
        </article>
      ))}
    </section>
  </div>
);

export default Services;