import React from 'react';
import Seo from '../components/Seo';
import styles from './About.module.css';

const milestones = [
  {
    year: '2019',
    title: 'Запуск студии',
    description:
      'Команда DigitalCovers сформировалась на базе продакшена, работавшего с YouTube и EdTech.',
  },
  {
    year: '2021',
    title: 'Визуальные экосистемы',
    description:
      'Добавили услуги по разработке цельных визуальных систем для брендов и образовательных платформ.',
  },
  {
    year: '2023',
    title: 'Платформа коллекций',
    description:
      'Запустили каталоги готовых паков обложек, аватаров и графики с возможностью гибкой кастомизации.',
  },
];

const About = () => (
  <div className={styles.page}>
    <Seo
      title="О DigitalCovers"
      description="DigitalCovers — студия визуальных решений для контент-креаторов. История, подход и ценности команды."
    />
    <section className={styles.hero}>
      <h1>Создаем визуальные системы, которые работают на результат</h1>
      <p>
        DigitalCovers объединяет арт-директоров, дизайнеров, motion-специалистов и аналитиков. Мы
        изучаем поведение аудитории на платформах, тестируем гипотезы и собираем решения, где
        каждая деталь имеет смысл: от цвета до микро-типографики.
      </p>
    </section>

    <section className={styles.mission}>
      <div className={styles.missionCard}>
        <h2>Наша миссия</h2>
        <p>
          Помогать создателям контента выделяться, удерживать внимание и строить свою историю с
          мощным визуалом. Мы верим, что продуманный дизайн ускоряет рост каналов, курсов и
          сообществ.
        </p>
      </div>
      <div className={styles.missionCard}>
        <h2>Что нас отличает</h2>
        <ul>
          <li>Фокус на платформенную специфику и метрики эффективности.</li>
          <li>Командная работа дизайнеров, motion-специалистов и аналитиков.</li>
          <li>Прозрачные процессы и поддержка после релиза.</li>
        </ul>
      </div>
    </section>

    <section className={styles.timeline}>
      <h2>Ключевые этапы</h2>
      <div className={styles.timelineGrid}>
        {milestones.map((milestone) => (
          <div key={milestone.year} className={styles.timelineItem}>
            <span className={styles.timelineYear}>{milestone.year}</span>
            <h3>{milestone.title}</h3>
            <p>{milestone.description}</p>
          </div>
        ))}
      </div>
    </section>

    <section className={styles.values}>
      <h2>Ценности команды</h2>
      <div className={styles.valuesGrid}>
        <div className={styles.valueCard}>
          <h3>Глубина</h3>
          <p>Изучаем продукт и аудиторию, прежде чем переходить к визуальному решению.</p>
        </div>
        <div className={styles.valueCard}>
          <h3>Итеративность</h3>
          <p>Тестируем, улучшаем, расширяем. Визуал живой, поэтому мы гибкие и вовлеченные.</p>
        </div>
        <div className={styles.valueCard}>
          <h3>Честность</h3>
          <p>Прозрачное общение, понятные условия и четкие сроки — фундамент нашей работы.</p>
        </div>
      </div>
    </section>
  </div>
);

export default About;