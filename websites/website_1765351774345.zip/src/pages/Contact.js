import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });
  const [status, setStatus] = useState(null);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setStatus({ type: 'error', message: 'Пожалуйста, заполните обязательные поля.' });
      return;
    }
    setStatus({
      type: 'success',
      message:
        'Спасибо! Мы получили вашу заявку и свяжемся с вами в течение одного рабочего дня.',
    });
    setFormData({
      name: '',
      email: '',
      company: '',
      message: '',
    });
  };

  return (
    <div className={styles.page}>
      <Seo
        title="Контакты DigitalCovers"
        description="Свяжитесь с DigitalCovers: консультации по обложкам, аватаркам и графическим пакетам. Заполните форму или напишите на email@digitalcovers.ru."
      />
      <section className={styles.hero}>
        <h1>Связаться с командой DigitalCovers</h1>
        <p>
          Расскажите о своем проекте или запросите консультацию. Мы ответим в течение одного
          рабочего дня и подготовим первые варианты решения.
        </p>
        <div className={styles.meta}>
          <span>Email: <a href="mailto:email@digitalcovers.ru">email@digitalcovers.ru</a></span>
          <span>Телефон: +7 (000) 000-00-00</span>
        </div>
      </section>

      <section className={styles.content}>
        <form className={styles.form} onSubmit={handleSubmit} aria-label="Форма обратной связи">
          <div className={styles.field}>
            <label htmlFor="name">Имя *</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Как к вам обращаться?"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Email *</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="email@company.com"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="company">Компания / канал</label>
            <input
              id="company"
              name="company"
              type="text"
              placeholder="Название бренда или канала"
              value={formData.company}
              onChange={handleChange}
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="message">Задача *</label>
            <textarea
              id="message"
              name="message"
              placeholder="Расскажите о проекте, сроках, пожеланиях к стилю…"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className={styles.submit}>
            Отправить заявку
          </button>
          {status && (
            <div
              className={`${styles.status} ${
                status.type === 'success' ? styles.statusSuccess : styles.statusError
              }`}
              role="status"
            >
              {status.message}
            </div>
          )}
        </form>

        <aside className={styles.sidebar}>
          <h2>Чем можем помочь</h2>
          <ul>
            <li>Разработка и кастомизация обложек для YouTube, Rutube, VK Видео.</li>
            <li>Создание аватаров, визуальных профилей и брендинга для соцсетей.</li>
            <li>Графические пакеты: оверлеи, инфографика, UI-наборы, дизайн презентаций.</li>
            <li>Абонентское сопровождение с регулярными обновлениями визуала.</li>
          </ul>
        </aside>
      </section>
    </div>
  );
};

export default Contact;