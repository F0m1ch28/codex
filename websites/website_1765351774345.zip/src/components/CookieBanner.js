import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'digitalcovers_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о cookie">
      <div className={styles.text}>
        Мы используем cookie, чтобы DigitalCovers работал быстрее и персонализированнее. Продолжая
        пользоваться сайтом, вы соглашаетесь с нашей{' '}
        <a href="/politika-cookie">Политикой cookie</a>.
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Понятно
      </button>
    </div>
  );
};

export default CookieBanner;