import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-labelledby="footer-title">
    <div className={styles.container}>
      <div className={styles.brandSection}>
        <h2 id="footer-title" className={styles.logo}>
          DigitalCovers
        </h2>
        <p className={styles.description}>
          Цифровые обложки, аватарки и графические элементы, созданные для того, чтобы ваш контент
          выделялся в любой среде — от социальных сетей до онлайн-курсов.
        </p>
        <div className={styles.meta}>
          <span className={styles.metaItem}>© {new Date().getFullYear()} DigitalCovers</span>
          <span className={styles.metaItem}>Создаем визуальные истории.</span>
        </div>
      </div>

      <div className={styles.columns}>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Навигация</h3>
          <ul className={styles.links}>
            <li>
              <Link to="/">Главная</Link>
            </li>
            <li>
              <Link to="/oblozhki-dlya-video">Обложки для видео</Link>
            </li>
            <li>
              <Link to="/avatarki">Аватарки</Link>
            </li>
            <li>
              <Link to="/graficheskie-elementy">Графические элементы</Link>
            </li>
            <li>
              <Link to="/services">Сервисы</Link>
            </li>
          </ul>
        </div>

        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Компания</h3>
          <ul className={styles.links}>
            <li>
              <Link to="/o-nas">О студии</Link>
            </li>
            <li>
              <Link to="/kontakty">Поддержка</Link>
            </li>
            <li>
              <a href="mailto:email@digitalcovers.ru">email@digitalcovers.ru</a>
            </li>
            <li>
              <span>Тел.: +7 (000) 000-00-00</span>
            </li>
          </ul>
        </div>

        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Правовая информация</h3>
          <ul className={styles.links}>
            <li>
              <Link to="/usloviya-ispolzovaniya">Условия использования</Link>
            </li>
            <li>
              <Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link>
            </li>
            <li>
              <Link to="/politika-cookie">Политика Cookie</Link>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;