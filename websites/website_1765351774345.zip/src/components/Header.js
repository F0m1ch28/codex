import React, { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { path: '/', label: 'Главная' },
  { path: '/oblozhki-dlya-video', label: 'Обложки' },
  { path: '/avatarki', label: 'Аватарки' },
  { path: '/graficheskie-elementy', label: 'Графика' },
  { path: '/services', label: 'Сервисы' },
  { path: '/o-nas', label: 'О нас' },
  { path: '/kontakty', label: 'Контакты' },
];

const Header = () => {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.pageYOffset > 40);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileOpen(false);
  }, [pathname]);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.headerScrolled : ''}`}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="DigitalCovers главная страница">
          <span className={styles.logoMark}>DC</span>
          <span className={styles.logoText}>DigitalCovers</span>
        </Link>

        <button
          type="button"
          className={styles.burger}
          onClick={() => setIsMobileOpen(!isMobileOpen)}
          aria-expanded={isMobileOpen}
          aria-controls="primary-navigation"
          aria-label="Переключить меню"
        >
          <span />
          <span />
          <span />
        </button>

        <nav
          id="primary-navigation"
          className={`${styles.navigation} ${isMobileOpen ? styles.navigationOpen : ''}`}
          aria-label="Основная навигация"
        >
          <ul className={styles.navList}>
            {navLinks.map((link) => (
              <li key={link.path}>
                <NavLink
                  to={link.path}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.navLinkActive : ''}`
                  }
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <div className={styles.actionArea}>
            <Link to="/kontakty" className={styles.contactButton}>
              Оставить заявку
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;