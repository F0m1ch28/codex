document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!isExpanded));
            navToggle.classList.toggle("is-active");
            siteNav.classList.toggle("is-open");
        });

        siteNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navToggle.setAttribute("aria-expanded", "false");
                navToggle.classList.remove("is-active");
                siteNav.classList.remove("is-open");
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector('[data-cookie-action="accept"]');
    const declineBtn = document.querySelector('[data-cookie-action="decline"]');
    const storageKey = "ailantkcfr-cookie-pref";

    const hideBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.remove("is-visible");
        }
    };

    const showBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.add("is-visible");
        }
    };

    try {
        const storedPreference = localStorage.getItem(storageKey);
        if (!storedPreference) {
            showBanner();
        }
    } catch (error) {
        console.warn("Cookie preference could not be retrieved", error);
        showBanner();
    }

    const setPreference = (value) => {
        try {
            localStorage.setItem(storageKey, value);
        } catch (error) {
            console.warn("Cookie preference could not be stored", error);
        }
    };

    if (acceptBtn) {
        acceptBtn.addEventListener("click", () => {
            setPreference("accepted");
            hideBanner();
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", () => {
            setPreference("declined");
            hideBanner();
        });
    }
});