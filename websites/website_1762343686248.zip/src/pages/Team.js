import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Team.module.css';

const teamMembers = [
  {
    name: 'Hassan Al-Masri',
    role: 'Principal Energy Consultant',
    experience: '18 years in utility planning, regulatory engagement, and integrated resource strategies.',
    specialties: ['Energy consulting Canada', 'Grid modernisation', 'Stakeholder facilitation'],
    image: 'https://picsum.photos/400/400?random=401',
    alt: 'Portrait of Hassan Al-Masri'
  },
  {
    name: 'Riley Thompson',
    role: 'Senior Field Engineer',
    experience: 'Leads crane installation, heavy lift operations, and commissioning for industrial assets.',
    specialties: ['Crane installation', 'Commissioning', 'Risk mitigation'],
    image: 'https://picsum.photos/400/400?random=402',
    alt: 'Portrait of Riley Thompson'
  },
  {
    name: 'Claudia Martinez',
    role: 'Lead Environmental Scientist',
    experience: 'Designs environmental assessments and sustainability roadmaps for energy infrastructure.',
    specialties: ['Environmental assessment', 'Sustainable engineering', 'ESG reporting'],
    image: 'https://picsum.photos/400/400?random=403',
    alt: 'Portrait of Claudia Martinez'
  },
  {
    name: 'Noah Pelletier',
    role: 'Reservoir Analyst',
    experience: 'Delivers oilfield research, geological interpretation, and digital twin models.',
    specialties: ['Oilfield research', 'Reservoir modelling', 'Data science'],
    image: 'https://picsum.photos/400/400?random=404',
    alt: 'Portrait of Noah Pelletier'
  },
  {
    name: 'Amina Farouk',
    role: 'Project Controls Manager',
    experience: 'Coordinates schedule, cost tracking, and risk analytics for multi-year programs.',
    specialties: ['Project controls', 'Risk analytics', 'Contract governance'],
    image: 'https://picsum.photos/400/400?random=405',
    alt: 'Portrait of Amina Farouk'
  },
  {
    name: 'Dylan Fraser',
    role: 'Logistics & Lifting Specialist',
    experience: 'Optimises heavy haul, rigging plans, and mobilization for complex sites.',
    specialties: ['Heavy lift logistics', 'Rigging design', 'Field supervision'],
    image: 'https://picsum.photos/400/400?random=406',
    alt: 'Portrait of Dylan Fraser'
  }
];

const Team = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Aurion Team | Consultants & Engineers</title>
      <meta
        name="description"
        content="Meet Aurion Energy Advisory’s consultants and engineers delivering energy consulting Canada, oilfield research, and industrial engineering services."
      />
    </Helmet>

    <section className={styles.hero}>
      <h1>Our Team</h1>
      <p>
        Aurion brings together consultants, engineers, researchers, and project managers with decades of combined experience. We collaborate across disciplines to solve complex energy infrastructure challenges.
      </p>
    </section>

    <section className={styles.teamSection}>
      <div className={styles.teamGrid}>
        {teamMembers.map((member) => (
          <article key={member.name} className={styles.teamCard}>
            <div className={styles.avatar}>
              <img src={member.image} alt={member.alt} loading="lazy" />
            </div>
            <div className={styles.teamContent}>
              <h2>{member.name}</h2>
              <span className={styles.role}>{member.role}</span>
              <p>{member.experience}</p>
              <ul>
                {member.specialties.map((specialty) => (
                  <li key={specialty}>{specialty}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </div>
    </section>
  </div>
);

export default Team;