import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookie Policy | Aurion Energy Advisory</title>
      <meta
        name="description"
        content="Learn about Aurion Energy Advisory’s use of cookies, analytics, and similar technologies."
      />
    </Helmet>
    <h1>Cookie Policy</h1>
    <p>Last updated: March 1, 2024</p>

    <h2>What are cookies?</h2>
    <p>
      Cookies are small text files placed on your device when you visit websites. They help us enhance user experience, analyse traffic, and deliver relevant content.
    </p>

    <h2>Types of cookies we use</h2>
    <ul>
      <li><strong>Essential cookies:</strong> Enable core website functionality, such as navigation and secure access.</li>
      <li><strong>Analytics cookies:</strong> Provide insights into how visitors interact with the site, helping us improve content.</li>
      <li><strong>Preference cookies:</strong> Remember your settings and choices for a more tailored experience.</li>
    </ul>

    <h2>Managing cookies</h2>
    <p>
      You can control cookie settings through your browser. Rejecting certain cookies may impact your experience on the site. Our cookie banner also allows you to accept or decline non-essential cookies.
    </p>

    <h2>Updates</h2>
    <p>
      We may update this Cookie Policy to reflect changes in technology or regulation. Please revisit this page periodically for the latest information.
    </p>

    <h2>Contact</h2>
    <p>
      Questions regarding this Cookie Policy can be directed to Aurion Energy Advisory at our Toronto office.
    </p>
  </div>
);

export default CookiePolicy;