import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const leadershipTeam = [
  {
    name: 'Emilia Chen',
    role: 'Founder & Managing Principal',
    bio: 'Emilia launched Aurion after two decades leading integrated energy consulting Canada programs. She specialises in portfolio governance, major capital planning, and stakeholder alignment.',
    image: 'https://picsum.photos/400/400?random=201',
    alt: 'Portrait of Emilia Chen'
  },
  {
    name: 'Jean-Luc Tremblay',
    role: 'Director of Engineering',
    bio: 'Jean-Luc brings 25 years of industrial engineering and crane installation experience, guiding multidisciplinary crews across marine, mining, and refining assets.',
    image: 'https://picsum.photos/400/400?random=202',
    alt: 'Portrait of Jean-Luc Tremblay'
  },
  {
    name: 'Maya Singh',
    role: 'Director of Oilfield Research',
    bio: 'Maya oversees reservoir analytics, geological modelling, and compliance reporting, ensuring oil and gas Canada projects adhere to stringent standards.',
    image: 'https://picsum.photos/400/400?random=203',
    alt: 'Portrait of Maya Singh'
  }
];

const About = () => (
  <div className={styles.page}>
    <Helmet>
      <title>About Aurion Energy Advisory</title>
      <meta
        name="description"
        content="Discover the history, leadership, mission, and safety culture driving Aurion Energy Advisory’s energy consulting Canada and industrial engineering services."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <h1>About Aurion Energy Advisory</h1>
        <p>
          Aurion Energy Advisory was established in Toronto to support energy producers, transmission operators, and industrial clients navigating the evolving energy landscape. Our consulting firm blends strategy, engineering, and sustainability to engineer dependable outcomes.
        </p>
      </div>
    </section>

    <section className={styles.historySection}>
      <div className={styles.sectionHeader}>
        <h2>Our story</h2>
        <p>
          What began as a boutique advisory practice now supports national-scale projects across Canada. From early days in oilfield research to today’s comprehensive portfolio, our journey demonstrates growth anchored in technical excellence.
        </p>
      </div>
      <div className={styles.timeline}>
        <article>
          <span className={styles.timelineYear}>2009</span>
          <h3>Consulting foundation</h3>
          <p>
            Aurion launches with a mission to unify energy consulting and industrial engineering for upstream clients seeking dependable project governance.
          </p>
        </article>
        <article>
          <span className={styles.timelineYear}>2014</span>
          <h3>Research capabilities</h3>
          <p>
            We introduce full-spectrum oilfield research services, combining geoscience expertise and advanced data analytics to reveal subsurface potential.
          </p>
        </article>
        <article>
          <span className={styles.timelineYear}>2018</span>
          <h3>Industrial expansion</h3>
          <p>
            Aurion scales crane installation, heavy-lift logistics, and commissioning teams to serve energy infrastructure and terminal developments nationwide.
          </p>
        </article>
        <article>
          <span className={styles.timelineYear}>2022</span>
          <h3>Sustainability embedded</h3>
          <p>
            We weave sustainable engineering rigor into every engagement, aligning clients with evolving ESG expectations and provincial climate roadmaps.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.leadershipSection}>
      <div className={styles.sectionHeader}>
        <h2>Leadership</h2>
        <p>Strategic thinkers and hands-on engineers guiding each engagement with precision.</p>
      </div>
      <div className={styles.leadershipGrid}>
        {leadershipTeam.map((leader) => (
          <article key={leader.name} className={styles.leadershipCard}>
            <div className={styles.leadershipImage}>
              <img src={leader.image} alt={leader.alt} loading="lazy" />
            </div>
            <div className={styles.leadershipContent}>
              <h3>{leader.name}</h3>
              <span>{leader.role}</span>
              <p>{leader.bio}</p>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.missionSection}>
      <div className={styles.missionCard}>
        <h2>Mission & values</h2>
        <p>
          We exist to engineer energy infrastructure that performs for generations. Our values revolve around collaborative partnerships, rigorous analysis, cultural respect, and unwavering safety leadership.
        </p>
        <ul>
          <li>Partner-centric delivery and transparent communication</li>
          <li>Evidence-based decisions rooted in research and data</li>
          <li>Commitment to sustainability and Indigenous engagement</li>
          <li>Safety-first culture influencing every field activity</li>
        </ul>
      </div>
      <div className={styles.missionCard}>
        <h2>Safety & stewardship</h2>
        <p>
          Safety is embedded at the design stage and continually reinforced on site. We run live scenario planning, competency checks, and digital permits to safeguard personnel, environments, and neighboring communities.
        </p>
        <p>
          Environmental stewardship extends beyond compliance—our teams track emissions, water usage, and biodiversity markers while exploring circular solutions for industrial projects.
        </p>
      </div>
    </section>
  </div>
);

export default About;