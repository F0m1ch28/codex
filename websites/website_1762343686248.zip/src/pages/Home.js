import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Integrated energy projects delivered', value: 48, suffix: '+' },
  { label: 'Specialists in consulting firm network', value: 85, suffix: '' },
  { label: 'Oilfield research campaigns executed', value: 32, suffix: '' },
  { label: 'Million tonnes emissions mitigated', value: 1.8, suffix: '' }
];

const expertiseItems = [
  {
    title: 'Energy Consulting',
    description: 'Advisory programs spanning grid modernisation, pipeline efficiency, and energy infrastructure governance.',
    icon: '⚙️'
  },
  {
    title: 'Oilfield Research',
    description: 'Reservoir studies, integrity assessments, and regulatory compliance for oil and gas Canada operations.',
    icon: '🛢️'
  },
  {
    title: 'Industrial Installations',
    description: 'Crane installation management, commissioning support, and maintenance planning for heavy assets.',
    icon: '🏗️'
  }
];

const serviceHighlights = [
  {
    title: 'Strategic Advisory',
    description: 'Roadmaps for multi-year capital programs anchored in stakeholder alignment and disciplined risk response.',
    image: 'https://picsum.photos/800/600?random=121',
    alt: 'Engineers reviewing energy infrastructure blueprint'
  },
  {
    title: 'Field Intelligence',
    description: 'Advanced subsurface analytics, geological modelling, and real-time field data curation for precise decision making.',
    image: 'https://picsum.photos/800/600?random=122',
    alt: 'Oilfield research team operating sensors'
  },
  {
    title: 'Logistics & Lifting',
    description: 'Crane installation leadership, heavy lift choreography, and safe mobilisation of critical industrial modules.',
    image: 'https://picsum.photos/800/600?random=123',
    alt: 'Industrial crane installation in progress'
  }
];

const processSteps = [
  {
    phase: 'Discover',
    detail: 'Immersive workshops and site diagnostics establish energy consulting Canada objectives and regulatory drivers.'
  },
  {
    phase: 'Model',
    detail: 'Scenario modelling integrates oilfield research, industrial engineering data, and sustainability metrics.'
  },
  {
    phase: 'Execute',
    detail: 'Project controls, crane installation sequencing, and vendor alignment deliver reliable infrastructure outcomes.'
  },
  {
    phase: 'Optimize',
    detail: 'Condition monitoring, emissions tracking, and knowledge transfer sustain operational excellence.'
  }
];

const testimonials = [
  {
    quote: 'Aurion guided our refinery expansion with decisive leadership, balancing production goals with environmental accountability.',
    name: 'Lena Marshall',
    role: 'Director of Engineering, Northern RefineCo'
  },
  {
    quote: 'Their oilfield research team illuminated subsurface potential that reshaped our drilling strategy across Western Canada.',
    name: 'Ahmed Patel',
    role: 'Exploration Manager, Prairie Basin Resources'
  },
  {
    quote: 'From crane installation to commissioning, Aurion orchestrated every milestone with precision and a safety-first mindset.',
    name: 'Sophie Gagnon',
    role: 'Operations Lead, CanLift Logistics'
  }
];

const projectHighlights = [
  {
    title: 'Arctic Terminal Expansion',
    category: 'Energy Infrastructure',
    description: 'Modular loading systems, cryogenic storage integration, and hybrid power to support northern communities.',
    image: 'https://picsum.photos/1200/800?random=131',
    alt: 'Arctic energy terminal at dusk'
  },
  {
    title: 'Prairie Basin Revitalisation',
    category: 'Oil & Gas Canada',
    description: 'Enhanced well integrity program and predictive analytics improving uptime for mature fields.',
    image: 'https://picsum.photos/1200/800?random=132',
    alt: 'Oilfield landscape with pumpjacks'
  },
  {
    title: 'Harbour Crane Network',
    category: 'Industrial Engineering',
    description: 'Coastal crane installation, structural upgrades, and IoT monitoring for marine logistics.',
    image: 'https://picsum.photos/1200/800?random=133',
    alt: 'Harbour cranes under evening sky'
  }
];

const faqItems = [
  {
    question: 'How does Aurion tailor energy consulting Canada programs?',
    answer: 'We combine regulatory insights, asset condition surveys, and stakeholder interviews to build tailored advisory roadmaps aligned with provincial and federal frameworks.'
  },
  {
    question: 'What differentiates Aurion’s oilfield research capability?',
    answer: 'Our geoscientists and data engineers integrate field samples, remote sensing, and machine learning to deliver actionable subsurface intelligence and compliance documentation.'
  },
  {
    question: 'Can Aurion oversee crane installation from concept to commissioning?',
    answer: 'Yes. We manage feasibility, lift engineering, equipment procurement, and onsite execution supported by experienced rigging supervisors.'
  },
  {
    question: 'How is sustainability embedded in industrial projects?',
    answer: 'We benchmark emissions, evaluate electrification pathways, and set performance KPIs to ensure every project advances sustainable engineering outcomes.'
  }
];

const blogPosts = [
  {
    title: 'Grid Modernisation Lessons from Remote Microgrids',
    excerpt: 'Deploying hybrid microgrids requires resilient controls, adaptive forecasting, and capacity-building for local operators.',
    link: '/blog/grid-modernisation',
    image: 'https://picsum.photos/800/600?random=141',
    alt: 'Control room overseeing energy network'
  },
  {
    title: 'Five Ways Oilfield Research Drives Regulatory Confidence',
    excerpt: 'Transparent data trails, collaborative reporting, and proactive remediation strategies are redefining responsible development.',
    link: '/blog/oilfield-research-confidence',
    image: 'https://picsum.photos/800/600?random=142',
    alt: 'Field researchers assessing geological core samples'
  },
  {
    title: 'Designing Safer Crane Installation Playbooks',
    excerpt: 'Integrated lift planning, digital rehearsals, and real-time monitoring elevate lifting campaigns across the energy sector.',
    link: '/blog/crane-installation-playbooks',
    image: 'https://picsum.photos/800/600?random=143',
    alt: 'Engineers planning crane operations with digital tools'
  }
];

const Home = () => {
  const [animatedValues, setAnimatedValues] = useState(statsData.map(() => 0));
  const [activeFAQ, setActiveFAQ] = useState(null);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  useEffect(() => {
    const start = performance.now();
    const duration = 1600;

    let frameId;

    const update = (timestamp) => {
      const progress = Math.min((timestamp - start) / duration, 1);
      const newValues = statsData.map((item) => {
        const target = item.value;
        const current = target * progress;
        return item.value % 1 !== 0 ? Number(current.toFixed(1)) : Math.round(current);
      });
      setAnimatedValues(newValues);
      if (progress < 1) {
        frameId = requestAnimationFrame(update);
      }
    };

    frameId = requestAnimationFrame(update);
    return () => cancelAnimationFrame(frameId);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const toggleFAQ = (index) => {
    setActiveFAQ((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Aurion Energy Advisory | Engineering the Future of Energy</title>
        <meta
          name="description"
          content="Aurion Energy Advisory delivers energy consulting Canada, oilfield research, industrial engineering, and crane installation leadership for reliable energy infrastructure."
        />
      </Helmet>

      <section
        className={styles.hero}
        style={{
          backgroundImage:
            "linear-gradient(120deg, rgba(15, 23, 42, 0.82), rgba(15, 23, 42, 0.35)), url('https://picsum.photos/1600/900?random=101')"
        }}
      >
        <div className={styles.heroContent}>
          <p className={styles.heroKicker}>Aurion Energy Advisory</p>
          <h1 className={styles.heroTitle}>Engineering the Future of Energy</h1>
          <p className={styles.heroDescription}>
            Aurion is a consulting firm headquartered in Toronto guiding energy infrastructure programs across Canada. We activate energy consulting Canada insights, oilfield research expertise, and industrial engineering execution to deliver resilient, low-carbon outcomes.
          </p>
          <div className={styles.heroActions}>
            <Link to="/services" className="button buttonPrimary">
              Explore Services
            </Link>
            <Link to="/contact" className="button buttonSecondary">
              Partner with Aurion
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Key achievements">
        <div className={styles.sectionHeader}>
          <h2>Trusted across complex industrial projects</h2>
          <p>
            Measurable experience in oil and gas Canada, sustainable engineering, and energy infrastructure revitalisation.
          </p>
        </div>
        <div className={styles.statsGrid}>
          {statsData.map((item, index) => (
            <div className={styles.statCard} key={item.label}>
              <span className={styles.statValue}>
                {animatedValues[index]}
                {item.suffix}
              </span>
              <span className={styles.statLabel}>{item.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.expertiseSection}>
        <div className={styles.sectionHeader}>
          <h2>Our Expertise</h2>
          <p>
            Integrated advisory, research, and engineering services ensuring every milestone advances operational reliability and sustainability goals.
          </p>
        </div>
        <div className={styles.expertiseGrid}>
          {expertiseItems.map((item) => (
            <article className={styles.expertiseCard} key={item.title}>
              <span className={styles.expertiseIcon} aria-hidden="true">
                {item.icon}
              </span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.highlightSection}>
        <div className={styles.sectionHeader}>
          <h2>Connected Energy Solutions</h2>
          <p>
            Cross-functional teams delivering oilfield research depth, crane installation assurance, and sustainable engineering innovations.
          </p>
        </div>
        <div className={styles.highlightGrid}>
          {serviceHighlights.map((item) => (
            <article key={item.title} className={styles.highlightCard}>
              <div className={styles.highlightImageWrapper}>
                <img src={item.image} alt={item.alt} loading="lazy" />
              </div>
              <div className={styles.highlightContent}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.processSection}>
        <div className={styles.sectionHeader}>
          <h2>How we deliver</h2>
          <p>Our process aligns industrial engineering rigour with change management and sustainability reporting.</p>
        </div>
        <ol className={styles.processList}>
          {processSteps.map((step) => (
            <li key={step.phase} className={styles.processItem}>
              <span className={styles.processBadge}>{step.phase}</span>
              <p>{step.detail}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className={styles.projectsSection}>
        <div className={styles.sectionHeader}>
          <h2>Recent industrial projects</h2>
          <p>Evidence of energy infrastructure upgrades and oilfield research campaigns executed with precision.</p>
        </div>
        <div className={styles.projectGrid}>
          {projectHighlights.map((project) => (
            <article className={styles.projectCard} key={project.title}>
              <div className={styles.projectImage}>
                <img src={project.image} alt={project.alt} loading="lazy" />
              </div>
              <div className={styles.projectContent}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
        <div className={styles.projectCta}>
          <Link to="/projects" className="button buttonPrimary">
            View Project Portfolio
          </Link>
        </div>
      </section>

      <section className={styles.testimonialsSection} aria-label="Client testimonials">
        <div className={styles.sectionHeader}>
          <h2>Client reflections</h2>
          <p>Leaders across Canada share how Aurion advances industrial projects with confidence.</p>
        </div>
        <div className={styles.testimonialWrapper}>
          {testimonials.map((testimonial, index) => (
            <figure
              key={testimonial.name}
              className={`${styles.testimonial} ${currentTestimonial === index ? styles.activeTestimonial : ''}`}
              aria-hidden={currentTestimonial === index ? 'false' : 'true'}
            >
              <blockquote className={styles.testimonialQuote}>
                “{testimonial.quote}”
              </blockquote>
              <figcaption className={styles.testimonialMeta}>
                <span className={styles.testimonialName}>{testimonial.name}</span>
                <span className={styles.testimonialRole}>{testimonial.role}</span>
              </figcaption>
            </figure>
          ))}
          <div className={styles.testimonialControls} role="tablist" aria-label="Testimonials navigation">
            {testimonials.map((testimonial, index) => (
              <button
                type="button"
                key={testimonial.name}
                className={`${styles.testimonialDot} ${currentTestimonial === index ? styles.activeDot : ''}`}
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Show testimonial from ${testimonial.name}`}
                aria-pressed={currentTestimonial === index}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.sustainSection}>
        <div className={styles.sustainImage}>
          <img
            src="https://picsum.photos/900/700?random=151"
            alt="Engineers assessing sustainable energy facility"
            loading="lazy"
          />
        </div>
        <div className={styles.sustainContent}>
          <h2>Sustainable engineering in action</h2>
          <p>
            From carbon baseline assessments to electrified lifting fleets, Aurion integrates sustainability into every workstream. We translate ESG directives into asset-level design criteria, engage Indigenous partners, and structure monitoring that keeps progress transparent.
          </p>
          <ul className={styles.sustainList}>
            <li>Emissions modelling and mitigation roadmaps</li>
            <li>Lifecycle assessments for industrial projects</li>
            <li>Water stewardship and biodiversity protection strategies</li>
          </ul>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className={styles.sectionHeader}>
          <h2>Frequently asked questions</h2>
          <p>Clarity around our consulting firm approach and delivery models.</p>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <div className={styles.faqItem} key={item.question}>
              <button
                type="button"
                onClick={() => toggleFAQ(index)}
                className={styles.faqTrigger}
                aria-expanded={activeFAQ === index}
                aria-controls={`faq-panel-${index}`}
              >
                <span>{item.question}</span>
                <span aria-hidden="true" className={styles.faqIcon}>
                  {activeFAQ === index ? '−' : '+'}
                </span>
              </button>
              <div
                id={`faq-panel-${index}`}
                className={`${styles.faqPanel} ${activeFAQ === index ? styles.faqPanelOpen : ''}`}
              >
                <p>{item.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className={styles.sectionHeader}>
          <h2>Insights & updates</h2>
          <p>Perspectives on energy consulting Canada, oilfield research, and industrial engineering innovation.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article className={styles.blogCard} key={post.title}>
              <div className={styles.blogImage}>
                <img src={post.image} alt={post.alt} loading="lazy" />
              </div>
              <div className={styles.blogContent}>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.blogLink} aria-label={`Read more: ${post.title}`}>
                  Read insight
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2>Ready to advance your energy infrastructure?</h2>
          <p>
            Align your next project with Aurion Energy Advisory and access multidisciplinary teams delivering consulting, research, and execution excellence.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/contact" className="button buttonPrimary">
              Partner with Aurion
            </Link>
            <Link to="/services" className="button buttonSecondary">
              View Capabilities
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;