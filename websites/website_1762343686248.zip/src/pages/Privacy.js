import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Policy | Aurion Energy Advisory</title>
      <meta
        name="description"
        content="Understand how Aurion Energy Advisory collects, uses, and protects personal information."
      />
    </Helmet>
    <h1>Privacy Policy</h1>
    <p>Last updated: March 1, 2024</p>

    <h2>Information we collect</h2>
    <p>
      We collect information you provide through contact forms, newsletter sign-ups, and event registrations. This may include your name, company, email, phone number, and project details.
    </p>

    <h2>How we use information</h2>
    <p>
      Aurion uses collected data to respond to inquiries, deliver requested services, manage client relationships, and communicate updates about our energy consulting Canada offerings.
    </p>

    <h2>Cookies and analytics</h2>
    <p>
      We use cookies and analytics to improve site performance and understand how visitors interact with our content. You can manage cookie preferences through your browser settings.
    </p>

    <h2>Data security</h2>
    <p>
      We implement reasonable safeguards to protect personal information. Despite these efforts, no transmission over the internet can be guaranteed as fully secure.
    </p>

    <h2>Information sharing</h2>
    <p>
      We do not sell personal information. We may share data with trusted partners who assist us in providing services, subject to confidentiality obligations and applicable laws.
    </p>

    <h2>Your rights</h2>
    <p>
      You may request access to, correction of, or deletion of your personal information by contacting us. We will respond in accordance with applicable privacy regulations.
    </p>

    <h2>Contact</h2>
    <p>
      For privacy-related questions, please reach out to Aurion Energy Advisory at our Toronto office.
    </p>
  </div>
);

export default Privacy;