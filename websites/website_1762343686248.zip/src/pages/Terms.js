import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms of Use | Aurion Energy Advisory</title>
      <meta
        name="description"
        content="Review the terms of use governing Aurion Energy Advisory’s website and services."
      />
    </Helmet>
    <h1>Terms of Use</h1>
    <p>Last updated: March 1, 2024</p>

    <h2>Acceptance of terms</h2>
    <p>
      By accessing this website, you acknowledge these Terms of Use and agree to comply with all applicable laws and regulations. If you do not agree with any provision, please discontinue use of the site.
    </p>

    <h2>Use of content</h2>
    <p>
      All content, including text, graphics, and media, is owned or licensed by Aurion Energy Advisory. You may view, download, or print material for informational purposes only and must retain proprietary notices.
    </p>

    <h2>Professional services</h2>
    <p>
      Information on this website is provided for general guidance and does not constitute engineering or consulting advice. Formal engagements are subject to project-specific agreements.
    </p>

    <h2>Links to other sites</h2>
    <p>
      This site may include links to third-party resources. Aurion Energy Advisory is not responsible for the content or accuracy of external sites.
    </p>

    <h2>Limitation of liability</h2>
    <p>
      Aurion Energy Advisory will not be liable for any direct or indirect damages arising from the use of this site or reliance on provided information.
    </p>

    <h2>Updates</h2>
    <p>
      We may revise these Terms of Use at any time. Continued use of the site following updates indicates acceptance of the revised terms.
    </p>

    <h2>Contact</h2>
    <p>
      For questions regarding these Terms of Use, please contact Aurion Energy Advisory at our Toronto office.
    </p>
  </div>
);

export default Terms;