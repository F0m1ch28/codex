import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  company: '',
  email: '',
  phone: '',
  message: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [statusMessage, setStatusMessage] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required.';
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[a-zA-Z]{2,}$/.test(formData.email)) {
      newErrors.email = 'Enter a valid email.';
    }
    if (!formData.message.trim()) newErrors.message = 'Please share a project summary.';
    return newErrors;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
    setErrors((prev) => ({ ...prev, [event.target.name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setStatusMessage('Thank you. Our consultants will respond within two business days.');
    setFormData(initialFormState);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Connect with Aurion Energy Advisory for energy consulting Canada, oilfield research, industrial engineering, and crane installation expertise."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Contact</h1>
        <p>
          Engage Aurion Energy Advisory to discuss energy infrastructure upgrades, oilfield research, crane installation, or sustainability programs. Submit a note and we will coordinate the right specialists for your project.
        </p>
      </section>

      <section className={styles.contactSection}>
        <div className={styles.infoPanel}>
          <h2>Office</h2>
          <p>460 Bay St, Toronto, ON M5H 2Y4, Canada</p>
          <p>
            <strong>Phone:</strong> <a href="tel:+14167924583">+1 (416) 792-4583</a>
          </p>
          <p>
            <strong>Email:</strong> <span aria-label="Email to be added by client">[Email to be added by client]</span>
          </p>
          <p>
            <strong>LinkedIn:</strong>{' '}
            <a href="https://www.linkedin.com/company/aurion-energy-advisory" target="_blank" rel="noopener noreferrer">
              Aurion Energy Advisory
            </a>
          </p>
          <iframe
            title="Aurion Energy Advisory office location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2886.277043164596!2d-79.38420712380786!3d43.65113065377905!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d6f22e4dfb%3A0xf35acc2c8d289f76!2s460%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202Y4%2C%20Canada!5e0!3m2!1sen!2sca!4v1700000000000!5m2!1sen!2sca"
            loading="lazy"
            className={styles.map}
            allowFullScreen
          />
        </div>

        <div className={styles.formPanel}>
          <h2>Let’s collaborate</h2>
          <p>Share your project scope and our consulting firm will coordinate a tailored response.</p>
          <form onSubmit={handleSubmit} noValidate>
            <div className={styles.formGroup}>
              <label htmlFor="name">Name*</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={errors.name ? 'true' : 'false'}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="company">Company</label>
              <input
                id="company"
                name="company"
                type="text"
                value={formData.company}
                onChange={handleChange}
              />
            </div>
            <div className={styles.formRow}>
              <div className={styles.formGroup}>
                <label htmlFor="email">Email*</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={errors.email ? 'true' : 'false'}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="phone">Phone</label>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="message">Project details*</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={errors.message ? 'true' : 'false'}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </div>
            <button type="submit" className="button buttonPrimary">Submit</button>
          </form>
          {statusMessage && (
            <p className={styles.status} role="status">
              {statusMessage}
            </p>
          )}
        </div>
      </section>
    </div>
  );
};

export default Contact;