import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Projects.module.css';

const projects = [
  {
    title: 'Northern LNG Terminal',
    category: 'Energy Infrastructure',
    description: 'Executed modular construction strategy, cryogenic piping, and hybrid power integration under Arctic conditions.',
    image: 'https://picsum.photos/1000/700?random=301',
    alt: 'Northern LNG facility with storage tanks'
  },
  {
    title: 'Prairie Basin Redevelopment',
    category: 'Oil & Gas Canada',
    description: 'Delivered oilfield research, reservoir modeling, and production optimisation for mature fields in Saskatchewan.',
    image: 'https://picsum.photos/1000/700?random=302',
    alt: 'Oilfield with pumpjacks and wide horizon'
  },
  {
    title: 'Harbour Crane Reconfiguration',
    category: 'Industrial Engineering',
    description: 'Orchestrated crane installation, structural reinforcement, and digital load monitoring at a busy Atlantic port.',
    image: 'https://picsum.photos/1000/700?random=303',
    alt: 'Port cranes aligned along cargo terminal'
  },
  {
    title: 'Coastal Wind Integration',
    category: 'Sustainable Engineering',
    description: 'Managed grid interconnection, dispatch modeling, and community liaison for coastal wind assets.',
    image: 'https://picsum.photos/1000/700?random=304',
    alt: 'Wind turbines along coast'
  },
  {
    title: 'Refinery Reliability Program',
    category: 'Industrial Engineering',
    description: 'Implemented project controls, turnaround coordination, and lifting operations for a refinery upgrade.',
    image: 'https://picsum.photos/1000/700?random=305',
    alt: 'Refinery infrastructure at sunset'
  },
  {
    title: 'Remote Microgrid Deployment',
    category: 'Sustainable Engineering',
    description: 'Designed hybrid microgrid for a northern community with energy storage, solar, and responsive controls.',
    image: 'https://picsum.photos/1000/700?random=306',
    alt: 'Aerial view of microgrid installation'
  }
];

const filters = ['All', 'Energy Infrastructure', 'Oil & Gas Canada', 'Industrial Engineering', 'Sustainable Engineering'];

const Projects = () => {
  const [activeFilter, setActiveFilter] = useState('All');

  const filteredProjects =
    activeFilter === 'All' ? projects : projects.filter((project) => project.category === activeFilter);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Aurion Projects | Energy Infrastructure Case Studies</title>
        <meta
          name="description"
          content="Review Aurion Energy Advisory projects spanning energy infrastructure, oilfield research, industrial engineering, and sustainable engineering initiatives."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Projects</h1>
        <p>
          A selection of recent projects demonstrating our ability to combine analysis, engineering, and field execution. Each case showcases collaborative delivery across diverse geographies and conditions.
        </p>
      </section>

      <section className={styles.filterSection}>
        <div className={styles.filterGroup} role="tablist" aria-label="Project categories">
          {filters.map((filter) => (
            <button
              key={filter}
              type="button"
              className={`${styles.filterButton} ${activeFilter === filter ? styles.activeFilter : ''}`}
              onClick={() => setActiveFilter(filter)}
              aria-pressed={activeFilter === filter}
            >
              {filter}
            </button>
          ))}
        </div>
      </section>

      <section className={styles.gridSection}>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <div className={styles.imageWrapper}>
                <img src={project.image} alt={project.alt} loading="lazy" />
              </div>
              <div className={styles.projectBody}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h2>{project.title}</h2>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Projects;