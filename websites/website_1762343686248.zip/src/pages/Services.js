import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const servicesData = [
  {
    title: 'Energy Consulting',
    description: 'Strategic planning, asset lifecycle management, and regulatory navigation for energy infrastructure programs across Canada.',
    bulletPoints: [
      'Integrated resource planning and scenario design',
      'Grid and pipeline modernisation advisory',
      'Stakeholder engagement and readiness facilitation'
    ],
    icon: '🧭'
  },
  {
    title: 'Oilfield Research',
    description: 'Reservoir analytics, core analysis, and compliance documentation that strengthen oil and gas Canada decisions.',
    bulletPoints: [
      'Geological and geophysical evaluations',
      'Reservoir simulation and decline analysis',
      'Regulatory filings, integrity reviews, and audit support'
    ],
    icon: '🛰️'
  },
  {
    title: 'Installation & Commissioning',
    description: 'Crane installation, heavy lift oversight, and precise commissioning support for refineries, terminals, and fabrication yards.',
    bulletPoints: [
      'Lift engineering and rigging supervision',
      'Mechanical completion and system turnover',
      'Digital commissioning, testing, and training'
    ],
    icon: '🏗️'
  },
  {
    title: 'Environmental Assessment',
    description: 'Sustainable engineering practices aligning projects with environmental stewardship and community expectations.',
    bulletPoints: [
      'Impact assessments and mitigation planning',
      'Emissions modelling and carbon roadmaps',
      'Water, land, and biodiversity management strategies'
    ],
    icon: '🌿'
  },
  {
    title: 'Project Management',
    description: 'Integrated project controls and risk oversight ensuring predictable delivery from concept through optimisation.',
    bulletPoints: [
      'Program governance and PMO setup',
      'Schedule, budget, and risk analytics',
      'Vendor coordination and performance insights'
    ],
    icon: '📊'
  }
];

const Services = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Aurion Services | Energy Consulting & Industrial Engineering</title>
      <meta
        name="description"
        content="Explore Aurion Energy Advisory services including energy consulting, oilfield research, crane installation, environmental assessment, and project management."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <h1>Services</h1>
        <p>
          We integrate consulting, research, and engineering capabilities to deliver tailored solutions. Our teams navigate regulatory frameworks, manage industrial construction, and embed sustainable practices from inception.
        </p>
      </div>
    </section>

    <section className={styles.servicesSection}>
      <div className={styles.servicesGrid}>
        {servicesData.map((service) => (
          <article key={service.title} className={styles.serviceCard}>
            <span className={styles.serviceIcon} aria-hidden="true">{service.icon}</span>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
            <ul>
              {service.bulletPoints.map((point) => (
                <li key={point}>{point}</li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.deliverySection}>
      <div className={styles.sectionHeader}>
        <h2>Integrated delivery model</h2>
        <p>Our framework connects strategy, field execution, and sustainable performance tracking.</p>
      </div>
      <div className={styles.deliveryGrid}>
        <article>
          <h3>Program strategy</h3>
          <p>
            Establish vision, scope, and metrics with stakeholder alignment workshops, market intelligence, and scenario planning.
          </p>
        </article>
        <article>
          <h3>Design & coordination</h3>
          <p>
            Translate blueprints into actionable plans, coordinating engineering disciplines, fabrication partners, and logistics teams.
          </p>
        </article>
        <article>
          <h3>Field execution</h3>
          <p>
            Deploy crane installation specialists, quality oversight, and commissioning leads with digital tools for real-time monitoring.
          </p>
        </article>
        <article>
          <h3>Performance optimisation</h3>
          <p>
            Monitor operational data, implement predictive maintenance, and report on sustainability commitments.
          </p>
        </article>
      </div>
    </section>
  </div>
);

export default Services;