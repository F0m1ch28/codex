import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-labelledby="footer-heading">
    <div className={styles.container}>
      <div className={styles.brand}>
        <h2 id="footer-heading" className={styles.title}>
          Aurion Energy Advisory
        </h2>
        <p className={styles.summary}>
          Canadian consulting firm delivering energy consulting Canada, oilfield research, industrial engineering, and sustainable engineering programs for critical infrastructure.
        </p>
      </div>
      <div className={styles.grid}>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Company</h3>
          <ul className={styles.linkList}>
            <li><NavLink to="/about">About</NavLink></li>
            <li><NavLink to="/team">Team</NavLink></li>
            <li><NavLink to="/projects">Projects</NavLink></li>
            <li><NavLink to="/services">Services</NavLink></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Resources</h3>
          <ul className={styles.linkList}>
            <li><NavLink to="/terms">Terms of Use</NavLink></li>
            <li><NavLink to="/policy">Privacy Policy</NavLink></li>
            <li><NavLink to="/cookie-policy">Cookie Policy</NavLink></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Contact</h3>
          <ul className={styles.contactList}>
            <li>460 Bay St, Toronto, ON M5H 2Y4, Canada</li>
            <li><a href="tel:+14167924583">+1 (416) 792-4583</a></li>
            <li>Email: <span aria-label="Email will be provided by client">[Email to be added]</span></li>
            <li>
              <a href="https://www.linkedin.com/company/aurion-energy-advisory" target="_blank" rel="noopener noreferrer">
                LinkedIn
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div className={styles.footerNote}>
      <p>© {new Date().getFullYear()} Aurion Energy Advisory. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;