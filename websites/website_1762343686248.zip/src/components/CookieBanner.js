import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'aurion-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(COOKIE_KEY, 'accepted');
    setVisible(false);
  };

  const declineCookies = () => {
    localStorage.setItem(COOKIE_KEY, 'declined');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <div className={styles.content}>
        <h2 className={styles.title}>Cookies Notice</h2>
        <p className={styles.message}>
          We use cookies to enhance navigation, analyse usage, and tailor content for energy consulting Canada audiences. You can accept or decline non-essential cookies.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className="button buttonSecondary" onClick={declineCookies}>
          Decline
        </button>
        <button type="button" className="button buttonPrimary" onClick={acceptCookies}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;