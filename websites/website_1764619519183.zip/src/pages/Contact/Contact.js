import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import Section from "../../components/Section/Section";
import Breadcrumbs from "../../components/Breadcrumbs/Breadcrumbs";
import Button from "../../components/Button/Button";
import { contactInfo } from "../../utils/constants";
import { useLanguage } from "../../context/LanguageContext";
import "./Contact.css";

const Contact = () => {
  const { language, t } = useLanguage();

  return (
    <motion.main
      className="contact"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <Helmet>
        <html lang={language === "es" ? "es" : "en"} />
        <title>{language === "es" ? "Contacto | Tu Progreso Hoy" : "Contact | Tu Progreso Hoy"}</title>
        <meta
          name="description"
          content="Contact Tu Progreso Hoy in Buenos Aires for bilingual inflation education, workshops, and ARS to USD planning tools."
        />
      </Helmet>

      <div className="contact__hero">
        <Breadcrumbs
          items={[
            {
              label: t("nav_contact")
            }
          ]}
        />
        <h1>{t("contact_title")}</h1>
        <p>
          {language === "es"
            ? "Co-creemos un plan claro para dominar la inflación argentina con datos verificables y un equipo bilingüe."
            : "Co-create a clear plan to master Argentina’s inflation with verifiable data and a bilingual team."}
        </p>
      </div>

      <Section id="contact-grid">
        <div className="contact__grid">
          <div className="contact__info">
            <h3>{t("contact_address")}</h3>
            <p>
              {t("contact_phone_label")}:{" "}
              <a href={`tel:${contactInfo.phone}`} className="contact__link">
                {contactInfo.phone}
              </a>
            </p>
            <p>
              {t("contact_email_label")}:{" "}
              <a href={`mailto:${contactInfo.email}`} className="contact__link">
                {contactInfo.email}
              </a>
            </p>
            <div className="contact__social">
              {contactInfo.socials.map((social) => (
                <a
                  key={social.name}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="contact__social-link"
                >
                  {social.name}
                </a>
              ))}
            </div>
            <Button variant="secondary" animated onClick={() => window.location.href = "mailto:contacto@tuprogresohoy.com"}>
              {language === "es" ? "Escribir correo" : "Send email"}
            </Button>
          </div>
          <form className="contact__form" aria-label="Contact form" onSubmit={(event) => event.preventDefault()}>
            <h3>{t("contact_form_title")}</h3>
            <label>
              {t("form_name")}
              <input type="text" name="name" required placeholder="Tu nombre" />
            </label>
            <label>
              {t("contact_email_placeholder")}
              <input type="email" name="email" required placeholder="email@ejemplo.com" />
            </label>
            <label>
              {language === "es" ? "Teléfono" : "Phone"}
              <input type="tel" name="phone" placeholder="+54 11 ..." />
            </label>
            <label>
              {t("contact_message_placeholder")}
              <textarea name="message" rows="5" placeholder="Contanos tu desafío" />
            </label>
            <label className="contact__checkbox">
              <input type="checkbox" required />
              <span>
                {language === "es"
                  ? "Acepto recibir comunicaciones y confirmo la suscripción doble al enviar."
                  : "I agree to receive communications and confirm the double opt-in upon submission."}
              </span>
            </label>
            <Button variant="primary" animated type="submit">
              {t("contact_submit")}
            </Button>
          </form>
        </div>
      </Section>

      <Section id="map">
        <div className="contact__map-wrapper">
          <img
            src="https://staticmap.openstreetmap.de/staticmap.php?center=-34.6037,-58.3816&zoom=14&size=800x500&markers=-34.6037,-58.3816,red"
            alt="Map of Buenos Aires office location / Mapa de la ubicación de la oficina en Buenos Aires"
            loading="lazy"
          />
        </div>
      </Section>
    </motion.main>
  );
};

export default Contact;