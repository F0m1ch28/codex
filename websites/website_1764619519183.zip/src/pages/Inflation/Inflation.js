import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import Section from "../../components/Section/Section";
import Accordion from "../../components/Accordion/Accordion";
import Breadcrumbs from "../../components/Breadcrumbs/Breadcrumbs";
import DataDashboard from "../../components/DataDashboard/DataDashboard";
import { methodologyPoints, faqItems } from "../../utils/constants";
import { useLanguage } from "../../context/LanguageContext";
import "./Inflation.css";

const Inflation = () => {
  const { language, t } = useLanguage();

  return (
    <motion.main
      className="inflation"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <Helmet>
        <html lang={language === "es" ? "es" : "en"} />
        <title>{language === "es" ? "Laboratorio de Inflación | Tu Progreso Hoy" : "Inflation Lab | Tu Progreso Hoy"}</title>
        <meta
          name="description"
          content="Dive into Tu Progreso Hoy methodology with CPI context, ARS → USD trackers, and bilingual FAQ to support Argentina decision-making."
        />
      </Helmet>

      <div className="inflation__hero">
        <Breadcrumbs
          items={[
            {
              label: language === "es" ? "Laboratorio de Inflación" : "Inflation Lab"
            }
          ]}
        />
        <h1>{language === "es" ? "Laboratorio de Inflación" : "Inflation Lab"}</h1>
        <p>
          {language === "es"
            ? "Metodología transparente para analizar el IPC argentino, comparativos cambiarios y escenarios prácticos."
            : "Transparent methodology to analyze Argentina CPI, FX comparisons, and practical scenario planning."}
        </p>
      </div>

      <Section id="methodology-grid" title="Methodology">
        <div className="inflation__grid">
          {methodologyPoints.map((point, index) => (
            <motion.article
              key={point.titleEn}
              className="inflation-card"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-70px" }}
              transition={{ delay: index * 0.1 }}
            >
              <h3>{language === "es" ? point.titleEs : point.titleEn}</h3>
              <p>{language === "es" ? point.descriptionEs : point.descriptionEn}</p>
            </motion.article>
          ))}
        </div>
      </Section>

      <Section id="dashboard" title={t("tracker_title")} background="muted">
        <DataDashboard
          title={t("tracker_title")}
          updatedLabel={t("tracker_updated")}
          rateLabel={t("tracker_rate")}
          changeLabel={t("tracker_change_daily")}
          insightLabel={t("tracker_insight")}
        />
      </Section>

      <Section
        id="context"
        title={language === "es" ? "Contexto CPI y FX" : "CPI & FX Context"}
        subtitle={
          language === "es"
            ? "Entiende cómo el IPC nacional se conecta con tus decisiones diarias y conversiones cambiarias."
            : "Understand how national CPI connects with daily decisions and FX conversions."
        }
      >
        <div className="inflation__context">
          <article>
            <h3>{language === "es" ? "CPI interanual" : "Year-on-year CPI"}</h3>
            <p>
              {language === "es"
                ? "El IPC acumulado anual se actualiza con datos de INDEC. Nuestras visualizaciones permiten comparar componentes como alimentos, transporte y educación."
                : "Year-to-date CPI relies on INDEC data. Our visuals let you compare components such as food, transport, and education."}
            </p>
          </article>
          <article>
            <h3>{language === "es" ? "Tipos de cambio" : "Exchange rates"}</h3>
            <p>
              {language === "es"
                ? "Seguimos MEP, CCL y tipos oficiales para ajustar modelos de flujo de caja y definir momentos de dolarización."
                : "We track MEP, CCL, and official rates to adjust cash-flow models and define dollarization timing."}
            </p>
          </article>
          <article>
            <h3>{language === "es" ? "Sensibilidad por provincia" : "Province sensitivity"}</h3>
            <p>
              {language === "es"
                ? "Los paneles incluyen filtros provinciales para equipos federales que necesitan coordinar salarios y planes de expansión."
                : "Dashboards include provincial filters for federal teams coordinating salaries and expansion plans."}
            </p>
          </article>
        </div>
      </Section>

      <Section id="faq" title={t("faq_title")}>
        <Accordion items={faqItems} language={language} />
      </Section>
    </motion.main>
  );
};

export default Inflation;