import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import Section from "../../components/Section/Section";
import Button from "../../components/Button/Button";
import { useLanguage } from "../../context/LanguageContext";
import "./ThankYou.css";

const ThankYou = () => {
  const { language, t } = useLanguage();

  return (
    <motion.main
      className="thankyou"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <Helmet>
        <html lang={language === "es" ? "es" : "en"} />
        <title>{t("thankyou_title")}</title>
        <meta
          name="description"
          content="Confirm your Tu Progreso Hoy subscription via email to access the free lesson and inflation planning resources."
        />
      </Helmet>

      <Section id="confirmation">
        <div className="thankyou__card">
          <h1>{t("thankyou_title")}</h1>
          <p>{t("thankyou_message")}</p>
          <Button variant="primary" animated onClick={() => window.location.href = "/"}>
            {t("back_home")}
          </Button>
        </div>
      </Section>
    </motion.main>
  );
};

export default ThankYou;