import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import Section from "../../components/Section/Section";
import { useLanguage } from "../../context/LanguageContext";
import "./Terms.css";

const Terms = () => {
  const { language, t } = useLanguage();

  return (
    <motion.main
      className="legal"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <Helmet>
        <html lang={language === "es" ? "es" : "en"} />
        <title>{t("terms_title")}</title>
      </Helmet>

      <Section id="terms">
        <div className="legal__card">
          <h1>{t("terms_title")}</h1>
          <h2>{language === "es" ? "Aceptación" : "Acceptance"}</h2>
          <p>
            {language === "es"
              ? "Al utilizar Tu Progreso Hoy aceptás estos términos y condiciones, incluyendo nuestras políticas de privacidad y cookies."
              : "By using Tu Progreso Hoy you accept these terms and conditions alongside our privacy and cookie policies."}
          </p>
          <h2>{language === "es" ? "Servicios educativos" : "Educational services"}</h2>
          <p>
            {language === "es"
              ? "Proveemos servicios educativos y de investigación. No brindamos asesoramiento financiero ni intermediamos productos."
              : "We deliver educational and research services. We do not offer financial advisory or intermediate products."}
          </p>
          <h2>{language === "es" ? "Propiedad intelectual" : "Intellectual property"}</h2>
          <p>
            {language === "es"
              ? "Los materiales del curso, dashboards y artículos están protegidos. Podés usarlos internamente con atribución."
              : "Course materials, dashboards, and articles are protected. You may use them internally with attribution."}
          </p>
        </div>
      </Section>
    </motion.main>
  );
};

export default Terms;