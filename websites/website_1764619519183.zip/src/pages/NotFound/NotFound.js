import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import Section from "../../components/Section/Section";
import Button from "../../components/Button/Button";
import { useLanguage } from "../../context/LanguageContext";
import "./NotFound.css";

const NotFound = () => {
  const { language, t } = useLanguage();

  return (
    <motion.main
      className="notfound"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <Helmet>
        <html lang={language === "es" ? "es" : "en"} />
        <title>{t("notfound_title")}</title>
      </Helmet>

      <Section id="404">
        <div className="notfound__card">
          <h1>404</h1>
          <p>{language === "es" ? "Esta página se desinfló. Volvamos a planificar." : "This page deflated. Let’s get back on track."}</p>
          <Button variant="primary" animated onClick={() => window.location.href = "/"}>
            {t("back_home")}
          </Button>
        </div>
      </Section>
    </motion.main>
  );
};

export default NotFound;