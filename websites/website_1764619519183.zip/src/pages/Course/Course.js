import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import Section from "../../components/Section/Section";
import Breadcrumbs from "../../components/Breadcrumbs/Breadcrumbs";
import CourseModule from "../../components/CourseModule/CourseModule";
import SubscriptionForm from "../../components/SubscriptionForm/SubscriptionForm";
import Button from "../../components/Button/Button";
import { courseModules } from "../../utils/constants";
import { useLanguage } from "../../context/LanguageContext";
import "./Course.css";

const courseImage =
  "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop";

const Course = () => {
  const { language, t } = useLanguage();

  return (
    <motion.main
      className="course"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <Helmet>
        <html lang={language === "es" ? "es" : "en"} />
        <title>{language === "es" ? "Programa Tu Progreso Hoy" : "Tu Progreso Hoy Course"}</title>
        <meta
          name="description"
          content="Access the Tu Progreso Hoy syllabus with bilingual modules covering inflation fundamentals, FX strategies, and decision playbooks for Argentina."
        />
      </Helmet>

      <div className="course__hero">
        <Breadcrumbs
          items={[
            {
              label: language === "es" ? "Programa" : "Course"
            }
          ]}
        />
        <div className="course__grid">
          <div className="course__copy">
            <h1>{language === "es" ? "Programa integral contra la inflación" : "Comprehensive Inflation Mastery"}</h1>
            <p>
              {language === "es"
                ? "Aprendé junto a expertos en economía argentina con un enfoque práctico, bilingüe y orientado a resultados medibles."
                : "Learn with Argentina-focused experts through a practical, bilingual curriculum engineered for measurable outcomes."}
            </p>
            <div className="course__actions">
              <a href="#modules">
                <Button variant="primary" animated>
                  {t("hero_cta")}
                </Button>
              </a>
              <a href="#form">
                <Button variant="outline" animated>
                  {language === "es" ? "Agendar asesoría" : "Book advisory call"}
                </Button>
              </a>
            </div>
          </div>
          <div className="course__media">
            <img
              src={courseImage}
              alt="Collaborative inflation workshop / Taller colaborativo sobre inflación"
              loading="lazy"
            />
          </div>
        </div>
      </div>

      <Section
        id="modules"
        title={language === "es" ? "Módulos del programa" : "Program Modules"}
        subtitle={
          language === "es"
            ? "Cada módulo incluye plantillas descargables, dashboards interactivos y sesiones bilingües."
            : "Each module features downloadable templates, interactive dashboards, and bilingual facilitation."
        }
      >
        <div className="course__modules">
          {courseModules.map((module, index) => (
            <CourseModule key={module.id} module={module} index={index} />
          ))}
        </div>
      </Section>

      <Section
        id="audience"
        title={language === "es" ? "¿Para quién es Tu Progreso Hoy?" : "Who is Tu Progreso Hoy for?"}
      >
        <div className="course__audience">
          <article>
            <h3>{language === "es" ? "Profesionales y freelancers" : "Professionals & Freelancers"}</h3>
            <p>
              {language === "es"
                ? "Protegé tus honorarios y renegociá contratos con tableros y benchmarks actualizados."
                : "Safeguard your fees and renegotiate contracts using up-to-date dashboards and benchmarks."}
            </p>
          </article>
          <article>
            <h3>{language === "es" ? "Equipos corporativos" : "Corporate teams"}</h3>
            <p>
              {language === "es"
                ? "Coordiná compensaciones, políticas de viaje y compras capitales con análisis FX ágil."
                : "Align compensation, travel policies, and capital purchases with agile FX analysis."}
            </p>
          </article>
          <article>
            <h3>{language === "es" ? "Familias y emprendedores" : "Families & Entrepreneurs"}</h3>
            <p>
              {language === "es"
                ? "Planificá gastos esenciales y escenarios de dolarización con plantillas interactivas."
                : "Plan essential spending and dollarization scenarios using interactive templates."}
            </p>
          </article>
        </div>
      </Section>

      <Section id="form" background="muted">
        <SubscriptionForm />
      </Section>
    </motion.main>
  );
};

export default Course;