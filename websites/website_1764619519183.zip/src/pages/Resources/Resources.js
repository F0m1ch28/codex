import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import Section from "../../components/Section/Section";
import Breadcrumbs from "../../components/Breadcrumbs/Breadcrumbs";
import Button from "../../components/Button/Button";
import { resourcesList } from "../../utils/constants";
import { useLanguage } from "../../context/LanguageContext";
import "./Resources.css";

const Resources = () => {
  const { language, t } = useLanguage();

  return (
    <motion.main
      className="resources"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <Helmet>
        <html lang={language === "es" ? "es" : "en"} />
        <title>{language === "es" ? "Recursos Tu Progreso Hoy" : "Tu Progreso Hoy Resources"}</title>
        <meta
          name="description"
          content="Browse bilingual resources, glossaries, and articles from Tu Progreso Hoy to deepen your understanding of Argentina’s inflation landscape."
        />
      </Helmet>

      <div className="resources__hero">
        <Breadcrumbs
          items={[
            {
              label: language === "es" ? "Recursos" : "Resources"
            }
          ]}
        />
        <h1>{language === "es" ? "Recursos & Glosarios" : "Resources & Glossaries"}</h1>
        <p>{t("resources_intro")}</p>
      </div>

      <Section id="resource-list">
        <div className="resources__grid">
          {resourcesList.map((resource, index) => (
            <motion.article
              key={resource.id}
              className="resource-card"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ delay: index * 0.08 }}
            >
              <span className="resource-card__date">{resource.date}</span>
              <h3>{language === "es" ? resource.titleEs : resource.titleEn}</h3>
              <p>{language === "es" ? resource.descriptionEs : resource.descriptionEn}</p>
              <Button variant="secondary" animated onClick={() => window.open(resource.url, "_blank")}>
                {language === "es" ? "Abrir recurso" : "Open resource"}
              </Button>
            </motion.article>
          ))}
        </div>
      </Section>

      <Section id="resource-image">
        <div className="resources__image">
          <img
            src="https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
            alt="Analyst reviewing financial reports / Analista revisando reportes financieros"
            loading="lazy"
          />
        </div>
      </Section>
    </motion.main>
  );
};

export default Resources;