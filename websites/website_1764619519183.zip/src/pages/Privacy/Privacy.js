import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import Section from "../../components/Section/Section";
import { useLanguage } from "../../context/LanguageContext";
import "./Privacy.css";

const Privacy = () => {
  const { language, t } = useLanguage();

  return (
    <motion.main
      className="legal"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <Helmet>
        <html lang={language === "es" ? "es" : "en"} />
        <title>{t("privacy_title")}</title>
      </Helmet>

      <Section id="privacy">
        <div className="legal__card">
          <h1>{t("privacy_title")}</h1>
          <p>
            {language === "es"
              ? "Tu Progreso Hoy protege tu privacidad conforme a la legislación argentina y estándares internacionales de e-learning."
              : "Tu Progreso Hoy protects your privacy according to Argentine legislation and international e-learning standards."}
          </p>
          <h2>{language === "es" ? "Información recopilada" : "Information collected"}</h2>
          <p>
            {language === "es"
              ? "Recopilamos datos provistos voluntariamente: nombre, correo, rol profesional y preferencias para personalizar las comunicaciones."
              : "We collect voluntarily provided data: name, email, professional role, and preferences to personalize communications."}
          </p>
          <h2>{language === "es" ? "Uso de la información" : "Use of information"}</h2>
          <p>
            {language === "es"
              ? "Utilizamos la información para coordinar el doble opt-in, enviar contenido educativo y estadísticas agregadas."
              : "We use information to coordinate double opt-in, deliver educational content, and aggregated statistics."}
          </p>
          <h2>{language === "es" ? "Tus derechos" : "Your rights"}</h2>
          <p>
            {language === "es"
              ? "Podés solicitar acceso, rectificación o eliminación de tus datos escribiendo a privacidad@tuprogresohoy.com."
              : "You may request access, rectification, or deletion of your data by emailing privacidad@tuprogresohoy.com."}
          </p>
        </div>
      </Section>
    </motion.main>
  );
};

export default Privacy;