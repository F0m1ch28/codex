import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import Section from "../../components/Section/Section";
import { useLanguage } from "../../context/LanguageContext";
import "./Cookies.css";

const Cookies = () => {
  const { language, t } = useLanguage();

  return (
    <motion.main
      className="legal"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <Helmet>
        <html lang={language === "es" ? "es" : "en"} />
        <title>{t("cookies_title")}</title>
      </Helmet>

      <Section id="cookies">
        <div className="legal__card">
          <h1>{t("cookies_title")}</h1>
          <p>
            {language === "es"
              ? "Utilizamos cookies esenciales y analíticas para mejorar la experiencia bilingüe y recordar tus preferencias de idioma."
              : "We use essential and analytical cookies to improve bilingual experiences and remember your language preferences."}
          </p>
          <h2>{language === "es" ? "Cookies esenciales" : "Essential cookies"}</h2>
          <p>
            {language === "es"
              ? "Necesarias para operar el sitio, gestionar sesiones y atender solicitudes de contacto."
              : "Required to operate the site, manage sessions, and process contact requests."}
          </p>
          <h2>{language === "es" ? "Cookies analíticas" : "Analytics cookies"}</h2>
          <p>
            {language === "es"
              ? "Medimos interacciones de forma agregada para mejorar módulos, artículos y eventos."
              : "We measure aggregated interactions to improve modules, articles, and events."}
          </p>
        </div>
      </Section>
    </motion.main>
  );
};

export default Cookies;