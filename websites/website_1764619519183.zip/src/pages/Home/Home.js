import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import Section from "../../components/Section/Section";
import DataDashboard from "../../components/DataDashboard/DataDashboard";
import SubscriptionForm from "../../components/SubscriptionForm/SubscriptionForm";
import TestimonialsSlider from "../../components/TestimonialsSlider/TestimonialsSlider";
import { insightsCards, courseModules } from "../../utils/constants";
import CourseModule from "../../components/CourseModule/CourseModule";
import Button from "../../components/Button/Button";
import { useLanguage } from "../../context/LanguageContext";
import "./Home.css";

const heroImage = "https://images.pexels.com/photos/4386476/pexels-photo-4386476.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop";

const Home = () => {
  const { t, language } = useLanguage();

  return (
    <motion.main
      className="home"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <Helmet>
        <html lang={language === "es" ? "es" : "en"} />
        <title>Tu Progreso Hoy | Argentina Inflation Academy</title>
        <link rel="alternate" hrefLang="en" href="https://www.tuprogresohoy.com/" />
        <link rel="alternate" hrefLang="es-AR" href="https://www.tuprogresohoy.com/" />
        <meta
          name="description"
          content="Tu Progreso Hoy delivers bilingual inflation education, ARS to USD tracking, and data-driven planning tools for Argentina."
        />
      </Helmet>

      <section className="hero">
        <div className="hero__background" aria-hidden="true">
          <img
            src={heroImage}
            alt="Financial planning team in Argentina / Equipo de planificación financiera en Argentina"
          />
          <div className="hero__flag-overlay" />
        </div>
        <div className="hero__content">
          <motion.div
            className="hero__copy"
            initial={{ y: 24, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="hero__title">{t("hero_title")}</h1>
            <p className="hero__subtitle">{t("hero_subtitle")}</p>
            <div className="hero__actions">
              <Button variant="primary" animated>
                {t("hero_cta")}
              </Button>
              <a href="#methodology">
                <Button variant="outline" animated>
                  {t("hero_secondary")}
                </Button>
              </a>
            </div>
            <div className="hero__meta">
              <span>Buenos Aires, Argentina</span>
              <span>{t("tracker_updated")}: {new Date().toLocaleDateString("es-AR")}</span>
            </div>
          </motion.div>
        </div>
      </section>

      <Section
        id="promises"
        title={t("promises_title")}
      >
        <div className="home__promises">
          {insightsCards.map((card, index) => (
            <motion.article
              key={card.id}
              className={`promise-card promise-card--${card.trend}`}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ delay: index * 0.08 }}
              whileHover={{ scale: 1.03 }}
            >
              <span className="promise-card__tag">
                {index === 0 ? "FX" : index === 1 ? "CPI" : "Alerts"}
              </span>
              <h3>{language === "es" ? card.titleEs : card.titleEn}</h3>
              <p>{language === "es" ? card.descriptionEs : card.descriptionEn}</p>
              <strong className="promise-card__metric">{card.metric}</strong>
            </motion.article>
          ))}
        </div>
      </Section>

      <Section
        id="tracker"
        background="muted"
        title={t("tracker_title")}
      >
        <DataDashboard
          title={t("tracker_title")}
          updatedLabel={t("tracker_updated")}
          rateLabel={t("tracker_rate")}
          changeLabel={t("tracker_change_daily")}
          insightLabel={t("tracker_insight")}
        />
      </Section>

      <Section
        id="insights"
        title={t("insights_title")}
        subtitle={t("insights_subtitle")}
      >
        <div className="home__insights-grid">
          <article className="insight-card">
            <h3>{language === "es" ? "Metodología verificable" : "Verifiable methodology"}</h3>
            <p>
              {language === "es"
                ? "Integramos dashboards con reseñas narrativas y alarmas configurables para anticipar los impactos en tu poder de compra."
                : "We blend dashboards with narrative recaps and configurable alerts so you can anticipate impacts on purchasing power."}
            </p>
          </article>
          <article className="insight-card insight-card--image">
            <img
              src="https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&fit=crop"
              alt="Research team reviewing charts / Equipo de investigación revisando gráficos"
              loading="lazy"
            />
          </article>
          <article className="insight-card">
            <h3>{language === "es" ? "Contexto CPI y FX" : "CPI and FX context"}</h3>
            <p>
              {language === "es"
                ? "Compará escenarios con plantillas descargables y compartí reportes bilingües listos para tus stakeholders."
                : "Compare scenarios with downloadable templates and share bilingual reports ready for your stakeholders."}
            </p>
          </article>
        </div>
      </Section>

      <Section
        id="course-overview"
        title={t("course_overview_title")}
        subtitle={t("course_overview_desc")}
      >
        <div className="home__course">
          <div className="home__course-media">
            <img
              src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1200&h=900&fit=crop"
              alt="Collaborative learning workshop / Taller de aprendizaje colaborativo"
              loading="lazy"
            />
          </div>
          <div className="home__course-list">
            {courseModules.slice(0, 3).map((module, index) => (
              <CourseModule key={module.id} module={module} index={index} />
            ))}
            <a href="/course" className="home__course-link">
              <Button variant="secondary" animated>
                {language === "es" ? "Ver programa completo" : "View full syllabus"}
              </Button>
            </a>
          </div>
        </div>
      </Section>

      <Section id="testimonials" title={t("testimonials_title")}>
        <TestimonialsSlider />
      </Section>

      <Section id="methodology" title="Metodología / Methodology">
        <div className="home__methodology">
          <article className="methodology-card">
            <h3>Datasets</h3>
            <p>
              {language === "es"
                ? "INDEC, BCRA, y fuentes internacionales con validación local semanal."
                : "INDEC, BCRA, and international feeds with weekly local validation."}
            </p>
          </article>
          <article className="methodology-card">
            <h3>Playbooks</h3>
            <p>
              {language === "es"
                ? "Escenarios accionables para hogares, pymes y equipos globales."
                : "Actionable scenarios for households, SMEs, and global teams."}
            </p>
          </article>
          <article className="methodology-card">
            <h3>Analytics</h3>
            <p>
              {language === "es"
                ? "Visualizaciones adaptativas y alertas correo/aplicación."
                : "Adaptive visualizations plus email/app alerts."}
            </p>
          </article>
        </div>
      </Section>

      <Section id="trial-form" background="muted">
        <SubscriptionForm />
      </Section>
    </motion.main>
  );
};

export default Home;