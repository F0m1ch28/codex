import React, { Suspense, lazy, useMemo } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { HelmetProvider } from "react-helmet-async";
import Header from "./components/Header/Header";
import Footer from "./components/Footer/Footer";
import CookieBanner from "./components/CookieBanner/CookieBanner";
import DisclaimerModal from "./components/DisclaimerModal/DisclaimerModal";
import BackToTop from "./components/BackToTop/BackToTop";
import { LanguageProvider } from "./context/LanguageContext";
import { ThemeProvider } from "./context/ThemeContext";
import LoadingScreen from "./components/LoadingScreen/LoadingScreen";
import ErrorBoundary from "./components/ErrorBoundary/ErrorBoundary";

const Home = lazy(() => import("./pages/Home/Home"));
const Inflation = lazy(() => import("./pages/Inflation/Inflation"));
const Course = lazy(() => import("./pages/Course/Course"));
const Resources = lazy(() => import("./pages/Resources/Resources"));
const Contact = lazy(() => import("./pages/Contact/Contact"));
const ThankYou = lazy(() => import("./pages/ThankYou/ThankYou"));
const Privacy = lazy(() => import("./pages/Privacy/Privacy"));
const Cookies = lazy(() => import("./pages/Cookies/Cookies"));
const Terms = lazy(() => import("./pages/Terms/Terms"));
const NotFound = lazy(() => import("./pages/NotFound/NotFound"));

function App() {
  const helmetContext = useMemo(() => ({}), []);

  return (
    <HelmetProvider context={helmetContext}>
      <ErrorBoundary>
        <ThemeProvider>
          <LanguageProvider>
            <div className="app">
              <Header />
              <AnimatePresence mode="wait">
                <Suspense fallback={<LoadingScreen />}>
                  <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/inflation" element={<Inflation />} />
                    <Route path="/course" element={<Course />} />
                    <Route path="/resources" element={<Resources />} />
                    <Route path="/contact" element={<Contact />} />
                    <Route path="/thank-you" element={<ThankYou />} />
                    <Route path="/privacy" element={<Privacy />} />
                    <Route path="/cookies" element={<Cookies />} />
                    <Route path="/terms" element={<Terms />} />
                    <Route path="/404" element={<NotFound />} />
                    <Route path="/sitemap.xml" element={<Navigate to="/" replace />} />
                    <Route path="*" element={<Navigate to="/404" replace />} />
                  </Routes>
                </Suspense>
              </AnimatePresence>
              <Footer />
              <CookieBanner />
              <DisclaimerModal />
              <BackToTop />
            </div>
          </LanguageProvider>
        </ThemeProvider>
      </ErrorBoundary>
    </HelmetProvider>
  );
}

export default App;