export const translations = {
  en: {
    nav_home: "Home",
    nav_inflation: "Inflation Lab",
    nav_course: "Course",
    nav_resources: "Resources",
    nav_contact: "Contact",
    hero_title: "Tu Progreso Hoy: Argentina Inflation Mastery",
    hero_subtitle:
      "Verified data, bilingual insights, and actionable tools to navigate Argentina’s inflation. Datos verificados para planificar tu presupuesto.",
    hero_cta: "Получить бесплатный пробный урок",
    hero_secondary: "Explore methodology",
    promises_title: "Why Argentines choose Tu Progreso Hoy",
    promise_1_title: "Real-time ARS → USD monitoring",
    promise_1_desc: "Track exchange rate shifts with contextual CPI data curated for Buenos Aires residents.",
    promise_2_title: "Scenario-based learning",
    promise_2_desc: "Interactive modules help families model expenses and protect their purchasing power.",
    promise_3_title: "Bilingual support",
    promise_3_desc: "Content and facilitators available in English and Español for multinational teams.",
    tracker_title: "ARS → USD Live Tracker",
    tracker_updated: "Last updated",
    tracker_rate: "ARS per USD",
    tracker_change_daily: "Daily variation",
    tracker_insight: "7-day volatility",
    insights_title: "Inflation Insights for Smarter Planning",
    insights_subtitle:
      "Stay ahead with curated commentary, CPI forecasts, and monthly spending benchmarks for Argentina.",
    course_overview_title: "Course Overview",
    course_overview_desc:
      "A blended curriculum designed for professionals, families, and business owners navigating Argentina’s economic landscape.",
    testimonials_title: "Trusted voices from Buenos Aires",
    form_title: "Получить бесплатный пробный урок",
    form_subtitle: "Secure your free discovery lesson and receive our double opt-in confirmation email.",
    form_name: "Full Name",
    form_email: "Email",
    form_confirm_email: "Confirm Email",
    form_role: "How do you plan to use the insights?",
    form_role_option1: "Personal budgeting",
    form_role_option2: "Business strategy",
    form_role_option3: "Academic research",
    form_role_option4: "Family planning",
    form_privacy_label:
      "I agree to Tu Progreso Hoy contacting me and understand a confirmation email will be required.",
    form_submit: "Reserve my seat",
    form_success: "Submission successful. Redirecting...",
    form_error: "Please ensure all fields are valid.",
    disclaimer_title: "Disclaimer",
    disclaimer_message_ru: "Мы не предоставляем финансовые услуги.",
    disclaimer_message_en: "We do not provide financial services.",
    disclaimer_message_es: "No brindamos servicios financieros.",
    disclaimer_ack: "Understood",
    cookie_message: "We use analytical cookies to improve your bilingual learning experience.",
    cookie_accept: "Accept",
    cookie_decline: "Decline",
    dark_mode: "Dark mode",
    breadcrumbs_home: "Home",
    resources_title: "Resources & Glossaries",
    resources_intro:
      "Curated bilingual articles, case studies, and definitions to empower your financial literacy journey in Argentina.",
    contact_title: "Let’s plan your progress",
    contact_address: "Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina",
    contact_phone_label: "Phone",
    contact_email_label: "Email",
    contact_social_title: "Connect with us",
    contact_form_title: "Book a consultation",
    contact_email_placeholder: "Your email",
    contact_message_placeholder: "Share your goals",
    contact_submit: "Send message",
    faq_title: "Frequently Asked Questions",
    thankyou_title: "¡Gracias! / Thank you!",
    thankyou_message:
      "Please confirm your subscription via the email we just sent. Your free lesson access will follow immediately after confirmation.",
    privacy_title: "Privacy Policy",
    terms_title: "Terms of Service",
    cookies_title: "Cookie Policy",
    notfound_title: "Page not found",
    back_home: "Back to Home",
    lang_en: "English",
    lang_es: "Español",
    hreflang_en: "en",
    hreflang_es: "es-AR"
  },
  es: {
    nav_home: "Inicio",
    nav_inflation: "Laboratorio de Inflación",
    nav_course: "Programa",
    nav_resources: "Recursos",
    nav_contact: "Contacto",
    hero_title: "Tu Progreso Hoy: Domina la inflación argentina",
    hero_subtitle:
      "Datos verificados, insights bilingües y herramientas accionables para navegar la inflación argentina. Datos verificados para planificar tu presupuesto.",
    hero_cta: "Получить бесплатный пробный урок",
    hero_secondary: "Explorar metodología",
    promises_title: "Por qué Argentina confía en Tu Progreso Hoy",
    promise_1_title: "Monitoreo ARS → USD en tiempo real",
    promise_1_desc:
      "Seguimiento del tipo de cambio con contexto del IPC diseñado para residentes de Buenos Aires.",
    promise_2_title: "Aprendizaje basado en escenarios",
    promise_2_desc:
      "Módulos interactivos que ayudan a familias y negocios a modelar gastos y proteger su poder adquisitivo.",
    promise_3_title: "Soporte bilingüe",
    promise_3_desc: "Contenido y facilitadores en English y Español para equipos multinacionales.",
    tracker_title: "Seguidor en vivo ARS → USD",
    tracker_updated: "Última actualización",
    tracker_rate: "ARS por USD",
    tracker_change_daily: "Variación diaria",
    tracker_insight: "Volatilidad 7 días",
    insights_title: "Insights inflacionarios para planificar mejor",
    insights_subtitle:
      "Anticipate con comentarios curados, proyecciones de IPC y referencias mensuales de gasto para Argentina.",
    course_overview_title: "Resumen del curso",
    course_overview_desc:
      "Un plan híbrido pensado para profesionales, familias y emprendedores que navegan la economía argentina.",
    testimonials_title: "Voces confiables desde Buenos Aires",
    form_title: "Получить бесплатный пробный урок",
    form_subtitle:
      "Asegura tu clase de descubrimiento gratuita y recibe nuestro correo de doble opt-in para confirmar.",
    form_name: "Nombre completo",
    form_email: "Correo",
    form_confirm_email: "Confirma tu correo",
    form_role: "¿Cómo aplicarás los insights?",
    form_role_option1: "Presupuesto personal",
    form_role_option2: "Estrategia de negocio",
    form_role_option3: "Investigación académica",
    form_role_option4: "Planificación familiar",
    form_privacy_label:
      "Acepto que Tu Progreso Hoy me contacte y entiendo que se requerirá confirmar por correo.",
    form_submit: "Reservar mi lugar",
    form_success: "Envío exitoso. Redirigiendo...",
    form_error: "Por favor revisa los campos obligatorios.",
    disclaimer_title: "Aviso Legal",
    disclaimer_message_ru: "Мы не предоставляем финансовые услуги.",
    disclaimer_message_en: "We do not provide financial services.",
    disclaimer_message_es: "No brindamos servicios financieros.",
    disclaimer_ack: "Entendido",
    cookie_message: "Utilizamos cookies analíticas para mejorar tu experiencia bilingüe.",
    cookie_accept: "Aceptar",
    cookie_decline: "Rechazar",
    dark_mode: "Modo oscuro",
    breadcrumbs_home: "Inicio",
    resources_title: "Recursos y glosarios",
    resources_intro:
      "Artículos bilingües, casos y definiciones seleccionadas para impulsar tu alfabetización financiera en Argentina.",
    contact_title: "Planifiquemos tu progreso",
    contact_address: "Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina",
    contact_phone_label: "Teléfono",
    contact_email_label: "Correo",
    contact_social_title: "Conecta con nosotros",
    contact_form_title: "Agenda una consulta",
    contact_email_placeholder: "Tu correo",
    contact_message_placeholder: "Comparte tus objetivos",
    contact_submit: "Enviar mensaje",
    faq_title: "Preguntas frecuentes",
    thankyou_title: "¡Gracias! / Thank you!",
    thankyou_message:
      "Por favor confirma tu suscripción en el correo que te enviamos. Accederás a la clase gratuita después de confirmar.",
    privacy_title: "Política de Privacidad",
    terms_title: "Términos de Servicio",
    cookies_title: "Política de Cookies",
    notfound_title: "Página no encontrada",
    back_home: "Volver al inicio",
    lang_en: "English",
    lang_es: "Español",
    hreflang_en: "en",
    hreflang_es: "es-AR"
  }
};

export const contactInfo = {
  address: "Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina",
  phone: "+54 11 5555-1234",
  email: "contacto@tuprogresohoy.com",
  socials: [
    { name: "LinkedIn", url: "https://www.linkedin.com/company/tu-progreso-hoy" },
    { name: "YouTube", url: "https://www.youtube.com/@tuprogresohoy" },
    { name: "Instagram", url: "https://www.instagram.com/tuprogresohoy" }
  ]
};

export const courseModules = [
  {
    id: 1,
    titleEn: "Module 1: Inflation Fundamentals",
    titleEs: "Módulo 1: Fundamentos de la inflación",
    descriptionEn:
      "Understand Argentina’s monetary history, key policy shifts, and how CPI is calculated across provinces.",
    descriptionEs:
      "Comprende la historia monetaria argentina, los cambios de política y cómo se calcula el IPC en las provincias.",
    duration: "90 min",
    format: "Live workshop + Toolkit"
  },
  {
    id: 2,
    titleEn: "Module 2: ARS Liquidity Strategies",
    titleEs: "Módulo 2: Estrategias de liquidez en ARS",
    descriptionEn:
      "Design cash flow buffers, analyze savings instruments, and build currency conversion checkpoints.",
    descriptionEs:
      "Diseña colchones de flujo de caja, analiza instrumentos de ahorro y construye controles de conversión.",
    duration: "120 min",
    format: "Case study + Templates"
  },
  {
    id: 3,
    titleEn: "Module 3: Scenario Modeling",
    titleEs: "Módulo 3: Modelado de escenarios",
    descriptionEn:
      "Simulate inflation trajectories, dollar-linked expenses, and family budgets with interactive worksheets.",
    descriptionEs:
      "Simula trayectorias inflacionarias, gastos dolarizados y presupuestos familiares con hojas interactivas.",
    duration: "100 min",
    format: "Interactive lab"
  },
  {
    id: 4,
    titleEn: "Module 4: Decision Playbooks",
    titleEs: "Módulo 4: Playbooks de decisiones",
    descriptionEn:
      "Turn insights into action with checklists for renegotiating contracts, planning purchases, and communicating with teams.",
    descriptionEs:
      "Convierte insights en acción con checklists para renegociar contratos, planificar compras y comunicar a equipos.",
    duration: "110 min",
    format: "Playbook library"
  }
];

export const faqItems = [
  {
    questionEn: "Is Tu Progreso Hoy a financial advisory service?",
    answerEn:
      "Tu Progreso Hoy is an educational platform. We provide data, frameworks, and workshops so you can make informed decisions, but we do not deliver regulated financial advisory services.",
    questionEs: "¿Tu Progreso Hoy brinda asesoramiento financiero?",
    answerEs:
      "Tu Progreso Hoy es una plataforma educativa. Ofrecemos datos, marcos y talleres para que tomes decisiones informadas, pero no brindamos servicios financieros regulados."
  },
  {
    questionEn: "How often is the ARS → USD tracker refreshed?",
    answerEn:
      "We refresh FX and CPI data multiple times per day using reputable public APIs and curated local sources to keep Argentines informed.",
    questionEs: "¿Con qué frecuencia se actualiza el seguidor ARS → USD?",
    answerEs:
      "Actualizamos datos cambiarios y de IPC varias veces al día utilizando APIs públicas confiables y fuentes locales curadas."
  },
  {
    questionEn: "Do you offer corporate training?",
    answerEn:
      "Yes. We facilitate bilingual workshops tailored for leadership teams, HR departments, and multinational organizations operating in Argentina.",
    questionEs: "¿Ofrecen capacitaciones corporativas?",
    answerEs:
      "Sí. Facilitamos talleres bilingües adaptados para directivos, áreas de RR. HH. y organizaciones multinacionales que operan en Argentina."
  },
  {
    questionEn: "What is the double opt-in process?",
    answerEn:
      "After submitting the form you will receive an email requiring confirmation. Only after confirming will you receive lesson materials and scheduling links.",
    questionEs: "¿Cómo funciona el doble opt-in?",
    answerEs:
      "Tras enviar el formulario recibirás un correo para confirmar. Solo después de confirmar recibirás los materiales y los enlaces de agenda."
  }
];

export const insightsCards = [
  {
    id: "insight-1",
    titleEn: "Monthly CPI Heatmap",
    titleEs: "Mapa de calor del IPC mensual",
    descriptionEn:
      "Compare Buenos Aires CPI versus Patagonia to understand regional acceleration and plan relocations.",
    descriptionEs:
      "Compara el IPC de Buenos Aires con Patagonia para detectar aceleraciones regionales y planificar relocalizaciones.",
    metric: "+6.7% m/m",
    trend: "up"
  },
  {
    id: "insight-2",
    titleEn: "Food Basket Outlook",
    titleEs: "Perspectiva canasta alimentaria",
    descriptionEn:
      "Monitor essential food basket variation to negotiate supplier contracts and align household budgets.",
    descriptionEs:
      "Monitorea la variación de la canasta alimentaria para negociar proveedores y alinear presupuestos.",
    metric: "ARS 89.400",
    trend: "stable"
  },
  {
    id: "insight-3",
    titleEn: "FX Trigger Alerts",
    titleEs: "Alertas de gatillos cambiarios",
    descriptionEn:
      "Set actionable thresholds for blue-chip swap spreads to optimize timing on currency conversions.",
    descriptionEs:
      "Configura umbrales accionables para spreads del CCL y optimiza el momento de las conversiones.",
    metric: "Alert at 2.3%",
    trend: "up"
  }
];

export const testimonials = [
  {
    name: "María Fernanda López",
    role: "Head of People, Start-up Palermo",
    quoteEn:
      "The simulations helped our team budget salaries in ARS while reporting in USD. We now meet board expectations with confidence.",
    quoteEs:
      "Las simulaciones ayudaron a nuestro equipo a presupuestar salarios en ARS mientras reportamos en USD. Ahora cumplimos expectativas del directorio con confianza.",
    image:
      "https://images.pexels.com/photos/3184357/pexels-photo-3184357.jpeg?auto=compress&cs=tinysrgb&w=600",
    alt: "Team leader smiling in modern office / Líder de equipo sonriendo en oficina moderna"
  },
  {
    name: "Julián Rodríguez",
    role: "Family Business Owner, San Isidro",
    quoteEn:
      "Tu Progreso Hoy gave us clarity on how to price services and plan imports despite volatile exchange rates.",
    quoteEs:
      "Tu Progreso Hoy nos dio claridad para fijar precios y planificar importaciones pese a la volatilidad cambiaria.",
    image:
      "https://images.pexels.com/photos/4427610/pexels-photo-4427610.jpeg?auto=compress&cs=tinysrgb&w=600",
    alt: "Entrepreneur planning finances / Emprendedor planificando finanzas"
  },
  {
    name: "Luciana Méndez",
    role: "University Lecturer, Belgrano",
    quoteEn:
      "The bilingual resources help my students connect macro theory with daily realities. It’s become required reading.",
    quoteEs:
      "Los recursos bilingües ayudan a mis alumnos a conectar teoría macro con realidades diarias. Ya es material obligatorio.",
    image:
      "https://images.pexels.com/photos/3321799/pexels-photo-3321799.jpeg?auto=compress&cs=tinysrgb&w=600",
    alt: "Professor teaching class / Profesora dictando clase"
  }
];

export const resourcesList = [
  {
    id: "resource-1",
    titleEn: "Guide: Negotiating Salaries Against Inflation",
    titleEs: "Guía: Negociar salarios frente a la inflación",
    descriptionEn:
      "A bilingual briefing for HR teams covering CPI clauses, mid-year adjustments, and internal communications.",
    descriptionEs:
      "Informe bilingüe para RR. HH. sobre cláusulas de IPC, ajustes semestrales y comunicación interna.",
    url: "#",
    date: "2024-03-02"
  },
  {
    id: "resource-2",
    titleEn: "Glossary: Argentina FX Landscape",
    titleEs: "Glosario: Panorama cambiario argentino",
    descriptionEn:
      "Understand the terminology behind MEP, CCL, blue dollar, and official rates with practical examples.",
    descriptionEs:
      "Comprende la terminología detrás del MEP, CCL, dólar blue y oficial con ejemplos prácticos.",
    url: "#",
    date: "2024-02-18"
  },
  {
    id: "resource-3",
    titleEn: "Playbook: Family Budget Scenarios",
    titleEs: "Playbook: Escenarios de presupuesto familiar",
    descriptionEn:
      "Step-by-step workbook to stress test groceries, education, and mobility costs under different CPI paths.",
    descriptionEs:
      "Manual paso a paso para stress test de gastos en alimentos, educación y movilidad bajo distintos IPC.",
    url: "#",
    date: "2024-01-26"
  }
];

export const methodologyPoints = [
  {
    titleEn: "Verified multi-source datasets",
    titleEs: "Datasets multisource verificados",
    descriptionEn:
      "We connect with Instituto Nacional de Estadística y Censos, BCRA releases, and reputable open data projects to triangulate CPI figures.",
    descriptionEs:
      "Nos conectamos con INDEC, publicaciones del BCRA y proyectos open data para triangular cifras de IPC."
  },
  {
    titleEn: "Contextual storytelling",
    titleEs: "Storytelling contextual",
    descriptionEn:
      "Visual narratives and bilingual summaries transform complex inflation trends into actionable insights.",
    descriptionEs:
      "Relatos visuales y resúmenes bilingües transforman tendencias complejas en insights accionables."
  },
  {
    titleEn: "Community validation",
    titleEs: "Validación comunitaria",
    descriptionEn:
      "We evaluate data with local economists, educators, and business owners to ensure practicality and cultural relevance.",
    descriptionEs:
      "Evaluamos datos con economistas, educadores y empresarios locales para asegurar practicidad y relevancia."
  }
];