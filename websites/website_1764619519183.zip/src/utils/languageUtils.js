export const hreflangLinks = [
  { hrefLang: "en", href: "https://www.tuprogresohoy.com/" },
  { hrefLang: "es-AR", href: "https://www.tuprogresohoy.com/es" }
];

export const getPageTitle = (base, language) =>
  language === "es" ? `${base} | Tu Progreso Hoy` : `${base} | Tu Progreso Hoy`;