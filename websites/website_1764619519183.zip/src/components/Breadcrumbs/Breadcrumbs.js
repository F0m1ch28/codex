import React from "react";
import { Link } from "react-router-dom";
import "./Breadcrumbs.css";
import { useLanguage } from "../../context/LanguageContext";

const Breadcrumbs = ({ items }) => {
  const { t } = useLanguage();

  return (
    <nav className="breadcrumbs" aria-label="Breadcrumb">
      <Link to="/" className="breadcrumbs__link">
        {t("breadcrumbs_home")}
      </Link>
      {items.map((item) => (
        <span key={item.label} className="breadcrumbs__item">
          <span className="breadcrumbs__separator">/</span>
          {item.url ? (
            <Link to={item.url} className="breadcrumbs__link">
              {item.label}
            </Link>
          ) : (
            <span className="breadcrumbs__current">{item.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
};

export default Breadcrumbs;