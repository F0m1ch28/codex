import React from "react";
import "./Section.css";

const Section = ({ id, title, subtitle, children, background = "default" }) => {
  return (
    <section id={id} className={`section section--${background}`}>
      <div className="section__header">
        {title && <h2 className="section__title">{title}</h2>}
        {subtitle && <p className="section__subtitle">{subtitle}</p>}
      </div>
      <div className="section__content">{children}</div>
    </section>
  );
};

export default Section;