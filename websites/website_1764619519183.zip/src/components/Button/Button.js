import React from "react";
import { motion } from "framer-motion";
import "./Button.css";

const Button = ({ children, variant = "primary", animated = false, ...props }) => {
  if (animated) {
    return (
      <motion.button
        whileHover={{ scale: 1.04 }}
        whileTap={{ scale: 0.98 }}
        className={`button button--${variant}`}
        {...props}
      >
        {children}
      </motion.button>
    );
  }

  return (
    <button className={`button button--${variant}`} {...props}>
      {children}
    </button>
  );
};

export default Button;