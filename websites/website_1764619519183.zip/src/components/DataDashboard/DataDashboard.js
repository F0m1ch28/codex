import React, { useEffect, useMemo, useState } from "react";
import { ResponsiveContainer, AreaChart, Area, Tooltip, CartesianGrid, XAxis, YAxis } from "recharts";
import { motion } from "framer-motion";
import LoadingSkeleton from "../LoadingSkeleton/LoadingSkeleton";
import "./DataDashboard.css";

const API_URL = "https://api.exchangerate.host";

const DataDashboard = ({ title, updatedLabel, rateLabel, changeLabel, insightLabel }) => {
  const [data, setData] = useState([]);
  const [rate, setRate] = useState(null);
  const [change, setChange] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const controller = new AbortController();
    async function fetchRates() {
      try {
        setLoading(true);
        const end = new Date();
        const start = new Date();
        start.setDate(end.getDate() - 7);
        const format = (d) => d.toISOString().split("T")[0];

        const url = `${API_URL}/timeseries?base=ARS&symbols=USD&start_date=${format(start)}&end_date=${format(
          end
        )}&amount=1`;
        const res = await fetch(url, { signal: controller.signal });
        if (!res.ok) throw new Error("Network error");
        const json = await res.json();

        if (json.rates) {
          const formatted = Object.entries(json.rates).map(([date, value]) => ({
            date,
            value: Number(value.USD.toFixed(6))
          }));
          const sorted = formatted.sort((a, b) => new Date(a.date) - new Date(b.date));
          setData(sorted);
          const last = sorted[sorted.length - 1];
          const prev = sorted[sorted.length - 2] || last;
          setRate(1 / last.value);
          setChange((( (1 / last.value) - (1 / prev.value)) / (1 / prev.value)) * 100);
        }
        setError("");
      } catch (err) {
        if (err.name !== "AbortError") {
          setError("Unable to load ARS → USD data right now.");
        }
      } finally {
        setLoading(false);
      }
    }
    fetchRates();
    const interval = setInterval(fetchRates, 1000 * 60 * 15);
    return () => {
      controller.abort();
      clearInterval(interval);
    };
  }, []);

  const chartData = useMemo(
    () =>
      data.map((item) => ({
        name: new Date(item.date).toLocaleDateString("es-AR", { month: "short", day: "numeric" }),
        arsPerUsd: Number((1 / item.value).toFixed(2))
      })),
    [data]
  );

  return (
    <motion.div
      className="dashboard"
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="dashboard__header">
        <h3 className="dashboard__title">{title}</h3>
        <span className="dashboard__timestamp">
          {updatedLabel}: {new Date().toLocaleString("es-AR")}
        </span>
      </div>
      {loading ? (
        <LoadingSkeleton height={260} />
      ) : error ? (
        <div role="alert" className="dashboard__error">
          {error}
        </div>
      ) : (
        <div className="dashboard__grid">
          <div className="dashboard__metric">
            <span className="dashboard__label">{rateLabel}</span>
            <strong className="dashboard__value">{rate ? rate.toFixed(2) : "--"}</strong>
          </div>
          <div className={`dashboard__metric ${change >= 0 ? "dashboard__metric--up" : "dashboard__metric--down"}`}>
            <span className="dashboard__label">{changeLabel}</span>
            <strong className="dashboard__value">
              {change ? `${change >= 0 ? "+" : ""}${change.toFixed(2)}%` : "--"}
            </strong>
          </div>
          <div className="dashboard__chart">
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="rgba(37, 99, 235, 0.8)" />
                    <stop offset="75%" stopColor="rgba(31, 58, 111, 0.05)" />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.3)" />
                <XAxis dataKey="name" stroke="rgba(15, 23, 42, 0.45)" />
                <YAxis stroke="rgba(15, 23, 42, 0.45)" domain={["dataMin", "dataMax"]} />
                <Tooltip
                  formatter={(value) => [`${value} ARS`, "ARS/USD"]}
                  contentStyle={{ borderRadius: 16 }}
                />
                <Area
                  type="monotone"
                  dataKey="arsPerUsd"
                  stroke="rgba(37, 99, 235, 1)"
                  strokeWidth={3}
                  fill="url(#colorRate)"
                  activeDot={{ r: 6 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
      <div className="dashboard__insight" aria-live="polite">
        <span className="dashboard__label">{insightLabel}</span>
        <p className="dashboard__insight-text">
          {chartData.length > 0
            ? `The highest rate this week was ${Math.max(...chartData.map((item) => item.arsPerUsd)).toFixed(
                2
              )} ARS per USD. The lowest reached ${Math.min(...chartData.map((item) => item.arsPerUsd)).toFixed(
                2
              )}.`
            : "Awaiting data to calculate weekly range."}
        </p>
      </div>
    </motion.div>
  );
};

export default DataDashboard;