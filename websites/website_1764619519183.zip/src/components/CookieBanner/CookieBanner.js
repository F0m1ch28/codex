import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "../../context/LanguageContext";
import Button from "../Button/Button";
import "./CookieBanner.css";

const CookieBanner = () => {
  const { t } = useLanguage();
  const [visible, setVisible] = useState(() => !localStorage.getItem("tph-cookies"));

  useEffect(() => {
    if (!visible) {
      document.body.classList.remove("cookie-banner-active");
    } else {
      document.body.classList.add("cookie-banner-active");
    }
  }, [visible]);

  const storeConsent = (choice) => {
    localStorage.setItem("tph-cookies", choice);
    setVisible(false);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.aside
          className="cookie"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 24 }}
          transition={{ duration: 0.3 }}
        >
          <p className="cookie__text">{t("cookie_message")}</p>
          <div className="cookie__actions">
            <Button variant="outline" onClick={() => storeConsent("decline")}>
              {t("cookie_decline")}
            </Button>
            <Button variant="primary" onClick={() => storeConsent("accept")}>
              {t("cookie_accept")}
            </Button>
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  );
};

export default CookieBanner;