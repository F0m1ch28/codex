import React from "react";
import Button from "../Button/Button";

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: "120px 24px", textAlign: "center" }}>
          <h1>We’re refreshing your insights.</h1>
          <p>Something went wrong. Please reload the page to continue planning with Tu Progreso Hoy.</p>
          <Button variant="primary" onClick={this.handleReload} animated>
            Reload
          </Button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;