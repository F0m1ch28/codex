import React from "react";
import { NavLink } from "react-router-dom";
import { useLanguage } from "../../context/LanguageContext";
import { contactInfo } from "../../utils/constants";
import "./Footer.css";

const Footer = () => {
  const { t } = useLanguage();

  return (
    <footer className="footer">
      <div className="footer__inner">
        <div className="footer__branding">
          <span className="footer__mark">TPH</span>
          <p className="footer__mission">
            Tu Progreso Hoy empowers Argentina with bilingual inflation education, data storytelling, and collaborative strategy workshops.
          </p>
          <p className="footer__contact">
            {contactInfo.address} · {t("contact_phone_label")}: {contactInfo.phone}
          </p>
        </div>
        <div className="footer__grid">
          <div className="footer__col">
            <h4 className="footer__title">Explore</h4>
            <NavLink to="/" className="footer__link">
              {t("nav_home")}
            </NavLink>
            <NavLink to="/inflation" className="footer__link">
              {t("nav_inflation")}
            </NavLink>
            <NavLink to="/course" className="footer__link">
              {t("nav_course")}
            </NavLink>
          </div>
          <div className="footer__col">
            <h4 className="footer__title">Legal</h4>
            <NavLink to="/privacy" className="footer__link">
              {t("privacy_title")}
            </NavLink>
            <NavLink to="/cookies" className="footer__link">
              {t("cookies_title")}
            </NavLink>
            <NavLink to="/terms" className="footer__link">
              {t("terms_title")}
            </NavLink>
          </div>
          <div className="footer__col">
            <h4 className="footer__title">{t("contact_social_title")}</h4>
            {contactInfo.socials.map((social) => (
              <a
                key={social.name}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="footer__link"
              >
                {social.name}
              </a>
            ))}
            <NavLink to="/contact" className="footer__link footer__link--cta">
              {t("contact_title")}
            </NavLink>
          </div>
        </div>
      </div>
      <div className="footer__lower">
        <span>© {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.</span>
        <a href="mailto:contacto@tuprogresohoy.com" className="footer__email">
          contacto@tuprogresohoy.com
        </a>
      </div>
    </footer>
  );
};

export default Footer;