import React, { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useLanguage } from "../../context/LanguageContext";
import Button from "../Button/Button";
import "./DisclaimerModal.css";

const DisclaimerModal = () => {
  const { t } = useLanguage();
  const [visible, setVisible] = useState(() => !sessionStorage.getItem("tph-disclaimer"));

  useEffect(() => {
    if (visible) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
  }, [visible]);

  const closeModal = () => {
    sessionStorage.setItem("tph-disclaimer", "acknowledged");
    setVisible(false);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="disclaimer"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          role="dialog"
          aria-modal="true"
        >
          <motion.div
            className="disclaimer__content"
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.94, opacity: 0 }}
          >
            <h3 className="disclaimer__title">{t("disclaimer_title")}</h3>
            <p className="disclaimer__line">{t("disclaimer_message_ru")}</p>
            <p className="disclaimer__line">{t("disclaimer_message_en")}</p>
            <p className="disclaimer__line">{t("disclaimer_message_es")}</p>
            <Button variant="primary" onClick={closeModal} animated>
              {t("disclaimer_ack")}
            </Button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default DisclaimerModal;