import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import Button from "../Button/Button";
import { useLanguage } from "../../context/LanguageContext";
import "./SubscriptionForm.css";

const SubscriptionForm = () => {
  const { t } = useLanguage();
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isSubmitSuccessful, isSubmitting }
  } = useForm();
  const navigate = useNavigate();

  const onSubmit = (data) => {
    if (data.email !== data.confirmEmail) {
      return;
    }
    setTimeout(() => {
      navigate("/thank-you");
    }, 1200);
  };

  const email = watch("email");
  const confirmEmail = watch("confirmEmail");

  useEffect(() => {
    if (isSubmitSuccessful) {
      // Additional logic if needed
    }
  }, [isSubmitSuccessful]);

  return (
    <form className="subscription" onSubmit={handleSubmit(onSubmit)} noValidate aria-live="polite">
      <h3 className="subscription__title">{t("form_title")}</h3>
      <p className="subscription__subtitle">{t("form_subtitle")}</p>

      <label className="subscription__label">
        {t("form_name")}
        <input
          type="text"
          {...register("name", { required: true, minLength: 3 })}
          className={`subscription__input ${errors.name ? "subscription__input--error" : ""}`}
          placeholder="María Pérez"
        />
        {errors.name && <span className="subscription__error">{t("form_error")}</span>}
      </label>

      <label className="subscription__label">
        {t("form_email")}
        <input
          type="email"
          {...register("email", { required: true })}
          className={`subscription__input ${errors.email ? "subscription__input--error" : ""}`}
          placeholder="maria@email.com"
        />
        {errors.email && <span className="subscription__error">{t("form_error")}</span>}
      </label>

      <label className="subscription__label">
        {t("form_confirm_email")}
        <input
          type="email"
          {...register("confirmEmail", { required: true })}
          className={`subscription__input ${
            errors.confirmEmail || (confirmEmail && confirmEmail !== email) ? "subscription__input--error" : ""
          }`}
          placeholder="Confirm email"
        />
        {confirmEmail && confirmEmail !== email && (
          <span className="subscription__error">{t("form_error")}</span>
        )}
      </label>

      <label className="subscription__label">
        {t("form_role")}
        <select
          {...register("role", { required: true })}
          className={`subscription__input ${errors.role ? "subscription__input--error" : ""}`}
        >
          <option value="">{t("form_role")}</option>
          <option value="personal">{t("form_role_option1")}</option>
          <option value="business">{t("form_role_option2")}</option>
          <option value="academic">{t("form_role_option3")}</option>
          <option value="family">{t("form_role_option4")}</option>
        </select>
        {errors.role && <span className="subscription__error">{t("form_error")}</span>}
      </label>

      <label className="subscription__checkbox">
        <input type="checkbox" {...register("consent", { required: true })} />
        <span>{t("form_privacy_label")}</span>
      </label>
      {errors.consent && <span className="subscription__error">{t("form_error")}</span>}

      <Button variant="primary" type="submit" animated disabled={isSubmitting}>
        {isSubmitting ? t("form_success") : t("form_submit")}
      </Button>
    </form>
  );
};

export default SubscriptionForm;