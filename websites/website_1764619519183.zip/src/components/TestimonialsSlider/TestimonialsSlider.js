import React, { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { testimonials } from "../../utils/constants";
import { useLanguage } from "../../context/LanguageContext";
import "./TestimonialsSlider.css";

const TestimonialsSlider = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const { language } = useLanguage();

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="testimonials" role="region" aria-label="Testimonials">
      <AnimatePresence mode="wait">
        {testimonials.map(
          (testimonial, index) =>
            index === activeIndex && (
              <motion.article
                key={testimonial.name}
                className="testimonial-card"
                initial={{ opacity: 0, x: 40 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -40 }}
                transition={{ duration: 0.45 }}
              >
                <img
                  src={`${testimonial.image}&auto=format&fit=crop&w=600&q=80`}
                  alt={testimonial.alt}
                  className="testimonial-card__image"
                  loading="lazy"
                />
                <blockquote className="testimonial-card__quote">
                  “{language === "es" ? testimonial.quoteEs : testimonial.quoteEn}”
                </blockquote>
                <p className="testimonial-card__name">{testimonial.name}</p>
                <span className="testimonial-card__role">{testimonial.role}</span>
              </motion.article>
            )
        )}
      </AnimatePresence>
      <div className="testimonials__dots">
        {testimonials.map((_, index) => (
          <button
            key={index}
            type="button"
            className={`testimonials__dot ${index === activeIndex ? "testimonials__dot--active" : ""}`}
            onClick={() => setActiveIndex(index)}
            aria-label={`Show testimonial ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
};

export default TestimonialsSlider;