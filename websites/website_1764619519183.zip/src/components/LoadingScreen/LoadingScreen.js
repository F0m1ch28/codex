import React from "react";
import { motion } from "framer-motion";
import "./LoadingScreen.css";

const LoadingScreen = () => {
  return (
    <div className="loader" role="status" aria-live="polite">
      <motion.div
        className="loader__pulse"
        animate={{ scale: [1, 1.1, 1], opacity: [0.8, 1, 0.8] }}
        transition={{ repeat: Infinity, duration: 1.2 }}
      />
      <span className="loader__text">Tu Progreso Hoy</span>
    </div>
  );
};

export default LoadingScreen;