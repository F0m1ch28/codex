import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import "./Accordion.css";

const Accordion = ({ items, language }) => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className="accordion" role="tablist">
      {items.map((item, index) => {
        const isActive = index === activeIndex;
        const question = language === "es" ? item.questionEs : item.questionEn;
        const answer = language === "es" ? item.answerEs : item.answerEn;

        return (
          <div key={question} className={`accordion__item ${isActive ? "accordion__item--active" : ""}`}>
            <button
              className="accordion__trigger"
              onClick={() => setActiveIndex(isActive ? -1 : index)}
              aria-expanded={isActive}
              aria-controls={`accordion-panel-${index}`}
              id={`accordion-trigger-${index}`}
            >
              <span>{question}</span>
              <span className="accordion__icon">{isActive ? "–" : "+"}</span>
            </button>
            <AnimatePresence initial={false}>
              {isActive && (
                <motion.div
                  id={`accordion-panel-${index}`}
                  role="region"
                  aria-labelledby={`accordion-trigger-${index}`}
                  className="accordion__panel"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.25 }}
                >
                  <p>{answer}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
};

export default Accordion;