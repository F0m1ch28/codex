import React from "react";
import { motion } from "framer-motion";
import { useLanguage } from "../../context/LanguageContext";
import "./CourseModule.css";

const CourseModule = ({ module, index }) => {
  const { language } = useLanguage();
  const title = language === "es" ? module.titleEs : module.titleEn;
  const description = language === "es" ? module.descriptionEs : module.descriptionEn;

  return (
    <motion.article
      className="module-card"
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ delay: index * 0.08 }}
      whileHover={{ scale: 1.03 }}
    >
      <div className="module-card__badge">#{index + 1}</div>
      <h3 className="module-card__title">{title}</h3>
      <p className="module-card__description">{description}</p>
      <div className="module-card__meta">
        <span>{module.duration}</span>
        <span>{module.format}</span>
      </div>
    </motion.article>
  );
};

export default CourseModule;