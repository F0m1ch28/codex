import React from "react";
import "./LoadingSkeleton.css";

const LoadingSkeleton = ({ height = 200 }) => {
  return <div className="loading-skeleton skeleton" style={{ height }} />;
};

export default LoadingSkeleton;