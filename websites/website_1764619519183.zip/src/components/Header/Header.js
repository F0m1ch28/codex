import React, { useEffect, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "../../context/LanguageContext";
import { useTheme } from "../../context/ThemeContext";
import Button from "../Button/Button";
import "./Header.css";

const Header = () => {
  const { language, setLanguage, t } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  return (
    <header className="header" role="banner">
      <div className="header__inner">
        <NavLink to="/" className="header__logo" aria-label="Tu Progreso Hoy">
          <span className="header__logo-mark">TPH</span>
          <span className="header__logo-text">Tu Progreso Hoy</span>
        </NavLink>

        <nav className="header__nav" aria-label="Primary navigation">
          <NavLink to="/" className="header__link">
            {t("nav_home")}
          </NavLink>
          <NavLink to="/inflation" className="header__link">
            {t("nav_inflation")}
          </NavLink>
          <NavLink to="/course" className="header__link">
            {t("nav_course")}
          </NavLink>
          <NavLink to="/resources" className="header__link">
            {t("nav_resources")}
          </NavLink>
          <NavLink to="/contact" className="header__link">
            {t("nav_contact")}
          </NavLink>
        </nav>

        <div className="header__actions">
          <div className="header__language" role="group" aria-label="Language selector">
            <button
              type="button"
              className={`header__lang-btn ${language === "en" ? "header__lang-btn--active" : ""}`}
              onClick={() => setLanguage("en")}
            >
              EN
            </button>
            <button
              type="button"
              className={`header__lang-btn ${language === "es" ? "header__lang-btn--active" : ""}`}
              onClick={() => setLanguage("es")}
            >
              ES
            </button>
          </div>
          <button
            type="button"
            className="header__theme-toggle"
            onClick={toggleTheme}
            aria-pressed={theme === "dark"}
            aria-label={t("dark_mode")}
          >
            <span className="header__theme-icon" />
          </button>
          <NavLink to="/course" className="header__cta-link">
            <Button variant="primary" animated>
              {t("hero_cta")}
            </Button>
          </NavLink>
        </div>

        <button
          type="button"
          className={`header__hamburger ${menuOpen ? "header__hamburger--active" : ""}`}
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
        </button>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className="header__mobile"
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.25 }}
          >
            <nav className="header__mobile-nav" aria-label="Mobile navigation">
              <NavLink to="/" className="header__mobile-link">
                {t("nav_home")}
              </NavLink>
              <NavLink to="/inflation" className="header__mobile-link">
                {t("nav_inflation")}
              </NavLink>
              <NavLink to="/course" className="header__mobile-link">
                {t("nav_course")}
              </NavLink>
              <NavLink to="/resources" className="header__mobile-link">
                {t("nav_resources")}
              </NavLink>
              <NavLink to="/contact" className="header__mobile-link">
                {t("nav_contact")}
              </NavLink>
              <NavLink to="/course" className="header__mobile-link header__mobile-link--cta">
                {t("hero_cta")}
              </NavLink>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;