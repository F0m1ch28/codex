document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");
    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".accept-btn");
    const declineBtn = document.querySelector(".decline-btn");
    const contactForm = document.querySelector("#contactForm");
    const formMessage = document.querySelector("#formMessage");

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navLinks.classList.toggle("active");
        });

        navLinks.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navLinks.classList.remove("active");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    if (cookieBanner && acceptBtn && declineBtn) {
        const consent = localStorage.getItem("flowerCookieConsent");
        if (!consent) {
            cookieBanner.classList.add("is-visible");
        }

        acceptBtn.addEventListener("click", () => {
            localStorage.setItem("flowerCookieConsent", "accepted");
            cookieBanner.classList.remove("is-visible");
        });

        declineBtn.addEventListener("click", () => {
            localStorage.setItem("flowerCookieConsent", "declined");
            cookieBanner.classList.remove("is-visible");
        });
    }

    if (contactForm) {
        contactForm.addEventListener("submit", (event) => {
            if (formMessage) {
                formMessage.classList.remove("visible");
                formMessage.textContent = "";
            }

            const name = contactForm.querySelector("[name='name']");
            const email = contactForm.querySelector("[name='email']");
            const company = contactForm.querySelector("[name='company']");
            const volume = contactForm.querySelector("[name='volume']");
            const message = contactForm.querySelector("[name='message']");

            const errors = [];

            if (!name.value.trim()) {
                errors.push("Вкажіть ім'я контактної особи.");
            }

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email.value.trim())) {
                errors.push("Перевірте правильність електронної пошти.");
            }

            if (!company.value.trim()) {
                errors.push("Вкажіть назву компанії або ФОП.");
            }

            if (!volume.value) {
                errors.push("Оберіть орієнтовний обсяг замовлення.");
            }

            if (!message.value.trim() || message.value.trim().length < 20) {
                errors.push("Опишіть потреби детальніше (мінімум 20 символів).");
            }

            if (errors.length > 0) {
                event.preventDefault();
                if (formMessage) {
                    formMessage.innerHTML = errors.join("<br>");
                    formMessage.classList.add("visible");
                }
            }
        });
    }
});