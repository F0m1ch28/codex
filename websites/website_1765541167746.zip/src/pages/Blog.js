```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Blog.module.css';
import Seo from '../components/Seo';
import { blogPosts } from '../data/content';

function Blog() {
  return (
    <div className={styles.page}>
      <Seo
        title="Blog | Lingua Academy"
        description="Read language learning insights, cultural stories, and success case studies from Lingua Academy tutors and learners."
        keywords="language learning blog, Dutch culture, Lingua Academy articles"
      />

      <header className={styles.header}>
        <h1 className={styles.title}>Insights from our learning community</h1>
        <p>
          Fresh ideas every month to support your language practice, cultural integration,
          and professional growth across the Netherlands.
        </p>
      </header>

      <div className={styles.grid}>
        {blogPosts.map((post) => (
          <article key={post.slug} className={styles.card}>
            <img
              src={post.image}
              alt={`${post.title} cover art`}
              className={styles.image}
            />
            <div className={styles.content}>
              <span className={styles.meta}>
                {post.date} · {post.readTime}
              </span>
              <h2>{post.title}</h2>
              <p className={styles.excerpt}>{post.excerpt}</p>
              <Link to={`/blog/${post.slug}`} className={styles.readMore}>
                Continue reading →
              </Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

export default Blog;
```