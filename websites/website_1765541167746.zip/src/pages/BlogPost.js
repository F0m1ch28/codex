```javascript
import React from 'react';
import { Link, useParams } from 'react-router-dom';
import styles from './BlogPost.module.css';
import Seo from '../components/Seo';
import { blogPosts } from '../data/content';

function BlogPost() {
  const { slug } = useParams();
  const post = blogPosts.find((item) => item.slug === slug);

  if (!post) {
    return (
      <div className={styles.page}>
        <Seo title="Article not found | Lingua Academy" />
        <p>We couldn’t locate that article. Return to the blog for more insights.</p>
        <Link to="/blog" className={styles.backLink}>
          ← Back to blog
        </Link>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <Seo
        title={`${post.title} | Lingua Academy`}
        description={post.excerpt}
        keywords="language learning tips, Dutch culture, Lingua Academy blog"
      />

      <img
        src={post.image}
        alt={`${post.title} hero`}
        className={styles.heroImage}
      />
      <h1 className={styles.title}>{post.title}</h1>
      <div className={styles.meta}>
        <span>{post.date}</span>
        <span>{post.author}</span>
        <span>{post.readTime}</span>
      </div>

      {post.content.map((paragraph, index) => (
        <p key={index} className={styles.paragraph}>
          {paragraph}
        </p>
      ))}

      <aside className={styles.highlight}>
        Looking for a personalised roadmap? Our tutors are ready to help you implement
        these insights into your daily routine. Get in touch and we’ll match you with
        the right program.
      </aside>

      <Link to="/blog" className={styles.backLink}>
        ← Back to all articles
      </Link>
    </div>
  );
}

export default BlogPost;
```