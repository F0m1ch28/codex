```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './NotFound.module.css';
import Seo from '../components/Seo';

function NotFound() {
  return (
    <div className={styles.page}>
      <Seo title="Page not found | Lingua Academy" />
      <h1 className={styles.title}>Page not found</h1>
      <p className={styles.text}>
        The page you are looking for may have been updated or moved. Let’s guide you back to
        the heart of Lingua Academy.
      </p>
      <Link to="/" className={styles.link}>
        Back to homepage
      </Link>
    </div>
  );
}

export default NotFound;
```