```javascript
import React from 'react';
import styles from './CookiePolicy.module.css';
import Seo from '../components/Seo';

function CookiePolicy() {
  return (
    <div className={styles.page}>
      <Seo
        title="Cookie Policy | Lingua Academy"
        description="Cookie Policy describing the types of cookies Lingua Academy uses and how learners can manage preferences."
        keywords="cookie policy Lingua Academy"
      />

      <h1 className={styles.title}>Cookie Policy</h1>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>1. What are cookies?</h2>
        <p>
          Cookies are small text files placed on your device to improve your browsing
          experience. We use cookies to remember preferences, analyse usage, and support
          secure login sessions.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>2. Types of cookies we use</h2>
        <ul className={styles.list}>
          <li><strong>Essential cookies:</strong> Required for secure login and core functionality.</li>
          <li><strong>Analytics cookies:</strong> Help us understand how learners navigate our platform so we can enhance usability.</li>
          <li><strong>Preference cookies:</strong> Save your language and interface choices for a personalised experience.</li>
        </ul>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>3. Managing cookies</h2>
        <p>
          You can control cookies through your browser settings. Disabling essential cookies
          may affect certain features. Analytics cookies can be toggled in the cookie banner
          or by contacting us at info@lingua-academy.nl.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>4. Updates</h2>
        <p>
          We review our cookie policy annually. When changes occur, the banner will reappear to
          request your consent. For additional information, please consult our privacy policy.
        </p>
      </section>
    </div>
  );
}

export default CookiePolicy;
```