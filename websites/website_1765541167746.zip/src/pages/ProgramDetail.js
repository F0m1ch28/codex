```javascript
import React from 'react';
import { Link, useParams } from 'react-router-dom';
import styles from './ProgramDetail.module.css';
import Seo from '../components/Seo';
import { programs } from '../data/content';

function ProgramDetail() {
  const { slug } = useParams();
  const program = programs.find((item) => item.slug === slug);

  if (!program) {
    return (
      <div className={styles.page}>
        <Seo title="Program not found | Lingua Academy" />
        <p>We couldn’t find that program. Please return to the programs overview.</p>
        <Link to="/programs" className={styles.backLink}>
          ← Back to programs
        </Link>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <Seo
        title={`${program.title} | Lingua Academy`}
        description={program.description}
        keywords={`${program.title}, Lingua Academy program, language course Netherlands`}
      />

      <div className={styles.hero}>
        <img
          src={program.image}
          alt={`${program.title} learners`}
          className={styles.heroImage}
        />
      </div>

      <h1 className={styles.title}>{program.title}</h1>
      <p className={styles.tagline}>{program.description}</p>

      <div className={styles.metaBar}>
        <span>{program.level}</span>
        <span>{program.format}</span>
        <span>{program.schedule}</span>
      </div>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Program highlights</h2>
        <ul className={styles.list}>
          {program.highlights.map((item) => (
            <li key={item} className={styles.listItem}>
              <span className={styles.icon}>•</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>What you’ll achieve</h2>
        <ul className={styles.list}>
          {program.outcomes.map((item) => (
            <li key={item} className={styles.listItem}>
              <span className={styles.icon}>✓</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Who is this for?</h2>
        <p>{program.audience}</p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Learning resources</h2>
        <div className={styles.miniGrid}>
          {program.materials.map((material) => (
            <div key={material} className={styles.listItem}>
              <span className={styles.icon}>⟡</span>
              <span>{material}</span>
            </div>
          ))}
        </div>
      </section>

      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>Ready to join?</h2>
        <p>
          Share your goals with our learner experience team. We’ll confirm availability,
          introduce you to the tutor, and guide you through onboarding.
        </p>
        <div className={styles.cta}>
          <Link to="/contact" className={styles.ctaLink}>
            Start the conversation
          </Link>
          <Link to="/programs" className={styles.secondaryLink}>
            ← Back to all programs
          </Link>
        </div>
      </div>
    </div>
  );
}

export default ProgramDetail;
```