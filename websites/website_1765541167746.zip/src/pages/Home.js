```javascript
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';
import Seo from '../components/Seo';
import {
  programs,
  blogPosts,
  testimonials,
  stats,
  learningSteps,
  teamMembers,
  faqs
} from '../data/content';

const features = [
  {
    icon: '🎯',
    title: 'Professional Tutors',
    description:
      'Certified linguists and communication coaches craft inspiring sessions that mirror real-life situations in the Netherlands.'
  },
  {
    icon: '🕒',
    title: 'Flexible Schedules',
    description:
      'Mix evening, weekend, and on-demand learning so language practice fits harmoniously into your Dutch daily routine.'
  },
  {
    icon: '💬',
    title: 'Interactive Tools',
    description:
      'Access our immersive app, pronunciation studio, and cultural cheat sheets to continue learning between sessions.'
  },
  {
    icon: '🌍',
    title: 'Inclusive Community',
    description:
      'Join international learners and Dutch locals who openly share experiences, tips, and opportunities.'
  }
];

function Home() {
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeFaq, setActiveFaq] = useState(null);

  const handleNextTestimonial = () => {
    setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
  };

  const handlePrevTestimonial = () => {
    setTestimonialIndex((prev) =>
      prev === 0 ? testimonials.length - 1 : prev - 1
    );
  };

  const toggleFaq = (index) => {
    setActiveFaq((prev) => (prev === index ? null : index));
  };

  const testimonial = testimonials[testimonialIndex];

  return (
    <div className={styles.wrapper}>
      <Seo
        title="Lingua Academy | Language Courses in the Netherlands"
        description="Explore Lingua Academy’s inclusive language courses. Individual and group lessons led by expert tutors for learners across the Netherlands."
        keywords="language courses Netherlands, Dutch lessons, English tutors, Lingua Academy, group language classes, individual language coaching"
      />

      <section
        className={styles.hero}
        role="region"
        aria-label="Lingua Academy language courses"
      >
        <div className={styles.heroContent}>
          <h1 className={styles.heroTitle}>
            Language learning tailored to life in the Netherlands.
          </h1>
          <p className={styles.heroText}>
            Lingua Academy brings together professional tutors, immersive tools, and
            a supportive community so you can thrive in Dutch, English, and beyond.
            Learn at your pace with coaching designed around your goals.
          </p>
          <div className={styles.heroActions}>
            <Link to="/programs" className={styles.primaryButton}>
              Browse Our Courses
            </Link>
            <Link to="/guide" className={styles.secondaryButton}>
              See how the platform works
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>A clear mission for every learner</h2>
          <p className={styles.sectionSubtitle}>
            We believe language opens doors to friendships, careers, and cultural
            understanding. From onboarding to alumni celebrations, our team ensures
            your journey is intentional, inspiring, and rooted in Dutch realities.
          </p>
        </div>

        <div className={styles.missionCard}>
          <p>
            Whether you are joining a Dutch-speaking team, preparing for exams, or
            navigating daily life, Lingua Academy combines human expertise with smart
            technology. Your personalised plan evolves with you—keeping motivation high
            and momentum steady.
          </p>

          <div className={styles.statsGrid}>
            {stats.map((item) => (
              <div key={item.label} className={styles.statCard}>
                <span className={styles.statNumber}>{item.value}</span>
                <p className={styles.statLabel}>{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>Why learners choose Lingua Academy</h2>
          <p className={styles.sectionSubtitle}>
            Holistic support from day one—combining expert feedback, modern resources,
            and community accountability.
          </p>
        </div>

        <div className={styles.featuresGrid}>
          {features.map((feature) => (
            <div key={feature.title} className={styles.featureCard}>
              <div className={styles.featureIcon}>{feature.icon}</div>
              <h3 className={styles.featureTitle}>{feature.title}</h3>
              <p>{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="popular-programs-title">
        <div className={styles.sectionHeader}>
          <h2 id="popular-programs-title" className={styles.sectionTitle}>
            Popular programs this season
          </h2>
          <p className={styles.sectionSubtitle}>
            Explore a snapshot of our most-loved tracks. Each program has an extended
            page with schedules, highlights, and learner stories.
          </p>
        </div>
        <div className={styles.programsGrid}>
          {programs.slice(0, 3).map((program) => (
            <div key={program.slug} className={styles.programCard}>
              <img
                src={program.image}
                alt={`${program.title} learners practising together`}
                className={styles.programImage}
              />
              <div className={styles.programContent}>
                <h3 className={styles.programTitle}>{program.title}</h3>
                <div className={styles.programMeta}>
                  <span>{program.level}</span>
                  <span>{program.format}</span>
                </div>
                <p>{program.description.slice(0, 150)}...</p>
                <Link to={`/programs/${program.slug}`} className={styles.programLink}>
                  View program details →
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="learning-journey-title">
        <div className={styles.sectionHeader}>
          <h2 id="learning-journey-title" className={styles.sectionTitle}>
            Your Lingua learning journey
          </h2>
          <p className={styles.sectionSubtitle}>
            Our process is transparent and flexible. Together we design the rhythm
            that keeps you inspired every week.
          </p>
        </div>
        <div className={styles.processGrid}>
          {learningSteps.map((step, index) => (
            <div key={step.title} className={styles.processCard}>
              <span className={styles.processStep}>
                Step {index + 1 < 10 ? `0${index + 1}` : index + 1}
              </span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="testimonials-title">
        <div className={styles.testimonialSection}>
          <div className={styles.testimonialContent}>
            <h2 id="testimonials-title" className={styles.sectionTitle}>
              Voices of our learners
            </h2>
            <p className={styles.testimonialQuote} aria-live="polite">
              {testimonial.message}
            </p>
            <div>
              <p className={styles.testimonialAuthor}>{testimonial.name}</p>
              <p>{testimonial.role}</p>
            </div>
            <div className={styles.testimonialControls}>
              <button
                type="button"
                className={styles.controlButton}
                onClick={handlePrevTestimonial}
                aria-label="Previous testimonial"
              >
                ←
              </button>
              <button
                type="button"
                className={styles.controlButton}
                onClick={handleNextTestimonial}
                aria-label="Next testimonial"
              >
                →
              </button>
            </div>
          </div>
          <div aria-hidden="true">
            <img
              src={testimonial.image}
              alt=""
              className={styles.teamImage}
            />
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="team-title">
        <div className={styles.sectionHeader}>
          <h2 id="team-title" className={styles.sectionTitle}>
            Meet the team behind the lessons
          </h2>
          <p className={styles.sectionSubtitle}>
            A collective of linguists, coaches, and cultural strategists guiding
            learners from first conversation to advanced fluency.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <div key={member.name} className={styles.teamCard}>
              <img
                src={member.image}
                alt={`${member.name}, ${member.role}`}
                className={styles.teamImage}
              />
              <h3>{member.name}</h3>
              <p className={styles.teamRole}>{member.role}</p>
              <p className={styles.teamBio}>{member.bio}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="faq-title">
        <div className={styles.sectionHeader}>
          <h2 id="faq-title" className={styles.sectionTitle}>
            Frequently asked questions
          </h2>
          <p className={styles.sectionSubtitle}>
            Clarity is key. Here are the questions learners in the Netherlands ask most
            often when choosing their language journey.
          </p>
        </div>
        <div className={styles.faqGrid}>
          {faqs.map((faq, index) => (
            <div key={faq.question} className={styles.faqItem}>
              <button
                className={styles.faqQuestion}
                onClick={() => toggleFaq(index)}
                aria-expanded={activeFaq === index}
              >
                {faq.question}
                <span aria-hidden="true">{activeFaq === index ? '−' : '+'}</span>
              </button>
              {activeFaq === index && (
                <p className={styles.faqAnswer}>{faq.answer}</p>
              )}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="blog-title">
        <div className={styles.sectionHeader}>
          <h2 id="blog-title" className={styles.sectionTitle}>
            Latest from our blog
          </h2>
          <p className={styles.sectionSubtitle}>
            Insights from tutors and learners on language practice, culture, and
            success stories across the Netherlands.
          </p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.slice(0, 3).map((post) => (
            <article key={post.slug} className={styles.blogCard}>
              <img
                src={post.image}
                alt={`${post.title} cover`}
                className={styles.blogImage}
              />
              <div className={styles.blogContent}>
                <span className={styles.blogMeta}>
                  {post.date} · {post.readTime}
                </span>
                <h3 className={styles.blogTitle}>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={`/blog/${post.slug}`} className={styles.programLink}>
                  Read the story →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <h2 className={styles.ctaTitle}>Ready to design your language journey?</h2>
        <p className={styles.ctaText}>
          Book a welcome session with our learner experience team. Together we will map
          your goals, match you with the ideal tutor, and carve out a learning rhythm
          that energises you week after week.
        </p>
        <div className={styles.ctaActions}>
          <Link to="/contact" className={styles.ctaPrimary}>
            Connect with us
          </Link>
          <Link to="/programs" className={styles.ctaSecondary}>
            Explore all programs
          </Link>
        </div>
      </section>
    </div>
  );
}

export default Home;
```