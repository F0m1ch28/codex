```javascript
import React from 'react';
import styles from './Tools.module.css';
import Seo from '../components/Seo';
import { toolCollections, studyTips } from '../data/content';

function Tools() {
  return (
    <div className={styles.page}>
      <Seo
        title="Tools & Resources | Lingua Academy"
        description="Access curated language learning tools, playlists, pronunciation labs, and cultural guides created by Lingua Academy tutors."
        keywords="language learning tools, pronunciation practice, Lingua Academy resources"
      />

      <header className={styles.header}>
        <h1 className={styles.title}>Tools to keep your practice thriving</h1>
        <p>
          Learning a language is easier when everything you need is in one place. Explore
          our favourite resources, curated for learners living and working in the Netherlands.
        </p>
      </header>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Digital toolkit</h2>
        <div className={styles.cardGrid}>
          {toolCollections.map((tool) => (
            <article key={tool.name} className={styles.card}>
              <div className={styles.cardTag}>{tool.type}</div>
              <h3 className={styles.cardTitle}>{tool.name}</h3>
              <p>{tool.description}</p>
              <a
                href={tool.link}
                target="_blank"
                rel="noopener noreferrer"
                className={styles.resourceLink}
              >
                Access resource →
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Study rituals that work</h2>
        <ul className={styles.tipList}>
          {studyTips.map((tip) => (
            <li key={tip} className={styles.tipItem}>
              <span className={styles.icon}>✓</span>
              <span>{tip}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Community & immersion</h2>
        <p>
          Each month we host speaking clubs, cultural walks, and themed workshops in Amsterdam,
          Rotterdam, Utrecht, and The Hague. Keep an eye on your learner dashboard for sign-ups
          or follow us on LinkedIn for updates. These events are excellent opportunities to apply
          what you learn in lively, supportive settings.
        </p>
      </section>
    </div>
  );
}

export default Tools;
```