```javascript
import React from 'react';
import styles from './About.module.css';
import Seo from '../components/Seo';
import { teamMembers } from '../data/content';

const timeline = [
  {
    year: '2015',
    description:
      'Lingua Academy launched in Amsterdam with a small collective of linguists supporting expats settling into Dutch life.'
  },
  {
    year: '2018',
    description:
      'Introduced blended learning experiences combining live instruction with interactive digital tools, expanding to Utrecht and Rotterdam.'
  },
  {
    year: '2021',
    description:
      'Partnered with universities and companies to deliver bespoke programs, emphasising inclusion and cultural fluency.'
  },
  {
    year: '2023',
    description:
      'Launched the Lingua Academy app, enabling learners across the Netherlands to practise anytime with personalised pathways.'
  }
];

function About() {
  return (
    <div className={styles.page}>
      <Seo
        title="About Lingua Academy"
        description="Meet the Lingua Academy team and discover our teaching philosophy rooted in inclusivity, innovation, and real-world language practice."
        keywords="Lingua Academy tutors, language school Netherlands, about Lingua Academy"
      />

      <section className={styles.hero}>
        <div>
          <h1 className={styles.title}>A community built on language and belonging</h1>
          <p className={styles.text}>
            Lingua Academy was founded to bridge cultures through meaningful communication.
            Our programs are shaped by academic research, lived experience, and the belief
            that learning should feel empowering, not intimidating.
          </p>
        </div>
        <div className={styles.quote}>
          “We meet learners where they are—celebrating every accent, every question, and
          every milestone. Language opens doors, and we make sure those doors stay open.”
        </div>
      </section>

      <section className={styles.gridSection}>
        <div className={styles.card}>
          <h2 className={styles.cardTitle}>Our teaching philosophy</h2>
          <p>
            We combine communicative methodologies with coaching techniques. Lessons are
            dynamic, collaborative, and anchored in the Dutch contexts you encounter daily.
            Expect to analyse real conversations, practise authentic scenarios, and receive
            feedback that is supportive yet specific.
          </p>
        </div>

        <div className={styles.card}>
          <h2 className={styles.cardTitle}>How we work with learners</h2>
          <ul>
            <li>Co-create learning goals that adapt over time.</li>
            <li>Blend individual coaching, group labs, and immersive events.</li>
            <li>Keep feedback loops transparent and encouraging.</li>
            <li>Celebrate cultural diversity within every cohort.</li>
          </ul>
        </div>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Our journey through the years</h2>
        <div className={styles.timeline}>
          {timeline.map((item) => (
            <div key={item.year} className={styles.timelineItem}>
              <span className={styles.timelineYear}>{item.year}</span>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Meet the leadership team</h2>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <div key={member.name} className={styles.teamCard}>
              <img
                src={member.image}
                alt={`${member.name}, ${member.role}`}
                className={styles.teamImage}
              />
              <h3>{member.name}</h3>
              <p className={styles.role}>{member.role}</p>
              <p className={styles.bio}>{member.bio}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Committed to impact</h2>
        <p>
          Being based in the Netherlands means we are close to our learners. We invest in
          scholarships for newcomers, collaborate with municipalities on integration
          initiatives, and host inclusive events where Dutch and international communities
          connect through language.
        </p>
      </section>
    </div>
  );
}

export default About;
```