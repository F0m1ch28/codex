```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Programs.module.css';
import Seo from '../components/Seo';
import { programs } from '../data/content';

const filterTags = ['Individual Coaching', 'Group Learning', 'Corporate Training', 'Exam Preparation'];

function Programs() {
  return (
    <div className={styles.page}>
      <Seo
        title="Programs | Lingua Academy"
        description="Browse Lingua Academy language programs. Discover individual coaching, group lessons, and corporate training options designed for life in the Netherlands."
        keywords="Lingua Academy programs, Dutch course, English course, Netherlands language school"
      />

      <header className={styles.header}>
        <h1 className={styles.title}>Discover programs crafted for your journey</h1>
        <p className={styles.subtitle}>
          Every program blends expert coaching, interactive resources, and cultural context.
          Select the pathway that aligns with your goals—whether you’re starting from scratch
          or refining advanced skills.
        </p>
      </header>

      <div className={styles.filters} aria-label="Program categories">
        {filterTags.map((tag) => (
          <span key={tag} className={styles.filterTag}>
            {tag}
          </span>
        ))}
      </div>

      <div className={styles.grid}>
        {programs.map((program) => (
          <article key={program.slug} className={styles.card}>
            <img
              src={program.image}
              alt={`${program.title} session`}
              className={styles.image}
            />
            <div className={styles.content}>
              <div className={styles.meta}>
                <span className={styles.badge}>{program.category}</span>
                <span>{program.level}</span>
                <span>{program.format}</span>
              </div>
              <h2>{program.title}</h2>
              <p>{program.description}</p>
              <ul className={styles.list}>
                {program.highlights.slice(0, 3).map((highlight) => (
                  <li key={highlight}>• {highlight}</li>
                ))}
              </ul>
              <Link to={`/programs/${program.slug}`} className={styles.link}>
                View full program →
              </Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

export default Programs;
```