```javascript
import React from 'react';
import styles from './Terms.module.css';
import Seo from '../components/Seo';

function Terms() {
  return (
    <div className={styles.page}>
      <Seo
        title="Terms of Service | Lingua Academy"
        description="Terms of Service for Lingua Academy covering usage of our platform, learning resources, and community spaces."
        keywords="terms of service Lingua Academy"
      />

      <h1 className={styles.title}>Terms of Service</h1>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>1. Introduction</h2>
        <p>
          These Terms of Service govern your use of Lingua Academy platforms, programs, and
          community spaces. By accessing our services you agree to these terms and any updates
          communicated through the platform. Lingua Academy operates from Amsterdam,
          Netherlands and complies with Dutch and EU regulations.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>2. Learning experience</h2>
        <p>
          Programs are designed collaboratively between learners and tutors. We reserve the
          right to adjust schedules, tutors, or group composition to maintain a high-quality
          experience. Any significant changes will be communicated in advance.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>3. Account responsibilities</h2>
        <p>
          You are responsible for safeguarding your login credentials and using the platform
          respectfully. Sharing resources outside of your cohort without permission is not
          allowed. Please notify our team if you suspect any unauthorised access.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>4. Community conduct</h2>
        <p>
          Lingua Academy fosters an inclusive environment. We do not tolerate discrimination,
          harassment, or any behaviour that undermines the wellbeing of learners or staff.
          We reserve the right to suspend access if these values are not respected.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>5. Updates</h2>
        <p>
          We may update these terms periodically. When changes are significant, we will notify
          learners via email and dashboard announcements. Continued use of the platform after
          updates constitutes acceptance of the new terms.
        </p>
      </section>
    </div>
  );
}

export default Terms;
```