```javascript
import React from 'react';
import styles from './Privacy.module.css';
import Seo from '../components/Seo';

function Privacy() {
  return (
    <div className={styles.page}>
      <Seo
        title="Privacy Policy | Lingua Academy"
        description="Privacy Policy explaining how Lingua Academy collects, stores, and processes personal data in line with GDPR."
        keywords="privacy policy Lingua Academy, GDPR language school"
      />

      <h1 className={styles.title}>Privacy Policy</h1>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>1. Data controller</h2>
        <p>
          Lingua Academy B.V., based in Amsterdam, Netherlands, is the data controller of your
          personal information. We comply with the General Data Protection Regulation (GDPR).
          You can contact us at info@lingua-academy.nl for any privacy related questions.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>2. Data we collect</h2>
        <p>
          We collect contact details, learning preferences, and progress data to personalise
          your experience. When you participate in community events or surveys, we may record
          feedback to improve our services. Payment information is processed securely by our
          trusted providers; we do not store full card details on our servers.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>3. How data is used</h2>
        <p>
          Data helps us recommend programs, match you with tutors, and send learning updates.
          Aggregated insights support curriculum improvements and product development. We only
          share data with partners (such as tutors or certified examiners) necessary to deliver
          the service you request.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>4. Your rights</h2>
        <p>
          You have the right to access, correct, or delete your personal data. You can also
          request data portability or lodge a complaint with the Dutch Data Protection Authority.
          Contact us via email to exercise any of these rights; we respond within 30 days.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>5. Data retention</h2>
        <p>
          We store learner records for as long as you maintain an active account or as required
          by Dutch law. If you decide to leave Lingua Academy, you can request removal of your
          personal data, and we will process the request unless legal obligations require retention.
        </p>
      </section>
    </div>
  );
}

export default Privacy;
```