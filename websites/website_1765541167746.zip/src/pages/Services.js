```javascript
import React from 'react';
import styles from './Services.module.css';
import Seo from '../components/Seo';
import { servicePackages } from '../data/content';

function Services() {
  return (
    <div className={styles.page}>
      <Seo
        title="Services | Lingua Academy"
        description="Discover Lingua Academy services including individual coaching, group learning labs, and corporate partnerships tailored to the Netherlands."
        keywords="language services Netherlands, corporate language training, Lingua Academy services"
      />

      <header className={styles.header}>
        <h1 className={styles.title}>Services tailored to every learner profile</h1>
        <p>
          From one-on-one coaching to large-scale corporate partnerships, our services are
          designed to deliver meaningful language outcomes and cultural fluency.
        </p>
      </header>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Core service packages</h2>
        <div className={styles.packageGrid}>
          {servicePackages.map((pkg) => (
            <article key={pkg.title} className={styles.packageCard}>
              <span className={styles.packageTag}>{pkg.tag}</span>
              <h3 className={styles.packageTitle}>{pkg.title}</h3>
              <ul className={styles.list}>
                {pkg.points.map((point) => (
                  <li key={point} className={styles.listItem}>
                    <span className={styles.icon}>•</span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Additional support</h2>
        <p>
          We also offer onboarding workshops for relocating teams, exam coaching clinics,
          bespoke cultural trainings, and alumni practice spaces. Reach out via the contact
          form so we can tailor a package that matches your objectives.
        </p>
      </section>

      <aside className={styles.highlight}>
        Unsure which service fits best? Start with our <a href="/programs">Programs</a> or
        book a discovery call. We’ll craft a learning journey that fits your pace, context,
        and ambitions in the Netherlands.
      </aside>
    </div>
  );
}

export default Services;
```