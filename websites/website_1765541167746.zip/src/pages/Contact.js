```javascript
import React, { useState } from 'react';
import styles from './Contact.module.css';
import Seo from '../components/Seo';

const initialForm = {
  name: '',
  email: '',
  subject: '',
  message: ''
};

function Contact() {
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please share your name.';
    if (!formData.email.trim()) {
      newErrors.email = 'An email address helps us reply quickly.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!formData.subject.trim()) newErrors.subject = 'Let us know the topic of your message.';
    if (!formData.message.trim() || formData.message.trim().length < 20) {
      newErrors.message = 'Tell us a bit more (at least 20 characters).';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;

    setStatus('sending');
    setTimeout(() => {
      setStatus('success');
      setFormData(initialForm);
      setTimeout(() => setStatus('idle'), 4000);
    }, 800);
  };

  return (
    <div className={styles.page}>
      <Seo
        title="Contact Lingua Academy"
        description="Contact Lingua Academy to discuss language courses, corporate training, or personalised coaching in the Netherlands."
        keywords="contact Lingua Academy, language school Amsterdam contact, Dutch tutors contact"
      />

      <header className={styles.header}>
        <h1 className={styles.title}>Let’s plan your next language victory</h1>
        <p className={styles.subtext}>
          Share your ambitions, questions, or challenges. Our learner experience team replies
          within one business day.
        </p>
      </header>

      <div className={styles.content}>
        <div className={styles.formWrapper}>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <label htmlFor="name" className={styles.label}>
              Name
            </label>
            <input
              id="name"
              name="name"
              type="text"
              className={styles.input}
              value={formData.name}
              onChange={handleChange}
              placeholder="Your full name"
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}

            <label htmlFor="email" className={styles.label}>
              Email
            </label>
            <input
              id="email"
              name="email"
              type="email"
              className={styles.input}
              value={formData.email}
              onChange={handleChange}
              placeholder="you@example.com"
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}

            <label htmlFor="subject" className={styles.label}>
              Subject
            </label>
            <input
              id="subject"
              name="subject"
              type="text"
              className={styles.input}
              value={formData.subject}
              onChange={handleChange}
              placeholder="Which program or topic?"
            />
            {errors.subject && <span className={styles.error}>{errors.subject}</span>}

            <label htmlFor="message" className={styles.label}>
              Message
            </label>
            <textarea
              id="message"
              name="message"
              className={styles.textarea}
              value={formData.message}
              onChange={handleChange}
              placeholder="Tell us about your goals, preferred schedule, or organisation."
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}

            <button type="submit" className={styles.submitButton}>
              Send Message
            </button>

            <div className={styles.status} aria-live="polite">
              {status === 'sending' && 'Sending your message...'}
              {status === 'success' && (
                <span className={styles.success}>
                  Thank you! We’ll be in touch shortly.
                </span>
              )}
            </div>
          </form>
        </div>

        <div className={styles.infoCard}>
          <h2 className={styles.infoTitle}>Our contact details</h2>
          <div className={styles.infoItem}>
            <div className={styles.icon}>📍</div>
            <p className={styles.infoText}>Amsterdam, Netherlands</p>
          </div>
          <div className={styles.infoItem}>
            <div className={styles.icon}>☎️</div>
            <p className={styles.infoText}>+31 20 123 4567</p>
          </div>
          <div className={styles.infoItem}>
            <div className={styles.icon}>✉️</div>
            <p className={styles.infoText}>info@lingua-academy.nl</p>
          </div>
          <p className={styles.infoText}>
            Office hours: Monday to Friday, 09:00–18:00 CET. We offer virtual consultations
            for learners residing across the Netherlands.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Contact;
```