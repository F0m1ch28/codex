```javascript
import React from 'react';
import styles from './Guide.module.css';
import Seo from '../components/Seo';

function Guide() {
  return (
    <div className={styles.page}>
      <Seo
        title="Guide | Navigate Lingua Academy"
        description="Step-by-step guide to choosing language courses, booking sessions, and exploring resources at Lingua Academy."
        keywords="lingua academy guide, language learning platform, how to choose language course"
      />

      <header className={styles.header}>
        <h1 className={styles.title}>Your guide to the Lingua Academy experience</h1>
        <p className={styles.intro}>
          We’ve mapped out every stage so you can move through the platform confidently.
          From discovering programs to celebrating achievements, this guide keeps things
          simple and transparent.
        </p>
      </header>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>1. Get started with clarity</h2>
        <ul className={styles.list}>
          <li className={styles.listItem}>
            <span className={styles.badge}>1</span>
            <div>
              <strong>Explore programs:</strong> Visit the Programs page to review course
              summaries, formats, and learner outcomes. Save your favourites.
            </div>
          </li>
          <li className={styles.listItem}>
            <span className={styles.badge}>2</span>
            <div>
              <strong>Use the quick questionnaire:</strong> At the bottom of each program
              page you’ll find a short form. Tell us about your goals, schedule, and the
              city you are based in. This helps us tailor your roadmap.
            </div>
          </li>
          <li className={styles.listItem}>
            <span className={styles.badge}>3</span>
            <div>
              <strong>Book a personalised consult:</strong> Within 24 hours our learner
              experience team will invite you to a virtual chat to finalise the best fit.
            </div>
          </li>
        </ul>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>2. Navigate your dashboard</h2>
        <p>
          Once enrolled, you will receive access to the Lingua Academy dashboard. From here
          you can:
        </p>
        <ul className={styles.list}>
          <li>Download session materials and vocabulary sets.</li>
          <li>Join live lessons or review replays of group workshops.</li>
          <li>Track progress milestones and tutor feedback.</li>
          <li>Bookmark cultural events and community meet-ups across the Netherlands.</li>
        </ul>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>3. Choose the resources that match your pace</h2>
        <p>
          The Tools section is updated weekly with playlists, pronunciation labs, reading
          bundles, and cultural cheat sheets. Sort resources by language or proficiency
          level, then add them to your personal study plan.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>4. Stay connected with tutors and peers</h2>
        <p>
          Our tutors check in between sessions via the dashboard messaging space. You will
          also receive invitations to community events in Amsterdam, Rotterdam, Utrecht,
          and The Hague. These gatherings keep motivation high and provide real-life practice.
        </p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>5. Measure impact and plan next steps</h2>
        <p>
          Every six weeks we host a progress review. Together we celebrate wins, adjust goals,
          and plan future modules. When you complete a program, you’ll receive a detailed report
          plus alumni access to ongoing practice sessions.
        </p>
      </section>

      <aside className={styles.highlight}>
        Remember: if anything feels unclear, our team is one message away. Use the contact form
        or the chat bubble inside your dashboard. We speak Dutch, English, Spanish, Portuguese,
        and more—so feel free to reach out in the language you are most comfortable with.
      </aside>
    </div>
  );
}

export default Guide;
```