```javascript
export const programs = [
  {
    slug: 'english-conversation-mastery',
    title: 'English Conversation Mastery',
    level: 'Intermediate to Advanced',
    category: 'Group Learning',
    format: 'Hybrid | 10 weeks',
    languageFocus: 'English fluency for multicultural teams',
    schedule: 'Evening cohorts in Amsterdam & Utrecht',
    image: 'https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=1200&q=80',
    description:
      'Gain the confidence to speak English naturally in professional and social settings across the Netherlands. Every session combines live conversation labs, pronunciation clinics, and guided feedback from expert tutors.',
    highlights: [
      'Weekly live workshops with native and near-native coaches',
      'Micro-coaching on pronunciation aligned with Dutch-English nuances',
      'Scenario-based practice for meetings, pitches, and networking',
      'Community conversation clubs to expand your network'
    ],
    outcomes: [
      'Speak with clarity and flow during fast-paced conversations',
      'Learn techniques to manage accents and intonation shifts',
      'Build vocabulary relevant to Dutch workplaces and daily life',
      'Receive personalised feedback and an action roadmap'
    ],
    audience: 'Professionals and expats who already speak English but want to move from competent to confident.',
    materials: [
      'Interactive pronunciation studio with AI-assisted practice',
      'Weekly reflection journals reviewed by your tutor',
      'Lingua Academy learner app with on-the-go exercises'
    ]
  },
  {
    slug: 'dutch-beginners-foundation',
    title: 'Dutch Beginners Foundation',
    level: 'Starter to A1',
    category: 'Individual Coaching',
    format: 'In-person & Online | 12 weeks',
    languageFocus: 'Dutch fundamentals for everyday life',
    schedule: 'Flexible mornings and afternoons across NL',
    image: 'https://images.unsplash.com/photo-1529070538774-1843cb3265df?auto=format&fit=crop&w=1200&q=80',
    description:
      'Start speaking Dutch from day one. Our foundation track introduces practical vocabulary, pronunciation, and cultural insights so you can navigate life in the Netherlands with ease.',
    highlights: [
      'Immersive modules that mirror real-life situations',
      'Cultural insights to understand Dutch habits and etiquette',
      'Dedicated success mentor guiding your weekly progress',
      'Bite-sized assignments with instant tutor feedback'
    ],
    outcomes: [
      'Introduce yourself, ask for help, and handle daily errands in Dutch',
      'Understand core sentence structures and pronunciation patterns',
      'Build a personalised toolkit of phrases relevant to your lifestyle',
      'Establish study habits with the support of your mentor'
    ],
    audience: 'Newcomers to the Netherlands and anyone eager to unlock Dutch essentials in a supportive environment.',
    materials: [
      'Interactive vocabulary decks with audio support',
      'Community forum to practise with fellow learners',
      'Printable survival guides for supermarkets, transport, and healthcare'
    ]
  },
  {
    slug: 'business-dutch-accelerator',
    title: 'Business Dutch Accelerator',
    level: 'B1 to C1',
    category: 'Corporate Training',
    format: 'Corporate cohorts | 8 weeks',
    languageFocus: 'Dutch communication in corporate contexts',
    schedule: 'On-site sessions plus live online clinics',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80',
    description:
      'Designed for multilingual professionals who collaborate with Dutch stakeholders. Strengthen your ability to negotiate, present, and write with formal Dutch that resonates in the workplace.',
    highlights: [
      'Industry-tailored modules curated with your HR team',
      'Presentation masterclasses with video feedback',
      'Writing labs for emails, proposals, and documentation',
      'Language coaching for cross-cultural leadership'
    ],
    outcomes: [
      'Deliver confident presentations and briefings in Dutch',
      'Write succinct, on-brand communications with ease',
      'Navigate nuanced cultural expectations in business',
      'Develop leadership vocabulary that inspires trust'
    ],
    audience: 'International professionals, team leads, and consultants working in Dutch organisations.',
    materials: [
      'Stakeholder communication playbook',
      'On-demand legal and compliance vocabulary packs',
      'Quarterly alumni networking events in Amsterdam'
    ]
  },
  {
    slug: 'ielts-exam-sprint',
    title: 'IELTS Exam Sprint',
    level: 'Upper-Intermediate',
    category: 'Exam Preparation',
    format: '12-week intensive',
    languageFocus: 'IELTS Academic & General Training',
    schedule: 'Weekend bootcamps + weekly strategy labs',
    image: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1200&q=80',
    description:
      'Strategic preparation for IELTS success tailored to Dutch testing centres. Each learner receives individualised study plans, examiner-style feedback, and performance analytics.',
    highlights: [
      'Diagnostic mock tests with personalised analytics',
      'Speaking simulations recorded and reviewed by examiners',
      'Writing clinics focusing on structure and coherence',
      'Vocabulary boosters themed around Dutch society and economy'
    ],
    outcomes: [
      'Achieve clarity on scoring criteria and master timing',
      'Receive detailed feedback on writing tasks 1 & 2',
      'Build resilience and confidence for exam day',
      'Access curated listening resources reflecting real exam accents'
    ],
    audience: 'Learners targeting international study, migration requirements, or professional registration in the Netherlands.',
    materials: [
      'Weekly progress dashboards with actionable tips',
      'Curated reading library with Dutch-relevant topics',
      'Exam-day toolkit including checklists and mindset coaching'
    ]
  }
];

export const blogPosts = [
  {
    slug: '5-tips-to-learn-faster',
    title: '5 Practical Tips to Learn Languages Faster in the Netherlands',
    excerpt:
      'Reduce overwhelm and keep your Dutch or English studies on track with strategies designed for busy lives in Amsterdam, Rotterdam, and beyond.',
    date: 'February 4, 2024',
    author: 'Mila Van Dijk',
    readTime: '6 min read',
    image: 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=1100&q=80',
    content: [
      'Settling into life in the Netherlands often means switching between multiple languages every day. The key is to bring structure to your practice without losing joy. Start by setting micro-goals for each week: one conversation at the local market, one podcast episode during your commute, and a quick chat with your tutor about progress.',
      'Pair your study sessions with familiar routines. Brew your morning koffie, open our mobile app, and complete three pronunciation exercises before leaving home. Associating learning with existing habits helps you stay consistent even on busy days.',
      'Seek out social spaces where Dutch and English overlap organically. International book clubs, coworking “borrels”, and yoga classes that switch languages mid-session provide low-pressure practice. You will start to relate vocabulary to real people and experiences, which dramatically boosts recall.',
      'Finally, reflect weekly. Our mentors encourage journaling in the language you’re learning—just one paragraph. Share it with your tutor for gentle corrections and celebrate how your voice evolves over time.'
    ]
  },
  {
    slug: 'understanding-dutch-culture',
    title: 'Understanding Dutch Culture Through Language',
    excerpt:
      'Why learning Dutch is more than grammar tables—it’s a doorway into local humour, values, and the art of being direct.',
    date: 'January 22, 2024',
    author: 'Thomas Becker',
    readTime: '5 min read',
    image: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1100&q=80',
    content: [
      'The Netherlands is famous for its direct communication style. When you understand the cultural roots behind phrases such as “niet lullen maar poetsen”, feedback conversations become smoother and friendlier.',
      'Language opens windows into Dutch priorities—community, pragmatism, and humour. We encourage learners to collect expressions they hear on the tram or at the office. Bring them to class, unpack the context with your tutor, and soon you’ll decode subtle meanings behind straightforward sentences.',
      'Listening to Dutch radio or podcasts can feel fast at first, but rhythm repeats itself. Focus on key markers like “dus”, “eigenlijk”, or “maar” to follow arguments. Over time, your ear recognises patterns and you respond with confidence.'
    ]
  },
  {
    slug: 'celebrating-learner-success',
    title: 'Celebrating Lingua Academy Learner Success Stories',
    excerpt:
      'From relocation to promotion, discover how our learners turned language goals into real-life wins across the Netherlands.',
    date: 'December 15, 2023',
    author: 'Lingua Academy Team',
    readTime: '7 min read',
    image: 'https://images.unsplash.com/photo-1460518451285-97b6aa326961?auto=format&fit=crop&w=1100&q=80',
    content: [
      'Irides, a UX designer in Eindhoven, joined our Business Dutch Accelerator to communicate more fluidly with stakeholders. After eight weeks of workshops and 1:1 coaching, she delivered her first pitch in Dutch and felt the shift in how colleagues collaborated.',
      'Meanwhile, Ahmed and Sara relocated to Utrecht with two young children. They joined our Dutch Beginners Foundation and used the family toolkit to practise at home. Their breakthrough moment arrived at their local school conference when the teacher complimented their newfound ease in conversation.',
      'These stories remind us that language is an enabler, not an exam. Every syllabus at Lingua Academy is co-designed with learners, ensuring the curriculum connects to daily realities in the Netherlands.'
    ]
  }
];

export const testimonials = [
  {
    name: 'Irides Van Lee',
    role: 'UX Designer, Eindhoven',
    message:
      '“The coaching team didn’t just teach me Dutch—they helped me craft the exact language for my product demos. I went from nervous to natural in eight weeks.”',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Miguel Ferreira',
    role: 'Customer Success Lead, Amsterdam',
    message:
      '“My English was okay, but I needed it to be excellent for board meetings. The conversation labs and confidence coaching changed how I show up at work.”',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Sara & Ahmed',
    role: 'Family relocating to Utrecht',
    message:
      '“Our tutor blended stories, games, and practical Dutch for parents. We now chat easily with teachers and neighbours—it has transformed our integration.”',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80'
  }
];

export const stats = [
  { label: 'Learners supported across the Netherlands', value: '3,200+' },
  { label: 'Expert tutors and language coaches', value: '48' },
  { label: 'Corporate partners & universities', value: '65' },
  { label: 'Average learner satisfaction score', value: '4.9/5' }
];

export const learningSteps = [
  {
    title: 'Discover & Design',
    description: 'Book a discovery call, share your goals, and receive a tailored roadmap that suits your schedule.'
  },
  {
    title: 'Engage & Practise',
    description: 'Attend live sessions, complete micro-tasks in our app, and receive weekly feedback from your tutor.'
  },
  {
    title: 'Connect & Immerse',
    description: 'Join conversation clubs, cultural field trips, and online communities to embed language habits.'
  },
  {
    title: 'Reflect & Grow',
    description: 'Measure progress with milestone reviews, celebrate wins, and plan your next language challenge.'
  }
];

export const teamMembers = [
  {
    name: 'Noor Jansen',
    role: 'Academic Director',
    bio: 'Former university lecturer specialising in applied linguistics, Noor ensures every program meets high academic and practical standards.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Lucas Martín',
    role: 'Lead Dutch Coach',
    bio: 'Lucas blends theatre techniques with language instruction to build confident communicators in Dutch business environments.',
    image: 'https://images.unsplash.com/photo-1504595403659-9088ce801e29?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Sanne de Groot',
    role: 'Learner Experience Strategist',
    bio: 'Sanne designs our learner journey, from onboarding to alumni events, ensuring every voice is heard and supported.',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80'
  }
];

export const faqs = [
  {
    question: 'How do I know which language program fits me best?',
    answer:
      'Start with our guide or book a free consultation. We analyse your goals, availability, and preferred learning style, then recommend a track and tutor who match your needs.'
  },
  {
    question: 'Can I switch between individual and group lessons?',
    answer:
      'Yes. Many learners begin with 1:1 coaching and later join group labs for additional practice. Your mentor will help you align the combination with your objectives.'
  },
  {
    question: 'Do you support corporate training in multiple locations?',
    answer:
      'We partner with organisations across the Netherlands, delivering in-house sessions, virtual classrooms, and blended programs that scale with your teams.'
  }
];

export const toolCollections = [
  {
    name: 'Daily Dutch Playlist',
    description: 'Twenty curated listening exercises featuring Dutch newscasts, interviews, and storytelling at varying speeds.',
    type: 'Listening practice',
    link: 'https://open.spotify.com/'
  },
  {
    name: 'Pronunciation Studio',
    description: 'Interactive pronunciation drills with instant feedback tailored to Dutch-English sound patterns.',
    type: 'Pronunciation',
    link: 'https://app.lingua-academy.nl/pronunciation'
  },
  {
    name: 'Grammar On-Demand',
    description: 'Micro-lessons with gifs, quizzes, and local examples so grammar becomes a usable tool instead of a hurdle.',
    type: 'Grammar lab',
    link: 'https://app.lingua-academy.nl/grammar'
  },
  {
    name: 'Cultural Cheat Sheets',
    description: 'Downloadable guides explaining Dutch holidays, etiquette, and workplace norms in English and Dutch.',
    type: 'Culture',
    link: 'https://www.lingua-academy.nl/resources'
  }
];

export const studyTips = [
  'Record yourself speaking twice a week and compare progress with your tutor.',
  'Pair each Dutch lesson with a real-life task, such as ordering koffie or making a call.',
  'Create “language zones” at home where you only speak the new language for 15 minutes.',
  'Schedule micro-revision sessions (10 minutes) directly after class to lock in new vocabulary.'
];

export const servicePackages = [
  {
    title: 'Individual Coaching',
    tag: 'Fully personalised',
    points: [
      'Weekly 1:1 sessions with a dedicated tutor',
      'Flexible scheduling across time zones',
      'Personalised study plan and progress dashboard',
      'Access to premium digital toolkits'
    ]
  },
  {
    title: 'Group Learning Labs',
    tag: 'Collaborative practice',
    points: [
      'Small cohort workshops led by senior tutors',
      'Peer review and project-based learning',
      'Conversation clubs hosted in major Dutch cities',
      'Monthly cultural immersion events'
    ]
  },
  {
    title: 'Corporate Partnerships',
    tag: 'Tailored for teams',
    points: [
      'Language audits and goal-setting with HR teams',
      'Industry-specific curriculum and case studies',
      'Leadership communication coaching',
      'Quarterly reporting and impact reviews'
    ]
  }
];
```