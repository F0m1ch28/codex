```javascript
import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Home' },
  { path: '/guide', label: 'Guide' },
  { path: '/programs', label: 'Programs' },
  { path: '/tools', label: 'Tools' },
  { path: '/blog', label: 'Blog' },
  { path: '/about', label: 'About' },
  { path: '/contact', label: 'Contact' }
];

function Header() {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  return (
    <header className={styles.header} role="banner">
      <div className={styles.container}>
        <Link to="/" className={styles.logo} aria-label="Lingua Academy">
          Lingua Academy
        </Link>

        <nav className={styles.nav} aria-label="Main navigation">
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    isActive
                      ? `${styles.navLink} ${styles.navLinkActive}`
                      : styles.navLink
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <Link to="/contact" className={styles.ctaButton}>
          Start a conversation
        </Link>

        <button
          type="button"
          className={styles.menuButton}
          onClick={() => setOpen((prev) => !prev)}
          aria-expanded={open}
          aria-controls="mobile-menu"
        >
          Menu
          <span aria-hidden="true">{open ? '−' : '+'}</span>
        </button>

        {open && (
          <div id="mobile-menu" className={styles.mobilePanel}>
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={styles.mobileLink}
              >
                {item.label}
              </NavLink>
            ))}
            <Link to="/contact" className={styles.mobileCta}>
              Start a conversation
            </Link>
          </div>
        )}
      </div>
    </header>
  );
}

export default Header;
```