```javascript
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'lingua-cookie-accepted';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = sessionStorage.getItem(STORAGE_KEY);
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    sessionStorage.setItem(STORAGE_KEY, 'true');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.text}>
        We use cookies to personalise content, analyse our traffic, and ensure a smooth
        learning experience. You can review details in our cookie policy.
      </p>
      <div className={styles.links}>
        <Link to="/cookie-policy" className={styles.link}>
          Cookie Policy
        </Link>
        <Link to="/privacy" className={styles.link}>
          Privacy Policy
        </Link>
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Accept
      </button>
    </div>
  );
}

export default CookieBanner;
```