```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.container}>
        <div className={styles.top}>
          <div className={styles.brand}>
            <h3 className={styles.brandTitle}>Lingua Academy</h3>
            <p className={styles.brandText}>
              We empower learners across the Netherlands to navigate multilingual
              environments with confidence. From personalised coaching to vibrant
              group sessions, every journey is crafted to fit local realities and
              global ambitions.
            </p>
          </div>

          <div className={styles.columns}>
            <div>
              <h4 className={styles.columnTitle}>Explore</h4>
              <Link to="/programs" className={styles.link}>Programs</Link>
              <Link to="/services" className={styles.link}>Services</Link>
              <Link to="/guide" className={styles.link}>Platform Guide</Link>
              <Link to="/tools" className={styles.link}>Learning Tools</Link>
            </div>
            <div>
              <h4 className={styles.columnTitle}>Resources</h4>
              <Link to="/blog" className={styles.link}>Blog</Link>
              <Link to="/about" className={styles.link}>Our Story</Link>
              <Link to="/contact" className={styles.link}>Contact</Link>
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className={styles.link}
              >
                LinkedIn Community
              </a>
            </div>
            <div>
              <h4 className={styles.columnTitle}>Legal</h4>
              <Link to="/terms" className={styles.link}>Terms of Service</Link>
              <Link to="/privacy" className={styles.link}>Privacy Policy</Link>
              <Link to="/cookie-policy" className={styles.link}>Cookie Policy</Link>
            </div>
          </div>
        </div>

        <div className={styles.bottom}>
          <p>© {new Date().getFullYear()} Lingua Academy. All rights reserved.</p>
          <div className={styles.socials}>
            <a
              href="https://www.instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.socialLink}
              aria-label="Instagram"
            >
              in
            </a>
            <a
              href="https://www.facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.socialLink}
              aria-label="Facebook"
            >
              fb
            </a>
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.socialLink}
              aria-label="YouTube"
            >
              yt
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
```