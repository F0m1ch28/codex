import React, { useEffect, useState } from "react";
import styles from "./ScrollToTop.module.css";

const ScrollToTopButton = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      setVisible(window.scrollY > 320);
    };
    window.addEventListener("scroll", toggleVisibility);
    return () => window.removeEventListener("scroll", toggleVisibility);
  }, []);

  const handleClick = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <button
      className={`${styles.scrollTop} ${visible ? styles.visible : ""}`}
      onClick={handleClick}
      aria-label="Nach oben scrollen"
    >
      ↑
    </button>
  );
};

export default ScrollToTopButton;