import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("raventolira-cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem("raventolira-cookie-consent", "accepted");
    setVisible(false);
  };

  const declineCookies = () => {
    localStorage.setItem("raventolira-cookie-consent", "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie Hinweis">
      <div className={styles.text}>
        <h4>Wir respektieren Ihre Privatsphäre</h4>
        <p>
          Wir verwenden Cookies, um Ihr Erlebnis zu verbessern und anonymisierte Nutzungsstatistiken zu erheben. Weitere Informationen finden Sie in unseren{" "}
          <Link to="/datenschutz">Datenschutzrichtlinien</Link> und{" "}
          <Link to="/cookie-richtlinien">Cookie-Richtlinien</Link>.
        </p>
      </div>
      <div className={styles.actions}>
        <button onClick={declineCookies} className={styles.secondaryBtn}>
          Ablehnen
        </button>
        <button onClick={acceptCookies} className={styles.primaryBtn}>
          Akzeptieren
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;