import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Fußbereich">
      <div className={styles.container}>
        <div className={styles.brand}>
          <h3 className={styles.logo}>
            <span className={styles.logoAccent}>Raven</span>tolira
          </h3>
          <p>
            Raventolira begleitet Paare in Deutschland dabei, Dialoge neu zu gestalten, Grenzen wertschätzend zu setzen und Vertrauen zu vertiefen.
          </p>
        </div>
        <div className={styles.grid}>
          <div>
            <h4>Navigation</h4>
            <ul>
              <li>
                <NavLink to="/">Start</NavLink>
              </li>
              <li>
                <NavLink to="/ueber-uns">Über uns</NavLink>
              </li>
              <li>
                <NavLink to="/kommunikations-beratung">Leistungen</NavLink>
              </li>
              <li>
                <NavLink to="/blog">Blog</NavLink>
              </li>
              <li>
                <NavLink to="/kontakt">Kontakt</NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h4>Rechtliches</h4>
            <ul>
              <li>
                <NavLink to="/datenschutz">Datenschutz</NavLink>
              </li>
              <li>
                <NavLink to="/nutzungsbedingungen">Nutzungsbedingungen</NavLink>
              </li>
              <li>
                <NavLink to="/cookie-richtlinien">Cookie-Richtlinien</NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h4>Kontakt</h4>
            <address className={styles.address}>
              Raventolira Beratungsraum<br />
              Lindenstraße 12<br />
              10115 Berlin, Deutschland
            </address>
            <a href="tel:+49301234567" className={styles.contactLink}>
              Telefon: +49 (0)30 1234567
            </a>
            <a href="mailto:kontakt@raventolira.de" className={styles.contactLink}>
              kontakt@raventolira.de
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottomNote}>
        © {new Date().getFullYear()} Raventolira. Alle Rechte vorbehalten.
      </div>
    </footer>
  );
};

export default Footer;