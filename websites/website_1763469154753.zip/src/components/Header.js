import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import styles from "./Header.module.css";

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 36);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ""}`}>
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Raventolira Startseite">
          <span className={styles.logoAccent}>Raven</span>tolira
        </NavLink>
        <nav className={`${styles.nav} ${menuOpen ? styles.open : ""}`} aria-label="Hauptnavigation">
          <NavLink to="/" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ""}`} onClick={closeMenu}>
            Start
          </NavLink>
          <NavLink to="/ueber-uns" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ""}`} onClick={closeMenu}>
            Über uns
          </NavLink>
          <NavLink to="/kommunikations-beratung" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ""}`} onClick={closeMenu}>
            Leistungen
          </NavLink>
          <NavLink to="/blog" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ""}`} onClick={closeMenu}>
            Blog
          </NavLink>
          <NavLink to="/kontakt" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ""}`} onClick={closeMenu}>
            Kontakt
          </NavLink>
        </nav>
        <button
          className={`${styles.burger} ${menuOpen ? styles.burgerActive : ""}`}
          onClick={toggleMenu}
          aria-label="Navigation umschalten"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;