import React from "react";
import { Helmet } from "react-helmet";
import styles from "./CookiePolicy.module.css";

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Cookie-Richtlinien | Raventolira</title>
        <meta
          name="description"
          content="Cookie-Richtlinien von Raventolira. Informieren Sie sich darüber, wie wir Cookies einsetzen und wie Sie diese verwalten können."
        />
        <link rel="canonical" href="https://www.raventolira.de/cookie-richtlinien" />
      </Helmet>
      <section className={styles.wrapper}>
        <h1>Cookie-Richtlinien</h1>
        <p>
          Wir verwenden Cookies, um grundlegende Funktionen unserer Website zu ermöglichen und anonymisierte Statistiken zur Nutzung zu erheben. Nachfolgend erhalten Sie einen Überblick über Art, Zweck und Verwaltungsmöglichkeiten.
        </p>

        <h2>1. Was sind Cookies?</h2>
        <p>Cookies sind kleine Textdateien, die auf Ihrem Endgerät gespeichert werden. Sie enthalten Informationen zum Nutzerverhalten und Einstellungen.</p>

        <h2>2. Arten von Cookies</h2>
        <ul>
          <li>Notwendige Cookies: sichern grundlegende Funktionen wie Navigation und Zugriff auf geschützte Bereiche.</li>
          <li>Statistik-Cookies: helfen uns, die Website zu verbessern, indem sie anonym Informationen sammeln.</li>
        </ul>

        <h2>3. Verwaltung</h2>
        <p>
          Sie können Cookies jederzeit über Ihre Browsereinstellungen löschen oder deaktivieren. Beachten Sie, dass dadurch Funktionen der Website eingeschränkt sein können.
        </p>

        <h2>4. Einwilligung</h2>
        <p>
          Beim ersten Besuch der Website fragen wir nach Ihrer Einwilligung zum Einsatz von Cookies. Ihre Entscheidung können Sie über die Browsereinstellungen oder durch Löschen der Cookies jederzeit ändern.
        </p>

        <h2>5. Kontakt</h2>
        <p>Für Fragen zum Einsatz von Cookies kontaktieren Sie uns unter kontakt@raventolira.de.</p>
      </section>
    </>
  );
};

export default CookiePolicy;