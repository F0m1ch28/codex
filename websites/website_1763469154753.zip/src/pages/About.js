import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const pillars = [
  {
    title: "Empathische Präsenz",
    description: "Wir hören zu, spiegeln und übersetzen unausgesprochene Botschaften in klare Worte."
  },
  {
    title: "Integrative Perspektive",
    description: "Systemische, traumasensible und körperorientierte Ansätze für nachhaltige Veränderungen."
  },
  {
    title: "Praxisnahe Umsetzung",
    description: "Übungen, Rituale und Check-ins, die im Alltag leicht verankert werden können."
  }
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>Über Raventolira | Vision und Team</title>
        <meta
          name="description"
          content="Erfahren Sie, wer hinter Raventolira steht: unser Team, unsere Haltung und warum wir Paare auf ihrem Weg zu gesunder Kommunikation begleiten."
        />
        <link rel="canonical" href="https://www.raventolira.de/ueber-uns" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.eyebrow}>Wir über uns</span>
          <h1>Räumlichkeiten für Dialoge, die tragen</h1>
          <p>
            Raventolira entstand aus der Vision, Paare in Umbruchphasen nicht allein zu lassen. Wir schaffen Räume, in denen Vulnerabilität willkommen ist und Grenzen klar benannt werden dürfen.
          </p>
        </div>
      </section>

      <section className={styles.storySection}>
        <div className={styles.storyImageWrapper}>
          <img src="https://picsum.photos/1000/700?random=31" alt="Team von Raventolira im Austausch" loading="lazy" />
        </div>
        <div className={styles.storyContent}>
          <h2>Eine Geschichte von Zuhören und Klarheit</h2>
          <p>
            Nach Jahren in Beratungsstellen und Organisationen sahen wir immer wieder, wie schwer es Paaren fällt, Grenzen zu benennen ohne Distanz zu erzeugen. Raventolira bündelt Methoden, die Kommunikation entlasten, Nähe erhalten und persönliche Autonomie sichern.
          </p>
          <p>
            Unsere Werte basieren auf respektvoller Sprache, aufmerksamer Körperwahrnehmung und einer Haltung, die Fehler als Lernmomente versteht. Wir begleiten Paare einfühlsam und konsequent zugleich.
          </p>
        </div>
      </section>

      <section className={styles.pillarsSection}>
        <h2>Unsere Säulen der Begleitung</h2>
        <div className={styles.pillarsGrid}>
          {pillars.map((pillar) => (
            <article key={pillar.title}>
              <h3>{pillar.title}</h3>
              <p>{pillar.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.approachSection}>
        <div className={styles.approachContent}>
          <h2>Verbindung & Grenzen als Lebenseinstellung</h2>
          <p>
            Wir sind überzeugt, dass Beziehungen sowohl Nähe als auch Autonomie brauchen. Deshalb vermitteln wir Paaren Handwerkszeug, das Kommunikation als lebendigen Prozess begreifbar macht.
          </p>
          <ul>
            <li>Reflexionsräume für individuelle und gemeinsame Bedürfnisse</li>
            <li>Gezielte Übungen für Präsenz, Atem und Selbstregulation</li>
            <li>Impulse, die zwischen den Sitzungen vertiefen und stärken</li>
          </ul>
        </div>
        <div className={styles.approachImageWrapper}>
          <img src="https://picsum.photos/900/650?random=32" alt="Beratungssituation in einem hellen Raum" loading="lazy" />
        </div>
      </section>

      <section className={styles.missionSection}>
        <div className={styles.missionContent}>
          <h2>Mission</h2>
          <p>
            Paare ermutigen, klar zu sprechen, achtsam zuzuhören und Grenzen als Wegweiser zu sehen – nicht als Mauern. Wir begleiten dabei, Kommunikation so zu gestalten, dass sie Halt gibt.
          </p>
        </div>
        <div className={styles.missionContent}>
          <h2>Vision</h2>
          <p>
            Beziehungen, in denen Konflikte nicht gescheut, sondern als Einladung zur gemeinsamen Entwicklung verstanden werden. Raventolira steht für eine Kultur der Verbindlichkeit.
          </p>
        </div>
      </section>
    </>
  );
};

export default About;