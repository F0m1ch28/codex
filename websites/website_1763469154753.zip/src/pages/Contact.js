import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

const initialFormState = {
  name: "",
  email: "",
  phone: "",
  message: ""
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Bitte geben Sie Ihren Namen ein.";
    if (!formData.email.trim()) {
      newErrors.email = "Bitte geben Sie Ihre E-Mail-Adresse ein.";
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/i.test(formData.email)) {
      newErrors.email = "Bitte geben Sie eine gültige E-Mail-Adresse ein.";
    }
    if (!formData.message.trim()) newErrors.message = "Bitte beschreiben Sie Ihr Anliegen.";
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormData(initialFormState);
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Raventolira Kommunikation</title>
        <meta
          name="description"
          content="Nehmen Sie Kontakt zu Raventolira auf. Wir beantworten Fragen rund um Paar-Dialoge, gesunde Grenzen und individuelle Begleitung."
        />
        <link rel="canonical" href="https://www.raventolira.de/kontakt" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.eyebrow}>Kontakt</span>
          <h1>Wir freuen uns auf Ihren Dialog</h1>
          <p>
            Schreiben Sie uns Ihr Anliegen – wir melden uns zeitnah und finden gemeinsam den passenden Rahmen für Ihr Gespräch.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className={styles.infoCard}>
          <h2>Kontaktinformationen</h2>
          <p>Raventolira Beratungsraum</p>
          <p>Lindenstraße 12, 10115 Berlin</p>
          <a href="tel:+49301234567">Telefon: +49 (0)30 1234567</a>
          <a href="mailto:kontakt@raventolira.de">kontakt@raventolira.de</a>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.formGroup}>
            <label htmlFor="name">Ihr Name*</label>
            <input
              type="text"
              id="name"
              name="name"
              placeholder="Vor- und Nachname"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={!!errors.name}
              aria-describedby={errors.name ? "name-error" : undefined}
            />
            {errors.name && (
              <span id="name-error" className={styles.error}>
                {errors.name}
              </span>
            )}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="email">E-Mail*</label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="Ihre E-Mail-Adresse"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={!!errors.email}
              aria-describedby={errors.email ? "email-error" : undefined}
            />
            {errors.email && (
              <span id="email-error" className={styles.error}>
                {errors.email}
              </span>
            )}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="phone">Telefon (optional)</label>
            <input
              type="tel"
              id="phone"
              name="phone"
              placeholder="+49 ..."
              value={formData.phone}
              onChange={handleChange}
            />
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="message">Ihre Nachricht*</label>
            <textarea
              id="message"
              name="message"
              placeholder="Worum geht es Ihnen? Welche Themen möchten Sie ansprechen?"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={!!errors.message}
              aria-describedby={errors.message ? "message-error" : undefined}
            />
            {errors.message && (
              <span id="message-error" className={styles.error}>
                {errors.message}
              </span>
            )}
          </div>
          <button type="submit" className={styles.submitBtn}>
            Nachricht senden
          </button>
          {submitted && <p className={styles.successMsg}>Vielen Dank! Wir melden uns zeitnah bei Ihnen.</p>}
        </form>
      </section>
    </>
  );
};

export default Contact;