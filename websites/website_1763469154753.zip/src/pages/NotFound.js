import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./NotFound.module.css";

const NotFound = () => (
  <>
    <Helmet>
      <title>Seite nicht gefunden | Raventolira</title>
      <meta name="robots" content="noindex" />
    </Helmet>
    <section className={styles.wrapper}>
      <h1>404</h1>
      <p>Die von Ihnen gesuchte Seite existiert nicht oder wurde verschoben.</p>
      <Link to="/" className={styles.link}>
        Zur Startseite
      </Link>
    </section>
  </>
);

export default NotFound;