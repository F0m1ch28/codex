import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Privacy.module.css";

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Datenschutz | Raventolira</title>
        <meta
          name="description"
          content="Datenschutzerklärung von Raventolira. Erfahren Sie, wie wir mit Ihren Daten umgehen und Ihre Privatsphäre schützen."
        />
        <link rel="canonical" href="https://www.raventolira.de/datenschutz" />
      </Helmet>
      <section className={styles.wrapper}>
        <h1>Datenschutzerklärung</h1>
        <p>Wir nehmen den Schutz Ihrer persönlichen Daten sehr ernst. Nachfolgend informieren wir Sie über die wichtigsten Aspekte der Datenverarbeitung auf unserer Website.</p>

        <h2>1. Verantwortliche Stelle</h2>
        <p>Raventolira, Lindenstraße 12, 10115 Berlin, Deutschland, kontakt@raventolira.de</p>

        <h2>2. Erhebung und Speicherung personenbezogener Daten</h2>
        <p>
          Wir verarbeiten personenbezogene Daten ausschließlich im gesetzlichen Rahmen, etwa bei der Nutzung unseres Kontaktformulars. Dabei speichern wir Ihren Namen, Ihre E-Mail-Adresse sowie Ihre Nachricht zur Bearbeitung des Anliegens.
        </p>

        <h2>3. Zweck und Rechtsgrundlage</h2>
        <p>
          Die Datenverarbeitung erfolgt zum Zweck der Beantwortung Ihrer Anfrage (Art. 6 Abs. 1 lit. b DSGVO). Eine Weitergabe an Dritte findet nicht statt, sofern keine gesetzliche Pflicht besteht.
        </p>

        <h2>4. Cookies</h2>
        <p>
          Unsere Website verwendet Cookies, um grundlegende Funktionen bereitzustellen. Weitere Informationen erhalten Sie in unseren Cookie-Richtlinien. Sie können Cookies jederzeit in Ihrem Browser deaktivieren.
        </p>

        <h2>5. Ihre Rechte</h2>
        <p>
          Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit sowie Widerspruch. Bitte richten Sie Ihre Anfrage an kontakt@raventolira.de.
        </p>

        <h2>6. Sicherheit</h2>
        <p>
          Wir setzen technische und organisatorische Maßnahmen ein, um Ihre Daten vor Verlust, Manipulation und unberechtigtem Zugriff zu schützen und passen diese dem Stand der Technik kontinuierlich an.
        </p>

        <h2>7. Aktualität</h2>
        <p>Diese Datenschutzerklärung wurde zuletzt am 1. August 2024 aktualisiert.</p>
      </section>
    </>
  );
};

export default Privacy;