import React, { useEffect, useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const statsData = [
  { label: "Begleitete Gespräche", target: 380 },
  { label: "Paare mit klaren Grenzen", target: 210 },
  { label: "Workshops in DE", target: 45 },
  { label: "Zufriedenheit", target: 98, suffix: "%" }
];

const services = [
  {
    title: "Dialogräume für Paare",
    description: "Moderierte Gespräche, die Sicherheit schaffen und unausgesprochene Bedürfnisse in Worte fassen helfen.",
    icon: "💬"
  },
  {
    title: "Grenzen achtsam setzen",
    description: "Individuelle Strategien, um Nähe und Selbstschutz zu balancieren, ohne Verbundenheit zu verlieren.",
    icon: "🛡️"
  },
  {
    title: "Emotionale Regulation",
    description: "Methoden, um in Konflikten ruhig zu bleiben, Trigger frühzeitig zu erkennen und neue Reaktionsmuster zu entwickeln.",
    icon: "🧭"
  }
];

const processSteps = [
  {
    number: "01",
    title: "Ankommen & Zuhören",
    text: "Wir schaffen einen sicheren Raum, in dem beide Seiten gehört werden und erste Ziele formuliert werden können."
  },
  {
    number: "02",
    title: "Verstehen vertiefen",
    text: "Gemeinsam analysieren wir Kommunikationsmuster und identifizieren Situationen, in denen Grenzen verschwimmen."
  },
  {
    number: "03",
    title: "Praktizieren & integrieren",
    text: "Wir trainieren neue Dialoge, Feedbackschleifen und Rituale, die gesunde Grenzen nachhaltig verankern."
  }
];

const testimonials = [
  {
    quote: "Wir haben gelernt, bei Konflikten nicht mehr gegeneinander, sondern miteinander zu sprechen. Die Tools begleiten uns im Alltag.",
    name: "Anna & Tobias aus Hamburg"
  },
  {
    quote: "Besonders die Arbeit an unseren Grenzen hat uns geholfen, uns nicht mehr zu verlieren und trotzdem nah zu bleiben.",
    name: "Mira & Daniel aus Köln"
  },
  {
    quote: "Raventolira hat uns gezeigt, wie wichtig kleine Check-ins sind – wir erleben heute mehr Leichtigkeit und Vertrauen.",
    name: "Anonymes Paar aus München"
  }
];

const faqItems = [
  {
    question: "Was bedeutet bei Raventolira „gesunde Grenzen“?",
    answer:
      "Gesunde Grenzen bedeuten Klarheit über eigene Bedürfnisse, Respekt für die Grenzen des Gegenübers und ein transparentes Communicating, das Verbundenheit erlaubt, ohne sich zu überfordern."
  },
  {
    question: "Für wen ist das Angebot geeignet?",
    answer:
      "Unsere Begleitung richtet sich an Paare in allen Lebensphasen, die Kommunikationsmuster reflektieren möchten – von frischen Partnerschaften bis zu langjährigen Beziehungen."
  },
  {
    question: "Wie sieht eine Zusammenarbeit aus?",
    answer:
      "Wir beginnen mit einem Einstiegsdialog, definieren Ziele und gestalten Sitzungen, die Gesprächspraxis, Reflexion und Übungen verbinden – sowohl vor Ort als auch digital."
  }
];

const projectsData = [
  { id: 1, category: "Workshops", title: "Grenzgespräche für junge Familien", img: "https://picsum.photos/1200/800?random=14" },
  { id: 2, category: "Retreats", title: "Wochenende für Vertrauensaufbau", img: "https://picsum.photos/1200/800?random=15" },
  { id: 3, category: "Firmen", title: "Partnerschaften in Veränderungsprozessen", img: "https://picsum.photos/1200/800?random=16" },
  { id: 4, category: "Workshops", title: "Stille Signale erkennen", img: "https://picsum.photos/1200/800?random=17" },
  { id: 5, category: "Retreats", title: "Grenzen & Nähe Retreat", img: "https://picsum.photos/1200/800?random=18" },
  { id: 6, category: "Firmen", title: "Kommunikationskultur in Teams", img: "https://picsum.photos/1200/800?random=19" }
];

const blogPreviews = [
  {
    id: 1,
    title: "Vier Gesprächsrituale, die Verbindung stärken",
    excerpt: "Wie kleine wöchentliche Dialoge Klarheit schaffen und emotionale Sicherheit fördern.",
    date: "15. August 2024"
  },
  {
    id: 2,
    title: "Die Sprache der Grenzen: Was wir wirklich meinen",
    excerpt: "Grenzen als Einladungen statt Mauern verstehen – eine Perspektive aus der Praxis.",
    date: "28. Juli 2024"
  },
  {
    id: 3,
    title: "Konflikte als Entwicklungsschub nutzen",
    excerpt: "Warum Streit neugierig macht und wie Paare gemeinsam lernen können.",
    date: "05. Juli 2024"
  }
];

const teamMembers = [
  {
    name: "Lena Hoffmann",
    role: "Systemische Paarberaterin",
    description:
      "Lena begleitet seit über 10 Jahren Paare, die ihre Kommunikation vertiefen möchten. Schwerpunkt: Bindungsdynamiken & Achtsamkeit.",
    img: "https://picsum.photos/400/400?random=21"
  },
  {
    name: "Farid Becker",
    role: "Mediator & Coach",
    description:
      "Farid gestaltet Dialoge in Veränderungsprozessen. Schwerpunkt: Konflikttransformation und wertschätzende Feedbackkultur.",
    img: "https://picsum.photos/400/400?random=22"
  },
  {
    name: "Mira Schultz",
    role: "Trainerin für Grenzen-Kompetenz",
    description:
      "Mira entwickelt Trainings zu Grenzen und Selbstfürsorge. Schwerpunkt: Körperorientierte Tools und Stressregulation.",
    img: "https://picsum.photos/400/400?random=23"
  }
];

const Home = () => {
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeCategory, setActiveCategory] = useState("Alle");
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const timers = statsData.map((stat, index) =>
      setInterval(() => {
        setStats((prev) => {
          const updated = [...prev];
          if (updated[index] < stat.target) {
            const increment = Math.ceil(stat.target / 80);
            updated[index] = Math.min(updated[index] + increment, stat.target);
          }
          return updated;
        });
      }, 40)
    );
    return () => timers.forEach((timer) => clearInterval(timer));
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeCategory === "Alle") return projectsData;
    return projectsData.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  return (
    <>
      <Helmet>
        <title>Raventolira | Kommunikation in Paaren & gesunde Grenzen</title>
        <meta
          name="description"
          content="Raventolira unterstützt Paare in Deutschland dabei, gesunde Kommunikation zu entwickeln, Grenzen zu stärken und Vertrauen aufzubauen."
        />
        <meta name="keywords" content="Paarberatung, Kommunikation, gesunde Grenzen, Beziehungen, Beratung Berlin" />
        <link rel="canonical" href="https://www.raventolira.de/" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroTag}>Verbundenheit mit Klarheit</p>
          <h1>
            Kommunikation vertiefen, Grenzen halten, Liebe lebendig gestalten.
          </h1>
          <p className={styles.heroText}>
            Raventolira begleitet Paare, Dialoge offen zu gestalten, Bedürfnisse klar zu formulieren und gesunde Grenzen in die gemeinsame Beziehungskultur zu integrieren.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakt" className={styles.ctaPrimary}>
              Gespräch anfragen
            </Link>
            <Link to="/kommunikations-beratung" className={styles.ctaSecondary}>
              Leistungen entdecken
            </Link>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/1600/900?random=11"
            alt="Paar im Gespräch mit professioneller Begleitung"
            className={styles.heroImage}
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Ergebnisse und Wirkung">
        <div className={styles.statsContainer}>
          {statsData.map((stat, index) => (
            <div className={styles.statCard} key={stat.label}>
              <span className={styles.statNumber}>
                {stats[index]}
                {stat.suffix || ""}
              </span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.aboutSection}>
        <div className={styles.aboutContent}>
          <span className={styles.sectionEyebrow}>Über Raventolira</span>
          <h2>Ein sicherer Raum für Paare, die mutig sprechen wollen</h2>
          <p>
            Bei Raventolira stehen Dialog, Respekt und Selbstfürsorge im Zentrum. Wir entwickeln mit Paaren neue Kommunikationswege, damit Bedürfnisse gehört, Grenzen respektiert und Beziehungen gestärkt werden können.
          </p>
          <ul className={styles.aboutList}>
            <li>Systemische und traumasensible Perspektive auf Paardialoge</li>
            <li>Individuell abgestimmte Übungen für Alltag und Krisensituationen</li>
            <li>Begleitung in Präsenz in Berlin oder online in ganz Deutschland</li>
          </ul>
          <Link to="/ueber-uns" className={styles.textLink}>
            Mehr über uns erfahren →
          </Link>
        </div>
        <div className={styles.aboutImageWrapper}>
          <img src="https://picsum.photos/800/600?random=12" alt="Coaches moderieren ein Gespräch" loading="lazy" />
        </div>
      </section>

      <section className={styles.valuesSection}>
        <span className={styles.sectionEyebrow}>Warum Grenzen zählen</span>
        <h2>Gesunde Grenzen sind der Schlüssel zu klarer Kommunikation</h2>
        <div className={styles.valuesGrid}>
          <article>
            <h3>Wertschätzung</h3>
            <p>
              Grenzen zeigen, wie wir gesehen werden möchten. Wenn sie respektiert werden, entsteht Vertrauen und ein ehrlicher Dialog.
            </p>
          </article>
          <article>
            <h3>Eigenverantwortung</h3>
            <p>
              Grenzen helfen, Bedürfnisse zu benennen und Verantwortung für das eigene Wohlbefinden zu übernehmen – ohne das Gegenüber zu verlieren.
            </p>
          </article>
          <article>
            <h3>Gemeinsame Kultur</h3>
            <p>
              Paare schaffen ihre individuelle Kommunikationskultur, in der Platz für Nähe, Wachstum und persönliche Entwicklung ist.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.servicesSection} id="leistungen">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Leistungen</span>
          <h2>Begleitung, die Klarheit und Verbindung vereint</h2>
        </div>
        <div className={styles.servicesGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard} tabIndex="0">
              <div className={styles.serviceIcon} aria-hidden="true">
                {service.icon}
              </div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/kommunikations-beratung" className={styles.serviceLink}>
                Mehr erfahren
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.processSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Prozess</span>
          <h2>So begleiten wir Ihren Dialog</h2>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <article key={step.number} className={styles.processCard}>
              <span className={styles.processNumber}>{step.number}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonialsSection} aria-label="Stimmen von Paaren">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Erfahrungen</span>
          <h2>Was Paare über Raventolira sagen</h2>
        </div>
        <div className={styles.testimonialCard}>
          <p className={styles.testimonialQuote}>&ldquo;{testimonials[testimonialIndex].quote}&rdquo;</p>
          <p className={styles.testimonialName}>{testimonials[testimonialIndex].name}</p>
          <div className={styles.testimonialDots} role="tablist">
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                className={`${styles.dot} ${idx === testimonialIndex ? styles.dotActive : ""}`}
                onClick={() => setTestimonialIndex(idx)}
                aria-label={`Testimonial ${idx + 1}`}
                aria-selected={idx === testimonialIndex}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.teamSection} aria-label="Team von Raventolira">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Team</span>
          <h2>Menschen, die Dialoge bewegen</h2>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard} tabIndex="0">
              <div className={styles.teamImageWrapper}>
                <img src={member.img} alt={`${member.name}, ${member.role}`} loading="lazy" />
              </div>
              <div className={styles.teamContent}>
                <h3>{member.name}</h3>
                <p className={styles.teamRole}>{member.role}</p>
                <p>{member.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Projekte</span>
          <h2>Impulse für Kommunikation in Aktion</h2>
        </div>
        <div className={styles.filterBar} role="tablist">
          {["Alle", "Workshops", "Retreats", "Firmen"].map((category) => (
            <button
              key={category}
              className={`${styles.filterBtn} ${activeCategory === category ? styles.filterBtnActive : ""}`}
              onClick={() => setActiveCategory(category)}
              aria-pressed={activeCategory === category}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <div className={styles.projectImageWrapper}>
                <img src={project.img} alt={`Projekt: ${project.title}`} loading="lazy" />
              </div>
              <div className={styles.projectContent}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>FAQ</span>
          <h2>Häufige Fragen rund um Kommunikation & Grenzen</h2>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, idx) => (
            <div key={item.question} className={styles.faqItem}>
              <button
                className={styles.faqQuestion}
                onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                aria-expanded={openFaq === idx}
              >
                <span>{item.question}</span>
                <span>{openFaq === idx ? "−" : "+"}</span>
              </button>
              {openFaq === idx && <p className={styles.faqAnswer}>{item.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionEyebrow}>Insights</span>
          <h2>Aktuelle Beiträge aus unserem Blog</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogPreviews.map((post) => (
            <article key={post.id} className={styles.blogCard}>
              <span className={styles.blogDate}>{post.date}</span>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <Link to="/blog" className={styles.blogLink}>
                Beitrag lesen →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection} aria-label="Kontakt aufnehmen">
        <div className={styles.ctaContent}>
          <h2>Bereit für neue Gespräche?</h2>
          <p>
            Wir gestalten mit Ihnen Kommunikationsräume, die Nähe, Individualität und Klarheit in Einklang bringen. Starten Sie den ersten Schritt zu gesunden Grenzen.
          </p>
          <Link to="/kontakt" className={styles.ctaButton}>
            Kontakt aufnehmen
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;