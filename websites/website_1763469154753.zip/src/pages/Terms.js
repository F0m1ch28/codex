import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Terms.module.css";

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Nutzungsbedingungen | Raventolira</title>
        <meta
          name="description"
          content="Nutzungsbedingungen der Website von Raventolira. Erfahren Sie, welche Regeln für die Nutzung unserer Inhalte gelten."
        />
        <link rel="canonical" href="https://www.raventolira.de/nutzungsbedingungen" />
      </Helmet>
      <section className={styles.wrapper}>
        <h1>Nutzungsbedingungen</h1>
        <p>Mit dem Zugriff auf diese Website erklären Sie sich mit den nachstehenden Bedingungen einverstanden.</p>

        <h2>1. Inhalte</h2>
        <p>
          Die Inhalte der Website dienen der Information über unsere Beratungsleistungen. Sämtliche Texte, Bilder und Grafiken sind urheberrechtlich geschützt.
        </p>

        <h2>2. Nutzung</h2>
        <p>
          Eine gewerbliche Nutzung oder Vervielfältigung der Inhalte ohne ausdrückliche Zustimmung ist nicht gestattet. Wir behalten uns vor, Inhalte jederzeit anzupassen.
        </p>

        <h2>3. Haftung</h2>
        <p>
          Wir übernehmen keine Haftung für die Richtigkeit und Vollständigkeit der bereitgestellten Informationen. Verweise auf externe Seiten liegen außerhalb unserer Verantwortung.
        </p>

        <h2>4. Änderungen</h2>
        <p>
          Diese Nutzungsbedingungen können jederzeit aktualisiert werden. Es gilt die jeweils aktuelle Fassung, abrufbar unter raventolira.de/nutzungsbedingungen.
        </p>

        <h2>5. Kontakt</h2>
        <p>Bei Fragen wenden Sie sich bitte an kontakt@raventolira.de.</p>
      </section>
    </>
  );
};

export default Terms;