import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const serviceDetails = [
  {
    title: "Paar-Dialog Sessions",
    description:
      "Moderierte Gespräche, die Raum für beide Perspektiven eröffnen. Wir strukturieren Dialoge, entschleunigen und übersetzen Emotionen in klare Botschaften.",
    points: [
      "Vorbereitung von sensiblen Themen",
      "Begleitete Kommunikation in Echtzeit",
      "Reflexion und Integration für den Alltag"
    ]
  },
  {
    title: "Grenzen-Kompetenz Coaching",
    description:
      "Ein Training, das Grenzen als kraftvolle, verbindende Elemente etabliert. Wir erarbeiten individuelle Grenzenprofile und konkrete Kommunikationsstrategien.",
    points: [
      "Persönliche Grenzen erkennen und benennen",
      "Wertschätzendes Nein-Sagen üben",
      "Grenzverletzungen reparieren"
    ]
  },
  {
    title: "Intensive Retreats",
    description:
      "Mehrere Tage intensiver Begleitung in einem geschützten Rahmen. Fokus auf neue Rituale, tiefes Verständnis und gemeinsame Visionen.",
    points: [
      "Tagesstruktur mit Tiefenarbeit und Integration",
      "Körperorientierte Methoden für Regulation",
      "Transferpläne für den Alltag"
    ]
  }
];

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Leistungen | Kommunikation & Grenzen bei Raventolira</title>
        <meta
          name="description"
          content="Erkunden Sie die Leistungen von Raventolira: Paar-Dialog Sessions, Grenzen-Kompetenz Coaching und intensive Retreats für gesunde Kommunikation."
        />
        <link rel="canonical" href="https://www.raventolira.de/kommunikations-beratung" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.eyebrow}>Leistungen</span>
          <h1>Kommunikationsräume, die Klarheit ermöglichen</h1>
          <p>
            Unsere Angebote verbinden achtsame Moderation, tiefe Reflexion und praxisnahe Übungen. Jedes Format ist auf Paare zugeschnitten, die gesunde Grenzen leben wollen.
          </p>
        </div>
      </section>

      <section className={styles.servicesSection}>
        {serviceDetails.map((service) => (
          <article key={service.title} className={styles.serviceCard}>
            <div className={styles.serviceHeader}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
            </div>
            <ul>
              {service.points.map((point) => (
                <li key={point}>{point}</li>
              ))}
            </ul>
          </article>
        ))}
      </section>

      <section className={styles.methodsSection}>
        <div className={styles.methodsContent}>
          <h2>Methoden, die Verbindung und Autonomie vereinen</h2>
          <p>
            Wir kombinieren systemische Fragen, Übungen aus der Achtsamkeit sowie körperorientierte Tools. So wird Kommunikation nicht nur gedacht, sondern erlebt und integriert.
          </p>
        </div>
        <div className={styles.methodsGrid}>
          <div>
            <h3>Sicherheit schaffen</h3>
            <p>Check-ins, klare Strukturen und Co-Regulation sorgen für einen Raum, in dem beide sprechen können.</p>
          </div>
          <div>
            <h3>Klarheit gewinnen</h3>
            <p>Wir übersetzen Emotionen in klare Ich-Botschaften, reflektieren Muster und schaffen neue Entscheidungsspielräume.</p>
          </div>
          <div>
            <h3>Üben & verankern</h3>
            <p>Zwischen den Sitzungen begleiten Worksheets, Mikro-Übungen und Reflexionen den Transfer in den Alltag.</p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;