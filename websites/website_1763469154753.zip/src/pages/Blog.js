import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Blog.module.css";

const posts = [
  {
    id: 1,
    title: "Grenzen proaktiv kommunizieren",
    excerpt: "Wie das Gespräch beginnt, bevor es schwierig wird: präventive Dialoge planen und gestalten.",
    date: "25. Juni 2024"
  },
  {
    id: 2,
    title: "Atem und Stimme in Konflikten nutzen",
    excerpt: "Die Verbindung von Körperarbeits-Tools und klarer Sprache im Streitmoment.",
    date: "11. Mai 2024"
  },
  {
    id: 3,
    title: "Mikro-Momente der Wertschätzung",
    excerpt: "Warum kleine Zeichen großen Einfluss auf Beziehungsqualität haben.",
    date: "20. April 2024"
  }
];

const Blog = () => {
  return (
    <>
      <Helmet>
        <title>Blog | Impulse für Kommunikation & Grenzen</title>
        <meta
          name="description"
          content="Lesen Sie Impulse und Reflexionen rund um gesunde Kommunikation, Grenzenkompetenz und Paarentwicklung von Raventolira."
        />
        <link rel="canonical" href="https://www.raventolira.de/blog" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.eyebrow}>Blog</span>
          <h1>Impulse für klare Dialoge und lebendige Beziehungen</h1>
          <p>
            Unser Blog bietet praxisnahe Artikel zu Kommunikation, Grenzenkompetenz und emotionalem Austausch. Inspiration für Paare, die bewusst gestalten wollen.
          </p>
        </div>
      </section>

      <section className={styles.postsSection}>
        <div className={styles.postsGrid}>
          {posts.map((post) => (
            <article key={post.id}>
              <span className={styles.date}>{post.date}</span>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <button className={styles.readMore} aria-label={`Mehr zum Beitrag ${post.title}`}>
                Beitrag bald verfügbar
              </button>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Blog;