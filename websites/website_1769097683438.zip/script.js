document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.site-nav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navToggle.classList.toggle('open');
      primaryNav.classList.toggle('open');
    });

    primaryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 900 && primaryNav.classList.contains('open')) {
          navToggle.click();
        }
      });
    });
  }

  const revealElements = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.18 });

    revealElements.forEach(element => revealObserver.observe(element));
  } else {
    revealElements.forEach(element => element.classList.add('visible'));
  }

  const cookieBanner = document.getElementById('cookieBanner');
  const cookieKey = 'aahp_cookie_choice';

  if (cookieBanner) {
    const storedChoice = window.localStorage.getItem(cookieKey);
    if (!storedChoice) {
      cookieBanner.classList.add('active');
    }

    cookieBanner.querySelectorAll('button[data-choice]').forEach(button => {
      button.addEventListener('click', () => {
        const choice = button.getAttribute('data-choice');
        window.localStorage.setItem(cookieKey, choice);
        cookieBanner.classList.remove('active');
      });
    });
  }

  const forms = document.querySelectorAll('form');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const toast = ensureToast();
      const action = form.getAttribute('action') || 'thank-you.html';
      toast.textContent = 'Details received. Redirecting...';
      toast.classList.add('visible');
      setTimeout(() => {
        toast.classList.remove('visible');
        window.location.href = action;
      }, 1100);
    });
  });

  function ensureToast() {
    let toast = document.getElementById('formToast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'formToast';
      toast.className = 'form-toast';
      toast.setAttribute('role', 'status');
      toast.setAttribute('aria-live', 'assertive');
      document.body.appendChild(toast);
    }
    return toast;
  }
});