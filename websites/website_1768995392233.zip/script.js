document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      primaryNav.classList.toggle('is-open');
      body.classList.toggle('nav-open');
    });

    primaryNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          navToggle.setAttribute('aria-expanded', 'false');
          primaryNav.classList.remove('is-open');
          body.classList.remove('nav-open');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('.cookie-accept');
  const declineBtn = document.querySelector('.cookie-decline');

  const consentKey = 'northlyx_cookie_consent';
  if (cookieBanner && acceptBtn && declineBtn) {
    const storedConsent = localStorage.getItem(consentKey);
    if (storedConsent) {
      cookieBanner.hidden = true;
    }

    acceptBtn.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'accepted');
      cookieBanner.hidden = true;
    });

    declineBtn.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'declined');
      cookieBanner.hidden = true;
    });
  }

  const canvas = document.getElementById('signal-canvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    const pulseCount = 18;
    const pulses = [];

    const resizeCanvas = () => {
      const parent = canvas.parentElement;
      const size = parent.offsetWidth;
      canvas.width = size;
      canvas.height = size;
    };

    const initPulses = () => {
      pulses.length = 0;
      for (let i = 0; i < pulseCount; i += 1) {
        pulses.push({
          radius: Math.random() * (canvas.width / 2),
          maxRadius: canvas.width / 2,
          speed: 0.25 + Math.random() * 0.7,
          alpha: 0.1 + Math.random() * 0.35,
        });
      }
    };

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.translate(canvas.width / 2, canvas.height / 2);

      ctx.strokeStyle = 'rgba(56, 189, 248, 0.25)';
      ctx.lineWidth = 1;
      const rings = 6;
      for (let r = 1; r <= rings; r += 1) {
        ctx.beginPath();
        ctx.arc(0, 0, (canvas.width / 2) * (r / rings), 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.strokeStyle = 'rgba(168, 85, 247, 0.25)';
      ctx.setLineDash([8, 6]);
      ctx.beginPath();
      ctx.arc(0, 0, canvas.width / 3, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      pulses.forEach((pulse) => {
        ctx.beginPath();
        ctx.strokeStyle = `rgba(34, 197, 94, ${pulse.alpha})`;
        ctx.lineWidth = 2;
        ctx.arc(0, 0, pulse.radius, 0, Math.PI * 2);
        ctx.stroke();

        pulse.radius += pulse.speed;
        if (pulse.radius > pulse.maxRadius) {
          pulse.radius = 0;
          pulse.alpha = 0.1 + Math.random() * 0.35;
        }
      });

      ctx.setTransform(1, 0, 0, 1, 0, 0);
      requestAnimationFrame(draw);
    };

    resizeCanvas();
    initPulses();
    draw();
    window.addEventListener('resize', () => {
      resizeCanvas();
      initPulses();
    });
  }

  const layerToggles = document.querySelectorAll('.layer-toggle');
  const layerGroups = document.querySelectorAll('[data-layer]');
  if (layerToggles.length > 0) {
    layerToggles.forEach((toggle) => {
      toggle.addEventListener('click', () => {
        const target = toggle.getAttribute('data-target');
        layerToggles.forEach((btn) => btn.classList.toggle('is-active', btn === toggle));
        layerGroups.forEach((group) => {
          if (group.getAttribute('data-layer') === target || target === 'all') {
            group.style.opacity = '1';
          } else {
            group.style.opacity = '0.18';
          }
        });
      });
    });
  }

  const redirectMap = {
    '/history': '/archives.html',
    '/history/': '/archives.html',
    '/infrastructure': '/maps.html',
    '/infrastructure/': '/maps.html',
    '/systems': '/signals.html',
    '/systems/': '/signals.html',
    '/resilience': '/contexts.html',
    '/resilience/': '/contexts.html'
  };

  const currentPath = window.location.pathname.replace(/index\.html$/, '/');
  if (redirectMap[currentPath]) {
    window.location.replace(redirectMap[currentPath]);
  }
});