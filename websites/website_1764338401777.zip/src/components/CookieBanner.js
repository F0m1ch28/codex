import React, { useEffect, useState } from 'react';
import styles from '../styles/CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const [choice, setChoice] = useState(() => localStorage.getItem('cookie-choice'));

  useEffect(() => {
    if (!choice) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, [choice]);

  const handleChoice = (value) => {
    setChoice(value);
    localStorage.setItem('cookie-choice', value);
    setVisible(false);
  };

  if (!visible || choice) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          We use cookies to improve performance, personalize language settings, and understand engagement. You can
          update preferences at any time.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={() => handleChoice('accepted')}>
            Accept
          </button>
          <button type="button" onClick={() => handleChoice('declined')}>
            Decline
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;