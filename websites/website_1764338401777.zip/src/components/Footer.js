import React, { useContext, useState } from 'react';
import { Link } from 'react-router-dom';
import { LanguageContext } from '../context/LanguageContext';
import styles from '../styles/Footer.module.css';

const Footer = () => {
  const { t } = useContext(LanguageContext);
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState(null);

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) {
      setStatus('error');
      return;
    }
    setStatus('success');
    setEmail('');
  };

  return (
    <footer className={styles.footer} id="footer">
      <div className={styles.container}>
        <div className={styles.about}>
          <h2>Tu Progreso Hoy</h2>
          <p>{t.footer.description}</p>
          <p className={styles.tagline}>
            Análisis transparentes y datos de mercado para decidir con seguridad.
          </p>
          <address className={styles.contactBlock}>
            <span>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</span>
            <a href="tel:+541155551234">+54 11 5555-1234</a>
            <a href="mailto:info@tuprogresohoy.com">info@tuprogresohoy.com</a>
          </address>
        </div>
        <div className={styles.links}>
          <div>
            <h3>{t.footer.resources}</h3>
            <ul>
              <li>
                <Link to="/inflation">Inflation Dashboard</Link>
              </li>
              <li>
                <Link to="/course">Course Overview</Link>
              </li>
              <li>
                <Link to="/resources">Resource Library</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3>{t.footer.company}</h3>
            <ul>
              <li>
                <Link to="/about">About Tu Progreso Hoy</Link>
              </li>
              <li>
                <Link to="/services">Services</Link>
              </li>
              <li>
                <Link to="/contact">Request a walkthrough</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3>{t.footer.legal}</h3>
            <ul>
              <li>
                <Link to="/terms">Terms of Service</Link>
              </li>
              <li>
                <Link to="/privacy">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/cookies">Cookie Policy</Link>
              </li>
            </ul>
          </div>
        </div>
        <div className={styles.newsletter}>
          <h3>{t.footer.newsletterTitle}</h3>
          <p>{t.footer.newsletterNote}</p>
          <form onSubmit={handleSubmit} className={styles.form}>
            <label htmlFor="newsletter-email" className="sr-only">
              Email
            </label>
            <input
              id="newsletter-email"
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder={t.footer.newsletterPlaceholder}
              required
            />
            <button type="submit">{t.footer.newsletterButton}</button>
          </form>
          {status === 'error' && (
            <p className={styles.feedback} role="alert">
              Please provide a valid email to continue.
            </p>
          )}
          {status === 'success' && (
            <p className={styles.feedbackSuccess} role="status">
              Thank you! Check your inbox to confirm the subscription.
            </p>
          )}
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© {new Date().getFullYear()} Tu Progreso Hoy. {t.footer.rights}</p>
        <p className={styles.disclaimer}>Plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
      </div>
    </footer>
  );
};

export default Footer;