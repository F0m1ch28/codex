import React, { useMemo, useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import InflationPage from './pages/InflationPage';
import CoursePage from './pages/CoursePage';
import ResourcesPage from './pages/ResourcesPage';
import ThankYouPage from './pages/ThankYouPage';
import PrivacyPolicy from './pages/PrivacyPolicy';
import CookiePolicy from './pages/CookiePolicy';
import TermsOfService from './pages/TermsOfService';
import NotFound from './pages/NotFound';
import { LanguageContext } from './context/LanguageContext';
import translations from './i18n/translations';

function App() {
  const [language, setLanguage] = useState('en');

  useEffect(() => {
    document.documentElement.setAttribute('lang', language === 'en' ? 'en' : 'es-AR');
  }, [language]);

  const contextValue = useMemo(
    () => ({
      language,
      setLanguage,
      t: translations[language]
    }),
    [language]
  );

  return (
    <LanguageContext.Provider value={contextValue}>
      <Router>
        <Helmet>
          <link rel="alternate" href="https://tuprogresohoy.com/" hrefLang="en" />
          <link rel="alternate" href="https://tuprogresohoy.com/" hrefLang="es-AR" />
          <meta name="author" content="Tu Progreso Hoy" />
        </Helmet>
        <Header />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/inflation" element={<InflationPage />} />
            <Route path="/course" element={<CoursePage />} />
            <Route path="/resources" element={<ResourcesPage />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/thank-you" element={<ThankYouPage />} />
            <Route path="/privacy" element={<PrivacyPolicy />} />
            <Route path="/cookies" element={<CookiePolicy />} />
            <Route path="/terms" element={<TermsOfService />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <ScrollToTop />
      </Router>
    </LanguageContext.Provider>
  );
}

export default App;