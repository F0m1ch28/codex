const translations = {
  en: {
    nav: {
      home: 'Home',
      about: 'About',
      services: 'Services',
      inflation: 'Inflation Insights',
      course: 'Course',
      resources: 'Resources',
      contact: 'Contact'
    },
    hero: {
      title: 'Plan smarter with Argentina’s trusted inflation intelligence.',
      subtitle: 'Real-time ARS to USD monitoring and a guided personal finance course built for resilient decisions.',
      ctaPrimary: 'Explore Live Inflation Data',
      ctaSecondary: 'Preview the Course'
    },
    stats: [
      { label: 'Market Signals Reviewed Monthly', value: 240 },
      { label: 'Learners across Argentina', value: 3800 },
      { label: 'Interactive Micro-lessons', value: 18 }
    ],
    servicesIntro: 'Insights and learning aligned with your financial objectives.',
    services: [
      {
        title: 'Macro Pulse Dashboard',
        description: 'Daily ARS to USD indicators, inflation forecasts, and context-rich narratives.'
      },
      {
        title: 'Personal Finance Playbook',
        description: 'Step-by-step lessons covering budgeting, savings cushions, and mindful currency planning.'
      },
      {
        title: 'Scenario Builder',
        description: 'Simulate monthly expenses in ARS with USD exposure to anticipate short-term moves.'
      }
    ],
    process: [
      'Capture verified data streams focused on Argentina.',
      'Transform signals into insights you can apply immediately.',
      'Guide you through lessons that strengthen judgment.',
      'Track progress and refine your plan with clarity.'
    ],
    testimonials: [
      {
        quote:
          'The inflation tracker keeps me grounded in facts, while the course makes the decisions digestible.',
        name: 'Valentina R.',
        role: 'Marketing Analyst, Córdoba'
      },
      {
        quote:
          'I finally understand how to compare ARS budgets with USD obligations without feeling lost.',
        name: 'Emilio G.',
        role: 'Freelance Designer, Mendoza'
      },
      {
        quote:
          'The blend of data and education respects my time and gives me confidence in every peso I manage.',
        name: 'Lucía P.',
        role: 'HR Specialist, Buenos Aires'
      }
    ],
    teamHighlight: 'Guided by economists, educators, and technologists from Argentina.',
    faq: [
      {
        question: 'How frequently is the ARS to USD data refreshed?',
        answer:
          'We refresh official and market-referenced indicators multiple times per day and flag updates in the dashboard timeline.'
      },
      {
        question: 'Is Tu Progreso Hoy providing financial advice?',
        answer:
          'No. Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
      },
      {
        question: 'Can I access materials in both English and Spanish?',
        answer:
          'Yes, you can toggle languages across the platform. Video captions, templates, and dashboards adapt instantly.'
      },
      {
        question: 'What is included in the free trial lesson?',
        answer:
          'You receive a guided walkthrough of the ARS to USD tracker, a budgeting worksheet, and the first micro-lesson on inflation fundamentals.'
      }
    ],
    blogTitle: 'Latest Insights',
    blogPosts: [
      {
        title: 'Inflation Watch: Signals that matter for Q1 households',
        excerpt:
          'We unpack seasonal price movements, how to follow the blue chip swap, and why focusing on core categories keeps your plan realistic.',
        date: 'January 2024'
      },
      {
        title: 'Designing a resilient ARS budget with USD liabilities',
        excerpt:
          'Learn a practical flow to allocate essentials, savings buffers, and FX exposure without losing track of priorities.',
        date: 'December 2023'
      },
      {
        title: 'From data to decisions: Weekly routines to stay informed',
        excerpt:
          'Discover a 20-minute cadence using our dashboards and course prompts to keep decision fatigue at bay.',
        date: 'November 2023'
      }
    ],
    ctaSection: {
      title: 'Stay ahead with trustworthy inflation intelligence.',
      description:
        'Decisiones responsables, objetivos nítidos. Conocimiento financiero impulsado por tendencias.'
    },
    footer: {
      description:
        'Análisis transparentes y datos de mercado para decidir con seguridad. Información confiable que respalda elecciones responsables sobre tu dinero.',
      resources: 'Resources',
      company: 'Company',
      legal: 'Legal',
      newsletterTitle: 'Get the weekly digest',
      newsletterPlaceholder: 'Your email address',
      newsletterButton: 'Subscribe',
      newsletterNote: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
      rights: 'All rights reserved.'
    },
    contact: {
      title: 'Let’s build your financial resilience roadmap.',
      description:
        'Share your needs and we will tailor a walkthrough of the platform, the ARS to USD dashboard, and the personal finance curriculum.',
      name: 'Full name',
      email: 'Email address',
      phone: 'Phone number',
      message: 'How can we help?',
      submit: 'Send message',
      success: 'Thank you. Please confirm your subscription through the email we sent.',
      error: 'Please complete the required fields with valid information.'
    },
    thankYou: {
      title: 'Check your inbox for confirmation.',
      description:
        'We sent a verification email to complete the double opt-in. Once confirmed, you will receive the trial lesson and live dashboard tour.',
      backHome: 'Return to homepage'
    },
    coursePage: {
      title: 'Personal Finance Course for Argentina: build strong habits with context.',
      intro:
        'De la información al aprendizaje: fortalece tu criterio financiero paso a paso. Each module combines data-driven insight with actionable routines.',
      modules: [
        {
          title: 'Module 1 · Inflation Foundations',
          lessons: [
            'Understanding ARS price indices and market signals',
            'How FX markets influence everyday decisions',
            'Datos verificados para planificar tu presupuesto.'
          ]
        },
        {
          title: 'Module 2 · Budgeting with Currency Awareness',
          lessons: [
            'Mapping income streams to expenses in mixed currencies',
            'Scenario planning for 3, 6, and 12 months',
            'Pasos acertados hoy, mejor futuro mañana.'
          ]
        },
        {
          title: 'Module 3 · Savings and Emergency Buffers',
          lessons: [
            'Estimating buffer goals tied to inflation variance',
            'Choosing instruments aligned with your risk tolerance',
            'Decisiones responsables, objetivos nítidos.'
          ]
        },
        {
          title: 'Module 4 · Adaptive Planning',
          lessons: [
            'Monthly review checklist using our dashboards',
            'Tracking progress and adjusting priorities with data',
            'Conocimiento financiero impulsado por tendencias.'
          ]
        }
      ],
      cta: 'Enroll and access the dashboard'
    },
    resourcesPage: {
      title: 'Resource Library',
      intro:
        'Curated templates, reports, and workshops to support every learner on Tu Progreso Hoy.',
      items: [
        {
          title: 'ARS vs USD Monthly Tracker Template',
          description: 'Excel and Google Sheets templates to record expenses and savings in blended currencies.',
          type: 'Template'
        },
        {
          title: 'Household Inflation Briefing',
          description: 'A monthly digest covering price movements in key categories with contextual commentary.',
          type: 'Report'
        },
        {
          title: 'Live Workshop: Budgeting Amid Volatility',
          description: 'Join our educators for scenario planning and hands-on exercises tailored to Argentina’s context.',
          type: 'Workshop'
        }
      ]
    },
    inflationPage: {
      title: 'Argentina Inflation & ARS to USD Insights',
      intro:
        'Plataforma educativa con datos esenciales, sin asesoría financiera directa. Stay informed with transparent metrics, narrative context, and actionable prompts.',
      tableTitle: 'Key Indicators',
      columns: ['Indicator', 'Latest Value', 'Change', 'Updated'],
      notes: [
        'We source data from reputable public and private entities, validating each update.',
        'Historical trends illustrate monthly shifts to equip you for near-term decisions.',
        'Our insights focus on clarity without speculation. Información confiable que respalda elecciones responsables sobre tu dinero.'
      ]
    },
    servicesPage: {
      title: 'Data and learning services for responsible financial progress.',
      intro:
        'Explore how Tu Progreso Hoy aligns insight delivery, educational content, and personalized guidance without crossing into financial advisory.',
      offerings: [
        {
          title: 'Inflation Intelligence',
          description: 'Real-time dashboards, annotated highlights, and scenario alerts focused on ARS to USD movements.',
          benefits: ['Real-time feed', 'Weekly summaries', 'Downloadable datasets']
        },
        {
          title: 'Financial Learning Journeys',
          description: 'Flexible learning paths blending video, interactive quizzes, and guided worksheets.',
          benefits: ['Bilingual content', 'Mobile-first lessons', 'Progress dashboards']
        },
        {
          title: 'Team Enablement',
          description: 'Enable your organization with workshops, dedicated office hours, and impact reporting.',
          benefits: ['Custom workshops', 'Team analytics', 'Quarterly alignment sessions']
        }
      ]
    },
    aboutPage: {
      title: 'Our mission: empower Argentina with clarity and confidence.',
      vision:
        'We built Tu Progreso Hoy to bridge the gap between fast-changing economic data and the practical decisions households and professionals make each day.',
      pillars: [
        'Data integrity first: every data point is double-checked before it reaches your dashboard.',
        'Education that respects your time: short lessons with measurable outcomes.',
        'Community accountability: we learn with our members to evolve responsibly.'
      ],
      timeline: [
        { year: '2021', milestone: 'Founded in Buenos Aires to simplify inflation monitoring for households.' },
        { year: '2022', milestone: 'Launched the bilingual personal finance course with 5,000 early learners.' },
        { year: '2023', milestone: 'Introduced scenario builder and organizational enablement programs.' }
      ],
      teamTitle: 'Leadership Team',
      teamIntro: 'Our team blends macroeconomic analysis, data science, and instructional design.',
      roles: ['Chief Economist', 'Head of Learning Experience', 'Lead Data Scientist']
    },
    privacyPage: {
      title: 'Privacy Policy',
      updated: 'Last updated: January 2, 2024'
    },
    cookiePage: {
      title: 'Cookie Policy',
      intro:
        'We use cookies to understand engagement, improve performance, and remember your language preferences. You can adjust preferences at any time through the banner.'
    },
    termsPage: {
      title: 'Terms of Service',
      intro:
        'Please read these terms carefully before using Tu Progreso Hoy. By accessing the platform you agree to the rules outlined below.'
    },
    form: {
      required: 'This field is required.',
      invalidEmail: 'Enter a valid email address.',
      consentLabel: 'I agree to receive emails and understand I must confirm via the follow-up email.',
      consentError: 'Please agree to the consent requirement to proceed.'
    },
    languageToggle: 'ES',
    projects: [
      {
        category: 'Household',
        title: 'Family Budget Navigator',
        description: 'Combined ARS expense data with USD obligations to recommend balanced monthly adjustments.'
      },
      {
        category: 'SMB',
        title: 'SMB Cash Flow Tracker',
        description: 'Mapped supplier costs against FX trends to support timely invoice planning.'
      },
      {
        category: 'Household',
        title: 'Savings Buffer Planner',
        description: 'Guided households to define emergency funds indexed to inflation scenarios.'
      },
      {
        category: 'Public Sector',
        title: 'Municipal Insight Brief',
        description: 'Delivered accessible inflation reports for community awareness campaigns.'
      }
    ]
  },
  es: {
    nav: {
      home: 'Inicio',
      about: 'Quiénes somos',
      services: 'Servicios',
      inflation: 'Indicadores de inflación',
      course: 'Curso',
      resources: 'Recursos',
      contact: 'Contacto'
    },
    hero: {
      title: 'Planificá con inteligencia los movimientos de la inflación argentina.',
      subtitle: 'Seguimiento ARS a USD en tiempo real y un curso de finanzas personales para decisiones responsables.',
      ctaPrimary: 'Ver datos en vivo',
      ctaSecondary: 'Conocer el curso'
    },
    stats: [
      { label: 'Señales de mercado analizadas cada mes', value: 240 },
      { label: 'Personas aprendiendo en Argentina', value: 3800 },
      { label: 'Micro-lecciones interactivas', value: 18 }
    ],
    servicesIntro: 'Insights y aprendizaje alineados con tus objetivos financieros.',
    services: [
      {
        title: 'Macro Pulse Dashboard',
        description: 'Indicadores diarios ARS a USD, proyecciones de inflación y relatos con contexto.'
      },
      {
        title: 'Personal Finance Playbook',
        description: 'Lecciones paso a paso sobre presupuestos, fondos y planificación cambiaria.'
      },
      {
        title: 'Scenario Builder',
        description: 'Simulá gastos mensuales en ARS con exposición a USD para anticipar movimientos.'
      }
    ],
    process: [
      'Capturar datos verificados con foco en Argentina.',
      'Transformar señales en insights aplicables.',
      'Acompañarte con lecciones que fortalecen tu criterio.',
      'Medir avances y ajustar tu plan con claridad.'
    ],
    testimonials: [
      {
        quote:
          'El tracker de inflación me da hechos concretos y el curso me ayuda a decidir sin abrumarme.',
        name: 'Valentina R.',
        role: 'Analista de marketing, Córdoba'
      },
      {
        quote:
          'Ahora puedo comparar presupuestos en ARS con obligaciones en USD sin sentirme perdido.',
        name: 'Emilio G.',
        role: 'Diseñador freelance, Mendoza'
      },
      {
        quote:
          'La combinación de datos y educación respeta mi tiempo y me da confianza en cada peso.',
        name: 'Lucía P.',
        role: 'Especialista en RR.HH., Buenos Aires'
      }
    ],
    teamHighlight: 'Economistas, educadores y tecnólogos argentinos guiando cada paso.',
    faq: [
      {
        question: '¿Con qué frecuencia se actualiza el dato ARS a USD?',
        answer:
          'Refrescamos indicadores oficiales y de mercado varias veces por día y señalamos cada novedad en el timeline del panel.'
      },
      {
        question: '¿Tu Progreso Hoy brinda asesoría financiera?',
        answer:
          'No. Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
      },
      {
        question: '¿Puedo acceder al contenido en inglés y español?',
        answer:
          'Sí, podés cambiar el idioma en toda la plataforma. Videos, plantillas y paneles se adaptan al instante.'
      },
      {
        question: '¿Qué incluye la lección de prueba gratuita?',
        answer:
          'Un recorrido guiado por el tracker ARS a USD, una planilla de presupuesto y la primera micro-lección sobre inflación.'
      }
    ],
    blogTitle: 'Últimas novedades',
    blogPosts: [
      {
        title: 'Inflación en foco: señales clave para los hogares en Q1',
        excerpt:
          'Analizamos movimientos estacionales, seguimiento del contado con liquidación y por qué enfocarte en categorías base mantiene realista tu plan.',
        date: 'enero 2024'
      },
      {
        title: 'Diseñar un presupuesto ARS con obligaciones en USD',
        excerpt:
          'Aprendé un flujo práctico para repartir esenciales, fondo de reserva y exposición cambiaria sin perder prioridades.',
        date: 'diciembre 2023'
      },
      {
        title: 'De los datos a las decisiones: rutinas semanales para informarte',
        excerpt:
          'Descubrí una rutina de 20 minutos usando nuestros paneles y recordatorios del curso para evitar la fatiga decisional.',
        date: 'noviembre 2023'
      }
    ],
    ctaSection: {
      title: 'Adelantate con inteligencia confiable sobre inflación.',
      description:
        'Decisiones responsables, objetivos nítidos. Conocimiento financiero impulsado por tendencias.'
    },
    footer: {
      description:
        'Análisis transparentes y datos de mercado para decidir con seguridad. Información confiable que respalda elecciones responsables sobre tu dinero.',
      resources: 'Recursos',
      company: 'Compañía',
      legal: 'Legal',
      newsletterTitle: 'Recibí el resumen semanal',
      newsletterPlaceholder: 'Tu correo electrónico',
      newsletterButton: 'Suscribirme',
      newsletterNote: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
      rights: 'Todos los derechos reservados.'
    },
    contact: {
      title: 'Construyamos tu mapa de resiliencia financiera.',
      description:
        'Contanos qué necesitás y adaptamos un recorrido por la plataforma, el panel ARS a USD y el curso de finanzas personales.',
      name: 'Nombre completo',
      email: 'Correo electrónico',
      phone: 'Teléfono',
      message: '¿Cómo podemos ayudarte?',
      submit: 'Enviar mensaje',
      success: 'Gracias. Por favor confirmá tu suscripción desde el correo que enviamos.',
      error: 'Completá los campos requeridos con información válida.'
    },
    thankYou: {
      title: 'Revisá tu correo para confirmar.',
      description:
        'Te enviamos un correo de verificación para completar el doble opt-in. Una vez confirmado recibirás la lección de prueba y el tour del panel.',
      backHome: 'Volver al inicio'
    },
    coursePage: {
      title: 'Curso de finanzas personales para Argentina con contexto real.',
      intro:
        'De la información al aprendizaje: fortalece tu criterio financiero paso a paso. Cada módulo combina datos y prácticas aplicables.',
      modules: [
        {
          title: 'Módulo 1 · Fundamentos de inflación',
          lessons: [
            'Qué muestran los índices de precios y señales de mercado',
            'Cómo impacta el mercado cambiario en tus decisiones diarias',
            'Datos verificados para planificar tu presupuesto.'
          ]
        },
        {
          title: 'Módulo 2 · Presupuesto con mirada cambiaria',
          lessons: [
            'Mapa de ingresos y gastos en monedas mixtas',
            'Planificación de escenarios a 3, 6 y 12 meses',
            'Pasos acertados hoy, mejor futuro mañana.'
          ]
        },
        {
          title: 'Módulo 3 · Ahorro y fondos de emergencia',
          lessons: [
            'Cómo estimar buffers según la variación inflacionaria',
            'Elegir instrumentos acorde a tu tolerancia',
            'Decisiones responsables, objetivos nítidos.'
          ]
        },
        {
          title: 'Módulo 4 · Planificación adaptable',
          lessons: [
            'Checklist mensual usando nuestros paneles',
            'Medir avances y ajustar prioridades con datos',
            'Conocimiento financiero impulsado por tendencias.'
          ]
        }
      ],
      cta: 'Inscribirme y acceder al panel'
    },
    resourcesPage: {
      title: 'Biblioteca de recursos',
      intro:
        'Plantillas, informes y workshops diseñados para cada persona que aprende con Tu Progreso Hoy.',
      items: [
        {
          title: 'Plantilla mensual ARS vs USD',
          description: 'Archivos en Excel y Google Sheets para registrar gastos y ahorros en monedas combinadas.',
          type: 'Plantilla'
        },
        {
          title: 'Informe de inflación para hogares',
          description: 'Un digest mensual con movimientos de precios clave y comentarios con contexto.',
          type: 'Informe'
        },
        {
          title: 'Workshop en vivo: Presupuesto en volatilidad',
          description: 'Participá para trabajar escenarios y ejercicios prácticos adaptados a Argentina.',
          type: 'Workshop'
        }
      ]
    },
    inflationPage: {
      title: 'Inflación argentina y señales ARS a USD',
      intro:
        'Plataforma educativa con datos esenciales, sin asesoría financiera directa. Mantente informado con métricas transparentes, contexto narrativo y prompts aplicables.',
      tableTitle: 'Indicadores clave',
      columns: ['Indicador', 'Último valor', 'Variación', 'Actualizado'],
      notes: [
        'Obtenemos datos de fuentes públicas y privadas confiables, validando cada actualización.',
        'Las tendencias históricas muestran movimientos mensuales para ayudarte a tomar decisiones cercanas.',
        'Nuestros insights priorizan la claridad sin especulación. Información confiable que respalda elecciones responsables sobre tu dinero.'
      ]
    },
    servicesPage: {
      title: 'Servicios de datos y aprendizaje para tu progreso financiero responsable.',
      intro:
        'Conocé cómo Tu Progreso Hoy coordina entrega de insights, contenido educativo y acompañamiento personalizado sin brindar asesoría financiera.',
      offerings: [
        {
          title: 'Inteligencia de inflación',
          description: 'Paneles en tiempo real, highlights anotados y alertas de escenarios enfocados en ARS a USD.',
          benefits: ['Feed en tiempo real', 'Resumen semanal', 'Descarga de datasets']
        },
        {
          title: 'Trayectorias de aprendizaje financiero',
          description: 'Rutas flexibles con videos, quizzes interactivos y planillas guiadas.',
          benefits: ['Contenido bilingüe', 'Lecciones mobile-first', 'Panel de progreso']
        },
        {
          title: 'Enablement para equipos',
          description: 'Capacitaciones, horas de consulta dedicadas e informes de impacto.',
          benefits: ['Workshops a medida', 'Analítica por equipo', 'Sesiones trimestrales']
        }
      ]
    },
    aboutPage: {
      title: 'Nuestra misión: claridad y confianza para Argentina.',
      vision:
        'Creamos Tu Progreso Hoy para cerrar la brecha entre datos económicos cambiantes y las decisiones cotidianas de hogares y profesionales.',
      pillars: [
        'Integridad de datos primero: cada indicador se verifica antes de llegar a tu panel.',
        'Educación que respeta tu tiempo: lecciones breves con resultados medibles.',
        'Comunidad responsable: aprendemos junto a quienes nos eligen para evolucionar con sentido.'
      ],
      timeline: [
        { year: '2021', milestone: 'Fundamos la plataforma en Buenos Aires para simplificar el seguimiento de inflación.' },
        { year: '2022', milestone: 'Lanzamos el curso bilingüe de finanzas personales con 5.000 estudiantes piloto.' },
        { year: '2023', milestone: 'Sumamos el scenario builder y programas de enablement para organizaciones.' }
      ],
      teamTitle: 'Equipo líder',
      teamIntro: 'Mezclamos análisis macro, ciencia de datos y diseño instruccional.',
      roles: ['Economista Jefe', 'Directora de Learning Experience', 'Data Scientist Líder']
    },
    privacyPage: {
      title: 'Política de privacidad',
      updated: 'Última actualización: 2 de enero de 2024'
    },
    cookiePage: {
      title: 'Política de cookies',
      intro:
        'Utilizamos cookies para entender el uso de la plataforma, mejorar el rendimiento y recordar tus preferencias de idioma. Podés ajustar la configuración desde el banner en cualquier momento.'
    },
    termsPage: {
      title: 'Términos y condiciones',
      intro:
        'Leé con atención estos términos antes de usar Tu Progreso Hoy. Al acceder aceptás las reglas detalladas a continuación.'
    },
    form: {
      required: 'Campo obligatorio.',
      invalidEmail: 'Ingresá un correo válido.',
      consentLabel: 'Acepto recibir correos y sé que debo confirmar desde el mail de seguimiento.',
      consentError: 'Debes aceptar la casilla de consentimiento para continuar.'
    },
    languageToggle: 'EN',
    projects: [
      {
        category: 'Hogar',
        title: 'Navegador de presupuesto familiar',
        description: 'Combinamos gastos en ARS con obligaciones en USD para recomendar ajustes mensuales equilibrados.'
      },
      {
        category: 'PyME',
        title: 'Tracker de flujo de fondos',
        description: 'Mapeamos costos de proveedores frente a tendencias cambiarias para planificar pagos a tiempo.'
      },
      {
        category: 'Hogar',
        title: 'Planificador de fondo de emergencia',
        description: 'Guiamos a los hogares para definir fondos indexados a escenarios inflacionarios.'
      },
      {
        category: 'Sector público',
        title: 'Informe municipal de insights',
        description: 'Entregamos reportes de inflación accesibles para campañas de concientización.'
      }
    ]
  }
};

export default translations;