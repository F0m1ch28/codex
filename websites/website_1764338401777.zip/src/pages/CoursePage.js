import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '../context/LanguageContext';
import styles from '../styles/Course.module.css';

const CoursePage = () => {
  const { t } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>Course | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Explore Tu Progreso Hoy's personal finance course for Argentina. Data-backed lessons, bilingual content, and actionable routines."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.text}>
          <h1>{t.coursePage.title}</h1>
          <p>{t.coursePage.intro}</p>
          <a href="/contact" className={styles.heroButton}>
            {t.coursePage.cta}
          </a>
        </div>
        <img
          src="https://picsum.photos/1200/800?random=1002"
          alt="Learner reviewing personal finance course modules"
          loading="lazy"
        />
      </section>
      <section className={styles.modules}>
        {t.coursePage.modules.map((module) => (
          <article key={module.title} className={styles.moduleCard}>
            <h2>{module.title}</h2>
            <ul>
              {module.lessons.map((lesson) => (
                <li key={lesson}>{lesson}</li>
              ))}
            </ul>
          </article>
        ))}
      </section>
      <section className={styles.benefits}>
        <div>
          <h2>{t.languageToggle === 'ES' ? 'What you gain' : 'Lo que obtenés'}</h2>
          <ul>
            <li>{t.languageToggle === 'ES'
              ? 'Guided explanations that connect inflation data with personal budgets.'
              : 'Explicaciones guiadas que conectan datos de inflación con tu presupuesto.'}</li>
            <li>{t.languageToggle === 'ES'
              ? 'Templates and trackers aligned with ARS and USD scenarios.'
              : 'Plantillas y trackers alineados con escenarios ARS y USD.'}</li>
            <li>{t.languageToggle === 'ES'
              ? 'Community sessions for questions and accountability.'
              : 'Sesiones comunitarias para preguntas y accountability.'}</li>
          </ul>
        </div>
        <div className={styles.card}>
          <h3>{t.languageToggle === 'ES' ? 'Format' : 'Formato'}</h3>
          <p>{t.languageToggle === 'ES'
            ? 'Video lessons, interactive activities, downloadable tools, and live Q&A.'
            : 'Video lessons, actividades interactivas, herramientas descargables y Q&A en vivo.'}</p>
        </div>
      </section>
    </>
  );
};

export default CoursePage;