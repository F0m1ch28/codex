import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '../context/LanguageContext';
import styles from '../styles/About.module.css';

const About = () => {
  const { t } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>About Tu Progreso Hoy | Mission and Team</title>
        <meta
          name="description"
          content="Discover the mission, values, and team behind Tu Progreso Hoy. We transform Argentina inflation data into learning experiences for responsible decisions."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.text}>
          <h1>{t.aboutPage.title}</h1>
          <p>{t.aboutPage.vision}</p>
        </div>
        <img
          src="https://picsum.photos/1200/800?random=501"
          alt="Team collaborating on financial insights"
          loading="lazy"
        />
      </section>
      <section className={styles.pillars}>
        <h2>{t.aboutPage.teamIntro}</h2>
        <div className={styles.pillarGrid}>
          {t.aboutPage.pillars.map((pillar) => (
            <article key={pillar} className={styles.pillarCard}>
              <p>{pillar}</p>
            </article>
          ))}
        </div>
      </section>
      <section className={styles.timeline}>
        <h2>{t.aboutPage.teamTitle}</h2>
        <div className={styles.timelineGrid}>
          {t.aboutPage.timeline.map((item) => (
            <div key={item.year} className={styles.timelineItem}>
              <span className={styles.year}>{item.year}</span>
              <p>{item.milestone}</p>
            </div>
          ))}
        </div>
      </section>
      <section className={styles.team}>
        <div className={styles.teamGrid}>
          {[
            {
              name: 'Martina López',
              role: t.aboutPage.roles[0],
              img: 'https://picsum.photos/400/400?random=604'
            },
            {
              name: 'Diego Fernández',
              role: t.aboutPage.roles[1],
              img: 'https://picsum.photos/400/400?random=605'
            },
            {
              name: 'Sofía Alvarez',
              role: t.aboutPage.roles[2],
              img: 'https://picsum.photos/400/400?random=606'
            }
          ].map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.img} alt={`${member.name} - ${member.role}`} loading="lazy" />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default About;