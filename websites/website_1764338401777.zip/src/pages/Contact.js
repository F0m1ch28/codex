import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '../context/LanguageContext';
import styles from '../styles/Contact.module.css';

const Contact = () => {
  const { t, language } = useContext(LanguageContext);
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
    consent: false
  });
  const [errors, setErrors] = useState({});
  const [formStatus, setFormStatus] = useState(null);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setForm((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) {
      newErrors.name = t.form.required;
    }
    if (!form.email.trim()) {
      newErrors.email = t.form.required;
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = t.form.invalidEmail;
    }
    if (!form.message.trim()) {
      newErrors.message = t.form.required;
    }
    if (!form.consent) {
      newErrors.consent = t.form.consentError;
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setFormStatus('success');
      navigate('/thank-you', { replace: true });
    } else {
      setFormStatus('error');
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Contact Tu Progreso Hoy for a personalized walkthrough of our inflation insights and personal finance learning platform."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.text}>
          <h1>{t.contact.title}</h1>
          <p>{t.contact.description}</p>
        </div>
        <img
          src="https://picsum.photos/1000/700?random=801"
          alt="Professional consultation with financial data"
          loading="lazy"
        />
      </section>
      <section className={styles.formSection}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="contact-name">{t.contact.name}</label>
            <input
              id="contact-name"
              name="name"
              type="text"
              value={form.name}
              onChange={handleChange}
              required
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="contact-email">{t.contact.email}</label>
            <input
              id="contact-email"
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              required
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="contact-phone">{t.contact.phone}</label>
            <input
              id="contact-phone"
              name="phone"
              type="tel"
              value={form.phone}
              onChange={handleChange}
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="contact-message">{t.contact.message}</label>
            <textarea
              id="contact-message"
              name="message"
              rows="5"
              value={form.message}
              onChange={handleChange}
              required
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </div>
          <div className={styles.checkbox}>
            <input
              id="contact-consent"
              name="consent"
              type="checkbox"
              checked={form.consent}
              onChange={handleChange}
            />
            <label htmlFor="contact-consent">{t.form.consentLabel}</label>
          </div>
          {errors.consent && <span className={styles.error}>{errors.consent}</span>}
          <button type="submit" className={styles.submitButton}>
            {t.contact.submit}
          </button>
          {formStatus === 'error' && (
            <p className={styles.formFeedback}>{t.contact.error}</p>
          )}
        </form>
        <div className={styles.contactInfo}>
          <h2>{language === 'en' ? 'Reach us directly' : 'Contactanos directo'}</h2>
          <ul>
            <li>
              <strong>Email:</strong> <a href="mailto:info@tuprogresohoy.com">info@tuprogresohoy.com</a>
            </li>
            <li>
              <strong>Phone:</strong> <a href="tel:+541155551234">+54 11 5555-1234</a>
            </li>
            <li>
              <strong>Address:</strong> Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
            </li>
          </ul>
          <div className={styles.highlights}>
            <p>Información confiable que respalda elecciones responsables sobre tu dinero.</p>
            <p>Conocimiento financiero impulsado por tendencias.</p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;