import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from '../styles/NotFound.module.css';

const NotFound = () => (
  <>
    <Helmet>
      <title>Page Not Found | Tu Progreso Hoy</title>
      <meta
        name="description"
        content="The page you are looking for cannot be found. Return to Tu Progreso Hoy homepage for inflation insights and finance learning."
      />
    </Helmet>
    <section className={styles.section}>
      <h1>404</h1>
      <p>The page you are looking for was moved or does not exist.</p>
      <Link to="/" className={styles.button}>
        Back to homepage
      </Link>
    </section>
  </>
);

export default NotFound;