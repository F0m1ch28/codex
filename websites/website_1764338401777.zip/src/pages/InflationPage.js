import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '../context/LanguageContext';
import styles from '../styles/Inflation.module.css';

const indicators = [
  { indicator: 'Official CPI YoY', value: '211.4%', change: '+3.1%', update: '2024-01-15' },
  { indicator: 'Blue Chip Swap Rate', value: 'ARS 1180', change: '-1.6%', update: '2024-01-16' },
  { indicator: 'Wholesale Price Index', value: '198.2%', change: '+2.4%', update: '2024-01-12' },
  { indicator: '12-Month Inflation Expectation', value: '214%', change: '+4.0%', update: '2024-01-10' }
];

const InflationPage = () => {
  const { t, language } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>Inflation Insights | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Track Argentina inflation and ARS to USD movements with Tu Progreso Hoy. Get verified data, narrative context, and clear indicators for confident planning."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.text}>
          <h1>{t.inflationPage.title}</h1>
          <p>{t.inflationPage.intro}</p>
        </div>
        <img
          src="https://picsum.photos/1200/800?random=901"
          alt="Inflation analytics dashboard overview"
          loading="lazy"
        />
      </section>
      <section className={styles.tableSection}>
        <h2>{t.inflationPage.tableTitle}</h2>
        <div className={styles.tableWrapper}>
          <table>
            <thead>
              <tr>
                {t.inflationPage.columns.map((column) => (
                  <th key={column}>{column}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {indicators.map((row) => (
                <tr key={row.indicator}>
                  <td>{row.indicator}</td>
                  <td>{row.value}</td>
                  <td className={row.change.startsWith('+') ? styles.positive : styles.negative}>
                    {row.change}
                  </td>
                  <td>{row.update}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className={styles.timeline}>
          <h3>{language === 'en' ? 'Timeline of recent updates' : 'Timeline de actualizaciones recientes'}</h3>
          <ul>
            <li>
              <span>48h</span>
              <p>{language === 'en' ? 'Wholesale price index refresh and transport category walk-through.' : 'Actualización de índice mayorista y recorrido por transporte.'}</p>
            </li>
            <li>
              <span>5d</span>
              <p>{language === 'en' ? 'Blue chip swap volatility report with scenario prompts.' : 'Reporte de volatilidad contado con liquidación con prompts de escenarios.'}</p>
            </li>
            <li>
              <span>7d</span>
              <p>{language === 'en' ? 'CPI release summary with visual snapshots for budgeting decisions.' : 'Resumen de IPC con visuales para decisiones de presupuesto.'}</p>
            </li>
          </ul>
        </div>
        <div className={styles.notes}>
          {t.inflationPage.notes.map((note) => (
            <p key={note}>{note}</p>
          ))}
        </div>
      </section>
      <section className={styles.cta}>
        <h2>{language === 'en' ? 'Need deeper analysis or team access?' : '¿Necesitás análisis profundo o acceso para tu equipo?'}</h2>
        <p>{language === 'en'
          ? 'Book a walkthrough to explore cohort updates, downloadable datasets, and custom alerts for your goals.'
          : 'Solicitá un recorrido para conocer actualizaciones por cohorte, datasets descargables y alertas personalizadas.'}</p>
        <a href="/contact" className={styles.ctaButton}>
          {language === 'en' ? 'Connect with our team' : 'Conectá con nuestro equipo'}
        </a>
      </section>
    </>
  );
};

export default InflationPage;