import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '../context/LanguageContext';
import styles from '../styles/Legal.module.css';

const TermsOfService = () => {
  const { t, language } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>Terms of Service | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Review the terms and conditions for using Tu Progreso Hoy's educational SaaS platform."
        />
      </Helmet>
      <section className={styles.section}>
        <h1>{t.termsPage.title}</h1>
        <p>{t.termsPage.intro}</p>
        <div className={styles.content}>
          <h2>{language === 'en' ? '1. Acceptance of terms' : '1. Aceptación de términos'}</h2>
          <p>
            {language === 'en'
              ? 'By accessing the platform you agree to comply with these terms and all applicable regulations.'
              : 'Al acceder a la plataforma aceptás cumplir estos términos y toda normativa aplicable.'}
          </p>
          <h2>{language === 'en' ? '2. Educational purpose' : '2. Propósito educativo'}</h2>
          <p>
            {language === 'en'
              ? 'Tu Progreso Hoy provides educational content and data insights. It is not a financial advisory service.'
              : 'Tu Progreso Hoy ofrece contenido educativo e insights de datos. No es un servicio de asesoría financiera.'}
          </p>
          <h2>{language === 'en' ? '3. User responsibilities' : '3. Responsabilidades del usuario'}</h2>
          <p>
            {language === 'en'
              ? 'You are responsible for safeguarding your account credentials and for the decisions you make based on our materials.'
              : 'Sos responsable de resguardar tus credenciales y de las decisiones que tomes basadas en nuestros materiales.'}
          </p>
          <h2>{language === 'en' ? '4. Limitation of liability' : '4. Limitación de responsabilidad'}</h2>
          <p>
            {language === 'en'
              ? 'We aim for accurate information but cannot guarantee outcomes. Decisions remain under your discretion.'
              : 'Apuntamos a brindar información precisa pero no podemos garantizar resultados. Las decisiones quedan bajo tu criterio.'}
          </p>
        </div>
      </section>
    </>
  );
};

export default TermsOfService;