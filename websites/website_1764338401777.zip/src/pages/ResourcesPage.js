import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '../context/LanguageContext';
import styles from '../styles/Resources.module.css';

const ResourcesPage = () => {
  const { t } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>Resources | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Access resources from Tu Progreso Hoy including templates, inflation reports, and live workshops tailored to Argentina."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>{t.resourcesPage.title}</h1>
        <p>{t.resourcesPage.intro}</p>
      </section>
      <section className={styles.resources}>
        {t.resourcesPage.items.map((item) => (
          <article key={item.title} className={styles.resourceCard}>
            <div className={styles.resourceType}>{item.type}</div>
            <h2>{item.title}</h2>
            <p>{item.description}</p>
            <a href="/contact" className={styles.resourceLink}>
              {t.languageToggle === 'ES' ? 'Solicitar acceso' : 'Request access'}
            </a>
          </article>
        ))}
      </section>
    </>
  );
};

export default ResourcesPage;