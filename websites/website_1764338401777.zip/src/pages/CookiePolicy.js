import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '../context/LanguageContext';
import styles from '../styles/Legal.module.css';

const CookiePolicy = () => {
  const { t, language } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>Cookie Policy | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Understand how Tu Progreso Hoy uses cookies to enhance your experience and manage language preferences."
        />
      </Helmet>
      <section className={styles.section}>
        <h1>{t.cookiePage.title}</h1>
        <p>{t.cookiePage.intro}</p>
        <div className={styles.content}>
          <h2>{language === 'en' ? 'Essential cookies' : 'Cookies esenciales'}</h2>
          <p>
            {language === 'en'
              ? 'These cookies keep the platform functional, such as remembering your language selection.'
              : 'Estas cookies mantienen la plataforma funcional, como recordar tu selección de idioma.'}
          </p>
          <h2>{language === 'en' ? 'Analytics cookies' : 'Cookies analíticas'}</h2>
          <p>
            {language === 'en'
              ? 'We measure engagement to improve features. Analytics cookies activate only after you opt in.'
              : 'Medimos engagement para mejorar funcionalidades. Las cookies analíticas se activan solo tras tu consentimiento.'}
          </p>
          <h2>{language === 'en' ? 'Managing cookies' : 'Gestión de cookies'}</h2>
          <p>
            {language === 'en'
              ? 'Adjust preferences anytime via the banner or through your browser settings.'
              : 'Ajustá preferencias en cualquier momento desde el banner o la configuración del navegador.'}
          </p>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;