import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '../context/LanguageContext';
import styles from '../styles/ThankYou.module.css';

const ThankYouPage = () => {
  const { t } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>Thank You | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Thank you for connecting with Tu Progreso Hoy. Confirm your email to access the free lesson and dashboard walkthrough."
        />
      </Helmet>
      <section className={styles.section}>
        <div className={styles.card}>
          <h1>{t.thankYou.title}</h1>
          <p>{t.thankYou.description}</p>
          <Link to="/" className={styles.button}>
            {t.thankYou.backHome}
          </Link>
        </div>
      </section>
    </>
  );
};

export default ThankYouPage;