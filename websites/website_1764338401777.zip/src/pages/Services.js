import React, { useContext, useState } from 'react';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '../context/LanguageContext';
import styles from '../styles/Services.module.css';

const Services = () => {
  const { t, language } = useContext(LanguageContext);
  const [active, setActive] = useState(0);

  return (
    <>
      <Helmet>
        <title>Services | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Explore Tu Progreso Hoy services: inflation intelligence, financial learning journeys, and team enablement programs tailored to Argentina."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>{t.servicesPage.title}</h1>
        <p>{t.servicesPage.intro}</p>
      </section>
      <section className={styles.services}>
        <div className={styles.tabs} role="tablist" aria-label="Service offerings">
          {t.servicesPage.offerings.map((offering, index) => (
            <button
              key={offering.title}
              type="button"
              role="tab"
              aria-selected={active === index}
              className={`${styles.tabButton} ${active === index ? styles.tabActive : ''}`}
              onClick={() => setActive(index)}
            >
              {offering.title}
            </button>
          ))}
        </div>
        <div className={styles.details} role="tabpanel">
          <img
            src={`https://picsum.photos/1000/700?random=${700 + active}`}
            alt="Service illustration"
            loading="lazy"
          />
          <div className={styles.detailText}>
            <h2>{t.servicesPage.offerings[active].title}</h2>
            <p>{t.servicesPage.offerings[active].description}</p>
            <ul>
              {t.servicesPage.offerings[active].benefits.map((benefit) => (
                <li key={benefit}>{benefit}</li>
              ))}
            </ul>
            <a href="mailto:info@tuprogresohoy.com" className={styles.cta}>
              {language === 'en' ? 'Request pricing and onboarding' : 'Solicitar precios y onboarding'}
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;