import React, { useContext } from 'react';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '../context/LanguageContext';
import styles from '../styles/Legal.module.css';

const PrivacyPolicy = () => {
  const { t, language } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>Privacy Policy | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Learn how Tu Progreso Hoy collects, uses, and protects your personal information across our educational SaaS platform."
        />
      </Helmet>
      <section className={styles.section}>
        <h1>{t.privacyPage.title}</h1>
        <p className={styles.updated}>{t.privacyPage.updated}</p>
        <div className={styles.content}>
          <h2>{language === 'en' ? '1. Information we collect' : '1. Información que recolectamos'}</h2>
          <p>
            {language === 'en'
              ? 'We collect data that you provide directly, such as name, email, and language preferences, along with usage analytics to improve performance.'
              : 'Recolectamos datos provistos directamente, como nombre, correo y preferencias de idioma, junto con analíticas de uso para mejorar el rendimiento.'}
          </p>
          <h2>{language === 'en' ? '2. How we use information' : '2. Uso de la información'}</h2>
          <p>
            {language === 'en'
              ? 'Data helps us personalize dashboards, deliver course materials, and send essential communications related to educational content.'
              : 'Los datos nos ayudan a personalizar paneles, entregar material del curso y enviar comunicaciones esenciales relacionadas al contenido educativo.'}
          </p>
          <h2>{language === 'en' ? '3. Data sharing' : '3. Compartir datos'}</h2>
          <p>
            {language === 'en'
              ? 'We do not sell personal data. Limited sharing occurs with service providers who support hosting, analytics, and email delivery under strict agreements.'
              : 'No vendemos datos personales. Compartimos únicamente con proveedores que soportan hosting, analíticas y envíos de mail bajo acuerdos estrictos.'}
          </p>
          <h2>{language === 'en' ? '4. Your rights' : '4. Tus derechos'}</h2>
          <p>
            {language === 'en'
              ? 'You can access, update, or request deletion of your data by contacting info@tuprogresohoy.com. We respond according to applicable laws in Argentina.'
              : 'Podés acceder, actualizar o solicitar la eliminación de tus datos escribiendo a info@tuprogresohoy.com. Respondemos según la normativa vigente en Argentina.'}
          </p>
        </div>
      </section>
    </>
  );
};

export default PrivacyPolicy;