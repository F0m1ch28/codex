import React, { useContext, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { LanguageContext } from '../context/LanguageContext';
import useAnimatedCounter from '../hooks/useAnimatedCounter';
import styles from '../styles/Home.module.css';

const RatesTicker = ({ language }) => {
  const [rate, setRate] = useState(null);
  const [change, setChange] = useState(null);
  const [status, setStatus] = useState('loading');
  const [timestamp, setTimestamp] = useState('');

  useEffect(() => {
    let mounted = true;
    let previous = null;

    const fetchRate = async () => {
      try {
        setStatus('loading');
        const response = await fetch('https://open.er-api.com/v6/latest/ARS');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        const usdRate = data.rates?.USD ? 1 / data.rates.USD : null;
        if (mounted && usdRate) {
          const formatted = parseFloat(usdRate.toFixed(4));
          setRate(formatted);
          if (previous !== null) {
            const diff = formatted - previous;
            setChange(diff);
          }
          previous = formatted;
          setTimestamp(new Date(data.time_last_update_utc).toLocaleString(language === 'en' ? 'en-US' : 'es-AR'));
          setStatus('ready');
        }
      } catch (error) {
        if (mounted) {
          setStatus('error');
        }
      }
    };

    fetchRate();
    const interval = setInterval(fetchRate, 60000);

    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, [language]);

  return (
    <div className={styles.ticker} role="status" aria-live="polite">
      <div className={styles.tickerHeader}>
        <span>ARS → USD Tracker</span>
        <span className={styles.tickerStatus}>
          {status === 'loading' && 'Refreshing data...'}
          {status === 'ready' && 'Live'}
          {status === 'error' && 'Update paused'}
        </span>
      </div>
      {status === 'ready' && (
        <div className={styles.tickerBody}>
          <div className={styles.tickerRate}>
            <strong>{rate}</strong>
            <span>USD for 1 ARS</span>
          </div>
          <div className={styles.tickerChange}>
            <span className={change > 0 ? styles.positive : change < 0 ? styles.negative : styles.neutral}>
              {change === null ? '•' : change > 0 ? `▲ ${change.toFixed(4)}` : change < 0 ? `▼ ${Math.abs(change).toFixed(4)}` : '— 0'}
            </span>
            <span>{timestamp}</span>
          </div>
        </div>
      )}
      {status === 'error' && (
        <p className={styles.tickerError}>
          Unable to refresh data now. Last known rate preserved.
        </p>
      )}
    </div>
  );
};

const Home = () => {
  const { t, language } = useContext(LanguageContext);
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [showDisclaimer, setShowDisclaimer] = useState(() => {
    if (typeof sessionStorage === 'undefined') {
      return true;
    }
    return !sessionStorage.getItem('disclaimerAcknowledged');
  });

  useEffect(() => {
    if (showDisclaimer) {
      const timer = setTimeout(() => {
        setShowDisclaimer(true);
      }, 400);
      return () => clearTimeout(timer);
    }
  }, [showDisclaimer]);

  const stats = t.stats.map((item) => ({
    ...item,
    animatedValue: useAnimatedCounter(item.value)
  }));

  const projectCategories = useMemo(() => ['All', ...new Set(t.projects.map((project) => project.category))], [t.projects]);

  const filteredProjects = useMemo(() => {
    if (selectedCategory === 'All') {
      return t.projects;
    }
    return t.projects.filter((project) => project.category === selectedCategory);
  }, [selectedCategory, t.projects]);

  const [trialForm, setTrialForm] = useState({
    name: '',
    email: '',
    consent: false
  });
  const [trialErrors, setTrialErrors] = useState({});

  const handleTrialChange = (event) => {
    const { name, value, type, checked } = event.target;
    setTrialForm((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const validateTrialForm = () => {
    const errors = {};
    if (!trialForm.name.trim()) {
      errors.name = language === 'en' ? 'Name is required.' : 'El nombre es obligatorio.';
    }
    if (!trialForm.email.trim()) {
      errors.email = language === 'en' ? 'Email is required.' : 'El correo es obligatorio.';
    } else if (!/\S+@\S+\.\S+/.test(trialForm.email)) {
      errors.email = language === 'en' ? 'Please enter a valid email.' : 'Ingresá un correo válido.';
    }
    if (!trialForm.consent) {
      errors.consent = language === 'en'
        ? 'Consent is required to proceed.'
        : 'Necesitamos tu consentimiento para continuar.';
    }
    return errors;
  };

  const handleTrialSubmit = (event) => {
    event.preventDefault();
    const errors = validateTrialForm();
    setTrialErrors(errors);
    if (Object.keys(errors).length === 0) {
      navigate('/thank-you', { replace: true });
    }
  };

  const closeDisclaimer = () => {
    setShowDisclaimer(false);
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.setItem('disclaimerAcknowledged', 'true');
    }
  };

  return (
    <>
      <Helmet>
        <title>Tu Progreso Hoy | Inflation Tracker & Finance Course</title>
        <meta
          name="description"
          content="Stay ahead of Argentina inflation with Tu Progreso Hoy. Live ARS to USD tracker, transparent insights, and a personal finance course designed for resilient planning."
        />
        <meta
          name="keywords"
          content="argentina inflation, ars usd, finanzas personales, budgeting argentina, curso finanzas, economic trends, datos confiables"
        />
      </Helmet>
      <section className={styles.hero}>
        <img
          src="https://picsum.photos/1600/900?random=101"
          alt="Analysts interpreting financial dashboards"
          className={styles.heroImage}
          loading="lazy"
        />
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <p className={styles.heroTagline}>Datos verificados para planificar tu presupuesto.</p>
          <h1>{t.hero.title}</h1>
          <p className={styles.heroSubtitle}>{t.hero.subtitle}</p>
          <div className={styles.heroActions}>
            <Link to="/inflation" className={styles.primaryButton}>
              {t.hero.ctaPrimary}
            </Link>
            <Link to="/course" className={styles.secondaryButton}>
              {t.hero.ctaSecondary}
            </Link>
          </div>
          <div className={styles.heroNotes}>
            <span>Plataforma educativa con datos esenciales, sin asesoría financiera directa.</span>
            <span>Pasos acertados hoy, mejor futuro mañana.</span>
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className={styles.statsGrid}>
          {stats.map((item) => (
            <div key={item.label} className={styles.statCard}>
              <span className={styles.statValue}>{item.animatedValue}</span>
              <span className={styles.statLabel}>{item.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.tickerSection}>
        <RatesTicker language={language} />
        <div className={styles.tickerCaption}>
          Conocimiento financiero impulsado por tendencias. Información confiable que respalda elecciones responsables sobre tu dinero.
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className={styles.sectionHeader}>
          <h2>{t.servicesIntro}</h2>
          <p>Decisiones responsables, objetivos nítidos.</p>
        </div>
        <div className={styles.servicesGrid}>
          {t.services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/services" className={styles.cardLink}>
                {language === 'en' ? 'Discover more' : 'Descubrir más'}
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.processSection}>
        <div className={styles.sectionHeader}>
          <h2>{language === 'en' ? 'How Tu Progreso Hoy works' : 'Cómo funciona Tu Progreso Hoy'}</h2>
          <p>Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.</p>
        </div>
        <ol className={styles.processList}>
          {t.process.map((step, index) => (
            <li key={step}>
              <span className={styles.stepNumber}>{index + 1}</span>
              <p>{step}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className={styles.insightsSection}>
        <div className={styles.sectionHeader}>
          <h2>{language === 'en' ? 'Insights tailored for Argentina' : 'Insights adaptados a Argentina'}</h2>
        </div>
        <div className={styles.insightsGrid}>
          <article>
            <h3>{language === 'en' ? 'Weekly Inflation Signals' : 'Señales de inflación semanales'}</h3>
            <p>{language === 'en'
              ? 'Receive briefs covering official CPI, blue chip swap, and wholesale trends in a single view.'
              : 'Recibí briefs sobre IPC, contado con liquidación y tendencias mayoristas en una sola vista.'}</p>
          </article>
          <article>
            <h3>{language === 'en' ? 'Scenario Stress Tests' : 'Stress tests de escenarios'}</h3>
            <p>{language === 'en'
              ? 'Model expenses with sliding ARS depreciation windows to anticipate cash flow impacts.'
              : 'Modelá gastos con ventanas de depreciación ARS para anticipar impactos en tu flujo.'}</p>
          </article>
          <article>
            <h3>{language === 'en' ? 'Learning Nudges' : 'Recordatorios de aprendizaje'}</h3>
            <p>{language === 'en'
              ? 'Micro-lessons with practical templates convert data into actionable priorities.'
              : 'Micro-lecciones con plantillas prácticas convierten datos en prioridades accionables.'}</p>
          </article>
        </div>
      </section>

      <section className={styles.testimonialSection}>
        <div className={styles.sectionHeader}>
          <h2>{language === 'en' ? 'Member voices' : 'Voces de quienes confían'}</h2>
        </div>
        <TestimonialCarousel testimonials={t.testimonials} />
      </section>

      <section className={styles.teamSection}>
        <div className={styles.sectionHeader}>
          <h2>{t.teamHighlight}</h2>
        </div>
        <div className={styles.teamGrid}>
          {[
            {
              name: language === 'en' ? 'Martina López' : 'Martina López',
              role: language === 'en' ? 'Chief Economist' : 'Economista Jefe',
              img: 'https://picsum.photos/400/400?random=301'
            },
            {
              name: language === 'en' ? 'Diego Fernández' : 'Diego Fernández',
              role: language === 'en' ? 'Head of Learning Experience' : 'Director de Learning Experience',
              img: 'https://picsum.photos/400/400?random=302'
            },
            {
              name: language === 'en' ? 'Sofía Alvarez' : 'Sofía Alvarez',
              role: language === 'en' ? 'Lead Data Scientist' : 'Data Scientist Líder',
              img: 'https://picsum.photos/400/400?random=303'
            }
          ].map((member) => (
            <div key={member.name} className={styles.teamCard}>
              <img src={member.img} alt={`${member.name} - ${member.role}`} loading="lazy" />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className={styles.sectionHeader}>
          <h2>{language === 'en' ? 'Featured Impact Stories' : 'Historias de impacto destacadas'}</h2>
        </div>
        <div className={styles.filterBar}>
          <span>{language === 'en' ? 'Filter:' : 'Filtrar:'}</span>
          <div className={styles.filterButtons}>
            {projectCategories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${selectedCategory === category ? styles.activeFilter : ''}`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <img
                src={`https://picsum.photos/600/420?random=${Math.floor(Math.random() * 2000) + 400}`}
                alt="Project insight visual"
                loading="lazy"
              />
              <div>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className={styles.sectionHeader}>
          <h2>{language === 'en' ? 'Frequently asked questions' : 'Preguntas frecuentes'}</h2>
        </div>
        <FAQAccordion items={t.faq} />
      </section>

      <section className={styles.blogSection}>
        <div className={styles.sectionHeader}>
          <h2>{t.blogTitle}</h2>
        </div>
        <div className={styles.blogGrid}>
          {t.blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <img
                src="https://picsum.photos/800/600?random=204"
                alt="Economic analysis illustration"
                loading="lazy"
              />
              <div className={styles.blogContent}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/resources" className={styles.blogLink}>
                  {language === 'en' ? 'Read more in resources' : 'Ver más en recursos'}
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2>{t.ctaSection.title}</h2>
          <p>{t.ctaSection.description}</p>
          <div className={styles.ctaActions}>
            <Link to="/contact" className={styles.primaryButton}>
              {language === 'en' ? 'Book a walkthrough' : 'Solicitar recorrido'}
            </Link>
            <Link to="/inflation" className={styles.secondaryButton}>
              {language === 'en' ? 'See latest indicators' : 'Ver indicadores recientes'}
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.trialSection} id="trial">
        <div className={styles.trialCard}>
          <div>
            <h2>{language === 'en' ? 'Unlock your free trial lesson' : 'Accedé a tu lección de prueba gratis'}</h2>
            <p>
              {language === 'en'
                ? 'Get the first lesson, dashboards overview, and starter toolkit. Confirm via the email we will send to activate access.'
                : 'Recibí la primera lección, overview del panel y toolkit inicial. Confirmá desde el correo que enviaremos para activar el acceso.'}
            </p>
          </div>
          <form className={styles.trialForm} onSubmit={handleTrialSubmit} noValidate>
            <div className={styles.formGroup}>
              <label htmlFor="trial-name">{language === 'en' ? 'Full name' : 'Nombre completo'}</label>
              <input
                id="trial-name"
                name="name"
                type="text"
                value={trialForm.name}
                onChange={handleTrialChange}
                required
              />
              {trialErrors.name && <span className={styles.errorText}>{trialErrors.name}</span>}
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="trial-email">{language === 'en' ? 'Email address' : 'Correo electrónico'}</label>
              <input
                id="trial-email"
                name="email"
                type="email"
                value={trialForm.email}
                onChange={handleTrialChange}
                required
              />
              {trialErrors.email && <span className={styles.errorText}>{trialErrors.email}</span>}
            </div>
            <div className={styles.checkboxGroup}>
              <input
                id="trial-consent"
                name="consent"
                type="checkbox"
                checked={trialForm.consent}
                onChange={handleTrialChange}
              />
              <label htmlFor="trial-consent">
                {language === 'en'
                  ? 'I agree to receive emails and will confirm through the follow-up email (double opt-in).'
                  : 'Acepto recibir correos y confirmaré desde el email de seguimiento (doble opt-in).'}
              </label>
            </div>
            {trialErrors.consent && <span className={styles.errorText}>{trialErrors.consent}</span>}
            <button type="submit" className={styles.primaryButton}>
              {language === 'en' ? 'Access free trial' : 'Acceder a la prueba gratis'}
            </button>
          </form>
        </div>
      </section>

      {showDisclaimer && (
        <div className={styles.modalOverlay} role="dialog" aria-modal="true">
          <div className={styles.modalContent}>
            <h3>{language === 'en' ? 'Important disclaimer' : 'Aviso importante'}</h3>
            <p>We do not provide financial services.</p>
            <button type="button" className={styles.primaryButton} onClick={closeDisclaimer}>
              {language === 'en' ? 'I understand' : 'Entendido'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};

const TestimonialCarousel = ({ testimonials }) => {
  const [index, setIndex] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [testimonials.length]);
  return (
    <div className={styles.testimonialWrapper}>
      {testimonials.map((testimonial, idx) => (
        <blockquote
          key={testimonial.name}
          className={`${styles.testimonialCard} ${idx === index ? styles.testimonialActive : ''}`}
        >
          <p>“{testimonial.quote}”</p>
          <footer>
            <strong>{testimonial.name}</strong>
            <span>{testimonial.role}</span>
          </footer>
        </blockquote>
      ))}
      <div className={styles.testimonialControls} role="tablist" aria-label="Testimonials selector">
        {testimonials.map((testimonial, idx) => (
          <button
            key={testimonial.name}
            type="button"
            className={`${styles.dot} ${idx === index ? styles.activeDot : ''}`}
            onClick={() => setIndex(idx)}
            aria-label={`Show testimonial from ${testimonial.name}`}
          />
        ))}
      </div>
    </div>
  );
};

const FAQAccordion = ({ items }) => {
  const [openIndex, setOpenIndex] = useState(null);
  return (
    <div className={styles.accordion}>
      {items.map((item, idx) => (
        <div key={item.question} className={styles.accordionItem}>
          <button
            type="button"
            className={styles.accordionButton}
            onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
            aria-expanded={openIndex === idx}
          >
            {item.question}
            <span>{openIndex === idx ? '-' : '+'}</span>
          </button>
          {openIndex === idx && (
            <div className={styles.accordionPanel}>
              <p>{item.answer}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default Home;