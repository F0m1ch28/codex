```javascript
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Contact = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    topic: '',
    message: '',
    consent: false,
    confirm: false,
  });
  const [feedback, setFeedback] = useState('');

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setFeedback('Thank you! Please confirm the email we just sent to complete your request.');
    setTimeout(() => {
      navigate('/thank-you', { state: { source: 'contact' } });
    }, 900);
  };

  return (
    <div>
      <section className="section-light" aria-labelledby="contact-title">
        <div className="container">
          <h1 id="contact-title">Contact Tu Progreso Hoy</h1>
          <p>
            Análisis transparentes y datos de mercado para decidir con seguridad. Reach out once you have confirmed the
            double opt-in email so we can respond to verified inquiries.
          </p>
          <div className="card-grid" role="list">
            <div className="card" role="listitem">
              <h3>Address</h3>
              <p>
                Av. 9 de Julio 1000
                <br />
                C1043 Buenos Aires, Argentina
              </p>
            </div>
            <div className="card" role="listitem">
              <h3>Contact details</h3>
              <p>
                Phone: <a href="tel:+541155551234">+54 11 5555-1234</a>
                <br />
                Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
              </p>
              <p className="language-note">
                Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera con responsabilidad.
              </p>
            </div>
          </div>
          <div className="map-container" aria-label="Map to Tu Progreso Hoy office">
            <iframe
              title="Map of Tu Progreso Hoy in Buenos Aires"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.050295002199!2d-58.383759523425685!3d-34.60373845745848!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccad9f0dfeced%3A0x59c59e86cdc84e75!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA!5e0!3m2!1sen!2sar!4v1710026400000!5m2!1sen!2sar"
              width="100%"
              height="360"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
            ></iframe>
          </div>
        </div>
      </section>

      <section className="section-muted" aria-labelledby="contact-form-heading">
        <div className="container">
          <h2 id="contact-form-heading">Send us a message</h2>
          <div className="form-card">
            <form onSubmit={handleSubmit}>
              <div className="form-grid double">
                <div>
                  <label htmlFor="contact-name">Full name</label>
                  <input
                    id="contact-name"
                    name="name"
                    type="text"
                    required
                    value={formData.name}
                    onChange={handleChange}
                  />
                </div>
                <div>
                  <label htmlFor="contact-email">Email</label>
                  <input
                    id="contact-email"
                    name="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="form-grid">
                <div>
                  <label htmlFor="topic">Topic</label>
                  <select id="topic" name="topic" value={formData.topic} onChange={handleChange} required>
                    <option value="">Select a topic</option>
                    <option value="course">Course information</option>
                    <option value="data">Data methodology</option>
                    <option value="partnerships">Partnership opportunities</option>
                    <option value="media">Media enquiry</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="message">Message</label>
                  <textarea
                    id="message"
                    name="message"
                    rows="4"
                    required
                    value={formData.message}
                    onChange={handleChange}
                  ></textarea>
                </div>
              </div>
              <div className="checkbox-field">
                <input
                  id="contact-consent"
                  name="consent"
                  type="checkbox"
                  checked={formData.consent}
                  onChange={handleChange}
                  required
                />
                <label htmlFor="contact-consent">
                  I have read and agree to the <Link to="/privacy">privacy policy</Link>.
                </label>
              </div>
              <div className="checkbox-field">
                <input
                  id="contact-confirm"
                  name="confirm"
                  type="checkbox"
                  checked={formData.confirm}
                  onChange={handleChange}
                  required
                />
                <label htmlFor="contact-confirm">
                  I understand Tu Progreso Hoy uses a double opt-in process and that emails are informational only. See
                  our <Link to="/terms">terms</Link> for details.
                </label>
              </div>
              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '1.5rem' }}>
                Submit enquiry
              </button>
            </form>
            <p className="language-note" style={{ marginTop: '1rem' }}>
              Plataforma educativa con datos esenciales, sin asesoría financiera directa. Мы не предоставляем финансовые
              услуги.
            </p>
            {feedback && (
              <div className="notice" role="status" aria-live="polite">
                {feedback}
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
```