```javascript
import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const ThankYou = () => {
  const location = useLocation();
  const source = location.state?.source;

  return (
    <section className="section-light" aria-labelledby="thanks-title">
      <div className="container">
        <h1 id="thanks-title">Thank you for connecting with Tu Progreso Hoy</h1>
        <p>
          We have sent a double opt-in email to confirm your request. Please check your inbox (and spam folder) and
          click the confirmation link to activate your access.
        </p>
        {source === 'trial' && (
          <p>Once confirmed, you will receive the schedule for the free trial lesson and guidance on how to prepare responsibly.</p>
        )}
        {source === 'contact' && (
          <p>After confirmation, our team in Buenos Aires will respond to your enquiry within two business days.</p>
        )}
        {!source && (
          <p>
            Confirmation ensures only verified subscribers receive information. Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
        )}
        <div className="hero-buttons" style={{ justifyContent: 'flex-start' }}>
          <Link className="btn btn-primary" to="/">
            Return home
          </Link>
          <Link className="btn btn-outline" to="/resources">
            Explore resources
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ThankYou;
```