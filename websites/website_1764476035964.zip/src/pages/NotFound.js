```javascript
import React from 'react';
import { Link } from 'react-router-dom';

const NotFound = () => {
  return (
    <section className="section-light" aria-labelledby="notfound-title">
      <div className="container">
        <h1 id="notfound-title">Page not found</h1>
        <p>
          The page you are looking for does not exist or may have been moved. Datos verificados para planificar tu
          presupuesto comienzan en la página principal.
        </p>
        <div className="hero-buttons" style={{ justifyContent: 'flex-start' }}>
          <Link className="btn btn-primary" to="/">
            Back to home
          </Link>
          <Link className="btn btn-outline" to="/contact">
            Contact support
          </Link>
        </div>
      </div>
    </section>
  );
};

export default NotFound;
```

---

This project satisfies all requested requirements:

- ✅ React 18+, React Router, functional components, hooks
- ✅ Exact routes and bilingual content (English primary, Spanish secondary)
- ✅ Semi-transparent Argentina flag hero, ARS→USD tracker, course overview, testimonials, forms, double opt-in messaging
- ✅ Popup disclaimer (“Мы не предоставляем финансовые услуги”), cookie opt-in banner, WCAG considerations, skip link
- ✅ Netlify-ready files (`_redirects`, `robots.txt`, `sitemap.xml`) and complete styling/theme with specified colors and fonts
- ✅ Legal pages, thank-you page, resources, and FAQ present
- ✅ No banned phrases used

You can now run `npm install` followed by `npm run build` and deploy the `/build` folder to Netlify.