```javascript
import React from 'react';

const Inflation = () => {
  const methodologyPoints = [
    {
      title: 'Source triangulation',
      description:
        'INDEC CPI releases, BCRA communications, and energy tariff updates are cross-checked to contextualise price behaviour.',
    },
    {
      title: 'Market monitors',
      description:
        'We track blue, CCL, and official ARS→USD references alongside interest rate curves to understand currency dynamics.',
    },
    {
      title: 'Household relevance',
      description:
        'Each dataset is distilled into actionable insights for rent, supermarkets, transport, and long-term purchasing plans.',
    },
  ];

  const cpiMonthly = [
    { label: 'Oct 2023', value: 8.3 },
    { label: 'Nov 2023', value: 12.8 },
    { label: 'Dec 2023', value: 25.5 },
    { label: 'Jan 2024', value: 20.6 },
    { label: 'Feb 2024', value: 13.2 },
  ];

  const fxContext = [
    {
      label: 'Official',
      note: 'Controlled crawl set by BCRA guidance with periodic adjustments.',
    },
    {
      label: 'Blue',
      note: 'Market sentiment indicator capturing liquidity constraints.',
    },
    {
      label: 'CCL',
      note: 'Financial channel reflecting demand for USD-linked assets.',
    },
  ];

  return (
    <div>
      <section className="section-light" aria-labelledby="inflation-title">
        <div className="container">
          <h1 id="inflation-title">Inflation methodology</h1>
          <p>
            Our inflation tracker combines official and alternative data to provide transparent context. Conocimiento
            financiero impulsado por tendencias guía cada actualización.
          </p>
          <div className="card-grid" role="list">
            {methodologyPoints.map((item) => (
              <div key={item.title} className="card" role="listitem">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-muted" aria-labelledby="cpi-heading">
        <div className="container">
          <h2 id="cpi-heading">CPI spotlight</h2>
          <p>
            CPI (Índice de Precios al Consumidor) readings are analysed with emphasis on month-on-month variation to
            identify inflection points relevant to households and small businesses.
          </p>
          <div className="chart-bars" role="list">
            {cpiMonthly.map((item) => (
              <div key={item.label} className="chart-bar" role="listitem">
                <span>{item.label}</span>
                <div className="chart-bar-track">
                  <div className="chart-bar-fill" style={{ width: `${item.value * 8}px` }} aria-hidden="true"></div>
                </div>
                <span>{item.value}% m/m</span>
              </div>
            ))}
          </div>
          <p className="language-note">
            Datos verificados para planificar tu presupuesto. Each bar references the official INDEC release.
          </p>
        </div>
      </section>

      <section className="section-light" aria-labelledby="fx-context-heading">
        <div className="container">
          <h2 id="fx-context-heading">FX context</h2>
          <p>
            Decisiones responsables, objetivos nítidos. We explain how ARS→USD references interact with inflation
            pressure to help you plan responsibly.
          </p>
          <div className="card-grid" role="list">
            {fxContext.map((item) => (
              <div key={item.label} className="card" role="listitem">
                <h3>{item.label}</h3>
                <p>{item.note}</p>
              </div>
            ))}
          </div>
          <div className="notice">
            <strong>Methodology note:</strong> Each FX reference is presented with spreads and historical averages.
            Información confiable que respalda elecciones responsables sobre tu dinero.
          </div>
        </div>
      </section>

      <section className="section-muted" aria-labelledby="workflow-heading">
        <div className="container">
          <h2 id="workflow-heading">Weekly workflow</h2>
          <div className="timeline" role="list">
            <div className="timeline-item" role="listitem">
              <h3>Monday</h3>
              <p>Collect energy, transport, and staple updates to monitor pass-through risk.</p>
            </div>
            <div className="timeline-item" role="listitem">
              <h3>Wednesday</h3>
              <p>Update ARS→USD tracker with official, blue, and CCL moves and publish commentary.</p>
            </div>
            <div className="timeline-item" role="listitem">
              <h3>Friday</h3>
              <p>Deliver course live session recaps with focus on household impact scenarios.</p>
            </div>
          </div>
          <p className="language-note">
            Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera — always with transparent sourcing.
          </p>
        </div>
      </section>

      <section className="section-light" aria-labelledby="inflation-faq">
        <div className="container faq-list">
          <h2 id="inflation-faq">Inflation FAQ</h2>
          <details>
            <summary>How often is the ARS→USD tracker updated?</summary>
            <p>
              We refresh data every Wednesday or sooner if market-moving events occur. Users receive a double opt-in
              email before any alerts.
            </p>
          </details>
          <details>
            <summary>Do you forecast inflation?</summary>
            <p>
              We provide scenario ranges with clear assumptions but no predictive guarantees. Pasos acertados hoy, mejor
              futuro mañana — we emphasise preparation over speculation.
            </p>
          </details>
          <details>
            <summary>Where can I find methodology references?</summary>
            <p>
              Sources are linked in each dashboard footnote, covering INDEC, BCRA, IMF, and reputable research entities.
              Plataforma educativa con datos esenciales, sin asesoría financiera directa.
            </p>
          </details>
        </div>
      </section>
    </div>
  );
};

export default Inflation;
```