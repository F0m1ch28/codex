```javascript
import React from 'react';
import { Link } from 'react-router-dom';

const Faq = () => {
  return (
    <section className="section-light" aria-labelledby="faq-title">
      <div className="container faq-list">
        <h1 id="faq-title">Frequently Asked Questions</h1>

        <details>
          <summary>Is Tu Progreso Hoy available in English and Spanish?</summary>
          <p>
            Yes. English is the primary language for dashboards and course content, with Español summaries and glossaries
            for every module.
          </p>
        </details>

        <details>
          <summary>How does the double opt-in work?</summary>
          <p>
            After you submit any form, we send a confirmation email. Only when you click that link do we activate your
            free trial or enquiry. This protects you from unsolicited emails.
          </p>
        </details>

        <details>
          <summary>Can I access recordings of the course?</summary>
          <p>Yes, recordings are available for confirmed participants for 60 days. We may extend access upon request.</p>
        </details>

        <details>
          <summary>Do you provide personalised financial advice?</summary>
          <p>
            No. Plataforma educativa con datos esenciales, sin asesoría financiera directa. For personal recommendations,
            please consult a licensed advisor.
          </p>
        </details>

        <details>
          <summary>Where can I learn more about the methodology?</summary>
          <p>
            Visit our <Link to="/inflation">Inflation page</Link> for detailed notes on sources, calculations, and update
            cadence.
          </p>
        </details>

        <details>
          <summary>How do I contact support?</summary>
          <p>
            Fill out the <Link to="/contact">contact form</Link> after confirming your double opt-in email. We respond
            within two business days.
          </p>
        </details>

        <p className="language-note">
          Conocimiento financiero impulsado por tendencias, entregado con responsabilidad.
        </p>
      </div>
    </section>
  );
};

export default Faq;
```