```javascript
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Course = () => {
  const navigate = useNavigate();

  const modules = [
    {
      title: 'Module 1 — Inflation decoded',
      points: [
        'Examine CPI basket composition, weighting, and how INDEC communicates changes.',
        'Translate macro movements into supermarket, transport, and housing categories.',
        'Build a bilingual glossary so mixed-language teams stay aligned.',
      ],
    },
    {
      title: 'Module 2 — Budget resilience',
      points: [
        'Design cash flow scenarios with conservative, base, and optimistic assumptions.',
        'Use ARS→USD trackers to adjust import-sensitive expenses responsibly.',
        'Prioritise goals with a framework anchored in verified data sources.',
      ],
    },
    {
      title: 'Module 3 — Savings toolkit',
      points: [
        'Compare savings avenues and understand associated regulatory notes without giving personalised advice.',
        'Evaluate liquidity needs versus inflation exposure in a structured way.',
        'Document conversations with household members to maintain shared visibility.',
      ],
    },
    {
      title: 'Module 4 — Monitoring practice',
      points: [
        'Set up weekly dashboards and alerts aligned with your objectives.',
        'Review case studies from Argentina to reinforce disciplined habits.',
        'Plan monthly retrospectives to keep “Pasos acertados hoy, mejor futuro mañana” at the centre.',
      ],
    },
  ];

  const audiences = [
    'Young professionals structuring independent budgets.',
    'Families preparing for education, housing, or healthcare expenses.',
    'Students and entrepreneurs who need reliable inflation context to support decisions.',
  ];

  const outcomes = [
    'Build a personalised weekly briefing template that captures key inflation and FX signals.',
    'Create actionable cash flow scenarios with transparent assumptions.',
    'Adopt a monitoring cadence that keeps objectives visible without overreacting to noise.',
  ];

  const handleAnchorClick = (event) => {
    event.preventDefault();
    navigate('/', { state: { fromCTA: true } });
  };

  return (
    <div>
      <section className="section-light" aria-labelledby="course-title">
        <div className="container">
          <h1 id="course-title">Personal finance starter course</h1>
          <p>
            De la información al aprendizaje: fortalece tu criterio financiero paso a paso. The course is delivered in
            English with supporting Español resources to serve Argentina-based learners.
          </p>
          <div className="card-grid" role="list">
            {modules.map((module) => (
              <div key={module.title} className="card" role="listitem">
                <h3>{module.title}</h3>
                <ul>
                  {module.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-muted" aria-labelledby="audience-heading">
        <div className="container">
          <h2 id="audience-heading">Who joins Tu Progreso Hoy?</h2>
          <ul>
            {audiences.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <div className="notice">
            Análisis transparentes y datos de mercado para decidir con seguridad. Each session includes discussion time
            to clarify concepts responsibly.
          </div>
        </div>
      </section>

      <section className="section-light" aria-labelledby="outcomes-heading">
        <div className="container">
          <h2 id="outcomes-heading">What you will accomplish</h2>
          <ul>
            {outcomes.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <p className="language-note">Información confiable que respalda elecciones responsables sobre tu dinero.</p>
        </div>
      </section>

      <section className="section-dark" id="course-cta" aria-labelledby="cta-course-heading">
        <div className="container">
          <h2 id="cta-course-heading">Ready to experience the course?</h2>
          <p>
            We use a double opt-in system for every registration. Sigue las tendencias, identifica oportunidades y
            diseña tu ruta financiera con responsabilidad.
          </p>
          <div className="hero-buttons">
            <a className="btn btn-primary" href="/#trial-form" onClick={handleAnchorClick}>
              Получить бесплатный пробный урок
            </a>
            <Link className="btn btn-outline" to="/resources">
              Preview learning resources
            </Link>
          </div>
          <p className="language-note" style={{ marginTop: '1rem' }}>
            Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Course;
```