```javascript
import React, { useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

const Home = () => {
  const trackerData = useMemo(
    () => [
      { date: '2024-03-10', official: 852.5, blue: 1035.0, ccl: 1018.2 },
      { date: '2024-03-03', official: 845.1, blue: 1020.4, ccl: 1006.45 },
      { date: '2024-02-25', official: 838.75, blue: 1004.9, ccl: 995.3 },
      { date: '2024-02-18', official: 830.2, blue: 980.5, ccl: 975.15 },
      { date: '2024-02-11', official: 822.0, blue: 962.3, ccl: 960.8 },
    ],
    []
  );

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    goal: '',
    language: 'English',
    consent: false,
    confirm: false,
  });
  const [submitMessage, setSubmitMessage] = useState('');
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (location.state && location.state.fromCTA) {
      const target = document.getElementById('trial-form');
      if (target) {
        setTimeout(() => target.scrollIntoView({ behavior: 'smooth', block: 'start' }), 200);
      }
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location, navigate]);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitMessage(
      'Thank you! We have emailed you a confirmation link. Please confirm to activate your free trial lesson access.'
    );
    setTimeout(() => {
      navigate('/thank-you', { state: { source: 'trial' } });
    }, 900);
  };

  const current = trackerData[0];
  const previous = trackerData[1];
  const officialChange = previous ? ((current.official - previous.official) / previous.official) * 100 : 0;
  const blueChange = previous ? ((current.blue - previous.blue) / previous.blue) * 100 : 0;

  const testimonials = [
    {
      name: 'Camila G., Product Manager',
      quote: '“The dashboards make it easier to translate inflation data into budgets for my family.”',
    },
    {
      name: 'Leandro P., Marketing Analyst',
      quote:
        '“Clear summaries in English and Spanish help our binational team stay aligned on FX assumptions.”',
    },
    {
      name: 'Gabriela R., University Student',
      quote:
        '“The personal finance starter course gave me structure to build an emergency fund plan responsibly.”',
    },
  ];

  const modules = [
    {
      title: 'Module 1 — Inflation landscape essentials',
      description: 'Understand official and alternative ARS→USD references, CPI structure, and inflation drivers.',
    },
    {
      title: 'Module 2 — Budget resilience toolkit',
      description: 'Design adaptable budgets, prioritise needs, and map expenses to actual price behaviour.',
    },
    {
      title: 'Module 3 — Savings pathways',
      description: 'Review diversified savings options and risk awareness frameworks without providing direct advice.',
    },
    {
      title: 'Module 4 — Monitoring routines',
      description: 'Build weekly dashboards to keep goals visible and align them with market signals.',
    },
  ];

  const insightStatements = [
    {
      title: 'Transparent analytics',
      quote: 'Análisis transparentes y datos de mercado para decidir con seguridad.',
      description:
        'Weekly ARS→USD trackers contextualise official, blue, and CCL references alongside CPI releases for clarity.',
    },
    {
      title: 'Reliable guidance cues',
      quote: 'Información confiable que respalda elecciones responsables sobre tu dinero.',
      description:
        'Every data point cites public sources and includes commentary in plain language to support informed choices.',
    },
    {
      title: 'Opportunity awareness',
      quote: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
      description:
        'Scenario planners and alerts spotlight shifts in purchasing power so you can adapt responsibly.',
    },
  ];

  return (
    <div>
      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-content">
          <span className="badge" aria-label="Service area">
            Buenos Aires • Monitoring Argentina&apos;s inflation story
          </span>
          <h1 id="hero-title" className="hero-title">
            Tu Progreso Hoy — responsible inflation insight and learning for Argentina
          </h1>
          <p className="hero-subtitle">Datos verificados para planificar tu presupuesto.</p>
          <p className="hero-subtitle">Decisiones responsables, objetivos nítidos.</p>
          <p className="hero-subtitle">Pasos acertados hoy, mejor futuro mañana.</p>
          <p className="language-note">
            English-first explanations with supporting Español content for regional relevance.
          </p>
          <div className="hero-buttons">
            <button className="btn btn-primary" onClick={() => navigate('/inflation')}>
              Explore inflation insights
            </button>
            <button className="btn btn-outline" onClick={() => navigate('/course')}>
              Review course syllabus
            </button>
          </div>
          <div className="hero-promise" role="list">
            <article className="hero-card" role="listitem">
              <h3>Conocimiento financiero impulsado por tendencias.</h3>
              <p>
                We translate macro indicators into practical dashboards so you can track purchasing power shifts with
                context.
              </p>
            </article>
            <article className="hero-card" role="listitem">
              <h3>Análisis transparentes y datos de mercado para decidir con seguridad.</h3>
              <p>
                Every chart includes methodology notes and historical comparatives to reinforce responsible decisions.
              </p>
            </article>
            <article className="hero-card" role="listitem">
              <h3>Información confiable que respalda elecciones responsables sobre tu dinero.</h3>
              <p>Dual-language summaries keep stakeholders aligned without replacing regulated financial advice.</p>
            </article>
            <article className="hero-card" role="listitem">
              <h3>Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.</h3>
              <p>
                Alerts highlight trend inflection points, encouraging thoughtful adjustments instead of impulsive
                reactions.
              </p>
            </article>
          </div>
          <span className="badge-sp" aria-label="Educational platform notice">
            Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </span>
        </div>
      </section>

      <section className="section-light" aria-labelledby="tracker-heading">
        <div className="container">
          <h2 id="tracker-heading">ARS→USD tracker</h2>
          <p>
            Updated weekly: official, blue, and CCL references quoted as ARS per USD. Context accompanies every change to
            underline responsible interpretation.
          </p>
          <div className="stats-grid" role="list">
            <div className="stat-card" role="listitem">
              <h4>Official reference</h4>
              <p>
                ARS {current.official.toFixed(2)} per USD
                <br />
                <span className="language-note">
                  {officialChange >= 0 ? '+' : ''}
                  {officialChange.toFixed(2)}% vs previous week
                </span>
              </p>
            </div>
            <div className="stat-card" role="listitem">
              <h4>Blue reference</h4>
              <p>
                ARS {current.blue.toFixed(2)} per USD
                <br />
                <span className="language-note">
                  {blueChange >= 0 ? '+' : ''}
                  {blueChange.toFixed(2)}% vs previous week
                </span>
              </p>
            </div>
            <div className="stat-card" role="listitem">
              <h4>Context note</h4>
              <p>
                We benchmark CPI releases, AFIP updates, and energy tariffs for better demand planning and household
                budgeting.
              </p>
            </div>
            <div className="stat-card" role="listitem">
              <h4>Weekly spotlight</h4>
              <p>Conocimiento financiero impulsado por tendencias applied to short summaries keeps your actions grounded.</p>
            </div>
          </div>
          <div className="table-wrapper">
            <table className="tracker-table" aria-describedby="tracker-heading">
              <caption className="language-note">
                Tabla bilingüe: valores expresados en pesos argentinos por dólar estadounidense (ARS/USD).
              </caption>
              <thead>
                <tr>
                  <th scope="col">Week of</th>
                  <th scope="col">Official</th>
                  <th scope="col">Blue</th>
                  <th scope="col">CCL</th>
                </tr>
              </thead>
              <tbody>
                {trackerData.map((row) => (
                  <tr key={row.date}>
                    <td>{row.date}</td>
                    <td>ARS {row.official.toFixed(2)}</td>
                    <td>ARS {row.blue.toFixed(2)}</td>
                    <td>ARS {row.ccl.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="section-muted" aria-labelledby="insights-heading">
        <div className="container">
          <h2 id="insights-heading">Insights designed for clarity</h2>
          <p>
            We keep decision-making grounded by combining headline indicators with household-relevant interpretation.
          </p>
          <div className="card-grid" role="list">
            {insightStatements.map((item) => (
              <div key={item.title} className="card" role="listitem">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
                <p className="language-note">{item.quote}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-light" aria-labelledby="course-overview">
        <div className="container">
          <h2 id="course-overview">Course overview</h2>
          <p>
            De la información al aprendizaje: fortalece tu criterio financiero paso a paso. The course combines live
            sessions, micro videos, and guided templates.
          </p>
          <div className="card-grid" role="list">
            {modules.map((module) => (
              <div key={module.title} className="card" role="listitem">
                <h3>{module.title}</h3>
                <p>{module.description}</p>
              </div>
            ))}
          </div>
          <div className="notice" role="status">
            <strong>Target participants:</strong> Young professionals, families planning long-term purchases, and
            students building responsible money habits.{' '}
            <span className="language-note">Contenido complementario en español disponible en cada módulo.</span>
          </div>
          <div className="hero-buttons" style={{ marginTop: '2rem' }}>
            <Link className="btn btn-primary" to="/course">
              See full syllabus
            </Link>
            <button className="btn btn-outline" onClick={() => navigate('/resources')}>
              Browse learning resources
            </button>
          </div>
        </div>
      </section>

      <section className="section-muted" aria-labelledby="testimonials-heading">
        <div className="container">
          <h2 id="testimonials-heading">Testimonials</h2>
          <p>Stories from community members who pair inflation awareness with practical learning.</p>
          <div className="testimonials" role="list">
            {testimonials.map((item) => (
              <figure key={item.name} className="testimonial" role="listitem">
                <blockquote>{item.quote}</blockquote>
                <figcaption style={{ marginTop: '1rem', fontWeight: '600' }}>{item.name}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className="section-dark" aria-labelledby="cta-heading">
        <div className="container">
          <h2 id="cta-heading">Get a responsible head start today</h2>
          <p>
            Our double opt-in system assures you validate subscriptions intentionally. Join the next cohort for timely
            data walkthroughs and disciplined budgeting routines.
          </p>
          <div className="form-card" id="trial-form">
            <form onSubmit={handleSubmit}>
              <div className="form-grid double">
                <div>
                  <label htmlFor="name">Full name</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    autoComplete="name"
                    required
                    value={formData.name}
                    onChange={handleChange}
                  />
                </div>
                <div>
                  <label htmlFor="email">Email</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="form-grid">
                <div>
                  <label htmlFor="goal">What financial objective are you focusing on?</label>
                  <textarea
                    id="goal"
                    name="goal"
                    rows="3"
                    placeholder="Tell us about the budgeting or savings challenge you want to work on."
                    value={formData.goal}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="language">Preferred language</label>
                  <select id="language" name="language" value={formData.language} onChange={handleChange}>
                    <option value="English">English</option>
                    <option value="Español">Español</option>
                    <option value="Bilingual">Bilingual</option>
                  </select>
                </div>
              </div>
              <div className="checkbox-field">
                <input
                  id="consent"
                  name="consent"
                  type="checkbox"
                  checked={formData.consent}
                  onChange={handleChange}
                  required
                />
                <label htmlFor="consent">
                  I agree to the <Link to="/terms">terms of use</Link> and <Link to="/privacy">privacy policy</Link>.
                </label>
              </div>
              <div className="checkbox-field">
                <input
                  id="confirm"
                  name="confirm"
                  type="checkbox"
                  checked={formData.confirm}
                  onChange={handleChange}
                  required
                />
                <label htmlFor="confirm">
                  I understand a double opt-in email will be sent and must be confirmed to receive the free trial lesson.
                </label>
              </div>
              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '1.5rem' }}>
                Получить бесплатный пробный урок
              </button>
            </form>
            <p className="language-note" style={{ marginTop: '1rem' }}>
              We do not send promotional email until you confirm the double opt-in link. | No iniciamos comunicaciones
              sin tu confirmación explícita.
            </p>
            {submitMessage && (
              <div className="notice" role="status" aria-live="polite">
                {submitMessage}
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
```