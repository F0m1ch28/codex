```javascript
import React from 'react';

const Terms = () => {
  return (
    <section className="section-light" aria-labelledby="terms-title">
      <div className="container legal-section">
        <h1 id="terms-title">Terms of Use</h1>
        <p>
          Welcome to Tu Progreso Hoy. By accessing https://www.tuprogresohoy.com you agree to these terms, which are
          designed to encourage informed and responsible learning.
        </p>

        <h2>Purpose of the service</h2>
        <p>
          We provide educational content, data dashboards, and community sessions. Plataforma educativa con datos
          esenciales, sin asesoría financiera directa. We do not deliver investment, legal, or tax advice.
        </p>

        <h2>Eligibility</h2>
        <p>
          You must be at least 16 years old to create an account or join live sessions. Guardians may enrol minors in
          consultation with our team.
        </p>

        <h2>Responsible usage</h2>
        <ul>
          <li>Do not redistribute content without written consent.</li>
          <li>Use insights to support thoughtful planning, not speculation.</li>
          <li>Respect community guidelines during live sessions and forums.</li>
        </ul>

        <h2>Payment &amp; trials</h2>
        <p>
          The free trial lesson is available after double opt-in confirmation. Continuing with the full course may
          require payment under separate terms presented during checkout.
        </p>

        <h2>Limitation of liability</h2>
        <p>
          While we strive for accuracy, markets can change quickly. Datos verificados para planificar tu presupuesto,
          pero siempre complementa con asesoría profesional si necesitas una recomendación individual.
        </p>

        <h2>Updates to terms</h2>
        <p>
          We may update these terms to reflect new features or regulations. Changes take effect once published on this
          page with the revised date.
        </p>

        <h2>Contact</h2>
        <p>
          Questions about these terms can be sent to <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>.
        </p>

        <p className="language-note">
          Pasos acertados hoy, mejor futuro mañana — including how you interpret and apply our materials.
        </p>
      </div>
    </section>
  );
};

export default Terms;
```