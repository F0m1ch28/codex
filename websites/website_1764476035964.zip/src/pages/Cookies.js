```javascript
import React from 'react';

const Cookies = () => {
  return (
    <section className="section-light" aria-labelledby="cookies-title">
      <div className="container legal-section">
        <h1 id="cookies-title">Cookies Policy</h1>
        <p>
          This policy explains how Tu Progreso Hoy uses cookies on https://www.tuprogresohoy.com. Decisiones
          responsables, objetivos nítidos también se aplican al manejo de tus datos digitales.
        </p>

        <h2>Essential cookies</h2>
        <p>
          These cookies keep the site functional (for example, remembering language choices). They are always enabled
          because they are required for security and accessibility.
        </p>

        <h2>Analytics cookies</h2>
        <p>
          We use lightweight analytics to understand aggregated behaviour only after you accept cookies via the opt-in
          banner. We do not use advertising or tracking pixels.
        </p>

        <h2>Managing preferences</h2>
        <p>
          You can accept or decline analytics cookies through the banner. If you wish to change your choice later, clear
          cookies in your browser and revisit the site.
        </p>

        <h2>Third-party services</h2>
        <p>
          Our analytics provider processes anonymised data under a privacy-focused agreement. No personal information is
          shared unless you have explicitly provided it via forms.
        </p>

        <h2>Contact</h2>
        <p>
          For cookie-related questions, email <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>.
        </p>

        <p className="language-note">Plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
      </div>
    </section>
  );
};

export default Cookies;
```