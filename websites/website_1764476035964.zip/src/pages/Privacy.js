```javascript
import React from 'react';

const Privacy = () => {
  return (
    <section className="section-light" aria-labelledby="privacy-title">
      <div className="container legal-section">
        <h1 id="privacy-title">Privacy Policy</h1>
        <p>
          Tu Progreso Hoy operates https://www.tuprogresohoy.com as an educational SaaS platform delivering inflation
          insights and a personal finance starter course. Datos verificados para planificar tu presupuesto y proteger tu
          información.
        </p>

        <h2>Information we collect</h2>
        <ul>
          <li>Contact details you provide (name, email, language preference, stated goals).</li>
          <li>Form submissions related to course participation and resource access.</li>
          <li>Aggregated analytics events collected only after you accept optional cookies.</li>
        </ul>

        <h2>Why we collect data</h2>
        <ul>
          <li>To deliver requested educational materials and ensure double opt-in verification.</li>
          <li>To understand high-level usage trends and improve content relevance.</li>
          <li>To comply with legal obligations regarding records of consent.</li>
        </ul>

        <h2>Double opt-in commitment</h2>
        <p>
          Every subscription or enquiry triggers a confirmation email. We do not send course schedules or updates until
          you confirm. This protects your inbox and prevents unauthorised signups.
        </p>

        <h2>Data storage &amp; security</h2>
        <p>
          We store data in secure cloud infrastructure with access restricted to authorised team members located in
          Argentina. Encryption in transit and regular reviews maintain confidentiality. Información confiable que respalda elecciones responsables sobre tu dinero.
        </p>

        <h2>Sharing data</h2>
        <p>
          We do not sell personal data. We may share information with processors who provide email delivery, analytics,
          or customer support strictly under confidentiality agreements.
        </p>

        <h2>Your rights</h2>
        <ul>
          <li>Access, update, or request deletion of your personal information.</li>
          <li>Withdraw consent for communications at any time by using unsubscribe links.</li>
          <li>Request details about processors handling your information.</li>
        </ul>

        <h2>Contact</h2>
        <p>
          For privacy questions, email <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a> after
          confirming your identity through the double opt-in procedure.
        </p>

        <p className="language-note">Pasos acertados hoy, mejor futuro mañana — that includes protecting your data with diligence.</p>
      </div>
    </section>
  );
};

export default Privacy;
```