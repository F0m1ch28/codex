```javascript
import React from 'react';
import { Link } from 'react-router-dom';

const Resources = () => {
  const resources = [
    {
      title: 'Weekly inflation briefing template',
      summary: 'A structured worksheet that guides you through CPI highlights, FX moves, and action steps.',
      spanish: 'Plantilla estructurada para resumir el IPC, los movimientos del dólar y los próximos pasos.',
      type: 'Template',
    },
    {
      title: 'Budget conversation checklist',
      summary: 'Questions to align households or teams on spending priorities and update cadences.',
      spanish: 'Preguntas para alinear prioridades de gastos y frecuencia de revisión.',
      type: 'Checklist',
    },
    {
      title: 'Glossary: Inflation & FX (EN/ES)',
      summary: 'Key terminology explained in English with Spanish equivalents for cross-team collaboration.',
      spanish: 'Términos clave explicados en inglés y español para equipos mixtos.',
      type: 'Glossary',
    },
    {
      title: 'Case study: Managing irregular income',
      summary:
        'How a freelance professional stabilised expenses by pairing ARS→USD monitoring with envelope budgeting.',
      spanish: 'Caso de cómo un profesional independiente estabilizó gastos con monitoreo ARS→USD.',
      type: 'Article',
    },
  ];

  return (
    <div>
      <section className="section-light" aria-labelledby="resources-title">
        <div className="container">
          <h1 id="resources-title">Resources</h1>
          <p>
            Our resource centre delivers concise guides, templates, and bilingual glossaries so you can apply insights
            immediately.
          </p>
          <div className="resources-list" role="list">
            {resources.map((item) => (
              <article key={item.title} className="resource-card" role="listitem">
                <span className="badge">{item.type}</span>
                <h3>{item.title}</h3>
                <p>{item.summary}</p>
                <p className="language-note">{item.spanish}</p>
              </article>
            ))}
          </div>
          <div className="notice" style={{ marginTop: '2rem' }}>
            Want personalised guidance on which resource to start with?{' '}
            <Link to="/contact">Contact us</Link> after confirming your double opt-in subscription.
          </div>
        </div>
      </section>
    </div>
  );
};

export default Resources;
```