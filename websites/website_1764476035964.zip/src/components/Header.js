```javascript
import React, { useState, useEffect } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  const handleTrialClick = () => {
    if (location.pathname === '/') {
      const target = document.getElementById('trial-form');
      if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      navigate('/', { state: { fromCTA: true } });
    }
  };

  return (
    <header>
      <nav className="navbar" aria-label="Primary navigation">
        <div className="nav-brand">
          <span>Tu Progreso Hoy</span>
          <span className="nav-tagline">Inflation insight &amp; learning hub • Argentina</span>
        </div>
        <button
          className="menu-toggle"
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Toggle navigation"
        >
          ☰
        </button>
        <div id="primary-navigation" className={`nav-links ${menuOpen ? 'open' : ''}`}>
          <NavLink to="/" className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
            Home
          </NavLink>
          <NavLink to="/inflation" className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
            Inflation
          </NavLink>
          <NavLink to="/course" className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
            Course
          </NavLink>
          <NavLink to="/resources" className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
            Resources
          </NavLink>
          <NavLink to="/faq" className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
            FAQ
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
            Contact
          </NavLink>
          <button className="nav-btn" onClick={handleTrialClick}>
            Free trial lesson
          </button>
        </div>
      </nav>
    </header>
  );
};

export default Header;
```