```javascript
import React, { useEffect, useState } from 'react';

const DisclaimerModal = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const dismissed = localStorage.getItem('tph_disclaimer_ack');
    if (!dismissed) {
      const timer = setTimeout(() => setVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    localStorage.setItem('tph_disclaimer_ack', 'acknowledged');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="disclaimer-modal-backdrop" role="dialog" aria-modal="true" aria-label="Financial service disclaimer">
      <div className="disclaimer-modal">
        <h3>Мы не предоставляем финансовые услуги</h3>
        <p>
          We do not provide financial services, investment brokerage, or individual advice. Tu Progreso Hoy is an
          educational Software-as-a-Service platform focused on responsible decision-making.
        </p>
        <p>
          Plataforma educativa con datos esenciales, sin asesoría financiera directa. Please consult a licensed
          professional for personalised guidance.
        </p>
        <button className="btn btn-primary" type="button" onClick={handleClose}>
          I understand
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;
```