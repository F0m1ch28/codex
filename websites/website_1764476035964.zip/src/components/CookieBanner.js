```javascript
import React, { useEffect, useState } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('tph_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem('tph_cookie_consent', choice);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <p>
        We use cookies to understand traffic and improve this educational experience. You can accept analytics cookies
        or decline non-essential cookies. Essential cookies keep the site functional.
      </p>
      <div className="cookie-actions">
        <button className="btn btn-primary" type="button" onClick={() => handleChoice('accepted')}>
          Accept
        </button>
        <button className="btn btn-outline" type="button" onClick={() => handleChoice('declined')}>
          Decline
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;
```