```javascript
import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer>
      <div className="container footer-grid">
        <div className="footer-grid-columns">
          <div>
            <h3 style={{ color: '#F8FAFC' }}>Tu Progreso Hoy</h3>
            <p>
              Datos verificados para planificar tu presupuesto.
              <br />
              Decisiones responsables, objetivos nítidos.
            </p>
            <p className="language-note">
              Platform in English with Spanish support to serve Argentina responsibly.
            </p>
            <p>Plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
          </div>
          <div>
            <h4 style={{ color: '#E2E8F0' }}>Navigate</h4>
            <nav aria-label="Footer navigation">
              <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                <li>
                  <Link to="/">Home</Link>
                </li>
                <li>
                  <Link to="/inflation">Inflation</Link>
                </li>
                <li>
                  <Link to="/course">Course</Link>
                </li>
                <li>
                  <Link to="/resources">Resources</Link>
                </li>
                <li>
                  <Link to="/faq">FAQ</Link>
                </li>
                <li>
                  <Link to="/contact">Contact</Link>
                </li>
              </ul>
            </nav>
          </div>
          <div>
            <h4 style={{ color: '#E2E8F0' }}>Visit &amp; Call</h4>
            <p>
              Av. 9 de Julio 1000
              <br />
              C1043 Buenos Aires, Argentina
            </p>
            <p>
              Phone: <a href="tel:+541155551234">+54 11 5555-1234</a>
              <br />
              Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
            </p>
            <div className="social-links">
              <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
                in
              </a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="X formerly Twitter">
                X
              </a>
              <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
                ▶
              </a>
            </div>
          </div>
          <div>
            <h4 style={{ color: '#E2E8F0' }}>Compliance</h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              <li>
                <Link to="/privacy">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/cookies">Cookies Policy</Link>
              </li>
              <li>
                <Link to="/terms">Terms of Use</Link>
              </li>
              <li>
                <a href="/sitemap.xml">Sitemap</a>
              </li>
            </ul>
            <p className="language-note">Información confiable que respalda elecciones responsables sobre tu dinero.</p>
          </div>
        </div>
        <div>
          <small>
            © {new Date().getFullYear()} Tu Progreso Hoy. Conocimiento financiero impulsado por tendencias. All rights
            reserved.
          </small>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
```