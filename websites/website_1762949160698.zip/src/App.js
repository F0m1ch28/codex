import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Inflation from './pages/Inflation';
import Course from './pages/Course';
import Resources from './pages/Resources';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import Privacy from './pages/Privacy';
import Cookies from './pages/Cookies';
import Terms from './pages/Terms';

const App = () => {
  return (
    <Router>
      <Helmet>
        <title>Tu Progreso Hoy | Argentina-focused financial learning</title>
        <meta
          name="description"
          content="Tu Progreso Hoy empowers learners with datos confiables on argentina inflation, ars usd movements, finanzas personales, budgeting argentina, curso finanzas, and economic trends."
        />
        <link rel="alternate" hreflang="en" href="https://www.tuprogresohoy.com/" />
        <link rel="alternate" hreflang="es-AR" href="https://www.tuprogresohoy.com/es-AR/" />
      </Helmet>
      <ScrollToTop />
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/inflation" element={<Inflation />} />
          <Route path="/course" element={<Course />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookies" element={<Cookies />} />
          <Route path="/terms" element={<Terms />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </Router>
  );
};

export default App;