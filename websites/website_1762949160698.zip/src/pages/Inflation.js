import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Inflation.module.css';

const Inflation = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Inflation Lab | Tu Progreso Hoy methodology</title>
      </Helmet>
      <section className={styles.hero}>
        <h1>Inflation Lab</h1>
        <p>
          Transparent methodology guiding argentina inflation analysis, CPI context, and FX linkages. Designed to keep
          learners ahead of macro shifts with datos confiables.
        </p>
      </section>

      <section className={styles.methodology}>
        <h2>Methodology</h2>
        <p>
          We synthesize official INDEC releases, provincial price trackers, and independent research institutes. Each
          visualization includes sampling notes, update cadence, and cross-checks with ars usd parallel markets to uncover
          meaningful economic trends.
        </p>
        <div className={styles.chartWrapper} role="img" aria-label="Sample inflation trend chart">
          <svg viewBox="0 0 400 240">
            <defs>
              <linearGradient id="lineGradient" x1="0" x2="1" y1="0" y2="0">
                <stop offset="0%" stopColor="#2563eb" />
                <stop offset="100%" stopColor="#38bdf8" />
              </linearGradient>
            </defs>
            <polyline
              fill="none"
              stroke="url(#lineGradient)"
              strokeWidth="4"
              strokeLinecap="round"
              points="0,200 60,150 110,120 160,80 210,110 260,70 310,90 360,60 400,90"
            />
            <polyline
              fill="rgba(37,99,235,0.12)"
              stroke="none"
              points="0,200 60,150 110,120 160,80 210,110 260,70 310,90 360,60 400,90 400,240 0,240"
            />
          </svg>
        </div>
      </section>

      <section className={styles.context}>
        <div className={styles.card}>
          <h3>CPI breakdown</h3>
          <p>
            Analyze weighted contributions: alimentos, vivienda, transporte, salud, educación. Each segment includes YOY,
            MOM, and seasonality notes plus inflation-adjusted budgeting argentina tips.
          </p>
        </div>
        <div className={styles.card}>
          <h3>FX context</h3>
          <p>
            Compare official, MEP, CCL, and informal ars usd references. Highlight spreads impacting import costs,
            inflation expectations, and curso finanzas scenario planning.
          </p>
        </div>
        <div className={styles.card}>
          <h3>Signals & risks</h3>
          <p>
            Spot leading indicators: commodity shifts, wage negotiations, and regulatory updates. Insights include recommended
            reflection prompts to integrate into finanzas personales journals.
          </p>
        </div>
      </section>

      <section className={styles.faq}>
        <h2>FAQ</h2>
        <details>
          <summary>How do you handle data gaps?</summary>
          <p>
            We flag provisional values, annotate uncertainty ranges, and avoid overfitting interpretations. Community members
            receive updates once official data is confirmed.
          </p>
        </details>
        <details>
          <summary>Can I download historical series?</summary>
          <p>
            Yes. Subscribers with double opt-in confirmed access can export CSV and JSON files with methodology notes.
          </p>
        </details>
        <details>
          <summary>Do you model inflation-adjusted salaries?</summary>
          <p>
            We provide frameworks to adjust ingresos, yet decisions should align with personal context. Educational content only.
          </p>
        </details>
      </section>
    </div>
  );
};

export default Inflation;