import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Resources.module.css';

const articles = [
  {
    id: 1,
    language: 'en',
    title: 'Argentina inflation toolkit for mindful decision-making',
    summary:
      'Understand monthly price shifts and build a reflection routine to stay grounded while adapting budgets.',
  },
  {
    id: 2,
    language: 'es-AR',
    title: 'Guía rápida para mantener finanzas personales en contexto argentino',
    summary:
      'Descubrí pasos concretos para planificar gastos, armar fondos de emergencia y priorizar bienestar.',
  },
  {
    id: 3,
    language: 'en',
    title: 'Tracking ars usd scenarios without overwhelm',
    summary:
      'Learn how to use reference bands, alerts, and community check-ins to integrate currency updates with calma.',
  },
  {
    id: 4,
    language: 'es-AR',
    title: 'Glosario esencial: economic trends y conceptos clave',
    summary:
      'Definiciones breves y ejemplos prácticos para conversar sobre inflación, salarios reales y consumo.',
  },
];

const Resources = () => {
  const [filter, setFilter] = useState('all');

  const filteredArticles =
    filter === 'all' ? articles : articles.filter((article) => article.language === filter);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Resources | Tu Progreso Hoy library</title>
      </Helmet>
      <section className={styles.hero}>
        <h1>Resource Library</h1>
        <p>
          Explore bilingual articles and glossaries that merge argentina inflation realities with finanzas personales
          practices. Hecho en Buenos Aires for learners everywhere.
        </p>
        <div className={styles.filters}>
          <button
            type="button"
            className={filter === 'all' ? styles.active : ''}
            onClick={() => setFilter('all')}
          >
            All
          </button>
          <button
            type="button"
            className={filter === 'en' ? styles.active : ''}
            onClick={() => setFilter('en')}
          >
            English
          </button>
          <button
            type="button"
            className={filter === 'es-AR' ? styles.active : ''}
            onClick={() => setFilter('es-AR')}
          >
            Español (AR)
          </button>
        </div>
      </section>

      <section className={styles.grid}>
        {filteredArticles.map((article) => (
          <article key={article.id}>
            <span>{article.language === 'en' ? 'English' : 'Español (AR)'}</span>
            <h2>{article.title}</h2>
            <p>{article.summary}</p>
            <a href="/contact">Request full article</a>
          </article>
        ))}
      </section>
    </div>
  );
};

export default Resources;