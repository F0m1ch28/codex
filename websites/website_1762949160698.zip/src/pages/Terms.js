import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Terms of Use | Tu Progreso Hoy</title>
      </Helmet>
      <section>
        <h1>Terms of Use</h1>
        <p>
          By accessing Tu Progreso Hoy, you agree to engage with content for educational purposes only. We do not offer
          advisory or financial services. Our resources support learning about argentina inflation, ars usd dynamics, and
          finanzas personales habits using datos confiables.
        </p>
        <h2>Acceptable use</h2>
        <p>
          Respect community standards, acknowledge source citations, and avoid misrepresenting educational materials as financial advice.
        </p>
        <h2>Intellectual property</h2>
        <p>
          All content, datasets, and visuals are licensed to Tu Progreso Hoy. You may reference them with attribution for non-commercial purposes.
        </p>
        <h2>Updates</h2>
        <p>
          Terms may evolve as economic trends shift or regulations update. We will notify users via double opt-in email where applicable.
        </p>
      </section>
    </div>
  );
};

export default Terms;