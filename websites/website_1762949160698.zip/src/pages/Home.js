import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import styles from './Home.module.css';

const statsData = [
  { id: 1, label: 'Learners tracking argentina inflation', value: 4500 },
  { id: 2, label: 'Datasets on ars usd & economic trends', value: 320 },
  { id: 3, label: 'Learning paths covering finanzas personales', value: 18 },
];

const servicesData = [
  {
    id: 1,
    title: 'Real-time argentina inflation dashboards',
    description:
      'Monitor CPI, PPI, and localized price baskets with datos confiables and transparent methodology.',
  },
  {
    id: 2,
    title: 'Personalized budgeting argentina toolkit',
    description:
      'Scenario planning for salary adjustments, alquiler updates, and essential expenses in Buenos Aires.',
  },
  {
    id: 3,
    title: 'Interactive curso finanzas modules',
    description:
      'Micro-lessons on finanzas personales, ahorro, and resilient decision-making across inflationary cycles.',
  },
];

const processSteps = [
  {
    step: 1,
    title: 'Discover insights',
    text: 'Explore economic trends with intuitive narratives and bilingual context to anchor cada decisión.',
  },
  {
    step: 2,
    title: 'Apply frameworks',
    text: 'Use budgeting argentina templates aligned with ARS realities and localized FX sensitivity.',
  },
  {
    step: 3,
    title: 'Track progress',
    text: 'Measure learning outcomes and iterate with evidence-based reflections and community feedback.',
  },
];

const testimonials = [
  {
    name: 'Lucía Fernández',
    role: 'Marketing Analyst, Palermo',
    quote:
      'The argentina inflation trackers and finanzas personales playbooks gave me clarity to plan quarterly budgets without anxiety.',
  },
  {
    name: 'Martín Rivas',
    role: 'Founder, CABA',
    quote:
      'I trust the datos confiables from Tu Progreso Hoy. The ars usd watchlist and trend briefs save me hours every week.',
  },
  {
    name: 'Sofía Benítez',
    role: 'Student, Córdoba',
    quote:
      'Curso finanzas broke down complex ideas into simple steps. The double opt-in access process also felt very respectful of my privacy.',
  },
];

const teamMembers = [
  {
    name: 'Camila Ortega',
    role: 'Chief Learning Architect',
    bio: 'Designs bilingual experiences linking economic trends with actionable finanzas personales strategies.',
    image: 'https://picsum.photos/400/400?random=31',
  },
  {
    name: 'Diego Álvarez',
    role: 'Head of Data Reliability',
    bio: 'Ensures datos confiables, validating CPI and ars usd sources across public and private feeds.',
    image: 'https://picsum.photos/400/400?random=32',
  },
  {
    name: 'Valeria Suárez',
    role: 'Community Experience Lead',
    bio: 'Connects learners with budgeting argentina cohorts, facilitating collaborative accountability.',
    image: 'https://picsum.photos/400/400?random=33',
  },
];

const projectsData = [
  {
    id: 1,
    title: 'Inflation diary for student budgets',
    category: 'Education',
    image: 'https://picsum.photos/1200/800?random=41',
  },
  {
    id: 2,
    title: 'SME liquidity planning toolkit',
    category: 'Business',
    image: 'https://picsum.photos/1200/800?random=42',
  },
  {
    id: 3,
    title: 'Household resilience sprint',
    category: 'Community',
    image: 'https://picsum.photos/1200/800?random=43',
  },
];

const faqItems = [
  {
    question: 'How frequently is the argentina inflation data updated?',
    answer:
      'We refresh inflation dashboards weekly and issue alerts for material shifts in CPI, CPI core, and provincial variations.',
  },
  {
    question: 'What type of ars usd scenarios can I explore?',
    answer:
      'Simulations span official, blue, and blended FX references with stress tests for essential goods, servicios, and savings goals.',
  },
  {
    question: 'Is the curso finanzas accessible in Spanish?',
    answer:
      'Yes, all modules are bilingual (English and es-AR) so you can switch seamlessly between languages.',
  },
];

const blogPosts = [
  {
    id: 1,
    title: 'Mapping argentina inflation impact on everyday gastos',
    date: 'July 2024',
    excerpt:
      'Analizamos cómo distintos hogares ajustan sus gastos frente a picos inflacionarios y qué tácticas funcionan.',
  },
  {
    id: 2,
    title: 'Understanding ars usd spreads for smarter budgeting argentina',
    date: 'June 2024',
    excerpt:
      'Exploramos las brechas entre distintos tipos de cambio y cómo anticipar movimientos relevantes.',
  },
  {
    id: 3,
    title: 'Finanzas personales: hábitos sostenibles en contextos volátiles',
    date: 'May 2024',
    excerpt:
      'Construimos rituales semanales que sostienen decisiones financieras éticas y conscientes durante cambios bruscos.',
  },
];

const Home = () => {
  const navigate = useNavigate();
  const [tracker, setTracker] = useState({ rate: null, lastUpdated: null, error: null });
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('All');
  const [formData, setFormData] = useState({ name: '', email: '' });
  const [formErrors, setFormErrors] = useState({});
  const [disclaimerVisible, setDisclaimerVisible] = useState(true);
  const [stats, setStats] = useState(statsData.map((item) => ({ ...item, display: 0 })));

  useEffect(() => {
    const fetchRate = async () => {
      try {
        const response = await fetch('https://api.exchangerate.host/latest?base=ARS&symbols=USD');
        if (!response.ok) throw new Error('Network response was not ok');
        const data = await response.json();
        const rate = data?.rates?.USD ? 1 / data.rates.USD : null;
        setTracker({
          rate: rate ? rate.toFixed(4) : null,
          lastUpdated: new Date().toLocaleString(),
          error: null,
        });
      } catch (error) {
        setTracker((prev) => ({
          ...prev,
          error: 'Live rate unavailable. Using last known reference.',
        }));
      }
    };
    fetchRate();
    const interval = setInterval(fetchRate, 60000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const statInterval = setInterval(() => {
      setStats((prev) =>
        prev.map((item) => {
          if (item.display >= item.value) return item;
          const increment = Math.ceil(item.value / 60);
          const nextValue = item.display + increment;
          return { ...item, display: nextValue > item.value ? item.value : nextValue };
        })
      );
    }, 30);
    return () => clearInterval(statInterval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'All') {
      return projectsData;
    }
    return projectsData.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  const handleFilterChange = (category) => {
    setProjectFilter(category);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const errors = {};
    if (!formData.name.trim()) {
      errors.name = 'Please enter your full name.';
    }
    if (!formData.email.trim()) {
      errors.email = 'Please provide an email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      errors.email = 'Please enter a valid email address.';
    }
    setFormErrors(errors);
    if (Object.keys(errors).length === 0) {
      navigate('/thank-you', { state: { lead: formData } });
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Tu Progreso Hoy | argentina inflation learning platform</title>
      </Helmet>
      {disclaimerVisible && (
        <div className={styles.modalOverlay} role="dialog" aria-modal="true" aria-label="Disclaimer">
          <div className={styles.modalContent}>
            <h2>Transparency first</h2>
            <p>We do not provide financial services. Educational resources only.</p>
            <button type="button" onClick={() => setDisclaimerVisible(false)}>
              I understand
            </button>
          </div>
        </div>
      )}
      <section className={styles.hero}>
        <img
          src="https://picsum.photos/1600/900?random=21"
          alt="Professional team reviewing economic dashboards"
          className={styles.heroImage}
          loading="lazy"
        />
        <div className={styles.flagOverlay} aria-hidden="true" />
        <div className={styles.heroContent}>
          <h1>
            Navigate argentina inflation with clarity and purpose-driven finanzas personales skills.
          </h1>
          <p>
            Tu Progreso Hoy equips you with data-driven playbooks, bilingual resources, and community support to
            build resilient budgeting argentina habits across every economic cycle.
          </p>
          <div className={styles.heroActions}>
            <button
              type="button"
              onClick={() => document.getElementById('cta').scrollIntoView({ behavior: 'smooth' })}
              className={styles.primary}
            >
              Start your learning journey
            </button>
            <button
              type="button"
              onClick={() => document.getElementById('services').scrollIntoView({ behavior: 'smooth' })}
              className={styles.secondary}
            >
              Explore insights
            </button>
          </div>
        </div>
      </section>

      <section className={styles.tracker} aria-live="polite">
        <div className={styles.trackerContent}>
          <h2>ARS → USD real-time tracker</h2>
          <p>
            Monitor currency shifts influencing finanzas personales and economic trends. Source: exchangerate.host (datos confiables).
          </p>
        </div>
        <div className={styles.trackerValue}>
          <span className={styles.rate}>
            {tracker.rate ? `1 USD ≈ ${tracker.rate} ARS` : 'Loading...'}
          </span>
          <span className={styles.meta}>
            {tracker.lastUpdated ? `Last updated: ${tracker.lastUpdated}` : 'Awaiting update'}
          </span>
          {tracker.error && <span className={styles.error}>{tracker.error}</span>}
        </div>
      </section>

      <section className={styles.stats} aria-label="Key achievements">
        {stats.map((item) => (
          <div key={item.id} className={styles.statCard}>
            <span className={styles.statNumber}>{item.display.toLocaleString()}</span>
            <p>{item.label}</p>
          </div>
        ))}
      </section>

      <section id="services" className={styles.services}>
        <div className={styles.sectionHeader}>
          <h2>Insights & analytics grounded in Buenos Aires realities</h2>
          <p>
            Combine argentina inflation research, ars usd variance tracking, and finanzas personales stories to
            take confident action con datos confiables.
          </p>
        </div>
        <div className={styles.serviceGrid}>
          {servicesData.map((service) => (
            <article key={service.id} className={styles.serviceCard}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <button
                type="button"
                className={styles.linkButton}
                onClick={() => document.getElementById('cta').scrollIntoView({ behavior: 'smooth' })}
              >
                Learn more
              </button>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <h2>A process designed for sustainable cambio</h2>
          <p>
            From early awareness to continuous improvement, our methodology supports your progreso hoy y mañana.
          </p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <div key={step.step} className={styles.processCard}>
              <span className={styles.stepNumber}>0{step.step}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Testimonials">
        <div className={styles.sectionHeader}>
          <h2>Community voices</h2>
          <p>
            Tu Progreso Hoy learners share how argentina inflation insights and curso finanzas modules fit into
            real life.
          </p>
        </div>
        <div className={styles.testimonialContent}>
          <blockquote className={styles.quote}>
            “{testimonials[currentTestimonial].quote}”
          </blockquote>
          <div className={styles.person}>
            <span>{testimonials[currentTestimonial].name}</span>
            <small>{testimonials[currentTestimonial].role}</small>
          </div>
          <div className={styles.dots}>
            {testimonials.map((testimonial, index) => (
              <button
                type="button"
                key={testimonial.name}
                className={`${styles.dot} ${index === currentTestimonial ? styles.activeDot : ''}`}
                aria-label={`Show testimonial from ${testimonial.name}`}
                onClick={() => setCurrentTestimonial(index)}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team} aria-label="Team">
        <div className={styles.sectionHeader}>
          <h2>Meet the team</h2>
          <p>
            A collective devoted to ethical storytelling, datos confiables, and inclusive finanzas personales education.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <div key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`${member.name} portrait`} loading="lazy" />
              <h3>{member.name}</h3>
              <span>{member.role}</span>
              <p>{member.bio}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.projects} aria-label="Featured projects">
        <div className={styles.sectionHeader}>
          <h2>Recent projects</h2>
          <p>
            Explore collaborative initiatives addressing argentina inflation literacy, economic trends, and budgeting argentina resilience.
          </p>
        </div>
        <div className={styles.filterButtons}>
          {['All', 'Education', 'Business', 'Community'].map((category) => (
            <button
              type="button"
              key={category}
              className={`${styles.filterButton} ${
                projectFilter === category ? styles.filterActive : ''
              }`}
              onClick={() => handleFilterChange(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <figure key={project.id} className={styles.projectCard}>
              <img
                src={project.image}
                alt={`${project.title} visual`}
                loading="lazy"
              />
              <figcaption>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.faq} aria-label="FAQ">
        <div className={styles.sectionHeader}>
          <h2>FAQ</h2>
          <p>Common questions about our argentina inflation methodology and curso finanzas experience.</p>
        </div>
        <div className={styles.accordion}>
          {faqItems.map((item, index) => (
            <details key={item.question} open={index === 0}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={styles.blog} aria-label="Blog preview">
        <div className={styles.sectionHeader}>
          <h2>Latest insights</h2>
          <p>Dive into curated explorations about economic trends y hábitos financieros sostenibles.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.id} className={styles.blogCard}>
              <img src="https://picsum.photos/800/600?random=52" alt="Economic analysis illustration" loading="lazy" />
              <div>
                <span>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <button
                  type="button"
                  onClick={() => navigate('/resources')}
                  className={styles.linkButton}
                >
                  Continue reading
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section id="cta" className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Get a free trial lesson</h2>
          <p>
            Request access today and confirm via double opt-in email to receive curated argentina inflation dashboards,
            ars usd updates, and finanzas personales guides.
          </p>
        </div>
        <form className={styles.ctaForm} onSubmit={handleSubmit} noValidate>
          <div className={styles.inputGroup}>
            <label htmlFor="name">Full name</label>
            <input
              id="name"
              name="name"
              type="text"
              autoComplete="name"
              value={formData.name}
              onChange={(event) => setFormData({ ...formData, name: event.target.value })}
              aria-invalid={!!formErrors.name}
              aria-describedby={formErrors.name ? 'name-error' : undefined}
              required
            />
            {formErrors.name && (
              <span id="name-error" className={styles.error}>
                {formErrors.name}
              </span>
            )}
          </div>
          <div className={styles.inputGroup}>
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              value={formData.email}
              onChange={(event) => setFormData({ ...formData, email: event.target.value })}
              aria-invalid={!!formErrors.email}
              aria-describedby={formErrors.email ? 'email-error' : undefined}
              required
            />
            {formErrors.email && (
              <span id="email-error" className={styles.error}>
                {formErrors.email}
              </span>
            )}
          </div>
          <p className={styles.optInNote}>
            After submitting, check your inbox for a confirmation link to complete the double opt-in process.
          </p>
          <button type="submit" className={styles.submit}>
            Request access
          </button>
        </form>
      </section>

      <section className={styles.disclaimerSection}>
        <p>
          Disclaimer (EN): Educational content only. No financial services provided. Datos confiables are sourced
          transparently, yet market conditions can evolve quickly.
        </p>
        <p>
          Дисклеймер (RU): Материалы предоставляются исключительно в образовательных целях. Финансовые услуги не оказываются.
        </p>
        <p>
          Descargo (ES): Contenido educativo. No brindamos servicios financieros ni asesoramiento personalizado.
        </p>
      </section>
    </div>
  );
};

export default Home;