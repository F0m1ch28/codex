import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Cookies.module.css';

const Cookies = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Cookie Policy | Tu Progreso Hoy</title>
      </Helmet>
      <section>
        <h1>Cookie Policy</h1>
        <p>
          Our cookie banner ensures opt-in consent. Essential cookies maintain session stability. Optional analytics cookies
          refine argentina inflation and ars usd reporting, only when you approve.
        </p>
        <h2>Types of cookies</h2>
        <ul>
          <li>Essential: Security, session management, accessibility features.</li>
          <li>Analytics (optional): Understand aggregated usage to improve finanzas personales content.</li>
        </ul>
        <h2>Managing preferences</h2>
        <p>
          Revise your choice anytime by clearing site cookies or contacting us. We honor your selections permanently unless
          you reset them.
        </p>
      </section>
    </div>
  );
};

export default Cookies;