import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Services | Tu Progreso Hoy educational solutions</title>
      </Helmet>
      <section className={styles.hero}>
        <h1>Services & Learning Labs</h1>
        <p>
          Our educational services are crafted to deepen understanding of argentina inflation, ars usd behaviors,
          and finanzas personales resilience with datos confiables and bilingual support.
        </p>
      </section>

      <section className={styles.cards}>
        <article>
          <h2>Inflation Scenario Studio</h2>
          <p>
            Weekly CPI briefings, interactive dashboards, and guided workshops help small businesses and households
            anticipate cambios sin perder calma.
          </p>
          <ul>
            <li>Scenario modelling for core expenses</li>
            <li>Sensitivity analysis integrating ars usd spreads</li>
            <li>Community debriefs with research notes</li>
          </ul>
        </article>
        <article>
          <h2>Bilingual Learning Journeys</h2>
          <p>
            Modular curso finanzas pathways blending short videos, reflective prompts, and real-world exercises built
            for Argentina&apos;s evolving economy.
          </p>
          <ul>
            <li>Self-paced Español & English content</li>
            <li>Progress trackers & accountability rituals</li>
            <li>Live Q&amp;A con especialistas invitados</li>
          </ul>
        </article>
        <article>
          <h2>Community Budgeting Circles</h2>
          <p>
            Co-facilitated spaces where learners share experiencias, benchmarking budgeting argentina strategies and
            strengthening financial self-efficacy.
          </p>
          <ul>
            <li>Peer coaching frameworks</li>
            <li>Resource library with datos confiables</li>
            <li>Localized case studies from Buenos Aires</li>
          </ul>
        </article>
      </section>

      <section className={styles.cta}>
        <div>
          <h2>Ready to explore the platform?</h2>
          <p>
            Request a guided walkthrough or join the next onboarding session. Double opt-in confirmation protects your privacy.
          </p>
        </div>
        <a className={styles.link} href="/contact">
          Contact our team
        </a>
      </section>
    </div>
  );
};

export default Services;