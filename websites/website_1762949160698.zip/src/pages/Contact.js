import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formValues, setFormValues] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    const newErrors = {};
    if (!formValues.name.trim()) newErrors.name = 'Please share your name.';
    if (!formValues.email.trim()) {
      newErrors.email = 'Please include an email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formValues.email.trim())) {
      newErrors.email = 'Enter a valid email.';
    }
    if (!formValues.message.trim()) newErrors.message = 'Let us know how we can support you.';

    setErrors(newErrors);
    if (Object.keys(newErrors).length === 0) {
      setSubmitted(true);
      setFormValues({ name: '', email: '', message: '' });
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact | Tu Progreso Hoy</title>
      </Helmet>
      <section className={styles.hero}>
        <h1>Connect with us</h1>
        <p>
          Share your goals around argentina inflation literacy, finanzas personales, or budgeting argentina programs.
          We&apos;ll respond after you confirm via double opt-in email.
        </p>
      </section>

      <section className={styles.info}>
        <div className={styles.mapWrapper}>
          <iframe
            title="Buenos Aires map"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3285.327763949061!2d-58.3824710233828!3d-34.61788235943032!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccacf9f1721c1%3A0x84afab9cf495f779!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1689876543210!5m2!1sen!2sar"
            loading="lazy"
            allowFullScreen
          />
        </div>
        <div className={styles.details}>
          <h2>Contact details</h2>
          <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
          <p><a href="tel:+541155551234">+54 11 5555-1234</a></p>
          <p>Email: [will be added soon]</p>
          <div className={styles.socials}>
            <a href="/" aria-label="LinkedIn">LinkedIn</a>
            <a href="/" aria-label="YouTube">YouTube</a>
            <a href="/" aria-label="Newsletter">Newsletter</a>
          </div>
        </div>
      </section>

      <section className={styles.formSection}>
        <form onSubmit={handleSubmit} noValidate>
          <div className={styles.inputGroup}>
            <label htmlFor="contact-name">Name</label>
            <input
              id="contact-name"
              type="text"
              value={formValues.name}
              onChange={(event) => setFormValues({ ...formValues, name: event.target.value })}
              aria-invalid={!!errors.name}
              aria-describedby={errors.name ? 'contact-name-error' : undefined}
              required
            />
            {errors.name && (
              <span id="contact-name-error" className={styles.error}>
                {errors.name}
              </span>
            )}
          </div>
          <div className={styles.inputGroup}>
            <label htmlFor="contact-email">Email</label>
            <input
              id="contact-email"
              type="email"
              value={formValues.email}
              onChange={(event) => setFormValues({ ...formValues, email: event.target.value })}
              aria-invalid={!!errors.email}
              aria-describedby={errors.email ? 'contact-email-error' : undefined}
              required
            />
            {errors.email && (
              <span id="contact-email-error" className={styles.error}>
                {errors.email}
              </span>
            )}
          </div>
          <div className={styles.inputGroup}>
            <label htmlFor="contact-message">Message</label>
            <textarea
              id="contact-message"
              rows="5"
              value={formValues.message}
              onChange={(event) => setFormValues({ ...formValues, message: event.target.value })}
              aria-invalid={!!errors.message}
              aria-describedby={errors.message ? 'contact-message-error' : undefined}
              required
            />
            {errors.message && (
              <span id="contact-message-error" className={styles.error}>
                {errors.message}
              </span>
            )}
          </div>
          <p className={styles.notice}>
            We operate a strict double opt-in policy. Please confirm the verification email to receive responses.
          </p>
          <button type="submit">Send message</button>
          {submitted && (
            <p className={styles.success} role="status">
              Thanks for reaching out. Please check your inbox to confirm your email so we can respond.
            </p>
          )}
        </form>
      </section>
    </div>
  );
};

export default Contact;