import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Privacy Policy | Tu Progreso Hoy</title>
      </Helmet>
      <section>
        <h1>Privacy Policy</h1>
        <p>
          Tu Progreso Hoy respects your privacy. We collect minimal personal information strictly for double opt-in
          communications and platform improvements related to argentina inflation and finanzas personales education.
        </p>
        <h2>Information we collect</h2>
        <p>
          We gather names, emails, and voluntary survey inputs. Cookies remain opt-in through our banner. Analytics are anonymized.
        </p>
        <h2>How we use data</h2>
        <p>
          Data supports onboarding, content personalization, and essential updates regarding economic trends. We never sell or
          lease contact information.
        </p>
        <h2>Your rights</h2>
        <p>
          You can request access, corrections, or deletion at any time by emailing us (email will be added soon). Opt-out links
          are included in every message.
        </p>
      </section>
    </div>
  );
};

export default Privacy;