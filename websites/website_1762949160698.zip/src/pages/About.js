import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>About Tu Progreso Hoy | Data-first learning collective</title>
      </Helmet>
      <section className={styles.intro}>
        <h1>About Tu Progreso Hoy</h1>
        <p>
          We are an educational SaaS platform grounded in Buenos Aires, amplifying argentina inflation awareness,
          ars usd comprehension, and finanzas personales mastery with datos confiables. Our mission is to democratize
          economic literacy while honoring cultural narratives and bilingual accessibility.
        </p>
      </section>

      <section className={styles.values}>
        <h2>Our values</h2>
        <div className={styles.grid}>
          <article>
            <h3>Integrity first</h3>
            <p>
              Every chart, insight, and curso finanzas module is sourced, verified, and documented for transparency.
            </p>
          </article>
          <article>
            <h3>Inclusive storytelling</h3>
            <p>
              We adapt complex economic trends into bilingual stories so learners feel heard, seen, and empowered.
            </p>
          </article>
          <article>
            <h3>Community-driven growth</h3>
            <p>
              We collaborate with educators, economists, and neighbors to keep budgeting argentina practices rooted in reality.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.vision}>
        <img
          src="https://picsum.photos/1200/800?random=61"
          alt="Team collaborating on financial learning insights"
          loading="lazy"
        />
        <div>
          <h2>Vision</h2>
          <p>
            Tu Progreso Hoy envisions a proactive learning community where argentina inflation no longer paralyzes
            decision-making. We support mission-driven individuals who care about equitable access to datos confiables
            and want to cultivate finanzas personales habits that uplift neighborhoods entire.
          </p>
          <p>
            By blending human-centered design with rigorous data analysis, we deliver experiences that inspire critical
            thinking, action, and cuidado mutuo. Every feature is built to honor your time, privacy, and self-determination.
          </p>
        </div>
      </section>
    </div>
  );
};

export default About;