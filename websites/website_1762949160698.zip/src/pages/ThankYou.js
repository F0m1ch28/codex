import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ThankYou.module.css';

const ThankYou = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Thank you | Tu Progreso Hoy</title>
      </Helmet>
      <section className={styles.content}>
        <h1>Thank you for requesting your trial</h1>
        <p>
          Please check your inbox and confirm the double opt-in email to finalise access to argentina inflation dashboards,
          ars usd updates, and finanzas personales resources.
        </p>
        <a href="/">Return to Home</a>
      </section>
    </div>
  );
};

export default ThankYou;