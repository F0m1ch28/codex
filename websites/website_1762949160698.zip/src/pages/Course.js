import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Course.module.css';

const modules = [
  {
    title: 'Module 1: Grounding in argentina inflation',
    description:
      'Understand CPI drivers, measurement cycles, and how inflation influences household decision-making.',
  },
  {
    title: 'Module 2: Mapping ars usd touchpoints',
    description:
      'Decode official and alternative FX rates, link them to everyday consumption, and plan for volatility.',
  },
  {
    title: 'Module 3: Finanzas personales foundations',
    description:
      'Build budgets, set intentions, and reprioritize expenses while honoring personal wellbeing and comunidad.',
  },
  {
    title: 'Module 4: Strategic habits & accountability',
    description:
      'Activate weekly rituals, track progress, and reflect on long-term economic trends shaping your future.',
  },
];

const targetAudiences = [
  'Young professionals navigating uncertain income scenarios',
  'Families planning multi-currency savings goals',
  'Entrepreneurs aligning cash flow with inflationary cycles',
  'Educators seeking datos confiables for community programs',
];

const Course = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Curso Finanzas | Tu Progreso Hoy syllabus</title>
      </Helmet>
      <section className={styles.hero}>
        <h1>Curso Finanzas: Syllabus Overview</h1>
        <p>
          A bilingual journey built for Argentina&apos;s reality, combining economic trends, budgeting argentina practicas,
          and mindful finanzas personales frameworks.
        </p>
      </section>

      <section className={styles.modules}>
        {modules.map((module) => (
          <article key={module.title}>
            <h2>{module.title}</h2>
            <p>{module.description}</p>
          </article>
        ))}
      </section>

      <section className={styles.audience}>
        <h2>Who is this for?</h2>
        <ul>
          {targetAudiences.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>

      <section className={styles.cta}>
        <div>
          <h2>Stay in the loop</h2>
          <p>
            Join the waitlist and confirm via double opt-in email to access sample lessons and upcoming cohort dates.
          </p>
        </div>
        <a href="/contact" className={styles.link}>
          Join the waitlist
        </a>
      </section>
    </div>
  );
};

export default Course;