import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { FiMenu, FiX } from 'react-icons/fi';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 32);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} aria-label="Main navigation">
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} aria-label="Tu Progreso Hoy home">
          <span className={styles.logoAccent}>Tu</span> Progreso Hoy
        </NavLink>
        <nav className={`${styles.nav} ${menuOpen ? styles.show : ''}`} aria-label="Primary">
          <NavLink to="/about" className={({ isActive }) => (isActive ? styles.active : '')}>
            About
          </NavLink>
          <NavLink to="/services" className={({ isActive }) => (isActive ? styles.active : '')}>
            Services
          </NavLink>
          <NavLink to="/inflation" className={({ isActive }) => (isActive ? styles.active : '')}>
            Inflation Lab
          </NavLink>
          <NavLink to="/course" className={({ isActive }) => (isActive ? styles.active : '')}>
            Course
          </NavLink>
          <NavLink to="/resources" className={({ isActive }) => (isActive ? styles.active : '')}>
            Resources
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => (isActive ? styles.active : '')}>
            Contact
          </NavLink>
        </nav>
        <button
          className={styles.menuButton}
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          {menuOpen ? <FiX /> : <FiMenu />}
        </button>
      </div>
    </header>
  );
};

export default Header;