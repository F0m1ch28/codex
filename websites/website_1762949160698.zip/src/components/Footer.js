import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Footer">
      <div className={styles.container}>
        <div className={styles.brand}>
          <h3>Tu Progreso Hoy</h3>
          <p>
            Data-first learning hub built in Buenos Aires, focused on argentina inflation, ars usd dynamics,
            finanzas personales, budgeting argentina practices, and economic trends with datos confiables.
          </p>
        </div>
        <div className={styles.links} aria-label="Footer navigation">
          <div>
            <h4>Navigate</h4>
            <NavLink to="/about">About</NavLink>
            <NavLink to="/services">Services</NavLink>
            <NavLink to="/inflation">Inflation Lab</NavLink>
            <NavLink to="/course">Course</NavLink>
            <NavLink to="/resources">Resources</NavLink>
          </div>
          <div>
            <h4>Support</h4>
            <NavLink to="/contact">Contact</NavLink>
            <NavLink to="/privacy">Privacy Policy</NavLink>
            <NavLink to="/cookies">Cookie Policy</NavLink>
            <NavLink to="/terms">Terms of Use</NavLink>
          </div>
        </div>
        <div className={styles.contact}>
          <h4>Contact</h4>
          <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
          <p><a href="tel:+541155551234">+54 11 5555-1234</a></p>
          <p>Email: [will be added soon]</p>
        </div>
      </div>
      <div className={styles.disclaimer}>
        <p>Disclaimer (EN): We do not provide financial services. Educational content only.</p>
        <p>Дисклеймер (RU): Мы не предоставляем финансовых услуг. Материалы носят образовательный характер.</p>
        <p>Descargo (ES): No brindamos servicios financieros. Contenido educativo únicamente.</p>
      </div>
      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.</span>
      </div>
    </footer>
  );
};

export default Footer;