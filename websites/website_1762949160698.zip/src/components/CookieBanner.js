import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const [choice, setChoice] = useState(null);

  useEffect(() => {
    const storedChoice = localStorage.getItem('tph-cookie-choice');
    if (!storedChoice) {
      setTimeout(() => setVisible(true), 800);
    } else {
      setChoice(storedChoice);
    }
  }, []);

  const handleChoice = (value) => {
    setChoice(value);
    localStorage.setItem('tph-cookie-choice', value);
    setVisible(false);
  };

  if (!visible || choice) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <div>
        <h4>Cookies & Privacy</h4>
        <p>
          We use essential cookies to enhance your learning experience. Optional analytics cookies help us refine
          argentina inflation and ars usd insights. Please choose your preference (opt-in required).
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" onClick={() => handleChoice('declined')} className={styles.secondary}>
          Decline
        </button>
        <button type="button" onClick={() => handleChoice('accepted')} className={styles.primary}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;