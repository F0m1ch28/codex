const casinos = [
  {
    id: 'orion-spin',
    name: 'Orion Spin Casino',
    slug: 'orion-spin-casino',
    shortDescription:
      'Многоуровневая программа лояльности, редкие слоты и поддержка 24/7 на нескольких языках.',
    summary:
      'Orion Spin — международное казино с лицензией Curacao, акцентом на инновационные слоты и прозрачные бонусные условия.',
    bannerImage: 'https://picsum.photos/seed/orionspin/1200/600',
    rating: 4.6,
    bonus: '150% до 500 € + 150 фриспинов',
    wager: '35x',
    limits: 'Ежедневный вывод до 5 000 €',
    games: ['Слоты', 'Живое казино', 'Краш-игры', 'Киберспорт'],
    payments: ['Visa', 'Mastercard', 'Skrill', 'Neteller', 'Bitcoin'],
    reliability: 'Высокая',
    established: '2020',
    license: 'Curacao eGaming',
    pros: [
      'Прозрачное описание бонусов с указанием вкладов',
      'Поддержка криптовалют и быстрые выплаты',
      'Собственный верификационный модуль ускоряет KYC'
    ],
    cons: ['Ограниченные лимиты для новых аккаунтов', 'Нет собственного мобильного приложения'],
    highlights: [
      'Каталог из 3200 игр от 48 провайдеров',
      'Проверка RTP на базе независимого аудитора iTech Labs',
      'Программа самоконтроля и лимитов депозитов'
    ],
    complianceNote:
      'Пользователи обязаны соблюдать возрастные ограничения и правила своей страны. Игровая деятельность регулируется лицензией Curacao.',
    languages: 'Английский, Испанский, Немецкий, Португальский, Русский',
    devices: 'Desktop, Mobile Web, Tablet',
    reviewDate: '2024-01-05'
  },
  {
    id: 'aurora-club',
    name: 'Aurora Club',
    slug: 'aurora-club',
    shortDescription:
      'Европейский подход к ответственному гэмблингу, ежедневные аудит-отчеты и live-поддержка.',
    summary:
      'Aurora Club — бренд с MGA лицензией, ориентированный на европейских игроков и строгие стандарты безопасности.',
    bannerImage: 'https://picsum.photos/seed/auroraclub/1200/600',
    rating: 4.8,
    bonus: '100% до 400 € + 50 безрисковых вращений',
    wager: '30x',
    limits: 'Вывод до 10 000 € в неделю',
    games: ['Слоты', 'Live Dealer', 'Рулетка', 'Покер'],
    payments: ['Visa', 'Mastercard', 'Skrill', 'Paysafecard', 'SEPA'],
    reliability: 'Очень высокая',
    established: '2017',
    license: 'Malta Gaming Authority',
    pros: [
      'Читабельные условия бонусов без скрытых формулировок',
      'Доступ к персональному менеджеру для VIP игроков',
      'Раздел Responsible Gaming с диагностическим тестом'
    ],
    cons: ['Недоступно в странах СНГ', 'Минимальный депозит 20 €'],
    highlights: [
      'Интеграция с GamStop и GamCare',
      'Сертифицированные RNG от GLI',
      'Мобильная версия с PWA-функционалом'
    ],
    complianceNote:
      'Aurora Club сотрудничает с европейскими регуляторами и соблюдает GDPR. Игроки обязаны подтвердить личность.',
    languages: 'Английский, Немецкий, Французский, Итальянский',
    devices: 'Desktop, iOS, Android',
    reviewDate: '2024-02-12'
  },
  {
    id: 'vega-portal',
    name: 'Vega Portal',
    slug: 'vega-portal',
    shortDescription:
      'Казино с расширенным каталогом live-игр и продвинутой системой аналитики для хай-роллеров.',
    summary:
      'Vega Portal действует по лицензии Kahnawake, известна оперативными выплатами и широким выбором платежных опций.',
    bannerImage: 'https://picsum.photos/seed/vegaportal/1200/600',
    rating: 4.4,
    bonus: '125% до 750 $ + страховой cashback 10%',
    wager: '40x',
    limits: 'Вывод до 12 000 $ в месяц',
    games: ['Слоты', 'Live Casino', 'Баккара', 'Блэкджек', 'Аркады'],
    payments: ['Visa', 'Mastercard', 'Interac', 'AstroPay', 'Tether'],
    reliability: 'Средне-высокая',
    established: '2019',
    license: 'Kahnawake Gaming Commission',
    pros: [
      'Автоматизированный AML-мониторинг транзакций',
      'Кастомизируемые лимиты депозитов и сессий',
      'Партнерские условия для стримеров и аффилиатов'
    ],
    cons: ['Бонус недоступен для некоторых стран Азии', 'Проверка документов до 48 часов'],
    highlights: [
      'Поддержка 15 валют и криптовалют',
      'Социальная платформа с рейтингом игроков',
      'Регулярные отчеты о выплатах'
    ],
    complianceNote:
      'Vega Portal применяет процедуры KYC/AML в соответствии с международными стандартами. Доступность оффера зависит от юрисдикции.',
    languages: 'Английский, Испанский, Португальский, Русский',
    devices: 'Desktop, Mobile, Smart TV',
    reviewDate: '2023-12-22'
  },
  {
    id: 'zenith-play',
    name: 'Zenith Play',
    slug: 'zenith-play',
    shortDescription:
      'Технологичная платформа с мгновенными выплатами, эксклюзивными слотами и детальной аналитикой RTP.',
    summary:
      'Zenith Play объединяет более 60 провайдеров, а также собственные студии. Казино позиционирует себя как hub для продвинутых игроков.',
    bannerImage: 'https://picsum.photos/seed/zenithplay/1200/600',
    rating: 4.7,
    bonus: '200% до 600 £ + 200 фриспинов в Age of Gems',
    wager: '32x',
    limits: 'Ежедневный вывод до 7 500 £',
    games: ['Слоты', 'Live Casino', 'Game Shows', 'Instant Games'],
    payments: ['Visa', 'Mastercard', 'Apple Pay', 'Google Pay', 'Ethereum', 'Litecoin'],
    reliability: 'Высокая',
    established: '2021',
    license: 'UK Gambling Commission, Gibraltar Gambling Commission',
    pros: [
      'Двойная лицензия (UKGC и Gibraltar) повышает доверие',
      'Глубокие инструменты самоограничения и тайм-ауты',
      'Раздел аналитики с отображением RTP и волатильности'
    ],
    cons: ['Негативные отзывы о поддержке в пиковые часы', 'Высокие требования к верификации'],
    highlights: [
      'AI-модуль для мониторинга игровой активности',
      'Сертификация ISO 27001 для ИБ',
      'Регулярные отчеты о поддержке ответственной игры'
    ],
    complianceNote:
      'Zenith Play подчиняется строгим требованиям UKGC. Пользователям необходимо подтвердить адрес проживания и источник средств.',
    languages: 'Английский, Норвежский, Шведский',
    devices: 'Desktop, Mobile, Console browsers',
    reviewDate: '2024-03-01'
  }
];

export default casinos;