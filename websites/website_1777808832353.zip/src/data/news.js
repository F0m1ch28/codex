const newsItems = [
  {
    id: 'news-1',
    title: 'Мальта обновила требования к мониторингу ответственной игры',
    excerpt:
      'Malta Gaming Authority объявила о расширении стандарта отчётности для операторов с 2024 года. Изменения касаются анализа паттернов поведения.',
    date: '2024-02-18',
    category: 'Регуляция',
    image: 'https://picsum.photos/seed/mga-update/1200/720',
    author: 'Алексей Воронов',
    link: '#',
    readingTime: '6 мин'
  },
  {
    id: 'news-2',
    title: 'Новые крипто-ограничения в Curacao: что нужно знать партнерам',
    excerpt:
      'Curacao eGaming вводит дополнительные процедуры AML и требования к хранению данных клиентов, действующие с июля 2024.',
    date: '2024-03-05',
    category: 'Легализация',
    image: 'https://picsum.photos/seed/curacao-aml/1200/720',
    author: 'Марина Ким',
    link: '#',
    readingTime: '5 мин'
  },
  {
    id: 'news-3',
    title: 'UKGC тестирует дашборд прозрачности RTP для игроков',
    excerpt:
      'UK Gambling Commission совместно с крупными операторами запускает пилотный проект, позволяющий игрокам мониторить RTP в реальном времени.',
    date: '2024-02-28',
    category: 'Технологии',
    image: 'https://picsum.photos/seed/ukgc-dashboard/1200/720',
    author: 'Сергей Романов',
    link: '#',
    readingTime: '4 мин'
  },
  {
    id: 'news-4',
    title: 'Игровые провайдеры внедряют AI для борьбы с лудоманией',
    excerpt:
      'Несколько студий объявили о внедрении алгоритмов раннего выявления проблемного поведения на основе машинного обучения.',
    date: '2024-03-09',
    category: 'Ответственная игра',
    image: 'https://picsum.photos/seed/ai-responsible/1200/720',
    author: 'Елена Григорьева',
    link: '#',
    readingTime: '7 мин'
  }
];

export default newsItems;