import React, { useMemo } from 'react';
import casinos from '../data/casinos';

const Rating = () => {
  const sortedCasinos = useMemo(
    () => [...casinos].sort((a, b) => b.rating - a.rating),
    []
  );

  return (
    <div className="page page--default">
      <section className="page-hero">
        <div className="container">
          <h1>Рейтинг казино по надежности</h1>
          <p>
            Список формируется на основе лицензий, отзывов, прозрачности бонусов, скорости выплат и
            инструментов ответственной игры. Рейтинг обновляется ежемесячно.
          </p>
        </div>
      </section>

      <section className="section rating-section">
        <div className="container rating-list">
          {sortedCasinos.map((casino, index) => (
            <article key={casino.id} className="rating-card">
              <div className="rating-card__index">
                <span>{index + 1}</span>
              </div>
              <div className="rating-card__content">
                <h2>{casino.name}</h2>
                <p>{casino.summary}</p>
                <div className="rating-card__metrics">
                  <div>
                    <span className="metric-label">Рейтинг</span>
                    <span className="metric-value">{casino.rating}</span>
                  </div>
                  <div>
                    <span className="metric-label">Лицензия</span>
                    <span className="metric-value">{casino.license}</span>
                  </div>
                  <div>
                    <span className="metric-label">Приветственный бонус</span>
                    <span className="metric-value">{casino.bonus}</span>
                  </div>
                  <div>
                    <span className="metric-label">Ответственная игра</span>
                    <span className="metric-value">{casino.highlights[1]}</span>
                  </div>
                </div>
              </div>
              <div className="rating-card__actions">
                <p className="rating-card__note">
                  {casino.complianceNote}
                </p>
              </div>
            </article>
          ))}
        </div>
        <div className="container rating-disclaimer">
          <h3>Дисклеймер</h3>
          <p>
            Рейтинг носит информационный характер и не является рекомендацией к участию в азартных играх.
            Рассматривайте азартные игры как форму развлечения. Используйте лимиты и инструменты
            самоконтроля, доступные у операторов.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Rating;