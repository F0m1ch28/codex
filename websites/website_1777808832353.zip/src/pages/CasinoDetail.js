import React from 'react';
import { Link, useParams } from 'react-router-dom';
import casinos from '../data/casinos';
import { useFavorites } from '../context/FavoritesContext';

const CasinoDetail = () => {
  const { slug } = useParams();
  const casino = casinos.find((item) => item.slug === slug);
  const { isFavorite, toggleFavorite } = useFavorites();

  if (!casino) {
    return (
      <div className="page page--default">
        <section className="page-hero">
          <div className="container">
            <h1>Обзор не найден</h1>
            <p>Мы не нашли обзор по указанной ссылке. Проверьте URL или вернитесь на страницу обзоров.</p>
            <Link to="/casino-reviews" className="btn btn--accent">
              Ко всем обзорам
            </Link>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="page page--default">
      <section
        className="casino-detail-hero"
        style={{
          backgroundImage: `linear-gradient(120deg, rgba(15,15,26,.92), rgba(26,26,46,.8)), url('https://picsum.photos/seed/${casino.slug}-hero/1600/900')`
        }}
      >
        <div className="container">
          <span className="badge badge--soft">Обзор казино</span>
          <h1>{casino.name}</h1>
          <p>{casino.summary}</p>
          <div className="casino-detail-hero__meta">
            <span>Лицензия: {casino.license}</span>
            <span>Основано: {casino.established}</span>
            <span>Рейтинг: {casino.rating}</span>
          </div>
          <div className="casino-detail-hero__actions">
            <button
              type="button"
              className={`favorite-toggle ${isFavorite(casino.id) ? 'favorite-toggle--active' : ''}`}
              onClick={() => toggleFavorite(casino.id)}
            >
              {isFavorite(casino.id) ? 'В избранном' : 'Добавить в избранное'}
            </button>
            <Link to="/comparison" className="btn btn--ghost">
              Сравнить условия
            </Link>
          </div>
        </div>
      </section>

      <section className="section casino-detail-section">
        <div className="container casino-detail-grid">
          <aside className="casino-detail-sidebar">
            <div className="sidebar-card">
              <h2>Ключевые параметры</h2>
              <ul>
                <li>
                  <strong>Приветственный бонус:</strong> {casino.bonus}
                </li>
                <li>
                  <strong>Вейджер:</strong> {casino.wager}
                </li>
                <li>
                  <strong>Лимиты вывода:</strong> {casino.limits}
                </li>
                <li>
                  <strong>Языки поддержки:</strong> {casino.languages}
                </li>
                <li>
                  <strong>Доступные устройства:</strong> {casino.devices}
                </li>
              </ul>
            </div>
            <div className="sidebar-card">
              <h2>Ответственная игра</h2>
              <p>{casino.complianceNote}</p>
              <Link to="/services" className="inline-link">
                Наша методология →
              </Link>
            </div>
          </aside>

          <div className="casino-detail-content">
            <section>
              <h2>Бонусы и условия отыгрыша</h2>
              <p>
                Приветственный пакет <strong>{casino.bonus}</strong> включает требования к вейджеру{' '}
                <strong>{casino.wager}</strong>. Вклад различных категорий игр может отличаться:
              </p>
              <ul className="highlight-list">
                <li>Слоты — 100% вклад в отыгрыш (исключения описаны на сайте оператора).</li>
                <li>Настольные игры и live-казино — 10–25% вклад в зависимости от провайдера.</li>
                <li>Игры с низким риском (блэкджек, баккара) могут исключаться из отыгрыша.</li>
              </ul>
              <p>
                Перед активацией бонуса обязательно ознакомьтесь с ограничениями по максимальной ставке и
                срокам отыгрыша. Мы рекомендуем заранее установить лимиты и помнить, что бонусы не
                гарантируют выигрыши.
              </p>
            </section>

            <section>
              <h2>Каталог игр</h2>
              <p>
                Казино предлагает более {casino.games.length > 3 ? 'трех тысяч' : 'тысячи'} игр, включая:{' '}
                {casino.games.join(', ')}, а также эксклюзивные тайтлы от ведущих студий. Особое внимание
                уделяется live-формату с профессиональными крупье и поддержкой нескольких языков.
              </p>
            </section>

            <section>
              <h2>Платежные методы</h2>
              <p>
                Доступные платежи: {casino.payments.join(', ')}. Проверка личности обязательна для
                вывода средств, в том числе при использовании криптовалют.
              </p>
              <div className="info-grid">
                <div>
                  <h3>Депозиты</h3>
                  <p>Мгновенное зачисление, минимальная сумма — 20 единиц выбранной валюты.</p>
                </div>
                <div>
                  <h3>Выплаты</h3>
                  <p>
                    Обработка заявок занимает от 1 до 48 часов. Время зависит от метода и статуса
                    верификации.
                  </p>
                </div>
                <div>
                  <h3>Комиссии</h3>
                  <p>Для банковских переводов возможны комиссии третьих сторон. Казино не взимает плату.</p>
                </div>
              </div>
            </section>

            <section>
              <h2>Плюсы и минусы</h2>
              <div className="pros-cons">
                <div>
                  <h3>Преимущества</h3>
                  <ul>
                    {casino.pros.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3>Ограничения</h3>
                  <ul>
                    {casino.cons.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </section>

            <section>
              <h2>Инструменты ответственной игры</h2>
              <p>
                Казино предлагает лимиты депозитов, ставок и времени сессии, а также временную
                самоэксклюзию. Партнерства с GamCare и GamStop обеспечивают дополнительную поддержку.
              </p>
            </section>

            <section className="callout">
              <h3>Важно</h3>
              <p>
                GambleReview предоставляет информацию в ознакомительных целях. Мы не проводим азартные
                игры и не гарантируем результаты. Убедитесь, что азартные игры разрешены в вашей
                юрисдикции.
              </p>
            </section>

            <section className="detail-navigation">
              <Link to="/casino-reviews" className="inline-link">
                ← Вернуться к списку обзоров
              </Link>
              <Link to="/comparison" className="btn btn--accent">
                Сравнить с другими
              </Link>
            </section>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CasinoDetail;