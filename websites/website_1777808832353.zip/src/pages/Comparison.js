import React, { useMemo } from 'react';
import casinos from '../data/casinos';

const Comparison = () => {
  const columns = [
    { key: 'bonus', label: 'Бонус приветствия' },
    { key: 'wager', label: 'Вейджер' },
    { key: 'limits', label: 'Лимиты выплат' },
    { key: 'payments', label: 'Платежные методы' },
    { key: 'reliability', label: 'Надежность' }
  ];

  const comparisonData = useMemo(
    () =>
      casinos.map((casino) => ({
        ...casino,
        paymentString: casino.payments.join(', ')
      })),
    []
  );

  return (
    <div className="page page--default">
      <section className="page-hero">
        <div className="container">
          <h1>Сравнение условий казино</h1>
          <p>
            Сопоставьте ключевые параметры: бонусы, вейджер, лимиты выплат, платежные методы и подход к
            ответственности. Информация обновляется при каждом изменении условий операторов.
          </p>
        </div>
      </section>

      <section className="section table-section">
        <div className="container table-wrapper table-wrapper--scrollable">
          <table className="comparison-table comparison-table--detailed">
            <thead>
              <tr>
                <th>Казино</th>
                {columns.map((column) => (
                  <th key={column.key}>{column.label}</th>
                ))}
                <th>Инструменты ответственной игры</th>
              </tr>
            </thead>
            <tbody>
              {comparisonData.map((casino) => (
                <tr key={casino.id}>
                  <td>
                    <div className="table-casino-info">
                      <span className="table-casino-name">{casino.name}</span>
                      <span className="table-casino-rating">Рейтинг {casino.rating}</span>
                    </div>
                  </td>
                  <td>{casino.bonus}</td>
                  <td>{casino.wager}</td>
                  <td>{casino.limits}</td>
                  <td>{casino.paymentString}</td>
                  <td>{casino.reliability}</td>
                  <td>{casino.highlights.join('; ')}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="table-note">
            *Проверяйте актуальность бонусов на официальном сайте оператора. Условия могут меняться без
            уведомления. Мы обновляем данные после официальных апдейтов.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Comparison;