import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import casinos from '../data/casinos';
import { useFavorites } from '../context/FavoritesContext';

const CasinoReviews = () => {
  const { favorites, toggleFavorite, isFavorite } = useFavorites();
  const [search, setSearch] = useState('');
  const [licenseFilter, setLicenseFilter] = useState('all');

  const licenses = useMemo(() => ['all', ...new Set(casinos.map((casino) => casino.license))], []);

  const filteredCasinos = useMemo(() => {
    return casinos
      .filter((casino) =>
        casino.name.toLowerCase().includes(search.trim().toLowerCase())
      )
      .filter((casino) => (licenseFilter === 'all' ? true : casino.license === licenseFilter));
  }, [search, licenseFilter]);

  return (
    <div className="page page--default">
      <section className="page-hero">
        <div className="container">
          <h1>Обзоры казино</h1>
          <p>
            Независимые обзоры, созданные на основе проверки лицензий, тестирования выплат и анализа
            инструментов ответственной игры. Информация предназначена для совершеннолетней аудитории.
          </p>
        </div>
      </section>

      <section className="section filter-section">
        <div className="container filter-bar">
          <div className="filter-group">
            <label htmlFor="casino-search">Поиск по названию</label>
            <input
              id="casino-search"
              type="text"
              placeholder="Например, Aurora"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>
          <div className="filter-group">
            <label htmlFor="license-filter">Лицензия</label>
            <select
              id="license-filter"
              value={licenseFilter}
              onChange={(event) => setLicenseFilter(event.target.value)}
            >
              {licenses.map((license) => (
                <option key={license} value={license}>
                  {license === 'all' ? 'Все лицензии' : license}
                </option>
              ))}
            </select>
          </div>
          <div className="filter-group favorites-counter">
            <span>Избранные: {favorites.length}</span>
            <Link to="/comparison" className="inline-link">
              Сравнить избранные →
            </Link>
          </div>
        </div>
      </section>

      <section className="section cards-list-section">
        <div className="container cards-grid cards-grid--extended">
          {filteredCasinos.map((casino) => (
            <article key={casino.id} className="casino-card casino-card--compact">
              <div className="casino-card__image" aria-hidden="true">
                <img src={`https://picsum.photos/seed/${casino.slug}-review/800/600`} alt={casino.name} />
              </div>
              <div className="casino-card__body">
                <div className="casino-card__header">
                  <h2>{casino.name}</h2>
                  <div className="casino-card__rating">
                    <span className="badge">Рейтинг {casino.rating}</span>
                  </div>
                </div>
                <p className="casino-card__summary">{casino.summary}</p>
                <ul className="casino-card__details">
                  <li>
                    <strong>Бонус:</strong> {casino.bonus}
                  </li>
                  <li>
                    <strong>Вейджер:</strong> {casino.wager}
                  </li>
                  <li>
                    <strong>Лицензия:</strong> {casino.license}
                  </li>
                  <li>
                    <strong>Поддерживаемые игры:</strong> {casino.games.join(', ')}
                  </li>
                  <li>
                    <strong>Платежные системы:</strong> {casino.payments.join(', ')}
                  </li>
                </ul>
                <div className="casino-card__actions">
                  <button
                    type="button"
                    className={`favorite-toggle ${isFavorite(casino.id) ? 'favorite-toggle--active' : ''}`}
                    onClick={() => toggleFavorite(casino.id)}
                    aria-pressed={isFavorite(casino.id)}
                  >
                    {isFavorite(casino.id) ? 'Убрать из избранного' : 'В избранное'}
                  </button>
                  <Link to={`/casino-reviews/${casino.slug}`} className="btn btn--accent">
                    Перейти к обзору
                  </Link>
                </div>
              </div>
            </article>
          ))}
          {filteredCasinos.length === 0 && (
            <div className="empty-state">
              <h3>Не найдено казино по заданным параметрам</h3>
              <p>Попробуйте изменить фильтры или напишите нам, если хотите увидеть новый обзор.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default CasinoReviews;