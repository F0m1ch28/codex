import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import casinos from '../data/casinos';
import newsItems from '../data/news';
import { useFavorites } from '../context/FavoritesContext';

const Home = () => {
  const { favorites, toggleFavorite, isFavorite } = useFavorites();
  const featuredCasinos = useMemo(() => casinos.slice(0, 3), []);
  const latestReviews = useMemo(
    () => [...casinos].sort((a, b) => new Date(b.reviewDate) - new Date(a.reviewDate)).slice(0, 3),
    []
  );

  const [stats, setStats] = useState({
    reviews: 0,
    jurisdictions: 0,
    partners: 0
  });

  useEffect(() => {
    const targets = {
      reviews: 126,
      jurisdictions: 42,
      partners: 58
    };
    const duration = 1600;
    const frame = 32;
    const iterations = duration / frame;
    let count = 0;

    const counter = setInterval(() => {
      count += 1;
      setStats({
        reviews: Math.round((targets.reviews * count) / iterations),
        jurisdictions: Math.round((targets.jurisdictions * count) / iterations),
        partners: Math.round((targets.partners * count) / iterations)
      });

      if (count >= iterations) {
        clearInterval(counter);
        setStats(targets);
      }
    }, frame);

    return () => clearInterval(counter);
  }, []);

  const [faqOpen, setFaqOpen] = useState(null);
  const [email, setEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState('');
  const [emailError, setEmailError] = useState('');

  const handleNewsletter = (e) => {
    e.preventDefault();
    if (!email.trim()) {
      setEmailError('Введите email для подписки.');
      setNewsletterStatus('');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/u;
    if (!emailRegex.test(email.trim())) {
      setEmailError('Проверьте корректность email.');
      setNewsletterStatus('');
      return;
    }
    setEmailError('');
    setNewsletterStatus('Спасибо! Мы подтвердим подписку письмом.');
    setEmail('');
  };

  const testimonials = [
    {
      id: 'testimonial-1',
      quote:
        'Команда GambleReview помогла нам адаптировать оффер под европейских игроков: акцент на прозрачности и локализации.',
      name: 'Анна Коваль',
      role: 'Менеджер партнерской программы, Aurora Club',
      avatar: 'https://picsum.photos/seed/testimonial1/200/200'
    },
    {
      id: 'testimonial-2',
      quote:
        'Отчёты по ответственному гэмблингу от GambleReview стали ориентиром при обновлении нашей политики самоконтроля.',
      name: 'Майкл Стоун',
      role: 'Директор по комплаенсу, Zenith Play',
      avatar: 'https://picsum.photos/seed/testimonial2/200/200'
    },
    {
      id: 'testimonial-3',
      quote:
        'Редакция тщательно проверяет бонусные условия, что экономит время наших читателей и усиливает доверие.',
      name: 'Людмила Чернова',
      role: 'Финансовый аналитик, Vega Portal',
      avatar: 'https://picsum.photos/seed/testimonial3/200/200'
    }
  ];

  const [testimonialIndex, setTestimonialIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6500);

    return () => clearInterval(timer);
  }, [testimonials.length]);

  const projects = [
    {
      id: 'project-1',
      title: 'Аудит бонусной политики для Orion Spin',
      description:
        'Переписали раздел бонусов, внедрили таблицу с вкладом игр и снизили количество жалоб на 28%.',
      image: 'https://picsum.photos/seed/projectgamma/1200/800'
    },
    {
      id: 'project-2',
      title: 'Roadmap по ответственному гэмблингу для Vega Portal',
      description:
        'Создали чек-лист для самоконтроля, внедрили лимиты депозитов по умолчанию и протоколы тайм-аутов.',
      image: 'https://picsum.photos/seed/projectdelta/1200/800'
    },
    {
      id: 'project-3',
      title: 'UX-оценка мобильной версии Aurora Club',
      description:
        'Провели UX-тестирование, оптимизировали навигацию и улучшили onboarding игроков в двух странах.',
      image: 'https://picsum.photos/seed/projectepsilon/1200/800'
    }
  ];

  const servicesPreview = [
    {
      id: 'service-1',
      title: 'Структурированные обзоры',
      description:
        'Анализируем лицензии, финансовые лимиты и пользовательские отзывы, формируя объективные профили казино.',
      icon: '🔍'
    },
    {
      id: 'service-2',
      title: 'Сравнительные таблицы',
      description:
        'Обновляем сравнительные данные о бонусах, вейджерах, каталогах игр и комиссиях выплат.',
      icon: '📊'
    },
    {
      id: 'service-3',
      title: 'Мониторинг ответственной игры',
      description:
        'Проверяем наличие инструментов самоограничения, сотрудничество с независимыми организациями и комплаенс-процессы.',
      icon: '🛡️'
    }
  ];

  const processSteps = [
    {
      title: 'Сбор данных',
      description:
        'Анализируем лицензии, платежные методы, пользовательские соглашения и отзывы независимых источников.',
      icon: '1'
    },
    {
      title: 'Тестирование',
      description:
        'Проходим путь игрока: регистрация, депозит, активация бонуса, вывод средств и проверка поддержки.',
      icon: '2'
    },
    {
      title: 'Верификация',
      description:
        'Подтверждаем заявленные RTP, проверяем инструменты самоконтроля и безопасность платформы.',
      icon: '3'
    },
    {
      title: 'Публикация и мониторинг',
      description:
        'Обзор выходит с рекомендациями и метриками. Обновляем материалы при изменении условий.',
      icon: '4'
    }
  ];

  const faqItems = [
    {
      question: 'Как часто обновляются обзоры казино?',
      answer:
        'Мы пересматриваем ключевые обзоры минимум раз в квартал или сразу после изменения лицензии, бонусных условий либо жалоб пользователей.'
    },
    {
      question: 'Проводите ли вы собственные игровые сессии?',
      answer:
        'Мы не транслируем игровые сессии. Тестирование проводится в закрытом режиме для проверки бонусов, платежей и скорости поддержки.'
    },
    {
      question: 'Как формируется рейтинг надежности?',
      answer:
        'Мы учитываем лицензии, регуляторные штрафы, оценку условий вывода, отзывы игроков, технологическую инфраструктуру и внедрение ответственной игры.'
    },
    {
      question: 'Можно ли предложить казино для обзора?',
      answer:
        'Да, отправьте запрос через раздел “Контакты”. Мы проверим платформу по нашему чек-листу и сообщим о сроках публикации.'
    }
  ];

  return (
    <div className="page home-page">
      <section
        className="hero-section"
        style={{
          backgroundImage:
            "linear-gradient(120deg, rgba(15,15,26,0.94), rgba(26,26,46,0.82)), url('https://picsum.photos/1600/900?random=11')"
        }}
      >
        <div className="container hero-content">
          <div className="hero-text">
            <p className="hero-kicker">GambleReview • глобальный обзор казино</p>
            <h1>Аналитика казино, построенная на данных и ответственности</h1>
            <p className="hero-subtitle">
              Комплексные обзоры, сравнительные таблицы и рейтинги надежности. Мы анализируем лицензии и
              процессы, чтобы помочь аудитории 18+ принимать взвешенные решения и соблюдать лимиты.
            </p>
            <div className="hero-actions">
              <Link to="/comparison" className="btn btn--accent">
                Сравнить условия
              </Link>
              <Link to="/casino-reviews" className="btn btn--ghost">
                Смотреть обзоры
              </Link>
            </div>
            <div className="hero-meta">
              <span>🔒 Независимая аналитика</span>
              <span>🕒 Обновление каждую неделю</span>
              <span>✅ Ответственный подход</span>
            </div>
          </div>
          <div className="hero-card">
            <div className="hero-card__header">
              <h3>Что внутри обзора</h3>
              <p>Помогаем сопоставить бонусы, лимиты и инструменты самоконтроля.</p>
            </div>
            <ul className="hero-card__list">
              <li>
                <span>✔</span>
                Проверенные лицензии и регуляторы
              </li>
              <li>
                <span>✔</span>
                Калькулятор отыгрыша и вклад игр
              </li>
              <li>
                <span>✔</span>
                Скорость выплат и комиссии
              </li>
              <li>
                <span>✔</span>
                Политика ответственной игры
              </li>
            </ul>
            <div className="hero-card__footer">
              <p>
                Для полного доступа к данным присоединяйтесь к рассылке аналитических дайджестов без
                рекламы.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section stats-section">
        <div className="container section-header">
          <div>
            <h2 className="section-title">Цифры, подтверждающие экспертизу</h2>
            <p className="section-subtitle">
              Мы работаем с международными командами, отслеживаем регуляторные изменения и обновляем
              рейтинги на основании живых данных.
            </p>
          </div>
        </div>
        <div className="container stats-grid">
          <div className="stat-card">
            <span className="stat-number">{stats.reviews}+</span>
            <p>проверенных обзоров</p>
          </div>
          <div className="stat-card">
            <span className="stat-number">{stats.jurisdictions}</span>
            <p>юрисдикций в мониторинге</p>
          </div>
          <div className="stat-card">
            <span className="stat-number">{stats.partners}</span>
            <p>партнеров по ответственному гэмблингу</p>
          </div>
        </div>
      </section>

      <section className="section services-preview-section">
        <div className="container section-header">
          <div>
            <h2 className="section-title">Наши основные практики</h2>
            <p className="section-subtitle">
              Мы не публикуем рекламные материалы. Каждый обзор проходит редакционную проверку и
              сопровождается чек-листом требований по безопасности.
            </p>
          </div>
          <Link to="/services" className="btn btn--ghost">
            Подробнее о сервисах
          </Link>
        </div>
        <div className="container cards-grid">
          {servicesPreview.map((service) => (
            <article key={service.id} className="feature-card">
              <div className="feature-card__icon" aria-hidden="true">
                {service.icon}
              </div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section featured-section">
        <div className="container section-header">
          <div>
            <h2 className="section-title">Избранные казино недели</h2>
            <p className="section-subtitle">
              Три площадки, прошедшие независимый аудит на соответствие стандартам безопасности и
              прозрачности.
            </p>
          </div>
          <Link to="/casino-reviews" className="inline-link">
            Все обзоры →
          </Link>
        </div>
        <div className="container cards-grid">
          {featuredCasinos.map((casino) => (
            <article key={casino.id} className="casino-card">
              <div
                className="casino-card__image"
                style={{
                  backgroundImage: `url('https://picsum.photos/seed/${casino.slug}/800/600')`
                }}
                aria-label={`Обложка ${casino.name}`}
              />
              <div className="casino-card__body">
                <div className="casino-card__header">
                  <h3>{casino.name}</h3>
                  <span className="badge">Рейтинг {casino.rating}</span>
                </div>
                <p className="casino-card__summary">{casino.shortDescription}</p>
                <ul className="casino-card__bullets">
                  <li>
                    <strong>Бонус:</strong> {casino.bonus}
                  </li>
                  <li>
                    <strong>Вейджер:</strong> {casino.wager}
                  </li>
                  <li>
                    <strong>Лицензия:</strong> {casino.license}
                  </li>
                </ul>
                <div className="casino-card__actions">
                  <button
                    type="button"
                    className={`favorite-toggle ${isFavorite(casino.id) ? 'favorite-toggle--active' : ''}`}
                    onClick={() => toggleFavorite(casino.id)}
                    aria-pressed={isFavorite(casino.id)}
                  >
                    {isFavorite(casino.id) ? 'В избранном' : 'Добавить в избранное'}
                  </button>
                  <Link to={`/casino-reviews/${casino.slug}`} className="btn btn--accent">
                    Читать обзор
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section latest-reviews-section">
        <div className="container section-header">
          <div>
            <h2 className="section-title">Новые обзоры и апдейты</h2>
            <p className="section-subtitle">
              Каждое обновление фиксирует изменения в бонусах, лимитах и политике ответственной игры.
            </p>
          </div>
        </div>
        <div className="container timeline">
          {latestReviews.map((casino) => (
            <article key={casino.id} className="timeline-item">
              <div className="timeline-item__marker" aria-hidden="true" />
              <div className="timeline-item__content">
                <div className="timeline-item__meta">
                  <span>{new Date(casino.reviewDate).toLocaleDateString('ru-RU')}</span>
                  <span className="badge badge--soft">Обновлено</span>
                </div>
                <h3>{casino.name}</h3>
                <p>{casino.summary}</p>
                <div className="timeline-item__tags">
                  <span>Лицензия: {casino.license}</span>
                  <span>Игры: {casino.games.slice(0, 2).join(', ')}…</span>
                  <span>Рейтинг: {casino.rating}</span>
                </div>
                <div className="timeline-item__actions">
                  <Link to={`/casino-reviews/${casino.slug}`} className="inline-link">
                    Подробнее →
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section comparison-preview-section">
        <div className="container section-header">
          <div>
            <h2 className="section-title">Быстрая сводка условий</h2>
            <p className="section-subtitle">
              Сравните ключевые параметры — бонус, вейджер, лимиты выплат и ответственность — за одну
              минуту.
            </p>
          </div>
          <Link to="/comparison" className="btn btn--ghost">
            Полная таблица
          </Link>
        </div>
        <div className="container table-wrapper">
          <table className="comparison-table">
            <thead>
              <tr>
                <th>Казино</th>
                <th>Бонус приветствия</th>
                <th>Вейджер</th>
                <th>Лимит выплат</th>
                <th>Ответственная игра</th>
              </tr>
            </thead>
            <tbody>
              {casinos.slice(0, 4).map((casino) => (
                <tr key={casino.id}>
                  <td>
                    <Link to={`/casino-reviews/${casino.slug}`} className="table-link">
                      {casino.name}
                    </Link>
                  </td>
                  <td>{casino.bonus}</td>
                  <td>{casino.wager}</td>
                  <td>{casino.limits}</td>
                  <td>{casino.highlights[2]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="section process-section">
        <div className="container section-header">
          <div>
            <h2 className="section-title">Как мы строим обзоры</h2>
            <p className="section-subtitle">
              Методология GambleReview сочетает аналитическую и UX-проверку, чтобы отразить реальный опыт
              пользователя.
            </p>
          </div>
        </div>
        <div className="container process-grid">
          {processSteps.map((step) => (
            <div key={step.title} className="process-card">
              <div className="process-card__icon">{step.icon}</div>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section testimonial-section">
        <div className="container section-header">
          <div>
            <h2 className="section-title">Отзывы партнеров и экспертов</h2>
            <p className="section-subtitle">
              Мы работаем с операторами, регуляторами и аналитиками, чтобы поддерживать объективность.
            </p>
          </div>
        </div>
        <div className="container testimonial-carousel">
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.id}
              className={`testimonial-card ${
                index === testimonialIndex ? 'testimonial-card--active' : ''
              }`}
              aria-hidden={index !== testimonialIndex}
            >
              <img
                src={`${testimonial.avatar}`}
                alt={`Фото: ${testimonial.name}`}
                className="testimonial-avatar"
              />
              <blockquote>“{testimonial.quote}”</blockquote>
              <p className="testimonial-author">{testimonial.name}</p>
              <span className="testimonial-role">{testimonial.role}</span>
            </article>
          ))}
          <div className="testimonial-dots">
            {testimonials.map((item, index) => (
              <button
                key={item.id}
                type="button"
                className={`dot ${index === testimonialIndex ? 'dot--active' : ''}`}
                onClick={() => setTestimonialIndex(index)}
                aria-label={`Перейти к отзыву ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section team-section">
        <div className="container section-header">
          <div>
            <h2 className="section-title">Экспертная команда</h2>
            <p className="section-subtitle">
              Редакция объединяет специалистов в сфере комплаенса, аффилиат-маркетинга и финансового
              анализа.
            </p>
          </div>
          <Link to="/about" className="inline-link">
            Подробнее о команде →
          </Link>
        </div>
        <div className="container cards-grid">
          {[
            {
              name: 'Ирина Мельник',
              role: 'Главный редактор',
              bio: '10 лет в отрасли, экс-аудитор MGA, сертификация ICA по AML.',
              image: 'https://picsum.photos/seed/team1/400/400'
            },
            {
              name: 'Даниэль Росс',
              role: 'Аналитик лицензий',
              bio: 'Специалист UKGC, опубликовал исследования по борьбе с лудоманией.',
              image: 'https://picsum.photos/seed/team2/400/400'
            },
            {
              name: 'Мария Гофф',
              role: 'UX-исследователь',
              bio: 'Проводит проверку пользовательских сценариев и образовательных модулей.',
              image: 'https://picsum.photos/seed/team3/400/400'
            }
          ].map((member) => (
            <article key={member.name} className="team-card">
              <img src={member.image} alt={`Эксперт ${member.name}`} />
              <div className="team-card__body">
                <h3>{member.name}</h3>
                <p className="team-card__role">{member.role}</p>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section projects-section">
        <div className="container section-header">
          <div>
            <h2 className="section-title">Кейсы и исследования</h2>
            <p className="section-subtitle">
              Мы помогаем площадкам внедрять стандарты ответственности и улучшать коммуникацию с
              аудиторией.
            </p>
          </div>
        </div>
        <div className="container cards-grid cards-grid--extended">
          {projects.map((project) => (
            <article key={project.id} className="project-card">
              <img src={project.image} alt={project.title} />
              <div className="project-card__body">
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <div className="project-card__meta">
                  <span>Формат: консалтинг + аудит</span>
                  <span>Статус: завершено</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section faq-section">
        <div className="container section-header">
          <div>
            <h2 className="section-title">Частые вопросы</h2>
            <p className="section-subtitle">
              Если вы не нашли ответ — напишите нам через форму обратной связи. Все обращения анонимны и
              обрабатываются вручную.
            </p>
          </div>
          <Link to="/contact" className="btn btn--ghost">
            Задать вопрос
          </Link>
        </div>
        <div className="container faq-list">
          {faqItems.map((item, index) => (
            <div key={item.question} className="faq-item">
              <button
                type="button"
                className="faq-question"
                onClick={() => setFaqOpen((prev) => (prev === index ? null : index))}
                aria-expanded={faqOpen === index}
              >
                <span>{item.question}</span>
                <span>{faqOpen === index ? '−' : '+'}</span>
              </button>
              <div className={`faq-answer ${faqOpen === index ? 'faq-answer--open' : ''}`}>
                <p>{item.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="section blog-preview-section">
        <div className="container section-header">
          <div>
            <h2 className="section-title">Свежие новости</h2>
            <p className="section-subtitle">
              Еженедельные дайджесты о лицензиях, регуляторных изменениях и технологиях ответственной игры.
            </p>
          </div>
          <Link to="/gambling-news" className="inline-link">
            Все новости →
          </Link>
        </div>
        <div className="container cards-grid">
          {newsItems.slice(0, 3).map((news) => (
            <article key={news.id} className="news-card">
              <div className="news-card__image-wrapper">
                <img src={news.image} alt={news.title} />
              </div>
              <div className="news-card__body">
                <div className="news-card__meta">
                  <span>{new Date(news.date).toLocaleDateString('ru-RU')}</span>
                  <span>{news.category}</span>
                  <span>{news.readingTime}</span>
                </div>
                <h3>{news.title}</h3>
                <p>{news.excerpt}</p>
                <Link to="/gambling-news" className="inline-link">
                  Читать →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section cta-section">
        <div className="container cta-card">
          <div className="cta-content">
            <h2>Присоединяйтесь к аудитории GambleReview</h2>
            <p>
              Получайте короткие аналитические дайджесты, схемы сравнения бонусов и напоминания об
              инструментах самоконтроля.
            </p>
          </div>
          <div className="cta-actions">
            <Link to="/contact" className="btn btn--accent">
              Связаться с редакцией
            </Link>
            <Link to="/services" className="btn btn--ghost">
              Наша методология
            </Link>
          </div>
        </div>
      </section>

      <section className="section newsletter-section">
        <div className="container newsletter-card">
          <div>
            <h2 className="section-title">Рассылка без спама</h2>
            <p className="section-subtitle">
              Только аналитика, обзоры и советы по ответственному гэмблингу. Можно отписаться в любой
              момент.
            </p>
          </div>
          <form className="newsletter-form" onSubmit={handleNewsletter} noValidate>
            <label htmlFor="newsletter-email" className="sr-only">
              Email
            </label>
            <input
              id="newsletter-email"
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="Введите ваш email"
              aria-invalid={Boolean(emailError)}
            />
            <button type="submit" className="btn btn--accent">
              Подписаться
            </button>
          </form>
          {emailError && <p className="form-error">{emailError}</p>}
          {newsletterStatus && <p className="form-success">{newsletterStatus}</p>}
        </div>
      </section>

      <section className="section responsible-section">
        <div className="container responsible-card">
          <h2>Ответственная игра — наш приоритет</h2>
          <p>
            GambleReview выступает за ответственное отношение к азартным играм. Наши обзоры и рейтинги не
            содержат призывов к ставкам. Если вы чувствуете дискомфорт, обратитесь за помощью к
            профессионалам: <a href="https://www.gamcare.org.uk" rel="noopener noreferrer">GamCare</a> или{' '}
            <a href="https://www.begambleaware.org" rel="noopener noreferrer">BeGambleAware</a>. Введите
            личные лимиты, используйте тайм-ауты и контролируйте эмоции.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Home;