import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import GoUpButton from './components/GoUpButton';
import Home from './pages/Home';
import CasinoReviews from './pages/CasinoReviews';
import CasinoDetail from './pages/CasinoDetail';
import Comparison from './pages/Comparison';
import Rating from './pages/Rating';
import GamblingNews from './pages/GamblingNews';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import About from './pages/About';
import Contact from './pages/Contact';
import Services from './pages/Services';
import casinos from './data/casinos';

const metaMap = {
  '/': {
    title: 'GambleReview — аналитика и обзоры казино',
    description:
      'Актуальные обзоры казино, детальное сравнение бонусов и условий, аналитика надежности и ответственный подход.',
    keywords:
      'гэмблинг, казино, обзоры казино, рейтинг казино, бонусы казино, сравнение казино'
  },
  '/casino-reviews': {
    title: 'Обзоры казино | GambleReview',
    description:
      'Подробные обзоры международных казино: бонусы, условия отыгрыша, платежные методы и безопасность.',
    keywords:
      'обзоры казино, условия казино, бонусы казино, платежные системы'
  },
  '/comparison': {
    title: 'Сравнение условий казино | GambleReview',
    description:
      'Сравнительная таблица условий казино: приветственные бонусы, вейджер, лимиты выплат и каталог игр.',
    keywords:
      'сравнение казино, таблица бонусов, вейджер, лимиты казино'
  },
  '/rating': {
    title: 'Рейтинг казино по надежности | GambleReview',
    description:
      'Топ международных казино по надежности, условиям и отзывам игроков. Независимая оценка команды GambleReview.',
    keywords:
      'рейтинг казино, надежность казино, отзывы игроков'
  },
  '/gambling-news': {
    title: 'Новости гэмблинга | GambleReview',
    description:
      'Индустриальные новости, регуляторные обновления и аналитика рынка онлайн-казино.',
    keywords: 'новости казино, новости гэмблинга, регуляция азартных игр'
  },
  '/services': {
    title: 'Наши сервисы и методы исследования | GambleReview',
    description:
      'Методология GambleReview: аудит лицензий, тестирование бонусов и UX-анализ казино.',
    keywords: 'аудит казино, тестирование бонусов, аналитика казино'
  },
  '/about': {
    title: 'О проекте GambleReview',
    description:
      'Миссия GambleReview — помогать аудитории делать осознанный выбор среди казино и продвигать ответственную игру.',
    keywords: 'о проекте, команда GambleReview, ответственная игра'
  },
  '/contact': {
    title: 'Контакты GambleReview',
    description:
      'Свяжитесь с командой GambleReview: партнерства, медиа-запросы и обратная связь.',
    keywords: 'контакты GambleReview, партнерство, поддержка'
  },
  '/terms': {
    title: 'Условия использования — GambleReview',
    description:
      'Правила использования материалов сайта GambleReview, ограничения ответственности и юридические положения.',
    keywords: 'условия использования, юридическая информация'
  },
  '/privacy': {
    title: 'Политика конфиденциальности — GambleReview',
    description:
      'Описание обработки персональных данных, использование cookies и защита информации на GambleReview.',
    keywords: 'политика конфиденциальности, обработка данных'
  },
  '/cookie-policy': {
    title: 'Политика Cookie — GambleReview',
    description:
      'Узнайте о применении файлов cookie на сайте GambleReview и настройках для пользователей.',
    keywords: 'cookie, политика cookie, файл cookie'
  }
};

const defaultMeta = metaMap['/'];

const usePageMeta = (pathname) => {
  useEffect(() => {
    let meta = metaMap[pathname];
    if (!meta && pathname.startsWith('/casino-reviews/')) {
      const slug = pathname.split('/').pop();
      const casino = casinos.find((item) => item.slug === slug);
      meta = casino
        ? {
            title: `${casino.name} — обзор казино | GambleReview`,
            description: `Изучите условия ${casino.name}: бонус ${casino.bonus}, вейджер ${casino.wager}, платежные варианты и надежность.`,
            keywords: `обзор ${casino.name}, бонусы казино, надежность ${casino.name}`
          }
        : metaMap['/casino-reviews'];
    }
    if (!meta) {
      meta = defaultMeta;
    }
    document.title = meta.title;
    const descriptionTag = document.querySelector('meta[name="description"]');
    if (descriptionTag) {
      descriptionTag.setAttribute('content', meta.description);
    }
    const keywordsTag = document.querySelector('meta[name="keywords"]');
    if (keywordsTag) {
      keywordsTag.setAttribute('content', meta.keywords);
    }
  }, [pathname]);
};

const App = () => {
  const location = useLocation();
  usePageMeta(location.pathname);

  return (
    <>
      <ScrollToTop />
      <div className="app-shell">
        <Header />
        <main id="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/casino-reviews" element={<CasinoReviews />} />
            <Route path="/casino-reviews/:slug" element={<CasinoDetail />} />
            <Route path="/comparison" element={<Comparison />} />
            <Route path="/rating" element={<Rating />} />
            <Route path="/gambling-news" element={<GamblingNews />} />
            <Route path="/services" element={<Services />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookie-policy" element={<CookiePolicy />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <GoUpButton />
      </div>
    </>
  );
};

export default App;