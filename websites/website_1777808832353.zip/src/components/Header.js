import React, { useEffect, useState } from 'react';
import { NavLink, Link } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 64);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  const navLinks = [
    { to: '/', label: 'Главная' },
    { to: '/casino-reviews', label: 'Обзоры казино' },
    { to: '/comparison', label: 'Сравнение' },
    { to: '/rating', label: 'Рейтинг' },
    { to: '/gambling-news', label: 'Новости' },
    { to: '/services', label: 'Сервисы' },
    { to: '/about', label: 'О проекте' },
    { to: '/contact', label: 'Контакты' }
  ];

  return (
    <header
      className={`site-header ${scrolled ? 'site-header--scrolled' : ''}`}
      aria-label="Основная навигация сайта"
    >
      <div className="container header-inner">
        <Link to="/" className="logo" onClick={closeMenu}>
          <span className="logo-mark" aria-hidden="true">
            GR
          </span>
          <div className="logo-text">
            <span className="logo-title">GambleReview</span>
            <span className="logo-tagline">аналитика казино</span>
          </div>
        </Link>

        <button
          className={`menu-toggle ${menuOpen ? 'menu-toggle--open' : ''}`}
          aria-label="Открыть меню"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>

        <nav className={`site-nav ${menuOpen ? 'site-nav--open' : ''}`}>
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `site-nav__link ${isActive ? 'site-nav__link--active' : ''}`
              }
              onClick={closeMenu}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;