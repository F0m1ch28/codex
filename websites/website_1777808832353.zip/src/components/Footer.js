import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="site-footer">
    <div className="container footer-grid">
      <div className="footer-brand">
        <div className="footer-logo">
          <span className="logo-mark" aria-hidden="true">
            GR
          </span>
          <div>
            <span className="logo-title">GambleReview</span>
            <p className="logo-tagline">ответственный путеводитель по казино</p>
          </div>
        </div>
        <p className="footer-description">
          Мы исследуем международные казино, анализируем лицензии, условия бонусов и практики
          ответственности. Наши материалы предназначены для аудитории 18+ и не содержат призывов к игре.
        </p>
        <p className="footer-disclaimer">
          Ответственная игра: всегда планируйте бюджет и соблюдайте ограничения законодательства вашей
          юрисдикции.
        </p>
      </div>

      <div className="footer-column">
        <h3>Навигация</h3>
        <ul>
          <li>
            <Link to="/casino-reviews">Обзоры казино</Link>
          </li>
          <li>
            <Link to="/comparison">Сравнение условий</Link>
          </li>
          <li>
            <Link to="/rating">Рейтинг надежности</Link>
          </li>
          <li>
            <Link to="/gambling-news">Новости индустрии</Link>
          </li>
          <li>
            <Link to="/services">Сервисы и методология</Link>
          </li>
        </ul>
      </div>

      <div className="footer-column">
        <h3>Правовая информация</h3>
        <ul>
          <li>
            <Link to="/terms">Условия использования</Link>
          </li>
          <li>
            <Link to="/privacy">Политика конфиденциальности</Link>
          </li>
          <li>
            <Link to="/cookie-policy">Политика Cookie</Link>
          </li>
        </ul>
        <p className="footer-note">
          GambleReview не принимает платежи и не проводит азартные игры. Информация носит обзорный
          характер.
        </p>
      </div>

      <div className="footer-column">
        <h3>Контакты</h3>
        <ul className="footer-contact">
          <li>
            Email:{' '}
            <a href="mailto:info@gamblereview.com" rel="noopener noreferrer">
              info@gamblereview.com
            </a>
          </li>
          <li>Телефон: support line +1 (000) 000-0000</li>
          <li>Адрес: Online platform</li>
        </ul>
        <p className="footer-newsletter-invite">
          Присоединяйтесь к рассылке, чтобы получать аналитические дайджесты и обновления стандартов
          ответственной игры.
        </p>
      </div>
    </div>
    <div className="footer-bottom">
      <p>© {new Date().getFullYear()} GambleReview. Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;