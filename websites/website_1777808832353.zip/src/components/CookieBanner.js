import React, { useEffect, useState } from 'react';

const storageKey = 'gamblereview-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(storageKey);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(storageKey, 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem(storageKey, 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-banner__content">
        <h3>Cookie-файлы</h3>
        <p>
          Мы используем технические и аналитические cookie, чтобы улучшать работу сайта. Вы можете
          ознакомиться с{' '}
          <a href="/cookie-policy" className="inline-link">
            Политикой Cookie
          </a>{' '}
          и выбрать подходящий вариант.
        </p>
      </div>
      <div className="cookie-banner__actions">
        <button type="button" className="btn btn--secondary" onClick={handleDecline}>
          Только необходимые
        </button>
        <button type="button" className="btn" onClick={handleAccept}>
          Принять все
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;