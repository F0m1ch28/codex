import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

const FavoritesContext = createContext();

export const FavoritesProvider = ({ children }) => {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    const stored = window.localStorage.getItem('gamblereview-favorites');
    if (stored) {
      try {
        setFavorites(JSON.parse(stored));
      } catch (error) {
        setFavorites([]);
      }
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem('gamblereview-favorites', JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = (casinoId) => {
    setFavorites((prev) =>
      prev.includes(casinoId) ? prev.filter((id) => id !== casinoId) : [...prev, casinoId]
    );
  };

  const value = useMemo(
    () => ({
      favorites,
      toggleFavorite,
      isFavorite: (casinoId) => favorites.includes(casinoId)
    }),
    [favorites]
  );

  return <FavoritesContext.Provider value={value}>{children}</FavoritesContext.Provider>;
};

export const useFavorites = () => useContext(FavoritesContext);