document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');
  if (navToggle && mainNav) {
    navToggle.addEventListener('click', function () {
      const expanded = this.getAttribute('aria-expanded') === 'true';
      this.setAttribute('aria-expanded', String(!expanded));
      mainNav.classList.toggle('is-open');
    });
    mainNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        navToggle.setAttribute('aria-expanded', 'false');
        mainNav.classList.remove('is-open');
      });
    });
  }

  const storageKey = 'test123nov26_cookie_consent';
  const banner = document.querySelector('[data-cookie-banner]');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const rejectBtn = document.querySelector('[data-cookie-reject]');

  const storageAvailable = (() => {
    try {
      const testKey = '__test_key__';
      window.localStorage.setItem(testKey, testKey);
      window.localStorage.removeItem(testKey);
      return true;
    } catch (error) {
      return false;
    }
  })();

  const hideBanner = () => {
    if (banner) {
      banner.classList.add('is-hidden');
    }
  };

  if (banner && storageAvailable) {
    const savedStatus = localStorage.getItem(storageKey);
    if (savedStatus === 'accepted' || savedStatus === 'rejected') {
      hideBanner();
    }
  }

  const storeConsent = (status) => {
    if (storageAvailable) {
      localStorage.setItem(storageKey, status);
    }
    hideBanner();
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', function () {
      storeConsent('accepted');
    });
  }

  if (rejectBtn) {
    rejectBtn.addEventListener('click', function () {
      storeConsent('rejected');
    });
  }
});