document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteHeader = document.querySelector(".site-header");
  const primaryNav = document.querySelector(".primary-nav");
  const navLinks = document.querySelectorAll(".nav-link");
  const currentPage = document.body.dataset.page;

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = primaryNav.classList.toggle("is-open");
      document.body.classList.toggle("nav-open", isOpen);
      siteHeader.classList.toggle("is-open", isOpen);
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });

    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        primaryNav.classList.remove("is-open");
        document.body.classList.remove("nav-open");
        siteHeader.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  if (currentPage) {
    navLinks.forEach((link) => {
      if (link.dataset.page === currentPage) {
        link.classList.add("is-active");
      }
    });
  }

  if (siteHeader) {
    const toggleScrolledClass = () => {
      siteHeader.classList.toggle("is-scrolled", window.scrollY > 12);
    };
    toggleScrolledClass();
    window.addEventListener("scroll", toggleScrolledClass);
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".cookie-accept");
  const declineBtn = document.querySelector(".cookie-decline");
  const storageKey = "pic_cookie_choice";

  if (cookieBanner) {
    const savedChoice = localStorage.getItem(storageKey);

    if (!savedChoice) {
      requestAnimationFrame(() => cookieBanner.classList.add("is-visible"));
    }

    const closeBanner = (choice) => {
      localStorage.setItem(storageKey, choice);
      cookieBanner.classList.remove("is-visible");
    };

    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => closeBanner("accepted"));
    }

    if (declineBtn) {
      declineBtn.addEventListener("click", () => closeBanner("declined"));
    }
  }
});