(function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const cookieBanner = document.getElementById("cookieBanner");
    const cookieChoices = document.querySelectorAll(".cookie-btn[data-choice]");
    const navLinks = document.querySelectorAll(".nav-list a");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", function () {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            siteNav.classList.toggle("is-active", !expanded);
        });

        navLinks.forEach(function (link) {
            link.addEventListener("click", function () {
                navToggle.setAttribute("aria-expanded", "false");
                siteNav.classList.remove("is-active");
            });
        });

        document.addEventListener("click", function (event) {
            if (siteNav.classList.contains("is-active") && !siteNav.contains(event.target) && !navToggle.contains(event.target)) {
                navToggle.setAttribute("aria-expanded", "false");
                siteNav.classList.remove("is-active");
            }
        });
    }

    if (cookieBanner && cookieChoices.length) {
        const storageKey = "abbeyuuvnCookieChoice";
        const choice = localStorage.getItem(storageKey);

        if (!choice) {
            cookieBanner.classList.add("is-visible");
        }

        cookieChoices.forEach(function (choiceBtn) {
            choiceBtn.addEventListener("click", function (event) {
                event.preventDefault();
                const decision = choiceBtn.getAttribute("data-choice");
                localStorage.setItem(storageKey, decision);
                cookieBanner.classList.remove("is-visible");
                window.location.href = choiceBtn.getAttribute("href");
            });
        });
    }
}());