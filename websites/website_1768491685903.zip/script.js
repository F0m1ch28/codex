document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('[data-nav-toggle]');
    const navMenu = document.querySelector('[data-nav-menu]');
    const cookieBanner = document.querySelector('[data-cookie-banner]');
    const cookieAccept = document.querySelector('[data-cookie-accept]');
    const cookieDecline = document.querySelector('[data-cookie-decline]');
    const consentKey = 'romanlqkgxCookieConsent';

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !expanded);
            navMenu.classList.toggle('active');
        });
    }

    if (cookieBanner && cookieAccept && cookieDecline) {
        const consentStatus = localStorage.getItem(consentKey);
        if (!consentStatus) {
            cookieBanner.classList.add('active');
        }

        cookieAccept.addEventListener('click', function () {
            localStorage.setItem(consentKey, 'accepted');
            cookieBanner.classList.remove('active');
        });

        cookieDecline.addEventListener('click', function () {
            localStorage.setItem(consentKey, 'declined');
            cookieBanner.classList.remove('active');
        });
    }
});