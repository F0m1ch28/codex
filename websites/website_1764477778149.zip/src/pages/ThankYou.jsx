```javascript
import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'

const ThankYou = () => {
  useEffect(() => {
    document.title = 'Thank you • Tu Progreso Hoy'
  }, [])

  return (
    <div className="section section--light">
      <div className="container">
        <div className="card" style={{ margin: '0 auto', maxWidth: '640px', textAlign: 'center' }}>
          <div className="badge" style={{ marginInline: 'auto' }}>Step 2 of 2</div>
          <h1 style={{ marginTop: '1rem' }}>Gracias / Thank you</h1>
          <p>
            Hemos recibido tu solicitud para el módulo de prueba. Revisa tu bandeja de entrada y confirma el email para completar el doble opt-in.
          </p>
          <p>
            Recuerda: Plataforma educativa con datos esenciales, sin asesoría financiera directa. Información confiable que respalda elecciones responsables sobre tu dinero.
          </p>
          <div style={{ marginTop: '2rem', display: 'flex', justifyContent: 'center', gap: '1rem', flexWrap: 'wrap' }}>
            <Link to="/" className="primary-button">
              Back to Home
            </Link>
            <Link to="/course" className="secondary-button">
              Review the syllabus
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ThankYou
```