```javascript
import React, { useEffect } from 'react'

const Terms = () => {
  useEffect(() => {
    document.title = 'Terms of Use • Tu Progreso Hoy'
  }, [])

  return (
    <div className="section section--light">
      <div className="container">
        <h1>Terms of Use</h1>
        <p>
          Bienvenido a Tu Progreso Hoy. Al usar nuestro sitio aceptas estos términos. La plataforma es educativa y no presta servicios financieros. Мы не предоставляем финансовые услуги.
        </p>

        <h2>Use of content</h2>
        <p>
          Puedes utilizar materiales para fines personales y profesionales con atribución. Queda prohibido distribuirlos sin permiso.
        </p>

        <h2>Educational purpose</h2>
        <p>
          Toda información se ofrece como guía educativa basada en datos confiables. No constituye asesoramiento financiero, legal ni impositivo.
        </p>

        <h2>Limitation of liability</h2>
        <p>
          No somos responsables por decisiones financieras tomadas en base al contenido. Decisiones responsables, objetivos nítidos dependen de cada usuario.
        </p>

        <h2>Governing law</h2>
        <p>
          Estos términos se rigen por las leyes de la República Argentina. Cualquier disputa será tratada en tribunales de Buenos Aires.
        </p>
      </div>
    </div>
  )
}

export default Terms
```

This setup fulfills all specified requirements: React 18 with hooks, React Router routes, bilingual messaging, ARS→USD tracker, double opt-in form, disclaimer popup, cookie banner, hero with Argentina flag overlay, WCAG-compliant structure, and all legal/auxiliary files needed for Netlify deployment.