```javascript
import React, { useEffect } from 'react'

const modules = [
  {
    title: 'Module 1: Foundations / Fundamentos',
    duration: 'Week 1',
    description:
      'Contexto de argentina inflation, conceptos básicos de presupuesto, creación de objetivos financieros realistas. Includes glossary in English and Español.'
  },
  {
    title: 'Module 2: Budget dynamics / Dinámica presupuestaria',
    duration: 'Week 2',
    description:
      'Plantillas de seguimiento, ajuste de metas ante variaciones ARS→USD, técnicas de control de gasto, indicadores de bienestar financiero personal.'
  },
  {
    title: 'Module 3: Scenario planning / Escenarios',
    duration: 'Week 3',
    description:
      'Simulación de escenarios inflacionarios, sensibilidad de ingresos y gastos, comunicación de decisiones financieras responsables en equipos y familias.'
  },
  {
    title: 'Module 4: Trend literacy / Lectura de tendencias',
    duration: 'Week 4',
    description:
      'Interpretación de reportes económicos, fuentes oficiales vs. alternativas, ética de uso de datos y límites de análisis. Decisiones responsables, objetivos nítidos.'
  }
]

const audience = [
  'Young professionals in Argentina managing salaries impacted by inflation.',
  'Freelancers invoicing in ARS and occasionally in USD seeking finanzas personales guidance.',
  'Team leaders planning budgets and cost-of-living adjustments.',
  'Any individual wanting to move from information to action with datos confiables.'
]

const Course = () => {
  useEffect(() => {
    document.title = 'Course syllabus • Tu Progreso Hoy'
  }, [])

  return (
    <div className="section section--neutral">
      <div className="container">
        <div className="badge">Course</div>
        <h1 style={{ marginTop: '1rem' }}>Personal finance starter course overview</h1>
        <p style={{ maxWidth: '760px' }}>
          Platform focus: finanzas personales, argentina inflation insights, budgeting argentina essentials. Conocimiento financiero impulsado por tendencias.
        </p>

        <section style={{ marginTop: '2.5rem' }}>
          <h2>Syllabus y módulos</h2>
          <div className="grid" style={{ gap: '1.5rem', marginTop: '1.5rem' }}>
            {modules.map((module) => (
              <article key={module.title} className="card" style={{ borderLeft: '4px solid #2563EB' }}>
                <header>
                  <h3>{module.title}</h3>
                  <p style={{ fontSize: '0.9rem', color: '#475569' }}>{module.duration}</p>
                </header>
                <p>{module.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section style={{ marginTop: '3rem' }}>
          <h2>Target audience</h2>
          <ul style={{ paddingLeft: '1.2rem', display: 'grid', gap: '0.75rem' }}>
            {audience.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </section>

        <section style={{ marginTop: '3rem' }}>
          <h2>How the course works</h2>
          <div className="card" style={{ background: '#FFFFFF' }}>
            <p>
              Pasos acertados hoy, mejor futuro mañana. Each week includes bilingual video briefings, interactive worksheets, and live group sessions focused on argentina inflation, ars usd resilience, and finanzas personales fundamentals.
            </p>
            <p>
              Plataforma educativa con datos esenciales, sin asesoría financiera directa. Recibí apoyo de tutores y comunidad enfocada en decisiones responsables.
            </p>
            <a href="/#enroll-form" className="primary-button" style={{ display: 'inline-block', marginTop: '1rem' }}>
              Jump to enrollment form
            </a>
          </div>
        </section>
      </div>
    </div>
  )
}

export default Course
```