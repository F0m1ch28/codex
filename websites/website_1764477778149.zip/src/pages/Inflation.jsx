```javascript
import React, { useEffect } from 'react'

const methodologySteps = [
  {
    title: 'Data collection',
    content:
      'We compile Argentina inflation series from INDEC, exchange rates from Banco Central de la República Argentina, and supplementary indicators from international institutions (IMF, World Bank). Datos verificados para planificar tu presupuesto.'
  },
  {
    title: 'Normalization & seasonal adjustment',
    content:
      'Each dataset is normalized to monthly frequency. When publication calendars diverge, we interpolate with conservative assumptions and flag revisions.'
  },
  {
    title: 'Contextual narratives',
    content:
      'We add commentary in English and Spanish to highlight drivers of argentina inflation, ars usd movements, and budgeting argentina considerations for households.'
  }
]

const chartData = [
  { month: 'Jan', ipc: 3.8, usd: 180 },
  { month: 'Feb', ipc: 4.2, usd: 190 },
  { month: 'Mar', ipc: 4.8, usd: 205 },
  { month: 'Apr', ipc: 5.1, usd: 220 },
  { month: 'May', ipc: 5.3, usd: 235 },
  { month: 'Jun', ipc: 5.7, usd: 250 }
]

const faqs = [
  {
    question: 'How often are the reports updated?',
    answer: 'We publish weekly briefs on exchange rate signals and a comprehensive inflation review at the end of each month. Updates follow official data releases to ensure accuracy.'
  },
  {
    question: 'Do you offer forecasts?',
    answer: 'We provide scenario planning with transparent assumptions, but not deterministic forecasts. Platforma educativa con datos esenciales, sin asesoría financiera directa.'
  },
  {
    question: 'Can I share the insights with my team?',
    answer: 'Yes. You may share excerpts with attribution to Tu Progreso Hoy. Enterprise plans include collaborative workspaces for teams in Buenos Aires and beyond.'
  }
]

const Inflation = () => {
  useEffect(() => {
    document.title = 'Inflation insights • Tu Progreso Hoy'
  }, [])

  return (
    <div className="section section--light">
      <div className="container">
        <div className="badge">Methodology</div>
        <h1 style={{ marginTop: '1rem' }}>Argentina inflation methodology</h1>
        <p style={{ maxWidth: '760px' }}>
          Conocimiento financiero impulsado por tendencias. Nuestro enfoque combina CPI, tipos de cambio y señales macro para orientar finanzas personales en Argentina.
        </p>

        <div className="grid grid-3" style={{ marginTop: '2.5rem' }}>
          {methodologySteps.map((step) => (
            <div key={step.title} className="card">
              <h3>{step.title}</h3>
              <p>{step.content}</p>
            </div>
          ))}
        </div>

        <div style={{ marginTop: '3rem' }}>
          <h2>CPI & Exchange Rate context</h2>
          <p>
            Seguimos indicadores oficiales y alternativos para contrastar inflación general, núcleo y variaciones del tipo de cambio. Análisis transparentes y datos de mercado para decidir con seguridad.
          </p>
          <div className="card">
            <div className="table-responsive">
              <table>
                <caption style={{ textAlign: 'left', padding: '0.75rem 1rem', captionSide: 'bottom', color: '#475569' }}>
                  Indicative data plotted for visualization. Official releases apply upon publication by Argentine authorities.
                </caption>
                <thead>
                  <tr>
                    <th scope="col">Month</th>
                    <th scope="col">CPI monthly %</th>
                    <th scope="col">ARS per USD (avg)</th>
                  </tr>
                </thead>
                <tbody>
                  {chartData.map((row) => (
                    <tr key={row.month}>
                      <td>{row.month}</td>
                      <td>{row.ipc.toFixed(1)}%</td>
                      <td>{row.usd}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div style={{ display: 'grid', gap: '0.75rem', marginTop: '1rem' }}>
              <div className="alert">
                CPI trend commentary: higher energy costs and regulated price adjustments keep argentina inflation elevated.
              </div>
              <div className="alert">
                ARS→USD context: peso volatility reflects policy uncertainty and carry-trade flows. Monitor parallel market spread weekly.
              </div>
            </div>
          </div>
        </div>

        <div style={{ marginTop: '3rem' }}>
          <h2>Frequently asked questions</h2>
          <div style={{ display: 'grid', gap: '1rem', marginTop: '1.5rem' }}>
            {faqs.map((faq) => (
              <details key={faq.question} className="card">
                <summary style={{ cursor: 'pointer', fontWeight: 600 }}>{faq.question}</summary>
                <p style={{ marginTop: '1rem' }}>{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Inflation
```