```javascript
import React, { useEffect } from 'react'

const Privacy = () => {
  useEffect(() => {
    document.title = 'Privacy Policy • Tu Progreso Hoy'
  }, [])

  return (
    <div className="section section--light">
      <div className="container">
        <h1>Privacy Policy</h1>
        <p>Effective date: {new Date().getFullYear()}</p>
        <p>
          Tu Progreso Hoy opera en Argentina con enfoque educativo. Esta política describe cómo recopilamos, usamos y protegemos datos personales en cumplimiento con normativa local y buenas prácticas internacionales.
        </p>

        <h2>Data we collect</h2>
        <ul>
          <li>Información de contacto provista al solicitar el curso o recursos.</li>
          <li>Preferencias de idioma y consentimientos de cookies.</li>
          <li>Datos de uso anónimos para mejorar experiencias, solo si aceptas cookies analíticas.</li>
        </ul>

        <h2>How we use data</h2>
        <p>
          Usamos la información para enviar materiales educativos, procesar el doble opt-in y compartir actualizaciones sobre argentina inflation y finanzas personales. No vendemos datos ni ofrecemos asesoría financiera directa.
        </p>

        <h2>Storage & security</h2>
        <p>
          Implementamos medidas razonables para proteger datos. Accesos están limitados al equipo de Tu Progreso Hoy en Buenos Aires.
        </p>

        <h2>Your rights</h2>
        <p>
          Podés solicitar acceso, corrección o eliminación escribiendo a <a href="mailto:privacidad@tuprogresohoy.ar">privacidad@tuprogresohoy.ar</a>.
        </p>

        <h2>Contact</h2>
        <p>
          If you have questions, contact Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina or email <a href="mailto:hola@tuprogresohoy.ar">hola@tuprogresohoy.ar</a>.
        </p>
      </div>
    </div>
  )
}

export default Privacy
```