```javascript
import React, { useEffect } from 'react'

const Cookies = () => {
  useEffect(() => {
    document.title = 'Cookie Policy • Tu Progreso Hoy'
  }, [])

  return (
    <div className="section section--light">
      <div className="container">
        <h1>Cookie Policy</h1>
        <p>We implement an opt-in cookie model respecting user preferences.</p>

        <h2>Types of cookies</h2>
        <ul>
          <li><strong>Essential:</strong> Required to maintain session security and remember language preferences.</li>
          <li><strong>Analytics (optional):</strong> Used to understand traffic patterns. Activated only when accepted.</li>
        </ul>

        <h2>Managing preferences</h2>
        <p>
          Puedes cambiar tu decisión eliminando el almacenamiento local de tu navegador o contactándonos en <a href="mailto:hola@tuprogresohoy.ar">hola@tuprogresohoy.ar</a>.
        </p>

        <h2>Updates</h2>
        <p>We may adjust this policy in line with regulatory changes in Argentina or international guidance.</p>
      </div>
    </div>
  )
}

export default Cookies
```