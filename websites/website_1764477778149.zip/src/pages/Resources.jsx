```javascript
import React, { useEffect } from 'react'

const resources = [
  {
    title: 'Argentina inflation tracker explained',
    language: 'English',
    description: 'Break down CPI methodology, peso dynamics, and how to translate indicators into practical budgeting steps.',
    link: '#'
  },
  {
    title: 'Glosario de finanzas personales (ES/EN)',
    language: 'Español / English',
    description: 'Términos clave para interpretar reportes económicos, contratos y acuerdos financieros en Argentina.',
    link: '#'
  },
  {
    title: 'Budgeting Argentina: herramientas gratuitas',
    language: 'English',
    description: 'Toolkits for monitoring gastos fijos, inflación of salaries, and building inflation-resistant savings plans.',
    link: '#'
  },
  {
    title: 'Tendencias económicas en Argentina — reporte semanal',
    language: 'Español',
    description: 'Resumen de indicadores clave con foco en inflación, consumo y expectativas de mercado.',
    link: '#'
  }
]

const Resources = () => {
  useEffect(() => {
    document.title = 'Resources • Tu Progreso Hoy'
  }, [])

  return (
    <div className="section section--light">
      <div className="container">
        <div className="badge">Resources</div>
        <h1 style={{ marginTop: '1rem' }}>Educational resources / Recursos educativos</h1>
        <p style={{ maxWidth: '720px' }}>
          Información confiable que respalda elecciones responsables sobre tu dinero. Descarga guías, glosarios y artículos que conectan tendencias macro con acciones concretas.
        </p>
        <div className="grid" style={{ gap: '1.5rem', marginTop: '2.5rem' }}>
          {resources.map((resource) => (
            <article key={resource.title} className="card">
              <h3>{resource.title}</h3>
              <p style={{ fontSize: '0.85rem', textTransform: 'uppercase', letterSpacing: '0.05em', color: '#2563EB' }}>{resource.language}</p>
              <p>{resource.description}</p>
              <a href={resource.link} className="secondary-button" style={{ marginTop: '1rem', display: 'inline-block' }}>
                Coming soon
              </a>
            </article>
          ))}
        </div>
      </div>
    </div>
  )
}

export default Resources
```