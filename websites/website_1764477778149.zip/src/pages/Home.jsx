```javascript
import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import ARSUSDTracker from '../components/ARSUSDTracker'

const promiseList = [
  'Decisiones responsables, objetivos nítidos.',
  'Conocimiento financiero impulsado por tendencias.',
  'Pasos acertados hoy, mejor futuro mañana.',
  'Información confiable que respalda elecciones responsables sobre tu dinero.'
]

const testimonials = [
  {
    name: 'Luciana Gómez',
    title: 'Marketing Analyst, Córdoba',
    quote:
      'Los módulos de Tu Progreso Hoy me ayudaron a comprender el impacto de la inflación en mis metas de ahorro. Decisiones responsables, objetivos nítidos.'
  },
  {
    name: 'Martín Ruiz',
    title: 'Freelance Developer, Mendoza',
    quote:
      'Datos verificados para planificar tu presupuesto. El seguimiento ARS→USD me orienta para ajustar honorarios en contratos internacionales.'
  },
  {
    name: 'Sofía Ferreyra',
    title: 'Product Manager, Buenos Aires',
    quote:
      'Plataforma educativa con datos esenciales, sin asesoría financiera directa. Aprender a mi ritmo y reconocer tendencias del mercado fue clave.'
  }
]

const Home = () => {
  const navigate = useNavigate()

  useEffect(() => {
    document.title = 'Tu Progreso Hoy — Argentina inflation insights & personal finance course'
  }, [])

  const handleSubmit = (event) => {
    event.preventDefault()
    navigate('/thank-you')
  }

  return (
    <>
      <section
        className="section"
        style={{
          paddingTop: '6rem',
          paddingBottom: '5rem',
          background: 'linear-gradient(135deg, rgba(31,58,111,0.95), rgba(37,99,235,0.85))',
          color: '#FFFFFF',
          position: 'relative',
          overflow: 'hidden'
        }}
        aria-labelledby="hero-title"
      >
        <div
          aria-hidden="true"
          style={{
            position: 'absolute',
            inset: 0,
            backgroundImage: 'url("https://upload.wikimedia.org/wikipedia/commons/1/1a/Flag_of_Argentina.svg")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            opacity: 0.12,
            mixBlendMode: 'screen'
          }}
        />
        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <div className="badge" style={{ background: 'rgba(15, 23, 42, 0.4)', color: '#E2E8F0' }}>
            Argentina • Educational SaaS
          </div>
          <h1 id="hero-title" style={{ fontSize: 'clamp(2.4rem, 5vw, 3.4rem)', marginTop: '1rem', marginBottom: '1rem' }}>
            Datos verificados para planificar tu presupuesto.
          </h1>
          <p style={{ fontSize: '1.1rem', maxWidth: '720px', marginBottom: '2rem', color: '#F8FAFC' }}>
            Análisis transparentes y datos de mercado para decidir con seguridad. Tu Progreso Hoy acerca contexto de inflación argentina, tipo de cambio ARS→USD e inicia tu ruta de finanzas personales con guía bilingüe.
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem' }}>
            <a href="#enroll-form" className="primary-button" style={{ textDecoration: 'none' }}>
              Получить бесплатный пробный урок
            </a>
            <a href="/inflation" className="secondary-button" style={{ textDecoration: 'none', color: '#FFFFFF', borderColor: 'rgba(255,255,255,0.25)' }}>
              Explore inflation insights
            </a>
          </div>
          <div style={{ marginTop: '2.5rem', display: 'grid', gap: '1rem' }}>
            {promiseList.map((item) => (
              <div key={item} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', background: 'rgba(15,23,42,0.25)', padding: '0.9rem 1rem', borderRadius: '12px' }}>
                <span aria-hidden="true" style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#FACC15' }} />
                <span style={{ fontWeight: 600 }}>{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section section--light">
        <div className="container">
          <div className="grid grid-2" style={{ alignItems: 'start' }}>
            <ARSUSDTracker />
            <div className="card" style={{ background: 'linear-gradient(135deg, rgba(37,99,235,0.15), rgba(15,23,42,0.08))' }}>
              <h3>Argentina inflation insights</h3>
              <p>
                Conoce evolución del índice de precios al consumidor, escenarios de tipo de cambio y cómo influyen en tu presupuesto. Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.
              </p>
              <ul style={{ paddingLeft: '1.2rem', display: 'grid', gap: '0.5rem' }}>
                <li>Panorama mensual del IPC y expectativas inflacionarias locales.</li>
                <li>Contexto ARS vs. USD con referencia a tasas oficiales y alternativas.</li>
                <li>Indicadores complementarios de consumo, salarios reales y tasas.</li>
              </ul>
              <a href="/inflation" className="primary-button" style={{ marginTop: '1.5rem', display: 'inline-block' }}>
                View methodology
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--neutral">
        <div className="container">
          <div className="badge">Course overview</div>
          <h2 style={{ marginTop: '1rem' }}>De la información al aprendizaje: fortalece tu criterio financiero paso a paso.</h2>
          <p style={{ maxWidth: '760px' }}>
            El curso inicial de finanzas personales combina materiales en inglés y español para profesionales jóvenes en Argentina. Información confiable que respalda elecciones responsables sobre tu dinero.
          </p>
          <div className="grid grid-3" style={{ marginTop: '2rem' }}>
            <div className="card">
              <h3>Módulo 1 • Fundamentos</h3>
              <p>
                Argentina inflation vs. inflación global, lectura de reportes, práctica de presupuesto familiar y adaptaciones al contexto ARS→USD.
              </p>
            </div>
            <div className="card">
              <h3>Módulo 2 • Herramientas</h3>
              <p>
                Introducción a hojas de cálculo, seguimiento de gastos, planificación de metas, plantillas bilingües y glosario finanzas personales.
              </p>
            </div>
            <div className="card">
              <h3>Módulo 3 • Rutas</h3>
              <p>
                Escenarios económicos, análisis de sensibilidad ante inflación, comunicación de objetivos financieros en equipos y familias.
              </p>
            </div>
          </div>
          <div style={{ marginTop: '2rem' }}>
            <a href="/course" className="secondary-button">
              View the complete syllabus
            </a>
          </div>
        </div>
      </section>

      <section className="section section--light">
        <div className="container">
          <div className="badge">Testimonials</div>
          <h2 style={{ marginTop: '1rem' }}>Experiencias reales, pasos acertados hoy, mejor futuro mañana.</h2>
          <div className="grid grid-3" style={{ marginTop: '2rem' }}>
            {testimonials.map((testimonial) => (
              <div key={testimonial.name} className="card" aria-label={`Testimonial from ${testimonial.name}`}>
                <blockquote style={{ marginBottom: '1rem' }}>
                  “{testimonial.quote}”
                </blockquote>
                <p style={{ fontWeight: 600 }}>{testimonial.name}</p>
                <p style={{ fontSize: '0.9rem', color: '#475569' }}>{testimonial.title}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section section--dark">
        <div className="container">
          <div className="badge" style={{ background: 'rgba(255,255,255,0.12)', color: '#FFFFFF' }}>
            Getting started
          </div>
          <h2 style={{ marginTop: '1rem', color: '#FFFFFF' }}>Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.</h2>
          <p style={{ maxWidth: '680px', color: '#E2E8F0' }}>
            Complete el formulario para recibir un módulo de prueba y confirmar tu acceso mediante doble opt-in. Conocimiento financiero impulsado por tendencias.
          </p>
          <form
            onSubmit={handleSubmit}
            id="enroll-form"
            style={{
              marginTop: '2rem',
              background: 'rgba(15, 23, 42, 0.65)',
              borderRadius: '16px',
              padding: '2rem',
              border: '1px solid rgba(226, 232, 240, 0.12)'
            }}
            aria-labelledby="enroll-title"
          >
            <h3 id="enroll-title" style={{ color: '#FFFFFF', marginBottom: '1.5rem' }}>Получить бесплатный пробный урок</h3>
            <div className="grid grid-2" style={{ gap: '1.5rem' }}>
              <div className="form-control">
                <label htmlFor="full-name">Full name / Nombre completo</label>
                <input id="full-name" name="full-name" type="text" required autoComplete="name" placeholder="María Pérez" />
              </div>
              <div className="form-control">
                <label htmlFor="email">Email (Step 1)</label>
                <input id="email" name="email" type="email" required autoComplete="email" placeholder="tu@correo.com" />
              </div>
              <div className="form-control">
                <label htmlFor="email-confirm">Confirm email (Step 2)</label>
                <input id="email-confirm" name="email-confirm" type="email" required placeholder="Re-enter email" />
              </div>
              <div className="form-control">
                <label htmlFor="goal">Main financial goal / Objetivo principal</label>
                <select id="goal" name="goal" required>
                  <option value="">Select...</option>
                  <option value="budgeting">Budgeting in Argentina</option>
                  <option value="inflation-tracking">Tracking inflation</option>
                  <option value="family-planning">Family finances</option>
                  <option value="professional-development">Professional development</option>
                </select>
              </div>
            </div>
            <div className="form-control" style={{ marginTop: '1.5rem' }}>
              <label htmlFor="message">Context / Contexto</label>
              <textarea id="message" name="message" rows="3" placeholder="Tell us more / Contanos más" />
            </div>
            <div style={{ marginTop: '1.5rem', display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
              <input id="consent" type="checkbox" required style={{ marginTop: '0.3rem' }} />
              <label htmlFor="consent" style={{ fontSize: '0.9rem', color: '#E2E8F0' }}>
                I understand Tu Progreso Hoy is an educational platform and I will confirm my subscription via the verification email. Información confiable que respalda elecciones responsables sobre tu dinero.
              </label>
            </div>
            <button type="submit" className="primary-button" style={{ marginTop: '1.75rem' }}>
              Получить бесплатный пробный урок
            </button>
          </form>
        </div>
      </section>
    </>
  )
}

export default Home
```