```javascript
import React, { useEffect } from 'react'

const Contact = () => {
  useEffect(() => {
    document.title = 'Contact • Tu Progreso Hoy'
  }, [])

  return (
    <div className="section section--neutral">
      <div className="container">
        <div className="badge">Contact</div>
        <h1 style={{ marginTop: '1rem' }}>Reach out / Contacto</h1>
        <p style={{ maxWidth: '720px' }}>
          Estamos en Buenos Aires para acompañar decisiones responsables. Use the form below or visit us at Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina.
        </p>

        <div className="grid grid-2" style={{ marginTop: '2.5rem', gap: '2rem' }}>
          <div className="card">
            <h2>Contact form</h2>
            <form onSubmit={(event) => event.preventDefault()}>
              <div className="form-control">
                <label htmlFor="contact-name">Name</label>
                <input id="contact-name" name="name" type="text" required placeholder="Nombre completo" />
              </div>
              <div className="form-control">
                <label htmlFor="contact-email">Email</label>
                <input id="contact-email" name="email" type="email" required placeholder="tu@correo.com" />
              </div>
              <div className="form-control">
                <label htmlFor="contact-topic">Topic</label>
                <select id="contact-topic" name="topic" required>
                  <option value="">Select...</option>
                  <option value="course">Course information</option>
                  <option value="insights">Inflation insights</option>
                  <option value="media">Media request</option>
                  <option value="partnership">Partnership</option>
                </select>
              </div>
              <div className="form-control">
                <label htmlFor="contact-message">Message</label>
                <textarea id="contact-message" name="message" rows="4" required placeholder="How can we help?" />
              </div>
              <div style={{ marginTop: '1rem', display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
                <input id="contact-consent" type="checkbox" required style={{ marginTop: '0.35rem' }} />
                <label htmlFor="contact-consent" style={{ fontSize: '0.9rem' }}>
                  I acknowledge Tu Progreso Hoy is an educational platform and no financial services are provided.
                </label>
              </div>
              <button type="submit" className="primary-button" style={{ marginTop: '1.5rem' }}>
                Submit
              </button>
            </form>
          </div>

          <div className="card" style={{ display: 'grid', gap: '1.5rem' }}>
            <div>
              <h2>Visit us</h2>
              <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
              <p>Phone: <a href="tel:+541155551234">+54 11 5555-1234</a></p>
              <p>Email: <a href="mailto:hola@tuprogresohoy.ar">hola@tuprogresohoy.ar</a></p>
            </div>
            <div>
              <iframe
                title="Map showing Tu Progreso Hoy location in Buenos Aires"
                src="https://maps.google.com/maps?q=Av.%209%20de%20Julio%201000%20Buenos%20Aires&t=&z=13&ie=UTF8&iwloc=&output=embed"
                width="100%"
                height="240"
                style={{ border: 0, borderRadius: '12px' }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            <div>
              <h2>Connect</h2>
              <ul style={{ listStyle: 'none', padding: 0, display: 'grid', gap: '0.5rem' }}>
                <li><a href="https://www.linkedin.com">LinkedIn</a></li>
                <li><a href="https://www.instagram.com">Instagram</a></li>
                <li><a href="https://www.twitter.com">Twitter</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Contact
```