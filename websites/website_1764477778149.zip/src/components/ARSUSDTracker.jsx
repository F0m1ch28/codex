```javascript
import React, { useEffect, useState } from 'react'

const formatDate = (date) =>
  date.toLocaleDateString('en-AR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  })

const ARSUSDTracker = () => {
  const [rate, setRate] = useState(null)
  const [trend, setTrend] = useState(null)
  const [lastUpdated, setLastUpdated] = useState(formatDate(new Date()))
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchRate = async () => {
      try {
        const response = await fetch('https://api.exchangerate.host/latest?base=ARS&symbols=USD')
        if (!response.ok) {
          throw new Error('Network response was not ok')
        }
        const data = await response.json()
        const fetchedRate = data?.rates?.USD
        if (fetchedRate) {
          setRate(1 / fetchedRate)
          setTrend(fetchedRate >= 0.003 ? 'up' : 'down')
          setLastUpdated(formatDate(new Date(data.date)))
        } else {
          throw new Error('Invalid data')
        }
      } catch (err) {
        setError('Live data unavailable. Showing indicative trend.')
        setRate(0.0038) // fallback
        setTrend('up')
      }
    }

    fetchRate()
  }, [])

  return (
    <div className="card" aria-live="polite">
      <div className="badge">ARS → USD Tracker</div>
      <h3 style={{ marginTop: '0.75rem' }}>Argentina inflation spotlight</h3>
      <p>Argentina inflation and exchange rate context to support budgeting decisions.</p>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.75rem', marginTop: '1rem' }}>
        <span style={{ fontSize: '2.5rem', fontWeight: 700, color: '#1F3A6F' }}>
          {rate ? rate.toFixed(2) : '—'}
        </span>
        <span style={{ color: trend === 'up' ? '#2563EB' : '#16A34A', fontWeight: 600, fontSize: '1rem' }}>
          {trend === 'up' ? '▲ Peso weakening' : '▼ Peso strengthening'}
        </span>
      </div>
      <p style={{ fontSize: '0.85rem', color: '#475569', marginTop: '0.75rem' }}>
        Last updated: {lastUpdated}
      </p>
      {error && (
        <div className="alert" role="status" style={{ marginTop: '1rem' }}>
          {error}
        </div>
      )}
    </div>
  )
}

export default ARSUSDTracker
```