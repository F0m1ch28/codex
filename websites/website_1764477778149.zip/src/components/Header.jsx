```javascript
import React, { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'

const Header = () => {
  const [isNavOpen, setIsNavOpen] = useState(false)

  return (
    <header style={{ background: '#0F172A', color: '#fff', position: 'sticky', top: 0, zIndex: 10 }}>
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem 0' }}>
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }} aria-label="Tu Progreso Hoy Home">
          <div style={{ width: 42, height: 42, borderRadius: '12px', background: 'linear-gradient(135deg, #2563EB, #1F3A6F)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700 }}>
            TPH
          </div>
          <div>
            <strong style={{ fontFamily: 'DM Sans', fontSize: '1.1rem' }}>Tu Progreso Hoy</strong>
            <div style={{ fontSize: '0.75rem', opacity: 0.75 }}>Datos verificados para planificar tu presupuesto.</div>
          </div>
        </Link>

        <button
          onClick={() => setIsNavOpen(!isNavOpen)}
          aria-expanded={isNavOpen}
          aria-controls="primary-navigation"
          style={{ background: 'transparent', color: '#fff', border: '1px solid rgba(255,255,255,0.25)', padding: '0.35rem 0.75rem', borderRadius: '8px', display: 'none' }}
          className="mobile-toggle"
        >
          Menu
        </button>

        <nav
          id="primary-navigation"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '1.5rem'
          }}
          className={isNavOpen ? 'nav-open' : ''}
        >
          <ul style={{ listStyle: 'none', display: 'flex', gap: '1.5rem', padding: 0, margin: 0, flexWrap: 'wrap' }}>
            <li>
              <NavLink to="/" end style={({ isActive }) => ({ color: isActive ? '#60A5FA' : '#ffffff', fontWeight: 600 })}>
                Home
              </NavLink>
            </li>
            <li>
              <NavLink to="/inflation" style={({ isActive }) => ({ color: isActive ? '#60A5FA' : '#ffffff', fontWeight: 600 })}>
                Inflation
              </NavLink>
            </li>
            <li>
              <NavLink to="/course" style={({ isActive }) => ({ color: isActive ? '#60A5FA' : '#ffffff', fontWeight: 600 })}>
                Course
              </NavLink>
            </li>
            <li>
              <NavLink to="/resources" style={({ isActive }) => ({ color: isActive ? '#60A5FA' : '#ffffff', fontWeight: 600 })}>
                Resources
              </NavLink>
            </li>
            <li>
              <NavLink to="/contact" style={({ isActive }) => ({ color: isActive ? '#60A5FA' : '#ffffff', fontWeight: 600 })}>
                Contacto
              </NavLink>
            </li>
          </ul>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <a href="tel:+541155551234" style={{ fontSize: '0.85rem', opacity: 0.85, color: '#E2E8F0' }}>
              +54 11 5555-1234
            </a>
            <a href="#enroll-form" className="primary-button" style={{ textDecoration: 'none', fontSize: '0.9rem', display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}>
              Получить бесплатный пробный урок
            </a>
          </div>
        </nav>
      </div>
    </header>
  )
}

export default Header
```