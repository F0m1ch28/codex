```javascript
import React, { useState, useEffect } from 'react'

const CookieBanner = () => {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const consentStatus = localStorage.getItem('tph-cookie-consent')
    if (!consentStatus) {
      setVisible(true)
    }
  }, [])

  const handleConsent = (status) => {
    localStorage.setItem('tph-cookie-consent', status)
    setVisible(false)
  }

  if (!visible) {
    return null
  }

  return (
    <div
      role="dialog"
      aria-live="polite"
      aria-label="Cookie preferences"
      style={{
        position: 'fixed',
        bottom: '1rem',
        left: '50%',
        transform: 'translateX(-50%)',
        background: '#FFFFFF',
        color: '#0F172A',
        padding: '1.5rem',
        borderRadius: '16px',
        boxShadow: '0 24px 48px rgba(15, 23, 42, 0.2)',
        width: 'min(90%, 520px)',
        zIndex: 50
      }}
    >
      <h4 style={{ marginBottom: '0.75rem' }}>Cookie preferences</h4>
      <p style={{ marginBottom: '1rem' }}>
        We use essential cookies to operate our platform and optional analytics to improve your experience. Selecciona tu preferencia para continuar.
      </p>
      <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
        <button className="primary-button" onClick={() => handleConsent('accepted')}>
          Accept analytics
        </button>
        <button className="secondary-button" onClick={() => handleConsent('declined')}>
          Decline optional cookies
        </button>
      </div>
    </div>
  )
}

export default CookieBanner
```