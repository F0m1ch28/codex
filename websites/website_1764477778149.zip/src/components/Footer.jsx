```javascript
import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer style={{ background: '#0F172A', color: '#E2E8F0', padding: '3rem 0' }}>
      <div className="container">
        <div className="grid grid-3" style={{ gap: '2rem' }}>
          <div>
            <h3 style={{ color: '#FFFFFF' }}>Tu Progreso Hoy</h3>
            <p>Datos verificados para planificar tu presupuesto.</p>
            <p>Plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
            <p style={{ fontSize: '0.9rem', opacity: 0.75 }}>
              Análisis transparentes y datos de mercado para decidir con seguridad.
            </p>
          </div>
          <div>
            <h4 style={{ color: '#FFFFFF' }}>Explore</h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'grid', gap: '0.5rem' }}>
              <li><Link to="/" style={{ color: '#E2E8F0' }}>Home</Link></li>
              <li><Link to="/inflation" style={{ color: '#E2E8F0' }}>Inflation</Link></li>
              <li><Link to="/course" style={{ color: '#E2E8F0' }}>Course</Link></li>
              <li><Link to="/resources" style={{ color: '#E2E8F0' }}>Resources</Link></li>
              <li><Link to="/contact" style={{ color: '#E2E8F0' }}>Contact</Link></li>
            </ul>
          </div>
          <div>
            <h4 style={{ color: '#FFFFFF' }}>Contact</h4>
            <p>Av. 9 de Julio 1000<br />C1043 Buenos Aires, Argentina</p>
            <p>Phone: <a href="tel:+541155551234" style={{ color: '#E2E8F0' }}>+54 11 5555-1234</a></p>
            <p>Email: <a href="mailto:hola@tuprogresohoy.ar" style={{ color: '#E2E8F0' }}>hola@tuprogresohoy.ar</a></p>
            <div style={{ display: 'flex', gap: '0.75rem', marginTop: '0.75rem' }}>
              <a href="https://www.linkedin.com" aria-label="LinkedIn" style={{ color: '#E2E8F0' }}>LinkedIn</a>
              <a href="https://www.instagram.com" aria-label="Instagram" style={{ color: '#E2E8F0' }}>Instagram</a>
              <a href="https://www.twitter.com" aria-label="Twitter" style={{ color: '#E2E8F0' }}>Twitter</a>
            </div>
          </div>
        </div>

        <hr style={{ border: 'none', borderTop: '1px solid rgba(226, 232, 240, 0.1)', margin: '2rem 0' }} />

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', justifyContent: 'space-between', fontSize: '0.85rem' }}>
          <div style={{ display: 'flex', gap: '1rem' }}>
            <Link to="/privacy" style={{ color: '#E2E8F0' }}>Privacy</Link>
            <Link to="/cookies" style={{ color: '#E2E8F0' }}>Cookies</Link>
            <Link to="/terms" style={{ color: '#E2E8F0' }}>Terms</Link>
          </div>
          <div>
            © {new Date().getFullYear()} Tu Progreso Hoy. De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
```