```javascript
import React, { useEffect, useState } from 'react'

const DisclaimerPopup = () => {
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const dismissed = localStorage.getItem('tph-disclaimer-dismissed')
    if (!dismissed) {
      const timer = setTimeout(() => {
        setOpen(true)
      }, 1500)
      return () => clearTimeout(timer)
    }
  }, [])

  const handleClose = () => {
    localStorage.setItem('tph-disclaimer-dismissed', 'true')
    setOpen(false)
  }

  if (!open) return null

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="financial-disclaimer-title"
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(15, 23, 42, 0.45)',
        display: 'grid',
        placeItems: 'center',
        zIndex: 100
      }}
    >
      <div className="card" style={{ width: 'min(90%, 420px)', textAlign: 'center' }}>
        <h3 id="financial-disclaimer-title">Disclaimer</h3>
        <p style={{ marginBottom: '0.75rem' }}>Мы не предоставляем финансовые услуги.</p>
        <p style={{ marginBottom: '1.5rem' }}>We do not provide financial services.</p>
        <button className="primary-button" onClick={handleClose}>
          Understood
        </button>
      </div>
    </div>
  )
}

export default DisclaimerPopup
```