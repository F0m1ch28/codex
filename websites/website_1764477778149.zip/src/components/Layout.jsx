```javascript
import React, { useEffect } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import Header from './Header'
import Footer from './Footer'
import CookieBanner from './CookieBanner'
import DisclaimerPopup from './DisclaimerPopup'

const Layout = () => {
  const location = useLocation()

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [location.pathname])

  useEffect(() => {
    const head = document.head
    const existingEn = head.querySelector('link[rel="alternate"][hreflang="en"]')
    const existingEs = head.querySelector('link[rel="alternate"][hreflang="es-AR"]')
    const baseUrl = window.location.origin
    const path = location.pathname === '/sitemap.xml' ? '/' : location.pathname

    if (!existingEn) {
      const linkEn = document.createElement('link')
      linkEn.setAttribute('rel', 'alternate')
      linkEn.setAttribute('hreflang', 'en')
      linkEn.href = `${baseUrl}${path}`
      head.appendChild(linkEn)
    } else {
      existingEn.href = `${baseUrl}${path}`
    }

    if (!existingEs) {
      const linkEs = document.createElement('link')
      linkEs.setAttribute('rel', 'alternate')
      linkEs.setAttribute('hreflang', 'es-AR')
      linkEs.href = `${baseUrl}${path}`
      head.appendChild(linkEs)
    } else {
      existingEs.href = `${baseUrl}${path}`
    }

    document.documentElement.setAttribute('lang', 'en')
  }, [location.pathname])

  return (
    <>
      <a className="skip-link" href="#main-content">
        Skip to main content
      </a>
      <Header />
      <main id="main-content">
        <Outlet />
      </main>
      <Footer />
      <CookieBanner />
      <DisclaimerPopup />
    </>
  )
}

export default Layout
```