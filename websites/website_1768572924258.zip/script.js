document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navLinks.classList.toggle('is-open');
            document.body.classList.toggle('nav-open', !expanded);
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
                document.body.classList.remove('nav-open');
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 1024) {
                navLinks.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
                document.body.classList.remove('nav-open');
            }
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const storedConsent = localStorage.getItem('unstucrpyh_cookie_consent');

    if (cookieBanner && !storedConsent) {
        requestAnimationFrame(() => {
            cookieBanner.classList.add('is-visible');
        });
    }

    if (cookieBanner) {
        cookieBanner.querySelectorAll('[data-cookie-action]').forEach(button => {
            button.addEventListener('click', () => {
                const action = button.dataset.cookieAction;
                localStorage.setItem('unstucrpyh_cookie_consent', action);
                cookieBanner.classList.remove('is-visible');
            });
        });
    }
});