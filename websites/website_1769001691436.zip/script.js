function setupNavigation() {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-navigation');

  if (!navToggle || !nav) {
    return;
  }

  navToggle.addEventListener('click', () => {
    const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', (!isExpanded).toString());
    nav.classList.toggle('is-open');
    document.body.classList.toggle('nav-open', !isExpanded);
  });

  window.addEventListener('resize', () => {
    if (window.innerWidth >= 1024) {
      nav.classList.remove('is-open');
      navToggle.setAttribute('aria-expanded', 'false');
      document.body.classList.remove('nav-open');
    }
  });
}

function setupCookieBanner() {
  const banner = document.getElementById('cookieBanner');
  const acceptButton = document.getElementById('cookieAccept');
  const rejectButton = document.getElementById('cookieReject');

  if (!banner) {
    return;
  }

  const storedPreference = localStorage.getItem('mpxsCookiePreference');
  if (storedPreference) {
    banner.classList.add('is-hidden');
    banner.setAttribute('aria-hidden', 'true');
    return;
  }

  const registerChoice = (choice) => {
    const payload = {
      value: choice,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('mpxsCookiePreference', JSON.stringify(payload));
    banner.classList.add('is-hidden');
    banner.setAttribute('aria-hidden', 'true');
  };

  if (acceptButton) {
    acceptButton.addEventListener('click', () => registerChoice('accepted'));
  }

  if (rejectButton) {
    rejectButton.addEventListener('click', () => registerChoice('rejected'));
  }
}

document.addEventListener('DOMContentLoaded', () => {
  setupNavigation();
  setupCookieBanner();
});