document.addEventListener('DOMContentLoaded', () => {
  const variantButtons = document.querySelectorAll('[data-variant]');
  const variantTitle = document.querySelector('[data-variant-title]');
  const variantTagline = document.querySelector('[data-variant-tagline]');
  const variantDescription = document.querySelector('[data-variant-description]');
  const variantBenefits = document.querySelector('[data-variant-benefits]');
  const variantTime = document.querySelector('[data-variant-time]');
  const variantInvestment = document.querySelector('[data-variant-investment]');
  const variantConfidence = document.querySelector('[data-variant-confidence]');
  const variantBadge = document.querySelector('[data-variant-badge]');
  const variantCTA = document.querySelector('[data-variant-cta]');
  const variantSummary = document.querySelector('[data-variant-summary]');
  const variantImage = document.querySelector('[data-variant-image]');

  const variantData = {
    '1': {
      badge: 'Фокусированный подход',
      title: 'Один точный вариант',
      tagline: 'Идеален, когда стратегия ясна и важна скорость запуска.',
      description: 'Мы проводим интервью с командой, уточняем гипотезу и воплощаем один выверенный концепт. Такой формат ускоряет запуск и помогает сконцентрироваться на ключевом сообщении бренда.',
      benefits: [
        'Глубокий брифинг и штурм, чтобы не тратить ресурсы на лишнее.',
        'Единая визуальная линия без размытия бренда.',
        'Самый быстрый путь к согласованию и передаче в разработку.'
      ],
      metrics: {
        time: '5–7 рабочих дней',
        investment: 'от 45 000 ₽',
        confidence: 'Чёткая стратегия и скорость'
      },
      cta: 'Заказать один вариант',
      summary: 'Рекомендуем, если вам нужен быстрый и чёткий старт без альтернатив.'
    },
    '2': {
      badge: 'Золотая середина',
      title: 'Два варианта для уверенного выбора',
      tagline: 'Классический выбор, когда важно сопоставить решения и увидеть нюансы.',
      description: 'Создаём две концепции, опираясь на аналитику и ценности бренда. Один вариант раскрывает смелую идею, второй — надёжную и проверенную. Вы сравниваете, комбинируете и утверждаете лучшее.',
      benefits: [
        'Баланс между глубиной исследования и скоростью.',
        'Возможность сравнить разные визуальные акценты и структуру блоков.',
        'Уверенность, что итоговое решение обосновано.'
      ],
      metrics: {
        time: '7–10 рабочих дней',
        investment: 'от 68 000 ₽',
        confidence: 'Выбор из двух сильных концепций'
      },
      cta: 'Получить два варианта',
      summary: 'Рекомендуем, если хотите сопоставить подходы и выбрать оптимальную стратегию.'
    },
    '3': {
      badge: 'Максимум возможностей',
      title: 'Три варианта + аналитика',
      tagline: 'Для проектов, где критично исследование аудитории и тестирование гипотез.',
      description: 'Проводим экспресс-исследование, определяем пользовательские сценарии и создаём три концепции: продуктовую, эмоциональную и экспериметальную. Вы видите весь спектр решений и выбираете, что резонирует с бизнесом.',
      benefits: [
        'Подробные раскадровки и логика пользовательских путей.',
        'Поддержка при комбинировании идей из разных концептов.',
        'Подготовка материалов для юзабилити-тестов и презентаций.'
      ],
      metrics: {
        time: '10–14 рабочих дней',
        investment: 'от 96 000 ₽',
        confidence: 'Глубокое сравнение и тестирование'
      },
      cta: 'Инвестировать в три варианта',
      summary: 'Рекомендуем, если решение влияет на ключевые метрики и нужна проверка гипотез.'
    }
  };

  function updateVariant(variantKey) {
    if (!variantData[variantKey]) return;
    const data = variantData[variantKey];

    variantButtons.forEach(button => {
      const isActive = button.dataset.variant === variantKey;
      button.classList.toggle('active', isActive);
      button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
    });

    if (variantBadge) variantBadge.textContent = data.badge;
    if (variantTitle) variantTitle.textContent = data.title;
    if (variantTagline) variantTagline.textContent = data.tagline;
    if (variantDescription) variantDescription.textContent = data.description;
    if (variantSummary) variantSummary.textContent = data.summary;
    if (variantBenefits) {
      variantBenefits.innerHTML = '';
      data.benefits.forEach(item => {
        const li = document.createElement('li');
        li.textContent = item;
        variantBenefits.appendChild(li);
      });
    }
    if (variantTime) variantTime.textContent = data.metrics.time;
    if (variantInvestment) variantInvestment.textContent = data.metrics.investment;
    if (variantConfidence) variantConfidence.textContent = data.metrics.confidence;
    if (variantCTA) variantCTA.textContent = data.cta;
    if (variantImage) {
      const variantImages = {
        '1': 'https://picsum.photos/720/520?random=design-focus',
        '2': 'https://picsum.photos/720/520?random=design-choice',
        '3': 'https://picsum.photos/720/520?random=design-lab'
      };
      variantImage.src = variantImages[variantKey];
      variantImage.alt = `${data.title} — визуализация`;
    }
  }

  if (variantButtons.length) {
    variantButtons.forEach(button => {
      button.addEventListener('click', () => updateVariant(button.dataset.variant));
    });
    updateVariant('2');
  }

  const compareButtons = document.querySelectorAll('[data-compare]');
  const compareTitle = document.querySelector('[data-compare-title]');
  const compareText = document.querySelector('[data-compare-text]');
  const comparePoints = document.querySelector('[data-compare-points]');
  const compareImage = document.querySelector('[data-compare-image]');

  const comparisonData = {
    'variant-1': {
      title: 'Вариант 1 — Чистый минимализм',
      text: 'Структура с акцентом на лаконичность и чёткую типографику. Подходит для b2b-решений и технологичных продуктов.',
      points: [
        'Геометрическая сетка, строгая иерархия блоков.',
        'Упор на статистику и факты — идеален для отчётных презентаций.',
        'Контрастный CTA, который ведёт к ключевому действию.'
      ],
      image: 'https://picsum.photos/960/540?random=portfolio-minimal'
    },
    'variant-2': {
      title: 'Вариант 2 — Эмоциональная визуализация',
      text: 'Больше иллюстраций, динамика и мягкие формы. Срабатывает, когда важно вовлечь пользователя и рассказать историю.',
      points: [
        'Сочетание фотографий и иллюстраций усиливает эмоцию.',
        'Плавные переходы и интерактивные элементы.',
        'Цветовые акценты поддерживают миссию бренда.'
      ],
      image: 'https://picsum.photos/960/540?random=portfolio-emotion'
    },
    'variant-3': {
      title: 'Вариант 3 — Продуктовый фокус',
      text: 'Концентрация на функциональности, демонстрация интерфейса, сравнение пакетов. Подходит для SaaS и цифровых продуктов.',
      points: [
        'Интерактивные карточки тарифов и FAQ блоки.',
        'Таблицы сравнений и интеграции подчёркивают ценность.',
        'Зонирование для быстрой ориентации пользователя.'
      ],
      image: 'https://picsum.photos/960/540?random=portfolio-product'
    }
  };

  function updateComparison(key) {
    const data = comparisonData[key];
    if (!data) return;
    compareButtons.forEach(button => {
      const isCurrent = button.dataset.compare === key;
      button.setAttribute('aria-pressed', isCurrent ? 'true' : 'false');
    });
    if (compareTitle) compareTitle.textContent = data.title;
    if (compareText) compareText.textContent = data.text;
    if (comparePoints) {
      comparePoints.innerHTML = '';
      data.points.forEach(point => {
        const li = document.createElement('li');
        li.textContent = point;
        comparePoints.appendChild(li);
      });
    }
    if (compareImage) {
      compareImage.src = data.image;
      compareImage.alt = `${data.title} — пример`;
    }
  }

  if (compareButtons.length) {
    compareButtons.forEach(button => {
      button.addEventListener('click', () => updateComparison(button.dataset.compare));
    });
    updateComparison('variant-2');
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    let storageEnabled = true;
    try {
      localStorage.getItem('cookieConsent');
    } catch (error) {
      storageEnabled = false;
    }

    let consent = null;
    if (storageEnabled) {
      consent = localStorage.getItem('cookieConsent');
    }

    if (!consent) {
      requestAnimationFrame(() => cookieBanner.classList.add('show'));
    }

    const acceptButton = cookieBanner.querySelector('[data-accept]');
    const declineButton = cookieBanner.querySelector('[data-decline]');

    const closeBanner = (value) => {
      if (storageEnabled) {
        localStorage.setItem('cookieConsent', value);
      }
      cookieBanner.classList.remove('show');
      setTimeout(() => {
        cookieBanner.remove();
      }, 320);
    };

    if (acceptButton) {
      acceptButton.addEventListener('click', () => closeBanner('accepted'));
    }

    if (declineButton) {
      declineButton.addEventListener('click', () => closeBanner('declined'));
    }
  }
});