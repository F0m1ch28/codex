document.addEventListener('DOMContentLoaded', () => {
  const navLinks = document.querySelector('.nav-links');
  const mobileToggle = document.querySelector('.mobile-toggle');

  if (mobileToggle && navLinks) {
    mobileToggle.addEventListener('click', () => {
      const expanded = mobileToggle.getAttribute('aria-expanded') === 'true';
      mobileToggle.setAttribute('aria-expanded', (!expanded).toString());
      navLinks.classList.toggle('open');
    });

    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('open');
        mobileToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const currentYearElements = document.querySelectorAll('.current-year');
  const year = new Date().getFullYear();
  currentYearElements.forEach(el => el.textContent = year.toString());

  const animateElements = document.querySelectorAll('.animate-on-scroll');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    animateElements.forEach(el => observer.observe(el));
  } else {
    animateElements.forEach(el => el.classList.add('is-visible'));
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('.cookie-accept');
  const declineBtn = document.querySelector('.cookie-decline');
  const cookieKey = 'rbph_cookie_choice';

  const setCookieChoice = choice => {
    localStorage.setItem(cookieKey, choice);
    if (cookieBanner) {
      cookieBanner.classList.add('hidden');
    }
  };

  const storedChoice = localStorage.getItem(cookieKey);
  if (storedChoice) {
    cookieBanner?.classList.add('hidden');
  }

  acceptBtn?.addEventListener('click', () => setCookieChoice('accepted'));
  declineBtn?.addEventListener('click', () => setCookieChoice('declined'));

  const toast = document.createElement('div');
  toast.className = 'form-toast';
  toast.setAttribute('role', 'status');
  toast.textContent = 'Zpráva byla úspěšně zaznamenána. Přesměrováváme...';
  document.body.appendChild(toast);

  const forms = document.querySelectorAll('form');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      toast.classList.add('visible');
      setTimeout(() => {
        toast.classList.remove('visible');
        window.location.href = form.getAttribute('action') || 'thank-you.html';
      }, 1800);
    });
  });
});