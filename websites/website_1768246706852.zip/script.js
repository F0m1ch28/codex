document.addEventListener("DOMContentLoaded", function () {
    const banner = document.querySelector(".cookie-banner");
    if (!banner) {
        return;
    }
    const storedChoice = localStorage.getItem("gc-cookie-choice");
    if (storedChoice) {
        banner.classList.add("hidden");
        return;
    }
    const buttons = banner.querySelectorAll("[data-cookie-action]");
    buttons.forEach(function (button) {
        button.addEventListener("click", function (event) {
            event.preventDefault();
            const choice = button.getAttribute("data-cookie-action");
            localStorage.setItem("gc-cookie-choice", choice);
            banner.classList.add("hidden");
            window.open("cookies.html", "_blank");
        });
    });
});