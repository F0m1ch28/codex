document.addEventListener("DOMContentLoaded", function () {
    var banner = document.querySelector(".cookie-banner");
    if (!banner) {
        return;
    }

    var storedPreference = localStorage.getItem("cerebentzj_cookie_preference");
    if (storedPreference) {
        banner.classList.add("is-hidden");
        return;
    }

    banner.addEventListener("click", function (event) {
        var target = event.target;
        if (!target.hasAttribute("data-cookie-choice")) {
            return;
        }
        var choice = target.getAttribute("data-cookie-choice");
        if (choice === "accept") {
            localStorage.setItem("cerebentzj_cookie_preference", "accepted");
        } else {
            localStorage.setItem("cerebentzj_cookie_preference", "declined");
        }
        banner.classList.add("is-hidden");
    });
});