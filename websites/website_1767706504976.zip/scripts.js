document.addEventListener('DOMContentLoaded', function () {
    var banner = document.getElementById('cookieBanner');
    if (!banner) return;

    var accept = document.getElementById('cookieAccept');
    var decline = document.getElementById('cookieDecline');
    var storedPreference = localStorage.getItem('largeotlboCookiePreference');

    if (storedPreference) {
        banner.classList.add('is-hidden');
    }

    if (accept) {
        accept.addEventListener('click', function () {
            localStorage.setItem('largeotlboCookiePreference', 'accepted');
            banner.classList.add('is-hidden');
        });
    }

    if (decline) {
        decline.addEventListener('click', function () {
            localStorage.setItem('largeotlboCookiePreference', 'declined');
            banner.classList.add('is-hidden');
        });
    }

    var yearElements = document.querySelectorAll('#currentYear');
    if (yearElements.length) {
        var currentYear = new Date().getFullYear();
        yearElements.forEach(function (el) {
            el.textContent = currentYear;
        });
    }
});