document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav-list');
    if (navToggle && navList) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navList.classList.toggle('open');
        });
        navList.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('active');
                navList.classList.remove('open');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-accept');
    const declineBtn = document.querySelector('.cookie-decline');
    const preferenceLink = document.querySelector('.cookie-preferences');
    const consentKey = 'toyterbqroCookieConsent';

    const setConsent = (value) => {
        localStorage.setItem(consentKey, value);
        if (cookieBanner) {
            cookieBanner.classList.remove('visible');
        }
    };

    if (cookieBanner) {
        const existingConsent = localStorage.getItem(consentKey);
        if (!existingConsent) {
            setTimeout(() => {
                cookieBanner.classList.add('visible');
            }, 600);
        }

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => setConsent('accepted'));
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', () => setConsent('declined'));
        }
        if (preferenceLink) {
            preferenceLink.addEventListener('click', () => setConsent('preferences'));
        }
    }
});