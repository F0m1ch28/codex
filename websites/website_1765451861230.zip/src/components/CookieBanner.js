import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('zla-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('zla-cookie-consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <p className={styles.message}>
        We use functional cookies to ensure the best learning experience on our website. By continuing, you agree to our <a href="/cookie-policy">Cookie Policy</a>.
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;