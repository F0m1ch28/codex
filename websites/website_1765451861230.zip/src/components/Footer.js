import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className="container">
      <div className={styles.grid}>
        <div className={styles.column}>
          <h3 className={styles.heading}>Zagreb Language Academy</h3>
          <p className={styles.text}>
            Empowering Croatia’s learners with immersive language training tailored to modern careers and global lifestyles.
          </p>
          <p className={styles.contactItem}>
            <strong>Address:</strong> Language Street 15, 10000 Zagreb, Croatia
          </p>
          <p className={styles.contactItem}>
            <strong>Phone:</strong> <a href="tel:+38514567890">+385 1 4567 890</a>
          </p>
          <p className={styles.contactItem}>
            <strong>Email:</strong> <a href="mailto:info@zagreblanguageacademy.com">info@zagreblanguageacademy.com</a>
          </p>
        </div>
        <div className={styles.column}>
          <h4 className={styles.subheading}>Explore</h4>
          <ul className={styles.linkList}>
            <li><Link to="/courses">Courses</Link></li>
            <li><Link to="/about">About Us</Link></li>
            <li><Link to="/contact">Contact</Link></li>
            <li><Link to="/privacy">Privacy Policy</Link></li>
            <li><Link to="/terms">Terms of Service</Link></li>
            <li><Link to="/cookie-policy">Cookie Policy</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4 className={styles.subheading}>Follow &amp; Visit</h4>
          <p className={styles.text}>Stay updated on language learning trends, events in Zagreb, Split, and Dubrovnik, and new course announcements.</p>
          <div className={styles.socials} aria-label="Social media links">
            <a href="https://www.facebook.com" aria-label="Facebook link">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M13.5 21v-7.2h2.4l.36-2.8h-2.76V8.8c0-.8.24-1.36 1.44-1.36h1.44V4.04C15.9 4 15.06 4 14.1 4c-2.22 0-3.72 1.32-3.72 3.72v2.24H8v2.8h2.38V21h3.12z" fill="currentColor"/></svg>
            </a>
            <a href="https://www.instagram.com" aria-label="Instagram link">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5zm0 2a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H7zm5 3.5A4.5 4.5 0 1 1 7.5 12 4.51 4.51 0 0 1 12 7.5zm0 2A2.5 2.5 0 1 0 14.5 12 2.51 2.51 0 0 0 12 9.5zm6.25-3.75a1.25 1.25 0 1 1-1.25 1.25 1.25 1.25 0 0 1 1.25-1.25z" fill="currentColor"/></svg>
            </a>
            <a href="https://www.linkedin.com" aria-label="LinkedIn link">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.98 3.5a2 2 0 1 1-.02 4 2 2 0 0 1 .02-4zM3 8.75h3.96V21H3zM9.5 8.75H13v1.68h.05c.49-.93 1.7-1.9 3.49-1.9C20.1 8.53 21 10.38 21 13.31V21h-3.96v-6.7c0-1.6-.03-3.66-2.23-3.66-2.23 0-2.57 1.74-2.57 3.54V21H9.5z" fill="currentColor"/></svg>
            </a>
          </div>
          <p className={styles.hours}><strong>Business Hours:</strong> Mon-Fri 9:00-18:00, Sat 9:00-14:00</p>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>&copy; {new Date().getFullYear()} Zagreb Language Academy. All rights reserved.</p>
      </div>
    </div>
  </footer>
);

export default Footer;