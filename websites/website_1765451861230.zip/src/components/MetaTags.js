import { useEffect } from 'react';

const ensureMetaTag = (attrName, attrValue, content) => {
  if (!attrName || !content) return;
  let element = document.querySelector(`meta[${attrName}="${attrValue}"]`);
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute(attrName, attrValue);
    document.head.appendChild(element);
  }
  element.setAttribute('content', content);
};

const ensureLinkTag = (rel, href) => {
  if (!href) return;
  let element = document.querySelector(`link[rel="${rel}"]`);
  if (!element) {
    element = document.createElement('link');
    element.setAttribute('rel', rel);
    document.head.appendChild(element);
  }
  element.setAttribute('href', href);
};

const MetaTags = ({
  title,
  description,
  canonical,
  image,
  keywords,
  type = 'website'
}) => {
  const helmetAsync = typeof window !== 'undefined' ? window.helmetAsync : undefined;
  const Helmet = helmetAsync ? helmetAsync.Helmet : undefined;

  useEffect(() => {
    if (title) {
      document.title = title;
    }
    if (description) {
      ensureMetaTag('name', 'description', description);
    }
    if (keywords) {
      ensureMetaTag('name', 'keywords', keywords);
    }
    if (image) {
      ensureMetaTag('property', 'og:image', image);
      ensureMetaTag('name', 'twitter:image', image);
    }
    if (title) {
      ensureMetaTag('property', 'og:title', title);
      ensureMetaTag('name', 'twitter:title', title);
    }
    if (description) {
      ensureMetaTag('property', 'og:description', description);
      ensureMetaTag('name', 'twitter:description', description);
    }
    ensureMetaTag('property', 'og:type', type);
    if (canonical) {
      ensureMetaTag('property', 'og:url', canonical);
      ensureLinkTag('canonical', canonical);
    }
  }, [title, description, canonical, image, keywords, type]);

  if (!Helmet) return null;

  return (
    <Helmet>
      {title && <title>{title}</title>}
      {description && <meta name="description" content={description} />}
      {keywords && <meta name="keywords" content={keywords} />}
      {canonical && <link rel="canonical" href={canonical} />}
      {canonical && <meta property="og:url" content={canonical} />}
      {image && <meta property="og:image" content={image} />}
      {image && <meta name="twitter:image" content={image} />}
      {title && <meta property="og:title" content={title} />}
      {description && <meta property="og:description" content={description} />}
      <meta property="og:type" content={type} />
      <meta property="og:locale" content="en_US" />
      <meta name="twitter:card" content="summary_large_image" />
    </Helmet>
  );
};

export default MetaTags;