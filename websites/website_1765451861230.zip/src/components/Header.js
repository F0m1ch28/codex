import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const closeMenu = () => setIsMenuOpen(false);
    closeMenu();
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`}>
      <div className="container">
        <div className={styles.inner}>
          <Link to="/" className={styles.logo} aria-label="Zagreb Language Academy Home">
            Zagreb Language Academy
          </Link>
          <nav className={`${styles.nav} ${isMenuOpen ? styles.open : ''}`} aria-label="Main Navigation">
            <NavLink to="/" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} end>
              Home
            </NavLink>
            <NavLink to="/courses" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}>
              Courses
            </NavLink>
            <NavLink to="/about" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}>
              About
            </NavLink>
            <NavLink to="/contact" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}>
              Contact
            </NavLink>
            <Link to="/contact" className={styles.ctaLink}>
              Enquire Now
            </Link>
          </nav>
          <button
            type="button"
            className={styles.burger}
            aria-label="Toggle navigation menu"
            aria-expanded={isMenuOpen}
            onClick={() => setIsMenuOpen(prev => !prev)}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;