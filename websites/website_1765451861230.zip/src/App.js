import React, { Suspense, lazy } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';
import styles from './App.module.css';

const Home = lazy(() => import('./pages/Home'));
const Courses = lazy(() => import('./pages/Courses'));
const About = lazy(() => import('./pages/About'));
const Contact = lazy(() => import('./pages/Contact'));
const Terms = lazy(() => import('./pages/Terms'));
const Privacy = lazy(() => import('./pages/Privacy'));
const CookiePolicy = lazy(() => import('./pages/CookiePolicy'));
const Services = lazy(() => import('./pages/Services'));

const ScrollToTopOnRoute = () => {
  const { pathname } = useLocation();
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);
  return null;
};

const App = () => (
  <div className={styles.app}>
    <Header />
    <main className={styles.main}>
      <Suspense fallback={<div className={styles.loading} role="status" aria-live="polite">Loading page...</div>}>
        <ScrollToTopOnRoute />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route
            path="/courses"
            element={
              <Courses
                pageTitle="Language Courses in Croatia | Zagreb Language Academy"
                canonicalPath="/courses"
                description="Explore English, German, Italian, Croatian, and summer intensive language courses tailored for learners across Croatia."
              />
            }
          />
          <Route
            path="/services"
            element={
              <Services />
            }
          />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Suspense>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTopButton />
  </div>
);

export default App;