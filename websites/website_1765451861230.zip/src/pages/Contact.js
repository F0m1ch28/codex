import React, { useState } from 'react';
import MetaTags from '../components/MetaTags';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  message: '',
  interest: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ submitting: false, success: false });

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your full name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!formData.interest) newErrors.interest = 'Let us know which course area interests you.';
    if (!formData.message.trim()) newErrors.message = 'Please include a short message or goal.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setStatus({ submitting: true, success: false });
      setTimeout(() => {
        setStatus({ submitting: false, success: true });
        setFormData(initialFormState);
      }, 1200);
    }
  };

  return (
    <>
      <MetaTags
        title="Contact Zagreb Language Academy | Enquire About Courses"
        description="Reach out to Zagreb Language Academy for language course enquiries, consultation bookings, and partnership opportunities."
        canonical="https://www.zagreblanguageacademy.com/contact"
        image="https://picsum.photos/1200/630?random=142"
        keywords="Contact language school Croatia, enquire language courses, Zagreb Language Academy contact"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Contact Us</h1>
          <p>
            Our advisors are ready to help you design the perfect language journey. Visit us in Zagreb or schedule a consultation online—whatever suits your schedule.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Send us a message</h2>
              <div className={styles.field}>
                <label htmlFor="name">Full name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={event => setFormData(prev => ({ ...prev, name: event.target.value }))}
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                />
                {errors.name && <span id="name-error" className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Email address</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={event => setFormData(prev => ({ ...prev, email: event.target.value }))}
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                />
                {errors.email && <span id="email-error" className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="interest">Course interest</label>
                <select
                  id="interest"
                  name="interest"
                  value={formData.interest}
                  onChange={event => setFormData(prev => ({ ...prev, interest: event.target.value }))}
                  aria-invalid={Boolean(errors.interest)}
                  aria-describedby={errors.interest ? 'interest-error' : undefined}
                >
                  <option value="">Select an option</option>
                  <option value="general-english">General English</option>
                  <option value="business-english">Business English</option>
                  <option value="german">German Programmes</option>
                  <option value="italian">Italian Courses</option>
                  <option value="croatian">Croatian for Foreigners</option>
                  <option value="summer">Summer Intensive Programmes</option>
                  <option value="corporate">Corporate Training Partnership</option>
                </select>
                {errors.interest && <span id="interest-error" className={styles.error}>{errors.interest}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Message</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={event => setFormData(prev => ({ ...prev, message: event.target.value }))}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                />
                {errors.message && <span id="message-error" className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className={styles.submit} disabled={status.submitting}>
                {status.submitting ? 'Sending...' : 'Submit enquiry'}
              </button>
              {status.success && (
                <p className={styles.success} role="status">
                  Thank you! Our admissions team will respond within one business day.
                </p>
              )}
            </form>

            <div className={styles.info}>
              <div className={styles.card}>
                <h2>Visit or call us</h2>
                <p><strong>Address:</strong> Language Street 15, 10000 Zagreb, Croatia</p>
                <p><strong>Phone:</strong> <a href="tel:+38514567890">+385 1 4567 890</a></p>
                <p><strong>Email:</strong> <a href="mailto:info@zagreblanguageacademy.com">info@zagreblanguageacademy.com</a></p>
                <p><strong>Business Hours:</strong> Mon-Fri 9:00-18:00, Sat 9:00-14:00</p>
              </div>
              <div className={styles.map} role="img" aria-label="Map placeholder showing Zagreb Language Academy location">
                Map preview coming soon
              </div>
              <div className={styles.card}>
                <h2>Connect beyond Zagreb</h2>
                <p>We also run satellite programmes in Split and Dubrovnik, and provide virtual sessions for learners across Croatia.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;