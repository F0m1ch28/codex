import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Ivana Petrović',
    role: 'Academic Director',
    bio: 'Cambridge-certified trainer with 15 years of experience designing corporate English programmes for leading Croatian brands.',
    image: 'https://picsum.photos/400/400?random=121'
  },
  {
    name: 'Markus Steiner',
    role: 'Head of German Programmes',
    bio: 'Native German linguist specialising in technical and engineering language for automotive and manufacturing sectors.',
    image: 'https://picsum.photos/400/400?random=122'
  },
  {
    name: 'Giulia Verdi',
    role: 'Italian Cultural Facilitator',
    bio: 'Italian educator blending language coaching with gastronomy and tourism experiences along the Dalmatian coast.',
    image: 'https://picsum.photos/400/400?random=123'
  },
  {
    name: 'Ana-Maria Jurić',
    role: 'Croatian for Foreigners Lead',
    bio: 'Helps expatriates thrive in Croatia through practical immersion and mentorship programmes in Zagreb and Split.',
    image: 'https://picsum.photos/400/400?random=124'
  }
];

const About = () => (
  <>
    <MetaTags
      title="About Zagreb Language Academy | Our Story & Mission"
      description="Learn about Zagreb Language Academy’s mission, expert teaching team, facilities, and accreditations supporting language learners across Croatia."
      canonical="https://www.zagreblanguageacademy.com/about"
      image="https://picsum.photos/1200/630?random=125"
      keywords="About language school Croatia, language academy team, language teaching mission"
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>Our Story &amp; Mission</h1>
        <p>
          Zagreb Language Academy was established to empower Croatia’s learners with contemporary language education anchored in cultural understanding and professional application. Our team unites certified linguists, corporate mentors, and digital learning designers who deliver inspiring experiences online and across our campuses in Zagreb, Split, and Dubrovnik.
        </p>
      </div>
    </section>

    <section className={styles.story}>
      <div className="container">
        <div className={styles.storyGrid}>
          <div>
            <h2>Transforming language learning across Croatia</h2>
            <p>
              We believe language skills unlock economic growth, academic success, and personal fulfilment. From customised corporate academies to specialised exam preparation and relocator support, every programme is rooted in rigorous methodology, measurable outcomes, and a personal connection to Croatian culture.
            </p>
            <p>
              Our mission is to inspire confidence through communication. We serve ambitious students and professionals from Zagreb’s innovation hubs, Split’s tourism ecosystem, Dubrovnik’s cultural sector, and beyond.
            </p>
          </div>
          <div className={styles.missionCard}>
            <h3>Mission in action</h3>
            <ul>
              <li>Design learner-centric pathways that respect personal goals and schedules.</li>
              <li>Integrate authentic Croatian cultural experiences to enrich language retention.</li>
              <li>Leverage technology for collaborative, data-informed learning journeys.</li>
              <li>Provide ongoing mentorship and feedback that accelerates real-world application.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Qualified Teachers &amp; Coaches</h2>
          <p>Our educators hold international certifications, industry expertise, and a passion for empowering learners.</p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map(member => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
              <div className={styles.teamContent}>
                <h3>{member.name}</h3>
                <p className={styles.role}>{member.role}</p>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.facilities}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Modern Facilities &amp; Learning Spaces</h2>
          <p>Inspiring classrooms, collaboration labs, and digital studios empower immersive, future-ready learning.</p>
        </div>
        <div className={styles.facilitiesGrid}>
          <article className={styles.facilityCard}>
            <img src="https://picsum.photos/800/600?random=131" alt="Zagreb campus collaboration space" loading="lazy" />
            <div>
              <h3>Zagreb Flagship Campus</h3>
              <p>Light-filled classrooms, innovation labs, and a learner lounge in the heart of Zagreb’s business district.</p>
            </div>
          </article>
          <article className={styles.facilityCard}>
            <img src="https://picsum.photos/800/600?random=132" alt="Split coastal learning studio" loading="lazy" />
            <div>
              <h3>Split Coastal Studio</h3>
              <p>Steps away from the Riva, this studio blends intensive workshops with Mediterranean cultural immersion.</p>
            </div>
          </article>
          <article className={styles.facilityCard}>
            <img src="https://picsum.photos/800/600?random=133" alt="Hybrid learning technology setup" loading="lazy" />
            <div>
              <h3>Digital Learning Hub</h3>
              <p>Virtual classrooms, AI-supported pronunciation labs, and analytics dashboards for blended learning.</p>
            </div>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.accreditation}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Accreditation &amp; Certificates</h2>
          <p>We uphold international standards to guarantee quality, recognition, and credibility for every learner.</p>
        </div>
        <div className={styles.accreditationGrid}>
          <div className={styles.accreditationCard}>
            <h3>International Standards</h3>
            <p>Accredited by global language quality frameworks and aligned with CEFR levels to ensure transparent progression.</p>
          </div>
          <div className={styles.accreditationCard}>
            <h3>Corporate Recognition</h3>
            <p>Trusted training partner to Croatian and multinational organisations in technology, finance, healthcare, and tourism.</p>
          </div>
          <div className={styles.accreditationCard}>
            <h3>Exam Partnerships</h3>
            <p>Official preparation centre for IELTS, Cambridge English, Goethe-Institut, TestDaF, and CELI proficiency exams.</p>
          </div>
          <div className={styles.accreditationCard}>
            <h3>Tailored Certificates</h3>
            <p>Graduates receive unique achievement reports highlighting competencies, learning hours, and project outcomes.</p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default About;