import React from 'react';
import Courses from './Courses';

const Services = () => (
  <Courses
    pageTitle="Language Training Services in Croatia | Zagreb Language Academy"
    canonicalPath="/services"
    description="Discover tailored language training services for organisations and individuals across Croatia, including corporate coaching, relocation support, and cultural immersion."
    aliasLabel="Language Training Services"
  />
);

export default Services;