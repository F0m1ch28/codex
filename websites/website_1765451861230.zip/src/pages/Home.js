import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import MetaTags from '../components/MetaTags';
import styles from './Home.module.css';

const statsData = [
  { label: 'Learners across Croatia', target: 1800 },
  { label: 'Corporate partners in Zagreb, Split & Dubrovnik', target: 65 },
  { label: 'Certified language trainers', target: 28 },
  { label: 'Average satisfaction score', target: 98 }
];

const coursesData = [
  { title: 'General English', description: 'Flexible schedules focused on everyday communication and cultural immersion.', color: '#FFD166' },
  { title: 'Business English', description: 'Tailored for professionals working with international teams and clients.', color: '#2C5AA0' },
  { title: 'German for Engineers', description: 'Technical language training for Croatia’s thriving industrial sectors.', color: '#4CAF50' },
  { title: 'Italian for Tourism', description: 'Hospitality-focused courses for Adriatic tourism professionals.', color: '#784CC0' },
  { title: 'Croatian for Foreigners', description: 'Immersive onboarding for expats settling in Zagreb, Split, and beyond.', color: '#FF8C94' }
];

const methodologySteps = [
  { title: 'Discover', detail: 'Personal language assessment and goal-setting session with an academic advisor.' },
  { title: 'Design', detail: 'Customized learning path blending virtual classrooms, workshops, and city immersions.' },
  { title: 'Practice', detail: 'Live simulations, role plays, and conversation labs across real-life scenarios.' },
  { title: 'Progress', detail: 'Continuous feedback, digital progress tracking, and internationally recognized certificates.' }
];

const successStories = [
  { id: 1, category: 'Zagreb', title: 'Medical English for Clinical Teams', summary: 'KBC Zagreb doctors improved bedside communication for international patients.' },
  { id: 2, category: 'Split', title: 'Hospitality German Bootcamp', summary: 'Split-based hotel staff mastered conversational German ahead of summer season.' },
  { id: 3, category: 'Dubrovnik', title: 'Cruise Industry Italian', summary: 'Port guides and concierge teams refined Italian service vocabulary.' },
  { id: 4, category: 'Rijeka', title: 'Maritime English Workshops', summary: 'Mariners improved safety briefings and onboard communication protocols.' }
];

const testimonials = [
  {
    name: 'Luka Horvat',
    role: 'Entrepreneur, Zagreb',
    quote: 'The business English programme aligned with my start-up’s expansion plans. Weekly coaching kept me accountable and confident during investor pitches.',
    image: 'https://picsum.photos/200/200?random=61'
  },
  {
    name: 'Marija Kovačić',
    role: 'Hospitality Manager, Split',
    quote: 'Dynamic German classes with real-life hospitality scripts boosted my team’s guest satisfaction scores ahead of the summer rush.',
    image: 'https://picsum.photos/200/200?random=62'
  },
  {
    name: 'Stefano Bianchi',
    role: 'Tech Relocator, Dubrovnik',
    quote: 'Croatian for Foreigners made integration effortless. Cultural workshops helped me connect with local colleagues instantly.',
    image: 'https://picsum.photos/200/200?random=63'
  },
  {
    name: 'Andreja Perković',
    role: 'University Student, Osijek',
    quote: 'Exam preparation was structured, motivating, and precise. My IELTS score exceeded what I needed for postgraduate studies abroad.',
    image: 'https://picsum.photos/200/200?random=64'
  }
];

const faqItems = [
  {
    question: 'Do you provide placement tests before enrolment?',
    answer: 'Yes. Every learner receives a free online placement test followed by a consultative interview to map goals, schedule, and preferred learning modalities.'
  },
  {
    question: 'Are hybrid or remote classes available?',
    answer: 'Absolutely. Learners can mix in-person classes in Zagreb, Split, or Dubrovnik with virtual collaboration sessions hosted on our digital campus.'
  },
  {
    question: 'Which certifications can I prepare for?',
    answer: 'We support IELTS, TOEFL, Cambridge, TestDaF, Goethe, CELI, and bespoke corporate language assessments tailored to your sector.'
  },
  {
    question: 'Do you organise cultural immersion activities?',
    answer: 'Yes. We coordinate conversation meetups, guided city tours, and professional networking events to embed language learning in authentic contexts.'
  }
];

const blogPosts = [
  {
    title: 'How Croatian Professionals Gain Confidence in English Meetings',
    date: 'January 2024',
    image: 'https://picsum.photos/800/600?random=81',
    excerpt: 'Explore proven strategies used by executives in Zagreb to speak with clarity, negotiate persuasively, and lead global teams.',
    link: '/courses'
  },
  {
    title: 'Summer Intensive Language Retreats on the Dalmatian Coast',
    date: 'December 2023',
    image: 'https://picsum.photos/800/600?random=82',
    excerpt: 'Discover immersive programmes in Split and Dubrovnik where language learning meets Adriatic culture, cuisine, and collaborations.',
    link: '/about'
  },
  {
    title: 'Why German Language Skills Matter for Croatia’s Industry 4.0',
    date: 'November 2023',
    image: 'https://picsum.photos/800/600?random=83',
    excerpt: 'Learn how manufacturing leaders from Rijeka to Varaždin are empowering teams with technical German vocabulary.',
    link: '/courses'
  }
];

const Home = () => {
  const [statValues, setStatValues] = useState(statsData.map(() => 0));
  const [activeStory, setActiveStory] = useState('All');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    let frame;
    const duration = 1600;
    const start = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - start) / duration, 1);
      setStatValues(statsData.map(stat => Math.floor(stat.target * progress)));
      if (progress < 1) {
        frame = requestAnimationFrame(animate);
      } else {
        setStatValues(statsData.map(stat => stat.target));
      }
    };

    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial(prev => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const filteredStories = useMemo(() => {
    if (activeStory === 'All') return successStories;
    return successStories.filter(story => story.category === activeStory);
  }, [activeStory]);

  return (
    <>
      <MetaTags
        title="Zagreb Language Academy | Premier Language School in Croatia"
        description="Master English, German, Italian, and Croatian with expert teachers, modern methodology, and immersive programmes across Zagreb, Split, and Dubrovnik."
        canonical="https://www.zagreblanguageacademy.com/"
        image="https://picsum.photos/1200/630?random=94"
        keywords="Language school Croatia, English courses Zagreb, Business English Split, Croatian for foreigners, German classes Croatia"
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.kicker}>Croatia’s trusted language academy</p>
          <h1>
            Elevate your language confidence with programmes built for life, study, and work across Croatia.
          </h1>
          <p className={styles.heroSubtitle}>
            From agile professionals in Zagreb to hospitality leaders on the Dalmatian coast, we equip you with fluent communication, cultural intelligence, and internationally recognised certification.
          </p>
          <div className={styles.heroActions}>
            <Link to="/courses" className={styles.heroPrimary}>Explore Courses</Link>
            <a href="#contact-section" className={styles.heroSecondary}>Talk to an advisor</a>
          </div>
          <div className={styles.heroStats}>
            <div>
              <span className={styles.statNumber}>{statValues[0]}+</span>
              <span className={styles.statLabel}>{statsData[0].label}</span>
            </div>
            <div>
              <span className={styles.statNumber}>{statValues[1]}+</span>
              <span className={styles.statLabel}>{statsData[1].label}</span>
            </div>
            <div>
              <span className={styles.statNumber}>{statValues[2]}</span>
              <span className={styles.statLabel}>{statsData[2].label}</span>
            </div>
            <div>
              <span className={styles.statNumber}>{statValues[3]}%</span>
              <span className={styles.statLabel}>{statsData[3].label}</span>
            </div>
          </div>
        </div>
        <div className={styles.heroImage} role="presentation" aria-hidden="true">
          <img src="https://picsum.photos/1600/900?random=95" alt="Students collaborating in a modern language classroom" loading="lazy" />
        </div>
      </section>

      <section className={styles.about}>
        <div className="container">
          <div className={styles.aboutGrid}>
            <div>
              <h2>About Zagreb Language Academy</h2>
              <p>
                Founded by Croatian linguists and international education specialists, Zagreb Language Academy delivers dynamic language learning across the country. Our campuses and digital classrooms bring together professionals, students, and newcomers who want impactful communication skills.
              </p>
              <p>
                We partner with companies in Zagreb’s tech hubs, Split’s tourism industry, Dubrovnik’s cultural organisations, and Rijeka’s maritime sector to design relevant programmes that reflect real-world needs. Every course is led by certified trainers with extensive global experience.
              </p>
            </div>
            <div className={styles.aboutCard}>
              <h3>Why learners choose us</h3>
              <ul>
                <li>Personalised learning paths and continuous progress coaching</li>
                <li>Immersive cultural experiences woven into every programme</li>
                <li>Blended learning combining virtual, on-site, and experiential modules</li>
                <li>Accredited certifications recognised by employers and universities</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.courses}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Our Course Portfolio</h2>
            <p>Structured pathways covering work, study, travel, and integration across Croatia’s key regions.</p>
          </div>
          <div className={styles.courseGrid}>
            {coursesData.map(course => (
              <article key={course.title} className={styles.courseCard}>
                <span className={styles.courseIcon} style={{ backgroundColor: course.color }} aria-hidden="true">
                  {course.title.split(' ').map(word => word[0]).join('').slice(0, 2)}
                </span>
                <h3>{course.title}</h3>
                <p>{course.description}</p>
                <Link to="/courses" className={styles.courseLink}>
                  Learn more
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.methodology}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Teaching Methodology &amp; Process</h2>
            <p>Our learning design blends communicative practice, digital resources, and Croatian cultural immersion.</p>
          </div>
          <div className={styles.timeline}>
            {methodologySteps.map((step, index) => (
              <div key={step.title} className={styles.timelineStep}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.detail}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Success Stories Across Croatia</h2>
            <p>Discover how organisations in Zagreb, Split, Dubrovnik, and beyond elevate language performance with us.</p>
          </div>
          <div className={styles.filterGroup} role="group" aria-label="Filter success stories by city">
            {['All', 'Zagreb', 'Split', 'Dubrovnik', 'Rijeka'].map(tag => (
              <button
                key={tag}
                type="button"
                className={`${styles.filterButton} ${activeStory === tag ? styles.filterActive : ''}`}
                onClick={() => setActiveStory(tag)}
              >
                {tag}
              </button>
            ))}
          </div>
          <div className={styles.storyGrid}>
            {filteredStories.map(story => (
              <article key={story.id} className={styles.storyCard}>
                <h3>{story.title}</h3>
                <p className={styles.storyCategory}>{story.category}</p>
                <p>{story.summary}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Learner testimonials">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Voices From Our Learners</h2>
            <p>Real success stories from professionals, students, and expats mastering new languages.</p>
          </div>
          <div className={styles.testimonialWrapper}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${index === currentTestimonial ? styles.testimonialActive : ''}`}
                aria-hidden={index !== currentTestimonial}
              >
                <img src={testimonial.image} alt={`Portrait of ${testimonial.name}`} loading="lazy" />
                <p className={styles.testimonialQuote}>&ldquo;{testimonial.quote}&rdquo;</p>
                <p className={styles.testimonialName}>{testimonial.name}</p>
                <span className={styles.testimonialRole}>{testimonial.role}</span>
              </article>
            ))}
          </div>
          <div className={styles.testimonialControls} role="tablist" aria-label="Testimonial navigation">
            {testimonials.map((testimonial, index) => (
              <button
                key={testimonial.name}
                type="button"
                className={`${styles.dot} ${index === currentTestimonial ? styles.dotActive : ''}`}
                onClick={() => setCurrentTestimonial(index)}
                aria-label={`Show testimonial from ${testimonial.name}`}
                aria-selected={index === currentTestimonial}
                role="tab"
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Frequently Asked Questions</h2>
            <p>Find quick answers about language courses, formats, and enrolment support throughout Croatia.</p>
          </div>
          <div className={styles.accordion} role="list">
            {faqItems.map((item, index) => {
              const isOpen = openFaq === index;
              return (
                <div key={item.question} className={styles.accordionItem} role="listitem">
                  <button
                    type="button"
                    className={styles.accordionButton}
                    onClick={() => setOpenFaq(prev => (prev === index ? null : index))}
                    aria-expanded={isOpen}
                  >
                    <span>{item.question}</span>
                    <span aria-hidden="true">{isOpen ? '−' : '+'}</span>
                  </button>
                  {isOpen && <p className={styles.accordionContent}>{item.answer}</p>}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Insights from our Academic Team</h2>
            <p>Stay informed with strategies, cultural tips, and language learning news from Croatia.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map(post => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.blogLink}>Continue reading</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="contact-section" className={styles.contactCta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Ready to accelerate your language journey?</h2>
              <p>Book a consultation with our advisors to design a tailored pathway for your team or personal growth.</p>
            </div>
            <Link to="/contact" className={styles.ctaButton}>
              Request a consultation
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;