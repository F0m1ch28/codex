import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './Legal.module.css';

const Privacy = () => (
  <>
    <MetaTags
      title="Privacy Policy | Zagreb Language Academy"
      description="Understand how Zagreb Language Academy protects your personal data in accordance with GDPR and Croatian regulations."
      canonical="https://www.zagreblanguageacademy.com/privacy"
      image="https://picsum.photos/1200/630?random=152"
      keywords="Privacy policy language school, GDPR Croatia, Zagreb Language Academy privacy"
    />
    <section className={styles.legal}>
      <div className="container">
        <h1>Privacy Policy</h1>
        <p className={styles.updated}>Last updated: January 2024</p>

        <h2>Personal Data We Collect</h2>
        <p>
          We collect contact details, course preferences, assessment results, and communication records necessary to deliver language training services. We may also gather feedback to improve our programmes.
        </p>

        <h2>How We Use Your Data</h2>
        <ul>
          <li>Planning and scheduling language courses and assessments.</li>
          <li>Providing learner support, progress reports, and certification updates.</li>
          <li>Informing you about relevant programmes, events, and promotions (with your consent).</li>
        </ul>

        <h2>Data Protection &amp; Security</h2>
        <p>
          Zagreb Language Academy adheres to GDPR and Croatian data protection laws. We implement physical, technical, and organisational safeguards to protect your information.
        </p>

        <h2>Your Rights</h2>
        <p>
          You may request access, correction, deletion, or portability of your personal data. You may also withdraw consent for marketing communications at any time.
        </p>

        <h2>Data Retention</h2>
        <p>
          We retain personal data only for as long as necessary to fulfil the purposes outlined above, or to comply with legal obligations.
        </p>

        <h2>Contact</h2>
        <p>To exercise your rights or ask questions, email privacy@zagreblanguageacademy.com.</p>
      </div>
    </section>
  </>
);

export default Privacy;