import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './Legal.module.css';

const Terms = () => (
  <>
    <MetaTags
      title="Terms of Service | Zagreb Language Academy"
      description="Review the terms of service governing your use of Zagreb Language Academy’s website, programmes, and services."
      canonical="https://www.zagreblanguageacademy.com/terms"
      image="https://picsum.photos/1200/630?random=151"
      keywords="Terms of service language school, Zagreb Language Academy terms"
    />
    <section className={styles.legal}>
      <div className="container">
        <h1>Terms of Service</h1>
        <p className={styles.updated}>Last updated: January 2024</p>

        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing or using the Zagreb Language Academy website or enrolling in our programmes, you agree to comply with these Terms of Service. If you do not agree, please refrain from using our services.
        </p>

        <h2>2. Services</h2>
        <p>
          We provide language education, consultation, and support services across Croatia. Course availability, schedules, and delivery formats may change based on demand and operational considerations.
        </p>

        <h2>3. User Responsibilities</h2>
        <ul>
          <li>Provide accurate personal information during enquiries and enrolment.</li>
          <li>Respect intellectual property and confidentiality of course materials.</li>
          <li>Adhere to attendance, participation, and code of conduct guidelines shared upon enrolment.</li>
        </ul>

        <h2>4. Intellectual Property</h2>
        <p>
          All content, including course materials, digital resources, and website assets, is owned or licensed by Zagreb Language Academy and may not be reproduced without written consent.
        </p>

        <h2>5. Liability</h2>
        <p>
          We make every effort to ensure accurate information and quality delivery. However, we are not liable for indirect, incidental, or consequential damages arising from use of our services, except where required by Croatian law.
        </p>

        <h2>6. Governing Law</h2>
        <p>
          These terms are governed by the laws of the Republic of Croatia. Disputes will be subject to the jurisdiction of Croatian courts.
        </p>

        <h2>7. Contact</h2>
        <p>For questions about these terms, please contact info@zagreblanguageacademy.com.</p>
      </div>
    </section>
  </>
);

export default Terms;