import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <MetaTags
      title="Cookie Policy | Zagreb Language Academy"
      description="Learn how Zagreb Language Academy uses cookies to deliver a secure and personalised browsing experience."
      canonical="https://www.zagreblanguageacademy.com/cookie-policy"
      image="https://picsum.photos/1200/630?random=153"
      keywords="Cookie policy language school, Zagreb Language Academy cookies"
    />
    <section className={styles.legal}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p className={styles.updated}>Last updated: January 2024</p>

        <h2>What Are Cookies?</h2>
        <p>
          Cookies are small text files stored on your device when you visit our website. They help us provide essential functionality, security, and insights into how visitors use our services.
        </p>

        <h2>Types of Cookies We Use</h2>
        <ul>
          <li><strong>Essential cookies:</strong> Required for secure browsing and basic functionality.</li>
          <li><strong>Performance cookies:</strong> Help us understand user behaviour to improve learning resources.</li>
          <li><strong>Preference cookies:</strong> Remember your language and location settings for future visits.</li>
        </ul>

        <h2>Managing Cookies</h2>
        <p>
          You can adjust cookie preferences through your browser settings or via our on-site cookie banner. Disabling some cookies may affect website performance.
        </p>

        <h2>Updates</h2>
        <p>
          We may update this policy to reflect changes in technology, regulation, or our services. Please review periodically.
        </p>

        <h2>Contact</h2>
        <p>
          Questions about this policy can be directed to privacy@zagreblanguageacademy.com.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;