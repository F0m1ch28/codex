import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './Courses.module.css';

const courseSections = [
  {
    title: 'English Programmes',
    image: 'https://picsum.photos/800/600?random=111',
    items: [
      {
        name: 'General English',
        description: 'Interactive classes that build confidence for travel, networking, and everyday communication in Croatia and abroad.'
      },
      {
        name: 'Business English',
        description: 'Scenario-based workshops for managers, entrepreneurs, and teams collaborating with international partners.'
      },
      {
        name: 'Exam Preparation',
        description: 'Targeted IELTS, TOEFL, and Cambridge preparation with mock testing and personalised feedback.'
      }
    ]
  },
  {
    title: 'German Courses',
    image: 'https://picsum.photos/800/600?random=112',
    items: [
      {
        name: 'Corporate German',
        description: 'Tailored modules for engineering, automotive, and logistics teams operating with German-speaking markets.'
      },
      {
        name: 'Healthcare German',
        description: 'Medical vocabulary, patient dialogues, and documentation training for healthcare professionals.'
      },
      {
        name: 'Conversational German',
        description: 'Small-group sessions perfect for hospitality and tourism staff working throughout the Adriatic coast.'
      }
    ]
  },
  {
    title: 'Italian Courses',
    image: 'https://picsum.photos/800/600?random=113',
    items: [
      {
        name: 'Italian for Tourism',
        description: 'Immersive coaching for travel agencies, guides, and concierge teams engaging Italian visitors daily.'
      },
      {
        name: 'Cultural Italian',
        description: 'Explore art, music, and gastronomy vocabulary through conversation labs and cultural excursions.'
      },
      {
        name: 'Business Italian',
        description: 'Confidence-building sessions for export managers and professionals dealing with Italian partners.'
      }
    ]
  },
  {
    title: 'Croatian for Foreigners',
    image: 'https://picsum.photos/800/600?random=114',
    items: [
      {
        name: 'Fast-Track Integration',
        description: 'Intensive crash courses designed for new arrivals relocating to Zagreb, Split, or Dubrovnik.'
      },
      {
        name: 'Workplace Communication',
        description: 'Understand workplace culture, professional etiquette, and industry-specific terminology.'
      },
      {
        name: 'Everyday Croatian',
        description: 'Learn functional language for navigating life in Croatia, from markets to municipal offices.'
      }
    ]
  },
  {
    title: 'Summer Intensive Programmes',
    image: 'https://picsum.photos/800/600?random=115',
    items: [
      {
        name: 'Adriatic Language Retreats',
        description: 'Combine daily immersion classes with experiential learning in Split, Hvar, or Dubrovnik.'
      },
      {
        name: 'University Prep Bootcamps',
        description: 'Academic English and German programmes for students preparing for international studies.'
      },
      {
        name: 'Youth Leadership Labs',
        description: 'Project-based learning where teens collaborate on social impact projects while mastering languages.'
      }
    ]
  }
];

const Courses = ({
  pageTitle = 'Language Courses in Croatia | Zagreb Language Academy',
  canonicalPath = '/courses',
  description = 'Explore English, German, Italian, Croatian, and summer intensive language programmes tailored for learners in Croatia.',
  aliasLabel = 'Courses'
}) => (
  <>
    <MetaTags
      title={pageTitle}
      description={description}
      canonical={`https://www.zagreblanguageacademy.com${canonicalPath}`}
      image="https://picsum.photos/1200/630?random=116"
      keywords="Language courses Croatia, English classes Zagreb, German course Split, Italian lessons Dubrovnik, Croatian for foreigners"
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>{aliasLabel}</h1>
        <p>
          Whether you are preparing for global opportunities, leading a tourism team on the Dalmatian coast, or settling into life in Croatia, our courses are built to deliver practical, measurable language progress.
        </p>
      </div>
    </section>
    <section className={styles.catalogue}>
      <div className="container">
        <div className={styles.grid}>
          {courseSections.map(section => (
            <article key={section.title} className={styles.card}>
              <div className={styles.cardImage}>
                <img src={section.image} alt={`${section.title} illustration`} loading="lazy" />
              </div>
              <div className={styles.cardContent}>
                <h2>{section.title}</h2>
                <ul>
                  {section.items.map(item => (
                    <li key={item.name}>
                      <h3>{item.name}</h3>
                      <p>{item.description}</p>
                    </li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
    <section className={styles.highlight}>
      <div className="container">
        <div className={styles.highlightCard}>
          <div>
            <h2>Flexible delivery, measurable outcomes</h2>
            <p>
              Programmes can be delivered on-site in Zagreb, Split, Dubrovnik, or Rijeka, fully online, or through a blended approach. Each client receives detailed progress analytics, certified assessments, and coaching within our digital learning portal.
            </p>
          </div>
          <Link to="/contact" className={styles.highlightButton}>
            Book a curriculum consultation
          </Link>
        </div>
      </div>
    </section>
  </>
);

export default Courses;