document.addEventListener('DOMContentLoaded', function () {
  const storageKey = 'auroraGiftCookiePreference';
  const banner = document.getElementById('cookie-banner');
  const acceptButton = document.getElementById('cookie-accept');
  const declineButton = document.getElementById('cookie-decline');

  if (banner && acceptButton && declineButton) {
    const savedPreference = localStorage.getItem(storageKey);
    if (savedPreference) {
      banner.classList.add('hidden');
    }

    acceptButton.addEventListener('click', function () {
      localStorage.setItem(storageKey, 'accepted');
      banner.classList.add('hidden');
    });

    declineButton.addEventListener('click', function () {
      localStorage.setItem(storageKey, 'declined');
      banner.classList.add('hidden');
    });
  }

  const menuToggle = document.querySelector('.menu-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', function () {
      const isOpen = navLinks.classList.toggle('is-open');
      menuToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  const customizerForm = document.querySelector('.customizer-form');
  if (customizerForm) {
    const sizeSelect = customizerForm.querySelector('#box-size');
    const themeSelect = customizerForm.querySelector('#box-theme');
    const messageInput = customizerForm.querySelector('#personal-message');
    const addOnCheckboxes = customizerForm.querySelectorAll('input[name="add-ons"]');
    const priceDisplay = document.querySelector('.price-display');
    const summaryList = document.querySelector('.summary-list');
    const previewImage = document.querySelector('.preview-image');

    const sizePrices = {
      classic: 65,
      deluxe: 95,
      grand: 135
    };

    const themeImages = {
      'winter-wonderland': 'https://picsum.photos/seed/wintergift/640/480',
      'midnight-luxe': 'https://picsum.photos/seed/luxegift/640/480',
      'birthday-bouquet': 'https://picsum.photos/seed/birthdaygift/640/480',
      'corporate-cheer': 'https://picsum.photos/seed/corporategift/640/480'
    };

    const addOnPrices = {
      ornaments: 15,
      gourmet: 22,
      candle: 18,
      personalization: 12
    };

    function updatePreview() {
      const sizeValue = sizeSelect.value;
      const themeValue = themeSelect.value;
      const messageValue = messageInput.value.trim();
      let totalPrice = sizePrices[sizeValue] || 65;
      const selections = [];

      selections.push(`Gift Box Size: ${sizeSelect.options[sizeSelect.selectedIndex].text}`);
      selections.push(`Holiday Theme: ${themeSelect.options[themeSelect.selectedIndex].text}`);

      addOnCheckboxes.forEach(function (checkbox) {
        if (checkbox.checked) {
          const addOnLabel = customizerForm.querySelector(`label[for="${checkbox.id}"]`);
          const addOnName = addOnLabel ? addOnLabel.dataset.label : checkbox.value;
          selections.push(`Add-on: ${addOnName}`);
          totalPrice += addOnPrices[checkbox.value] || 0;
        }
      });

      if (messageValue.length > 0) {
        selections.push(`Personal Message: “${messageValue}”`);
      } else {
        selections.push('Personal Message: Not included yet');
      }

      if (summaryList) {
        summaryList.innerHTML = '';
        selections.forEach(function (text) {
          const item = document.createElement('li');
          item.textContent = text;
          summaryList.appendChild(item);
        });
      }

      if (priceDisplay) {
        priceDisplay.textContent = `$${totalPrice.toFixed(2)}`;
      }

      if (previewImage) {
        const themeImage = themeImages[themeValue] || themeImages['winter-wonderland'];
        previewImage.style.backgroundImage = `url("${themeImage}")`;
      }
    }

    customizerForm.addEventListener('input', updatePreview);
    customizerForm.addEventListener('change', updatePreview);
    updatePreview();
  }
});