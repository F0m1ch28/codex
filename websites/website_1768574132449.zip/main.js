document.addEventListener("DOMContentLoaded", () => {
    const header = document.querySelector(".site-header");
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelectorAll(".nav-list a");
    const cookieBanner = document.getElementById("cookie-banner");
    const acceptBtn = document.getElementById("cookie-accept");
    const declineBtn = document.getElementById("cookie-decline");
    const consentKey = "lawrennoqo-cookie-consent";

    if (navToggle && header) {
        navToggle.addEventListener("click", () => {
            header.classList.toggle("nav-open");
        });
    }

    navLinks.forEach(link => {
        link.addEventListener("click", () => {
            if (header.classList.contains("nav-open")) {
                header.classList.remove("nav-open");
            }
        });
    });

    const setConsent = value => {
        localStorage.setItem(consentKey, value);
        if (cookieBanner) {
            cookieBanner.classList.add("hidden");
        }
    };

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (storedConsent) {
            cookieBanner.classList.add("hidden");
        }
        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => setConsent("accepted"));
        }
        if (declineBtn) {
            declineBtn.addEventListener("click", () => setConsent("declined"));
        }
    }
});