document.addEventListener("DOMContentLoaded", () => {
    const yearHolders = document.querySelectorAll(".current-year");
    const currentYear = new Date().getFullYear();
    yearHolders.forEach(holder => {
        holder.textContent = currentYear;
    });

    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");
    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            navLinks.classList.toggle("open");
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const consentKey = "cir_cookie_consent";
    const storedConsent = localStorage.getItem(consentKey);

    if (cookieBanner && !storedConsent) {
        cookieBanner.classList.add("active");
    }

    if (cookieBanner) {
        const consentButtons = cookieBanner.querySelectorAll("[data-consent-action]");
        consentButtons.forEach(button => {
            button.addEventListener("click", event => {
                event.preventDefault();
                const action = button.getAttribute("data-consent-action");
                localStorage.setItem(consentKey, action);
                cookieBanner.classList.remove("active");
            });
        });
    }

    const postSection = document.querySelector(".posts-page");
    if (postSection) {
        const searchInput = document.querySelector("#post-search");
        const filterButtons = document.querySelectorAll("[data-filter]");
        const postCards = Array.from(document.querySelectorAll(".post-card"));
        const paginationContainer = document.querySelector(".pagination");
        const postsPerPage = 6;
        let activeCategory = "all";
        let searchTerm = "";
        let currentPage = 1;

        const renderPosts = () => {
            const filtered = postCards.filter(card => {
                const title = card.getAttribute("data-title").toLowerCase();
                const category = card.getAttribute("data-category");
                const matchesCategory = activeCategory === "all" || category === activeCategory;
                const matchesSearch = !searchTerm || title.includes(searchTerm.toLowerCase());
                return matchesCategory && matchesSearch;
            });

            const totalPages = Math.max(1, Math.ceil(filtered.length / postsPerPage));
            if (currentPage > totalPages) {
                currentPage = totalPages;
            }
            const startIndex = (currentPage - 1) * postsPerPage;
            const endIndex = startIndex + postsPerPage;
            postCards.forEach(card => card.style.display = "none");
            filtered.slice(startIndex, endIndex).forEach(card => card.style.display = "flex");

            if (paginationContainer) {
                paginationContainer.innerHTML = "";
                for (let i = 1; i <= totalPages; i += 1) {
                    const button = document.createElement("button");
                    button.textContent = i;
                    if (i === currentPage) {
                        button.classList.add("active");
                    }
                    button.addEventListener("click", () => {
                        currentPage = i;
                        renderPosts();
                        window.scrollTo({ top: postSection.offsetTop - 120, behavior: "smooth" });
                    });
                    paginationContainer.appendChild(button);
                }
            }
        };

        if (searchInput) {
            searchInput.addEventListener("input", event => {
                searchTerm = event.target.value.trim();
                currentPage = 1;
                renderPosts();
            });
        }

        filterButtons.forEach(button => {
            button.addEventListener("click", () => {
                filterButtons.forEach(btn => btn.classList.remove("active"));
                button.classList.add("active");
                activeCategory = button.getAttribute("data-filter");
                currentPage = 1;
                renderPosts();
            });
        });

        renderPosts();
    }

    const forms = document.querySelectorAll("form[data-validate]");
    forms.forEach(form => {
        form.addEventListener("submit", event => {
            const invalidFields = Array.from(form.querySelectorAll("[required]")).filter(field => !field.value.trim());
            invalidFields.forEach(field => {
                field.classList.add("invalid");
                field.addEventListener("input", () => field.classList.remove("invalid"), { once: true });
            });
            if (invalidFields.length > 0) {
                event.preventDefault();
            }
        });
    });
});