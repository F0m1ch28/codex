document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const header = document.querySelector('.site-header');
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');
  const navLinks = document.querySelectorAll('.nav-link');

  // Mobile navigation toggle
  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = primaryNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', isOpen);
      body.classList.toggle('nav-open', isOpen);
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        if (primaryNav.classList.contains('open')) {
          primaryNav.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
          body.classList.remove('nav-open');
        }
      });
    });
  }

  // Active navigation highlighting
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  navLinks.forEach(link => {
    const linkPath = link.getAttribute('href');
    if (linkPath === currentPath || (currentPath === '' && linkPath === 'index.html')) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // Smooth scroll for anchor links
  const anchorLinks = document.querySelectorAll('a[href^="#"]');
  anchorLinks.forEach(anchor => {
    const href = anchor.getAttribute('href');
    if (href && href.length > 1) {
      anchor.addEventListener('click', (event) => {
        const target = document.querySelector(href);
        if (target) {
          event.preventDefault();
          target.scrollIntoView({ behavior: 'smooth' });
        }
      });
    }
  });

  // Cookie banner logic
  const cookieBanner = document.getElementById('cookieBanner');
  const acceptBtn = document.getElementById('cookieAccept');
  const declineBtn = document.getElementById('cookieDecline');
  const consent = localStorage.getItem('cookieConsent');

  const hideBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.remove('is-visible');
      cookieBanner.setAttribute('aria-hidden', 'true');
    }
  };

  const showBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.add('is-visible');
      cookieBanner.setAttribute('aria-hidden', 'false');
    }
  };

  if (!consent) {
    setTimeout(showBanner, 500);
  }

  const setConsent = (value) => {
    localStorage.setItem('cookieConsent', value);
    hideBanner();
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => setConsent('accepted'));
  }
  if (declineBtn) {
    declineBtn.addEventListener('click', () => setConsent('declined'));
  }
  if (consent === 'accepted' || consent === 'declined') {
    hideBanner();
  }

  // Contact form validation
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    const feedback = document.getElementById('formFeedback');

    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      let formValid = true;
      const requiredFields = ['name', 'email', 'timeline', 'message', 'consent'];

      requiredFields.forEach((fieldId) => {
        const field = contactForm.elements[fieldId];
        if (field) {
          const isCheckbox = field.type === 'checkbox';
          const isValid = isCheckbox ? field.checked : field.value.trim() !== '';
          if (!isValid) {
            formValid = false;
            field.classList.add('input-error');
          } else {
            field.classList.remove('input-error');
          }
        }
      });

      const emailField = contactForm.elements['email'];
      if (emailField && emailField.value) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(emailField.value)) {
          formValid = false;
          emailField.classList.add('input-error');
        }
      }

      if (!formValid) {
        feedback.textContent = 'Please review the highlighted fields.';
        feedback.classList.add('error');
        feedback.classList.remove('success');
        return;
      }

      feedback.textContent = 'Thank you! We’ll be in touch within 24 hours.';
      feedback.classList.add('success');
      feedback.classList.remove('error');
      contactForm.reset();
    });
  }

  // Update footer year
  const yearEl = document.getElementById('currentYear');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
});