document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.site-nav');
    if (navToggle && nav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            nav.classList.toggle('is-open');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector('.cookie-btn.accept');
        const declineBtn = cookieBanner.querySelector('.cookie-btn.decline');
        const storageKey = 'gbs_cookie_choice';
        const storedChoice = localStorage.getItem(storageKey);

        const hideBanner = () => {
            cookieBanner.setAttribute('data-visible', 'false');
            setTimeout(() => {
                cookieBanner.style.display = 'none';
            }, 400);
        };

        if (!storedChoice) {
            cookieBanner.style.display = 'grid';
            requestAnimationFrame(() => {
                cookieBanner.setAttribute('data-visible', 'true');
            });
        } else {
            cookieBanner.style.display = 'none';
        }

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => {
                localStorage.setItem(storageKey, 'accepted');
                hideBanner();
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => {
                localStorage.setItem(storageKey, 'declined');
                hideBanner();
            });
        }
    }
});