(function () {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');
  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      siteNav.classList.toggle('is-open');
    });
    siteNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        siteNav.classList.remove('is-open');
      });
    });
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  document.querySelectorAll('.fade-in').forEach(element => observer.observe(element));

  const yearSpan = document.querySelectorAll('#footerYear');
  const currentYear = new Date().getFullYear();
  yearSpan.forEach(span => { span.textContent = currentYear; });

  const toast = document.getElementById('globalToast');
  const showToast = message => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
    }, 2600);
  };

  const cookieBanner = document.getElementById('cookieBanner');
  const cookieKey = 'kapadokyaseyahatim_cookie_choice';
  if (cookieBanner) {
    const savedChoice = localStorage.getItem(cookieKey);
    if (!savedChoice) {
      requestAnimationFrame(() => cookieBanner.classList.add('is-visible'));
    }
    cookieBanner.querySelectorAll('button').forEach(button => {
      button.addEventListener('click', () => {
        const value = button.classList.contains('accept') ? 'accepted' : 'declined';
        localStorage.setItem(cookieKey, value);
        cookieBanner.classList.remove('is-visible');
        showToast('Preference saved.');
      });
    });
  }

  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      showToast('Message received. Redirecting...');
      setTimeout(() => {
        window.location.href = contactForm.getAttribute('action');
      }, 1500);
    });
  }
})();