document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navList = document.querySelector('.nav-list');
  const navLinks = document.querySelectorAll('.nav-list a');
  if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
      const isOpen = navList.classList.toggle('is-open');
      navToggle.classList.toggle('is-active', isOpen);
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        if (navList.classList.contains('is-open')) {
          navList.classList.remove('is-open');
          navToggle.classList.remove('is-active');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  // Cookie banner
  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtns = document.querySelectorAll('[data-cookie-decline]');
  const cookieChoice = localStorage.getItem('cookieConsent');

  const hideCookieBanner = () => {
    cookieBanner.classList.remove('is-visible');
    setTimeout(() => cookieBanner.setAttribute('hidden', ''), 300);
  };

  if (cookieBanner) {
    if (!cookieChoice) {
      cookieBanner.removeAttribute('hidden');
      requestAnimationFrame(() => {
        cookieBanner.classList.add('is-visible');
      });
    }

    acceptBtn?.addEventListener('click', () => {
      localStorage.setItem('cookieConsent', 'accepted');
      hideCookieBanner();
    });

    declineBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        localStorage.setItem('cookieConsent', 'declined');
        hideCookieBanner();
      });
    });
  }

  // Agencies filter
  const filterSelect = document.querySelector('[data-filter="agencies"]');
  const agencyCards = document.querySelectorAll('[data-agency-card]');
  const emptyState = document.querySelector('[data-empty-state]');

  const filterAgencies = value => {
    let visibleCount = 0;
    agencyCards.forEach(card => {
      const categories = card.dataset.categories.split(',').map(cat => cat.trim());
      const match = value === 'all' || categories.includes(value);
      card.style.display = match ? 'flex' : 'none';
      if (match) visibleCount++;
    });
    if (emptyState) {
      emptyState.hidden = visibleCount !== 0;
    }
  };

  if (filterSelect) {
    filterSelect.addEventListener('change', event => {
      filterAgencies(event.target.value);
    });
    filterAgencies(filterSelect.value);
  }

  // Contact form validation
  const contactForm = document.querySelector('[data-contact-form]');
  if (contactForm) {
    const requiredFields = contactForm.querySelectorAll('[data-required]');
    const successMessage = contactForm.querySelector('[data-form-success]');

    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      let isValid = true;

      requiredFields.forEach(field => {
        const errorElement = field.nextElementSibling;
        if (errorElement && errorElement.classList.contains('form-error')) {
          errorElement.textContent = '';
        }

        if (!field.value.trim()) {
          isValid = false;
          if (errorElement) {
            errorElement.textContent = 'This field is required.';
          }
        } else if (field.type === 'email') {
          const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailPattern.test(field.value.trim())) {
            isValid = false;
            if (errorElement) {
              errorElement.textContent = 'Enter a valid email address.';
            }
          }
        }
      });

      const phoneField = contactForm.querySelector('input[name="phone"]');
      if (phoneField && phoneField.value.trim()) {
        const phonePattern = /^[+\d][\d\s-]{6,}$/;
        const errorElement = phoneField.nextElementSibling;
        if (!phonePattern.test(phoneField.value.trim())) {
          isValid = false;
          if (errorElement) {
            errorElement.textContent = 'Enter a valid phone number.';
          }
        }
      }

      if (isValid) {
        contactForm.reset();
        if (successMessage) {
          successMessage.textContent = 'Thank you! Our consultants will reach out shortly.';
        }
      } else if (successMessage) {
        successMessage.textContent = '';
      }
    });
  }

  // Footer year
  document.querySelectorAll('#current-year').forEach(el => {
    el.textContent = new Date().getFullYear();
  });
});