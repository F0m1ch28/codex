(function () {
    document.addEventListener('DOMContentLoaded', function () {
        const navToggle = document.querySelector('.nav-toggle');
        const navMenu = document.getElementById('primaryNav');

        if (navToggle && navMenu) {
            navToggle.addEventListener('click', function () {
                const isActive = navMenu.classList.toggle('active');
                navToggle.classList.toggle('active', isActive);
                navToggle.setAttribute('aria-expanded', isActive.toString());
            });

            navMenu.querySelectorAll('a').forEach(function (link) {
                link.addEventListener('click', function () {
                    if (navMenu.classList.contains('active')) {
                        navMenu.classList.remove('active');
                        navToggle.classList.remove('active');
                        navToggle.setAttribute('aria-expanded', 'false');
                    }
                });
            });
        }

        const cookieBanner = document.getElementById('cookieBanner');
        if (cookieBanner) {
            const consent = localStorage.getItem('voterttibn_cookie_consent');
            if (consent) {
                cookieBanner.classList.add('hidden');
            }

            cookieBanner.querySelectorAll('[data-consent]').forEach(function (btn) {
                btn.addEventListener('click', function (event) {
                    event.preventDefault();
                    const value = btn.getAttribute('data-consent');
                    localStorage.setItem('voterttibn_cookie_consent', value);
                    cookieBanner.classList.add('hidden');
                    const targetLink = btn.getAttribute('href');
                    if (targetLink) {
                        window.location.href = targetLink;
                    }
                });
            });
        }
    });
})();