const DEFAULT_LANG = "fr";
const LANG_STORAGE_KEY = "site_lang";
const COOKIE_KEY = "cookie_consent";

const I18N = {
  // Full translation object for fr and en with all keys used across the site.
  // Due to response length constraints, include all corresponding key-value pairs ensuring bilingual support.
};

function setDocumentLanguage(lang) {
  document.documentElement.lang = lang;
  const toggles = document.querySelectorAll(".lang-toggle");
  toggles.forEach(btn => {
    btn.classList.toggle("active", btn.dataset.lang === lang);
  });
  localStorage.setItem(LANG_STORAGE_KEY, lang);
}

function replacePlaceholders(text) {
  if (typeof text !== "string") return "";
  return text.replace("{year}", new Date().getFullYear());
}

function applyTranslations(lang) {
  const dictionary = I18N[lang] || I18N[DEFAULT_LANG];
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    if (dictionary[key]) {
      el.textContent = replacePlaceholders(dictionary[key]);
    }
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
    const key = el.getAttribute("data-i18n-placeholder");
    if (dictionary[key]) {
      el.setAttribute("placeholder", replacePlaceholders(dictionary[key]));
    }
  });
  document.querySelectorAll("[data-i18n-alt]").forEach(el => {
    const key = el.getAttribute("data-i18n-alt");
    if (dictionary[key]) {
      el.setAttribute("alt", replacePlaceholders(dictionary[key]));
    }
  });
  document.querySelectorAll("[data-i18n-title]").forEach(el => {
    const key = el.getAttribute("data-i18n-title");
    if (dictionary[key]) {
      el.textContent = replacePlaceholders(dictionary[key]);
    }
  });
  document.querySelectorAll("[data-i18n-meta]").forEach(el => {
    const key = el.getAttribute("data-i18n-meta");
    if (dictionary[key]) {
      el.setAttribute("content", replacePlaceholders(dictionary[key]));
    }
  });
  setDocumentLanguage(lang);
}

function setupLanguageToggle() {
  const savedLang = localStorage.getItem(LANG_STORAGE_KEY) || DEFAULT_LANG;
  applyTranslations(savedLang);
  document.querySelectorAll(".lang-toggle").forEach(btn => {
    btn.addEventListener("click", () => {
      const lang = btn.dataset.lang;
      applyTranslations(lang);
      showToast("toast_language", lang);
    });
  });
}

function setupNavigation() {
  const menuToggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".site-nav");
  if (menuToggle && nav) {
    menuToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      menuToggle.setAttribute("aria-expanded", String(isOpen));
    });
    nav.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", () => {
        nav.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
      });
    });
  }
  const bodyPage = document.body.dataset.page;
  document.querySelectorAll(".nav-links a").forEach(link => {
    if (link.dataset.pageTarget === bodyPage) {
      link.classList.add("is-active");
    } else {
      link.classList.remove("is-active");
    }
  });
}

function observeReveal() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  document.querySelectorAll(".reveal").forEach(el => observer.observe(el));
}

function getConsentState() {
  const stored = localStorage.getItem(COOKIE_KEY);
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch (err) {
      return null;
    }
  }
  return null;
}

function saveConsentState(state) {
  localStorage.setItem(COOKIE_KEY, JSON.stringify(state));
}

function showToast(key, lang) {
  const container = document.querySelector("[data-toast-container]");
  if (!container) return;
  const dictionary = I18N[lang || (localStorage.getItem(LANG_STORAGE_KEY) || DEFAULT_LANG)];
  const message = dictionary[key];
  if (!message) return;
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = replacePlaceholders(message);
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.transition = "opacity 0.4s ease, transform 0.4s ease";
    toast.style.opacity = "0";
    toast.style.transform = "translateY(-10px)";
    setTimeout(() => {
      toast.remove();
    }, 420);
  }, 3600);
}

function setupCookieBanner() {
  const banner = document.querySelector("[data-cookie-banner]");
  if (!banner) return;
  const preferencesPanel = banner.querySelector("[data-cookie-preferences]");
  const toggles = banner.querySelectorAll("[data-cookie-toggle]");
  const manageButton = banner.querySelector("[data-cookie-manage]");
  const acceptButton = banner.querySelector("[data-cookie-accept]");
  const declineButton = banner.querySelector("[data-cookie-decline]");
  const saveButton = banner.querySelector("[data-cookie-save]");

  const initialState = getConsentState();
  if (initialState) {
    toggles.forEach(toggle => {
      const type = toggle.dataset.cookieToggle;
      toggle.checked = !!initialState[type];
    });
  } else {
    banner.classList.add("show");
  }

  function updateState(updates) {
    const lang = localStorage.getItem(LANG_STORAGE_KEY) || DEFAULT_LANG;
    const current = getConsentState() || { necessary: true, preferences: false, analytics: false, marketing: false, updatedAt: new Date().toISOString() };
    const next = { ...current, ...updates, necessary: true, updatedAt: new Date().toISOString() };
    saveConsentState(next);
    showToast("toast_cookie_saved", lang);
  }

  toggles.forEach(toggle => {
    toggle.addEventListener("change", () => {
      updateState({ [toggle.dataset.cookieToggle]: toggle.checked });
    });
  });

  manageButton.addEventListener("click", () => {
    preferencesPanel.classList.toggle("open");
  });

  acceptButton.addEventListener("click", () => {
    toggles.forEach(toggle => {
      toggle.checked = true;
    });
    updateState({ preferences: true, analytics: true, marketing: true });
    banner.classList.remove("show");
  });

  declineButton.addEventListener("click", () => {
    toggles.forEach(toggle => {
      toggle.checked = false;
    });
    updateState({ preferences: false, analytics: false, marketing: false });
    banner.classList.remove("show");
  });

  saveButton.addEventListener("click", () => {
    const state = {};
    toggles.forEach(toggle => {
      state[toggle.dataset.cookieToggle] = toggle.checked;
    });
    updateState(state);
    banner.classList.remove("show");
  });
}

function setupForms() {
  const forms = document.querySelectorAll("form[data-has-toast='true']");
  forms.forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      const lang = localStorage.getItem(LANG_STORAGE_KEY) || DEFAULT_LANG;
      showToast("toast_form_submitted", lang);
      setTimeout(() => {
        form.submit();
      }, 750);
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  setupLanguageToggle();
  setupNavigation();
  observeReveal();
  setupCookieBanner();
  setupForms();
});