import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('naverilano-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('naverilano-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div>
        <p className={styles.title}>Wir verwenden Cookies</p>
        <p className={styles.text}>
          Wir nutzen funktionale Cookies, um Dir ein reibungsloses Erlebnis zu ermöglichen. Es werden keine
          persönlichen Profile erstellt.
        </p>
      </div>
      <button className={styles.button} onClick={handleAccept}>
        Verstanden
      </button>
    </div>
  );
};

export default CookieBanner;