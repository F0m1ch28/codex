import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-label="Seitenende">
    <div className={styles.top}>
      <div className={styles.brand}>
        <div className={styles.logo} aria-hidden="true">N</div>
        <div>
          <p className={styles.brandName}>Naverilano</p>
          <p className={styles.brandClaim}>
            Orientierung, die Dich in der Arbeitswelt mit KI sicher begleitet.
          </p>
        </div>
      </div>
      <div className={styles.columns}>
        <div>
          <p className={styles.columnTitle}>Erkunden</p>
          <ul>
            <li>
              <NavLink to="/guide">Leitfaden</NavLink>
            </li>
            <li>
              <NavLink to="/programs">Programme</NavLink>
            </li>
            <li>
              <NavLink to="/tools">Tools & Checklisten</NavLink>
            </li>
            <li>
              <NavLink to="/blog">Blog</NavLink>
            </li>
          </ul>
        </div>
        <div>
          <p className={styles.columnTitle}>Über Naverilano</p>
          <ul>
            <li>
              <NavLink to="/about">Team & Mission</NavLink>
            </li>
            <li>
              <NavLink to="/services">Angebote</NavLink>
            </li>
            <li>
              <NavLink to="/contact">Kontakt</NavLink>
            </li>
          </ul>
        </div>
        <div>
          <p className={styles.columnTitle}>Rechtliches</p>
          <ul>
            <li>
              <NavLink to="/legal">Rechtliche Hinweise</NavLink>
            </li>
            <li>
              <NavLink to="/privacy">Datenschutz</NavLink>
            </li>
            <li>
              <NavLink to="/imprint">Impressum</NavLink>
            </li>
          </ul>
        </div>
        <div>
          <p className={styles.columnTitle}>Kontakt</p>
          <ul>
            <li>Friedrichstraße 123</li>
            <li>10117 Berlin</li>
            <li>
              <a href="mailto:kontakt@naverilano.de">kontakt@naverilano.de</a>
            </li>
            <li>
              <a href="tel:+49301234567">+49 30 123 45 67</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Naverilano. Alle Rechte vorbehalten.</p>
      <div className={styles.bottomLinks}>
        <NavLink to="/privacy">Datenschutz</NavLink>
        <NavLink to="/legal">Rechtliches</NavLink>
        <NavLink to="/imprint">Impressum</NavLink>
      </div>
    </div>
  </footer>
);

export default Footer;