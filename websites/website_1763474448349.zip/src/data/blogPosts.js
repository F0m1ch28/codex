const blogPosts = [
  {
    slug: 'berufsorientierung-mit-ki-gelassen-bleiben',
    title: 'Berufsorientierung mit KI: Wie Du gelassen bleibst',
    category: 'Berufsorientierung',
    excerpt:
      'Künstliche Intelligenz sorgt für Unsicherheit. Mit diesen drei Schritten behältst Du Ruhe und findest heraus, wo Dein Platz bleibt.',
    readingTime: 6,
    date: '08. Januar 2024',
    content: [
      {
        heading: 'Warum Gelassenheit gerade jetzt wichtig ist',
        paragraphs: [
          'Viele Menschen erleben die Veränderungen durch KI als diffuse Bedrohung. Gelassenheit bedeutet nicht, alles schönzureden, sondern bewusst hinzuschauen, was sich wirklich verändert.',
          'Bevor Du Entscheidungen triffst, lohnt sich eine ehrliche Bestandsaufnahme: Welche Aufgaben hast Du? Welche davon liebst Du? Wo spürst Du Überforderung?'
        ]
      },
      {
        heading: 'Drei Schritte zu klaren Entscheidungen',
        paragraphs: [
          '1. Sortiere Deine Aufgaben: Welche werden durch KI erleichtert? Wo braucht es weiterhin Deine Verantwortung?',
          '2. Sprich mit Menschen, die bereits erste KI-Projekte umgesetzt haben. Häufig zeigt sich: Die Mischung aus Mensch und Technik zählt.',
          '3. Lege Mini-Experimente fest. Ein Gespräch, ein kurzes Lernmodul oder ein Shadowing-Tag liefern mehr Erkenntnisse als stundenlange Recherche.'
        ],
        list: ['Aufgabenlandkarte erstellen', 'Gesprächspartner:innen identifizieren', 'Experiment planen']
      },
      {
        heading: 'Wann Du Unterstützung brauchst',
        paragraphs: [
          'Wenn Du merkst, dass sich Ängste festsetzen oder dass Informationen Dich überrollen, hilft externe Begleitung. Du musst Deinen Weg nicht allein gehen.',
          'Ein strukturierter Leitfaden, Reflexionsfragen und klare Check-ins bringen Ruhe in den Prozess. Genau das bieten wir bei Naverilano.'
        ]
      }
    ]
  },
  {
    slug: 'karrierewechsel-ohne-alles-aufzugeben',
    title: 'Karrierewechsel ohne Alles-oder-Nichts-Denken',
    category: 'Karrierewechsel',
    excerpt:
      'Du willst Dich verändern, aber nicht alles auf einmal? Ein sanfter Wechsel ermöglicht Dir, Neues zu testen und Sicherheit zu behalten.',
    readingTime: 7,
    date: '19. Dezember 2023',
    content: [
      {
        heading: 'Warum radikale Schritte selten nötig sind',
        paragraphs: [
          'Karrierewechsel wird oft als großer Sprung dargestellt. In der Realität funktioniert es für die meisten Menschen besser, in Etappen zu gehen.',
          'Durch die Verbindung von alten und neuen Kompetenzen entsteht ein glaubwürdiger Weg, den auch Arbeitgeber nachvollziehen können.'
        ]
      },
      {
        heading: 'Bausteine eines sanften Wechsels',
        paragraphs: [
          'Starte mit einem klaren Zielbild: Was möchtest Du häufiger tun, was weniger? Diese Klarheit hilft Dir bei Entscheidungen.',
          'Nutze Gesprächsformate: Informationsgespräche, Hospitationen oder interne Projekte zeigen Dir, wie sich neue Aufgaben anfühlen.'
        ],
        list: ['Zielbild formulieren', 'Kernkompetenzen matchen', 'Erste Projekte testen']
      },
      {
        heading: 'Dranbleiben trotz Alltag',
        paragraphs: [
          'Plane kleine Lernschritte und dokumentiere Fortschritte. So siehst Du, dass sich etwas bewegt – selbst wenn es langsam wirkt.',
          'Hol Dir Sparringspartner:innen. Gemeinsam lässt sich Motivation leichter halten und Rückschläge werden schneller verarbeitet.'
        ]
      }
    ]
  },
  {
    slug: 'ki-am-arbeitsplatz-rollen-klarheit',
    title: 'KI am Arbeitsplatz: Rollen neu denken',
    category: 'Umgang mit KI',
    excerpt:
      'Welche Aufgaben übernimmt KI, und wo bleibst Du wichtig? Eine ehrliche Rollenklärung ist der Schlüssel für Teams und Einzelpersonen.',
    readingTime: 5,
    date: '02. November 2023',
    content: [
      {
        heading: 'Verantwortung bewusst verteilen',
        paragraphs: [
          'KI-Systeme brauchen Menschen, die Ergebnisse prüfen, Entscheidungen treffen und Verantwortung übernehmen. Rollenklärung verhindert, dass Aufgaben liegen bleiben.',
          'Teams sollten regelmäßig gemeinsam prüfen: Was läuft gut? Wo braucht es Anpassungen? Offenheit zahlt sich aus.'
        ]
      },
      {
        heading: 'Transparenz schafft Vertrauen',
        paragraphs: [
          'Beschreibe genau, welche Aufgabe KI übernimmt und welche Schritte Menschen durchführen. Das schafft Sicherheit bei Kolleg:innen und Kund:innen.',
          'Nutze Feedback: Wenn jemand Unsicherheit spürt, sollte das ernst genommen und nicht als Widerstand abgetan werden.'
        ],
        list: ['Rollen-Matrix erstellen', 'Regelmäßige Retro einplanen', 'Feedbackräume sichern']
      },
      {
        heading: 'Der Mensch bleibt entscheidend',
        paragraphs: [
          'Empathie, Verantwortung und kritisches Denken lassen sich nicht automatisieren. Investiere in diese Fähigkeiten – sie machen Dich unverzichtbar.',
          'Naverilano unterstützt Dich dabei, genau diese Qualitäten sichtbar zu machen und auszubauen.'
        ]
      }
    ]
  }
];

export default blogPosts;