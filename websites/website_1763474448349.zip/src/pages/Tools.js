import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const tools = [
  {
    title: 'Reflexionsfragen zu Stärken',
    description:
      'Ein Leitfaden mit Fragen für Dich und für Menschen aus Deinem Umfeld. Aufgeteilt in Erfolge, Herausforderungen und Lernfelder.',
    items: ['Persönliche Reflexion', 'Feedback-Impulse', 'Handlungsableitung']
  },
  {
    title: 'Liste: Was kann KI übernehmen – was nicht?',
    description:
      'Sortiere Deine Aufgaben und prüfe, wo KI heute unterstützt, wo sie Grenzen hat und wo Du Expertise ausbauen kannst.',
    items: ['Aufgaben-Check', 'Entscheidungshilfe', 'Risikoanalyse']
  },
  {
    title: 'Wochenplan für Recherche & Gespräche',
    description:
      'Plane gezielt Gespräche, Micro-Learnings und Pausen. Mit Reflexionsfeldern, um Fortschritt sichtbar zu machen.',
    items: ['Planungsvorlagen', 'Check-ins', 'Feedback-Box']
  },
  {
    title: 'Tagesstruktur für Lernphasen',
    description:
      'Hilft Dir, Lernzeiten mit Alltag zu vereinbaren. Inklusive Tipps für digitale Tools, die Dich unterstützen.',
    items: ['Zeitfenster planen', 'Routinen etablieren', 'Energie im Blick behalten']
  },
  {
    title: 'Gesprächsleitfäden mit Arbeitgeber:innen',
    description:
      'Vorlagen, mit denen Du ruhig über Deine Rolle, KI-Einsatz und Weiterbildungen sprichst – klar, wertschätzend, vorbereitet.',
    items: ['Frageliste', 'Argumentationshilfe', 'Follow-up Ideen']
  }
];

const Tools = () => (
  <>
    <Helmet>
      <title>Tools & Checklisten | Naverilano</title>
      <meta
        name="description"
        content="Praktische Werkzeuge von Naverilano unterstützen Dich im Berufsalltag mit KI und bei beruflicher Neuorientierung."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Tools & Checklisten für Deine berufliche Klarheit</h1>
        <p>Nutze praktische Hilfen, um strukturiert zu bleiben – im Kopf und im Kalender.</p>
      </div>
    </section>

    <section className={styles.toolsSection}>
      <div className="container">
        <div className={styles.grid}>
          {tools.map((tool) => (
            <article key={tool.title} className={styles.card}>
              <h2>{tool.title}</h2>
              <p>{tool.description}</p>
              <ul>
                {tool.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <button type="button">Tool herunterladen</button>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Tools;