import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Leonie Krämer',
    role: 'Berufs- und Laufbahnexpertin',
    bio: 'Leonie begleitet seit über zehn Jahren Menschen in beruflichen Veränderungsprozessen. Sie verbindet psychologische Beratung mit klaren Arbeitsmarktanalysen.',
    focus: ['Berufsorientierung', 'Stärkenarbeit', 'Gespräche mit Arbeitgeber:innen'],
    image: 'https://picsum.photos/800/600?random=51'
  },
  {
    name: 'Daniel Vogt',
    role: 'Arbeitsmarktforscher',
    bio: 'Daniel übersetzt Daten in verständliche Trends. Er arbeitet daran, KI-Entwicklungen greifbar zu machen und Rollenprofile der Zukunft zu beschreiben.',
    focus: ['Zukunftsrollen', 'KI-Analysen', 'Branchenreports'],
    image: 'https://picsum.photos/800/600?random=52'
  },
  {
    name: 'Sara Bennani',
    role: 'Coach für Lernstrategien',
    bio: 'Sara sorgt dafür, dass Du neue Kompetenzen nachhaltig verankerst. Sie kennt die Herausforderungen, Lernen neben Job und Leben zu integrieren.',
    focus: ['Lernpfade', 'Motivation', 'Routinen & Alltag'],
    image: 'https://picsum.photos/800/600?random=53'
  },
  {
    name: 'Micha Wagner',
    role: 'Community & Partnerschaften',
    bio: 'Micha baut Brücken zu Unternehmen, Bildungsanbietern und Netzwerken. Ihm ist wichtig, dass Menschen ehrlich miteinander sprechen – ohne Marketingsprache.',
    focus: ['Kooperationen', 'Netzwerke', 'Gespräche mit Betrieben'],
    image: 'https://picsum.photos/800/600?random=54'
  }
];

const About = () => (
  <>
    <Helmet>
      <title>Über uns | Naverilano</title>
      <meta
        name="description"
        content="Das Team von Naverilano unterstützt Menschen in Deutschland dabei, berufliche Entscheidungen im KI-Zeitalter fundiert zu treffen."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Wir sind Naverilano</h1>
        <p>
          Unsere Mission: Dich in Deutschland dabei zu unterstützen, Deinen beruflichen Weg mit KI bewusst zu gestalten.
          Wir arbeiten praxisnah, datenbasiert und immer wertschätzend.
        </p>
      </div>
    </section>

    <section className={styles.mission}>
      <div className="container">
        <div className={styles.content}>
          <h2>Was uns antreibt</h2>
          <p>
            Die Arbeitswelt braucht Menschen, die Verantwortung übernehmen. Wir glauben an eine Zukunft, in der KI
            Menschen unterstützt und nicht ersetzt. Dafür braucht es Orientierung, realistische Informationen und Räume
            für ehrliche Gespräche. Hier setzen wir an.
          </p>
          <ul>
            <li>
              <strong>Verantwortungsvoll:</strong> Wir arbeiten DSGVO-konform, speichern Daten auf deutschen Servern und
              geben nichts weiter.
            </li>
            <li>
              <strong>Realistisch:</strong> Wir versprechen keine Wunder, sondern zeigen Dir, wie Schritte machbar
              werden.
            </li>
            <li>
              <strong>Empathisch:</strong> Deine Situation steht im Mittelpunkt. Wir hören zu und begleiten ohne
              Druck.
            </li>
          </ul>
        </div>
        <div className={styles.imageWrapper}>
          <img src="https://picsum.photos/800/600?random=55" alt="Teamwork bei Naverilano" loading="lazy" />
        </div>
      </div>
    </section>

    <section className={styles.teamSection}>
      <div className="container">
        <h2>Unser Team</h2>
        <div className={styles.grid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.card}>
              <div className={styles.photo}>
                <img src={member.image} alt={member.name} loading="lazy" />
              </div>
              <div className={styles.info}>
                <h3>{member.name}</h3>
                <p className={styles.role}>{member.role}</p>
                <p>{member.bio}</p>
                <div className={styles.tags}>
                  {member.focus.map((tag) => (
                    <span key={tag}>{tag}</span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default About;