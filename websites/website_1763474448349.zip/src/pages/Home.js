import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';
import blogPosts from '../data/blogPosts';

const statsData = [
  { label: 'Finden klare berufliche Richtung nach 4 Wochen', value: 78 },
  { label: 'Entwickeln neue Perspektiven auf KI', value: 92 },
  { label: 'Fühlen sich sicherer in Gesprächen mit Arbeitgebern', value: 81 },
  { label: 'Bleiben mit uns in Kontakt für weiteren Austausch', value: 64 }
];

const testimonials = [
  {
    name: 'Tamina, Produktmanagerin',
    quote:
      'Vor Naverilano hatte ich Angst, dass KI meinen Job ersetzt. Jetzt kenne ich meine Stärken und habe ein konkretes Weiterbildungsziel – ohne Panik.',
    role: 'Wechsel von E-Commerce zu Digital Health'
  },
  {
    name: 'Levent, Industriemechaniker',
    quote:
      'Mir wurde klar, welche Teile meiner Arbeit künftig automatisiert werden könnten. Entscheidend: Ich sehe jetzt, wo ich weiterlernen will und welche Aufgaben weiterhin menschlich bleiben.',
    role: 'Neuorientierung in Richtung Instandhaltung & KI-gestützte Fertigung'
  },
  {
    name: 'Mara, Sozialwissenschaftlerin',
    quote:
      'Der Berufe-Scan von Naverilano hat mir geholfen, gezielt Gespräche mit Menschen zu führen, die bereits mit KI arbeiten. Das senkt meinen Stress enorm.',
    role: 'Schritt in die Beratung für Zukunftskompetenzen'
  }
];

const teamPreview = [
  {
    name: 'Leonie Krämer',
    role: 'Berufs- und Laufbahnexpertin',
    focus: 'Übersetzt Zukunftstrends in konkrete Schritte für Dich.',
    image: 'https://picsum.photos/400/400?random=31'
  },
  {
    name: 'Daniel Vogt',
    role: 'Arbeitsmarktforscher',
    focus: 'Analysiert, wie KI Branchen verändert – verständlich und nahbar.',
    image: 'https://picsum.photos/400/400?random=32'
  },
  {
    name: 'Sara Bennani',
    role: 'Coach für Lernstrategien',
    focus: 'Hilft Dir, ohne Überforderung dranzubleiben.',
    image: 'https://picsum.photos/400/400?random=33'
  }
];

const projectsData = [
  {
    id: 1,
    title: 'Neuausrichtung im Maschinenbau',
    category: 'Karrierewechsel',
    description:
      'Begleitung eines Teams von Facharbeitenden bei der Einführung KI-gestützter Wartungsprozesse. Fokus auf Rollenklärung und Kompetenzaufbau.',
    image: 'https://picsum.photos/1200/800?random=41'
  },
  {
    id: 2,
    title: 'Weiterbildungspfad für kaufmännische Mitarbeitende',
    category: 'Weiterbildung',
    description:
      'Entwicklung eines vierwöchigen Lernplans mit begleitender Reflexion, um KI als Assistenzwerkzeug zu nutzen, nicht als Konkurrenz.',
    image: 'https://picsum.photos/1200/800?random=42'
  },
  {
    id: 3,
    title: 'Berufsorientierung für Studienabsolvent:innen',
    category: 'Berufsorientierung',
    description:
      'Workshops zu Zukunftsberufen mit Schwerpunkt menschenzentrierte KI, inklusive Praxisgesprächen mit Unternehmen.',
    image: 'https://picsum.photos/1200/800?random=43'
  },
  {
    id: 4,
    title: 'Neuaufstellung eines Kundenservice-Teams',
    category: 'Karrierewechsel',
    description:
      'Identifikation hybrider Rollen zwischen Mensch und KI, Aufbau neuer Routinen für Gespräche mit Kund:innen.',
    image: 'https://picsum.photos/1200/800?random=44'
  }
];

const faqItems = [
  {
    question: 'Wer profitiert von Naverilano am meisten?',
    answer:
      'Menschen in Deutschland, die beruflich an einem Wendepunkt stehen – egal ob Berufsstart, Wechsel oder Weiterbildung. Wir konzentrieren uns besonders auf Branchen, die von KI spürbar beeinflusst werden.'
  },
  {
    question: 'Welche Rolle spielt KI bei Euch konkret?',
    answer:
      'Wir analysieren gemeinsam, welche Aufgaben automatisiert werden können, welche Kompetenzen bleiben und wie Du Deinen Platz definierst. KI ist Werkzeug, nicht Endgegner.'
  },
  {
    question: 'Brauche ich Vorwissen in Technik?',
    answer:
      'Nein. Wir setzen dort an, wo Du stehst. Entscheidender ist Deine Bereitschaft, Neues auszuprobieren, Fragen zu stellen und Schritt für Schritt Klarheit aufzubauen.'
  },
  {
    question: 'Wie läuft die Zusammenarbeit ab?',
    answer:
      'Du startest mit einer Standortbestimmung. Danach wählst Du passende Programme oder Tools. Wir begleiten Dich mit klaren Check-ins, Reflexionsfragen und Materialien zum Dranbleiben.'
  }
];

const Home = () => {
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Alle');
  const [openFaq, setOpenFaq] = useState(null);
  const navigate = useNavigate();

  const categories = useMemo(() => ['Alle', ...new Set(projectsData.map((p) => p.category))], []);

  useEffect(() => {
    const duration = 1800;
    const start = performance.now();
    const animate = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      setStats(
        statsData.map((item, index) => Math.floor(progress * item.value + (progress < 1 ? Math.random() * 2 : 0)))
      );
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    requestAnimationFrame(animate);
  }, []);

  const filteredProjects =
    activeCategory === 'Alle'
      ? projectsData
      : projectsData.filter((project) => project.category === activeCategory);

  const latestPosts = blogPosts.slice(0, 3);

  const nextTestimonial = () => {
    setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setActiveTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <>
      <Helmet>
        <title>Naverilano | Klarheit für Deinen beruflichen Weg im KI-Zeitalter</title>
        <meta
          name="description"
          content="Finde Deinen Weg im Job, auch mit KI: Naverilano begleitet Dich bei Berufsorientierung, Karrierewechsel und Weiterbildung in Deutschland."
        />
      </Helmet>
      <div className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroBadge}>Berufsorientierung im KI-Zeitalter</p>
          <h1>Finde Deinen Weg im Job – auch mit KI.</h1>
          <p className={styles.heroText}>
            Die Arbeitswelt verändert sich rasant. Wir helfen Dir, Deine Stärken klar zu sehen, KI bewusst einzusetzen
            und angstfrei ins Gespräch mit Arbeitgebern zu gehen.
          </p>
          <div className={styles.heroActions}>
            <Link to="/guide" className={styles.ctaPrimary}>
              Jetzt starten
            </Link>
            <Link to="/programs" className={styles.ctaSecondary}>
              Deinen nächsten Schritt entdecken
            </Link>
          </div>
          <div className={styles.heroStats}>
            {statsData.map((item, index) => (
              <div key={item.label} className={styles.heroStat}>
                <p className={styles.heroStatValue}>{stats[index]}%</p>
                <p className={styles.heroStatLabel}>{item.label}</p>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/1600/900?random=11"
            alt="Berufliche Zusammenarbeit mit KI-Tools"
            className={styles.heroImage}
            loading="lazy"
          />
        </div>
      </div>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.aiChange}>
            <div>
              <h2>Wie sich Arbeit durch KI wirklich verändert</h2>
              <p>
                Neue Tools übernehmen Routinen, aber sie ersetzen nicht Deine Persönlichkeit. Wir schaffen Klarheit
                darüber, welche Tätigkeiten stabil bleiben, welche neu entstehen und wie Du Deine Rolle bewusst
                gestaltest.
              </p>
            </div>
            <ul className={styles.aiList}>
              <li>
                <span>1</span>
                <div>
                  <p className={styles.aiTitle}>Arbeiten mit KI bedeutet Zusammenarbeit</p>
                  <p>Menschen, die Fragen stellen, prüfen und gestalten, werden wichtiger denn je.</p>
                </div>
              </li>
              <li>
                <span>2</span>
                <div>
                  <p className={styles.aiTitle}>Kompetenzen verschieben sich</p>
                  <p>
                    Analysefähigkeiten, Kommunikation und Lernbereitschaft sind zentrale Anker – sie wachsen mit Dir.
                  </p>
                </div>
              </li>
              <li>
                <span>3</span>
                <div>
                  <p className={styles.aiTitle}>Sicherheit entsteht durch Orientierung</p>
                  <p>
                    Wer seinen Standort kennt, trifft ruhigere Entscheidungen. Deshalb starten wir genau dort:
                    realistisch, empathisch, strukturiert.
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.whiteSection}`}>
        <div className="container">
          <h2>Was Dir Naverilano bringt</h2>
          <div className={styles.benefitsGrid}>
            <article>
              <h3>Klare Sicht auf Deine Stärken</h3>
              <p>
                Wir verbinden Deine Erfahrungen mit dem, was der Markt braucht – ohne Deine Persönlichkeit zu verbiegen.
              </p>
            </article>
            <article>
              <h3>Gelassenheit im Umgang mit KI</h3>
              <p>Du verstehst, was KI konkret kann und wo Du unersetzlich bleibst. So entsteht echte Sicherheit.</p>
            </article>
            <article>
              <h3>Konkrete nächste Schritte</h3>
              <p>Strukturierte Pläne helfen Dir, fokussiert zu bleiben und neue Routinen zu etablieren.</p>
            </article>
            <article>
              <h3>Gemeinschaft statt Alleingang</h3>
              <p>Du findest Menschen, die ähnliche Fragen haben, und profitierst von ehrlichem Austausch.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.topicsHead}>
            <h2>Themen, die wir gemeinsam angehen</h2>
            <p>
              Du musst nicht alles auf einmal klären. Wir zerlegen Deine Fragen in gut bewältigbare Etappen – und bleiben
              nah dran.
            </p>
          </div>
          <div className={styles.topicsGrid}>
            <article>
              <h3>Berufsorientierung</h3>
              <p>Standort bestimmen, Stärken verstehen, passende Rollen entdecken.</p>
            </article>
            <article>
              <h3>Karrierewechsel</h3>
              <p>Sanfte Übergänge gestalten, Netzwerke nutzen und neue Arbeitsbereiche testen.</p>
            </article>
            <article>
              <h3>Weiterbildung</h3>
              <p>Gezielt lernen, ohne Dich zu überfordern – mit Fokus auf Zukunftskompetenzen.</p>
            </article>
            <article>
              <h3>Arbeit mit KI</h3>
              <p>Wissen, wann Du KI einsetzt, wann Du stopp sagst und wie Du Verantwortung behältst.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.whySection}`}>
        <div className="container">
          <div className={styles.whyHeader}>
            <h2>Warum Naverilano</h2>
            <p>
              Wir verbinden fundierte Arbeitsmarktdaten mit Empathie. Keine leeren Versprechen, sondern realistische,
              machbare Schritte.
            </p>
          </div>
          <div className={styles.whyGrid}>
            <article>
              <h3>Realistisch & nahbar</h3>
              <p>Wir kennen Betriebe und Teams. Unsere Empfehlungen sind geprüft, nicht theoretisch.</p>
            </article>
            <article>
              <h3>Fokus auf Umsetzung</h3>
              <p>Du bekommst klare Aufgaben, Reflexionsfragen und Check-ins. So bleibt Deine Motivation stabil.</p>
            </article>
            <article>
              <h3>Sicherheit im Datenschutz</h3>
              <p>Deine Daten bleiben in Deutschland und werden streng nach DSGVO behandelt.</p>
            </article>
            <article>
              <h3>Kompetenzteams</h3>
              <p>Arbeitsmarktforschung, psychologische Beratung, Lernstrategien – vereint für Dich.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.processHeader}>
            <h2>So arbeiten wir mit Dir</h2>
            <p>Fünf Schritte, die Orientierung schaffen – flexibel, menschlich, strukturiert.</p>
          </div>
          <div className={styles.processGrid}>
            <div>
              <span>1</span>
              <p className={styles.processTitle}>Standort verstehen</p>
              <p>Wir schauen auf Deine Situation, Erwartungen und Grenzen.</p>
            </div>
            <div>
              <span>2</span>
              <p className={styles.processTitle}>Stärken & Interessen schärfen</p>
              <p>Mit Reflexionsfragen und Feedback aus Deinem Umfeld.</p>
            </div>
            <div>
              <span>3</span>
              <p className={styles.processTitle}>KI-Auswirkungen einordnen</p>
              <p>Wir erstellen ein realistisches Bild der Veränderungen in Deinem Feld.</p>
            </div>
            <div>
              <span>4</span>
              <p className={styles.processTitle}>Richtungen auswählen</p>
              <p>Du entscheidest, welche Optionen Dich anziehen – mit unseren Analysen als Basis.</p>
            </div>
            <div>
              <span>5</span>
              <p className={styles.processTitle}>Erste Schritte planen</p>
              <p>Gemeinsam definieren wir Lernziele, Gespräche und Feedback-Schleifen.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.servicesSection}`}>
        <div className="container">
          <div className={styles.servicesHeader}>
            <h2>Programme, die Dich ins Tun bringen</h2>
            <p>Wähle das Format, das zu Deiner Situation passt – wir begleiten Dich fokussiert.</p>
          </div>
          <div className={styles.servicesGrid}>
            <article>
              <h3>7-Tage-Klarheits-Check</h3>
              <p>Bewusst hinschauen, sortieren, priorisieren – kompakt und intensiv.</p>
              <button onClick={() => navigate('/programs')} aria-label="Mehr zum 7-Tage-Klarheits-Check">
                Mehr erfahren
              </button>
            </article>
            <article>
              <h3>Berufe-Scan im KI-Zeitalter</h3>
              <p>Wir analysieren Chancenfelder und Zukunftsrollen, die zu Dir passen.</p>
              <button onClick={() => navigate('/programs')} aria-label="Mehr zum Berufe-Scan">
                Mehr erfahren
              </button>
            </article>
            <article>
              <h3>30 Tage sanfter Karrierewechsel</h3>
              <p>Ein Month-by-Month Ansatz mit realistischen Experimenten und Gesprächen.</p>
              <button onClick={() => navigate('/programs')} aria-label="Mehr zum Karrierewechselprogramm">
                Mehr erfahren
              </button>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <h2>Einblicke in unsere Projekte</h2>
            <div className={styles.projectFilters}>
              {categories.map((category) => (
                <button
                  type="button"
                  key={category}
                  className={`${styles.filterButton} ${activeCategory === category ? styles.filterActive : ''}`}
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img src={project.image} alt={`Projekt: ${project.title}`} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectTag}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.testimonialsSection}`}>
        <div className="container">
          <div className={styles.testimonialHeader}>
            <h2>Was Teilnehmende erzählen</h2>
            <div className={styles.testimonialControls}>
              <button onClick={prevTestimonial} aria-label="Vorheriges Feedback">
                ←
              </button>
              <button onClick={nextTestimonial} aria-label="Nächstes Feedback">
                →
              </button>
            </div>
          </div>
          <div className={styles.testimonialCard}>
            <p className={styles.testimonialQuote}>{testimonials[activeTestimonial].quote}</p>
            <p className={styles.testimonialName}>{testimonials[activeTestimonial].name}</p>
            <p className={styles.testimonialRole}>{testimonials[activeTestimonial].role}</p>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.teamSection}`}>
        <div className="container">
          <div className={styles.teamHeader}>
            <h2>Menschen hinter Naverilano</h2>
            <p>Wir sind ein interdisziplinäres Team mit Wurzeln in Beratung, Forschung und Lernen.</p>
          </div>
          <div className={styles.teamGrid}>
            {teamPreview.map((member) => (
              <article key={member.name}>
                <div className={styles.teamImageWrapper}>
                  <img src={member.image} alt={`Teammitglied ${member.name}`} loading="lazy" />
                </div>
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p>{member.focus}</p>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.teamCTA}>
            <Link to="/about">Mehr über unser Team erfahren</Link>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.blogHeader}>
            <h2>Aktuelle Einblicke</h2>
            <p>Artikel, die Dir helfen, ruhig zu bleiben und Klarheit zu gewinnen.</p>
          </div>
          <div className={styles.blogGrid}>
            {latestPosts.map((post) => (
              <article key={post.slug} className={styles.blogCard}>
                <span className={styles.blogCategory}>{post.category}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <div className={styles.blogMeta}>
                  <span>{post.readingTime} Min. Lesezeit</span>
                  <Link to={`/blog/${post.slug}`} aria-label={`Weiterlesen: ${post.title}`}>
                    Weiterlesen →
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.blogCTA}>
            <Link to="/blog">Alle Artikel ansehen</Link>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.faqSection}`}>
        <div className="container">
          <div className={styles.faqHeader}>
            <h2>Häufige Fragen</h2>
            <p>Wenn Du unsicher bist, melde Dich. Wir nehmen Deine Situation ernst.</p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, idx) => (
              <div key={item.question} className={styles.faqItem}>
                <button
                  className={styles.faqButton}
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  aria-expanded={openFaq === idx}
                  aria-controls={`faq-panel-${idx}`}
                >
                  <span>{item.question}</span>
                  <span>{openFaq === idx ? '−' : '+'}</span>
                </button>
                <div
                  id={`faq-panel-${idx}`}
                  className={`${styles.faqPanel} ${openFaq === idx ? styles.faqPanelOpen : ''}`}
                >
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.ctaFinal}`}>
        <div className="container">
          <div className={styles.ctaCard}>
            <h2>Bereit für Deinen nächsten Schritt?</h2>
            <p>
              Lass uns gemeinsam anschauen, wo Du stehst – und wie Du mit KI Deinen Weg selbstbewusst gestaltest.
              Unkompliziert, menschlich, konkret.
            </p>
            <div className={styles.ctaButtons}>
              <Link to="/contact" className={styles.ctaPrimary}>
                Gespräch anfragen
              </Link>
              <Link to="/guide" className={styles.ctaSecondary}>
                Leitfaden ansehen
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;