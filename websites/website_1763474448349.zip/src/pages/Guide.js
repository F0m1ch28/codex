import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Guide.module.css';

const steps = [
  {
    title: 'Standortbestimmung',
    description:
      'Du reflektierst Deine aktuelle Situation, Rahmenbedingungen und was Dich wirklich beschäftigt. Wir nutzen gezielte Fragen sowie eine klare Status-Checkliste.',
    bullets: ['Was läuft gut, was blockiert?', 'Welche Bedürfnisse sind akut?', 'Welche Ressourcen stehen bereit?']
  },
  {
    title: 'Stärken & Interessen schärfen',
    description:
      'Gemeinsam finden wir Muster: Welche Aufgaben füllen Dich? Wofür bekommst Du Anerkennung? Wir nutzen Feedback und Kompetenzkarten.',
    bullets: ['Persönliche Review Deiner Projekte', 'Feedback aus Deinem Umfeld', 'Ableitung klarer Stärke-Statements']
  },
  {
    title: 'KI-Auswirkungen verstehen',
    description:
      'Wir analysieren, wie KI Dein Feld verändert. Was wird automatisiert, welche Menschen braucht es künftig? So erkennst Du Chancen und Grenzen.',
    bullets: ['Branchenradar zu KI-Einfluss', 'Analyse von Zukunftsrollen', 'Bewertung: Wo bleibst Du wichtig?']
  },
  {
    title: 'Richtungen auswählen',
    description:
      'Du wählst 2–3 Optionen, die Dich anziehen. Wir vergleichen sie nach Passung, Lernaufwand und Stabilität. Anschließend priorisieren wir.',
    bullets: ['Kriterien festlegen', 'Optionen vergleichen', 'Fokus festlegen']
  },
  {
    title: 'Erste Schritte planen',
    description:
      'Wir definieren konkrete Experimente: Gespräche, Micro-Learnings, Aufgaben im Job. Mit Check-ins bleibst Du dran – ohne Dich zu überfordern.',
    bullets: ['Mini-Experimente planen', 'Termine für Feedback setzen', 'Erfolge & Learnings dokumentieren']
  }
];

const Guide = () => (
  <>
    <Helmet>
      <title>Leitfaden | Naverilano</title>
      <meta
        name="description"
        content="Der Naverilano-Leitfaden führt Dich Schritt für Schritt durch Berufsorientierung, KI-Verständnis und konkrete Planung."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Dein Leitfaden durch die berufliche Veränderung</h1>
        <p>
          Berufsorientierung ist kein Sprint. Unser Leitfaden zeigt Dir, wie Du systematisch Klarheit gewinnst – ohne
          Druck, dafür mit Wirkung.
        </p>
      </div>
    </section>

    <section className={styles.stepsSection}>
      <div className="container">
        <div className={styles.stepsGrid}>
          {steps.map((step, index) => (
            <article key={step.title} className={styles.stepCard}>
              <span className={styles.stepNumber}>{index + 1}</span>
              <h2>{step.title}</h2>
              <p>{step.description}</p>
              <ul>
                {step.bullets.map((bullet) => (
                  <li key={bullet}>{bullet}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
        <div className={styles.cta}>
          <h3>Bereit für den nächsten Schritt?</h3>
          <p>Schau Dir an, welche Programme Dich unterstützen oder melde Dich direkt bei uns.</p>
          <div className={styles.ctaActions}>
            <Link to="/programs">Programme ansehen</Link>
            <Link to="/contact" className={styles.secondary}>
              Kontakt aufnehmen
            </Link>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Guide;