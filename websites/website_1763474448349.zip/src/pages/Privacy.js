import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Datenschutz (DSGVO) | Naverilano</title>
      <meta
        name="description"
        content="Naverilano schützt Deine Daten nach DSGVO. Erfahre mehr über unsere Datenschutzrichtlinien."
      />
    </Helmet>
    <section className={styles.page}>
      <div className="container">
        <h1>Datenschutzerklärung</h1>
        <p>
          Wir nehmen den Schutz Deiner persönlichen Daten sehr ernst. Deine Daten werden vertraulich und entsprechend
          den gesetzlichen Datenschutzvorschriften sowie dieser Datenschutzerklärung behandelt.
        </p>

        <section>
          <h2>Verantwortliche Stelle</h2>
          <p>
            Naverilano<br />
            Friedrichstraße 123, 10117 Berlin<br />
            E-Mail: <a href="mailto:kontakt@naverilano.de">kontakt@naverilano.de</a>
          </p>
        </section>

        <section>
          <h2>Erhebung und Verarbeitung personenbezogener Daten</h2>
          <p>
            Wir erheben personenbezogene Daten, wenn Du uns diese freiwillig mitteilst, etwa über das Kontaktformular
            oder per E-Mail. Diese Daten verwenden wir ausschließlich zur Bearbeitung Deiner Anfrage.
          </p>
        </section>

        <section>
          <h2>Cookies</h2>
          <p>
            Unsere Website nutzt ausschließlich technisch notwendige Cookies. Diese dienen der Bereitstellung der
            Website und enthalten keine personenbezogenen Informationen. Eine Analyse Deines Nutzungsverhaltens findet
            nicht statt.
          </p>
        </section>

        <section>
          <h2>Speicherdauer</h2>
          <p>
            Wir speichern personenbezogene Daten nur so lange, wie es für die Bearbeitung Deiner Anfrage erforderlich
            ist oder gesetzliche Aufbewahrungspflichten bestehen.
          </p>
        </section>

        <section>
          <h2>Rechte Betroffener</h2>
          <ul>
            <li>Auskunft über Deine gespeicherten personenbezogenen Daten</li>
            <li>Berichtigung unrichtiger Daten</li>
            <li>Löschung Deiner Daten, sofern keine gesetzlichen Pflichten entgegenstehen</li>
            <li>Einschränkung der Verarbeitung und Widerspruch gegen Verarbeitung</li>
          </ul>
          <p>
            Bitte richte Deine Anfrage an <a href="mailto:kontakt@naverilano.de">kontakt@naverilano.de</a>. Wir
            beantworten sie innerhalb der gesetzlichen Frist.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default Privacy;