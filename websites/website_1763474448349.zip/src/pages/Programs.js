import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programs.module.css';

const programs = [
  {
    title: '7-Tage-Klarheits-Check',
    description:
      'Sieben Tage Fokus für Deinen Standort. Du klärst Erwartungen, definierst Stärken und legst Prioritäten fest – ideal, wenn Du schnelle Orientierung brauchst.',
    duration: '7 Tage',
    audience: 'Menschen vor beruflichen Entscheidungen oder Rückkehr nach Pause'
  },
  {
    title: 'Berufe-Scan im KI-Zeitalter',
    description:
      'Wir analysieren Deine Branche, recherchieren Zukunftsrollen und prüfen, wie KI Aufgaben verändert. Du erhältst konkrete Szenarien und Gesprächsleitfäden.',
    duration: '2 Wochen',
    audience: 'Fach- und Führungskräfte, die ihr Berufsfeld aktiv gestalten möchten'
  },
  {
    title: '30 Tage sanfter Karrierewechsel',
    description:
      'Ein strukturierter Pfad mit wöchentlichen Check-ins, Lernaufgaben und Netzwerkgesprächen. Du testest neue Rollen und bleibst mental stabil.',
    duration: '30 Tage',
    audience: 'Berufstätige, die Schritt für Schritt in eine neue Richtung gehen wollen'
  }
];

const Programs = () => (
  <>
    <Helmet>
      <title>Programme | Naverilano</title>
      <meta
        name="description"
        content="Wähle das Naverilano-Programm, das Dich im beruflichen Wandel mit KI am besten unterstützt."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Programme für Deinen beruflichen Weg</h1>
        <p>
          Struktur schafft Ruhe. Unsere Programme sind bewusst gestaltet, damit Du fokussiert vorankommst – realistisch,
          empathisch, wirksam.
        </p>
      </div>
    </section>

    <section className={styles.programsSection}>
      <div className="container">
        <div className={styles.grid}>
          {programs.map((program) => (
            <article key={program.title} className={styles.card}>
              <h2>{program.title}</h2>
              <p>{program.description}</p>
              <ul>
                <li>
                  <strong>Dauer:</strong> {program.duration}
                </li>
                <li>
                  <strong>Für:</strong> {program.audience}
                </li>
              </ul>
              <button type="button" className={styles.button}>
                Programm starten
              </button>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Programs;