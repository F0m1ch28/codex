import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Imprint.module.css';

const Imprint = () => (
  <>
    <Helmet>
      <title>Impressum | Naverilano</title>
      <meta
        name="description"
        content="Impressum von Naverilano – Angaben gemäß § 5 TMG für das Angebot zur Berufsorientierung in Deutschland."
      />
    </Helmet>
    <section className={styles.page}>
      <div className="container">
        <h1>Impressum</h1>
        <section>
          <h2>Angaben gemäß § 5 TMG</h2>
          <p>
            Naverilano<br />
            Friedrichstraße 123<br />
            10117 Berlin<br />
            Deutschland
          </p>
        </section>

        <section>
          <h2>Kontakt</h2>
          <p>
            Telefon: <a href="tel:+49301234567">+49 30 123 45 67</a>
            <br />
            E-Mail: <a href="mailto:kontakt@naverilano.de">kontakt@naverilano.de</a>
          </p>
        </section>

        <section>
          <h2>Vertretungsberechtigt</h2>
          <p>Leonie Krämer und Daniel Vogt</p>
        </section>

        <section>
          <h2>Umsatzsteuer-ID</h2>
          <p>Beantragt. Wird nachgereicht, sobald verfügbar.</p>
        </section>

        <section>
          <h2>Streitschlichtung</h2>
          <p>
            Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit:{' '}
            <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noreferrer">
              https://ec.europa.eu/consumers/odr
            </a>
            . Wir sind nicht verpflichtet und nicht bereit, an Streitbeilegungsverfahren vor einer
            Verbraucherschlichtungsstelle teilzunehmen.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default Imprint;