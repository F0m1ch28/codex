import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';
import blogPosts from '../data/blogPosts';

const Blog = () => (
  <>
    <Helmet>
      <title>Blog | Naverilano</title>
      <meta
        name="description"
        content="Der Naverilano-Blog liefert Einblicke zu Berufsorientierung, Karrierewechseln und dem Umgang mit KI im Arbeitsalltag."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Blog</h1>
        <p>Erfahrungen, Analysen und praktische Tipps für Deinen Weg mit KI.</p>
      </div>
    </section>

    <section className={styles.blogSection}>
      <div className="container">
        <div className={styles.grid}>
          {blogPosts.map((post) => (
            <article key={post.slug} className={styles.card}>
              <p className={styles.category}>{post.category}</p>
              <h2>{post.title}</h2>
              <p className={styles.excerpt}>{post.excerpt}</p>
              <div className={styles.meta}>
                <span>{post.readingTime} Min. Lesezeit</span>
                <Link to={`/blog/${post.slug}`}>Weiterlesen →</Link>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Blog;