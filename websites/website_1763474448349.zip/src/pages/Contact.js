import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) {
      newErrors.name = 'Bitte gib Deinen Namen ein.';
    }
    if (!form.email.trim()) {
      newErrors.email = 'Bitte gib Deine E-Mail-Adresse ein.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = 'Bitte gib eine gültige E-Mail-Adresse ein.';
    }
    if (!form.message.trim()) {
      newErrors.message = 'Bitte formuliere Dein Anliegen.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setErrors((prev) => ({ ...prev, [e.target.name]: '' }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      setSubmitted(true);
      setForm({ name: '', email: '', message: '' });
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Naverilano</title>
        <meta
          name="description"
          content="Melde Dich bei Naverilano: Wir begleiten Dich auf Deinem beruflichen Weg mit KI – empathisch und strukturiert."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Wir sind für Dich da</h1>
          <p>
            Du hast Fragen oder möchtest Deinen Einstieg planen? Schreib uns – wir antworten innerhalb von zwei
            Werktagen.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.formGroup}>
                <label htmlFor="name">Name *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="email">E-Mail *</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="message">Nachricht *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={form.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className={styles.submit}>
                Nachricht senden
              </button>
              {submitted && <p className={styles.success}>Danke für Deine Nachricht! Wir melden uns bald bei Dir.</p>}
            </form>

            <div className={styles.info}>
              <h2>Kontaktdaten</h2>
              <ul>
                <li>
                  <strong>Adresse:</strong> Friedrichstraße 123, 10117 Berlin
                </li>
                <li>
                  <strong>E-Mail:</strong>{' '}
                  <a href="mailto:kontakt@naverilano.de">kontakt@naverilano.de</a>
                </li>
                <li>
                  <strong>Telefon:</strong> <a href="tel:+49301234567">+49 30 123 45 67</a>
                </li>
              </ul>
              <div className={styles.map}>
                <img
                  src="https://picsum.photos/800/600?random=61"
                  alt="Symbolische Karte von Berlin"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;