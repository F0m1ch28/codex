import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './BlogArticle.module.css';
import blogPosts from '../data/blogPosts';

const BlogArticle = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const article = blogPosts.find((post) => post.slug === slug);

  if (!article) {
    return (
      <section className={styles.notFound}>
        <div className="container">
          <h1>Artikel nicht gefunden</h1>
          <p>Vielleicht wurde der Beitrag verschoben. Schau Dich im Blog um.</p>
          <button type="button" onClick={() => navigate('/blog')}>
            Zurück zum Blog
          </button>
        </div>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{article.title} | Naverilano</title>
        <meta name="description" content={article.excerpt} />
      </Helmet>
      <article className={styles.article}>
        <div className={styles.hero}>
          <div className="container">
            <p className={styles.category}>{article.category}</p>
            <h1>{article.title}</h1>
            <div className={styles.meta}>
              <span>{article.date}</span>
              <span>{article.readingTime} Min. Lesezeit</span>
            </div>
          </div>
        </div>
        <div className={styles.body}>
          <div className="container">
            {article.content.map((block) => (
              <section key={block.heading} className={styles.block}>
                <h2>{block.heading}</h2>
                {block.paragraphs.map((paragraph) => (
                  <p key={paragraph.slice(0, 20)}>{paragraph}</p>
                ))}
                {block.list && (
                  <ul>
                    {block.list.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                )}
              </section>
            ))}
            <div className={styles.back}>
              <Link to="/blog">← Zurück zum Blog</Link>
            </div>
          </div>
        </div>
      </article>
    </>
  );
};

export default BlogArticle;