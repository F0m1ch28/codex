import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const serviceCards = [
  {
    title: 'Orientierungs-Session',
    description:
      '60 Minuten Fokus. Wir klären Deine aktuelle Lage, Deine Fragen und priorisieren mögliche Schritte. Ideal als Startpunkt.',
    details: [
      'Vorab-Fragen, damit wir vorbereitet sind',
      'Stärkenprofil in knackiger Zusammenfassung',
      'Konkrete To-dos für die nächsten 2 Wochen'
    ]
  },
  {
    title: 'Zukunftsrollen-Workshop',
    description:
      'Gemeinsam kartieren wir Rollen, die durch KI entstehen. Du bekommst klare Perspektiven und Entscheidungshilfen.',
    details: ['Arbeitsmarktrecherche', 'Rollenprofile inkl. Skill-Anforderungen', 'Gesprächsleitfäden für Netzwerkkontakte']
  },
  {
    title: 'Lernpfad-Design',
    description:
      'Wir entwickeln einen individuellen Lernplan, der in Deinen Alltag passt und Dir hilft, neue Fähigkeiten konsequent aufzubauen.',
    details: ['Priorisierte Lernziele', 'Wochenstruktur mit Check-ins', 'Reflexionsfragen für nachhaltige Umsetzung']
  },
  {
    title: 'Teamformate',
    description:
      'Beratung für Unternehmen und Teams, die Mitarbeitende im KI-Wandel begleiten möchten. Menschlich, fair und praxisnah.',
    details: ['Workshops & Talks', 'Materialpakete für Führungskräfte', 'Begleitung von Pilotprojekten']
  }
];

const Services = () => {
  const [active, setActive] = useState(0);

  return (
    <>
      <Helmet>
        <title>Angebote | Naverilano</title>
        <meta
          name="description"
          content="Entdecke die Angebote von Naverilano – von Orientierungs-Sessions bis zu Lernpfaden für Deinen beruflichen Wandel."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Unsere Angebote</h1>
          <p>
            Egal ob Du am Anfang stehst oder mitten im Wechsel: Wir bieten Formate, die Dich strukturiert begleiten –
            Schritt für Schritt.
          </p>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.tabs}>
              {serviceCards.map((card, index) => (
                <button
                  type="button"
                  key={card.title}
                  onClick={() => setActive(index)}
                  className={active === index ? styles.active : ''}
                  aria-expanded={active === index}
                >
                  {card.title}
                </button>
              ))}
            </div>
            <div className={styles.detailCard}>
              <h2>{serviceCards[active].title}</h2>
              <p>{serviceCards[active].description}</p>
              <ul>
                {serviceCards[active].details.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <button type="button" className={styles.primary}>
                Mehr Informationen anfragen
              </button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;