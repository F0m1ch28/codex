import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Legal = () => (
  <>
    <Helmet>
      <title>Rechtliche Hinweise | Naverilano</title>
      <meta
        name="description"
        content="Rechtliche Hinweise von Naverilano: Informationen zu Nutzung, Haftung und Urheberrecht."
      />
    </Helmet>
    <section className={styles.page}>
      <div className="container">
        <h1>Rechtliche Hinweise</h1>
        <p>
          Diese Website dient der Bereitstellung von Informationen über Naverilano und unsere Programme. Wir achten auf
          inhaltliche Richtigkeit, übernehmen jedoch keine Haftung für Aktualität, Vollständigkeit oder externe Links.
        </p>

        <section>
          <h2>Haftung für Inhalte</h2>
          <p>
            Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten verantwortlich. Nach
            §§ 8 bis 10 TMG sind wir jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde Informationen zu
            überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen. Verpflichtungen
            zur Entfernung oder Sperrung der Nutzung von Informationen nach den allgemeinen Gesetzen bleiben hiervon
            unberührt.
          </p>
        </section>

        <section>
          <h2>Haftung für Links</h2>
          <p>
            Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. Daher
            können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist
            stets der jeweilige Anbieter oder Betreiber verantwortlich.
          </p>
        </section>

        <section>
          <h2>Urheberrecht</h2>
          <p>
            Die durch Naverilano erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen Urheberrecht.
            Beiträge Dritter sind als solche gekennzeichnet. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art
            der Verwertung bedürfen der schriftlichen Zustimmung von Naverilano.
          </p>
        </section>

        <section>
          <h2>Kontakt</h2>
          <p>
            Bei rechtlichen Fragen wende Dich bitte an{' '}
            <a href="mailto:kontakt@naverilano.de">kontakt@naverilano.de</a>.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default Legal;