```javascript
document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.getElementById('navMenu');
  const navLinks = document.querySelectorAll('.nav-link');
  const header = document.querySelector('.site-header');
  const metrics = {
    sync: document.querySelector('[data-metric="sync"]'),
    horizon: document.querySelector('[data-metric="horizon"]'),
    alignment: document.querySelector('[data-metric="alignment"]')
  };
  const streamFeed = document.getElementById('streamFeed');
  const roiForm = document.getElementById('roiForm');
  const contactForm = document.getElementById('contactForm');
  const formFeedback = document.getElementById('formFeedback');
  const cookieBanner = document.getElementById('cookieBanner');
  const acceptCookies = document.getElementById('acceptCookies');
  const declineCookies = document.getElementById('declineCookies');
  const activateAudio = document.getElementById('activateAudio');
  const launchDemo = document.getElementById('launchDemo');
  const currentYearEl = document.getElementById('currentYear');
  const yearTerms = document.getElementById('currentYearTerms');
  const yearPrivacy = document.getElementById('currentYearPrivacy');
  const year404 = document.getElementById('currentYear404');

  const year = new Date().getFullYear();
  [currentYearEl, yearTerms, yearPrivacy, year404].forEach(el => {
    if (el) el.textContent = year;
  });

  /* Mobile nav toggle */
  if (navToggle) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('is-open');
    });
  }

  /* Smooth scroll for nav links */
  navLinks.forEach(link => {
    link.addEventListener('click', event => {
      const targetId = link.getAttribute('href');
      if (targetId.startsWith('#')) {
        event.preventDefault();
        const targetEl = document.querySelector(targetId);
        if (targetEl) {
          const offset = header.offsetHeight + 24;
          const elementPosition = targetEl.getBoundingClientRect().top + window.pageYOffset;
          window.scrollTo({
            top: elementPosition - offset,
            behavior: 'smooth'
          });
        }
        navMenu.classList.remove('is-open');
        navToggle?.setAttribute('aria-expanded', 'false');
      }
    });
  });

  /* Active navigation state */
  const observerOptions = {
    root: null,
    rootMargin: '-50% 0px -50% 0px',
    threshold: 0
  };

  const sectionIds = Array.from(navLinks)
    .map(link => link.getAttribute('href'))
    .filter(href => href.startsWith('#'));

  const sectionElements = sectionIds
    .map(id => document.querySelector(id))
    .filter(Boolean);

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const id = `#${entry.target.id}`;
      const link = document.querySelector(`.nav-link[href="${id}"]`);
      if (entry.isIntersecting && link) {
        navLinks.forEach(l => l.classList.remove('is-active'));
        link.classList.add('is-active');
      }
    });
  }, observerOptions);

  sectionElements.forEach(section => observer.observe(section));

  /* Metrics animation */
  setInterval(() => {
    const syncValue = (85 + Math.random() * 5).toFixed(1);
    const horizonValue = Math.floor(60 + Math.random() * 30);
    const alignmentValue = `${Math.floor(93 + Math.random() * 5)}%`;
    metrics.sync.textContent = syncValue;
    metrics.horizon.textContent = horizonValue;
    metrics.alignment.textContent = alignmentValue;
  }, 3200);

  /* Stream feed simulation */
  const streamMessages = [
    'Cognitive mesh aligning finance, clinical, and logistics signals...',
    'Predictive analytics refreshing with new macroeconomic indicators...',
    'Expert annotation applied to scenario cluster #47...',
    'Intelligent workflow deploying governance update to APAC node...',
    'Decision intelligence insight: variance stabilized within tolerance...'
  ];
  let streamIndex = 0;

  setInterval(() => {
    if (!streamFeed) return;
    const li = document.createElement('li');
    li.textContent = streamMessages[streamIndex % streamMessages.length];
    streamFeed.prepend(li);
    if (streamFeed.children.length > 5) {
      streamFeed.removeChild(streamFeed.lastElementChild);
    }
    streamIndex++;
  }, 4200);

  /* ROI calculator */
  if (roiForm) {
    const decisionVolume = document.getElementById('decisionVolume');
    const decisionVolumeValue = document.getElementById('decisionVolumeValue');
    const teamSize = document.getElementById('teamSize');
    const teamSizeValue = document.getElementById('teamSizeValue');
    const currentLatency = document.getElementById('currentLatency');
    const currentLatencyValue = document.getElementById('currentLatencyValue');
    const latencyReduction = document.getElementById('latencyReduction');
    const clarityUplift = document.getElementById('clarityUplift');
    const hoursReclaimed = document.getElementById('hoursReclaimed');

    const updateROI = () => {
      const dv = parseInt(decisionVolume.value, 10);
      const ts = parseInt(teamSize.value, 10);
      const cl = parseInt(currentLatency.value, 10);

      decisionVolumeValue.textContent = dv;
      teamSizeValue.textContent = ts;
      currentLatencyValue.textContent = cl;

      const reduction = Math.round(cl * 0.42);
      const clarity = Math.round((dv / 10) + (ts / 5));
      const hours = Math.round((dv * cl) / 24 * 0.35);

      latencyReduction.textContent = `-${reduction} hrs`;
      clarityUplift.textContent = `${clarity} pts`;
      hoursReclaimed.textContent = `${hours} hrs`;
    };

    [decisionVolume, teamSize, currentLatency].forEach(input => {
      input.addEventListener('input', updateROI);
    });

    updateROI();
  }

  /* Contact form validation */
  if (contactForm) {
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      let valid = true;
      contactForm.querySelectorAll('[required]').forEach(field => {
        if (!field.value.trim() || (field.type === 'checkbox' && !field.checked)) {
          field.classList.add('has-error');
          valid = false;
        } else {
          field.classList.remove('has-error');
        }
      });
      if (valid) {
        formFeedback.textContent = 'Thank you. Our enterprise team will connect within one business day.';
        formFeedback.style.color = 'var(--color-green)';
        contactForm.reset();
      } else {
        formFeedback.textContent = 'Please complete all required fields.';
        formFeedback.style.color = '#F87171';
      }
    });
  }

  /* Cookie banner */
  const consentStatus = localStorage.getItem('nsCookieConsent');
  if (!consentStatus && cookieBanner) {
    cookieBanner.style.display = 'block';
  }

  const handleConsent = value => {
    localStorage.setItem('nsCookieConsent', value);
    if (cookieBanner) cookieBanner.style.display = 'none';
    if (value === 'accepted') {
      initAnalytics();
    }
  };

  acceptCookies?.addEventListener('click', () => handleConsent('accepted'));
  declineCookies?.addEventListener('click', () => handleConsent('declined'));

  if (consentStatus === 'accepted') {
    initAnalytics();
  }

  function initAnalytics() {
    // Placeholder for analytics initialization
    console.info('Analytics initialized for NeuralSync AI.');
  }

  /* Neural canvas animation */
  const neuralCanvas = document.getElementById('neuralCanvas');
  if (neuralCanvas) {
    const ctx = neuralCanvas.getContext('2d');
    const resizeCanvas = () => {
      neuralCanvas.width = neuralCanvas.offsetWidth;
      neuralCanvas.height = neuralCanvas.offsetHeight;
    };
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    const nodes = Array.from({ length: 120 }, () => ({
      x: Math.random() * neuralCanvas.width,
      y: Math.random() * neuralCanvas.height,
      vx: (Math.random() - 0.5) * 0.6,
      vy: (Math.random() - 0.5) * 0.6
    }));

    const animate = () => {
      ctx.clearRect(0, 0, neuralCanvas.width, neuralCanvas.height);
      nodes.forEach(node => {
        node.x += node.vx;
        node.y += node.vy;

        if (node.x < 0 || node.x > neuralCanvas.width) node.vx *= -1;
        if (node.y < 0 || node.y > neuralCanvas.height) node.vy *= -1;

        ctx.beginPath();
        ctx.arc(node.x, node.y, 2.2, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(16, 185, 129, 0.65)';
        ctx.fill();
      });

      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i];
          const b = nodes[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          if (distance < 120) {
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.strokeStyle = `rgba(102,126,234,${1 - distance / 120})`;
            ctx.lineWidth = 0.6;
            ctx.stroke();
          }
        }
      }

      requestAnimationFrame(animate);
    };
    animate();
  }

  /* Dashboard canvas animation */
  const dashCanvas = document.getElementById('dashboardCanvas');
  if (dashCanvas) {
    const ctx = dashCanvas.getContext('2d');
    const drawDashboard = () => {
      const { width, height } = dashCanvas;
      ctx.clearRect(0, 0, width, height);

      ctx.fillStyle = 'rgba(247, 250, 252, 0.04)';
      ctx.fillRect(0, 0, width, height);

      ctx.strokeStyle = 'rgba(102, 126, 234, 0.2)';
      ctx.lineWidth = 1;
      for (let i = 0; i < 12; i++) {
        const y = (height / 12) * i;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      const drawWave = (color, amplitude, speed, offset) => {
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2.5;
        for (let x = 0; x <= width; x += 4) {
          const y = height / 2 + Math.sin((x + offset) * speed) * amplitude;
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      };

      const time = Date.now() / 1000;
      drawWave('rgba(16, 185, 129, 0.9)', 60, 0.02, time * 80);
      drawWave('rgba(102, 126, 234, 0.8)', 40, 0.015, time * 60);
      drawWave('rgba(246, 173, 85, 0.7)', 25, 0.03, time * 90);

      requestAnimationFrame(drawDashboard);
    };
    drawDashboard();
  }

  /* Web Audio API */
  let audioContext;
  let ambientOscillator;
  function createSoundscape() {
    if (!audioContext) {
      audioContext = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (ambientOscillator) {
      ambientOscillator.stop();
    }
    ambientOscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    ambientOscillator.type = 'sine';
    ambientOscillator.frequency.value = 220;
    gainNode.gain.value = 0.08;
    ambientOscillator.connect(gainNode).connect(audioContext.destination);
    ambientOscillator.start();
    setInterval(() => {
      if (ambientOscillator) {
        ambientOscillator.frequency.setValueAtTime(
          200 + Math.random() * 80,
          audioContext.currentTime + 0.1
        );
      }
    }, 2600);
  }

  activateAudio?.addEventListener('click', () => {
    if (localStorage.getItem('nsCookieConsent') === 'accepted') {
      createSoundscape();
      activateAudio.textContent = 'Neural Soundscape Active';
      activateAudio.disabled = true;
    } else {
      alert('Enable cookies to activate the neural soundscape.');
    }
  });

  launchDemo?.addEventListener('click', () => {
    alert('Interactive demo initialized. Scroll to explore real-time intelligence layers.');
  });

  /* Legal page nav active year update handled earlier */
});
```