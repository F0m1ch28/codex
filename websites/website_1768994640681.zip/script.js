document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
      navLinks.classList.toggle('active');
    });
  }

  const consentKey = 'arctexyCookieConsent';
  const banner = document.getElementById('cookie-banner');
  if (banner && !localStorage.getItem(consentKey)) {
    banner.classList.add('visible');
  }

  document.querySelectorAll('[data-cookie-accept]').forEach((button) => {
    button.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'accepted');
      if (banner) banner.classList.remove('visible');
    });
  });

  document.querySelectorAll('[data-cookie-decline]').forEach((button) => {
    button.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'declined');
      if (banner) banner.classList.remove('visible');
    });
  });

  const parallaxElements = document.querySelectorAll('[data-parallax]');
  if (parallaxElements.length > 0) {
    window.addEventListener('scroll', () => {
      const scrollY = window.scrollY;
      parallaxElements.forEach((element) => {
        const speed = parseFloat(element.dataset.parallaxSpeed || '0.4');
        element.style.backgroundPositionY = `calc(50% + ${scrollY * speed * -0.1}px)`;
      });
    });
  }

  const redirects = {
    '/history': '/samples.html',
    '/history/': '/samples.html',
    '/infrastructure': '/layers.html',
    '/infrastructure/': '/layers.html',
    '/systems': '/terrain.html',
    '/systems/': '/terrain.html',
    '/resilience': '/context.html',
    '/resilience/': '/context.html'
  };
  const path = window.location.pathname.replace(/\/+$/, '');
  if (redirects[path]) {
    window.location.replace(redirects[path]);
  }
});