import React from 'react';
import MetaManager from '../components/MetaManager';
import styles from './Course.module.css';

const modules = [
  { title: 'Module 1 · Setting the stage', focus: 'Clarify your objectives amid inflation and exchange-rate shifts.' },
  { title: 'Module 2 · Income resilience', focus: 'Map salary, freelance, or business income to realistic scenarios.' },
  { title: 'Module 3 · Expense lenses', focus: 'Use updated inflation categories to understand cost drivers.' },
  { title: 'Module 4 · ARS↔USD navigation', focus: 'Evaluate conversion needs, legal frameworks, and responsible communication.' },
  { title: 'Module 5 · Cushion building', focus: 'Design buffers accounting for regulated and free market adjustments.' },
  { title: 'Module 6 · Community workshop', focus: 'Apply learnings with peers, using anonymized real cases.' },
  { title: 'Module 7 · Iteration rituals', focus: 'Structure check-ins, alerts, and reflection prompts.' },
  { title: 'Module 8 · Presentation day', focus: 'Share your plan, get feedback, and plan your next iteration.' }
];

function CoursePage() {
  return (
    <div className={styles.page}>
      <MetaManager
        title="Course Overview | Tu Progreso Hoy Budget Playbook"
        description="Discover the Tu Progreso Hoy budgeting course modules, learning outcomes, and community features. Education-focused, no financial services."
        canonical="https://www.tuprogresohoy.com/course"
        alternate={[
          { hrefLang: 'es-AR', href: 'https://www.tuprogresohoy.com/es/course' }
        ]}
      />
      <section className={`${styles.section} ${styles.hero}`}>
        <div className="container">
          <h1>Budget Playbook: Argentina edition</h1>
          <p>
            A practical, eight-module course to establish and iterate your budget. We combine data exploration, guided
            exercises, and community dialogues. No miracle promises—just structured learning.
          </p>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.modulesGrid}>
            {modules.map((module) => (
              <article key={module.title} className={styles.moduleCard}>
                <h2>{module.title}</h2>
                <p>{module.focus}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.callout}`}>
        <div className="container">
          <h2>Double opt-in, transparent onboarding</h2>
          <p>
            We respect your inbox and your autonomy. Every enrollment includes a confirmation step, clear expectations, and
            direct support from our facilitators. Tu Progreso Hoy is an educational platform—no financial services provided.
          </p>
          <a className="btn btn-primary" href="/contact">
            Join the next cohort
          </a>
        </div>
      </section>
    </div>
  );
}

export default CoursePage;