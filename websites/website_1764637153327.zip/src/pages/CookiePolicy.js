import React from 'react';
import MetaManager from '../components/MetaManager';
import styles from './CookiePolicy.module.css';

function CookiePolicyPage() {
  return (
    <div className={styles.page}>
      <MetaManager
        title="Cookie Policy | Tu Progreso Hoy"
        description="Review how Tu Progreso Hoy uses cookies, including essential and optional analytics cookies."
        canonical="https://www.tuprogresohoy.com/cookies"
        alternate={[
          { hrefLang: 'es-AR', href: 'https://www.tuprogresohoy.com/es/cookies' }
        ]}
      />
      <section className={styles.section}>
        <div className="container">
          <h1>Cookie Policy</h1>

          <article className={styles.card}>
            <h2>Essential cookies</h2>
            <p>
              These cookies are required for security, authentication, and remembering your cookie preferences. They are
              always active and do not store personally identifying information beyond the session.
            </p>
          </article>

          <article className={styles.card}>
            <h2>Analytics cookies</h2>
            <p>
              With your consent, we use privacy-friendly analytics to understand how educational content performs. These
              cookies help us improve lessons and dashboards. You can opt in or out anytime via the cookie banner.
            </p>
          </article>

          <article className={styles.card}>
            <h2>Marketing cookies</h2>
            <p>
              We rarely use marketing cookies. When enabled by you, they help us share relevant updates about cohorts or
              webinars. No third-party ad networks are used.
            </p>
          </article>

          <article className={styles.card}>
            <h2>Managing preferences</h2>
            <p>
              Adjust your settings through the cookie banner or contact us at{' '}
              <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
}

export default CookiePolicyPage;