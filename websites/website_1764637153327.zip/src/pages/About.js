import React from 'react';
import MetaManager from '../components/MetaManager';
import styles from './About.module.css';

function AboutPage() {
  return (
    <div className={styles.page}>
      <MetaManager
        title="About Tu Progreso Hoy | Educational SaaS from Argentina"
        description="Learn about Tu Progreso Hoy’s mission, values, and team building an educational SaaS platform that brings Argentina economic data to life."
        canonical="https://www.tuprogresohoy.com/about"
        alternate={[
          { hrefLang: 'es-AR', href: 'https://www.tuprogresohoy.com/es/about' }
        ]}
      />
      <section className={`${styles.section} ${styles.hero}`}>
        <div className="container">
          <span className="badge">Our story</span>
          <h1>Grounded in Argentina, focused on clarity for every learner</h1>
          <p>
            Tu Progreso Hoy was born in Buenos Aires with a straightforward mission: to humanize economics for households,
            teams, and educators that need trustworthy context without exaggerated promises. We combine official data,
            vetted private sources, and learning design expertise to help people plan responsibly.
          </p>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.grid}>
            <article className={styles.card}>
              <h2>Why we exist</h2>
              <p>
                In Argentina, volatility is a given. We saw friends and colleagues overwhelmed by spreadsheets, news alerts,
                and contradictory opinions. The vision: build a platform that filters noise, offers contextual narratives,
                and empowers decisions through responsible education.
              </p>
            </article>
            <article className={styles.card}>
              <h2>Values we live by</h2>
              <ul className={styles.list}>
                <li>
                  <strong>Integrity over hype.</strong> No guaranteed outcomes, no aggressive tactics—just honest data and
                  thoughtful guidance.
                </li>
                <li>
                  <strong>Community-first design.</strong> Cohorts and forums are moderated to stay respectful, inclusive,
                  and bilingual when needed.
                </li>
                <li>
                  <strong>Accessibility.</strong> Whether you are a business owner or a teacher, you deserve clear,
                  understandable insights.
                </li>
              </ul>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.timelineSection}`}>
        <div className="container">
          <h2>Milestones that shaped Tu Progreso Hoy</h2>
          <div className={styles.timeline}>
            <div>
              <span className={styles.year}>2021</span>
              <p>Co-founders Laura and Tomás prototype the first ARS→USD dashboards for family use.</p>
            </div>
            <div>
              <span className={styles.year}>2022</span>
              <p>Launch of private beta with 120 early adopters across Buenos Aires, Tucumán, and Mendoza.</p>
            </div>
            <div>
              <span className={styles.year}>2023</span>
              <p>Introduced guided budgeting course and live workshops with educators and small business owners.</p>
            </div>
            <div>
              <span className={styles.year}>2024</span>
              <p>Expanded community features, introduced double opt-in onboarding, and strengthened Spanish resources.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.callout}`}>
        <div className="container">
          <h2>Educational platform, not financial advisory</h2>
          <p>
            We are proud of our role as educators. Tu Progreso Hoy does not offer financial services, investment products, or
            guarantees. Our promise is to keep delivering context-rich learning experiences that respect your intelligence
            and your autonomy.
          </p>
          <a className="btn btn-primary" href="mailto:hola@tuprogresohoy.com">
            Connect with the founders
          </a>
        </div>
      </section>
    </div>
  );
}

export default AboutPage;