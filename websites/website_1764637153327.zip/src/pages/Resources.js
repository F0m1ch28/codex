import React from 'react';
import MetaManager from '../components/MetaManager';
import styles from './Resources.module.css';

const resources = [
  {
    title: 'Inflation digest template',
    type: 'Template',
    description: 'Weekly checklist to record official data, private trackers, and personal observations.',
    link: '#'
  },
  {
    title: 'Talking about currency shifts with your team',
    type: 'Guide',
    description:
      'Communication prompts that keep conversations grounded in verified information and shared goals.',
    link: '#'
  },
  {
    title: 'Household budget calculator (ARS & USD)',
    type: 'Tool',
    description: 'Spreadsheet designed for multiple exchange rates and regulated price adjustments.',
    link: '#'
  },
  {
    title: 'Cohort notes: Educators session',
    type: 'Notes',
    description: 'Summary of questions and insights from teachers explaining inflation to students.',
    link: '#'
  },
  {
    title: 'SMB pulse check',
    type: 'Toolkit',
    description: 'Framework for SMEs to revisit pricing, payroll, and imports without panic.',
    link: '#'
  },
  {
    title: 'Community stories',
    type: 'Article',
    description: 'Interviews with learners applying Tu Progreso Hoy modules to their daily lives.',
    link: '#'
  }
];

function ResourcesPage() {
  return (
    <div className={styles.page}>
      <MetaManager
        title="Resources | Tu Progreso Hoy Knowledge Hub"
        description="Explore Tu Progreso Hoy resources: templates, guides, and community notes designed for Argentina’s economic context."
        canonical="https://www.tuprogresohoy.com/resources"
        alternate={[
          { hrefLang: 'es-AR', href: 'https://www.tuprogresohoy.com/es/resources' }
        ]}
      />
      <section className={`${styles.section} ${styles.hero}`}>
        <div className="container">
          <h1>Resource hub</h1>
          <p>
            Trusted templates, guides, and community notes that help you apply what you learn from Tu Progreso Hoy. Everything
            is bilingual-friendly and updated frequently to reflect Argentina&apos;s reality.
          </p>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.grid}>
            {resources.map((resource) => (
              <article key={resource.title} className={styles.card}>
                <span className={styles.type}>{resource.type}</span>
                <h2>{resource.title}</h2>
                <p>{resource.description}</p>
                <a href={resource.link} className={styles.link}>
                  Coming soon →
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.disclaimerSection}`}>
        <div className="container">
          <p>
            Tu Progreso Hoy resources are intended for educational purposes only. Plataforma educativa sin asesoría
            financiera directa.
          </p>
        </div>
      </section>
    </div>
  );
}

export default ResourcesPage;