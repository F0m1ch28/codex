import React from 'react';
import MetaManager from '../components/MetaManager';
import styles from './Services.module.css';

const offerings = [
  {
    title: 'Argentina Data Lab',
    description:
      'Access inflation dashboards, ARS→USD monitoring, tariff timelines, and curated annotations that decode what moved and why it matters.',
    details: ['Multi-source visualizations', 'Scenario builder for ARS and USD', 'Weekly sentiment briefs'],
    outcome: 'Ideal for teams aligning on economic context.'
  },
  {
    title: 'Budget Playbook Course',
    description:
      'A cohort-based program to build resilient budgets with accountability checkpoints, templates, and peer exchange.',
    details: ['Eight modules + live sessions', 'Applied exercises with mock data', 'Feedback from certified facilitators'],
    outcome: 'Perfect for individuals and families seeking clarity.'
  },
  {
    title: 'Executive Briefings',
    description:
      'Tailored workshops for leadership teams. Align market narratives, plan responsible responses, and communicate with empathy.',
    details: ['Custom dashboards', 'Facilitated discussions', 'Bilingual summaries'],
    outcome: 'Great for organizations planning across Argentina operations.'
  }
];

function ServicesPage() {
  return (
    <div className={styles.page}>
      <MetaManager
        title="Services | Tu Progreso Hoy Educational SaaS"
        description="Discover Tu Progreso Hoy services: Argentina data lab, budgeting course, and executive briefings that keep teams informed without false promises."
        canonical="https://www.tuprogresohoy.com/services"
        alternate={[
          { hrefLang: 'es-AR', href: 'https://www.tuprogresohoy.com/es/services' }
        ]}
      />
      <section className={`${styles.section} ${styles.hero}`}>
        <div className="container">
          <h1>Responsible services for economies that move fast</h1>
          <p>
            From interactive dashboards to structured learning cohorts, Tu Progreso Hoy offers educational services
            for individuals and teams navigating Argentina&apos;s shifts. Always grounded, never sensational.
          </p>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.grid}>
            {offerings.map((service) => (
              <article key={service.title} className={styles.card}>
                <h2>{service.title}</h2>
                <p>{service.description}</p>
                <ul>
                  {service.details.map((detail) => (
                    <li key={detail}>{detail}</li>
                  ))}
                </ul>
                <div className={styles.outcome}>{service.outcome}</div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.cta}`}>
        <div className="container">
          <h2>Let&apos;s create a responsible action plan together</h2>
          <p>
            Tell us what you need at <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>. We&apos;ll respond
            with a suggested path, always emphasizing education and context—never unrealistic promises.
          </p>
          <a className="btn btn-primary" href="mailto:hola@tuprogresohoy.com">
            Request a discovery call
          </a>
        </div>
      </section>
    </div>
  );
}

export default ServicesPage;