import React from 'react';
import MetaManager from '../components/MetaManager';
import styles from './PrivacyPolicy.module.css';

function PrivacyPolicyPage() {
  return (
    <div className={styles.page}>
      <MetaManager
        title="Privacy Policy | Tu Progreso Hoy"
        description="Read the Tu Progreso Hoy privacy policy. Learn how we protect your information and your rights."
        canonical="https://www.tuprogresohoy.com/privacy"
        alternate={[
          { hrefLang: 'es-AR', href: 'https://www.tuprogresohoy.com/es/privacy' }
        ]}
      />
      <section className={styles.section}>
        <div className="container">
          <h1>Privacy Policy</h1>
          <p className={styles.updated}>Last updated: January 2024</p>

          <article className={styles.card}>
            <h2>1. Who we are</h2>
            <p>
              Tu Progreso Hoy (“we”, “us”) is an educational SaaS platform headquartered at Av. 9 de Julio 1000, C1043 Buenos
              Aires, Argentina. Contact us at hola@tuprogresohoy.com.
            </p>
          </article>

          <article className={styles.card}>
            <h2>2. Information we collect</h2>
            <ul>
              <li>Contact details submitted through forms (name, email, organization).</li>
              <li>Course participation details (modules completed, feedback, cohort attendance).</li>
              <li>Aggregated analytics to understand platform usage (if you accept optional cookies).</li>
            </ul>
          </article>

          <article className={styles.card}>
            <h2>3. How we use information</h2>
            <ul>
              <li>Deliver educational services and communicate updates you request.</li>
              <li>Improve course materials and dashboards based on aggregated patterns.</li>
              <li>Comply with legal obligations in Argentina.</li>
            </ul>
          </article>

          <article className={styles.card}>
            <h2>4. Data sharing</h2>
            <p>
              We do not sell personal data. We share information only with trusted processors necessary to provide the
              service (for example, email delivery providers) under strict data protection agreements.
            </p>
          </article>

          <article className={styles.card}>
            <h2>5. Your rights</h2>
            <ul>
              <li>Access, correct, or request deletion of your personal data.</li>
              <li>Withdraw consent for optional communications at any time.</li>
              <li>Contact the Agencia de Acceso a la Información Pública in Argentina for data protection matters.</li>
            </ul>
          </article>

          <article className={styles.card}>
            <h2>6. Cookies</h2>
            <p>
              We use essential cookies for security and functionality. Optional analytics cookies run only with your explicit
              consent. Read more in our <a href="/cookies">Cookie Policy</a>.
            </p>
          </article>

          <article className={styles.card}>
            <h2>7. Contact</h2>
            <p>
              For privacy questions, email <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a> or write to Av.
              9 de Julio 1000, C1043 Buenos Aires, Argentina.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
}

export default PrivacyPolicyPage;