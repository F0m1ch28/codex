import React from 'react';
import MetaManager from '../components/MetaManager';
import styles from './TermsOfService.module.css';

function TermsOfServicePage() {
  return (
    <div className={styles.page}>
      <MetaManager
        title="Terms of Service | Tu Progreso Hoy"
        description="Review the Tu Progreso Hoy terms of service. Educational use only, no financial guarantees."
        canonical="https://www.tuprogresohoy.com/terms"
        alternate={[
          { hrefLang: 'es-AR', href: 'https://www.tuprogresohoy.com/es/terms' }
        ]}
      />
      <section className={styles.section}>
        <div className="container">
          <h1>Terms of Service</h1>
          <p className={styles.updated}>Effective January 2024</p>

          <article className={styles.card}>
            <h2>1. Purpose</h2>
            <p>
              Tu Progreso Hoy provides educational resources, courses, and data visualizations focused on Argentina&apos;s
              economic context. We do not offer financial services or investment advice.
            </p>
          </article>

          <article className={styles.card}>
            <h2>2. Eligibility</h2>
            <p>
              By using the platform you confirm you are at least 18 years old or have parental consent, and that you will use
              the services for educational purposes only.
            </p>
          </article>

          <article className={styles.card}>
            <h2>3. User responsibilities</h2>
            <ul>
              <li>Provide accurate information when registering or contacting us.</li>
              <li>Respect community guidelines during live sessions and forums.</li>
              <li>Avoid sharing login details or proprietary content publicly.</li>
            </ul>
          </article>

          <article className={styles.card}>
            <h2>4. Intellectual property</h2>
            <p>
              All course materials, dashboards, and publications remain the intellectual property of Tu Progreso Hoy. You may
              use them for personal educational purposes and may not redistribute without consent.
            </p>
          </article>

          <article className={styles.card}>
            <h2>5. Disclaimer</h2>
            <p>
              Content is provided “as is” for learning. We do not guarantee financial outcomes. Decisions made using our
              materials are your responsibility.
            </p>
          </article>

          <article className={styles.card}>
            <h2>6. Termination</h2>
            <p>
              We may suspend or terminate access if users breach these terms or community standards. Users may cancel
              anytime by contacting hola@tuprogresohoy.com.
            </p>
          </article>

          <article className={styles.card}>
            <h2>7. Governing law</h2>
            <p>These terms are governed by the laws of Argentina.</p>
          </article>

          <article className={styles.card}>
            <h2>8. Contact</h2>
            <p>
              Questions about the terms? Email <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
}

export default TermsOfServicePage;