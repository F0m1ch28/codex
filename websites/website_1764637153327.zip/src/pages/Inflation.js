import React from 'react';
import MetaManager from '../components/MetaManager';
import styles from './Inflation.module.css';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar
} from 'recharts';

const monthlyInflation = [
  { month: 'Jan', ipc: 20.1 },
  { month: 'Feb', ipc: 18.4 },
  { month: 'Mar', ipc: 16.9 },
  { month: 'Apr', ipc: 15.5 },
  { month: 'May', ipc: 13.8 },
  { month: 'Jun', ipc: 12.7 },
  { month: 'Jul', ipc: 11.4 },
  { month: 'Aug', ipc: 10.3 },
  { month: 'Sep', ipc: 9.6 },
  { month: 'Oct', ipc: 9.1 },
  { month: 'Nov', ipc: 8.5 },
  { month: 'Dec', ipc: 8.1 }
];

const basketBreakdown = [
  { category: 'Food', yoy: 186 },
  { category: 'Housing', yoy: 162 },
  { category: 'Transport', yoy: 148 },
  { category: 'Education', yoy: 172 },
  { category: 'Health', yoy: 158 }
];

function InflationPage() {
  return (
    <div className={styles.page}>
      <MetaManager
        title="Argentina Inflation Dashboards | Tu Progreso Hoy"
        description="Track Argentina inflation trends, ARS to USD movements, and scenario planning with Tu Progreso Hoy. Mock data illustrating how our dashboards work."
        canonical="https://www.tuprogresohoy.com/inflation"
        alternate={[
          { hrefLang: 'es-AR', href: 'https://www.tuprogresohoy.com/es/inflation' }
        ]}
      />
      <section className={`${styles.section} ${styles.hero}`}>
        <div className="container">
          <h1>Inflation insights built for clarity</h1>
          <p>
            Explore a mock representation of Tu Progreso Hoy&apos;s inflation dashboards. Actual product pulls from
            multiple sources and includes narrative annotations, contextual alerts, and bilingual summaries.
          </p>
          <p className={styles.disclaimer}>
            Educational purposes only. Datos de ejemplo. We do not provide investment services.
          </p>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.grid}>
            <article className={styles.chartCard}>
              <h2>Monthly inflation (YoY)</h2>
              <p>
                Mock trajectory showing a deceleration trend, helping learners interpret pace and shape of change—not just
                the point estimate.
              </p>
              <ResponsiveContainer width="100%" height={320}>
                <AreaChart data={monthlyInflation}>
                  <defs>
                    <linearGradient id="colorIpc" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2563EB" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="8 8" stroke="rgba(148, 163, 184, 0.35)" />
                  <XAxis dataKey="month" stroke="rgba(71, 85, 105, 0.8)" />
                  <YAxis stroke="rgba(71, 85, 105, 0.8)" />
                  <Tooltip
                    formatter={(value) => [`${value}%`, 'YoY inflation']}
                    contentStyle={{
                      borderRadius: '1rem',
                      border: '1px solid rgba(37, 99, 235, 0.15)'
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="ipc"
                    stroke="#2563EB"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#colorIpc)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </article>

            <article className={styles.chartCard}>
              <h2>Basket breakdown (YoY mock)</h2>
              <p>
                Understand which categories drive the index. We combine official releases with private trackers and
                summarize in plain language.
              </p>
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={basketBreakdown}>
                  <CartesianGrid strokeDasharray="8 8" stroke="rgba(148, 163, 184, 0.25)" />
                  <XAxis dataKey="category" stroke="rgba(71, 85, 105, 0.8)" />
                  <YAxis stroke="rgba(71, 85, 105, 0.8)" />
                  <Tooltip
                    formatter={(value) => [`${value}%`, 'YoY']}
                    contentStyle={{
                      borderRadius: '1rem',
                      border: '1px solid rgba(37, 99, 235, 0.15)'
                    }}
                  />
                  <Bar dataKey="yoy" fill="#1F3A6F" radius={[12, 12, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.callout}`}>
        <div className="container">
          <h2>Scenarios with context, not predictions</h2>
          <p>
            Instead of promising specific outcomes, Tu Progreso Hoy supports you with scenario planning, historical
            comparisons, and community discussions to evaluate responses responsibly.
          </p>
          <a className="btn btn-primary" href="/contact">
            Request a guided tour
          </a>
        </div>
      </section>
    </div>
  );
}

export default InflationPage;