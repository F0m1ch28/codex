import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  LineChart,
  Line,
  ResponsiveContainer,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip
} from 'recharts';
import MetaManager from '../components/MetaManager';
import styles from './Home.module.css';

const promises = [
  {
    title: 'Datos verificados para planificar tu presupuesto',
    detail:
      'Weekly-updated indicators from BCRA, INDEC, and trusted private sources, curated into one intuitive dashboard.',
    icon: '📊'
  },
  {
    title: 'Decisiones responsables, objetivos nítidos',
    detail:
      'Translate macro trends into everyday choices with guided explanations and contextual alerts that matter in Argentina.',
    icon: '🎯'
  },
  {
    title: 'Aprendizaje continuo con cohortes colaborativas',
    detail:
      'Join moderated study groups to compare strategies, discuss new regulations, and practice real-world budgeting scenarios.',
    icon: '🤝'
  },
  {
    title: 'Insights accionables, sin promesas vacías',
    detail:
      'Contextual analysis and benchmarks built for volatility, ensuring no “magic formulas” or unrealistic expectations.',
    icon: '🛡️'
  }
];

const statsData = [
  { label: 'Trusted data series', value: 68 },
  { label: 'Learners community', value: 1240 },
  { label: 'Hours of live workshops', value: 42 },
  { label: 'Monthly scenario updates', value: 18 }
];

const inflationTrend = [
  { month: 'Jan', yoy: 210 },
  { month: 'Feb', yoy: 204 },
  { month: 'Mar', yoy: 198 },
  { month: 'Apr', yoy: 192 },
  { month: 'May', yoy: 188 },
  { month: 'Jun', yoy: 182 },
  { month: 'Jul', yoy: 176 },
  { month: 'Aug', yoy: 169 },
  { month: 'Sep', yoy: 163 },
  { month: 'Oct', yoy: 156 },
  { month: 'Nov', yoy: 152 },
  { month: 'Dec', yoy: 148 }
];

const testimonials = [
  {
    name: 'María Belén P.',
    role: 'Product Manager · Córdoba',
    quote:
      '“Las visualizaciones de Tu Progreso Hoy me permiten explicar la inflación argentina a mi equipo global sin drama ni hype. El curso de budgeting fue directo y aplicable desde la primera semana.”'
  },
  {
    name: 'Ignacio R.',
    role: 'Consultor de PyMEs · Rosario',
    quote:
      '“La combinación de datos confiables y ejercicios guiados me ayudó a sostener conversaciones realistas con clientes. No ofrecen milagros: ofrecen contexto y herramientas.”'
  },
  {
    name: 'Valentina G.',
    role: 'Economía doméstica · Buenos Aires',
    quote:
      '“La lógica de doble validación para el presupuesto familiar nos dio tranquilidad. Las alertas sobre tipo de cambio se entienden y se aplican a la vida real.”'
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Diagnóstico guiado',
    text: 'Carga tu situación actual y recibe un mapa visual con tus drivers principales.'
  },
  {
    step: '02',
    title: 'Tableros personalizados',
    text: 'Filtra inflación, ARS→USD y tarifas para escenarios realistas en Argentina.'
  },
  {
    step: '03',
    title: 'Learning sprints',
    text: 'Módulos cortos + talleres en vivo con casos de uso vinculados a datos reales.'
  },
  {
    step: '04',
    title: 'Iteración y comunidad',
    text: 'Revisa tus avances con feedback de especialistas y compañeros en cada cohorte.'
  }
];

const services = [
  {
    title: 'Data Lab Argentina',
    text: 'Daily ARS→USD tracker, inflation dashboards, scenario planning, interactive cohorts.',
    icon: '📈'
  },
  {
    title: 'Budget Playbook',
    text: 'Step-by-step course with templates, role-play exercises, and peer reviews for personal finance.',
    icon: '🗂️'
  },
  {
    title: 'Executive Briefings',
    text: 'Custom briefings for teams needing rapid alignment on Argentina economic shifts without jargon.',
    icon: '🧭'
  }
];

const teamMembers = [
  {
    name: 'Laura Etcheverry',
    role: 'Head of Insights',
    bio: 'Former research lead at BCRA digital labs, now translating macro data into human stories.',
    image: 'https://picsum.photos/400/400?random=31',
    alt: 'Portrait of Laura Etcheverry, Head of Insights at Tu Progreso Hoy'
  },
  {
    name: 'Tomás Villalba',
    role: 'Lead Curriculum Designer',
    bio: 'Certified educator with 10+ years designing learning experiences about volatility and budgeting.',
    image: 'https://picsum.photos/400/400?random=32',
    alt: 'Portrait of Tomás Villalba, Curriculum Designer at Tu Progreso Hoy'
  },
  {
    name: 'Solange Martínez',
    role: 'Community Facilitator',
    bio: 'Guides weekly cohorts, ensures respectful dialogue, and highlights applicable lessons.',
    image: 'https://picsum.photos/400/400?random=33',
    alt: 'Portrait of Solange Martínez, Community Facilitator at Tu Progreso Hoy'
  }
];

const projects = [
  {
    title: 'Household Budget Resilience',
    category: 'budgeting',
    description:
      'Used real inflation data to stress-test a household plan over 12 months with targeted adjustments.',
    image: 'https://picsum.photos/1200/800?random=41',
    alt: 'Dashboard showing household budget resilience analysis in Argentina'
  },
  {
    title: 'SMB Cash Flow Monitor',
    category: 'inflation',
    description:
      'Designed for a Rosario-based SMB to align ARS and USD flows, using our live tracker and alerts.',
    image: 'https://picsum.photos/1200/800?random=42',
    alt: 'Tu Progreso Hoy project showing SMB cash flow monitor dashboard'
  },
  {
    title: 'Community Learning Sprint',
    category: 'education',
    description:
      'Facilitated a 4-week cohort on inflation literacy for educators, focusing on practical activities.',
    image: 'https://picsum.photos/1200/800?random=43',
    alt: 'Group workshop during Tu Progreso Hoy community learning sprint'
  }
];

const faqItems = [
  {
    question: 'Do you provide financial advice or investment services?',
    answer:
      'No. Tu Progreso Hoy is strictly an educational platform. We combine public and private datasets with learning tools to help you understand trends. Any decisions remain your responsibility.'
  },
  {
    question: 'How does the double opt-in work for the free trial?',
    answer:
      'Submit the form with your name and email. We send a confirmation step to ensure you truly want the materials. After confirming, you receive access to the introductory lessons and dashboards.'
  },
  {
    question: 'What makes your ARS→USD tracker different?',
    answer:
      'We update movements throughout the day, combine official and market references, and add narrative context explaining what changed and why it matters for budgeting decisions.'
  },
  {
    question: 'Can teams join together?',
    answer:
      'Yes, we work with teams and professional groups. Custom workshops include best practices for discussing volatility internally while staying grounded in verified information.'
  }
];

const blogPosts = [
  {
    title: 'Budgeting Argentina: Five Signals to Monitor Each Week',
    date: 'January 2024',
    excerpt:
      'Identify the most impactful short-term indicators, from regulated price adjustments to wholesale inflation leaps.',
    image: 'https://picsum.photos/600/400?random=51',
    alt: 'Financial analyst reviewing Argentina economic charts'
  },
  {
    title: 'Understanding ARS→USD Scenarios Without Panic',
    date: 'December 2023',
    excerpt:
      'A walkthrough on how to evaluate exchange rate movements, communicate options calmly, and keep plans flexible.',
    image: 'https://picsum.photos/600/400?random=52',
    alt: 'Person analyzing ARS to USD exchange rate scenario planning'
  },
  {
    title: 'Community Spotlight: Educators Teaching Inflation',
    date: 'November 2023',
    excerpt:
      'How three educators leveraged Tu Progreso Hoy to bring realistic inflation lessons into the classroom.',
    image: 'https://picsum.photos/600/400?random=53',
    alt: 'Teachers collaborating on inflation lesson plans in Argentina'
  }
];

function HomePage() {
  const navigate = useNavigate();
  const [trackerData, setTrackerData] = useState([
    { time: '09:00', rate: 880.5, change: '+0.30%' },
    { time: '11:00', rate: 882.1, change: '+0.18%' },
    { time: '13:00', rate: 883.6, change: '+0.17%' },
    { time: '15:00', rate: 885.2, change: '+0.18%' }
  ]);
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [projectFilter, setProjectFilter] = useState('all');
  const [formStage, setFormStage] = useState('form');
  const [pendingSubmission, setPendingSubmission] = useState(null);
  const [formErrors, setFormErrors] = useState({});

  useEffect(() => {
    const interval = setInterval(() => {
      setTrackerData((prev) => {
        const last = prev[prev.length - 1];
        const delta = (Math.random() - 0.4) * 2.4;
        const newRate = Math.max(840, +(last.rate + delta).toFixed(2));
        const newChange = ((newRate - prev[0].rate) / prev[0].rate) * 100;
        const now = new Date();
        const time = now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
        const next = { time, rate: newRate, change: `${newChange >= 0 ? '+' : ''}${newChange.toFixed(2)}%` };
        return [...prev.slice(1), next];
      });
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setAnimatedStats((prev) =>
        prev.map((value, index) => {
          const target = statsData[index].value;
          if (value >= target) return target;
          const increment = Math.ceil(target / 28);
          return Math.min(target, value + increment);
        })
      );
    }, 120);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const rotation = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 8000);

    return () => clearInterval(rotation);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'all') return projects;
    return projects.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  const handleFormSubmit = (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = form.get('name').trim();
    const email = form.get('email').trim();

    const errors = {};
    if (!name) errors.name = 'Please share your name so we can greet you properly.';
    if (!email) {
      errors.email = 'Email is required to send the confirmation step.';
    } else if (!/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/i.test(email)) {
      errors.email = 'Kindly enter a valid email address.';
    }

    setFormErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setPendingSubmission({ name, email });
    setFormStage('confirm');
  };

  const handleConfirmOptIn = () => {
    navigate('/thank-you', {
      state: pendingSubmission
    });
  };

  const handleEdit = () => {
    setFormStage('form');
  };

  return (
    <>
      <MetaManager
        title="Tu Progreso Hoy | Educational Economic Insights for Argentina"
        description="Tu Progreso Hoy centralizes Argentina inflation data, ARS→USD live trackers, and a practical financial course for responsible decisions."
        canonical="https://www.tuprogresohoy.com/"
        alternate={[
          { hrefLang: 'es-AR', href: 'https://www.tuprogresohoy.com/es' }
        ]}
      />
      <section className={styles.hero}>
        <div className={styles.heroOverlay} aria-hidden="true" />
        <div className="container">
          <div className={styles.heroContent}>
            <div className={styles.heroBadge}>
              <span className="badge">Informed budgeting for Argentina</span>
            </div>
            <h1 className={styles.heroTitle}>
              Understand Argentina&apos;s economy today, build resilient plans for tomorrow.
            </h1>
            <p className={styles.heroSubtitle}>
              Tu Progreso Hoy blends verified data, ARS→USD trackers, and guided learning so you can
              align decisions with reality—no empty promises, just clarity.
            </p>
            <div className={styles.heroActions}>
              <Link to="#leadForm" className="btn btn-primary animated-cta">
                Get the free trial lesson
              </Link>
              <Link to="/inflation" className="btn btn-outline">
                See live data dashboards
              </Link>
            </div>
            <p className={styles.heroDisclaimer}>
              We do not provide financial services. No brindamos servicios financieros.
            </p>
          </div>
          <div className={styles.heroVisual}>
            <img
              src="https://picsum.photos/800/600?random=2"
              alt="Professional analyzing Argentina economic dashboards"
              loading="lazy"
            />
            <div className={styles.heroCard}>
              <p className={styles.heroCardTitle}>Daily ARS → USD pulse</p>
              <p className={styles.heroCardValue}>{trackerData[trackerData.length - 1].rate} ARS</p>
              <span className={styles.heroCardBadge}>{trackerData[trackerData.length - 1].change}</span>
              <span className={styles.heroCardMeta}>Updated {trackerData[trackerData.length - 1].time}</span>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.promises} section-spacing`} id="promises">
        <div className="container">
          <h2 className="section-title">Key promises that guide our platform</h2>
          <p className="section-subtitle">
            Built in Buenos Aires, designed for anyone navigating Argentina&apos;s shifting economy with
            responsibility, context, and community learning.
          </p>
          <div className={styles.promiseGrid}>
            {promises.map((promise) => (
              <article key={promise.title} className={styles.promiseCard}>
                <span className={styles.promiseIcon} aria-hidden="true">
                  {promise.icon}
                </span>
                <h3>{promise.title}</h3>
                <p>{promise.detail}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.trackerSection} section-spacing`} aria-labelledby="tracker-heading">
        <div className="container">
          <div className={styles.trackerHeader}>
            <div>
              <h2 id="tracker-heading">Live ARS → USD tracker (mock data)</h2>
              <p>
                Designed to mimic our daily view: official, blend, and market references with annotated
                changes, giving you a responsible pulse without noise.
              </p>
            </div>
            <Link to="/inflation" className="btn btn-outline">
              Explore full dashboards
            </Link>
          </div>
          <div className={styles.trackerGrid}>
            <div className={styles.trackerPanel}>
              <header>
                <span className="badge">ARS → USD snapshots</span>
                <h3>Latest trend</h3>
              </header>
              <ul className={styles.trackerList}>
                {trackerData.map((dataPoint) => (
                  <li key={dataPoint.time}>
                    <span>{dataPoint.time}h</span>
                    <span>{dataPoint.rate} ARS</span>
                    <span className={dataPoint.change.startsWith('+') ? styles.positive : styles.negative}>
                      {dataPoint.change}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
            <div className={styles.statsPanel}>
              {statsData.map((item, index) => (
                <div key={item.label} className={styles.statCard}>
                  <span className={styles.statValue}>{animatedStats[index]}+</span>
                  <p>{item.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.insights} section-spacing`}>
        <div className="container">
          <div className={styles.insightsHeader}>
            <div>
              <h2 className="section-title">Inflation story told with empathy and facts</h2>
              <p className="section-subtitle">
                A curated timeline of Argentina&apos;s inflation deceleration (mock data) to show how we frame
                trends. Each module contextualizes the numbers with narratives and questions.
              </p>
            </div>
            <Link to="/resources" className="btn btn-outline">
              Read latest briefs
            </Link>
          </div>
          <div className={styles.chartCard} role="img" aria-label="Line chart showing mock inflation trend decelerating through the year">
            <ResponsiveContainer width="100%" height={340}>
              <LineChart data={inflationTrend}>
                <CartesianGrid strokeDasharray="8 8" stroke="rgba(148, 163, 184, 0.35)" />
                <XAxis dataKey="month" stroke="rgba(71, 85, 105, 0.8)" />
                <YAxis stroke="rgba(71, 85, 105, 0.8)" tickFormatter={(value) => `${value}%`} />
                <Tooltip
                  formatter={(value) => [`${value}%`, 'YoY inflation']}
                  contentStyle={{ borderRadius: '1rem', border: '1px solid rgba(37, 99, 235, 0.15)' }}
                />
                <Line
                  type="monotone"
                  dataKey="yoy"
                  stroke="#2563EB"
                  strokeWidth={3}
                  dot={{ r: 4, strokeWidth: 2, stroke: '#93C5FD' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      <section className={`${styles.courseOverview} section-spacing`}>
        <div className="container">
          <div className={styles.courseContent}>
            <div>
              <span className="badge">Course spotlight</span>
              <h2>Budgeting Argentina: From context to action</h2>
              <p>
                An eight-module journey to help you craft a living budget aligned with Argentina&apos;s volatility.
                You get templates, reflective exercises, and community check-ins—without any “get rich quick” claims.
              </p>
              <ul className={styles.courseList}>
                <li>Module 1: Setting responsible objectives anchored in reality.</li>
                <li>Module 2: Understanding ARS→USD pressures and hedging options.</li>
                <li>Module 3: Aligning household needs with regulated prices and open market updates.</li>
                <li>Module 4: Communication frameworks to align families or teams.</li>
              </ul>
              <div className={styles.courseActions}>
                <Link to="/course" className="btn btn-primary">
                  View full syllabus
                </Link>
                <Link to="/contact" className="btn btn-outline">
                  Schedule a cohort briefing
                </Link>
              </div>
            </div>
            <div className={styles.courseCard}>
              <h3>Course outcomes</h3>
              <ul>
                <li>Personalized base budget anchored in verified data.</li>
                <li>Scenario templates for inflation, ARS→USD, and salary updates.</li>
                <li>Community review session with constructive feedback.</li>
                <li>Checklist to support responsible decision-making conversations.</li>
              </ul>
              <p className={styles.courseNote}>
                Educational purposes only. Plataforma educativa sin asesoría financiera directa.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.processSection} section-spacing`}>
        <div className="container">
          <div className={styles.processHeader}>
            <h2>How our learning process works</h2>
            <p>
              A clear, supportive journey guiding you from diagnosis to community follow-up. Every step is grounded in
              transparency and practical application.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.step} className={styles.processCard}>
                <span className={styles.processNumber}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.servicesSection} section-spacing`} id="services">
        <div className="container">
          <h2 className="section-title">Services built for contexts that shift fast</h2>
          <p className="section-subtitle">
            From data dashboards to executive workshops, we help individuals and teams act responsibly. Always educational,
            always transparent.
          </p>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <span aria-hidden="true" className={styles.serviceIcon}>
                  {service.icon}
                </span>
                <h3>{service.title}</h3>
                <p>{service.text}</p>
                <Link to="/contact" className={styles.serviceLink}>
                  Talk with our team →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.testimonials} section-spacing`}>
        <div className="container">
          <div className={styles.testimonialHeader}>
            <h2>Trusted by people navigating Argentina&apos;s complexity</h2>
            <p>
              Real stories from learners and professionals who prefer data with context over hype. Testimonials are genuine
              and free from any promises of overnight success.
            </p>
          </div>
          <div className={styles.testimonialCarousel}>
            {testimonials.map((testimonial, index) => (
              <figure
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === testimonialIndex ? styles.testimonialActive : ''
                }`}
              >
                <blockquote>{testimonial.quote}</blockquote>
                <figcaption>
                  <span>{testimonial.name}</span>
                  <span>{testimonial.role}</span>
                </figcaption>
              </figure>
            ))}
          </div>
          <div className={styles.testimonialControls}>
            {testimonials.map((_, index) => (
              <button
                key={`dot-${index}`}
                type="button"
                aria-label={`Show testimonial ${index + 1}`}
                className={`${styles.dot} ${index === testimonialIndex ? styles.dotActive : ''}`}
                onClick={() => setTestimonialIndex(index)}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.teamSection} section-spacing`}>
        <div className="container">
          <h2>Meet the team behind Tu Progreso Hoy</h2>
          <p className="section-subtitle">
            A multidisciplinary crew combining economics, education, and community facilitation to keep the platform humane
            and practical.
          </p>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.alt} loading="lazy" />
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.projectsSection} section-spacing`}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <div>
              <h2>Highlighted projects and case studies</h2>
              <p>
                Glimpses into how Tu Progreso Hoy supports households, educators, and teams across Argentina. Filter by
                focus area to explore.
              </p>
            </div>
            <div className={styles.filterGroup}>
              <button
                type="button"
                className={`${styles.filterButton} ${projectFilter === 'all' ? styles.filterActive : ''}`}
                onClick={() => setProjectFilter('all')}
              >
                All
              </button>
              <button
                type="button"
                className={`${styles.filterButton} ${projectFilter === 'budgeting' ? styles.filterActive : ''}`}
                onClick={() => setProjectFilter('budgeting')}
              >
                Budgeting
              </button>
              <button
                type="button"
                className={`${styles.filterButton} ${projectFilter === 'inflation' ? styles.filterActive : ''}`}
                onClick={() => setProjectFilter('inflation')}
              >
                Inflation
              </button>
              <button
                type="button"
                className={`${styles.filterButton} ${projectFilter === 'education' ? styles.filterActive : ''}`}
                onClick={() => setProjectFilter('education')}
              >
                Education
              </button>
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={project.alt} loading="lazy" />
                <div className={styles.projectContent}>
                  <span className="tag">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/services" className={styles.projectLink}>
                    Discover our approach →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.faqSection} section-spacing`}>
        <div className="container">
          <div className={styles.faqHeader}>
            <h2>Questions we hear often</h2>
            <p>
              Transparency is one of our values. If you don&apos;t find your answer here, our team is an email away at{' '}
              <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>.
            </p>
          </div>
          <div className={styles.faqGrid}>
            {faqItems.map((item) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.blogSection} section-spacing`}>
        <div className="container">
          <div className={styles.blogHeader}>
            <h2>Latest insights from our team</h2>
            <p>Practical, data-backed perspectives on inflation, budgeting, and community learning in Argentina.</p>
            <Link to="/resources" className="btn btn-outline">
              Visit resource hub
            </Link>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.alt} loading="lazy" />
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/resources" className={styles.blogLink}>
                    Read article
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.leadSection} section-spacing`} id="leadForm">
        <div className="container">
          <div className={styles.leadGrid}>
            <div className={styles.leadCopy}>
              <span className="badge">Free trial lesson</span>
              <h2>Experience Tu Progreso Hoy with a respectful double opt-in</h2>
              <p>
                Share your email to receive a confirmation step. Once confirmed, we send the introductory lesson, live
                dashboard walkthrough, and weekly digest. Straightforward resources, no spam.
              </p>
              <ul className={styles.leadList}>
                <li>Personalized welcome email with curated dashboards.</li>
                <li>Access to one live community session (preview).</li>
                <li>Weekly digest summarizing key Argentina economic moves.</li>
              </ul>
              <p className={styles.leadDisclaimer}>
                Educational platform only. Plataforma educativa sin asesoría financiera directa.
              </p>
            </div>
            <div className={styles.formCard} role="form">
              {formStage === 'form' && (
                <form onSubmit={handleFormSubmit} noValidate>
                  <div className={styles.field}>
                    <label htmlFor="lead-name">Name</label>
                    <input id="lead-name" name="name" type="text" placeholder="Your name" />
                    {formErrors.name && <span className="error">{formErrors.name}</span>}
                  </div>
                  <div className={styles.field}>
                    <label htmlFor="lead-email">Email</label>
                    <input id="lead-email" name="email" type="email" placeholder="you@example.com" />
                    {formErrors.email && <span className="error">{formErrors.email}</span>}
                  </div>
                  <div className={styles.consent}>
                    <input id="lead-consent" type="checkbox" required />
                    <label htmlFor="lead-consent">
                      I agree to receive the confirmation email and educational updates from Tu Progreso Hoy.
                    </label>
                  </div>
                  <button type="submit" className="btn btn-primary">
                    Send confirmation step
                  </button>
                </form>
              )}

              {formStage === 'confirm' && pendingSubmission && (
                <div className={styles.confirmCard}>
                  <h3>Almost there, {pendingSubmission.name}!</h3>
                  <p>
                    We sent a confirmation to <strong>{pendingSubmission.email}</strong>. Hit confirm and you&apos;ll be
                    redirected to the free lesson.
                  </p>
                  <div className={styles.confirmActions}>
                    <button type="button" onClick={handleConfirmOptIn} className="btn btn-primary">
                      I confirmed my email
                    </button>
                    <button type="button" onClick={handleEdit} className="btn btn-outline">
                      Edit my details
                    </button>
                  </div>
                  <p className={styles.confirmNote}>
                    Didn&apos;t receive it? Check spam or write to{' '}
                    <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default HomePage;