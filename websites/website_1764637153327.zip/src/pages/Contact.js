import React, { useState } from 'react';
import axios from 'axios';
import MetaManager from '../components/MetaManager';
import styles from './Contact.module.css';

function ContactPage() {
  const [status, setStatus] = useState({ state: 'idle', message: '' });

  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);

    const payload = {
      name: formData.get('name'),
      email: formData.get('email'),
      organization: formData.get('organization'),
      message: formData.get('message'),
      consent: formData.get('consent') === 'on'
    };

    if (!payload.name || !payload.email || !payload.message || !payload.consent) {
      setStatus({
        state: 'error',
        message: 'Please complete all required fields and consent to be contacted.'
      });
      return;
    }

    try {
      setStatus({ state: 'loading', message: 'Sending your message…' });
      await axios.post('https://jsonplaceholder.typicode.com/posts', payload);
      setStatus({
        state: 'success',
        message: 'Thank you! We will reply within two business days.'
      });
      event.currentTarget.reset();
    } catch (error) {
      setStatus({
        state: 'error',
        message:
          'Something went wrong when sending your message. Please email us directly at hola@tuprogresohoy.com.'
      });
    }
  };

  return (
    <div className={styles.page}>
      <MetaManager
        title="Contact Tu Progreso Hoy | Educational SaaS Platform"
        description="Contact Tu Progreso Hoy in Buenos Aires for educational SaaS inquiries. We provide data-driven learning experiences, not financial services."
        canonical="https://www.tuprogresohoy.com/contact"
        alternate={[
          { hrefLang: 'es-AR', href: 'https://www.tuprogresohoy.com/es/contact' }
        ]}
      />
      <section className={`${styles.section} ${styles.hero}`}>
        <div className="container">
          <h1>Let&apos;s connect</h1>
          <p>
            Share a bit about your needs and we&apos;ll schedule a conversation. We&apos;re based in Buenos Aires and work
            with learners all across Argentina.
          </p>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.infoCard}>
              <h2>Contact details</h2>
              <p>Tu Progreso Hoy · Educational SaaS</p>
              <ul>
                <li>
                  Address: Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
                </li>
                <li>
                  Phone: <a href="tel:+541155551234">+54 11 5555-1234</a>
                </li>
                <li>
                  Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
                </li>
              </ul>
              <p className={styles.note}>
                Disclaimer: We do not provide financial services or investment guarantees. Plataforma educativa sin asesoría
                financiera directa.
              </p>
            </div>
            <form className={styles.formCard} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="contact-name">Name*</label>
                <input id="contact-name" name="name" type="text" placeholder="Your name" required />
              </div>
              <div className={styles.field}>
                <label htmlFor="contact-email">Email*</label>
                <input id="contact-email" name="email" type="email" placeholder="you@example.com" required />
              </div>
              <div className={styles.field}>
                <label htmlFor="contact-organization">Organization</label>
                <input
                  id="contact-organization"
                  name="organization"
                  type="text"
                  placeholder="Company, school, or project"
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="contact-message">How can we help?*</label>
                <textarea
                  id="contact-message"
                  name="message"
                  placeholder="Tell us about your goals or questions."
                  required
                />
              </div>
              <div className={styles.checkbox}>
                <input id="contact-consent" name="consent" type="checkbox" required />
                <label htmlFor="contact-consent">
                  I agree to be contacted by Tu Progreso Hoy for educational purposes.
                </label>
              </div>
              <button type="submit" className="btn btn-primary">
                Send message
              </button>
              {status.state !== 'idle' && (
                <p className={`${styles.status} ${styles[status.state]}`}>{status.message}</p>
              )}
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}

export default ContactPage;