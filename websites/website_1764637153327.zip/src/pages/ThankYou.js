import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import MetaManager from '../components/MetaManager';
import styles from './ThankYou.module.css';

function ThankYouPage() {
  const location = useLocation();
  const name = location.state?.name || 'there';

  return (
    <div className={styles.page}>
      <MetaManager
        title="Thanks for joining | Tu Progreso Hoy"
        description="Thank you for confirming your interest in Tu Progreso Hoy. Check your inbox for the first lesson."
        canonical="https://www.tuprogresohoy.com/thank-you"
        alternate={[
          { hrefLang: 'es-AR', href: 'https://www.tuprogresohoy.com/es/thank-you' }
        ]}
      />
      <section className={styles.section}>
        <div className="container">
          <div className={styles.card}>
            <span className="badge">Welcome aboard</span>
            <h1>Gracias, {name}!</h1>
            <p>
              Your confirmation was successful. The first lesson and dashboard walkthrough are on their way. Remember, Tu
              Progreso Hoy is an educational platform: no financial services, no false guarantees.
            </p>
            <div className={styles.actions}>
              <Link to="/resources" className="btn btn-primary">
                Explore resources
              </Link>
              <Link to="/" className="btn btn-outline">
                Return home
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default ThankYouPage;