import React, { useEffect, useState } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage from './pages/Services';
import InflationPage from './pages/Inflation';
import CoursePage from './pages/Course';
import ResourcesPage from './pages/Resources';
import ContactPage from './pages/Contact';
import ThankYouPage from './pages/ThankYou';
import PrivacyPolicyPage from './pages/PrivacyPolicy';
import TermsOfServicePage from './pages/TermsOfService';
import CookiePolicyPage from './pages/CookiePolicy';

const defaultConsent = {
  status: 'pending',
  preferences: {
    analytics: false,
    marketing: false,
    essential: true
  }
};

function App() {
  const location = useLocation();
  const [cookieConsent, setCookieConsent] = useState(() => {
    try {
      const stored = localStorage.getItem('tph_cookie_consent');
      return stored ? JSON.parse(stored) : defaultConsent;
    } catch (error) {
      return defaultConsent;
    }
  });

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  const persistConsent = (consent) => {
    setCookieConsent(consent);
    try {
      localStorage.setItem('tph_cookie_consent', JSON.stringify(consent));
    } catch (error) {
      // Fallback silently if storage is not available
    }
  };

  const handleAcceptAll = () => {
    persistConsent({
      status: 'acceptedAll',
      preferences: {
        essential: true,
        analytics: true,
        marketing: true
      }
    });
  };

  const handleRejectAll = () => {
    persistConsent({
      status: 'rejectedAll',
      preferences: {
        essential: true,
        analytics: false,
        marketing: false
      }
    });
  };

  const handleSavePreferences = (preferences) => {
    persistConsent({
      status: 'customized',
      preferences: { ...preferences, essential: true }
    });
  };

  const shouldShowBanner = cookieConsent.status === 'pending';

  return (
    <div className="app-shell">
      <Header />
      <main id="mainContent">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/inflation" element={<InflationPage />} />
          <Route path="/course" element={<CoursePage />} />
          <Route path="/resources" element={<ResourcesPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/thank-you" element={<ThankYouPage />} />
          <Route path="/privacy" element={<PrivacyPolicyPage />} />
          <Route path="/terms" element={<TermsOfServicePage />} />
          <Route path="/cookies" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTopButton />
      <CookieBanner
        visible={shouldShowBanner}
        initialPreferences={cookieConsent.preferences}
        onAcceptAll={handleAcceptAll}
        onRejectAll={handleRejectAll}
        onSavePreferences={handleSavePreferences}
      />
    </div>
  );
}

export default App;