import React from 'react';
import { Helmet } from 'react-helmet-async';

function MetaManager({ title, description, canonical, lang = 'en', alternate }) {
  return (
    <Helmet>
      <html lang={lang} />
      {title && <title>{title}</title>}
      {description && <meta name="description" content={description} />}
      {canonical && <link rel="canonical" href={canonical} />}
      {Array.isArray(alternate) &&
        alternate.map((item) => (
          <link key={item.hrefLang} rel="alternate" hrefLang={item.hrefLang} href={item.href} />
        ))}
    </Helmet>
  );
}

export default MetaManager;