import React, { useEffect, useState } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { label: 'Home', to: '/' },
  { label: 'About', to: '/about' },
  { label: 'Services', to: '/services' },
  { label: 'Inflation', to: '/inflation' },
  { label: 'Course', to: '/course' },
  { label: 'Resources', to: '/resources' },
  { label: 'Contact', to: '/contact' }
];

function Header() {
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 16);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className="container">
        <div className={styles.navbar}>
          <Link to="/" className={styles.logo} aria-label="Tu Progreso Hoy home">
            <span className={styles.logoMark}>TPH</span>
            <span className={styles.logoText}>Tu Progreso Hoy</span>
          </Link>

          <nav className={styles.desktopNav} aria-label="Primary navigation">
            <ul className={styles.navLinks}>
              {navItems.map((item) => (
                <li key={item.to}>
                  <NavLink
                    to={item.to}
                    className={({ isActive }) =>
                      `${styles.navLink} ${isActive ? styles.active : ''}`
                    }
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>

          <div className={styles.actions}>
            <span className={styles.languageBadge} aria-label="Content language">
              EN · ES
            </span>
            <Link to="/course" className="btn btn-outline">
              Explore the Course
            </Link>
          </div>

          <button
            className={styles.menuToggle}
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            onClick={() => setMenuOpen((prev) => !prev)}
          >
            <span className={styles.menuBar} />
            <span className={styles.menuBar} />
            <span className={styles.menuBar} />
          </button>
        </div>
      </div>

      <div
        id="mobile-menu"
        className={`${styles.mobileMenu} ${menuOpen ? styles.mobileMenuOpen : ''}`}
      >
        <nav aria-label="Mobile navigation">
          <ul className={styles.mobileLinks}>
            {navItems.map((item) => (
              <li key={`mobile-${item.to}`}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    `${styles.mobileLink} ${isActive ? styles.activeMobile : ''}`
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <div className={styles.mobileActions}>
            <Link to="/course" className="btn btn-primary animated-cta">
              Start Your Free Trial
            </Link>
          </div>
          <p className={styles.mobileDisclaimer}>
            Educational insights only. Tu Progreso Hoy does not deliver financial services.
          </p>
        </nav>
      </div>
    </header>
  );
}

export default Header;