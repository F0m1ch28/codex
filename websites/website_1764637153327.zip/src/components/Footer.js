import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.topRow}>
          <div className={styles.brand}>
            <span className={styles.brandMark} aria-hidden="true">
              TPH
            </span>
            <div>
              <p className={styles.brandName}>Tu Progreso Hoy</p>
              <p className={styles.brandTagline}>
                Educational SaaS with trusted Argentina economic data and practical learning paths.
              </p>
            </div>
          </div>

          <div className={styles.ctaBox}>
            <p className={styles.ctaTitle}>Stay informed with weekly insights</p>
            <Link to="/resources" className="btn btn-primary animated-cta">
              Browse the latest insights
            </Link>
          </div>
        </div>

        <div className={styles.middleRow}>
          <div>
            <h3 className={styles.columnTitle}>Navigate</h3>
            <ul className={styles.linkList}>
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <Link to="/about">About</Link>
              </li>
              <li>
                <Link to="/services">Services</Link>
              </li>
              <li>
                <Link to="/course">Course</Link>
              </li>
              <li>
                <Link to="/inflation">Inflation Data</Link>
              </li>
              <li>
                <Link to="/resources">Resources</Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className={styles.columnTitle}>Contact</h3>
            <address className={styles.address}>
              <span>Av. 9 de Julio 1000</span>
              <span>C1043 Buenos Aires, Argentina</span>
              <span>Phone: <a href="tel:+541155551234">+54 11 5555-1234</a></span>
              <span>
                Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
              </span>
            </address>
          </div>

          <div>
            <h3 className={styles.columnTitle}>Policy</h3>
            <ul className={styles.linkList}>
              <li>
                <Link to="/privacy">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/terms">Terms of Service</Link>
              </li>
              <li>
                <Link to="/cookies">Cookie Policy</Link>
              </li>
            </ul>
            <div className={styles.socials}>
              <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
                <span aria-hidden="true">in</span>
              </a>
              <a href="https://www.twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
                <span aria-hidden="true">tw</span>
              </a>
              <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
                <span aria-hidden="true">yt</span>
              </a>
            </div>
          </div>
        </div>

        <div className={styles.bottomRow}>
          <p className={styles.disclaimer}>
            Plataforma educativa con datos esenciales, sin asesoría financiera directa. We do not
            provide financial services or investment guarantees.
          </p>
          <p className={styles.copy}>
            © {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;