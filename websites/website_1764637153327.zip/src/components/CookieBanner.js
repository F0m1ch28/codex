import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

function CookieBanner({
  visible,
  initialPreferences,
  onAcceptAll,
  onRejectAll,
  onSavePreferences
}) {
  const [showPreferences, setShowPreferences] = useState(false);
  const [preferences, setPreferences] = useState(
    initialPreferences || {
      essential: true,
      analytics: false,
      marketing: false
    }
  );

  useEffect(() => {
    setPreferences(initialPreferences || { essential: true, analytics: false, marketing: false });
  }, [initialPreferences]);

  if (!visible) {
    return null;
  }

  const handlePreferenceChange = (event) => {
    const { name, checked } = event.target;
    setPreferences((prev) => ({
      ...prev,
      [name]: checked
    }));
  };

  const handleSave = () => {
    onSavePreferences(preferences);
    setShowPreferences(false);
  };

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <div className={styles.text}>
          <h2 className={styles.title}>Cookies keep the insights flowing</h2>
          <p className={styles.description}>
            We use essential cookies to make the platform work, plus optional analytics to understand
            how our educational materials perform. No marketing trackers, no surprises. Learn more in
            our <Link to="/cookies">Cookie Policy</Link>.
          </p>
        </div>
        <div className={styles.actions}>
          <button type="button" className={styles.reject} onClick={onRejectAll}>
            Reject All
          </button>
          <button
            type="button"
            className={styles.customize}
            onClick={() => setShowPreferences((prev) => !prev)}
            aria-expanded={showPreferences}
            aria-controls="cookie-preferences"
          >
            Customize
          </button>
          <button type="button" className={styles.accept} onClick={onAcceptAll}>
            Accept All
          </button>
        </div>
      </div>

      {showPreferences && (
        <div className={styles.preferences} id="cookie-preferences">
          <h3>Choose how Tu Progreso Hoy can use cookies:</h3>
          <ul>
            <li>
              <div>
                <p className={styles.prefTitle}>Essential</p>
                <p className={styles.prefText}>Required for site features. Always on.</p>
              </div>
              <input type="checkbox" checked disabled />
            </li>
            <li>
              <div>
                <p className={styles.prefTitle}>Analytics</p>
                <p className={styles.prefText}>
                  Help us understand which lessons and dashboards are most helpful.
                </p>
              </div>
              <input
                type="checkbox"
                name="analytics"
                checked={preferences.analytics}
                onChange={handlePreferenceChange}
              />
            </li>
            <li>
              <div>
                <p className={styles.prefTitle}>Marketing</p>
                <p className={styles.prefText}>
                  Optional updates about live cohorts and community events. Low frequency.
                </p>
              </div>
              <input
                type="checkbox"
                name="marketing"
                checked={preferences.marketing}
                onChange={handlePreferenceChange}
              />
            </li>
          </ul>
          <div className={styles.prefActions}>
            <button type="button" onClick={handleSave} className={styles.save}>
              Save my choices
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default CookieBanner;