document.addEventListener("DOMContentLoaded", () => {
    const nav = document.querySelector("[data-nav]");
    const navToggle = nav ? nav.querySelector(".nav-toggle") : null;
    const navLinks = nav ? nav.querySelectorAll(".nav-links a") : [];

    if (navToggle) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            nav.classList.toggle("open");
        });

        navLinks.forEach(link => {
            link.addEventListener("click", () => {
                navToggle.setAttribute("aria-expanded", "false");
                nav.classList.remove("open");
            });
        });
    }

    const animateTargets = document.querySelectorAll("[data-animate]");
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("animated");
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15 });
    animateTargets.forEach(target => observer.observe(target));

    const toast = document.getElementById("global-toast");
    function showToast(message) {
        if (!toast) return;
        toast.textContent = message;
        toast.classList.add("visible");
        setTimeout(() => toast.classList.remove("visible"), 3200);
    }

    const forms = document.querySelectorAll("form[data-redirect]");
    forms.forEach(form => {
        form.addEventListener("submit", event => {
            event.preventDefault();
            const redirectUrl = form.dataset.redirect || form.getAttribute("action") || "thank-you.html";
            showToast("Form submitted. Redirecting shortly.");
            setTimeout(() => {
                window.location.href = redirectUrl;
            }, 1800);
        });
    });

    const cookieBanner = document.getElementById("cookie-banner");
    const COOKIE_KEY = "htl_cookie_preference";

    if (cookieBanner) {
        const stored = localStorage.getItem(COOKIE_KEY);
        if (!stored) {
            requestAnimationFrame(() => cookieBanner.classList.remove("hidden"));
        }

        cookieBanner.addEventListener("click", event => {
            const button = event.target.closest("[data-cookie-consent]");
            if (!button) return;
            const choice = button.getAttribute("data-cookie-consent");
            localStorage.setItem(COOKIE_KEY, choice);
            cookieBanner.classList.add("hidden");
            showToast(`Cookie preference saved: ${choice}`);
        });
    }
});