```javascript
import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const LanguageToggle = () => {
  const { language, toggleLanguage } = useLanguage();

  return (
    <div className="language-toggle" role="group" aria-label="Language selection">
      <button
        type="button"
        onClick={() => toggleLanguage('en')}
        className={language === 'en' ? 'active' : ''}
        aria-pressed={language === 'en'}
      >
        EN
      </button>
      <button
        type="button"
        onClick={() => toggleLanguage('es')}
        className={language === 'es' ? 'active' : ''}
        aria-pressed={language === 'es'}
      >
        ES
      </button>
    </div>
  );
};

export default LanguageToggle;
```