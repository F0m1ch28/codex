```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const Footer = () => {
  const { language } = useLanguage();

  return (
    <footer className="footer" role="contentinfo">
      <div className="footer-grid">
        <div>
          <h3>Tu Progreso Hoy</h3>
          <p>
            Datos verificados para planificar tu presupuesto.<br />
            Decisiones responsables, objetivos nítidos.
          </p>
          <p style={{ fontSize: '0.95rem', opacity: 0.85 }}>
            Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
        </div>
        <div>
          <h4>{language === 'en' ? 'Explore' : 'Explora'}</h4>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'grid', gap: '0.5rem' }}>
            <li><Link to="/inflation">Inflation insights</Link></li>
            <li><Link to="/course">Course</Link></li>
            <li><Link to="/resources">Resources</Link></li>
            <li><Link to="/faq">FAQ</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4>{language === 'en' ? 'Legal' : 'Cumplimiento'}</h4>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'grid', gap: '0.5rem' }}>
            <li><Link to="/privacy">Privacy</Link></li>
            <li><Link to="/cookies">Cookies</Link></li>
            <li><Link to="/terms">Terms</Link></li>
            <li><a href="https://www.tuprogresohoy.com/sitemap.xml">Sitemap</a></li>
          </ul>
        </div>
        <div>
          <h4>{language === 'en' ? 'Contact' : 'Contacto'}</h4>
          <p>Av. 9 de Julio 1000<br />C1043 Buenos Aires, Argentina</p>
          <p>
            {language === 'en' ? 'Phone' : 'Teléfono'}: <a href="tel:+541155551234">+54 11 5555-1234</a><br />
            Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
          </p>
          <p>
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>{' '}
            ·{' '}
            <a href="https://twitter.com" target="_blank" rel="noreferrer">
              X/Twitter
            </a>
          </p>
        </div>
      </div>
      <div className="footer-bottom">
        <p>
          Conocimiento financiero impulsado por tendencias. Pasos acertados hoy, mejor futuro mañana.
        </p>
        <p>Análisis transparentes y datos de mercado para decidir con seguridad.</p>
        <p>
          &copy; {new Date().getFullYear()} Tu Progreso Hoy. Información confiable que respalda elecciones responsables sobre tu dinero.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
```