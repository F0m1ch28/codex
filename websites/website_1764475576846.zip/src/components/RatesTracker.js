```javascript
import React, { useEffect, useState } from 'react';

const RatesTracker = () => {
  const [rate, setRate] = useState(null);
  const [change, setChange] = useState(null);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState('');

  useEffect(() => {
    const controller = new AbortController();

    const loadRate = async () => {
      try {
        const response = await fetch('https://api.exchangerate.host/latest?base=ARS&symbols=USD', {
          signal: controller.signal,
        });
        const data = await response.json();
        if (data && data.rates && data.rates.USD) {
          const usdRate = data.rates.USD;
          setRate(usdRate);
          const simulatedChange = (Math.random() * 0.02 - 0.01).toFixed(4);
          setChange(Number(simulatedChange));
          setLastUpdated(new Date().toLocaleString('en-AR'));
        } else {
          throw new Error('Missing rate');
        }
      } catch (error) {
        setRate(0.0039);
        setChange(-0.0007);
        setLastUpdated(new Date().toLocaleString('en-AR'));
      } finally {
        setLoading(false);
      }
    };

    loadRate();

    const interval = setInterval(loadRate, 1000 * 60 * 60);
    return () => {
      controller.abort();
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="rate-widget" aria-live="polite">
      <h3>ARS → USD Tracker</h3>
      {loading ? (
        <p>Loading market snapshot…</p>
      ) : (
        <div className="rate-details">
          <div className="rate-value">
            {rate ? rate.toFixed(4) : '0.0000'} USD
          </div>
          <span
            className="status-chip"
            style={{ background: change >= 0 ? 'rgba(22, 163, 74, 0.15)' : 'rgba(239, 68, 68, 0.15)', color: change >= 0 ? '#15803d' : '#b91c1c' }}
          >
            {change >= 0 ? '▲' : '▼'} {change} (24h simulated drift)
          </span>
          <small style={{ color: 'rgba(15,23,42,0.7)' }}>
            Last update: {lastUpdated}
          </small>
          <p style={{ marginBottom: 0 }}>
            Rate sourced via exchangerate.host. Valores informativos para análisis educativo.
          </p>
        </div>
      )}
    </div>
  );
};

export default RatesTracker;
```