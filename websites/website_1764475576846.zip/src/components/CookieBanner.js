```javascript
import React, { useEffect, useState } from 'react';

const storageKey = 'tph_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem(storageKey);
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const handleAction = (value) => {
    window.localStorage.setItem(storageKey, value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie consent">
      <strong>Cookies &amp; analytics preference</strong>
      <p>
        We use cookies to measure engagement and improve the learning experience. You can accept analytics cookies or decline and continue with essential cookies only.
      </p>
      <div className="cookie-banner-buttons">
        <button className="button secondary" onClick={() => handleAction('declined')}>
          Decline
        </button>
        <button className="button" onClick={() => handleAction('accepted')}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;
```