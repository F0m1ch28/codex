```javascript
import React from 'react';
import { NavLink } from 'react-router-dom';
import LanguageToggle from './LanguageToggle';
import { useLanguage } from '../context/LanguageContext';

const Header = () => {
  const { language } = useLanguage();

  const navItems = [
    { path: '/', label: language === 'en' ? 'Home' : 'Inicio' },
    { path: '/inflation', label: language === 'en' ? 'Inflation' : 'Inflación' },
    { path: '/course', label: language === 'en' ? 'Course' : 'Curso' },
    { path: '/resources', label: language === 'en' ? 'Resources' : 'Recursos' },
    { path: '/faq', label: language === 'en' ? 'FAQ' : 'Preguntas' },
    { path: '/contact', label: language === 'en' ? 'Contact' : 'Contacto' },
  ];

  return (
    <header className="header" role="banner">
      <div className="header-inner">
        <NavLink to="/" className="logo" aria-label="Tu Progreso Hoy homepage">
          Tu Progreso Hoy
          <span>Financial Learning Hub</span>
        </NavLink>
        <nav className="nav" aria-label="Primary navigation">
          {navItems.map((item) => (
            <NavLink key={item.path} to={item.path} end>
              {item.label}
            </NavLink>
          ))}
          <NavLink to="/course" className="button secondary" style={{ padding: '0.6rem 1rem' }}>
            {language === 'en' ? 'View Syllabus' : 'Ver programa'}
          </NavLink>
        </nav>
        <LanguageToggle />
      </div>
    </header>
  );
};

export default Header;
```