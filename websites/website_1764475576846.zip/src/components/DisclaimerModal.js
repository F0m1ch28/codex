```javascript
import React, { useEffect, useState } from 'react';

const storageKey = 'tph_disclaimer_ack';

const DisclaimerModal = () => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem(storageKey);
    if (!stored) {
      const timer = setTimeout(() => setOpen(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const closeModal = () => {
    window.localStorage.setItem(storageKey, 'seen');
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="disclaimer-modal" role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
      <div className="disclaimer-content">
        <h3 id="disclaimer-title">Important transparency note</h3>
        <p style={{ fontWeight: 600, color: '#1f3a6f' }}>
          Мы не предоставляем финансовые услуги.
          <br />
          We do not provide financial services.
        </p>
        <p>
          Tu Progreso Hoy is an educational platform focused on helping people interpret verified information, market trends, and inflation context. Nothing on this website is an individual recommendation.
        </p>
        <button className="button" onClick={closeModal}>
          I understand
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;
```