```javascript
import React from 'react';
import { Link } from 'react-router-dom';

const NotFound = () => (
  <div className="page not-found">
    <section className="section light" aria-labelledby="not-found-title">
      <div className="container" style={{ textAlign: 'center' }}>
        <div className="badge">404</div>
        <h1 id="not-found-title">Page not found</h1>
        <p>
          The page you are looking for may have been moved. Return to the homepage to continue exploring financial learning resources.
        </p>
        <Link to="/" className="button">
          Go home
        </Link>
      </div>
    </section>
  </div>
);

export default NotFound;
```