```javascript
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import RatesTracker from '../components/RatesTracker';
import { useLanguage } from '../context/LanguageContext';

const Home = () => {
  const { language } = useLanguage();
  const [step, setStep] = useState(1);
  const [optIn, setOptIn] = useState(false);
  const [confirmAck, setConfirmAck] = useState(false);

  const handleFirstSubmit = (event) => {
    event.preventDefault();
    if (!optIn) return;
    setStep(2);
  };

  const handleConfirmation = (event) => {
    event.preventDefault();
    if (!confirmAck) return;
    window.location.href = '/thank-you';
  };

  return (
    <div className="home">
      <section className="hero" role="region" aria-labelledby="hero-title">
        <div className="container">
          <div>
            <div className="badge">Buenos Aires · Financial Education</div>
            <h1 id="hero-title">
              Data-driven learning hub for Argentina&apos;s evolving economy.
            </h1>
            <p>
              Análisis transparentes y datos de mercado para decidir con seguridad. Información confiable que respalda elecciones responsables sobre tu dinero.
            </p>
            <div className="hero-actions">
              <Link to="/course" className="button">
                {language === 'en' ? 'Explore the course' : 'Explorar el curso'}
              </Link>
              <Link to="/inflation" className="button secondary">
                {language === 'en' ? 'Inflation methodology' : 'Metodología inflacionaria'}
              </Link>
            </div>
            <div className="tag-list" aria-label="Key promises">
              <span className="tag">Datos verificados para planificar tu presupuesto.</span>
              <span className="tag">Decisiones responsables, objetivos nítidos.</span>
              <span className="tag">Conocimiento financiero impulsado por tendencias.</span>
              <span className="tag">Pasos acertados hoy, mejor futuro mañana.</span>
            </div>
          </div>
          <RatesTracker />
        </div>
      </section>

      <section className="section light" aria-labelledby="insights-title">
        <div className="container">
          <div className="badge">{language === 'en' ? 'Insights' : 'Perspectivas'}</div>
          <h2 id="insights-title">
            Follow macro signals with clarity and confidence.
          </h2>
          <p>
            Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
          </p>
          <div className="grid three">
            <div className="card">
              <h3>{language === 'en' ? 'Weekly Inflation Pulse' : 'Pulso inflacionario semanal'}</h3>
              <p>
                Review CPI variance, food price trackers, and policy announcements shaping purchasing power in Argentina.
              </p>
              <Link to="/inflation" className="button secondary">
                {language === 'en' ? 'See details' : 'Ver detalles'}
              </Link>
            </div>
            <div className="card">
              <h3>{language === 'en' ? 'FX Market Brief' : 'Resumen cambiario'}</h3>
              <p>
                Monitor ARS reference rates, blue market differentials, and seasonal factors that influence currency spreads.
              </p>
              <Link to="/resources" className="button secondary">
                {language === 'en' ? 'Browse resources' : 'Ver recursos'}
              </Link>
            </div>
            <div className="card">
              <h3>{language === 'en' ? 'Learning Sessions' : 'Sesiones educativas'}</h3>
              <p>
                Cohort-based lessons with bilingual materials help you apply the data to budgeting, forecasting, and responsible planning.
              </p>
              <Link to="/course" className="button secondary">
                {language === 'en' ? 'Course modules' : 'Módulos del curso'}
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="section dark" aria-labelledby="course-overview-title">
        <div className="container">
          <div className="badge" style={{ background: 'rgba(148, 163, 184, 0.35)', color: '#fff' }}>
            {language === 'en' ? 'Course Overview' : 'Resumen del curso'}
          </div>
          <h2 id="course-overview-title">
            A bilingual curriculum designed for Argentina&apos;s realities.
          </h2>
          <div className="grid two">
            <div>
              <h3>{language === 'en' ? 'What you will learn' : 'Lo que aprenderás'}</h3>
              <ul>
                <li>Macro indicators that shape household budgets.</li>
                <li>Scenario planning tools for Argentine pesos and US dollars.</li>
                <li>How to read inflation releases and FX bulletins critically.</li>
              </ul>
            </div>
            <div>
              <h3>{language === 'en' ? 'Format' : 'Formato'}</h3>
              <p>
                Live virtual workshops, self-paced materials, and community forums. Each module includes summaries in English and Español for inclusive access.
              </p>
              <Link to="/course" className="button" style={{ marginTop: '1rem' }}>
                {language === 'en' ? 'View full syllabus' : 'Ver programa completo'}
              </Link>
            </div>
          </div>
          <p style={{ marginTop: '2rem', fontSize: '0.95rem' }}>
            Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
        </div>
      </section>

      <section className="section light" aria-labelledby="testimonials-title">
        <div className="container">
          <div className="badge">{language === 'en' ? 'Voices from learners' : 'Testimonios'}</div>
          <h2 id="testimonials-title">
            Learners from Buenos Aires, Córdoba, and Mendoza share their experiences.
          </h2>
          <div className="grid three">
            <article className="testimonial-card">
              <blockquote>
                “The CPI dashboards make it easier to explain price movements to my family. Having Spanish summaries helps everyone follow.”
              </blockquote>
              <p><strong>Lucía Gómez</strong><br />Family budget planner, Buenos Aires</p>
            </article>
            <article className="testimonial-card">
              <blockquote>
                “Understanding ARS to USD dynamics in context changed how we schedule purchases for our business.”
              </blockquote>
              <p><strong>Carlos Perez</strong><br />Retail manager, Córdoba</p>
            </article>
            <article className="testimonial-card">
              <blockquote>
                “The methodology section clarifies what is data-driven and what is commentary. It keeps expectations grounded.”
              </blockquote>
              <p><strong>Marina Torres</strong><br />Freelancer, Mendoza</p>
            </article>
          </div>
        </div>
      </section>

      <section className="section light" id="trial" aria-labelledby="trial-form-title">
        <div className="container form-wrapper">
          <div className="badge">Double Opt-In · Ensuring consent</div>
          <h2 id="trial-form-title">Request your complimentary learning session</h2>
          <p>
            Pasos acertados hoy, mejor futuro mañana. Complete the first step below; we will email you a confirmation link to activate access to the trial lesson.
          </p>
          {step === 1 && (
            <form onSubmit={handleFirstSubmit}>
              <div>
                <label htmlFor="name-input">Full name</label>
                <input id="name-input" name="name" type="text" required placeholder="Your name" />
              </div>
              <div>
                <label htmlFor="email-input">Email</label>
                <input id="email-input" name="email" type="email" required placeholder="you@email.com" />
              </div>
              <div>
                <label htmlFor="language-select">Preferred language for materials</label>
                <select id="language-select" name="materialLanguage" defaultValue="es">
                  <option value="en">English</option>
                  <option value="es">Español</option>
                  <option value="bilingual">Bilingual</option>
                </select>
              </div>
              <div>
                <label htmlFor="focus-area">Focus area</label>
                <textarea id="focus-area" name="focus" rows="3" placeholder="Tell us about your budgeting or planning goals" />
              </div>
              <div>
                <label>
                  <input
                    type="checkbox"
                    required
                    onChange={(event) => setOptIn(event.target.checked)}
                    aria-describedby="optin-description"
                  />{' '}
                  {language === 'en'
                    ? 'I request to join the mailing list and agree to receive the confirmation email.'
                    : 'Solicito unirme a la lista y acepto recibir el correo de confirmación.'}
                </label>
                <p id="optin-description" style={{ fontSize: '0.9rem', color: 'rgba(15,23,42,0.7)' }}>
                  Step 1 · We will only send materials after you confirm in Step 2.
                </p>
              </div>
              <button className="button" type="submit" aria-label="Proceed to email confirmation step">
                Получить бесплатный пробный урок
              </button>
            </form>
          )}
          {step === 2 && (
            <form onSubmit={handleConfirmation}>
              <div className="alert">
                Step 2 · Check your inbox for the confirmation email. Click the confirmation link, then mark the checkbox below to simulate completion.
              </div>
              <label>
                <input
                  type="checkbox"
                  onChange={(event) => setConfirmAck(event.target.checked)}
                  required
                />{' '}
                I confirm I have validated my email through the link.
              </label>
              <p style={{ fontSize: '0.9rem', color: 'rgba(15,23,42,0.7)' }}>
                After confirming, click the button to finalize your complimentary trial access.
              </p>
              <button className="button" type="submit">
                Finish double opt-in &amp; continue
              </button>
            </form>
          )}
          <p style={{ fontSize: '0.9rem', marginTop: '1rem', color: 'rgba(15,23,42,0.7)' }}>
            Conocimiento financiero impulsado por tendencias. De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Home;
```