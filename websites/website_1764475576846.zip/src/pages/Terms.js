```javascript
import React from 'react';

const Terms = () => (
  <div className="page terms">
    <section className="section light" aria-labelledby="terms-title">
      <div className="container">
        <div className="badge">Terms</div>
        <h1 id="terms-title">Terms &amp; Conditions</h1>
        <p>
          These terms govern the use of Tu Progreso Hoy’s website and educational services. By accessing the site you agree to the following conditions.
        </p>
        <h2>Educational purpose</h2>
        <p>
          Our content is for educational use only. Мы не предоставляем финансовые услуги. We do not provide financial services or individualized investment recommendations.
        </p>
        <h2>User responsibilities</h2>
        <ul>
          <li>Verify the accuracy of data before making financial decisions.</li>
          <li>Respect intellectual property of course materials.</li>
          <li>Abstain from sharing login credentials or community content without consent.</li>
        </ul>
        <h2>Limitations of liability</h2>
        <p>
          Tu Progreso Hoy is not liable for decisions taken based on site content. We provide data context and learning tools meant to strengthen independent judgment.
        </p>
        <h2>Payments and refunds</h2>
        <p>
          Paid cohorts follow a separate agreement outlining payment schedules and refund policies. The trial session is complimentary.
        </p>
        <h2>Governing law</h2>
        <p>
          These terms are governed by the laws of Argentina. Any disputes will be resolved in courts located in Buenos Aires.
        </p>
      </div>
    </section>
  </div>
);

export default Terms;
```