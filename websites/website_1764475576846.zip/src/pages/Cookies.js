```javascript
import React from 'react';

const Cookies = () => (
  <div className="page cookies">
    <section className="section light" aria-labelledby="cookies-title">
      <div className="container">
        <div className="badge">Cookies</div>
        <h1 id="cookies-title">Cookie Policy</h1>
        <p>
          Tu Progreso Hoy uses cookies to enable essential site functionality and to analyze engagement when you provide consent.
        </p>
        <h2>Types of cookies</h2>
        <ul>
          <li><strong>Essential cookies:</strong> Required for navigation and form submissions. These are always active.</li>
          <li><strong>Analytics cookies:</strong> Help us understand how learners use the site. Activated only after you click “Accept” in the cookie banner.</li>
        </ul>
        <h2>Managing preferences</h2>
        <p>
          You can manage your cookie settings through the banner or adjust browser preferences. Declining analytics cookies will not limit access to content.
        </p>
        <h2>Data retention</h2>
        <p>
          Analytics cookies expire within 13 months. We refresh consent periodically to honor your choices.
        </p>
        <h2>Contact</h2>
        <p>
          For questions about this policy, email hola@tuprogresohoy.com.
        </p>
      </div>
    </section>
  </div>
);

export default Cookies;
```