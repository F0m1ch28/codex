```javascript
import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const resources = [
  {
    title: 'Weekly Inflation Brief',
    en: 'Executive summary in English covering CPI releases, surprises, and policy headlines.',
    es: 'Resumen ejecutivo en Español con los principales datos del IPC, sorpresas y titulares de política económica.',
    link: '#',
  },
  {
    title: 'Glossary · Argentina FX terms',
    en: 'Clarifies commonly used terms such as dólar oficial, dólar MEP, and blue chip swap.',
    es: 'Aclara términos frecuentes como dólar oficial, dólar MEP y contado con liquidación.',
    link: '#',
  },
  {
    title: 'Budget Template · Peso/Dollar',
    en: 'Spreadsheet template for aligning expenses and income across currencies.',
    es: 'Plantilla de hoja de cálculo para alinear ingresos y gastos entre monedas.',
    link: '#',
  },
  {
    title: 'Policy Tracker',
    en: 'Timeline of fiscal and monetary announcements relevant to household planning.',
    es: 'Cronología de anuncios fiscales y monetarios relevantes para la planificación del hogar.',
    link: '#',
  },
];

const Resources = () => {
  const { language } = useLanguage();

  return (
    <div className="page resources">
      <section className="section light" aria-labelledby="resources-title">
        <div className="container">
          <div className="badge">{language === 'en' ? 'Resources' : 'Recursos'}</div>
          <h1 id="resources-title">Bilingual articles, glossaries, and tools</h1>
          <p>
            Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. Each resource includes English and Español formats so your entire household or team can learn together.
          </p>
          <div className="resources-list" role="list">
            {resources.map((resource) => (
              <article className="resource-card" key={resource.title} role="listitem">
                <h3>{resource.title}</h3>
                <p><strong>EN:</strong> {resource.en}</p>
                <p><strong>ES:</strong> {resource.es}</p>
                <a href={resource.link} className="button secondary" aria-label={`Open resource ${resource.title}`}>
                  {language === 'en' ? 'Access resource' : 'Acceder al recurso'}
                </a>
              </article>
            ))}
          </div>
          <div className="notice-box" style={{ marginTop: '2rem' }}>
            Pasos acertados hoy, mejor futuro mañana. Platform materials are informative guides designed to build financial literacy.
          </div>
        </div>
      </section>
    </div>
  );
};

export default Resources;
```