```javascript
import React from 'react';
import { Link } from 'react-router-dom';

const ThankYou = () => {
  return (
    <div className="page thank-you">
      <section className="section light" aria-labelledby="thank-title">
        <div className="container">
          <div className="badge">Double opt-in confirmed</div>
          <h1 id="thank-title">Thank you for confirming your email</h1>
          <p>
            You will receive the onboarding pack for the complimentary session within the next business day. If it does not arrive, please check spam folders or contact hola@tuprogresohoy.com.
          </p>
          <p>
            Información confiable que respalda elecciones responsables sobre tu dinero. We look forward to learning with you.
          </p>
          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
            <Link to="/" className="button">
              Return home
            </Link>
            <Link to="/resources" className="button secondary">
              Explore resources
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ThankYou;
```