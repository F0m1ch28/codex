```javascript
import React from 'react';

const Privacy = () => (
  <div className="page privacy">
    <section className="section light" aria-labelledby="privacy-title">
      <div className="container">
        <div className="badge">Privacy</div>
        <h1 id="privacy-title">Privacy Policy</h1>
        <p>
          This privacy policy explains how Tu Progreso Hoy collects, uses, and safeguards personal information. Our focus is educational services and community engagement.
        </p>
        <h2>Information we collect</h2>
        <ul>
          <li>Contact details submitted through forms (name, email, language preference).</li>
          <li>Voluntary survey responses regarding learning goals.</li>
          <li>Analytics data gathered via cookies if you provide consent.</li>
        </ul>
        <h2>How we use information</h2>
        <ul>
          <li>Send educational materials after double opt-in confirmation.</li>
          <li>Respond to inquiries and provide support.</li>
          <li>Improve our curriculum based on aggregated analytics.</li>
        </ul>
        <h2>Data protection</h2>
        <p>
          We store information in secure systems with restricted access. We do not sell personal data and we do not provide financial services.
        </p>
        <h2>Your rights</h2>
        <p>
          You may request access, correction, or deletion of your data by emailing hola@tuprogresohoy.com. You may unsubscribe at any time using the link in our emails.
        </p>
        <h2>International transfers</h2>
        <p>
          Some service providers may be located outside Argentina. We ensure they comply with adequate data protection frameworks.
        </p>
        <h2>Updates</h2>
        <p>We may update this policy periodically. The revision date will be noted at the top of the page.</p>
        <p style={{ marginTop: '2rem' }}>
          Effective date: {new Date().getFullYear()}.
        </p>
      </div>
    </section>
  </div>
);

export default Privacy;
```