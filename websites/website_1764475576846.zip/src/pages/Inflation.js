```javascript
import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const inflationSeries = [
  { month: 'Jan', cpi: 5.8, fx: 1.7 },
  { month: 'Feb', cpi: 6.2, fx: 2.1 },
  { month: 'Mar', cpi: 7.1, fx: 2.3 },
  { month: 'Apr', cpi: 6.7, fx: 1.9 },
  { month: 'May', cpi: 5.6, fx: 1.4 },
  { month: 'Jun', cpi: 5.2, fx: 1.2 },
];

const faqItems = [
  {
    question: 'How frequently is the inflation dashboard updated?',
    answer:
      'We refresh CPI data as soon as new INDEC releases are published. FX references are updated weekly using public market sources.',
  },
  {
    question: 'What methodology is used to compute the weighted basket?',
    answer:
      'We track a basket aligned with urban households, weighting food, energy, mobility, and services. The weighting follows INDEC guidelines with quarterly adjustments.',
  },
  {
    question: 'Does Tu Progreso Hoy provide projections?',
    answer:
      'We offer scenario ranges based on trend analysis but not explicit forecasts. The coursework emphasizes how to interpret ranges responsibly.',
  },
  {
    question: 'Where do FX figures originate?',
    answer:
      'FX data references official wholesale rates, blue market indicators, and regulated channels. We cite the source in each weekly brief.',
  },
];

const Inflation = () => {
  const { language } = useLanguage();

  return (
    <div className="page inflation">
      <section className="section light" aria-labelledby="methodology-title">
        <div className="container">
          <div className="badge">{language === 'en' ? 'Methodology' : 'Metodología'}</div>
          <h1 id="methodology-title">Transparent methodology for Argentine inflation tracking</h1>
          <p>
            Our approach focuses on clarity. We combine official CPI releases with complementary data to map short-term price stress and medium-term dynamics.
          </p>
          <div className="grid two">
            <div className="notice-box">
              <h3>Key principles</h3>
              <ul>
                <li>Source: INDEC CPI, provincial stats, and energy price boards.</li>
                <li>Frequency: Weekly updates with historical context.</li>
                <li>Bias checks: Cross-compare against grocery and transport sub-indices.</li>
              </ul>
            </div>
            <div className="notice-box">
              <h3>Scope</h3>
              <ul>
                <li>Urban households with mixed peso/dollar expenses.</li>
                <li>Domestic inflation interactions with FX shifts.</li>
                <li>Educational insights, not individual recommendations.</li>
              </ul>
            </div>
          </div>
          <p style={{ marginTop: '1.5rem' }}>
            Conocimiento financiero impulsado por tendencias. Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
        </div>
      </section>

      <section className="section light" aria-labelledby="chart-title">
        <div className="container">
          <div className="badge">CPI · FX Context</div>
          <h2 id="chart-title">Monthly CPI change vs. ARS depreciation</h2>
          <svg className="chart" role="img" aria-label="Line chart comparing CPI and FX change">
            <desc>Illustrative chart showing CPI monthly change and FX depreciation percentages.</desc>
            <g>
              <line x1="50" y1="20" x2="50" y2="220" stroke="#CBD5F5" strokeWidth="1" />
              <line x1="50" y1="220" x2="520" y2="220" stroke="#CBD5F5" strokeWidth="1" />
              {inflationSeries.map((item, index) => {
                const x = 50 + index * 80;
                const cpiY = 220 - item.cpi * 20;
                const fxY = 220 - item.fx * 40;
                return (
                  <g key={item.month}>
                    <circle cx={x} cy={cpiY} r="5" fill="#2563eb">
                      <title>{`${item.month} CPI ${item.cpi}%`}</title>
                    </circle>
                    {index < inflationSeries.length - 1 && (
                      <line
                        x1={x}
                        y1={cpiY}
                        x2={50 + (index + 1) * 80}
                        y2={220 - inflationSeries[index + 1].cpi * 20}
                        stroke="#2563eb"
                        strokeWidth="2"
                      />
                    )}
                    <rect x={x - 4} y={fxY} width="8" height={220 - fxY} fill="rgba(15,23,42,0.3)">
                      <title>{`${item.month} FX ${item.fx}%`}</title>
                    </rect>
                    <text x={x} y={240} textAnchor="middle" fill="rgba(15,23,42,0.7)" fontSize="12">
                      {item.month}
                    </text>
                  </g>
                );
              })}
            </g>
          </svg>
          <div className="grid two">
            <div>
              <h3>{language === 'en' ? 'Reading the chart' : 'Cómo leer el gráfico'}</h3>
              <p>
                The blue line tracks monthly CPI change. The shaded columns capture ARS depreciation against USD. When both rise, household budgets face additive pressure.
              </p>
            </div>
            <div>
              <h3>{language === 'en' ? 'Scenario interpretation' : 'Interpretación de escenarios'}</h3>
              <p>
                Learners discuss mitigating strategies such as expense scheduling, cash flow buffers, and milestone planning. Información confiable que respalda elecciones responsables sobre tu dinero.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section light" aria-labelledby="faq-title">
        <div className="container">
          <div className="badge">{language === 'en' ? 'FAQ' : 'Preguntas frecuentes'}</div>
          <h2 id="faq-title">Frequently asked questions about our inflation toolkit</h2>
          <div className="timeline" role="list">
            {faqItems.map((item) => (
              <div className="timeline-item" key={item.question} role="listitem">
                <h3>{item.question}</h3>
                <p>{item.answer}</p>
              </div>
            ))}
          </div>
          <div className="notice-box" style={{ marginTop: '2rem' }}>
            <strong>Disclaimer:</strong> We contextualize inflation and FX data for educational purposes only. Decisions remain the responsibility of each participant.
          </div>
        </div>
      </section>
    </div>
  );
};

export default Inflation;
```