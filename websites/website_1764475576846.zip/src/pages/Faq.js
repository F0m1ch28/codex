```javascript
import React from 'react';

const faqs = [
  {
    q: 'Is the content suitable for beginners?',
    a: 'Yes. We start with foundational explanations before moving to data interpretation.',
  },
  {
    q: 'Do you provide investment advice?',
    a: 'No. Plataforma educativa con datos esenciales, sin asesoría financiera directa.',
  },
  {
    q: 'How does the double opt-in work?',
    a: 'You submit the request form, confirm via email, and only then receive materials.',
  },
  {
    q: 'Are there live classes?',
    a: 'Yes. We host live virtual workshops with bilingual support and recordings.',
  },
  {
    q: 'Can companies enroll teams?',
    a: 'Yes. Contact us to schedule a tailored onboarding for your team.',
  },
  {
    q: 'What if I need support?',
    a: 'Email hola@tuprogresohoy.com and we will respond within one business day.',
  },
];

const Faq = () => (
  <div className="page faq">
    <section className="section light" aria-labelledby="faq-page-title">
      <div className="container">
        <div className="badge">FAQ</div>
        <h1 id="faq-page-title">Frequently Asked Questions</h1>
        <div className="timeline" role="list">
          {faqs.map((item) => (
            <div className="timeline-item" key={item.q} role="listitem">
              <h3>{item.q}</h3>
              <p>{item.a}</p>
            </div>
          ))}
        </div>
        <div className="notice-box" style={{ marginTop: '2rem' }}>
          De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
        </div>
      </div>
    </section>
  </div>
);

export default Faq;
```