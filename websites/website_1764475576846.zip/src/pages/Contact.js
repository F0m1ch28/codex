```javascript
import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const Contact = () => {
  const { language } = useLanguage();

  return (
    <div className="page contact">
      <section className="section light" aria-labelledby="contact-title">
        <div className="container">
          <div className="badge">{language === 'en' ? 'Contact' : 'Contacto'}</div>
          <h1 id="contact-title">Stay in touch with Tu Progreso Hoy</h1>
          <div className="grid two">
            <div>
              <h2>{language === 'en' ? 'Our office' : 'Nuestra oficina'}</h2>
              <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
              <p>
                {language === 'en' ? 'Phone' : 'Teléfono'}:{' '}
                <a href="tel:+541155551234">+54 11 5555-1234</a>
                <br />
                Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
              </p>
              <p>
                {language === 'en'
                  ? 'Office hours: Monday to Friday, 9:00 - 18:00 (ART).'
                  : 'Horario de atención: lunes a viernes de 9:00 a 18:00 (ART).'}
              </p>
              <div className="notice-box">
                Мы не предоставляем финансовые услуги. We do not provide financial services. Requests for personalized advice will be directed to independent professionals.
              </div>
            </div>
            <div>
              <h2>{language === 'en' ? 'Send us a message' : 'Envíanos un mensaje'}</h2>
              <form>
                <label htmlFor="contact-name">{language === 'en' ? 'Name' : 'Nombre'}</label>
                <input id="contact-name" name="name" type="text" required placeholder="Your name" />
                <label htmlFor="contact-email">Email</label>
                <input id="contact-email" name="email" type="email" required placeholder="you@email.com" />
                <label htmlFor="contact-message">{language === 'en' ? 'Message' : 'Mensaje'}</label>
                <textarea id="contact-message" name="message" rows="4" placeholder="Tell us how we can help" />
                <button type="submit" className="button">
                  {language === 'en' ? 'Send message' : 'Enviar mensaje'}
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      <section className="section light" aria-labelledby="map-title">
        <div className="container">
          <div className="badge">Buenos Aires</div>
          <h2 id="map-title">Find us in the heart of the city</h2>
          <div className="map-wrapper">
            <iframe
              title="Map showing Tu Progreso Hoy office location in Buenos Aires"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.12876854057!2d-58.38375968477037!3d-34.603734480459816!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccac72fc66507%3A0x42aa3c7a39863dbf!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1700000000000!5m2!1sen!2sar"
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
```