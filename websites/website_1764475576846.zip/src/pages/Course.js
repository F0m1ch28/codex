```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const modules = [
  {
    title: 'Module 1 · Measuring inflation signals',
    description: 'Understand CPI construction, basket weights, and how to interpret adjustments announced by INDEC.',
    outcomes: ['Identify key CPI sub-indices', 'Translate data releases into planning checkpoints'],
  },
  {
    title: 'Module 2 · Peso and dollar budgeting',
    description: 'Design dual-currency plans that reflect ARS volatility and dollar-referenced commitments.',
    outcomes: ['Build a peso-dollar calendar', 'Apply FX buffers responsibly'],
  },
  {
    title: 'Module 3 · Scenario playbooks',
    description: 'Craft optimistic, baseline, and stress scenarios using data-driven templates.',
    outcomes: ['Stress-test savings plans', 'Prioritize expenses with clarity'],
  },
  {
    title: 'Module 4 · Community workshop',
    description: 'Live discussions with peers across Argentina to share frameworks and questions.',
    outcomes: ['Co-create action checklists', 'Refine personal dashboards'],
  },
];

const Course = () => {
  const { language } = useLanguage();

  return (
    <div className="page course">
      <section className="section light" aria-labelledby="course-title">
        <div className="container">
          <div className="badge">{language === 'en' ? 'Curriculum' : 'Plan de estudios'}</div>
          <h1 id="course-title">Course syllabus and learning journey</h1>
          <p>
            Conocimiento financiero impulsado por tendencias. Every session includes bilingual resources so you can revise concepts in English and Español.
          </p>
          <div className="timeline" aria-label="Course modules">
            {modules.map((module) => (
              <div className="timeline-item" key={module.title}>
                <h3>{module.title}</h3>
                <p>{module.description}</p>
                <ul>
                  {module.outcomes.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="notice-box" style={{ marginTop: '2rem' }}>
            Plataforma educativa con datos esenciales, sin asesoría financiera directa. Our facilitators moderate discussions and provide methodological guidance.
          </div>
          <div style={{ marginTop: '2rem', display: 'flex', flexWrap: 'wrap', gap: '1rem' }}>
            <a href="#trial" className="button">
              {language === 'en' ? 'Anchor to trial form' : 'Ir a la solicitud de prueba'}
            </a>
            <Link to="/resources" className="button secondary">
              {language === 'en' ? 'Preview resources' : 'Ver recursos'}
            </Link>
          </div>
        </div>
      </section>

      <section className="section dark" aria-labelledby="audience-title">
        <div className="container">
          <h2 id="audience-title">Who is this course for?</h2>
          <div className="grid three">
            <div>
              <h3>Households</h3>
              <p>Families balancing income in pesos while reserving savings in dollars for key milestones.</p>
            </div>
            <div>
              <h3>Entrepreneurs</h3>
              <p>Small business owners adjusting cash flow, vendor payments, and supply planning.</p>
            </div>
            <div>
              <h3>Independent professionals</h3>
              <p>Freelancers invoicing in mixed currencies who seek stability through better forecasting.</p>
            </div>
          </div>
          <p style={{ marginTop: '2rem' }}>
            Información confiable que respalda elecciones responsables sobre tu dinero. De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
          </p>
        </div>
      </section>

      <section className="section light" aria-labelledby="cta-title">
        <div className="container">
          <div className="badge">Next steps</div>
          <h2 id="cta-title">Ready to begin?</h2>
          <p>
            Use the trial form on the homepage to start the double opt-in process. We will send the onboarding pack after confirming your email.
          </p>
          <a href="#trial" className="button">
            {language === 'en' ? 'Request complimentary session' : 'Solicitar sesión gratuita'}
          </a>
        </div>
      </section>
    </div>
  );
};

export default Course;
```