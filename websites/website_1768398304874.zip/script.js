document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    const header = document.querySelector('.site-header');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('open');
            navLinks.classList.toggle('open');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('open');
                navToggle.classList.remove('open');
            });
        });
    }

    if (header) {
        const updateHeader = () => {
            if (window.scrollY > 20) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        };
        updateHeader();
        window.addEventListener('scroll', updateHeader);
    }

    const banner = document.getElementById('cookie-banner');
    const accept = document.getElementById('cookie-accept');
    const decline = document.getElementById('cookie-decline');

    const storedConsent = localStorage.getItem('manbcjpCookieConsent');
    if (banner && !storedConsent) {
        banner.classList.add('is-visible');
    }

    const handleChoice = (choice, urlHash) => {
        if (!banner) return;
        localStorage.setItem('manbcjpCookieConsent', choice);
        banner.classList.remove('is-visible');
        banner.classList.add('hidden');
        window.open(`cookies.html${urlHash}`, '_blank', 'noopener');
    };

    if (accept) {
        accept.addEventListener('click', event => {
            event.preventDefault();
            handleChoice('accepted', '#accept');
        });
    }

    if (decline) {
        decline.addEventListener('click', event => {
            event.preventDefault();
            handleChoice('declined', '#decline');
        });
    }
});