document.addEventListener('DOMContentLoaded', () => {
  const header = document.querySelector('.site-header');
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');
  const navLinks = document.querySelectorAll('.nav-link');

  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  navLinks.forEach(link => {
    if (link.getAttribute('href') === currentPath) {
      link.classList.add('is-active');
      const ariaCurrent = link.getAttribute('aria-current');
      if (!ariaCurrent) {
        link.setAttribute('aria-current', 'page');
      }
    }
  });

  if (header) {
    const handleScroll = () => {
      header.classList.toggle('scrolled', window.scrollY > 30);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
  }

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      mainNav.classList.toggle('open');
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        mainNav.classList.remove('open');
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-accept]');
    const declineBtn = cookieBanner.querySelector('[data-decline]');
    const storedChoice = localStorage.getItem('altaverinoCookieChoice');

    if (!storedChoice) {
      cookieBanner.classList.add('show');
    }

    const closeBanner = (choice) => {
      localStorage.setItem('altaverinoCookieChoice', choice);
      cookieBanner.classList.remove('show');
    };

    acceptBtn?.addEventListener('click', () => closeBanner('accepted'));
    declineBtn?.addEventListener('click', () => closeBanner('declined'));
  }

  const plannerForm = document.querySelector('[data-planner-form]');
  const plannerList = document.querySelector('[data-planner-list]');

  if (plannerForm && plannerList) {
    plannerForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const titleInput = plannerForm.querySelector('[name="planner-title"]');
      const dateInput = plannerForm.querySelector('[name="planner-date"]');
      const timeInput = plannerForm.querySelector('[name="planner-time"]');

      const title = titleInput.value.trim();
      const date = dateInput.value;
      const time = timeInput.value;

      if (!title) {
        titleInput.focus();
        titleInput.setAttribute('aria-invalid', 'true');
        return;
      }

      titleInput.removeAttribute('aria-invalid');

      const card = document.createElement('div');
      card.className = 'planner-item card card--micro';
      const formattedDate = date ? new Date(date + 'T00:00:00').toLocaleDateString('de-DE') : '';
      const metaString = [formattedDate, time].filter(Boolean).join(' • ');

      card.innerHTML = `
        <div class="planner-item__header">
          <span class="planner-item__title">${title}</span>
          <span class="planner-item__meta">${metaString || 'Kein Termin definiert'}</span>
        </div>
        <button type="button" class="btn btn--ghost btn--xs" data-remove-entry>Entfernen</button>
      `;
      plannerList.appendChild(card);
      plannerForm.reset();
      titleInput.focus();
    });

    plannerList.addEventListener('click', (event) => {
      if (event.target.matches('[data-remove-entry]')) {
        const item = event.target.closest('.planner-item');
        item?.remove();
      }
    });
  }
});