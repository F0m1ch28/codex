document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.primary-navigation');
    const scrollTopBtn = document.querySelector('.scroll-top');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieAcceptBtn = document.querySelector('.cookie-accept');
    const forms = document.querySelectorAll('.contact-form, .newsletter-form');

    // Navigation toggle
    if (navToggle) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            navigation.classList.toggle('open');
        });
    }

    // Close nav when link clicked
    const navLinks = document.querySelectorAll('.primary-navigation a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navigation.classList.remove('open');
            if (navToggle) {
                navToggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    // Scroll top button
    window.addEventListener('scroll', () => {
        if (window.scrollY > 400) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    });

    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // Cookie banner
    const COOKIE_KEY = 'mclabCookieConsent';
    if (cookieBanner && !localStorage.getItem(COOKIE_KEY)) {
        cookieBanner.style.display = 'block';
    }

    if (cookieAcceptBtn) {
        cookieAcceptBtn.addEventListener('click', () => {
            localStorage.setItem(COOKIE_KEY, 'accepted');
            cookieBanner.style.display = 'none';
        });
    }

    // Set footer year
    const yearElements = document.querySelectorAll('#year');
    yearElements.forEach(el => {
        el.textContent = new Date().getFullYear();
    });

    // Simple form handler
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            event.preventDefault();
            const feedback = form.querySelector('.form-feedback');
            const requiredFields = form.querySelectorAll('[required]');
            let valid = true;

            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    valid = false;
                    field.setAttribute('aria-invalid', 'true');
                } else {
                    field.removeAttribute('aria-invalid');
                }
            });

            if (!valid) {
                if (feedback) {
                    feedback.textContent = 'Please complete the required fields.';
                    feedback.style.color = '#c0392b';
                }
                return;
            }

            if (feedback) {
                feedback.textContent = 'Thank you—our team will follow up shortly.';
                feedback.style.color = '#1f5c8c';
            }
            form.reset();
        });
    });
});