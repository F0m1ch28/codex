import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';
import Helmet from '../components/Helmet';
import casinos from '../data/casinos';
import CasinoCard from '../components/CasinoCard';

const stats = [
  { value: '120+', label: 'Проверенных казино в базе' },
  { value: '47', label: 'Метрик в чек-листе аудитора' },
  { value: '6 мин.', label: 'Среднее время проверки выплаты' },
  { value: '0', label: 'Комиссия за вывод по топ-рейтингу' }
];

const showcases = [
  {
    category: 'Хайроллеры',
    title: 'VIP-клубы и крупные лимиты',
    description: 'Казино с повышенными лимитами вывода и личным менеджером.',
    image: 'https://picsum.photos/seed/showcase-highroller/1200/800',
    slug: 'royal-ace-lounge'
  },
  {
    category: 'Крипто',
    title: 'Молниеносные криптовыплаты',
    description: 'Операторы с поддержкой BTC/ETH и бонусами без ограничений.',
    image: 'https://picsum.photos/seed/showcase-crypto/1200/800',
    slug: 'quantum-plays'
  },
  {
    category: 'Новичкам',
    title: 'Комфортные условия для старта',
    description: 'Низкий минимальный депозит и дружественный вейджер.',
    image: 'https://picsum.photos/seed/showcase-starter/1200/800',
    slug: 'emerald-bet-house'
  }
];

const services = [
  {
    title: 'Экспертный аудит лицензии',
    description: 'Проверяем статус лицензии, жалобы и историю штрафов.',
    icon: '🛡️'
  },
  {
    title: 'Скорость выплат и кешаут',
    description: 'Отправляем тестовые выводы и фиксируем фактические сроки.',
    icon: '⚡'
  },
  {
    title: 'Прозрачность бонусов',
    description: 'Расшифровываем вейджер, ограничения и допустимые игры.',
    icon: '🧾'
  }
];

const processSteps = [
  {
    title: 'Сбор данных',
    description: 'Лицензии, аудит провайдеров, история блокировок.',
    icon: '1'
  },
  {
    title: 'Тестирование',
    description: 'Реальные депозиты, бонусы и запросы на вывод.',
    icon: '2'
  },
  {
    title: 'Оценка',
    description: '47 метрик. Вес каждой метрики зависит от важности.',
    icon: '3'
  },
  {
    title: 'Мониторинг',
    description: 'Еженедельный пересмотр и обновление рейтинга.',
    icon: '4'
  }
];

const testimonials = [
  {
    name: 'Елена М.',
    role: 'Хайроллер из Киева',
    quote:
      'Благодаря CasinoReview я избежала длительного вейджера и нашла площадку, где VIP-менеджер действительно решает вопросы в течение часа.',
    rating: 5
  },
  {
    name: 'Дмитрий К.',
    role: 'Стример & контент-мейкер',
    quote:
      'Использую обзоры на стримах. Рейтинги и таблицы по бонусам экономят массу времени при подготовке проводок.',
    rating: 5
  },
  {
    name: 'Алия Ж.',
    role: 'Криптоигрок',
    quote:
      'Раздел с крипто-казино помог выбрать Quantum Plays — вывела USDT за 6 минут без комиссий. Очень ценю честную аналитику.',
    rating: 5
  }
];

const blogPosts = [
  {
    title: 'Как мы тестируем скорость выплат: пошаговый протокол',
    date: '15 февраля 2024',
    image: 'https://picsum.photos/seed/blog-speed/600/420',
    link: '/services'
  },
  {
    title: 'Рейтинг слотов с лучшей волатильностью для отыгрыша бонусов',
    date: '2 февраля 2024',
    image: 'https://picsum.photos/seed/blog-volatility/600/420',
    link: '/casinos'
  },
  {
    title: 'Гайд по ответственной игре: лимиты, паузы и контроль эмоций',
    date: '25 января 2024',
    image: 'https://picsum.photos/seed/blog-rg/600/420',
    link: '/about'
  }
];

const faqItems = [
  {
    question: 'Как формируется общий рейтинг онлайн-казино?',
    answer:
      'Мы используем 47 метрик: скорость выплат, надёжность лицензии, работу саппорта, прозрачность бонусов, техническую безопасность и репутацию среди игроков. Каждому критерию присвоен вес.'
  },
  {
    question: 'Проверяете ли вы скорость вывода средств?',
    answer:
      'Да. У нас есть пул из 6 тестовых аккаунтов. Мы делаем реальные депозиты и выводим средства разными методами, фиксируя фактическое время до зачисления.'
  },
  {
    question: 'Получает ли портал вознаграждение от казино?',
    answer:
      'Мы можем получать комиссию за переходы на лицензированные сайты, но редакция не принимает оплату за изменение рейтинга или сокрытие негативных фактов.'
  },
  {
    question: 'Чем отличается раздел сравнения бонусов?',
    answer:
      'В таблице показаны максимальные приветственные пакеты, вейджер, ограничения по ставкам и доступные методы депозита. Всё можно сравнить на одной странице.'
  },
  {
    question: 'Как часто обновляются обзоры?',
    answer:
      'Каждую неделю команда аналитиков перепроверяет ключевые параметры. Срочные изменения (например, смена лицензии) публикуются в течение 24 часов.'
  },
  {
    question: 'Есть ли рекомендации по ответственной игре?',
    answer:
      'Да. Мы рассказываем о лимитах, самоисключении, даём контакты специализированных организаций и регулярно публикуем статьи о контроле банкролла.'
  }
];

const teamMembers = [
  {
    name: 'Кирилл Назаров',
    role: 'Главный редактор • 10 лет в iGaming',
    image: 'https://picsum.photos/seed/team-kirill/400/400'
  },
  {
    name: 'Мария Лебедева',
    role: 'Аналитик бонусов • Бывший VIP-менеджер',
    image: 'https://picsum.photos/seed/team-maria/400/400'
  },
  {
    name: 'Илья Романов',
    role: 'Тестировщик выплат • AML-специалист',
    image: 'https://picsum.photos/seed/team-ilya/400/400'
  }
];

const HomePage = () => {
  const [activeFaq, setActiveFaq] = useState(null);
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeShowcase, setActiveShowcase] = useState('Хайроллеры');

  const topCasinos = useMemo(() => casinos.slice(0, 5), []);
  const selectedShowcase = useMemo(
    () => showcases.find((item) => item.category === activeShowcase),
    [activeShowcase]
  );

  useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 9000);
    return () => clearInterval(timer);
  }, []);

  return (
    <>
      <Helmet
        title="CasinoReview — лучшие онлайн-казино 2024 с честными обзорами"
        description="Независимые обзоры лицензированных онлайн-казино: рейтинги, сравнение бонусов, скорость выплат и реальные условия акций. CasinoReview — экспертный гид по азартным играм."
      />
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="badge">Экспертные обзоры без компромиссов</span>
            <h1>Лучшие онлайн-казино: честные обзоры и сравнения</h1>
            <p>
              Тестируем казино реальными депозитами, фиксируем время выплат и разбираем бонусы
              построчно. Только лицензированные операторы, независимая редакция и проверка фактов.
            </p>
            <div className={styles.heroActions}>
              <Link to="/casinos" className="btnPrimary">
                Посмотреть рейтинг
              </Link>
              <Link to="/compare" className="btnSecondary">
                Сравнить бонусы
              </Link>
            </div>
            <div className={styles.heroStats} aria-label="Ключевые показатели CasinoReview">
              {stats.map((item) => (
                <div key={item.label} className={styles.statCard}>
                  <span>{item.value}</span>
                  <small>{item.label}</small>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.topSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2 className="sectionTitle">Топ-5 казино 2024 по версии CasinoReview</h2>
            <p className="sectionSubtitle">
              Составлено на основе 47 критериев: лицензия, скорость выплат, прозрачность бонусов, качество саппорта и опыт реальных игроков.
            </p>
          </header>
          <div className={styles.cardGrid}>
            {topCasinos.map((casino) => (
              <CasinoCard key={casino.slug} casino={casino} compact />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.showcase}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2 className="sectionTitle">Подборки под ваш стиль игры</h2>
            <p className="sectionSubtitle">
              Фильтрованные коллекции казино: хайроллеры, крипто, быстрый старт. Обновляем рекомендации каждую неделю.
            </p>
          </header>
          <div className={styles.showcaseControls} role="tablist" aria-label="Категории подборок">
            {showcases.map((item) => (
              <button
                key={item.category}
                type="button"
                className={item.category === activeShowcase ? styles.activeFilter : ''}
                onClick={() => setActiveShowcase(item.category)}
                role="tab"
                aria-selected={item.category === activeShowcase}
              >
                {item.category}
              </button>
            ))}
          </div>
          {selectedShowcase && (
            <article className={styles.showcaseCard}>
              <div className={styles.showcaseImage}>
                <img src={selectedShowcase.image} alt={selectedShowcase.title} loading="lazy" />
              </div>
              <div className={styles.showcaseBody}>
                <h3>{selectedShowcase.title}</h3>
                <p>{selectedShowcase.description}</p>
                <Link to={`/casino/${selectedShowcase.slug}`} className="btnPrimary">
                  Перейти к обзору
                </Link>
              </div>
            </article>
          )}
        </div>
      </section>

      <section className={styles.comparison}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2 className="sectionTitle">Сравнение приветственных бонусов</h2>
            <p className="sectionSubtitle">
              Быстро сопоставьте ключевые параметры и выберите предложение, подходящее вашей стратегии банкролла.
            </p>
          </header>
          <div className={styles.tableWrapper}>
            <table>
              <caption>Основные условия приветственных пакетов</caption>
              <thead>
                <tr>
                  <th scope="col">Казино</th>
                  <th scope="col">Приветственный бонус</th>
                  <th scope="col">Вейджер</th>
                  <th scope="col">Мин. депозит</th>
                  <th scope="col">Макс. ставка при отыгрыше</th>
                </tr>
              </thead>
              <tbody>
                {topCasinos.map((casino) => (
                  <tr key={casino.slug}>
                    <td data-label="Казино">
                      <Link to={`/casino/${casino.slug}`}>{casino.name}</Link>
                    </td>
                    <td data-label="Приветственный бонус">{casino.bonus}</td>
                    <td data-label="Вейджер">{casino.wagering}</td>
                    <td data-label="Мин. депозит">{casino.minDeposit}</td>
                    <td data-label="Макс. ставка">$5</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className={styles.notice}>
            ⚠️ Всегда читайте правила конкретного бонуса: ограничения по слотам, сроки и лимиты ставок.
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2 className="sectionTitle">Почему нам доверяют тысячи игроков</h2>
            <p className="sectionSubtitle">
              Мы делимся методологией: все шаги прозрачны, а результаты проверяем независимой редакцией.
            </p>
          </header>
          <div className={styles.serviceGrid}>
            {services.map((service) => (
              <div key={service.title} className={styles.serviceCard}>
                <span aria-hidden="true">{service.icon}</span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </div>
            ))}
          </div>
          <div className={styles.process}>
            {processSteps.map((step) => (
              <div key={step.title} className={styles.processStep}>
                <span>{step.icon}</span>
                <strong>{step.title}</strong>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <div className={styles.testimonialCard}>
            <header>
              <h2 className="sectionTitle">Отзывы читателей</h2>
              <p className="sectionSubtitle">Реальные игроки о том, как наши обзоры помогли им сэкономить время и деньги.</p>
            </header>
            <blockquote>
              <p>“{testimonials[testimonialIndex].quote}”</p>
              <footer>
                <strong>{testimonials[testimonialIndex].name}</strong>
                <span>{testimonials[testimonialIndex].role}</span>
              </footer>
            </blockquote>
            <div className={styles.testimonialControls}>
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  className={index === testimonialIndex ? styles.dotActive : styles.dot}
                  onClick={() => setTestimonialIndex(index)}
                  aria-label={`Показать отзыв ${index + 1}`}
                  aria-pressed={index === testimonialIndex}
                />
              ))}
            </div>
          </div>
          <div className={styles.teamCard}>
            <h3>Экспертная команда</h3>
            <p>Наша редакция работает в iGaming с 2013 года. Каждый материал проходит фактчекинг и вторую проверку.</p>
            <div className={styles.teamGrid}>
              {teamMembers.map((member) => (
                <article key={member.name}>
                  <img src={member.image} alt={member.name} loading="lazy" />
                  <h4>{member.name}</h4>
                  <p>{member.role}</p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.faqContent}>
            <header>
              <h2 className="sectionTitle">Часто задаваемые вопросы</h2>
              <p className="sectionSubtitle">Собрали ключевые ответы о безопасности, бонусах и критериях отбора.</p>
            </header>
            <div className={styles.faq}>
              {faqItems.map((item, index) => {
                const isOpen = activeFaq === index;
                return (
                  <div key={item.question} className={styles.faqItem}>
                    <button
                      type="button"
                      onClick={() => setActiveFaq(isOpen ? null : index)}
                      aria-expanded={isOpen}
                    >
                      <span>{item.question}</span>
                      <span aria-hidden="true">{isOpen ? '−' : '+'}</span>
                    </button>
                    {isOpen && <p>{item.answer}</p>}
                  </div>
                );
              })}
            </div>
          </div>
          <aside className={styles.blogSidebar}>
            <h3>Свежие материалы</h3>
            <ul>
              {blogPosts.map((post) => (
                <li key={post.title}>
                  <Link to={post.link}>
                    <div className={styles.blogImage}>
                      <img src={post.image} alt={post.title} loading="lazy" />
                    </div>
                    <div>
                      <span>{post.date}</span>
                      <h4>{post.title}</h4>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
            <div className={styles.blogCta}>
              <h4>Готовы выбрать казино?</h4>
              <p>Сравните приветственные бонусы и узнайте точные условия отыгрыша.</p>
              <Link to="/compare" className="btnPrimary">
                Перейти к сравнению
              </Link>
            </div>
          </aside>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Получайте независимые обновления первым</h2>
              <p>
                Подпишитесь на еженедельную рассылку: новые рейтинги, инсайды по бонусам, предупреждения о рисках.
              </p>
            </div>
            <Link to="/contact" className="btnSecondary">
              Связаться с редакцией
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;