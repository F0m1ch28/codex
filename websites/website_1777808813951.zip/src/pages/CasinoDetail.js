import React from 'react';
import { Link, useParams } from 'react-router-dom';
import Helmet from '../components/Helmet';
import casinos from '../data/casinos';
import styles from './CasinoDetail.module.css';

const CasinoDetailPage = () => {
  const { slug } = useParams();
  const casino = casinos.find((item) => item.slug === slug);

  if (!casino) {
    return (
      <>
        <Helmet
          title="Казино не найдено | CasinoReview"
          description="Похоже, данное казино было удалено или недоступно. Вернитесь в каталог и выберите актуальное предложение."
        />
        <section className={styles.notFound}>
          <div className="container">
            <div className={styles.notFoundCard}>
              <h1>Казино не найдено</h1>
              <p>
                Возможно, мы сняли обзор из-за обновления лицензии или нарушения условий. Перейдите
                в каталог, чтобы выбрать актуальное казино.
              </p>
              <Link to="/casinos" className="btnPrimary">
                Вернуться к рейтингу
              </Link>
            </div>
          </div>
        </section>
      </>
    );
  }

  return (
    <>
      <Helmet
        title={`${casino.name} — обзор и условия | CasinoReview`}
        description={`${casino.summary} Лицензия ${casino.license}, бонус ${casino.bonus}, скорость выплат ${casino.payoutSpeed}.`}
      />
      <section
        className={styles.hero}
        style={{ backgroundImage: `url(${casino.heroImage})` }}
        aria-label={`Обложка ${casino.name}`}
      >
        <div className={styles.overlay}>
          <div className="container">
            <div className={styles.heroContent}>
              <div>
                <span className="badge">Обзор казино</span>
                <h1>{casino.name}</h1>
                <p>{casino.summary}</p>
              </div>
              <div className={styles.heroMeta}>
                <div>
                  <strong>Рейтинг</strong>
                  <span>{casino.rating}</span>
                </div>
                <div>
                  <strong>Лицензия</strong>
                  <span>{casino.license}</span>
                </div>
                <div>
                  <strong>Основано</strong>
                  <span>{casino.established}</span>
                </div>
                <div>
                  <strong>Мин. депозит</strong>
                  <span>{casino.minDeposit}</span>
                </div>
              </div>
              <div className={styles.heroActions}>
                <a
                  href={casino.website}
                  target="_blank"
                  rel="noreferrer"
                  className="btnPrimary"
                >
                  Перейти на сайт
                </a>
                <Link to="/compare" className="btnSecondary">
                  Сравнить бонус
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.details}>
        <div className="container">
          <div className={styles.grid}>
            <article className={styles.card}>
              <h2>Ключевые условия</h2>
              <ul>
                <li>
                  <strong>Скорость выплат:</strong> {casino.payoutSpeed}
                </li>
                <li>
                  <strong>Методы оплаты:</strong> {casino.payments.join(', ')}
                </li>
                <li>
                  <strong>Языки поддержки:</strong> {casino.languages.join(', ')}
                </li>
                <li>
                  <strong>Поддержка:</strong> {casino.support}
                </li>
                <li>
                  <strong>VIP-программа:</strong> {casino.vipProgram}
                </li>
                <li>
                  <strong>Безопасность:</strong> {casino.security}
                </li>
              </ul>
            </article>

            <article className={styles.card}>
              <h2>Пакеты бонусов</h2>
              <table>
                <thead>
                  <tr>
                    <th>Предложение</th>
                    <th>Размер</th>
                    <th>Вейджер</th>
                    <th>Мин. депозит</th>
                    <th>Срок</th>
                  </tr>
                </thead>
                <tbody>
                  {casino.bonusDetails.map((bonus) => (
                    <tr key={bonus.title}>
                      <td>{bonus.title}</td>
                      <td>{bonus.value}</td>
                      <td>{bonus.wagering}</td>
                      <td>{bonus.minDeposit}</td>
                      <td>{bonus.expiry}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className={styles.disclaimer}>
                ⚠️ Обратите внимание: превышение максимальной ставки при отыгрыше приведёт к аннулированию бонуса.
              </p>
            </article>

            <article className={styles.card}>
              <h2>Игровое лобби</h2>
              <ul className={styles.tags}>
                {casino.gameCategories.map((game) => (
                  <li key={game.category}>
                    <strong>{game.category}</strong>
                    <span>{game.count} игр</span>
                  </li>
                ))}
              </ul>
              <p>
                Топовые провайдеры: <strong>{casino.providers?.join(', ')}</strong>.
              </p>
            </article>

            <article className={styles.card}>
              <h2>Плюсы и минусы</h2>
              <div className={styles.prosCons}>
                <div>
                  <h3>Преимущества</h3>
                  <ul>
                    {casino.pros.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3>Ограничения</h3>
                  <ul>
                    {casino.cons.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </article>

            <article className={styles.card}>
              <h2>Ответственная игра</h2>
              <ul className={styles.responsible}>
                {casino.responsibleGaming.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <p>
                Поддерживаем партнерство с GamCare и <Link to="/about">публикуем гайды</Link> по
                контролю банкролла.
              </p>
            </article>

            <article className={styles.card}>
              <h2>Доступность</h2>
              <p>
                Ограниченные страны: <strong>{casino.restrictedCountries.join(', ') || 'нет'}</strong>.
              </p>
              <p>
                Рекомендуемый банкролл для комфортной игры: <strong>$200+</strong>.
              </p>
              <p>Подходит для: хайроллеров, любителей лайв-игр, игроков с крипто-кошельками.</p>
            </article>
          </div>

          <div className={styles.cta}>
            <div>
              <h3>Готовы протестировать {casino.name}?</h3>
              <p>
                Начните с минимального депозита {casino.minDeposit}. Используйте трекер отыгрыша и фиксируйте время выплат — делитесь отзывом с редакцией.
              </p>
            </div>
            <a
              href={casino.website}
              target="_blank"
              rel="noreferrer"
              className="btnPrimary"
            >
              Перейти на сайт
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default CasinoDetailPage;