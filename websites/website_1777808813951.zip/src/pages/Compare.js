import React from 'react';
import { Link } from 'react-router-dom';
import Helmet from '../components/Helmet';
import casinos from '../data/casinos';
import styles from './Compare.module.css';

const ComparePage = () => {
  const comparisonData = casinos.map((casino) => ({
    name: casino.name,
    slug: casino.slug,
    bonus: casino.bonus,
    wagering: casino.wagering,
    minDeposit: casino.minDeposit,
    cashback: casino.cashback,
    payments: casino.payments.slice(0, 3).join(', '),
    payoutSpeed: casino.payoutSpeed,
    license: casino.license,
    rating: casino.rating
  }));

  return (
    <>
      <Helmet
        title="Сравнение бонусов онлайн-казино | CasinoReview"
        description="Сравните приветственные бонусы, вейджер, минимальный депозит и скорость выплат лучших онлайн-казино. Интерактивная таблица от CasinoReview."
      />
      <section className={styles.section}>
        <div className="container">
          <header className={styles.header}>
            <span className="badge">Сравнение условий</span>
            <h1>Сравнение бонусов и условий казино</h1>
            <p>
              Сопоставляйте параметры на одной таблице: размер приветственного пакета, требования к вейджеру, минимальный депозит, кэшбэк и скорость выплат.
            </p>
          </header>

          <div className={styles.tableWrapper}>
            <table>
              <thead>
                <tr>
                  <th>Казино</th>
                  <th>Бонус</th>
                  <th>Вейджер</th>
                  <th>Мин. депозит</th>
                  <th>Кэшбэк</th>
                  <th>Методы оплаты</th>
                  <th>Скорость выплат</th>
                  <th>Лицензия</th>
                  <th>Рейтинг</th>
                </tr>
              </thead>
              <tbody>
                {comparisonData.map((row) => (
                  <tr key={row.slug}>
                    <td data-label="Казино">
                      <Link to={`/casino/${row.slug}`}>{row.name}</Link>
                    </td>
                    <td data-label="Бонус">{row.bonus}</td>
                    <td data-label="Вейджер">{row.wagering}</td>
                    <td data-label="Мин. депозит">{row.minDeposit}</td>
                    <td data-label="Кэшбэк">{row.cashback}</td>
                    <td data-label="Методы">{row.payments}</td>
                    <td data-label="Выплаты">{row.payoutSpeed}</td>
                    <td data-label="Лицензия">{row.license}</td>
                    <td data-label="Рейтинг">{row.rating}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <aside className={styles.aside}>
            <h2>Как читать таблицу</h2>
            <ul>
              <li>Рейтинг основан на нашей методологии (47 метрик и проверки раз в неделю).</li>
              <li>Максимальная ставка при отыгрыше — $5, если иное не указано в условиях казино.</li>
              <li>Вейджер отображается по бонусной части, фриспины имеют отдельные условия.</li>
              <li>Скорость выплат указана по данным реальных тестовых заявок редакции.</li>
            </ul>
            <p>
              Используйте таблицу как отправную точку и обязательно прочитайте детальный обзор выбранного казино.
            </p>
          </aside>
        </div>
      </section>
    </>
  );
};

export default ComparePage;