import React, { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import Helmet from '../components/Helmet';
import casinos from '../data/casinos';
import CasinoCard from '../components/CasinoCard';
import styles from './CasinoList.module.css';

const CasinoListPage = () => {
  const location = useLocation();
  const [search, setSearch] = useState('');
  const [licenseFilter, setLicenseFilter] = useState('all');
  const [paymentFilter, setPaymentFilter] = useState('all');
  const [minRating, setMinRating] = useState('0');

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const query = params.get('search') || '';
    setSearch(query);
  }, [location.search]);

  const licenses = useMemo(
    () => Array.from(new Set(casinos.map((casino) => casino.license))),
    []
  );
  const paymentMethods = useMemo(
    () => Array.from(new Set(casinos.flatMap((casino) => casino.payments))),
    []
  );

  const filteredCasinos = useMemo(() => {
    return casinos.filter((casino) => {
      const matchesSearch =
        casino.name.toLowerCase().includes(search.toLowerCase()) ||
        casino.summary.toLowerCase().includes(search.toLowerCase());
      const matchesLicense = licenseFilter === 'all' || casino.license === licenseFilter;
      const matchesPayment =
        paymentFilter === 'all' || casino.payments.includes(paymentFilter);
      const matchesRating = casino.rating >= Number(minRating);
      return matchesSearch && matchesLicense && matchesPayment && matchesRating;
    });
  }, [search, licenseFilter, paymentFilter, minRating]);

  const resetFilters = () => {
    setSearch('');
    setLicenseFilter('all');
    setPaymentFilter('all');
    setMinRating('0');
  };

  return (
    <>
      <Helmet
        title="Рейтинг онлайн-казино | CasinoReview"
        description="Полный список проверенных онлайн-казино: лицензия, скорость выплат, бонусы, поддержка и условия. Фильтруйте по лицензии, платёжным системам и рейтингу."
      />
      <section className={styles.section}>
        <div className="container">
          <header className={styles.header}>
            <div>
              <span className="badge">Каталог казино</span>
              <h1>Все обзоры казино</h1>
              <p>
                Фильтруйте по лицензии, способам оплаты и рейтингу. Мы проверяем все данные вручную и подтверждаем условия выводов.
              </p>
            </div>
            <button type="button" className={styles.reset} onClick={resetFilters}>
              Сбросить фильтры
            </button>
          </header>

          <form className={styles.filters} aria-label="Фильтры казино">
            <div className={styles.field}>
              <label htmlFor="search">Поиск по названию</label>
              <input
                id="search"
                type="search"
                placeholder="Например, Aurora или Royal"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </div>
            <div className={styles.field}>
              <label htmlFor="license">Лицензия</label>
              <select
                id="license"
                value={licenseFilter}
                onChange={(event) => setLicenseFilter(event.target.value)}
              >
                <option value="all">Все лицензии</option>
                {licenses.map((license) => (
                  <option key={license} value={license}>
                    {license}
                  </option>
                ))}
              </select>
            </div>
            <div className={styles.field}>
              <label htmlFor="payments">Метод оплаты</label>
              <select
                id="payments"
                value={paymentFilter}
                onChange={(event) => setPaymentFilter(event.target.value)}
              >
                <option value="all">Все методы</option>
                {paymentMethods.map((method) => (
                  <option key={method} value={method}>
                    {method}
                  </option>
                ))}
              </select>
            </div>
            <div className={styles.field}>
              <label htmlFor="rating">Минимальный рейтинг</label>
              <input
                id="rating"
                type="range"
                min="0"
                max="10"
                step="0.5"
                value={minRating}
                onChange={(event) => setMinRating(event.target.value)}
                aria-valuemin={0}
                aria-valuemax={10}
                aria-valuenow={minRating}
              />
              <span className={styles.rangeValue}>{minRating}+</span>
            </div>
          </form>

          <div className={styles.resultsInfo} role="status" aria-live="polite">
            Найдено казино: <strong>{filteredCasinos.length}</strong>
          </div>

          <div className={styles.grid}>
            {filteredCasinos.length === 0 ? (
              <div className={styles.empty}>
                <h2>Ничего не найдено</h2>
                <p>Попробуйте расширить фильтры или изменить запрос.</p>
              </div>
            ) : (
              filteredCasinos.map((casino) => (
                <CasinoCard key={casino.slug} casino={casino} />
              ))
            )}
          </div>
        </div>
      </section>
    </>
  );
};

export default CasinoListPage;