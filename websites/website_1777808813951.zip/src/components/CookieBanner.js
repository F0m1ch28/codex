import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const COOKIE_STORAGE_KEY = 'casinoReviewCookieConsent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(COOKIE_STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о cookie">
      <div>
        <strong>Мы используем cookie.</strong> Продолжая использовать сайт, вы принимаете{' '}
        <Link to="/cookie-policy">политику cookie</Link>.
      </div>
      <button className={styles.accept} onClick={handleAccept}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;