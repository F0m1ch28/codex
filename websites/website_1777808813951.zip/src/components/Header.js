import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation, useNavigate } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { label: 'Главная', path: '/' },
  { label: 'Рейтинг казино', path: '/casinos' },
  { label: 'Сравнение', path: '/compare' },
  { label: 'О нас', path: '/about' },
  { label: 'Методология', path: '/services' },
  { label: 'Контакты', path: '/contact' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  const handleSubmit = (event) => {
    event.preventDefault();
    const query = searchTerm.trim();
    if (query.length > 0) {
      navigate(`/casinos?search=${encodeURIComponent(query)}`);
    } else {
      navigate('/casinos');
    }
  };

  return (
    <header className={styles.header} role="banner">
      <div className={`container ${styles.inner}`}>
        <Link to="/" className={styles.logo} aria-label="CasinoReview — на главную">
          <span className={styles.logoAccent}>Casino</span>
          <span>Review</span>
        </Link>

        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Основная навигация">
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.path} className={styles.navItem}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <form className={styles.search} onSubmit={handleSubmit} role="search" aria-label="Поиск казино по названию">
            <label htmlFor="header-search" className="visually-hidden">
              Поиск казино
            </label>
            <input
              id="header-search"
              type="search"
              placeholder="Поиск казино..."
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              aria-label="Введите название казино"
            />
            <button type="submit" aria-label="Найти казино">
              🔍
            </button>
          </form>
        </nav>

        <button
          type="button"
          className={styles.menuButton}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Меню"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;