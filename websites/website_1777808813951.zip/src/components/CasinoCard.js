import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CasinoCard.module.css';

const CasinoCard = ({ casino, compact = false }) => {
  return (
    <article className={`${styles.card} ${compact ? styles.compact : ''}`}>
      <header className={styles.header}>
        <div className={styles.logoWrapper} aria-hidden="true">
          <img src={casino.logo} alt={`Логотип ${casino.name}`} loading="lazy" />
        </div>
        <div>
          <h3>{casino.name}</h3>
          <p className={styles.tagline}>{casino.tagline}</p>
        </div>
        <div className={styles.rating} aria-label={`Рейтинг ${casino.rating} из 10`}>
          <span>{casino.rating}</span>
          <small>Рейтинг</small>
        </div>
      </header>
      <div className={styles.bonusBlock}>
        <div>
          <h4>Приветственный бонус</h4>
          <p className={styles.bonus}>{casino.bonus}</p>
        </div>
        <div className={styles.terms}>
          <span>Вейджер: <strong>{casino.wagering}</strong></span>
          <span>Мин. депозит: <strong>{casino.minDeposit}</strong></span>
          <span>Кэшбэк: <strong>{casino.cashback}</strong></span>
        </div>
      </div>
      <div className={styles.meta}>
        <div>
          <strong>Лицензия</strong>
          <span>{casino.license}</span>
        </div>
        <div>
          <strong>Выплаты</strong>
          <span>{casino.payoutSpeed}</span>
        </div>
        <div>
          <strong>Игры</strong>
          <span>{casino.gamesCount.toLocaleString('ru-RU')}</span>
        </div>
      </div>
      <div className={styles.footer}>
        <div className={styles.tags} aria-label="Основные особенности">
          {casino.features.slice(0, 3).map((feature) => (
            <span key={feature} className="tag">
              {feature}
            </span>
          ))}
        </div>
        <Link to={`/casino/${casino.slug}`} className={styles.link} aria-label={`Подробнее о казино ${casino.name}`}>
          Подробнее
        </Link>
      </div>
    </article>
  );
};

export default CasinoCard;