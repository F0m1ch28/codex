import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={`container ${styles.grid}`}>
      <div className={styles.brand}>
        <div className={styles.logo}>
          <span className={styles.logoAccent}>Casino</span>Review
        </div>
        <p>
          Независимый портал о безопасной игре. Мы анализируем онлайн-казино, сравниваем бонусы и
          обновляем обзоры каждую неделю, чтобы вы принимали решения на основе фактов.
        </p>
        <div className={styles.warning}>
          <strong>18+</strong> Азартные игры предназначены только для взрослых. Играйте ответственно.
        </div>
      </div>

      <div className={styles.column}>
        <h4>Навигация</h4>
        <ul>
          <li><Link to="/">Главная</Link></li>
          <li><Link to="/casinos">Все казино</Link></li>
          <li><Link to="/compare">Сравнение бонусов</Link></li>
          <li><Link to="/services">Методология</Link></li>
          <li><Link to="/about">О проекте</Link></li>
        </ul>
      </div>

      <div className={styles.column}>
        <h4>Правовая информация</h4>
        <ul>
          <li><Link to="/terms">Условия использования</Link></li>
          <li><Link to="/privacy">Политика конфиденциальности</Link></li>
          <li><Link to="/cookie-policy">Политика Cookie</Link></li>
        </ul>
      </div>

      <div className={styles.column}>
        <h4>Контакты</h4>
        <p>Email: <a href="mailto:info@gambling.review">info@gambling.review</a></p>
        <p>Поддержка: 24/7 в чате и по электронной почте</p>
        <p>Телеграм: <a href="https://t.me/casinoreview" target="_blank" rel="noreferrer">@casinoreview</a></p>
        <div className={styles.socials} aria-label="Социальные сети">
          <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
            ▶
          </a>
          <a href="https://www.twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
            🐦
          </a>
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
            in
          </a>
        </div>
      </div>
    </div>

    <div className={styles.bottomLine}>
      © {new Date().getFullYear()} CasinoReview. Все права защищены. Независимая редакция, строгая редакционная политика.
    </div>
  </footer>
);

export default Footer;