const casinos = [
  {
    name: 'Aurora Spins',
    slug: 'aurora-spins',
    tagline: 'Премиум-платформа с мгновенными выплатами и VIP-программой',
    rating: 9.6,
    bonus: '$2000 + 150 фриспинов',
    wagering: '35x',
    minDeposit: '$20',
    cashback: '10% еженедельно',
    license: 'MGA',
    payoutSpeed: 'до 24 часов',
    gamesCount: 3200,
    heroImage: 'https://picsum.photos/seed/aurora-spins/1400/700',
    logo: 'https://picsum.photos/seed/aurora-logo/200/200',
    established: 2019,
    languages: ['Русский', 'English', 'Deutsch'],
    payments: ['Visa', 'Mastercard', 'Skrill', 'Neteller', 'Bitcoin'],
    support: '24/7 live chat, email',
    features: ['VIP-статусы', 'Собственный лайв-клуб', 'Крипто-платежи'],
    pros: [
      'Подтверждённые выплаты за 6 минут',
      'Ежедневные турниры с призовым фондом $15k',
      'Аудит RTP от eCOGRA'
    ],
    cons: ['Нет локального приложения для iOS', 'Бонус недоступен для Skrill/Neteller'],
    bonusDetails: [
      {
        title: 'Приветственный пакет',
        value: '$2000 + 150 FS',
        wagering: '35x',
        minDeposit: '$20',
        expiry: '14 дней'
      },
      {
        title: 'Highroller бонус',
        value: '$3000 + 80 FS',
        wagering: '40x',
        minDeposit: '$250',
        expiry: '21 день'
      },
      {
        title: 'Кэшбэк',
        value: '10% без вейджера',
        wagering: '0x',
        minDeposit: '-',
        expiry: 'еженедельно'
      }
    ],
    gameCategories: [
      { category: 'Слоты', count: 2100 },
      { category: 'Лайв казино', count: 180 },
      { category: 'Столы', count: 120 },
      { category: 'Crash игры', count: 12 }
    ],
    responsibleGaming: [
      'Лимиты депозита и потерь',
      'Самоисключение до 12 месяцев',
      'Реality-check напоминания'
    ],
    restrictedCountries: ['Италия', 'Франция'],
    trustScore: 96,
    website: 'https://www.auroraspins.example',
    vipProgram: '6 уровней, быстрый мэнеджер',
    mobileApp: 'Web, Android',
    security: 'SSL, двухфакторная авторизация',
    summary: 'Aurora Spins — выбор хайроллеров и игроков, ценящих стабильность и премиальные условия.'
  },
  {
    name: 'Neon Jackpot',
    slug: 'neon-jackpot',
    tagline: 'Казино в неоновой стилистике с экспресс-бонусами',
    rating: 9.3,
    bonus: '$1500 + 200 фриспинов',
    wagering: '30x',
    minDeposit: '$15',
    cashback: '7% на слоты',
    license: 'Curacao Antillephone',
    payoutSpeed: '1-12 часов',
    gamesCount: 2800,
    heroImage: 'https://picsum.photos/seed/neon-jackpot/1400/700',
    logo: 'https://picsum.photos/seed/neon-logo/200/200',
    established: 2020,
    languages: ['Русский', 'English', 'Polski'],
    payments: ['Visa', 'Mastercard', 'Qiwi', 'WebMoney', 'Ethereum'],
    support: '24/7 live chat, Telegram',
    features: ['Ежедневные миссии', 'Криптовалютные бонусы', 'Лайв-игры в 4К'],
    pros: [
      'Ротация эксклюзивных слотов от Relax Gaming',
      'Программа лояльности с кешбэком до 15%',
      'Молниеносный лайв-чат (<30 секунд)'
    ],
    cons: ['Заморозка вывода при активном бонусе', 'Дополнительная верификация для VIP'],
    bonusDetails: [
      {
        title: 'Неоновый пакет',
        value: '$1500 + 200 FS',
        wagering: '30x',
        minDeposit: '$15',
        expiry: '10 дней'
      },
      {
        title: 'Crypto Boost',
        value: '75% до $1000',
        wagering: '33x',
        minDeposit: '$30',
        expiry: '7 дней'
      },
      {
        title: 'Кэшбэк',
        value: '7% на слоты',
        wagering: '5x',
        minDeposit: '-',
        expiry: 'еженедельно'
      }
    ],
    gameCategories: [
      { category: 'Слоты', count: 1900 },
      { category: 'Лайв казино', count: 140 },
      { category: 'Джекпоты', count: 60 },
      { category: 'Instant Win', count: 32 }
    ],
    responsibleGaming: ['Лимиты по времени', 'Самоисключение', 'Контроль ставки'],
    restrictedCountries: ['США', 'Испания'],
    trustScore: 92,
    website: 'https://www.neonjackpot.example',
    vipProgram: 'Неон-клуб с еженедельными подарками',
    mobileApp: 'Web progressive app',
    security: 'Сертификация iTechLabs',
    summary: 'Neon Jackpot — динамичное казино с упором на миссии и постоянные акции для активных игроков.'
  },
  {
    name: 'Royal Ace Lounge',
    slug: 'royal-ace-lounge',
    tagline: 'Люксовое казино со студиями Evolution и Playtech',
    rating: 9.1,
    bonus: '$2500 + доступ в приватные лайв-комнаты',
    wagering: '38x',
    minDeposit: '$50',
    cashback: '15% при статусе Gold',
    license: 'UKGC & MGA',
    payoutSpeed: 'до 6 часов',
    gamesCount: 2400,
    heroImage: 'https://picsum.photos/seed/royal-ace/1400/700',
    logo: 'https://picsum.photos/seed/royal-logo/200/200',
    established: 2017,
    languages: ['Русский', 'English', 'Français'],
    payments: ['Visa', 'Mastercard', 'Bank Transfer', 'Revolut'],
    support: 'Премиальная поддержка 24/7',
    features: ['VIP-столы', 'Эксклюзивные турниры', 'Страховка ставок'],
    pros: [
      'Персональный менеджер с уровня Platinum',
      'Проверенные выводы до $50k без разбивки',
      'Приватные столы Evolution с русскоязычными дилерами'
    ],
    cons: ['Высокий минимальный депозит', 'Нет криптовалютных платежей'],
    bonusDetails: [
      {
        title: 'Royal пакет',
        value: '$2500 + 2 лайв-билета',
        wagering: '38x',
        minDeposit: '$100',
        expiry: '30 дней'
      },
      {
        title: 'Страховка ставок',
        value: '$500',
        wagering: '0x',
        minDeposit: '$50',
        expiry: 'ежемесячно'
      }
    ],
    gameCategories: [
      { category: 'Лайв казино', count: 220 },
      { category: 'Слоты', count: 1600 },
      { category: 'Столы', count: 140 },
      { category: 'Шоу', count: 26 }
    ],
    responsibleGaming: ['Лимиты депозита', 'Самоисключение', 'Отчеты по активности'],
    restrictedCountries: ['Германия'],
    trustScore: 94,
    website: 'https://www.royalacelounge.example',
    vipProgram: '5 статусов, кэшбэк до 20%',
    mobileApp: 'iOS, Android',
    security: 'PCI DSS Level 1',
    summary: 'Royal Ace Lounge — элитный клуб для требовательных игроков с щедрым кэшбэком и топовыми студиями.'
  },
  {
    name: 'Quantum Plays',
    slug: 'quantum-plays',
    tagline: 'Технологичное казино с расширенной крипто-поддержкой',
    rating: 8.9,
    bonus: '$1000 + 100 фриспинов + NFT-награда',
    wagering: '28x',
    minDeposit: '$10',
    cashback: '6% auto-cashback',
    license: 'Curacao Embrace',
    payoutSpeed: 'мгновенно для крипто',
    gamesCount: 3500,
    heroImage: 'https://picsum.photos/seed/quantum-plays/1400/700',
    logo: 'https://picsum.photos/seed/quantum-logo/200/200',
    established: 2021,
    languages: ['Русский', 'English', 'Türkçe'],
    payments: ['Bitcoin', 'Ethereum', 'Tether', 'Litecoin', 'Visa'],
    support: 'Live chat, Discord-канал',
    features: ['NFT-коллекция', 'Геймификация уровней', 'Мгновенные выплаты'],
    pros: [
      'Геймификация с сезонными пропусками',
      'Крипто-кошельки без комиссии',
      'Публичное доказуемое честное RNG'
    ],
    cons: ['В некоторых странах требуют VPN', 'Лицензия не для всех банковских методов'],
    bonusDetails: [
      {
        title: 'Quantum Boost',
        value: '$1000 + 100 FS',
        wagering: '28x',
        minDeposit: '$10',
        expiry: '7 дней'
      },
      {
        title: 'NFT-награда',
        value: 'эксклюзивное NFT',
        wagering: '0x',
        minDeposit: '$50',
        expiry: 'моментально'
      }
    ],
    gameCategories: [
      { category: 'Crash игры', count: 26 },
      { category: 'Слоты', count: 2300 },
      { category: 'Лайв-дилеры', count: 130 },
      { category: 'Мультиплеер', count: 18 }
    ],
    responsibleGaming: ['Лимиты депозитов', 'Паузы', 'История транзакций'],
    restrictedCountries: ['США', 'Нидерланды'],
    trustScore: 88,
    website: 'https://www.quantumplays.example',
    vipProgram: 'Quantum Pass с сезонными бустами',
    mobileApp: 'Web',
    security: 'Blockchain-proof, Cloudflare Zero Trust',
    summary: 'Quantum Plays — инновационное казино для криптоэнтузиастов и любителей современных игровых механик.'
  },
  {
    name: 'Emerald Bet House',
    slug: 'emerald-bet-house',
    tagline: 'Европейский подход с акцентом на ответственную игру',
    rating: 8.7,
    bonus: '$800 + 80 фриспинов',
    wagering: '25x',
    minDeposit: '$20',
    cashback: '5% на проигрыши',
    license: 'Malta MGA',
    payoutSpeed: 'до 24 часов',
    gamesCount: 2100,
    heroImage: 'https://picsum.photos/seed/emerald-bet/1400/700',
    logo: 'https://picsum.photos/seed/emerald-logo/200/200',
    established: 2018,
    languages: ['Русский', 'English', 'Español'],
    payments: ['Visa', 'Mastercard', 'Skrill', 'Paysafecard', 'Apple Pay'],
    support: 'Email, чат (10:00-02:00 CET)',
    features: ['Поддержка ответственной игры', 'Сильные джекпоты', 'Детальная статистика'],
    pros: [
      'Прозрачные правила и бонусы без скрытых условий',
      'Фильтры провайдеров и волатильности',
      'Бесплатные демо для всех игр'
    ],
    cons: ['Нет круглосуточной поддержки', 'Ограниченные крипто-опции'],
    bonusDetails: [
      {
        title: 'Emerald старт',
        value: '$800 + 80 FS',
        wagering: '25x',
        minDeposit: '$20',
        expiry: '10 дней'
      },
      {
        title: 'Страховка ставок',
        value: 'до $200',
        wagering: '5x',
        minDeposit: '$50',
        expiry: 'ежемесячно'
      }
    ],
    gameCategories: [
      { category: 'Слоты', count: 1500 },
      { category: 'Лайв', count: 100 },
      { category: 'Рулетки', count: 40 },
      { category: 'Покер', count: 12 }
    ],
    responsibleGaming: ['Игровые лимиты', 'Самоисключение', 'Партнерство с GamCare'],
    restrictedCountries: ['Австралия'],
    trustScore: 90,
    website: 'https://www.emeraldbet.example',
    vipProgram: 'Emerald club — подарки и кэшбэк',
    mobileApp: 'Web, PWA',
    security: 'SSL, независимый аудит eCOGRA',
    summary: 'Emerald Bet House — честный европейский бренд с сильным фокусом на устойчивой игре и игроках-новичках.'
  }
];

export default casinos;