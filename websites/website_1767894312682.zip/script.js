document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            navLinks.classList.toggle("is-open");
        });

        navLinks.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                navLinks.classList.remove("is-open");
            });
        });
    }

    const cookieBanner = document.getElementById("cookieBanner");
    const cookieConsent = localStorage.getItem("strepthpyd-cookie-consent");

    if (!cookieConsent && cookieBanner) {
        cookieBanner.classList.add("is-visible");
    }

    const cookieButtons = document.querySelectorAll(".cookie-banner button");
    cookieButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const value = button.dataset.value || "pending";
            localStorage.setItem("strepthpyd-cookie-consent", value);
            cookieBanner.classList.remove("is-visible");
        });
    });

    const previewToggles = document.querySelectorAll(".preview-toggle");
    previewToggles.forEach((toggle) => {
        toggle.addEventListener("click", () => {
            const targetId = toggle.dataset.target;
            const panel = document.getElementById(targetId);
            if (panel) {
                panel.classList.toggle("is-visible");
                toggle.setAttribute(
                    "aria-expanded",
                    panel.classList.contains("is-visible").toString()
                );
            }
        });
    });
});