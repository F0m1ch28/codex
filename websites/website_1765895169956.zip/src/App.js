import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services, {
  RiskAssessmentPage,
  ResilienceAnalysisPage,
  EnvironmentalExposurePage,
  ApplicationsPage,
} from './pages/Services';
import Contact, { ThankYouPage } from './pages/Contact';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy, { CookiePolicyPage } from './pages/PrivacyPolicy';

const RouteChangeHandler = () => {
  const location = useLocation();
  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const main = document.querySelector('main');
      if (main) {
        main.setAttribute('tabindex', '-1');
        main.focus({ preventScroll: true });
      }
    }
  }, [location]);
  return null;
};

const App = () => (
  <div className="flex min-h-screen flex-col bg-softcream text-slate-900">
    <Header />
    <RouteChangeHandler />
    <main className="flex-1 outline-none focus-visible:ring-4 focus-visible:ring-offset-4 focus-visible:ring-accentblue focus-visible:outline-none">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/company" element={<About />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/risk-assessment" element={<RiskAssessmentPage />} />
        <Route path="/resilience-analysis" element={<ResilienceAnalysisPage />} />
        <Route path="/environmental-exposure" element={<EnvironmentalExposurePage />} />
        <Route path="/applications" element={<ApplicationsPage />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/privacy" element={<PrivacyPolicy />} />
        <Route path="/cookies" element={<CookiePolicyPage />} />
        <Route path="/terms" element={<TermsOfService />} />
        <Route path="/thanks" element={<ThankYouPage />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTopButton />
  </div>
);

export default App;