import React, { useEffect, useRef } from 'react';

const FadeInSection = ({ children, delay = 0, className = '', as: Tag = 'section', id }) => {
  const ref = useRef(null);

  useEffect(() => {
    if (typeof window === 'undefined') return undefined;
    const el = ref.current;
    if (!el) return undefined;

    el.style.opacity = 0;
    el.style.transform = 'translateY(48px)';

    const runAnimation = () => {
      if (window?.framerMotion?.animate) {
        const controls = window.framerMotion.animate(
          el,
          { opacity: [0, 1], y: [48, 0] },
          { duration: 0.9, delay, easing: 'easeOut' }
        );
        return () => controls?.stop?.();
      }
      el.style.transition = 'opacity 0.9s ease, transform 0.9s ease';
      requestAnimationFrame(() => {
        el.style.opacity = 1;
        el.style.transform = 'translateY(0px)';
      });
      return undefined;
    };

    let observer;
    if ('IntersectionObserver' in window) {
      observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              runAnimation();
              observer.disconnect();
            }
          });
        },
        { threshold: 0.2 }
      );
      observer.observe(el);
    } else {
      runAnimation();
    }

    return () => observer && observer.disconnect();
  }, [delay]);

  return (
    <Tag ref={ref} id={id} className={`fade-in-section ${className}`}>
      {children}
    </Tag>
  );
};

export default FadeInSection;