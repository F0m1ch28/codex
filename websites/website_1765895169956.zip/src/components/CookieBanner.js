import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const STORAGE_KEY = 'grl-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-3 left-3 right-3 z-50 rounded-2xl border border-primary/10 bg-white p-5 shadow-2xl md:left-auto md:right-8 md:max-w-xl">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="md:max-w-sm">
          <h2 className="font-outfit text-lg font-semibold text-primary">
            We use cookies
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            We deploy cookies to analyze website interaction, improve accessibility, and deliver climate intelligence content responsibly. See how we use data in our cookie policy.
          </p>
        </div>
        <div className="flex flex-col gap-2 md:min-w-[160px]">
          <button
            type="button"
            onClick={acceptCookies}
            className="w-full rounded-full bg-primary px-5 py-2 text-sm font-semibold text-softcream shadow-lg transition hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2"
          >
            Accept
          </button>
          <Link
            to="/cookies"
            className="w-full rounded-full border border-primary px-5 py-2 text-center text-sm font-semibold text-primary transition hover:border-accentblue hover:text-accentblue focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2"
            onClick={() => setVisible(false)}
          >
            Manage Preferences
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;