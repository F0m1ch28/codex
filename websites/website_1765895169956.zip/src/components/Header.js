import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/company', label: 'Company' },
  { to: '/services', label: 'Services' },
  { to: '/risk-assessment', label: 'Risk Assessment' },
  { to: '/resilience-analysis', label: 'Resilience' },
  { to: '/environmental-exposure', label: 'Environmental Exposure' },
  { to: '/applications', label: 'Applications' },
  { to: '/contact', label: 'Contact' },
];

const Header = () => {
  const [open, setOpen] = useState(false);

  const toggleMenu = () => setOpen((prev) => !prev);
  const closeMenu = () => setOpen(false);

  return (
    <header className="sticky top-0 z-40 bg-softcream/80 backdrop-blur-lg shadow-md">
      <a href="#main-content" className="skip-link">
        Skip to content
      </a>
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <Link
          to="/"
          onClick={closeMenu}
          className="flex items-center gap-3 text-primary focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2"
        >
          <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary text-softcream">
            <span className="text-xl font-bold">GR</span>
          </span>
          <div className="leading-tight">
            <span className="block font-outfit text-lg font-semibold">
              Green Resilience Lab
            </span>
            <span className="block text-sm text-slate-500">
              Renewable Infrastructure Analytics
            </span>
          </div>
        </Link>

        <nav className="hidden items-center gap-6 lg:flex" aria-label="Main navigation">
          {navLinks.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `rounded-full px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2 ${
                  isActive
                    ? 'bg-primary text-softcream shadow-lg'
                    : 'text-slate-700 hover:text-primary hover:bg-accentyellow/20'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <button
          type="button"
          onClick={toggleMenu}
          className="inline-flex items-center justify-center rounded-full bg-primary px-4 py-2 text-softcream transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2 lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
        >
          <span className="sr-only">Toggle navigation</span>
          <svg
            className="h-6 w-6"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            {open ? (
              <path d="M18 6 6 18M6 6l12 12" />
            ) : (
              <path d="M3 12h18M3 6h18M3 18h18" />
            )}
          </svg>
        </button>
      </div>

      {open && (
        <nav
          id="mobile-menu"
          className="lg:hidden"
          aria-label="Mobile navigation"
        >
          <ul className="space-y-2 border-t border-slate-200 bg-softcream px-4 py-4 shadow-lg">
            {navLinks.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  onClick={closeMenu}
                  className={({ isActive }) =>
                    `block rounded-xl px-4 py-3 text-base font-semibold focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2 ${
                      isActive
                        ? 'bg-primary text-softcream'
                        : 'text-slate-700 hover:bg-accentyellow/20'
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      )}
    </header>
  );
};

export default Header;