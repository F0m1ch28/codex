import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="bg-primary text-softcream">
    <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-4 lg:px-8">
      <div>
        <h3 className="font-outfit text-xl font-semibold">Green Resilience Lab</h3>
        <p className="mt-3 text-sm leading-relaxed text-softcream/80">
          Engineering intelligence for resilient renewable energy infrastructure
          across Canada&apos;s diverse climates.
        </p>
        <div className="mt-5 space-y-1 text-sm text-softcream/70">
          <p>The Stack – Vancouver</p>
          <p>1133 Melville Street, Floor 18</p>
          <p>Vancouver, British Columbia, Canada</p>
          <p>Phone: <a href="tel:+16043439186" className="hover:text-accentyellow">+1 604 343 9186</a></p>
          <p>Email: <a href="mailto:info@greenresiliencelab.com" className="hover:text-accentyellow">info@greenresiliencelab.com</a></p>
        </div>
      </div>

      <div>
        <h4 className="font-outfit text-lg font-semibold text-accentyellow">Navigation</h4>
        <ul className="mt-4 space-y-2 text-sm">
          <li><Link to="/" className="hover:text-accentyellow">Home</Link></li>
          <li><Link to="/company" className="hover:text-accentyellow">Company</Link></li>
          <li><Link to="/services" className="hover:text-accentyellow">Services</Link></li>
          <li><Link to="/risk-assessment" className="hover:text-accentyellow">Risk Assessment</Link></li>
          <li><Link to="/resilience-analysis" className="hover:text-accentyellow">Resilience Analysis</Link></li>
          <li><Link to="/environmental-exposure" className="hover:text-accentyellow">Environmental Exposure</Link></li>
          <li><Link to="/applications" className="hover:text-accentyellow">Applications</Link></li>
        </ul>
      </div>

      <div>
        <h4 className="font-outfit text-lg font-semibold text-accentyellow">Governance</h4>
        <ul className="mt-4 space-y-2 text-sm">
          <li><Link to="/contact" className="hover:text-accentyellow">Contact</Link></li>
          <li><Link to="/privacy" className="hover:text-accentyellow">Privacy Policy</Link></li>
          <li><Link to="/cookies" className="hover:text-accentyellow">Cookie Policy</Link></li>
          <li><Link to="/terms" className="hover:text-accentyellow">Terms of Service</Link></li>
        </ul>
      </div>

      <div>
        <h4 className="font-outfit text-lg font-semibold text-accentyellow">Connect</h4>
        <p className="mt-4 text-sm text-softcream/70">
          Follow our latest research insights, resilience benchmarks, and climate intelligence briefings.
        </p>
        <div className="mt-6 flex items-center gap-4">
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn" className="social-icon">
            in
          </a>
          <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter" className="social-icon">
            t
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube" className="social-icon">
            yt
          </a>
        </div>
      </div>
    </div>
    <div className="border-t border-softcream/20">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 py-6 text-xs text-softcream/60 sm:flex-row sm:px-6 lg:px-8">
        <span>&copy; {new Date().getFullYear()} Green Resilience Lab. All rights reserved.</span>
        <span>Engineered in Vancouver, British Columbia.</span>
      </div>
    </div>
  </footer>
);

export default Footer;