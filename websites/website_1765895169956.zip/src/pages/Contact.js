import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import FadeInSection from '../components/FadeInSection';

const usePageMeta = ({ title, description, url }) => {
  useEffect(() => {
    const fullTitle = title ? `${title} | Green Resilience Lab` : 'Green Resilience Lab';
    document.title = fullTitle;

    const ensure = (attribute, name, content) => {
      if (!content) return;
      let tag = document.head.querySelector(`meta[${attribute}=`${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute(attribute, name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };

    ensure('name', 'description', description);
    ensure('property', 'og:title', fullTitle);
    ensure('property', 'og:description', description);
    ensure('property', 'og:url', url);
    ensure('name', 'twitter:title', fullTitle);
    ensure('name', 'twitter:description', description);
  }, [title, description, url]);
};

const Contact = () => {
  usePageMeta({
    title: 'Contact',
    description:
      'Connect with Green Resilience Lab to request renewable risk assessments, resilience analysis, or climate exposure intelligence for Canadian projects.',
    url: 'https://www.greenresiliencelab.com/contact',
  });

  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!formData.company.trim()) newErrors.company = 'Please enter your organisation.';
    if (!formData.message.trim()) newErrors.message = 'Share a brief description of your objectives.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitting(true);

    // Simulate async submission
    setTimeout(() => {
      setSubmitting(false);
      navigate('/thanks');
    }, 1200);
  };

  return (
    <div className="bg-softcream py-16">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 sm:px-6 lg:grid-cols-5 lg:gap-16 lg:px-8">
        <div className="lg:col-span-2">
          <FadeInSection as="span" className="tagline">
            Contact
          </FadeInSection>
          <FadeInSection as="h1" className="mt-3 font-outfit text-3xl font-semibold text-primary sm:text-4xl">
            Request Renewable Risk Assessment
          </FadeInSection>
          <FadeInSection as="p" className="mt-4 text-sm leading-relaxed text-slate-600">
            Share your project type, climate challenges, and organisational priorities. Our engineers will reply within two business days with a tailored engagement outline or follow-up questions to align scopes.
          </FadeInSection>

          <FadeInSection className="mt-8 rounded-3xl bg-white p-6 shadow-2xl">
            <h2 className="font-outfit text-xl font-semibold text-primary">
              Contact details
            </h2>
            <ul className="mt-4 space-y-3 text-sm text-slate-600">
              <li>
                <strong className="text-primary">Address:</strong> The Stack – Vancouver, 1133 Melville Street, Floor 18, Vancouver, British Columbia, Canada
              </li>
              <li>
                <strong className="text-primary">Phone:</strong>{' '}
                <a href="tel:+16043439186" className="text-accentblue hover:underline">
                  +1 604 343 9186
                </a>
              </li>
              <li>
                <strong className="text-primary">Email:</strong>{' '}
                <a href="mailto:info@greenresiliencelab.com" className="text-accentblue hover:underline">
                  info@greenresiliencelab.com
                </a>
              </li>
            </ul>
            <div className="mt-6 text-sm text-slate-600">
              <p className="font-semibold text-primary">Office hours</p>
              <p>Monday to Friday: 8:30 AM – 5:30 PM PT</p>
              <p>Extended support during major weather events.</p>
            </div>
          </FadeInSection>
        </div>

        <FadeInSection className="lg:col-span-3">
          <form
            onSubmit={handleSubmit}
            noValidate
            className="rounded-3xl bg-white p-8 shadow-2xl"
          >
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <label htmlFor="name" className="form-label">
                  Name
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  className={`form-input ${errors.name ? 'border-red-400 focus:ring-red-400' : ''}`}
                  placeholder="Your full name"
                  autoComplete="name"
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                />
                {errors.name && (
                  <p id="name-error" className="form-error">
                    {errors.name}
                  </p>
                )}
              </div>
              <div>
                <label htmlFor="email" className="form-label">
                  Email
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`form-input ${errors.email ? 'border-red-400 focus:ring-red-400' : ''}`}
                  placeholder="you@example.com"
                  autoComplete="email"
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                />
                {errors.email && (
                  <p id="email-error" className="form-error">
                    {errors.email}
                  </p>
                )}
              </div>
            </div>

            <div className="mt-6">
              <label htmlFor="company" className="form-label">
                Organisation
              </label>
              <input
                id="company"
                name="company"
                type="text"
                value={formData.company}
                onChange={handleChange}
                className={`form-input ${errors.company ? 'border-red-400 focus:ring-red-400' : ''}`}
                placeholder="Company, utility, or community"
                autoComplete="organization"
                aria-invalid={Boolean(errors.company)}
                aria-describedby={errors.company ? 'company-error' : undefined}
              />
              {errors.company && (
                <p id="company-error" className="form-error">
                  {errors.company}
                </p>
              )}
            </div>

            <div className="mt-6">
              <label htmlFor="message" className="form-label">
                Project overview
              </label>
              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                className={`form-textarea ${errors.message ? 'border-red-400 focus:ring-red-400' : ''}`}
                placeholder="Describe your assets, climate challenges, timelines, and stakeholders."
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && (
                <p id="message-error" className="form-error">
                  {errors.message}
                </p>
              )}
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="mt-8 w-full rounded-full bg-primary px-6 py-3 text-sm font-semibold text-softcream shadow-lg transition hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:bg-primary/60"
            >
              {submitting ? 'Submitting...' : 'Submit request'}
            </button>
          </form>
          <div className="mt-8 overflow-hidden rounded-3xl bg-white shadow-2xl">
            <iframe
              title="Green Resilience Lab Vancouver Office Map"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2603.323628765489!2d-123.12231222343794!3d49.28708457138174!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5486717c093cc5ef%3A0xd01c7a1f5edecf66!2sThe%20Stack!5e0!3m2!1sen!2sca!4v1700000000000!5m2!1sen!2sca"
              className="h-72 w-full border-0"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </FadeInSection>
      </div>
    </div>
  );
};

export const ThankYouPage = () => {
  usePageMeta({
    title: 'Request Received',
    description:
      'Thank you for contacting Green Resilience Lab. Our team will respond shortly regarding your renewable resilience inquiry.',
    url: 'https://www.greenresiliencelab.com/thanks',
  });

  return (
    <div className="bg-white py-20">
      <div className="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
        <FadeInSection as="h1" className="font-outfit text-3xl font-semibold text-primary sm:text-4xl">
          Request Received
        </FadeInSection>
        <FadeInSection as="p" className="mt-4 text-lg text-slate-600">
          Thank you for reaching out to Green Resilience Lab. Our engineers will review your information and respond within two business days.
        </FadeInSection>
        <FadeInSection className="mt-8">
          <Link
            to="/"
            className="inline-flex items-center rounded-full bg-primary px-6 py-3 text-sm font-semibold text-softcream shadow-lg transition hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2"
          >
            Return to homepage
          </Link>
        </FadeInSection>
      </div>
    </div>
  );
};

export default Contact;