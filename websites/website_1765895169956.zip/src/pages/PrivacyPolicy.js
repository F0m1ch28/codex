import React, { useEffect } from 'react';
import FadeInSection from '../components/FadeInSection';

const usePageMeta = ({ title, description, url }) => {
  useEffect(() => {
    const fullTitle = title ? `${title} | Green Resilience Lab` : 'Green Resilience Lab';
    document.title = fullTitle;

    const ensure = (attribute, name, content) => {
      if (!content) return;
      let tag = document.head.querySelector(`meta[${attribute}=`${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute(attribute, name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };

    ensure('name', 'description', description);
    ensure('property', 'og:title', fullTitle);
    ensure('property', 'og:description', description);
    ensure('property', 'og:url', url);
    ensure('name', 'twitter:title', fullTitle);
    ensure('name', 'twitter:description', description);
  }, [title, description, url]);
};

const PrivacyPolicy = () => {
  usePageMeta({
    title: 'Privacy Policy',
    description:
      'Privacy Policy outlining how Green Resilience Lab collects, uses, and protects personal data in accordance with Canadian privacy legislation.',
    url: 'https://www.greenresiliencelab.com/privacy',
  });

  return (
    <div className="bg-white py-16">
      <div className="mx-auto max-w-4xl rounded-3xl bg-softcream px-6 py-10 shadow-2xl sm:px-10">
        <FadeInSection as="h1" className="font-outfit text-3xl font-semibold text-primary sm:text-4xl">
          Privacy Policy
        </FadeInSection>
        <FadeInSection as="p" className="mt-4 text-sm leading-relaxed text-slate-600">
          Effective date: January 1, 2024
        </FadeInSection>

        <FadeInSection className="mt-6 space-y-6 text-sm leading-relaxed text-slate-600">
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">1. Commitment to privacy</h2>
            <p className="mt-2">
              Green Resilience Lab respects your privacy and handles personal information in alignment with the Personal Information Protection and Electronic Documents Act (PIPEDA), British Columbia’s Personal Information Protection Act (PIPA), and other applicable Canadian legislation.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">2. Information we collect</h2>
            <p className="mt-2">
              We collect personal and business contact details submitted through forms, emails, or consultations. We may also collect technical information such as IP addresses, device type, and pages visited to understand site usage and enhance accessibility.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">3. How information is used</h2>
            <p className="mt-2">
              Information is used to respond to inquiries, provide services, improve our offerings, and share relevant research or event invitations. We do not sell or trade personal information. Data may be shared with trusted partners who support service delivery under confidentiality agreements.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">4. Data storage &amp; security</h2>
            <p className="mt-2">
              We store data on secure servers located in Canada or jurisdictions with comparable protections. Access is limited to personnel with a legitimate need. We maintain administrative, technical, and physical safeguards to protect against unauthorised access.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">5. Your rights</h2>
            <p className="mt-2">
              You may request access to, correction of, or deletion of your personal information, subject to legal and contractual obligations. To submit a request, contact our privacy officer at{' '}
              <a href="mailto:info@greenresiliencelab.com" className="text-accentblue hover:underline">
                info@greenresiliencelab.com
              </a>.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">6. Children’s privacy</h2>
            <p className="mt-2">
              Our services are designed for professionals and organisations. We do not knowingly collect information from individuals under the age of 16.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">7. Updates</h2>
            <p className="mt-2">
              We may update this policy to reflect changes in regulation or practice. The effective date above will change when updates occur.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">8. Contact</h2>
            <p className="mt-2">
              For questions regarding privacy or to exercise your rights, contact our privacy officer at Green Resilience Lab, The Stack – Vancouver, 1133 Melville Street, Floor 18, Vancouver, British Columbia, Canada, or email{' '}
              <a href="mailto:info@greenresiliencelab.com" className="text-accentblue hover:underline">
                info@greenresiliencelab.com
              </a>.
            </p>
          </section>
        </FadeInSection>
      </div>
    </div>
  );
};

export const CookiePolicyPage = () => {
  usePageMeta({
    title: 'Cookie Policy',
    description:
      'Cookie Policy describing how Green Resilience Lab uses cookies and similar technologies for analytics and accessibility.',
    url: 'https://www.greenresiliencelab.com/cookies',
  });

  return (
    <div className="bg-softcream py-16">
      <div className="mx-auto max-w-4xl rounded-3xl bg-white px-6 py-10 shadow-2xl sm:px-10">
        <FadeInSection as="h1" className="font-outfit text-3xl font-semibold text-primary sm:text-4xl">
          Cookie Policy
        </FadeInSection>
        <FadeInSection className="mt-6 space-y-6 text-sm leading-relaxed text-slate-600">
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">1. Purpose of cookies</h2>
            <p className="mt-2">
              We use cookies to understand website performance, maintain accessibility preferences, and tailor content to visitor interests. Cookies support us in delivering relevant information without storing unnecessary personal data.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">2. Types of cookies</h2>
            <ul className="mt-2 list-disc space-y-2 pl-5">
              <li><strong>Essential cookies</strong> maintain session integrity and core site functionality.</li>
              <li><strong>Analytics cookies</strong> capture aggregated site usage to enhance navigation and content design.</li>
              <li><strong>Preference cookies</strong> remember language, accessibility, and consent selections.</li>
            </ul>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">3. Managing preferences</h2>
            <p className="mt-2">
              You can adjust your cookie preferences through our cookie banner or via browser settings. Restricting cookies may impact certain site features, but essential functionality will remain accessible.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">4. Third-party analytics</h2>
            <p className="mt-2">
              We may use privacy-focused analytics services that anonymise visitor data. These providers are bound by contractual obligations to process data securely and in compliance with Canadian regulations.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">5. Updates</h2>
            <p className="mt-2">
              We review this cookie policy periodically to reflect technology changes and regulatory updates. Continued use of the site after changes constitutes acceptance of the updated policy.
            </p>
          </section>
        </FadeInSection>
      </div>
    </div>
  );
};

export default PrivacyPolicy;