import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import FadeInSection from '../components/FadeInSection';

const usePageMeta = ({ title, description, url, image, keywords, jsonLd }) => {
  useEffect(() => {
    const fullTitle = title ? `${title} | Green Resilience Lab` : 'Green Resilience Lab';
    document.title = fullTitle;

    const setMeta = (selector, attr, value) => {
      if (!value) return;
      let element = document.head.querySelector(selector);
      if (!element) {
        element = document.createElement('meta');
        if (attr === 'property') {
          element.setAttribute('property', selector.replace('meta[property="', '').replace('"]', ''));
        } else {
          element.setAttribute('name', selector.replace('meta[name="', '').replace('"]', ''));
        }
        document.head.appendChild(element);
      }
      element.setAttribute(attr, value);
      if (attr === 'name') {
        element.setAttribute('content', value);
      }
    };

    const ensureMeta = (name, content) => {
      if (!content) return;
      let tag = document.head.querySelector(`meta[name=`${name}`]`);
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };

    const ensureProperty = (property, content) => {
      if (!content) return;
      let tag = document.head.querySelector(`meta[property=`${property}`]`);
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('property', property);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };

    ensureMeta('description', description);
    ensureMeta('keywords', keywords);
    ensureProperty('og:title', fullTitle);
    ensureProperty('og:description', description);
    ensureProperty('og:url', url);
    ensureProperty('og:image', image);
    ensureProperty('twitter:title', fullTitle);
    ensureProperty('twitter:description', description);
    ensureMeta('twitter:image', image);

    const existingJsonLd = document.getElementById('structured-data-home');
    if (existingJsonLd) {
      existingJsonLd.remove();
    }
    if (jsonLd) {
      const script = document.createElement('script');
      script.setAttribute('type', 'application/ld+json');
      script.id = 'structured-data-home';
      script.textContent = JSON.stringify(jsonLd);
      document.head.appendChild(script);
    }
  }, [title, description, url, image, keywords, jsonLd]);
};

const Home = () => {
  usePageMeta({
    title: 'Assessing Risk & Resilience for Renewable Infrastructure',
    description:
      'Green Resilience Lab delivers climate-informed risk, resilience, and reliability analytics for renewable infrastructure operating in Canadian conditions.',
    url: 'https://www.greenresiliencelab.com/',
    image: 'https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=1600&q=80',
    keywords:
      'renewable risk assessment Canada, clean energy resilience analysis, renewable infrastructure reliability, solar wind risk evaluation, environmental exposure renewables, operational resilience energy, clean power risk monitoring',
    jsonLd: {
      '@context': 'https://schema.org',
      '@type': 'EducationalOrganization',
      'name': 'Green Resilience Lab',
      'url': 'https://www.greenresiliencelab.com',
      'logo': 'https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=1600&q=80',
      'address': {
        '@type': 'PostalAddress',
        'streetAddress': '1133 Melville Street, Floor 18',
        'addressLocality': 'Vancouver',
        'addressRegion': 'BC',
        'postalCode': 'V6E 4E5',
        'addressCountry': 'CA',
      },
      'contactPoint': {
        '@type': 'ContactPoint',
        'telephone': '+1-604-343-9186',
        'contactType': 'customer support',
        'email': 'info@greenresiliencelab.com',
      },
      'description':
        'Engineering consulting and analytics for renewable risk assessment, resilience modelling, and operational reliability in Canadian conditions.',
    },
  });

  const stats = [
    {
      label: 'Climate stressors modeled annually',
      value: '120+',
      detail: 'Wind, icing, wildfire smoke, freeze-thaw, lightning, hydrometeorological extremes.',
    },
    {
      label: 'Infrastructure components monitored',
      value: '18,000',
      detail: 'Turbine nacelles, PV strings, battery racks, power electronics, substations.',
    },
    {
      label: 'Resilience uplift achieved',
      value: '28%',
      detail: 'Average downtime reduction after implementing mitigation recommendations.',
    },
  ];

  const riskFactors = [
    {
      title: 'Wind Shear & Turbulence',
      description:
        'Granular wind field modelling for Atlantic, Prairie, and Arctic corridors, identifying tower fatigue hotspots and yaw misalignment risk.',
      icon: '💨',
    },
    {
      title: 'Icing & Freezing Rain',
      description:
        'Supercooled droplet accretion analysis and blade heating ROI scenarios for winterized wind farms and alpine solar arrays.',
      icon: '❄️',
    },
    {
      title: 'Heat Waves & Wildfire Smoke',
      description:
        'Thermal derating projections for PV inverters, balance-of-system equipment, and battery systems facing wildfire particulate loads.',
      icon: '🔥',
    },
    {
      title: 'Permafrost & Soil Instability',
      description:
        'Foundation settlement modelling for northern microgrids, including thaw subsidence and geotechnical monitoring thresholds.',
      icon: '🧊',
    },
  ];

  const testimonials = [
    {
      quote:
        'Green Resilience Lab translated complex weather datasets into clear operational decisions for our hybrid wind-solar facility in Saskatchewan.',
      person: 'Amelia Chen',
      role: 'Director of Asset Reliability, Prairie Renewables Cooperative',
    },
    {
      quote:
        'Their resilience scoring illuminated weak points in our Arctic microgrid and guided a pragmatic reinforcement plan that our engineers could execute.',
      person: 'Marc Tremblay',
      role: 'Chief Engineer, Northern Lights Energy Authority',
    },
    {
      quote:
        'We now have a living risk register and mitigation roadmap tied to real environmental triggers rather than static assumptions.',
      person: 'Leah Ross',
      role: 'Operations Manager, Cascadia Clean Power',
    },
  ];

  return (
    <div id="main-content">
      <section
        className="relative overflow-hidden bg-primary text-softcream"
        aria-labelledby="hero-heading"
      >
        <div
          className="absolute inset-0"
          aria-hidden="true"
          style={{
            backgroundImage:
              'linear-gradient(120deg, rgba(30,27,75,0.85) 20%, rgba(59,130,246,0.35) 100%), url("https://images.unsplash.com/photo-1521208914985-588393a3aa45?auto=format&fit=crop&w=1600&q=80")',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="relative mx-auto flex max-w-7xl flex-col gap-10 px-4 py-24 sm:px-6 lg:grid lg:grid-cols-12 lg:gap-16 lg:px-8 lg:py-28">
          <div className="lg:col-span-7">
            <FadeInSection delay={0.1} as="div">
              <p className="inline-flex items-center rounded-full bg-softcream/10 px-4 py-1 text-sm uppercase tracking-widest text-accentyellow backdrop-blur">
                Renewable Risk Intelligence
              </p>
            </FadeInSection>
            <FadeInSection delay={0.2} as="div">
              <h1
                id="hero-heading"
                className="mt-6 font-outfit text-4xl font-semibold leading-tight sm:text-5xl lg:text-6xl lg:leading-[1.05]"
              >
                Assessing Risk &amp; Resilience for Renewable Infrastructure
              </h1>
            </FadeInSection>
            <FadeInSection delay={0.3} as="p" className="mt-6 max-w-2xl text-lg text-softcream/80">
              We combine climate science, engineering analytics, and operational data to quantify how Canadian weather extremes impact solar, wind, and hybrid energy assets—then design resilient pathways for dependable generation.
            </FadeInSection>
            <FadeInSection delay={0.4} as="div" className="mt-10 flex flex-wrap items-center gap-4">
              <Link
                to="/contact"
                className="btn-primary"
              >
                Request Renewable Risk Assessment
              </Link>
              <Link
                to="/services"
                className="inline-flex items-center rounded-full border border-softcream px-6 py-3 text-sm font-semibold text-softcream transition hover:border-accentyellow hover:text-accentyellow focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2 focus-visible:ring-offset-primary"
              >
                Explore Resilience Services
              </Link>
            </FadeInSection>
          </div>
          <FadeInSection delay={0.4} as="div" className="lg:col-span-5">
            <div className="glass-panel flex flex-col gap-6">
              <h2 className="font-outfit text-xl font-semibold text-accentyellow">
                2024 Climate Readiness Dashboard
              </h2>
              <ul className="space-y-4 text-sm text-softcream/80">
                <li className="flex items-start gap-3">
                  <span className="mt-1 inline-flex h-8 w-8 items-center justify-center rounded-full bg-accentyellow/20 text-accentyellow">
                    01
                  </span>
                  <div>
                    <p className="font-semibold text-softcream">
                      Adaptive stress testing
                    </p>
                    <p>
                      Scenario libraries for atmospheric rivers, polar vortex events, and heat dome conditions.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-1 inline-flex h-8 w-8 items-center justify-center rounded-full bg-accentyellow/20 text-accentyellow">
                    02
                  </span>
                  <div>
                    <p className="font-semibold text-softcream">
                      Real-time reliability scoring
                    </p>
                    <p>
                      Component-level health indices aligned to IEC standards, CSA guidelines, and Indigenous community agreements.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-1 inline-flex h-8 w-8 items-center justify-center rounded-full bg-accentyellow/20 text-accentyellow">
                    03
                  </span>
                  <div>
                    <p className="font-semibold text-softcream">
                      Mitigation design briefs
                    </p>
                    <p>
                      Engineering actions prioritised by risk criticality, budget cadence, and seasonal access windows.
                    </p>
                  </div>
                </li>
              </ul>
            </div>
          </FadeInSection>
        </div>
      </section>

      <FadeInSection id="why-resilience" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2">
          <div>
            <span className="tagline">Why Resilience Matters for Clean Energy Assets</span>
            <h2 className="mt-4 font-outfit text-3xl font-semibold text-primary sm:text-4xl">
              Canadian renewable infrastructure is operating inside a volatility era
            </h2>
            <p className="mt-4 text-lg text-slate-600">
              Wind gust differentials, icing events, and wildfire seasons are accelerating faster than legacy engineering assumptions. Green Resilience Lab architects resilience programmes that mitigate downtime, extend component life, and maintain community trust in clean power systems.
            </p>
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {stats.map((stat) => (
                <div key={stat.label} className="rounded-2xl bg-white/70 p-6 shadow-soft">
                  <p className="text-3xl font-bold text-primary">{stat.value}</p>
                  <p className="mt-2 text-sm font-semibold text-slate-500 uppercase tracking-wide">{stat.label}</p>
                  <p className="mt-3 text-sm text-slate-600">{stat.detail}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-3xl bg-gradient-to-br from-primary/90 via-primary to-accentblue/80 p-[1px]">
            <div className="h-full rounded-[calc(1.5rem-1px)] bg-white/90 p-8 text-sm leading-relaxed text-slate-700 shadow-xl">
              <h3 className="font-outfit text-xl font-semibold text-primary">
                Resilience programme architecture
              </h3>
              <ul className="mt-6 space-y-5">
                <li className="flex items-start gap-3">
                  <span className="mt-1 inline-flex h-6 w-6 items-center justify-center rounded-full bg-accentblue/10 text-accentblue">1</span>
                  <div>
                    <p className="font-semibold text-primary">Asset &amp; component mapping</p>
                    <p>Digital twins established for turbines, PV strings, BESS clusters, and grid interfaces.</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-1 inline-flex h-6 w-6 items-center justify-center rounded-full bg-accentblue/10 text-accentblue">2</span>
                  <div>
                    <p className="font-semibold text-primary">Climate hazard libraries</p>
                    <p>Regionally downscaled climate projections layered with historical extremes for scenario depth.</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-1 inline-flex h-6 w-6 items-center justify-center rounded-full bg-accentblue/10 text-accentblue">3</span>
                  <div>
                    <p className="font-semibold text-primary">Operational risk loops</p>
                    <p>Maintenance workflows aligned to risk thresholds, predictive alerts, and Indigenous community agreements.</p>
                  </div>
                </li>
              </ul>
              <Link
                to="/company"
                className="mt-8 inline-flex items-center rounded-full bg-accentblue px-5 py-3 font-semibold text-white shadow-lg transition hover:bg-accentblue/90 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2"
              >
                Learn about our methodology
              </Link>
            </div>
          </div>
        </div>
      </FadeInSection>

      <FadeInSection id="environmental-factors" className="bg-white py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="md:flex md:items-center md:justify-between">
            <div>
              <span className="tagline">Environmental Risk Factors in Canada</span>
              <h2 className="mt-3 font-outfit text-3xl font-semibold text-primary sm:text-4xl">
                Mapping exposure profiles across provinces and territories
              </h2>
              <p className="mt-4 max-w-3xl text-lg text-slate-600">
                From Atlantic hurricane remnants to Arctic polar lows and Pacific atmospheric rivers, our datasets map exposure intensity across site portfolios. We combine Environment and Climate Change Canada records, remote sensing, and SCADA data to deliver actionable hazard profiles.
              </p>
            </div>
            <Link
              to="/environmental-exposure"
              className="mt-6 inline-flex items-center rounded-full border border-primary px-5 py-3 font-semibold text-primary transition hover:border-accentblue hover:text-accentblue focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2 md:mt-0"
            >
              Dive into exposure analytics →
            </Link>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-2">
            {riskFactors.map((factor) => (
              <div
                key={factor.title}
                className="rounded-3xl border border-slate-200 bg-softcream/60 p-8 shadow-soft transition hover:-translate-y-1 hover:shadow-2xl"
              >
                <span className="text-3xl">{factor.icon}</span>
                <h3 className="mt-4 font-outfit text-2xl font-semibold text-primary">
                  {factor.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-slate-600">
                  {factor.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </FadeInSection>

      <FadeInSection id="operational-vulnerability" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <div>
            <span className="tagline">Operational Vulnerability Analysis</span>
            <h2 className="mt-4 font-outfit text-3xl font-semibold text-primary sm:text-4xl">
              Pinpointing failure modes before they cascade into outages
            </h2>
            <p className="mt-4 text-lg text-slate-600">
              Using probabilistic risk assessment and lived operational data, we quantify component stresses, failure likelihoods, and downtime impacts. Our vulnerability workflows connect engineering models, inspection reports, and SCADA anomalies to reveal how weather complexity triggers operational strain.
            </p>
            <div className="mt-6 space-y-4">
              <div className="rounded-2xl border border-accentblue/20 bg-white p-5">
                <p className="text-sm font-semibold uppercase text-accentblue">Reliability insights</p>
                <p className="mt-2 text-sm text-slate-600">
                  Weibull reliability curves for blades, gearboxes, PV modules, and energy storage stacks calibrated to Canadian conditions.
                </p>
              </div>
              <div className="rounded-2xl border border-accentblue/20 bg-white p-5">
                <p className="text-sm font-semibold uppercase text-accentblue">Operational readiness</p>
                <p className="mt-2 text-sm text-slate-600">
                  Maintenance backlog triage, parts logistics under winter road closures, and segment-level risk dashboards.
                </p>
              </div>
            </div>
          </div>
          <div>
            <img
              src="https://images.unsplash.com/photo-1616587226075-6d6df3a3c9ed?auto=format&fit=crop&w=1200&q=80"
              alt="Wind turbines operating in snowy environment"
              className="rounded-3xl shadow-xl"
            />
            <p className="mt-4 text-xs text-slate-500">
              Example: iced turbine cluster analysis for coastal Labrador wind site with predictive blade heating plan.
            </p>
          </div>
        </div>
      </FadeInSection>

      <FadeInSection id="resilience-scoring" className="bg-midnight py-20 text-softcream">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="md:flex md:items-center md:justify-between">
            <div>
              <span className="tagline text-accentyellow">Resilience Scoring &amp; Reliability Metrics</span>
              <h2 className="mt-3 font-outfit text-3xl font-semibold sm:text-4xl">
                A transparent scoring system grounded in engineering standards
              </h2>
            </div>
            <Link
              to="/resilience-analysis"
              className="mt-6 inline-flex items-center rounded-full bg-accentyellow px-6 py-3 text-sm font-semibold text-primary shadow-lg transition hover:bg-accentyellow/90 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-softcream focus-visible:ring-offset-2 focus-visible:ring-offset-midnight md:mt-0"
            >
              Review scoring framework
            </Link>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {[
              {
                title: 'Resilience Index (RI)',
                detail:
                  'Composite score integrating hazard exposure, system redundancy, operational response, and recovery velocity.',
              },
              {
                title: 'Reliability Confidence Interval',
                detail:
                  'Quantifies uncertainty bounds for component performance based on climate-adjusted Weibull analysis.',
              },
              {
                title: 'Adaptive Capacity Indicators',
                detail:
                  'Measures organisational ability to update procedures, allocate resources, and coordinate during stress events.',
              },
            ].map((item) => (
              <div key={item.title} className="rounded-3xl bg-softcream/10 p-6 shadow-soft backdrop-blur">
                <h3 className="font-outfit text-xl font-semibold text-accentyellow">
                  {item.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-softcream/80">
                  {item.detail}
                </p>
              </div>
            ))}
          </div>
        </div>
      </FadeInSection>

      <FadeInSection id="engineering-insights" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-10 lg:flex-row">
          <div className="lg:w-2/5">
            <span className="tagline">Engineering Insights for Risk Mitigation</span>
            <h2 className="mt-4 font-outfit text-3xl font-semibold text-primary sm:text-4xl">
              Design reviews, retrofit strategies, and adaptive playbooks
            </h2>
            <p className="mt-4 text-lg text-slate-600">
              We translate analytics into actionable engineering insights spanning early-stage design charrettes, retrofit planning, and real-time event response. Client teams receive stakeholder-ready communication kits and implementation roadmaps.
            </p>
            <ul className="mt-6 space-y-4 text-sm text-slate-600">
              <li className="rounded-2xl border border-slate-200 bg-white p-4">
                <strong className="text-primary">Winterization retrofits:</strong> Blade icing solutions, panel tilt optimisation, heat trace upgrades, and control tuning.
              </li>
              <li className="rounded-2xl border border-slate-200 bg-white p-4">
                <strong className="text-primary">Hybrid system integration:</strong> Coordinating PV, wind, storage, and backup systems for coherent resilience strategies.
              </li>
              <li className="rounded-2xl border border-slate-200 bg-white p-4">
                <strong className="text-primary">Community readiness:</strong> Indigenous and northern engagement frameworks aligning with cultural protocols and energy sovereignty goals.
              </li>
            </ul>
          </div>
          <div className="lg:w-3/5">
            <div className="rounded-3xl bg-white p-6 shadow-xl">
              <h3 className="font-outfit text-xl font-semibold text-primary">
                Voices from Canadian clean energy operators
              </h3>
              <div className="mt-6 grid gap-6 md:grid-cols-2">
                {testimonials.map((item) => (
                  <blockquote
                    key={item.person}
                    className="flex h-full flex-col justify-between rounded-2xl border border-slate-200 bg-softcream/60 p-5 text-sm leading-relaxed text-slate-700"
                  >
                    <p>&ldquo;{item.quote}&rdquo;</p>
                    <footer className="mt-4">
                      <p className="font-semibold text-primary">{item.person}</p>
                      <p className="text-xs uppercase tracking-wide text-slate-500">{item.role}</p>
                    </footer>
                  </blockquote>
                ))}
              </div>
            </div>
          </div>
        </div>
      </FadeInSection>

      <FadeInSection id="cta" className="bg-gradient-to-br from-primary via-primary to-accentblue py-20">
        <div className="mx-auto max-w-5xl rounded-3xl bg-white/10 p-10 text-center text-softcream shadow-2xl backdrop-blur">
          <h2 className="font-outfit text-3xl font-semibold">Ready to stress-test your renewable assets?</h2>
          <p className="mx-auto mt-4 max-w-3xl text-lg text-softcream/80">
            Share your site specifics, technology mix, and operational priorities. We will curate a resilience assessment blueprint tailored to Canadian regulations, permitting realities, and your organisational thresholds.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link to="/contact" className="btn-primary">
              Launch Assessment Request
            </Link>
            <Link
              to="/applications"
              className="inline-flex items-center rounded-full border border-softcream px-6 py-3 text-sm font-semibold text-softcream transition hover:border-accentyellow hover:text-accentyellow focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-softcream focus-visible:ring-offset-2 focus-visible:ring-offset-primary"
            >
              See Canadian application scenarios
            </Link>
          </div>
        </div>
      </FadeInSection>
    </div>
  );
};

export default Home;