import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import FadeInSection from '../components/FadeInSection';

const usePageMeta = ({ title, description, url }) => {
  useEffect(() => {
    const fullTitle = title ? `${title} | Green Resilience Lab` : 'Green Resilience Lab';
    document.title = fullTitle;

    const ensure = (attribute, name, content) => {
      if (!content) return;
      let tag = document.head.querySelector(`meta[${attribute}=`${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute(attribute, name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };

    ensure('name', 'description', description);
    ensure('property', 'og:title', fullTitle);
    ensure('property', 'og:description', description);
    ensure('property', 'og:url', url);
    ensure('name', 'twitter:title', fullTitle);
    ensure('name', 'twitter:description', description);
  }, [title, description, url]);
};

const coreServices = [
  {
    title: 'Infrastructure Risk Assessment',
    description:
      'Comprehensive risk matrices, failure mode assessments, and mitigation plans for wind, solar, storage, and hybrid assets.',
    link: '/risk-assessment',
  },
  {
    title: 'Resilience Modelling & Stress Testing',
    description:
      'Scenario-driven simulations capturing climate extremes, redundancy modelling, and adaptive capacity scoring.',
    link: '/resilience-analysis',
  },
  {
    title: 'Environmental Exposure Intelligence',
    description:
      'Regionally calibrated hazard libraries mapping wind, icing, wildfire, and thermal loading for Canadian geographies.',
    link: '/environmental-exposure',
  },
  {
    title: 'Applications Across Canada',
    description:
      'Use cases for large-scale farms, industrials, remote communities, and hybrid systems navigating Canada’s climate diversity.',
    link: '/applications',
  },
];

const Services = () => {
  usePageMeta({
    title: 'Services',
    description:
      'Discover Green Resilience Lab services spanning renewable risk assessment, resilience modelling, environmental exposure analysis, and Canadian application support.',
    url: 'https://www.greenresiliencelab.com/services',
  });

  return (
    <div className="bg-white py-16">
      <div className="mx-auto max-w-5xl px-4 text-center sm:px-6 lg:px-8">
        <FadeInSection delay={0.1} as="span" className="tagline">
          Services
        </FadeInSection>
        <FadeInSection delay={0.2} as="h1" className="font-outfit text-3xl font-semibold text-primary sm:text-4xl">
          Integrated risk and resilience services for renewable operators
        </FadeInSection>
        <FadeInSection delay={0.3} as="p" className="mx-auto mt-4 max-w-3xl text-lg text-slate-600">
          From pre-construction feasibility to operational optimisation, we deploy engineering analysis that anticipates climate stress and maintains renewable reliability for Canadian communities.
        </FadeInSection>
      </div>

      <FadeInSection delay={0.2} className="mx-auto mt-12 grid max-w-6xl gap-6 px-4 sm:px-6 lg:grid-cols-2 lg:gap-8 lg:px-8">
        {coreServices.map((service) => (
          <div key={service.title} className="rounded-3xl border border-slate-200 bg-softcream/60 p-8 text-left shadow-soft transition hover:-translate-y-1 hover:shadow-xl">
            <h3 className="font-outfit text-2xl font-semibold text-primary">{service.title}</h3>
            <p className="mt-3 text-sm leading-relaxed text-slate-600">{service.description}</p>
            <Link
              to={service.link}
              className="mt-6 inline-flex items-center rounded-full bg-primary px-5 py-3 text-sm font-semibold text-softcream shadow-lg transition hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2"
            >
              Explore {service.title} →
            </Link>
          </div>
        ))}
      </FadeInSection>

      <FadeInSection delay={0.3} className="mx-auto mt-16 max-w-6xl rounded-3xl bg-primary px-6 py-12 text-softcream shadow-2xl sm:px-10">
        <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
          <div>
            <h2 className="font-outfit text-2xl font-semibold">How we collaborate</h2>
            <p className="mt-4 text-sm text-softcream/80">
              We operate as embedded partners, aligning our analytics with your operational cadence. Engagements often blend remote sensing analysis, on-site inspections, stakeholder workshops, and real-time monitoring integration.
            </p>
            <ul className="mt-4 space-y-3 text-sm text-softcream/80">
              <li>Co-designing resilience KPIs with asset managers and community leaders.</li>
              <li>Developing learning modules for technicians preparing for seasonal hazards.</li>
              <li>Producing board-ready briefings articulating capital planning priorities.</li>
            </ul>
          </div>
          <div className="rounded-3xl bg-white/10 p-6 text-sm text-softcream/80">
            <h3 className="font-outfit text-lg font-semibold text-accentyellow">Engagement timeline</h3>
            <ul className="mt-4 space-y-2">
              <li><strong className="text-softcream">Weeks 1-4:</strong> Data discovery, stakeholder interviews, baseline resilience scoring.</li>
              <li><strong className="text-softcream">Weeks 5-10:</strong> Scenario modelling, risk register development, and technical workshops.</li>
              <li><strong className="text-softcream">Weeks 11-16:</strong> Mitigation design briefs, implementation roadmap, monitoring framework.</li>
            </ul>
            <p className="mt-4">
              Engagement cadence adapts to site conditions, permitting windows, and community consultations.
            </p>
          </div>
        </div>
      </FadeInSection>

      <FadeInSection delay={0.4} className="mx-auto mt-16 max-w-5xl px-4 text-center sm:px-6 lg:px-8">
        <h2 className="font-outfit text-2xl font-semibold text-primary">
          Start a resilience dialogue
        </h2>
        <p className="mt-4 text-sm text-slate-600">
          Contact our Vancouver team to align on goals, data availability, and collaboration models. We provide a tailored engagement outline within five business days.
        </p>
        <Link
          to="/contact"
          className="mt-6 inline-flex items-center rounded-full bg-accentblue px-6 py-3 text-sm font-semibold text-white shadow-lg transition hover:bg-accentblue/90 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-accentblue focus-visible:ring-offset-2"
        >
          Connect with our engineers
        </Link>
      </FadeInSection>
    </div>
  );
};

export const RiskAssessmentPage = () => {
  usePageMeta({
    title: 'Renewable Infrastructure Risk Assessment',
    description:
      'Green Resilience Lab delivers component-level renewable risk assessments with failure mode analysis and mitigation roadmaps tailored to Canadian climates.',
    url: 'https://www.greenresiliencelab.com/risk-assessment',
  });

  const riskSteps = [
    {
      title: 'Asset inventory & topology',
      detail:
        'Cataloguing turbines, PV arrays, storage banks, and balance-of-plant assets with geospatial attributes, maintenance history, and criticality scoring.',
    },
    {
      title: 'Hazard mapping & failure modes',
      detail:
        'Quantifying climatic, geotechnical, and operational hazards that interact with component vulnerabilities to trigger failure modes.',
    },
    {
      title: 'Risk register & prioritisation',
      detail:
        'Ranking risks by likelihood, severity, and detection ability, supported by heat maps, Monte Carlo outputs, and recommended mitigation actions.',
    },
  ];

  return (
    <div className="bg-softcream py-16">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <FadeInSection as="span" className="tagline">
          Services · Risk Assessment
        </FadeInSection>
        <FadeInSection as="h1" className="mt-3 font-outfit text-3xl font-semibold text-primary sm:text-4xl">
          Renewable infrastructure risk assessment grounded in Canadian data
        </FadeInSection>
        <FadeInSection as="p" className="mt-4 text-lg text-slate-600">
          We build comprehensive risk matrices for renewable assets, integrating site inspections, SCADA analytics, and climate projections. Each assessment delivers actionable insights that align engineering teams, communities, and regulators.
        </FadeInSection>

        <FadeInSection className="mt-10 grid gap-6 md:grid-cols-3">
          {riskSteps.map((step) => (
            <div key={step.title} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
              <h3 className="font-outfit text-xl font-semibold text-primary">{step.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-slate-600">{step.detail}</p>
            </div>
          ))}
        </FadeInSection>

        <FadeInSection className="mt-12 rounded-3xl bg-white p-8 shadow-2xl">
          <h2 className="font-outfit text-2xl font-semibold text-primary">Structured deliverables</h2>
          <ul className="mt-4 space-y-3 text-sm text-slate-600">
            <li><strong className="text-primary">Component vulnerability dossiers:</strong> Detailed narratives highlighting early warning indicators and maintenance triggers.</li>
            <li><strong className="text-primary">Risk exposure heat maps:</strong> Visual overlays combining geographic, climatic, and operational data.</li>
            <li><strong className="text-primary">Mitigation cost-benefit narratives:</strong> Engineering rationale, implementation sequencing, and expected resilience uplift.</li>
          </ul>
        </FadeInSection>
      </div>
    </div>
  );
};

export const ResilienceAnalysisPage = () => {
  usePageMeta({
    title: 'Resilience Analysis & Stress Testing',
    description:
      'Green Resilience Lab models renewable resilience with stress tests, redundancy analysis, and adaptive capacity metrics for Canadian clean energy systems.',
    url: 'https://www.greenresiliencelab.com/resilience-analysis',
  });

  const modules = [
    {
      title: 'Scenario stress testing',
      detail:
        'Simulate atmospheric rivers, heat domes, polar vortex events, and compound hazards to evaluate system behaviour.',
    },
    {
      title: 'Redundancy & recovery modelling',
      detail:
        'Assess backup systems, islanding capabilities, and inventory resilience to maintain power delivery during disruptions.',
    },
    {
      title: 'Adaptive capacity metrics',
      detail:
        'Gauge organisational readiness, decision velocity, and knowledge management for rapid response and learning.',
    },
  ];

  return (
    <div className="bg-white py-16">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <FadeInSection as="span" className="tagline">
          Services · Resilience Analysis
        </FadeInSection>
        <FadeInSection as="h1" className="mt-3 font-outfit text-3xl font-semibold text-primary sm:text-4xl">
          Resilience analysis that anticipates climate volatility
        </FadeInSection>
        <FadeInSection as="p" className="mt-4 text-lg text-slate-600">
          We translate future climate uncertainties into actionable resilience plans, ensuring renewable infrastructure maintains dependable operations under stress.
        </FadeInSection>

        <FadeInSection className="mt-10 grid gap-6 md:grid-cols-3">
          {modules.map((module) => (
            <div key={module.title} className="rounded-3xl border border-slate-200 bg-softcream/60 p-6 shadow-soft">
              <h3 className="font-outfit text-xl font-semibold text-primary">{module.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-slate-600">{module.detail}</p>
            </div>
          ))}
        </FadeInSection>

        <FadeInSection className="mt-12 rounded-3xl bg-primary/90 p-8 text-softcream shadow-2xl">
          <h2 className="font-outfit text-2xl font-semibold text-accentyellow">
            Outputs that empower decisions
          </h2>
          <ul className="mt-4 space-y-3 text-sm text-softcream/80">
            <li>Resilience scorecards with benchmarks against national and provincial peers.</li>
            <li>Decision playbooks for operational, tactical, and strategic horizons.</li>
            <li>Training modules reinforcing how teams respond to alerts and triggers.</li>
          </ul>
        </FadeInSection>
      </div>
    </div>
  );
};

export const EnvironmentalExposurePage = () => {
  usePageMeta({
    title: 'Environmental Exposure Analysis',
    description:
      'Green Resilience Lab maps wind, temperature, icing, and solar exposure for renewable projects across Canada, delivering detailed hazard profiles.',
    url: 'https://www.greenresiliencelab.com/environmental-exposure',
  });

  const exposures = [
    {
      title: 'Wind & turbulence corridors',
      description:
        'Fine-scale wind modelling for onshore and offshore installations, capturing shear, gust, and wake interactions.',
    },
    {
      title: 'Temperature & icing thresholds',
      description:
        'Freeze-thaw analytics, icing accretion forecasting, and thermal derating profiles across provinces and territories.',
    },
    {
      title: 'Solar irradiance & particulate load',
      description:
        'Site-specific solar resource assessment coupled with wildfire smoke and dust deposition analytics.',
    },
    {
      title: 'Regional climate signatures',
      description:
        'Tailored hazard narratives for Atlantic storms, Prairie chinooks, Pacific atmospheric rivers, and Arctic present/future climates.',
    },
  ];

  return (
    <div className="bg-softcream py-16">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <FadeInSection as="span" className="tagline">
          Services · Environmental Exposure
        </FadeInSection>
        <FadeInSection as="h1" className="mt-3 font-outfit text-3xl font-semibold text-primary sm:text-4xl">
          Climate exposure intelligence for renewable portfolios
        </FadeInSection>
        <FadeInSection as="p" className="mt-4 text-lg text-slate-600">
          Our exposure models integrate climate projections, historical records, and remote sensing to quantify hazards affecting construction, commissioning, and long-term operation.
        </FadeInSection>

        <FadeInSection className="mt-10 grid gap-6 md:grid-cols-2">
          {exposures.map((item) => (
            <div key={item.title} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
              <h3 className="font-outfit text-xl font-semibold text-primary">{item.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-slate-600">{item.description}</p>
            </div>
          ))}
        </FadeInSection>

        <FadeInSection className="mt-12 rounded-3xl bg-white p-8 shadow-2xl">
          <h2 className="font-outfit text-2xl font-semibold text-primary">
            Forecast products &amp; deliverables
          </h2>
          <ul className="mt-4 space-y-3 text-sm text-slate-600">
            <li>Monthly and seasonal hazard bulletins tailored to asset portfolios.</li>
            <li>Interactive maps accessible through secure web portals for collaboration.</li>
            <li>Trigger-based alerting integrated with operational communication channels.</li>
          </ul>
        </FadeInSection>
      </div>
    </div>
  );
};

export const ApplicationsPage = () => {
  usePageMeta({
    title: 'Applications Across Canada',
    description:
      'Explore how Green Resilience Lab supports renewable projects from large-scale farms to remote microgrids across Canada.',
    url: 'https://www.greenresiliencelab.com/applications',
  });

  const applications = [
    {
      title: 'Utility-scale wind & solar',
      detail:
        'Lifecycle risk assessments for multi-gigawatt portfolios, including turbine array optimisation and photovoltaic heat management.',
      region: 'Alberta, Saskatchewan, Ontario',
    },
    {
      title: 'Industrial clean energy assets',
      detail:
        'Resilience programmes for mining operations, ports, and heavy industry integrating renewable power into critical processes.',
      region: 'British Columbia, Quebec',
    },
    {
      title: 'Remote & northern installations',
      detail:
        'Hybrid microgrids combining wind, solar, batteries, and diesel backup with a focus on reliability under extreme cold and limited access.',
      region: 'Yukon, Northwest Territories, Nunavut',
    },
    {
      title: 'Community-owned projects',
      detail:
        'Collaborative planning with Indigenous Nations and municipalities to ensure culturally aligned, resilient renewable systems.',
      region: 'Atlantic Canada, Prairie Provinces',
    },
  ];

  return (
    <div className="bg-white py-16">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <FadeInSection as="span" className="tagline">
          Services · Applications
        </FadeInSection>
        <FadeInSection as="h1" className="mt-3 font-outfit text-3xl font-semibold text-primary sm:text-4xl">
          Resilience applications tailored to Canadian geographies
        </FadeInSection>
        <FadeInSection as="p" className="mt-4 text-lg text-slate-600">
          We adapt our analytics to the realities of each province and territory, ensuring renewable infrastructure remains dependable for communities and industries.
        </FadeInSection>

        <FadeInSection className="mt-10 grid gap-6 md:grid-cols-2">
          {applications.map((app) => (
            <div key={app.title} className="rounded-3xl border border-slate-200 bg-softcream/60 p-6 shadow-soft">
              <h3 className="font-outfit text-xl font-semibold text-primary">{app.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-slate-600">{app.detail}</p>
              <p className="mt-4 text-xs uppercase tracking-wide text-slate-500">Focus regions: {app.region}</p>
            </div>
          ))}
        </FadeInSection>

        <FadeInSection className="mt-12 rounded-3xl bg-primary/90 p-8 text-softcream shadow-2xl">
          <h2 className="font-outfit text-2xl font-semibold text-accentyellow">
            Collaboration approach
          </h2>
          <p className="mt-3 text-sm text-softcream/80">
            We engage early to align with permitting, grid interconnection timelines, and community consultation milestones. Our specialists remain accessible through implementation and monitoring, ensuring resilience strategies evolve with your assets.
          </p>
          <Link
            to="/contact"
            className="mt-6 inline-flex items-center rounded-full bg-softcream px-6 py-3 text-sm font-semibold text-primary shadow-lg transition hover:bg-softcream/90 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-softcream focus-visible:ring-offset-2 focus-visible:ring-offset-primary"
          >
            Discuss your application →
          </Link>
        </FadeInSection>
      </div>
    </div>
  );
};

export default Services;