import React, { useEffect } from 'react';
import FadeInSection from '../components/FadeInSection';

const TermsOfService = () => {
  useEffect(() => {
    const title = 'Terms of Service | Green Resilience Lab';
    document.title = title;

    const ensure = (attribute, name, content) => {
      if (!content) return;
      let tag = document.head.querySelector(`meta[${attribute}=`${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute(attribute, name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };

    const description =
      'Terms of Service for Green Resilience Lab covering acceptable use, confidentiality, liability, and compliance with Canadian law.';
    ensure('name', 'description', description);
    ensure('property', 'og:title', title);
    ensure('property', 'og:description', description);
    ensure('property', 'og:url', 'https://www.greenresiliencelab.com/terms');
    ensure('name', 'twitter:title', title);
    ensure('name', 'twitter:description', description);
  }, []);

  return (
    <div className="bg-softcream py-16">
      <div className="mx-auto max-w-4xl rounded-3xl bg-white px-6 py-10 shadow-2xl sm:px-10">
        <FadeInSection as="h1" className="font-outfit text-3xl font-semibold text-primary sm:text-4xl">
          Terms of Service
        </FadeInSection>
        <FadeInSection as="p" className="mt-4 text-sm leading-relaxed text-slate-600">
          Effective date: January 1, 2024
        </FadeInSection>

        <FadeInSection className="mt-6 space-y-6 text-sm leading-relaxed text-slate-600">
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">1. Overview</h2>
            <p className="mt-2">
              Green Resilience Lab (&ldquo;we&rdquo;, &ldquo;our&rdquo;, &ldquo;us&rdquo;) provides engineering consulting and analytics services focused on renewable infrastructure resilience. By accessing our website or engaging our services, you agree to these Terms of Service. These terms comply with applicable laws and regulations of Canada, including provincial and territorial requirements relevant to our engagements.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">2. Acceptable use</h2>
            <p className="mt-2">
              You may use this site for lawful purposes related to evaluating or engaging our services. Unauthorised attempts to breach security, reverse engineer proprietary tools, or misuse information are strictly prohibited. We reserve the right to suspend access for activities that compromise system integrity or violate Canadian law.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">3. Confidentiality &amp; intellectual property</h2>
            <p className="mt-2">
              Information shared during consultations, assessments, and deliverables is treated as confidential. Intellectual property created by Green Resilience Lab—including methodologies, tools, and reports—remains our property unless explicitly transferred via written agreement. Clients receive usage rights for agreed project purposes.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">4. Data protection</h2>
            <p className="mt-2">
              We manage client data according to privacy laws such as the Personal Information Protection and Electronic Documents Act (PIPEDA) and relevant provincial legislation. Data is stored in Canadian data centres or locations agreed upon with clients. Additional details are found in our Privacy Policy.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">5. Third-party resources</h2>
            <p className="mt-2">
              Our site may reference external datasets, tools, or research. These links are provided for context. We are not responsible for content maintained by third parties and recommend reviewing their terms before use.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">6. Limitation of liability</h2>
            <p className="mt-2">
              To the extent permitted by Canadian law, Green Resilience Lab is not liable for indirect, incidental, or consequential damages arising from the use of this website or reliance on preliminary information. Formal consulting engagements are governed by project-specific agreements that detail scope, deliverables, and responsibilities.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">7. Governing law</h2>
            <p className="mt-2">
              These Terms are governed by the laws of the Province of British Columbia and the federal laws of Canada. Any disputes will be resolved in the courts located in Vancouver, British Columbia, unless otherwise agreed in a written contract.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">8. Updates</h2>
            <p className="mt-2">
              We may update these Terms to reflect regulatory changes or operational adjustments. The effective date above will change when updates occur. Continued use of the site constitutes acceptance of revised terms.
            </p>
          </section>
          <section>
            <h2 className="font-outfit text-xl font-semibold text-primary">9. Contact</h2>
            <p className="mt-2">
              Questions about these Terms can be directed to{' '}
              <a href="mailto:info@greenresiliencelab.com" className="text-accentblue hover:underline">
                info@greenresiliencelab.com
              </a>{' '}
              or by mail at The Stack – Vancouver, 1133 Melville Street, Floor 18, Vancouver, British Columbia, Canada.
            </p>
          </section>
        </FadeInSection>
      </div>
    </div>
  );
};

export default TermsOfService;