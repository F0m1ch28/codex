import React, { useEffect } from 'react';
import FadeInSection from '../components/FadeInSection';

const usePageMeta = ({ title, description, url }) => {
  useEffect(() => {
    const fullTitle = title ? `${title} | Green Resilience Lab` : 'Green Resilience Lab';
    document.title = fullTitle;

    const ensure = (attribute, name, content) => {
      if (!content) return;
      let tag = document.head.querySelector(`meta[${attribute}=`${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute(attribute, name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };

    ensure('name', 'description', description);
    ensure('property', 'og:title', fullTitle);
    ensure('property', 'og:description', description);
    ensure('property', 'og:url', url);
    ensure('name', 'twitter:title', fullTitle);
    ensure('name', 'twitter:description', description);
  }, [title, description, url]);
};

const About = () => {
  usePageMeta({
    title: 'Company Overview & Methodology',
    description:
      'Green Resilience Lab is a Canadian engineering consultancy delivering climate-informed risk, resilience, and reliability analysis for renewable infrastructure.',
    url: 'https://www.greenresiliencelab.com/company',
  });

  const pillars = [
    {
      title: 'Interdisciplinary engineering expertise',
      description:
        'We unite mechanical, electrical, civil, environmental, and systems engineers into dedicated asset squads capable of diagnosing complex renewable operations under Canadian climate stress.',
    },
    {
      title: 'Climate-forward analytics',
      description:
        'Downscaled regional climate models, satellite datasets, and remote sensing feed our risk libraries for wind, solar, storage, and hybrid systems from coast to coast to Arctic.',
    },
    {
      title: 'Operationally pragmatic delivery',
      description:
        'We embed with asset managers, Indigenous partners, and field teams to ensure mitigation plans are logistically viable, culturally respectful, and timed with seasonal access windows.',
    },
  ];

  return (
    <div className="bg-softcream pb-20 pt-16">
      <div className="mx-auto max-w-5xl px-4 text-center sm:px-6 lg:px-8">
        <FadeInSection delay={0.1} as="div">
          <span className="tagline">About Green Resilience Lab</span>
        </FadeInSection>
        <FadeInSection delay={0.2} as="h1" className="font-outfit text-3xl font-semibold text-primary sm:text-4xl">
          Engineering consulting for renewable resilience rooted in Canadian realities
        </FadeInSection>
        <FadeInSection delay={0.3} as="p" className="mx-auto mt-4 max-w-3xl text-lg text-slate-600">
          Headquartered in Vancouver, we analyse infrastructure that spans every Canadian climate zone. Our team translates high-resolution climate intelligence into actionable engineering strategies—supporting developers, utilities, Indigenous communities, and public agencies committed to reliable clean power.
        </FadeInSection>
      </div>

      <FadeInSection delay={0.2} className="mx-auto mt-16 max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-6 md:grid-cols-3">
          {pillars.map((pillar) => (
            <div key={pillar.title} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
              <h3 className="font-outfit text-xl font-semibold text-primary">{pillar.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-slate-600">{pillar.description}</p>
            </div>
          ))}
        </div>
      </FadeInSection>

      <FadeInSection delay={0.3} className="mx-auto mt-16 max-w-6xl rounded-3xl bg-white px-4 py-12 shadow-2xl sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
          <div>
            <h2 className="font-outfit text-2xl font-semibold text-primary">
              Analytical methodology
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-slate-600">
              Our methodology blends rigorous quantitative modelling with qualitative insights from operators who understand day-to-day realities. Each engagement follows a transparent sequence:
            </p>
            <ol className="mt-6 space-y-4 text-sm text-slate-600">
              <li>
                <strong className="text-primary">Discovery &amp; scoping:</strong> Aligning on asset inventory, geographies, data quality, Indigenous partnership frameworks, and performance priorities.
              </li>
              <li>
                <strong className="text-primary">Data &amp; model integration:</strong> Curating climate projections, weather station records, SCADA logs, inspection findings, and grid interconnection data.
              </li>
              <li>
                <strong className="text-primary">Risk diagnostics:</strong> Building vulnerability matrices, resilience KPIs, and scenario stress tests referencing IEC, CSA, ISO 55000, and Canadian Electrical Code.
              </li>
              <li>
                <strong className="text-primary">Mitigation roadmap:</strong> Delivering engineered solutions, timeline planning, and change management toolkits that embed resilience into operations.
              </li>
            </ol>
          </div>
          <div>
            <h2 className="font-outfit text-2xl font-semibold text-primary">
              Commitment to sustainable development
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-slate-600">
              Sustainability extends beyond emissions reduction. We account for biodiversity, land stewardship, and social impact. Our projects align with the United Nations Sustainable Development Goals, the Pan-Canadian Framework on Clean Growth and Climate Change, and provincial environmental regulations. We actively collaborate with Indigenous Nations to honour treaty relationships, integrate traditional knowledge, and maintain energy sovereignty.
            </p>
            <div className="mt-6 rounded-2xl bg-softcream p-6 text-sm text-slate-600">
              <h3 className="font-outfit text-lg font-semibold text-primary">Compliance &amp; quality assurance</h3>
              <ul className="mt-4 space-y-2 list-disc pl-5">
                <li>Professional Engineers of British Columbia &amp; Ontario licensed team leads.</li>
                <li>ISO 14001-aligned environmental management practices.</li>
                <li>Data governance following ISO/IEC 27001 principles with Canadian data residency.</li>
                <li>Safety management aligned to COR certification frameworks.</li>
              </ul>
            </div>
          </div>
        </div>
      </FadeInSection>

      <FadeInSection delay={0.4} className="mx-auto mt-16 max-w-5xl px-4 text-center sm:px-6 lg:px-8">
        <h2 className="font-outfit text-2xl font-semibold text-primary">
          Partnering across the renewable ecosystem
        </h2>
        <p className="mt-4 text-sm leading-relaxed text-slate-600">
          We work alongside developers scaling large wind installations, Indigenous-owned microgrids balancing solar, wind, and storage, and public agencies regulating interconnections. Our approach emphasizes transparent communication, knowledge transfer, and capability building—ensuring our clients own the resilience journey long after our engagement.
        </p>
      </FadeInSection>
    </div>
  );
};

export default About;