document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('.nav-toggle');
    var primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', function () {
            var isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !isExpanded);
            primaryNav.classList.toggle('open');
        });
    }

    var cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        var storedConsent = localStorage.getItem('arsCookieConsent');
        if (!storedConsent) {
            cookieBanner.classList.add('active');
        }

        var acceptButton = document.getElementById('cookie-accept');
        var declineButton = document.getElementById('cookie-decline');

        if (acceptButton) {
            acceptButton.addEventListener('click', function () {
                localStorage.setItem('arsCookieConsent', 'accepted');
                cookieBanner.classList.remove('active');
            });
        }

        if (declineButton) {
            declineButton.addEventListener('click', function () {
                localStorage.setItem('arsCookieConsent', 'declined');
                cookieBanner.classList.remove('active');
            });
        }
    }

    var layerButtons = document.querySelectorAll('[data-layer]');
    var layerTitle = document.getElementById('layer-title');
    var layerDescription = document.getElementById('layer-description');
    var layerList = document.getElementById('layer-list');

    var layerData = {
        generation: {
            title: 'Generation Assets',
            description: 'Generation resources across Atlantic Canada span hydropower facilities, onshore and offshore wind, biomass, and natural gas plants. The network balances heritage assets such as Churchill Falls imports, NB Power hydro, and Nova Scotia tidal pilots with rapidly scaling renewable projects. Operational practices emphasise flexible dispatch, fuel diversity, and seasonal balancing to meet demand while supporting decarbonisation objectives.',
            items: [
                'Hydroelectric complexes in Labrador and New Brunswick delivering baseload supply through 8,500+ MW of capacity.',
                'Wind generation corridors in Prince Edward Island and coastal Nova Scotia paired with battery storage pilots.',
                'Biomass and combined heat and power assets within industrial clusters, optimised for reliability in winter peaks.',
                'Emerging tidal stream demonstrations in the Bay of Fundy integrating with hybrid microgrids for adjacent communities.'
            ]
        },
        transmission: {
            title: 'Transmission Backbone',
            description: 'Transmission backbones tie together provincial grids through high-voltage corridors, subsea cables, and advanced monitoring. Atlantic Regional Systems curates data on conductor ratings, tower hardening, and dynamic line rating pilots to deliver situational awareness during seasonal storms and high load periods.',
            items: [
                '750 kV and 345 kV corridors reinforcing Labrador-Quebec routes and cross-border exports into New England balancing markets.',
                'Subsea links such as the Maritime Link delivering 500 MW from Labrador to Nova Scotia with synchronous condensers for stability.',
                'Grid modernisation projects deploying phasor measurement units and synchrophasor analytics across 120+ substations.',
                'Vegetation management and storm hardening initiatives applying LiDAR data to prioritise pole replacements and guying upgrades.'
            ]
        },
        interties: {
            title: 'Interties and Exchanges',
            description: 'Interconnections facilitate balanced exchanges of energy across provincial and international borders. Atlantic Regional Systems monitors scheduling practices, emergency support protocols, and congestion management tools that keep power flowing during contingencies.',
            items: [
                'New Brunswick–Maine interties enabling 700+ MW of cross-border transfers supporting ISO-NE reserve requirements.',
                'Nova Scotia–New Brunswick links providing bidirectional capability for wind balancing and contingency support.',
                'Prince Edward Island submarine cables modernised with fibre-optic monitoring to anticipate marine environment impacts.',
                'Seasonal scheduling agreements with Hydro-Québec, ISO-NE, and New York ISO ensuring equitable capacity sharing.'
            ]
        }
    };

    if (layerButtons && layerButtons.length > 0 && layerTitle && layerDescription && layerList) {
        layerButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                layerButtons.forEach(function (btn) { btn.classList.remove('active'); });
                button.classList.add('active');
                var layerKey = button.getAttribute('data-layer');
                var content = layerData[layerKey];

                if (content) {
                    layerTitle.textContent = content.title;
                    layerDescription.textContent = content.description;
                    layerList.innerHTML = '';
                    content.items.forEach(function (item) {
                        var li = document.createElement('li');
                        li.textContent = item;
                        layerList.appendChild(li);
                    });
                }
            });
        });
    }

    var timelineButtons = document.querySelectorAll('[data-timeline]');
    var timelineYear = document.getElementById('timeline-year');
    var timelineDescription = document.getElementById('timeline-description');
    var timelineNote = document.getElementById('timeline-note');

    var timelineDataset = {
        '1990s': {
            year: '1990s: Foundation of Regional Coordination',
            description: 'The 1990s established the essential coordination protocols among Atlantic provinces. Engineers harmonised load forecasting methodologies, while system operators developed seasonal marine weather playbooks. Investments focused on reinforcing 230 kV and 345 kV corridors, and early digital SCADA upgrades improved situational awareness. The region also began exploring tidal feasibility studies in the Bay of Fundy, laying groundwork for today’s marine renewable pilots.',
            note: 'Milestone: Formalised mutual assistance protocols and shared maintenance procedures for interties during winter storm events.'
        },
        '2000s': {
            year: '2000s: Integration of Renewables and Market Access',
            description: 'The early 2000s saw accelerated wind development in Prince Edward Island, Cape Breton, and northern New Brunswick. Atlantic operators defined curtailment procedures and introduced demand response pilots in industrial facilities. Harmonisation with Northeast power markets expanded, enabling new export pathways. Energy literacy programs across Atlantic Canada emphasised storm preparedness and customer participation in conservation efforts.',
            note: 'Milestone: Commissioning of the first 100 MW class wind clusters tied to improved forecasting models shared among provinces.'
        },
        '2010s': {
            year: '2010s: Subsea Expansion and Digital Visibility',
            description: 'Deployment of the Maritime Link in 2017 transformed the region’s supply portfolio by importing hydroelectricity from Labrador. Projects across Nova Scotia and New Brunswick embraced voltage control technologies and dynamic line rating pilots. Utilities introduced advanced metering infrastructure, allowing more granular outage analytics. Regional academic partnerships delivered workforce training for coastal climate adaptation and smart grid operations.',
            note: 'Milestone: Launch of shared data hubs integrating phasor measurement units, enabling real-time regional situational awareness.'
        },
        '2020s': {
            year: '2020s: Resilience, Electrification, and Net-Zero Pathways',
            description: 'The current decade prioritises storm resilience, widespread electrification, and achieving mid-century net-zero goals. Atlantic Regional Systems maps microgrid testing in coastal communities, hydrogen-ready power plant conversions, and large-scale battery storage deployments. Data-driven asset management ensures wooden poles, substations, and submarine cables are hardened against more frequent severe weather. Collaborative planning now integrates Indigenous leadership and community energy ownership models.',
            note: 'Milestone: Regional resilience blueprints outlining adaptive infrastructure corridors and climate-informed investment sequencing.'
        },
        '2030s': {
            year: '2030s Outlook: Integrated Atlantic Energy Hub',
            description: 'Forward-looking scenarios highlight electrified transportation corridors, marine-based renewable hubs, and interoperable data platforms that link electricity with heating and mobility. By coordinating investments in transmission backbones, Atlantic Canada positions itself as a net exporter of clean energy while maintaining reliable service for rural and islanded communities. Emerging technologies like grid-forming inverters and green hydrogen storage promise new flexibility layers.',
            note: 'Milestone: Envisioned commissioning of multi-gigawatt offshore wind zones with shared transmission collecting systems.'
        }
    };

    if (timelineButtons && timelineButtons.length > 0 && timelineYear && timelineDescription && timelineNote) {
        timelineButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                timelineButtons.forEach(function (btn) { btn.classList.remove('active'); });
                button.classList.add('active');
                var key = button.getAttribute('data-timeline');
                var payload = timelineDataset[key];
                if (payload) {
                    timelineYear.textContent = payload.year;
                    timelineDescription.textContent = payload.description;
                    timelineNote.textContent = payload.note;
                }
            });
        });
    }

    var systemsLayerButtons = document.querySelectorAll('[data-system-layer]');
    var systemsLayerCards = document.querySelectorAll('.system-layer-card');

    if (systemsLayerButtons && systemsLayerButtons.length > 0 && systemsLayerCards && systemsLayerCards.length > 0) {
        systemsLayerButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                var target = button.getAttribute('data-system-layer');
                systemsLayerButtons.forEach(function (btn) { btn.classList.remove('active'); });
                systemsLayerCards.forEach(function (card) {
                    if (card.getAttribute('data-system-layer') === target || target === 'all') {
                        card.classList.remove('hidden');
                    } else {
                        card.classList.add('hidden');
                    }
                });
                button.classList.add('active');
            });
        });
    }
});