document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const mainNav = document.querySelector(".main-nav");

    if (navToggle && mainNav) {
        navToggle.addEventListener("click", () => {
            const isOpen = mainNav.classList.toggle("is-open");
            navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
        });

        mainNav.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                if (mainNav.classList.contains("is-open")) {
                    mainNav.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookieBanner");
    const acceptCookies = document.getElementById("acceptCookies");
    const declineCookies = document.getElementById("declineCookies");
    const cookieKey = "greentechCookieConsent";

    if (cookieBanner && acceptCookies && declineCookies) {
        const storedConsent = localStorage.getItem(cookieKey);
        if (storedConsent) {
            cookieBanner.classList.add("is-hidden");
        }

        acceptCookies.addEventListener("click", () => {
            localStorage.setItem(cookieKey, "accepted");
            cookieBanner.classList.add("is-hidden");
        });

        declineCookies.addEventListener("click", () => {
            localStorage.setItem(cookieKey, "declined");
            cookieBanner.classList.add("is-hidden");
        });
    }

    const energyForm = document.getElementById("energyForm");
    const annualSavingsEl = document.getElementById("annualSavings");
    const paybackEl = document.getElementById("paybackPeriod");
    const impactEl = document.getElementById("impactRating");

    if (energyForm) {
        energyForm.addEventListener("submit", (event) => {
            event.preventDefault();

            const consumption = parseFloat(energyForm.querySelector("#consumption").value) || 0;
            const price = parseFloat(energyForm.querySelector("#price").value) || 0;
            const solarShare = parseFloat(energyForm.querySelector("#solarShare").value) || 0;
            const investment = parseFloat(energyForm.querySelector("#investment").value) || 0;
            const subsidy = parseFloat(energyForm.querySelector("#subsidy").value) || 0;

            const currentCost = consumption * price;
            const solarCoverage = (consumption * solarShare) / 100;
            const solarGeneration = solarCoverage * 0.92;
            const savingsPerKwh = price * 0.82;
            const annualSavings = solarGeneration * savingsPerKwh;

            const effectiveInvestment = Math.max(investment - subsidy, 0);
            const paybackPeriod = annualSavings > 0 ? effectiveInvestment / annualSavings : 0;
            const impactScore = Math.min(Math.round((solarShare + (annualSavings / (currentCost || 1)) * 100) / 2), 100);

            if (annualSavingsEl) {
                annualSavingsEl.textContent = `${annualSavings.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €`;
            }

            if (paybackEl) {
                if (paybackPeriod > 0 && isFinite(paybackPeriod)) {
                    paybackEl.textContent = `${paybackPeriod.toLocaleString("de-DE", { minimumFractionDigits: 1, maximumFractionDigits: 1 })} Jahre`;
                } else {
                    paybackEl.textContent = "Nicht berechenbar";
                }
            }

            if (impactEl) {
                let rating = "Moderate Wirkung";
                if (impactScore > 75) {
                    rating = "Hervorragende Wirkung";
                } else if (impactScore < 40) {
                    rating = "Optimierung empfohlen";
                }
                impactEl.textContent = `${rating} (${impactScore} / 100)`;
            }
        });
    }

    const contactForm = document.getElementById("contactForm");
    const contactFeedback = document.getElementById("contactFeedback");

    if (contactForm) {
        contactForm.addEventListener("submit", (event) => {
            const message = contactForm.querySelector("#message").value.trim();
            const privacy = contactForm.querySelector("#privacy");

            if (message.length < 20) {
                event.preventDefault();
                if (contactFeedback) {
                    contactFeedback.textContent = "Bitte geben Sie eine Nachricht mit mindestens 20 Zeichen ein.";
                }
                return;
            }

            if (!privacy.checked) {
                event.preventDefault();
                if (contactFeedback) {
                    contactFeedback.textContent = "Bitte stimmen Sie der Datenschutzerklärung zu.";
                }
                return;
            }

            if (contactFeedback) {
                contactFeedback.textContent = "";
            }
        });
    }
});