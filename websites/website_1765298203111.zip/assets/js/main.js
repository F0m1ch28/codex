document.addEventListener('DOMContentLoaded', () => {
  const header = document.querySelector('[data-header]');
  const cookieBanner = document.querySelector('.cookie-banner');
  const storedConsent = localStorage.getItem('fec-cookie-consent');

  if (header) {
    const onScroll = () => {
      if (window.scrollY > 30) {
        header.setAttribute('data-scrolled', 'true');
      } else {
        header.removeAttribute('data-scrolled');
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  if (cookieBanner) {
    if (!storedConsent) {
      cookieBanner.setAttribute('data-visible', 'true');
    }

    cookieBanner.addEventListener('click', (event) => {
      const button = event.target.closest('[data-cookie-action]');
      if (!button) return;

      const action = button.getAttribute('data-cookie-action');
      localStorage.setItem('fec-cookie-consent', action);
      cookieBanner.setAttribute('data-visible', 'false');
    });
  }
});