document.addEventListener('DOMContentLoaded', function () {
  const banner = document.getElementById('cookieBanner');
  const acceptBtn = document.getElementById('cookieAccept');
  const declineBtn = document.getElementById('cookieDecline');
  const storageKey = 'cookieConsentState';

  function hideBanner() {
    if (banner) {
      banner.classList.remove('active');
    }
  }

  function showBanner() {
    if (banner) {
      banner.classList.add('active');
    }
  }

  const consentState = localStorage.getItem(storageKey);
  if (!consentState) {
    showBanner();
  }

  if (acceptBtn) {
    acceptBtn.addEventListener('click', function () {
      localStorage.setItem(storageKey, 'accepted');
      hideBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', function () {
      localStorage.setItem(storageKey, 'declined');
      hideBanner();
    });
  }

  const gameRoot = document.getElementById('gameRoot');
  if (gameRoot) {
    const startButton = document.getElementById('startGame');
    const nextButton = document.getElementById('nextQuestion');
    const restartButton = document.getElementById('restartGame');
    const questionElement = document.getElementById('gameQuestion');
    const scenarioElement = document.getElementById('gameScenario');
    const optionsContainer = document.getElementById('gameOptions');
    const feedbackElement = document.getElementById('gameFeedback');
    const levelIndicator = document.getElementById('gameLevel');
    const accuracyIndicator = document.getElementById('gameAccuracy');
    const meterBar = document.getElementById('gameMeter');
    const summaryBlock = document.getElementById('gameSummary');
    const summaryText = document.getElementById('gameSummaryText');
    const summaryAccuracy = document.getElementById('summaryAccuracy');
    const summaryScore = document.getElementById('summaryScore');
    const summarySpeed = document.getElementById('summarySpeed');

    const questions = [
      {
        title: 'Рекомендации в Яндекс.Музыке',
        scenario: 'Пользователь слушал инди-рок и электронную музыку. Какой трек стоит предложить в первую очередь?',
        options: [
          { text: 'Новинка в стиле инди-электро с похожими исполнителями', correct: true },
          { text: 'Популярный поп-хит из чарта', correct: false },
          { text: 'Классику джаза для контраста', correct: false }
        ]
      },
      {
        title: 'Построение маршрута в Навигаторе',
        scenario: 'Маршрут построен в час пик. Пользователь торопится, но избегает платных дорог.',
        options: [
          { text: 'Маршрут через платный участок для сокращения времени', correct: false },
          { text: 'Маршрут с учётом пробок и альтернативных дворовых проездов', correct: true },
          { text: 'Маршрут по самой короткой дистанции без учёта пробок', correct: false }
        ]
      },
      {
        title: 'Выбор ответа в Яндекс.Кью',
        scenario: 'Вопрос: «Как выбрать ноутбук для дизайнера?»',
        options: [
          { text: 'Ответ со ссылкой на конкретный магазин', correct: false },
          { text: 'Развернутый ответ с рекомендациями по параметрам и сравнениями', correct: true },
          { text: 'Шутливый комментарий без полезной информации', correct: false }
        ]
      },
      {
        title: 'Обработка писем в Яндекс.Почте',
        scenario: 'Нужно распределить письма по умным папкам.',
        options: [
          { text: 'Поместить рекламную рассылку в папку «Промоакции»', correct: true },
          { text: 'Оставить все письма во «Входящих» без сортировки', correct: false },
          { text: 'Удалить все письма от незнакомых отправителей', correct: false }
        ]
      },
      {
        title: 'Работа рекомендаций в Дзене',
        scenario: 'Пользователь смотрит видео про дизайн и обучение.',
        options: [
          { text: 'Показать подборку новостей о политике', correct: false },
          { text: 'Показать материалы по дизайну и образовательные курсы', correct: true },
          { text: 'Показать случайные ролики без анализа интересов', correct: false }
        ]
      }
    ];

    let currentIndex = 0;
    let score = 0;
    let correctAnswers = 0;
    let reactionTimes = [];
    let roundActive = false;
    let questionStartTime = null;

    function updateStatus() {
      const total = questions.length;
      levelIndicator.textContent = `Раунд ${currentIndex + 1}/${total}`;
      const accuracy = total ? Math.round((correctAnswers / total) * 100) : 0;
      accuracyIndicator.textContent = `Точность: ${accuracy}%`;
      const meterValue = ((currentIndex) / total) * 100;
      meterBar.style.width = `${meterValue}%`;
    }

    function resetOptionsState() {
      while (optionsContainer.firstChild) {
        optionsContainer.removeChild(optionsContainer.firstChild);
      }
      feedbackElement.textContent = '';
    }

    function renderQuestion() {
      const currentQuestion = questions[currentIndex];
      questionElement.textContent = currentQuestion.title;
      scenarioElement.textContent = currentQuestion.scenario;
      resetOptionsState();
      currentQuestion.options.forEach((option, idx) => {
        const button = document.createElement('button');
        button.className = 'quiz-option';
        button.type = 'button';
        button.textContent = option.text;
        button.dataset.correct = option.correct ? 'true' : 'false';
        button.dataset.index = idx.toString();
        button.addEventListener('click', handleOptionClick);
        optionsContainer.appendChild(button);
      });
      questionStartTime = performance.now();
    }

    function handleOptionClick(event) {
      const target = event.currentTarget;
      const isCorrect = target.dataset.correct === 'true';
      const buttons = optionsContainer.querySelectorAll('.quiz-option');
      buttons.forEach((btn) => {
        btn.disabled = true;
        const correct = btn.dataset.correct === 'true';
        if (correct) {
          btn.classList.add('correct');
        } else if (btn !== target) {
          btn.classList.add('incorrect');
        }
      });

      const reactionTime = performance.now() - questionStartTime;
      reactionTimes.push(reactionTime);

      if (isCorrect) {
        score += 100;
        correctAnswers += 1;
        feedbackElement.textContent = 'Верно! Ваш выбор совпал с эталонным сценарием.';
        target.classList.add('correct');
      } else {
        score = Math.max(0, score - 10);
        feedbackElement.textContent = 'Не совсем. Попробуйте следующий вопрос — анализ поможет улучшить результат.';
        target.classList.add('incorrect');
      }

      nextButton.disabled = false;
    }

    function finishGame() {
      roundActive = false;
      summaryBlock.hidden = false;
      const totalQuestions = questions.length;
      const accuracy = totalQuestions ? Math.round((correctAnswers / totalQuestions) * 100) : 0;
      const avgReaction = reactionTimes.length
        ? Math.round(reactionTimes.reduce((sum, time) => sum + time, 0) / reactionTimes.length)
        : 0;
      summaryText.textContent = `Вы завершили сценарий с точностью ${accuracy}% и заработали ${score} очков.`;
      summaryAccuracy.textContent = `${accuracy}%`;
      summaryScore.textContent = score.toString();
      summarySpeed.textContent = `${(avgReaction / 1000).toFixed(1)} сек`;
      meterBar.style.width = '100%';
      levelIndicator.textContent = `Раунд ${totalQuestions}/${totalQuestions}`;
      accuracyIndicator.textContent = `Точность: ${accuracy}%`;
      startButton.disabled = false;
      nextButton.disabled = true;
    }

    function nextQuestion() {
      currentIndex += 1;
      if (currentIndex >= questions.length) {
        finishGame();
      } else {
        nextButton.disabled = true;
        updateStatus();
        renderQuestion();
      }
    }

    function startGame() {
      roundActive = true;
      currentIndex = 0;
      score = 0;
      correctAnswers = 0;
      reactionTimes = [];
      summaryBlock.hidden = true;
      startButton.disabled = true;
      nextButton.disabled = true;
      updateStatus();
      renderQuestion();
    }

    function restartGame() {
      startButton.disabled = true;
      nextButton.disabled = true;
      currentIndex = 0;
      score = 0;
      correctAnswers = 0;
      reactionTimes = [];
      summaryBlock.hidden = true;
      updateStatus();
      renderQuestion();
    }

    if (startButton) {
      startButton.addEventListener('click', function () {
        if (!roundActive) {
          startGame();
        }
      });
    }

    if (nextButton) {
      nextButton.addEventListener('click', function () {
        if (!roundActive) {
          roundActive = true;
        }
        nextQuestion();
      });
    }

    if (restartButton) {
      restartButton.addEventListener('click', function () {
        restartGame();
      });
    }

    updateStatus();
  }
});