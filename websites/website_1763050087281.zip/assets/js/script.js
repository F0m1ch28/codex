document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.main-navigation');
    const navLinks = document.querySelectorAll('.nav-links a');
    const scrollButton = document.getElementById('scrollTop');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const isOpen = navigation.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navigation.classList.contains('open')) {
                navigation.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    });

    const handleScrollButton = () => {
        if (window.scrollY > 300) {
            scrollButton.style.display = 'inline-flex';
        } else {
            scrollButton.style.display = 'none';
        }
    };

    window.addEventListener('scroll', handleScrollButton);
    handleScrollButton();

    scrollButton.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    const COOKIE_KEY = 'delnariCookieConsent';

    if (cookieBanner && acceptCookiesBtn) {
        const consent = localStorage.getItem(COOKIE_KEY);

        if (!consent) {
            cookieBanner.style.display = 'block';
        }

        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem(COOKIE_KEY, 'true');
            cookieBanner.style.display = 'none';
        });
    }
});