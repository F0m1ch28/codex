'use strict';

document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('[data-nav-toggle]');
    const navMenu = document.querySelector('[data-nav-menu]');
    const cookieBanner = document.querySelector('[data-cookie-banner]');
    const acceptButton = document.querySelector('[data-cookie-accept]');
    const declineButton = document.querySelector('[data-cookie-decline]');
    const navLinks = document.querySelectorAll('[data-nav-menu] a');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('active');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768 && navMenu.classList.contains('active')) {
                    navMenu.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (cookieBanner && acceptButton && declineButton) {
        const consentStatus = localStorage.getItem('kaliurcvvk-cookie-consent');
        if (!consentStatus) {
            requestAnimationFrame(() => {
                cookieBanner.classList.add('visible');
            });
        }

        acceptButton.addEventListener('click', () => {
            localStorage.setItem('kaliurcvvk-cookie-consent', 'accepted');
            cookieBanner.classList.remove('visible');
        });

        declineButton.addEventListener('click', () => {
            localStorage.setItem('kaliurcvvk-cookie-consent', 'declined');
            cookieBanner.classList.remove('visible');
        });
    }
});