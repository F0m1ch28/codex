document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".main-nav");
    const scrollTopBtn = document.querySelector(".scroll-top");
    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptCookiesBtn = document.getElementById("accept-cookies");
    const yearSpan = document.getElementById("current-year");
    const contactForm = document.getElementById("contact-form");

    if (navToggle) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            nav.classList.toggle("open");
        });

        document.addEventListener("click", (event) => {
            if (!nav.contains(event.target) && !navToggle.contains(event.target)) {
                nav.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            }
        });
    }

    if (scrollTopBtn) {
        const toggleScrollBtn = () => {
            if (window.scrollY > 300) {
                scrollTopBtn.classList.add("visible");
            } else {
                scrollTopBtn.classList.remove("visible");
            }
        };

        toggleScrollBtn();
        window.addEventListener("scroll", toggleScrollBtn);

        scrollTopBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    if (cookieBanner && acceptCookiesBtn) {
        const consent = localStorage.getItem("cna-cookie-consent");
        if (consent === "accepted") {
            cookieBanner.classList.add("hidden");
        }

        acceptCookiesBtn.addEventListener("click", () => {
            localStorage.setItem("cna-cookie-consent", "accepted");
            cookieBanner.classList.add("hidden");
        });
    }

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (contactForm) {
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const response = contactForm.querySelector(".form-response");
            response.textContent = "Thank you for reaching out. Our team will contact you within one business day.";
            contactForm.reset();
        });
    }

    document.querySelectorAll(".main-nav a").forEach(link => {
        link.addEventListener("click", () => {
            window.scrollTo({ top: 0 });
        });
    });
});