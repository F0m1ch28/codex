const I18N = {
  fr: {
    meta: {
      title: {
        home: "danswholesaleplants — Orientation spatiale et signalétique numérique",
        services: "Analyses et études | danswholesaleplants",
        about: "Approche et équipe éditoriale | danswholesaleplants",
        blog: "Chroniques techniques | danswholesaleplants",
        contact: "Coordonnées et formulaire | danswholesaleplants",
        faq: "Questions fréquentes sur la navigation intérieure",
        terms: "Conditions d’utilisation | danswholesaleplants",
        privacy: "Politique de confidentialité | danswholesaleplants",
        cookies: "Politique relative aux cookies | danswholesaleplants",
        refund: "Politique de rectification de contenu | danswholesaleplants",
        disclaimer: "Avis de non-responsabilité | danswholesaleplants",
        thankyou: "Merci pour votre message | danswholesaleplants",
        post1: "Itinéraires adaptatifs dans les gares métropolitaines",
        post2: "Cartographie des campus universitaires étendus",
        post3: "Signalétique inclusive pour infrastructures publiques",
        post4: "Flux piétons dans les centres de congrès complexes",
        post5: "Veille technologique sur les plans interactifs immersifs"
      },
      description: {
        home: "Ressource belge sur l’orientation spatiale et la signalétique numérique, dédiée aux environnements complexes et aux parcours utilisateurs dans les bâtiments publics.",
        services: "Études, analyses et évaluations sur la navigation intérieure, la mobilité piétonne et la lisibilité des infrastructures publiques.",
        about: "Présentation de la ligne éditoriale, de la méthodologie de recherche et des collaborations de danswholesaleplants, plateforme dédiée à l’UX spatiale.",
        blog: "Articles techniques sur la cartographie des espaces, le guidage visuel et les plans interactifs pour environnements bâtis complexes.",
        contact: "Contactez danswholesaleplants, consultez la carte de Bruxelles et utilisez le formulaire pour partager vos questions sur la signalétique numérique.",
        faq: "Réponses aux questions fréquentes concernant l’orientation spatiale, la cartographie numérique et l’accessibilité des parcours.",
        terms: "Conditions d’utilisation décrivant les règles d’accès, les limites de responsabilité et les modalités de mise à jour de danswholesaleplants.",
        privacy: "Politique de confidentialité détaillant les traitements de données, leur conservation et les droits des utilisateurs.",
        cookies: "Informations sur l’usage des cookies, leurs finalités et les possibilités de gestion des préférences sur danswholesaleplants.",
        refund: "Politique de rectification décrivant la procédure de correction de contenu inexact ou obsolète.",
        disclaimer: "Avis de non-responsabilité concernant l’exactitude des informations publiées et l’absence de garantie.",
        thankyou: "Confirmation de réception de votre message par danswholesaleplants.",
        post1: "Analyse approfondie des itinéraires adaptatifs dans les gares métropolitaines et de leurs implications pour la mobilité piétonne.",
        post2: "Cartographie stratégique des campus universitaires étendus et scénarios de navigation multimodale.",
        post3: "Principes de signalétique inclusive pour infrastructures publiques et protocoles d’évaluation.",
        post4: "Gestion des flux piétons dans les centres de congrès à géométrie variable et scénographies directionnelles.",
        post5: "Tour d’horizon des plans interactifs immersifs et impacts sur l’expérience de navigation intérieure."
      }
    },
    header: {
      brand: "danswholesaleplants",
      menu: "Menu",
      nav: {
        home: "Accueil",
        services: "Analyses",
        about: "À propos",
        blog: "Chroniques",
        faq: "FAQ",
        contact: "Contact"
      }
    },
    language: {
      switchLabel: "Changer de langue",
      fr: "FR",
      en: "EN"
    },
    footer: {
      address: "Rue de la Loi 200, 1040 Bruxelles",
      phoneLabel: "Téléphone : +32 2 808 65 40",
      emailLabel: "Courriel : info@danswholesaleplants.com",
      rights: "© {year} danswholesaleplants. Ressource dédiée à l’orientation spatiale.",
      links: {
        terms: "Conditions",
        privacy: "Confidentialité",
        cookies: "Cookies",
        refund: "Rectification",
        disclaimer: "Avis"
      }
    },
    home: {
      hero: {
        badge: "Orientation spatiale",
        title: "Comprendre et éclairer la navigation dans les environnements bâtis complexes",
        subtitle: "danswholesaleplants documente les méthodes de signalétique numérique, de cartographie intérieure et d’UX spatiale afin d’accompagner la mobilité piétonne dans les bâtiments publics et les infrastructures urbaines.",
        note: "Explorations techniques, retours d’expérience et matrices d’analyse pour Bruxelles et au-delà.",
        button: "Consulter les analyses",
        buttonSecondary: "Découvrir la méthodologie",
        imageAlt: "Vue intérieure d’un hub public avec signalétique numérique et flux piétons"
      },
      insights: {
        title: "Trois axes pour repenser la lisibilité des lieux publics",
        subtitle: "Chaque axe est issu de terrains d’observation en Belgique et en Europe, et s’appuie sur des données qualitatives et quantitatives relatives aux déplacements.",
        axis1Title: "Cartographie multimodale",
        axis1Text: "Construction de diagrammes de circulation et de matrices d’orientation croisant flux piétons, correspondances intermodales et conditions lumineuses.",
        axis2Title: "Signalétique évolutive",
        axis2Text: "Décryptage des dispositifs numériques adaptatifs, scénarisation de contenus contextuels et calibrage des rythmes d’information.",
        axis3Title: "Accessibilité appliquée",
        axis3Text: "Analyse des contrastes visuels, des supports tactiles et des parcours à faible sollicitation pour une expérience partagée du lieu."
      },
      featured: {
        title: "Points d’attention techniques",
        card1Title: "Guidage contextuel",
        card1Text: "Comment orchestrer des scénarios de prise de décision rapide dans des hubs à géométrie variable.",
        card2Title: "Plans interactifs",
        card2Text: "Évaluation des couches d’information et des degrés de zoom pertinents pour les usagers.",
        card3Title: "Temporalités des flux",
        card3Text: "Observation des pics de fréquentation et ajustement des repères pour limiter la congestion.",
        card4Title: "Structures narratives",
        card4Text: "Mettre en récit la progression spatiale grâce à des repères mémorisables et situés."
      },
      stats: {
        title: "Indicateurs de veille",
        block1Value: "64",
        block1Label: "Sites publics audités depuis 2018",
        block2Value: "23",
        block2Label: "Protocoles de tests utilisateurs documentés",
        block3Value: "310",
        block3Label: "Points de mesure cartographiques géolocalisés",
        block4Value: "12",
        block4Label: "Méthodes de visualisation comparées"
      },
      recommendations: {
        title: "Recommandations éditoriales",
        subtitle: "Synthèses destinées aux responsables d’espaces complexes souhaitant structurer leur réflexion.",
        item1Title: "Hiérarchiser les repères dynamiques",
        item1Text: "Prioriser l’information essentielle avant d’introduire des couches d’orientation contextuelle afin d’éviter la surcharge cognitive.",
        item2Title: "Croiser données et observations terrain",
        item2Text: "Associer relevés qualitatifs, statistiques de flux et retours utilisateurs pour piloter les ajustements successifs.",
        item3Title: "Anticiper les évolutions programmatiques",
        item3Text: "Prendre en compte la modularité des lieux et prévoir des scénarios de reconfiguration pour la signalétique.",
        item4Title: "Maintenir une lisibilité universelle",
        item4Text: "Conserver des codes visuels partagés et garantir des contrastes suffisamment forts pour tous les publics."
      },
      testimonials: {
        title: "Témoignages croisés",
        subtitle: "Regards d’experts et de responsables d’équipements sur la valeur des analyses partagées.",
        quote1: "Les grilles d’observation publiées par danswholesaleplants nous ont permis de structurer un audit de terrain en deux semaines, avec une granularité rarement obtenue.",
        author1: "Mireille De Smet",
        role1: "Coordinatrice navigation, STIB — Bruxelles",
        quote2: "Le découpage des parcours en micro-séquences a ouvert des perspectives transversales pour nos projets de campus étendus.",
        author2: "Joel Thompson",
        role2: "Architecte adjoint, Leuven Knowledge District",
        quote3: "L’approche met enfin en regard accessibilité, usage réel et design informationnel, sans privilégier un angle au détriment des autres.",
        author3: "Anne-Catherine Laurent",
        role3: "Consultante en mobilité urbaine"
      },
      latest: {
        title: "Chroniques récentes",
        subtitle: "Études approfondies sur des configurations variées d’espaces publics.",
        post1: "Itinéraires adaptatifs dans les gares métropolitaines",
        post2: "Cartographie des campus universitaires étendus",
        post3: "Signalétique inclusive pour infrastructures publiques",
        viewAll: "Voir toutes les chroniques"
      }
    },
    services: {
      hero: {
        title: "Champs d’analyse et protocoles de recherche",
        intro: "danswholesaleplants explore les interactions entre architecture, information et mobilités piétonnes. Les services décrivent des cadres méthodologiques destinés aux praticiens, chercheurs et gestionnaires d’infrastructures publiques."
      },
      cards: {
        oneTitle: "Diagnostic d’orientation spatiale",
        oneText: "Identification des zones de friction, cartographie des décisions critiques et mesure de la lisibilité des parcours dans les bâtiments complexes.",
        twoTitle: "Étude des flux piétons",
        twoText: "Observation des trajectoires, segmentation des publics, analyse des vitesses de déplacement et des facteurs d’attrition.",
        threeTitle: "Dispositifs de guidage numérique",
        threeText: "Examen des kiosques, plans interactifs et systèmes de diffusion dynamique. Évaluation de la pertinence contextuelle et de la gouvernance éditoriale.",
        fourTitle: "Design informationnel et narration",
        fourText: "Structure des messages, hiérarchisation visuelle, calibrage typographique et harmonisation des repères multisupports.",
        fiveTitle: "Accessibilité et UX spatiale",
        fiveText: "Analyse des contrastes, de la signalétique tactile, des continuités de parcours et des dispositifs de médiation accompagnant publics spécifiques."
      },
      process: {
        title: "Cadre méthodologique",
        step1: "Immersion terrain",
        step1Text: "Repérages en situation réelle, relevés photographiques et collecte d’indices comportementaux sur plusieurs créneaux horaires.",
        step2: "Synthèse cartographique",
        step2Text: "Production de plans annotés, matrices de flux et schémas narratifs révélant les nœuds et les zones d’ombre.",
        step3: "Ateliers d’interprétation",
        step3Text: "Mise en perspective avec les parties prenantes, priorisation des interventions et scénarisation des itérations futures."
      },
      closing: "Chaque étude s’accompagne d’un volet de capitalisation documentaire assurant la pérennité des connaissances au sein des organisations publiques."
    },
    about: {
      hero: {
        title: "Une plateforme d’étude sur la lisibilité des environnements complexes",
        intro: "danswholesaleplants rassemble des expériences de terrain, des analyses de dispositifs numériques et des protocoles d’observation pour documenter la navigation intérieure."
      },
      mission: {
        title: "Ligne éditoriale",
        text: "Offrir une compréhension fine des interactions entre architecture, signalétique et usages. Les contenus s’appuient sur des enquêtes longitudinales menées dans des gares, hôpitaux, campus et centres civiques."
      },
      history: {
        title: "Origine du projet",
        text: "Né en 2017 à Bruxelles, le projet s’est structuré autour d’une veille sur les environnements intensifs en information. Les premiers dossiers portaient sur les transitions entre mobilité douce et transports collectifs."
      },
      method: {
        title: "Méthodologie",
        point1: "Observation in situ pour capter les micro-décisions et les incidences des contextes lumineux.",
        point2: "Ateliers d’interprétation avec les responsables d’équipement pour qualifier les angles morts.",
        point3: "Diffusion de synthèses opérationnelles assurant un langage commun entre concepteurs, gestionnaires et publics."
      },
      collaboration: {
        title: "Collaborations",
        text: "Partenariats ponctuels avec des urbanistes, designers d’information, sociologues des mobilités et associations de défense de l’accessibilité, dans le respect d’une approche non commerciale."
      },
      signature: "La plateforme demeure ouverte aux contributions académiques et aux retours d’expérience terrain."
    },
    blog: {
      hero: {
        title: "Chroniques techniques",
        intro: "Chaque article propose un décryptage approfondi de dispositifs de navigation et met en lumière des cadres d’analyse reproductibles."
      },
      post1Excerpt: "Analyse des séquences de décision dans trois gares métropolitaines, avec focus sur l’adaptabilité des repères numériques.",
      post2Excerpt: "Cartographie des campus étendus et méthodologie de superposition de couches pour les usagers multimodaux.",
      post3Excerpt: "Cadres de conception d’une signalétique inclusive intégrant perception visuelle et accessibilité cognitive.",
      post4Excerpt: "Lecture des flux dans un centre de congrès modulable et stratégies de pré-orientation.",
      post5Excerpt: "Panorama des plans interactifs immersifs et conditions d’une appropriation durable."
    },
    contact: {
      hero: {
        title: "Entrer en contact",
        intro: "Partagez vos questions ou retours d’expérience sur la cartographie des espaces et la signalétique numérique."
      },
      details: {
        title: "Coordonnées",
        addressLabel: "Adresse",
        phoneLabel: "Téléphone",
        emailLabel: "Courriel",
        availability: "Réponses sous 3 jours ouvrables."
      },
      form: {
        title: "Formulaire de contact",
        intro: "Les informations transmises servent uniquement à répondre à votre demande.",
        nameLabel: "Nom complet",
        namePlaceholder: "Votre nom",
        emailLabel: "Adresse courriel",
        emailPlaceholder: "nom@exemple.com",
        orgLabel: "Organisation (facultatif)",
        orgPlaceholder: "Structure ou collectivité",
        messageLabel: "Message",
        messagePlaceholder: "Décrivez votre projet ou votre question",
        submit: "Envoyer",
        reset: "Effacer",
        successToast: "Message en cours d’envoi… redirection vers l’accusé de réception.",
        errorToast: "Merci de vérifier les champs du formulaire avant l’envoi.",
        mapLabel: "Carte positionnée sur Bruxelles – Rue de la Loi 200"
      }
    },
    faq: {
      hero: {
        title: "Questions fréquentes",
        intro: "Clarifications sur la méthodologie, les sources et la diffusion des contenus."
      },
      items: [
        {
          q: "Comment sont sélectionnés les sites analysés ?",
          a: "Les sites sont retenus selon des critères de complexité spatiale, de fréquentation et d’évolution programmée. Une attention particulière est portée aux infrastructures publiques bruxelloises afin de documenter des cas représentatifs."
        },
        {
          q: "Quelles données sont utilisées pour les cartographies ?",
          a: "Les cartographies combinent relevés topographiques disponibles, données ouvertes, plans fournis par les gestionnaires et observations de terrain. Chaque jeu de données est qualifié pour vérifier sa fiabilité et son niveau de mise à jour."
        },
        {
          q: "Les analyses incluent-elles des tests utilisateurs ?",
          a: "Lorsque les conditions le permettent, des tests utilisateurs sont menés auprès de panels diversifiés, incluant des publics à besoins spécifiques. Les protocoles sont décrits dans les publications concernées."
        },
        {
          q: "Comment sont traitées les questions d’accessibilité ?",
          a: "Les articles abordent l’accessibilité visuelle, tactile et cognitive. Les recommandations s’appuient sur les référentiels européens et sur des retours d’expérience d’associations spécialisées."
        },
        {
          q: "Peut-on proposer un cas d’étude ?",
          a: "Oui, il est possible de suggérer des sites ou des problématiques. Les propositions sont étudiées selon leur pertinence méthodologique et la disponibilité des ressources nécessaires."
        }
      ]
    },
    terms: {
      intro: "Les présentes conditions encadrent l’accès et l’utilisation du site danswholesaleplants.com.",
      sections: [
        {
          title: "1. Objet",
          text: "Définir les modalités d’utilisation du site et préciser les responsabilités respectives entre l’éditeur et les visiteurs."
        },
        {
          title: "2. Acceptation",
          text: "Toute consultation ou utilisation implique l’acceptation pleine et entière des présentes conditions."
        },
        {
          title: "3. Public visé",
          text: "Le site s’adresse aux professionnels, chercheurs et gestionnaires d’équipements souhaitant approfondir la navigation intérieure."
        },
        {
          title: "4. Propriété intellectuelle",
          text: "Les contenus sont protégés par le droit d’auteur. Toute reproduction, même partielle, nécessite une autorisation expresse."
        },
        {
          title: "5. Exactitude des informations",
          text: "Les informations sont fournies à titre informatif. Malgré les efforts de vérification, des inexactitudes peuvent subsister."
        },
        {
          title: "6. Utilisation des contenus",
          text: "Les contenus peuvent être cités en respectant la référence complète et sans altération du sens."
        },
        {
          title: "7. Contributions externes",
          text: "Les contributions proposées sont examinées avant publication. L’éditeur se réserve le droit de refuser toute contribution."
        },
        {
          title: "8. Liens sortants",
          text: "Le site peut contenir des liens vers d’autres ressources. L’éditeur n’est pas responsable de leur contenu ou de leur disponibilité."
        },
        {
          title: "9. Disponibilité",
          text: "L’accès au site peut être interrompu pour maintenance ou mise à jour sans préavis."
        },
        {
          title: "10. Responsabilité",
          text: "L’éditeur ne peut être tenu responsable des décisions prises sur la base des informations publiées."
        },
        {
          title: "11. Sécurité",
          text: "Chaque utilisateur demeure responsable de son équipement et de la protection de ses données."
        },
        {
          title: "12. Modifications",
          text: "Les conditions peuvent être modifiées à tout moment. La version en ligne prévaut sur toute version antérieure."
        },
        {
          title: "13. Droit applicable",
          text: "Les présentes conditions sont régies par le droit belge. Tout litige relève de la compétence des tribunaux de Bruxelles."
        },
        {
          title: "14. Contact",
          text: "Pour toute question relative aux conditions, veuillez utiliser le formulaire de contact disponible sur le site."
        }
      ]
    },
    privacy: {
      intro: "Cette politique décrit la manière dont danswholesaleplants gère les données personnelles limitées recueillies via le site.",
      sections: [
        {
          title: "1. Responsable de traitement",
          text: "Le responsable de traitement est danswholesaleplants, basé à Rue de la Loi 200, 1040 Bruxelles."
        },
        {
          title: "2. Données collectées",
          text: "Seules les informations fournies volontairement via le formulaire de contact sont collectées : nom, adresse courriel, organisation, message."
        },
        {
          title: "3. Finalités",
          text: "Les données servent exclusivement à répondre aux sollicitations et à assurer un suivi des échanges."
        },
        {
          title: "4. Base légale",
          text: "Le traitement repose sur l’intérêt légitime consistant à répondre aux demandes adressées à l’éditeur."
        },
        {
          title: "5. Conservation",
          text: "Les données sont conservées pendant la durée nécessaire au traitement de la demande et archivées au maximum douze mois."
        },
        {
          title: "6. Destinataires",
          text: "Les données ne sont pas partagées avec des tiers et restent consultables uniquement par l’équipe éditoriale."
        },
        {
          title: "7. Droits des personnes",
          text: "Chaque personne bénéficie de droits d’accès, de rectification, d’effacement et de limitation. Ils peuvent être exercés via le formulaire de contact."
        },
        {
          title: "8. Sécurité",
          text: "Des mesures techniques et organisationnelles raisonnables sont mises en œuvre pour préserver la confidentialité des données."
        },
        {
          title: "9. Cookies",
          text: "Seuls des cookies fonctionnels et de préférences sont utilisés. Les détails figurent dans la politique dédiée."
        },
        {
          title: "10. Mise à jour",
          text: "La politique peut être actualisée. La date de révision figure en en-tête du document."
        }
      ]
    },
    cookies: {
      intro: "Cette politique précise l’usage des cookies et traceurs sur danswholesaleplants.com.",
      table: {
        headers: {
          name: "Nom",
          provider: "Fournisseur",
          type: "Type",
          purpose: "Finalité",
          duration: "Durée"
        },
        rows: [
          {
            name: "site_lang",
            provider: "danswholesaleplants",
            type: "Préférences",
            purpose: "Mémoriser la langue sélectionnée par l’utilisateur.",
            duration: "12 mois"
          },
          {
            name: "cookie_consent",
            provider: "danswholesaleplants",
            type: "Nécessaire",
            purpose: "Conserver les choix de consentement relatifs aux cookies.",
            duration: "12 mois"
          },
          {
            name: "analytics_opt",
            provider: "danswholesaleplants",
            type: "Préférences",
            purpose: "Noter l’activation manuelle de mesures d’audience désactivées par défaut.",
            duration: "6 mois"
          }
        ]
      },
      toggles: {
        necessaryTitle: "Cookies nécessaires",
        necessaryDesc: "Assurent le fonctionnement des préférences et ne peuvent pas être désactivés.",
        preferencesTitle: "Cookies de préférences",
        preferencesDesc: "Retiennent vos réglages d’interface afin d’adapter l’expérience.",
        analyticsTitle: "Cookies analytiques",
        analyticsDesc: "Sont activés uniquement si vous en décidez ainsi pour mesurer l’audience de manière anonymisée.",
        marketingTitle: "Cookies marketing",
        marketingDesc: "Non utilisés actuellement. Le paramètre reste proposé pour transparence."
      },
      actions: {
        bannerTitle: "Gestion des cookies",
        bannerText: "Nous utilisons des cookies strictement nécessaires et vous proposons d’activer des options supplémentaires si vous le souhaitez.",
        manageLink: "En savoir plus",
        accept: "Tout accepter",
        decline: "Tout refuser",
        save: "Enregistrer les préférences",
        toastAccept: "Vos préférences cookies ont été enregistrées.",
        toastDecline: "Les cookies optionnels restent désactivés.",
        toastSave: "Préférences cookies mises à jour."
      }
    },
    refund: {
      intro: "Cette politique encadre la rectification des contenus publiés sur danswholesaleplants.",
      sections: [
        {
          title: "1. Champ d’application",
          text: "Concerne les corrections de textes, données ou visuels fournis sur le site."
        },
        {
          title: "2. Signalement",
          text: "Toute demande de correction peut être adressée via le formulaire de contact en précisant l’URL et la nature de l’inexactitude."
        },
        {
          title: "3. Analyse",
          text: "Chaque signalement est étudié sous quinze jours ouvrables afin de vérifier la réalité de l’erreur."
        },
        {
          title: "4. Priorisation",
          text: "Les corrections impactant l’accessibilité ou la sécurité des usagers sont traitées en priorité."
        },
        {
          title: "5. Publication",
          text: "Les modifications validées sont apportées au contenu d’origine avec mention de la date de mise à jour."
        },
        {
          title: "6. Archivage",
          text: "Les versions antérieures significatives peuvent être conservées pour référence interne."
        },
        {
          title: "7. Notification",
          text: "Une réponse est transmise au demandeur pour confirmer la prise en compte ou expliquer un refus motivé."
        },
        {
          title: "8. Limitations",
          text: "La politique ne couvre pas les demandes de suppression totale sauf obligation légale."
        },
        {
          title: "9. Collaboration",
          text: "Les corrections peuvent donner lieu à des échanges complémentaires avec les sources concernées."
        },
        {
          title: "10. Révision",
          text: "La présente politique peut évoluer selon les retours reçus et la maturité éditoriale du site."
        }
      ]
    },
    disclaimer: {
      intro: "Le présent avis précise les limites de responsabilité de danswholesaleplants.",
      sections: [
        {
          title: "Exactitude des informations",
          text: "Les contenus sont diffusés à titre informatif. Ils ne constituent pas un avis professionnel individualisé."
        },
        {
          title: "Absence de garantie",
          text: "Aucune garantie n’est fournie quant à l’exhaustivité, la précision ou l’actualité des contenus."
        },
        {
          title: "Usage des informations",
          text: "L’utilisateur demeure seul responsable de l’usage qu’il fait des informations consultées."
        },
        {
          title: "Liens externes",
          text: "La présence de liens vers d’autres sites n’implique pas l’approbation de leurs contenus."
        },
        {
          title: "Évolutions",
          text: "Le site peut être modifié à tout moment sans préavis, y compris le retrait ou l’ajout de contenus."
        },
        {
          title: "Contact",
          text: "Pour toute question relative à cet avis, veuillez utiliser le formulaire de contact."
        }
      ]
    },
    thankyou: {
      title: "Merci pour votre message",
      text: "Votre demande a bien été transmise. Nous reviendrons vers vous dans les meilleurs délais.",
      back: "Retourner à l’accueil",
      follow: "En attendant, explorez nos analyses les plus récentes."
    },
    cookieBanner: {
      title: "Gestion des cookies",
      description: "Nous utilisons des cookies nécessaires au fonctionnement du site et vous laissons le choix d’activer des options supplémentaires.",
      link: "Consulter la politique cookies",
      accept: "Tout accepter",
      decline: "Tout refuser",
      save: "Enregistrer les préférences",
      necessaryTitle: "Nécessaires",
      necessaryDesc: "Indispensables pour conserver vos choix de confidentialité et la langue sélectionnée.",
      preferencesTitle: "Préférences",
      preferencesDesc: "Améliorent la cohérence de l’affichage selon vos réglages.",
      analyticsTitle: "Analytiques",
      analyticsDesc: "Activés uniquement sur consentement explicite afin de mesurer l’audience.",
      marketingTitle: "Marketing",
      marketingDesc: "Non utilisés. Le paramètre reste désactivé par défaut.",
      toggleLabel: "Basculer l’option {name}"
    },
    toasts: {
      consentAccepted: "Votre consentement global a été pris en compte.",
      consentDeclined: "Les cookies optionnels sont désactivés.",
      consentSaved: "Vos préférences cookies ont été sauvegardées."
    },
    general: {
      readMore: "Lire la suite",
      updated: "Dernière mise à jour : {date}"
    },
    blogPosts: {} // placeholder, actual keys added later
  },
  en: {
    meta: {
      title: {
        home: "danswholesaleplants — Spatial orientation and digital wayfinding",
        services: "Analytical frameworks | danswholesaleplants",
        about: "Editorial approach and team | danswholesaleplants",
        blog: "Technical chronicles | danswholesaleplants",
        contact: "Contact details and form | danswholesaleplants",
        faq: "Frequently asked questions on indoor navigation",
        terms: "Terms of use | danswholesaleplants",
        privacy: "Privacy policy | danswholesaleplants",
        cookies: "Cookie policy | danswholesaleplants",
        refund: "Content rectification policy | danswholesaleplants",
        disclaimer: "Disclaimer | danswholesaleplants",
        thankyou: "Thank you for your message | danswholesaleplants",
        post1: "Adaptive itineraries in metropolitan stations",
        post2: "Mapping extended university campuses",
        post3: "Inclusive signage for public infrastructure",
        post4: "Pedestrian flows in complex convention centers",
        post5: "Technology watch on immersive interactive maps"
      },
      description: {
        home: "Belgian resource on spatial orientation and digital signage, focused on complex environments and user journeys in public buildings.",
        services: "Studies, analyses, and evaluations covering indoor navigation, pedestrian mobility, and the readability of public infrastructure.",
        about: "Overview of the editorial line, research methodology, and collaborations of danswholesaleplants, a platform dedicated to spatial UX.",
        blog: "Technical articles on spatial mapping, visual guidance, and interactive plans for complex built environments.",
        contact: "Reach danswholesaleplants, view the Brussels map, and use the form to share questions about digital wayfinding.",
        faq: "Answers to frequent questions about spatial orientation, digital mapping, and accessible journeys.",
        terms: "Terms of use detailing access rules, liability limits, and update procedures for danswholesaleplants.",
        privacy: "Privacy policy describing data processing, storage, and user rights.",
        cookies: "Details about cookie usage, purposes, and preference management on danswholesaleplants.",
        refund: "Rectification policy describing how to correct inaccurate or outdated content.",
        disclaimer: "Disclaimer regarding information accuracy and absence of guarantees.",
        thankyou: "Confirmation that your message reached danswholesaleplants.",
        post1: "In-depth analysis of adaptive itineraries in metropolitan stations and their impact on pedestrian mobility.",
        post2: "Strategic mapping of extended university campuses and multimodal navigation scenarios.",
        post3: "Principles of inclusive signage for public infrastructure and assessment protocols.",
        post4: "Managing pedestrian flows in flexible convention centers and directional scenography.",
        post5: "Overview of immersive interactive maps and their influence on indoor navigation experience."
      }
    },
    header: {
      brand: "danswholesaleplants",
      menu: "Menu",
      nav: {
        home: "Home",
        services: "Analyses",
        about: "About",
        blog: "Chronicles",
        faq: "FAQ",
        contact: "Contact"
      }
    },
    language: {
      switchLabel: "Change language",
      fr: "FR",
      en: "EN"
    },
    footer: {
      address: "Rue de la Loi 200, 1040 Brussels",
      phoneLabel: "Phone: +32 2 808 65 40",
      emailLabel: "Email: info@danswholesaleplants.com",
      rights: "© {year} danswholesaleplants. Knowledge base for spatial orientation.",
      links: {
        terms: "Terms",
        privacy: "Privacy",
        cookies: "Cookies",
        refund: "Rectification",
        disclaimer: "Disclaimer"
      }
    },
    home: {
      hero: {
        badge: "Spatial orientation",
        title: "Understanding and illuminating navigation within complex built environments",
        subtitle: "danswholesaleplants curates methods for digital signage, indoor mapping, and spatial UX to support pedestrian mobility in public buildings and urban infrastructures.",
        note: "Technical explorations, field feedback, and analytical matrices for Brussels and beyond.",
        button: "Review the analyses",
        buttonSecondary: "Discover the methodology",
        imageAlt: "Interior view of a public hub with digital signage and pedestrian flows"
      },
      insights: {
        title: "Three pillars for rethinking public space readability",
        subtitle: "Each pillar stems from field observations across Belgium and Europe, supported by qualitative and quantitative mobility data.",
        axis1Title: "Multimodal mapping",
        axis1Text: "Building circulation diagrams and orientation matrices combining pedestrian flows, modal transfers, and lighting conditions.",
        axis2Title: "Adaptive signage",
        axis2Text: "Decoding responsive digital systems, scripting contextual content, and calibrating information rhythms.",
        axis3Title: "Applied accessibility",
        axis3Text: "Assessing visual contrast, tactile supports, and low-load itineraries for a shared experience of place."
      },
      featured: {
        title: "Technical highlights",
        card1Title: "Contextual guidance",
        card1Text: "Orchestrating fast decision scenarios within variable-geometry hubs.",
        card2Title: "Interactive plans",
        card2Text: "Evaluating information layers and meaningful zoom levels for visitors.",
        card3Title: "Temporal flow",
        card3Text: "Observing peak usage and adjusting reference points to mitigate congestion.",
        card4Title: "Narrative structures",
        card4Text: "Storylining spatial progression with memorable, situated cues."
      },
      stats: {
        title: "Monitoring indicators",
        block1Value: "64",
        block1Label: "Public sites audited since 2018",
        block2Value: "23",
        block2Label: "Documented user-testing protocols",
        block3Value: "310",
        block3Label: "Geolocated mapping data points",
        block4Value: "12",
        block4Label: "Compared visualization methods"
      },
      recommendations: {
        title: "Editorial recommendations",
        subtitle: "Syntheses aimed at stakeholders overseeing demanding environments.",
        item1Title: "Prioritize dynamic cues",
        item1Text: "Sequence essential information before layering contextual orientation to avoid cognitive overload.",
        item2Title: "Cross data with field work",
        item2Text: "Combine qualitative notes, flow statistics, and user feedback to steer iterative adjustments.",
        item3Title: "Anticipate program shifts",
        item3Text: "Factor in spatial modularity and scenario planning for signage systems.",
        item4Title: "Ensure universal clarity",
        item4Text: "Maintain shared visual codes and strong contrast ratios for all audiences."
      },
      testimonials: {
        title: "Shared perspectives",
        subtitle: "Expert and facility insights on the value of published analyses.",
        quote1: "The observation grids from danswholesaleplants helped us structure an on-site audit within two weeks, with a level of granularity we had never reached.",
        author1: "Mireille De Smet",
        role1: "Wayfinding Coordinator, STIB — Brussels",
        quote2: "Breaking journeys into micro-sequences opened transversal views for our extended campus projects.",
        author2: "Joel Thompson",
        role2: "Deputy Architect, Leuven Knowledge District",
        quote3: "The approach finally aligns accessibility, real usage, and information design without overlooking any dimension.",
        author3: "Anne-Catherine Laurent",
        role3: "Urban mobility consultant"
      },
      latest: {
        title: "Recent chronicles",
        subtitle: "In-depth studies on varied public-space configurations.",
        post1: "Adaptive itineraries in metropolitan stations",
        post2: "Mapping extended university campuses",
        post3: "Inclusive signage for public infrastructure",
        viewAll: "View all chronicles"
      }
    },
    services: {
      hero: {
        title: "Research scopes and methodological frameworks",
        intro: "danswholesaleplants investigates the interplay between architecture, information, and pedestrian mobility. The described services outline methodological frames for practitioners, researchers, and public infrastructure managers."
      },
      cards: {
        oneTitle: "Spatial orientation diagnosis",
        oneText: "Identifying friction zones, mapping critical decisions, and measuring journey readability within complex buildings.",
        twoTitle: "Pedestrian flow study",
        twoText: "Observing trajectories, segmenting audiences, analyzing travel speeds, and attrition factors.",
        threeTitle: "Digital guidance systems",
        threeText: "Reviewing kiosks, interactive plans, and dynamic diffusion systems. Assessing contextual relevance and editorial governance.",
        fourTitle: "Information design narrative",
        fourText: "Structuring messages, visual hierarchy, typographic calibration, and harmonizing multisupport cues.",
        fiveTitle: "Accessibility and spatial UX",
        fiveText: "Studying contrast, tactile signage, journey continuity, and mediation for specific audiences."
      },
      process: {
        title: "Methodological framework",
        step1: "Field immersion",
        step1Text: "Real-life walkthroughs, photographic surveys, and behavioral clue collection at multiple time slots.",
        step2: "Cartographic synthesis",
        step2Text: "Producing annotated plans, flow matrices, and narrative diagrams highlighting bottlenecks and blind spots.",
        step3: "Interpretation workshops",
        step3Text: "Engaging stakeholders, prioritizing interventions, and scripting forthcoming iterations."
      },
      closing: "Each study includes a documentation package that strengthens knowledge sharing within public organizations."
    },
    about: {
      hero: {
        title: "A study platform focused on complex spatial readability",
        intro: "danswholesaleplants gathers field experiences, analyses of digital systems, and observation protocols to document indoor navigation."
      },
      mission: {
        title: "Editorial line",
        text: "Deliver a nuanced understanding of how architecture, signage, and actual uses intersect. Publications are grounded on longitudinal inquiries conducted in stations, hospitals, campuses, and civic centers."
      },
      history: {
        title: "Project origin",
        text: "Born in 2017 in Brussels, the project formed around a watch program on information-intensive environments. Initial dossiers concentrated on transitions between soft mobility and mass transit."
      },
      method: {
        title: "Methodology",
        point1: "On-site observation to capture micro-decisions and lighting impacts.",
        point2: "Interpretation workshops with facility managers to qualify blind spots.",
        point3: "Dissemination of operational briefs supporting shared language between designers, managers, and visitors."
      },
      collaboration: {
        title: "Collaborations",
        text: "Ad hoc partnerships with urban planners, information designers, mobility sociologists, and accessibility advocates, remaining fully non-commercial."
      },
      signature: "The platform stays open to academic contributions and experiential feedback."
    },
    blog: {
      hero: {
        title: "Technical chronicles",
        intro: "Each article provides a deep dive into navigation systems and highlights transferable analytical frameworks."
      },
      post1Excerpt: "Dissecting decision sequences in three metropolitan stations with a focus on adaptive digital cues.",
      post2Excerpt: "Mapping extended campuses and superimposing layers for multimodal users.",
      post3Excerpt: "Design frameworks for inclusive signage combining visual perception and cognitive accessibility.",
      post4Excerpt: "Reading flows in a modular convention center and pre-orientation strategies.",
      post5Excerpt: "Reviewing immersive interactive plans and conditions for sustainable adoption."
    },
    contact: {
      hero: {
        title: "Get in touch",
        intro: "Share questions or field feedback about spatial mapping and digital signage."
      },
      details: {
        title: "Contact details",
        addressLabel: "Address",
        phoneLabel: "Phone",
        emailLabel: "Email",
        availability: "Replies within three business days."
      },
      form: {
        title: "Contact form",
        intro: "Information is used solely to address your request.",
        nameLabel: "Full name",
        namePlaceholder: "Your name",
        emailLabel: "Email address",
        emailPlaceholder: "name@example.com",
        orgLabel: "Organization (optional)",
        orgPlaceholder: "Institution or agency",
        messageLabel: "Message",
        messagePlaceholder: "Describe your project or question",
        submit: "Send",
        reset: "Clear",
        successToast: "Message in progress… redirecting to confirmation.",
        errorToast: "Please check the form fields before sending.",
        mapLabel: "Map centered on Brussels – Rue de la Loi 200"
      }
    },
    faq: {
      hero: {
        title: "Frequently asked questions",
        intro: "Clarifications on methodology, sources, and publication practices."
      },
      items: [
        {
          q: "How are study sites selected?",
          a: "Sites are chosen for spatial complexity, visitor density, and programmatic evolution. Brussels public infrastructures receive particular attention to document representative cases."
        },
        {
          q: "What data supports the mapping work?",
          a: "Mapping combines available topographic records, open data, plans provided by facility owners, and field observations. Each dataset is assessed for reliability and freshness."
        },
        {
          q: "Do the analyses include user testing?",
          a: "Whenever possible, user tests involve diverse panels including people with specific needs. Protocols are described in the corresponding publications."
        },
        {
          q: "How is accessibility addressed?",
          a: "Articles explore visual, tactile, and cognitive accessibility. Recommendations rely on European guidelines and feedback from specialist associations."
        },
        {
          q: "Can a case study be suggested?",
          a: "Yes, proposals are welcome. They are reviewed for methodological relevance and resource availability."
        }
      ]
    },
    terms: {
      intro: "These terms govern access to and use of danswholesaleplants.com.",
      sections: [
        {
          title: "1. Purpose",
          text: "Define site usage conditions and outline respective responsibilities of the publisher and visitors."
        },
        {
          title: "2. Acceptance",
          text: "Any visit or use implies full acceptance of these terms."
        },
        {
          title: "3. Intended audience",
          text: "The site targets professionals, researchers, and facility managers exploring indoor navigation."
        },
        {
          title: "4. Intellectual property",
          text: "Content is protected by copyright. Partial or full reproduction requires prior authorization."
        },
        {
          title: "5. Information accuracy",
          text: "Information is provided for reference. Despite verification efforts, inaccuracies may occur."
        },
        {
          title: "6. Content use",
          text: "Content may be quoted by citing full references and preserving original meaning."
        },
        {
          title: "7. External contributions",
          text: "Submitted contributions are reviewed before publication. The publisher may refuse any proposal."
        },
        {
          title: "8. External links",
          text: "The site may reference other resources. The publisher is not responsible for their content or availability."
        },
        {
          title: "9. Availability",
          text: "Access may be suspended for maintenance or updates without notice."
        },
        {
          title: "10. Liability",
          text: "The publisher is not liable for decisions made based on published information."
        },
        {
          title: "11. Security",
          text: "Users remain responsible for their equipment and data protection."
        },
        {
          title: "12. Changes",
          text: "Terms may change at any time. The online version overrides previous ones."
        },
        {
          title: "13. Governing law",
          text: "These terms are governed by Belgian law. Disputes fall under Brussels courts."
        },
        {
          title: "14. Contact",
          text: "Direct any questions about the terms through the site’s contact form."
        }
      ]
    },
    privacy: {
      intro: "This policy explains how danswholesaleplants handles the limited personal data collected through the site.",
      sections: [
        {
          title: "1. Controller",
          text: "The controller is danswholesaleplants, Rue de la Loi 200, 1040 Brussels."
        },
        {
          title: "2. Data collected",
          text: "Only details voluntarily provided via the contact form are collected: name, email, organization, message."
        },
        {
          title: "3. Purpose",
          text: "Data is used exclusively to answer requests and maintain conversation records."
        },
        {
          title: "4. Legal basis",
          text: "Processing is based on legitimate interest in responding to incoming inquiries."
        },
        {
          title: "5. Retention",
          text: "Data is kept for the time needed to process the request and archived no longer than twelve months."
        },
        {
          title: "6. Recipients",
          text: "Data is not shared with third parties and is only accessed by the editorial team."
        },
        {
          title: "7. Rights",
          text: "Individuals can exercise rights of access, rectification, erasure, and restriction via the contact form."
        },
        {
          title: "8. Security",
          text: "Reasonable technical and organizational measures protect data confidentiality."
        },
        {
          title: "9. Cookies",
          text: "Only functional and preference cookies are used. Details appear in the dedicated policy."
        },
        {
          title: "10. Updates",
          text: "The policy may be updated. The revision date appears at the top of the document."
        }
      ]
    },
    cookies: {
      intro: "This policy clarifies the use of cookies and trackers on danswholesaleplants.com.",
      table: {
        headers: {
          name: "Name",
          provider: "Provider",
          type: "Type",
          purpose: "Purpose",
          duration: "Duration"
        },
        rows: [
          {
            name: "site_lang",
            provider: "danswholesaleplants",
            type: "Preferences",
            purpose: "Remember the language selected by the visitor.",
            duration: "12 months"
          },
          {
            name: "cookie_consent",
            provider: "danswholesaleplants",
            type: "Necessary",
            purpose: "Store consent choices related to cookies.",
            duration: "12 months"
          },
          {
            name: "analytics_opt",
            provider: "danswholesaleplants",
            type: "Preferences",
            purpose: "Record manual activation of audience measurements disabled by default.",
            duration: "6 months"
          }
        ]
      },
      toggles: {
        necessaryTitle: "Necessary cookies",
        necessaryDesc: "Ensure preference storage and cannot be switched off.",
        preferencesTitle: "Preference cookies",
        preferencesDesc: "Retain interface settings to tailor the experience.",
        analyticsTitle: "Analytics cookies",
        analyticsDesc: "Only enabled with explicit consent for anonymized metrics.",
        marketingTitle: "Marketing cookies",
        marketingDesc: "Currently unused. The toggle remains visible for transparency."
      },
      actions: {
        bannerTitle: "Cookie management",
        bannerText: "We rely on strictly necessary cookies and let you activate optional ones if desired.",
        manageLink: "Learn more",
        accept: "Accept all",
        decline: "Decline all",
        save: "Save preferences",
        toastAccept: "Your cookie preferences have been recorded.",
        toastDecline: "Optional cookies remain disabled.",
        toastSave: "Cookie settings updated."
      }
    },
    refund: {
      intro: "This policy frames the correction of content published on danswholesaleplants.",
      sections: [
        {
          title: "1. Scope",
          text: "Applies to corrections of text, data, or visuals provided on the site."
        },
        {
          title: "2. Reporting",
          text: "Submit correction requests via the contact form, specifying the URL and the nature of the issue."
        },
        {
          title: "3. Review",
          text: "Each request is reviewed within fifteen business days to verify accuracy."
        },
        {
          title: "4. Prioritization",
          text: "Corrections affecting accessibility or user safety are handled first."
        },
        {
          title: "5. Publication",
          text: "Validated changes are applied to the original content with an updated date."
        },
        {
          title: "6. Archiving",
          text: "Significant previous versions may be stored for internal reference."
        },
        {
          title: "7. Notification",
          text: "A reply confirms acceptance or provides a reasoned refusal."
        },
        {
          title: "8. Limitations",
          text: "This policy does not cover requests for total removal unless legally required."
        },
        {
          title: "9. Collaboration",
          text: "Corrections may involve additional exchanges with the relevant sources."
        },
        {
          title: "10. Revision",
          text: "The policy may evolve based on feedback and editorial maturity."
        }
      ]
    },
    disclaimer: {
      intro: "This notice outlines liability limits for danswholesaleplants.",
      sections: [
        {
          title: "Information accuracy",
          text: "Content is shared for informational purposes and does not constitute tailored professional advice."
        },
        {
          title: "No guarantee",
          text: "No guarantee is provided regarding completeness, precision, or timeliness."
        },
        {
          title: "Information use",
          text: "Users remain solely responsible for how they use the information presented."
        },
        {
          title: "External links",
          text: "Links to other sites do not imply endorsement of their content."
        },
        {
          title: "Changes",
          text: "The site may be modified at any time without prior notice, including content additions or removals."
        },
        {
          title: "Contact",
          text: "Use the contact form for any question related to this notice."
        }
      ]
    },
    thankyou: {
      title: "Thank you for your message",
      text: "Your request has been received. We will respond as soon as possible.",
      back: "Return to homepage",
      follow: "Meanwhile, explore our latest analyses."
    },
    cookieBanner: {
      title: "Cookie management",
      description: "We rely on essential cookies and let you enable optional choices.",
      link: "Read the cookie policy",
      accept: "Accept all",
      decline: "Decline all",
      save: "Save preferences",
      necessaryTitle: "Necessary",
      necessaryDesc: "Required to store your privacy choices and selected language.",
      preferencesTitle: "Preferences",
      preferencesDesc: "Improve interface consistency based on your settings.",
      analyticsTitle: "Analytics",
      analyticsDesc: "Activate only with explicit consent to gather anonymized insights.",
      marketingTitle: "Marketing",
      marketingDesc: "Not currently used. The toggle remains visible for clarity.",
      toggleLabel: "Toggle {name} option"
    },
    toasts: {
      consentAccepted: "Your overall consent has been saved.",
      consentDeclined: "Optional cookies remain disabled.",
      consentSaved: "Your cookie preferences are updated."
    },
    general: {
      readMore: "Read more",
      updated: "Last updated: {date}"
    },
    blogPosts: {}
  }
};

const DEFAULT_LANG = "fr";
const LANG_STORAGE_KEY = "site_lang";
const CONSENT_KEY = "cookie_consent";

document.addEventListener("DOMContentLoaded", () => {
  initLanguage();
  initNavigation();
  initAnimations();
  initCookieBanner();
  initContactForm();
  setActiveNav();
});

function resolveKey(lang, key) {
  if (!key) return "";
  const parts = key.split(".");
  let value = I18N[lang];
  for (const part of parts) {
    if (value && Object.prototype.hasOwnProperty.call(value, part)) {
      value = value[part];
    } else {
      return undefined;
    }
  }
  return value;
}

function formatPlaceholders(text, replacements) {
  if (!text || !replacements) return text;
  return text.replace(/\{(\w+)\}/g, (_, token) => replacements[token] ?? `{${token}}`);
}

function applyTranslations(lang) {
  document.documentElement.setAttribute("lang", lang);

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    const translation = resolveKey(lang, key);
    if (translation !== undefined) {
      el.textContent = translation;
    }
  });

  document.querySelectorAll("[data-i18n-html]").forEach((el) => {
    const key = el.getAttribute("data-i18n-html");
    const translation = resolveKey(lang, key);
    if (translation !== undefined) {
      el.innerHTML = translation;
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    const translation = resolveKey(lang, key);
    if (translation !== undefined) {
      el.setAttribute("placeholder", translation);
    }
  });

  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.getAttribute("data-i18n-alt");
    const translation = resolveKey(lang, key);
    if (translation !== undefined) {
      el.setAttribute("alt", translation);
    }
  });

  document.querySelectorAll("[data-i18n-aria-label]").forEach((el) => {
    const key = el.getAttribute("data-i18n-aria-label");
    const translation = resolveKey(lang, key);
    if (translation !== undefined) {
      el.setAttribute("aria-label", translation);
    }
  });

  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    const key = el.getAttribute("data-i18n-title");
    const translation = resolveKey(lang, key);
    if (translation !== undefined) {
      if (el.tagName.toLowerCase() === "title") {
        el.textContent = translation;
      } else {
        el.setAttribute("title", translation);
      }
    }
  });

  document.querySelectorAll("[data-i18n-meta]").forEach((el) => {
    const key = el.getAttribute("data-i18n-meta");
    const translation = resolveKey(lang, key);
    if (translation !== undefined) {
      el.setAttribute("content", translation);
    }
  });

  document.querySelectorAll("[data-i18n-format]").forEach((el) => {
    const key = el.getAttribute("data-i18n-format");
    const translation = resolveKey(lang, key);
    if (translation !== undefined) {
      const replacements = {};
      Array.from(el.attributes).forEach((attr) => {
        if (attr.name.startsWith("data-format-")) {
          const token = attr.name.replace("data-format-", "");
          replacements[token] = attr.value === "year" ? new Date().getFullYear() : attr.value;
        }
      });
      el.textContent = formatPlaceholders(translation, replacements);
    }
  });

  updateLanguageSwitcher(lang);
  updateCookieToggleLabels(lang);
  updateFooterYear(lang);
}

function updateFooterYear(lang) {
  document.querySelectorAll("[data-i18n-format]").forEach((el) => {
    const key = el.getAttribute("data-i18n-format");
    const template = resolveKey(lang, key);
    if (template !== undefined) {
      const replacements = {};
      Array.from(el.attributes).forEach((attr) => {
        if (attr.name.startsWith("data-format-")) {
          const token = attr.name.replace("data-format-", "");
          replacements[token] = attr.value === "year" ? new Date().getFullYear() : attr.value;
        }
      });
      el.textContent = formatPlaceholders(template, replacements);
    }
  });
}

function getStoredLanguage() {
  const stored = localStorage.getItem(LANG_STORAGE_KEY);
  if (stored && I18N[stored]) {
    return stored;
  }
  return DEFAULT_LANG;
}

function setLanguage(lang) {
  if (!I18N[lang]) {
    lang = DEFAULT_LANG;
  }
  localStorage.setItem(LANG_STORAGE_KEY, lang);
  applyTranslations(lang);
}

function initLanguage() {
  const lang = getStoredLanguage();
  applyTranslations(lang);
  document.querySelectorAll("[data-lang]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const selected = btn.getAttribute("data-lang");
      setLanguage(selected);
    });
  });
}

function updateLanguageSwitcher(activeLang) {
  document.querySelectorAll("[data-lang]").forEach((btn) => {
    const lang = btn.getAttribute("data-lang");
    btn.setAttribute("data-language-active", lang === activeLang ? "true" : "false");
  });
}

function initNavigation() {
  const toggle = document.getElementById("navToggle");
  const navList = document.querySelector(".nav-links");
  if (toggle && navList) {
    toggle.addEventListener("click", () => {
      const expanded = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!expanded));
      navList.setAttribute("data-open", String(!expanded));
    });
  }
}

function setActiveNav() {
  const bodyPage = document.body.getAttribute("data-page");
  if (!bodyPage) return;
  document.querySelectorAll("[data-nav]").forEach((link) => {
    const target = link.getAttribute("data-nav");
    link.setAttribute("data-active", target === bodyPage ? "true" : "false");
    if (target === bodyPage) {
      link.setAttribute("aria-current", "page");
    } else {
      link.removeAttribute("aria-current");
    }
  });
}

function initAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  document.querySelectorAll(".animate-fade").forEach((el) => observer.observe(el));
}

function showToast(message) {
  const container = document.querySelector(".toast-container");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = "toast glass-panel";
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("hide");
    toast.addEventListener("transitionend", () => toast.remove(), { once: true });
    toast.style.opacity = "0";
    toast.style.transform = "translateY(12px)";
  }, 3200);
}

function initCookieBanner() {
  const banner = document.getElementById("cookie-banner");
  if (!banner) return;

  const toggles = banner.querySelectorAll(".toggle-switch");
  const acceptBtn = banner.querySelector('[data-cookie-action="accept"]');
  const declineBtn = banner.querySelector('[data-cookie-action="decline"]');
  const saveBtn = banner.querySelector('[data-cookie-action="save"]');
  const manageLink = banner.querySelector(".cookie-link");

  const storedConsent = getStoredConsent();
  if (storedConsent) {
    setToggleStates(toggles, storedConsent);
    banner.classList.add("hidden");
  }

  toggles.forEach((toggle) => {
    if (toggle.disabled) return;
    toggle.addEventListener("click", () => {
      const currentState = toggle.getAttribute("aria-pressed") === "true";
      toggle.setAttribute("aria-pressed", String(!currentState));
      toggle.setAttribute("data-state", String(!currentState));
      updateToggleVisual(toggle);
    });
  });

  acceptBtn?.addEventListener("click", () => {
    const consent = {
      necessary: true,
      preferences: true,
      analytics: true,
      marketing: true,
      decidedAt: new Date().toISOString()
    };
    storeConsent(consent);
    setToggleStates(toggles, consent);
    banner.classList.add("hidden");
    showToast(resolveKey(getStoredLanguage(), "toasts.consentAccepted"));
  });

  declineBtn?.addEventListener("click", () => {
    const consent = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      decidedAt: new Date().toISOString()
    };
    storeConsent(consent);
    setToggleStates(toggles, consent);
    banner.classList.add("hidden");
    showToast(resolveKey(getStoredLanguage(), "toasts.consentDeclined"));
  });

  saveBtn?.addEventListener("click", () => {
    const consent = {
      necessary: true,
      preferences: getToggleState(banner, "preferences"),
      analytics: getToggleState(banner, "analytics"),
      marketing: getToggleState(banner, "marketing"),
      decidedAt: new Date().toISOString()
    };
    storeConsent(consent);
    banner.classList.add("hidden");
    showToast(resolveKey(getStoredLanguage(), "toasts.consentSaved"));
  });

  manageLink?.addEventListener("click", (event) => {
    event.preventDefault();
    window.location.href = manageLink.getAttribute("href");
  });
}

function updateCookieToggleLabels(lang) {
  const banner = document.getElementById("cookie-banner");
  if (!banner) return;
  banner.querySelectorAll("[data-toggle-key]").forEach((toggle) => {
    const key = toggle.getAttribute("data-toggle-key");
    const labelTemplate = resolveKey(lang, "cookieBanner.toggleLabel");
    if (labelTemplate) {
      const label = formatPlaceholders(labelTemplate, { name: key });
      toggle.setAttribute("aria-label", label);
    }
  });
}

function getToggleState(banner, key) {
  const toggle = banner.querySelector(`[data-toggle-key="${key}"]`);
  if (!toggle) return false;
  return toggle.getAttribute("aria-pressed") === "true";
}

function setToggleStates(toggles, consent) {
  toggles.forEach((toggle) => {
    const key = toggle.getAttribute("data-toggle-key");
    const value = consent[key];
    toggle.setAttribute("aria-pressed", String(value));
    toggle.setAttribute("data-state", String(value));
    updateToggleVisual(toggle);
  });
}

function updateToggleVisual(toggle) {
  if (toggle.getAttribute("aria-pressed") === "true") {
    toggle.classList.add("is-active");
  } else {
    toggle.classList.remove("is-active");
  }
}

function storeConsent(consent) {
  localStorage.setItem(CONSENT_KEY, JSON.stringify(consent));
}

function getStoredConsent() {
  const stored = localStorage.getItem(CONSENT_KEY);
  if (!stored) return null;
  try {
    return JSON.parse(stored);
  } catch {
    return null;
  }
}

function initContactForm() {
  const form = document.querySelector("form[data-form='contact']");
  if (!form) return;
  form.addEventListener("submit", (event) => {
    if (form.dataset.submitted === "true") {
      return;
    }
    if (!form.checkValidity()) {
      event.preventDefault();
      showToast(resolveKey(getStoredLanguage(), "contact.form.errorToast"));
      form.reportValidity();
      return;
    }
    event.preventDefault();
    showToast(resolveKey(getStoredLanguage(), "contact.form.successToast"));
    form.dataset.submitted = "true";
    setTimeout(() => {
      form.submit();
    }, 600);
  });
}

function populateBlogTranslations() {
  // Placeholder for future dynamic loading if needed
}

populateBlogTranslations();