document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.getElementById('primary-navigation');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            siteNav.classList.toggle('is-open');
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth <= 768 && siteNav.classList.contains('is-open')) {
                    siteNav.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookies = document.querySelector('[data-cookie-action="accept"]');
    const declineCookies = document.querySelector('[data-cookie-action="decline"]');
    const cookieChoice = localStorage.getItem('highflhoye-cookie-choice');

    function hideCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.remove('active');
        }
    }

    if (!cookieChoice && cookieBanner) {
        cookieBanner.classList.add('active');
    }

    if (acceptCookies) {
        acceptCookies.addEventListener('click', () => {
            localStorage.setItem('highflhoye-cookie-choice', 'accepted');
            hideCookieBanner();
        });
    }

    if (declineCookies) {
        declineCookies.addEventListener('click', () => {
            localStorage.setItem('highflhoye-cookie-choice', 'declined');
            hideCookieBanner();
        });
    }
});