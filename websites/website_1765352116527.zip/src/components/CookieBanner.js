import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('digitalcover_cookie_consent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('digitalcover_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="region" aria-label="Уведомление об использовании файлов cookie">
      <p>
        Мы используем файлы cookie для персонализации контента и анализа трафика. Подробнее в{' '}
        <Link to="/cookie-policy">Политике cookie</Link>.
      </p>
      <button type="button" onClick={handleAccept} className={styles.button}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;