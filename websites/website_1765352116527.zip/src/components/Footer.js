import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={styles.container}>
      <div className={styles.brandColumn}>
        <span className={styles.logo}>Digital<span className={styles.logoAccent}>Cover</span></span>
        <p className={styles.description}>
          DigitalCover помогает контент-мейкерам выделяться за счет продуманного визуального стиля. Наши шаблоны адаптированы для YouTube, Twitch, Telegram и других платформ.
        </p>
        <p className={styles.copyright}>
          © {new Date().getFullYear()} DigitalCover. Все права защищены.
        </p>
      </div>

      <div className={styles.linksColumn}>
        <h3>Компания</h3>
        <ul>
          <li><Link to="/about">О нас</Link></li>
          <li><Link to="/services">Услуги</Link></li>
          <li><Link to="/how-it-works">Как это работает</Link></li>
          <li><Link to="/contacts">Контакты</Link></li>
        </ul>
      </div>

      <div className={styles.linksColumn}>
        <h3>Каталоги</h3>
        <ul>
          <li><Link to="/covers">Обложки</Link></li>
          <li><Link to="/avatars">Аватарки</Link></li>
          <li><Link to="/templates">Шаблоны</Link></li>
        </ul>
      </div>

      <div className={styles.linksColumn}>
        <h3>Юридическая информация</h3>
        <ul>
          <li><Link to="/terms">Условия использования</Link></li>
          <li><Link to="/privacy">Политика конфиденциальности</Link></li>
          <li><Link to="/cookie-policy">Политика cookie</Link></li>
        </ul>
        <a className={styles.email} href="mailto:support@digitalcover.example">
          support@digitalcover.example
        </a>
      </div>
    </div>
  </footer>
);

export default Footer;