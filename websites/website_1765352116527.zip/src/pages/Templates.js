import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Catalog.module.css';

const tags = ['Все', 'Twitch', 'YouTube', 'Stories', 'Презентации'];

const templates = [
  {
    title: 'Пакет оверлеев для Twitch',
    description: 'Сцены пауз, донат-зоны и анимации в едином стиле для стрима.',
    tag: 'Twitch',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Комплект YouTube-баннера',
    description: 'Хедер канала, превью и финальные заставки в фирменных цветах.',
    tag: 'YouTube',
    image: 'https://images.unsplash.com/photo-1487014679447-9f8336841d58?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Шаблоны Stories для анонсов',
    description: 'Мобильные макеты для Instagram и Telegram с быстрым редактированием текста.',
    tag: 'Stories',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Коллекция титров для видеоуроков',
    description: 'Интеграция в монтажные программы, гибкая система стилей и анимация.',
    tag: 'YouTube',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Дизайн презентации для стримеров',
    description: 'Презентационный шаблон для брендов и партнёров с визуальными акцентами.',
    tag: 'Презентации',
    image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Мультимедийный пакет для событий',
    description: 'Заставки, превью и графика для YouTube-трансляции и социальных сетей.',
    tag: 'Twitch',
    image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=80'
  }
];

const Templates = () => {
  const [activeTag, setActiveTag] = useState('Все');

  const filtered = activeTag === 'Все'
    ? templates
    : templates.filter((template) => template.tag === activeTag);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Каталог шаблонов — DigitalCover</title>
        <meta
          name="description"
          content="Шаблоны для YouTube, Twitch, Stories и презентаций. Готовые решения, которые легко адаптировать под ваш проект."
        />
      </Helmet>

      <header className={styles.header}>
        <h1>Каталог шаблонов</h1>
        <p>Здесь собраны универсальные пакеты для стримов, сторис и презентаций. Каждый шаблон адаптирован под популярные платформы и включает подробную структуру.</p>
        <div className={styles.filters}>
          {tags.map((tag) => (
            <button
              key={tag}
              type="button"
              className={activeTag === tag ? `${styles.filterButton} ${styles.active}` : styles.filterButton}
              onClick={() => setActiveTag(tag)}
            >
              {tag}
            </button>
          ))}
        </div>
      </header>

      <div className={styles.grid}>
        {filtered.map((template) => (
          <article key={template.title} className={styles.card}>
            <img src={template.image} alt={template.title} loading="lazy" />
            <div className={styles.cardBody}>
              <h3>{template.title}</h3>
              <p>{template.description}</p>
              <div className={styles.cardFooter}>
                <span className={styles.tag}>{template.tag}</span>
                <button type="button" className={styles.moreButton}>
                  Подробнее
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default Templates;