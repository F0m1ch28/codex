import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Catalog.module.css';

const tags = ['Все', 'Гейминг', 'Личный бренд', 'Минимализм'];

const avatars = [
  {
    title: 'Неоновый стиль для стримера',
    description: 'Смелые сияющие контуры и тайпфейс, вдохновленный киберспортом.',
    tag: 'Гейминг',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Личный бренд продюсера',
    description: 'Сочетание портретной фотографии и фирменных графических элементов.',
    tag: 'Личный бренд',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Минималистичный монограмный логотип',
    description: 'Геометрические буквы, нейтральная палитра, идеален для подкаста.',
    tag: 'Минимализм',
    image: 'https://images.unsplash.com/photo-1524502397800-2eeaad7c3fe5?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Аватарка для геймерского клана',
    description: 'Символика клана, четкие контуры, легко масштабируется под разные платформы.',
    tag: 'Гейминг',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Авторская иллюстрация',
    description: 'Артистичный портрет в фирменной палитре для блога о путешествиях.',
    tag: 'Личный бренд',
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Нейтральный минималистичный знак',
    description: 'Чистые линии и аккуратная типографика для технического блога.',
    tag: 'Минимализм',
    image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=80'
  }
];

const Avatars = () => {
  const [activeTag, setActiveTag] = useState('Все');

  const filtered = activeTag === 'Все'
    ? avatars
    : avatars.filter((avatar) => avatar.tag === activeTag);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Каталог аватарок — DigitalCover</title>
        <meta
          name="description"
          content="Коллекция аватарок и логотипов для стримеров, подкастеров и персональных брендов. Выберите стиль, отражающий вашу индивидуальность."
        />
      </Helmet>

      <header className={styles.header}>
        <h1>Каталог аватарок</h1>
        <p>Аватар — первое впечатление о вашем проекте. Мы создаём знаки и иллюстрации, которые читаются в маленьких размерах и выглядят выразительно на любом фоне.</p>
        <div className={styles.filters}>
          {tags.map((tag) => (
            <button
              key={tag}
              type="button"
              className={activeTag === tag ? `${styles.filterButton} ${styles.active}` : styles.filterButton}
              onClick={() => setActiveTag(tag)}
            >
              {tag}
            </button>
          ))}
        </div>
      </header>

      <div className={styles.grid}>
        {filtered.map((avatar) => (
          <article key={avatar.title} className={styles.card}>
            <img src={avatar.image} alt={avatar.title} loading="lazy" />
            <div className={styles.cardBody}>
              <h3>{avatar.title}</h3>
              <p>{avatar.description}</p>
              <div className={styles.cardFooter}>
                <span className={styles.tag}>{avatar.tag}</span>
                <button type="button" className={styles.moreButton}>
                  Подробнее
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default Avatars;