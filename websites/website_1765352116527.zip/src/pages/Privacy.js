import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const Privacy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Политика конфиденциальности — DigitalCover</title>
      <meta
        name="description"
        content="Описание принципов обработки персональных данных DigitalCover. Узнайте, как мы защищаем вашу информацию."
      />
    </Helmet>

    <header className={styles.hero}>
      <h1>Политика конфиденциальности</h1>
      <p>Мы заботимся о защите персональных данных и описываем, как собираем, используем и храним информацию пользователей DigitalCover.</p>
    </header>

    <section className={styles.section}>
      <h2>1. Какие данные мы собираем</h2>
      <p>Мы можем собирать имя, адрес электронной почты и детали заказа для предоставления услуг. Информация хранится в защищённых системах.</p>
    </section>

    <section className={styles.section}>
      <h2>2. Как мы используем данные</h2>
      <ul className={styles.list}>
        <li>Обработка запросов и предоставление услуг;</li>
        <li>Информирование о новых продуктах и обновлениях (при согласии пользователя);</li>
        <li>Аналитика и улучшение сервиса.</li>
      </ul>
    </section>

    <section className={styles.section}>
      <h2>3. Передача данных третьим лицам</h2>
      <p>Мы не передаём персональные данные третьим лицам, за исключением случаев, необходимых для выполнения обязательств и когда это требуется законом.</p>
    </section>

    <section className={styles.section}>
      <h2>4. Хранение данных</h2>
      <p>Данные сохраняются в течение срока выполнения услуг и удаляются по запросу пользователя или в соответствии с законодательством.</p>
    </section>
  </div>
);

export default Privacy;