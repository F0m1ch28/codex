import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contacts.module.css';

const Contacts = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [feedback, setFeedback] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!form.name || !form.email || !form.message) {
      setFeedback('Пожалуйста, заполните все поля формы.');
      return;
    }
    setFeedback('Спасибо! Мы свяжемся с вами в течение рабочего дня.');
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Контакты — DigitalCover</title>
        <meta
          name="description"
          content="Свяжитесь с DigitalCover: вопросы, сотрудничество и запросы на кастомный дизайн. Email службы поддержки support@digitalcover.example."
        />
      </Helmet>

      <header className={styles.hero}>
        <div>
          <span className={styles.badge}>Контакты</span>
          <h1>Давайте обсудим ваш проект</h1>
          <p>Напишите нам, и мы предложим решения для вашего контента: от быстрой адаптации готовых шаблонов до разработки фирменной визуальной айдентики.</p>
        </div>
        <div className={styles.contactCard}>
          <h2>Служба поддержки</h2>
          <p>support@digitalcover.example</p>
          <p>Мы отвечаем в течение одного рабочего дня.</p>
        </div>
      </header>

      <section className={styles.section}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Имя</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Как к вам обращаться?"
              value={form.name}
              onChange={handleChange}
              required
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="name@example.com"
              value={form.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="message">Сообщение</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Расскажите о задаче или задайте вопрос"
              value={form.message}
              onChange={handleChange}
              required
            />
          </div>
          {feedback && <p className={styles.feedback}>{feedback}</p>}
          <button type="submit" className={styles.submit}>
            Отправить сообщение
          </button>
        </form>
      </section>
    </div>
  );
};

export default Contacts;