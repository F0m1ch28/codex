import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Алексей Карпин',
    role: 'Креативный директор',
    bio: 'Куратор визуальной стратегии DigitalCover. Отвечает за общий стиль и актуальность графических решений.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Наталья Вереск',
    role: 'Ведущий дизайнер',
    bio: 'Специализируется на создании обложек и превью для контент-мейкеров. Работала с крупными YouTube-проектами.',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Руслан Думов',
    role: 'Арт-продюсер',
    bio: 'Выстраивает процессы работающей команды дизайнеров и иллюстраторов, отвечает за сроки и качество.',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=400&q=80'
  }
];

const values = [
  {
    title: 'Прозрачность',
    description: 'Работаем открыто, обсуждая каждый шаг — от концепции до финальной правки, чтобы результат совпал с ожиданиями.'
  },
  {
    title: 'Гибкость',
    description: 'Подстраиваемся под график клиента, его инструменты и платформы, создавая элементы, которые легко масштабировать.'
  },
  {
    title: 'Технологичность',
    description: 'Используем современные инструменты и автоматизацию, чтобы ускорять разработку визуальных пакетов.'
  }
];

const About = () => (
  <div className={styles.page}>
    <Helmet>
      <title>О DigitalCover — команда дизайнеров для контент-мейкеров</title>
      <meta
        name="description"
        content="Мы создаём визуальные системы для авторов, брендов и медиа. Узнайте, как DigitalCover помогает проектам развиваться через дизайн."
      />
    </Helmet>

    <header className={styles.hero}>
      <div>
        <span className={styles.badge}>О компании</span>
        <h1>Команда, которая говорит с авторами на одном языке</h1>
        <p>
          DigitalCover — это студия цифрового дизайна, созданная контент-мейкерами для контент-мейкеров. Мы разбираемся в потребностях блогеров, стримеров и SMM-специалистов, создаём графику, которая усиливает их истории.
        </p>
      </div>
      <div className={styles.heroVisual}>
        <img
          src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80"
          alt="Команда дизайнеров обсуждает проект"
        />
      </div>
    </header>

    <section className={styles.section} aria-labelledby="mission-heading">
      <div className={styles.sectionContent}>
        <h2 id="mission-heading">Миссия DigitalCover</h2>
        <p>
          Мы верим, что качественный дизайн должен быть доступен каждому автору, независимо от масштаба его проекта. Поэтому создаём каталог шаблонов для быстрого запуска и предлагаем индивидуальные решения для тех, кто хочет выделиться в конкурентной среде. Наши дизайнеры работают в разных стилях: от минимализма до насыщенного неона и motion-элементов.
        </p>
      </div>
      <div className={styles.highlights}>
        <article>
          <h3>Внимание к деталям</h3>
          <p>Каждый макет проходит внутренний контроль качества, чтобы наши клиенты получали продуманный и структурированный дизайн.</p>
        </article>
        <article>
          <h3>Партнёрский подход</h3>
          <p>Мы включаемся в стратегию контент-плана и помогаем брифовать дизайнеров, если у клиента нет специальных навыков.</p>
        </article>
      </div>
    </section>

    <section className={styles.section} aria-labelledby="values-heading">
      <div className={styles.sectionContent}>
        <h2 id="values-heading">Наши ценности</h2>
        <p>На них строится работа команды и взаимодействие с каждым клиентом. Эти принципы помогают удерживать высокий уровень качества.</p>
      </div>
      <div className={styles.valuesGrid}>
        {values.map((value) => (
          <article key={value.title}>
            <h3>{value.title}</h3>
            <p>{value.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.section} aria-labelledby="team-heading">
      <div className={styles.sectionContent}>
        <h2 id="team-heading">Команда DigitalCover</h2>
        <p>
          Мы не просто рисуем красочные обложки. Наша команда исследует аудиторию, тестирует гипотезы и создаёт визуальные истории, которые увеличивают вовлечённость.
        </p>
      </div>
      <div className={styles.teamGrid}>
        {teamMembers.map((member) => (
          <article key={member.name} className={styles.teamCard}>
            <img src={member.image} alt={member.name} />
            <h3>{member.name}</h3>
            <span>{member.role}</span>
            <p>{member.bio}</p>
          </article>
        ))}
      </div>
    </section>
  </div>
);

export default About;