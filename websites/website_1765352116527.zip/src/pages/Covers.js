import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Catalog.module.css';

const tags = ['Все', 'YouTube', 'Гейминг', 'Подкаст', 'Lifestyle'];

const covers = [
  {
    title: 'Яркое превью для геймерского стрима',
    description: 'Смелые цвета, динамичная типографика, адаптация под мобильную выдачу.',
    tag: 'Гейминг',
    image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Минималистичная обложка для интервью',
    description: 'Акцент на героя, чистый фон, выразительный заголовок в корпоративной палитре.',
    tag: 'Подкаст',
    image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Lifestyle превью с акцентом на эмоции',
    description: 'Теплая цветовая схема, мягкий свет и акцент на деталях кадра.',
    tag: 'Lifestyle',
    image: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Образовательное превью',
    description: 'Чёткая структура, иконки, удобная сетка для нескольких тезисов.',
    tag: 'YouTube',
    image: 'https://images.unsplash.com/photo-1580894906472-c24393997115?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Обложка для аналитического шоу',
    description: 'Темная палитра, инфографика и место под логотип канала.',
    tag: 'YouTube',
    image: 'https://images.unsplash.com/photo-1517433456452-f9633a875f6f?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Превью для трейлера игрового события',
    description: 'Неоновые элементы, детали, вдохновленные киберпанком, и динамичный коллаж.',
    tag: 'Гейминг',
    image: 'https://images.unsplash.com/photo-1525182008055-f88b95ff7980?auto=format&fit=crop&w=1200&q=80'
  }
];

const Covers = () => {
  const [activeTag, setActiveTag] = useState('Все');

  const filtered = activeTag === 'Все'
    ? covers
    : covers.filter((cover) => cover.tag === activeTag);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Каталог обложек — DigitalCover</title>
        <meta
          name="description"
          content="Найдите идеальную обложку для YouTube, подкаста или стрима. Каталог DigitalCover включает готовые решения с гибкой адаптацией."
        />
      </Helmet>

      <header className={styles.header}>
        <h1>Каталог обложек</h1>
        <p>Каждая обложка строится на исследовании поведения аудитории и правилах визуальной иерархии. Выбирайте подходящий стиль и адаптируйте под свой канал.</p>
        <div className={styles.filters}>
          {tags.map((tag) => (
            <button
              key={tag}
              type="button"
              className={activeTag === tag ? `${styles.filterButton} ${styles.active}` : styles.filterButton}
              onClick={() => setActiveTag(tag)}
            >
              {tag}
            </button>
          ))}
        </div>
      </header>

      <div className={styles.grid}>
        {filtered.map((cover) => (
          <article key={cover.title} className={styles.card}>
            <img src={cover.image} alt={cover.title} loading="lazy" />
            <div className={styles.cardBody}>
              <h3>{cover.title}</h3>
              <p>{cover.description}</p>
              <div className={styles.cardFooter}>
                <span className={styles.tag}>{cover.tag}</span>
                <button type="button" className={styles.moreButton}>
                  Подробнее
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default Covers;