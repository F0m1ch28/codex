import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './HowItWorks.module.css';

const steps = [
  {
    title: 'Понимаем задачу',
    description: 'Вы заполняете короткий бриф или делитесь ссылками на канал. Мы анализируем формат контента и аудиторию.',
    details: 'На этом этапе мы обсуждаем желаемый стиль, референсы и срок. Предлагаем оптимальный пакет услуг.'
  },
  {
    title: 'Создаём концепцию',
    description: 'Подбираем цветовые палитры, типографику и графические приёмы, готовим предварительный макет.',
    details: 'Вы получаете 1–2 концепции, обсуждаете правки и отмечаете, какие элементы понравились больше всего.'
  },
  {
    title: 'Готовим пакет',
    description: 'Разрабатываем финальные макеты, адаптируем под разные форматы и платформы.',
    details: 'На выходе вы получаете набор файлов, организованных по папкам. Прикладываем инструкции по применению.'
  },
  {
    title: 'Поддерживаем запуск',
    description: 'Помогаем внедрить дизайн в рабочие процессы и остаёмся на связи для обновлений.',
    details: 'Если необходимо, готовим дополнительные элементы: превью, баннеры, графику для рекламных акций.'
  }
];

const HowItWorks = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Как работает DigitalCover — шаги сотрудничества</title>
      <meta
        name="description"
        content="Узнайте, как мы создаём обложки, аватарки и шаблоны: от брифа до поддержки запуска. Процесс DigitalCover прозрачен и удобен."
      />
    </Helmet>

    <header className={styles.hero}>
      <h1>Как мы создаём дизайн для контент-мейкеров</h1>
      <p>
        Процесс DigitalCover построен на диалоге. Мы внимательны к деталям и помогаем интегрировать новые решения без лишних усилий.
      </p>
    </header>

    <section className={styles.timeline} aria-label="Шаги сотрудничества">
      {steps.map((step, index) => (
        <article key={step.title} className={styles.step}>
          <div className={styles.stepIndex}>{index + 1}</div>
          <div className={styles.stepBody}>
            <h2>{step.title}</h2>
            <p>{step.description}</p>
            <p className={styles.details}>{step.details}</p>
          </div>
        </article>
      ))}
    </section>

    <section className={styles.support}>
      <h2>Что мы гарантируем</h2>
      <ul>
        <li>Чёткий дедлайн и прозрачное согласование правок.</li>
        <li>Передачу исходников и руководства по использованию.</li>
        <li>Рекомендации по интеграции дизайна в контент-план.</li>
        <li>Поддержку после релиза и обновления при необходимости.</li>
      </ul>
    </section>
  </div>
);

export default HowItWorks;