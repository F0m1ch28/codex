import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Политика использования файлов cookie — DigitalCover</title>
      <meta
        name="description"
        content="Узнайте, какие типы cookie использует DigitalCover и как вы можете управлять своими предпочтениями."
      />
    </Helmet>

    <header className={styles.hero}>
      <h1>Политика использования файлов cookie</h1>
      <p>В этой политике описано, как DigitalCover применяет cookie и аналогичные технологии для персонализации и аналитики.</p>
    </header>

    <section className={styles.section}>
      <h2>1. Зачем мы используем cookie</h2>
      <p>Cookie помогают анализировать трафик, запоминать выбранный язык и улучшать работу сайта. Некоторые cookie необходимы для корректного отображения страниц.</p>
    </section>

    <section className={styles.section}>
      <h2>2. Типы cookie</h2>
      <ul className={styles.list}>
        <li>Функциональные — обеспечивают базовую работу сайта;</li>
        <li>Аналитические — помогают понимать, как пользователи взаимодействуют с контентом;</li>
        <li>Предпочтения — запоминают ваши выбранные настройки.</li>
      </ul>
    </section>

    <section className={styles.section}>
      <h2>3. Управление cookie</h2>
      <p>Вы можете отключить cookie в настройках браузера. Обратите внимание, что это может повлиять на удобство использования некоторых разделов сайта.</p>
    </section>
  </div>
);

export default CookiePolicy;