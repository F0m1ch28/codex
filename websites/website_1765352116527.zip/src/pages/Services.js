import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

const services = [
  {
    title: 'Персональный пакет обложек',
    description: 'Разрабатываем серию превью в едином стиле под рубрики вашего канала. Анализируем аудиторию, тестируем варианты и создаём шаблонную систему, которая легко обновляется.',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Фирменный набор для стримера',
    description: 'Оверлеи, баннеры, стартовые и финальные сцены, панели донатов и окна чата. Все элементы синхронизированы с вашим брендингом и готовы к импортированию.',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Дизайн для соцсетей и рассылок',
    description: 'Шаблоны постов, сториз и превью для Telegram, VK, Instagram, email. Предоставляем версии для разных форматов и готовим гайд по использованию.',
    image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=1200&q=80'
  }
];

const Services = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Услуги DigitalCover — комплексный дизайн для авторов</title>
      <meta
        name="description"
        content="DigitalCover предоставляет кастомные пакеты дизайна: обложки, стримерские оверлеи, оформление соцсетей и брендинг."
      />
    </Helmet>

    <header className={styles.hero}>
      <div>
        <span className={styles.badge}>Услуги</span>
        <h1>Комплексная визуальная поддержка вашего контента</h1>
        <p>Мы создаём дизайн-пакеты, которые закрывают потребности автора в нескольких форматах: обложки, аватарки, шаблоны, графика для stories и презентаций.</p>
      </div>
    </header>

    <section className={styles.section}>
      <div className={styles.grid}>
        {services.map((service) => (
          <article key={service.title} className={styles.card}>
            <img src={service.image} alt={service.title} loading="lazy" />
            <div className={styles.cardBody}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <a href="mailto:support@digitalcover.example" className={styles.link}>
                Обсудить проект →
              </a>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.section}>
      <div className={styles.checklist}>
        <h2>Что входит в работу</h2>
        <ul>
          <li>Бриф и аудит текущего визуала</li>
          <li>Концепция и moodboard для согласования</li>
          <li>Создание адаптивных макетов и шаблонов</li>
          <li>Подготовка инструкций по использованию</li>
          <li>Поддержка и обновления по запросу</li>
        </ul>
      </div>
    </section>
  </div>
);

export default Services;