import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const statsData = [
  { label: 'Готовых макетов', value: 3200, suffix: '+' },
  { label: 'Клиентов по всему миру', value: 1200, suffix: '+' },
  { label: 'Созданных дизайнов в месяц', value: 450, suffix: '+' },
  { label: 'Средняя оценка', value: 4.9, suffix: '' }
];

const advantages = [
  {
    title: 'Аутентичный стиль',
    description: 'Каждый макет создаётся с нуля, чтобы подчеркнуть уникальность автора и его контента.',
    icon: '🎨'
  },
  {
    title: 'Молниеносная адаптация',
    description: 'Подстраиваем дизайн под YouTube, Twitch, Telegram, TikTok и другие площадки за считанные часы.',
    icon: '⚡'
  },
  {
    title: 'Поддержка 24/7',
    description: 'Подскажем, как встроить ресурсы в ваш контент и сохраним проект для будущих обновлений.',
    icon: '🤝'
  },
  {
    title: 'Готовность к трендам',
    description: 'Постоянно отслеживаем визуальные тренды, чтобы ваши превью выглядели свежо и современно.',
    icon: '🚀'
  }
];

const categories = [
  {
    title: 'Обложки для видео',
    description: 'Выразительные превью, которые повышают CTR роликов и делают ваш канал узнаваемым.',
    image: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&w=1200&q=80',
    link: '/covers'
  },
  {
    title: 'Аватарки и логотипы',
    description: 'Яркие аватарки, отражающие характер автора или проекта, в стиле гейминга, влогов и подкастов.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
    link: '/avatars'
  },
  {
    title: 'Шаблоны и графика для стримов',
    description: 'Оверлеи, баннеры и наборы для live-трансляций, которые легко редактировать.',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1200&q=80',
    link: '/templates'
  }
];

const galleryItems = [
  {
    id: 1,
    category: 'covers',
    title: 'YouTube превью: образовательный контент',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 2,
    category: 'avatars',
    title: 'Аватарка для стримера',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 3,
    category: 'templates',
    title: 'Оверлей для Twitch',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 4,
    category: 'covers',
    title: 'Обложка для подкаста',
    image: 'https://images.unsplash.com/photo-1545239351-ef35f43d514b?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 5,
    category: 'templates',
    title: 'Шаблон Stories для соцсетей',
    image: 'https://images.unsplash.com/photo-1487014679447-9f8336841d58?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 6,
    category: 'avatars',
    title: 'Минималистичная аватарка',
    image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=1200&q=80'
  }
];

const testimonials = [
  {
    name: 'Мария Климова',
    role: 'Автор образовательного канала',
    quote: 'С DigitalCover мои превью стали значительно кликабельнее. Команда быстро подхватывает идеи и предлагает неожиданные решения.',
    avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80'
  },
  {
    name: 'Иван Чесноков',
    role: 'Стример и подкастер',
    quote: 'Их шаблоны для стримов экономят кучу времени. Всё собрано в одном наборе, легко адаптируется под новые темы.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80'
  },
  {
    name: 'Дарья Соловьёва',
    role: 'SMM-менеджер',
    quote: 'Удобная структура каталога и дружественная поддержка. Вся графика в высоком разрешении и с понятными слоями.',
    avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80'
  }
];

const faqItems = [
  {
    question: 'Можно ли адаптировать шаблон под мой бренд?',
    answer: 'Да, мы учитываем цвета, шрифты и визуальные приёмы вашего бренда. Команда дизайнеров подготовит соответствующие варианты и поможет внедрить их в контент-план.'
  },
  {
    question: 'Какие форматы файлов я получу?',
    answer: 'Мы предоставляем PSD, PNG и дополнительные форматы по запросу. Каждый макет организован по слоям, что облегчает последующее редактирование.'
  },
  {
    question: 'Сколько времени занимает подготовка дизайна?',
    answer: 'Готовые шаблоны доступны мгновенно, а индивидуальные решения занимают от 24 часов в зависимости от сложности задачи и количества правок.'
  }
];

const blogPosts = [
  {
    title: 'Как повышать CTR роликов за счёт визуала',
    date: '12.05.2024',
    link: '/how-it-works',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Тренды графики для стриминговых платформ',
    date: '03.05.2024',
    link: '/services',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80'
  }
];

const processSteps = [
  {
    title: 'Выберите основу',
    description: 'Изучите каталог и подберите обложку, аватар или шаблон под задачи вашего проекта.',
    icon: '🔍'
  },
  {
    title: 'Настройте детали',
    description: 'Передайте нам материалы или используйте собственный редактор, чтобы вносить правки.',
    icon: '🛠️'
  },
  {
    title: 'Получите файлы',
    description: 'Скачайте готовые ресурсы в нужных форматах и запустите их в работу без задержек.',
    icon: '⬇️'
  },
  {
    title: 'Обновляйте визуал',
    description: 'Сохраняйте шаблон и возвращайтесь за новыми элементами в любой момент.',
    icon: '🔁'
  }
];

const Home = () => {
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [activeFilter, setActiveFilter] = useState('all');
  const [expandedFaq, setExpandedFaq] = useState(null);

  useEffect(() => {
    const intervals = statsData.map((stat, index) =>
      setInterval(() => {
        setAnimatedStats((prev) => {
          const updated = [...prev];
          const increment = Math.ceil(stat.value / 40);
          if (updated[index] < stat.value) {
            updated[index] = Math.min(stat.value, updated[index] + increment);
          }
          return updated;
        });
      }, 80)
    );

    return () => {
      intervals.forEach((interval) => clearInterval(interval));
    };
  }, []);

  const filteredGallery = activeFilter === 'all'
    ? galleryItems
    : galleryItems.filter((item) => item.category === activeFilter);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>DigitalCover — Обложки, аватарки и шаблоны для контент-мейкеров</title>
        <meta
          name="description"
          content="DigitalCover помогает блогерам, стримерам и SMM-специалистам создавать впечатляющие обложки, аватарки и шаблоны. Каталог готовых решений и кастомный дизайн."
        />
        <meta
          name="keywords"
          content="обложки для видео, аватарки, шаблоны для ютуба, графика для стримов, дизайн для соцсетей, превью, баннеры канала"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.heroBadge}>Визуальные решения нового поколения</span>
          <h1 className={styles.heroTitle}>Создаём визуальную идентичность контент-мейкеров</h1>
          <p className={styles.heroSubtitle}>
            Подберите готовую обложку, аватарку или шаблон из нашего каталога или закажите индивидуальный дизайн. DigitalCover поддерживает авторов от идеи до запуска проекта.
          </p>
          <div className={styles.heroActions}>
            <Link to="/covers" className={styles.ctaPrimary}>Перейти в каталог</Link>
            <Link to="/how-it-works" className={styles.ctaSecondary}>Узнать как это работает</Link>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1200&q=80"
            alt="Цифровой художник работает над дизайном обложки"
          />
          <div className={styles.heroWidget}>
            <span>+37 новых шаблонов за неделю</span>
          </div>
        </div>
      </section>

      <section className={styles.statsSection} aria-labelledby="stats-heading">
        <h2 id="stats-heading" className="visuallyHidden">Достижения DigitalCover</h2>
        <div className={styles.statsGrid}>
          {statsData.map((stat, index) => (
            <article key={stat.label} className={styles.statCard}>
              <span className={styles.statValue}>
                {animatedStats[index]}
                {animatedStats[index] >= stat.value ? stat.suffix : ''}
              </span>
              <p className={styles.statLabel}>{stat.label}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="advantages-heading">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Преимущества</span>
          <h2 id="advantages-heading" className={styles.sectionTitle}>Почему авторы выбирают DigitalCover</h2>
          <p className={styles.sectionDescription}>
            Мы создаём инструменты, которые помогают развиваться быстрее: от готовых шаблонов до кастомных пакетов с поддержкой команды дизайнеров.
          </p>
        </div>
        <div className={styles.advantagesGrid}>
          {advantages.map((advantage) => (
            <article key={advantage.title} className={styles.advantageCard}>
              <span className={styles.advantageIcon} aria-hidden="true">{advantage.icon}</span>
              <h3>{advantage.title}</h3>
              <p>{advantage.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="categories-heading">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Категории</span>
          <h2 id="categories-heading" className={styles.sectionTitle}>Популярные решения для вашего контента</h2>
        </div>
        <div className={styles.categoriesGrid}>
          {categories.map((category) => (
            <article key={category.title} className={styles.categoryCard}>
              <img src={category.image} alt={category.title} />
              <div className={styles.categoryBody}>
                <h3>{category.title}</h3>
                <p>{category.description}</p>
                <Link to={category.link} className={styles.link}>
                  Смотреть коллекцию →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="gallery-heading">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Проекты</span>
          <h2 id="gallery-heading" className={styles.sectionTitle}>Примеры реализованных макетов</h2>
          <div className={styles.filterGroup} role="group" aria-label="Фильтр галереи">
            <button
              type="button"
              onClick={() => setActiveFilter('all')}
              className={activeFilter === 'all' ? `${styles.filterButton} ${styles.filterActive}` : styles.filterButton}
            >
              Все
            </button>
            <button
              type="button"
              onClick={() => setActiveFilter('covers')}
              className={activeFilter === 'covers' ? `${styles.filterButton} ${styles.filterActive}` : styles.filterButton}
            >
              Обложки
            </button>
            <button
              type="button"
              onClick={() => setActiveFilter('avatars')}
              className={activeFilter === 'avatars' ? `${styles.filterButton} ${styles.filterActive}` : styles.filterButton}
            >
              Аватарки
            </button>
            <button
              type="button"
              onClick={() => setActiveFilter('templates')}
              className={activeFilter === 'templates' ? `${styles.filterButton} ${styles.filterActive}` : styles.filterButton}
            >
              Шаблоны
            </button>
          </div>
        </div>
        <div className={styles.galleryGrid}>
          {filteredGallery.map((item) => (
            <figure key={item.id} className={styles.galleryItem}>
              <img src={item.image} alt={item.title} loading="lazy" />
              <figcaption>{item.title}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="process-heading">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Как это работает</span>
          <h2 id="process-heading" className={styles.sectionTitle}>От идеи до готового визуала в четыре шага</h2>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <article key={step.title} className={styles.processCard}>
              <span className={styles.processIcon} aria-hidden="true">{step.icon}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </article>
          ))}
        </div>
        <div className={styles.processCTA}>
          <Link to="/how-it-works" className={styles.ctaSecondary}>Подробнее о процессе</Link>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="testimonials-heading">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Отзывы</span>
          <h2 id="testimonials-heading" className={styles.sectionTitle}>Что говорят наши клиенты</h2>
          <p className={styles.sectionDescription}>
            Мы строим долгосрочные отношения с авторами каналов, студиями продакшена и командами SMM. Вот что они отмечают.
          </p>
        </div>
        <div className={styles.testimonialsGrid}>
          {testimonials.map((testimonial) => (
            <article key={testimonial.name} className={styles.testimonialCard}>
              <img src={testimonial.avatar} alt={`Отзыв от ${testimonial.name}`} />
              <blockquote>“{testimonial.quote}”</blockquote>
              <p className={styles.testimonialName}>{testimonial.name}</p>
              <span className={styles.testimonialRole}>{testimonial.role}</span>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="faq-heading">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>FAQ</span>
          <h2 id="faq-heading" className={styles.sectionTitle}>Часто задаваемые вопросы</h2>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <article key={item.question} className={styles.faqItem}>
              <button
                type="button"
                className={styles.faqQuestion}
                onClick={() => setExpandedFaq((prev) => (prev === index ? null : index)))
                aria-expanded={expandedFaq === index}
              >
                {item.question}
                <span aria-hidden="true">{expandedFaq === index ? '−' : '+'}</span>
              </button>
              {expandedFaq === index && (
                <p className={styles.faqAnswer}>{item.answer}</p>
              )}
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section} aria-labelledby="blog-heading">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Блог</span>
          <h2 id="blog-heading" className={styles.sectionTitle}>Инсайты и свежие идеи</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <img src={post.image} alt={post.title} loading="lazy" />
              <div className={styles.blogBody}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <Link to={post.link} className={styles.link}>
                  Читать →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection} aria-labelledby="cta-heading">
        <div className={styles.ctaContent}>
          <h2 id="cta-heading">Готовы усилить свой бренд?</h2>
          <p>Выберите готовый шаблон или оставьте заявку на персональный дизайн. DigitalCover поможет собрать визуальную экосистему вашего проекта.</p>
          <div className={styles.ctaActions}>
            <Link to="/templates" className={styles.ctaPrimary}>Открыть шаблоны</Link>
            <Link to="/contacts" className={styles.ctaSecondary}>Связаться с нами</Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;