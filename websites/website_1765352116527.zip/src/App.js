import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Covers from './pages/Covers';
import Avatars from './pages/Avatars';
import Templates from './pages/Templates';
import Services from './pages/Services';
import HowItWorks from './pages/HowItWorks';
import Contacts from './pages/Contacts';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import styles from './App.module.css';

const App = () => (
  <div className={styles.app}>
    <ScrollToTop />
    <Header />
    <main className={styles.main} role="main">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/covers" element={<Covers />} />
        <Route path="/avatars" element={<Avatars />} />
        <Route path="/templates" element={<Templates />} />
        <Route path="/services" element={<Services />} />
        <Route path="/about" element={<About />} />
        <Route path="/how-it-works" element={<HowItWorks />} />
        <Route path="/contacts" element={<Contacts />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/cookie-policy" element={<CookiePolicy />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
  </div>
);

export default App;