document.addEventListener("DOMContentLoaded", function () {
    const banner = document.querySelector(".cookie-banner");
    if (!banner) {
        return;
    }

    const storedChoice = localStorage.getItem("racerbbvnCookieChoice");
    if (storedChoice) {
        banner.classList.add("is-hidden");
        return;
    }

    const buttons = banner.querySelectorAll("[data-cookie-choice]");
    buttons.forEach((button) => {
        button.addEventListener("click", function () {
            const choice = button.getAttribute("data-cookie-choice");
            localStorage.setItem("racerbbvnCookieChoice", choice);
            banner.classList.add("is-hidden");
        });
    });
});