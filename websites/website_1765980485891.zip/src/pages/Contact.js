import React from 'react';
import styles from './Contacts.module.css';
import usePageMeta from '../hooks/usePageMeta';

const channels = [
  {
    title: 'LinkedIn',
    description: 'Следите за обновлениями и мыслями о дизайне и продукте.',
    link: 'https://www.linkedin.com',
    icon: '💼'
  },
  {
    title: 'Behance',
    description: 'Подборка визуальных концепций и дизайн-экспериментов.',
    link: 'https://www.behance.net',
    icon: '🎨'
  },
  {
    title: 'Dribbble',
    description: 'Микро-анимации, интерфейсы и тренды.',
    link: 'https://dribbble.com',
    icon: '🏀'
  }
];

function ContactsPage() {
  usePageMeta(
    'Контакты Valentor Amicado — обсудить проект',
    'Свяжитесь с Valentor Amicado через контактную форму, чтобы обсудить дизайн, стратегию и запуск цифрового продукта.'
  );

  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    message: ''
  });
  const [errors, setErrors] = React.useState({});
  const [status, setStatus] = React.useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, представьтесь.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите email для обратной связи.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Похоже, адрес указан неверно.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Расскажите чуть подробнее о задаче.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }

    console.log('Contact form submission:', formData);
    setStatus('Спасибо! Сообщение отправлено. Я свяжусь с вами в ближайшее время.');
    setFormData({ name: '', email: '', message: '' });
    setErrors({});
    setTimeout(() => setStatus(''), 6000);
  };

  return (
    <div className={styles.page}>
      <section className={styles.intro}>
        <div className="container">
          <h1>Связаться со мной</h1>
          <p>
            Поделитесь идеей, запросом или вопросом — и мы обсудим, как сделать ваш продукт более человечным и убедительным.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Имя</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Как к вам обращаться?"
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="name@example.com"
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="message">Сообщение</label>
                <textarea
                  id="message"
                  name="message"
                  rows="6"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Кратко опишите задачу или идею."
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>

              <button type="submit" className="button button-primary">
                Отправить сообщение
              </button>
              {status && <p className={styles.success}>{status}</p>}
            </form>

            <aside className={styles.infoPanel}>
              <h2>Где меня найти</h2>
              <p>
                Удобнее всего начать с письма или сообщения в соцсетях. Подготовлю ответ в течение 1-2 рабочих дней.
              </p>
              <div className={styles.channels}>
                {channels.map((channel) => (
                  <a
                    key={channel.title}
                    href={channel.link}
                    className={styles.channelCard}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <span className={styles.channelIcon} aria-hidden="true">{channel.icon}</span>
                    <div>
                      <h3>{channel.title}</h3>
                      <p>{channel.description}</p>
                    </div>
                  </a>
                ))}
              </div>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
}

export default ContactsPage;