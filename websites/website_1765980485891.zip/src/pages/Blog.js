import React from 'react';
import styles from './Blog.module.css';
import usePageMeta from '../hooks/usePageMeta';

const posts = [
  {
    title: 'Как выстроить дизайн-систему, которая действительно работает',
    date: '05 марта 2024',
    category: 'Дизайн-процессы',
    excerpt: 'Делю дизайн-систему на стратегический, операционный и визуальный уровни. Показываю, как настроить ритм обновлений и вовлечь команду.',
    readTime: '8 минут'
  },
  {
    title: 'Методы сторителлинга для цифровых продуктов',
    date: '18 февраля 2024',
    category: 'Контент и нарратив',
    excerpt: 'Разбираю инструменты сторителлинга, которые помогают объяснить сложные сценарии и сохранять единую тональность в продукте.',
    readTime: '6 минут'
  },
  {
    title: 'UX-исследования без больших бюджетов',
    date: '29 января 2024',
    category: 'Исследования',
    excerpt: 'Какие методы Discovery-интервью и быстрых тестов работают в стартапах, и как документировать результаты так, чтобы команда ими пользовалась.',
    readTime: '7 минут'
  },
  {
    title: 'Как фасилитировать стратегическую сессию',
    date: '14 декабря 2023',
    category: 'Командные практики',
    excerpt: 'Поделился сценариями фасилитации, картами эмпатии и методами, которые помогают команде договариваться и принимать решения.',
    readTime: '9 минут'
  }
];

function BlogPage() {
  usePageMeta(
    'Блог Valentor Amicado — дизайн, исследования, стратегия',
    'Статьи Valentor Amicado о дизайне цифровых продуктов, исследовательских практиках и сторителлинге.'
  );

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <span className={styles.badge}>Блог</span>
          <h1>Мысли о дизайне, исследованиях и человеческих продуктах</h1>
          <p>
            Делюсь наблюдениями, методами и практиками, которые помогают создавать дружелюбные цифровые сервисы.
            Каждая статья — это приглашение к диалогу и обмену опытом.
          </p>
        </div>
      </section>

      <section className="container">
        <div className={styles.postsGrid}>
          {posts.map((post) => (
            <article key={post.title} className={styles.postCard}>
              <p className={styles.meta}>{post.category} · {post.date} · {post.readTime}</p>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <a href="#!" className={styles.readLink} onClick={(e) => e.preventDefault()}>
                Материал готовится к публикации →
              </a>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}

export default BlogPage;