import React from 'react';
import styles from './About.module.css';
import usePageMeta from '../hooks/usePageMeta';

const milestones = [
  {
    year: '2024',
    title: 'Valentor Amicado Studio',
    description: 'Запустил независимую практику, где объединяю дизайнеров, исследователей и авторов вокруг сложных задач.'
  },
  {
    year: '2021',
    title: 'Design Lead в международной edtech-компании',
    description: 'Руководил распределённой командой, создавая глобальную платформу обучения с уникальным тоном общения.'
  },
  {
    year: '2018',
    title: 'Product Designer',
    description: 'Работал над мобильными сервисами, внедряя UX-исследования и дизайн-системы на ранней стадии.'
  },
  {
    year: '2016',
    title: 'Стартап-путь',
    description: 'Начал карьеру в стартапах, экспериментируя с digital storytelling и визуальными идентичностями.'
  }
];

const values = [
  {
    title: 'Человечность в технологиях',
    description: 'Я стремлюсь, чтобы продукты говорили простым языком и создавали ощущение заботы.'
  },
  {
    title: 'Прозрачные процессы',
    description: 'Делаю работу понятной: общие декы, открытые канбан-доски, регулярные синки и ретроспективы.'
  },
  {
    title: 'Красота деталей',
    description: 'Люблю, когда за формой стоит смысл. Продумываю микро-взаимодействия, шрифты и движение.'
  }
];

const team = [
  {
    name: 'Леона Вэй',
    role: 'Креативный стратег',
    avatar: 'https://picsum.photos/seed/valentor-team1/420/420'
  },
  {
    name: 'Матео Лопес',
    role: 'UX-исследователь',
    avatar: 'https://picsum.photos/seed/valentor-team2/420/420'
  },
  {
    name: 'София Чернова',
    role: 'Иллюстратор и motion-дизайнер',
    avatar: 'https://picsum.photos/seed/valentor-team3/420/420'
  }
];

function AboutPage() {
  usePageMeta(
    'О Valentor Amicado — дизайнер и стратег цифровых продуктов',
    'Узнайте больше о подходе Valentor Amicado: опыт, ценности, команда и история становления.'
  );

  return (
    <div className={styles.page}>
      <section className={styles.intro}>
        <div className="container">
          <span className={styles.badge}>Обо мне</span>
          <h1>Соединяю смысл, эстетику и методологию</h1>
          <p>
            Меня зовут Valentor Amicado. Я верю, что дизайн — это язык доверия, а стратегия — карта,
            которая ведёт продукт к людям. Работаю с компаниями, ищущими глубину, и с людьми, которым нужен
            сопровождённый путь от идеи до запуска.
          </p>
        </div>
      </section>

      <section className={`${styles.mission} container`}>
        <div className={styles.missionText}>
          <h2>Миссия</h2>
          <p>
            Помогаю цифровым продуктам разговаривать с пользователями на одном языке. Для этого погружаюсь в контекст,
            слушаю людей, исследую рынки и формирую визуальный код, который отражает характер бренда.
            Мне интересно работать с командами, которые не боятся экспериментировать и ценят осознанность.
          </p>
        </div>
        <div className={styles.missionImage}>
          <img
            src="https://picsum.photos/seed/valentor-about/520/520"
            alt="Рабочее пространство Valentor Amicado"
            loading="lazy"
          />
        </div>
      </section>

      <section className={`${styles.timeline} container`}>
        <h2>Маршрут</h2>
        <div className={styles.timelineList}>
          {milestones.map((milestone) => (
            <article key={milestone.year} className={styles.timelineItem}>
              <span className={styles.year}>{milestone.year}</span>
              <div>
                <h3>{milestone.title}</h3>
                <p>{milestone.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.values} container`}>
        <h2>Ценности</h2>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <h2>Партнёрская команда</h2>
          <p className={styles.teamIntro}>
            В проектах я сотрудничаю с проверенными экспертами. Мы быстро собираем agile-команды,
            объединяя стратегию, UX, визуал и разработку.
          </p>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.avatar} alt={member.name} loading="lazy" />
                <h3>{member.name}</h3>
                <p>{member.role}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default AboutPage;