import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Portfolio.module.css';
import usePageMeta from '../hooks/usePageMeta';

const projects = [
  {
    title: 'Aurora Wellness Platform',
    description: 'Создал мультиканальную платформу заботы о психическом здоровье. Разработал карту пользовательских сценариев и язык бренда.',
    result: 'Рост вовлечённости пользователей на 42% за первые три месяца.',
    image: 'https://picsum.photos/seed/valentor-case1/720/500',
    tags: ['UX strategy', 'Бренд-платформа', 'Design System']
  },
  {
    title: 'Nova Learning Hub',
    description: 'Запустил образовательную среду с адаптивным контентом. Настроил дизайн-команду и внедрил календарь исследований.',
    result: 'Сократилось время выхода новых курсов с 8 до 3 недель.',
    image: 'https://picsum.photos/seed/valentor-case2/720/500',
    tags: ['EdTech', 'Product Design', 'UX Research']
  },
  {
    title: 'Lumen City Guide',
    description: 'Создал мобильный гид с персональными рекомендациями. Прототипировал AR-функции и разработал визуальный язык города.',
    result: 'Средний рейтинг приложения вырос до 4.8 в App Store.',
    image: 'https://picsum.photos/seed/valentor-case3/720/500',
    tags: ['Mobile UX', 'Motion', 'Storytelling']
  },
  {
    title: 'Sphere Collaboration Tool',
    description: 'Инструмент для гибридных команд. Настроил дизайн-систему, создал систему onboarding и карту ролей.',
    result: 'Показатель активации новых пользователей увеличился на 35%.',
    image: 'https://picsum.photos/seed/valentor-case4/720/500',
    tags: ['B2B SaaS', 'Design Ops', 'Product Discovery']
  }
];

function PortfolioPage() {
  usePageMeta(
    'Портфолио Valentor Amicado — цифровые продукты и дизайн-системы',
    'Проекты Valentor Amicado: дизайн цифровых сервисов, продуктовая стратегия, дизайн-системы и работа с командами.'
  );

  return (
    <div className={styles.page}>
      <section className={styles.intro}>
        <div className="container">
          <h1>Портфолио и кейсы</h1>
          <p>
            От стратегических сессий и UX-исследований до финального визуального языка — я беру на себя полную
            ответственность за качество и смысл продукта. Ниже — подборка проектов, которые особенно дороги.
          </p>
        </div>
      </section>

      <section className={`container ${styles.projects}`}>
        {projects.map((project) => (
          <article key={project.title} className={styles.projectCard}>
            <div className={styles.projectImage}>
              <img src={project.image} alt={project.title} loading="lazy" />
            </div>
            <div className={styles.projectContent}>
              <h2>{project.title}</h2>
              <p>{project.description}</p>
              <div className={styles.result}>
                <strong>Результат:</strong>
                <span>{project.result}</span>
              </div>
              <ul className={styles.tags}>
                {project.tags.map((tag) => (
                  <li key={tag}>{tag}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.footerCta}>
        <div className="container">
          <h2>Хотите увидеть полный список проектов?</h2>
          <p>
            Расскажу о релевантных кейсах и подготовлю кастомную подборку специально под ваш запрос.
          </p>
          <Link to="/contacts" className="button button-primary">
            Запросить консультацию
          </Link>
        </div>
      </section>
    </div>
  );
}

export default PortfolioPage;