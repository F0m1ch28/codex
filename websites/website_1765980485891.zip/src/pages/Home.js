import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';
import usePageMeta from '../hooks/usePageMeta';

const services = [
  {
    title: 'Дизайн цифрового опыта',
    description: 'Создаю цельные интерфейсы, которые соединяют эмоции и аналитику, помогая пользователю чувствовать себя уверенно.',
    icon: '🎨'
  },
  {
    title: 'Стратегия продукта',
    description: 'Исследую аудиторию и формирую стратегию развития, чтобы проекты росли органично и приносили пользу.',
    icon: '🧭'
  },
  {
    title: 'Дизайн-системы',
    description: 'Настраиваю живые библиотеки компонентов и процессов, чтобы команда могла быстро масштабироваться без потери качества.',
    icon: '🧩'
  },
  {
    title: 'Фронтенд-поддержка',
    description: 'Воплощаю дизайн в React, забочусь о производительности, доступности и чистом коде.',
    icon: '⚛️'
  }
];

const projects = [
  {
    title: 'Aurora Wellness Platform',
    description: 'Экосистема для поддержки mental health специалистов. Разработал нарратив бренда и выстроил продуктовую карту.',
    image: 'https://picsum.photos/seed/valentor-project1/640/420',
    link: '/portfolio'
  },
  {
    title: 'Nova Learning Hub',
    description: 'Образовательная платформа нового поколения с интерактивными сценариями и визуальной идентичностью.',
    image: 'https://picsum.photos/seed/valentor-project2/640/420',
    link: '/portfolio'
  },
  {
    title: 'Lumen City Guide',
    description: 'Мобильный гид по городу с персональными рекомендациями. Настроил дизайн-систему и UX-аналитику.',
    image: 'https://picsum.photos/seed/valentor-project3/640/420',
    link: '/portfolio'
  }
];

const testimonials = [
  {
    quote: 'Valentor раскрыл потенциал команды, выстроил процесс и помог увидеть продукт глазами клиента. С этим подходом мы ускорили релиз на три месяца.',
    name: 'Елизавета Соколова',
    company: 'Aurora Wellness',
    avatar: 'https://picsum.photos/seed/valentor-client1/120/120'
  },
  {
    quote: 'Его дизайн-система стала каркасом всей нашей платформы. Взаимодействие с разработкой и маркетингом оказалось безупречным.',
    name: 'Ираклий Мцква',
    company: 'Nova Learning',
    avatar: 'https://picsum.photos/seed/valentor-client2/120/120'
  },
  {
    quote: 'Редко встречается такое сочетание стратегического мышления и способности глубоко чувствовать аудиторию. Valentor умеет создавать истории.',
    name: 'Марина Дашкевич',
    company: 'Storydive Agency',
    avatar: 'https://picsum.photos/seed/valentor-client3/120/120'
  }
];

const blogPosts = [
  {
    title: 'Как выстроить дизайн-систему, которая действительно работает',
    description: 'Мой опыт внедрения динамической дизайн-системы в распределённой команде и набор проверенных ритуалов.',
    date: '05 марта 2024',
    category: 'Дизайн-процессы'
  },
  {
    title: 'Методы сторителлинга для цифровых продуктов',
    description: 'Пять инструментов, которые помогают превратить сложную функциональность в ясные сценарии и эмоции.',
    date: '18 февраля 2024',
    category: 'Контент и нарратив'
  },
  {
    title: 'UX-исследования без больших бюджетов',
    description: 'Поделиться методами, которые позволяют быстро получать инсайты и проверять гипотезы без давления времени.',
    date: '29 января 2024',
    category: 'Исследования'
  }
];

const toolkit = [
  'Product Discovery',
  'UX/UI дизайн',
  'Design Ops',
  'Фасилитация воркшопов',
  'React + TypeScript',
  'Service Design'
];

const stats = [
  { label: 'лет практики', value: '8+' },
  { label: 'запущенных продуктов', value: '36' },
  { label: 'стран аудитории', value: '12' }
];

function HomePage() {
  usePageMeta(
    'Valentor Amicado — дизайнер цифровых продуктов и стратег',
    'Портфолио Valentor Amicado: дизайн цифровых сервисов, стратегия, дизайн-системы и создание смысла для брендов.'
  );

  return (
    <div className={styles.page}>
      <section className={`${styles.hero} container`}>
        <div className={styles.heroContent}>
          <span className={styles.badge}>Создаю цифровые истории, которые запоминаются</span>
          <h1>Valentor Amicado — дизайн, стратегия и смысл для людей и компаний</h1>
          <p>
            Я помогаю продуктам звучать ярко и честно. От идеи до реализации — выстраиваю путь пользователя,
            архитектуру бренда и визуальный язык, сохраняя человеческое лицо технологии.
          </p>
          <div className={styles.heroActions}>
            <Link to="/portfolio" className="button button-primary">
              Посмотреть портфолио
            </Link>
            <Link to="/contacts" className="button button-secondary">
              Обсудить проект
            </Link>
          </div>
          <div className={styles.stats}>
            {stats.map((stat) => (
              <div key={stat.label} className={styles.statCard}>
                <span>{stat.value}</span>
                <p>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://picsum.photos/seed/valentor-hero/640/640"
            alt="Коллаж проектов Valentor Amicado"
            loading="lazy"
          />
        </div>
      </section>

      <section className={`${styles.aboutPreview} container`}>
        <div className={styles.aboutWrapper}>
          <div className={styles.aboutText}>
            <h2>Обо мне в двух словах</h2>
            <p>
              Работаю на стыке дизайна, продуктовой стратегии и сторителлинга. Веду discovery-интервью,
              формирую видение и сопровождаю команды от гипотез до масштабирования. Мне важно, чтобы продукты
              были понятными, эстетичными и полезными.
            </p>
            <Link to="/about" className="button button-secondary">
              Читать подробнее
            </Link>
          </div>
          <div className={styles.toolkit}>
            <h3>Мой инструментарий</h3>
            <ul>
              {toolkit.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className={`${styles.services} container`}>
        <div className={styles.sectionHeader}>
          <h2>Направления работы</h2>
          <p>
            Каждый проект — это диалог. Я внимательно слушаю, исследую и собираю команду вокруг ясной цели.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">{service.icon}</span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.projects} container`}>
        <div className={styles.sectionHeader}>
          <h2>Избранные проекты</h2>
          <p>
            Подборка кейсов, где удалось объединить стратегию, визуальную культуру и технологическую составляющую.
          </p>
        </div>
        <div className={styles.projectsGrid}>
          {projects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <div className={styles.projectImage}>
                <img src={project.image} alt={project.title} loading="lazy" />
              </div>
              <div className={styles.projectContent}>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <Link to={project.link} className={styles.projectLink}>
                  Подробнее в портфолио →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Отзывы партнёров</h2>
            <p>Несколько тёплых слов от людей, с которыми мы создавали смелые продукты.</p>
          </div>
          <div className={styles.testimonialsGrid}>
            {testimonials.map((testimonial) => (
              <figure key={testimonial.name} className={styles.testimonial}>
                <img src={testimonial.avatar} alt={testimonial.name} loading="lazy" />
                <blockquote>“{testimonial.quote}”</blockquote>
                <figcaption>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.company}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.blog} container`}>
        <div className={styles.sectionHeader}>
          <h2>Последние статьи</h2>
          <p>Пишу о дизайне, исследованиях и том, как продукты становятся ближе к людям.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <p className={styles.blogMeta}>{post.category} · {post.date}</p>
              <h3>{post.title}</h3>
              <p>{post.description}</p>
              <Link to="/blog" className={styles.blogLink}>
                Читать статью →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Готовы обсудить идею или продукт?</h2>
            <p>
              Расскажите, что хотите изменить или создать — я помогу структурировать запрос, предложу сценарии
              и сформирую дорожную карту.
            </p>
            <Link to="/contacts" className="button button-primary">
              Заполнить форму
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

export default HomePage;