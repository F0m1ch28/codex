import React from 'react';
import styles from './CookiePolicy.module.css';
import usePageMeta from '../hooks/usePageMeta';

function CookiePolicyPage() {
  usePageMeta(
    'Политика использования файлов cookie — Valentor Amicado',
    'Информация о том, как сайт Valentor Amicado использует файлы cookie.'
  );

  return (
    <div className={`${styles.page} container`}>
      <h1>Политика использования файлов cookie</h1>
      <p>Последнее обновление: 10 марта 2024 года</p>

      <section>
        <h2>1. Что такое cookie</h2>
        <p>
          Cookie — это небольшие текстовые файлы, которые сохраняются на вашем устройстве и помогают нам анализировать
          взаимодействие с сайтом, а также делать интерфейс более удобным.
        </p>
      </section>

      <section>
        <h2>2. Какие cookie применяются</h2>
        <ul>
          <li><strong>Аналитические:</strong> помогают понять, какие страницы интересуют пользователей больше всего.</li>
          <li><strong>Функциональные:</strong> запоминают выбранные вами настройки (например, согласие с баннером).</li>
        </ul>
      </section>

      <section>
        <h2>3. Управление cookie</h2>
        <p>
          Вы можете удалить или ограничить использование cookie через настройки браузера. Обратите внимание,
          что это может повлиять на корректную работу некоторых элементов Сайта.
        </p>
      </section>

      <section>
        <h2>4. Обновления политики</h2>
        <p>
          Политика может изменяться. Изменения вступают в силу после публикации на этой странице.
        </p>
      </section>
    </div>
  );
}

export default CookiePolicyPage;