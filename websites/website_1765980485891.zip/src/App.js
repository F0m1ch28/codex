import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import PortfolioPage from './pages/Services';
import ContactsPage from './pages/Contact';
import TermsPage from './pages/TermsOfService';
import PrivacyPage from './pages/PrivacyPolicy';
import BlogPage from './pages/Blog';
import CookiePolicyPage from './pages/CookiePolicy';

function ScrollToTopOnRoute() {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: 'instant' in window ? 'instant' : 'auto'
    });
  }, [pathname]);

  return null;
}

function App() {
  return (
    <div className="app">
      <Header />
      <ScrollToTopOnRoute />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/portfolio" element={<PortfolioPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/contacts" element={<ContactsPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/cookie-policy" element={<CookiePolicyPage />} />
          <Route path="*" element={<HomePage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;