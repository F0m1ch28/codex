import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.grid}`}>
        <div className={styles.brand}>
          <Link to="/" className={styles.logo}>
            Valentor Amicado
          </Link>
          <p className={styles.description}>
            Помогаю брендам и людям находить ясность в цифровых продуктах, объединяя стратегию, дизайн и технологии.
          </p>
        </div>

        <div className={styles.column}>
          <h4>Навигация</h4>
          <ul>
            <li><Link to="/about">Обо мне</Link></li>
            <li><Link to="/portfolio">Портфолио</Link></li>
            <li><Link to="/blog">Блог</Link></li>
            <li><Link to="/contacts">Контакты</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4>Юридическая информация</h4>
          <ul>
            <li><Link to="/terms">Условия использования</Link></li>
            <li><Link to="/privacy">Политика конфиденциальности</Link></li>
            <li><Link to="/cookie-policy">Политика cookies</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4>Соцсети</h4>
          <ul className={styles.socials}>
            <li><a href="https://www.linkedin.com" target="_blank" rel="noreferrer">LinkedIn</a></li>
            <li><a href="https://www.behance.net" target="_blank" rel="noreferrer">Behance</a></li>
            <li><a href="https://dribbble.com" target="_blank" rel="noreferrer">Dribbble</a></li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {year} Valentor Amicado. Все права защищены.</p>
        <a className={styles.toTopLink} href="#top" onClick={(e) => e.preventDefault()}>
          Вернуться наверх
        </a>
      </div>
    </footer>
  );
}

export default Footer;