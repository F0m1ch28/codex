import React from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'valentor_cookie_consent';

function CookieBanner() {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(COOKIE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        Продолжая пользоваться сайтом, вы соглашаетесь на использование файлов cookie для анализа и персонализации контента.
      </p>
      <button type="button" className="button button-primary" onClick={acceptCookies}>
        Принять
      </button>
    </div>
  );
}

export default CookieBanner;