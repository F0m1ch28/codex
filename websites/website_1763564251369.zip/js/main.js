(function () {
  const body = document.body;
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  const navLinks = document.querySelectorAll(".site-nav a[data-page]");
  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector("[data-cookie-accept]");
  const declineBtn = document.querySelector("[data-cookie-decline]");
  const contactForm = document.querySelector("#contact-form");

  const STORAGE_KEY = "apexedge-cookie-preference";

  // Set current year in footer
  const yearEl = document.getElementById("current-year");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  // Mobile navigation toggle
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
      if (isOpen) {
        body.style.overflow = "hidden";
      } else {
        body.style.overflow = "";
      }
    });

    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        if (nav.classList.contains("open")) {
          nav.classList.remove("open");
          navToggle.setAttribute("aria-expanded", "false");
          body.style.overflow = "";
        }
      });
    });
  }

  // Highlight active nav link based on body class
  const pageClass = Array.from(body.classList).find((cls) => cls.startsWith("page-"));
  if (pageClass) {
    const currentPage = pageClass.replace("page-", "");
    navLinks.forEach((link) => {
      if (link.dataset.page === currentPage) {
        link.classList.add("active");
      }
    });
  }

  // Smooth scroll for same-page anchors
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", (event) => {
      const targetId = anchor.getAttribute("href");
      const targetEl = document.querySelector(targetId);
      if (targetEl) {
        event.preventDefault();
        targetEl.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });
  });

  // Cookie banner logic
  function showCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add("show");
    }
  }

  function hideCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove("show");
    }
  }

  function setCookiePreference(value) {
    localStorage.setItem(STORAGE_KEY, value);
  }

  function getCookiePreference() {
    return localStorage.getItem(STORAGE_KEY);
  }

  if (cookieBanner) {
    const pref = getCookiePreference();
    if (!pref) {
      setTimeout(showCookieBanner, 600);
    }

    acceptBtn?.addEventListener("click", () => {
      setCookiePreference("accepted");
      hideCookieBanner();
    });

    declineBtn?.addEventListener("click", () => {
      setCookiePreference("declined");
      hideCookieBanner();
    });
  }

  // FAQ accordion
  document.querySelectorAll(".faq-question").forEach((btn) => {
    btn.addEventListener("click", () => {
      const expanded = btn.getAttribute("aria-expanded") === "true";
      btn.setAttribute("aria-expanded", String(!expanded));
    });
  });

  // Contact form validation
  if (contactForm) {
    const feedbackEl = contactForm.querySelector(".form-feedback");
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      let formValid = true;

      contactForm.querySelectorAll(".field-error").forEach((el) => (el.textContent = ""));
      feedbackEl.textContent = "";

      const requiredFields = ["name", "email", "message", "consent"];
      requiredFields.forEach((field) => {
        const input = contactForm.elements[field];
        const errorEl = input?.closest(".form-field, .form-consent")?.querySelector(".field-error");
        if (input) {
          if ((input.type === "checkbox" && !input.checked) || (input.type !== "checkbox" && !input.value.trim())) {
            formValid = false;
            if (errorEl) errorEl.textContent = "This field is required.";
          } else if (input.type === "email" && !/^\S+@\S+\.\S+$/.test(input.value)) {
            formValid = false;
            if (errorEl) errorEl.textContent = "Enter a valid email address.";
          }
        }
      });

      if (formValid) {
        feedbackEl.textContent = "Thank you! Your message has been submitted.";
        feedbackEl.style.color = "#16a34a";
        contactForm.reset();
      } else {
        feedbackEl.textContent = "Please fix the highlighted fields.";
        feedbackEl.style.color = "#dc2626";
      }
    });
  }
})();