"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  const navLinks = document.querySelectorAll(".nav-link");
  const header = document.querySelector(".site-header");
  const sections = document.querySelectorAll("main section[id]");
  const cookieBanner = document.getElementById("cookie-banner");
  const yearSpan = document.getElementById("year");
  const newsletterForms = document.querySelectorAll(".newsletter-form");
  const faqButtons = document.querySelectorAll(".faq-question");
  const testimonialSlider = document.querySelector(".testimonial-slider");
  const testimonialCards = document.querySelectorAll(".testimonial-card");
  const testimonialPrev = document.querySelector(".testimonial-nav.prev");
  const testimonialNext = document.querySelector(".testimonial-nav.next");

  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  // Mobile navigation toggle
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!expanded).toString());
      nav.classList.toggle("is-open");
    });

    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        if (nav.classList.contains("is-open")) {
          nav.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  // Active navigation highlighting
  if (sections.length) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const id = entry.target.getAttribute("id");
          const link = document.querySelector(`.nav-link[href="#${id}"]`);
          if (entry.isIntersecting) {
            document.querySelectorAll(".nav-link.active").forEach((activeLink) => activeLink.classList.remove("active"));
            if (link) {
              link.classList.add("active");
            }
          }
        });
      },
      {
        rootMargin: "-50% 0px -40% 0px",
        threshold: [0.25, 0.5, 0.75]
      }
    );
    sections.forEach((section) => observer.observe(section));
  }

  // Newsletter form validation
  if (newsletterForms.length) {
    newsletterForms.forEach((form) => {
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        const emailInput = form.querySelector('input[type="email"]');
        const feedback = form.querySelector(".form-feedback");
        if (!emailInput) return;

        const email = emailInput.value.trim();
        const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

        if (!isValid) {
          if (feedback) {
            feedback.textContent = "Please enter a valid email address.";
            feedback.classList.add("error");
            feedback.classList.remove("success");
          }
          emailInput.focus();
          return;
        }

        if (feedback) {
          feedback.textContent = "Thank you for subscribing. Check your inbox for confirmation.";
          feedback.classList.remove("error");
          feedback.classList.add("success");
        }
        emailInput.value = "";
      });
    });
  }

  // FAQ accordion
  faqButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const expanded = button.getAttribute("aria-expanded") === "true";
      const targetId = button.getAttribute("aria-controls");
      const target = document.getElementById(targetId);

      faqButtons.forEach((btn) => {
        const ctrl = btn.getAttribute("aria-controls");
        const content = document.getElementById(ctrl);
        if (content && btn !== button) {
          content.hidden = true;
          btn.setAttribute("aria-expanded", "false");
        }
      });

      button.setAttribute("aria-expanded", (!expanded).toString());
      if (target) {
        target.hidden = expanded;
      }
    });
  });

  // Testimonial slider
  if (testimonialSlider && testimonialCards.length) {
    let currentIndex = 0;

    const updateTestimonials = () => {
      testimonialCards.forEach((card, index) => {
        if (index === currentIndex) {
          card.classList.add("active");
          card.setAttribute("aria-hidden", "false");
        } else {
          card.classList.remove("active");
          card.setAttribute("aria-hidden", "true");
        }
      });
    };

    const showPrev = () => {
      currentIndex = (currentIndex - 1 + testimonialCards.length) % testimonialCards.length;
      updateTestimonials();
    };

    const showNext = () => {
      currentIndex = (currentIndex + 1) % testimonialCards.length;
      updateTestimonials();
    };

    updateTestimonials();

    if (testimonialPrev) testimonialPrev.addEventListener("click", showPrev);
    if (testimonialNext) testimonialNext.addEventListener("click", showNext);

    testimonialSlider.addEventListener("keydown", (event) => {
      if (event.key === "ArrowLeft") {
        showPrev();
      } else if (event.key === "ArrowRight") {
        showNext();
      }
    });
  }

  // Cookie banner
  if (cookieBanner) {
    const storageKey = "devlayer_cookie_consent";

    const hideBanner = () => {
      cookieBanner.setAttribute("hidden", "");
    };

    try {
      const consent = localStorage.getItem(storageKey);
      if (!consent) {
        cookieBanner.removeAttribute("hidden");
      }
    } catch (error) {
      console.error("LocalStorage unavailable:", error);
    }

    cookieBanner.addEventListener("click", (event) => {
      const actionButton = event.target.closest("[data-cookie-action]");
      if (!actionButton) return;
      const action = actionButton.getAttribute("data-cookie-action");
      try {
        localStorage.setItem(storageKey, action);
      } catch (error) {
        console.error("Unable to persist cookie preference:", error);
      }
      hideBanner();
    });
  }
});