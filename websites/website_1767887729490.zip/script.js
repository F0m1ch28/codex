document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.getElementById('navToggle');
    const siteNav = document.getElementById('siteNav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = siteNav.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });
    }

    const banner = document.getElementById('cookieBanner');
    if (banner) {
        const storedPreference = localStorage.getItem('otaheituqf_cookie_consent');
        if (!storedPreference) {
            banner.classList.add('is-visible');
        }

        const buttons = banner.querySelectorAll('[data-cookie-action]');
        buttons.forEach((button) => {
            button.addEventListener('click', () => {
                const action = button.getAttribute('data-cookie-action');
                localStorage.setItem('otaheituqf_cookie_consent', action === 'accept' ? 'accepted' : 'declined');
                banner.classList.remove('is-visible');
            });
        });
    }
});