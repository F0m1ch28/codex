import React, { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : 'auto';
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [menuOpen]);

  return (
    <header className={styles.header}>
      <a className={styles.skipLink} href="#mainContent">
        Skip to main content
      </a>
      <div className={"${styles.inner} container"}>
        <Link to="/" className={styles.logo} aria-label="blhank home">
          <span className={styles.logoMark}>blhank</span>
          <span className={styles.tagline}>Bank Independent</span>
        </Link>
        <button
          className={styles.menuButton}
          type="button"
          aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span className={styles.menuIcon} />
        </button>
        <nav id="primary-navigation" className={"${styles.nav} ${menuOpen ? styles.open : ''}"} aria-label="Primary navigation">
          <ul className={styles.navList}>
            <li>
              <NavLink to="/" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
                Home
              </NavLink>
            </li>
            <li>
              <NavLink to="/about" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
                About
              </NavLink>
            </li>
            <li>
              <NavLink to="/services" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
                Services
              </NavLink>
            </li>
            <li>
              <NavLink to="/cases" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
                Cases
              </NavLink>
            </li>
            <li>
              <NavLink to="/blog" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
                Blog
              </NavLink>
            </li>
            <li>
              <NavLink to="/careers" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
                Careers
              </NavLink>
            </li>
          </ul>
          <div className={styles.navCta}>
            <Link to="/contacts" className={styles.ctaButton}>
              Connect with us
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;