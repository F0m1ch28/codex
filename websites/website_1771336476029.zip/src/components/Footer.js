import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={"${styles.inner} container"}>
        <div className={styles.brandColumn}>
          <h2 className={styles.logo}>blhank</h2>
          <p className={styles.description}>
            blhank, powered by Itech Us Inc, helps community and regional institutions embrace bank independent operations with confidence, clarity, and human-centered technology.
          </p>
          <div className={styles.socials}>
            <a href="https://www.linkedin.com/company/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
              <span aria-hidden="true">in</span>
            </a>
            <a href="https://twitter.com/" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
              <span aria-hidden="true">tw</span>
            </a>
            <a href="https://www.youtube.com/" target="_blank" rel="noopener noreferrer" aria-label="YouTube">
              <span aria-hidden="true">yt</span>
            </a>
          </div>
        </div>
        <div className={styles.linkColumn}>
          <h3>Explore</h3>
          <ul>
            <li><Link to="/about">About</Link></li>
            <li><Link to="/services">Services</Link></li>
            <li><Link to="/cases">Cases</Link></li>
            <li><Link to="/blog">Blog</Link></li>
            <li><Link to="/careers">Careers</Link></li>
          </ul>
        </div>
        <div className={styles.linkColumn}>
          <h3>Support</h3>
          <ul>
            <li><Link to="/privacy-policy">Privacy Policy</Link></li>
            <li><Link to="/terms-conditions">Terms of Use</Link></li>
            <li><Link to="/cookie-policy">Cookie Policy</Link></li>
            <li><Link to="/disclaimer">Disclaimer</Link></li>
            <li><Link to="/contacts">Contact</Link></li>
          </ul>
        </div>
        <div className={styles.contactColumn}>
          <h3>Contact</h3>
          <address>
            Itech Us Inc<br/>
            20 Kimball Ave #303n<br/>
            South Burlington, VT 05403
          </address>
          <Link to="/contacts" className={styles.contactLink}>+1 802-383-1500</Link>
          <Link to="/contacts" className={styles.contactLink}>info@blhank.pro</Link>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© {currentYear} blhank · Bank Independent Solutions crafted in the United States.</p>
      </div>
    </footer>
  );
};

export default Footer;