import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('blhank_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem('blhank_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <p>
        We use cookies to personalize your blhank experience and to better understand how leaders pursue bank independent strategies. By continuing, you agree to our Cookie Policy.
      </p>
      <button type="button" onClick={handleAccept} className={styles.acceptButton}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;