import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const TermsConditionsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms &amp; Conditions | blhank</title>
      <meta name="description" content="Review the terms and conditions for using blhank bank independent services and digital experiences." />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Terms &amp; Conditions</h1>
        <p>Last updated: September 15, 2023</p>
        <p>
          These Terms &amp; Conditions govern your use of the blhank website and any related digital experiences operated by Itech Us Inc. By accessing this site you agree to follow these terms and applicable laws.
        </p>
        <h2>Use of content</h2>
        <p>
          All content is provided for informational purposes to support bank independent strategies. You may reference material with proper attribution, but you may not reproduce, redistribute, or modify content without written permission from Itech Us Inc.
        </p>
        <h2>Acceptable behavior</h2>
        <p>
          You agree not to misuse the site, attempt unauthorized access, or introduce malicious code. We reserve the right to restrict access if misuse is detected.
        </p>
        <h2>Intellectual property</h2>
        <p>
          The blhank brand, logos, and original content belong to Itech Us Inc. These assets may not be used without consent.
        </p>
        <h2>Changes to the terms</h2>
        <p>
          We may update these terms periodically. Continued use after changes means you accept the updated terms.
        </p>
        <h2>Contact</h2>
        <p>
          Questions? Write to info@blhank.pro or visit us at 20 Kimball Ave #303n, South Burlington, VT 05403.
        </p>
      </div>
    </section>
  </div>
);

export const DisclaimerPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Disclaimer | blhank</title>
      <meta name="description" content="Understand the informational nature of blhank content and our limitation of liability." />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Disclaimer</h1>
        <p>Last updated: September 15, 2023</p>
        <p>
          The information on this site is provided for general guidance to support bank independent strategies. It should not be considered legal, accounting, or regulatory advice. Before making decisions, consult qualified professionals familiar with your circumstances.
        </p>
        <p>
          Itech Us Inc makes reasonable efforts to ensure accuracy but does not guarantee completeness. We are not responsible for actions taken based on this content.
        </p>
      </div>
    </section>
  </div>
);

export const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookie Policy | blhank</title>
      <meta name="description" content="Learn how blhank uses cookies to enhance your experience and support bank independent services." />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p>Last updated: September 15, 2023</p>
        <p>
          Cookies help us understand how visitors engage with bank independent content so we can improve relevance and usability.
        </p>
        <h2>Types of cookies</h2>
        <ul>
          <li>Essential cookies keep the site secure and functional.</li>
          <li>Analytics cookies measure usage trends to improve digital experiences.</li>
        </ul>
        <h2>Managing preferences</h2>
        <p>
          You can control cookies through your browser settings. Some features may not function correctly if cookies are disabled.
        </p>
      </div>
    </section>
  </div>
);

export default TermsConditionsPage;