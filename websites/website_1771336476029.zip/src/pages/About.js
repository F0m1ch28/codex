import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const AboutPage = () => {
  const values = [
    {
      title: 'Empathy over ego',
      description: 'We listen first, translate complexity into clarity, and champion the people who will live with the solution every day.',
    },
    {
      title: 'Momentum with discipline',
      description: 'Delivering bank independent outcomes means sequencing change, managing risk, and celebrating measurable progress.',
    },
    {
      title: 'Transparency always',
      description: 'Our clients know the why behind every decision, the metrics we track, and the knowledge we are transferring.',
    },
  ];

  const milestones = [
    { year: '2016', detail: 'Itech Us Inc launched blhank to modernize banking through human-centered technology.' },
    { year: '2018', detail: 'Expanded to cross-functional pods pairing designers, engineers, and former bankers.' },
    { year: '2020', detail: 'Introduced bank independent acceleration labs to help teams prototype in days.' },
    { year: '2022', detail: 'Scaled service coverage across the United States with remote-first delivery.' },
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>About blhank | Itech Us Inc</title>
        <meta
          name="description"
          content="Discover the story, mission, and team behind blhank. Itech Us Inc helps financial institutions lead with bank independent solutions."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>We help institutions think and act bank independent.</h1>
          <p>
            blhank is the strategic arm of Itech Us Inc—a Vermont-based innovation company that exists to serve financial leaders who refuse to be confined by legacy systems or outdated service models.
          </p>
        </div>
      </section>

      <section className={styles.office}>
        <div className="container">
          <div className={styles.officeGrid}>
            <img src="https://picsum.photos/id/1032/900/650" alt="blhank office space in South Burlington" loading="lazy" />
            <div className={styles.officeContent}>
              <h2>Our home base in South Burlington, Vermont</h2>
              <p>
                From 20 Kimball Ave #303n, the blhank team coordinates nationwide engagements while staying rooted in a collaborative studio environment. We bring together strategists, analysts, engineers, and experience designers under one roof (and through remote hubs) to accelerate decision-making.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2>Values that guide every engagement</h2>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <div key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.teamGrid}>
            <div className={styles.teamText}>
              <h2>Meet the leaders</h2>
              <p>
                Our leadership blends decades of financial industry operations with modern product delivery. We are mentors, builders, and partners who bring humility and clarity to complex initiatives.
              </p>
            </div>
            <div className={styles.teamImages}>
              <img src="https://picsum.photos/id/1052/600/500" alt="blhank team collaborating" loading="lazy" />
              <img src="https://picsum.photos/id/1049/600/500" alt="blhank leadership portrait" loading="lazy" />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.milestones}>
        <div className="container">
          <h2>Moments that shaped blhank</h2>
          <ul className={styles.timeline}>
            {milestones.map((milestone) => (
              <li key={milestone.year}>
                <span className={styles.year}>{milestone.year}</span>
                <p>{milestone.detail}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <h2>Our mission</h2>
          <p>
            Empower every financial institution in the United States to pursue bank independent growth with confidence. We do this by aligning teams around purpose, building modern capabilities, and transferring knowledge so value continues long after we leave the room.
          </p>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;