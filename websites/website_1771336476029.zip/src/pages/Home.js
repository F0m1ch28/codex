import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const HomePage = () => {
  const services = [
    {
      title: 'Digital Operating Blueprint',
      description: 'Co-create an actionable framework that modernizes your banking operations without relying on legacy vendor lock-in.',
      image: 'https://picsum.photos/id/1011/800/600',
    },
    {
      title: 'Experience Engineering',
      description: 'Design people-first journeys across lending, deposits, and treasury that reinforce bank independent differentiation.',
      image: 'https://picsum.photos/id/1015/800/600',
    },
    {
      title: 'Cloud Native Platforms',
      description: 'Implement secure, compliant, and scalable platforms that liberate your teams from brittle monolithic cores.',
      image: 'https://picsum.photos/id/1025/800/600',
    },
  ];

  const caseStudies = [
    {
      title: 'Community Growth Bank',
      description: 'Reduced onboarding time by 47% through a bank independent process redesign and human-led automation.',
      image: 'https://picsum.photos/id/1005/700/500',
    },
    {
      title: 'North Coast Credit Union',
      description: 'Unified data infrastructure accelerated lending decisions and unlocked new member experiences.',
      image: 'https://picsum.photos/id/1035/700/500',
    },
    {
      title: 'Riverfront Regional',
      description: 'Migrated mission-critical workloads to a resilient hybrid-cloud architecture in under six months.',
      image: 'https://picsum.photos/id/1044/700/500',
    },
  ];

  const blogPosts = [
    {
      title: 'The New Era of Bank Independent Infrastructure',
      date: 'September 14, 2023',
      description: 'Why regional leaders are decoupling from legacy cores and building pragmatic digital ecosystems.',
      image: 'https://picsum.photos/id/1033/700/500',
    },
    {
      title: 'Standing Up a Modern Risk Command Center',
      date: 'August 23, 2023',
      description: 'How to bring together data, people, and AI to respond to risk with clarity and speed.',
      image: 'https://picsum.photos/id/1019/700/500',
    },
    {
      title: 'Reimagining Branches Through Hybrid Journeys',
      date: 'July 5, 2023',
      description: 'Practical ideas to harmonize digital-first self-service with human empathy in the branch.',
      image: 'https://picsum.photos/id/1022/700/500',
    },
  ];

  const testimonials = [
    {
      quote: 'blhank guided us from vision to launch with a calm, informed presence. Our teams feel empowered to solve customer challenges faster than ever.',
      name: 'Avery Morris',
      role: 'Chief Innovation Officer, Community Growth Bank',
      image: 'https://picsum.photos/id/1005/200/200',
    },
    {
      quote: 'Their bank independent expertise helped us negotiate vendor contracts and stand up new digital services with zero downtime.',
      name: 'Linh Nguyen',
      role: 'VP Digital Banking, Riverfront Regional',
      image: 'https://picsum.photos/id/1012/200/200',
    },
  ];

  const teamMembers = [
    {
      name: 'Jordan Blake',
      role: 'Managing Partner',
      image: 'https://picsum.photos/id/64/400/400',
    },
    {
      name: 'Priya Dutta',
      role: 'Head of Platform Strategy',
      image: 'https://picsum.photos/id/65/400/400',
    },
    {
      name: 'Miles Carter',
      role: 'Director of Experience Design',
      image: 'https://picsum.photos/id/66/400/400',
    },
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>blhank | Bank Independent Technology for Modern Institutions</title>
        <meta
          name="description"
          content="Itech Us Inc delivers bank independent consulting, platforms, and managed services that modernize American financial institutions."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <p className={styles.kicker}>Bank Independent Momentum</p>
            <h1>Build the future of banking on your terms.</h1>
            <p>
              blhank equips ambitious financial leaders with the talent, tools, and operational intelligence to become bank independent—faster, safer, and with more customer delight.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contacts" className={styles.primaryCta}>
                Schedule a discovery call
              </Link>
              <Link to="/cases" className={styles.secondaryCta}>
                Explore recent cases
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.partners}>
        <div className="container">
          <p>Trusted by forward-looking financial teams across the United States</p>
          <div className={styles.partnerLogos}>
            <span>Atlas Union</span>
            <span>Harborline</span>
            <span>Blue Peak</span>
            <span>Sunstate Mutual</span>
            <span>First Meridian</span>
          </div>
        </div>
      </section>

      <section className={styles.aboutPreview}>
        <div className="container">
          <div className={styles.aboutGrid}>
            <div className={styles.aboutText}>
              <h2>We unite strategy, design, and engineering.</h2>
              <p>
                From our base in Vermont, the blhank collective pairs financial insiders with product builders to unlock bank independent roadmaps. We deliver clarity through collaborative workshops, data-backed insights, and solutions crafted around your customers—not vendor agendas.
              </p>
              <ul className={styles.highlights}>
                <li>Human-centered delivery teams rooted in banking reality</li>
                <li>Outcome dashboards to track progress in real time</li>
                <li>Embedded change management with measurable adoption</li>
              </ul>
              <Link to="/about" className={styles.linkButton}>
                Meet the team
              </Link>
            </div>
            <div className={styles.aboutImageWrapper}>
              <img src="https://picsum.photos/id/1067/900/700" alt="blhank consultants collaborating in the studio" loading="lazy" />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Services crafted for bank independent resilience</h2>
            <p>Right-size your roadmap with modular engagements that scale with your institution.</p>
          </div>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <img src={service.image} alt={service.title} loading="lazy" />
                <div>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.servicesCta}>
            <Link to="/services" className={styles.primaryCta}>
              View all services
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.cases}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Latest bank independent case stories</h2>
            <p>Proof that thoughtful transformation can be fast, compliant, and loved by customers.</p>
          </div>
          <div className={styles.casesGrid}>
            {caseStudies.map((item) => (
              <article key={item.title} className={styles.caseCard}>
                <img src={item.image} alt={item.title} loading="lazy" />
                <div className={styles.caseContent}>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                  <Link to="/cases" className={styles.linkButton}>
                    Read the story
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Leaders who chose bank independent paths</h2>
          </div>
          <div className={styles.testimonialGrid}>
            {testimonials.map((testimonial) => (
              <figure key={testimonial.name} className={styles.testimonialCard}>
                <img src={testimonial.image} alt={testimonial.name} loading="lazy" />
                <blockquote>“{testimonial.quote}”</blockquote>
                <figcaption>
                  <span className={styles.person}>{testimonial.name}</span>
                  <span className={styles.role}>{testimonial.role}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Insights from the blhank newsroom</h2>
            <p>Stay ahead with curated research, interviews, and playbooks.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.description}</p>
                  <Link to="/blog" className={styles.linkButton}>
                    Continue reading
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>The blhank collective</h2>
            <p>Strategists, creators, and builders dedicated to bank independent transformation.</p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <div key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <h3>{member.name}</h3>
                <p>{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Ready to act on your bank independent strategy?</h2>
            <p>Let’s align your stakeholders, surface quick wins, and orchestrate lasting change.</p>
            <Link to="/contacts" className={styles.primaryCta}>
              Start the conversation
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;