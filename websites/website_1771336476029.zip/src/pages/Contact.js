import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const ContactPage = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Please enter your name.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (formData.message.trim().length < 10) {
      newErrors.message = 'Please provide a bit more context for your request.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      navigate('/thank-you', { state: { name: formData.name.trim() } });
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact blhank | Start Your Bank Independent Journey</title>
        <meta
          name="description"
          content="Connect with the blhank team in South Burlington, Vermont to explore bank independent consulting, experience design, and engineering services."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Let’s build your bank independent roadmap</h1>
          <p>Reach out to the blhank team and we’ll respond within one business day.</p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.formWrapper}>
              <h2>Share a few details</h2>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label htmlFor="name">
                  Name*
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    aria-required="true"
                    aria-invalid={Boolean(errors.name)}
                  />
                  {errors.name && <span className={styles.errorMessage}>{errors.name}</span>}
                </label>
                <label htmlFor="email">
                  Email*
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    aria-required="true"
                    aria-invalid={Boolean(errors.email)}
                  />
                  {errors.email && <span className={styles.errorMessage}>{errors.email}</span>}
                </label>
                <label htmlFor="company">
                  Company
                  <input
                    id="company"
                    name="company"
                    type="text"
                    value={formData.company}
                    onChange={handleChange}
                    aria-required="false"
                  />
                </label>
                <label htmlFor="message">
                  How can we help?*
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    value={formData.message}
                    onChange={handleChange}
                    aria-required="true"
                    aria-invalid={Boolean(errors.message)}
                  />
                  {errors.message && <span className={styles.errorMessage}>{errors.message}</span>}
                </label>
                <button type="submit" className={styles.submitButton}>
                  Send message
                </button>
              </form>
            </div>
            <div className={styles.details}>
              <h2>Visit or call us</h2>
              <address>
                Itech Us Inc<br />
                20 Kimball Ave #303n<br />
                South Burlington, VT 05403
              </address>
              <p className={styles.contactItem}>Phone: +1 802-383-1500</p>
              <p className={styles.contactItem}>Email: info@blhank.pro</p>
              <div className={styles.mapWrapper}>
                <iframe
                  title="Itech Us Inc location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2881.2841709930653!2d-73.14072872336454!3d44.46694290221668!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cca7a1f9b8c0ba5%3A0x7cb6805ae0cbae78!2s20%20Kimball%20Ave%20%23303n%2C%20South%20Burlington%2C%20VT%2005403!5e0!3m2!1sen!2sus!4v1697040483345!5m2!1sen!2sus"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;