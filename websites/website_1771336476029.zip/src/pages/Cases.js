import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Cases.module.css';

const CasesPage = () => {
  const cases = [
    {
      title: 'Community Growth Bank',
      image: 'https://picsum.photos/id/1031/760/520',
      description: 'Integrated a digital-first onboarding journey that cut account opening time nearly in half while increasing NPS by 18 points.',
    },
    {
      title: 'Riverfront Regional',
      image: 'https://picsum.photos/id/1038/760/520',
      description: 'Built a composable architecture with new APIs, enabling faster product launches and real-time reporting for leadership.',
    },
    {
      title: 'North Coast Credit Union',
      image: 'https://picsum.photos/id/1053/760/520',
      description: 'Unified data pipelines and developed an analytics command center that supports proactive member engagement.',
    },
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Case Studies | blhank</title>
        <meta name="description" content="Explore bank independent case studies from blhank, featuring community banks and credit unions across the US." />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Bank independent stories</h1>
          <p>Every engagement is measured by outcomes, adoption, and customer delight.</p>
        </div>
      </section>
      <section className={styles.cards}>
        <div className="container">
          <div className={styles.grid}>
            {cases.map((item) => (
              <article key={item.title} className={styles.card}>
                <img src={item.image} alt={item.title} loading="lazy" />
                <div className={styles.cardContent}>
                  <h2>{item.title}</h2>
                  <p>{item.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default CasesPage;