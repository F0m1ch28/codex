import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const PrivacyPolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Policy | blhank</title>
      <meta name="description" content="Review how blhank and Itech Us Inc collect, use, and protect personal information." />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Privacy Policy</h1>
        <p>Last updated: September 15, 2023</p>
        <p>
          Itech Us Inc respects your privacy and is committed to protecting the personal data you share with us. This policy explains what information we collect, how we use it, and the controls available to you.
        </p>
        <h2>Information we collect</h2>
        <ul>
          <li>Contact details you submit via forms or email.</li>
          <li>Usage data gathered through analytics cookies.</li>
          <li>Professional information shared during discovery calls.</li>
        </ul>
        <h2>How we use information</h2>
        <p>
          We use data to respond to inquiries, deliver services, improve our content, and send relevant updates about bank independent resources.
        </p>
        <h2>Data protection</h2>
        <p>
          We implement technical and organizational safeguards to protect data. Access is limited to team members who need it to fulfill their responsibilities.
        </p>
        <h2>Your choices</h2>
        <p>
          You may request access, correction, or deletion of your data by emailing info@blhank.pro. We respond promptly in accordance with applicable laws.
        </p>
      </div>
    </section>
  </div>
);

export default PrivacyPolicyPage;