import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const ServicesPage = () => {
  const offerings = [
    {
      title: 'Strategy & Advisory',
      bulletPoints: [
        'Bank independent diagnostic and maturity assessment',
        'Transformation roadmap with measurable milestones',
        'Vendor evaluation and partnership orchestration',
      ],
      image: 'https://picsum.photos/id/1062/800/600',
    },
    {
      title: 'Product & Experience',
      bulletPoints: [
        'Customer journey visioning and service blueprinting',
        'Rapid prototyping with real customer validation',
        'Omnichannel orchestration aligned with compliance',
      ],
      image: 'https://picsum.photos/id/1050/800/600',
    },
    {
      title: 'Engineering & Delivery',
      bulletPoints: [
        'API-first architecture and core integration',
        'Cloud migration with resiliency and observability',
        'Managed services to sustain momentum post-launch',
      ],
      image: 'https://picsum.photos/id/1047/800/600',
    },
  ];

  const processSteps = [
    {
      title: 'Discover & Align',
      description: 'Collaborative workshops to align leadership on intent, metrics, and blueprint for bank independent outcomes.',
    },
    {
      title: 'Design & Prototype',
      description: 'Translate insights into tangible experiences and validate with users to ensure viability and delight.',
    },
    {
      title: 'Build & Launch',
      description: 'Deliver iteratively with continuous testing, compliance checkpoints, and change management at every step.',
    },
    {
      title: 'Measure & Evolve',
      description: 'Activate data observability, train teams, and iterate on releases informed by customer feedback.',
    },
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Services | blhank Bank Independent Solutions</title>
        <meta
          name="description"
          content="Explore blhank services spanning advisory, experience design, engineering, and managed delivery for bank independent transformation."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Services that power bank independent transformation</h1>
          <p>
            Wherever you are on the journey, blhank shapes engagements to accelerate progress while transferring skills to your teams.
          </p>
        </div>
      </section>

      <section className={styles.offerings}>
        <div className="container">
          <div className={styles.offeringsGrid}>
            {offerings.map((offering) => (
              <article key={offering.title} className={styles.offeringCard}>
                <img src={offering.image} alt={offering.title} loading="lazy" />
                <div className={styles.offeringContent}>
                  <h2>{offering.title}</h2>
                  <ul>
                    {offering.bulletPoints.map((point) => (
                      <li key={point}>{point}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <h2>Our collaborative process</h2>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <div key={step.title} className={styles.processCard}>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.differentiators}>
        <div className="container">
          <h2>Why teams choose blhank</h2>
          <ul>
            <li>Cross-functional pods bring strategy, design, data, and engineering under one team.</li>
            <li>Outcome dashboards tie every deliverable to your bank independent objectives.</li>
            <li>Knowledge transfer sessions ensure your team owns the future roadmap.</li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;