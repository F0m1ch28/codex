import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const BlogPage = () => {
  const articles = [
    {
      title: 'Defining a Bank Independent Operating Model',
      date: 'October 2, 2023',
      excerpt: 'A step-by-step approach to align leadership, technology, and talent around independent capabilities.',
      image: 'https://picsum.photos/id/1040/760/520',
    },
    {
      title: 'How Data Observability Protects Customer Trust',
      date: 'September 12, 2023',
      excerpt: 'Discover the dashboards and rituals top institutions use to make faster, smarter decisions.',
      image: 'https://picsum.photos/id/1043/760/520',
    },
    {
      title: 'Modernizing Loan Origination Without Disruption',
      date: 'August 22, 2023',
      excerpt: 'See how a phased rollout keeps teams productive while delivering new customer journeys.',
      image: 'https://picsum.photos/id/1048/760/520',
    },
    {
      title: 'Inclusive Design for Community Banking',
      date: 'July 18, 2023',
      excerpt: 'Why accessibility and empathy are core pillars of a bank independent experience.',
      image: 'https://picsum.photos/id/1046/760/520',
    },
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Blog | blhank Insights</title>
        <meta name="description" content="Read the latest insights from blhank on building resilient, bank independent financial institutions." />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>blhank insights</h1>
          <p>Curated stories, research, and playbooks for bank independent leaders.</p>
        </div>
      </section>
      <section className={styles.articles}>
        <div className="container">
          <div className={styles.grid}>
            {articles.map((article) => (
              <article key={article.title} className={styles.card}>
                <img src={article.image} alt={article.title} loading="lazy" />
                <div className={styles.cardContent}>
                  <span className={styles.date}>{article.date}</span>
                  <h2>{article.title}</h2>
                  <p>{article.excerpt}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default BlogPage;