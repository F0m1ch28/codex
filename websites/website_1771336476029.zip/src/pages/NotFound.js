import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './NotFound.module.css';

const NotFoundPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Page Not Found | blhank</title>
      <meta name="description" content="The page you were looking for could not be found on the blhank website." />
    </Helmet>
    <div className={styles.content}>
      <h1>404</h1>
      <p>We can’t find the page you’re looking for. Let’s get you back to the bank independent insights you need.</p>
      <Link to="/" className={styles.link}>Back to home</Link>
    </div>
  </div>
);

export default NotFoundPage;