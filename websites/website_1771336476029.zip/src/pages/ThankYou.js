import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './ThankYou.module.css';

const ThankYouPage = () => {
  const location = useLocation();
  const name = location.state?.name || 'there';

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Thank You | blhank</title>
        <meta name="description" content="Thank you for contacting blhank. A member of our bank independent team will be in touch shortly." />
      </Helmet>
      <section className={styles.section}>
        <div className="container">
          <h1>Thank you, {name}!</h1>
          <p>We received your message and a member of the blhank team will respond within one business day.</p>
          <Link to="/" className={styles.homeLink}>
            Return to homepage
          </Link>
        </div>
      </section>
    </div>
  );
};

export default ThankYouPage;