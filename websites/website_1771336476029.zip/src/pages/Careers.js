import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Careers.module.css';

const CareersPage = () => {
  const roles = [
    {
      title: 'Senior Transformation Strategist',
      location: 'Hybrid · United States',
      description: 'Lead multi-disciplinary teams to design and activate bank independent operating models for regional banks.',
    },
    {
      title: 'Experience Design Lead',
      location: 'Remote · United States',
      description: 'Shape omnichannel customer journeys and co-create service blueprints with clients and their customers.',
    },
    {
      title: 'Cloud Solutions Engineer',
      location: 'Hybrid · South Burlington, VT',
      description: 'Build resilient platform foundations, integrate with third-party systems, and coach client teams on cloud practices.',
    },
  ];

  const benefits = [
    'Remote-first flexibility with purposeful on-site collaboration.',
    'Wellness coverage, learning stipend, and dedicated focus weeks.',
    'Opportunities to work directly with executives at leading financial institutions.',
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Careers | Join blhank</title>
        <meta name="description" content="Join the blhank team and help financial institutions achieve bank independent growth across the United States." />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Careers at blhank</h1>
          <p>We hire curious builders who care about people, precision, and beating expectations.</p>
        </div>
      </section>
      <section className={styles.roles}>
        <div className="container">
          <h2>Open roles</h2>
          <div className={styles.grid}>
            {roles.map((role) => (
              <article key={role.title} className={styles.card}>
                <h3>{role.title}</h3>
                <span className={styles.location}>{role.location}</span>
                <p>{role.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className={styles.benefits}>
        <div className="container">
          <h2>Life at blhank</h2>
          <ul>
            {benefits.map((benefit) => (
              <li key={benefit}>{benefit}</li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
};

export default CareersPage;