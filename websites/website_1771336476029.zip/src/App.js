import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage from './pages/Services';
import BlogPage from './pages/Blog';
import CasesPage from './pages/Cases';
import CareersPage from './pages/Careers';
import ContactPage from './pages/Contact';
import ThankYouPage from './pages/ThankYou';
import TermsConditionsPage, { DisclaimerPage, CookiePolicyPage } from './pages/TermsOfService';
import PrivacyPolicyPage from './pages/PrivacyPolicy';
import NotFoundPage from './pages/NotFound';

const App = () => {
  return (
    <div className="appShell">
      <Header />
      <main id="mainContent">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/cases" element={<CasesPage />} />
          <Route path="/careers" element={<CareersPage />} />
          <Route path="/contacts" element={<ContactPage />} />
          <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
          <Route path="/terms-conditions" element={<TermsConditionsPage />} />
          <Route path="/disclaimer" element={<DisclaimerPage />} />
          <Route path="/cookie-policy" element={<CookiePolicyPage />} />
          <Route path="/thank-you" element={<ThankYouPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
};

export default App;