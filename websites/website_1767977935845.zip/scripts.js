document.addEventListener('DOMContentLoaded', () => {
    const yearEl = document.getElementById('currentYear');
    if (yearEl) {
        yearEl.textContent = new Date().getFullYear();
    }

    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.site-nav-list');
    if (navToggle && navList) {
        navToggle.addEventListener('click', () => {
            const isOpen = navList.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const storedCookieChoice = localStorage.getItem('ncrCookieChoice');
    if (cookieBanner && !storedCookieChoice) {
        cookieBanner.classList.add('is-visible');
    }
    const acceptCookie = document.querySelector('.cookie-accept');
    const declineCookie = document.querySelector('.cookie-decline');

    const handleCookieChoice = (choice) => {
        localStorage.setItem('ncrCookieChoice', choice);
        if (cookieBanner) {
            cookieBanner.classList.remove('is-visible');
        }
    };

    if (acceptCookie) {
        acceptCookie.addEventListener('click', (event) => {
            event.preventDefault();
            handleCookieChoice('accepted');
        });
    }

    if (declineCookie) {
        declineCookie.addEventListener('click', (event) => {
            event.preventDefault();
            handleCookieChoice('declined');
        });
    }

    const forms = document.querySelectorAll('form[data-redirect]');
    forms.forEach((form) => {
        form.addEventListener('submit', (event) => {
            if (!form.checkValidity()) {
                form.reportValidity();
                event.preventDefault();
                return;
            }
            event.preventDefault();
            const redirectUrl = form.dataset.redirect || 'thanks.html';
            window.location.href = redirectUrl;
        });
    });

    const postsContainer = document.querySelector('[data-post-list]');
    if (postsContainer) {
        const cards = Array.from(postsContainer.querySelectorAll('.post-card'));
        const filterButtons = document.querySelectorAll('[data-filter]');
        const searchInput = document.getElementById('postSearch');
        const paginationWrap = document.querySelector('[data-pagination]');
        const pageLabel = document.querySelector('[data-page-label]');
        const prevButton = paginationWrap ? paginationWrap.querySelector('[data-prev]') : null;
        const nextButton = paginationWrap ? paginationWrap.querySelector('[data-next]') : null;

        let activeCategory = 'all';
        let searchTerm = '';
        let currentPage = 1;
        const itemsPerPage = 6;

        const getFilteredCards = () => {
            return cards.filter((card) => {
                const category = card.dataset.category || '';
                const tags = (card.dataset.tags || '').toLowerCase();
                const matchesCategory = activeCategory === 'all' || category === activeCategory;
                const matchesSearch = searchTerm === '' || tags.includes(searchTerm);
                return matchesCategory && matchesSearch;
            });
        };

        const renderCards = () => {
            const filteredCards = getFilteredCards();
            const totalPages = Math.max(1, Math.ceil(filteredCards.length / itemsPerPage));
            if (currentPage > totalPages) {
                currentPage = totalPages;
            }
            cards.forEach((card) => card.classList.add('is-hidden'));
            const start = (currentPage - 1) * itemsPerPage;
            const end = start + itemsPerPage;
            filteredCards.slice(start, end).forEach((card) => card.classList.remove('is-hidden'));

            if (pageLabel) {
                pageLabel.textContent = `Page ${currentPage} of ${totalPages}`;
            }
            if (prevButton) {
                prevButton.disabled = currentPage === 1;
            }
            if (nextButton) {
                nextButton.disabled = currentPage === totalPages;
            }
        };

        filterButtons.forEach((button) => {
            button.addEventListener('click', () => {
                filterButtons.forEach((btn) => btn.classList.remove('is-active'));
                button.classList.add('is-active');
                activeCategory = button.dataset.filter || 'all';
                currentPage = 1;
                renderCards();
            });
        });

        if (searchInput) {
            searchInput.addEventListener('input', (event) => {
                searchTerm = event.target.value.trim().toLowerCase();
                currentPage = 1;
                renderCards();
            });
        }

        if (prevButton) {
            prevButton.addEventListener('click', () => {
                if (currentPage > 1) {
                    currentPage -= 1;
                    renderCards();
                }
            });
        }

        if (nextButton) {
            nextButton.addEventListener('click', () => {
                const filteredCards = getFilteredCards();
                const totalPages = Math.max(1, Math.ceil(filteredCards.length / itemsPerPage));
                if (currentPage < totalPages) {
                    currentPage += 1;
                    renderCards();
                }
            });
        }

        renderCards();
    }
});