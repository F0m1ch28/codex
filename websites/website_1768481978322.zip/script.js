document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.site-nav .nav-link');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-btn');
    const consentKey = 'genusCayqgCookieConsent';

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            siteNav.classList.toggle('nav-open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (siteNav.classList.contains('nav-open')) {
                    siteNav.classList.remove('nav-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (cookieBanner) {
        const existingConsent = localStorage.getItem(consentKey);
        if (!existingConsent) {
            cookieBanner.classList.add('show');
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', () => {
                const action = button.getAttribute('data-cookie-action');
                const targetLink = button.getAttribute('data-link');
                if (action) {
                    localStorage.setItem(consentKey, action);
                    cookieBanner.classList.remove('show');
                }
                if (targetLink) {
                    window.open(targetLink, '_blank', 'noopener');
                }
            });
        });
    }
});