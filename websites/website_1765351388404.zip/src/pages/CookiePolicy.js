```javascript
import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  usePageMetadata({
    title: 'Политика использования cookie — VideoCovers & Avatars',
    description:
      'Подробная информация о том, как платформа VideoCovers & Avatars использует файлы cookie и технологии отслеживания.'
  });

  return (
    <section className={styles.legal}>
      <div className={styles.wrapper}>
        <h1>Политика использования файлов cookie</h1>
        <p>Дата обновления: 10 января 2024 года</p>

        <article>
          <h2>1. Что такое cookie</h2>
          <p>
            Cookie — это небольшие текстовые файлы, которые сохраняются в браузере. Они помогают запомнить ваши
            настройки и предпочтения на сайте.
          </p>
        </article>

        <article>
          <h2>2. Какие cookie мы используем</h2>
          <ul>
            <li>Функциональные — обеспечивают корректную работу форм, входа и навигации.</li>
            <li>Аналитические — помогают понять, какие разделы платформы наиболее востребованы.</li>
            <li>Настройки — сохраняют выбранный язык и фильтры каталога.</li>
          </ul>
        </article>

        <article>
          <h2>3. Как управлять cookie</h2>
          <p>
            Вы можете изменить настройки браузера и запретить сохранение cookie. Обратите внимание, что некоторые функции
            платформы могут работать некорректно без cookie.
          </p>
        </article>

        <article>
          <h2>4. Контакты</h2>
          <p>
            Вопросы по cookie направляйте на{' '}
            <a href="mailto:support@videocovers-avatars.com">support@videocovers-avatars.com</a>.
          </p>
        </article>
      </div>
    </section>
  );
};

export default CookiePolicy;
```

Need CSS.