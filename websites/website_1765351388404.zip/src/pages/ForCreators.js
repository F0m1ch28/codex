```javascript
import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './ForCreators.module.css';

const benefits = [
  {
    title: 'Прозрачные условия',
    description: 'Мы работаем без скрытых комиссий и предоставляем понятную статистику заказов.'
  },
  {
    title: 'Глобальная аудитория',
    description: 'Ваши работы увидят авторы из разных стран, ориентированные на русскоязычный контент.'
  },
  {
    title: 'Профессиональная поддержка',
    description: 'Кураторы помогают с портфолио, оформлением карточек и продвижением на платформе.'
  }
];

const steps = [
  {
    number: '01',
    title: 'Расскажите о себе',
    description: 'Заполните форму и добавьте примеры работ. Мы рассмотрим заявку в течение 3 рабочих дней.'
  },
  {
    number: '02',
    title: 'Создайте коллекцию',
    description: 'Опубликуйте готовые наборы или предложите уникальные проекты с возможностью адаптации.'
  },
  {
    number: '03',
    title: 'Получайте заказы',
    description: 'Отвечайте на запросы авторов, обновляйте портфолио и расширяйте клиентскую базу.'
  }
];

const ForCreators = () => {
  usePageMetadata({
    title: 'Для дизайнеров — VideoCovers & Avatars',
    description:
      'Подключайтесь к VideoCovers & Avatars как дизайнер. Прозрачные условия, глобальная аудитория и поддержка кураторов.'
  });

  return (
    <section className={styles.creators}>
      <div className={styles.wrapper}>
        <header className={styles.header}>
          <h1>Раздел для дизайнеров</h1>
          <p>
            Публикуйте свои коллекции, получайте заказы от авторов и развивайте личный бренд. Мы обеспечим прозрачную
            работу и поддержку на каждом шаге.
          </p>
          <a className={styles.headerLink} href="mailto:creators@videocovers-avatars.com">
            Написать кураторам: creators@videocovers-avatars.com
          </a>
        </header>

        <section className={styles.benefits} aria-labelledby="creator-benefits">
          <h2 id="creator-benefits">Преимущества</h2>
          <div className={styles.benefitsGrid}>
            {benefits.map((benefit) => (
              <article key={benefit.title} className={styles.benefitCard}>
                <h3>{benefit.title}</h3>
                <p>{benefit.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.steps} aria-labelledby="creator-steps">
          <h2 id="creator-steps">Как присоединиться</h2>
          <div className={styles.stepsGrid}>
            {steps.map((step) => (
              <article key={step.number} className={styles.stepCard}>
                <span className={styles.stepNumber}>{step.number}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </section>
      </div>
    </section>
  );
};

export default ForCreators;
```

Need CSS.