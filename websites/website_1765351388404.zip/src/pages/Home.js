```javascript
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Home.module.css';

const categories = [
  { name: 'Обложки для видео', description: 'Яркие и кликабельные постеры для YouTube и VK Видео', value: 'covers' },
  { name: 'Аватарки', description: 'Эффектные аватары и логотипы, которые узнают с первого взгляда', value: 'avatars' },
  { name: 'Баннеры для стримов', description: 'Стильные сценки и панели для Twitch и Trovo', value: 'banners' },
  { name: 'Шапки каналов', description: 'Гармоничные шапки для оформления канала и сообществ', value: 'headers' }
];

const advantages = [
  {
    title: 'Уникальные дизайнерские стили',
    text: 'Каждая работа проходит модерацию и проверку на оригинальность, чтобы ваш бренд выглядел эксклюзивно.',
    icon: '🎨'
  },
  {
    title: 'Быстрый доступ к файлам',
    text: 'Файлы доступны для скачивания сразу после покупки, без ожидания и переписки.',
    icon: '⚡'
  },
  {
    title: 'Поддержка авторов 24/7',
    text: 'Наша команда помогает с подбором дизайна и ответами на вопросы в любое время суток.',
    icon: '💬'
  },
  {
    title: 'Фокус на создателях',
    text: 'Мы учли потребности стримеров, блогеров и продюсеров, чтобы оформление усиливало каждую публикацию.',
    icon: '🚀'
  }
];

const stats = [
  { label: 'Готовых дизайнов', value: '2 450+' },
  { label: 'Дизайнеров в каталоге', value: '180' },
  { label: 'Сообществ по всему миру', value: '4 300+' }
];

const featuredWorks = [
  { id: 1, title: 'Neon Motion Cover', image: 'https://via.placeholder.com/300x200?text=Cover+Preview+1' },
  { id: 2, title: 'Stream Energy Pack', image: 'https://via.placeholder.com/300x200?text=Cover+Preview+2' },
  { id: 3, title: 'Cyberwave Avatar', image: 'https://via.placeholder.com/300x200?text=Cover+Preview+3' },
  { id: 4, title: 'Lifestyle Channel Kit', image: 'https://via.placeholder.com/300x200?text=Cover+Preview+4' },
  { id: 5, title: 'Esport Banner Duo', image: 'https://via.placeholder.com/300x200?text=Cover+Preview+5' },
  { id: 6, title: 'Minimal Creator Pack', image: 'https://via.placeholder.com/300x200?text=Cover+Preview+6' }
];

const processSteps = [
  {
    title: 'Выбор дизайна',
    description: 'Ознакомьтесь с каталогом и фильтрами, подберите стиль, который соответствует вашей аудитории.'
  },
  {
    title: 'Мгновенное оформление',
    description: 'Добавьте дизайн в коллекцию, укажите требования по адаптации и заполните контактные данные.'
  },
  {
    title: 'Получение файлов',
    description: 'Скачайте готовые файлы или свяжитесь с дизайнером для персональной настройки.'
  },
  {
    title: 'Публичный запуск',
    description: 'Используйте графику на каналах, стримах и в соцсетях, чтобы усилить ваш личный бренд.'
  }
];

const testimonials = [
  {
    id: 1,
    name: 'Алексей Миронов',
    role: 'YouTube-автор, канал о технике',
    text: 'Наконец нашёл место, где можно быстро обновить стиль канала и настроить обложки под каждое видео.',
    avatar: 'https://picsum.photos/200/200?random=301'
  },
  {
    id: 2,
    name: 'Мария Соколова',
    role: 'Стримерша на Twitch',
    text: 'Понравились готовые пакеты для стримов и отдельные панели. Зрители заметили обновление с первого дня.',
    avatar: 'https://picsum.photos/200/200?random=302'
  },
  {
    id: 3,
    name: 'Digital Team Aurora',
    role: 'Продюсерский центр',
    text: 'Каталог помог оперативно подготовить визуал для нескольких проектов без длительного брифа.',
    avatar: 'https://picsum.photos/200/200?random=303'
  }
];

const projects = [
  {
    id: 1,
    title: 'Creator Pulse Pack',
    type: 'Видео',
    description: 'Комплект обложек и энд-кардов для динамичных видеороликов.',
    image: 'https://picsum.photos/800/600?random=201'
  },
  {
    id: 2,
    title: 'Stream Galaxy Layout',
    type: 'Стримы',
    description: 'Адаптируемые графические сцены для OBS и Streamlabs.',
    image: 'https://picsum.photos/800/600?random=202'
  },
  {
    id: 3,
    title: 'Indie Podcast Visual',
    type: 'Подкасты',
    description: 'Универсальный набор для визуального сопровождения аудио-проектов.',
    image: 'https://picsum.photos/800/600?random=203'
  },
  {
    id: 4,
    title: 'Brand Channel Identity',
    type: 'Видео',
    description: 'Акцент на фирменные цвета и лаконичную типографику.',
    image: 'https://picsum.photos/800/600?random=204'
  }
];

const faq = [
  {
    question: 'Можно ли изменить цвета и текст в готовом дизайне?',
    answer:
      'Да, дизайнеры предоставляют исходные файлы или слои, чтобы вы могли адаптировать цвета, логотипы и тексты под свою задачу.'
  },
  {
    question: 'Как получить уникальный дизайн только для моего канала?',
    answer:
      'Выберите пункт «Персональный заказ» на странице дизайнера или напишите нам на support@videocovers-avatars.com — мы сопоставим вас с автором.'
  },
  {
    question: 'Какие форматы файлов доступны после покупки?',
    answer:
      'В большинстве наборов присутствуют PSD, PNG и JPG. Для анимации авторы предоставляют исходники After Effects или готовый видеофайл.'
  }
];

const blogPosts = [
  {
    id: 1,
    title: 'Как выбрать графику для премьер на YouTube',
    excerpt:
      'Разбираем цветовые акценты, композицию и работу с текстом, чтобы ролики набирали больше кликов.',
    image: 'https://picsum.photos/600/400?random=401'
  },
  {
    id: 2,
    title: 'Чек-лист оформления Twitch-канала',
    excerpt:
      'Собрали ключевые элементы интерфейса, которые помогают зрителям ориентироваться и возвращаться на стримы.',
    image: 'https://picsum.photos/600/400?random=402'
  },
  {
    id: 3,
    title: 'Гайд по запуску визуального стиля бренда',
    excerpt:
      'Если вы продюсер или руководите командой, этот материал поможет выстроить единое визуальное ДНК.',
    image: 'https://picsum.photos/600/400?random=403'
  }
];

const Home = () => {
  usePageMetadata({
    title: 'VideoCovers & Avatars — Профессиональная графика для вашего контента',
    description:
      'Каталог обложек, аватарок, баннеров и паков сцен для создателей видео и стримов. Поддержка дизайнеров и оригинальные решения.'
  });

  const navigate = useNavigate();
  const [selectedProjectType, setSelectedProjectType] = useState('Все');
  const [activeFaq, setActiveFaq] = useState(null);

  const filteredProjects =
    selectedProjectType === 'Все'
      ? projects
      : projects.filter((project) => project.type === selectedProjectType);

  return (
    <div className={styles.home}>
      <section
        className={styles.hero}
        style={{ backgroundImage: 'url(https://picsum.photos/1600/900?random=101)' }}
        aria-labelledby="hero-title"
      >
        <div className={styles.heroInner}>
          <span className={styles.heroTag}>Дизайн без границ</span>
          <h1 id="hero-title" className={styles.heroTitle}>
            Профессиональная графика для вашего контента
          </h1>
          <p className={styles.heroText}>
            Обложки, аватары, баннеры и сценки для трансляций — всё, что нужно, чтобы визуально выделиться
            среди авторов и брендов. Выбирайте из готовых коллекций или вдохновляйтесь на индивидуальный заказ.
          </p>
          <div className={styles.heroActions}>
            <button
              type="button"
              className={styles.primaryButton}
              onClick={() => navigate('/catalog')}
            >
              Смотреть каталог
            </button>
            <button
              type="button"
              className={styles.secondaryButton}
              onClick={() => navigate('/for-creators')}
            >
              Для дизайнеров
            </button>
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className={styles.sectionInner}>
          <div className={styles.statsGrid}>
            {stats.map((item) => (
              <article key={item.label} className={styles.statCard}>
                <strong className={styles.statValue}>{item.value}</strong>
                <span className={styles.statLabel}>{item.label}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.categoriesSection} aria-labelledby="categories-heading">
        <div className={styles.sectionInner}>
          <header className={styles.sectionHeader}>
            <h2 id="categories-heading">Категории каталога</h2>
            <p>Готовые подборки для разных форматов контента и площадок.</p>
          </header>
          <div className={styles.categoriesGrid}>
            {categories.map((category) => (
              <button
                type="button"
                key={category.value}
                className={styles.categoryCard}
                onClick={() => navigate('/catalog', { state: { category: category.value } })}
              >
                <span className={styles.categoryIcon}>★</span>
                <h3>{category.name}</h3>
                <p>{category.description}</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.benefitsSection} aria-labelledby="benefits-heading">
        <div className={styles.sectionInner}>
          <header className={styles.sectionHeader}>
            <h2 id="benefits-heading">Почему выбирают VideoCovers &amp; Avatars</h2>
          </header>
          <div className={styles.benefitsGrid}>
            {advantages.map((advantage) => (
              <article key={advantage.title} className={styles.benefitCard}>
                <span className={styles.benefitIcon} aria-hidden="true">
                  {advantage.icon}
                </span>
                <h3>{advantage.title}</h3>
                <p>{advantage.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.featuredSection} aria-labelledby="featured-heading">
        <div className={styles.sectionInner}>
          <header className={styles.sectionHeader}>
            <h2 id="featured-heading">Популярные работы</h2>
            <p>Подборка обновляется каждую неделю с учётом трендов и отзывов авторов.</p>
          </header>
          <div className={styles.featuredGrid}>
            {featuredWorks.map((work) => (
              <article key={work.id} className={styles.featuredCard}>
                <img src={work.image} alt={work.title} loading="lazy" />
                <div className={styles.featuredContent}>
                  <h3>{work.title}</h3>
                  <a href="#!" className={styles.featuredLink}>
                    Подробнее
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection} aria-labelledby="process-heading">
        <div className={styles.sectionInner}>
          <header className={styles.sectionHeader}>
            <h2 id="process-heading">Как это работает</h2>
            <p>Простой путь от идеи до загруженного дизайна.</p>
          </header>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.title} className={styles.processCard}>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection} aria-labelledby="projects-heading">
        <div className={styles.sectionInner}>
          <header className={styles.sectionHeader}>
            <h2 id="projects-heading">Дизайн-проекты в фокусе</h2>
            <p>Истории, где графика помогла авторам добиться вовлечения.</p>
          </header>
          <div className={styles.projectFilters}>
            {['Все', 'Видео', 'Стримы', 'Подкасты'].map((type) => (
              <button
                key={type}
                type="button"
                className={`${styles.filterButton} ${
                  selectedProjectType === type ? styles.filterActive : ''
                }`}
                onClick={() => setSelectedProjectType(type)}
              >
                {type}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectContent}>
                  <span className={styles.projectType}>{project.type}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection} aria-labelledby="testimonials-heading">
        <div className={styles.sectionInner}>
          <header className={styles.sectionHeader}>
            <h2 id="testimonials-heading">Отзывы создателей</h2>
          </header>
          <div className={styles.testimonialsGrid}>
            {testimonials.map((testimonial) => (
              <article key={testimonial.id} className={styles.testimonialCard}>
                <img src={testimonial.avatar} alt={testimonial.name} loading="lazy" />
                <div className={styles.testimonialContent}>
                  <p className={styles.testimonialText}>&ldquo;{testimonial.text}&rdquo;</p>
                  <span className={styles.testimonialName}>{testimonial.name}</span>
                  <span className={styles.testimonialRole}>{testimonial.role}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection} aria-labelledby="faq-heading">
        <div className={styles.sectionInner}>
          <header className={styles.sectionHeader}>
            <h2 id="faq-heading">Вопросы и ответы</h2>
          </header>
          <div className={styles.faqList}>
            {faq.map((item, index) => (
              <article
                key={item.question}
                className={`${styles.faqItem} ${activeFaq === index ? styles.faqItemOpen : ''}`}
              >
                <button
                  type="button"
                  className={styles.faqButton}
                  onClick={() => setActiveFaq(activeFaq === index ? null : index)}
                  aria-expanded={activeFaq === index}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>{activeFaq === index ? '−' : '+'}</span>
                </button>
                <div className={styles.faqAnswer}>
                  <p>{item.answer}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection} aria-labelledby="blog-heading">
        <div className={styles.sectionInner}>
          <header className={styles.sectionHeader}>
            <h2 id="blog-heading">Свежие кейсы и советы</h2>
            <p>Тенденции визуального оформления в медиа и стриминге.</p>
          </header>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogContent}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <a href="#!" className={styles.blogLink}>
                    Читать далее
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.finalCta} aria-labelledby="final-cta-heading">
        <div className={styles.sectionInner}>
          <div className={styles.finalCtaCard}>
            <h2 id="final-cta-heading">Присоединяйтесь как дизайнер</h2>
            <p>
              Расскажите о себе, загрузите портфолио и начните зарабатывать на цифровых дизайнах. Мы поможем
              заявить о вашем стиле и найдём заинтересованных авторов.
            </p>
            <button
              type="button"
              className={styles.primaryButton}
              onClick={() => navigate('/for-creators')}
            >
              Открыть раздел для создателей
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
```

Need to ensure we imported arrays? we defined top.

Now create `Home.module.css`.