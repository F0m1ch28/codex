```javascript
import React, { useState } from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Contacts.module.css';

const Contacts = () => {
  usePageMetadata({
    title: 'Контакты — VideoCovers & Avatars',
    description:
      'Свяжитесь с командой VideoCovers & Avatars. Поддержка авторов и дизайнеров, вопросы по сотрудничеству и партнёрству.'
  });

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    topic: '',
    message: ''
  });

  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Укажите имя или название проекта.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Введите электронную почту.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Используйте корректный формат email.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Расскажите, чем мы можем помочь.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);

    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setFormData({ name: '', email: '', topic: '', message: '' });
    }
  };

  return (
    <section className={styles.contacts}>
      <div className={styles.wrapper}>
        <header className={styles.header}>
          <h1>Контакты</h1>
          <p>
            Мы на связи в будни и выходные. Напишите нам — и команда ответит в течение 24 часов.
            <br />
            Email поддержки: <a href="mailto:support@videocovers-avatars.com">support@videocovers-avatars.com</a>
          </p>
        </header>

        <div className={styles.content}>
          <div className={styles.info}>
            <h2>Офис и реквизиты</h2>
            <ul>
              <li>
                <strong>Адрес:</strong> 123456, г. Москва, ул. Цифровая, д. 7, офис 14
              </li>
              <li>
                <strong>Телефон:</strong>{' '}
                <a href="tel:+74951234567" className={styles.link}>
                  +7 (495) 123-45-67
                </a>
              </li>
              <li>
                <strong>Email поддержки:</strong>{' '}
                <a href="mailto:support@videocovers-avatars.com" className={styles.link}>
                  support@videocovers-avatars.com
                </a>
              </li>
              <li>
                <strong>Для дизайнеров:</strong>{' '}
                <a href="mailto:creators@videocovers-avatars.com" className={styles.link}>
                  creators@videocovers-avatars.com
                </a>
              </li>
            </ul>
            <div className={styles.mapWrapper}>
              <iframe
                title="Офис VideoCovers & Avatars"
                src="https://maps.google.com/maps?q=%D0%BC%D0%BE%D1%81%D0%BA%D0%B2%D0%B0%20%D1%83%D0%BB%20%D0%A6%D0%B8%D1%84%D1%80%D0%BE%D0%B2%D0%B0%D1%8F%207&t=&z=13&ie=UTF8&iwloc=&output=embed"
                loading="lazy"
              />
            </div>
          </div>

          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <h2>Напишите нам</h2>
            <div className={styles.field}>
              <label htmlFor="name">Имя / Компания</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </div>

            <div className={styles.field}>
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </div>

            <div className={styles.field}>
              <label htmlFor="topic">Тема обращения</label>
              <input
                id="topic"
                name="topic"
                type="text"
                value={formData.topic}
                onChange={handleChange}
              />
            </div>

            <div className={styles.field}>
              <label htmlFor="message">Сообщение</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </div>

            <button type="submit" className={styles.submit}>
              Отправить запрос
            </button>

            {submitted && (
              <div className={styles.success}>
                Спасибо! Ваше сообщение отправлено. Мы свяжемся с вами в ближайшее время.
              </div>
            )}
          </form>
        </div>
      </div>
    </section>
  );
};

export default Contacts;
```

Need CSS.