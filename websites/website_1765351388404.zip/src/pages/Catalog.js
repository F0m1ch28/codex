```javascript
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Catalog.module.css';

const items = [
  {
    id: 1,
    title: 'Pulse Motion Cover',
    category: 'covers',
    tags: ['YouTube', 'Музыка'],
    image: 'https://via.placeholder.com/400x260?text=Cover'
  },
  {
    id: 2,
    title: 'Storyline Thumbnail Kit',
    category: 'covers',
    tags: ['Vlog', 'Lifestyle'],
    image: 'https://via.placeholder.com/400x260?text=Thumbnail'
  },
  {
    id: 3,
    title: 'Avatar Neon Flux',
    category: 'avatars',
    tags: ['Streamer', 'Электро'],
    image: 'https://via.placeholder.com/400x260?text=Avatar'
  },
  {
    id: 4,
    title: 'Podcast Profile Set',
    category: 'avatars',
    tags: ['Podcast', 'Minimal'],
    image: 'https://via.placeholder.com/400x260?text=Profile'
  },
  {
    id: 5,
    title: 'Stream Overlay Nova',
    category: 'banners',
    tags: ['Twitch', 'OBS'],
    image: 'https://via.placeholder.com/400x260?text=Overlay'
  },
  {
    id: 6,
    title: 'Panel Gradient Pack',
    category: 'banners',
    tags: ['Trovo', 'Panels'],
    image: 'https://via.placeholder.com/400x260?text=Panels'
  },
  {
    id: 7,
    title: 'Channel Skyline Header',
    category: 'headers',
    tags: ['YouTube', 'Бренд'],
    image: 'https://via.placeholder.com/400x260?text=Header'
  },
  {
    id: 8,
    title: 'Community Aura Cover',
    category: 'headers',
    tags: ['VK', 'Сообщество'],
    image: 'https://via.placeholder.com/400x260?text=Community'
  }
];

const filters = [
  { value: 'all', label: 'Все' },
  { value: 'covers', label: 'Обложки для видео' },
  { value: 'avatars', label: 'Аватарки' },
  { value: 'banners', label: 'Баннеры для стримов' },
  { value: 'headers', label: 'Шапки для каналов' }
];

const Catalog = () => {
  usePageMetadata({
    title: 'Каталог дизайнов — VideoCovers & Avatars',
    description:
      'Обложки для видео, аватарки, баннеры для стримов и шапки каналов. Найдите графику для YouTube, Twitch и других платформ.'
  });

  const location = useLocation();
  const [activeFilter, setActiveFilter] = useState('all');

  useEffect(() => {
    if (location.state?.category) {
      setActiveFilter(location.state.category);
    }
  }, [location.state]);

  const filteredItems =
    activeFilter === 'all' ? items : items.filter((item) => item.category === activeFilter);

  return (
    <section className={styles.catalog}>
      <div className={styles.wrapper}>
        <header className={styles.header}>
          <h1>Каталог дизайнов</h1>
          <p>
            Проверенные авторские работы. Используйте фильтры, чтобы найти решения для платформы,
            которая важна именно вам.
          </p>
        </header>

        <div className={styles.filters} role="tablist" aria-label="Фильтр категорий">
          {filters.map((filter) => (
            <button
              key={filter.value}
              type="button"
              role="tab"
              className={`${styles.filterButton} ${
                activeFilter === filter.value ? styles.filterActive : ''
              }`}
              onClick={() => setActiveFilter(filter.value)}
            >
              {filter.label}
            </button>
          ))}
        </div>

        <div className={styles.grid}>
          {filteredItems.map((item) => (
            <article key={item.id} className={styles.card}>
              <img src={item.image} alt={item.title} loading="lazy" />
              <div className={styles.cardBody}>
                <span className={styles.badge}>
                  {filters.find((filter) => filter.value === item.category)?.label}
                </span>
                <h3>{item.title}</h3>
                <ul className={styles.tags}>
                  {item.tags.map((tag) => (
                    <li key={tag}>#{tag}</li>
                  ))}
                </ul>
                <a href="#!" className={styles.detailsLink}>
                  Подробнее
                </a>
              </div>
            </article>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className={styles.emptyState}>
            <h3>В этой категории пока нет работ</h3>
            <p>Загляните позже или напишите нам, чтобы оформить индивидуальный заказ.</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default Catalog;
```

Need CSS.