```javascript
import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './HowItWorks.module.css';

const steps = [
  {
    title: 'Исследование и подбор',
    description:
      'Фильтруйте каталог по форматам, цветам и платформам. Используйте теги и подборки, чтобы отобрать работы, соответствующие вашему проекту.',
    image: 'https://picsum.photos/800/500?random=701'
  },
  {
    title: 'Согласование деталей',
    description:
      'Добавляйте работы в коллекцию, формируйте запросы на адаптацию. Дизайнер получает уведомление и уточняет задачи в чате платформы.',
    image: 'https://picsum.photos/800/500?random=702'
  },
  {
    title: 'Доставка и сопровождение',
    description:
      'После утверждения вы получаете доступ к финальным файлам. Команда поддержки следит за качеством и помогает при необходимости внести правки.',
    image: 'https://picsum.photos/800/500?random=703'
  }
];

const extras = [
  'Интегрированный чат для обсуждения правок',
  'Библиотека полезных гайдов по визуальному брендингу',
  'Безопасное хранение файлов и история версий',
  'Персональные подборки от кураторов платформы'
];

const HowItWorks = () => {
  usePageMetadata({
    title: 'Как работает VideoCovers & Avatars',
    description:
      'Узнайте, как устроен процесс работы на платформе VideoCovers & Avatars: подбор, согласование и получение файлов.'
  });

  return (
    <section className={styles.how}>
      <div className={styles.wrapper}>
        <header className={styles.header}>
          <h1>Как это работает</h1>
          <p>
            Мы построили процесс так, чтобы дизайнеры и авторы говорили на одном языке. Никакой бюрократии — только
            понятные шаги и удобные инструменты для сотрудничества.
          </p>
        </header>

        <div className={styles.stepsGrid}>
          {steps.map((step) => (
            <article key={step.title} className={styles.stepCard}>
              <img src={step.image} alt={step.title} loading="lazy" />
              <div className={styles.stepContent}>
                <h2>{step.title}</h2>
                <p>{step.description}</p>
              </div>
            </article>
          ))}
        </div>

        <section className={styles.extraSection}>
          <div className={styles.extraCard}>
            <h2>Что ещё вы получаете</h2>
            <ul>
              {extras.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </section>
      </div>
    </section>
  );
};

export default HowItWorks;
```

Need CSS.