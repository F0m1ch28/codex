```javascript
import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Privacy.module.css';

const Privacy = () => {
  usePageMetadata({
    title: 'Политика конфиденциальности — VideoCovers & Avatars',
    description:
      'Политика конфиденциальности платформы VideoCovers & Avatars. Узнайте, как мы обрабатываем и защищаем ваши данные.'
  });

  return (
    <section className={styles.legal}>
      <div className={styles.wrapper}>
        <h1>Политика конфиденциальности</h1>
        <p>Дата обновления: 10 января 2024 года</p>

        <article>
          <h2>1. Сбор данных</h2>
          <p>
            Мы собираем минимальный набор персональных данных для регистраций, оплаты и коммуникаций. Это может
            включать имя, электронную почту и ссылки на портфолио.
          </p>
        </article>

        <article>
          <h2>2. Использование данных</h2>
          <p>
            Информация используется для предоставления услуг, поддержания связи и отправки уведомлений о статусе заказов
            и обновлениях платформы.
          </p>
        </article>

        <article>
          <h2>3. Хранение и защита</h2>
          <p>
            Данные хранятся на защищённых серверах. Мы применяем технические и организационные меры, чтобы предотвратить
            несанкционированный доступ.
          </p>
        </article>

        <article>
          <h2>4. Передача третьим лицам</h2>
          <p>
            Мы не передаём персональные данные третьим сторонам без вашего согласия, за исключением случаев, предусмотренных
            законодательством.
          </p>
        </article>

        <article>
          <h2>5. Права пользователя</h2>
          <p>
            Вы можете запросить доступ, обновление или удаление своих данных. Для этого напишите на{' '}
            <a href="mailto:support@videocovers-avatars.com">support@videocovers-avatars.com</a>.
          </p>
        </article>
      </div>
    </section>
  );
};

export default Privacy;
```

Need CSS.