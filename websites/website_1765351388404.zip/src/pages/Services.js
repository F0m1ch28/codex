```javascript
import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Services.module.css';

const services = [
  {
    title: 'Премиальные обложки для видео',
    description:
      'Композиции, адаптированные под актуальные алгоритмы YouTube. Подбор цветовых акцентов, работа с текстовыми блоками и персонажами.',
    image: 'https://picsum.photos/800/600?random=601'
  },
  {
    title: 'Пакеты сцен для стримов',
    description:
      'Готовые сцены «Скоро начнём», «Перерыв», «Общение» и интерактивные панели. Совместимо с OBS, Streamlabs и Lightstream.',
    image: 'https://picsum.photos/800/600?random=602'
  },
  {
    title: 'Фирменные наборы для команд',
    description:
      'Комплексные brand kits для киберспортивных организаций, продюсерских центров и студий подкастов.',
    image: 'https://picsum.photos/800/600?random=603'
  }
];

const addOns = [
  {
    title: 'Персональная адаптация',
    description: 'Настраиваем цвета, логотипы и шрифты под ваш бренд всего за 24 часа.'
  },
  {
    title: 'Подготовка анимации',
    description: 'Создаём анимированные вступления и переходы, готовые к использованию на стримах.'
  },
  {
    title: 'Экспресс-анализ канала',
    description: 'Даем рекомендации по визуалу и подсказываем, как повысить узнаваемость в соцсетях.'
  }
];

const Services = () => {
  usePageMetadata({
    title: 'Услуги по дизайну — VideoCovers & Avatars',
    description:
      'Профессиональные услуги по созданию обложек, пакетов сцен и фирменных наборов для авторов контента.'
  });

  return (
    <section className={styles.services}>
      <div className={styles.wrapper}>
        <header className={styles.header}>
          <h1>Услуги платформы</h1>
          <p>
            Помимо каталога готовых работ мы предоставляем индивидуальные услуги. Команда опытных дизайнеров помогает
            адаптировать стиль и подготовить уникальные материалы для вашего проекта.
          </p>
        </header>

        <div className={styles.serviceGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <img src={service.image} alt={service.title} loading="lazy" />
              <div className={styles.serviceContent}>
                <h2>{service.title}</h2>
                <p>{service.description}</p>
                <a href="/contacts" className={styles.serviceLink}>
                  Связаться для обсуждения
                </a>
              </div>
            </article>
          ))}
        </div>

        <section className={styles.addOns} aria-labelledby="addons-heading">
          <h2 id="addons-heading">Дополнительные опции</h2>
          <div className={styles.addOnGrid}>
            {addOns.map((item) => (
              <article key={item.title} className={styles.addOnCard}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </section>
      </div>
    </section>
  );
};

export default Services;
```

Need CSS.