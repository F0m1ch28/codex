```javascript
import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './About.module.css';

const milestones = [
  {
    year: '2019',
    title: 'Идея платформы',
    description: 'Команда дизайнеров столкнулась с нехваткой витрин для цифровых графических работ.'
  },
  {
    year: '2020',
    title: 'Запуск каталога',
    description: 'Первые 50 авторов опубликовали коллекции обложек и аватарок для YouTube и Twitch.'
  },
  {
    year: '2022',
    title: 'Международное расширение',
    description: 'Добавили поддержку английского интерфейса и подключили дизайнеров из Европы и Азии.'
  },
  {
    year: '2023',
    title: 'Инструменты для студий',
    description: 'Появились совместные кабинеты и аналитика для продюсерских команд.'
  }
];

const team = [
  {
    name: 'Дарья Коваль',
    role: 'CEO и сооснователь',
    description: 'Ответственная за стратегию платформы и взаимодействие с партнёрами.',
    image: 'https://picsum.photos/400/400?random=501'
  },
  {
    name: 'Илья Жуков',
    role: 'Creative Director',
    description: 'Формирует стандарты качества и помогает дизайнерам развивать портфолио.',
    image: 'https://picsum.photos/400/400?random=502'
  },
  {
    name: 'Софи Чэнь',
    role: 'Head of Community',
    description: 'Куратор программ для авторов и организатор обучающих сессий.',
    image: 'https://picsum.photos/400/400?random=503'
  }
];

const values = [
  {
    title: 'Честность и оригинальность',
    text: 'Каждая работа проходит проверку на оригинальность. Мы не публикуем шаблоны с нарушением авторских прав.'
  },
  {
    title: 'Партнёрство с создателями',
    text: 'Мы строим доверие через прозрачные условия и поддержку на всех этапах — от загрузки до обратной связи.'
  },
  {
    title: 'Постоянное развитие',
    text: 'Следим за трендами визуала и совершенствуем инструменты, чтобы авторам было удобно экспериментировать.'
  }
];

const About = () => {
  usePageMetadata({
    title: 'О компании VideoCovers & Avatars',
    description:
      'Узнайте историю, миссию и команду VideoCovers & Avatars. Мы создаём пространство для дизайнеров и авторов контента.'
  });

  return (
    <section className={styles.about}>
      <div className={styles.wrapper}>
        <header className={styles.header}>
          <h1>О нас</h1>
          <p>
            VideoCovers &amp; Avatars — международный маркетплейс графики, который помогает создателям контента получить
            визуальный стиль без компромиссов. Мы объединили дизайнеров, продюсеров и тех, кто ценит яркий визуал.
          </p>
        </header>

        <section className={styles.mission}>
          <div>
            <h2>Наша миссия</h2>
            <p>
              Мы стремимся сделать качественный дизайн доступным каждому автору. Независимо от того, ведёте ли вы
              небольшой блог или управляете медиахолдингом, у вас должен быть доступ к профессиональным дизайнерам и
              проверенным инструментам для масштабирования визуальной коммуникации.
            </p>
            <p>
              Платформа соединяет свободных художников и креаторов, предоставляя прозрачную инфраструктуру и понятные
              процессы сотрудничества.
            </p>
          </div>
          <img
            src="https://picsum.photos/900/700?random=511"
            alt="Команда дизайнеров за обсуждением проекта"
            loading="lazy"
          />
        </section>

        <section className={styles.timeline} aria-labelledby="timeline-heading">
          <h2 id="timeline-heading">Ключевые этапы</h2>
          <div className={styles.timelineGrid}>
            {milestones.map((milestone) => (
              <article key={milestone.year} className={styles.timelineCard}>
                <span className={styles.timelineYear}>{milestone.year}</span>
                <h3>{milestone.title}</h3>
                <p>{milestone.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.values} aria-labelledby="values-heading">
          <h2 id="values-heading">Наши ценности</h2>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.team} aria-labelledby="team-heading">
          <div className={styles.teamHeader}>
            <h2 id="team-heading">Лица платформы</h2>
            <p>
              За успехом VideoCovers &amp; Avatars стоит мультикультурная команда, объединённая любовью к дизайну и
              технологиям.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <span className={styles.teamRole}>{member.role}</span>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>
    </section>
  );
};

export default About;
```

Need CSS.