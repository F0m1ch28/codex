```javascript
import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'videocovers-avatars-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem(COOKIE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div>
        <p className={styles.text}>
          Мы используем cookie, чтобы сайт работал стабильно и персонализировал рекомендации. Продолжая
          пользоваться ресурсом, вы соглашаетесь с{' '}
          <a href="/cookie-policy" className={styles.link}>
            политикой использования файлов cookie
          </a>
          .
        </p>
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;
```