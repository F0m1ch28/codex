import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './ServicesPage.module.css';

const serviceAreas = [
  {
    title: 'Brand Transformation',
    subtitle: 'Strategy · Identity · Voice',
    description:
      'Comprehensive brand programmes that translate positioning into living systems across visual, verbal, and sonic expressions.',
    benefits: ['Brand workshops', 'Design systems', 'Packaging suites', 'Guideline playbooks'],
    image: 'https://picsum.photos/600/400?random=71',
  },
  {
    title: 'Integrated Campaigns',
    subtitle: 'Creative · Media · Production',
    description:
      'Full-funnel campaign orchestration that converges creativity, media strategy, and agile production to drive measurable growth.',
    benefits: ['Campaign architecture', 'Audience mapping', 'Paid media strategy', 'Asset production'],
    image: 'https://picsum.photos/600/400?random=72',
  },
  {
    title: 'Digital Experience',
    subtitle: 'UX · Platforms · Emerging Tech',
    description:
      'Digital products and touchpoints designed for frictionless journeys, backed by performance analytics and experimentation.',
    benefits: ['CX audits', 'Website & app builds', 'CRO roadmaps', 'Analytics ops'],
    image: 'https://picsum.photos/600/400?random=73',
  },
  {
    title: 'Experiential & Events',
    subtitle: 'Spatial · Hybrid · Live Content',
    description:
      'Immersive experiences bridging physical and digital worlds, from flagship activations to travelling pop-ups.',
    benefits: ['Concept & scenography', 'Production planning', 'Interactive tech', 'Onsite storytelling'],
    image: 'https://picsum.photos/600/400?random=74',
  },
];

const ServicesPage = () => {
  const [activeService, setActiveService] = useState(serviceAreas[0]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Services | AdWorld Belgium</title>
        <meta
          name="description"
          content="Discover the spectrum of services offered by Belgium’s top advertising agencies—from brand transformation and integrated campaigns to immersive experiences."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Capabilities designed for bold Belgian brands.</h1>
        <p>
          AdWorld Belgium outlines core service verticals offered by leading agencies, helping you pinpoint the expertise
          your campaign needs. Explore the spectrum and connect with specialists ready to make an impact.
        </p>
      </section>
      <section className={styles.layout}>
        <div className={styles.menu}>
          {serviceAreas.map((service) => (
            <button
              key={service.title}
              type="button"
              className={`${styles.tab} ${activeService.title === service.title ? styles.active : ''}`}
              onClick={() => setActiveService(service)}
            >
              <span>{service.title}</span>
              <small>{service.subtitle}</small>
            </button>
          ))}
        </div>
        <div className={styles.detail}>
          <img src={activeService.image} alt={`${activeService.title} illustration`} />
          <div className={styles.detailText}>
            <h2>{activeService.title}</h2>
            <p>{activeService.description}</p>
            <ul>
              {activeService.benefits.map((benefit) => (
                <li key={benefit}>{benefit}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;