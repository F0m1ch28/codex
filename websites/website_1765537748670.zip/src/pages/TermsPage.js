import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './TermsPage.module.css';

const TermsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms of Use | AdWorld Belgium</title>
      <meta
        name="description"
        content="Review the terms of use that govern your access to AdWorld Belgium’s website and services."
      />
    </Helmet>
    <h1>Terms of Use</h1>
    <p>Last updated: February 2024</p>
    <h2>1. Acceptance of terms</h2>
    <p>
      By accessing or using AdWorld Belgium, you agree to comply with and be bound by these Terms of Use. If you do not
      agree to all of these terms, you must not use the website.
    </p>
    <h2>2. Use of content</h2>
    <p>
      All content on this site, including text, imagery, and resources, is owned or licensed by AdWorld Belgium. You may
      use the content for informational purposes only. Any reproduction, distribution, or modification requires prior
      written consent.
    </p>
    <h2>3. Advisory services</h2>
    <p>
      Recommendations provided through our advisory services are based on information supplied by clients and agencies.
      AdWorld Belgium does not guarantee specific outcomes or results.
    </p>
    <h2>4. Limitation of liability</h2>
    <p>
      We strive to keep information accurate and up to date; however, AdWorld Belgium does not warrant the completeness or
      reliability of content. We are not liable for any direct or indirect damages resulting from the use of this site.
    </p>
    <h2>5. Changes to terms</h2>
    <p>
      We may update these terms periodically. Continued use of the site after changes constitutes acceptance of the
      revised terms. We encourage users to review this page regularly.
    </p>
  </div>
);

export default TermsPage;