import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PrivacyPage.module.css';

const PrivacyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Policy | AdWorld Belgium</title>
      <meta
        name="description"
        content="Understand how AdWorld Belgium collects, uses, and protects your personal data when you interact with our services."
      />
    </Helmet>
    <h1>Privacy Policy</h1>
    <p>Effective date: February 2024</p>
    <h2>Information we collect</h2>
    <p>
      We collect personal data that you voluntarily provide, such as your name, email address, and company information when
      you submit forms or request advisory support. We also collect usage data including IP addresses, device details, and
      browsing behaviour through analytics tools.
    </p>
    <h2>How we use your data</h2>
    <p>
      Data is used to respond to inquiries, deliver advisory services, personalise content, and improve our platform. We may
      send updates or insights with your consent and you can opt out at any time.
    </p>
    <h2>Data sharing</h2>
    <p>
      We do not sell your personal data. We may share limited information with trusted service providers who support our
      operations, subject to confidentiality agreements and GDPR compliance.
    </p>
    <h2>Your rights</h2>
    <p>
      You have the right to access, correct, or delete your personal data, restrict processing, and request data portability.
      To exercise these rights, contact us at info@adworld-belgium.com.
    </p>
    <h2>Data security</h2>
    <p>
      We implement administrative, technical, and physical safeguards to protect personal data. While we strive to ensure
      security, no method of transmission is entirely secure.
    </p>
    <h2>Updates</h2>
    <p>
      We may update this policy to reflect operational, legal, or regulatory changes. Revisions will be posted on this page
      with an updated effective date.
    </p>
  </div>
);

export default PrivacyPage;