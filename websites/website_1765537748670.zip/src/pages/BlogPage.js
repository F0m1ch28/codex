import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './BlogPage.module.css';

const posts = [
  {
    title: 'How Belgian agencies are rethinking hybrid experiences',
    category: 'Experiential',
    summary:
      'A look at the technology, partnerships, and creative formats driving the next wave of hybrid activations across Belgium.',
    author: 'Anika Janssens',
    date: 'February 2, 2024',
    image: 'https://picsum.photos/800/600?random=81',
  },
  {
    title: 'Brand storytelling with authenticity in regulated industries',
    category: 'Strategy',
    summary:
      'We explore best-in-class examples from fintech, healthcare, and energy brands balancing compliance with creativity.',
    author: 'Thomas Verbeeck',
    date: 'January 18, 2024',
    image: 'https://picsum.photos/800/600?random=82',
  },
  {
    title: 'Data collaborations that supercharge campaign performance',
    category: 'Performance',
    summary:
      'Insights into how agencies and brands collaborate on clean rooms, first-party data, and predictive modelling.',
    author: 'Elise Laurent',
    date: 'January 4, 2024',
    image: 'https://picsum.photos/800/600?random=83',
  },
];

const BlogPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Insights &amp; Updates | AdWorld Belgium</title>
      <meta
        name="description"
        content="Stay updated with AdWorld Belgium’s insights on creative trends, pitch best practices, and performance strategies in the Belgian advertising scene."
      />
    </Helmet>
    <section className={styles.header}>
      <h1>Insights, playbooks, and agency spotlights.</h1>
      <p>
        Discover how Belgian marketers are designing standout campaigns, experimenting with new formats, and measuring
        success across the funnel.
      </p>
    </section>
    <section className={styles.grid}>
      {posts.map((post) => (
        <article key={post.title}>
          <img src={post.image} alt={`${post.title} illustration`} />
          <div className={styles.body}>
            <span>{post.category}</span>
            <h2>{post.title}</h2>
            <p>{post.summary}</p>
            <div className={styles.meta}>
              <strong>{post.author}</strong>
              <span>{post.date}</span>
            </div>
          </div>
        </article>
      ))}
    </section>
  </div>
);

export default BlogPage;