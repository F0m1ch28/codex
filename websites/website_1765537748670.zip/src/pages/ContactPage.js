import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './ContactPage.module.css';

const initialState = {
  name: '',
  email: '',
  message: '',
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialState);
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    if (!formData.name.trim()) {
      return 'Please enter your full name.';
    }
    if (!formData.email.trim()) {
      return 'Please enter your email address.';
    }
    if (!/\S+@\S+\.\S+/.test(formData.email)) {
      return 'Please provide a valid email address.';
    }
    if (!formData.message.trim()) {
      return 'Please include a message.';
    }
    return '';
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const error = validate();
    if (error) {
      setStatus({ type: 'error', message: error });
      return;
    }
    setStatus({ type: 'success', message: 'Thank you! We will respond within two business days.' });
    setFormData(initialState);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact AdWorld Belgium</title>
        <meta
          name="description"
          content="Contact AdWorld Belgium for tailored agency recommendations, partnership inquiries, or media opportunities."
        />
      </Helmet>
      <section className={styles.info}>
        <h1>Let’s build your next campaign partnership.</h1>
        <p>
          Share your campaign details and our advisory team will get in touch with curated agency recommendations and
          next steps.
        </p>
        <ul>
          <li><strong>Address:</strong> Belgium</li>
          <li><strong>Phone:</strong> +32 000 00 00 00</li>
          <li><strong>Email:</strong> info@adworld-belgium.com</li>
        </ul>
      </section>
      <section className={styles.formWrapper}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="name">Full name</label>
          <input
            id="name"
            name="name"
            type="text"
            required
            value={formData.name}
            onChange={handleChange}
            placeholder="Your full name"
          />
          <label htmlFor="email">Email</label>
          <input
            id="email"
            name="email"
            type="email"
            required
            value={formData.email}
            onChange={handleChange}
            placeholder="you@example.com"
          />
          <label htmlFor="message">Message</label>
          <textarea
            id="message"
            name="message"
            required
            rows="6"
            value={formData.message}
            onChange={handleChange}
            placeholder="Tell us about your campaign, timeline, and objectives."
          />
          {status.message && (
            <div className={`${styles.status} ${status.type === 'success' ? styles.success : styles.error}`}>
              {status.message}
            </div>
          )}
          <button type="submit" className={styles.submit}>Send Message</button>
        </form>
      </section>
    </div>
  );
};

export default ContactPage;