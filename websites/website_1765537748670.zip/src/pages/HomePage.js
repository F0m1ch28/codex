import React, { useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './HomePage.module.css';

const statsTargets = {
  agencies: 48,
  partnerships: 120,
  campaigns: 360,
  awards: 58,
};

const testimonialsData = [
  {
    name: 'Charlotte De Wilde',
    role: 'Marketing Director, Urban Bloom',
    quote:
      'AdWorld Belgium made it effortless to compare agencies. We discovered a partner that understood our sustainability mission and delivered a 40% lift in brand engagement.',
    avatar: 'https://picsum.photos/200/200?random=61',
  },
  {
    name: 'Khalid Ben Aissa',
    role: 'Co-Founder, Orbit Studios',
    quote:
      'The depth of insight in each agency profile goes beyond a simple directory. We saved weeks of research time and launched our campaign ahead of schedule.',
    avatar: 'https://picsum.photos/200/200?random=62',
  },
  {
    name: 'Sophie Van Damme',
    role: 'Head of Growth, FinixPay',
    quote:
      'We loved the strategic guidance. The tailored shortlist and sector benchmarks helped us secure the right creative partner for regulated fintech marketing.',
    avatar: 'https://picsum.photos/200/200?random=63',
  },
];

const projectsData = [
  {
    title: 'Immersive Heritage Campaign',
    category: 'Experiential',
    description: 'Multi-sensory activation celebrating Belgian design week with AR storytelling and street projections.',
    image: 'https://picsum.photos/1200/800?random=41',
  },
  {
    title: 'Fintech Trust Series',
    category: 'Digital',
    description: 'Performance marketing and thought-leadership hub for a European payments scale-up.',
    image: 'https://picsum.photos/1200/800?random=42',
  },
  {
    title: 'Sustainable Fashion Launch',
    category: 'Branding',
    description: 'Identity refresh and launch campaign for an eco-conscious apparel label across Antwerp and Ghent.',
    image: 'https://picsum.photos/1200/800?random=43',
  },
  {
    title: 'Smart Mobility Showcase',
    category: 'Digital',
    description: 'Interactive microsite and data-driven media plan for an autonomous vehicle pilot.',
    image: 'https://picsum.photos/1200/800?random=44',
  },
  {
    title: 'Belgian Craft Spirits',
    category: 'Branding',
    description: 'Heritage narrative, packaging, and on-trade activations championing local distillers.',
    image: 'https://picsum.photos/1200/800?random=45',
  },
];

const faqItems = [
  {
    question: 'How are agencies evaluated before being featured?',
    answer:
      'Every agency on AdWorld Belgium is vetted through an editorial review, client interviews, and performance data analysis. We examine creative output, sector expertise, leadership, and measurable campaign results.',
  },
  {
    question: 'Can brands request a tailored shortlist?',
    answer:
      'Absolutely. Submit your campaign objectives via our Contact form and our advisory team will prepare a curated shortlist, complete with chemistry session recommendations and pitch preparation tips.',
  },
  {
    question: 'Do you cover agencies outside major cities?',
    answer:
      'Yes. We highlight talent from Brussels, Antwerp, Ghent, Leuven, Liège, and emerging creative hubs across Belgium, ensuring access to niche specialists as well as full-service leaders.',
  },
];

const HomePage = () => {
  const [stats, setStats] = useState({
    agencies: 0,
    partnerships: 0,
    campaigns: 0,
    awards: 0,
  });
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('All');

  useEffect(() => {
    const intervals = Object.keys(statsTargets).map((key) => {
      const increment = Math.ceil(statsTargets[key] / 40);
      return setInterval(() => {
        setStats((prev) => {
          const nextValue = Math.min(prev[key] + increment, statsTargets[key]);
          return { ...prev, [key]: nextValue };
        });
      }, 60);
    });
    return () => intervals.forEach(clearInterval);
  }, []);

  useEffect(() => {
    const rotation = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 6000);
    return () => clearInterval(rotation);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'All') return projectsData;
    return projectsData.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>AdWorld Belgium | Discover Elite Advertising Agencies</title>
        <meta
          name="description"
          content="AdWorld Belgium is the definitive platform to explore top advertising agencies, creative expertise, and marketing services shaping Belgian brands."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroMedia}>
          <img src="https://picsum.photos/1600/900?random=11" alt="Creative marketing team collaborating" />
        </div>
        <div className={styles.heroContent}>
          <p className={styles.pill}>Belgium’s Advertising Vanguard</p>
          <h1>Elevate every campaign with the right Belgian agency partner.</h1>
          <p>
            Navigate a curated ecosystem of award-winning agencies, sector specialists, and breakthrough campaigns
            delivering measurable brand impact.
          </p>
          <div className={styles.heroActions}>
            <Link to="/agencies" className={styles.primaryCta}>
              Find Your Agency Match
            </Link>
            <Link to="/guide" className={styles.secondaryCta}>
              Explore the Selection Guide
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.why}>
        <div className={styles.sectionHeader}>
          <p className={styles.eyebrow}>Why AdWorld Belgium</p>
          <h2>Expert insights meet trusted agency relationships.</h2>
          <p>
            We audit agencies across creative excellence, strategic rigor, data fluency, and cultural fit—giving you the
            confidence to commission bold work.
          </p>
        </div>
        <div className={styles.statsGrid}>
          <div>
            <span>{stats.agencies}+</span>
            <p>Verified Belgian agencies profiled with in-depth insights.</p>
          </div>
          <div>
            <span>{stats.partnerships}+</span>
            <p>Brand-agency partnerships facilitated via our advisory desk.</p>
          </div>
          <div>
            <span>{stats.campaigns}+</span>
            <p>Campaign case studies benchmarked across key industries.</p>
          </div>
          <div>
            <span>{stats.awards}</span>
            <p>Prestigious awards represented across our featured agencies.</p>
          </div>
        </div>
      </section>

      <section className={styles.featured}>
        <div className={styles.sectionHeader}>
          <p className={styles.eyebrow}>Featured agencies</p>
          <h2>Front-runners shaping Belgium’s creative landscape.</h2>
        </div>
        <div className={styles.cards}>
          <article>
            <img src="https://picsum.photos/800/600?random=21" alt="Agency studio interior" />
            <h3>Studio Lumen</h3>
            <p>Ghent-based storytellers connecting heritage brands with immersive digital experiences.</p>
            <Link to="/agencies" aria-label="View Studio Lumen profile">View profile</Link>
          </article>
          <article>
            <img src="https://picsum.photos/800/600?random=22" alt="Creative campaign storyboard" />
            <h3>Orbit Pulse</h3>
            <p>Brussels strategy collective aligning performance marketing with culture-first creativity.</p>
            <Link to="/agencies" aria-label="View Orbit Pulse profile">View profile</Link>
          </article>
          <article>
            <img src="https://picsum.photos/800/600?random=23" alt="Team collaborating on digital campaign" />
            <h3>Maison Nova</h3>
            <p>Luxury specialists elevating premium Belgian brands through meticulous craft and design.</p>
            <Link to="/agencies" aria-label="View Maison Nova profile">View profile</Link>
          </article>
        </div>
      </section>

      <section className={styles.servicesProcess}>
        <div className={styles.servicesBlock}>
          <div className={styles.sectionHeader}>
            <p className={styles.eyebrow}>Key services</p>
            <h2>Solutions engineered for modern marketers.</h2>
            <p>
              From brand relaunches and integrated media to experiential innovation, explore the services powering Belgium’s
              most successful campaigns.
            </p>
          </div>
          <div className={styles.serviceGrid}>
            <div>
              <h3>Brand &amp; Design Systems</h3>
              <p>Identity development, sonic branding, and packaging that builds recognition across every touchpoint.</p>
            </div>
            <div>
              <h3>Performance Acceleration</h3>
              <p>Data-informed media strategies aligned with conversion goals and lifetime value metrics.</p>
            </div>
            <div>
              <h3>Content &amp; Social Narratives</h3>
              <p>Editorial frameworks and always-on storytelling tailored to the Belgian cultural landscape.</p>
            </div>
            <div>
              <h3>Experiential Innovation</h3>
              <p>Hybrid events, pop-ups, and AR activations that connect audiences to brand purpose.</p>
            </div>
          </div>
          <Link to="/services" className={styles.primaryCtaSmall}>Discover the service suite</Link>
        </div>
        <div className={styles.processBlock}>
          <h2>Our collaborative selection process.</h2>
          <ul>
            <li>
              <span>01</span>
              <div>
                <h4>Clarify your campaign ambitions</h4>
                <p>Define outcomes, audience insights, and critical timelines with our advisory team.</p>
              </div>
            </li>
            <li>
              <span>02</span>
              <div>
                <h4>Curate a shortlist</h4>
                <p>Receive a data-backed shortlist with chemistry considerations and work samples aligned to your brief.</p>
              </div>
            </li>
            <li>
              <span>03</span>
              <div>
                <h4>Engage &amp; evaluate</h4>
                <p>Plan discovery sessions, review strategic proposals, and score creative alignment with our evaluation toolkit.</p>
              </div>
            </li>
            <li>
              <span>04</span>
              <div>
                <h4>Launch with confidence</h4>
                <p>Use our onboarding checklists, KPI frameworks, and campaign retrospectives to ensure long-term success.</p>
              </div>
            </li>
          </ul>
        </div>
      </section>

      <section className={styles.testimonialsTeam}>
        <div className={styles.testimonial}>
          <p className={styles.eyebrow}>Testimonials</p>
          <h2>Trusted by ambitious Belgian brands.</h2>
          <div className={styles.testimonialCard}>
            <img src={testimonialsData[activeTestimonial].avatar} alt={`Portrait of ${testimonialsData[activeTestimonial].name}`} />
            <blockquote>
              <p>“{testimonialsData[activeTestimonial].quote}”</p>
              <footer>
                <strong>{testimonialsData[activeTestimonial].name}</strong>
                <span>{testimonialsData[activeTestimonial].role}</span>
              </footer>
            </blockquote>
          </div>
          <div className={styles.dots}>
            {testimonialsData.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`${styles.dot} ${index === activeTestimonial ? styles.activeDot : ''}`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Show testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
        <div className={styles.team}>
          <p className={styles.eyebrow}>AdWorld Advisors</p>
          <h2>Meet the strategists behind the platform.</h2>
          <div className={styles.teamGrid}>
            <article>
              <img src="https://picsum.photos/400/400?random=31" alt="Portrait of Elise Laurent" />
              <h3>Elise Laurent</h3>
              <span>Head of Agency Partnerships</span>
              <p>Former agency leader guiding brand-agency matchmaking with deep sector knowledge.</p>
            </article>
            <article>
              <img src="https://picsum.photos/400/400?random=32" alt="Portrait of Thomas Verbeeck" />
              <h3>Thomas Verbeeck</h3>
              <span>Strategy &amp; Insights Lead</span>
              <p>Data storyteller translating campaign analytics into clear decision-making frameworks.</p>
            </article>
            <article>
              <img src="https://picsum.photos/400/400?random=33" alt="Portrait of Anika Janssens" />
              <h3>Anika Janssens</h3>
              <span>Creative Curator</span>
              <p>Curates award-winning case studies and highlights emerging creative talent in Belgium.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.sectionHeader}>
          <p className={styles.eyebrow}>Project showcase</p>
          <h2>See how agencies transform Belgian brand stories.</h2>
        </div>
        <div className={styles.filters}>
          {['All', 'Digital', 'Branding', 'Experiential'].map((category) => (
            <button
              key={category}
              type="button"
              className={`${styles.filterButton} ${category === activeCategory ? styles.filterActive : ''}`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title}>
              <img src={project.image} alt={`${project.title} visual`} loading="lazy" />
              <div>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.insightsFaq}>
        <div className={styles.insights}>
          <div className={styles.sectionHeader}>
            <p className={styles.eyebrow}>Latest blog insights</p>
            <h2>Fresh intelligence for campaign leaders.</h2>
          </div>
          <div className={styles.blogList}>
            <article>
              <span>Thought Leadership</span>
              <h3>Belgian consumer trends redefining engagement in 2024</h3>
              <p>Explore six behavioural shifts reshaping storytelling, from circular commerce to micro-communities.</p>
              <Link to="/blog">Read more</Link>
            </article>
            <article>
              <span>Playbook</span>
              <h3>How to run a high-impact agency pitch in four weeks</h3>
              <p>Template your briefing, chemistry sessions, and scoring rubric to minimise decision fatigue.</p>
              <Link to="/blog">Read more</Link>
            </article>
            <article>
              <span>Spotlight</span>
              <h3>Inside Antwerp’s growing experiential scene</h3>
              <p>Meet the creators blending art, technology, and hospitality to build unforgettable branded moments.</p>
              <Link to="/blog">Read more</Link>
            </article>
          </div>
        </div>
        <div className={styles.faq}>
          <p className={styles.eyebrow}>FAQ</p>
          <h2>Your questions, answered.</h2>
          <div className={styles.accordion}>
            {faqItems.map((item) => (
              <details key={item.question}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Ready to commission breakthrough work?</h2>
          <p>
            Compare agencies, access strategic frameworks, and partner with creative teams that share your ambition.
          </p>
          <div className={styles.heroActions}>
            <Link to="/agencies" className={styles.primaryCta}>
              Browse Agencies
            </Link>
            <Link to="/contact" className={styles.secondaryCta}>
              Talk to an Advisor
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;