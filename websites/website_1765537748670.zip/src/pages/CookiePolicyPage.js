import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookie Policy | AdWorld Belgium</title>
      <meta
        name="description"
        content="Learn about the cookies used on AdWorld Belgium, including essential, analytics, and customisation technologies."
      />
    </Helmet>
    <h1>Cookie Policy</h1>
    <p>Last updated: February 2024</p>
    <h2>What are cookies?</h2>
    <p>
      Cookies are small text files stored on your device to help websites remember information about your visit. They
      enable core functionality, analytics, and personalisation features.
    </p>
    <h2>Types of cookies we use</h2>
    <ul>
      <li><strong>Essential cookies:</strong> Required for site navigation and security features.</li>
      <li><strong>Analytics cookies:</strong> Help us understand how visitors interact with the site, enabling continuous improvement.</li>
      <li><strong>Preference cookies:</strong> Remember your settings and choices, such as language or consent preferences.</li>
    </ul>
    <h2>Managing cookies</h2>
    <p>
      You can control cookies through your browser settings and through the cookie banner on our site. Note that disabling
      essential cookies may impact site performance.
    </p>
    <h2>Contact</h2>
    <p>
      For questions about this policy, contact us at info@adworld-belgium.com.
    </p>
  </div>
);

export default CookiePolicyPage;