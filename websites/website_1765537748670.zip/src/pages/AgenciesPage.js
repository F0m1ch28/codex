import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './AgenciesPage.module.css';

const agencies = [
  {
    name: 'Studio Lumen',
    city: 'Ghent',
    specialties: ['Brand Strategy', 'Digital Experience', 'Content Labs'],
    focus: 'Heritage brands, cultural institutions, tourism boards',
    description:
      'Studio Lumen builds emotionally resonant digital experiences that celebrate Belgian heritage. Their integrated teams span narrative design, UX, and spatial storytelling.',
    image: 'https://picsum.photos/800/600?random=51',
  },
  {
    name: 'Orbit Pulse',
    city: 'Brussels',
    specialties: ['Integrated Campaigns', 'Performance Marketing', 'Media Planning'],
    focus: 'Scale-ups, urban lifestyle, sustainable mobility',
    description:
      'Orbit Pulse combines data intelligence with culturally tuned creative. They specialise in cross-channel activations that translate ambitious growth targets into measurable outcomes.',
    image: 'https://picsum.photos/800/600?random=52',
  },
  {
    name: 'Maison Nova',
    city: 'Antwerp',
    specialties: ['Luxury Branding', 'Retail Experiences', 'Influencer Strategy'],
    focus: 'Premium fashion, hospitality, design houses',
    description:
      'Maison Nova elevates premium brands with high-touch creative direction and curated influencer collaborations. Their studio is known for refined cinematography and art direction.',
    image: 'https://picsum.photos/800/600?random=53',
  },
  {
    name: 'Northwave Collective',
    city: 'Leuven',
    specialties: ['B2B Storytelling', 'Thought Leadership', 'ABM Campaigns'],
    focus: 'Tech innovators, universities, industrial leaders',
    description:
      'Northwave Collective translates complex technology narratives into clear and compelling touchpoints, blending strategic positioning with editorial authority.',
    image: 'https://picsum.photos/800/600?random=54',
  },
  {
    name: 'Flux Event Lab',
    city: 'Liège',
    specialties: ['Experiential Marketing', 'Live Production', 'Immersive Technology'],
    focus: 'Automotive, public sector, sport & entertainment',
    description:
      'Flux Event Lab crafts immersive in-person and hybrid experiences. Their modular production teams bring bold ideas to life with precision and audience impact.',
    image: 'https://picsum.photos/800/600?random=55',
  },
];

const AgenciesPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Agencies Directory | AdWorld Belgium</title>
      <meta
        name="description"
        content="Browse the AdWorld Belgium directory of verified advertising agencies excelling in branding, digital, experiential, and performance marketing."
      />
    </Helmet>
    <section className={styles.intro}>
      <h1>Explore Belgium’s leading advertising agencies.</h1>
      <p>
        Each profile is vetted by AdWorld Belgium editors and includes verified capabilities, sector focus, and cultural
        fit indicators. Use these insights to shortlist partners aligned with your objectives.
      </p>
    </section>
    <section className={styles.grid}>
      {agencies.map((agency) => (
        <article key={agency.name}>
          <img src={agency.image} alt={`${agency.name} office space`} loading="lazy" />
          <div className={styles.text}>
            <h2>{agency.name}</h2>
            <p className={styles.meta}>{agency.city} · {agency.specialties.join(', ')}</p>
            <p>{agency.description}</p>
            <ul>
              <li><strong>Specialties:</strong> {agency.specialties.join(', ')}</li>
              <li><strong>Primary focus:</strong> {agency.focus}</li>
            </ul>
          </div>
        </article>
      ))}
    </section>
    <section className={styles.callout}>
      <h2>Need a tailored shortlist?</h2>
      <p>
        Share your campaign details and we will recommend agencies that align with your budget, timeline, and brand
        culture.
      </p>
      <a className={styles.cta} href="/contact">Request bespoke recommendations</a>
    </section>
  </div>
);

export default AgenciesPage;