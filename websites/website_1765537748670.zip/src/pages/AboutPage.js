import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './AboutPage.module.css';

const AboutPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>About AdWorld Belgium</title>
      <meta
        name="description"
        content="Learn about AdWorld Belgium’s mission to champion the country’s advertising talent and help brands navigate agency partnerships."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Curating Belgium’s creative excellence, one partnership at a time.</h1>
      <p>
        AdWorld Belgium was founded to give marketers clarity in an evolving agency landscape. We spotlight the ideas,
        teams, and collaborations defining Belgium’s creative future.
      </p>
    </section>
    <section className={styles.story}>
      <div>
        <h2>Our mission</h2>
        <p>
          We bridge the gap between ambitious brands and forward-thinking agencies. By combining journalistic rigour with
          strategic consultancy, we deliver insights that accelerate collaboration and catalyse breakthrough campaigns.
        </p>
      </div>
      <div>
        <h2>What drives us</h2>
        <ul>
          <li><strong>Transparency:</strong> Honest profiles, open methodologies, and performance data you can trust.</li>
          <li><strong>Diversity:</strong> Highlighting independent studios, specialised boutiques, and global networks.</li>
          <li><strong>Innovation:</strong> Tracking emerging tools, formats, and creative practices across Belgium.</li>
        </ul>
      </div>
    </section>
    <section className={styles.timeline}>
      <h2>Milestones</h2>
      <div className={styles.timelineGrid}>
        <article>
          <span>2019</span>
          <p>AdWorld Belgium launches with 20 founding agency partners and editorial insights.</p>
        </article>
        <article>
          <span>2021</span>
          <p>Introduced the Agency Advisory Desk, offering personalised matchmaking and pitch support.</p>
        </article>
        <article>
          <span>2023</span>
          <p>Expanded coverage to include experiential innovators and data-driven media specialists nationwide.</p>
        </article>
      </div>
    </section>
    <section className={styles.values}>
      <h2>Leadership perspectives</h2>
      <div className={styles.quotes}>
        <figure>
          <img src="https://picsum.photos/400/400?random=91" alt="Portrait of Elise Laurent" />
          <blockquote>
            “Belgium’s creative community is world-class. We exist to surface the nuance, the talent, and the strategic
            thinking that fuels it.”
          </blockquote>
          <figcaption>Elise Laurent · Head of Agency Partnerships</figcaption>
        </figure>
        <figure>
          <img src="https://picsum.photos/400/400?random=92" alt="Portrait of Thomas Verbeeck" />
          <blockquote>
            “Our editorial lens focuses on impact. We look at outcomes, measurable results, and the craft that powers
            them.”
          </blockquote>
          <figcaption>Thomas Verbeeck · Strategy &amp; Insights Lead</figcaption>
        </figure>
      </div>
    </section>
  </div>
);

export default AboutPage;