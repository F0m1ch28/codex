import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './GuidePage.module.css';

const GuidePage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Selection Guide | AdWorld Belgium</title>
      <meta
        name="description"
        content="Follow the AdWorld Belgium guide to define campaign objectives, shortlist agencies, and run an efficient selection process."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>The essential guide to selecting your perfect Belgian agency partner.</h1>
      <p>
        From framing your brief to evaluating chemistry, this guide distils best practices from hundreds of successful
        collaborations. Use it as your blueprint for a confident, transparent selection journey.
      </p>
    </section>
    <section className={styles.steps}>
      <article>
        <h2>1. Clarify ambition and constraints</h2>
        <p>
          Define campaign objectives, KPIs, budget ranges, and decision-makers. Document previous learnings to share with
          prospective partners. Establish your timeline and approval cadence early to avoid bottlenecks.
        </p>
      </article>
      <article>
        <h2>2. Shape an inspiring brief</h2>
        <p>
          Highlight audience insights, brand positioning, and must-have deliverables. Offer context on internal resources
          and collaboration style. A compelling brief yields richer strategic responses and floats the best ideas.
        </p>
      </article>
      <article>
        <h2>3. Build a smart shortlist</h2>
        <p>
          Filter agencies by category expertise, team composition, and cultural alignment. AdWorld Belgium’s profiles
          include verified case studies, capabilities, and leadership interviews to accelerate comparison.
        </p>
      </article>
      <article>
        <h2>4. Design your pitch process</h2>
        <p>
          Limit to three agencies, assign clear roles, and set evaluation criteria. Use chemistry sessions to understand
          day-to-day collaboration. Score responses against the same rubric to keep the process objective.
        </p>
      </article>
      <article>
        <h2>5. Negotiate and onboard</h2>
        <p>
          Align on scope, deliverables, governance, and success metrics. Assign onboarding champions on both sides and
          schedule recurring retrospectives to maintain momentum.
        </p>
      </article>
    </section>
    <section className={styles.resources}>
      <h2>Toolkit resources</h2>
      <ul>
        <li>
          <strong>Brief builder template:</strong> Step-by-step prompts to articulate your brand challenge and desired outcome.
        </li>
        <li>
          <strong>Pitch scoring matrix:</strong> Weighted criteria covering strategy, creativity, execution, and chemistry.
        </li>
        <li>
          <strong>Contracting checklist:</strong> Key clauses addressing IP, data, SLAs, and measurement alignment.
        </li>
        <li>
          <strong>Onboarding agenda:</strong> Kick-off templates, governance model, and retrospectives schedule.
        </li>
      </ul>
    </section>
  </div>
);

export default GuidePage;