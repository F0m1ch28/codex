import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.grid}>
      <div>
        <p className={styles.brand}>AdWorld Belgium</p>
        <p className={styles.text}>
          The definitive resource for discovering Belgium’s most visionary advertising agencies, creative talent,
          and marketing innovations.
        </p>
      </div>
      <div>
        <h4 className={styles.heading}>Explore</h4>
        <ul className={styles.list}>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/guide">Guide</Link></li>
          <li><Link to="/agencies">Agencies</Link></li>
          <li><Link to="/services">Services</Link></li>
          <li><Link to="/blog">Blog</Link></li>
        </ul>
      </div>
      <div>
        <h4 className={styles.heading}>Company</h4>
        <ul className={styles.list}>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/contact">Contact</Link></li>
          <li><Link to="/terms">Terms of Use</Link></li>
          <li><Link to="/privacy">Privacy Policy</Link></li>
          <li><Link to="/cookie-policy">Cookie Policy</Link></li>
        </ul>
      </div>
      <div>
        <h4 className={styles.heading}>Contact</h4>
        <ul className={styles.list}>
          <li><strong>Address:</strong> Belgium</li>
          <li><strong>Phone:</strong> +32 000 00 00 00</li>
          <li><strong>Email:</strong> info@adworld-belgium.com</li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <span>© {new Date().getFullYear()} AdWorld Belgium. Crafted for ambitious marketers.</span>
    </div>
  </footer>
);

export default Footer;