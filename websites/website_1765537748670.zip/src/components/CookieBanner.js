import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const accepted = localStorage.getItem('adworld-cookie-consent');
    if (!accepted) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem('adworld-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div>
        <strong>Cookies Notice</strong>
        <p>
          We use cookies to personalize content, analyze traffic, and deliver a better browsing experience.
          Learn more in our <Link to="/cookie-policy">Cookie Policy</Link>.
        </p>
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;