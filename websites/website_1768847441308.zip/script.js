document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector("nav.primary-nav");
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (window.innerWidth < 1024) {
          nav.classList.remove("open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }
  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const preference = localStorage.getItem("aces-cookie-preference");
    if (!preference) {
      cookieBanner.classList.add("visible");
    }
    const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
    const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
    const closeBanner = (choice) => {
      cookieBanner.classList.remove("visible");
      localStorage.setItem("aces-cookie-preference", choice);
    };
    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => {
        closeBanner("accepted");
      });
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => {
        closeBanner("declined");
      });
    }
  }
});