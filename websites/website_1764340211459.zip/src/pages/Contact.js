```javascript
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '', consent: false, doubleOpt: false });
  const [feedback, setFeedback] = useState('');

  useEffect(() => {
    document.title = 'Contact · Tu Progreso Hoy';
  }, []);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.consent || !formData.doubleOpt) {
      setFeedback('Please confirm both consent checkboxes.');
      return;
    }
    setFeedback('Thank you! Please confirm the email we just sent to complete the double opt-in.');
    setFormData({ name: '', email: '', message: '', consent: false, doubleOpt: false });
  };

  return (
    <div className="page contact-page">
      <motion.section
        className="page-hero"
        initial={{ opacity: 0, y: 22 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <h1>Contact us in Buenos Aires</h1>
        <p>Información confiable que respalda elecciones responsables sobre tu dinero.</p>
      </motion.section>

      <section className="contact-grid">
        <motion.div
          className="contact-card glass-elevated"
          initial={{ opacity: 0, x: -28 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true }}
        >
          <h2>Write to us</h2>
          <form onSubmit={handleSubmit}>
            <label className="floating-label">
              <span>Name</span>
              <input type="text" name="name" required value={formData.name} onChange={handleChange} />
            </label>
            <label className="floating-label">
              <span>Email</span>
              <input type="email" name="email" required value={formData.email} onChange={handleChange} />
            </label>
            <label className="floating-label">
              <span>Message</span>
              <textarea name="message" rows="4" required value={formData.message} onChange={handleChange}></textarea>
            </label>
            <label className="checkbox">
              <input type="checkbox" name="consent" checked={formData.consent} onChange={handleChange} />
              <span>I agree to be contacted and have read the privacy policy.</span>
            </label>
            <label className="checkbox">
              <input type="checkbox" name="doubleOpt" checked={formData.doubleOpt} onChange={handleChange} />
              <span>I will confirm the double opt-in email.</span>
            </label>
            {feedback && <p className="form-feedback">{feedback}</p>}
            <button type="submit" className="btn-primary">
              Send
            </button>
          </form>
        </motion.div>

        <motion.div
          className="contact-info glass-elevated"
          initial={{ opacity: 0, x: 28 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true }}
        >
          <h2>Visit us</h2>
          <p>
            Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
            <br />
            +54 11 5555-1234
            <br />
            hola@tuprogresohoy.com
          </p>
          <iframe
            title="Tu Progreso Hoy Location"
            width="100%"
            height="280"
            style={{ border: 0, borderRadius: '16px' }}
            loading="lazy"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3283.7414842493004!2d-58.38375978476904!3d-34.603738265006704!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccacb4b90bf05%3A0x2a2d3c6248768e7e!2sAv.%209%20de%20Julio%201000%2C%20C1043AAT%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1700000000000"
            allowFullScreen
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
          <p className="contact-note">
            Conocimiento financiero impulsado por tendencias. Visit us for tailored coaching sessions with our education
            team.
          </p>
        </motion.div>
      </section>
    </div>
  );
};

export default Contact;
```

---