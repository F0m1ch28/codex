```javascript
import React, { useEffect } from 'react';

const Terms = () => {
  useEffect(() => {
    document.title = 'Terms of Use · Tu Progreso Hoy';
  }, []);

  return (
    <div className="page legal-page">
      <section className="legal-card glass-elevated">
        <h1>Terms of Use</h1>
        <p>
          Tu Progreso Hoy provides educational content. We do not offer investment, legal, or tax advice. By accessing
          the site you agree to use information responsibly and acknowledge double opt-in requirements for
          communications.
        </p>
        <h2>Permitted use</h2>
        <ul>
          <li>Access content for personal educational purposes.</li>
          <li>Share insights with proper attribution.</li>
          <li>Contact us for workshops with prior agreement.</li>
        </ul>
        <h2>Prohibited actions</h2>
        <ul>
          <li>Redistributing content without consent.</li>
          <li>Using data visualizations for commercial advisory services.</li>
        </ul>
        <h2>Liability</h2>
        <p>
          Content is provided “as-is” for educational purposes. Decisions remain the responsibility of each user. Datos
          verificados para planificar tu presupuesto — interpret responsibly.
        </p>
      </section>
    </div>
  );
};

export default Terms;
```

---