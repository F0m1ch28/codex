```javascript
import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { FaChartBar, FaCompass, FaHandsHelping, FaLeaf, FaRegCalendarCheck, FaUserGraduate } from 'react-icons/fa';

const modules = [
  {
    title: 'Module 1 · Inflation Essentials',
    description:
      'Understand CPI composition, regional divergences, and how Argentine pricing cycles influence everyday expenses.',
    outcomes: ['Identify main inflation drivers', 'Read CPI reports critically', 'Compare provincial price behavior']
  },
  {
    title: 'Module 2 · ARS→USD Dynamics',
    description:
      'Learn FX regime history, parallel markets, and how currency changes impact savings and purchases in Argentina.',
    outcomes: ['Explain FX controls', 'Evaluate currency risk scenarios', 'Build alert systems for FX volatility']
  },
  {
    title: 'Module 3 · Household Budget Lab',
    description:
      'Apply inflation data to real budgets, simulate adjustments, and align expenses with salary updates and goals.',
    outcomes: ['Create adaptive budgets', 'Stress test scenarios', 'Plan buffers for volatility']
  },
  {
    title: 'Module 4 · Trend-driven Decisions',
    description:
      'Conocimiento financiero impulsado por tendencias: integrate macro signals with personal timelines without overreacting.',
    outcomes: ['Translate macro data to action points', 'Prioritize responsible decisions', 'Communicate plans with stakeholders']
  }
];

const Course = () => {
  const navigate = useNavigate();

  useEffect(() => {
    document.title = 'Course Syllabus · Tu Progreso Hoy';
  }, []);

  return (
    <div className="page course-page">
      <motion.section
        className="page-hero"
        initial={{ opacity: 0, y: 25 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <h1>Personal Finance Starter · Argentina</h1>
        <p>
          De la información al aprendizaje: fortalece tu criterio financiero paso a paso. Build literacy through modular
          lessons, data labs, and bilingual guides.
        </p>
        <button className="btn-primary" onClick={() => navigate('/', { state: { scrollTo: 'trialForm' } })}>
          Request trial access
        </button>
      </motion.section>

      <section className="target-section">
        <div className="target-card glass-elevated">
          <FaUserGraduate />
          <h3>Who Should Join?</h3>
          <p>Professionals, freelancers, and families in Argentina seeking reliable data to support financial decisions.</p>
        </div>
        <div className="target-card glass-elevated">
          <FaHandsHelping />
          <h3>Learning approach</h3>
          <p>
            Blend asynchronous lessons, bilingual glossaries, and live clinics. Pasos acertados hoy, mejor futuro mañana.
          </p>
        </div>
        <div className="target-card glass-elevated">
          <FaRegCalendarCheck />
          <h3>Duration &amp; Rhythm</h3>
          <p>Four weeks, flexible schedule, recommended pace of 2-3 sessions per week.</p>
        </div>
      </section>

      <section className="modules-section">
        {modules.map((module) => (
          <motion.article
            key={module.title}
            className="module-card glass-elevated"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h2>{module.title}</h2>
            <p>{module.description}</p>
            <ul>
              {module.outcomes.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </motion.article>
        ))}
      </section>

      <section className="benefits-section">
        <motion.div
          className="benefit-card glass-elevated"
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <FaChartBar />
          <h3>Data Companion</h3>
          <p>
            Each module includes AR inflation dashboards, ARS→USD monitors, and curated datasets to practice insights on
            real numbers.
          </p>
        </motion.div>
        <motion.div
          className="benefit-card glass-elevated"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <FaCompass />
          <h3>Decision Compass</h3>
          <p>Frameworks that keep you grounded: Decisiones responsables, objetivos nítidos.</p>
        </motion.div>
        <motion.div
          className="benefit-card glass-elevated"
          initial={{ opacity: 0, x: 24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <FaLeaf />
          <h3>Responsible Choices</h3>
          <p>Información confiable que respalda elecciones responsables sobre tu dinero, sin promesas irreales.</p>
        </motion.div>
      </section>

      <section className="cta-banner glass-elevated">
        <h2>Ready to experience the course?</h2>
        <p>Submit the free trial form and confirm the double opt-in email to unlock the first module.</p>
        <button className="btn-secondary" onClick={() => navigate('/', { state: { scrollTo: 'trialForm' } })}>
          Go to trial form
        </button>
      </section>
    </div>
  );
};

export default Course;
```

---