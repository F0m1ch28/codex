```javascript
import React, { useEffect } from 'react';

const Privacy = () => {
  useEffect(() => {
    document.title = 'Privacy Policy · Tu Progreso Hoy';
  }, []);

  return (
    <div className="page legal-page">
      <section className="legal-card glass-elevated">
        <h1>Privacy Policy</h1>
        <p>Updated: January 2024</p>
        <p>
          Tu Progreso Hoy operates in Argentina and complies with Ley N° 25.326 on personal data protection. We collect
          essential data (name, email, optional phone) to provide educational content and trial onboarding.
        </p>
        <h2>What we collect</h2>
        <ul>
          <li>Contact information submitted via forms</li>
          <li>Course progress statistics (anonymized)</li>
          <li>Cookie preferences for analytics (only when opted-in)</li>
        </ul>
        <h2>How we use information</h2>
        <ul>
          <li>Deliver emails after double opt-in confirmation</li>
          <li>Schedule educational sessions and provide dashboards</li>
          <li>Improve UX through aggregated analytics (if consented)</li>
        </ul>
        <h2>Data rights</h2>
        <p>
          You may access, update, or delete your data by contacting hola@tuprogresohoy.com. Requests are answered within
          10 business days.
        </p>
        <h2>International transfers</h2>
        <p>
          We store data on secure servers. When transfers occur outside Argentina, we use providers with adequate data
          protection safeguards.
        </p>
        <h2>Retention</h2>
        <p>Data retained until you withdraw consent or 24 months of inactivity, whichever occurs first.</p>
        <h2>Contact</h2>
        <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina · hola@tuprogresohoy.com · +54 11 5555-1234</p>
      </section>
    </div>
  );
};

export default Privacy;
```

---