```javascript
import React, { useEffect } from 'react';

const Cookies = () => {
  useEffect(() => {
    document.title = 'Cookie Policy · Tu Progreso Hoy';
  }, []);

  return (
    <div className="page legal-page">
      <section className="legal-card glass-elevated">
        <h1>Cookie Policy</h1>
        <p>
          Tu Progreso Hoy uses cookies to improve your browsing experience. Necessary cookies ensure security. Optional
          analytics and marketing cookies are only activated when you opt-in via the cookie banner.
        </p>
        <h2>Cookie categories</h2>
        <ul>
          <li>Necessary: session management, language preferences.</li>
          <li>Analytics (opt-in): usage metrics to enhance content.</li>
          <li>Marketing (opt-in): limited to newsletter performance tracking.</li>
        </ul>
        <p>You can change or withdraw consent at any time by clearing browser cookies or contacting us.</p>
      </section>
    </div>
  );
};

export default Cookies;
```

---