```javascript
import React, { useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const ThankYou = () => {
  const location = useLocation();
  const email = location.state?.email;

  useEffect(() => {
    document.title = 'Thank you · Tu Progreso Hoy';
  }, []);

  return (
    <div className="page thankyou-page">
      <motion.section
        className="thankyou-card glass-elevated"
        initial={{ opacity: 0, y: 28 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
      >
        <h1>¡Gracias! / Thank you!</h1>
        <p>
          We sent a confirmation to <strong>{email || 'your email'}</strong>. Please confirm the double opt-in to unlock
          your free trial.
        </p>
        <p>
          Datos verificados para planificar tu presupuesto. Once confirmed, you will receive onboarding steps and
          session invitations.
        </p>
        <Link to="/" className="btn-primary">
          Return to Home
        </Link>
      </motion.section>
    </div>
  );
};

export default ThankYou;
```

---