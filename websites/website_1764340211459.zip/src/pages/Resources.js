```javascript
import React, { useEffect } from 'react';
import { motion } from 'framer-motion';

const resources = [
  {
    title: 'Inflation vocabulary · English & Spanish',
    description: 'Glossary covering CPI nuances, wage agreements, and monetary policy jargon.',
    tags: ['Glossary', 'Bilingual'],
    language: 'EN / ES'
  },
  {
    title: 'Case Study: Argentine household budgeting',
    description: 'Walkthrough with monthly adjustments, subsidy changes, and FX alerts.',
    tags: ['Guide', 'Argentina'],
    language: 'EN'
  },
  {
    title: 'Guía rápida: calcular inflación acumulada',
    description: 'Pasos prácticos para convertir tasas mensuales en acumuladas durante el año.',
    tags: ['Guía', 'Inflación'],
    language: 'ES'
  },
  {
    title: 'FX primer for Argentine freelancers',
    description: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera con ejemplos reales.',
    tags: ['FX', 'Freelancers'],
    language: 'EN / ES'
  }
];

const Resources = () => {
  useEffect(() => {
    document.title = 'Resources · Tu Progreso Hoy';
  }, []);

  return (
    <div className="page resources-page">
      <motion.section
        className="page-hero"
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
      >
        <h1>Resource Library</h1>
        <p>
          Datos verificados para planificar tu presupuesto. Explore bilingual articles, glossaries, and actionable
          guides curated for Argentina.
        </p>
      </motion.section>

      <section className="resource-grid">
        {resources.map((resource, index) => (
          <motion.article
            key={resource.title}
            className="resource-card glass-elevated"
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: index * 0.1 }}
          >
            <div className="resource-header">
              <span className="resource-language">{resource.language}</span>
              <h2>{resource.title}</h2>
            </div>
            <p>{resource.description}</p>
            <div className="resource-tags">
              {resource.tags.map((tag) => (
                <span key={tag}>{tag}</span>
              ))}
            </div>
            <button className="btn-ghost">Coming soon</button>
          </motion.article>
        ))}
      </section>
    </div>
  );
};

export default Resources;
```

---