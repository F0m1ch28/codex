```javascript
import React, { useEffect } from 'react';

const Sitemap = () => {
  useEffect(() => {
    document.title = 'Sitemap · Tu Progreso Hoy';
  }, []);

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://www.tuprogresohoy.com/</loc></url>
  <url><loc>https://www.tuprogresohoy.com/inflation</loc></url>
  <url><loc>https://www.tuprogresohoy.com/course</loc></url>
  <url><loc>https://www.tuprogresohoy.com/resources</loc></url>
  <url><loc>https://www.tuprogresohoy.com/contact</loc></url>
  <url><loc>https://www.tuprogresohoy.com/thank-you</loc></url>
  <url><loc>https://www.tuprogresohoy.com/privacy</loc></url>
  <url><loc>https://www.tuprogresohoy.com/cookies</loc></url>
  <url><loc>https://www.tuprogresohoy.com/terms</loc></url>
</urlset>`;

  return (
    <div className="page legal-page">
      <section className="legal-card glass-elevated">
        <h1>Sitemap</h1>
        <p>XML Preview:</p>
        <pre className="sitemap-pre">{xml}</pre>
      </section>
    </div>
  );
};

export default Sitemap;
```

---