```javascript
import React, { useEffect } from 'react';

const Robots = () => {
  useEffect(() => {
    document.title = 'Robots · Tu Progreso Hoy';
  }, []);

  return (
    <div className="page legal-page">
      <section className="legal-card glass-elevated">
        <h1>Robots.txt Preview</h1>
        <pre>
User-agent: *
Allow: /
Sitemap: https://www.tuprogresohoy.com/sitemap.xml
        </pre>
      </section>
    </div>
  );
};

export default Robots;
```

---