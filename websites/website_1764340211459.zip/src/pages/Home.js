```javascript
import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import {
  FaArrowDown,
  FaBalanceScale,
  FaChartLine,
  FaGlobeAmericas,
  FaLightbulb,
  FaPlayCircle,
  FaShieldAlt,
  FaTasks
} from 'react-icons/fa';
import AnimatedCounter from '../components/AnimatedCounter';

const Typewriter = ({ phrases, speed = 65, pause = 1800 }) => {
  const [display, setDisplay] = useState('');
  const [index, setIndex] = useState(0);
  const [direction, setDirection] = useState('forward');

  useEffect(() => {
    let timeout;

    if (direction === 'forward') {
      if (display.length < phrases[index].length) {
        timeout = setTimeout(() => {
          setDisplay(phrases[index].slice(0, display.length + 1));
        }, speed);
      } else {
        timeout = setTimeout(() => setDirection('backward'), pause);
      }
    } else {
      if (display.length > 0) {
        timeout = setTimeout(() => {
          setDisplay(display.slice(0, -1));
        }, speed / 1.5);
      } else {
        timeout = setTimeout(() => {
          setDirection('forward');
          setIndex((prev) => (prev + 1) % phrases.length);
        }, speed);
      }
    }

    return () => clearTimeout(timeout);
  }, [display, direction, index, phrases, speed, pause]);

  return <span className="typewriter-text">{display}</span>;
};

const Home = () => {
  const [rateData, setRateData] = useState({ rate: null, change: null, date: null, loading: true });
  const [rateError, setRateError] = useState('');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    goal: '',
    consent: false,
    doubleOpt: false
  });
  const [formError, setFormError] = useState('');
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    document.title = 'Tu Progreso Hoy | Financial Intelligence for Argentina';
  }, []);

  useEffect(() => {
    if (location.state?.scrollTo) {
      const targetId = location.state.scrollTo;
      const element = document.getElementById(targetId);
      if (element) {
        setTimeout(() => {
          element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 300);
      }
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location, navigate]);

  useEffect(() => {
    const fetchRates = async () => {
      try {
        const today = new Date();
        const endDate = today.toISOString().split('T')[0];
        const prevDate = new Date(today);
        prevDate.setDate(prevDate.getDate() - 1);
        const startDate = prevDate.toISOString().split('T')[0];
        const url = `https://api.exchangerate.host/timeseries?start_date=${startDate}&end_date=${endDate}&base=ARS&symbols=USD`;

        const response = await fetch(url);
        if (!response.ok) throw new Error('Network error');
        const data = await response.json();

        const todayRate = data?.rates?.[endDate]?.USD;
        const previousRate = data?.rates?.[startDate]?.USD;

        if (todayRate) {
          const change = previousRate ? todayRate - previousRate : null;
          setRateData({
            rate: todayRate,
            change,
            date: endDate,
            loading: false
          });
        } else {
          throw new Error('No rate data');
        }
      } catch (error) {
        setRateError('Live exchange data temporarily unavailable. Showing reference rate.');
        setRateData({
          rate: 0.0031,
          change: null,
          date: 'Reference',
          loading: false
        });
      }
    };

    fetchRates();
  }, []);

  const features = useMemo(
    () => [
      {
        icon: <FaGlobeAmericas />,
        title: 'Context for Argentina',
        description:
          'Decisiones responsables, objetivos nítidos. Combine macro data with your personal objectives in a calm, structured environment.'
      },
      {
        icon: <FaShieldAlt />,
        title: 'Transparent Analytics',
        description:
          'Análisis transparentes y datos de mercado para decidir con seguridad. Every chart includes methodology, sources, and caveats.'
      },
      {
        icon: <FaLightbulb />,
        title: 'Learning Journey',
        description:
          'De la información al aprendizaje: fortalece tu criterio financiero paso a paso. Navigate from fundamentals to trend interpretation.'
      }
    ],
    []
  );

  const courseHighlights = [
    {
      icon: <FaTasks />,
      title: 'Module-based clarity',
      copy: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera con structured blueprints.'
    },
    {
      icon: <FaBalanceScale />,
      title: 'Responsible decisions',
      copy: 'Información confiable que respalda elecciones responsables sobre tu dinero con contextual benchmarks.'
    },
    {
      icon: <FaPlayCircle />,
      title: 'Interactive labs',
      copy: 'Conocimiento financiero impulsado por tendencias through guided simulations and data labs.'
    }
  ];

  const testimonials = [
    {
      quote:
        'Las visualizaciones son claras y conectadas con la realidad argentina. Pasos acertados hoy, mejor futuro mañana.',
      name: 'Carolina M.',
      role: 'Product Manager · Córdoba'
    },
    {
      quote:
        'Datos verificados para planificar tu presupuesto y herramientas para entender la inflación sin ruido.',
      name: 'Matías R.',
      role: 'Ingeniero · Mendoza'
    },
    {
      quote:
        'El enfoque bilingüe es perfecto para mi equipo. Análisis transparentes y datos de mercado para decidir con seguridad.',
      name: 'Lucía P.',
      role: 'Consultora · Buenos Aires'
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const handleFormChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    if (!formData.consent || !formData.doubleOpt) {
      setFormError('Please confirm both consent checkboxes to continue.');
      return;
    }
    navigate('/thank-you', { state: { email: formData.email } });
  };

  const rateChangeLabel =
    typeof rateData.change === 'number'
      ? `${rateData.change > 0 ? '+' : ''}${rateData.change.toFixed(6)}`
      : '—';

  return (
    <div className="home-page">
      <section className="hero-section">
        <div className="hero-background" aria-hidden="true"></div>
        <div className="hero-overlay"></div>
        <motion.div
          className="hero-content"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: 'easeOut' }}
        >
          <div className="hero-badge">Argentina · Education &amp; Data</div>
          <h1>
            Empowering Argentine financial literacy with{' '}
            <Typewriter
              phrases={[
                'Datos verificados para planificar tu presupuesto.',
                'Decisiones responsables, objetivos nítidos.',
                'Conocimiento financiero impulsado por tendencias.',
                'Pasos acertados hoy, mejor futuro mañana.'
              ]}
            />
          </h1>
          <p>
            Tu Progreso Hoy blends actionable inflation intelligence, ARS→USD monitoring, and a progressive learning
            path. Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
          <div className="hero-actions">
            <button className="btn-primary" onClick={() => navigate('/course')}>
              Explore Course
            </button>
            <button className="btn-ghost" onClick={() => navigate('/inflation')}>
              View Inflation Monitor
            </button>
          </div>
        </motion.div>

        <div className="scroll-indicator" aria-hidden="true">
          <span>Scroll for insights</span>
          <FaArrowDown />
        </div>
      </section>

      <section className="exchange-section">
        <motion.div
          className="exchange-card glass-elevated"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="exchange-header">
            <h2>ARS → USD Tracker</h2>
            <span className="badge">Live · Buenos Aires</span>
          </div>
          <div className="exchange-body">
            {rateData.loading ? (
              <div className="skeleton-row">
                <div className="skeleton skeleton-title"></div>
                <div className="skeleton skeleton-subtitle"></div>
              </div>
            ) : (
              <>
                <div className="exchange-rate">
                  <span className="label">1 ARS</span>
                  <span className="value">
                    {rateData.rate
                      ? rateData.rate.toLocaleString('en-US', {
                          minimumFractionDigits: 6,
                          maximumFractionDigits: 6
                        })
                      : '—'}{' '}
                    USD
                  </span>
                </div>
                <div className={`exchange-change ${rateData.change > 0 ? 'up' : rateData.change < 0 ? 'down' : ''}`}>
                  24h: {rateChangeLabel}
                </div>
                <div className="exchange-footnote">
                  Data source: exchangerate.host · {rateData.date}
                  {rateError && <span className="exchange-error">{rateError}</span>}
                </div>
              </>
            )}
          </div>
          <div className="exchange-note">
            <strong>Note:</strong> Análisis transparentes y datos de mercado para decidir con seguridad.
          </div>
        </motion.div>
        <motion.div
          className="exchange-side"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.15 }}
          viewport={{ once: true }}
        >
          <h3>Macroeconomic insights</h3>
          <p>
            Stay alert to policy shifts and external shocks. Información confiable que respalda elecciones responsables
            sobre tu dinero.
          </p>
          <div className="exchange-tags">
            <span>#inflation</span>
            <span>#fx</span>
            <span>#mercosur</span>
            <span>#energy</span>
          </div>
        </motion.div>
      </section>

      <section className="feature-section">
        {features.map((feature, index) => (
          <motion.article
            key={feature.title}
            className="feature-card glass-elevated"
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: index * 0.15 }}
            viewport={{ once: true }}
          >
            <div className="feature-icon">{feature.icon}</div>
            <h3>{feature.title}</h3>
            <p>{feature.description}</p>
          </motion.article>
        ))}
      </section>

      <section className="stats-section">
        <motion.div
          className="stats-intro"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true }}
        >
          <h2>Learning with data-driven accountability</h2>
          <p>
            Track your progress and AR indicators simultaneously. Sigue las tendencias, identifica oportunidades y
            diseña tu ruta financiera.
          </p>
        </motion.div>
        <div className="stats-grid">
          <div className="stat-card glass-elevated">
            <span className="stat-label">Learners in Argentina</span>
            <AnimatedCounter target={2150} suffix="+" />
          </div>
          <div className="stat-card glass-elevated">
            <span className="stat-label">Curated data series</span>
            <AnimatedCounter target={38} />
          </div>
          <div className="stat-card glass-elevated">
            <span className="stat-label">Weekly inflation alerts</span>
            <AnimatedCounter target={14} />
          </div>
          <div className="stat-card glass-elevated">
            <span className="stat-label">Guided simulations</span>
            <AnimatedCounter target={12} />
          </div>
        </div>
      </section>

      <section className="course-highlight">
        <motion.div
          className="course-copy"
          initial={{ opacity: 0, x: -32 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2>Course overview · AR Personal Finance Starter</h2>
          <p>
            Conocimiento financiero impulsado por tendencias con prácticas en escenarios reales. Blend fundamentals,
            inflation literacy, FX decision frameworks and goal-setting for Argentine households.
          </p>
          <Link to="/course" className="btn-primary">
            View syllabus
          </Link>
        </motion.div>
        <div className="course-grid">
          {courseHighlights.map((item, index) => (
            <motion.div
              key={item.title}
              className="course-card glass-elevated"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: index * 0.12 }}
              viewport={{ once: true }}
            >
              <div className="course-icon">{item.icon}</div>
              <h4>{item.title}</h4>
              <p>{item.copy}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="testimonials-section">
        <motion.div
          className="testimonial-card glass-elevated"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <blockquote>
            “{testimonials[currentTestimonial].quote}”
            <span className="testimonial-name">{testimonials[currentTestimonial].name}</span>
            <span className="testimonial-role">{testimonials[currentTestimonial].role}</span>
          </blockquote>
          <div className="testimonial-controls" role="group" aria-label="Testimonials navigation">
            {testimonials.map((_, idx) => (
              <button
                key={`testimonial-${idx}`}
                onClick={() => setCurrentTestimonial(idx)}
                className={`dot ${idx === currentTestimonial ? 'active' : ''}`}
                aria-label={`Show testimonial ${idx + 1}`}
              ></button>
            ))}
          </div>
        </motion.div>
      </section>

      <section className="insight-section">
        <motion.div
          className="insight-copy"
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true }}
        >
          <h2>Insight Streams</h2>
          <p>
            Decisiones responsables, objetivos nítidos. Combine CPI outlooks, FX corridors, and commodity alerts with
            your learning schedule.
          </p>
        </motion.div>
        <div className="insight-grid">
          <motion.article
            className="insight-card glass-elevated"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h3>Weekly Inflation Capsule</h3>
            <p>Micro-data from Buenos Aires, Córdoba, and Mendoza with comparative visualizations and risk briefs.</p>
          </motion.article>
          <motion.article
            className="insight-card glass-elevated"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h3>FX &amp; Commodities Radar</h3>
            <p>Monitor ARS cross-rates plus soy, corn, and energy inputs that influence domestic costs.</p>
          </motion.article>
          <motion.article
            className="insight-card glass-elevated"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h3>Scenario Workshops</h3>
            <p>Guided labs bridging inflation data to household planning — De la información al aprendizaje: fortalece tu criterio financiero paso a paso.</p>
          </motion.article>
        </div>
      </section>

      <section className="cta-form-section" id="trialForm">
        <motion.div
          className="cta-copy"
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2>Start with a guided experience</h2>
          <p>
            Pasos acertados hoy, mejor futuro mañana. Request your complimentary session and confirm your email (double
            opt-in) to unlock the platform.
          </p>
          <ul className="cta-benefits">
            <li>• Tailored onboarding for Argentine realities</li>
            <li>• Access to inflation dashboards for 7 days</li>
            <li>• Live Q&amp;A with our learning advisors</li>
          </ul>
        </motion.div>
        <motion.form
          className="cta-form glass-elevated"
          onSubmit={handleFormSubmit}
          initial={{ opacity: 0, x: 24 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3>Получить бесплатный пробный урок</h3>
          <p className="form-note">Double opt-in: check your inbox to confirm subscription after submitting.</p>

          <label className="floating-label">
            <span>Name / Nombre</span>
            <input
              type="text"
              name="name"
              required
              autoComplete="name"
              value={formData.name}
              onChange={handleFormChange}
            />
          </label>

          <label className="floating-label">
            <span>Email</span>
            <input
              type="email"
              name="email"
              required
              autoComplete="email"
              value={formData.email}
              onChange={handleFormChange}
            />
          </label>

          <label className="floating-label">
            <span>Phone (WhatsApp optional)</span>
            <input
              type="tel"
              name="phone"
              autoComplete="tel"
              value={formData.phone}
              onChange={handleFormChange}
              aria-describedby="phoneHelp"
            />
          </label>
          <small id="phoneHelp">We may use WhatsApp for scheduling confirmations.</small>

          <label className="floating-label">
            <span>What is your main goal? / Objetivo principal</span>
            <textarea name="goal" rows="3" required value={formData.goal} onChange={handleFormChange}></textarea>
          </label>

          <div className="consent-group">
            <label>
              <input type="checkbox" name="consent" checked={formData.consent} onChange={handleFormChange} />
              <span>I agree to receive educational emails and understand the privacy policy.</span>
            </label>
            <label>
              <input type="checkbox" name="doubleOpt" checked={formData.doubleOpt} onChange={handleFormChange} />
              <span>I will confirm the double opt-in email to activate access.</span>
            </label>
          </div>

          {formError && <p className="form-error" role="alert">{formError}</p>}

          <button type="submit" className="btn-primary">
            Submit &amp; Confirm
          </button>
        </motion.form>
      </section>
    </div>
  );
};

export default Home;
```

---