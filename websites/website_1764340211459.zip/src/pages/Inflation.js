```javascript
import React, { useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend } from 'chart.js';
import { motion } from 'framer-motion';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend);

const Inflation = () => {
  useEffect(() => {
    document.title = 'Inflation Methodology · Tu Progreso Hoy';
  }, []);

  const cpiData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Monthly CPI % (YoY)',
        data: [211, 214, 216, 219, 223, 226, 229, 232, 235, 238, 240, 243],
        borderColor: '#2563EB',
        backgroundColor: 'rgba(37, 99, 235, 0.3)',
        tension: 0.35,
        fill: true,
        pointRadius: 4
      },
      {
        label: 'Core CPI % (YoY)',
        data: [198, 200, 202, 206, 210, 212, 215, 219, 222, 225, 228, 230],
        borderColor: '#1F3A6F',
        backgroundColor: 'rgba(31, 58, 111, 0.2)',
        tension: 0.35,
        fill: false,
        borderDash: [6, 4],
        pointRadius: 4
      }
    ]
  };

  const fxData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'ARS Official → USD',
        data: [0.0058, 0.0056, 0.0053, 0.0049, 0.0046, 0.0042, 0.0039, 0.0036, 0.0033, 0.0030, 0.0028, 0.0026],
        borderColor: '#22d3ee',
        backgroundColor: 'rgba(34, 211, 238, 0.2)',
        tension: 0.4,
        fill: true
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom'
      },
      tooltip: {
        mode: 'index',
        intersect: false
      }
    },
    scales: {
      y: {
        ticks: {
          color: '#0F172A'
        },
        grid: {
          color: 'rgba(15, 23, 42, 0.08)'
        }
      },
      x: {
        ticks: {
          color: '#0F172A'
        },
        grid: {
          display: false
        }
      }
    }
  };

  return (
    <div className="page inflation-page">
      <motion.section
        className="page-hero"
        initial={{ opacity: 0, y: 22 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <h1>Inflation Monitor · Methodology</h1>
        <p>
          Análisis transparentes y datos de mercado para decidir con seguridad. Our inflation dashboards align with INDEC
          sources and independent panels to reflect Argentine price dynamics.
        </p>
      </motion.section>

      <section className="methodology-section">
        <motion.article
          className="method-card glass-elevated"
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2>Methodology</h2>
          <ul>
            <li>Blend of official INDEC CPI, provincial releases, and high-frequency supermarket trackers.</li>
            <li>Seasonality adjustment applied with ARIMA models to highlight trend and core inflation.</li>
            <li>FX pass-through measured using lagged USD/ARS corridors and import-sensitive baskets.</li>
            <li>Monthly commentary includes energy, logistics, and wage negotiations context for Argentina.</li>
          </ul>
        </motion.article>

        <motion.article
          className="method-card glass-elevated"
          initial={{ opacity: 0, x: 24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2>Quality Controls</h2>
          <ul>
            <li>Data cross-verified with academic economists and consumer associations.</li>
            <li>Outliers flagged with interquartile range rules, reviewed manually before publishing.</li>
            <li>Time-series automatically benchmarked to identify structural breaks from policy shifts.</li>
            <li>Datasets updated daily to capture rapid Argentine price re-calibrations.</li>
          </ul>
        </motion.article>
      </section>

      <section className="chart-section">
        <div className="chart-card glass-elevated">
          <h3>CPI trend comparison</h3>
          <div className="chart-wrapper">
            <Line data={cpiData} options={chartOptions} aria-label="CPI chart" />
          </div>
        </div>
        <div className="chart-card glass-elevated">
          <h3>ARS → USD official corridor</h3>
          <div className="chart-wrapper">
            <Line data={fxData} options={chartOptions} aria-label="FX chart" />
          </div>
        </div>
      </section>

      <section className="context-section">
        <motion.div
          className="context-card glass-elevated"
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2>CPI &amp; FX Context</h2>
          <p>
            Datos verificados para planificar tu presupuesto. We monitor wage negotiations, subsidies, and import rules
            to anticipate CPI inflections. Decisiones responsables, objetivos nítidos cuando se combinan datos con
            educación financiera.
          </p>
          <p>
            Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera con workshops that connect macro
            movements to everyday budgeting.
          </p>
        </motion.div>
      </section>

      <section className="faq-section">
        <h2>FAQ</h2>
        <div className="faq-grid">
          <details>
            <summary>How often is the inflation dashboard updated?</summary>
            <p>Daily for high-frequency indicators; full CPI releases follow INDEC schedules.</p>
          </details>
          <details>
            <summary>Do you offer investment recommendations?</summary>
            <p>No. Plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
          </details>
          <details>
            <summary>What makes your CPI data transparent?</summary>
            <p>Each chart includes sources, methodology notes, and highlights uncertainties so you can interpret responsibly.</p>
          </details>
          <details>
            <summary>Can I export data?</summary>
            <p>Yes, subscribers can export CSV snapshots to compare historical Argentine price levels.</p>
          </details>
        </div>
      </section>
    </div>
  );
};

export default Inflation;
```

---