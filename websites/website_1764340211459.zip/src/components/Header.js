```javascript
import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FaBars, FaTimes } from 'react-icons/fa';

const navItems = [
  { path: '/', label: 'Insights' },
  { path: '/inflation', label: 'Inflation Monitor' },
  { path: '/course', label: 'Course' },
  { path: '/resources', label: 'Resources' },
  { path: '/contact', label: 'Contact' }
];

const Header = () => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const handleNavigateCTA = () => {
    navigate('/', { state: { scrollTo: 'trialForm' } });
    setOpen(false);
  };

  return (
    <header className={`site-header ${open ? 'header-open' : ''}`}>
      <div className="header-content">
        <motion.div
          className="logo-wrap"
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
        >
          <button
            className="logo-btn"
            onClick={() => navigate('/')}
            aria-label="Go to Tu Progreso Hoy home"
          >
            <span className="logo-icon">TPH</span>
            <div className="logo-text">
              <span className="logo-title">Tu Progreso Hoy</span>
              <span className="logo-subtitle">Buenos Aires · EN/ES</span>
            </div>
          </button>
        </motion.div>

        <nav className={`nav-links ${open ? 'nav-open' : ''}`} aria-label="Primary">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
              onClick={() => setOpen(false)}
            >
              <span>{item.label}</span>
            </NavLink>
          ))}
          <button className="nav-cta" onClick={handleNavigateCTA}>
            Free Trial · ES
          </button>
        </nav>

        <button
          className="menu-toggle"
          aria-label="Toggle navigation menu"
          onClick={() => setOpen((prev) => !prev)}
        >
          {open ? <FaTimes /> : <FaBars />}
        </button>
      </div>
    </header>
  );
};

export default Header;
```

---