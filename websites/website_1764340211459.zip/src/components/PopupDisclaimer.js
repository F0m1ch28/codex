```javascript
import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const PopupDisclaimer = () => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setOpen(true), 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="popup-disclaimer"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          role="alertdialog"
          aria-modal="true"
          aria-label="Financial disclaimer"
        >
          <motion.div
            className="popup-inner glass-elevated"
            initial={{ scale: 0.9, y: 10 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.85, opacity: 0 }}
          >
            <h4>Disclaimer</h4>
            <p>Мы не предоставляем финансовые услуги.</p>
            <p>We do not provide financial services. Plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
            <button onClick={() => setOpen(false)} className="btn-primary">
              Understood
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default PopupDisclaimer;
```

---