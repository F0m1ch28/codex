```javascript
import React, { useState, useEffect } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const [prefs, setPrefs] = useState({ analytics: false, marketing: false });

  useEffect(() => {
    const stored = localStorage.getItem('tph-cookie-consent');
    if (!stored) {
      const timeout = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timeout);
    }
  }, []);

  const persist = (settings) => {
    localStorage.setItem('tph-cookie-consent', JSON.stringify(settings));
  };

  const handleAcceptAll = () => {
    const settings = { necessary: true, analytics: true, marketing: true, timestamp: new Date().toISOString() };
    persist(settings);
    setVisible(false);
  };

  const handleSave = () => {
    const settings = { necessary: true, analytics: prefs.analytics, marketing: prefs.marketing, timestamp: new Date().toISOString() };
    persist(settings);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-modal="true" aria-label="Cookie preferences">
      <div className="cookie-content glass-elevated">
        <h3>Cookie Preferences</h3>
        <p>
          We use cookies to enhance UX. Necessary cookies keep the platform secure. You can opt-in for analytics or
          marketing insights.
        </p>
        <div className="cookie-options">
          <label className="cookie-toggle">
            <input type="checkbox" checked disabled />
            <span>Necessary cookies (always on)</span>
          </label>
          <label className="cookie-toggle">
            <input
              type="checkbox"
              checked={prefs.analytics}
              onChange={(e) => setPrefs((prev) => ({ ...prev, analytics: e.target.checked }))}
            />
            <span>Analytics (help us improve)</span>
          </label>
          <label className="cookie-toggle">
            <input
              type="checkbox"
              checked={prefs.marketing}
              onChange={(e) => setPrefs((prev) => ({ ...prev, marketing: e.target.checked }))}
            />
            <span>Marketing updates</span>
          </label>
        </div>
        <div className="cookie-actions">
          <button onClick={handleSave} className="btn-secondary">
            Save choices
          </button>
          <button onClick={handleAcceptAll} className="btn-primary">
            Accept all
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;
```

---