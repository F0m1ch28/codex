```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import { FaEnvelope, FaPhoneAlt, FaMapMarkerAlt, FaLinkedinIn, FaTwitter, FaYoutube } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer className="site-footer" aria-label="Footer">
      <div className="footer-bg-gradient" aria-hidden="true"></div>
      <div className="footer-grid">
        <div className="footer-col">
          <h3>Tu Progreso Hoy</h3>
          <p>
            Datos verificados para planificar tu presupuesto. Información confiable que respalda elecciones responsables
            sobre tu dinero.
          </p>
          <p className="footer-desc">
            Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
        </div>
        <div className="footer-col">
          <h4>Visit &amp; Call</h4>
          <ul className="footer-links">
            <li>
              <FaMapMarkerAlt /> Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
            </li>
            <li>
              <FaPhoneAlt /> +54 11 5555-1234
            </li>
            <li>
              <FaEnvelope /> hola@tuprogresohoy.com
            </li>
          </ul>
        </div>
        <div className="footer-col">
          <h4>Navigate</h4>
          <div className="footer-nav-links">
            <Link to="/">Home</Link>
            <Link to="/inflation">Inflation Monitor</Link>
            <Link to="/course">Course</Link>
            <Link to="/resources">Resources</Link>
            <Link to="/contact">Contact</Link>
          </div>
        </div>
        <div className="footer-col">
          <h4>Legal</h4>
          <div className="footer-nav-links">
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/cookies">Cookie Policy</Link>
            <Link to="/terms">Terms of Use</Link>
            <Link to="/sitemap.xml">Sitemap</Link>
            <Link to="/robots.txt">Robots.txt</Link>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} Tu Progreso Hoy · Buenos Aires</span>
        <div className="footer-social">
          <a href="https://www.linkedin.com" aria-label="LinkedIn">
            <FaLinkedinIn />
          </a>
          <a href="https://twitter.com" aria-label="Twitter">
            <FaTwitter />
          </a>
          <a href="https://youtube.com" aria-label="YouTube">
            <FaYoutube />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
```

---