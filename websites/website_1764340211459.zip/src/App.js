```javascript
import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import PopupDisclaimer from './components/PopupDisclaimer';
import ScrollToTopButton from './components/ScrollToTop';

import Home from './pages/Home';
import Inflation from './pages/Inflation';
import Course from './pages/Course';
import Resources from './pages/Resources';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import Privacy from './pages/Privacy';
import Cookies from './pages/Cookies';
import Terms from './pages/Terms';
import Sitemap from './pages/Sitemap';
import Robots from './pages/Robots';

const PageWrapper = ({ children }) => (
  <motion.main
    role="main"
    initial={{ opacity: 0, y: 18 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -18 }}
    transition={{ duration: 0.6, ease: 'easeInOut' }}
    className="page-wrapper"
  >
    {children}
  </motion.main>
);

const AnimatedRoutes = () => {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route
          path="/"
          element={
            <PageWrapper>
              <Home />
            </PageWrapper>
          }
        />
        <Route
          path="/inflation"
          element={
            <PageWrapper>
              <Inflation />
            </PageWrapper>
          }
        />
        <Route
          path="/course"
          element={
            <PageWrapper>
              <Course />
            </PageWrapper>
          }
        />
        <Route
          path="/resources"
          element={
            <PageWrapper>
              <Resources />
            </PageWrapper>
          }
        />
        <Route
          path="/contact"
          element={
            <PageWrapper>
              <Contact />
            </PageWrapper>
          }
        />
        <Route
          path="/thank-you"
          element={
            <PageWrapper>
              <ThankYou />
            </PageWrapper>
          }
        />
        <Route
          path="/privacy"
          element={
            <PageWrapper>
              <Privacy />
            </PageWrapper>
          }
        />
        <Route
          path="/cookies"
          element={
            <PageWrapper>
              <Cookies />
            </PageWrapper>
          }
        />
        <Route
          path="/terms"
          element={
            <PageWrapper>
              <Terms />
            </PageWrapper>
          }
        />
        <Route
          path="/sitemap.xml"
          element={
            <PageWrapper>
              <Sitemap />
            </PageWrapper>
          }
        />
        <Route
          path="/robots.txt"
          element={
            <PageWrapper>
              <Robots />
            </PageWrapper>
          }
        />
      </Routes>
    </AnimatePresence>
  );
};

const App = () => {
  return (
    <div className="app-shell">
      <Header />
      <AnimatedRoutes />
      <Footer />
      <CookieBanner />
      <PopupDisclaimer />
      <ScrollToTopButton />
    </div>
  );
};

export default App;
```

---