import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      const consent = localStorage.getItem("apexvision-cookie-consent");
      if (!consent) {
        const timer = setTimeout(() => setVisible(true), 1200);
        return () => clearTimeout(timer);
      }
    } catch (error) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    try {
      localStorage.setItem("apexvision-cookie-consent", "accepted");
    } catch (error) {
      // noop
    }
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div>
        <h4>We Value Your Privacy</h4>
        <p>
          We use cookies to personalize content, analyze traffic, and improve
          your experience. By continuing, you agree to our{" "}
          <a href="/privacy">privacy policy</a>.
        </p>
      </div>
      <div className="cookie-actions">
        <button className="btn btn-sm" onClick={acceptCookies}>
          Accept &amp; Continue
        </button>
        <a className="btn-link" href="/privacy">
          Learn more
        </a>
      </div>
    </div>
  );
};

export default CookieBanner;