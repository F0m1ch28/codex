import React from "react";
import { NavLink } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div>
          <div className="logo footer-logo">
            <span className="logo-mark">AV</span>
            <span className="logo-type">
              Apex<span>Vision</span>
            </span>
          </div>
          <p className="footer-desc">
            ApexVision Consulting partners with ambitious leaders to ignite
            sustainable growth, build resilient cultures, and embrace
            innovation with confidence.
          </p>
          <div className="footer-contact">
            <a href="mailto:hello@apexvision.co">hello@apexvision.co</a>
            <a href="tel:+12125550123">+1 (212) 555-0123</a>
          </div>
        </div>
        <div>
          <h4>Company</h4>
          <ul className="footer-links">
            <li>
              <NavLink to="/about">About</NavLink>
            </li>
            <li>
              <NavLink to="/services">Services</NavLink>
            </li>
            <li>
              <NavLink to="/terms">Terms of Service</NavLink>
            </li>
            <li>
              <NavLink to="/privacy">Privacy Policy</NavLink>
            </li>
          </ul>
        </div>
        <div>
          <h4>Stay Connected</h4>
          <p>
            Join our insights list for leadership strategies, innovation tips,
            and industry intelligence.
          </p>
          <form
            className="footer-form"
            onSubmit={(e) => e.preventDefault()}
            aria-label="Newsletter signup"
          >
            <label htmlFor="newsletter-email" className="sr-only">
              Email address
            </label>
            <input
              id="newsletter-email"
              type="email"
              placeholder="Email address"
              required
            />
            <button type="submit" className="btn btn-sm">
              Subscribe
            </button>
          </form>
          <div className="footer-social">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
            <a href="https://www.twitter.com" target="_blank" rel="noreferrer">
              Twitter
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer">
              YouTube
            </a>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        © {new Date().getFullYear()} ApexVision Consulting. All rights
        reserved.
      </div>
    </footer>
  );
};

export default Footer;