import React from "react";

const About = () => {
  const leadership = [
    {
      name: "Elena Ford",
      role: "Founder & Chief Strategist",
      bio: "Elena blends 18 years of corporate strategy experience with a passion for human-centered transformation. She advises Fortune 500 boards on growth, innovation, and operating model reinvention.",
      image: "https://picsum.photos/400/400?random=3",
    },
    {
      name: "Gabriel Chen",
      role: "Partner, Innovation & Ventures",
      bio: "Gabriel has launched 45+ digital ventures across fintech, energy, and mobility. He leads ApexVision’s innovation studio, infusing experimentation and venture design into every engagement.",
      image: "https://picsum.photos/400/400?random=8",
    },
    {
      name: "Sophia Martinez",
      role: "Practice Lead, Culture & Change",
      bio: "Sophia is a certified leadership coach and organizational psychologist. She orchestrates change programs that build inclusive cultures and elevate leadership performance.",
      image: "https://picsum.photos/400/400?random=9",
    },
    {
      name: "Noah Patel",
      role: "Director, Data & Intelligence",
      bio: "Noah architected data platforms for global enterprises. He ensures every ApexVision strategy is grounded in actionable insights, predictive analytics, and measurable outcomes.",
      image: "https://picsum.photos/400/400?random=10",
    },
  ];

  return (
    <div className="page about-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">About ApexVision</span>
          <h1>We transform vision into velocity—for people, planet, and profit.</h1>
          <p>
            ApexVision Consulting was founded to help ambitious leaders navigate
            accelerated change with confidence. Our multidisciplinary team
            fuses strategic foresight, design thinking, and operational
            excellence to co-create transformation that lasts.
          </p>
        </div>
      </section>

      <section className="values">
        <div className="container values-grid">
          <article>
            <h3>Purpose-Led Strategy</h3>
            <p>
              We anchor every engagement in purpose, ensuring strategies align
              with stakeholder needs and long-term value creation.
            </p>
          </article>
          <article>
            <h3>Evidence-Based Insight</h3>
            <p>
              Our recommendations are grounded in rigorous analytics, market
              intelligence, and an obsession with measurable impact.
            </p>
          </article>
          <article>
            <h3>Human-Centered Change</h3>
            <p>
              We design experiences and operating models that elevate people,
              empowering them to lead, adapt, and thrive.
            </p>
          </article>
        </div>
      </section>

      <section className="team">
        <div className="container section-header">
          <span className="eyebrow">Leadership Team</span>
          <h2>Guiding your transformation with experienced partners.</h2>
          <p>
            Our leaders bring cross-industry expertise, entrepreneurial energy,
            and a shared commitment to creating meaningful change.
          </p>
        </div>
        <div className="container team-grid">
          {leadership.map((member) => (
            <article key={member.name} className="team-card">
              <div className="team-avatar">
                <img
                  src={`${member.image}&sig=${encodeURIComponent(member.name)}`}
                  alt={`${member.name}, ${member.role}`}
                  loading="lazy"
                />
              </div>
              <div className="team-info">
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="impact">
        <div className="container impact-grid">
          <div>
            <span className="eyebrow">Our Impact</span>
            <h2>Partnering with over 70 organizations across 12 countries.</h2>
            <p>
              From multinational enterprises to mission-driven startups, we’ve
              guided clients through their most critical inflection points,
              unlocking new value streams and building adaptive cultures.
            </p>
          </div>
          <ul className="impact-list">
            <li>Integrated sustainability into core strategy for a top-5 energy provider.</li>
            <li>Enabled $500M in net-new revenue through venture studios and corporate incubation.</li>
            <li>Elevated leadership capabilities via experiential change programs.</li>
            <li>Reduced operational waste by 23% through intelligent automation initiatives.</li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default About;