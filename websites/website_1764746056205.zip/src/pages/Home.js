import React, { useEffect, useMemo, useRef, useState } from "react";
import { NavLink } from "react-router-dom";

const Home = () => {
  const statsRef = useRef([]);
  const [revealedStats, setRevealedStats] = useState({});
  const [activeCategory, setActiveCategory] = useState("All");
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  const stats = useMemo(
    () => [
      { label: "Global Transformations", value: 128 },
      { label: "Revenue Growth Achieved", value: 34 },
      { label: "Innovation Programs Delivered", value: 76 },
      { label: "Leadership Teams Coached", value: 52 },
    ],
    []
  );

  const services = [
    {
      title: "Strategic Roadmapping",
      description:
        "Craft vision-led roadmaps that align stakeholders, prioritize investments, and accelerate execution.",
      icon: "🛤️",
    },
    {
      title: "Innovation Studio",
      description:
        "Design and launch breakthrough products with customer-centric experimentation and agile delivery.",
      icon: "🚀",
    },
    {
      title: "Change Leadership",
      description:
        "Shape adaptive cultures and empower leaders to navigate complexity with clarity and confidence.",
      icon: "🧭",
    },
    {
      title: "Digital Operating Models",
      description:
        "Reimagine operating models with data-driven insights to unlock scalability and efficiency.",
      icon: "📊",
    },
  ];

  const processSteps = [
    {
      title: "Discover & Diagnose",
      description:
        "We immerse in your organization to understand aspirations, constraints, and hidden opportunities.",
    },
    {
      title: "Co-create Strategy",
      description:
        "Collaborative workshops translate insights into pragmatic strategies backed by data and foresight.",
    },
    {
      title: "Pilot & Validate",
      description:
        "Low-risk pilots test solutions, generate momentum, and refine execution playbooks.",
    },
    {
      title: "Scale & Sustain",
      description:
        "We embed capabilities, governance, and measurement to ensure enduring impact.",
    },
  ];

  const testimonials = [
    {
      quote:
        "ApexVision helped us reimagine our operating model and delivered a 19% uplift in profitability within six months.",
      name: "Jordan Alvarez",
      role: "COO, NovaTech Industries",
    },
    {
      quote:
        "Their ability to bring clarity to complexity is unmatched. Our innovation pipeline has never been stronger.",
      name: "Priya Desai",
      role: "Chief Innovation Officer, Horizon Labs",
    },
    {
      quote:
        "The change leadership program transformed our culture. Employee engagement scores jumped 24 points.",
      name: "Marcus Lee",
      role: "HR Director, Stellar Financial",
    },
  ];

  const projects = [
    {
      title: "Digital Supply Chain Reinvention",
      category: "Strategy",
      description:
        "Built a data-powered ecosystem to reduce lead times by 38% across four continents.",
      image: "https://picsum.photos/1200/800?random=4",
    },
    {
      title: "Intelligent Customer Experience",
      category: "Innovation",
      description:
        "Designed AI-enabled journeys that increased retention by 27% for a global telecom.",
      image: "https://picsum.photos/1200/800?random=5",
    },
    {
      title: "Culture of Experimentation",
      category: "Culture",
      description:
        "Developed a scalable experimentation framework adopted by 6,000 employees.",
      image: "https://picsum.photos/1200/800?random=6",
    },
    {
      title: "Sustainable Growth Blueprint",
      category: "Strategy",
      description:
        "Mapped new revenue pathways adding $220M ARR for a green energy pioneer.",
      image: "https://picsum.photos/1200/800?random=7",
    },
  ];

  const categories = ["All", "Strategy", "Innovation", "Culture"];

  const faqs = [
    {
      question: "How do you tailor solutions to our industry's realities?",
      answer:
        "We begin every engagement with deep discovery, data analysis, and stakeholder interviews. This ensures our recommendations are grounded in your market dynamics, regulatory environment, and organizational DNA.",
    },
    {
      question: "What is the typical length of an engagement?",
      answer:
        "While some strategy sprints can be completed within 6-8 weeks, transformational programs often span 6-12 months. We design modular engagements that deliver value at every milestone.",
    },
    {
      question: "Do you offer executive coaching and enablement?",
      answer:
        "Yes. Our certified executive coaches partner with leadership teams to build alignment, enhance decision-making, and embed resilience throughout transformation journeys.",
    },
    {
      question: "How do you measure success?",
      answer:
        "We define success metrics collaboratively—ranging from financial KPIs to cultural indicators—and implement dashboards that track progress against these metrics in real time.",
    },
  ];

  const blogPosts = [
    {
      title: "Reframing Strategy for the Era of Intelligent Automation",
      excerpt:
        "Discover how leading enterprises are reframing strategy to integrate automation and human ingenuity.",
      date: "February 15, 2024",
    },
    {
      title: "Five Cultural Shifts for High-Velocity Innovation",
      excerpt:
        "Culture drives innovation velocity. Explore five pragmatic shifts that unlock creativity and speed.",
      date: "January 28, 2024",
    },
    {
      title: "Embedding Sustainability into Operating Models",
      excerpt:
        "Move beyond ESG reporting with operating models designed for sustainable growth and impact.",
      date: "January 10, 2024",
    },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = entry.target.getAttribute("data-index");
            setRevealedStats((prev) => ({ ...prev, [index]: true }));
          }
        });
      },
      { threshold: 0.4 }
    );

    statsRef.current.forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => {
      statsRef.current.forEach((el) => {
        if (el) observer.unobserve(el);
      });
    };
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const filteredProjects =
    activeCategory === "All"
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  return (
    <div className="home-page">
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-copy">
            <span className="eyebrow">Strategy | Innovation | Culture</span>
            <h1>
              Build resilient organizations that thrive in accelerated change.
            </h1>
            <p>
              ApexVision Consulting equips visionary leaders with data-driven
              strategies, adaptive cultures, and innovation ecosystems that
              deliver tangible impact.
            </p>
            <div className="hero-actions">
              <NavLink to="/contact" className="btn">
                Schedule a Strategy Call
              </NavLink>
              <NavLink to="/services" className="btn-outline">
                Explore Our Services
              </NavLink>
            </div>
            <div className="hero-trust">
              Trusted by future-ready enterprises worldwide.
            </div>
          </div>
          <div className="hero-media">
            <img
              src="https://picsum.photos/1600/900?random=1"
              alt="Strategic business team meeting"
              loading="lazy"
            />
            <div className="hero-card">
              <strong>94%</strong>
              <span>Clients exceed growth targets within 12 months.</span>
            </div>
          </div>
        </div>
      </section>

      <section className="stats">
        <div className="container stats-grid">
          {stats.map((stat, index) => {
            const displayValue = revealedStats[index]
              ? stat.value
              : Math.floor(stat.value * 0.2);
            return (
              <div
                key={stat.label}
                className="stat-card"
                data-index={index}
                ref={(el) => (statsRef.current[index] = el)}
              >
                <span className="stat-value">
                  {displayValue}
                  {stat.label.includes("Revenue") ? "%" : ""}
                </span>
                <span className="stat-label">{stat.label}</span>
              </div>
            );
          })}
        </div>
      </section>

      <section className="services">
        <div className="container section-header">
          <span className="eyebrow">What We Do</span>
          <h2>End-to-end advisory for leaders of modern enterprises.</h2>
          <p>
            Our consultants orchestrate strategy, technology, and human
            potential to accelerate value creation across your organization.
          </p>
        </div>
        <div className="container service-cards">
          {services.map((service) => (
            <article key={service.title} className="service-card">
              <div className="service-icon">{service.icon}</div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <NavLink to="/services" className="service-link">
                Learn more →
              </NavLink>
            </article>
          ))}
        </div>
      </section>

      <section className="process">
        <div className="container">
          <div className="section-header align-left">
            <span className="eyebrow">Our Methodology</span>
            <h2>Designed for momentum, built for measurable outcomes.</h2>
            <p>
              We combine strategic foresight with human-centered design to guide
              teams from ambiguity to clarity, and from ambition to execution.
            </p>
          </div>
          <div className="process-steps">
            {processSteps.map((step, index) => (
              <div key={step.title} className="process-step">
                <span className="step-number">{index + 1}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials">
        <div className="container testimonials-layout">
          <div className="section-header align-left compact">
            <span className="eyebrow">Client Voices</span>
            <h2>Impact stories from the leaders we serve.</h2>
            <p>
              Hear how visionary organizations partner with ApexVision to unlock
              transformation at scale.
            </p>
          </div>
          <div className="testimonial-carousel">
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.name}
                className={`testimonial-slide ${
                  index === activeTestimonial ? "active" : ""
                }`}
              >
                <p className="testimonial-quote">{testimonial.quote}</p>
                <span className="testimonial-name">{testimonial.name}</span>
                <span className="testimonial-role">{testimonial.role}</span>
              </div>
            ))}
            <div className="testimonial-controls">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  aria-label={`Show testimonial ${index + 1}`}
                  className={index === activeTestimonial ? "active" : ""}
                  onClick={() => setActiveTestimonial(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="projects">
        <div className="container section-header">
          <span className="eyebrow">Featured Projects</span>
          <h2>From vision to value: transformations we led.</h2>
          <p>
            Explore how we architected measurable change across industries,
            guiding clients from possibility to performance.
          </p>
        </div>
        <div className="container project-filters">
          {categories.map((category) => (
            <button
              key={category}
              className={`filter-chip ${
                category === activeCategory ? "active" : ""
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className="container project-grid">
          {filteredProjects.map((project) => (
            <article key={project.title} className="project-card">
              <div className="project-image">
                <img
                  src={`${project.image}&sig=${encodeURIComponent(
                    project.title
                  )}`}
                  alt={`${project.title} case study`}
                  loading="lazy"
                />
              </div>
              <div className="project-content">
                <span className="project-category">{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="insights-highlight">
        <div className="container insights-grid">
          <div className="insights-media">
            <img
              src="https://picsum.photos/800/600?random=2"
              alt="Business professionals analyzing data dashboards"
              loading="lazy"
            />
          </div>
          <div className="section-header align-left compact">
            <span className="eyebrow">Insights &amp; Research</span>
            <h2>Diagnostic intelligence to decode tomorrow’s opportunities.</h2>
            <p>
              Our analysts translate signals into strategic foresight, equipping
              leaders to act decisively amid uncertainty.
            </p>
            <NavLink to="/services" className="btn">
              Discover our advisory approach
            </NavLink>
          </div>
        </div>
      </section>

      <section className="faq">
        <div className="container section-header">
          <span className="eyebrow">FAQ</span>
          <h2>Answers to the questions leaders ask most.</h2>
          <p>
            Need more clarity? Explore our frequently asked questions or reach
            out directly for a custom briefing.
          </p>
        </div>
        <div className="container faq-accordion">
          {faqs.map((faqItem, index) => (
            <details key={faqItem.question} open={index === 0}>
              <summary>{faqItem.question}</summary>
              <p>{faqItem.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="blog-preview">
        <div className="container section-header">
          <span className="eyebrow">Latest from the ApexVision Lab</span>
          <h2>Insights to empower bold decisions.</h2>
          <p>
            Fresh thinking at the intersection of strategy, innovation, and
            transformation.
          </p>
        </div>
        <div className="container blog-grid">
          {blogPosts.map((post) => (
            <article key={post.title} className="blog-card">
              <span className="blog-date">{post.date}</span>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <button className="btn-link" type="button">
                Read article →
              </button>
            </article>
          ))}
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-inner">
          <div>
            <span className="eyebrow light">Ready to accelerate?</span>
            <h2>Let’s architect your next horizon together.</h2>
            <p>
              Partner with ApexVision to shape strategies that energize teams,
              inspire customers, and deliver measurable growth.
            </p>
          </div>
          <div className="cta-buttons">
            <NavLink to="/contact" className="btn btn-light">
              Book a Discovery Session
            </NavLink>
            <NavLink to="/about" className="btn-outline btn-light-outline">
              Meet our leadership →
            </NavLink>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;