import React from "react";

const Privacy = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">Privacy</span>
          <h1>Privacy Policy</h1>
          <p>Last updated: January 5, 2024</p>
        </div>
      </section>
      <section className="container legal-content">
        <h2>1. Overview</h2>
        <p>
          ApexVision Consulting respects your privacy and is committed to
          protecting your personal data. This policy outlines how we collect,
          use, and safeguard information.
        </p>
        <h2>2. Information We Collect</h2>
        <p>
          We collect information you provide via forms, as well as technical
          data through cookies and analytics to enhance user experience.
        </p>
        <h2>3. Use of Information</h2>
        <p>
          Information is used to respond to inquiries, deliver services,
          improve our offerings, and communicate relevant insights and updates.
        </p>
        <h2>4. Cookies</h2>
        <p>
          We use cookies to personalize content and analyze site performance.
          You may control cookies through browser settings, but some features
          may be limited.
        </p>
        <h2>5. Data Security</h2>
        <p>
          We implement administrative, technical, and physical safeguards to
          protect personal information against unauthorized access and misuse.
        </p>
        <h2>6. Your Rights</h2>
        <p>
          Depending on your jurisdiction, you may have rights to access, amend,
          or delete personal data. Contact us to exercise these rights.
        </p>
        <h2>7. Contact</h2>
        <p>
          For privacy inquiries, email{" "}
          <a href="mailto:privacy@apexvision.co">privacy@apexvision.co</a>.
        </p>
      </section>
    </div>
  );
};

export default Privacy;