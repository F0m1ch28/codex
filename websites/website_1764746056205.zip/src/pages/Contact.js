import React, { useState } from "react";

const Contact = () => {
  const initialState = {
    name: "",
    email: "",
    company: "",
    message: "",
  };
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please enter your name.";
    if (!formData.email.trim()) {
      newErrors.email = "Please enter your email.";
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = "Enter a valid email address.";
    }
    if (!formData.company.trim())
      newErrors.company = "Please enter your company.";
    if (!formData.message.trim() || formData.message.length < 20) {
      newErrors.message =
        "Please share more context (minimum 20 characters).";
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setErrors((prev) => ({ ...prev, [name]: null }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData(initialState);
    } else {
      setErrors(validationErrors);
      setSubmitted(false);
    }
  };

  return (
    <div className="page contact-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">Contact</span>
          <h1>Let’s create momentum together.</h1>
          <p>
            Tell us about your ambitions and challenges. We’ll assemble the
            right experts to craft a response within two business days.
          </p>
        </div>
      </section>

      <section className="contact-section">
        <div className="container contact-grid">
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="name">Full name</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={!!errors.name}
              />
              {errors.name && <span className="form-error">{errors.name}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="email">Work email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={!!errors.email}
              />
              {errors.email && (
                <span className="form-error">{errors.email}</span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="company">Company</label>
              <input
                id="company"
                name="company"
                type="text"
                value={formData.company}
                onChange={handleChange}
                aria-invalid={!!errors.company}
              />
              {errors.company && (
                <span className="form-error">{errors.company}</span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="message">Tell us about your priorities</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={!!errors.message}
              />
              {errors.message && (
                <span className="form-error">{errors.message}</span>
              )}
            </div>
            <button type="submit" className="btn">
              Submit Inquiry
            </button>
            {submitted && (
              <div className="form-success">
                Thank you! We’ll be in touch shortly to schedule a consultation.
              </div>
            )}
          </form>
          <div className="contact-info-panel">
            <h2>Global Presence</h2>
            <p>
              We partner with clients in North America, Europe, Asia, and Latin
              America through hybrid engagement models.
            </p>
            <div className="contact-details">
              <div>
                <h3>Headquarters</h3>
                <p>
                  745 Lexington Avenue
                  <br />
                  Suite 1800
                  <br />
                  New York, NY 10022
                </p>
              </div>
              <div>
                <h3>Direct Contact</h3>
                <p>
                  <a href="mailto:hello@apexvision.co">hello@apexvision.co</a>
                  <br />
                  <a href="tel:+12125550123">+1 (212) 555-0123</a>
                </p>
              </div>
              <div>
                <h3>Partner With Us</h3>
                <p>
                  Interested in collaboration? Share your perspective and we’ll
                  explore synergies.
                </p>
              </div>
            </div>
            <div className="contact-callout">
              <h4>Office Hours</h4>
              <p>Monday to Friday — 8:30 AM to 6:30 PM EST</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;