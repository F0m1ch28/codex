import React, { useState } from "react";

const Services = () => {
  const tabs = [
    {
      id: "strategy",
      title: "Strategy & Growth",
      summary:
        "Shape resilient strategies that translate vision into measurable growth, backed by scenario planning and data intelligence.",
      deliverables: [
        "Corporate and business-unit strategy",
        "Growth acceleration roadmaps",
        "M&A and portfolio optimization",
        "Customer and market insights",
      ],
    },
    {
      id: "innovation",
      title: "Innovation & Venture Design",
      summary:
        "Launch differentiated products and ventures by combining human insight, experimentation, and scalable technology platforms.",
      deliverables: [
        "Innovation portfolio management",
        "Customer discovery and design sprints",
        "Rapid prototyping & venture incubation",
        "Innovation operating model design",
      ],
    },
    {
      id: "culture",
      title: "Culture & Change Leadership",
      summary:
        "Build adaptive cultures and equip leaders to guide transformation with clarity, empathy, and data-driven coaching.",
      deliverables: [
        "Leadership alignment & enablement",
        "Change readiness diagnostics",
        "Capability academies & coaching",
        "Employee experience design",
      ],
    },
    {
      id: "operations",
      title: "Digital Operations & Enablement",
      summary:
        "Modernize operating models with automation, analytics, and performance management frameworks that sustain momentum.",
      deliverables: [
        "Operating model redesign",
        "Automation opportunity mapping",
        "Data platform strategy",
        "Performance dashboards & OKRs",
      ],
    },
  ];

  const [activeTab, setActiveTab] = useState(tabs[0]);

  return (
    <div className="page services-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">Services</span>
          <h1>Integrated advisory solutions for every phase of transformation.</h1>
          <p>
            We partner with executives and teams to design strategies, build
            capabilities, and deliver outcomes that endure. Explore our
            interconnected services tailored to your most pressing priorities.
          </p>
        </div>
      </section>

      <section className="service-tabs">
        <div className="container tab-list">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={`tab-button ${
                tab.id === activeTab.id ? "active" : ""
              }`}
              onClick={() => setActiveTab(tab)}
            >
              {tab.title}
            </button>
          ))}
        </div>
        <div className="container tab-panel">
          <div className="tab-content">
            <h2>{activeTab.title}</h2>
            <p>{activeTab.summary}</p>
            <h4>Core Deliverables</h4>
            <ul>
              {activeTab.deliverables.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <button className="btn btn-sm" type="button">
              Request a tailored proposal →
            </button>
          </div>
        </div>
      </section>

      <section className="partnership">
        <div className="container partnership-grid">
          <div>
            <span className="eyebrow">Partnership Models</span>
            <h2>Flexible engagement models aligned to your goals.</h2>
            <p>
              Whether you need rapid diagnostics, embedded squads, or executive
              coaching, ApexVision adapts to your cadence, culture, and desired
              outcomes.
            </p>
          </div>
          <div className="partnership-cards">
            <article>
              <h3>Transformation Sprints</h3>
              <p>
                6-12 week sprints to validate new strategies, define operating
                models, or test innovation hypotheses with measurable outputs.
              </p>
            </article>
            <article>
              <h3>Embedded Advisory Squads</h3>
              <p>
                Cross-functional teams integrated with your organization to
                accelerate execution and build internal capabilities.
              </p>
            </article>
            <article>
              <h3>Executive & Team Enablement</h3>
              <p>
                Leadership coaching, capability academies, and experiential
                programs to align teams and sustain change.
              </p>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;