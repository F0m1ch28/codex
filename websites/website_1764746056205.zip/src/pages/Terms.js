import React from "react";

const Terms = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">Legal</span>
          <h1>Terms of Service</h1>
          <p>Last updated: January 5, 2024</p>
        </div>
      </section>
      <section className="container legal-content">
        <h2>1. Introduction</h2>
        <p>
          These Terms of Service govern your use of the ApexVision Consulting
          website and services. By accessing our site, you agree to these terms.
        </p>
        <h2>2. Use of Services</h2>
        <p>
          You agree to use our services responsibly and in compliance with all
          applicable laws. Unauthorized or unethical use is strictly prohibited.
        </p>
        <h2>3. Intellectual Property</h2>
        <p>
          All content on this site, including text, graphics, and trademarks,
          is the property of ApexVision Consulting and protected by intellectual
          property laws.
        </p>
        <h2>4. Limitation of Liability</h2>
        <p>
          ApexVision Consulting is not liable for any indirect, incidental, or
          consequential damages arising from your use of our website or
          services.
        </p>
        <h2>5. Changes to Terms</h2>
        <p>
          We may update these terms periodically. Continued use of the site
          indicates acceptance of the revised terms.
        </p>
        <h2>6. Contact</h2>
        <p>
          For questions, contact{" "}
          <a href="mailto:legal@apexvision.co">legal@apexvision.co</a>.
        </p>
      </section>
    </div>
  );
};

export default Terms;