document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
      navToggle.classList.toggle('is-active');
      siteNav.classList.toggle('nav-open');
    });

    siteNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          siteNav.classList.remove('nav-open');
          navToggle.classList.remove('is-active');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth >= 768) {
        siteNav.classList.remove('nav-open');
        navToggle.classList.remove('is-active');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  const navLinks = document.querySelectorAll('.site-nav a');
  let currentPath = window.location.pathname.split('/').pop();
  if (currentPath === '' || currentPath === undefined) {
    currentPath = 'index.html';
  }
  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPath) {
      link.classList.add('active');
      link.setAttribute('aria-current', 'page');
    }
  });

  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', event => {
      const targetId = anchor.getAttribute('href').substring(1);
      const target = document.getElementById(targetId);
      if (target) {
        event.preventDefault();
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');
    const consent = localStorage.getItem('aurora-cookie-consent');

    if (!consent) {
      requestAnimationFrame(() => cookieBanner.classList.add('active'));
    }

    const hideBanner = value => {
      localStorage.setItem('aurora-cookie-consent', value);
      cookieBanner.classList.remove('active');
    };

    acceptBtn?.addEventListener('click', () => hideBanner('accepted'));
    declineBtn?.addEventListener('click', () => hideBanner('declined'));
  }

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    const formMessage = document.getElementById('form-message');

    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const errors = [];
      const name = formData.get('name').trim();
      const email = formData.get('email').trim();
      const company = formData.get('company').trim();
      const message = formData.get('message').trim();
      const budget = formData.get('budget');
      const timeline = formData.get('timeline');
      const consent = contactForm.querySelector('#consent').checked;

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (!name) errors.push('Please enter your name.');
      if (!email || !emailPattern.test(email)) errors.push('Please provide a valid email address.');
      if (!company) errors.push('Please share your company name.');
      if (!budget) errors.push('Select an estimated budget.');
      if (!timeline) errors.push('Select your ideal timeline.');
      if (!message || message.length < 20) errors.push('Please provide a brief project overview (at least 20 characters).');
      if (!consent) errors.push('Please agree to the privacy policy.');

      if (errors.length > 0) {
        formMessage.textContent = errors[0];
        formMessage.className = 'form-message error';
        return;
      }

      formMessage.textContent = 'Thank you! Your message has been received. We’ll be in touch soon.';
      formMessage.className = 'form-message success';
      contactForm.reset();
    });
  }
});