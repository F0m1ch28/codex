document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');
    const currentYear = new Date().getFullYear();
    const yearElements = document.querySelectorAll('[id^="year-"]');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            siteNav.classList.toggle('active');
        });

        siteNav.addEventListener('click', (event) => {
            if (event.target.tagName === 'A') {
                navToggle.classList.remove('active');
                siteNav.classList.remove('active');
            }
        });
    }

    if (yearElements.length) {
        yearElements.forEach((el) => {
            el.textContent = currentYear;
        });
    }

    if (cookieBanner && acceptBtn && declineBtn) {
        const storedPreference = localStorage.getItem('mv_cookie_preference');

        if (!storedPreference) {
            cookieBanner.classList.add('active');
        }

        acceptBtn.addEventListener('click', () => {
            localStorage.setItem('mv_cookie_preference', 'accepted');
            cookieBanner.classList.remove('active');
        });

        declineBtn.addEventListener('click', () => {
            localStorage.setItem('mv_cookie_preference', 'declined');
            cookieBanner.classList.remove('active');
        });
    }
});