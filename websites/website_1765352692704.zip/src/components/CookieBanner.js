import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'digitalcovers-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setTimeout(() => setIsVisible(true), 1000);
    }
  }, []);

  const handleChoice = (value) => {
    localStorage.setItem(STORAGE_KEY, value);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Мы используем cookie</h4>
        <p>
          DigitalCovers применяет файлы cookie для улучшения работы сайта и персонализации контента. Подробности — в нашей{' '}
          <a href="/cookie-policy">Политике использования файлов cookie</a>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.accept} onClick={() => handleChoice('accepted')} aria-label="Принять использование файлов cookie">
          Принять
        </button>
        <button type="button" className={styles.decline} onClick={() => handleChoice('declined')} aria-label="Отклонить использование файлов cookie">
          Отклонить
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;