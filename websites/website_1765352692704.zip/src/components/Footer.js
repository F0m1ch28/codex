import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.grid}>
        <div>
          <h3 className={styles.logo}>
            Digital<span>Covers</span>
          </h3>
          <p className={styles.text}>
            Профессиональные цифровые дизайны для стримеров, блогеров и креаторов. Создаем визуал, который помогает выделяться и привлекать аудиторию.
          </p>
          <div className={styles.socials} aria-label="Социальные сети DigitalCovers">
            <a href="https://vk.com" target="_blank" rel="noreferrer" aria-label="Открыть VK DigitalCovers">
              VK
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="Открыть YouTube DigitalCovers">
              YouTube
            </a>
            <a href="https://www.twitch.tv" target="_blank" rel="noreferrer" aria-label="Открыть Twitch DigitalCovers">
              Twitch
            </a>
          </div>
        </div>

        <div>
          <h4 className={styles.heading}>Навигация</h4>
          <ul className={styles.list}>
            <li>
              <Link to="/" className={styles.link}>
                Главная
              </Link>
            </li>
            <li>
              <Link to="/catalog" className={styles.link}>
                Каталог
              </Link>
            </li>
            <li>
              <Link to="/about" className={styles.link}>
                О нас
              </Link>
            </li>
            <li>
              <Link to="/contact" className={styles.link}>
                Контакты
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className={styles.heading}>Документы</h4>
          <ul className={styles.list}>
            <li>
              <Link to="/terms" className={styles.link}>
                Условия использования
              </Link>
            </li>
            <li>
              <Link to="/privacy" className={styles.link}>
                Политика конфиденциальности
              </Link>
            </li>
            <li>
              <Link to="/cookie-policy" className={styles.link}>
                Политика Cookie
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className={styles.heading}>Контакты</h4>
          <ul className={styles.contactList}>
            <li>
              <span className={styles.contactLabel}>Email:</span>
              <a href="mailto:support@digitalcovers.store" className={styles.link}>
                support@digitalcovers.store
              </a>
            </li>
            <li>
              <span className={styles.contactLabel}>Телефон (для консультаций):</span>
              <a href="tel:+7XXXXXXXXXX" className={styles.link}>
                +7 (XXX) XXX-XX-XX
              </a>
            </li>
            <li>
              <span className={styles.contactLabel}>Адрес:</span>
              <span className={styles.text}>123456, Россия, г. Москва, ул. Цифровая, д. 1, офис &laquo;Виртуальный&raquo;</span>
            </li>
          </ul>
        </div>
      </div>

      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} DigitalCovers. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;