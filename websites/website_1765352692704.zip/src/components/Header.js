import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleToggleMenu = () => setIsMenuOpen((prev) => !prev);
  const handleCloseMenu = () => setIsMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="DigitalCovers — переход на главную">
          Digital<span>Covers</span>
        </Link>

        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Главная навигация">
          <NavLink to="/" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} onClick={handleCloseMenu}>
            Главная
          </NavLink>
          <NavLink to="/catalog" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} onClick={handleCloseMenu}>
            Каталог
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} onClick={handleCloseMenu}>
            О нас
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} onClick={handleCloseMenu}>
            Контакты
          </NavLink>
        </nav>

        <div className={styles.actions}>
          <Link to="/catalog" className={styles.catalogButton} aria-label="Перейти в каталог DigitalCovers" onClick={handleCloseMenu}>
            В каталог
          </Link>
          <button
            type="button"
            className={styles.menuButton}
            onClick={handleToggleMenu}
            aria-label={isMenuOpen ? 'Закрыть меню' : 'Открыть меню'}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;