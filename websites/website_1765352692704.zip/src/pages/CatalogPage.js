import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './CatalogPage.module.css';

const collections = [
  {
    title: 'Коллекция «Flux Motion»',
    description: 'Динамичные превью и баннеры с акцентом на неон и motion-эффекты. Идеально для игровых каналов.',
    image: 'https://images.unsplash.com/photo-1474631245212-32dc3c8310c6?auto=format&fit=crop&w=900&q=80',
    link: '/catalog/video-covers',
    tags: ['YouTube', 'Gaming', 'Motion']
  },
  {
    title: 'Набор «Creator Focus»',
    description: 'Универсальные обложки и иконки для образовательных и лайфстайл-каналов, акцент на персонаже и типографике.',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80',
    link: '/catalog/avatars-icons',
    tags: ['Lifestyle', 'Education', 'Personal brand']
  },
  {
    title: 'Оформление «Streamline»',
    description: 'Комплект сцен, панелей и alerts для Twitch. Поддержка анимации и адаптация под мобильные платформы.',
    image: 'https://images.unsplash.com/photo-1483478550801-ceba5fe50e8e?auto=format&fit=crop&w=900&q=80',
    link: '/catalog/banners-overlays',
    tags: ['Twitch', 'Overlay', 'Animated']
  }
];

const CatalogPage = () => {
  return (
    <div className={styles.page}>
      <Seo
        title="Каталог DigitalCovers — коллекции цифровых дизайнов"
        description="Ознакомьтесь с коллекциями DigitalCovers: обложки для видео, аватарки, баннеры и оверлеи для стримеров и блогеров."
      />
      <section className={styles.intro}>
        <h1>Каталог DigitalCovers</h1>
        <p>
          Готовые решения для YouTube, Twitch и социальных сетей. Выберите категорию, найдите дизайн, адаптируйте под свой проект и впечатляйте аудиторию.
        </p>
      </section>

      <section className={styles.collections}>
        {collections.map((collection) => (
          <article key={collection.title} className={styles.card}>
            <div className={styles.media}>
              <img src={collection.image} alt={collection.title} loading="lazy" />
            </div>
            <div className={styles.content}>
              <h2>{collection.title}</h2>
              <p>{collection.description}</p>
              <ul className={styles.tags} aria-label="Особенности коллекции">
                {collection.tags.map((tag) => (
                  <li key={tag}>{tag}</li>
                ))}
              </ul>
              <Link to={collection.link} className={styles.button} aria-label={`Открыть ${collection.title}`}>
                Смотреть коллекцию
              </Link>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaCard}>
          <h2>Нужен индивидуальный дизайн?</h2>
          <p>Расскажите, какой визуал вы ищете, и мы соберём персональный пакет под ваши задачи.</p>
          <Link to="/contact" className={styles.ctaButton} aria-label="Связаться с DigitalCovers для индивидуального дизайна">
            Связаться с командой
          </Link>
        </div>
      </section>
    </div>
  );
};

export default CatalogPage;