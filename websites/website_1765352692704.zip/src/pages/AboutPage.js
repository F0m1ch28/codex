import React from 'react';
import Seo from '../components/Seo';
import styles from './AboutPage.module.css';

const team = [
  {
    name: 'Екатерина Власова',
    role: 'Креативный директор',
    bio: 'Курирует визуальные концепции DigitalCovers и отвечает за тренды графического оформления стримов.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Михаил Орлов',
    role: 'Lead Motion Designer',
    bio: 'Создает анимированные оверлеи и alerts, следит за качеством motion-графики в проектах.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Анастасия Зорина',
    role: 'Менеджер по работе с клиентами',
    bio: 'Настраивает коммуникацию и следит, чтобы каждый клиент получал идеальный результат и поддержку.',
    image: 'https://images.unsplash.com/photo-1531891437562-4301cf35b7e4?auto=format&fit=crop&w=600&q=80'
  }
];

const milestones = [
  {
    year: '2020',
    text: 'DigitalCovers запускает первую коллекцию обложек для YouTube и Twitch.'
  },
  {
    year: '2021',
    text: 'Появляются анимированные overlays и кастомизация под бренды.'
  },
  {
    year: '2022',
    text: 'Команда выходит на международный рынок и расширяет поддержку 24/7.'
  },
  {
    year: '2023',
    text: 'Запуск каталога с пакетами «под ключ» и партнерские программы с агентствами.'
  }
];

const AboutPage = () => {
  return (
    <div className={styles.page}>
      <Seo
        title="О компании DigitalCovers"
        description="DigitalCovers — команда дизайнеров, создающих визуальные решения для стримеров и блогеров по всему миру."
      />
      <section className={styles.hero}>
        <div>
          <h1>DigitalCovers — команда, которая помогает контенту сиять</h1>
          <p>
            Мы создаем графику, которая усиливает личный бренд, рассказывает истории и помогает креаторам масштабировать проекты. Наша задача — дать доступ к профессиональному дизайну каждому, кто стремится выделиться.
          </p>
        </div>
        <img src="https://images.unsplash.com/photo-1521737604893-5b040b35b7f0?auto=format&fit=crop&w=900&q=80" alt="Команда DigitalCovers за обсуждением проекта" loading="lazy" />
      </section>

      <section className={styles.mission}>
        <article>
          <h2>Миссия</h2>
          <p>Дарить возможность контент-мейкерам любого масштаба говорить с аудиторией через сильный визуальный стиль.</p>
        </article>
        <article>
          <h2>Ценности</h2>
          <ul>
            <li>Ответственность за результат и эффект для аудитории.</li>
            <li>Доступность профессионального дизайна без лишней бюрократии.</li>
            <li>Прозрачность в процессах и поддержка на каждом этапе.</li>
          </ul>
        </article>
        <article>
          <h2>Экспертиза</h2>
          <p>DigitalCovers сочетает дизайн, motion-графику и продюсерский опыт, чтобы создавать решения, работающие в digital-среде.</p>
        </article>
      </section>

      <section className={styles.timeline}>
        <h2>Как мы развивались</h2>
        <div className={styles.timelineGrid}>
          {milestones.map((item) => (
            <div className={styles.timelineItem} key={item.year}>
              <span>{item.year}</span>
              <p>{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.teamSection}>
        <h2>Команда DigitalCovers</h2>
        <p className={styles.teamIntro}>Мы работаем удаленно из разных городов, но объединены любовью к дизайну и вниманием к деталям.</p>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article key={member.name}>
              <img src={member.image} alt={member.name} loading="lazy" />
              <div>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.partners}>
        <div>
          <h2>Работа с агентствами</h2>
          <p>Сотрудничаем с маркетинговыми командами и продюсерскими центрами, предлагаем white-label решения и гибкие условия.</p>
        </div>
        <div className={styles.partnerHighlights}>
          <div>
            <strong>35+</strong>
            <span>постоянных партнёров</span>
          </div>
          <div>
            <strong>190+</strong>
            <span>запусков кампаний в год</span>
          </div>
          <div>
            <strong>4,8/5</strong>
            <span>средняя оценка проектов</span>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;