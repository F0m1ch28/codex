import React from 'react';
import Seo from '../components/Seo';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => {
  return (
    <div className={styles.page}>
      <Seo
        title="Политика использования файлов cookie — DigitalCovers"
        description="Информация о том, как DigitalCovers использует файлы cookie."
      />
      <h1>Политика использования файлов cookie</h1>
      <p className={styles.updated}>Обновлено: 1 мая 2024 г.</p>

      <section>
        <h2>1. Что такое cookie</h2>
        <p>Cookie — это небольшие текстовые файлы, которые сохраняются в браузере пользователя для анализа поведения и персонализации контента.</p>
      </section>

      <section>
        <h2>2. Как мы используем cookie</h2>
        <ul>
          <li>Функциональные cookie — помогают запомнить ваши настройки и предпочтения.</li>
          <li>Аналитические cookie — используются для анонимной статистики посещений и улучшения сервиса.</li>
        </ul>
      </section>

      <section>
        <h2>3. Управление cookie</h2>
        <p>Вы можете отключить cookie в настройках браузера или воспользоваться баннером согласия на сайте. Учтите, что это может ограничить часть функциональности.</p>
      </section>

      <section>
        <h2>4. Контакты</h2>
        <p>По вопросам использования cookie пишите на support@digitalcovers.store.</p>
      </section>
    </div>
  );
};

export default CookiePolicyPage;