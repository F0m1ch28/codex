import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './HomePage.module.css';

const categories = [
  {
    title: 'Обложки для видео',
    description: 'Высококонтрастные превью для YouTube и буст CTR в рекомендациях.',
    link: '/catalog/video-covers',
    icon: '🎬'
  },
  {
    title: 'Аватарки и иконки',
    description: 'Запоминающиеся и узнаваемые образы для любых платформ.',
    link: '/catalog/avatars-icons',
    icon: '🛸'
  },
  {
    title: 'Баннеры и оверлеи',
    description: 'Целостный стиль трансляций и социальных сетей.',
    link: '/catalog/banners-overlays',
    icon: '🛰️'
  },
  {
    title: 'Комплект для стримера',
    description: 'Полное оформление каналов Twitch, Trovo, YouTube Live.',
    link: '/catalog',
    icon: '🚀'
  }
];

const stats = [
  { value: '1200+', label: 'готовых дизайнов' },
  { value: '89%', label: 'рост вовлечения клиентов' },
  { value: '48 ч', label: 'средний срок кастомизации' },
  { value: '24/7', label: 'поддержка DigitalCovers' }
];

const steps = [
  {
    title: 'Выберите дизайн',
    text: 'Найдите стиль, который отражает вашу индивидуальность или цель кампании.'
  },
  {
    title: 'Оформите заказ',
    text: 'Укажите нужные данные, загрузите референсы и подтвердите оплату.'
  },
  {
    title: 'Получите файлы',
    text: 'Мгновенная загрузка готовых пакетов и дополнительные форматы по запросу.'
  },
  {
    title: 'Расскажите миру',
    text: 'Запускайте прямые эфиры, публикуйте ролики и делитесь впечатлениями.'
  }
];

const benefits = [
  {
    title: 'Уникальность',
    text: 'Каждый дизайн продуман для максимальной узнаваемости и фирменного стиля.',
    icon: 'https://images.unsplash.com/photo-1526498460520-4c246339dccb?auto=format&fit=crop&w=300&q=80'
  },
  {
    title: 'Готовые решения',
    text: 'Пакеты включают PSD, PNG и адаптации под основные платформы.',
    icon: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=300&q=80'
  },
  {
    title: 'Поддержка форматов',
    text: 'Работаем с 4K, вертикальными и квадратными форматами, animated overlay.',
    icon: 'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=300&q=80'
  }
];

const personas = [
  {
    title: 'Стримеры',
    text: 'Оформление сцен, ожиданий и донат-панелей для Twitch, Trovo и YouTube Live.'
  },
  {
    title: 'Видео блогеры',
    text: 'Эффектные обложки, титры и нижние третьи для YouTube и VK Видео.'
  },
  {
    title: 'Бренды и предприниматели',
    text: 'Визуальные концепции для курсов, марафонов и digital-кампаний.'
  }
];

const testimonials = [
  {
    name: 'Мария Селиванова',
    role: 'YouTube-продюсер',
    text: 'Мы протестировали обложки DigitalCovers на пяти разных форматах: рост CTR составил 47% без дополнительной рекламы.',
    avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80'
  },
  {
    name: 'Алексей Кравцов',
    role: 'Стример Twitch',
    text: 'Полный комплект оверлеев пришёл за один день. Теперь канал выглядит профессионально, донаты выросли вдвое.',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=200&q=80'
  },
  {
    name: 'DigitalFix Studio',
    role: 'Агентство контента',
    text: 'Подкупает гибкость команды: они адаптируют макеты под брендбук и отдают исходники без лишних вопросов.',
    avatar: 'https://images.unsplash.com/photo-1521322080334-4bebac2761fb?auto=format&fit=crop&w=200&q=80'
  }
];

const projects = [
  {
    title: 'Линейка обложек «Neon Pulse»',
    text: 'Комплект превью для обучающих роликов с акцентом на читабельность и динамику.',
    image: 'https://images.unsplash.com/photo-1522542550221-31fd19575a2d?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Twitch Overlay «Spectrum»',
    text: 'Анимированные сцены ожидания, донат-панели и alerts в неоновом стиле.',
    image: 'https://images.unsplash.com/photo-1522199996660-7b43f57c76d0?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Пакет иконок «Pixel Icons»',
    text: 'Минималистичные иконки для Discord, Telegram и YouTube.',
    image: 'https://images.unsplash.com/photo-1549921296-3ecf9c46b993?auto=format&fit=crop&w=1200&q=80'
  }
];

const blogPosts = [
  {
    title: '5 трендов дизайн-оформления стримов в 2024 году',
    excerpt: 'Неоновые палитры, адаптивная анимация и персонализация алертов — разбираем, что работает.',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Подготовка YouTube-обложек: чек-лист продюсера',
    excerpt: 'Фокус на персонаже, хороший контраст и крупная типографика — рассказываем, как повысить CTR.',
    image: 'https://images.unsplash.com/photo-1523473827534-986f4bc980e3?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Как бренду построить визуальную экосистему в digital',
    excerpt: 'Разбираем кейсы DigitalCovers и шаги по внедрению единого фирменного стиля.',
    image: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&w=800&q=80'
  }
];

const faqItems = [
  {
    question: 'Можно ли адаптировать дизайн под мой брендбук?',
    answer: 'Да, укажите требования в комментариях к заказу или прикрепите брендбук. Мы подготовим дополнительные версии с нужными цветами и шрифтами.'
  },
  {
    question: 'В каком формате предоставляются файлы?',
    answer: 'Стандартно мы передаём PSD, PNG и JPG. По запросу доступны анимированные сцены в WEBM и After Effects-шаблоны.'
  },
  {
    question: 'Вы делаете эксклюзивные проекты?',
    answer: 'Да, мы берём ограниченное количество кастомных проектов каждый месяц. Напишите на support@digitalcovers.store — обсудим детали.'
  },
  {
    question: 'Как быстро я получу доступ к файлам?',
    answer: 'В готовых пакетах доступ появится мгновенно после оплаты. Кастомные правки занимают от 24 до 72 часов.'
  }
];

const HomePage = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const toggleFaq = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.page}>
      <Seo
        title="DigitalCovers — Готовый дизайн для стримеров и блогеров"
        description="Каталог готовых цифровых дизайнов: обложки для видео, аватарки, баннеры и оверлеи для YouTube, Twitch и других платформ."
      />

      <section className={styles.hero}>
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <p className={styles.label}>DigitalCovers • графика нового уровня</p>
          <h1>Премиум-дизайн для вашего контента</h1>
          <p className={styles.subtitle}>
            Создаём обложки, баннеры и оверлеи, которые сразу считываются аудиторией и выделяют ваш бренд среди конкурентов.
          </p>
          <div className={styles.heroActions}>
            <Link to="/catalog" className={styles.heroPrimary} aria-label="Смотреть каталог дизайнов DigitalCovers">
              Смотреть каталог
            </Link>
            <Link to="/contact" className={styles.heroSecondary} aria-label="Связаться с DigitalCovers">
              Получить консультацию
            </Link>
          </div>
          <div className={styles.heroStats} aria-label="Достижения DigitalCovers">
            {stats.map((item) => (
              <div className={styles.stat} key={item.label}>
                <span>{item.value}</span>
                <p>{item.label}</p>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroVisual} aria-hidden="true">
          <img src="https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1200&q=80" alt="Неоновый рабочий стол дизайнера" />
        </div>
      </section>

      <section className={styles.categories}>
        <div className={styles.sectionHead}>
          <h2>Популярные категории</h2>
          <p>Готовые коллекции для мгновенного улучшения визуала.</p>
        </div>
        <div className={styles.categoryGrid}>
          {categories.map((category) => (
            <Link to={category.link} className={styles.categoryCard} key={category.title} aria-label={`Перейти в категорию ${category.title}`}>
              <span className={styles.categoryIcon}>{category.icon}</span>
              <h3>{category.title}</h3>
              <p>{category.description}</p>
              <span className={styles.categoryCta}>Открыть</span>
            </Link>
          ))}
        </div>
      </section>

      <section className={styles.services}>
        <div className={styles.sectionHead}>
          <h2>Сервисы DigitalCovers</h2>
          <p>Гибкие пакеты и кастомные решения для разных этапов развития канала.</p>
        </div>
        <div className={styles.servicesGrid}>
          <article>
            <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80" alt="Команда дизайнеров за работой" loading="lazy" />
            <div>
              <h3>Готовые коллекции</h3>
              <p>Подборки дизайнов с единой стилистикой: обновите весь канал за вечер.</p>
            </div>
          </article>
          <article>
            <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80" alt="Рабочее место motion-дизайнера" loading="lazy" />
            <div>
              <h3>Анимированные оверлеи</h3>
              <p>Живые элементы и переходы для трансляций, которые удерживают внимание зрителей.</p>
            </div>
          </article>
          <article>
            <img src="https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=800&q=80" alt="Презентация бренда" loading="lazy" />
            <div>
              <h3>Кастом по запросу</h3>
              <p>Дизайн под ваш брендбук, с адаптацией под рекламные выходы и ключевые события.</p>
            </div>
          </article>
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHead}>
          <h2>Как это работает</h2>
        </div>
        <div className={styles.processGrid}>
          {steps.map((step, index) => (
            <div className={styles.processCard} key={step.title}>
              <span className={styles.stepNumber}>{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.benefits}>
        <div className={styles.sectionHead}>
          <h2>Преимущества DigitalCovers</h2>
          <p>Мы закрываем полный цикл — от идеи до внедрения на ваших платформах.</p>
        </div>
        <div className={styles.benefitGrid}>
          {benefits.map((benefit) => (
            <article className={styles.benefitCard} key={benefit.title}>
              <img src={benefit.icon} alt={benefit.title} loading="lazy" />
              <div>
                <h3>{benefit.title}</h3>
                <p>{benefit.text}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.personas}>
        <div className={styles.sectionHead}>
          <h2>Для кого наш дизайн?</h2>
          <p>DigitalCovers помогает разным командам и авторам уверенно развивать медиа.</p>
        </div>
        <div className={styles.personaGrid}>
          {personas.map((persona) => (
            <article key={persona.title}>
              <h3>{persona.title}</h3>
              <p>{persona.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.sectionHead}>
          <h2>Недавние проекты</h2>
          <p>Подборка визуальных решений, которые вдохновляют наших клиентов.</p>
        </div>
        <div className={styles.projectGrid}>
          {projects.map((project) => (
            <article key={project.title}>
              <div className={styles.projectImage}>
                <img src={project.image} alt={project.title} loading="lazy" />
              </div>
              <div className={styles.projectInfo}>
                <h3>{project.title}</h3>
                <p>{project.text}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHead}>
          <h2>Отзывы клиентов</h2>
          <p>Реальные истории о том, как дизайн влияет на результаты.</p>
        </div>
        <div className={styles.testimonialSlider}>
          {testimonials.map((item, index) => (
            <article
              key={item.name}
              className={`${styles.testimonialCard} ${index === activeTestimonial ? styles.testimonialActive : ''}`}
            >
              <img src={item.avatar} alt={`Фото — ${item.name}`} loading="lazy" />
              <blockquote>{item.text}</blockquote>
              <div>
                <h4>{item.name}</h4>
                <span>{item.role}</span>
              </div>
            </article>
          ))}
          <div className={styles.sliderDots} aria-label="Слайдер отзывов">
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                className={index === activeTestimonial ? styles.dotActive : styles.dot}
                aria-label={`Переключить отзыв ${index + 1}`}
                onClick={() => setActiveTestimonial(index)}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.sectionHead}>
          <h2>FAQ</h2>
          <p>Ответы на частые вопросы о заказе цифровых дизайнов.</p>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <article className={styles.faqItem} key={item.question}>
              <button
                type="button"
                aria-expanded={openFaq === index}
                onClick={() => toggleFaq(index)}
                className={styles.faqQuestion}
              >
                {item.question}
                <span>{openFaq === index ? '–' : '+'}</span>
              </button>
              {openFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
            </article>
          ))}
        </div>
      </section>

      <section className={styles.blog}>
        <div className={styles.sectionHead}>
          <h2>Digital Insights</h2>
          <p>Аналитика и советы по визуальному продвижению контента.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <img src={post.image} alt={post.title} loading="lazy" />
              <div>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <span className={styles.blogTag}>Смотреть подробнее</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaCard}>
          <h2>Начните улучшать свой визуал сегодня</h2>
          <p>Подберите готовый пакет или напишите нам, чтобы создать уникальный стиль под ваш проект.</p>
          <div className={styles.ctaActions}>
            <Link to="/catalog" className={styles.ctaPrimary} aria-label="Перейти в каталог DigitalCovers">
              Выбрать дизайн
            </Link>
            <Link to="/contact" className={styles.ctaSecondary} aria-label="Связаться с DigitalCovers">
              Связаться с нами
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;