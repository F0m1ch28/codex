import React from 'react';
import Seo from '../components/Seo';
import ProductCard from '../components/ProductCard';
import styles from './VideoCoversPage.module.css';

const products = [
  {
    title: 'Обложка «Hyper Boost»',
    description: 'Контраст, крупная типографика и четкий Call-To-Action. Создано для роликов с динамикой.',
    image: 'https://images.unsplash.com/photo-1618005198919-d3d4b5a92eee?auto=format&fit=crop&w=900&q=80',
    tags: ['YouTube', 'CTR', 'Gaming']
  },
  {
    title: 'Обложка «Storyline»',
    description: 'Кинематографический стиль и мягкая цветовая палитра для блогов и storytelling форматов.',
    image: 'https://images.unsplash.com/photo-1526498460520-4c246339dccb?auto=format&fit=crop&w=900&q=80',
    tags: ['Lifestyle', 'Premium', 'Series']
  },
  {
    title: 'Обложка «Expert View»',
    description: 'Минимализм, акцент на эксперте и инфографике — подходит для образовательных роликов.',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=900&q=80',
    tags: ['Education', 'Business', 'Minimal']
  },
  {
    title: 'Обложка «Neon Arena»',
    description: 'Захватывающий световой дизайн для киберспортивных матчей и хайлайтов.',
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80',
    tags: ['Esports', 'Dynamic', 'Highlights']
  },
  {
    title: 'Обложка «Trend Pulse»',
    description: 'Вертикальный формат для YouTube Shorts и Reels — ярко, динамично и эффектно.',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=900&q=80&sat=-100',
    tags: ['Shorts', 'Vertical', 'Viral']
  },
  {
    title: 'Обложка «Podcast Wave»',
    description: 'Идеально для подкастов и интервью. Структурированные блоки под гостей и тему выпуска.',
    image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=900&q=80',
    tags: ['Podcast', 'Interview', 'Clean']
  }
];

const VideoCoversPage = () => {
  return (
    <div className={styles.page}>
      <Seo
        title="Обложки для видео — DigitalCovers"
        description="Подборка обложек для YouTube и других платформ: увеличьте CTR и сделайте контент узнаваемым."
      />
      <header className={styles.header}>
        <h1>Обложки для видео</h1>
        <p>
          Превью, которые привлекают внимание и повышают CTR в рекомендациях. Каждый макет адаптируем под ваш стиль и формат.
        </p>
      </header>

      <section className={styles.grid}>
        {products.map((product) => (
          <ProductCard
            key={product.title}
            title={product.title}
            description={product.description}
            image={product.image}
            tags={product.tags}
            link="/contact"
          />
        ))}
      </section>

      <section className={styles.note}>
        <div>
          <h2>Готовы к кастомизации</h2>
          <p>Добавим ваш логотип, шрифты и цветовую палитру, адаптируем под сезоны и спецпроекты.</p>
        </div>
      </section>
    </div>
  );
};

export default VideoCoversPage;