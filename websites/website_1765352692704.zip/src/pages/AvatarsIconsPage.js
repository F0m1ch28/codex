import React from 'react';
import Seo from '../components/Seo';
import ProductCard from '../components/ProductCard';
import styles from './AvatarsIconsPage.module.css';

const products = [
  {
    title: 'Аватар «Neon Streamer»',
    description: 'Яркий образ с подсветкой и деталями, выделяющими ваш персонаж в ленте.',
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80',
    tags: ['Twitch', 'Glow', 'Character']
  },
  {
    title: 'Иконки «Brand Set»',
    description: 'Минималистичный набор иконок для соцсетей, дискорда и десктопных приложений.',
    image: 'https://images.unsplash.com/photo-1551292831-023188e78222?auto=format&fit=crop&w=900&q=80',
    tags: ['Discord', 'Telegram', 'Business']
  },
  {
    title: 'Аватар «Pixel Hero»',
    description: 'Геймерский стиль с пиксель-арт деталями и яркой цветовой палитрой.',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=900&q=80',
    tags: ['Gaming', 'Pixel', 'Retro']
  },
  {
    title: 'Иконки «Edu Pack»',
    description: 'Набор нейтральных иконок для образовательных каналов и подкастов.',
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80&sat=-100',
    tags: ['Education', 'Podcast', 'Clean']
  },
  {
    title: 'Аватар «Studio Line»',
    description: 'Портрет в фирменной палитре бренда с проработанной светотенью и акцентами.',
    image: 'https://images.unsplash.com/photo-1573497491208-6b1acb260507?auto=format&fit=crop&w=900&q=80',
    tags: ['Business', 'Portrait', 'Premium']
  },
  {
    title: 'Иконки «Motion Glyphs»',
    description: 'Лаконичные глифы, поддерживающие анимацию при наведении и в сторис.',
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80&h=500',
    tags: ['Motion', 'Glyph', 'Social']
  }
];

const AvatarsIconsPage = () => {
  return (
    <div className={styles.page}>
      <Seo
        title="Аватарки и иконки — DigitalCovers"
        description="Выразительные аватарки и комплект иконок для креаторов. Сделайте профиль узнаваемым."
      />
      <header className={styles.header}>
        <h1>Аватарки и иконки</h1>
        <p>Создаем узнаваемые персонажи и графические элементы, которые помогают строить личный бренд.</p>
      </header>

      <section className={styles.grid}>
        {products.map((product) => (
          <ProductCard
            key={product.title}
            title={product.title}
            description={product.description}
            image={product.image}
            tags={product.tags}
            link="/contact"
          />
        ))}
      </section>

      <section className={styles.highlight}>
        <h2>Brand-kit под ключ</h2>
        <p>Подготовим иконки для всех платформ, аватар, обложку и дополнительные вариации — одно решение для всей экосистемы.</p>
      </section>
    </div>
  );
};

export default AvatarsIconsPage;