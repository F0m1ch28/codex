import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    project: '',
    message: ''
  });
  const [status, setStatus] = useState({ success: '', error: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!form.name || !form.email || !form.message) {
      setStatus({ success: '', error: 'Пожалуйста, заполните обязательные поля.' });
      return;
    }
    setStatus({ success: 'Спасибо! Мы свяжемся с вами в течение 24 часов.', error: '' });
    setForm({ name: '', email: '', project: '', message: '' });
  };

  return (
    <div className={styles.page}>
      <Seo
        title="Контакты DigitalCovers"
        description="Свяжитесь с DigitalCovers — расскажите о проекте, получите консультацию и персональное предложение по дизайну."
      />
      <section className={styles.hero}>
        <div>
          <h1>Давайте обсудим ваш визуал</h1>
          <p>
            Хотите кастомный дизайн или расширенную поддержку? Оставьте краткую информацию о проекте — мы подберём решение и предложим понятный план действий.
          </p>
          <ul className={styles.details}>
            <li>
              <strong>Email:</strong>
              <a href="mailto:support@digitalcovers.store">support@digitalcovers.store</a>
            </li>
            <li>
              <strong>Телефон (для консультаций):</strong>
              <a href="tel:+7XXXXXXXXXX">+7 (XXX) XXX-XX-XX</a>
            </li>
            <li>
              <strong>Адрес:</strong>
              <span>123456, Россия, г. Москва, ул. Цифровая, д. 1, офис «Виртуальный»</span>
            </li>
          </ul>
        </div>
        <div className={styles.contactCard}>
          <h2>Форма обратной связи</h2>
          <form onSubmit={handleSubmit} noValidate>
            <label htmlFor="name">
              Имя*
              <input
                id="name"
                name="name"
                type="text"
                value={form.name}
                onChange={handleChange}
                placeholder="Как к вам обращаться?"
                required
              />
            </label>
            <label htmlFor="email">
              Email*
              <input
                id="email"
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                placeholder="name@example.com"
                required
              />
            </label>
            <label htmlFor="project">
              Тип проекта
              <input
                id="project"
                name="project"
                type="text"
                value={form.project}
                onChange={handleChange}
                placeholder="YouTube канал, Twitch, бренд и т.д."
              />
            </label>
            <label htmlFor="message">
              Сообщение*
              <textarea
                id="message"
                name="message"
                rows="4"
                value={form.message}
                onChange={handleChange}
                placeholder="Расскажите о задачах, ссылках и желаемых сроках."
                required
              />
            </label>
            <button type="submit" className={styles.submit} aria-label="Отправить сообщение DigitalCovers">
              Отправить
            </button>
            {status.error && <p className={styles.error}>{status.error}</p>}
            {status.success && <p className={styles.success}>{status.success}</p>}
          </form>
        </div>
      </section>

      <section className={styles.support}>
        <article>
          <h3>Работаем по всему миру</h3>
          <p>Поддерживаем RU и EN аудиторию. Ведём проекты в разных часовых поясах и учитываем локальные особенности платформ.</p>
        </article>
        <article>
          <h3>Синхронизируемся с командой</h3>
          <p>Создаём общие каналы в Slack или Discord, подключаем продюсеров и редакторов для оперативной работы.</p>
        </article>
        <article>
          <h3>Гибкая коммуникация</h3>
          <p>Zoom, Telegram или электронная почта — выбирайте удобный способ общения, мы подстроимся.</p>
        </article>
      </section>
    </div>
  );
};

export default ContactPage;