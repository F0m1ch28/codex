import React from 'react';
import Seo from '../components/Seo';
import ProductCard from '../components/ProductCard';
import styles from './BannersOverlaysPage.module.css';

const products = [
  {
    title: 'Overlay «Night Stream»',
    description: 'Глубокие цвета, световые акценты и анимированные рамки для трансляций в вечернее время.',
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80',
    tags: ['Twitch', 'Animated', 'Dark mode']
  },
  {
    title: 'Баннер «Launch Event»',
    description: 'Презентационный баннер для запуска продукта: таймлайн, CTA и визуальные маркеры.',
    image: 'https://images.unsplash.com/photo-1508921912186-1d1a45ebb3c1?auto=format&fit=crop&w=900&q=80',
    tags: ['Product', 'Promo', 'Event']
  },
  {
    title: 'Overlay «Retro Grid»',
    description: 'Сетка и градиенты в ретро-стиле для чилловых трансляций и творческих эфиров.',
    image: 'https://images.unsplash.com/photo-1462396881884-de2c07cb95ed?auto=format&fit=crop&w=900&q=80',
    tags: ['Retro', 'Creative', 'Overlay']
  },
  {
    title: 'Баннер «Creator Space»',
    description: 'Универсальный баннер для YouTube и Twitch с адаптивной композицией под мобильные устройства.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80',
    tags: ['Responsive', 'Cross-platform', 'Brand']
  },
  {
    title: 'Overlay «Infinite Pulse»',
    description: 'Пульсирующие элементы, динамичные переходы и сценические блоки для киберспорта.',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=900&q=80&sat=50',
    tags: ['Esports', 'Dynamic', 'Scene pack']
  },
  {
    title: 'Набор «Social Alerts»',
    description: 'Аллерты и панели социальных сетей в едином стиле, поддержка анимации Lottie.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80&sat=-30',
    tags: ['Alerts', 'Lottie', 'Social']
  }
];

const BannersOverlaysPage = () => {
  return (
    <div className={styles.page}>
      <Seo
        title="Баннеры и оверлеи — DigitalCovers"
        description="Профессиональные баннеры и overlays для стримов и социальных сетей. Адаптация под любой формат."
      />
      <header className={styles.header}>
        <h1>Баннеры и оверлеи</h1>
        <p>Сцены, панели, alerts и баннеры — полный комплект для вашего канала и социальных сетей.</p>
      </header>

      <section className={styles.grid}>
        {products.map((product) => (
          <ProductCard
            key={product.title}
            title={product.title}
            description={product.description}
            image={product.image}
            tags={product.tags}
            link="/contact"
          />
        ))}
      </section>

      <section className={styles.banner}>
        <div>
          <h2>Модульная структура</h2>
          <p>Выбирайте нужные сцены, комбинируйте и обновляйте оформление без лишних усилий.</p>
        </div>
      </section>
    </div>
  );
};

export default BannersOverlaysPage;