import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';

import HomePage from './pages/HomePage';
import CatalogPage from './pages/CatalogPage';
import VideoCoversPage from './pages/VideoCoversPage';
import AvatarsIconsPage from './pages/AvatarsIconsPage';
import BannersOverlaysPage from './pages/BannersOverlaysPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import TermsPage from './pages/TermsPage';
import PrivacyPage from './pages/PrivacyPage';
import CookiePolicyPage from './pages/CookiePolicyPage';

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

const Layout = ({ children }) => (
  <div className="app-shell">
    <Header />
    <main className="main-content" role="main">
      {children}
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTopButton />
  </div>
);

const App = () => {
  return (
    <>
      <ScrollToTopOnRouteChange />
      <Routes>
        <Route
          path="/"
          element={
            <Layout>
              <HomePage />
            </Layout>
          }
        />
        <Route
          path="/catalog"
          element={
            <Layout>
              <CatalogPage />
            </Layout>
          }
        />
        <Route
          path="/catalog/video-covers"
          element={
            <Layout>
              <VideoCoversPage />
            </Layout>
          }
        />
        <Route
          path="/catalog/avatars-icons"
          element={
            <Layout>
              <AvatarsIconsPage />
            </Layout>
          }
        />
        <Route
          path="/catalog/banners-overlays"
          element={
            <Layout>
              <BannersOverlaysPage />
            </Layout>
          }
        />
        <Route
          path="/about"
          element={
            <Layout>
              <AboutPage />
            </Layout>
          }
        />
        <Route
          path="/contact"
          element={
            <Layout>
              <ContactPage />
            </Layout>
          }
        />
        <Route
          path="/terms"
          element={
            <Layout>
              <TermsPage />
            </Layout>
          }
        />
        <Route
          path="/privacy"
          element={
            <Layout>
              <PrivacyPage />
            </Layout>
          }
        />
        <Route
          path="/cookie-policy"
          element={
            <Layout>
              <CookiePolicyPage />
            </Layout>
          }
        />
      </Routes>
    </>
  );
};

export default App;