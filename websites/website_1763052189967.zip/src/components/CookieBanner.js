// @ts-check
import React, { useEffect, useState } from "react";

const STORAGE_KEY = "devlayer-cookie-consent";

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem(STORAGE_KEY, "declined");
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 bg-secondary text-surface">
      <div className="mx-auto flex max-w-6xl flex-col items-start gap-4 px-4 py-5 md:flex-row md:items-center md:justify-between lg:px-6">
        <p className="text-sm leading-relaxed text-surface/80">
          DevLayer uses functional cookies and privacy-preserving analytics to
          understand engagement. You can accept or decline tracking at any time.
        </p>
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="rounded-md bg-surface px-4 py-2 text-sm font-semibold text-secondary transition hover:bg-accent hover:text-surface"
            onClick={handleAccept}
          >
            Accept
          </button>
          <button
            type="button"
            className="rounded-md border border-surface px-4 py-2 text-sm font-semibold text-surface transition hover:bg-surface/10"
            onClick={handleDecline}
          >
            Decline
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;