// @ts-check
import React from "react";
import { Link } from "react-router-dom";

function Footer() {
  return (
    <footer className="mt-16 bg-secondary/95 text-surface">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 md:grid-cols-3 lg:px-6">
        <div>
          <h3 className="font-heading text-xl font-semibold">DevLayer</h3>
          <p className="mt-3 text-sm text-surface/80">
            Canadian editorial platform for developer workflows, systems
            thinking, and platform engineering disciplines.
          </p>
        </div>
        <div>
          <h4 className="font-heading text-lg font-semibold">Reach us</h4>
          <ul className="mt-3 space-y-2 text-sm text-surface/80">
            <li>333 Bay St, Toronto, ON M5H 2R2, Canada</li>
            <li>Phone: +1 (416) 905-6621</li>
            <li>Email: <a href="mailto:editorial@devlayer.com" className="underline hover:text-surface">editorial@devlayer.com</a></li>
            <li>GitHub: <a href="https://github.com/devlayer" className="underline hover:text-surface">github.com/devlayer</a></li>
            <li>LinkedIn: <a href="https://www.linkedin.com/company/devlayer" className="underline hover:text-surface">linkedin.com/company/devlayer</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-heading text-lg font-semibold">Navigation</h4>
          <nav className="mt-3 grid grid-cols-2 gap-2 text-sm text-surface/80">
            <Link to="/" className="hover:text-surface">Home</Link>
            <Link to="/about" className="hover:text-surface">About</Link>
            <Link to="/workflows" className="hover:text-surface">Workflows</Link>
            <Link to="/mindset" className="hover:text-surface">Mindset</Link>
            <Link to="/queue" className="hover:text-surface">Reading Queue</Link>
            <Link to="/archives" className="hover:text-surface">Archives</Link>
            <Link to="/notes" className="hover:text-surface">Notes</Link>
            <Link to="/blog" className="hover:text-surface">Blog</Link>
            <Link to="/contact" className="hover:text-surface">Contact</Link>
            <Link to="/privacy" className="hover:text-surface">Privacy</Link>
            <Link to="/terms" className="hover:text-surface">Terms</Link>
          </nav>
        </div>
      </div>
      <div className="border-t border-surface/10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 py-4 text-xs text-surface/60 md:flex-row lg:px-6">
          <span>© {new Date().getFullYear()} DevLayer. All rights reserved.</span>
          <span>Toronto · Canada</span>
        </div>
      </div>
    </footer>
  );
}

export default Footer;