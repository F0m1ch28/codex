// @ts-check
import React from "react";
import { Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
import ContactThanks from "./pages/ContactThanks";
import Privacy from "./pages/Privacy";
import Terms from "./pages/Terms";
import Blog from "./pages/Blog";
import BlogContextSwitching from "./pages/BlogContextSwitching";
import BlogCloudPatterns from "./pages/BlogCloudPatterns";
import BlogDevOpsCulture from "./pages/BlogDevOpsCulture";
import Workflows from "./pages/Workflows";
import Mindset from "./pages/Mindset";
import Queue from "./pages/Queue";
import Archives from "./pages/Archives";
import Notes from "./pages/Notes";

function App() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header />
      <ScrollToTop />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/workflows" element={<Workflows />} />
          <Route path="/mindset" element={<Mindset />} />
          <Route path="/queue" element={<Queue />} />
          <Route path="/archives" element={<Archives />} />
          <Route path="/notes" element={<Notes />} />
          <Route path="/blog" element={<Blog />} />
          <Route
            path="/blog/why-context-switching-kills-productivity"
            element={<BlogContextSwitching />}
          />
          <Route
            path="/blog/cloud-patterns-for-scale"
            element={<BlogCloudPatterns />}
          />
          <Route
            path="/blog/the-evolution-of-devops-culture"
            element={<BlogDevOpsCulture />}
          />
          <Route path="/contact" element={<Contact />} />
          <Route path="/contact/thanks" element={<ContactThanks />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/terms" element={<Terms />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
}

export default App;