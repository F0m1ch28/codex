// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

function Notes() {
  const notes = [
    {
      date: "April 4, 2024",
      title: "Workflow Atlas Update",
      body:
        "Expanded the Workflow Atlas with new diagrams covering stewardship rotations and asynchronous reviews."
    },
    {
      date: "March 12, 2024",
      title: "Reader Salon Recap",
      body:
        "Hosted our first virtual reader salon featuring platform leads from Vancouver and Montréal. Transcript coming soon."
    },
    {
      date: "February 28, 2024",
      title: "Tooling Signals Study",
      body:
        "Completed interviews with five Canadian platform teams on flow telemetry practices. Findings feed into an upcoming series."
    },
    {
      date: "January 30, 2024",
      title: "Archive Digitization",
      body:
        "Digitized six additional RFCs and added annotations connecting them to modern distributed tracing stories."
    }
  ];

  return (
    <div className="mx-auto max-w-5xl px-4 py-16 lg:px-6">
      <Helmet>
        <title>Notes | DevLayer Editorial Updates</title>
        <meta
          name="description"
          content="DevLayer notes featuring short editorial updates, platform news, and internal commentary."
        />
        <link rel="canonical" href="https://devlayer.com/notes" />
      </Helmet>

      <header className="text-center">
        <h1 className="font-heading text-4xl text-primary">Editorial Notes</h1>
        <p className="mt-4 text-base text-secondary">
          Brief updates from the DevLayer studio — production notes, upcoming
          series, and behind-the-scenes reflections.
        </p>
      </header>

      <div className="mt-12 space-y-6">
        {notes.map((note) => (
          <article
            key={note.title}
            className="rounded-2xl border border-primary/10 bg-surface p-6 shadow-sm"
          >
            <span className="text-xs uppercase tracking-wide text-accent">
              {note.date}
            </span>
            <h2 className="mt-3 font-heading text-2xl text-primary">{note.title}</h2>
            <p className="mt-3 text-sm text-secondary">{note.body}</p>
          </article>
        ))}
      </div>
    </div>
  );
}

export default Notes;