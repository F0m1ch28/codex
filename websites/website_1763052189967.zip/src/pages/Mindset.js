// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

function Mindset() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16 lg:px-6">
      <Helmet>
        <title>Mindset | DevLayer Essays on Developer Psychology</title>
        <meta
          name="description"
          content="DevLayer essays about cognitive aspects of development, burnout prevention, communication practices, and focus rituals."
        />
        <link rel="canonical" href="https://devlayer.com/mindset" />
      </Helmet>

      <header className="text-center">
        <h1 className="font-heading text-4xl text-primary">Developer Mindset</h1>
        <p className="mt-4 text-base text-secondary">
          Essays on attention, burnout, communication, and the psychological
          landscape of modern software teams.
        </p>
      </header>

      <section className="mt-12 space-y-8 text-sm leading-relaxed text-secondary">
        <article className="rounded-2xl border border-primary/10 bg-surface p-8 shadow-sm">
          <h2 className="font-heading text-2xl text-primary">
            Cognitive Load and Sustainable Pace
          </h2>
          <p className="mt-3">
            We map the signals of cognitive overload and how teams redesign
            processes to distribute load. Weekly retrospectives, documented
            expectations, and clarity around on-call boundaries are essential.
          </p>
        </article>

        <article className="rounded-2xl border border-primary/10 bg-surface p-8 shadow-sm">
          <h2 className="font-heading text-2xl text-primary">
            Burnout Prevention as Organizational Practice
          </h2>
          <p className="mt-3">
            Burnout is addressed not by slogans but by structural support:
            intentional rest policies, equitable distribution of toil, and
            decision-making transparency. We highlight teams that measure
            wellbeing alongside delivery metrics.
          </p>
        </article>

        <article className="rounded-2xl border border-primary/10 bg-surface p-8 shadow-sm">
          <h2 className="font-heading text-2xl text-primary">
            Communication Frameworks
          </h2>
          <p className="mt-3">
            DevLayer chronicles narrative frameworks that help teams share
            context—architectural decision records, asynchronous updates,
            storytelling workshops. Great communication is an engineering skill.
          </p>
        </article>

        <article className="rounded-2xl border border-primary/10 bg-surface p-8 shadow-sm">
          <h2 className="font-heading text-2xl text-primary">Focus Rituals</h2>
          <p className="mt-3">
            Focus emerges from rituals such as pairing windows, study groups,
            intentionally quiet hours, and reflective journaling. We interview
            practitioners who design their days with purpose.
          </p>
        </article>
      </section>
    </div>
  );
}

export default Mindset;