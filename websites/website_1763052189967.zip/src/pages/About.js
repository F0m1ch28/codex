// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

function About() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 lg:px-6">
      <Helmet>
        <title>About DevLayer | Mission, Values, Editorial Process</title>
        <meta
          name="description"
          content="Discover DevLayer's mission, editorial values, contributors, methodology, ethics, and the story behind our Canadian platform for developers."
        />
        <link rel="canonical" href="https://devlayer.com/about" />
      </Helmet>

      <header className="mx-auto max-w-3xl text-center">
        <h1 className="font-heading text-4xl text-primary">
          About DevLayer
        </h1>
        <p className="mt-4 text-base text-secondary">
          DevLayer is an independent Canadian editorial platform exploring how
          developers build, document, and maintain complex systems. We map the
          stories behind delivery rituals, cognitive practices, and platform
          architectures.
        </p>
      </header>

      <section className="mt-12 grid gap-8 md:grid-cols-2">
        <div className="rounded-2xl border border-primary/10 bg-surface p-6 shadow-sm">
          <h2 className="font-heading text-2xl text-primary">Mission</h2>
          <p className="mt-3 text-sm leading-relaxed text-secondary">
            We illuminate the intricate layers of software practice so that
            engineers, architects, and technical managers can make informed,
            human-centered decisions. DevLayer exists to record the nuance
            behind delivery excellence and platform stewardship.
          </p>
        </div>
        <div className="rounded-2xl border border-primary/10 bg-surface p-6 shadow-sm">
          <h2 className="font-heading text-2xl text-primary">Editorial Values</h2>
          <ul className="mt-3 space-y-3 text-sm text-secondary">
            <li>• Systems literacy over hype cycles.</li>
            <li>• Evidence-based storytelling grounded in practitioner voices.</li>
            <li>• Accessibility—clarity without dilution.</li>
            <li>• Accountability to our readers and contributors.</li>
          </ul>
        </div>
      </section>

      <section className="mt-12 rounded-2xl border border-primary/10 bg-surface p-8 shadow-sm">
        <h2 className="font-heading text-2xl text-primary">Contributors</h2>
        <p className="mt-3 text-sm text-secondary">
          DevLayer collaborates with engineers, designers, sociotechnical
          researchers, and technical communicators. Every contributor undergoes
          a narrative workshop to align on tone, clarity, and responsible
          storytelling. We maintain an internal style guide that blends academic
          rigour with approachable prose.
        </p>
      </section>

      <section className="mt-12 grid gap-8 md:grid-cols-2">
        <div className="rounded-2xl border border-primary/10 bg-surface p-6">
          <h2 className="font-heading text-2xl text-primary">Methodology</h2>
          <ol className="mt-4 space-y-3 text-sm text-secondary">
            <li>1. Topic discovery through community interviews and archival research.</li>
            <li>2. Drafting with annotated references and context-specific interviews.</li>
            <li>3. Peer review by subject matter experts and editorial staff.</li>
            <li>4. Publication with transparent revision history and errata tracking.</li>
          </ol>
        </div>
        <div className="rounded-2xl border border-primary/10 bg-surface p-6">
          <h2 className="font-heading text-2xl text-primary">Ethics</h2>
          <p className="mt-3 text-sm text-secondary">
            We anonymize sensitive operational details, respect confidentiality
            agreements, and avoid content that could compromise teams or
            individuals. Quotations are verified with contributors and context
            is preserved to prevent misinterpretation.
          </p>
        </div>
      </section>

      <section className="mt-12 rounded-2xl border border-primary/10 bg-surface p-8 shadow-sm">
        <h2 className="font-heading text-2xl text-primary">Platform History</h2>
        <p className="mt-3 text-sm text-secondary leading-relaxed">
          DevLayer was founded in Toronto in 2019 by a collective of engineers
          and technical writers who saw a gap between conference talks and the
          lived realities of platform teams. What began as a quarterly zine
          evolved into a digital publication with archival ambitions. Our
          archives preserve historical documents, RFCs, and oral histories that
          inform the practice of modern distributed systems.
        </p>
      </section>
    </div>
  );
}

export default About;