// @ts-check
import React, { useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";

const categories = ["All", "Workflow", "Systems", "Tooling", "Culture"];

function Blog() {
  const posts = useMemo(
    () => [
      {
        title: "Why Context Switching Kills Productivity",
        summary:
          "Explores the cognitive tax of multi-threaded work and the practices that reduce churn across engineering teams.",
        path: "/blog/why-context-switching-kills-productivity",
        date: "March 5, 2024",
        category: "Workflow"
      },
      {
        title: "Cloud Patterns for Scale",
        summary:
          "A deep dive into cloud-native orchestration, design principles, and trade-offs behind elastic infrastructure.",
        path: "/blog/cloud-patterns-for-scale",
        date: "February 16, 2024",
        category: "Systems"
      },
      {
        title: "The Evolution of DevOps Culture",
        summary:
          "Tracing the socio-technical shifts that shaped DevOps, incident response, and platform stewardship.",
        path: "/blog/the-evolution-of-devops-culture",
        date: "January 20, 2024",
        category: "Culture"
      }
    ],
    []
  );

  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredPosts =
    selectedCategory === "All"
      ? posts
      : posts.filter((post) => post.category === selectedCategory);

  return (
    <div className="mx-auto max-w-6xl px-4 py-16 lg:px-6">
      <Helmet>
        <title>DevLayer Blog | Essays on Developer Workflows and Systems</title>
        <meta
          name="description"
          content="Browse the DevLayer archive of essays covering workflows, systems, tooling signals, and engineering culture."
        />
        <link rel="canonical" href="https://devlayer.com/blog" />
      </Helmet>

      <header className="mx-auto max-w-3xl text-center">
        <h1 className="font-heading text-4xl text-primary">DevLayer Essays</h1>
        <p className="mt-4 text-base text-secondary">
          Editorial analyses and essays capturing the pulse of engineering
          practice and platform evolution.
        </p>
      </header>

      <div className="mt-10 flex flex-wrap justify-center gap-3">
        {categories.map((category) => (
          <button
            key={category}
            type="button"
            onClick={() => setSelectedCategory(category)}
            className={[
              "rounded-full border px-4 py-2 text-sm font-semibold transition",
              selectedCategory === category
                ? "border-accent bg-accent text-surface"
                : "border-primary/20 text-secondary hover:border-accent hover:text-accent"
            ].join(" ")}
          >
            {category}
          </button>
        ))}
      </div>

      <div className="mt-12 grid gap-8 md:grid-cols-2">
        {filteredPosts.map((post) => (
          <article
            key={post.path}
            className="rounded-2xl border border-primary/10 bg-surface p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
          >
            <span className="text-xs uppercase tracking-wide text-accent">
              {post.category}
            </span>
            <h2 className="mt-3 font-heading text-2xl text-primary">{post.title}</h2>
            <p className="mt-3 text-sm leading-relaxed text-secondary">
              {post.summary}
            </p>
            <div className="mt-6 flex items-center justify-between text-xs text-secondary/70">
              <span>{post.date}</span>
              <Link
                to={post.path}
                className="font-semibold text-accent hover:text-primary"
              >
                Continue reading →
              </Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

export default Blog;