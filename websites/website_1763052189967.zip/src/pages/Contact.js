// @ts-check
import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import { useNavigate } from "react-router-dom";

function Contact() {
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      navigate("/contact/thanks");
    }, 800);
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-16 lg:px-6">
      <Helmet>
        <title>Contact DevLayer | Connect with Our Editorial Team</title>
        <meta
          name="description"
          content="Contact DevLayer for editorial collaborations, partnership inquiries, or questions about our developer platform coverage."
        />
        <link rel="canonical" href="https://devlayer.com/contact" />
      </Helmet>

      <div className="mx-auto max-w-3xl text-center">
        <h1 className="font-heading text-4xl text-primary">Contact DevLayer</h1>
        <p className="mt-4 text-base text-secondary">
          Reach our editorial team for story pitches, partnership opportunities,
          or reflections on the evolving practice of software engineering.
        </p>
      </div>

      <div className="mt-12 grid gap-10 lg:grid-cols-[2fr_1fr]">
        <form
          onSubmit={handleSubmit}
          className="rounded-3xl border border-primary/10 bg-surface p-8 shadow-md"
        >
          <div className="grid gap-6 md:grid-cols-2">
            <div className="flex flex-col">
              <label className="text-sm font-semibold text-primary">Full name</label>
              <input
                type="text"
                name="name"
                required
                autoComplete="name"
                placeholder="Your name"
                className="mt-2 rounded-lg border border-primary/20 px-4 py-3 text-sm text-secondary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent"
              />
            </div>
            <div className="flex flex-col">
              <label className="text-sm font-semibold text-primary">Email</label>
              <input
                type="email"
                name="email"
                required
                autoComplete="email"
                placeholder="you@company.com"
                className="mt-2 rounded-lg border border-primary/20 px-4 py-3 text-sm text-secondary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent"
              />
            </div>
            <div className="flex flex-col">
              <label className="text-sm font-semibold text-primary">
                Organization
              </label>
              <input
                type="text"
                name="organization"
                autoComplete="organization"
                placeholder="Team or affiliation"
                className="mt-2 rounded-lg border border-primary/20 px-4 py-3 text-sm text-secondary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent"
              />
            </div>
            <div className="flex flex-col">
              <label className="text-sm font-semibold text-primary">
                Topic
              </label>
              <select
                name="topic"
                className="mt-2 rounded-lg border border-primary/20 px-4 py-3 text-sm text-secondary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent"
                defaultValue="editorial"
              >
                <option value="editorial">Editorial collaboration</option>
                <option value="partnership">Partnership inquiry</option>
                <option value="feedback">Reader feedback</option>
                <option value="other">Other question</option>
              </select>
            </div>
          </div>
          <div className="mt-6 flex flex-col">
            <label className="text-sm font-semibold text-primary">Message</label>
            <textarea
              name="message"
              required
              rows={6}
              placeholder="Share context, desired outcomes, and timelines."
              className="mt-2 rounded-lg border border-primary/20 px-4 py-3 text-sm text-secondary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent"
            ></textarea>
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="mt-8 inline-flex items-center justify-center rounded-full bg-primary px-6 py-3 text-sm font-semibold text-surface transition hover:bg-accent disabled:cursor-not-allowed disabled:bg-primary/60"
          >
            {submitting ? "Sending…" : "Submit message"}
          </button>
        </form>

        <aside className="space-y-6">
          <div className="rounded-2xl border border-primary/10 bg-primary/10 p-6">
            <h2 className="font-heading text-lg text-primary">Direct contact</h2>
            <p className="mt-3 text-sm text-secondary">
              Email:{" "}
              <a
                href="mailto:editorial@devlayer.com"
                className="text-accent hover:text-primary"
              >
                editorial@devlayer.com
              </a>
            </p>
            <p className="text-sm text-secondary">Phone: +1 (416) 905-6621</p>
            <p className="mt-3 text-sm text-secondary">
              GitHub:{" "}
              <a
                href="https://github.com/devlayer"
                className="text-accent hover:text-primary"
              >
                github.com/devlayer
              </a>
            </p>
            <p className="text-sm text-secondary">
              LinkedIn:{" "}
              <a
                href="https://www.linkedin.com/company/devlayer"
                className="text-accent hover:text-primary"
              >
                linkedin.com/company/devlayer
              </a>
            </p>
          </div>
          <div className="rounded-2xl border border-primary/10 bg-surface p-6">
            <h2 className="font-heading text-lg text-primary">Studio</h2>
            <p className="text-sm text-secondary">
              333 Bay St
              <br />
              Toronto, ON M5H 2R2
              <br />
              Canada
            </p>
            <div className="mt-4 overflow-hidden rounded-xl">
              <iframe
                title="DevLayer Toronto"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2886.457941173084!2d-79.38165592352947!3d43.64913567110063!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d7192f1d8f%3A0xdd7183762c508d57!2s333%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202R2!5e0!3m2!1sen!2sca!4v1700000000000!5m2!1sen!2sca"
                width="100%"
                height="250"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

export default Contact;