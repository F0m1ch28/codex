// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

function Terms() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16 lg:px-6">
      <Helmet>
        <title>Terms of Use | DevLayer</title>
        <meta
          name="description"
          content="DevLayer terms of use detailing acceptable usage, intellectual property, disclaimers, jurisdiction, and external link policy."
        />
        <link rel="canonical" href="https://devlayer.com/terms" />
      </Helmet>

      <h1 className="font-heading text-4xl text-primary">Terms of Use</h1>
      <p className="mt-4 text-sm text-secondary">Last updated: January 1, 2024</p>

      <section className="mt-8 space-y-6 text-sm leading-relaxed text-secondary">
        <p>
          By accessing devlayer.com you agree to these terms. If you disagree
          with any part of the terms, please discontinue use of the site.
        </p>

        <h2 className="font-heading text-2xl text-primary">Acceptable Use</h2>
        <p>
          You may read, share, and link to our content for informational
          purposes. Republishing full articles requires written permission from
          DevLayer. Automated scraping that degrades service quality is
          prohibited.
        </p>

        <h2 className="font-heading text-2xl text-primary">Intellectual Property</h2>
        <p>
          All essays, analyses, graphics, and trademarks on DevLayer are owned
          by DevLayer or our contributors. Attribution is required when citing
          excerpts. Unauthorized commercial distribution is not permitted.
        </p>

        <h2 className="font-heading text-2xl text-primary">Disclaimer</h2>
        <p>
          Content on DevLayer is provided for educational purposes only. We
          make no warranties regarding accuracy or completeness. Implementation
          of described practices is at your discretion.
        </p>

        <h2 className="font-heading text-2xl text-primary">Jurisdiction</h2>
        <p>
          These terms are governed by the laws of the Province of Ontario and
          the laws of Canada applicable therein. Any disputes shall be resolved
          in the courts located in Toronto, Ontario.
        </p>

        <h2 className="font-heading text-2xl text-primary">External Links</h2>
        <p>
          DevLayer may reference external sites for context or archival
          purposes. We are not responsible for the content or privacy practices
          of external resources.
        </p>

        <h2 className="font-heading text-2xl text-primary">Updates</h2>
        <p>
          We may revise these terms periodically. Continued use of the site
          after updates constitutes acceptance of the revised terms.
        </p>
      </section>
    </div>
  );
}

export default Terms;