// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

function Workflows() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 lg:px-6">
      <Helmet>
        <title>Workflows | DevLayer</title>
        <meta
          name="description"
          content="DevLayer workflow insights covering CI/CD orchestration, build pipelines, IDE ergonomics, and team rituals."
        />
        <link rel="canonical" href="https://devlayer.com/workflows" />
      </Helmet>

      <header className="mx-auto max-w-3xl text-center">
        <h1 className="font-heading text-4xl text-primary">Workflow Patterns</h1>
        <p className="mt-4 text-base text-secondary">
          Analyses and field notes on the discipline of shipping software with
          clarity, from CI/CD to everyday team cadence.
        </p>
      </header>

      <section className="mt-12 grid gap-8 md:grid-cols-2">
        <div className="rounded-2xl border border-primary/10 bg-surface p-8 shadow-sm">
          <h2 className="font-heading text-2xl text-primary">CI/CD Architectures</h2>
          <p className="mt-3 text-sm text-secondary">
            We study layered pipelines that balance velocity with assurance.
            Expect breakdowns of trunk-based workflows, progressive delivery,
            and canary orchestration within regulated environments.
          </p>
        </div>
        <div className="rounded-2xl border border-primary/10 bg-surface p-8 shadow-sm">
          <h2 className="font-heading text-2xl text-primary">Build Pipelines</h2>
          <p className="mt-3 text-sm text-secondary">
            From reproducible builds to dependency governance, our essays audit
            the tooling choices and diagrams that make build pipelines legible
            to both developers and operations partners.
          </p>
        </div>
        <div className="rounded-2xl border border-primary/10 bg-surface p-8 shadow-sm">
          <h2 className="font-heading text-2xl text-primary">IDE Ergonomics</h2>
          <p className="mt-3 text-sm text-secondary">
            We explore the ergonomics of the developer workstation—shared
            tooling templates, pairing setups, and instrumentation that supports
            composability.
          </p>
        </div>
        <div className="rounded-2xl border border-primary/10 bg-surface p-8 shadow-sm">
          <h2 className="font-heading text-2xl text-primary">Team Rituals</h2>
          <p className="mt-3 text-sm text-secondary">
            The human layer of workflows: standups, asynchronous status
            handoffs, demo days, and incident reviews that empower continuous
            learning.
          </p>
        </div>
      </section>
    </div>
  );
}

export default Workflows;