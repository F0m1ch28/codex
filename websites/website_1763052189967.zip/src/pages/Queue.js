// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

function Queue() {
  const queueItems = [
    {
      title: "Operating with Intentional Debt",
      author: "Latoya Mitchell",
      tags: ["Strategy", "Architecture"],
      summary:
        "A look at how platform teams consciously manage technical debt with staged payback cycles."
    },
    {
      title: "Design Systems for Reliability",
      author: "Joel Carver",
      tags: ["Design", "Reliability"],
      summary:
        "Blends product design, incident response, and resilience engineering into a shared vocabulary."
    },
    {
      title: "Incident Stewardship",
      author: "Eun-Young Cho",
      tags: ["Operations", "Culture"],
      summary:
        "Discusses stewardship roles, emotional labour, and supportive incident review rituals."
    },
    {
      title: "The Quiet Power of Pairing",
      author: "Hassan Rahim",
      tags: ["Collaboration", "Mindset"],
      summary:
        "Explores pairing modalities, remote facilitation, and knowledge diffusion across teams."
    },
    {
      title: "Governance as Code",
      author: "Sophie N'goma",
      tags: ["Platform Engineering", "Policy"],
      summary:
        "How organizations codify policies while preserving autonomy for product teams."
    },
    {
      title: "Narrating Availability",
      author: "Marc Tremblay",
      tags: ["Observability", "Storytelling"],
      summary:
        "Connects service level objectives to storytelling that resonates with stakeholders."
    }
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-16 lg:px-6">
      <Helmet>
        <title>Reading Queue | DevLayer</title>
        <meta
          name="description"
          content="DevLayer's curated reading queue with annotations and tags for deeper exploration of developer workflows and systems."
        />
        <link rel="canonical" href="https://devlayer.com/queue" />
      </Helmet>

      <header className="mx-auto max-w-3xl text-center">
        <h1 className="font-heading text-4xl text-primary">
          Curated Reading Queue
        </h1>
        <p className="mt-4 text-base text-secondary">
          Explorations that inform our editorial direction. Each selection is
          annotated with tags to guide your reading journey.
        </p>
      </header>

      <div className="mt-12 grid gap-8 md:grid-cols-2">
        {queueItems.map((item) => (
          <article
            key={item.title}
            className="rounded-2xl border border-primary/10 bg-surface p-6 shadow-sm"
          >
            <div className="flex items-center justify-between text-xs uppercase tracking-wide text-accent">
              <span>{item.author}</span>
              <div className="flex gap-2">
                {item.tags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full bg-accent/10 px-2 py-1 text-accent"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
            <h2 className="mt-4 font-heading text-2xl text-primary">
              {item.title}
            </h2>
            <p className="mt-3 text-sm text-secondary">{item.summary}</p>
          </article>
        ))}
      </div>
    </div>
  );
}

export default Queue;