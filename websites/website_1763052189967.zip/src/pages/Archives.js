// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

function Archives() {
  const artifacts = [
    {
      title: "RFC 1958: Architectural Principles of the Internet",
      type: "RFC",
      year: "1996",
      description:
        "Guiding document outlining enduring principles for distributed networking."
    },
    {
      title: "Unix Programming Environment Manual (1984)",
      type: "Documentation",
      year: "1984",
      description:
        "A seminal text capturing the philosophy behind Unix tooling and pipelines."
    },
    {
      title: "Google SRE Workbook (2016)",
      type: "Handbook",
      year: "2016",
      description:
        "Operational playbook illustrating the evolution of reliability engineering practices."
    },
    {
      title: "Agile Manifesto",
      type: "Manifesto",
      year: "2001",
      description:
        "Sets the tone for iterative delivery and collaborative values in software development."
    },
    {
      title: "Open Container Initiative Specifications",
      type: "Open Standard",
      year: "2015",
      description:
        "Defines container formats and runtimes, enabling interoperability in cloud ecosystems."
    },
    {
      title: "IBM System/360 Principles of Operation",
      type: "Technical Manual",
      year: "1964",
      description:
        "Historic documentation that influenced modern compute architectures."
    }
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-16 lg:px-6">
      <Helmet>
        <title>Archives | DevLayer Historic References</title>
        <meta
          name="description"
          content="DevLayer archives with historic computer science references, RFCs, legacy documentation, and open standards for contextual learning."
        />
        <link rel="canonical" href="https://devlayer.com/archives" />
      </Helmet>

      <header className="mx-auto max-w-3xl text-center">
        <h1 className="font-heading text-4xl text-primary">Archives</h1>
        <p className="mt-4 text-base text-secondary">
          Historic references that contextualize contemporary practice. Each
          artifact reminds us that today’s challenges are part of a longer
          narrative.
        </p>
      </header>

      <div className="mt-12 grid gap-8 md:grid-cols-2">
        {artifacts.map((item) => (
          <div
            key={item.title}
            className="rounded-2xl border border-primary/10 bg-surface p-6 shadow-sm"
          >
            <div className="flex items-center justify-between text-xs uppercase tracking-wide text-accent">
              <span>{item.type}</span>
              <span>{item.year}</span>
            </div>
            <h2 className="mt-4 font-heading text-2xl text-primary">{item.title}</h2>
            <p className="mt-3 text-sm text-secondary">{item.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Archives;