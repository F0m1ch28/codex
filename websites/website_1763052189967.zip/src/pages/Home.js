// @ts-check
import React, { useMemo, useRef } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { motion, useInView } from "framer-motion";

const sectionWrapperClasses =
  "mx-auto max-w-6xl px-4 py-16 lg:px-6";

const fadeInConfig = {
  initial: { opacity: 0, y: 32 },
  whileInView: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: "easeOut" },
  viewport: { once: true, amount: 0.2 }
};

const HomeSection = ({ id, kicker, title, description, children }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <motion.section
      id={id}
      ref={ref}
      initial={{ opacity: 0, y: 32 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 32 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={sectionWrapperClasses}
    >
      <div className="mx-auto max-w-4xl text-center">
        {kicker && (
          <span className="text-sm uppercase tracking-[0.3em] text-accent">
            {kicker}
          </span>
        )}
        <h2 className="mt-3 font-heading text-3xl font-semibold text-primary md:text-4xl">
          {title}
        </h2>
        {description && (
          <p className="mt-4 text-base leading-relaxed text-secondary">
            {description}
          </p>
        )}
      </div>
      <div className="mt-12">{children}</div>
    </motion.section>
  );
};

function Home() {
  const featuredEssays = useMemo(
    () => [
      {
        title: "Why Context Switching Kills Productivity",
        excerpt:
          "Dissecting cognitive overhead and the signals that appear in engineering organizations when asynchronous work collides with reactive support.",
        link: "/blog/why-context-switching-kills-productivity",
        readingTime: "12 min read",
        image:
          "https://images.unsplash.com/photo-1522252234503-e356532cafd5?auto=format&fit=crop&w=900&q=80",
        tags: ["Developer Mindset", "Focus"]
      },
      {
        title: "Cloud Patterns for Scale",
        excerpt:
          "Exploring composable infrastructure, layered orchestration, and the tradeoffs that surface when teams chase elasticity with observability gaps.",
        link: "/blog/cloud-patterns-for-scale",
        readingTime: "15 min read",
        image:
          "https://images.unsplash.com/photo-1517677129300-07b130802f46?auto=format&fit=crop&w=900&q=80",
        tags: ["Systems", "Cloud"]
      },
      {
        title: "The Evolution of DevOps Culture",
        excerpt:
          "A longitudinal view of collaborative rituals, socio-technical feedback loops, and the stories teams tell when delivery becomes a shared craft.",
        link: "/blog/the-evolution-of-devops-culture",
        readingTime: "18 min read",
        image:
          "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=900&q=80",
        tags: ["Culture", "Team Dynamics"]
      }
    ],
    []
  );

  const explorationThemes = useMemo(
    () => [
      {
        title: "Systems",
        description:
          "Composability, platform architectures, and the narratives that make distributed services understandable."
      },
      {
        title: "Workflows",
        description:
          "Cadence, feedback loops, and the choreography that keeps cross-functional teams aligned."
      },
      {
        title: "Cognition",
        description:
          "Attention, decision-making, and the invisible ergonomics that influence engineering judgement."
      }
    ],
    []
  );

  const workflowPatterns = useMemo(
    () => [
      {
        name: "Progressive Delivery Paths",
        summary:
          "Segmented release channels, layered validation suites, and observability handoffs between platform and product squads.",
        signal: "Look for shared dashboards, chaos game-days, and visual handbooks."
      },
      {
        name: "Human-in-the-Loop Automation",
        summary:
          "Orchestrations that blend guardrails with deliberate pause points to reinforce shared accountability.",
        signal: "Narrated runbooks, steward rotations, and annotated pipelines."
      },
      {
        name: "Async Coordination Mesh",
        summary:
          "Document-first collaboration with ritualized touchpoints that sync architecture, product, and operations context.",
        signal: "Living architecture memos and intentional inbox design."
      }
    ],
    []
  );

  const developerMindset = useMemo(
    () => [
      {
        title: "Cognitive Load Mapping",
        content:
          "How teams identify the mental overhead of their platforms, make it visible, and budget curious time for refactoring."
      },
      {
        title: "Sustainable Focus",
        content:
          "Rhythms that sustain deep work without isolating engineers. Crafted schedules, mediated interruptions, and ambient awareness."
      },
      {
        title: "Communication as Craft",
        content:
          "Narrative memos, ADR practice, and the editorial habits that give technical decisions a reliable history."
      }
    ],
    []
  );

  const toolingSignals = useMemo(
    () => [
      {
        tool: "Flow Telemetry",
        description:
          "Tracing commit-to-deploy journeys with empathetic metrics that highlight learning rather than velocity."
      },
      {
        tool: "Architecture Atlases",
        description:
          "Curated repositories that blend diagrams, decision logs, and stories about system constraints."
      },
      {
        tool: "Ergonomic IDE Environments",
        description:
          "Shared starter kits, annotated code lenses, and plugin curation that signal collective ownership."
      }
    ],
    []
  );

  const codeHistoryEntries = useMemo(
    () => [
      {
        era: "1990s",
        focus:
          "RFC-driven co-creation and the early collaborations that still shape modern distributed computing.",
        artifact: "RFC 1122, the canonical host requirements narrative."
      },
      {
        era: "2000s",
        focus:
          "Rise of continuous integration disciplines, narrated build pipelines, and test-first advocacy.",
        artifact: "Thoughtworks Radar entries on automation craftsmanship."
      },
      {
        era: "2010s",
        focus:
          "Platform teams, observability shifts, and the blending of product and operations storytelling.",
        artifact: "SRE handbooks and incident analysis micro-essays."
      },
      {
        era: "2020s",
        focus:
          "Composable platforms, governance as code, and the pursuit of clarity amid ambient service meshes.",
        artifact: "Open-source platform engineering charters with living diagrams."
      }
    ],
    []
  );

  const editorialHighlights = useMemo(
    () => [
      {
        title: "Field Notes: Incident Narratives",
        description:
          "Qualitative analysis of how leading teams turn incident reviews into shared learning rituals."
      },
      {
        title: "Platform Engineering Atlas",
        description:
          "Long-form essays mapping infrastructure layers, golden paths, and the stories teams tell about platform ergonomics."
      },
      {
        title: "Sustained Delivery Series",
        description:
          "A dialogue with technical leaders on long-term cadence, strategic prioritization, and mindful iteration."
      }
    ],
    []
  );

  const readingQueue = useMemo(
    () => [
      {
        title: "Maintaining Narrative Debt",
        author: "Priya Desai",
        tags: ["Culture", "Narrative"],
        annotation:
          "How documentation debt mirrors architectural debt and the rituals that retire both."
      },
      {
        title: "Latency as Dialogue",
        author: "Andre Lefebvre",
        tags: ["Systems", "Performance"],
        annotation:
          "Examines latency budgets as cross-team agreements rather than numeric targets."
      },
      {
        title: "Design Docs as Invitations",
        author: "Mira Conway",
        tags: ["Communication", "Collaboration"],
        annotation:
          "Empowers engineers to write design docs that become conversation starters instead of sign-off artifacts."
      },
      {
        title: "Resilience Through Rituals",
        author: "Hyejin Park",
        tags: ["Mindset", "Wellbeing"],
        annotation:
          "Connects team rituals, psychological safety signals, and sustainable delivery cadence."
      }
    ],
    []
  );

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "DevLayer",
    url: "https://devlayer.com/",
    description:
      "DevLayer publishes essays on developer workflows, software systems, tooling signals, and engineering culture.",
    inLanguage: "en-CA",
    publisher: {
      "@type": "Organization",
      name: "DevLayer",
      url: "https://devlayer.com"
    }
  };

  const handleSmoothScroll = (id) => {
    const section = document.getElementById(id);
    if (section) {
      section.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <>
      <Helmet>
        <title>DevLayer | Every Layer Tells a Story</title>
        <meta
          name="description"
          content="DevLayer is a Canadian editorial platform exploring developer workflows, software systems, and engineering culture through essays and analysis."
        />
        <meta
          name="keywords"
          content="developer workflows, software systems, cloud infrastructure, platform engineering, devops culture, technical writing, distributed computing, engineering psychology"
        />
        <link rel="canonical" href="https://devlayer.com/" />
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>
      </Helmet>

      <motion.section
        id="hero"
        className="relative overflow-hidden bg-surface"
        {...fadeInConfig}
      >
        <div className={`${sectionWrapperClasses} flex flex-col-reverse gap-10 lg:flex-row lg:items-center`}>
          <div className="lg:w-1/2">
            <span className="text-xs uppercase tracking-[0.3em] text-accent">
              Editorial Platform · Canada
            </span>
            <h1 className="mt-4 font-heading text-4xl font-semibold text-primary sm:text-5xl lg:text-6xl">
              Every Layer Tells a Story
            </h1>
            <p className="mt-6 text-base leading-relaxed text-secondary sm:text-lg">
              DevLayer documents the evolving craft of software engineering.
              We curate essays, workflow studies, and lived experiences from
              developers, platform engineers, and technical leaders who shape
              modern systems.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/blog"
                className="inline-flex items-center rounded-full bg-primary px-6 py-3 text-sm font-semibold text-surface transition hover:bg-accent"
              >
                Read the latest essays
              </Link>
              <button
                type="button"
                onClick={() => handleSmoothScroll("featured-essays")}
                className="inline-flex items-center rounded-full border border-primary/40 px-6 py-3 text-sm font-semibold text-primary transition hover:border-accent hover:text-accent"
              >
                Browse highlights
              </button>
            </div>
            <div className="mt-10 flex items-center gap-4 text-sm text-secondary">
              <span className="flex items-center gap-2">
                <span className="inline-block h-2 w-2 rounded-full bg-accent"></span>
                Multi-disciplinary perspectives
              </span>
              <span className="flex items-center gap-2">
                <span className="inline-block h-2 w-2 rounded-full bg-accent"></span>
                Systems, workflows, mindset
              </span>
            </div>
          </div>
          <div className="lg:w-1/2">
            <div className="relative rounded-3xl bg-primary/10 p-3 shadow-subtle">
              <img
                src="https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1200&q=80"
                alt="Developers collaborating with layered diagrams"
                loading="lazy"
                className="h-full w-full rounded-2xl object-cover"
              />
              <div className="absolute inset-0 rounded-2xl border border-primary/20"></div>
            </div>
          </div>
        </div>
      </motion.section>

      <HomeSection
        id="featured-essays"
        kicker="Featured Essays"
        title="Essays that anchor current discourse"
        description="Select pieces from our editorial archive that illuminate systems thinking, developer cognition, and collaborative craft."
      >
        <div className="grid gap-8 md:grid-cols-3">
          {featuredEssays.map((essay) => (
            <article
              key={essay.title}
              className="flex h-full flex-col overflow-hidden rounded-2xl bg-surface shadow-md transition hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="relative h-48">
                <img
                  src={essay.image}
                  alt={essay.title}
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="flex flex-1 flex-col p-6">
                <div className="flex flex-wrap gap-2 text-xs uppercase tracking-wide text-accent">
                  {essay.tags.map((tag) => (
                    <span key={tag} className="rounded-full bg-accent/10 px-2 py-1">
                      {tag}
                    </span>
                  ))}
                </div>
                <h3 className="mt-4 font-heading text-xl text-primary">
                  {essay.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-secondary">
                  {essay.excerpt}
                </p>
                <div className="mt-auto flex items-center justify-between pt-5 text-xs text-secondary/70">
                  <span>{essay.readingTime}</span>
                  <Link
                    to={essay.link}
                    className="font-semibold text-accent hover:text-primary"
                  >
                    Read essay →
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>
      </HomeSection>

      <HomeSection
        id="what-we-explore"
        kicker="What We Explore"
        title="Systems, workflows, cognitive dimensions"
        description="Our editorial focus spans the interconnected layers that define modern engineering practice."
      >
        <div className="grid gap-6 md:grid-cols-3">
          {explorationThemes.map((theme) => (
            <div
              key={theme.title}
              className="rounded-2xl border border-primary/10 bg-surface p-6 shadow-sm"
            >
              <h3 className="font-heading text-2xl text-primary">{theme.title}</h3>
              <p className="mt-4 text-sm leading-relaxed text-secondary">
                {theme.description}
              </p>
            </div>
          ))}
        </div>
      </HomeSection>

      <HomeSection
        id="workflow-patterns"
        kicker="Workflow Patterns"
        title="Signals from high-trust delivery environments"
        description="Field research on how teams choreograph releases, feedback loops, and automation with human clarity."
      >
        <div className="space-y-6">
          {workflowPatterns.map((pattern) => (
            <div
              key={pattern.name}
              className="rounded-2xl border border-primary/10 bg-surface p-6 shadow-sm hover:border-accent/40"
            >
              <div className="flex items-start justify-between gap-4">
                <h3 className="font-heading text-xl text-primary">{pattern.name}</h3>
                <span className="rounded-full bg-primary/10 px-4 py-1 text-xs font-semibold text-primary">
                  Field Study
                </span>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-secondary">
                {pattern.summary}
              </p>
              <div className="mt-5 rounded-xl bg-primary/5 p-4 text-sm text-secondary">
                <span className="font-semibold text-primary">Signal: </span>
                {pattern.signal}
              </div>
            </div>
          ))}
        </div>
      </HomeSection>

      <HomeSection
        id="developer-mindset"
        kicker="Developer Mindset"
        title="Narratives about cognition, focus, and communication"
        description="We surface stories from practitioners who navigate complexity while preserving clarity and collaborative intent."
      >
        <div className="grid gap-6 md:grid-cols-3">
          {developerMindset.map((item) => (
            <div
              key={item.title}
              className="rounded-2xl bg-primary/5 p-6 shadow-inner"
            >
              <h3 className="font-heading text-lg text-primary">{item.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-secondary">
                {item.content}
              </p>
            </div>
          ))}
        </div>
      </HomeSection>

      <HomeSection
        id="tooling-signals"
        kicker="Tooling Signals"
        title="Observing tools through the lens of team behaviour"
        description="Tool stacks reveal culture. We identify the subtle cues that show when tools uplift engineers rather than constrain them."
      >
        <div className="grid gap-6 md:grid-cols-3">
          {toolingSignals.map((tool) => (
            <div
              key={tool.tool}
              className="rounded-2xl border border-primary/10 bg-surface p-6"
            >
              <h3 className="font-heading text-xl text-primary">{tool.tool}</h3>
              <p className="mt-3 text-sm leading-relaxed text-secondary">
                {tool.description}
              </p>
            </div>
          ))}
        </div>
      </HomeSection>

      <HomeSection
        id="code-history"
        kicker="Code History"
        title="Historic threads that inform present-day engineering"
        description="We revisit artifacts, RFCs, and chronicles that expose the lineage of today’s practices."
      >
        <div className="grid gap-6 md:grid-cols-2">
          {codeHistoryEntries.map((entry) => (
            <div
              key={entry.era}
              className="rounded-2xl bg-primary/10 p-6 shadow-sm"
            >
              <h3 className="font-heading text-2xl text-primary">{entry.era}</h3>
              <p className="mt-3 text-sm text-secondary">{entry.focus}</p>
              <div className="mt-4 rounded-lg border border-primary/20 bg-surface p-4 text-sm text-secondary/90">
                <span className="font-semibold text-primary">Artifact: </span>
                {entry.artifact}
              </div>
            </div>
          ))}
        </div>
      </HomeSection>

      <HomeSection
        id="editorial-highlights"
        kicker="Editorial Highlights"
        title="Curations that define DevLayer’s voice"
        description="Highlights from our ongoing investigations into how engineering teams operate, document, and evolve."
      >
        <div className="grid gap-6 md:grid-cols-3">
          {editorialHighlights.map((highlight) => (
            <div
              key={highlight.title}
              className="rounded-2xl border border-primary/10 bg-surface p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
            >
              <h3 className="font-heading text-xl text-primary">
                {highlight.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-secondary">
                {highlight.description}
              </p>
              <Link
                to="/blog"
                className="mt-4 inline-flex items-center text-sm font-semibold text-accent hover:text-primary"
              >
                Explore collection →
              </Link>
            </div>
          ))}
        </div>
      </HomeSection>

      <HomeSection
        id="reading-queue"
        kicker="Reading Queue"
        title="Curated queue with editorial annotations"
        description="A living queue of influential readings we revisit while shaping DevLayer’s narrative."
      >
        <div className="grid gap-6 md:grid-cols-2">
          {readingQueue.map((item) => (
            <div
              key={item.title}
              className="rounded-2xl border border-primary/10 bg-surface p-6"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs uppercase tracking-wide text-accent">
                <span>{item.author}</span>
                <div className="flex gap-2">
                  {item.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-accent/10 px-2 py-1 text-accent"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
              <h3 className="mt-4 font-heading text-xl text-primary">
                {item.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-secondary">
                {item.annotation}
              </p>
            </div>
          ))}
        </div>
        <div className="mt-10 text-center">
          <Link
            to="/queue"
            className="inline-flex items-center rounded-full border border-primary/30 px-6 py-3 text-sm font-semibold text-primary transition hover:border-accent hover:text-accent"
          >
            View the full queue →
          </Link>
        </div>
      </HomeSection>

      <HomeSection
        id="newsletter"
        kicker="Newsletter"
        title="Subscribe to the DevLayer Briefing"
        description="A periodic digest featuring new essays, workflow studies, and archival finds. Structured for engineering leaders and curious makers."
      >
        <div className="mx-auto max-w-3xl rounded-3xl bg-primary/10 p-8 shadow-subtle">
          <form
            className="flex flex-col gap-4 md:flex-row"
            onSubmit={(event) => {
              event.preventDefault();
              const form = event.currentTarget;
              form.reset();
              alert("Thank you for subscribing to the DevLayer Briefing.");
            }}
          >
            <input
              type="email"
              required
              placeholder="Email address"
              className="w-full rounded-full border border-primary/20 bg-surface px-5 py-3 text-sm text-secondary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent"
            />
            <button
              type="submit"
              className="w-full rounded-full bg-primary px-6 py-3 text-sm font-semibold text-surface transition hover:bg-accent md:w-auto"
            >
              Join briefing list
            </button>
          </form>
          <p className="mt-4 text-center text-xs text-secondary/80">
            Editorial cadence: monthly highlights with occasional field notes.
          </p>
        </div>
      </HomeSection>

      <HomeSection
        id="disclaimer"
        kicker="Disclaimer"
        title="For educational use only"
        description="DevLayer provides editorial commentary. All narratives, analyses, and recommendations are published for educational purposes and reflective practice."
      >
        <div className="mx-auto max-w-3xl rounded-2xl border border-primary/10 bg-surface p-6 text-sm leading-relaxed text-secondary">
          Opinions expressed are those of the individual contributors and do not
          constitute consulting advice. Readers should evaluate applicability to
          their own contexts and exercise independent judgement before adopting
          described practices.
        </div>
      </HomeSection>
    </>
  );
}

export default Home;