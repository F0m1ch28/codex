// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

function Privacy() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16 lg:px-6">
      <Helmet>
        <title>Privacy Policy | DevLayer</title>
        <meta
          name="description"
          content="DevLayer privacy policy covering cookies, analytics, data handling, third-party services, user rights, and contact details."
        />
        <link rel="canonical" href="https://devlayer.com/privacy" />
      </Helmet>

      <h1 className="font-heading text-4xl text-primary">Privacy Policy</h1>
      <p className="mt-4 text-sm text-secondary">
        Effective date: January 1, 2024
      </p>

      <section className="mt-8 space-y-6 text-sm leading-relaxed text-secondary">
        <p>
          DevLayer respects the privacy of our readers and contributors. This
          policy describes how we handle personal information when you interact
          with devlayer.com.
        </p>

        <h2 className="font-heading text-2xl text-primary">Cookies</h2>
        <p>
          We use minimal cookies to maintain session preferences and measure
          aggregate interest in our content. Essential cookies ensure smooth
          navigation. You may accept or decline optional cookies via our cookie
          banner.
        </p>

        <h2 className="font-heading text-2xl text-primary">Analytics</h2>
        <p>
          We employ privacy-preserving analytics that store anonymized event
          data. We do not use invasive tracking or behavioural advertising
          tools. Aggregate insights help us prioritize topics that benefit the
          community.
        </p>

        <h2 className="font-heading text-2xl text-primary">Data Handling</h2>
        <p>
          When you contact us or subscribe to the newsletter, we collect only
          the information you provide, such as name, email, organization, and
          message content. We store this information securely and limit access
          to authorized editorial staff.
        </p>

        <h2 className="font-heading text-2xl text-primary">Third-Party Services</h2>
        <p>
          We rely on reputable providers for email delivery, analytics, and
          hosting. Each provider is required to comply with Canadian privacy
          legislation and relevant international standards.
        </p>

        <h2 className="font-heading text-2xl text-primary">User Rights</h2>
        <p>
          You may request access, correction, or deletion of the personal data
          you have shared with us. To exercise these rights, contact
          editorial@devlayer.com. We will respond within 30 days.
        </p>

        <h2 className="font-heading text-2xl text-primary">Contact</h2>
        <p>
          Questions about our privacy practices can be directed to:
          editorial@devlayer.com or by mail to 333 Bay St, Toronto, ON M5H 2R2,
          Canada.
        </p>
      </section>
    </div>
  );
}

export default Privacy;