// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";

function ContactThanks() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 text-center lg:px-6">
      <Helmet>
        <title>Thank You | DevLayer Contact</title>
        <meta
          name="description"
          content="Thank you for contacting DevLayer. We will review your note and respond shortly."
        />
        <link rel="canonical" href="https://devlayer.com/contact/thanks" />
      </Helmet>
      <div className="rounded-3xl border border-primary/10 bg-surface p-12 shadow-lg">
        <h1 className="font-heading text-3xl text-primary">Message received</h1>
        <p className="mt-4 text-sm text-secondary">
          Thank you for reaching out. Our editorial team will review your
          message and respond within two business days.  
          This confirmation page is intended to integrate with the Sendler PHP
          script that handles outbound acknowledgement emails.
        </p>
        <Link
          to="/"
          className="mt-8 inline-flex items-center rounded-full bg-primary px-6 py-3 text-sm font-semibold text-surface transition hover:bg-accent"
        >
          Return to home
        </Link>
      </div>
    </div>
  );
}

export default ContactThanks;