document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.mobile-toggle');
  const nav = document.getElementById('primaryNav');

  if (toggle && nav) {
    toggle.setAttribute('aria-label', 'Toggle navigation');
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('is-open');
      toggle.classList.toggle('is-active', isOpen);
      toggle.setAttribute('aria-expanded', String(isOpen));
    });

    nav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (nav.classList.contains('is-open')) {
          nav.classList.remove('is-open');
          toggle.classList.remove('is-active');
          toggle.setAttribute('aria-expanded', 'false');
        }
      });
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth > 1024 && nav.classList.contains('is-open')) {
        nav.classList.remove('is-open');
        if (toggle) {
          toggle.classList.remove('is-active');
          toggle.setAttribute('aria-expanded', 'false');
        }
      }
    });
  }

  const yearEls = document.querySelectorAll('.current-year');
  const currentYear = new Date().getFullYear();
  yearEls.forEach((el) => {
    el.textContent = currentYear;
  });

  const animatedSections = document.querySelectorAll('[data-animate="fade"]');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    animatedSections.forEach((section) => observer.observe(section));
  } else {
    animatedSections.forEach((section) => section.classList.add('is-visible'));
  }

  const cookieBanner = document.getElementById('cookieBanner');
  const acceptBtn = document.getElementById('cookieAccept');
  const declineBtn = document.getElementById('cookieDecline');
  let storedChoice = null;
  try {
    storedChoice = localStorage.getItem('cherwell_cookie_choice');
  } catch (error) {
    storedChoice = null;
  }
  if (cookieBanner && storedChoice) {
    cookieBanner.classList.add('is-hidden');
  }
  const handleCookieChoice = (choice) => {
    try {
      localStorage.setItem('cherwell_cookie_choice', choice);
    } catch (error) {
      // ignore storage errors
    }
    if (cookieBanner) {
      cookieBanner.classList.add('is-hidden');
    }
  };
  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => handleCookieChoice('accepted'));
  }
  if (declineBtn) {
    declineBtn.addEventListener('click', () => handleCookieChoice('declined'));
  }

  const forms = document.querySelectorAll('form[data-form-type="contact"]');
  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const toastId = form.getAttribute('data-toast-target');
      const toast = toastId ? document.getElementById(toastId) : document.querySelector('.form-toast');
      if (toast) {
        toast.classList.add('is-active');
        toast.setAttribute('aria-hidden', 'false');
        setTimeout(() => {
          toast.classList.remove('is-active');
          toast.setAttribute('aria-hidden', 'true');
        }, 2000);
      }
      setTimeout(() => {
        window.location.href = form.getAttribute('action');
      }, 1100);
    });
  });
});