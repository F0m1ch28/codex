document.addEventListener('DOMContentLoaded', () => {
  const banner = document.querySelector('.cookie-banner');
  if (!banner) return;

  const decision = localStorage.getItem('cdip-cookie-consent');
  if (decision) {
    banner.setAttribute('hidden', 'hidden');
    return;
  }

  const acceptBtn = banner.querySelector('[data-cookie-accept]');
  const declineBtn = banner.querySelector('[data-cookie-decline]');

  const closeBanner = (choice) => {
    localStorage.setItem('cdip-cookie-consent', choice);
    banner.classList.add('cookie-banner--hidden');
    banner.addEventListener('transitionend', () => {
      banner.setAttribute('hidden', 'hidden');
    }, { once: true });
  };

  acceptBtn.addEventListener('click', () => closeBanner('accepted'));
  declineBtn.addEventListener('click', () => closeBanner('declined'));

  // Update footer year
  const yearSpan = document.querySelectorAll('#year');
  yearSpan.forEach(span => span.textContent = new Date().getFullYear());
});