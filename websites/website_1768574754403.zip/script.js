document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const mainMenu = document.querySelector('.main-menu');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookiesBtn = document.querySelector('.cookie-actions .accept');
    const declineCookiesBtn = document.querySelector('.cookie-actions .decline');
    const customizeLink = document.querySelector('.cookie-actions .customize');

    if (navToggle && mainMenu) {
        navToggle.addEventListener('click', () => {
            const isOpen = mainMenu.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen);
            navToggle.classList.toggle('active', isOpen);
        });

        mainMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (mainMenu.classList.contains('open')) {
                    mainMenu.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                    navToggle.classList.remove('active');
                }
            });
        });
    }

    const cookiePreference = localStorage.getItem('fellerbhiyCookieChoice');
    if (!cookiePreference && cookieBanner) {
        cookieBanner.classList.add('active');
    }

    const handleCookieChoice = (choice) => {
        localStorage.setItem('fellerbhiyCookieChoice', choice);
        if (cookieBanner) {
            cookieBanner.classList.remove('active');
        }
    };

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', () => handleCookieChoice('accepted'));
    }

    if (declineCookiesBtn) {
        declineCookiesBtn.addEventListener('click', () => handleCookieChoice('declined'));
    }

    if (customizeLink) {
        customizeLink.addEventListener('click', () => handleCookieChoice('customize'));
    }
});