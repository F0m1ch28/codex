document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            siteNav.classList.toggle('is-open');
        });

        const navLinks = siteNav.querySelectorAll('a');
        navLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.innerWidth < 768 && siteNav.classList.contains('is-open')) {
                    siteNav.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });

        window.addEventListener('resize', function () {
            if (window.innerWidth >= 768) {
                siteNav.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');
    const consentKey = 'swampatbwkCookieConsent';

    if (cookieBanner && acceptBtn && declineBtn) {
        const existingConsent = localStorage.getItem(consentKey);

        if (!existingConsent) {
            cookieBanner.classList.add('visible');
        }

        acceptBtn.addEventListener('click', function () {
            localStorage.setItem(consentKey, 'accepted');
            cookieBanner.classList.remove('visible');
        });

        declineBtn.addEventListener('click', function () {
            localStorage.setItem(consentKey, 'declined');
            cookieBanner.classList.remove('visible');
        });
    }
});