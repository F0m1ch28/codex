document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', function () {
            const isOpen = primaryNav.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
            navToggle.classList.toggle('is-active', isOpen);
            const toggleBar = navToggle.querySelector('span');
            if (toggleBar) {
                if (isOpen) {
                    toggleBar.style.transform = 'rotate(45deg)';
                    toggleBar.style.background = '#fff';
                    toggleBar::before;
                } else {
                    toggleBar.style.transform = '';
                }
            }
        });
    }

    const cookieBanner = document.querySelector('[data-cookie-banner]');
    const acceptBtn = document.querySelector('[data-cookie-accept]');
    const declineBtn = document.querySelector('[data-cookie-decline]');
    const storageKey = 'voltroute-cookie-consent';

    if (cookieBanner && acceptBtn && declineBtn) {
        const consentState = localStorage.getItem(storageKey);
        if (!consentState) {
            cookieBanner.classList.add('is-visible');
        }

        const hideBanner = () => {
            cookieBanner.classList.remove('is-visible');
        };

        acceptBtn.addEventListener('click', function () {
            localStorage.setItem(storageKey, 'accepted');
            hideBanner();
        });

        declineBtn.addEventListener('click', function () {
            localStorage.setItem(storageKey, 'declined');
            hideBanner();
        });
    }
});