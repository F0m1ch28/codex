document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.menu-toggle');
    const globalNav = document.querySelector('.global-nav');

    if (navToggle && globalNav) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-active');
            globalNav.classList.toggle('is-open');
        });

        globalNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('is-active');
                globalNav.classList.remove('is-open');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-actions .accept');
    const declineBtn = document.querySelector('.cookie-actions .decline');

    if (cookieBanner) {
        const consent = localStorage.getItem('genusligvnCookieConsent');
        if (!consent) {
            setTimeout(() => {
                cookieBanner.classList.add('active');
            }, 600);
        }

        const handleConsent = (status) => {
            localStorage.setItem('genusligvnCookieConsent', status);
            cookieBanner.classList.remove('active');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => handleConsent('accepted'));
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => handleConsent('declined'));
        }
    }
});