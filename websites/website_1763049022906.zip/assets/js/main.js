document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".site-nav");
    const scrollBtn = document.getElementById("scrollTopBtn");
    const cookieBanner = document.getElementById("cookie-banner");
    const cookieAccept = document.getElementById("cookie-accept");
    const contactForm = document.getElementById("contact-form");
    const formStatus = document.getElementById("form-status");

    if (navToggle && nav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            nav.classList.toggle("is-open");
        });

        nav.querySelectorAll("a[href^='#']").forEach(link => {
            link.addEventListener("click", event => {
                const targetId = link.getAttribute("href").substring(1);
                const targetEl = document.getElementById(targetId);
                if (targetEl) {
                    event.preventDefault();
                    nav.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                    targetEl.scrollIntoView({ behavior: "smooth", block: "start" });
                }
            });
        });
    }

    const handleScrollButton = () => {
        if (!scrollBtn) return;
        if (window.scrollY > 250) {
            scrollBtn.classList.add("is-visible");
        } else {
            scrollBtn.classList.remove("is-visible");
        }
    };

    window.addEventListener("scroll", handleScrollButton);
    handleScrollButton();

    if (scrollBtn) {
        scrollBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    if (cookieBanner && cookieAccept) {
        const hasAccepted = localStorage.getItem("nevoltraCookiesAccepted");
        if (!hasAccepted) {
            cookieBanner.classList.add("active");
        }

        cookieAccept.addEventListener("click", () => {
            localStorage.setItem("nevoltraCookiesAccepted", "true");
            cookieBanner.classList.remove("active");
        });
    }

    if (contactForm && formStatus) {
        contactForm.addEventListener("submit", event => {
            event.preventDefault();
            formStatus.textContent = "Vielen Dank! Wir melden uns in Kürze bei dir.";
            formStatus.style.color = "#2e8b57";
            contactForm.reset();
            setTimeout(() => {
                formStatus.textContent = "";
            }, 6000);
        });
    }
});