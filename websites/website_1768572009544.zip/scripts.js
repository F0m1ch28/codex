document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector("[data-nav]");
    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!isExpanded));
            siteNav.classList.toggle("is-open");
        });
        siteNav.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 768) {
                    navToggle.setAttribute("aria-expanded", "false");
                    siteNav.classList.remove("is-open");
                }
            });
        });
    }

    const cookieBanner = document.querySelector("[data-cookie-banner]");
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
        const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
        const consentState = localStorage.getItem("halfliwhqc_cookie_consent");
        if (consentState === "accepted" || consentState === "declined") {
            cookieBanner.classList.add("is-hidden");
        } else {
            requestAnimationFrame(() => {
                cookieBanner.classList.add("is-visible");
            });
        }
        const handleConsent = (value) => {
            localStorage.setItem("halfliwhqc_cookie_consent", value);
            cookieBanner.classList.remove("is-visible");
            setTimeout(() => {
                cookieBanner.classList.add("is-hidden");
            }, 320);
        };
        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => handleConsent("accepted"));
        }
        if (declineBtn) {
            declineBtn.addEventListener("click", () => handleConsent("declined"));
        }
    }
});