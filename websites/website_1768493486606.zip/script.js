document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-active');
            navLinks.classList.toggle('is-active');
        });
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('is-active');
                navLinks.classList.remove('is-active');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-button.primary');
    const declineBtn = document.querySelector('.cookie-button.decline');
    const cookiePreference = localStorage.getItem('addupeCookieConsent');

    if (!cookiePreference && cookieBanner) {
        cookieBanner.classList.add('active');
    }

    const handleCookieChoice = (choice) => {
        localStorage.setItem('addupeCookieConsent', choice);
        if (cookieBanner) {
            cookieBanner.classList.remove('active');
        }
    };

    if (acceptBtn) {
        acceptBtn.addEventListener('click', () => handleCookieChoice('accepted'));
    }
    if (declineBtn) {
        declineBtn.addEventListener('click', () => handleCookieChoice('declined'));
    }
});