import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';
import contactDetails from '../data/contactDetails';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.top}>
          <div>
            <div className={styles.brandName}>IT Learning Hub</div>
            <p className={styles.description}>
              We empower technology professionals across Belgium with practice-rich learning experiences,
              recognised certifications, and mentoring that accelerates every stage of their IT career.
            </p>
          </div>
          <div>
            <div className={styles.columnTitle}>Navigation</div>
            <ul className={styles.linkList}>
              <li><Link to="/" className={styles.link}>Home</Link></li>
              <li><Link to="/courses" className={styles.link}>Courses</Link></li>
              <li><Link to="/learning-paths" className={styles.link}>Learning Paths</Link></li>
              <li><Link to="/about" className={styles.link}>About Us</Link></li>
              <li><Link to="/contact" className={styles.link}>Contact</Link></li>
            </ul>
          </div>
          <div>
            <div className={styles.columnTitle}>Resources</div>
            <ul className={styles.linkList}>
              <li><Link to="/services" className={styles.link}>Training Services</Link></li>
              <li><a href="#faq" className={styles.link}>FAQs</a></li>
              <li><a href="#blog" className={styles.link}>Insights</a></li>
              <li><Link to="/learning-paths" className={styles.link}>Certification Roadmaps</Link></li>
            </ul>
          </div>
          <div>
            <div className={styles.columnTitle}>Contact</div>
            <div className={styles.contactDetails}>
              <span>{contactDetails.companyName}</span>
              <span>{contactDetails.address}</span>
              <a href={`tel:${contactDetails.phone}`} className={styles.link}>{contactDetails.phone}</a>
              <a href={`mailto:${contactDetails.email}`} className={styles.link}>{contactDetails.email}</a>
            </div>
          </div>
        </div>
        <div className={styles.bottom}>
          <span>© {new Date().getFullYear()} IT Learning Hub. All rights reserved.</span>
          <div>
            <Link to="/terms" className={styles.link}>Terms of Service</Link> ·{' '}
            <Link to="/privacy" className={styles.link}>Privacy Policy</Link> ·{' '}
            <Link to="/cookie-policy" className={styles.link}>Cookie Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;