import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const hasConsent = document.cookie.split('; ').find((row) => row.startsWith('ilh_cookie_consent='));
    if (!hasConsent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    const expires = new Date();
    expires.setFullYear(expires.getFullYear() + 1);
    document.cookie = `ilh_cookie_consent=accepted; expires=${expires.toUTCString()}; path=/`;
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        We use cookies to enhance your learning experience, analyse traffic, and personalise content. By clicking Accept,
        you consent to our use of cookies aligned with EU regulations.
      </div>
      <div className={styles.actions}>
        <button type="button" onClick={acceptCookies} className={styles.acceptButton}>
          Accept
        </button>
        <Link to="/cookie-policy" className={styles.policyLink}>
          Review Cookie Policy
        </Link>
      </div>
    </div>
  );
}

export default CookieBanner;