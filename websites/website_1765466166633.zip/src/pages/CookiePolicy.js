import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicy.module.css';

function CookiePolicyPage() {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | IT Learning Hub</title>
        <meta name="description" content="Cookie policy for IT Learning Hub explaining how cookies are used on this site." />
      </Helmet>
      <section className={styles.wrapper}>
        <div className="container">
          <h1 className="section-title">Cookie Policy</h1>
          <div className={styles.content}>
            <p>
              This Cookie Policy explains how IT Learning Hub uses cookies and similar technologies on our website. We
              comply with EU regulations and strive for transparency about the data we collect.
            </p>
            <div>
              <div className={styles.sectionTitle}>What Are Cookies?</div>
              <p>
                Cookies are small text files stored on your device that help us deliver a reliable, personalised experience.
                They remember your preferences and support analytics to improve our services.
              </p>
            </div>
            <div>
              <div className={styles.sectionTitle}>Types of Cookies We Use</div>
              <ul>
                <li><strong>Essential cookies:</strong> Enable core functionality such as navigation and form submissions.</li>
                <li><strong>Analytics cookies:</strong> Provide anonymised insights into how visitors use our website.</li>
                <li><strong>Preference cookies:</strong> Remember language and accessibility preferences.</li>
              </ul>
            </div>
            <div>
              <div className={styles.sectionTitle}>Managing Cookies</div>
              <p>
                Upon first visit you can accept cookies through our banner. You may also adjust browser settings to accept
                or reject cookies. Disabling cookies may impact some site features.
              </p>
            </div>
            <p>
              Questions about this policy can be directed to info@itlearninghub.be. This policy was last updated in January
              2024.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default CookiePolicyPage;