import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

function AboutPage() {
  const values = [
    { title: 'Learner-Centred Design', description: 'We build every session around practical application, real Belgian case studies, and continuous feedback.' },
    { title: 'Collaboration & Community', description: 'Peer learning, alumni exchanges, and industry partnerships keep knowledge flowing across the ecosystem.' },
    { title: 'Excellence & Integrity', description: 'Our mentors are vetted experts who uphold rigorous quality standards and transparent guidance.' }
  ];

  const milestones = [
    { year: '2009', text: 'Founded in Brussels to deliver advanced programming bootcamps for Belgian professionals.' },
    { year: '2014', text: 'Expanded into data and cybersecurity disciplines with dedicated labs and simulation environments.' },
    { year: '2018', text: 'Launched corporate academies and custom programmes for high-growth scale-ups and enterprises.' },
    { year: '2022', text: 'Introduced hybrid learning model with live cohorts, local meetups, and on-demand support.' }
  ];

  return (
    <>
      <Helmet>
        <title>About IT Learning Hub</title>
        <meta
          name="description"
          content="Learn about IT Learning Hub’s mission, values, and expert mentors delivering high-impact IT education across Belgium."
        />
      </Helmet>
      <section className={styles.wrapper}>
        <div className="container">
          <div className={styles.intro}>
            <h1 className="section-title">Built in Belgium, Focused on Real Outcomes</h1>
            <p className="section-subtitle">
              IT Learning Hub has supported thousands of technologists and organisations across Brussels, Flanders, and
              Wallonia. Our purpose is to help people thrive in fast-changing digital roles with confidence and purpose.
            </p>
          </div>

          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <div className={styles.valueCard} key={value.title}>
                <h2>{value.title}</h2>
                <p>{value.description}</p>
              </div>
            ))}
          </div>

          <div className={styles.storySection}>
            <h2>Our Story</h2>
            <p>
              Started by a collective of engineers, data scientists, and educators, IT Learning Hub emerged from a simple
              observation: Belgian professionals deserve a local partner that matches international standards for IT
              education. We collaborate with employers, universities, and industry groups to keep every learning journey
              current and challenging.
            </p>
            <div className={styles.timeline}>
              {milestones.map((milestone) => (
                <div className={styles.timelineItem} key={milestone.year}>
                  <h3>{milestone.year}</h3>
                  <p>{milestone.text}</p>
                </div>
              ))}
            </div>
          </div>

          <div className={styles.expertise}>
            <h2>Instructor Expertise</h2>
            <p>
              Our instructor network includes certified architects, experienced developers, cybersecurity specialists, and
              agile coaches. Each mentor balances technical mastery with strong facilitation skills. They bring stories
              from Belgian startups, government agencies, and multinational teams—ensuring every concept is grounded in
              practical reality.
            </p>
            <p>
              We continuously invest in instructor development, peer observations, and innovation labs. This ensures every
              cohort benefits from refreshed material, new tooling, and teaching techniques that make complex topics
              approachable.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default AboutPage;