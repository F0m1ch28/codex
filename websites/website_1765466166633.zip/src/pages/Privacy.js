import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Privacy.module.css';

function PrivacyPage() {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | IT Learning Hub</title>
        <meta name="description" content="Privacy policy detailing how IT Learning Hub handles personal data." />
      </Helmet>
      <section className={styles.wrapper}>
        <div className="container">
          <h1 className="section-title">Privacy Policy</h1>
          <div className={styles.content}>
            <p>
              IT Learning Hub respects your privacy and complies with the General Data Protection Regulation (GDPR). This
              policy explains how we collect, use, and protect personal data obtained through our website and services.
            </p>
            <div>
              <div className={styles.sectionTitle}>Data We Collect</div>
              <p>
                We collect contact details, professional information, and learning preferences shared via forms, email, or
                programme participation. We also collect limited analytics data to improve the website experience.
              </p>
            </div>
            <div>
              <div className={styles.sectionTitle}>Use of Data</div>
              <p>
                Personal data supports course administration, learner support, and communication about relevant programmes.
                We do not sell personal data. Data is only shared with partners when required to deliver a course and with
                appropriate safeguards.
              </p>
            </div>
            <div>
              <div className={styles.sectionTitle}>Retention</div>
              <p>
                Data is retained for as long as necessary to provide services, comply with legal obligations, or until you
                request deletion. Records for ongoing programmes are kept securely within the EU.
              </p>
            </div>
            <div>
              <div className={styles.sectionTitle}>Your Rights</div>
              <p>
                You can request access, correction, or deletion of your personal data at any time. Contact us at
                info@itlearninghub.be to submit a request. We respond within statutory timeframes.
              </p>
            </div>
            <div>
              <div className={styles.sectionTitle}>Security</div>
              <p>
                We implement technical and organisational measures to safeguard personal data, including encryption,
                access controls, and regular reviews of our security practices.
              </p>
            </div>
            <p>
              For questions about this policy, email info@itlearninghub.be. This policy was last updated in January 2024.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default PrivacyPage;