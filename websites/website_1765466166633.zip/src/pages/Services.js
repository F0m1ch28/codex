import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

function ServicesPage() {
  const services = [
    {
      title: 'Corporate Academies',
      description: 'Partner with us to design long-term upskilling programmes tailored to your technology stack and business roadmap.',
      image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=800&q=80',
      points: [
        'Role-based competency mapping',
        'Blended delivery with onsite labs in Belgium',
        'Dedicated success manager and progress analytics'
      ]
    },
    {
      title: 'Executive & Leadership Briefings',
      description: 'Align your leadership teams around emerging trends, investment priorities, and governance best practices.',
      image: 'https://images.unsplash.com/photo-1521737604893-0d74f1c1a3ae?auto=format&fit=crop&w=800&q=80',
      points: [
        'Strategy workshops on cloud, AI, and security',
        'Custom research and benchmarking reports',
        'Scenario planning and decision support'
      ]
    },
    {
      title: 'Assessment & Certification Clinics',
      description: 'Prepare teams for global certifications with diagnostics, mentoring hours, and exam simulations.',
      image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=800&q=80',
      points: [
        'Hands-on labs aligned to certification objectives',
        'Peer study groups and office hours',
        'Detailed readiness reports for leaders'
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>Training Services | IT Learning Hub</title>
        <meta
          name="description"
          content="Discover IT Learning Hub services for corporate academies, executive briefings, and certification readiness designed for Belgian organisations."
        />
      </Helmet>
      <section className={styles.wrapper}>
        <div className="container">
          <div className={styles.intro}>
            <h1 className="section-title">Training Services for Organisations</h1>
            <p className="section-subtitle">
              We partner with Belgian companies to craft learning ecosystems that strengthen teams, accelerate adoption
              of new technologies, and build a culture of continuous improvement.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <div className={styles.serviceCard} key={service.title}>
                <div className={styles.image}>
                  <img src={service.image} alt={service.title} loading="lazy" />
                </div>
                <h2>{service.title}</h2>
                <p>{service.description}</p>
                <ul>
                  {service.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className={styles.delivery}>
            <h2>Flexible Delivery Options</h2>
            <p>
              Choose the delivery format that meets your team’s rhythm: onsite workshops in Brussels, Ghent, or Antwerp;
              virtual cohorts with live labs; or hybrid experiences blending both. We provide detailed reporting, learner
              feedback analytics, and strategic recommendations to keep momentum high.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default ServicesPage;