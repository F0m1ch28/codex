import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Courses.module.css';

function CoursesPage() {
  const categories = [
    {
      name: 'Programming & Software Engineering',
      description: 'Deepen your mastery of modern languages, frameworks, and testing practices to build scalable applications.',
      courses: [
        'React & TypeScript Mastery Lab',
        'Python for Software Engineers',
        'Clean Architecture and Testing Practices'
      ]
    },
    {
      name: 'Cloud Engineering & DevOps',
      description: 'Design resilient pipelines and cloud environments leveraging AWS, Azure, and container ecosystems.',
      courses: [
        'AWS Architecture with Infrastructure as Code',
        'Azure DevOps Accelerator',
        'Kubernetes Production Operations'
      ]
    },
    {
      name: 'Data Science & AI',
      description: 'Harness data pipelines, predictive analytics, and responsible AI frameworks to deliver business insight.',
      courses: [
        'Data Engineering with Python & Spark',
        'Machine Learning in Practice',
        'Responsible AI Strategy Workshop'
      ]
    },
    {
      name: 'Cybersecurity & Governance',
      description: 'Build a security-first mindset across infrastructure, applications, and compliance requirements.',
      courses: [
        'Offensive Security & Ethical Hacking',
        'Cloud Security Architecture',
        'ISO 27001 Implementation Practices'
      ]
    },
    {
      name: 'Product & Agile Leadership',
      description: 'Elevate digital product strategies with agile rituals, stakeholder management, and outcome-driven roadmaps.',
      courses: [
        'Product Management in Tech Organisations',
        'Scaled Agile Delivery Practices',
        'Design Thinking for Innovation'
      ]
    },
    {
      name: 'Emerging Technologies',
      description: 'Explore forward-looking tools such as edge computing, low-code platforms, and automation.',
      courses: [
        'Low-Code Application Development',
        'IoT Solutions Architecture',
        'Robotic Process Automation Foundations'
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>Courses | IT Learning Hub</title>
        <meta
          name="description"
          content="Explore IT Learning Hub courses across programming, cloud, data science, cybersecurity, and emerging technology targeted to the Belgian market."
        />
      </Helmet>
      <section className={styles.wrapper}>
        <div className="container">
          <div className={styles.heading}>
            <h1 className="section-title">Courses That Power Modern IT Careers</h1>
            <p className="section-subtitle">
              Whether you are expanding an existing capability or transforming into a new role, our courses pair
              real-world scenarios with supportive mentoring to help you apply knowledge immediately.
            </p>
          </div>
          <div className={styles.categories}>
            {categories.map((category) => (
              <div className={styles.categoryCard} key={category.name}>
                <h2>{category.name}</h2>
                <p>{category.description}</p>
                <ul className={styles.courseList}>
                  {category.courses.map((course) => (
                    <li key={course}>
                      <span className={styles.courseTitle}>{course}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default CoursesPage;