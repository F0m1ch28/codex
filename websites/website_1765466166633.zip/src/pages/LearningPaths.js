import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './LearningPaths.module.css';

function LearningPathsPage() {
  const paths = [
    {
      name: 'Full-Stack Developer Path',
      duration: '6-9 months',
      summary: 'Develop expertise in modern frontend and backend engineering with deployment know-how.',
      sequence: [
        'Modern JavaScript and TypeScript Foundations',
        'Advanced React and State Management',
        'API Design with Node.js and GraphQL',
        'Automated Testing & CI/CD Pipelines',
        'Capstone: Deploying a production-ready web platform'
      ]
    },
    {
      name: 'Data Scientist Path',
      duration: '5-8 months',
      summary: 'Gain confidence in data engineering, predictive analytics, and responsible AI delivery.',
      sequence: [
        'Python for Data Analysis',
        'Statistics & Experimentation for Decision Making',
        'Machine Learning Algorithms in Practice',
        'Data Engineering with Spark and Cloud Warehouses',
        'Capstone: End-to-end analytics solution with stakeholder presentation'
      ]
    },
    {
      name: 'Cybersecurity Professional Path',
      duration: '4-6 months',
      summary: 'Strengthen cyber resilience through technical defence, governance, and incident response.',
      sequence: [
        'Foundations of Cybersecurity & Threat Modelling',
        'Network Security and Ethical Hacking Labs',
        'Security Operations & Incident Response Simulations',
        'Cloud Security Architecture & Zero Trust',
        'Capstone: Build and present a security improvement roadmap'
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>Learning Paths | IT Learning Hub</title>
        <meta
          name="description"
          content="Structured IT learning paths that combine expert mentoring, hands-on labs, and certification support for full-stack developers, data scientists, and cybersecurity professionals."
        />
      </Helmet>
      <section className={styles.wrapper}>
        <div className="container">
          <div className={styles.intro}>
            <h1 className="section-title">Learning Paths to Guide Your Career Growth</h1>
            <p className="section-subtitle">
              Choose a curated roadmap that blends live instruction, collaborative labs, mentoring, and certification
              preparation. Every learning path is backed by measurable outcomes and ongoing support.
            </p>
          </div>
          <div className={styles.pathGrid}>
            {paths.map((path) => (
              <div key={path.name} className={styles.pathCard}>
                <div className={styles.pathHeader}>
                  <h2>{path.name}</h2>
                  <span className={styles.badge}>{path.duration}</span>
                </div>
                <p>{path.summary}</p>
                <ol className={styles.sequence}>
                  {path.sequence.map((step) => (
                    <li key={step}>{step}</li>
                  ))}
                </ol>
              </div>
            ))}
          </div>
          <div className={styles.support}>
            <h2>Included in Every Learning Path</h2>
            <ul>
              <li>One-to-one coaching sessions to review progress and remove blockers.</li>
              <li>Peer study circles and community events hosted across Belgium.</li>
              <li>Certification readiness assessments and exam simulations.</li>
              <li>Access to a growing library of labs, templates, and knowledge bases.</li>
            </ul>
          </div>
        </div>
      </section>
    </>
  );
}

export default LearningPathsPage;