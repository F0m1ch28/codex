import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Terms.module.css';

function TermsPage() {
  return (
    <>
      <Helmet>
        <title>Terms of Service | IT Learning Hub</title>
        <meta name="description" content="Terms of service for IT Learning Hub training programmes and website usage." />
      </Helmet>
      <section className={styles.wrapper}>
        <div className="container">
          <h1 className="section-title">Terms of Service</h1>
          <div className={styles.content}>
            <p>
              These Terms of Service govern the use of the IT Learning Hub website and participation in our learning
              programmes. By accessing our site or engaging with our services, you agree to comply with these terms.
            </p>
            <div>
              <div className={styles.sectionTitle}>1. Services</div>
              <p>
                IT Learning Hub delivers educational content, mentoring, and related resources focused on IT skills
                development. Programme scopes, schedules, and learning outcomes are confirmed directly with participants
                or partner organisations.
              </p>
            </div>
            <div>
              <div className={styles.sectionTitle}>2. Intellectual Property</div>
              <p>
                All course materials, documentation, and digital assets are owned or licensed by IT Learning Hub. Materials
                may not be reproduced, distributed, or shared without written permission.
              </p>
            </div>
            <div>
              <div className={styles.sectionTitle}>3. Conduct</div>
              <p>
                We foster inclusive, respectful learning environments. Participants are expected to uphold professional
                conduct, respect confidentiality, and follow community guidelines shared during programmes.
              </p>
            </div>
            <div>
              <div className={styles.sectionTitle}>4. Liability</div>
              <p>
                We strive to provide accurate, up-to-date information. However, learning outcomes depend on participant
                engagement and organisational implementation. IT Learning Hub is not liable for indirect or consequential
                losses arising from the use of our services.
              </p>
            </div>
            <div>
              <div className={styles.sectionTitle}>5. Updates</div>
              <p>
                We may revise these terms to reflect changes in regulations or our services. Updates will be published on
                this page with an updated revision date.
              </p>
            </div>
            <p>
              If you have questions regarding these terms, contact us at info@itlearninghub.be. Last updated: January 2024.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default TermsPage;