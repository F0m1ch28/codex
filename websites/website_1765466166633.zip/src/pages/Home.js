import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

function HomePage() {
  const stats = [
    { value: '15+', label: 'Years empowering IT professionals' },
    { value: '1200+', label: 'Learners supported annually' },
    { value: '92%', label: 'Certification exam success rate' },
    { value: '30+', label: 'Belgian companies partnering' }
  ];

  const featuredCourses = [
    {
      title: 'Modern Web Development',
      description: 'Master React, TypeScript, accessibility, and scalable architecture for high-performing web apps.',
      icon: '💻'
    },
    {
      title: 'Data, AI & Analytics',
      description: 'Build deep skills in Python, machine learning, and cloud-based analytics to interpret complex data.',
      icon: '📊'
    },
    {
      title: 'Cybersecurity Foundations',
      description: 'Gain practical competencies in ethical hacking, network defence, and security governance.',
      icon: '🛡️'
    },
    {
      title: 'Cloud & DevOps Engineering',
      description: 'Design resilient infrastructure with AWS, Azure, containers, and automation pipelines.',
      icon: '☁️'
    }
  ];

  const benefits = [
    {
      title: 'Industry-Relevant Curriculum',
      body: 'Every syllabus aligns with Belgian market needs, European standards, and employer feedback.'
    },
    {
      title: 'Expert Mentors',
      body: 'Learn from certified engineers and consultants who apply these skills daily in the field.'
    },
    {
      title: 'Flexible Delivery',
      body: 'Choose immersive bootcamps, blended learning, or self-paced tracks that adapt to your schedule.'
    },
    {
      title: 'Career Acceleration',
      body: 'Receive personalised guidance on certification routes, job readiness, and portfolio storytelling.'
    }
  ];

  const learningPaths = [
    {
      title: 'Full-Stack Developer Journey',
      outcomes: 'From HTML foundations to advanced React, testing, and cloud deployment with real-world scenarios.'
    },
    {
      title: 'Data Scientist Roadmap',
      outcomes: 'Progress through Python, statistics, machine learning projects, and responsible AI practices.'
    },
    {
      title: 'Cybersecurity Professional Path',
      outcomes: 'Advance from threat awareness to incident response, governance, and SOC readiness.'
    }
  ];

  const processSteps = [
    { title: 'Discover & Assess', description: 'Capture your current skills and ambitions through diagnostic workshops.' },
    { title: 'Plan & Personalise', description: 'Design a tailored curriculum and timeline aligned with your goals.' },
    { title: 'Learn & Apply', description: 'Combine instructor-led sessions with hands-on labs and collaborative projects.' },
    { title: 'Validate & Grow', description: 'Benchmark progress, earn certifications, and gain continued mentorship.' }
  ];

  const testimonials = [
    {
      quote: 'The data science path helped me pivot from business analysis to a machine learning role in Brussels. The mentors were invested in my success.',
      name: 'Charlotte De Smet',
      role: 'Data Scientist, Antwerp',
      avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80'
    },
    {
      quote: 'Our engineering team transformed its DevOps pipeline within months. IT Learning Hub delivered targeted training and coaching that stuck.',
      name: 'Maxime Verbruggen',
      role: 'Head of Engineering, Ghent',
      avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80'
    },
    {
      quote: 'I achieved my AWS certification on the first attempt. The labs, study circles, and exam simulations mirrored the real environment perfectly.',
      name: 'Sara Van Damme',
      role: 'Cloud Engineer, Brussels',
      avatar: 'https://images.unsplash.com/photo-1544723795-43253782cd5d?auto=format&fit=crop&w=200&q=80'
    }
  ];

  const team = [
    {
      name: 'Lise Vandermissen',
      title: 'Director of Learning Innovation',
      bio: 'Specialist in adult pedagogy and digital learning design with 12+ years in EdTech leadership.',
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: 'Jonas Willems',
      title: 'Lead Cloud Architect',
      bio: 'AWS Hero and Azure MVP guiding enterprises on cloud-native transformations across Europe.',
      image: 'https://images.unsplash.com/photo-1544723795-43253782cd5d?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: 'Anika Janssens',
      title: 'Head of Cybersecurity Programmes',
      bio: 'Former SOC manager delivering incident response simulations and governance frameworks.',
      image: 'https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: 'Tom Quinten',
      title: 'Data Science Principal Mentor',
      bio: 'Machine learning strategist focusing on ethical AI adoption in regulated industries.',
      image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=400&q=80'
    }
  ];

  const projects = [
    {
      title: 'Digital Upskilling for Flemish Healthcare',
      description: 'Designed a blended programme enabling 150+ professionals to leverage analytics for patient care improvements.',
      image: 'https://images.unsplash.com/photo-1522071901873-411886a10004?auto=format&fit=crop&w=1200&q=80'
    },
    {
      title: 'Cybersecurity Academy for Brussels SMEs',
      description: 'Delivered hands-on labs, tabletop exercises, and policy support for fast-scaling companies.',
      image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1200&q=80'
    },
    {
      title: 'University Industry Bridge',
      description: 'Co-created cloud-native modules with Belgian universities, aligning academic theory with enterprise realities.',
      image: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1200&q=80'
    }
  ];

  const faqs = [
    { question: 'Do you offer programmes in English and Dutch?', answer: 'Yes. Most cohorts run in English, with selected sessions available in Dutch or bilingual formats depending on demand.' },
    { question: 'Can learning paths be customised for organisations?', answer: 'We frequently co-design programmes with employers, tailoring content, labs, and coaching to internal tools and workflows.' },
    { question: 'How are courses delivered?', answer: 'We combine live virtual classrooms, in-person labs in Brussels, Ghent, and Antwerp, plus on-demand resources for reinforcement.' },
    { question: 'Do you provide certification preparation?', answer: 'Each path includes exam blueprints, simulated assessments, and mentoring from certified experts to optimise readiness.' }
  ];

  const blogPosts = [
    {
      title: '7 Emerging Tech Skills Belgian Employers Expect in 2024',
      summary: 'Discover the most in-demand competencies that CIOs and hiring managers highlight in our latest industry report.',
      image: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=800&q=80',
      link: '/blog/emerging-skills-2024'
    },
    {
      title: 'How to Build a Learning Culture Inside Your Engineering Team',
      summary: 'Practical strategies for embedding continuous learning rituals, mentorship, and measurable outcomes.',
      image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=800&q=80',
      link: '/blog/learning-culture-engineering'
    },
    {
      title: 'Designing Responsible AI Projects from Day One',
      summary: 'A blueprint for data science teams to integrate ethics, compliance, and transparency across projects.',
      image: 'https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=800&q=80',
      link: '/blog/responsible-ai-belgium'
    }
  ];

  return (
    <>
      <Helmet>
        <title>IT Learning Hub | Advance Your IT Career in Belgium</title>
        <meta
          name="description"
          content="IT Learning Hub accelerates IT skills in Belgium with modern courses, structured learning paths, and expert mentorship in cloud, data, cybersecurity, and development."
        />
      </Helmet>
      <section
        className={styles.hero}
        style={{
          backgroundImage:
            'linear-gradient(135deg, rgba(248,250,252,0.9), rgba(226,232,240,0.6)), url(https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=1600&q=80)',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="container">
          <div className={styles.heroContent}>
            <div className={styles.heroText}>
              <span className={styles.kicker}>Belgium’s trusted IT education partner</span>
              <h1 className={styles.title}>Advance Your IT Career with Future-Proof Skills</h1>
              <p className={styles.subtitle}>
                Join expert-led programmes tailored to the Belgian technology landscape. From web development to cloud,
                data, and cybersecurity, we help professionals and teams learn faster, apply knowledge, and stay ahead.
              </p>
              <div className={styles.heroActions}>
                <Link to="/courses" className="button-primary" aria-label="Browse IT courses">
                  Explore Courses
                </Link>
                <Link to="/learning-paths" className="button-secondary" aria-label="Discover learning paths">
                  View Learning Paths
                </Link>
              </div>
            </div>
            <div className={styles.heroVisual} aria-hidden="true">
              <img
                src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=900&q=80"
                alt="Learners collaborating with laptops"
                loading="lazy"
              />
              <div className={styles.heroStats}>
                <span>Live cohorts every month</span>
                <span>Accredited mentors & labs</span>
              </div>
            </div>
          </div>
          <div className={styles.statsSection}>
            {stats.map((item) => (
              <div key={item.label} className={styles.statCard}>
                <div className={styles.statValue}>{item.value}</div>
                <div className={styles.statLabel}>{item.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.featuredSection}`} id="courses">
        <div className="container">
          <h2 className="section-title">Featured Learning Themes</h2>
          <p className="section-subtitle">
            Build skills that help you design, deploy, and secure technology products. Each course blends guidance from
            Belgian experts with immersive labs.
          </p>
          <div className={styles.featuredGrid}>
            {featuredCourses.map((course) => (
              <div className={styles.featuredCard} key={course.title}>
                <div className={styles.iconBadge}>{course.icon}</div>
                <h3>{course.title}</h3>
                <p>{course.description}</p>
                <Link to="/courses" className="button-secondary" aria-label={`View courses for ${course.title}`}>
                  View Course List →
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.whySection}>
        <div className="container">
          <h2 className="section-title">Why Professionals Choose IT Learning Hub</h2>
          <p className="section-subtitle">
            Our programmes are forged with industry leaders, ensuring each learning experience creates measurable
            outcomes across Belgian organisations.
          </p>
          <div className={styles.whyGrid}>
            {benefits.map((benefit) => (
              <div className={styles.whyCard} key={benefit.title}>
                <h3>{benefit.title}</h3>
                <p>{benefit.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.pathsSection}>
        <div className="container">
          <h2 className="section-title">Structured Learning Paths</h2>
          <p className="section-subtitle">
            Each path combines mentoring, applied labs, and certification preparation—ideal for individuals and teams
            seeking a clear roadmap to career goals.
          </p>
          <div className={styles.pathsGrid}>
            {learningPaths.map((path) => (
              <div className={styles.pathCard} key={path.title}>
                <h3>{path.title}</h3>
                <p>{path.outcomes}</p>
                <Link to="/learning-paths" className="button-secondary">
                  Explore Path →
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <h2 className="section-title">How Our Learning Experience Works</h2>
          <p className="section-subtitle">
            From assessment to ongoing mentorship, we provide the structure and feedback you need to excel.
          </p>
          <div className={styles.processFlow}>
            {processSteps.map((step, index) => (
              <div className={styles.processStep} key={step.title}>
                <div className={styles.stepNumber}>0{index + 1}</div>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <h2 className="section-title">Success Stories from Our Learners</h2>
          <p className="section-subtitle">
            Hear how professionals and teams across Belgium upskilled with confidence and transformed their work.
          </p>
          <div className={styles.testimonialsGrid}>
            {testimonials.map((testimony) => (
              <div className={styles.testimonialCard} key={testimony.name}>
                <div className={styles.quoteMark}>“</div>
                <p>{testimony.quote}</p>
                <div className={styles.testimonialAuthor}>
                  <img className={styles.avatar} src={testimony.avatar} alt={testimony.name} loading="lazy" />
                  <div>
                    <strong>{testimony.name}</strong>
                    <div>{testimony.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <h2 className="section-title">Meet the Mentors Guiding Your Journey</h2>
          <p className="section-subtitle">
            Our facilitators combine deep technical expertise with empathetic coaching to keep you motivated.
          </p>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <div className={styles.teamCard} key={member.name}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <div className={styles.teamBody}>
                  <h3>{member.name}</h3>
                  <p><strong>{member.title}</strong></p>
                  <p>{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <h2 className="section-title">Impact Across Belgian Organisations</h2>
          <p className="section-subtitle">
            We collaborate with universities, scale-ups, and established enterprises to build resilient IT capabilities.
          </p>
          <div className={styles.projectsGrid}>
            {projects.map((project) => (
              <div className={styles.projectCard} key={project.title}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectContent}>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection} id="faq">
        <div className="container">
          <h2 className="section-title">Frequently Asked Questions</h2>
          <p className="section-subtitle">
            Everything you need to know about our programmes, delivery formats, and support model.
          </p>
          <div className={styles.faqGrid}>
            {faqs.map((faq) => (
              <div className={styles.faqItem} key={faq.question}>
                <h3>{faq.question}</h3>
                <p>{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection} id="blog">
        <div className="container">
          <h2 className="section-title">Latest Insights</h2>
          <p className="section-subtitle">
            Stay updated with trends, research, and best practices for building high-performing technology teams.
          </p>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <div className={styles.blogCard} key={post.title}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogContent}>
                  <h3>{post.title}</h3>
                  <p>{post.summary}</p>
                  <Link to={post.link} className="button-secondary">
                    Read Insight →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <h2 className="section-title" style={{ color: '#fff' }}>Ready to Unlock the Next Stage of Your IT Career?</h2>
          <p className="section-subtitle" style={{ color: 'rgba(255,255,255,0.86)' }}>
            Talk with our learning advisors to map your goals, select the right courses, and join the next cohort.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/contact" className="button-primary">
              Connect with Our Team
            </Link>
            <Link to="/services" className="button-secondary">
              Discover Training Services
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

export default HomePage;