import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';
import contactDetails from '../data/contactDetails';

function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const currentErrors = {};
    if (!formData.name.trim()) currentErrors.name = 'Please provide your name.';
    if (!formData.email.trim()) {
      currentErrors.email = 'Please provide your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      currentErrors.email = 'Please provide a valid email address.';
    }
    if (!formData.subject.trim()) currentErrors.subject = 'Please tell us how we can help.';
    if (!formData.message.trim()) currentErrors.message = 'A short message helps us prepare the right response.';

    setErrors(currentErrors);
    return Object.keys(currentErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Contact IT Learning Hub</title>
        <meta
          name="description"
          content="Contact IT Learning Hub in Brussels for IT training enquiries, learning path guidance, and corporate programme partnerships."
        />
      </Helmet>
      <section className={styles.wrapper}>
        <div className="container">
          <div className="section-title">Connect with Our Learning Advisors</div>
          <p className="section-subtitle">
            Share a few details and we’ll be in touch to discuss the right courses, learning paths, or customised training
            experiences for you or your organisation.
          </p>
          <div className={styles.layout}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              {submitted && (
                <div className={styles.successMessage}>
                  Thank you for reaching out! Our team will contact you shortly to continue the conversation.
                </div>
              )}
              <div className={styles.fieldGroup}>
                <label htmlFor="name">Name</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  className={styles.input}
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Enter your full name"
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  className={styles.input}
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="you@example.com"
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="subject">Subject</label>
                <input
                  id="subject"
                  name="subject"
                  type="text"
                  className={styles.input}
                  value={formData.subject}
                  onChange={handleChange}
                  placeholder="How can we assist you?"
                />
                {errors.subject && <span className={styles.error}>{errors.subject}</span>}
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="message">Message</label>
                <textarea
                  id="message"
                  name="message"
                  className={styles.textarea}
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Tell us about your goals, timeline, or team."
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className="button-primary">
                Submit Enquiry
              </button>
            </form>
            <div className={styles.details}>
              <h2>Contact Details</h2>
              <div className={styles.detailItem}>
                <span className={styles.detailLabel}>Address</span>
                <span>{contactDetails.address}</span>
              </div>
              <div className={styles.detailItem}>
                <span className={styles.detailLabel}>Phone</span>
                <a href={`tel:${contactDetails.phone}`}>{contactDetails.phone}</a>
              </div>
              <div className={styles.detailItem}>
                <span className={styles.detailLabel}>Email</span>
                <a href={`mailto:${contactDetails.email}`}>{contactDetails.email}</a>
              </div>
              <p>
                Visit our Brussels learning studio for in-person sessions, coaching, and community events. We also host
                regular meetups in Ghent and Antwerp—reach out to learn more.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default ContactPage;