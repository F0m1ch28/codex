const contactDetails = {
  companyName: 'IT Learning Hub',
  address: 'Tech Square 1, 1000 Brussels, Belgium',
  phone: '+32 2 123 45 67',
  email: 'info@itlearninghub.be'
};

export default contactDetails;