```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    id: 1,
    title: 'Как построить дорожную карту цифровой трансформации',
    excerpt:
      'Рассказываем, как оценить текущие процессы, сформировать цели и выбрать приоритетные инициативы для первого года трансформации.',
    image: 'https://picsum.photos/900/600?random=231',
    date: '15 марта 2024',
    tag: 'Стратегия'
  },
  {
    id: 2,
    title: 'Роль CRM в управлении продажами и сервисом',
    excerpt:
      'Почему CRM — это не только про продажи, а про клиентоориентированность и постоянное улучшение сервиса благодаря данным.',
    image: 'https://picsum.photos/900/600?random=232',
    date: '1 марта 2024',
    tag: 'CRM'
  },
  {
    id: 3,
    title: 'BI и KPI: какие метрики действительно важны руководителю',
    excerpt:
      'Выделяем ключевые показатели и показываем, как визуализировать их так, чтобы принимать решения быстрее и точнее.',
    image: 'https://picsum.photos/900/600?random=233',
    date: '16 февраля 2024',
    tag: 'Аналитика'
  },
  {
    id: 4,
    title: 'Миграция в облако: чек-лист для МСБ',
    excerpt:
      'Готовый чек-лист для подготовки к миграции: от инвентаризации активов до выбора архитектуры и расчёта TCO.',
    image: 'https://picsum.photos/900/600?random=234',
    date: '2 февраля 2024',
    tag: 'Облака'
  }
];

const BlogPage = () => {
  return (
    <>
      <Helmet>
        <title>Блог Горизонта — аналитика и практики цифровой трансформации</title>
        <meta
          name="description"
          content="Статьи Горизонта о цифровой трансформации, CRM, бизнес-аналитике и облачных решениях для компаний Москвы и области."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Блог Горизонта</h1>
          <p>
            Делимся практикой цифровой трансформации, рассказываем о проектах и полезных инструментах
            для бизнеса. Подписывайтесь, чтобы не пропустить новые материалы.
          </p>
        </div>
      </section>

      <section className={styles.postsSection}>
        <div className="container">
          <div className={styles.postsGrid}>
            {posts.map((post) => (
              <article key={post.id} className={styles.postCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.postContent}>
                  <span className={styles.postTag}>{post.tag}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <div className={styles.postMeta}>
                    <span>{post.date}</span>
                    <span>Читать в блоге</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default BlogPage;
```