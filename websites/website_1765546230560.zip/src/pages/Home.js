```javascript
import React, { useEffect, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const statsData = [
  { id: 1, label: 'Проектов по цифровизации', value: 120 },
  { id: 2, label: 'Средний рост эффективности', value: 37, suffix: '%' },
  { id: 3, label: 'Специалистов в команде', value: 45 },
  { id: 4, label: 'Лет опыта внедрения ИТ', value: 12 }
];

const servicesData = [
  {
    id: 1,
    title: 'Анализ и редизайн процессов',
    description:
      'Диагностика текущих процессов, карта цифровой зрелости и дорожная карта изменений.',
    icon: '📊'
  },
  {
    id: 2,
    title: 'Внедрение CRM и автоматизация продаж',
    description:
      'Подбор платформы, настройка pipeline, обучение команды и интеграция с каналами коммуникаций.',
    icon: '🤝'
  },
  {
    id: 3,
    title: 'Бизнес-аналитика и BI-отчётность',
    description:
      'Создание дашбордов, связка источников данных, построение KPI и мониторинг в реальном времени.',
    icon: '📈'
  },
  {
    id: 4,
    title: 'Облачные решения и архитектура',
    description:
      'Миграция в облако, настройка инфраструктуры, обеспечение отказоустойчивости и безопасности.',
    icon: '☁️'
  }
];

const processSteps = [
  {
    id: 1,
    title: 'Диагностика',
    description: 'Интервью, аудит данных, оценка зрелости и точки цифрового роста.'
  },
  {
    id: 2,
    title: 'Стратегия',
    description: 'Формируем дорожную карту трансформации и бизнес-кейс изменений.'
  },
  {
    id: 3,
    title: 'Внедрение',
    description: 'Реализуем приоритетные инициативы, обучаем команды и масштабируем решения.'
  },
  {
    id: 4,
    title: 'Поддержка',
    description: 'Сопровождаем после запуска, измеряем результаты, развиваем продукты.'
  }
];

const casesData = [
  {
    id: 1,
    title: 'RetailX',
    industry: 'Ритейл',
    result: 'CRM + аналитика: рост NPS на 18%, ускорение обработки заказов на 30%.',
    image: 'https://picsum.photos/640/420?random=201'
  },
  {
    id: 2,
    title: 'LogiChain',
    industry: 'Логистика',
    result: 'Цифровой диспетчерский центр и RPA: сокращение операционных издержек на 24%.',
    image: 'https://picsum.photos/640/420?random=202'
  },
  {
    id: 3,
    title: 'FinNext',
    industry: 'Финансовые услуги',
    result: 'Витрина данных и BI: управленческий отчёт готовится за 20 минут вместо 4 часов.',
    image: 'https://picsum.photos/640/420?random=203'
  }
];

const projectsData = [
  {
    id: 1,
    title: 'Цифровизация отдела продаж',
    category: 'Продажи',
    description: 'Внедрение CRM с омниканальной связью и автоматизацией договоров.',
    image: 'https://picsum.photos/800/600?random=501'
  },
  {
    id: 2,
    title: 'Переезд в облако',
    category: 'Инфраструктура',
    description: 'Миграция ERP и клиентских сервисов в облачную среду с SLA 99,9%.',
    image: 'https://picsum.photos/800/600?random=502'
  },
  {
    id: 3,
    title: 'BI-портал руководителя',
    category: 'Аналитика',
    description: 'Единая витрина KPI с данными из 6 систем и прогнозной аналитикой.',
    image: 'https://picsum.photos/800/600?random=503'
  },
  {
    id: 4,
    title: 'Автоматизация склада',
    category: 'Операции',
    description: 'Интеграция WMS и RPA-ботов для ускорения отгрузки и снижения ошибок.',
    image: 'https://picsum.photos/800/600?random=504'
  }
];

const testimonialsData = [
  {
    id: 1,
    name: 'Анна Кудрявцева',
    role: 'Генеральный директор RetailX',
    quote:
      'Команда Горизонта помогла нам увидеть картину процессов целиком и дала чёткий план действий. Результаты превзошли ожидания: конверсия выросла, а клиенты стали лояльнее.',
    image: 'https://picsum.photos/200/200?random=401'
  },
  {
    id: 2,
    name: 'Игорь Соколов',
    role: 'COO LogiChain',
    quote:
      'Особенно ценно, что консультанты работают вместе с нашей командой, обучают и поддерживают после запуска. Мы продолжаем проекты цифровизации с Горизонтом и дальше.',
    image: 'https://picsum.photos/200/200?random=402'
  },
  {
    id: 3,
    name: 'Мария Пшеничная',
    role: 'Директор по развитию FinNext',
    quote:
      'От диагностики до внедрения BI прошло всего четыре месяца. Новая аналитика помогла быстрее принимать решения и заметно улучшила прозрачность бизнеса.',
    image: 'https://picsum.photos/200/200?random=403'
  }
];

const teamData = [
  {
    id: 1,
    name: 'Сергей Мельников',
    role: 'Партнёр по стратегии',
    expertise: '15 лет в ИТ-консалтинге, экспертиза в CRM и управлении изменениями.',
    image: 'https://picsum.photos/400/400?random=301'
  },
  {
    id: 2,
    name: 'Ирина Беляева',
    role: 'Руководитель практики данных',
    expertise: 'BI, построение дата-платформ и внедрение Power BI/Tableau в МСБ.',
    image: 'https://picsum.photos/400/400?random=302'
  },
  {
    id: 3,
    name: 'Алексей Горчак',
    role: 'Архитектор решений',
    expertise: 'Облачные инфраструктуры, DevOps, устойчивость и безопасность.',
    image: 'https://picsum.photos/400/400?random=303'
  }
];

const faqItems = [
  {
    id: 1,
    question: 'С чего начинается проект цифровой трансформации?',
    answer:
      'Первый шаг — диагностика: интервью, анализ данных, оценка технических систем. На её основе формируем карту инициатив и приоритетов.'
  },
  {
    id: 2,
    question: 'Работаете ли вы с небольшими компаниями?',
    answer:
      'Да, мы специализируемся на малом и среднем бизнесе, помогаем внедрять практичные решения с понятной окупаемостью и быстрым эффектом.'
  },
  {
    id: 3,
    question: 'Как вы сопровождаете проекты после запуска?',
    answer:
      'Предоставляем поддержку, SLA, аналитический контроль, обучаем команды и помогаем масштабировать решения на другие подразделения.'
  },
  {
    id: 4,
    question: 'Можно ли интегрировать существующие системы?',
    answer:
      'Мы анализируем текущий ландшафт и строим архитектуру интеграций, чтобы использовать уже внедрённые системы и дополнить их новыми инструментами.'
  }
];

const blogPreview = [
  {
    id: 1,
    title: 'Цифровая зрелость: с чего стартовать компании из МСБ',
    excerpt:
      'Разбираем, какие данные собрать и как сформировать дорожную карту, чтобы цифровая трансформация приносила измеримые результаты.',
    image: 'https://picsum.photos/640/420?random=601',
    date: '15 марта 2024'
  },
  {
    id: 2,
    title: 'CRM как единый центр продаж: опыт внедрения',
    excerpt:
      'Какие шаги позволяют сгладить сопротивление отделов и добиться быстрой адаптации команды к новой системе.',
    image: 'https://picsum.photos/640/420?random=602',
    date: '27 февраля 2024'
  },
  {
    id: 3,
    title: 'BI-дэшборды для руководителя: 5 ключевых показателей',
    excerpt:
      'Что важно включить в панель мониторинга, чтобы руководитель видел ситуацию в бизнесе в режиме реального времени.',
    image: 'https://picsum.photos/640/420?random=603',
    date: '8 февраля 2024'
  }
];

const HomePage = () => {
  const [stats, setStats] = useState(statsData.map((stat) => ({ ...stat, current: 0 })));
  const [activeCategory, setActiveCategory] = useState('Все');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [ctaEmail, setCtaEmail] = useState('');
  const [ctaMessage, setCtaMessage] = useState('');
  const animationRef = useRef(null);

  useEffect(() => {
    animationRef.current = setInterval(() => {
      setStats((prev) => {
        let allComplete = true;
        const next = prev.map((stat) => {
          if (stat.current >= stat.value) {
            return stat;
          }
          allComplete = false;
          const increment = Math.ceil(stat.value / 50);
          const updated = Math.min(stat.current + increment, stat.value);
          return { ...stat, current: updated };
        });

        if (allComplete && animationRef.current) {
          clearInterval(animationRef.current);
          animationRef.current = null;
        }
        return next;
      });
    }, 60);

    return () => {
      if (animationRef.current) {
        clearInterval(animationRef.current);
      }
    };
  }, []);

  const filteredProjects =
    activeCategory === 'Все'
      ? projectsData
      : projectsData.filter((project) => project.category === activeCategory);

  const handlePrevTestimonial = () => {
    setCurrentTestimonial((prev) =>
      prev === 0 ? testimonialsData.length - 1 : prev - 1
    );
  };

  const handleNextTestimonial = () => {
    setCurrentTestimonial((prev) =>
      prev === testimonialsData.length - 1 ? 0 : prev + 1
    );
  };

  const handleCtaSubmit = (event) => {
    event.preventDefault();
    const trimmed = ctaEmail.trim();
    const emailRegex = /^\S+@\S+\.\S+$/;

    if (!emailRegex.test(trimmed)) {
      setCtaMessage('Пожалуйста, укажите корректный email.');
      return;
    }

    setCtaMessage('Спасибо! Мы свяжемся с вами в течение одного рабочего дня.');
    setCtaEmail('');
  };

  return (
    <>
      <Helmet>
        <title>Горизонт — цифровая трансформация бизнеса</title>
        <meta
          name="description"
          content="Горизонт помогает компаниям Москвы и области в цифровой трансформации: аудит процессов, внедрение CRM, аналитика и облачные решения."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <p className={styles.heroLabel}>Цифровая трансформация для роста</p>
            <h1 className={styles.heroTitle}>
              Перезапускаем ключевые процессы бизнеса с помощью данных, автоматизации и облачных
              платформ.
            </h1>
            <p className={styles.heroSubtitle}>
              Мы соединяем стратегию, технологии и людей, чтобы цифровые инициативы приносили
              измеримый результат и укрепляли конкурентоспособность компании.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className={`primaryButton ${styles.heroButton}`}>
                Обсудить проект
              </Link>
              <Link to="/uslugi" className={`ghostButton ${styles.heroButtonSecondary}`}>
                Узнать об услугах
              </Link>
            </div>
          </div>
          <div className={styles.heroCard} role="presentation">
            <div className={styles.heroCardHeader}>
              <span>Диагностика процессов</span>
              <strong>10 дней</strong>
            </div>
            <ul className={styles.heroChecklist}>
              <li>Интервью и аудит данных</li>
              <li>Карта цифровой зрелости</li>
              <li>Роудмап инициатив</li>
            </ul>
            <span className={styles.heroBadge}>Подходит для МСБ</span>
          </div>
        </div>
      </section>

      <section className={styles.intro}>
        <div className="container">
          <h2 className={styles.sectionTitle}>О компании</h2>
          <p className={styles.introText}>
            Горизонт — команда стратегов, аналитиков и архитекторов решений, которые превращают
            цифровые инициативы в стабильный рост бизнеса. Мы работаем с предпринимателями Москвы и
            Московской области, создаём системы управления данными, выстраиваем процессную модель и
            поддерживаем команду на каждом этапе изменений.
          </p>
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Ключевые показатели">
        <div className="container">
          <div className={styles.statsGrid}>
            {stats.map((stat) => (
              <article key={stat.id} className={styles.statCard}>
                <h3>
                  {stat.current}
                  {stat.suffix || ''}
                </h3>
                <p>{stat.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.servicesSection} id="services">
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionLabel}>Комплексные решения</p>
            <h2 className={styles.sectionTitle}>Ключевые направления работы</h2>
            <p className={styles.sectionDescription}>
              Подбираем точные инструменты и технологии под задачи бизнеса — без избыточных функций
              и сложных внедрений.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <article key={service.id} className={styles.serviceCard}>
                <span className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionLabel}>Подход</p>
            <h2 className={styles.sectionTitle}>Как мы ведём проекты</h2>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.id} className={styles.processCard}>
                <span className={styles.processNumber}>{`0${step.id}`}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.advantagesSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionLabel}>Почему нас выбирают</p>
            <h2 className={styles.sectionTitle}>Преимущества работы с Горизонтом</h2>
          </div>
          <div className={styles.advantagesGrid}>
            <article className={styles.advCard}>
              <h3>Практический опыт</h3>
              <p>Эксперты из консалтинга и продуктовых компаний с реальными внедрениями в МСБ.</p>
            </article>
            <article className={styles.advCard}>
              <h3>Индивидуальный подход</h3>
              <p>Решения на основе потребностей бизнеса, а не только возможностей технологий.</p>
            </article>
            <article className={styles.advCard}>
              <h3>Прозрачная стратегия</h3>
              <p>Единая дорожная карта, бюджет, KPI и понятные этапы трансформации.</p>
            </article>
            <article className={styles.advCard}>
              <h3>Команда и обучение</h3>
              <p>Передаём компетенции, сопровождаем внедрения и поддерживаем команды.</p>
            </article>
            <article className={styles.advCard}>
              <h3>Интеграция решений</h3>
              <p>Соединяем CRM, ERP, BI и облачные сервисы в единую экосистему.</p>
            </article>
            <article className={styles.advCard}>
              <h3>Поддержка изменений</h3>
              <p>Помогаем адаптировать процессы и корпоративную культуру к новым инструментам.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.casesSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionLabel}>Последние проекты</p>
            <h2 className={styles.sectionTitle}>Кейсы цифровой трансформации</h2>
          </div>
          <div className={styles.casesGrid}>
            {casesData.map((caseItem) => (
              <article key={caseItem.id} className={styles.caseCard}>
                <img
                  src={caseItem.image}
                  alt={`Проект ${caseItem.title}`}
                  loading="lazy"
                />
                <div className={styles.caseContent}>
                  <h3>{caseItem.title}</h3>
                  <span className={styles.caseIndustry}>{caseItem.industry}</span>
                  <p>{caseItem.result}</p>
                  <Link to="/kejsy" className={styles.caseLink}>
                    Подробнее
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.moreCases}>
            <Link to="/kejsy" className="ghostButton">
              Смотреть все кейсы
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionLabel}>Портфолио решений</p>
            <h2 className={styles.sectionTitle}>Проекты по направлениям</h2>
          </div>
          <div className={styles.filterBar} role="tablist" aria-label="Фильтр проектов">
            {['Все', 'Продажи', 'Инфраструктура', 'Аналитика', 'Операции'].map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={activeCategory === category}
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterButtonActive : ''
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img
                  src={project.image}
                  alt={project.title}
                  loading="lazy"
                />
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection} aria-label="Отзывы клиентов">
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionLabel}>Обратная связь</p>
            <h2 className={styles.sectionTitle}>Что говорят клиенты</h2>
          </div>
          <div className={styles.testimonialSlider}>
            <button
              type="button"
              className={styles.sliderButton}
              onClick={handlePrevTestimonial}
              aria-label="Предыдущий отзыв"
            >
              ‹
            </button>
            <article className={styles.testimonialCard}>
              <img
                src={testimonialsData[currentTestimonial].image}
                alt={testimonialsData[currentTestimonial].name}
                loading="lazy"
              />
              <blockquote>
                {testimonialsData[currentTestimonial].quote}
              </blockquote>
              <div className={styles.testimonialMeta}>
                <strong>{testimonialsData[currentTestimonial].name}</strong>
                <span>{testimonialsData[currentTestimonial].role}</span>
              </div>
            </article>
            <button
              type="button"
              className={styles.sliderButton}
              onClick={handleNextTestimonial}
              aria-label="Следующий отзыв"
            >
              ›
            </button>
          </div>
        </div>
      </section>

      <section className={styles.teamSection} id="team">
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionLabel}>Команда</p>
            <h2 className={styles.sectionTitle}>Эксперты Горизонта</h2>
          </div>
          <div className={styles.teamGrid}>
            {teamData.map((member) => (
              <article key={member.id} className={styles.teamCard}>
                <img
                  src={member.image}
                  alt={`Фотография: ${member.name}`}
                  loading="lazy"
                />
                <div>
                  <h3>{member.name}</h3>
                  <span className={styles.teamRole}>{member.role}</span>
                  <p>{member.expertise}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionLabel}>Частые вопросы</p>
            <h2 className={styles.sectionTitle}>FAQ по цифровой трансформации</h2>
          </div>
          <div className={styles.faqAccordion}>
            {faqItems.map((item) => (
              <details key={item.id} className={styles.faqItem}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionLabel}>Актуальные материалы</p>
            <h2 className={styles.sectionTitle}>Блог Горизонта</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPreview.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <img
                  src={post.image}
                  alt={post.title}
                  loading="lazy"
                />
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/blog" className={styles.blogLink}>
                    Читать далее
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={`container ${styles.ctaContent}`}>
          <div>
            <h2>Готовы вывести ваш бизнес на новый уровень?</h2>
            <p>
              Расскажите о задачах — подготовим персональную сессию, где обсудим стратегию
              цифровизации и возможные сценарии роста.
            </p>
          </div>
          <form className={styles.ctaForm} onSubmit={handleCtaSubmit}>
            <label htmlFor="cta-email" className="visuallyHidden">
              Email для связи
            </label>
            <input
              id="cta-email"
              type="email"
              value={ctaEmail}
              onChange={(event) => setCtaEmail(event.target.value)}
              placeholder="Ваш email"
              required
            />
            <button type="submit">Отправить</button>
            {ctaMessage && <p className={styles.ctaMessage}>{ctaMessage}</p>}
          </form>
        </div>
      </section>
    </>
  );
};

export default HomePage;
```