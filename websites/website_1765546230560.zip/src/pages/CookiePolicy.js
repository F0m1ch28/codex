```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicyPage = () => {
  return (
    <>
      <Helmet>
        <title>Политика Cookie — Горизонт</title>
        <meta
          name="description"
          content="Политика использования файлов cookie на сайте Горизонта. Узнайте, как мы применяем cookie и как управлять ими."
        />
      </Helmet>

      <section className={styles.page}>
        <div className="container">
          <h1>Политика использования файлов Cookie</h1>
          <p className={styles.update}>Последнее обновление: 1 апреля 2024 года</p>

          <div className={styles.block}>
            <h2>1. Что такое Cookie</h2>
            <p>
              Cookie — это небольшие текстовые файлы, которые сохраняются на вашем устройстве при
              посещении сайта. Они помогают улучшать работу сайта и анализировать взаимодействие
              пользователей с ресурсом.
            </p>
          </div>

          <div className={styles.block}>
            <h2>2. Какие cookie мы используем</h2>
            <ul>
              <li>Технические cookie — обеспечивают корректное функционирование сайта.</li>
              <li>Аналитические cookie — позволяют понимать, как пользователи взаимодействуют с сайтом.</li>
              <li>Функциональные cookie — сохраняют пользовательские настройки и предпочтения.</li>
            </ul>
          </div>

          <div className={styles.block}>
            <h2>3. Управление cookie</h2>
            <p>
              Вы можете управлять cookie через настройки вашего браузера. Обратите внимание, что
              отключение cookie может повлиять на работу отдельных функций сайта.
            </p>
          </div>

          <div className={styles.block}>
            <h2>4. Контакты</h2>
            <p>
              По вопросам использования cookie, пожалуйста, свяжитесь с нами по адресу{' '}
              <a href="mailto:info@gorizont-consult.ru">info@gorizont-consult.ru</a>.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default CookiePolicyPage;
```