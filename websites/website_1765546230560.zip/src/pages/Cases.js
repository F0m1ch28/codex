```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Cases.module.css';

const cases = [
  {
    id: 1,
    company: 'RetailX',
    industry: 'Ритейл, Москва',
    challenge:
      'Разрозненные данные о клиентах, отсутствие единой системы продаж и прогнозирования спроса.',
    solution:
      'Внедрение CRM с омниканальной коммуникацией, интеграция с кассовыми системами и разработка BI-дашбордов по ассортименту.',
    result:
      'Рост конверсии повторных продаж на 22%, снижение времени обработки заказов на 30%, NPS +18 пунктов.',
    image: 'https://picsum.photos/900/600?random=221'
  },
  {
    id: 2,
    company: 'LogiChain',
    industry: 'Логистика, Московская область',
    challenge:
      'Большое количество ручных операций при планировании рейсов, нет прозрачности по SLA и загрузке автопарка.',
    solution:
      'RPA-боты для обработки заявок, единый центр мониторинга на базе облачной архитектуры и мобильное приложение для водителей.',
    result:
      'Сокращение операционных издержек на 24%, точность планирования отгрузок +28%, повышение соблюдения SLA до 96%.',
    image: 'https://picsum.photos/900/600?random=222'
  },
  {
    id: 3,
    company: 'FinNext',
    industry: 'Финансовые услуги, Москва',
    challenge:
      'Финансовая команда тратит много времени на подготовку отчётности, нет единого источника правды по данным.',
    solution:
      'Построение корпоративного хранилища данных, автоматизация ETL, внедрение управленческой аналитики и сценарного моделирования.',
    result:
      'Подготовка отчёта сокращена с 4 часов до 20 минут, доступ к показателям в режиме реального времени, управленческие решения стали прозрачнее.',
    image: 'https://picsum.photos/900/600?random=223'
  }
];

const CasesPage = () => {
  return (
    <>
      <Helmet>
        <title>Кейсы Горизонта — успешные проекты цифровой трансформации</title>
        <meta
          name="description"
          content="Реальные кейсы Горизонта: внедрение CRM, автоматизация процессов, бизнес-аналитика и облачные решения для компаний Москвы и области."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Кейсы и результаты клиентов</h1>
          <p>
            Мы показываем, как цифровая трансформация влияет на конкретные показатели. Каждый
            проект — это совместная работа с командой клиента и персонально подобранные решения.
          </p>
        </div>
      </section>

      <section className={styles.casesSection}>
        <div className="container">
          <div className={styles.casesGrid}>
            {cases.map((item) => (
              <article key={item.id} className={styles.caseCard}>
                <div className={styles.caseImage}>
                  <img src={item.image} alt={`Проект для компании ${item.company}`} loading="lazy" />
                </div>
                <div className={styles.caseContent}>
                  <h2>{item.company}</h2>
                  <span className={styles.industry}>{item.industry}</span>
                  <div className={styles.caseBlock}>
                    <h3>Задача</h3>
                    <p>{item.challenge}</p>
                  </div>
                  <div className={styles.caseBlock}>
                    <h3>Решение</h3>
                    <p>{item.solution}</p>
                  </div>
                  <div className={styles.caseBlock}>
                    <h3>Результат</h3>
                    <p>{item.result}</p>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default CasesPage;
```