```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contacts.module.css';

const ContactsPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    message: ''
  });
  const [statusMessage, setStatusMessage] = useState('');

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setStatusMessage('Пожалуйста, заполните обязательные поля.');
      return;
    }
    setStatusMessage(
      'Спасибо! Мы получили ваше сообщение и свяжемся с вами в течение одного рабочего дня.'
    );
    setFormData({
      name: '',
      company: '',
      email: '',
      message: ''
    });
  };

  return (
    <>
      <Helmet>
        <title>Контакты — Горизонт, цифровой консалтинг</title>
        <meta
          name="description"
          content="Свяжитесь с Горизонтом: консультация по цифровой трансформации, внедрению CRM, бизнес-аналитике и облачным решениям. Москва, Башня Федерация."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Свяжитесь с нами</h1>
          <p>
            Расскажите о задаче — предложим лучшие решения по цифровой трансформации и договоримся о
            консультации.
          </p>
        </div>
      </section>

      <section className={styles.contactsSection}>
        <div className="container">
          <div className={styles.contactsGrid}>
            <div className={styles.contactCard}>
              <h2>Контактные данные</h2>
              <p>
                <strong>Адрес:</strong> 123112, г. Москва, Пресненская наб., д. 12, офис 345 (БЦ
                &quot;Башня Федерация&quot;)
              </p>
              <p>
                <strong>Телефон:</strong>{' '}
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </p>
              <p>
                <strong>Email:</strong>{' '}
                <a href="mailto:info@gorizont-consult.ru">info@gorizont-consult.ru</a>
              </p>
              <p>
                <strong>Рабочие часы:</strong> Пн–Пт, 09:00–19:00
              </p>
            </div>
            <form className={styles.formCard} onSubmit={handleSubmit}>
              <h2>Отправить запрос</h2>
              <div className={styles.formGroup}>
                <label htmlFor="name">Имя *</label>
                <input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Введите ваше имя"
                  required
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="company">Компания</label>
                <input
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="Название компании"
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="email">Email *</label>
                <input
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  type="email"
                  placeholder="name@company.ru"
                  required
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="message">Сообщение *</label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows="4"
                  placeholder="Опишите задачу или интересующие услуги"
                  required
                />
              </div>
              <button type="submit" className="primaryButton">
                Отправить
              </button>
              {statusMessage && <p className={styles.status}>{statusMessage}</p>}
            </form>
          </div>
        </div>
      </section>

      <section className={styles.mapSection} aria-label="Карта офиса">
        <div className="container">
          <div className={styles.mapWrapper}>
            <iframe
              title="Офис Горизонта на карте"
              src="https://yandex.ru/map-widget/v1/?um=constructor%3Aaf5f18f67d390b03fd19d7c728687e50c0f6229a3d721d2c81a55b35c50a6484&amp;source=constructor"
              frameBorder="0"
              allowFullScreen
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactsPage;
```