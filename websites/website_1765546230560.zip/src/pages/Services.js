```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const serviceGroups = [
  {
    id: 1,
    title: 'Цифровая стратегия и аудит',
    description:
      'Помогаем понять, где бизнес находится сегодня, и формируем дорожную карту, которая соединяет бизнес-цели и технологии.',
    services: [
      'Диагностика процессов и оценка цифровой зрелости',
      'Разработка стратегии цифровой трансформации',
      'Построение карты инициатив и бизнес-кейса',
      'Проектирование архитектуры данных и ИТ-ландшафта'
    ],
    image: 'https://picsum.photos/800/600?random=211'
  },
  {
    id: 2,
    title: 'CRM и автоматизация клиентских процессов',
    description:
      'Повышаем прозрачность и управляемость воронки продаж и сервисных запросов, создаём единый центр коммуникации.',
    services: [
      'Подбор платформы и дизайн пользовательских сценариев',
      'Настройка воронок, интеграция каналов коммуникации',
      'Автоматизация договоров, документооборота и отчётности',
      'Обучение команд и поддержка запуска'
    ],
    image: 'https://picsum.photos/800/600?random=212'
  },
  {
    id: 3,
    title: 'Бизнес-аналитика и управление данными',
    description:
      'Делаем данные доступными и полезными: от построения модуля сбора до визуализации ключевых KPI и прогнозной аналитики.',
    services: [
      'Проектирование витрин данных и хранилищ',
      'Внедрение BI-платформ и интерактивных дашбордов',
      'Настройка системы KPI и alerts для руководителей',
      'Организация процессов data governance и качества данных'
    ],
    image: 'https://picsum.photos/800/600?random=213'
  },
  {
    id: 4,
    title: 'Облачные решения и инфраструктура',
    description:
      'Обеспечиваем гибкость и надёжность: строим облачную инфраструктуру, автоматизируем деплой и заботимся о безопасности.',
    services: [
      'Оценка готовности и план миграции в облако',
      'Настройка DevOps-пайплайна и CI/CD',
      'Построение систем мониторинга и резервирования',
      'Усиление информационной безопасности и compliance'
    ],
    image: 'https://picsum.photos/800/600?random=214'
  }
];

const ServicesPage = () => {
  return (
    <>
      <Helmet>
        <title>Услуги Горизонта — цифровая трансформация, CRM, аналитика, облака</title>
        <meta
          name="description"
          content="Комплексные услуги Горизонта: аудит процессов, внедрение CRM, построение бизнес-аналитики, миграция в облако и ИТ-консалтинг."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Комплекс услуг по цифровой трансформации</h1>
            <p>
              Мы берём на себя ключевые этапы — от диагностики процессов до запуска систем и
              сопровождения команд. Формат сотрудничества выбирается под задачи и ресурс команды
              заказчика.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          {serviceGroups.map((group, index) => (
            <article key={group.id} className={styles.serviceGroup}>
              <div
                className={`${styles.serviceImage} ${index % 2 === 1 ? styles.serviceImageRight : ''}`}
              >
                <img src={group.image} alt={group.title} loading="lazy" />
              </div>
              <div className={styles.serviceContent}>
                <h2>{group.title}</h2>
                <p>{group.description}</p>
                <ul>
                  {group.services.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.methodsSection}>
        <div className="container">
          <div className={styles.methodsGrid}>
            <article className={styles.methodCard}>
              <h3>Форматы сотрудничества</h3>
              <p>
                Проектные команды, коучинг внедрения, поддержка внутренних ИТ- и операционных
                подразделений, совместная работа с вашими подрядчиками.
              </p>
            </article>
            <article className={styles.methodCard}>
              <h3>Инструменты</h3>
              <p>
                Используем проверенные платформы и open-source решения. Подбираем инструменты,
                которые масштабируются и поддерживаются на рынке.
              </p>
            </article>
            <article className={styles.methodCard}>
              <h3>Контроль качества</h3>
              <p>
                Еженедельные статусы, прозрачные метрики прогресса, контроль бюджета и четкий
                бэклог задач в понятной системе.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;
```