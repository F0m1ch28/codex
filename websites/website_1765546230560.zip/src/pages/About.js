```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const milestones = [
  {
    year: '2012',
    title: 'Основание Горизонта',
    description:
      'Команда консультантов из крупных интеграторов объединилась, чтобы сосредоточиться на задачах малого и среднего бизнеса.'
  },
  {
    year: '2016',
    title: 'Практика управленческой аналитики',
    description:
      'Запустили направление BI и построения витрин данных, помогая руководителям принимать решения быстрее.'
  },
  {
    year: '2020',
    title: 'Облачная экспертиза',
    description:
      'Сформировали команду архитекторов, наладили партнёрства с ведущими облачными провайдерами и DevOps-практики.'
  },
  {
    year: '2023',
    title: 'Центр компетенций по цифровой трансформации',
    description:
      'Расширили портфель услуг: от диагностики процессной зрелости до поддержки изменений и обучения сотрудников.'
  }
];

const values = [
  {
    id: 1,
    title: 'Результат важнее технологии',
    description:
      'Технологии — инструмент. Реальный критерий успеха проекта — бизнес-эффект и удовлетворённость команды.'
  },
  {
    id: 2,
    title: 'Открытая коммуникация',
    description:
      'Мы строим честный диалог, объясняем риски и совместно находим оптимальные решения в условиях ограниченных ресурсов.'
  },
  {
    id: 3,
    title: 'Передача компетенций',
    description:
      'Не создаём зависимость от внешнего подрядчика: обучаем сотрудников, документируем процессы и сопровождаем адаптацию.'
  },
  {
    id: 4,
    title: 'Постоянное развитие',
    description:
      'Отслеживаем тренды ИТ, тестируем новые подходы и делимся практиками через блог, вебинары и внутренние лаборатории.'
  }
];

const partners = [
  'Облачные платформы: Selectel, VK Cloud, Yandex Cloud',
  'CRM и автоматизация: Bitrix24, Creatio, Microsoft Dynamics',
  'BI и аналитика: Power BI, Tableau, Qlik, Redash',
  'Инфраструктура и DevOps: Kubernetes, GitLab, Terraform'
];

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>О компании Горизонт — эксперты цифровой трансформации</title>
        <meta
          name="description"
          content="Познакомьтесь с командой Горизонта: опытные консультанты по цифровой трансформации, автоматизации процессов и управленческой аналитике."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div>
              <p className={styles.heroLabel}>О компании</p>
              <h1>Стратегический партнёр вашего цифрового роста</h1>
              <p>
                Мы создаём устойчивые цифровые экосистемы, где люди, процессы и технологии работают
                синхронно. Наша сила — сочетание консалтингового подхода и практического опыта
                внедрения решений.
              </p>
            </div>
            <div className={styles.heroFact}>
              <span>15+</span>
              <p>отраслей, где мы помогли бизнесу перейти на новые цифровые рельсы.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.missionSection}>
        <div className="container">
          <div className={styles.missionGrid}>
            <article className={styles.missionCard}>
              <h2>Наша миссия</h2>
              <p>
                Простыми словами объяснять сложные технологические решения и внедрять их так, чтобы
                люди видели реальный смысл и эффект для бизнеса. Мы делаем цифровую трансформацию
                понятной и достижимой для компаний любого масштаба.
              </p>
            </article>
            <article className={styles.missionCard}>
              <h2>Команда</h2>
              <p>
                В штате Горизонта 45 специалистов: бизнес-аналитики, архитекторы решений, project
                managerʼы, data scientists и методологи. Мы постоянно инвестируем в обучение и
                сертификацию, чтобы соответствовать вызовам рынка.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.timelineSection}>
        <div className="container">
          <h2 className={styles.sectionTitle}>Ключевые этапы развития</h2>
          <div className={styles.timeline}>
            {milestones.map((item) => (
              <div key={item.year} className={styles.timelineItem}>
                <div className={styles.timelineYear}>{item.year}</div>
                <div className={styles.timelineContent}>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.valuesSection}>
        <div className="container">
          <h2 className={styles.sectionTitle}>Что нас отличает</h2>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.id} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.partnersSection}>
        <div className="container">
          <div className={styles.partnersContent}>
            <h2>Технологические партнёры</h2>
            <ul>
              {partners.map((partner) => (
                <li key={partner}>{partner}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.cultureSection}>
        <div className="container">
          <div className={styles.cultureGrid}>
            <article className={styles.cultureCard}>
              <h2>Как мы работаем</h2>
              <ul>
                <li>Создаём гибкие команды проекта и делимся экспертизой с заказчиком.</li>
                <li>Планируем быстрые итерации: результат каждые 2–4 недели.</li>
                <li>Соблюдаем прозрачность бюджета и соблюдение сроков.</li>
                <li>Поддерживаем культуру обратной связи и совместного развития.</li>
              </ul>
            </article>
            <article className={styles.cultureCard}>
              <h2>Сообщество и обучение</h2>
              <p>
                Ежеквартально мы проводим открытые вебинары по вопросам цифровой трансформации,
                делимся аналитикой и исследованиями рынка. Следите за анонсами в нашем блоге и
                соцсетях.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;
```