```javascript
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import HomePage from './pages/Home';
import ServicesPage from './pages/Services';
import CasesPage from './pages/Cases';
import AboutPage from './pages/About';
import BlogPage from './pages/Blog';
import ContactsPage from './pages/Contacts';
import TermsPage from './pages/Terms';
import PrivacyPage from './pages/Privacy';
import CookiePolicyPage from './pages/CookiePolicy';

const App = () => {
  return (
    <>
      <ScrollToTop />
      <Header />
      <main className="mainContent" role="main">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/uslugi" element={<ServicesPage />} />
          <Route path="/kejsy" element={<CasesPage />} />
          <Route path="/o-kompanii" element={<AboutPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/kontakty" element={<ContactsPage />} />
          <Route path="/pravila-polzovaniya" element={<TermsPage />} />
          <Route path="/politika-konfidencialnosti" element={<PrivacyPage />} />
          <Route path="/politika-cookie" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </>
  );
};

export default App;
```