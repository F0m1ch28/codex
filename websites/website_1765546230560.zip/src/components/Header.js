```javascript
import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <header className={styles.header}>
      <div className={`container ${styles.headerInner}`}>
        <div className={styles.logoArea}>
          <NavLink to="/" className={styles.logo} aria-label="Логотип Горизонт">
            <span className={styles.logoMark}>Горизонт</span>
            <span className={styles.logoTagline}>Цифровая трансформация</span>
          </NavLink>
        </div>

        <button
          className={styles.menuButton}
          aria-label="Открыть главное меню"
          aria-expanded={isMenuOpen}
          onClick={() => setIsMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>

        <nav
          className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`}
          aria-label="Основная навигация"
        >
          <NavLink
            to="/"
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.activeNav}` : styles.navLink
            }
          >
            Главная
          </NavLink>
          <NavLink
            to="/uslugi"
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.activeNav}` : styles.navLink
            }
          >
            Услуги
          </NavLink>
          <NavLink
            to="/kejsy"
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.activeNav}` : styles.navLink
            }
          >
            Кейсы
          </NavLink>
          <NavLink
            to="/o-kompanii"
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.activeNav}` : styles.navLink
            }
          >
            О компании
          </NavLink>
          <NavLink
            to="/blog"
            className={({ isActive }) =>
              isActive ? `${styles.navLink} ${styles.activeNav}` : styles.navLink
            }
          >
            Блог
          </NavLink>
        </nav>

        <NavLink to="/kontakty" className={styles.contactButton}>
          Связаться
        </NavLink>
      </div>
    </header>
  );
};

export default Header;
```