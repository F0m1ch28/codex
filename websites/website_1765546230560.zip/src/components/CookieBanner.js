```javascript
import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'gorizont_cookie_consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 800);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem(COOKIE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о Cookie">
      <p className={styles.text}>
        Мы используем cookies для корректной работы сайта, персонализации и аналитики. Продолжая
        пользоваться сайтом, вы соглашаетесь с{' '}
        <a href="/politika-cookie" className={styles.link}>
          политикой использования Cookie
        </a>
        .
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Согласиться
      </button>
    </div>
  );
};

export default CookieBanner;
```