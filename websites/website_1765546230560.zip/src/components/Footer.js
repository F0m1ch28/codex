```javascript
import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={`container ${styles.footerInner}`}>
        <div className={styles.brandBlock}>
          <div className={styles.logo}>
            <span className={styles.logoMark}>Горизонт</span>
            <span className={styles.logoTagline}>Консалтинг цифровой трансформации</span>
          </div>
          <p className={styles.description}>
            Помогаем малому и среднему бизнесу Москвы и области выстраивать цифровую
            экосистему: от диагностики процессов до внедрения CRM, аналитики и облачных
            платформ.
          </p>
        </div>

        <div className={styles.linksBlock}>
          <h3 className={styles.blockTitle}>Навигация</h3>
          <ul className={styles.linkList}>
            <li>
              <NavLink to="/uslugi" className={styles.footerLink}>
                Услуги
              </NavLink>
            </li>
            <li>
              <NavLink to="/kejsy" className={styles.footerLink}>
                Кейсы
              </NavLink>
            </li>
            <li>
              <NavLink to="/o-kompanii" className={styles.footerLink}>
                О компании
              </NavLink>
            </li>
            <li>
              <NavLink to="/blog" className={styles.footerLink}>
                Блог
              </NavLink>
            </li>
            <li>
              <NavLink to="/kontakty" className={styles.footerLink}>
                Контакты
              </NavLink>
            </li>
          </ul>
        </div>

        <div className={styles.contactBlock}>
          <h3 className={styles.blockTitle}>Контакты</h3>
          <address className={styles.address}>
            <span>123112, г. Москва, Пресненская наб., д. 12, офис 345 (БЦ "Башня Федерация")</span>
            <a className={styles.phone} href="tel:+74951234567">
              +7 (495) 123-45-67
            </a>
            <a className={styles.email} href="mailto:info@gorizont-consult.ru">
              info@gorizont-consult.ru
            </a>
          </address>
        </div>

        <div className={styles.policyBlock}>
          <h3 className={styles.blockTitle}>Документы</h3>
          <ul className={styles.linkList}>
            <li>
              <NavLink to="/pravila-polzovaniya" className={styles.footerLink}>
                Правила пользования
              </NavLink>
            </li>
            <li>
              <NavLink to="/politika-konfidencialnosti" className={styles.footerLink}>
                Политика конфиденциальности
              </NavLink>
            </li>
            <li>
              <NavLink to="/politika-cookie" className={styles.footerLink}>
                Политика Cookie
              </NavLink>
            </li>
          </ul>
        </div>
      </div>

      <div className={styles.bottomLine}>
        <div className="container">
          <p>© {new Date().getFullYear()} Горизонт. Все права защищены.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
```