import React, { useEffect, useState } from "react";
import { NavLink, Link } from "react-router-dom";

const navLinks = [
  { path: "/", label: "Home" },
  { path: "/about", label: "About" },
  { path: "/services", label: "Services" },
  { path: "/contact", label: "Contact" },
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "auto";
    return () => {
      document.body.style.overflow = "auto";
    };
  }, [menuOpen]);

  const handleLinkClick = () => setMenuOpen(false);

  return (
    <header className={`site-header ${scrolled ? "site-header--scrolled" : ""}`}>
      <div className="container header-container">
        <div className="brand">
          <Link to="/" className="brand__link" onClick={handleLinkClick}>
            <span className="brand__mark">Aurora Dynamics</span>
            <span className="brand__tagline">Strategic Foresight Studio</span>
          </Link>
        </div>

        <nav
          className={`primary-nav ${menuOpen ? "primary-nav--open" : ""}`}
          aria-label="Main navigation"
        >
          <ul className="primary-nav__list">
            {navLinks.map((link) => (
              <li key={link.path} className="primary-nav__item">
                <NavLink
                  to={link.path}
                  className={({ isActive }) =>
                    `primary-nav__link ${isActive ? "is-active" : ""}`
                  }
                  onClick={handleLinkClick}
                  end={link.path === "/"}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <Link to="/contact" className="btn btn-primary nav-cta" onClick={handleLinkClick}>
            Start a Project
          </Link>
        </nav>

        <button
          className={`menu-toggle ${menuOpen ? "is-active" : ""}`}
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;