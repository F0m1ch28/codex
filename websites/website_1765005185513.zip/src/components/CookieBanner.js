import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem("aurora_cookie_consent");
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem("aurora_cookie_consent", "accepted");
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-banner__content">
        <h4>We respect your privacy</h4>
        <p>
          We use cookies to personalize content, enhance experience, and analyze traffic.
          By continuing to browse, you agree to our <a href="/privacy">Privacy Policy</a>.
        </p>
      </div>
      <button className="btn btn-primary cookie-banner__button" onClick={handleAccept}>
        Accept &amp; Continue
      </button>
    </div>
  );
};

export default CookieBanner;