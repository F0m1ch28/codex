import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <h3>Aurora Dynamics</h3>
          <p>
            We partner with ambitious teams to design intelligent strategies,
            craft differentiated experiences, and accelerate digital growth.
          </p>
          <Link to="/contact" className="btn btn-secondary footer-cta">
            Book a Consultation
          </Link>
        </div>
        <div className="footer-column">
          <h4>Company</h4>
          <ul>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/services">Services</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
            <li>
              <Link to="/terms">Terms of Service</Link>
            </li>
          </ul>
        </div>
        <div className="footer-column">
          <h4>Services</h4>
          <ul>
            <li>
              <Link to="/services#strategy">Strategic Advisory</Link>
            </li>
            <li>
              <Link to="/services#innovation">Innovation Roadmapping</Link>
            </li>
            <li>
              <Link to="/services#experience">Experience Design</Link>
            </li>
            <li>
              <Link to="/services#delivery">Digital Delivery</Link>
            </li>
          </ul>
        </div>
        <div className="footer-column">
          <h4>Contact</h4>
          <ul>
            <li>
              <a href="tel:+12125551234">+1 (212) 555-1234</a>
            </li>
            <li>
              <a href="mailto:hello@auroradynamics.com">hello@auroradynamics.com</a>
            </li>
            <li>
              458 Innovation Way, Suite 12<br />
              New York, NY 10001
            </li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {year} Aurora Dynamics. All rights reserved.</p>
        <div className="footer-socials">
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
            LinkedIn
          </a>
          <a href="https://twitter.com" target="_blank" rel="noreferrer">
            X/Twitter
          </a>
          <a href="https://dribbble.com" target="_blank" rel="noreferrer">
            Dribbble
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;