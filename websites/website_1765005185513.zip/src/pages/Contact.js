import React, { useState } from "react";

const initialFormState = {
  name: "",
  email: "",
  company: "",
  message: "",
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please enter your name.";
    if (!formData.company.trim()) newErrors.company = "Please specify your company.";
    if (!formData.email.trim()) {
      newErrors.email = "Please enter a valid email.";
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/.test(formData.email)) {
      newErrors.email = "The email address looks incorrect.";
    }
    if (!formData.message.trim()) newErrors.message = "Let us know how we can help.";
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData(initialFormState);
    }
  };

  return (
    <div className="contact-page">
      <section className="section contact-hero">
        <div className="container split-layout">
          <div>
            <p className="eyebrow">Contact</p>
            <h1>Let’s shape what’s next, together.</h1>
            <p>
              Share your goals, challenges, or boldest ideas. Our team will respond within one
              business day to explore how we can help you move forward with confidence.
            </p>
            <div className="contact-details">
              <div>
                <h4>Visit</h4>
                <p>
                  458 Innovation Way, Suite 12
                  <br />
                  New York, NY 10001
                </p>
              </div>
              <div>
                <h4>Call</h4>
                <a href="tel:+12125551234">+1 (212) 555-1234</a>
              </div>
              <div>
                <h4>Email</h4>
                <a href="mailto:hello@auroradynamics.com">hello@auroradynamics.com</a>
              </div>
            </div>
          </div>
          <div className="contact-card">
            <form onSubmit={handleSubmit} noValidate>
              <div className="form-group">
                <label htmlFor="name">Full name</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Jane Doe"
                />
                {errors.name && <span className="form-error">{errors.name}</span>}
              </div>
              <div className="form-group">
                <label htmlFor="email">Work email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="jane@company.com"
                />
                {errors.email && <span className="form-error">{errors.email}</span>}
              </div>
              <div className="form-group">
                <label htmlFor="company">Company</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="Company name"
                />
                {errors.company && <span className="form-error">{errors.company}</span>}
              </div>
              <div className="form-group">
                <label htmlFor="message">How can we help?</label>
                <textarea
                  id="message"
                  name="message"
                  rows="4"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Tell us about your project, timeline, and goals."
                />
                {errors.message && <span className="form-error">{errors.message}</span>}
              </div>
              <button type="submit" className="btn btn-primary">
                Submit Message
              </button>
              {submitted && (
                <div className="form-success">
                  Thank you! We’ve received your message and will reach out shortly.
                </div>
              )}
            </form>
          </div>
        </div>
      </section>

      <section className="section contact-support">
        <div className="container">
          <div className="section-heading">
            <h2>Additional ways to engage</h2>
            <p>
              Not ready for a project yet? Connect with our specialists through events and thought
              leadership.
            </p>
          </div>
          <div className="support-grid">
            <article className="support-card">
              <h3>Executive Briefings</h3>
              <p>Private sessions tailored to your leadership team’s strategic priorities.</p>
              <a className="btn btn-secondary" href="/services">
                Request a briefing
              </a>
            </article>
            <article className="support-card">
              <h3>Innovation Workshops</h3>
              <p>Facilitated design sprints to explore new opportunities and build alignment.</p>
              <a className="btn btn-secondary" href="/services">
                View workshop formats
              </a>
            </article>
            <article className="support-card">
              <h3>Research &amp; Insights</h3>
              <p>Subscribe to receive quarterly trend reports and perspective pieces.</p>
              <a className="btn btn-secondary" href="/services">
                Join the list
              </a>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;