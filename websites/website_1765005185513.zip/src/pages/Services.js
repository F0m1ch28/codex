import React, { useState } from "react";

const servicesDetails = [
  {
    id: "strategy",
    title: "Strategic Intelligence & Advisory",
    summary:
      "Navigate complexity with clarity using our adaptive strategy frameworks and signal monitoring.",
    bullets: [
      "Executive visioning and opportunity framing",
      "Scenario planning and risk modeling",
      "Customer, market, and competitor intelligence",
      "Transformation governance and OKR design",
    ],
  },
  {
    id: "innovation",
    title: "Innovation Orchestration",
    summary:
      "Build repeatable innovation capabilities that unite cross-functional teams around measurable outcomes.",
    bullets: [
      "Innovation operating model design",
      "Capability assessments and playbooks",
      "Experiment design and rapid validation",
      "Venture building and launch support",
    ],
  },
  {
    id: "experience",
    title: "Experience & Service Design",
    summary:
      "Craft frictionless, human-centered experiences across channels with deep research and design systems.",
    bullets: [
      "Experience strategy and service blueprints",
      "Design research and customer insights",
      "Product and service prototyping",
      "Design systems and accessibility frameworks",
    ],
  },
  {
    id: "delivery",
    title: "Digital Delivery & Engineering",
    summary:
      "Launch resilient products and platforms leveraging composable architectures, automation, and data intelligence.",
    bullets: [
      "Product roadmapping and backlog acceleration",
      "Full-stack engineering and integration",
      "Automation, AI, and data platform development",
      "Quality assurance and DevSecOps enablement",
    ],
  },
];

const Services = () => {
  const [activeService, setActiveService] = useState(servicesDetails[0].id);

  return (
    <div className="services-page">
      <section className="section services-hero">
        <div className="container split-layout">
          <div>
            <p className="eyebrow">Services</p>
            <h1>Integrated capabilities engineered for velocity and confidence.</h1>
            <p>
              We connect strategy to execution through multidisciplinary squads. Each engagement is
              tailored to the realities of your organization, your customers, and your growth goals.
            </p>
          </div>
          <div className="services-hero__media">
            <img
              src="https://picsum.photos/800/600?random=204"
              alt="Consultants collaborating on digital roadmap"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="section services-tabs">
        <div className="container">
          <div className="service-tabs">
            {servicesDetails.map((service) => (
              <button
                key={service.id}
                className={`service-tab ${activeService === service.id ? "is-active" : ""}`}
                onClick={() => setActiveService(service.id)}
              >
                {service.title}
              </button>
            ))}
          </div>
          <div className="service-panels">
            {servicesDetails.map((service) => (
              <div
                key={service.id}
                className={`service-panel ${activeService === service.id ? "is-visible" : ""}`}
                id={service.id}
              >
                <h2>{service.title}</h2>
                <p>{service.summary}</p>
                <ul>
                  {service.bullets.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
                <a href="/contact" className="btn btn-primary">
                  Discuss this service
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section services-outcomes">
        <div className="container">
          <div className="section-heading">
            <h2>Proven outcomes</h2>
            <p>
              From healthcare to fintech to climate tech, we help teams achieve ambitious goals with
              precision and confidence.
            </p>
          </div>
          <div className="outcome-grid">
            <article className="outcome-card">
              <h3>+38% Net Promoter Score</h3>
              <p>
                Redefined patient journeys for a leading health network, integrating digital touchpoints
                with in-person care.
              </p>
            </article>
            <article className="outcome-card">
              <h3>4x Faster Launch</h3>
              <p>
                Implemented agile delivery pods for a global insurer, shrinking product release cycles
                from 16 weeks to 4.
              </p>
            </article>
            <article className="outcome-card">
              <h3>$72M New Revenue</h3>
              <p>
                Built a greenfield platform for a clean energy provider, unlocking new subscription
                business models.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className="section services-cta">
        <div className="container cta-panel">
          <div>
            <h2>Design your engagement</h2>
            <p>
              Tell us about your challenge. We’ll assemble the right leaders, craft a tailored
              engagement, and move fast to deliver value.
            </p>
          </div>
          <div className="cta-actions">
            <a className="btn btn-primary" href="/contact">
              Start a Conversation
            </a>
            <a className="btn btn-secondary" href="/about">
              Meet the Team
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;