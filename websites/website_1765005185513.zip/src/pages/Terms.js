import React from "react";

const Terms = () => {
  return (
    <div className="legal-page">
      <section className="section legal-hero">
        <div className="container">
          <h1>Terms of Service</h1>
          <p>Effective date: May 1, 2024</p>
        </div>
      </section>

      <section className="section legal-content">
        <div className="container legal-richtext">
          <h2>1. Acceptance of Terms</h2>
          <p>
            By accessing or using the Aurora Dynamics website, products, or services, you agree to be
            bound by these Terms of Service. If you do not agree, please refrain from using our site or
            services.
          </p>

          <h2>2. Services</h2>
          <p>
            Aurora Dynamics provides strategic advisory, design, and digital delivery services. The scope
            of each engagement is defined within a mutually executed Statement of Work (SOW).
          </p>

          <h2>3. Intellectual Property</h2>
          <p>
            All content, trademarks, and materials on this website are property of Aurora Dynamics or our
            partners and are protected by applicable intellectual property laws. You may not use, copy, or
            distribute any content without prior written consent.
          </p>

          <h2>4. Confidentiality</h2>
          <p>
            Both parties agree to maintain the confidentiality of proprietary information shared during
            the course of an engagement. Confidential information shall not be disclosed to third parties
            without prior consent unless required by law.
          </p>

          <h2>5. Limitation of Liability</h2>
          <p>
            To the fullest extent permitted by law, Aurora Dynamics shall not be liable for any indirect,
            incidental, special, or consequential damages arising from or in connection with our services
            or this website.
          </p>

          <h2>6. Governing Law</h2>
          <p>
            These Terms of Service shall be governed by the laws of the State of New York without regard
            to its conflict of law provisions.
          </p>

          <h2>7. Updates to Terms</h2>
          <p>
            We may update these terms periodically. Continued use of our services after changes become
            effective constitutes acceptance of the revised terms.
          </p>

          <h2>Contact</h2>
          <p>
            For questions regarding these Terms of Service, please contact{" "}
            <a href="mailto:legal@auroradynamics.com">legal@auroradynamics.com</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Terms;