import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const statsData = [
  { label: "Projects Delivered", value: 240, suffix: "+" },
  { label: "Client Satisfaction", value: 98, suffix: "%" },
  { label: "Revenue Unlocked", value: 120, suffix: "M" },
  { label: "Innovation Sprints", value: 36, suffix: "" },
];

const servicesData = [
  {
    title: "Strategic Intelligence",
    description:
      "Scenario planning, market mapping, and strategic roadmaps to future-proof your organization.",
    icon: "🧭",
  },
  {
    title: "Experience Design",
    description:
      "Human-centered service and product design that transforms complex ideas into intuitive journeys.",
    icon: "✨",
  },
  {
    title: "Product Acceleration",
    description:
      "Cross-functional squads delivering validated digital solutions from MVP to enterprise scale.",
    icon: "⚡",
  },
  {
    title: "Innovation Enablement",
    description:
      "Capability building, playbooks, and governance models to fuel sustainable innovation.",
    icon: "🚀",
  },
];

const processSteps = [
  {
    title: "Discover",
    description: "Immersive research, stakeholder interviews, and value mapping to define opportunity.",
  },
  {
    title: "Design",
    description: "Experience architecture, prototyping, and co-creation to align teams and customers.",
  },
  {
    title: "Develop",
    description: "Iterative build, technical integration, and validation powered by agile delivery.",
  },
  {
    title: "Scale",
    description: "Growth experiments, optimization, and enablement to drive adoption and ROI.",
  },
];

const testimonialsData = [
  {
    quote:
      "Aurora Dynamics empowered our global transformation with clarity and measurable outcomes. The team felt like an extension of our own.",
    name: "Maya Chen",
    role: "Chief Digital Officer, Horizon Health",
    image: "https://picsum.photos/200/200?random=601",
  },
  {
    quote:
      "Their ability to translate complex data into actionable strategy is unmatched. We launched in half the time we expected.",
    name: "Ethan Ward",
    role: "VP of Product, Nova Financial",
    image: "https://picsum.photos/200/200?random=602",
  },
  {
    quote:
      "From concept to launch, the Aurora team delivered with precision, empathy, and an unwavering commitment to quality.",
    name: "Priya Desai",
    role: "Founder, Lumen Mobility",
    image: "https://picsum.photos/200/200?random=603",
  },
];

const teamMembers = [
  {
    name: "Isabella Moore",
    role: "Managing Partner",
    bio: "Leads strategic transformation initiatives and executive alignment for enterprise clients.",
    image: "https://picsum.photos/400/400?random=301",
  },
  {
    name: "Marcus Reed",
    role: "Director of Experience Design",
    bio: "Designs intuitive, future-ready customer experiences informed by deep research insights.",
    image: "https://picsum.photos/400/400?random=302",
  },
  {
    name: "Leila Ahmed",
    role: "Head of Innovation",
    bio: "Champions rapid experimentation and capability building programs across industries.",
    image: "https://picsum.photos/400/400?random=303",
  },
  {
    name: "Jonas Patel",
    role: "Engineering Lead",
    bio: "Architects scalable digital platforms with resilient, high-performing technology stacks.",
    image: "https://picsum.photos/400/400?random=304",
  },
];

const projectData = [
  {
    title: "Regenerative Commerce Platform",
    category: "Strategy",
    description: "Built a circularity marketplace enabling traceability across 1.4M products.",
    image: "https://picsum.photos/1200/800?random=401",
  },
  {
    title: "Immersive Patient Journey",
    category: "Experience",
    description: "Unified telehealth ecosystem with 35% increase in patient satisfaction.",
    image: "https://picsum.photos/1200/800?random=402",
  },
  {
    title: "AI Operations Command",
    category: "Engineering",
    description: "Automated mission-critical workflows, saving 12k hours annually.",
    image: "https://picsum.photos/1200/800?random=403",
  },
  {
    title: "Sustainability Intelligence Hub",
    category: "Strategy",
    description: "Data platform aligning ESG strategy with investment performance metrics.",
    image: "https://picsum.photos/1200/800?random=404",
  },
  {
    title: "Enterprise Design System",
    category: "Experience",
    description: "Multi-brand design system accelerating product delivery by 48%.",
    image: "https://picsum.photos/1200/800?random=405",
  },
  {
    title: "Digital Claims Modernization",
    category: "Engineering",
    description: "Cloud-native claims platform reducing cycle time from 21 to 6 days.",
    image: "https://picsum.photos/1200/800?random=406",
  },
];

const faqData = [
  {
    question: "How do you tailor engagements for different industries?",
    answer:
      "We begin with a discovery sprint that maps industry forces, customer behavior, and organizational capability. This allows us to tailor our frameworks and assemble the right cross-functional squad for each engagement.",
  },
  {
    question: "Can you work alongside our internal teams?",
    answer:
      "Absolutely. We embed with your teams, establish shared rituals, and co-create the roadmap to ensure knowledge transfer and sustainable change.",
  },
  {
    question: "What is your typical project timeline?",
    answer:
      "Strategy engagements run 6–10 weeks, while end-to-end product delivery averages 12–24 weeks depending on complexity. We move in agile increments to deliver value early and often.",
  },
  {
    question: "Do you offer post-launch support?",
    answer:
      "Yes. We provide managed optimization, capability upskilling, and long-term strategic advisory to ensure continued growth and performance.",
  },
];

const blogPosts = [
  {
    title: "Designing for Intelligent Ecosystems",
    excerpt: "How to orchestrate connected experiences that anticipate needs and deliver measurable impact.",
    image: "https://picsum.photos/800/600?random=501",
    date: "April 12, 2024",
  },
  {
    title: "AI Governance Principles for Product Leaders",
    excerpt: "Build trust, transparency, and accountability into every intelligent experience you launch.",
    image: "https://picsum.photos/800/600?random=502",
    date: "March 27, 2024",
  },
  {
    title: "Scaling Innovation Without Losing Momentum",
    excerpt: "Operational frameworks to maintain creativity while keeping teams aligned on outcomes.",
    image: "https://picsum.photos/800/600?random=503",
    date: "February 18, 2024",
  },
];

const Home = () => {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState("All");
  const [activeFaqIndex, setActiveFaqIndex] = useState(null);

  useEffect(() => {
    const totalSteps = 60;
    const interval = setInterval(() => {
      setCounters((prev) => {
        const updated = prev.map((value, index) => {
          const target = statsData[index].value;
          if (value >= target) return target;
          return Math.min(value + Math.ceil(target / totalSteps), target);
        });
        if (updated.every((val, idx) => val === statsData[idx].value)) {
          clearInterval(interval);
        }
        return updated;
      });
    }, 40);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    projectFilter === "All"
      ? projectData
      : projectData.filter((project) => project.category === projectFilter);

  const handleFaqToggle = (index) => {
    setActiveFaqIndex((prev) => (prev === index ? null : index));
  };

  return (
    <div className="home-page">
      <section className="hero" id="hero">
        <div
          className="hero__media"
          style={{
            backgroundImage: "url('https://picsum.photos/1600/900?random=101')",
          }}
        >
          <span className="hero__overlay" />
        </div>
        <div className="container hero__content">
          <p className="eyebrow">Strategic Innovation Studio</p>
          <h1>
            Architecting intelligent experiences for the next generation of digital leaders.
          </h1>
          <p className="hero__subtitle">
            We integrate strategy, design, and engineering to accelerate transformation across
            regulated industries, emerging ventures, and mission-critical organizations.
          </p>
          <div className="hero__actions">
            <Link to="/contact" className="btn btn-primary">
              Book a Consultation
            </Link>
            <a href="#services" className="btn btn-text">
              Explore Services
            </a>
          </div>
          <div className="hero__confidence">
            <span>Trusted by category leaders in health, finance, and climate.</span>
          </div>
        </div>
      </section>

      <section className="section stats">
        <div className="container">
          <div className="section-heading">
            <h2>Impact you can measure</h2>
            <p>
              High-performing organizations partner with Aurora to unlock measurable growth,
              orchestrate resilient operations, and shape differentiated customer journeys.
            </p>
          </div>
          <div className="stats-grid">
            {statsData.map((stat, index) => (
              <article className="stat-card" key={stat.label}>
                <span className="stat-card__value">
                  {counters[index]}
                  {stat.suffix}
                </span>
                <p className="stat-card__label">{stat.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section services" id="services">
        <div className="container">
          <div className="section-heading">
            <h2>Services engineered for momentum</h2>
            <p>
              Modular engagements designed to plug into your roadmap, accelerate delivery, and
              build enduring capability across your teams.
            </p>
          </div>
          <div className="services-grid">
            {servicesData.map((service) => (
              <article className="service-card" key={service.title}>
                <div className="service-card__icon" aria-hidden="true">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className="service-card__link">
                  Discover how
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section process">
        <div className="container">
          <div className="section-heading">
            <h2>Clarity at every step</h2>
            <p>
              Our integrated workflow ensures alignment, velocity, and accountability from the first
              workshop to enterprise-scale implementation.
            </p>
          </div>
          <div className="process-steps">
            {processSteps.map((step, index) => (
              <div className="process-step" key={step.title}>
                <span className="process-step__number">{index + 1}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section testimonials">
        <div className="container">
          <div className="section-heading">
            <h2>What leaders are saying</h2>
            <p>
              Collaborative partnerships grounded in transparency, creativity, and a relentless focus
              on value creation.
            </p>
          </div>
          <div className="testimonial-card">
            <button
              className="testimonial-nav testimonial-nav--prev"
              onClick={() =>
                setCurrentTestimonial((prev) =>
                  prev === 0 ? testimonialsData.length - 1 : prev - 1
                )
              }
              aria-label="Previous testimonial"
            >
              ←
            </button>
            <div className="testimonial-content">
              <img
                src={testimonialsData[currentTestimonial].image}
                alt={`${testimonialsData[currentTestimonial].name} portrait`}
                loading="lazy"
              />
              <blockquote>
                “{testimonialsData[currentTestimonial].quote}”
              </blockquote>
              <p className="testimonial-author">
                {testimonialsData[currentTestimonial].name}
                <span>{testimonialsData[currentTestimonial].role}</span>
              </p>
            </div>
            <button
              className="testimonial-nav testimonial-nav--next"
              onClick={() =>
                setCurrentTestimonial((prev) => (prev + 1) % testimonialsData.length)
              }
              aria-label="Next testimonial"
            >
              →
            </button>
          </div>
          <div className="testimonial-dots" role="tablist">
            {testimonialsData.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentTestimonial(index)}
                className={`testimonial-dot ${currentTestimonial === index ? "is-active" : ""}`}
                aria-label={`View testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section team">
        <div className="container">
          <div className="section-heading">
            <h2>The specialists behind your success</h2>
            <p>
              Strategy leads, designers, engineers, and data scientists unified by a shared mindset:
              outcomes over output.
            </p>
          </div>
          <div className="team-grid">
            {teamMembers.map((member) => (
              <article className="team-card" key={member.name}>
                <div className="team-card__image">
                  <img src={member.image} alt={`${member.name} headshot`} loading="lazy" />
                </div>
                <div className="team-card__content">
                  <h3>{member.name}</h3>
                  <p className="team-card__role">{member.role}</p>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section projects" id="projects">
        <div className="container">
          <div className="section-heading">
            <h2>Featured engagements</h2>
            <p>
              We thrive at the intersection of regulation, complexity, and innovation—delivering
              resilient platforms and experiences.
            </p>
          </div>
          <div className="project-filters">
            {["All", "Strategy", "Experience", "Engineering"].map((filter) => (
              <button
                key={filter}
                className={`filter-pill ${projectFilter === filter ? "is-active" : ""}`}
                onClick={() => setProjectFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className="projects-grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.title}>
                <div className="project-card__media">
                  <img src={project.image} alt={`${project.title} project preview`} loading="lazy" />
                </div>
                <div className="project-card__content">
                  <span className="project-card__category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/contact" className="project-card__link">
                    Request case study →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section faq">
        <div className="container">
          <div className="section-heading">
            <h2>Answers to common questions</h2>
            <p>
              If you need more clarity, our consultants are ready to discuss how Aurora can support
              your next initiative.
            </p>
          </div>
          <div className="faq-accordion">
            {faqData.map((faq, index) => (
              <div
                className={`faq-item ${activeFaqIndex === index ? "is-open" : ""}`}
                key={faq.question}
              >
                <button className="faq-question" onClick={() => handleFaqToggle(index)}>
                  <span>{faq.question}</span>
                  <span className="faq-icon">{activeFaqIndex === index ? "−" : "+"}</span>
                </button>
                <div className="faq-answer">
                  <p>{faq.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section blog-preview">
        <div className="container">
          <div className="section-heading">
            <h2>Insights &amp; perspectives</h2>
            <p>
              Explore fresh thinking on strategic foresight, intelligent operations, and designing
              for the future of work.
            </p>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.title}>
                <div className="blog-card__media">
                  <img src={post.image} alt={`${post.title} cover`} loading="lazy" />
                </div>
                <div className="blog-card__content">
                  <span className="blog-card__date">{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/services" className="blog-card__link">
                    Read the insight →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section cta">
        <div className="container cta-panel">
          <div>
            <h2>Let’s design your next strategic advantage</h2>
            <p>
              Schedule a working session with our team to unpack your ambitions, define success
              metrics, and co-create a path forward.
            </p>
          </div>
          <div className="cta-actions">
            <Link to="/contact" className="btn btn-primary">
              Schedule a Call
            </Link>
            <Link to="/services" className="btn btn-secondary">
              Explore Services
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;