import React from "react";

const About = () => {
  const values = [
    {
      title: "Outcome Obsessed",
      description:
        "We anchor every engagement in measurable business impact, blending evidence with experimentation.",
    },
    {
      title: "Co-Creation First",
      description:
        "Your teams are integral partners. We embed, share playbooks, and upskill to ensure sustainable change.",
    },
    {
      title: "Future Ready",
      description:
        "We scan horizon trends, evaluate emerging technologies, and translate signals into strategic action.",
    },
  ];

  const milestones = [
    {
      year: "2017",
      detail: "Aurora Dynamics founded to bridge strategic advisory and delivery excellence.",
    },
    {
      year: "2019",
      detail: "Launched our Innovation Operating System now used by 26 enterprises globally.",
    },
    {
      year: "2021",
      detail: "Expanded multidisciplinary studio with experience design and data science practices.",
    },
    {
      year: "2023",
      detail: "Recognized as a top boutique consultancy for complex digital transformation.",
    },
  ];

  return (
    <div className="about-page">
      <section className="section about-hero">
        <div className="container split-layout">
          <div>
            <p className="eyebrow">About Aurora Dynamics</p>
            <h1>We orchestrate clarity, momentum, and growth for visionary teams.</h1>
            <p>
              Aurora Dynamics was founded by strategists, designers, and technologists united by a
              belief that the most ambitious organizations deserve partners who can see around the
              corner. Today, we operate as an interdisciplinary studio solving for the moments when
              innovation, regulation, and customer expectation converge.
            </p>
          </div>
          <div className="about-highlight">
            <div className="about-highlight__card">
              <span>Global team distributed across 6 hubs with a shared mission: unlock tomorrow.</span>
            </div>
            <img
              src="https://picsum.photos/800/600?random=202"
              alt="Aurora Dynamics consultants collaborating in a modern workspace"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="section about-values">
        <div className="container">
          <div className="section-heading">
            <h2>Guiding principles</h2>
            <p>
              Our values shape how we show up, how we collaborate, and how we deliver results for
              the partners who trust us with their biggest challenges.
            </p>
          </div>
          <div className="values-grid">
            {values.map((value) => (
              <article className="value-card" key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section about-mission">
        <div className="container split-layout">
          <div className="mission-statement">
            <h2>Our mission</h2>
            <p>
              To accelerate the ideas that make industries more resilient, more equitable, and more
              human. We partner with leaders to turn strategic ambition into operational momentum,
              blending foresight with the craft of building transformative experiences.
            </p>
          </div>
          <div className="mission-timeline">
            <h3>Milestones</h3>
            <ul>
              {milestones.map((milestone) => (
                <li key={milestone.year}>
                  <span>{milestone.year}</span>
                  <p>{milestone.detail}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="section about-team">
        <div className="container">
          <div className="section-heading">
            <h2>Leadership</h2>
            <p>
              Our leadership team blends enterprise transformation expertise with entrepreneurial
              momentum and hands-on product delivery experience.
            </p>
          </div>
          <div className="leadership-grid">
            <article className="leadership-card">
              <img
                src="https://picsum.photos/400/400?random=305"
                alt="Portrait of Ava Serrano"
                loading="lazy"
              />
              <div>
                <h3>Ava Serrano</h3>
                <p className="leadership-role">Founder &amp; CEO</p>
                <p>
                  15+ years crafting digital ventures and transformation programs for Fortune 100
                  companies. Advocate for ethical innovation and inclusive design.
                </p>
              </div>
            </article>
            <article className="leadership-card">
              <img
                src="https://picsum.photos/400/400?random=306"
                alt="Portrait of Daniel Laurent"
                loading="lazy"
              />
              <div>
                <h3>Daniel Laurent</h3>
                <p className="leadership-role">Chief Strategy Officer</p>
                <p>
                  Leads enterprise strategy engagements, blending systems thinking with pragmatic
                  execution playbooks across global organizations.
                </p>
              </div>
            </article>
            <article className="leadership-card">
              <img
                src="https://picsum.photos/400/400?random=307"
                alt="Portrait of Nia Francis"
                loading="lazy"
              />
              <div>
                <h3>Nia Francis</h3>
                <p className="leadership-role">Chief Experience Officer</p>
                <p>
                  Award-winning design leader focused on accessible, data-driven product experiences
                  that move key metrics and delight users.
                </p>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className="section about-cta">
        <div className="container cta-panel">
          <div>
            <h2>Ready to write your next chapter?</h2>
            <p>
              We collaborate with leaders who are ready to think bigger, move faster, and transform
              their industries for the better. Let’s build something exceptional together.
            </p>
          </div>
          <div className="cta-actions">
            <a className="btn btn-primary" href="/contact">
              Connect with Us
            </a>
            <a className="btn btn-secondary" href="/services">
              View Capabilities
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;