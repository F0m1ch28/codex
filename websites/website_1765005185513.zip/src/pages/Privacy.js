import React from "react";

const Privacy = () => {
  return (
    <div className="legal-page">
      <section className="section legal-hero">
        <div className="container">
          <h1>Privacy Policy</h1>
          <p>Effective date: May 1, 2024</p>
        </div>
      </section>

      <section className="section legal-content">
        <div className="container legal-richtext">
          <h2>1. Overview</h2>
          <p>
            Aurora Dynamics respects your privacy. This policy explains how we collect, use, and protect
            personal information when you interact with our website and services.
          </p>

          <h2>2. Information We Collect</h2>
          <p>
            We collect information you provide directly, such as contact details submitted through
            forms, and information collected automatically, including browser type and usage data.
          </p>

          <h2>3. Use of Information</h2>
          <p>
            We use your information to respond to inquiries, deliver requested services, improve user
            experience, and share relevant insights or updates with your consent.
          </p>

          <h2>4. Cookies</h2>
          <p>
            We use cookies and similar technologies to personalize your experience and analyze website
            performance. You may adjust your browser settings to refuse cookies; however, this may limit
            site functionality.
          </p>

          <h2>5. Data Sharing</h2>
          <p>
            We do not sell personal data. We may share information with trusted service providers who
            assist us in operating our business, provided they adhere to strict confidentiality
            obligations.
          </p>

          <h2>6. Data Security</h2>
          <p>
            We implement administrative, technical, and physical safeguards to protect your information.
            While we strive to secure your data, no transmission is 100% secure.
          </p>

          <h2>7. Your Rights</h2>
          <p>
            Depending on your jurisdiction, you may have rights to access, correct, or delete your
            personal data. To exercise these rights, contact{" "}
            <a href="mailto:privacy@auroradynamics.com">privacy@auroradynamics.com</a>.
          </p>

          <h2>8. Policy Updates</h2>
          <p>
            We may update this Privacy Policy periodically. We encourage you to review this page to stay
            informed about our data practices.
          </p>

          <h2>Contact</h2>
          <p>
            Questions about this policy can be directed to{" "}
            <a href="mailto:privacy@auroradynamics.com">privacy@auroradynamics.com</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;