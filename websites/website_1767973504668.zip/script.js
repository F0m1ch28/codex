document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('nav');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('open');
            navToggle.classList.toggle('active');
        });
        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('open');
                navToggle.classList.remove('active');
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const cookieButtons = cookieBanner.querySelectorAll('.cookie-actions a');
        const cookieStatus = localStorage.getItem('cpo-cookie-choice');
        if (cookieStatus) {
            cookieBanner.classList.add('hidden');
        }
        cookieButtons.forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const action = button.dataset.action;
                localStorage.setItem('cpo-cookie-choice', action);
                cookieBanner.classList.add('hidden');
                window.open('cookies.html', '_blank', 'noopener');
            });
        });
    }

    const yearHolder = document.getElementById('current-year');
    if (yearHolder) {
        yearHolder.textContent = new Date().getFullYear();
    }

    const postsGrid = document.querySelector('[data-posts-grid]');
    if (postsGrid) {
        const filterChips = document.querySelectorAll('.filter-chip');
        const searchInput = document.querySelector('#posts-search');
        const postCards = postsGrid.querySelectorAll('[data-category]');

        const applyFilters = () => {
            const activeCategoryChip = document.querySelector('.filter-chip.active');
            const activeCategory = activeCategoryChip ? activeCategoryChip.dataset.category : 'all';
            const query = searchInput ? searchInput.value.trim().toLowerCase() : '';

            postCards.forEach(card => {
                const cardCategory = card.dataset.category;
                const title = card.querySelector('.card-title') ? card.querySelector('.card-title').textContent.toLowerCase() : '';
                const excerpt = card.querySelector('.card-excerpt') ? card.querySelector('.card-excerpt').textContent.toLowerCase() : '';
                const matchesCategory = activeCategory === 'all' || cardCategory === activeCategory;
                const matchesQuery = !query || title.includes(query) || excerpt.includes(query);
                if (matchesCategory && matchesQuery) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                }
            });
        };

        filterChips.forEach(chip => {
            chip.addEventListener('click', () => {
                filterChips.forEach(btn => btn.classList.remove('active'));
                chip.classList.add('active');
                applyFilters();
            });
        });

        if (searchInput) {
            searchInput.addEventListener('input', applyFilters);
        }
    }

    const forms = document.querySelectorAll('form[data-validate]');
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            const fields = form.querySelectorAll('[data-required]');
            let isValid = true;
            fields.forEach(field => {
                const errorMessage = field.parentElement.querySelector('.error-message');
                if (errorMessage) {
                    errorMessage.remove();
                }
                if (!field.value.trim()) {
                    isValid = false;
                    const error = document.createElement('div');
                    error.className = 'error-message';
                    error.textContent = 'Required field';
                    field.parentElement.appendChild(error);
                } else if (field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value.trim())) {
                    isValid = false;
                    const error = document.createElement('div');
                    error.className = 'error-message';
                    error.textContent = 'Enter a valid email';
                    field.parentElement.appendChild(error);
                }
            });
            if (!isValid) {
                event.preventDefault();
            } else {
                form.submit();
            }
        });
    });
});