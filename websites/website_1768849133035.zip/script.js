document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', !isExpanded);
      navLinks.classList.toggle('open');
    });

    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          navLinks.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');
    const cookieDecision = localStorage.getItem('abracadabraCookiesDecision');

    if (!cookieDecision) {
      cookieBanner.classList.remove('hide');
    }

    const handleDecision = (decision) => {
      localStorage.setItem('abracadabraCookiesDecision', decision);
      cookieBanner.classList.add('hide');
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => handleDecision('accepted'));
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', () => handleDecision('declined'));
    }
  }
});