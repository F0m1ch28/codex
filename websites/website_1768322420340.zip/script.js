document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieActions = document.querySelectorAll('.cookie-action');
    const consentKey = 'sqzd-cookie-consent';

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            siteNav.classList.toggle('open');
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768 && siteNav.classList.contains('open')) {
                    siteNav.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent && cookieBanner) {
        cookieBanner.classList.add('visible');
    }

    cookieActions.forEach(action => {
        action.addEventListener('click', (event) => {
            if (cookieBanner) {
                cookieBanner.classList.remove('visible');
            }
            const choice = action.getAttribute('data-choice') || 'decline';
            localStorage.setItem(consentKey, choice);
        });
    });
});

const containers = document.querySelectorAll('.container');
if (containers.length) {
    containers.forEach(container => {
        container.style.width = '100%';
        container.style.maxWidth = 'var(--max-width)';
        container.style.margin = '0 auto';
        container.style.paddingLeft = 'var(--space-sm)';
        container.style.paddingRight = 'var(--space-sm)';
    });
}