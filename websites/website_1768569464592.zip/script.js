document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            primaryNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', primaryNav.classList.contains('open'));
        });
        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                primaryNav.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-accept');
    const declineBtn = document.querySelector('.cookie-decline');
    const cookieKey = 'yorubarnqt-cookie-consent';

    if (cookieBanner && acceptBtn && declineBtn) {
        const savedPreference = localStorage.getItem(cookieKey);
        if (!savedPreference) {
            cookieBanner.classList.add('active');
        }

        acceptBtn.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'accepted');
            cookieBanner.classList.remove('active');
        });

        declineBtn.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'declined');
            cookieBanner.classList.remove('active');
        });
    }
});