document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-links a');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            siteNav.classList.toggle('nav-open');
        });
        navLinks.forEach((link) => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                siteNav.classList.remove('nav-open');
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
        const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');
        const customizeBtn = cookieBanner.querySelector('[data-cookie="customize"]');
        const consentKey = 'lungerecwb_cookie_consent';
        const storedConsent = localStorage.getItem(consentKey);

        if (!storedConsent) {
            cookieBanner.classList.add('active');
        }

        const handleConsent = (value) => {
            localStorage.setItem(consentKey, value);
            cookieBanner.classList.remove('active');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => handleConsent('accepted'));
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', () => handleConsent('declined'));
        }
        if (customizeBtn) {
            customizeBtn.addEventListener('click', () => {
                window.location.href = 'cookies.html';
            });
        }
    }
});