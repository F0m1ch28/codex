import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Legal.module.css';

const CookiePolicyPage = () => {
  usePageMeta(
    'Политика Cookie | Введите заголовок:',
    'Политика использования файлов Cookie на сайте технологического стартапа «Введите заголовок:».'
  );

  return (
    <div className={styles.page}>
      <div className="container">
        <h1>Политика в отношении Cookie</h1>
        <p className={styles.updated}>Обновлено: 15 марта 2024 года</p>
        <section>
          <h2>1. Что такое Cookie</h2>
          <p>
            Cookie — это небольшие файлы, которые сохраняются на устройстве пользователя для повышения удобства работы с сайтом и анализа трафика.
          </p>
        </section>
        <section>
          <h2>2. Какие Cookie мы используем</h2>
          <ul>
            <li>Технические cookie — обеспечивают работу основных функций сайта.</li>
            <li>Аналитические cookie — помогают понять, какие разделы сайта наиболее востребованы.</li>
          </ul>
        </section>
        <section>
          <h2>3. Управление Cookie</h2>
          <p>
            Вы можете ограничить или отключить cookie в настройках своего браузера. Однако это может повлиять на корректность работы отдельных функций сайта.
          </p>
        </section>
        <section>
          <h2>4. Обратная связь</h2>
          <p>
            Вопросы по использованию cookie направляйте на{' '}
            <a href="mailto:info@vvedite-zagolovok.ru">info@vvedite-zagolovok.ru</a>.
          </p>
        </section>
      </div>
    </div>
  );
};

export default CookiePolicyPage;