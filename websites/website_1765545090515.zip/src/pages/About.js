import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './About.module.css';

const AboutPage = () => {
  usePageMeta(
    'О компании | Введите заголовок:',
    'Узнайте подробнее о стартапе «Введите заголовок:» из Москвы: миссия, ценности, команда и подход к инновациям.'
  );

  const milestones = [
    {
      year: '2021',
      title: 'Идея и запуск',
      text: 'Собрали ядро команды, сформировали манифест и взяли первые пилоты в промышленности и fintech.',
    },
    {
      year: '2022',
      title: 'Рост компетенций',
      text: 'Расширили экспертизу в AI и DevOps, запустили внутреннюю лабораторию быстрых экспериментов.',
    },
    {
      year: '2023',
      title: 'Международные проекты',
      text: 'Вышли на зарубежный рынок, запустили проекты на Ближнем Востоке и в Центральной Европе.',
    },
  ];

  const principles = [
    {
      title: 'Доверие и прозрачность',
      description: 'Работаем открыто: делимся промежуточными результатами, фиксируем договорённости и держим обещания.',
    },
    {
      title: 'Любопытство и эксперименты',
      description: 'Не боимся проверять гипотезы и учиться. Наши открытия лежат в основе решений клиентов.',
    },
    {
      title: 'Системность и ответственность',
      description: 'Проектируем платформы с прицелом на масштабирование, сопровождаем внедрение и обучаем команды.',
    },
  ];

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <div>
              <span className="badge-mono">О нас</span>
              <h1>Мы строим технологическое будущее Москвы и создаём глобальный импакт</h1>
              <p>
                «Введите заголовок:» — команда инженеров, аналитиков и предпринимателей. Мы выбираем сложные вызовы, потому что любим видеть, как идеи превращаются в работающие сервисы, которые используют тысячи людей.
              </p>
            </div>
            <img
              src="https://picsum.photos/840/620?random=71"
              alt="Команда работает над инновационным проектом"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.mission}>
            <div>
              <h2>Миссия</h2>
              <p>
                Мы помогаем компаниям запускать инновации быстро и безопасно. Наша цель — сделать передовые технологии доступными для бизнеса любого размера и чувствовать ответственность за результат вместе с клиентом.
              </p>
            </div>
            <div>
              <h2>Ценности</h2>
              <ul>
                <li>Работаем как единая команда с клиентом.</li>
                <li>Формируем культуру уважения, любознательности и поиска истины.</li>
                <li>Доставляем измеримый эффект, а не просто закрытые задачи.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={`section ${styles.timelineSection}`}>
        <div className="container">
          <h2 className="section-title">Ключевые этапы пути</h2>
          <div className={styles.timeline}>
            {milestones.map((milestone) => (
              <article key={milestone.year} className={styles.timelineCard}>
                <span className={styles.timelineYear}>{milestone.year}</span>
                <h3>{milestone.title}</h3>
                <p>{milestone.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`section ${styles.principlesSection}`}>
        <div className="container">
          <h2 className="section-title">Принципы работы</h2>
          <div className={styles.principlesGrid}>
            {principles.map((principle) => (
              <article key={principle.title} className={styles.principleCard}>
                <h3>{principle.title}</h3>
                <p>{principle.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`section ${styles.cultureSection}`}>
        <div className="container">
          <div className={styles.cultureGrid}>
            <div>
              <span className="badge-mono">Командная культура</span>
              <h2>Создаём пространство для роста</h2>
              <p>
                Мы инвестируем в людей: проводим совместные демо, кросс-функциональные митапы и поддерживаем стремление коллег к экспериментам. Это помогает нам сохранять гибкость и устойчивость даже на динамичном рынке.
              </p>
            </div>
            <img
              src="https://picsum.photos/840/620?random=72"
              alt="Совместная работа команды"
              loading="lazy"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;