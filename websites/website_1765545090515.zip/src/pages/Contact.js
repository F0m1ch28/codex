import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Contact.module.css';

const ContactsPage = () => {
  usePageMeta(
    'Контакты | Введите заголовок:',
    'Свяжитесь с командой стартапа «Введите заголовок:» в Москве: адрес, телефон, email и форма обратной связи.'
  );

  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState({ error: '', success: '' });

  const handleChange = (event) => {
    setFormData((prev) => ({ ...prev, [event.target.name]: event.target.value }));
    setStatus({ error: '', success: '' });
  };

  const validateEmail = (email) => /\S+@\S+\.\S+/.test(email);

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setStatus({ error: 'Пожалуйста, заполните все поля.', success: '' });
      return;
    }
    if (!validateEmail(formData.email)) {
      setStatus({ error: 'Проверьте корректность email.', success: '' });
      return;
    }
    setStatus({
      error: '',
      success: 'Спасибо! Мы свяжемся с вами в течение двух рабочих дней.',
    });
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Контакты</h1>
            <p>
              Мы открыты к диалогу. Запланируйте встречу, чтобы обсудить технологические идеи, ускорить эксперименты или запустить новый продукт.
            </p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.contactGrid}>
            <div className={styles.contactInfo}>
              <h2>Наш офис</h2>
              <p>
                123456, г. Москва, ул. Ленина, д. 1, офис 101
              </p>
              <div className={styles.contactDetails}>
                <div>
                  <span>Телефон</span>
                  <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </div>
                <div>
                  <span>Email</span>
                  <a href="mailto:info@vvedite-zagolovok.ru">info@vvedite-zagolovok.ru</a>
                </div>
              </div>
              <div className={styles.map}>
                <img
                  src="https://picsum.photos/900/400?random=81"
                  alt="Схематичное изображение района офиса в Москве"
                  loading="lazy"
                />
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <span className="badge-mono">Напишите нам</span>
              <h2>Расскажите о своей задаче</h2>
              <label htmlFor="name">Имя и компания</label>
              <input
                id="name"
                name="name"
                placeholder="Например, Анна из Tech Group"
                value={formData.name}
                onChange={handleChange}
              />
              <label htmlFor="email">Рабочий email</label>
              <input
                id="email"
                name="email"
                placeholder="you@company.ru"
                value={formData.email}
                onChange={handleChange}
              />
              <label htmlFor="message">Сообщение</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                placeholder="Кратко опишите проект, сроки и желаемый результат."
                value={formData.message}
                onChange={handleChange}
              />
              {status.error && <p className={styles.error}>{status.error}</p>}
              {status.success && <p className={styles.success}>{status.success}</p>}
              <button type="submit" className="primary-button">
                Отправить сообщение
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactsPage;