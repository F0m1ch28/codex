import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Home.module.css';

const HomePage = () => {
  usePageMeta(
    'Введите заголовок: | Технологический стартап | Москва',
    'Введите заголовок: — технологический стартап из Москвы, создающий инновационные решения, цифровые продукты и профессиональные команды для устойчивого роста бизнеса.'
  );

  const stats = [
    { label: 'Запущенных платформ', value: 28 },
    { label: 'Партнёров по всему миру', value: 16 },
    { label: 'Высоконагруженных интеграций', value: 42 },
  ];

  const [statValues, setStatValues] = useState(stats.map(() => 0));

  useEffect(() => {
    const duration = 1500;
    const frameRate = 30;
    const totalFrames = Math.round(duration / (1000 / frameRate));
    let frame = 0;

    const interval = setInterval(() => {
      frame += 1;
      setStatValues(
        stats.map((item) =>
          Math.min(
            item.value,
            Math.floor((item.value * frame) / totalFrames)
          )
        )
      );
      if (frame === totalFrames) {
        clearInterval(interval);
      }
    }, 1000 / frameRate);

    return () => clearInterval(interval);
  }, []);

  const servicesPreview = [
    {
      title: 'Цифровые продукты под ключ',
      description:
        'Масштабируемые веб- и мобильные решения с акцентом на пользовательский опыт и безопасность данных.',
      image: 'https://picsum.photos/600/400?random=11',
    },
    {
      title: 'AI и аналитика данных',
      description:
        'Модели машинного обучения, автоматизация принятия решений и интеллектуальные ассистенты для команд.',
      image: 'https://picsum.photos/600/400?random=12',
    },
    {
      title: 'Инфраструктура и DevOps',
      description:
        'Непрерывные релизы, инфраструктура как код и контроль качества для надежного масштабирования.',
      image: 'https://picsum.photos/600/400?random=13',
    },
  ];

  const processSteps = [
    {
      title: 'Диагностика',
      text: 'Проводим исследование потребностей, определяем метрики успеха и формируем карту ожиданий.',
      index: '01',
    },
    {
      title: 'Дизайн и прототипирование',
      text: 'Создаём дизайн-систему, собираем интерактивный прототип и тестируем сценарии с ключевыми пользователями.',
      index: '02',
    },
    {
      title: 'Разработка и масштабирование',
      text: 'Интегрируем решения в инфраструктуру клиента, автоматизируем процессы и готовим команду к развитию.',
      index: '03',
    },
  ];

  const projects = [
    {
      title: 'Платформа логистики для e-commerce',
      category: 'AI',
      description:
        'Построили адаптивную систему прогнозирования спроса и распределения потоков в реальном времени.',
      image: 'https://picsum.photos/1200/800?random=21',
    },
    {
      title: 'Умная сеть сенсоров для smart city',
      category: 'IoT',
      description:
        'Мониторинг качества воздуха, шума и трафика с аналитикой для городских служб Москвы.',
      image: 'https://picsum.photos/1200/800?random=22',
    },
    {
      title: 'Облачный конструктор API',
      category: 'Cloud',
      description:
        'Платформа для быстрого подключения новых сервисов и контроля SLA в финансовом секторе.',
      image: 'https://picsum.photos/1200/800?random=23',
    },
    {
      title: 'Цифровой двойник производственной линии',
      category: 'AI',
      description:
        'Прогнозирование простоев и оптимизация загрузки оборудования на основе данных датчиков.',
      image: 'https://picsum.photos/1200/800?random=24',
    },
  ];

  const [activeFilter, setActiveFilter] = useState('Все');

  const filteredProjects =
    activeFilter === 'Все'
      ? projects
      : projects.filter((project) => project.category === activeFilter);

  const testimonials = [
    {
      name: 'Анна Мельникова',
      position: 'Директор по продуктам, «Сфера»',
      quote:
        'Команда «Введите заголовок:» в рекордные сроки развернула пилот, который стал основой нашей новой бизнес-линии. Особенно ценю прозрачность процессов и способность слышать клиента.',
      avatar: 'https://picsum.photos/200/200?random=31',
    },
    {
      name: 'Игорь Леднев',
      position: 'COO, TechForward',
      quote:
        'Их инженерная культура и дисциплина в DevOps впечатляют. У нас появилось ощущение, что мы работаем с собственным внутренним подразделением.',
      avatar: 'https://picsum.photos/200/200?random=32',
    },
    {
      name: 'Мария Михайлова',
      position: 'Руководитель инноваций, UrbanData',
      quote:
        'Благодаря совместному проекту мы получили живые нагрузочные модели города и смогли доказать эффективность решений на данных.',
      avatar: 'https://picsum.photos/200/200?random=33',
    },
  ];

  const [testimonialIndex, setTestimonialIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const faq = [
    {
      question: 'Как быстро вы начинаете работу после первого контакта?',
      answer:
        'Мы проводим экспресс-диагностику в течение 10 рабочих дней. После согласования гипотез и состава команды подписываем соглашение и приступаем к спринтам.',
    },
    {
      question: 'С какими технологиями вы работаете?',
      answer:
        'Используем стек, наиболее подходящий под задачу: TypeScript, React, Python, Kotlin, инфраструктуру Kubernetes, решения на базе MLFlow и TensorFlow, а также отечественные платформы.',
    },
    {
      question: 'Можно ли интегрировать ваше решение с нашей текущей системой?',
      answer:
        'Да, мы проектируем API и коннекторы для безболезненной интеграции. Уделяем особое внимание безопасности, логированию и мониторингу каждый раз, когда подключаем внешние системы.',
    },
  ];

  const blogEntries = [
    {
      title: 'Как построить цифровой двойник завода за 12 недель',
      excerpt:
        'Поделились практикой быстрой постановки эксперимента и согласования данных между цехами и аналитиками.',
      image: 'https://picsum.photos/800/600?random=41',
      date: '15 марта 2024',
    },
    {
      title: 'Гайд по внедрению MLOps в корпоративной среде',
      excerpt:
        'Разбираем четыре ключевых шага, которые помогли банку в Москве сократить цикл обновления моделей с 3 месяцев до 2 недель.',
      image: 'https://picsum.photos/800/600?random=42',
      date: '28 февраля 2024',
    },
  ];

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={`container ${styles.heroContainer}`}>
          <div className={styles.heroContent}>
            <span className="badge-mono">Москва · технологии · инновации</span>
            <h1>
              Создаём продукты, которые делают инновации <span className={styles.heroAccent}>ежедневной практикой</span>.
            </h1>
            <p>
              «Введите заголовок:» — технологический стартап из Москвы. Помогаем бизнесу превращать идеи в цифровые сервисы, внедряем алгоритмы принятия решений и строим инфраструктуру, способную выдержать рост.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className="primary-button">
                Обсудить проект
              </Link>
              <Link to="/uslugi" className="secondary-button">
                Смотреть портфолио
              </Link>
            </div>
            <div className={styles.heroMeta}>
              <div>
                <span>Фокус на результате</span>
                <p>Меряем успех по достигнутым бизнес-метрикам, а не по количеству кодовых строк.</p>
              </div>
              <div>
                <span>Партнёрский подход</span>
                <p>Работаем в тесной связке с командами клиентов, дополняя их экспертный потенциал.</p>
              </div>
            </div>
          </div>
          <div className={styles.heroMedia}>
            <img
              src="https://picsum.photos/860/690?random=1"
              alt="Инновационная команда, работающая над технологическим решением"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={`section ${styles.statsSection}`}>
        <div className="container">
          <div className={styles.statsGrid}>
            {stats.map((item, index) => (
              <div key={item.label} className={styles.statCard}>
                <span className={styles.statNumber}>{statValues[index]}+</span>
                <p>{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="badge-mono">Наши компетенции</span>
            <h2 className="section-title">Фокусируемся на задачах с ощутимым бизнес-результатом</h2>
            <p className="section-subtitle">
              От первого прототипа до управления инфраструктурой в продакшене — сопровождаем клиента на каждом этапе. Команда комбинирует инженерное мышление и стратегический взгляд.
            </p>
          </div>
          <div className={styles.serviceCards}>
            {servicesPreview.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceImageWrapper}>
                  <img src={service.image} alt={service.title} loading="lazy" />
                </div>
                <div className={styles.serviceBody}>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <Link to="/uslugi" className={styles.serviceLink}>
                    Узнать подробнее →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`section ${styles.processSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="badge-mono">Совместный путь</span>
            <h2 className="section-title">Работаем прозрачно и поэтапно</h2>
            <p className="section-subtitle">
              Каждая инициатива проходит три ключевых этапа. Так мы фиксируем прогресс, управляем рисками и добиваемся измеримых результатов.
            </p>
          </div>
          <div className={styles.processTimeline}>
            {processSteps.map((step) => (
              <div key={step.title} className={styles.processStep}>
                <span className={styles.stepIndex}>{step.index}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`section ${styles.projectsSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="badge-mono">Кейсы</span>
            <h2 className="section-title">Проекты, которыми гордимся</h2>
            <p className="section-subtitle">
              Мы помогаем компаниям из Москвы и регионов экспериментировать, запускать и масштабировать продукты, которые меняют свои отрасли.
            </p>
          </div>
          <div className={styles.filters}>
            {['Все', 'AI', 'IoT', 'Cloud'].map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={`${styles.filterButton} ${
                  activeFilter === filter ? styles.filterActive : ''
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectBody}>
                  <span className={styles.projectTag}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`section ${styles.testimonialsSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="badge-mono">Отзывы</span>
            <h2 className="section-title">Нам доверяют сильные команды</h2>
          </div>
          <div className={styles.testimonialSlider}>
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === testimonialIndex ? styles.testimonialActive : ''
                }`}
              >
                <div className={styles.testimonialAvatar}>
                  <img src={testimonial.avatar} alt={testimonial.name} loading="lazy" />
                </div>
                <blockquote>“{testimonial.quote}”</blockquote>
                <div className={styles.testimonialAuthor}>
                  <span>{testimonial.name}</span>
                  <p>{testimonial.position}</p>
                </div>
              </div>
            ))}
            <div className={styles.sliderControls}>
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  className={`${styles.sliderDot} ${
                    testimonialIndex === index ? styles.dotActive : ''
                  }`}
                  onClick={() => setTestimonialIndex(index)}
                  aria-label={`Переключить отзыв ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`section ${styles.teamSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="badge-mono">Команда</span>
            <h2 className="section-title">Инженеры, аналитики, стратеги</h2>
            <p className="section-subtitle">
              Мы объединяем специалистов с опытом работы в продуктовых компаниях, консалтинге и исследовательских лабораториях.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {[
              {
                name: 'Николай Громов',
                role: 'CEO · Стратегия',
                image: 'https://picsum.photos/400/400?random=51',
                focus: 'Сценарное планирование и развитие продуктов.',
              },
              {
                name: 'Светлана Платонова',
                role: 'CTO · Архитектура',
                image: 'https://picsum.photos/400/400?random=52',
                focus: 'Инфраструктура, DevOps и инженерный менторинг.',
              },
              {
                name: 'Даниил Котов',
                role: 'Head of Data',
                image: 'https://picsum.photos/400/400?random=53',
                focus: 'Машинное обучение, аналитика и MLOps.',
              },
            ].map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <div className={styles.teamBody}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.focus}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`section ${styles.faqSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="badge-mono">FAQ</span>
            <h2 className="section-title">Часто задаваемые вопросы</h2>
          </div>
          <div className={styles.faqList}>
            {faq.map((item, idx) => (
              <details key={item.question} open={idx === 0}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={`section ${styles.blogSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="badge-mono">Пульс инноваций</span>
            <h2 className="section-title">Свежие мысли и наблюдения</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogEntries.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogBody}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/o-kompanii" className={styles.blogLink}>
                    Читать заметку →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`section ${styles.ctaSection}`}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <span className="badge-mono">Готовы к диалогу</span>
              <h2>Давайте спроектируем следующее достижение для вашего бизнеса</h2>
              <p>
                Заполните форму и расскажите о задаче. Мы предложим концепцию, рассчитанную под ваши метрики и горизонты развития.
              </p>
            </div>
            <Link to="/kontakty" className="primary-button">
              Назначить встречу
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;