import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Services.module.css';

const ServicesPage = () => {
  usePageMeta(
    'Услуги | Введите заголовок:',
    'Услуги стартапа «Введите заголовок:» включают разработку цифровых продуктов, внедрение AI, DevOps и консалтинг по инновациям.'
  );

  const services = [
    {
      title: 'Разработка цифровых продуктов',
      description:
        'Создаём веб- и мобильные приложения с нуля. Определяем архитектуру, формируем дизайн-систему, строим продуктовую аналитику и помогаем запустить решение без срывов сроков.',
      stack: ['React', 'TypeScript', 'Node.js', 'Kotlin', 'PostgreSQL'],
      accent: 'Фокус на пользовательском опыте и измеримых продуктовых метриках.',
      image: 'https://picsum.photos/900/600?random=61',
    },
    {
      title: 'Модели искусственного интеллекта и аналитика',
      description:
        'Разрабатываем и внедряем алгоритмы прогнозирования, персонализации и автоматизации решений. Настраиваем MLOps-подход, чтобы модели развивались вместе с бизнесом.',
      stack: ['Python', 'TensorFlow', 'PyTorch', 'Airflow', 'MLflow'],
      accent: 'Комбинируем экспертные знания и данные для уверенных решений.',
      image: 'https://picsum.photos/900/600?random=62',
    },
    {
      title: 'Инфраструктура и DevOps',
      description:
        'Строим непрерывные конвейеры доставки, автоматизируем развёртывание и мониторинг. Оптимизируем расходы на облака и создаём надёжный фундамент для роста.',
      stack: ['Kubernetes', 'Terraform', 'Grafana', 'Prometheus', 'GitLab CI'],
      accent: 'Инфраструктура как код и ежедневные релизы как норма.',
      image: 'https://picsum.photos/900/600?random=63',
    },
  ];

  const [activeService, setActiveService] = useState(services[0]);

  const accelerators = [
    {
      title: 'Диагностика инновационного потенциала',
      text: 'Оцениваем процессы разработки, проводим интервью и формируем «тепловую карту» возможностей.',
    },
    {
      title: 'Воркшопы по цифровой стратегии',
      text: 'Помогаем руководителям сформулировать продуктовый фокус и составить дорожную карту внедрения.',
    },
    {
      title: 'Технический аудит',
      text: 'Проверяем архитектуру, безопасность и производительность решений, даём рекомендации по улучшению.',
    },
    {
      title: 'Трансформация команд',
      text: 'Настраиваем культуру экспериментов, помогаем выстроить процессы agile и continuous discovery.',
    },
  ];

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="badge-mono">Сервисы</span>
            <h1>Комплексные решения для амбициозных компаний</h1>
            <p>
              Сочетаем стратегический консалтинг, разработку и технологическую экспертизу. Работаем с командами, которым важно опережать рынок и внедрять инновации без компромиссов.
            </p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.serviceSwitcher}>
            <div className={styles.switcherNav}>
              {services.map((service) => (
                <button
                  key={service.title}
                  type="button"
                  onClick={() => setActiveService(service)}
                  className={`${styles.switcherButton} ${
                    activeService.title === service.title ? styles.switcherActive : ''
                  }`}
                >
                  {service.title}
                </button>
              ))}
            </div>
            <div className={styles.serviceDetail}>
              <div className={styles.detailText}>
                <h2>{activeService.title}</h2>
                <p>{activeService.description}</p>
                <div className={styles.stackList}>
                  {activeService.stack.map((item) => (
                    <span key={item}>{item}</span>
                  ))}
                </div>
                <div className={styles.accent}>
                  <span className="badge-mono">Мы верим</span>
                  <p>{activeService.accent}</p>
                </div>
              </div>
              <div className={styles.detailImage}>
                <img src={activeService.image} alt={activeService.title} loading="lazy" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`section ${styles.acceleratorSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="badge-mono">Акселераторы</span>
            <h2 className="section-title">Ускоряем внедрение технологий</h2>
            <p className="section-subtitle">
              У нас вы можете заказать отдельные форматы поддержки, чтобы быстро закрыть стратегические задачи и передать знания команде.
            </p>
          </div>
          <div className={styles.acceleratorGrid}>
            {accelerators.map((item) => (
              <article key={item.title} className={styles.acceleratorCard}>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`section ${styles.techSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="badge-mono">Технологии</span>
            <h2 className="section-title">Используем проверенный стек</h2>
            <p className="section-subtitle">
              Мы не гоняемся за модой на технологии. Выбираем инструменты, которые дадут устойчивый и предсказуемый результат.
            </p>
          </div>
          <div className={styles.techGrid}>
            {[
              'Microservices & Event-driven архитектуры',
              'CI/CD конвейеры и Infrastructure as Code',
              'Machine Learning и аналитические пайплайны',
              'Edge computing и IoT-интеграции',
              'Современные фреймворки фронтенда',
              'Облачные и гибридные решения',
            ].map((item) => (
              <div key={item} className={styles.techCard}>
                <span>▸</span>
                <p>{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;