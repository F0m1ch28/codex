import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('vvedite-zagolovok-cookie-consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('vvedite-zagolovok-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Мы используем Cookie</h4>
        <p>
          Cookie помогают анализировать трафик и улучшать пользовательский опыт. Продолжая пользоваться сайтом, вы соглашаетесь с условиями обработки данных.
        </p>
      </div>
      <button className="primary-button" onClick={acceptCookies}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;