import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.inner}`}>
        <div className={styles.brand}>
          <h3>Введите заголовок:</h3>
          <p>
            Мы создаём технологические решения, которые помогают московским компаниям ускорять рост, расширять сеть партнеров и внедрять инновации без риска.
          </p>
          <div className={styles.badge}>Создано в Москве</div>
        </div>
        <div className={styles.column}>
          <h4>Навигация</h4>
          <Link to="/">Главная</Link>
          <Link to="/uslugi">Услуги</Link>
          <Link to="/o-kompanii">О компании</Link>
          <Link to="/kontakty">Контакты</Link>
        </div>
        <div className={styles.column}>
          <h4>Правовые документы</h4>
          <Link to="/pravila-polzovaniya">Правила пользования</Link>
          <Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link>
          <Link to="/politika-cookie">Политика Cookie</Link>
        </div>
        <div className={styles.column}>
          <h4>Контакты</h4>
          <p>Адрес: 123456, г. Москва, ул. Ленина, д. 1, офис 101</p>
          <a href="tel:+74951234567">+7 (495) 123-45-67</a>
          <a href="mailto:info@vvedite-zagolovok.ru">info@vvedite-zagolovok.ru</a>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Введите заголовок:. Все права защищены.</p>
        <span>Инновации сегодня — масштабирование завтра.</span>
      </div>
    </footer>
  );
};

export default Footer;