import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLinkClick = () => {
    setMenuOpen(false);
  };

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} onClick={handleLinkClick}>
          <span className={styles.logoMark}>Введите заголовок:</span>
          <span className={styles.logoTag}>Технологический стартап</span>
        </NavLink>
        <button
          className={styles.burger}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-label="Переключить меню"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`}>
          <NavLink
            to="/"
            end
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ''}`
            }
            onClick={handleLinkClick}
          >
            Главная
          </NavLink>
          <NavLink
            to="/uslugi"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ''}`
            }
            onClick={handleLinkClick}
          >
            Услуги
          </NavLink>
          <NavLink
            to="/o-kompanii"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ''}`
            }
            onClick={handleLinkClick}
          >
            О компании
          </NavLink>
          <NavLink
            to="/kontakty"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ''}`
            }
            onClick={handleLinkClick}
          >
            Контакты
          </NavLink>
          <div className={styles.navDivider} />
          <NavLink
            to="/pravila-polzovaniya"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ''} ${styles.aux}`
            }
            onClick={handleLinkClick}
          >
            Правила
          </NavLink>
          <NavLink
            to="/politika-konfidencialnosti"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ''} ${styles.aux}`
            }
            onClick={handleLinkClick}
          >
            Конфиденциальность
          </NavLink>
          <NavLink
            to="/politika-cookie"
            className={({ isActive }) =>
              `${styles.link} ${isActive ? styles.active : ''} ${styles.aux}`
            }
            onClick={handleLinkClick}
          >
            Cookie
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;