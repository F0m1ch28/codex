import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const navItems = [
  { label: 'Home', path: '/' },
  { label: 'Ricette', path: '/ricette' },
  { label: 'Portfolio', path: '/portfolio' },
  { label: 'Blog', path: '/blog' },
  { label: 'Chi siamo', path: '/chi-siamo' },
  { label: 'Servizi', path: '/servizi' },
  { label: 'Contatti', path: '/contatti' }
];

const Header = () => {
  const [isTop, setIsTop] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsTop(window.scrollY < 16);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={`site-header ${isTop ? '' : 'site-header--scrolled'}`}>
      <div className="container header-container">
        <a href="/" className="logo" aria-label="Fetta Di Giorno home">
          <span className="logo-mark">F</span>
          <span className="logo-text">Fetta Di Giorno</span>
        </a>
        <nav className="desktop-nav" aria-label="Navigazione principale">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `nav-link ${isActive ? 'nav-link--active' : ''}`
              }
            >
              {item.label}
            </NavLink>
          ))}
          <a className="btn btn-tertiary" href="/ricette">
            Sfoglia ricette
          </a>
        </nav>
        <button
          className={`menu-toggle ${menuOpen ? 'open' : ''}`}
          type="button"
          aria-expanded={menuOpen}
          aria-controls="mobile-menu"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span className="menu-line" />
          <span className="menu-line" />
          <span className="menu-line" />
          <span className="sr-only">Apri il menu</span>
        </button>
      </div>
      <AnimatePresence>
        {menuOpen && (
          <motion.nav
            id="mobile-menu"
            className="mobile-nav"
            aria-label="Navigazione mobile"
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
          >
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `mobile-link ${isActive ? 'mobile-link--active' : ''}`
                }
              >
                {item.label}
              </NavLink>
            ))}
            <a className="btn btn-primary" href="/ricette">
              Ultime ricette
            </a>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;