import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="site-footer">
    <div className="container footer-grid">
      <div className="footer-column">
        <h3 className="footer-title">Fetta Di Giorno</h3>
        <p className="footer-text">
          Ricette italiane quotidiane, ingredienti di stagione e fotografie
          morbide dal quartiere Ortica a Milano.
        </p>
        <div className="footer-contact">
          <p>Via Privata Flumendosa 11<br />20132 Milano MI, Italia</p>
          <p>
            <a href="tel:+390257892146">+39 02 5789 2146</a><br />
            <a href="mailto:ciao@fettadigiorno.it">ciao@fettadigiorno.it</a>
          </p>
        </div>
      </div>
      <div className="footer-column">
        <h4 className="footer-subtitle">Navigazione</h4>
        <ul className="footer-list">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/chi-siamo">Chi siamo</Link></li>
          <li><Link to="/ricette">Ricette</Link></li>
          <li><Link to="/portfolio">Portfolio</Link></li>
          <li><Link to="/servizi">Servizi</Link></li>
          <li><Link to="/contatti">Contatti</Link></li>
        </ul>
      </div>
      <div className="footer-column">
        <h4 className="footer-subtitle">Approfondimenti</h4>
        <ul className="footer-list">
          <li><Link to="/blog/pomodori-che-profumano-d-estate">Pomodori che profumano d’estate</Link></li>
          <li><Link to="/blog/come-tostiamo-il-pane-a-casa">Come tostiamo il pane a casa</Link></li>
          <li><Link to="/blog/come-proviamo-le-erbe-in-cucina">Come proviamo le erbe in cucina</Link></li>
        </ul>
      </div>
      <div className="footer-column">
        <h4 className="footer-subtitle">Supporto</h4>
        <ul className="footer-list">
          <li><Link to="/termini">Termini di utilizzo</Link></li>
          <li><Link to="/privacy">Privacy</Link></li>
          <li><Link to="/cookie-policy">Cookie policy</Link></li>
          <li><a href="/sitemap.xml">Sitemap</a></li>
        </ul>
        <p className="footer-note">
          Raccontaci la tua ricetta di famiglia scrivendo a{' '}
          <a href="mailto:ciao@fettadigiorno.it">ciao@fettadigiorno.it</a>
        </p>
      </div>
    </div>
    <div className="footer-bottom">
      <p>© {new Date().getFullYear()} Fetta Di Giorno. Tutti i diritti riservati.</p>
    </div>
  </footer>
);

export default Footer;