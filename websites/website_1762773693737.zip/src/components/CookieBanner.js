import React, { useEffect, useState } from 'react';

const STORAGE_KEY = 'fetta-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const closeBanner = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <p>
          Utilizziamo cookie tecnici e di performance per offrirti un’esperienza
          morbida come una focaccia appena sfornata. Proseguendo accetti la nostra{' '}
          <a href="/cookie-policy">cookie policy</a>.
        </p>
      </div>
      <div className="cookie-actions">
        <button type="button" className="btn btn-primary" onClick={closeBanner}>
          Accetto
        </button>
        <a className="btn btn-outline" href="/cookie-policy">
          Preferenze
        </a>
      </div>
    </div>
  );
};

export default CookieBanner;