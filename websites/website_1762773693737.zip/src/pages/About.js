import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';

const timeline = [
  {
    year: '2011',
    title: 'Primo taccuino',
    description: 'Francesca apre un quaderno a quadretti per segnare le ricette di casa.'
  },
  {
    year: '2015',
    title: 'Luce naturale',
    description: 'Arrivano le prime fotografie con la luce dell’appartamento di Ortica.'
  },
  {
    year: '2018',
    title: 'Newsletter del venerdì',
    description: 'Inizia l’appuntamento settimanale con 120 lettori fedeli.'
  },
  {
    year: '2022',
    title: 'Laboratori itineranti',
    description: 'Workshop in cascine lombarde con produttori e cuochi amici.'
  }
];

const kitchenPhotos = [
  {
    src: 'https://picsum.photos/900/600?random=71',
    alt: 'Banco di cucina con ingredienti e taccuini sparsi'
  },
  {
    src: 'https://picsum.photos/900/600?random=72',
    alt: 'Dettaglio di pentole appese in una cucina domestica'
  },
  {
    src: 'https://picsum.photos/900/600?random=73',
    alt: 'Tavolo apparecchiato con tovaglia panna e bicchieri colorati'
  },
  {
    src: 'https://picsum.photos/900/600?random=74',
    alt: 'Scaffale con piatti in ceramica e spezie in barattolo'
  }
];

const pantryItems = [
  'Olio extravergine ligure e siciliano',
  'Aceti fatti in casa, agrumi e vinaccioli',
  'Passata di pomodoro dell’estate scorsa',
  'Riso carnaroli, farro e orzo perlato',
  'Scatole di pasta secca artigianale',
  'Legumi secchi già ammollati e congelati',
  'Erbe essiccate raccolte al mercato',
  'Acciughe sotto sale e colatura di alici',
  'Miele di castagno e pistacchi di Bronte',
  'Cioccolato fondente per dolci improvvisati'
];

const About = () => (
  <>
    <Helmet>
      <title>Chi siamo | Fetta Di Giorno</title>
      <meta
        name="description"
        content="Conosci il team di Fetta Di Giorno: storie, motivazioni e stile del nostro blog di cucina italiana quotidiana."
      />
      <link rel="canonical" href="https://www.fettadigiorno.it/chi-siamo" />
    </Helmet>
    <section className="section about-hero">
      <div className="container about-hero-grid">
        <motion.div
          className="about-hero-text"
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <p className="overline">Chi siamo</p>
          <h1 className="page-title">Siamo una famiglia di appunti, stoviglie e luce morbida</h1>
          <p className="lead">
            Fetta Di Giorno nasce nella nostra cucina di Milano Ortica. Francesca
            scrive e cucina, Marco fotografa e monta, Giulia tesse relazioni con
            produttori e lettori. Ci piace la semplicità, quella che non ha paura
            delle imperfezioni ma pretende cura.
          </p>
          <p>
            Qui raccontiamo ciò che cuciniamo davvero. Le ricette vengono annotate
            con matite morbide, riprovate tre volte, assaggiate da chi capita a
            cena. La cucina è piccola, il tavolo è una tavola da falegname
            recuperata, ma la luce è quella giusta.
          </p>
        </motion.div>
        <motion.div
          className="about-hero-photo"
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <img
            src="https://picsum.photos/900/700?random=75"
            alt="Il team di Fetta Di Giorno intorno al tavolo di cucina"
            loading="lazy"
          />
        </motion.div>
      </div>
    </section>

    <section className="section about-story">
      <div className="container about-story-grid">
        <motion.article
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.45 }}
        >
          <h2>Perché scriviamo</h2>
          <p>
            Sentivamo il bisogno di un luogo dove raccontare la cucina di tutti i giorni
            con onestà. Niente foto patinate impossibili da replicare, niente ingredienti
            introvabili. Solo ciò che davvero passa dalla nostra dispensa e arriva nei piatti.
          </p>
          <p>
            Le storie nascono dalle conversazioni con chi compra verdure insieme a noi,
            con chi lavora in cascina o con i vicini di pianerottolo che ci prestano il
            forno quando stiamo provando l’ennesimo pane. Una cucina è fatta di persone.
          </p>
        </motion.article>
        <motion.article
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.45, delay: 0.1 }}
        >
          <h2>Come cucina la nostra casa</h2>
          <p>
            Il nostro stile è semplice e stratificato: uniamo stoviglie di famiglia con
            pezzi trovati ai mercatini, usiamo colori tenui e luce naturale, raccontiamo
            ogni piatto con parole precise. Cerchiamo di lasciar spazio all’ingrediente
            principale senza sovraccaricarlo.
          </p>
          <p>
            Amiamo i piatti unici che si possono condividere, le insalate tiepide, i pani
            profumati. Il nostro obiettivo è dare sicurezza a chi cucina, perché sappia
            interpretare, usare ciò che ha, adattare senza paura.
          </p>
        </motion.article>
      </div>
    </section>

    <section className="section timeline">
      <div className="container">
        <div className="section-heading">
          <p className="overline">La nostra storia</p>
          <h2 className="section-title">Quattro tappe importanti</h2>
        </div>
        <div className="timeline-grid">
          {timeline.map((event) => (
            <motion.div
              key={event.year}
              className="timeline-card"
              whileHover={{ translateY: -8 }}
              transition={{ duration: 0.25 }}
            >
              <span className="timeline-year">{event.year}</span>
              <h3>{event.title}</h3>
              <p>{event.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    <section className="section kitchen-photos">
      <div className="container">
        <div className="section-heading">
          <p className="overline">La nostra cucina</p>
          <h2 className="section-title">Dettagli reali del nostro spazio</h2>
        </div>
        <div className="kitchen-grid">
          {kitchenPhotos.map((photo) => (
            <motion.figure
              key={photo.src}
              className="kitchen-photo"
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.25 }}
            >
              <img src={photo.src} alt={photo.alt} loading="lazy" />
            </motion.figure>
          ))}
        </div>
      </div>
    </section>

    <section className="section pantry">
      <div className="container pantry-grid">
        <motion.div
          className="pantry-text"
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.45 }}
        >
          <h2>Cosa teniamo in dispensa</h2>
          <p>
            La nostra dispensa è compatta ma organizzata: amiamo avere sempre basi che
            ci permettano di improvvisare cene creative anche quando torniamo tardi.
          </p>
        </motion.div>
        <motion.ul
          className="pantry-list"
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.45, delay: 0.1 }}
        >
          {pantryItems.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </motion.ul>
      </div>
    </section>
  </>
);

export default About;