import React from 'react';
import { Helmet } from 'react-helmet-async';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy | Fetta Di Giorno</title>
      <meta
        name="description"
        content="Informativa sul trattamento dei dati personali per i visitatori del sito Fetta Di Giorno."
      />
      <link rel="canonical" href="https://www.fettadigiorno.it/privacy" />
    </Helmet>
    <section className="section legal">
      <div className="container legal-content">
        <h1 className="page-title">Informativa Privacy</h1>
        <p>Aggiornamento: 12 aprile 2024</p>
        <h2>1. Titolare del trattamento</h2>
        <p>
          Fetta Di Giorno, con sede in Via Privata Flumendosa 11, 20132 Milano MI,
          Italia, è il titolare del trattamento dei dati personali raccolti tramite
          il sito.
        </p>
        <h2>2. Tipologie di dati raccolti</h2>
        <p>
          Raccogliamo dati forniti volontariamente (nome, email, messaggi inviati) e
          dati di navigazione (cookie tecnici e di performance).
        </p>
        <h2>3. Finalità del trattamento</h2>
        <ul>
          <li>Risposta a richieste ricevute tramite form di contatto.</li>
          <li>Invio della newsletter, previo consenso esplicito.</li>
          <li>Analisi statistiche anonime per migliorare il sito.</li>
        </ul>
        <h2>4. Conservazione</h2>
        <p>
          I dati vengono conservati per il tempo necessario a gestire la richiesta o,
          in caso di newsletter, finché l’utente non revoca il consenso.
        </p>
        <h2>5. Diritti dell’utente</h2>
        <p>
          Puoi richiedere accesso, rettifica, cancellazione o limitazione del
          trattamento scrivendo a{' '}
          <a href="mailto:privacy@fettadigiorno.it">privacy@fettadigiorno.it</a>.
        </p>
        <h2>6. Cookie</h2>
        <p>
          Utilizziamo cookie tecnici per il corretto funzionamento del sito e cookie
          analitici anonimizzati. Per maggiori dettagli consulta la{' '}
          <a href="/cookie-policy">Cookie policy</a>.
        </p>
        <h2>7. Sicurezza</h2>
        <p>
          Adottiamo misure tecniche e organizzative adeguate per proteggere i dati
          personali da accessi non autorizzati, perdita o uso improprio.
        </p>
        <h2>8. Aggiornamenti</h2>
        <p>
          Questa informativa può essere aggiornata. Ti invitiamo a consultarla
          periodicamente.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;