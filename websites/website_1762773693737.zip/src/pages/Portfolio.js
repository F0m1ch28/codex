import React, { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';

const series = [
  {
    title: 'Cosa cuciniamo davvero',
    category: 'Tavolo quotidiano',
    description: 'Sequenze di piatti familiari preparati nelle serate feriali, con luci morbide e stoviglie spaiate.',
    images: [
      { src: 'https://picsum.photos/1000/700?random=111', alt: 'Piatto di pasta fumante su tavolo di legno' },
      { src: 'https://picsum.photos/1000/700?random=112', alt: 'Teglia di verdure arrostite con erbe fresche' },
      { src: 'https://picsum.photos/1000/700?random=113', alt: 'Ciotola di insalata di cereali con posate' },
      { src: 'https://picsum.photos/1000/700?random=114', alt: 'Pane fatto in casa tagliato a fette' },
      { src: 'https://picsum.photos/1000/700?random=115', alt: 'Tavolo apparecchiato con piatti bianchi e bicchieri' },
      { src: 'https://picsum.photos/1000/700?random=116', alt: 'Dolce semplice con frutta fresca' },
      { src: 'https://picsum.photos/1000/700?random=117', alt: 'Dettaglio di mani che impastano la pizza' },
      { src: 'https://picsum.photos/1000/700?random=118', alt: 'Tazza di tisana con biscotti fatti in casa' }
    ]
  },
  {
    title: 'Reali tavole italiane',
    category: 'Tavolo condiviso',
    description: 'Pranzi e cene in case amiche, con persone vere, piatti passati di mano in mano e conversazioni accese.',
    images: [
      { src: 'https://picsum.photos/1000/700?random=121', alt: 'Tavolo lungo con piatti condivisi' },
      { src: 'https://picsum.photos/1000/700?random=122', alt: 'Mani che servono pasta da un grande piatto' },
      { src: 'https://picsum.photos/1000/700?random=123', alt: 'Bicchieri colorati con vino e acqua' },
      { src: 'https://picsum.photos/1000/700?random=124', alt: 'Teglia di melanzane alla parmigiana sul tavolo' },
      { src: 'https://picsum.photos/1000/700?random=125', alt: 'Dettaglio di mani che spezzano il pane' },
      { src: 'https://picsum.photos/1000/700?random=126', alt: 'Insalatiera grande con posate in legno' },
      { src: 'https://picsum.photos/1000/700?random=127', alt: 'Dolce al cioccolato servito al cucchiaio' },
      { src: 'https://picsum.photos/1000/700?random=128', alt: 'Vista dall’alto di piatti vuoti dopo la cena' }
    ]
  },
  {
    title: 'Mini stagioni',
    category: 'Studio ingredienti',
    description: 'Set fotografici dedicati alle micro-stagioni italiane: dalle ciliegie di giugno alle castagne di ottobre.',
    images: [
      { src: 'https://picsum.photos/1000/700?random=131', alt: 'Cesto di ciliegie con foglie verdi' },
      { src: 'https://picsum.photos/1000/700?random=132', alt: 'Fichi maturi su tovaglia panna' },
      { src: 'https://picsum.photos/1000/700?random=133', alt: 'Zucca tagliata su tagliere di legno' },
      { src: 'https://picsum.photos/1000/700?random=134', alt: 'Cachi maturi con foglie' },
      { src: 'https://picsum.photos/1000/700?random=135', alt: 'Carciofi disposti su fondo scuro' },
      { src: 'https://picsum.photos/1000/700?random=136', alt: 'Mazzi di erbe aromatiche fresche' },
      { src: 'https://picsum.photos/1000/700?random=137', alt: 'Fragole su piatto di ceramica artigianale' },
      { src: 'https://picsum.photos/1000/700?random=138', alt: 'Castagne arrostite in una ciotola smaltata' },
      { src: 'https://picsum.photos/1000/700?random=139', alt: 'Limoni verdi e gialli su tela grezza' }
    ]
  }
];

const categories = ['Tutte', 'Tavolo quotidiano', 'Tavolo condiviso', 'Studio ingredienti'];

const Portfolio = () => {
  const [filter, setFilter] = useState('Tutte');

  const filteredSeries = useMemo(() => {
    if (filter === 'Tutte') return series;
    return series.filter((serie) => serie.category === filter);
  }, [filter]);

  return (
    <>
      <Helmet>
        <title>Portfolio fotografico | Fetta Di Giorno</title>
        <meta
          name="description"
          content="Portfolio fotografico di Fetta Di Giorno: serie dedicate a tavole reali, ingredienti stagionali e progetti con produttori."
        />
        <link rel="canonical" href="https://www.fettadigiorno.it/portfolio" />
      </Helmet>
      <section className="section portfolio-hero">
        <div className="container">
          <div className="section-heading">
            <p className="overline">Portfolio</p>
            <h1 className="page-title">Fotografie della nostra cucina reale</h1>
            <p className="lead">
              Amiamo raccontare le tavole vere: quelle che si apparecchiano in famiglia,
              che cambiano luce durante la giornata e che accolgono amici. Sfoglia le nostre serie fotografiche.
            </p>
          </div>
          <div className="project-filters" role="tablist">
            {categories.map((category) => (
              <button
                type="button"
                key={category}
                className={`filter-chip ${filter === category ? 'filter-chip--active' : ''}`}
                onClick={() => setFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="section portfolio-list">
        <div className="container">
          {filteredSeries.map((serie) => (
            <article key={serie.title} className="portfolio-block">
              <div className="portfolio-header">
                <span className="badge">{serie.category}</span>
                <h2>{serie.title}</h2>
                <p>{serie.description}</p>
              </div>
              <div className="portfolio-gallery">
                {serie.images.map((image) => (
                  <motion.figure
                    key={image.src}
                    className="portfolio-image"
                    whileHover={{ scale: 1.03 }}
                    transition={{ duration: 0.25 }}
                  >
                    <img src={image.src} alt={image.alt} loading="lazy" />
                  </motion.figure>
                ))}
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Portfolio;