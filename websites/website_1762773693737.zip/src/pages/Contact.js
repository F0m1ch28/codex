import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';

const Contact = () => {
  const [formValues, setFormValues] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    setFormValues((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const { name, email, message } = formValues;

    if (!name || !email || !message) {
      setStatus({ type: 'error', message: 'Compila tutti i campi prima di inviare.' });
      return;
    }

    const emailRegex = /\S+@\S+\.\S+/;
    if (!emailRegex.test(email)) {
      setStatus({ type: 'error', message: 'Inserisci un indirizzo email valido.' });
      return;
    }

    setStatus({
      type: 'success',
      message: 'Grazie! Ti risponderemo entro 48 ore.'
    });
    setFormValues({ name: '', email: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Contatti | Fetta Di Giorno</title>
        <meta
          name="description"
          content="Contatta Fetta Di Giorno: indirizzo a Milano, email, telefono e form per proporre ricette o collaborazioni."
        />
        <link rel="canonical" href="https://www.fettadigiorno.it/contatti" />
      </Helmet>
      <section className="section contact-hero">
        <div className="container contact-hero-grid">
          <div className="contact-hero-text">
            <p className="overline">Contatti</p>
            <h1 className="page-title">Scrivici, vieni a trovarci, raccontaci la tua ricetta</h1>
            <p className="lead">
              Siamo nel quartiere Ortica, Milano. Ci piace incontrare chi ama la cucina
              semplice e stagionale. Mandaci una mail, chiamaci o passa per un caffè.
            </p>
          </div>
          <div className="contact-details">
            <div className="contact-card">
              <h3>Indirizzo</h3>
              <p>
                Via Privata Flumendosa 11<br />
                20132 Milano MI, Italia
              </p>
            </div>
            <div className="contact-card">
              <h3>Email e telefono</h3>
              <p>
                <a href="mailto:ciao@fettadigiorno.it">ciao@fettadigiorno.it</a><br />
                <a href="tel:+390257892146">+39 02 5789 2146</a>
              </p>
            </div>
            <div className="contact-card">
              <h3>Orari</h3>
              <p>
                Lunedì - Venerdì: 9:30 - 18:00<br />
                Sabato su appuntamento
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section contact-map">
        <div className="container">
          <div className="map-wrapper">
            <iframe
              title="Mappa di Fetta Di Giorno a Milano"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2798.778284325932!2d9.245171915557824!3d45.49070273868771!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4786c6ecce0ee907%3A0x5c2e9b99b4e72f4!2sVia%20Privata%20Flumendosa%2C%2011%2C%2020132%20Milano%20MI!5e0!3m2!1sit!2sit!4v1681478453000!5m2!1sit!2sit"
              allowFullScreen
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="section contact-form-section">
        <div className="container contact-form-grid">
          <div>
            <h2>Mandaci un messaggio</h2>
            <p>
              Scrivici per collaborazioni, richieste stampa, laboratori o per inviarci
              una ricetta di famiglia. Ci piace conoscere le storie che stanno dietro ai piatti.
            </p>
            <p className="note">
              Nota: le ricette inviate dai lettori vengono testate e pubblicate citando sempre l’autore.
            </p>
          </div>
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <label htmlFor="name">Nome e cognome</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Il tuo nome"
              value={formValues.name}
              onChange={handleChange}
              required
            />
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="nome@email.it"
              value={formValues.email}
              onChange={handleChange}
              required
            />
            <label htmlFor="message">Messaggio</label>
            <textarea
              id="message"
              name="message"
              rows={6}
              placeholder="Raccontaci cosa ti piacerebbe condividere..."
              value={formValues.message}
              onChange={handleChange}
              required
            />
            <button type="submit" className="btn btn-primary">
              Invia il messaggio
            </button>
            {status.message && (
              <p className={`form-status form-status--${status.type}`}>
                {status.message}
              </p>
            )}
          </form>
        </div>
      </section>
    </>
  );
};

export default Contact;