import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';

const posts = [
  {
    title: 'Pomodori che profumano d’estate',
    href: '/blog/pomodori-che-profumano-d-estate',
    excerpt: 'Profumi, consistenze e gesti per scegliere pomodori dolci, maturi e pronti alla bruschetta.'
  },
  {
    title: 'Come tostiamo il pane a casa',
    href: '/blog/come-tostiamo-il-pane-a-casa',
    excerpt: 'Padelle, forno e griglia: ogni metodo ha piccoli segreti per una tostatura uniforme.'
  },
  {
    title: 'Come proviamo le erbe in cucina',
    href: '/blog/come-proviamo-le-erbe-in-cucina',
    excerpt: 'Taccuini odorosi, infusi e abbinamenti per capire quali erbe tenere sempre a portata.'
  }
];

const Blog = () => (
  <>
    <Helmet>
      <title>Blog | Fetta Di Giorno</title>
      <meta
        name="description"
        content="Articoli di Fetta Di Giorno dedicati a ingredienti, tecniche casalinghe e storie di tavole italiane."
      />
      <link rel="canonical" href="https://www.fettadigiorno.it/blog" />
    </Helmet>
    <section className="section blog-hero">
      <div className="container">
        <div className="section-heading">
          <p className="overline">Blog</p>
          <h1 className="page-title">Storie, approfondimenti e appunti odorosi</h1>
          <p className="lead">
            Ogni articolo nasce da un ingrediente che ci ha conquistati, una tecnica
            che testiamo più volte o un dettaglio di vita reale a cui teniamo.
          </p>
        </div>
        <div className="articles-grid">
          {posts.map((post) => (
            <motion.article
              key={post.href}
              className="article-card"
              whileHover={{ translateY: -8 }}
              transition={{ duration: 0.25 }}
            >
              <h2 className="card-title">{post.title}</h2>
              <p>{post.excerpt}</p>
              <Link className="card-link" to={post.href}>
                Leggi di più →
              </Link>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Blog;