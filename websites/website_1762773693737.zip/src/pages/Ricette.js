import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';

const recipes = [
  {
    id: 'risotto-piselli',
    title: 'Risotto ai piselli, limone e timo',
    category: 'Primavera',
    description: 'Un risotto cremoso con acqua di piselli e scorza di limone.',
    image: 'https://picsum.photos/700/520?random=91',
    ingredients: [
      '320 g di riso carnaroli',
      '400 g di piselli freschi',
      '1 cipollotto fresco',
      '1 litro di brodo vegetale',
      '40 g di burro freddo',
      '40 g di parmigiano grattugiato',
      '1 limone non trattato',
      'Timo fresco',
      'Olio extravergine di oliva',
      'Sale grosso',
      'Pepe bianco',
      '1 foglia di alloro'
    ],
    paragraphs: [
      'Sbollenta i piselli in acqua salata per tre minuti, poi scolali conservando il liquido di cottura. Frulla metà dei piselli con un mestolo di acqua e un filo d’olio: diventerà la crema verde che useremo alla fine.',
      'In casseruola soffriggi dolcemente il cipollotto in olio e alloro. Tosta il riso per due minuti, sfuma con un mestolo di acqua dei piselli e cuoci aggiungendo brodo caldo, mescolando con calma.',
      'A fine cottura incorpora la crema di piselli, la scorza di limone e il resto dei piselli interi. Manteca fuori dal fuoco con burro e parmigiano. Servi con timo fresco e una grattata di pepe bianco.'
    ],
    note: 'Il trucco è conservare l’acqua dolce dei piselli: rende il risotto verde e intensamente profumato senza appesantire.'
  },
  {
    id: 'pasta-sgombro',
    title: 'Spaghetti con sgombro, agretti e limone',
    category: 'Primavera',
    description: 'Spaghetti veloci con filetti di sgombro scottati e agretti croccanti.',
    image: 'https://picsum.photos/700/520?random=92',
    ingredients: [
      '360 g di spaghetti',
      '2 filetti di sgombro freschi',
      '150 g di agretti puliti',
      '1 spicchio d’aglio',
      'Olio extravergine di oliva',
      'Scorza di 1 limone',
      'Prezzemolo tritato',
      'Peperoncino fresco',
      'Sale marino',
      'Pepe nero',
      '20 g di mandorle tostate',
      'Fleur de sel'
    ],
    paragraphs: [
      'Sbollenta gli agretti per un minuto in acqua salata e raffreddali. In padella antiaderente scalda olio, aglio e peperoncino, poi aggiungi lo sgombro spellato tagliato a bocconi e rosola per due minuti.',
      'Cuoci gli spaghetti molto al dente e trasferiscili nella padella con un mestolo di acqua di cottura. Unisci agretti, scorza di limone e prezzemolo. Salta energicamente per creare un’emulsione lucida.',
      'Servi con mandorle tostate tritate e un pizzico di fleur de sel. Il piatto deve rimanere brillante e succoso.'
    ],
    note: 'Usa sgombro freschissimo: chiedi al pescivendolo di spinare i filetti per risparmiare tempo.'
  },
  {
    id: 'insalata-farro',
    title: 'Farro tiepido con fragole e feta',
    category: 'Estate',
    description: 'Insalata tiepida di farro con fragole, cetriolo e feta sbriciolata.',
    image: 'https://picsum.photos/700/520?random=93',
    ingredients: [
      '250 g di farro perlato',
      '200 g di fragole mature',
      '1 cetriolo',
      '120 g di feta greca',
      'Una manciata di pistacchi',
      'Basilico fresco',
      'Succo di mezzo limone',
      'Olio extravergine delicato',
      'Sale in fiocchi',
      'Pepe rosa',
      '1 cucchiaino di miele di tiglio',
      'Aceto di vino bianco'
    ],
    paragraphs: [
      'Cuoci il farro in acqua salata finché rimane al dente. Scolalo e condiscilo ancora caldo con olio, succo di limone, miele e una goccia di aceto.',
      'Taglia le fragole a spicchi, il cetriolo a fettine sottili e spezzetta la feta con le mani. Unisci al farro tiepido insieme a basilico fresco e pistacchi tritati grossolanamente.',
      'Aggiusta di sale e pepe rosa pestato. Servi subito oppure conserva a temperatura ambiente per un picnic rapido.'
    ],
    note: 'La feta va aggiunta a mano per mantenerla irregolare e assorbire meglio il condimento.'
  },
  {
    id: 'panzanella',
    title: 'Panzanella di pane di segale e pomodori gialli',
    category: 'Estate',
    description: 'Un classico toscano rivisitato con pane di segale e pomodori colorati.',
    image: 'https://picsum.photos/700/520?random=94',
    ingredients: [
      '4 fette di pane di segale raffermo',
      '500 g di pomodori misti gialli e rossi',
      '1 cipolla rossa di Tropea',
      'Basilico e origano freschi',
      '1 cetriolo piccolo',
      'Aceto di mele',
      'Olio extravergine fruttato',
      'Sale grosso',
      'Pepe nero',
      '1 cucchiaino di capperi sotto sale',
      'Olive taggiasche',
      'Acqua fredda'
    ],
    paragraphs: [
      'Ammolla il pane in acqua fredda e aceto per pochi minuti, strizzalo e spezzettalo in una ciotola ampia.',
      'Taglia i pomodori in pezzetti irregolari, affetta sottile la cipolla e il cetriolo, sciacqua i capperi e tieni da parte. Versa tutto sul pane.',
      'Condisci con olio abbondante, basilico, origano e olive. Massaggia con le mani per distribuire il succo dei pomodori. Lascia riposare 20 minuti in frigorifero e servi freddo.'
    ],
    note: 'Lascia riposare la panzanella il tempo necessario perché il pane assorba il succo dei pomodori senza sfaldarsi.'
  },
  {
    id: 'crespelle-carciofi',
    title: 'Crespelle ai carciofi e robiola di capra',
    category: 'Inverno',
    description: 'Crespelle sottili ripiene di carciofi stufati e robiola fresca.',
    image: 'https://picsum.photos/700/520?random=95',
    ingredients: [
      '200 g di farina 0',
      '3 uova',
      '400 ml di latte',
      '6 carciofi violetti',
      '200 g di robiola di capra',
      '40 g di parmigiano',
      '1 spicchio d’aglio',
      'Prezzemolo fresco',
      'Noce moscata',
      'Brodo vegetale leggero',
      'Burro per la teglia',
      'Sale e pepe'
    ],
    paragraphs: [
      'Prepara la pastella con farina, uova, latte e un pizzico di sale. Lascia riposare 30 minuti in frigorifero.',
      'Monda i carciofi, tagliali a lamelle e stufali in padella con aglio, olio e un mestolo di brodo. Cuoci finché sono morbidi e profuma con prezzemolo tritato.',
      'Cuoci le crespelle sottili in una padella antiaderente. Farcisci con carciofi e robiola, arrotola e disponi in teglia imburrata. Spolvera di parmigiano e gratina per 10 minuti a 200°C.'
    ],
    note: 'Per una crema più morbida frulla metà dei carciofi con un cucchiaio di robiola prima di farcire.'
  },
  {
    id: 'zuppa-fagioli',
    title: 'Zuppa di fagioli, cavolo nero e pane abbrustolito',
    category: 'Inverno',
    description: 'Una zuppa robusta con fagioli cannellini e cavolo nero stufato.',
    image: 'https://picsum.photos/700/520?random=96',
    ingredients: [
      '300 g di fagioli cannellini secchi',
      '1 mazzo di cavolo nero',
      '1 carota',
      '1 costa di sedano',
      '1 cipolla',
      '2 spicchi d’aglio',
      '2 foglie di alloro',
      'Rosmarino fresco',
      'Brodo vegetale',
      'Pane toscano',
      'Olio extravergine',
      'Pepe nero',
      'Sale marino',
      'Peperoncino essiccato'
    ],
    paragraphs: [
      'Metti in ammollo i fagioli per una notte. Cuocili con alloro e aglio finché teneri, salando solo alla fine.',
      'Prepara un soffritto con carota, sedano, cipolla, rosmarino e peperoncino. Aggiungi il cavolo nero tagliato a strisce e ammorbidisci con brodo caldo.',
      'Unisci i fagioli con la loro acqua e prosegui la cottura per 20 minuti. Servi con pane abbrustolito strofinato con aglio e olio a crudo.'
    ],
    note: 'Conserva una parte di fagioli interi e frulla il resto per una consistenza avvolgente.'
  },
  {
    id: 'gallette-mele',
    title: 'Gallette di mele e nocciole',
    category: 'Autunno',
    description: 'Pasta brisée integrale con mele caramellate e nocciole tostate.',
    image: 'https://picsum.photos/700/520?random=97',
    ingredients: [
      '200 g di farina semi integrale',
      '120 g di burro freddo',
      '50 ml di acqua ghiacciata',
      '3 mele renette',
      '40 g di zucchero di canna',
      'Cannella in polvere',
      'Nocciole tostate',
      'Succo di mezzo limone',
      'Sale fino',
      '1 uovo per spennellare',
      '1 cucchiaio di miele di castagno',
      'Vaniglia naturale'
    ],
    paragraphs: [
      'Prepara la brisée lavorando farina, sale e burro a pezzetti fino a ottenere un composto sabbioso. Aggiungi acqua ghiacciata quanto basta per compattare. Riposa in frigorifero per 30 minuti.',
      'Affetta le mele sottili e condiscile con limone, zucchero, cannella e vaniglia. Stendi la pasta in dischi rustici, sistema le mele sovrapponendole e ripiega i bordi.',
      'Spennella con uovo, spolvera di nocciole tritate e cuoci a 190°C per 25 minuti. Servi con miele di castagno appena scaldato.'
    ],
    note: 'Scegli mele renette leggermente acidule: reggono la cottura e bilanciano la dolcezza del miele.'
  },
  {
    id: 'hummus-zucca',
    title: 'Hummus di zucca arrosto e ceci',
    category: 'Autunno',
    description: 'Crema vellutata con zucca al forno, ceci, tahina e spezie calde.',
    image: 'https://picsum.photos/700/520?random=98',
    ingredients: [
      '400 g di zucca delica',
      '250 g di ceci cotti',
      '2 cucchiai di tahina',
      '1 spicchio d’aglio',
      'Succo di un limone',
      'Semi di cumino',
      'Paprika affumicata',
      'Olio extravergine',
      'Sale marino',
      'Pepe nero',
      'Semi di zucca tostati',
      'Erba cipollina fresca'
    ],
    paragraphs: [
      'Arrostisci la zucca a fette con olio, sale e cumino a 200°C finché caramellata. Lascia intiepidire.',
      'Nel frullatore unisci ceci, tahina, aglio, limone e la zucca pulita dalla buccia. Aggiungi acqua fredda per regolare la consistenza.',
      'Condisci con olio, paprika e semi di zucca tostati. Servi con pane caldo o verdure crude.'
    ],
    note: 'Frulla a lungo aggiungendo acqua ghiacciata: l’hummus risulterà leggerissimo e montato.'
  },
  {
    id: 'tagliata-cavolfiore',
    title: 'Tagliata di cavolfiore con salsa alle nocciole',
    category: 'Base',
    description: 'Fette spesse di cavolfiore arrostite con salsa cremosa alle nocciole.',
    image: 'https://picsum.photos/700/520?random=99',
    ingredients: [
      '1 cavolfiore bianco',
      'Olio extravergine di oliva',
      'Sale affumicato',
      'Pepe nero',
      '50 g di nocciole',
      '2 cucchiai di yogurt greco',
      '1 cucchiaio di miso bianco',
      'Succo di mezzo limone',
      'Paprika dolce',
      'Prezzemolo fresco',
      'Acqua calda',
      'Scorza di arancia'
    ],
    paragraphs: [
      'Taglia il cavolfiore a fette spesse di 2 cm, spennella con olio e condisci con sale affumicato e pepe. Cuoci su teglia calda a 220°C per 18 minuti, girando a metà cottura.',
      'Prepara la salsa frullando nocciole tostate, yogurt, miso, limone e un poco d’acqua calda fino a ottenere una crema vellutata.',
      'Servi la tagliata di cavolfiore con salsa, paprika e scorza di arancia. Completa con prezzemolo tritato.'
    ],
    note: 'Per una crosticina perfetta termina con 2 minuti di grill e tieni la teglia vicina alla resistenza.'
  },
  {
    id: 'uova-al-forno',
    title: 'Uova al forno con pomodori confit',
    category: 'Base',
    description: 'Uova in cocotte con pomodori confit, erbe e pane croccante.',
    image: 'https://picsum.photos/700/520?random=100',
    ingredients: [
      '4 uova freschissime',
      '300 g di pomodorini',
      '2 spicchi d’aglio',
      'Origano fresco',
      'Timo limonato',
      'Olio extravergine',
      'Sale e pepe',
      'Pane rustico',
      'Ricotta salata',
      'Peperoncino fresco',
      'Zucchero di canna',
      'Aceto balsamico'
    ],
    paragraphs: [
      'Condisci i pomodorini con olio, sale, zucchero e aceto balsamico. Cuocili in forno a 160°C per 45 minuti finché confit.',
      'Distribuisci i pomodorini in cocotte, apri le uova sopra e aggiungi erbe fresche. Inforna a 180°C per 8-10 minuti finché l’albume sarà quasi cotto.',
      'Servi con pane tostato, ricotta salata grattugiata e qualche rondella di peperoncino.'
    ],
    note: 'Togli le cocotte dal forno quando il centro è ancora morbido: continuerà a cuocere per inerzia.'
  },
  {
    id: 'gnocchi-ricotta',
    title: 'Gnocchi di ricotta con spinaci novelli',
    category: 'Primavera',
    description: 'Gnocchi leggeri di ricotta setacciata, conditi con spinaci e burro nocciola.',
    image: 'https://picsum.photos/700/520?random=101',
    ingredients: [
      '400 g di ricotta fresca',
      '160 g di farina 00',
      '80 g di parmigiano',
      '1 uovo',
      'Noce moscata',
      'Sale fino',
      '400 g di spinaci novelli',
      '50 g di burro',
      'Salvia fresca',
      'Scorza di limone',
      'Pepe bianco',
      'Semi di papavero tostati'
    ],
    paragraphs: [
      'Scola la ricotta per almeno un’ora, poi setacciala. Mescola con farina, parmigiano, uovo, sale e noce moscata fino a ottenere un impasto morbido.',
      'Forma cordoncini e taglia gli gnocchi. Cuocili in acqua salata finché salgono a galla.',
      'In padella sciogli burro con salvia, aggiungi spinaci e lascia appassire. Salta gli gnocchi nel burro nocciola, completa con scorza di limone e semi di papavero.'
    ],
    note: 'La ricotta deve essere ben asciutta per evitare di aggiungere troppa farina.'
  },
  {
    id: 'polenta-cremosa',
    title: 'Polenta cremosa con funghi trifolati',
    category: 'Inverno',
    description: 'Polenta morbida con latte e acqua, servita con funghi misti trifolati.',
    image: 'https://picsum.photos/700/520?random=102',
    ingredients: [
      '250 g di farina di mais fioretto',
      '1 litro di acqua',
      '500 ml di latte intero',
      '50 g di burro',
      'Parmigiano grattugiato',
      '500 g di funghi misti',
      'Aglio e prezzemolo',
      'Olio extravergine',
      'Timo fresco',
      'Sale e pepe',
      'Peperoncino in fiocchi',
      'Brodo vegetale'
    ],
    paragraphs: [
      'Porta a bollore acqua e latte, aggiungi sale e versa la farina di mais a pioggia mescolando con una frusta. Cuoci a fuoco dolce per 40 minuti, aggiungendo brodo se serve.',
      'Salta i funghi in padella con olio, aglio e timo. Sfumali con un goccio di brodo e termina con prezzemolo tritato.',
      'Manteca la polenta con burro e parmigiano. Servila morbida in ciotole con i funghi sopra e qualche fiocco di peperoncino.'
    ],
    note: 'Per una polenta ancora più vellutata usa metà acqua e metà latte e monta con una frusta negli ultimi minuti.'
  },
  {
    id: 'insalata-finocchi',
    title: 'Insalata di finocchi, arance e capperi fritti',
    category: 'Inverno',
    description: 'Finocchi croccanti con arance bionde, capperi fritti e mandorle.',
    image: 'https://picsum.photos/700/520?random=103',
    ingredients: [
      '2 finocchi grandi',
      '2 arance bionde',
      'Capperi sotto sale',
      'Mandorle pelate',
      'Olive nere',
      'Olio extravergine',
      'Aceto di vino bianco',
      'Sale e pepe',
      'Aneto fresco',
      'Semi di finocchio',
      'Miele agli agrumi',
      'Succo di limone'
    ],
    paragraphs: [
      'Affetta i finocchi sottilissimi con la mandolina e immergili in acqua ghiacciata per 10 minuti. Asciuga bene.',
      'Friggi i capperi sciacquati in olio caldo finché croccanti. Tosta le mandorle in padella.',
      'Assemblaggio: finocchi, spicchi di arancia pelati al vivo, olive, capperi. Condisci con olio, aceto, miele e semi di finocchio. Completa con aneto fresco.'
    ],
    note: 'Il bagno in acqua ghiacciata rende i finocchi croccantissimi e bianchi.'
  },
  {
    id: 'cavolo-rapa',
    title: 'Cavolo rapa arrosto con crema di yogurt e erbe',
    category: 'Primavera',
    description: 'Cavolo rapa arrosto servito con crema di yogurt e molte erbe.',
    image: 'https://picsum.photos/700/520?random=104',
    ingredients: [
      '3 cavoli rapa',
      'Olio extravergine',
      'Sale in fiocchi',
      'Pepe nero',
      'Yogurt greco intero',
      'Aneto, erba cipollina e menta',
      'Succo di lime',
      'Semi di sesamo nero',
      'Miele millefiori',
      'Peperoncino fresco',
      'Scorza di lime',
      'Paprika dolce'
    ],
    paragraphs: [
      'Taglia il cavolo rapa a spicchi, condisci con olio, sale e paprika. Arrostisci a 210°C per 25 minuti finché dorato.',
      'Prepara la crema mescolando yogurt, erbe tritate, lime, miele e un pizzico di sale.',
      'Servi il cavolo rapa caldo sulla crema, completa con sesamo nero e peperoncino a rondelle.'
    ],
    note: 'Arrostisci su teglia ben calda per ottenere bordi caramellati.'
  }
];

const categories = ['Tutte', 'Primavera', 'Estate', 'Autunno', 'Inverno', 'Base'];

const Ricette = () => {
  const [activeCategory, setActiveCategory] = useState('Tutte');
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  const filteredRecipes = useMemo(() => {
    if (activeCategory === 'Tutte') return recipes;
    return recipes.filter((recipe) => recipe.category === activeCategory);
  }, [activeCategory]);

  return (
    <>
      <Helmet>
        <title>Ricette di stagione | Fetta Di Giorno</title>
        <meta
          name="description"
          content="Sfoglia le ricette di Fetta Di Giorno: piatti di stagione provati in cucina, ingredienti dettagliati e note pratiche."
        />
        <link rel="canonical" href="https://www.fettadigiorno.it/ricette" />
      </Helmet>
      <section className="section recipes-hero">
        <div className="container recipes-hero-grid">
          <div className="recipes-hero-text">
            <p className="overline">Raccolta</p>
            <h1 className="page-title">Ricette provate e fotografate nella nostra cucina</h1>
            <p className="lead">
              Ogni ricetta nasce dalla tavola di casa: ingredienti misurati, passaggi chiari e note per replicarla senza stress. Seleziona la stagione e lasciati guidare.
            </p>
          </div>
          <div className="recipes-filter" role="tablist">
            {categories.map((category) => (
              <button
                type="button"
                key={category}
                className={`filter-chip ${activeCategory === category ? 'filter-chip--active' : ''}`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="section recipes-grid-section">
        <div className="container">
          <div className="recipes-grid">
            {filteredRecipes.map((recipe) => (
              <motion.article
                key={recipe.id}
                className="recipe-card--grid"
                whileHover={{ translateY: -8 }}
                transition={{ duration: 0.25 }}
              >
                <button
                  type="button"
                  className="recipe-card__button"
                  onClick={() => setSelectedRecipe(recipe)}
                  aria-label={`Apri la ricetta ${recipe.title}`}
                >
                  <div className="recipe-card__thumb">
                    <img src={recipe.image} alt={`Ricetta ${recipe.title}`} loading="lazy" />
                    <span className="badge">{recipe.category}</span>
                  </div>
                  <div className="recipe-card__content">
                    <h3>{recipe.title}</h3>
                    <p>{recipe.description}</p>
                    <span className="card-link">Apri la ricetta →</span>
                  </div>
                </button>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <AnimatePresence>
        {selectedRecipe && (
          <motion.div
            className="modal-overlay"
            role="dialog"
            aria-modal="true"
            aria-label={`Ricetta ${selectedRecipe.title}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="modal-content"
              initial={{ scale: 0.95, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 20, opacity: 0 }}
              transition={{ duration: 0.25 }}
            >
              <button
                type="button"
                className="modal-close"
                onClick={() => setSelectedRecipe(null)}
                aria-label="Chiudi ricetta"
              >
                ×
              </button>
              <div className="modal-grid">
                <div className="modal-image">
                  <img src={selectedRecipe.image} alt={`Preparazione di ${selectedRecipe.title}`} />
                </div>
                <div className="modal-body">
                  <span className="badge">{selectedRecipe.category}</span>
                  <h2>{selectedRecipe.title}</h2>
                  <p className="lead">{selectedRecipe.description}</p>
                  <h3>Ingredienti</h3>
                  <ul className="modal-list">
                    {selectedRecipe.ingredients.map((ingredient) => (
                      <li key={ingredient}>{ingredient}</li>
                    ))}
                  </ul>
                </div>
              </div>
              <div className="modal-details">
                <h3>Procedimento</h3>
                {selectedRecipe.paragraphs.map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
                <div className="modal-note">
                  <strong>Nota di cucina:</strong> {selectedRecipe.note}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Ricette;