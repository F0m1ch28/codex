import React from 'react';
import { Helmet } from 'react-helmet-async';

const BlogPomodori = () => (
  <>
    <Helmet>
      <title>Pomodori che profumano d’estate | Fetta Di Giorno</title>
      <meta
        name="description"
        content="I nostri appunti sui pomodori estivi: come sceglierli, conservarli e trasformarli in cucina."
      />
      <link
        rel="canonical"
        href="https://www.fettadigiorno.it/blog/pomodori-che-profumano-d-estate"
      />
    </Helmet>
    <article className="section blog-post">
      <div className="container blog-post-content">
        <p className="overline">Appunti di stagione</p>
        <h1 className="page-title">Pomodori che profumano d’estate</h1>
        <img
          src="https://picsum.photos/1100/700?random=141"
          alt="Pomodori maturi su un tagliere di legno"
          className="blog-image"
          loading="lazy"
        />
        <p>
          I pomodori migliori profumano già prima di essere tagliati. Al mercato li
          avvicino al naso: devono ricordare le foglie, la terra ancora fresca, la
          pianta. Quando manca quel profumo, aspettiamo. Nessuna fretta, perché la
          pazienza è la prima componente della salsa.
        </p>
        <p>
          Li scegliamo maturi ma non molli, con un picciolo ancora teso. Preferiamo
          varietà medio-piccole perché concentrano il sapore: datterini per le cotture
          veloci, cuore di bue per i condimenti a crudo, costoluti per la passata.
        </p>
        <blockquote className="blog-quote">
          “La prova del pomodoro perfetto? Il sapore della buccia. Se è dolce e sottile,
          avrai una polpa generosa anche senza zucchero.”
        </blockquote>
        <p>
          A casa li laviamo rapidamente, mai in ammollo. Li lasciamo asciugare su un
          canovaccio e poi decidiamo la loro strada: alcuni finiscono in forno per
          diventare confit, altri sono destinati a bruschette veloci, gli ultimi
          vengono scottati e spellati per la conserva dell’anno.
        </p>
        <img
          src="https://picsum.photos/1100/700?random=142"
          alt="Pomodori tagliati a metà pronti per essere infornati"
          className="blog-image"
          loading="lazy"
        />
        <p>
          Quando arrivano amici improvvisati prepariamo una padella di pomodori
          confit: li adagiamo con spicchi d’aglio, timo e un pizzico di zucchero di
          canna. A 160°C per 45 minuti diventano caramellati, pronti per condire pasta
          o crostini.
        </p>
        <p>
          La passata invece richiede una domenica pomeriggio. Li tagliamo, li cuociamo
          con basilico e li passiamo con il passaverdura grande. Le bottiglie vengono
          sterilizzate con cura e avvolte in coperte fino al mattino. È la nostra
          assicurazione contro l’inverno.
        </p>
        <p>
          Un ultimo trucco: conserva sempre un po’ di acqua dei pomodori. Aggiunta a
          fine cottura nelle salse, restituisce freschezza e quella nota verde che sa
          di foglia strofinata tra le dita.
        </p>
      </div>
    </article>
  </>
);

export default BlogPomodori;