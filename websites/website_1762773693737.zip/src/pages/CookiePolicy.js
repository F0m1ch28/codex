import React from 'react';
import { Helmet } from 'react-helmet-async';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie policy | Fetta Di Giorno</title>
      <meta
        name="description"
        content="Scopri come Fetta Di Giorno utilizza i cookie tecnici e analitici per migliorare l'esperienza di navigazione."
      />
      <link rel="canonical" href="https://www.fettadigiorno.it/cookie-policy" />
    </Helmet>
    <section className="section legal">
      <div className="container legal-content">
        <h1 className="page-title">Cookie policy</h1>
        <p>Aggiornamento: 12 aprile 2024</p>
        <h2>1. Cosa sono i cookie</h2>
        <p>
          I cookie sono piccoli file di testo che i siti visitati inviano al browser
          dell’utente, dove vengono memorizzati per essere poi ritrasmessi agli stessi
          siti alla visita successiva.
        </p>
        <h2>2. Tipologie di cookie utilizzati</h2>
        <ul>
          <li>
            <strong>Cookie tecnici</strong>: necessari al funzionamento del sito, permettono
            ad esempio la memorizzazione delle preferenze.
          </li>
          <li>
            <strong>Cookie analitici anonimizzati</strong>: utilizzati per raccogliere dati
            statistici aggregati sull’uso del sito.
          </li>
        </ul>
        <h2>3. Cookie di terze parti</h2>
        <p>
          Alcuni servizi integrati (es. mappe, font) possono inserire cookie di terze
          parti. Invitiamo a consultare le rispettive informative.
        </p>
        <h2>4. Gestione delle preferenze</h2>
        <p>
          Puoi gestire i cookie tramite le impostazioni del browser oppure cliccando
          su “Preferenze” nel banner cookie del sito.
        </p>
        <h2>5. Aggiornamenti</h2>
        <p>
          La presente informativa può subire modifiche. Le variazioni saranno
          pubblicate su questa pagina.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;