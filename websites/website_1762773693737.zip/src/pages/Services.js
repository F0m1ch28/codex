import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';

const services = [
  {
    title: 'Ricette su misura per produttori',
    description:
      'Creiamo ricette dedicate a ingredienti specifici, rispettando territorio e stagionalità. Ogni proposta include test multipli e fotograﬁa naturale.',
    deliverables: ['Test e sviluppo ricette', 'Schede tecniche', 'Fotografie lifestyle e top-shot']
  },
  {
    title: 'Storytelling fotografico',
    description:
      'Costruiamo reportage intimi per botteghe, cascine e chef domestici che desiderano raccontarsi con un tono autentico e accessibile.',
    deliverables: ['Piano editoriale', 'Sessione fotografica', 'Editing e selezione finale']
  },
  {
    title: 'Workshop e laboratori',
    description:
      'Organizziamo incontri itineranti dedicati a gruppi ridotti in cui cuciniamo insieme, fotografiamo e impariamo a gestire il tempo in cucina.',
    deliverables: ['Programma completo', 'Dispense illustrate', 'Supporto post workshop']
  }
];

const workflow = [
  {
    title: 'Ascolto e brief',
    text: 'Partiamo sempre da una telefonata in cui raccogliamo il vostro punto di vista. Ci interessa capire i ritmi, le persone coinvolte e la storia.'
  },
  {
    title: 'Progetto editoriale',
    text: 'Definiamo calendario, ricette, focus fotografici e tono di voce. Condividiamo una guida visiva e un timone testuale prima di iniziare.'
  },
  {
    title: 'Produzione e test',
    text: 'Cuciniamo le ricette, realizziamo gli scatti e raccogliamo feedback in tempo reale con una bacheca condivisa.'
  },
  {
    title: 'Consegna e accompagnamento',
    text: 'Impaginiamo il materiale, consegniamo i file e restiamo disponibili per eventuali adattamenti o pubblicazioni dedicate.'
  }
];

const partners = [
  {
    name: 'Cascina Gelsomino',
    quote: 'Hanno tradotto il carattere delle nostre verdure in immagini delicate e precise. Il servizio fotografico sembra un giorno trascorso insieme in cascina.',
    role: 'Azienda agricola biologica'
  },
  {
    name: 'Pane Sottocasa',
    quote: 'Il laboratorio con i nostri clienti è stato intimo e concreto: abbiamo impastato, fotografato e costruito ricette da replicare a casa.',
    role: 'Forno artigianale a Milano'
  },
  {
    name: 'Mercato Diffuso',
    quote: 'Abbiamo organizzato un percorso in quattro tappe stagionali, con ricette pronte per i nostri abbonati e foto da utilizzare nel catalogo.',
    role: 'Rete di piccoli produttori'
  }
];

const Services = () => (
  <>
    <Helmet>
      <title>Servizi editoriali | Fetta Di Giorno</title>
      <meta
        name="description"
        content="Servizi editoriali e fotografici di Fetta Di Giorno: sviluppo ricette, storytelling e laboratori per produttori e botteghe."
      />
      <link rel="canonical" href="https://www.fettadigiorno.it/servizi" />
    </Helmet>
    <section className="section services-hero">
      <div className="container services-hero-grid">
        <motion.div
          className="services-hero-text"
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <p className="overline">Servizi</p>
          <h1 className="page-title">Aiutiamo produttori e botteghe a raccontarsi</h1>
          <p className="lead">
            Offriamo ricette dedicate, fotografie sincere e workshop leggeri per chi
            desidera mostrare la propria cucina senza artifici. Costruiamo progetti
            su misura, con la stessa cura che mettiamo nel nostro blog.
          </p>
        </motion.div>
        <motion.div
          className="services-hero-photo"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <img
            src="https://picsum.photos/1100/700?random=81"
            alt="Set fotografico con ingredienti freschi e luci morbide"
            loading="lazy"
          />
        </motion.div>
      </div>
    </section>

    <section className="section services-list">
      <div className="container">
        <div className="section-heading">
          <p className="overline">Cosa possiamo fare insieme</p>
          <h2 className="section-title">Servizi principali</h2>
        </div>
        <div className="services-grid">
          {services.map((service) => (
            <motion.article
              key={service.title}
              className="service-card"
              whileHover={{ translateY: -8 }}
              transition={{ duration: 0.25 }}
            >
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <ul>
                {service.deliverables.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </motion.article>
          ))}
        </div>
      </div>
    </section>

    <section className="section workflow">
      <div className="container">
        <div className="section-heading">
          <p className="overline">Processo</p>
          <h2 className="section-title">Come lavoriamo con i partner</h2>
        </div>
        <div className="workflow-grid">
          {workflow.map((step, index) => (
            <motion.article
              key={step.title}
              className="workflow-card"
              whileHover={{ translateY: -6 }}
              transition={{ duration: 0.25 }}
            >
              <span className="workflow-step">{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </motion.article>
          ))}
        </div>
      </div>
    </section>

    <section className="section partners">
      <div className="container">
        <div className="section-heading">
          <p className="overline">Testimonianze</p>
          <h2 className="section-title">Voci di chi ha lavorato con noi</h2>
        </div>
        <div className="partners-grid">
          {partners.map((partner) => (
            <motion.blockquote
              key={partner.name}
              className="partner-card"
              whileHover={{ translateY: -8 }}
              transition={{ duration: 0.25 }}
            >
              <p>“{partner.quote}”</p>
              <footer>
                <strong>{partner.name}</strong>
                <span>{partner.role}</span>
              </footer>
            </motion.blockquote>
          ))}
        </div>
      </div>
    </section>

    <section className="section services-cta">
      <div className="container cta-box">
        <div className="cta-text">
          <h2>Parliamo del tuo progetto</h2>
          <p>
            Raccontaci l’idea, l’ingrediente o l’evento che vuoi condividere. Rispondiamo
            entro 48 ore e fissiamo una chiamata conoscitiva.
          </p>
        </div>
        <a className="btn btn-primary" href="/contatti">
          Scrivici dal form
        </a>
      </div>
    </section>
  </>
);

export default Services;