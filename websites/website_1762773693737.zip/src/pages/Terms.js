import React from 'react';
import { Helmet } from 'react-helmet-async';

const Terms = () => (
  <>
    <Helmet>
      <title>Termini di utilizzo | Fetta Di Giorno</title>
      <meta
        name="description"
        content="Consulta i termini di utilizzo del sito Fetta Di Giorno, blog di cucina italiana quotidiana."
      />
      <link rel="canonical" href="https://www.fettadigiorno.it/termini" />
    </Helmet>
    <section className="section legal">
      <div className="container legal-content">
        <h1 className="page-title">Termini di utilizzo</h1>
        <p>Aggiornamento: 12 aprile 2024</p>
        <h2>1. Introduzione</h2>
        <p>
          L’accesso e l’utilizzo del sito Fetta Di Giorno comportano l’accettazione
          integrale dei presenti Termini di utilizzo. Se non accetti uno o più punti,
          ti invitiamo a non utilizzare il sito.
        </p>
        <h2>2. Contenuti</h2>
        <p>
          Le ricette, i testi e le fotografie pubblicate sono di proprietà degli autori
          di Fetta Di Giorno, salvo diversa indicazione. Non è consentito copiare,
          distribuire o utilizzare i contenuti senza autorizzazione scritta.
        </p>
        <h2>3. Uso personale</h2>
        <p>
          Le ricette sono destinate a un uso personale e domestico. Ogni riproduzione
          professionale richiede un accordo con la redazione.
        </p>
        <h2>4. Commenti e contributi</h2>
        <p>
          I messaggi inviati tramite il form di contatto devono essere rispettosi e
          pertinenti. Ci riserviamo il diritto di non pubblicare contributi offensivi
          o inappropriati.
        </p>
        <h2>5. Limitazione di responsabilità</h2>
        <p>
          Pur verificando con cura informazioni e ricette, non siamo responsabili di
          eventuali danni derivanti dall’uso improprio delle indicazioni fornite.
        </p>
        <h2>6. Modifiche</h2>
        <p>
          Possiamo aggiornare i Termini in qualsiasi momento. Le modifiche sono
          efficaci dal momento della pubblicazione sul sito.
        </p>
        <h2>7. Contatti</h2>
        <p>
          Per domande relative ai Termini scrivi a{' '}
          <a href="mailto:ciao@fettadigiorno.it">ciao@fettadigiorno.it</a>.
        </p>
      </div>
    </section>
  </>
);

export default Terms;