import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Helmet } from 'react-helmet-async';

const heroImage = 'https://picsum.photos/1600/900?random=11';

const statsData = [
  { label: 'Ricette provate a casa', value: 365 },
  { label: 'Anni di appunti', value: 12 },
  { label: 'Lettere spedite ogni anno', value: 48 },
  { label: 'Mercati incontrati', value: 27 }
];

const weeklyIdeas = [
  {
    title: 'Trofie al pesto di rucola e mandorle',
    description: 'Una pasta verde e profumata, pronta in dieci minuti.'
  },
  {
    title: 'Frittata soffice agli agretti',
    description: 'Uova montate a neve e agretti croccanti in padella di ferro.'
  },
  {
    title: 'Insalata tiepida di farro e fragole',
    description: 'Cereali, frutta dolce e vinaigrette agli agrumi leggeri.'
  },
  {
    title: 'Polpette di ceci al limone',
    description: 'Croccanti fuori, morbide dentro, con yogurt ed erbe fresche.'
  },
  {
    title: 'Sfoglia con zucchine e menta',
    description: 'Una base croccante, taglio quadrato e fiori di zucchina sopra.'
  },
  {
    title: 'Crostini di pane con crema di fave',
    description: 'Pane tostato, fave frullate e un filo di olio nuovo.'
  }
];

const spotlightIngredient = {
  name: 'Piselli novelli',
  description:
    'Arrivano in cassette verdi, hanno il profumo del mattino presto e la pazienza di chi si siede a sgranare lontano dal telefono. Li cuociamo appena, giusto tre minuti, e conserviamo l’acqua dolce per tirare risotti leggeri. Questi piselli sono il simbolo della stagione che cambia, della luce che allunga le giornate e dei pranzi che tornano sul terrazzo.',
  pairings: [
    'Piselli, finocchietto e burrata fresca',
    'Piselli, limone candito e orzo perlato',
    'Piselli saltati con guanciale croccante',
    'Piselli, menta e ricotta di capra',
    'Piselli, asparagi e brodo affumicato'
  ]
};

const tablePhotos = [
  {
    src: 'https://picsum.photos/800/600?random=31',
    alt: 'Tavolo di legno con piatto di pasta fresca e vino bianco'
  },
  {
    src: 'https://picsum.photos/800/600?random=32',
    alt: 'Insalata di stagione con erbe fresche su tovaglia a righe'
  },
  {
    src: 'https://picsum.photos/800/600?random=33',
    alt: 'Pane appena sfornato su tagliere di legno'
  },
  {
    src: 'https://picsum.photos/800/600?random=34',
    alt: 'Tavola apparecchiata con piatti in ceramica artigianale'
  },
  {
    src: 'https://picsum.photos/800/600?random=35',
    alt: 'Dettaglio di un piatto di verdure arrosto con erbe'
  }
];

const newRecipes = [
  {
    title: 'Orecchiette al ragù bianco di fave e piselli',
    description: 'Un condimento cremoso, scaldato con brodo vegetale e rosmarino.',
    image: 'https://picsum.photos/600/500?random=41'
  },
  {
    title: 'Carpaccio di zucchine con pistacchi e fiordilatte',
    description: 'Fette sottilissime, condite con olio al basilico fatto in casa.',
    image: 'https://picsum.photos/600/500?random=42'
  },
  {
    title: 'Zuppetta di seppie e patate novelle',
    description: 'Cottura lenta in casseruola di coccio e finitura al limone.',
    image: 'https://picsum.photos/600/500?random=43'
  }
];

const recentArticles = [
  {
    title: 'Pomodori che profumano d’estate',
    link: '/blog/pomodori-che-profumano-d-estate',
    excerpt: 'Dal mercato alle prime bruschette della stagione: come ascoltiamo i pomodori.'
  },
  {
    title: 'Come tostiamo il pane a casa',
    link: '/blog/come-tostiamo-il-pane-a-casa',
    excerpt: 'Due padelle, un filo d’olio, il tempo giusto per una crosta perfetta.'
  },
  {
    title: 'Come proviamo le erbe in cucina',
    link: '/blog/come-proviamo-le-erbe-in-cucina',
    excerpt: 'Taccuini odorosi e tè caldi per capire cosa tenere sempre sul davanzale.'
  }
];

const quickTips = [
  'Sbollenta gli asparagi interi e tagliali solo dopo, rimangono più croccanti.',
  'Aggiungi qualche goccia di aceto di mele al brodo di legumi per un sapore più rotondo.',
  'Conserva l’acqua di cottura delle verdure verdi: diventa il fondo perfetto per couscous leggeri.',
  'Usa la micro-piastra per grattugiare aglio fresco direttamente nella marinata.',
  'Spezza i pomodorini con le mani sopra la teglia: il succo fa da condimento.',
  'Il giorno dopo, scalda la pasta in padella con poca acqua e olio, mai al microonde.',
  'Tieni una ciotola di erbe tritate in frigo: salva ogni uovo strapazzato improvviso.'
];

const processSteps = [
  {
    title: 'Andiamo al mercato presto',
    description:
      'Ci dividiamo gli appunti: chi cerca il pesce, chi fa scorta di erbe. Parliamo con chi coltiva e scattiamo foto già lì, con la luce morbida delle 8.'
  },
  {
    title: 'Cuciniamo più versioni',
    description:
      'Ogni ricetta passa per tre prove: gli aggiustamenti li annotiamo direttamente sul marmo della cucina, tra le briciole di pane.'
  },
  {
    title: 'Scattiamo al tavolo',
    description:
      'Una coperta di lino, la luce di Milano filtrata dalle persiane, e gli scatti che raccontano la vita reale, con posate spaiate ma amate.'
  },
  {
    title: 'Condividiamo con calma',
    description:
      'Il testo arriva solo quando siamo certi che la ricetta funzioni anche la sera di una giornata piena. Scriviamo come parleremmo a un’amica.'
  }
];

const testimonials = [
  {
    quote:
      'Le ricette di Fetta Di Giorno sono concrete, con quell’attenzione ai dettagli che ti fa sentire in cucina con loro. Il formato step-by-step è un abbraccio.',
    name: 'Irene Conti',
    role: 'Lettrice dal 2016'
  },
  {
    quote:
      'Collaborare per la mia bottega è stato naturale: hanno restituito il sapore delle nostre verdure con immagini vere e parole oneste.',
    name: 'Carlo Berti',
    role: 'Ortolano al mercato di Lambrate'
  },
  {
    quote:
      'Le newsletter arrivano sempre al momento giusto. Sono un invito a preparare qualcosa di buono anche quando la settimana corre.',
    name: 'Lucia Pagani',
    role: 'Chef di cucina domestica'
  }
];

const teamMembers = [
  {
    name: 'Francesca Lodi',
    role: 'Scrittrice e cuoca di casa',
    bio: 'Appunti, spezie e qualche stoviglia da mercatino. Scrive e cucina con un occhio ai tempi della settimana.',
    image: 'https://picsum.photos/400/400?random=51'
  },
  {
    name: 'Marco Ferri',
    role: 'Fotografo e regista di tavole',
    bio: 'Ama la luce che filtra al mattino e i piani top-shot con texture naturali. Cura l’estetica senza mai snaturare il piatto.',
    image: 'https://picsum.photos/400/400?random=52'
  },
  {
    name: 'Giulia Serra',
    role: 'Editor e ricercatrice di ingredienti',
    bio: 'Tiene aggiornato il calendario delle stagioni, testa mercati e crea ponti con piccoli produttori italiani.',
    image: 'https://picsum.photos/400/400?random=53'
  }
];

const projectEntries = [
  {
    title: 'Tavola di Albicocche',
    description: 'Una serie di colazioni leggere con albicocche grigliate e yogurt colato.',
    category: 'Tavole di stagione',
    image: 'https://picsum.photos/1200/800?random=61'
  },
  {
    title: 'Mercato del sabato',
    description: 'Raccolta di scatti e note dai banchi di Porta Venezia in piena primavera.',
    category: 'Mercato',
    image: 'https://picsum.photos/1200/800?random=62'
  },
  {
    title: 'Dietro le quinte del ragù',
    description: 'Pentole, appunti e prove colore per un ragù bianco leggero.',
    category: 'Dietro le quinte',
    image: 'https://picsum.photos/1200/800?random=63'
  },
  {
    title: 'Tavolo della Domenica',
    description: 'Una mise en place con tovaglia panna e candele basse per pranzo condiviso.',
    category: 'Tavole di stagione',
    image: 'https://picsum.photos/1200/800?random=64'
  },
  {
    title: 'Gite in cascina',
    description: 'Visite a piccoli produttori di formaggi con degustazioni al tramonto.',
    category: 'Mercato',
    image: 'https://picsum.photos/1200/800?random=65'
  },
  {
    title: 'Test pasta fresca',
    description: 'Studio delle sfoglie sottili con farine alternative e ripieni leggeri.',
    category: 'Dietro le quinte',
    image: 'https://picsum.photos/1200/800?random=66'
  }
];

const faqItems = [
  {
    question: 'Come scegliete le ricette da pubblicare?',
    answer:
      'Partiamo da ciò che cuciniamo davvero durante la settimana e dal calendario dei prodotti freschi. Ogni ricetta che arriva online è stata provata almeno tre volte e misurata su porzioni reali.'
  },
  {
    question: 'Posso proporre un ingrediente della mia zona?',
    answer:
      'Sì, ci piace quando ci scrivete di qualcosa che coltivate o che trovate nella vostra realtà. Scriveteci con dettagli sul periodo migliore: organizziamo test e, se possibile, veniamo a trovarvi.'
  },
  {
    question: 'Come vi posso incontrare dal vivo?',
    answer:
      'Due volte l’anno organizziamo piccoli workshop di cucina in cascine lombarde. Annunciamo tutto nella newsletter con calendario, modalità e numero limitato di posti.'
  },
  {
    question: 'Che attrezzatura serve per seguire le ricette?',
    answer:
      'Ci limitiamo alla strumentazione di una cucina domestica: pentole in acciaio, padelle antiaderenti, forno statico e frullatore a immersione. Ogni ricetta indica eventuali strumenti particolari.'
  }
];

const AnimatedCounter = ({ target }) => {
  const [value, setValue] = useState(0);

  useEffect(() => {
    let frame;
    let start;
    const duration = 1200;

    const step = (timestamp) => {
      if (!start) start = timestamp;
      const progress = Math.min((timestamp - start) / duration, 1);
      setValue(Math.floor(progress * target));
      if (progress < 1) {
        frame = window.requestAnimationFrame(step);
      }
    };

    frame = window.requestAnimationFrame(step);
    return () => window.cancelAnimationFrame(frame);
  }, [target]);

  return <span>{value}</span>;
};

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Tutte');

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'Tutte') return projectEntries;
    return projectEntries.filter((entry) => entry.category === projectFilter);
  }, [projectFilter]);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const testimonial = testimonials[activeTestimonial];

  return (
    <>
      <Helmet>
        <title>Fetta Di Giorno | Cucina italiana di ogni giorno</title>
        <meta
          name="description"
          content="Ricette italiane semplici, idee di stagione e fotografie morbide. Scopri le nostre idee della settimana, ingredienti spotlight e consigli rapidi."
        />
        <link rel="canonical" href="https://www.fettadigiorno.it/" />
      </Helmet>
      <section className="hero">
        <div className="hero-image" aria-hidden="true">
          <img src={heroImage} alt="Macro ingrediente di stagione su fondo scuro" loading="lazy" />
        </div>
        <div className="container hero-content">
          <motion.div
            className="hero-text"
            initial={{ opacity: 0, y: 28 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
          >
            <p className="overline">Cucina di stagione da Milano</p>
            <h1 className="hero-title">Cucinare ogni giorno può essere leggero.</h1>
            <p className="lead">
              Fetta Di Giorno è un quaderno di cucina italiana quotidiana: ingredienti
              freschi, ricette provate più volte, fotografie calde e consigli rapidi
              per affrontare con calma anche i giorni feriali. Qui trovi ciò che finisce
              davvero sulla nostra tavola di casa.
            </p>
            <div className="hero-actions">
              <Link to="/ricette" className="btn btn-primary">
                Vai alle ricette
              </Link>
              <Link to="/blog" className="btn btn-outline">
                Leggi le storie
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section stats">
        <div className="container">
          <div className="section-heading">
            <p className="overline">Numeri di casa</p>
            <h2 className="section-title">Cosa succede in una stagione di Fetta Di Giorno</h2>
          </div>
          <div className="stats-grid">
            {statsData.map((item) => (
              <motion.div
                key={item.label}
                className="stat-card"
                whileHover={{ translateY: -6 }}
                transition={{ duration: 0.2, ease: 'easeOut' }}
              >
                <div className="stat-value">
                  <AnimatedCounter target={item.value} />
                  {item.value > 100 ? '+' : ''}
                </div>
                <p className="stat-label">{item.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section ideas">
        <div className="container">
          <div className="section-heading">
            <p className="overline">Settimana corrente</p>
            <h2 className="section-title">Idee della settimana</h2>
            <p className="section-subtitle">
              Ricette veloci e stagionali annotate sul nostro frigorifero. Ogni idea ha
              ingredienti che trovi facilmente al mercato di aprile.
            </p>
          </div>
          <div className="ideas-grid">
            {weeklyIdeas.map((idea) => (
              <motion.article
                key={idea.title}
                className="idea-card"
                whileHover={{ translateY: -8 }}
                transition={{ duration: 0.25 }}
              >
                <h3 className="card-title">{idea.title}</h3>
                <p>{idea.description}</p>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section spotlight">
        <div className="container spotlight-grid">
          <motion.div
            className="spotlight-text"
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
          >
            <p className="overline">Spotlight ingrediente</p>
            <h2 className="section-title">{spotlightIngredient.name}</h2>
            <p className="lead">{spotlightIngredient.description}</p>
          </motion.div>
          <motion.div
            className="spotlight-pairings"
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, ease: 'easeOut', delay: 0.1 }}
          >
            <h3>Abbinamenti che amiamo</h3>
            <ul>
              {spotlightIngredient.pairings.map((pairing) => (
                <li key={pairing}>{pairing}</li>
              ))}
            </ul>
          </motion.div>
        </div>
      </section>

      <section className="section table-strip">
        <div className="container">
          <div className="section-heading">
            <p className="overline">Fotografie</p>
            <h2 className="section-title">Questa settimana sul tavolo</h2>
          </div>
        </div>
        <div className="table-strip-gallery" aria-label="Questa settimana sul tavolo">
          {tablePhotos.map((photo) => (
            <div className="table-strip-item" key={photo.src}>
              <img src={photo.src} alt={photo.alt} loading="lazy" />
            </div>
          ))}
        </div>
      </section>

      <section className="section new-recipes">
        <div className="container">
          <div className="section-heading">
            <p className="overline">Appena pubblicate</p>
            <h2 className="section-title">3 ricette nuove</h2>
          </div>
          <div className="new-recipes-grid">
            {newRecipes.map((recipe) => (
              <motion.article
                key={recipe.title}
                className="recipe-card"
                whileHover={{ translateY: -12 }}
                transition={{ duration: 0.25 }}
              >
                <div className="recipe-card__image">
                  <img src={recipe.image} alt={`Ricetta ${recipe.title}`} loading="lazy" />
                </div>
                <div className="recipe-card__body">
                  <h3 className="card-title">{recipe.title}</h3>
                  <p>{recipe.description}</p>
                  <Link className="card-link" to="/ricette">
                    Vai alla raccolta →
                  </Link>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section articles">
        <div className="container">
          <div className="section-heading">
            <p className="overline">Letture</p>
            <h2 className="section-title">Articoli recenti</h2>
            <p className="section-subtitle">
              Appunti veloci e storie più lunghe su ingredienti, strumenti e buona luce.
            </p>
          </div>
          <div className="articles-grid">
            {recentArticles.map((article) => (
              <motion.article
                key={article.title}
                className="article-card"
                whileHover={{ translateY: -10 }}
                transition={{ duration: 0.25 }}
              >
                <h3 className="card-title">{article.title}</h3>
                <p>{article.excerpt}</p>
                <Link className="card-link" to={article.link}>
                  Leggi l’articolo →
                </Link>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section quick-tips">
        <div className="container">
          <div className="section-heading">
            <p className="overline">Consigli rapidi</p>
            <h2 className="section-title">Piccole cose che salvano la cena</h2>
          </div>
          <ul className="tips-list">
            {quickTips.map((tip, index) => (
              <li key={tip}>
                <span className="tip-number">{index + 1}</span>
                <p>{tip}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="section process">
        <div className="container">
          <div className="section-heading">
            <p className="overline">Dietro le quinte</p>
            <h2 className="section-title">Il nostro processo in 4 passi</h2>
          </div>
          <div className="process-grid">
            {processSteps.map((step, index) => (
              <motion.article
                key={step.title}
                className="process-card"
                whileHover={{ translateY: -6 }}
                transition={{ duration: 0.25 }}
              >
                <span className="process-step">{index + 1}</span>
                <h3 className="card-title">{step.title}</h3>
                <p>{step.description}</p>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section testimonials">
        <div className="container testimonials-wrapper">
          <div className="testimonials-text">
            <p className="overline">Testimonianze</p>
            <h2 className="section-title">Cosa dicono i nostri lettori</h2>
            <p className="section-subtitle">
              Le parole delle persone che cucinano con noi ogni settimana sono il nostro metro di misura.
            </p>
          </div>
          <div className="testimonials-carousel">
            <AnimatePresence mode="wait">
              <motion.blockquote
                key={testimonial.name}
                className="testimonial-card"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -16 }}
                transition={{ duration: 0.35 }}
              >
                <p>“{testimonial.quote}”</p>
                <footer>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </footer>
              </motion.blockquote>
            </AnimatePresence>
            <div className="testimonial-dots" role="tablist">
              {testimonials.map((item, index) => (
                <button
                  type="button"
                  key={item.name}
                  aria-label={`Testimonianza ${index + 1}`}
                  aria-selected={activeTestimonial === index}
                  className={`dot ${activeTestimonial === index ? 'dot--active' : ''}`}
                  onClick={() => setActiveTestimonial(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section team">
        <div className="container">
          <div className="section-heading">
            <p className="overline">Team</p>
            <h2 className="section-title">Chi tiene vivo il diario</h2>
          </div>
          <div className="team-grid">
            {teamMembers.map((member) => (
              <motion.article
                key={member.name}
                className="team-card"
                whileHover={{ translateY: -10 }}
                transition={{ duration: 0.25 }}
              >
                <div className="team-image">
                  <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                </div>
                <div className="team-body">
                  <h3>{member.name}</h3>
                  <p className="team-role">{member.role}</p>
                  <p>{member.bio}</p>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section projects">
        <div className="container">
          <div className="section-heading">
            <p className="overline">Portfolio</p>
            <h2 className="section-title">Progetti preferiti</h2>
          </div>
          <div className="project-filters" role="tablist">
            {['Tutte', 'Tavole di stagione', 'Mercato', 'Dietro le quinte'].map((category) => (
              <button
                type="button"
                key={category}
                className={`filter-chip ${projectFilter === category ? 'filter-chip--active' : ''}`}
                onClick={() => setProjectFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="projects-grid">
            {filteredProjects.map((project) => (
              <motion.article
                key={project.title}
                className="project-card"
                whileHover={{ translateY: -8 }}
                transition={{ duration: 0.25 }}
              >
                <img src={project.image} alt={`Serie fotografica ${project.title}`} loading="lazy" />
                <div className="project-body">
                  <span className="badge">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/portfolio" className="card-link">
                    Guarda la serie completa →
                  </Link>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section faq">
        <div className="container">
          <div className="section-heading">
            <p className="overline">Domande frequenti</p>
            <h2 className="section-title">Le curiosità di chi ci legge</h2>
          </div>
          <div className="faq-list">
            {faqItems.map((item) => (
              <details key={item.question} className="faq-item">
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="section blog-preview">
        <div className="container">
          <div className="section-heading">
            <p className="overline">Dal blog</p>
            <h2 className="section-title">Ultimi approfondimenti</h2>
          </div>
          <div className="articles-grid">
            {recentArticles.map((article) => (
              <motion.article
                key={article.link}
                className="article-card"
                whileHover={{ translateY: -8 }}
                transition={{ duration: 0.25 }}
              >
                <h3 className="card-title">{article.title}</h3>
                <p>{article.excerpt}</p>
                <Link className="card-link" to={article.link}>
                  Continua a leggere →
                </Link>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section cta">
        <div className="container cta-box">
          <div className="cta-text">
            <h2>Iscriviti alla nostra lettera del venerdì</h2>
            <p>
              Ogni venerdì mattina ti mandiamo tre idee per la cena del weekend,
              playlist da cucina e un ingrediente da guardare con occhi nuovi.
            </p>
          </div>
          <form className="cta-form">
            <label htmlFor="newsletter-email" className="sr-only">
              Email
            </label>
            <input
              id="newsletter-email"
              type="email"
              name="email"
              placeholder="nome@email.it"
              required
            />
            <button type="submit" className="btn btn-primary">
              Voglio la lettera
            </button>
            <p className="form-note">
              Iscrivendoti confermi di avere letto la nostra <Link to="/privacy">privacy policy</Link>.
            </p>
          </form>
        </div>
      </section>
    </>
  );
};

export default Home;