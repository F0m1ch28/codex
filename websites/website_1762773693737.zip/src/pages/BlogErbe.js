import React from 'react';
import { Helmet } from 'react-helmet-async';

const favoriteHerbs = [
  { name: 'Finocchietto selvatico', use: 'Perfetto con legumi, carni bianche e pesce azzurro.' },
  { name: 'Maggiorana fresca', use: 'Ideale nei ripieni di verdure e nelle polpette di pane.' },
  { name: 'Erba cipollina', use: 'Da aggiungere a fine cottura su uova, patate e zuppe cremose.' },
  { name: 'Dragoncello', use: 'Ottimo nelle marinate di pollo e nelle salse yogurt.' },
  { name: 'Menta marocchina', use: 'Per insalate di frutta, tè freddi e couscous estivi.' }
];

const BlogErbe = () => (
  <>
    <Helmet>
      <title>Come proviamo le erbe in cucina | Fetta Di Giorno</title>
      <meta
        name="description"
        content="Il nostro metodo per scegliere e provare le erbe aromatiche in cucina: infusi, abbinamenti e appunti pratici."
      />
      <link
        rel="canonical"
        href="https://www.fettadigiorno.it/blog/come-proviamo-le-erbe-in-cucina"
      />
    </Helmet>
    <article className="section blog-post">
      <div className="container blog-post-content">
        <p className="overline">Profumi da dispensa</p>
        <h1 className="page-title">Come proviamo le erbe in cucina</h1>
        <img
          src="https://picsum.photos/1100/700?random=161"
          alt="Erbe aromatiche fresche su un tagliere di legno"
          className="blog-image"
          loading="lazy"
        />
        <p>
          Ogni erba ha una storia e una voce. Per conoscerla davvero la tocchiamo,
          la strofiniamo tra le mani e annusiamo il profumo che rimane. Poi prepariamo
          tre infusioni: una in acqua calda, una in olio tiepido, una in burro fuso.
          Il sapore che sprigiona in ciascun medium ci rivela come si comporterà nella ricetta.
        </p>
        <p>
          Gli assaggi si fanno al tavolo grande, con tazze e cucchiaini etichettati.
          Segniamo su un quaderno consistenza, intensità e abbinamenti istintivi.
          Non si tratta di teoria, ma di ascolto paziente. Spesso invitiamo qualche
          amico in cucina: le reazioni immediate sono preziose quanto le nostre note.
        </p>
        <p>
          Alcune erbe si prestano a essere essiccate e tenute a lungo, altre danno il
          meglio solo fresche. Il basilico, per esempio, preferisce il mortaio e la
          temperatura ambiente. L’origano fresco lo lasciamo seccare appeso, il timo
          lo conserviamo in olio extravergine.
        </p>
        <img
          src="https://picsum.photos/1100/700?random=162"
          alt="Foglie di erbe fresche immerse in olio"
          className="blog-image"
          loading="lazy"
        />
        <p>
          Tenere in cucina un piccolo vassoio con erbe fresche ci ricorda che ogni
          piatto può cambiare carattere con un gesto finale. Tagliamo al momento, con
          forbici pulite, per non stressare le foglie. Se dobbiamo conservarle, le
          avvolgiamo in carta umida e le riponiamo in un contenitore ermetico.
        </p>
        <div className="herbs-block">
          <h2>Le nostre erbe del cuore</h2>
          <ul>
            {favoriteHerbs.map((herb) => (
              <li key={herb.name}>
                <strong>{herb.name}</strong> – {herb.use}
              </li>
            ))}
          </ul>
        </div>
        <p>
          La parte più stimolante arriva quando abbiniamo le erbe tra loro. Dragoncello
          e menta, per esempio, rinfrescano un’insalata di patate. Finocchietto e
          maggiorana accendono una vellutata di fave. Sperimentare significa anche
          accettare qualche tentativo andato storto: lo annotiamo e ripartiamo.
        </p>
        <p>
          Concludiamo ogni sessione preparando un piatto semplice con le erbe testate:
          uova strapazzate, pane tostato, verdure saltate. È il modo migliore per
          fissare la memoria del sapore e capire se un abbinamento funziona davvero.
        </p>
      </div>
    </article>
  </>
);

export default BlogErbe;