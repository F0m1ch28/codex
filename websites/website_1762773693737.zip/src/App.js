import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';

import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import Ricette from './pages/Ricette';
import Portfolio from './pages/Portfolio';
import Blog from './pages/Blog';
import BlogPomodori from './pages/BlogPomodori';
import BlogPane from './pages/BlogPane';
import BlogErbe from './pages/BlogErbe';

const siteUrl = 'https://www.fettadigiorno.it';

const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'Fetta Di Giorno',
  url: siteUrl,
  logo: `${siteUrl}/favicon.png`,
  sameAs: [
    'https://www.instagram.com/fettadigiorno',
    'https://www.pinterest.com/fettadigiorno'
  ],
  contactPoint: {
    '@type': 'ContactPoint',
    telephone: '+39 02 5789 2146',
    contactType: 'customer support',
    areaServed: 'IT',
    availableLanguage: ['Italian']
  },
  address: {
    '@type': 'PostalAddress',
    streetAddress: 'Via Privata Flumendosa 11',
    addressLocality: 'Milano',
    postalCode: '20132',
    addressCountry: 'IT'
  }
};

const PageWrapper = ({ children }) => (
  <motion.div
    initial={{ opacity: 0, y: 24 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -24 }}
    transition={{ duration: 0.4, ease: 'easeOut' }}
  >
    {children}
  </motion.div>
);

const NotFound = () => (
  <div className="section">
    <div className="container text-center space-y-6">
      <h1 className="page-title">Pagina non trovata</h1>
      <p className="lead">
        La pagina che cerchi si è probabilmente spostata in un’altra stagione.
        Torna alla home per ritrovare il filo.
      </p>
      <a className="btn btn-primary" href="/">
        Torna alla home
      </a>
    </div>
  </div>
);

const App = () => (
  <>
    <Helmet>
      <html lang="it-IT" />
      <meta property="og:site_name" content="Fetta Di Giorno" />
      <link rel="alternate" href={siteUrl} hrefLang="it-IT" />
      <script type="application/ld+json">
        {JSON.stringify(organizationSchema)}
      </script>
    </Helmet>
    <Header />
    <ScrollToTop />
    <main className="site-main">
      <Routes>
        <Route path="/" element={<PageWrapper><Home /></PageWrapper>} />
        <Route path="/chi-siamo" element={<PageWrapper><About /></PageWrapper>} />
        <Route path="/servizi" element={<PageWrapper><Services /></PageWrapper>} />
        <Route path="/ricette" element={<PageWrapper><Ricette /></PageWrapper>} />
        <Route path="/portfolio" element={<PageWrapper><Portfolio /></PageWrapper>} />
        <Route path="/blog" element={<PageWrapper><Blog /></PageWrapper>} />
        <Route
          path="/blog/pomodori-che-profumano-d-estate"
          element={<PageWrapper><BlogPomodori /></PageWrapper>}
        />
        <Route
          path="/blog/come-tostiamo-il-pane-a-casa"
          element={<PageWrapper><BlogPane /></PageWrapper>}
        />
        <Route
          path="/blog/come-proviamo-le-erbe-in-cucina"
          element={<PageWrapper><BlogErbe /></PageWrapper>}
        />
        <Route path="/contatti" element={<PageWrapper><Contact /></PageWrapper>} />
        <Route path="/termini" element={<PageWrapper><Terms /></PageWrapper>} />
        <Route path="/privacy" element={<PageWrapper><Privacy /></PageWrapper>} />
        <Route
          path="/cookie-policy"
          element={<PageWrapper><CookiePolicy /></PageWrapper>}
        />
        <Route path="*" element={<PageWrapper><NotFound /></PageWrapper>} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
  </>
);

export default App;