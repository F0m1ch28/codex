document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            navMenu.classList.toggle('open');
        });

        navMenu.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (navMenu.classList.contains('open')) {
                    navMenu.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const consentKey = 'axilePulqtCookieConsent';
        const storedConsent = localStorage.getItem(consentKey);

        if (!storedConsent) {
            requestAnimationFrame(function () {
                cookieBanner.classList.add('is-visible');
            });
        }

        const acceptBtn = cookieBanner.querySelector('.cookie-accept');
        const declineBtn = cookieBanner.querySelector('.cookie-decline');

        const hideBanner = function (status) {
            localStorage.setItem(consentKey, status);
            cookieBanner.classList.remove('is-visible');
            setTimeout(function () {
                cookieBanner.style.display = 'none';
            }, 350);
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                hideBanner('accepted');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                hideBanner('declined');
            });
        }
    }
});