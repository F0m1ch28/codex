(function () {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.primary-nav');
  const navClose = document.querySelector('.nav-close');
  const body = document.body;

  function openNav() {
    if (navMenu) {
      navMenu.classList.add('is-open');
      navToggle.setAttribute('aria-expanded', 'true');
      body.classList.add('no-scroll');
    }
  }

  function closeNav() {
    if (navMenu) {
      navMenu.classList.remove('is-open');
      navToggle.setAttribute('aria-expanded', 'false');
      body.classList.remove('no-scroll');
    }
  }

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', openNav);
  }
  if (navClose) {
    navClose.addEventListener('click', closeNav);
  }
  if (navMenu) {
    navMenu.addEventListener('click', (event) => {
      if (event.target.tagName === 'A') {
        closeNav();
      }
    });
  }

  const observerTargets = document.querySelectorAll('.animate-on-scroll');
  if (observerTargets.length > 0) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    observerTargets.forEach((el) => observer.observe(el));
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = cookieBanner ? cookieBanner.querySelector('.cookie-accept') : null;
  const declineBtn = cookieBanner ? cookieBanner.querySelector('.cookie-decline') : null;
  const cookieKey = 'nauticfleet_cookie_choice';

  function hideCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add('is-hidden');
    }
  }

  if (cookieBanner) {
    const storedChoice = localStorage.getItem(cookieKey);
    if (storedChoice) {
      hideCookieBanner();
    } else {
      cookieBanner.classList.remove('is-hidden');
    }
  }

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => {
      localStorage.setItem(cookieKey, 'accepted');
      hideCookieBanner();
      showToast('Preferința pentru cookie-uri a fost salvată.');
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => {
      localStorage.setItem(cookieKey, 'declined');
      hideCookieBanner();
      showToast('Ai respins utilizarea cookie-urilor opționale.');
    });
  }

  const toast = document.getElementById('global-toast');
  let toastTimer;

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('is-active');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toast.classList.remove('is-active');
    }, 3000);
  }

  const forms = document.querySelectorAll('form[data-redirect="thank-you.html"]');
  if (forms.length > 0) {
    forms.forEach((form) => {
      form.addEventListener('submit', (event) => {
        event.preventDefault();
        showToast('Mesajul a fost înregistrat.');
        setTimeout(() => {
          window.location.href = form.getAttribute('action') || 'thank-you.html';
        }, 900);
      });
    });
  }
})();