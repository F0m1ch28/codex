document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const navLinks = document.querySelectorAll(".nav-list a");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const isOpen = siteNav.classList.toggle("is-open");
            navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (siteNav.classList.contains("is-open")) {
                    siteNav.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-accept");
    const declineBtn = document.querySelector(".cookie-decline");
    const customizeBtn = document.querySelector(".cookie-customize");

    if (cookieBanner) {
        const storedConsent = localStorage.getItem("lawrennoqoCookieConsent");
        if (storedConsent) {
            cookieBanner.classList.add("hidden");
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => {
                localStorage.setItem("lawrennoqoCookieConsent", "accepted");
                cookieBanner.classList.add("hidden");
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", () => {
                localStorage.setItem("lawrennoqoCookieConsent", "declined");
                cookieBanner.classList.add("hidden");
            });
        }

        if (customizeBtn) {
            customizeBtn.addEventListener("click", () => {
                window.location.href = "cookies.html";
            });
        }
    }
});