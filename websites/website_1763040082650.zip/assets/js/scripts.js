document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");
    const scrollBtn = document.getElementById("scrollToTop");
    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptCookiesBtn = document.getElementById("acceptCookies");
    const contactForm = document.getElementById("contact-form");
    const currentYearElement = document.getElementById("current-year");

    if (currentYearElement) {
        currentYearElement.textContent = new Date().getFullYear();
    }

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            navMenu.classList.toggle("open");
        });

        navMenu.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navMenu.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    const internalLinks = document.querySelectorAll('a[href^="#"]:not([href="#"])');
    internalLinks.forEach(link => {
        link.addEventListener("click", event => {
            const targetId = link.getAttribute("href").substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                event.preventDefault();
                targetElement.scrollIntoView({ behavior: "smooth" });
            }
        });
    });

    if (scrollBtn) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 280) {
                scrollBtn.classList.add("visible");
            } else {
                scrollBtn.classList.remove("visible");
            }
        });

        scrollBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    if (cookieBanner && acceptCookiesBtn) {
        const cookieKey = "dorivanlyxaCookiesAccepted";
        if (localStorage.getItem(cookieKey) !== "true") {
            cookieBanner.classList.add("active");
        }

        acceptCookiesBtn.addEventListener("click", () => {
            localStorage.setItem(cookieKey, "true");
            cookieBanner.classList.remove("active");
        });
    }

    if (contactForm) {
        contactForm.addEventListener("submit", event => {
            event.preventDefault();
            const formStatus = contactForm.querySelector(".form-status");
            const formData = new FormData(contactForm);
            const name = formData.get("name").trim();
            const email = formData.get("email").trim();
            const message = formData.get("message").trim();
            if (!name || !email || !message) {
                formStatus.textContent = "Bitte fülle alle Felder sorgfältig aus.";
                formStatus.style.color = "#ffd166";
                return;
            }
            formStatus.textContent = "Danke für deine Nachricht! Wir melden uns bald.";
            formStatus.style.color = "#9ef3c9";
            contactForm.reset();
        });
    }
});