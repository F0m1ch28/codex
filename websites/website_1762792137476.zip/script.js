document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.getElementById("primary-navigation");
    const scrollButton = document.querySelector(".scroll-top");
    const cookieBanner = document.getElementById("cookie-banner");
    const acceptCookiesButton = document.getElementById("accept-cookies");
    const forms = document.querySelectorAll('form[data-form="contact"]');
    const yearSpan = document.getElementById("current-year");

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            primaryNav.classList.toggle("open");
        });

        primaryNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                if (primaryNav.classList.contains("open")) {
                    primaryNav.classList.remove("open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
                window.scrollTo({ top: 0, behavior: "smooth" });
            });
        });
    }

    const handleScroll = () => {
        if (window.scrollY > 400) {
            scrollButton.classList.add("show");
        } else {
            scrollButton.classList.remove("show");
        }
    };

    if (scrollButton) {
        window.addEventListener("scroll", handleScroll, { passive: true });
        scrollButton.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    if (cookieBanner && acceptCookiesButton) {
        const cookiesAccepted = localStorage.getItem("polarCookiesAccepted");
        if (!cookiesAccepted) {
            cookieBanner.classList.add("show");
        }
        acceptCookiesButton.addEventListener("click", () => {
            localStorage.setItem("polarCookiesAccepted", "true");
            cookieBanner.classList.remove("show");
        });
    }

    if (forms) {
        forms.forEach(form => {
            const status = form.querySelector(".form-status");
            form.addEventListener("submit", event => {
                event.preventDefault();
                const formData = new FormData(form);
                const name = formData.get("name");
                const email = formData.get("email");
                const message = formData.get("message");

                if (!name || !email || !message) {
                    if (status) {
                        status.textContent = "Please complete the required fields.";
                        status.style.color = "#f87171";
                    }
                    return;
                }

                if (!validateEmail(String(email))) {
                    if (status) {
                        status.textContent = "Please enter a valid email address.";
                        status.style.color = "#facc15";
                    }
                    return;
                }

                setTimeout(() => {
                    form.reset();
                    if (status) {
                        status.textContent = "Thank you. We’ll be in touch within one business day.";
                        status.style.color = "#34d399";
                    }
                }, 500);
            });
        });
    }

    function validateEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
});