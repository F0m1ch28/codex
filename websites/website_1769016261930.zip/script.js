document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.getElementById('nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('is-open');
            document.body.classList.toggle('nav-open');
        });

        document.querySelectorAll('.site-nav a').forEach(link => {
            link.addEventListener('click', () => {
                if (navToggle.getAttribute('aria-expanded') === 'true') {
                    navToggle.setAttribute('aria-expanded', 'false');
                    navMenu.classList.remove('is-open');
                    document.body.classList.remove('nav-open');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const acceptBtn = document.getElementById('acceptCookies');
    const declineBtn = document.getElementById('declineCookies');

    if (cookieBanner && acceptBtn && declineBtn) {
        const stored = localStorage.getItem('absoluteInkCookieConsent');
        if (stored === 'accepted' || stored === 'declined') {
            cookieBanner.classList.add('is-hidden');
        } else {
            cookieBanner.classList.add('is-visible');
        }

        acceptBtn.addEventListener('click', () => {
            localStorage.setItem('absoluteInkCookieConsent', 'accepted');
            cookieBanner.classList.remove('is-visible');
            cookieBanner.classList.add('is-hidden');
        });

        declineBtn.addEventListener('click', () => {
            localStorage.setItem('absoluteInkCookieConsent', 'declined');
            cookieBanner.classList.remove('is-visible');
            cookieBanner.classList.add('is-hidden');
        });
    }
});