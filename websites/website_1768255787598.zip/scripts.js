(function () {
    const menuToggle = document.querySelector('[data-mobile-toggle]');
    const navigation = document.querySelector('[data-navigation]');
    if (menuToggle && navigation) {
        menuToggle.addEventListener('click', () => {
            navigation.classList.toggle('open');
        });
    }

    const banner = document.querySelector('[data-cookie-banner]');
    if (!banner) return;
    const storedChoice = localStorage.getItem('determqmkn-cookie');
    if (storedChoice) {
        banner.classList.add('hidden');
    }
    banner.addEventListener('click', (event) => {
        const target = event.target.closest('[data-choice]');
        if (!target) return;
        const choice = target.getAttribute('data-choice');
        localStorage.setItem('determqmkn-cookie', choice);
        banner.classList.add('hidden');
    });
})();