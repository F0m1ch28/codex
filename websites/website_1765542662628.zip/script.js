document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.querySelector(".site-nav");
  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      navMenu.classList.toggle("is-open");
      navToggle.classList.toggle("is-active");
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!expanded).toString());
    });
    navMenu.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navMenu.classList.remove("is-open");
        navToggle.classList.remove("is-active");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  const acceptBtn = document.querySelector("[data-cookie-accept]");
  const declineBtn = document.querySelector("[data-cookie-decline]");
  const consentKey = "qnm-cookie-consent";

  const showCookieBanner = () => {
    if (cookieBanner && !localStorage.getItem(consentKey)) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add("is-visible");
      });
    }
  };

  const hideCookieBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.add("is-hidden");
      setTimeout(() => {
        cookieBanner.classList.remove("is-visible");
      }, 300);
    }
  };

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "accepted");
      hideCookieBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "declined");
      hideCookieBanner();
    });
  }

  showCookieBanner();

  const accordionItems = document.querySelectorAll('[data-accordion="item"]');
  accordionItems.forEach((item) => {
    const button = item.querySelector(".accordion-button");
    const panel = item.querySelector(".accordion-panel");
    const inner = panel.querySelector(".accordion-panel__inner");
    button.addEventListener("click", () => {
      const isOpen = item.classList.contains("is-open");
      accordionItems.forEach((other) => {
        if (other !== item) {
          other.classList.remove("is-open");
          const otherPanel = other.querySelector(".accordion-panel");
          otherPanel.style.height = 0;
          other.querySelector(".accordion-button").setAttribute("aria-expanded", "false");
        }
      });
      if (!isOpen) {
        item.classList.add("is-open");
        panel.style.height = `${inner.offsetHeight}px`;
        button.setAttribute("aria-expanded", "true");
      } else {
        item.classList.remove("is-open");
        panel.style.height = 0;
        button.setAttribute("aria-expanded", "false");
      }
    });
  });

  const yearTargets = document.querySelectorAll("[data-year]");
  const currentYear = new Date().getFullYear();
  yearTargets.forEach((node) => {
    node.textContent = currentYear.toString();
  });
});