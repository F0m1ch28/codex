document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.site-nav');
    const cookieBanner = document.getElementById('cookie-banner');
    const yearElement = document.getElementById('year');

    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            navigation.classList.toggle('open');
        });

        navigation.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                navigation.classList.remove('open');
            });
        });
    }

    if (cookieBanner) {
        const preference = localStorage.getItem('ctc_cookie_pref');
        if (!preference) {
            cookieBanner.classList.add('active');
            cookieBanner.setAttribute('aria-hidden', 'false');
        } else {
            cookieBanner.classList.remove('active');
            cookieBanner.setAttribute('aria-hidden', 'true');
        }

        cookieBanner.querySelectorAll('button[data-action]').forEach(button => {
            button.addEventListener('click', () => {
                const action = button.getAttribute('data-action');
                localStorage.setItem('ctc_cookie_pref', action);
                cookieBanner.classList.remove('active');
                cookieBanner.setAttribute('aria-hidden', 'true');
            });
        });
    }
});