```javascript
import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.classList.add('no-scroll');
    } else {
      document.body.classList.remove('no-scroll');
    }
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/about', label: 'About' },
    { to: '/practice-areas', label: 'Practice Areas' },
    { to: '/attorneys', label: 'Attorneys' },
    { to: '/insights', label: 'Insights' },
    { to: '/contact', label: 'Contact' }
  ];

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} aria-label="Primary navigation">
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          <span className={styles.logoMark}>CLP</span>
          <span className={styles.logoText}>Consonragp Legal Partners</span>
        </NavLink>
        <nav className={styles.nav}>
          <ul className={styles.navList}>
            {navLinks.map((link) => (
              <li key={link.to} className={styles.navItem}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <a className={styles.ctaButton} href="/contact">
          Schedule Consultation
        </a>
        <button
          className={`${styles.mobileToggle} ${menuOpen ? styles.open : ''}`}
          onClick={toggleMenu}
          aria-label="Toggle navigation menu"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
      <div className={`${styles.mobileMenu} ${menuOpen ? styles.mobileMenuOpen : ''}`}>
        <ul className={styles.mobileNavList}>
          {navLinks.map((link) => (
            <li key={link.to} className={styles.mobileNavItem}>
              <NavLink
                to={link.to}
                onClick={closeMenu}
                className={({ isActive }) => (isActive ? `${styles.mobileNavLink} ${styles.mobileActive}` : styles.mobileNavLink)}
              >
                {link.label}
              </NavLink>
            </li>
          ))}
          <li className={styles.mobileNavItem}>
            <a className={styles.mobileCTA} href="/contact" onClick={closeMenu}>
              Schedule Consultation
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
};

export default Header;
```