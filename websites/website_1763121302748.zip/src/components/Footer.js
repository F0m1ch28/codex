```javascript
import React from 'react';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Footer">
      <div className={styles.columns}>
        <div className={styles.column}>
          <div className={styles.brand}>
            <span className={styles.brandMark}>CLP</span>
            <p className={styles.brandName}>Consonragp Legal Partners</p>
          </div>
          <p className={styles.mission}>
            Providing precise, business-focused legal guidance to international and Belgian companies from the heart of Brussels.
          </p>
        </div>
        <div className={styles.column}>
          <h4 className={styles.columnTitle}>Explore</h4>
          <ul className={styles.linksList}>
            <li><a href="/about">About</a></li>
            <li><a href="/practice-areas">Practice Areas</a></li>
            <li><a href="/attorneys">Attorneys</a></li>
            <li><a href="/insights">Insights</a></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4 className={styles.columnTitle}>Compliance</h4>
          <ul className={styles.linksList}>
            <li><a href="/terms">Terms of Service</a></li>
            <li><a href="/privacy">Privacy Policy</a></li>
            <li><a href="/cookie-policy">Cookie Policy</a></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4 className={styles.columnTitle}>Contact</h4>
          <address className={styles.contact}>
            <span>Avenue Louise 250</span>
            <span>1050 Brussels, Belgium</span>
            <a href="tel:+3221234567">+32 2 123 4567</a>
            <a href="mailto:info@consonragp.com">info@consonragp.com</a>
          </address>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© {new Date().getFullYear()} Consonragp Legal Partners. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
```