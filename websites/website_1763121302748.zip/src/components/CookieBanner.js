```javascript
import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('clp_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('clp_cookie_consent', 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem('clp_cookie_consent', 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <div className={styles.content}>
        <h3>Cookies & Privacy</h3>
        <p>
          We use cookies to enhance your browsing experience, analyze site traffic, and tailor content. Review our{' '}
          <a href="/cookie-policy">Cookie Policy</a> for details.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.secondary} onClick={handleDecline}>
          Decline
        </button>
        <button type="button" className={styles.primary} onClick={handleAccept}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;
```