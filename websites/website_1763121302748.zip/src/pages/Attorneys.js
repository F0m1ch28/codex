```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Attorneys.module.css';

const attorneys = [
  {
    name: 'Anneke Verstraete',
    title: 'Managing Partner',
    specialisations: 'Corporate governance, cross-border M&A, private equity transactions.',
    education: 'KU Leuven (LL.M.), College of Europe (LL.M. European Law)',
    admissions: 'Brussels Bar, 2008',
    image: 'https://picsum.photos/500/500?random=221'
  },
  {
    name: 'Olivier Lambert',
    title: 'Partner',
    specialisations: 'Commercial litigation, arbitration, urgent proceedings.',
    education: 'Université Libre de Bruxelles (LL.B.), King’s College London (LL.M. Dispute Resolution)',
    admissions: 'Brussels Bar, 2010',
    image: 'https://picsum.photos/500/500?random=222'
  },
  {
    name: 'Sofia Janssens',
    title: 'Partner',
    specialisations: 'Employment restructuring, labour relations, executive compensation.',
    education: 'Ghent University (LL.M.), VUB (Postgraduate Employment Law)',
    admissions: 'Brussels Bar, 2011',
    image: 'https://picsum.photos/500/500?random=223'
  },
  {
    name: 'Dries Meunier',
    title: 'Partner',
    specialisations: 'Regulatory compliance, contract architecture, public procurement.',
    education: 'University of Antwerp (LL.B.), University of Cambridge (LL.M. Commercial Law)',
    admissions: 'Brussels Bar, 2009',
    image: 'https://picsum.photos/500/500?random=224'
  },
  {
    name: 'Clara Vogel',
    title: 'Counsel',
    specialisations: 'Data protection, technology contracts, digital platforms.',
    education: 'Université Catholique de Louvain (LL.M.), Certified DPO',
    admissions: 'Brussels Bar, 2013',
    image: 'https://picsum.photos/500/500?random=225'
  },
  {
    name: 'Mathieu Renard',
    title: 'Senior Associate',
    specialisations: 'Corporate advisory, start-up governance, venture capital transactions.',
    education: 'Université de Liège (LL.M.), Solvay Brussels School (MBA)',
    admissions: 'Brussels Bar, 2015',
    image: 'https://picsum.photos/500/500?random=226'
  }
];

const Attorneys = () => {
  return (
    <>
      <Helmet>
        <title>Our Attorneys | Consonragp Legal Partners</title>
        <meta
          name="description"
          content="Meet the Brussels attorneys leading Consonragp Legal Partners. Discover their expertise across corporate law, commercial litigation, employment, and contract advisory."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Our Attorneys</h1>
          <p>
            An accomplished team of Brussels-based lawyers with complementary expertise and a shared commitment to
            excellence.
          </p>
        </div>
      </section>
      <section className={`${styles.section} ${styles.gridSection}`}>
        <div className="container">
          <div className={styles.attorneysGrid}>
            {attorneys.map((attorney) => (
              <article key={attorney.name} className={styles.attorneyCard}>
                <img src={attorney.image} alt={`Portrait of ${attorney.name}`} loading="lazy" />
                <div className={styles.cardContent}>
                  <h2>{attorney.name}</h2>
                  <p className={styles.title}>{attorney.title}</p>
                  <p><strong>Specialisations:</strong> {attorney.specialisations}</p>
                  <p><strong>Education:</strong> {attorney.education}</p>
                  <p><strong>Admissions:</strong> {attorney.admissions}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Attorneys;
```