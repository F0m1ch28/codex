```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Insights.module.css';

const insights = [
  {
    title: 'Belgian Corporate Governance Updates for 2024',
    date: 'March 12, 2024',
    summary:
      'Changes to the Belgian Companies and Associations Code strengthen board accountability and shareholder rights. We outline key action points for governance teams.',
    link: '#'
  },
  {
    title: 'Managing Collective Redundancies: Lessons from Recent Case Law',
    date: 'February 26, 2024',
    summary:
      'Recent labour court decisions provide critical guidance on consultation processes, selection criteria, and documentation obligations.',
    link: '#'
  },
  {
    title: 'Cross-Border Commercial Contracts: Mitigating Supply Chain Risk',
    date: 'January 30, 2024',
    summary:
      'Companies with multi-jurisdictional supply chains must reassess contract clauses to address logistics volatility and regulatory divergence.',
    link: '#'
  },
  {
    title: 'Arbitration Trends: Efficiency Measures in ICC Proceedings',
    date: 'December 18, 2023',
    summary:
      'We examine recent measures introduced by the ICC to streamline proceedings and how to leverage them for commercial disputes.',
    link: '#'
  }
];

const Insights = () => {
  return (
    <>
      <Helmet>
        <title>Insights &amp; Analysis | Consonragp Legal Partners</title>
        <meta
          name="description"
          content="Stay informed with Consonragp Legal Partners' insights on corporate governance, commercial litigation, employment law, and contract advisory developments in Belgium."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Insights &amp; Analysis</h1>
          <p>
            In-depth commentary on legislative changes, case law, and strategic considerations for businesses operating
            in Belgium and the European market.
          </p>
        </div>
      </section>
      <section className={`${styles.section} ${styles.insightsSection}`}>
        <div className="container">
          <div className={styles.insightsGrid}>
            {insights.map((insight) => (
              <article key={insight.title} className={styles.insightCard}>
                <span className={styles.date}>{insight.date}</span>
                <h2>{insight.title}</h2>
                <p>{insight.summary}</p>
                <a className={styles.readMore} href={insight.link}>
                  Read more →
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Insights;
```