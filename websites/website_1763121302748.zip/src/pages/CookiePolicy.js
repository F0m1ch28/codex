```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | Consonragp Legal Partners</title>
        <meta
          name="description"
          content="Cookie policy describing how Consonragp Legal Partners uses cookies and similar technologies on its website."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Cookie Policy</h1>
        </div>
      </section>
      <section className={styles.section}>
        <div className="container">
          <article className={styles.content}>
            <h2>1. What Are Cookies?</h2>
            <p>
              Cookies are small text files stored on your device when you visit a website. They help improve user
              experience and provide analytical insights.
            </p>

            <h2>2. Types of Cookies We Use</h2>
            <ul>
              <li>
                <strong>Essential Cookies</strong> – required for website functionality, such as security and accessibility.
              </li>
              <li>
                <strong>Analytics Cookies</strong> – help us understand how visitors interact with the site to enhance performance.
              </li>
              <li>
                <strong>Preference Cookies</strong> – store your settings such as cookie consent choices.
              </li>
            </ul>

            <h2>3. Managing Cookies</h2>
            <p>
              You can adjust your browser settings to refuse or delete cookies. Note that disabling essential cookies may
              impact website functionality.
            </p>

            <h2>4. Third-Party Cookies</h2>
            <p>
              We may use third-party analytics providers. These providers process cookie data on our behalf and are bound
              by data protection obligations.
            </p>

            <h2>5. Updates</h2>
            <p>
              We review this Cookie Policy regularly. Any changes will be posted on this page with an updated revision
              date.
            </p>

            <h2>6. Contact</h2>
            <p>
              For questions, contact us at <a href="mailto:info@consonragp.com">info@consonragp.com</a>.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;
```