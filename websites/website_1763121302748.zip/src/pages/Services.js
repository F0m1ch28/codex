```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Practice Areas | Consonragp Legal Partners</title>
        <meta
          name="description"
          content="Explore Consonragp Legal Partners' practice areas including corporate law, commercial litigation, employment law, and contract advisory services across Belgium."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Practice Areas</h1>
          <p>
            Comprehensive legal services designed to support companies through complex transactions, contentious matters,
            and strategic workforce decisions.
          </p>
        </div>
      </section>

      <section className={`${styles.section} ${styles.servicesSection}`}>
        <div className="container">
          <div className={styles.servicesGrid}>
            <article className={styles.serviceCard}>
              <div className={styles.serviceHeader}>
                <h2>Corporate &amp; M&amp;A</h2>
              </div>
              <p>
                We advise on corporate governance, mergers and acquisitions, restructurings, and joint ventures. Our
                team combines transactional rigour with sector-specific insights to ensure successful deal execution.
              </p>
              <ul>
                <li>Deal structuring &amp; due diligence</li>
                <li>Equity instruments &amp; financing arrangements</li>
                <li>Corporate housekeeping &amp; governance reviews</li>
                <li>Regulatory compliance with Belgian and EU requirements</li>
              </ul>
            </article>

            <article className={styles.serviceCard}>
              <div className={styles.serviceHeader}>
                <h2>Commercial Litigation &amp; Arbitration</h2>
              </div>
              <p>
                When disputes arise, our litigators provide measured advocacy, supported by deep procedural knowledge
                and strong negotiation skills.
              </p>
              <ul>
                <li>Distribution and agency disputes</li>
                <li>International arbitration (ICC, CEPANI, ad hoc)</li>
                <li>Urgent interim relief &amp; enforcement</li>
                <li>Settlement strategy &amp; mediation support</li>
              </ul>
            </article>

            <article className={styles.serviceCard}>
              <div className={styles.serviceHeader}>
                <h2>Employment &amp; Labour</h2>
              </div>
              <p>
                Our employment team partners with HR leaders to manage organisational change while mitigating legal and
                reputational risk.
              </p>
              <ul>
                <li>Collective bargaining &amp; works council negotiations</li>
                <li>Executive contracts &amp; incentive schemes</li>
                <li>Workforce restructuring &amp; redundancies</li>
                <li>Employment litigation &amp; internal investigations</li>
              </ul>
            </article>

            <article className={styles.serviceCard}>
              <div className={styles.serviceHeader}>
                <h2>Contract Advisory</h2>
              </div>
              <p>
                We design and negotiate contracts that protect value, allocate risk, and uphold regulatory requirements
                across supply chains and partnerships.
              </p>
              <ul>
                <li>Commercial distribution &amp; supply agreements</li>
                <li>Technology licensing &amp; data sharing</li>
                <li>Strategic alliances &amp; outsourcing arrangements</li>
                <li>Contract lifecycle management and audits</li>
              </ul>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;
```