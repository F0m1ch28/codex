```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | Consonragp Legal Partners</title>
        <meta
          name="description"
          content="Consonragp Legal Partners' GDPR-compliant privacy policy detailing how personal data is collected, processed, and protected."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Privacy Policy</h1>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <article className={styles.content}>
            <h2>1. Controller</h2>
            <p>
              Consonragp Legal Partners, Avenue Louise 250, 1050 Brussels, Belgium (“CLP”), is the data controller for
              personal data processed through this website.
            </p>

            <h2>2. Personal Data Collection</h2>
            <p>
              We collect personal data that you voluntarily submit via contact forms, email, or telephone, including
              name, contact details, company information, and the nature of your enquiry.
            </p>

            <h2>3. Legal Bases</h2>
            <p>
              CLP processes personal data based on legitimate interests (responding to enquiries, managing client
              relationships) and consent where required.
            </p>

            <h2>4. Use of Data</h2>
            <p>
              Personal data is used to respond to enquiries, provide legal services, maintain records, comply with legal
              obligations, and manage client relationships.
            </p>

            <h2>5. Data Sharing</h2>
            <p>
              We share personal data only with third parties necessary to deliver our services (e.g., IT providers) or
              as required by law. All third parties are bound by confidentiality obligations.
            </p>

            <h2>6. International Transfers</h2>
            <p>
              If personal data is transferred outside the European Economic Area, CLP ensures appropriate safeguards such
              as Standard Contractual Clauses.
            </p>

            <h2>7. Data Retention</h2>
            <p>
              We retain personal data only as long as necessary to fulfil the purposes described above or as required by
              legal and regulatory obligations.
            </p>

            <h2>8. Your Rights</h2>
            <p>
              Under GDPR, you have the right to access, rectify, erase, restrict, or object to processing of your
              personal data, and the right to data portability. Contact{' '}
              <a href="mailto:info@consonragp.com">info@consonragp.com</a> to exercise these rights.
            </p>

            <h2>9. Security</h2>
            <p>
              CLP implements technical and organisational measures to protect personal data against unauthorised access,
              alteration, or disclosure.
            </p>

            <h2>10. Cookies</h2>
            <p>
              Our use of cookies is described in the <a href="/cookie-policy">Cookie Policy</a>. You can manage
              preferences via your browser settings.
            </p>

            <h2>11. Updates</h2>
            <p>
              We may update this Privacy Policy periodically. The latest version will be posted on this page with the
              revision date.
            </p>

            <h2>12. Contact</h2>
            <p>
              For privacy-related enquiries, please email <a href="mailto:info@consonragp.com">info@consonragp.com</a>.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Privacy;
```