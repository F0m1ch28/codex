```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  return (
    <>
      <Helmet>
        <title>About Consonragp Legal Partners | Brussels Law Firm</title>
        <meta
          name="description"
          content="Discover the history, values, and leadership of Consonragp Legal Partners, a Brussels-based law firm dedicated to precise corporate, commercial, and employment counsel."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>About Consonragp Legal Partners</h1>
          <p>
            A Brussels law firm dedicated to delivering precise, business-aligned legal advice to companies operating in
            Belgium and across Europe.
          </p>
        </div>
      </section>

      <section className={`${styles.section} ${styles.storySection}`}>
        <div className="container">
          <div className={styles.storyGrid}>
            <div>
              <h2>Our Story</h2>
              <p>
                Consonragp Legal Partners was founded by a group of seasoned Brussels attorneys who recognised the need
                for a law firm that blends sophisticated cross-border capability with a practical, client-first ethos.
              </p>
              <p>
                Over the past decade, we have grown into a multidisciplinary team that advises multinational groups,
                scale-ups, and family-owned enterprises on their most consequential corporate, commercial, and employment
                matters. Our office on Avenue Louise serves as a collaborative hub where attorneys, clients, and partner
                firms convene to shape resilient legal strategies.
              </p>
            </div>
            <div>
              <h2>Values in Practice</h2>
              <ul className={styles.valuesList}>
                <li>
                  <strong>Integrity.</strong> We safeguard confidentiality and deliver advice anchored in ethical
                  judgment.
                </li>
                <li>
                  <strong>Excellence.</strong> Each mandate is handled with the meticulous attention to detail it
                  deserves.
                </li>
                <li>
                  <strong>Agility.</strong> We adapt quickly to new developments and regulatory shifts affecting our
                  clients.
                </li>
                <li>
                  <strong>Collaboration.</strong> We work seamlessly with in-house counsel, management teams, and trusted
                  foreign lawyers.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.timelineSection}`}>
        <div className="container">
          <h2>Milestones</h2>
          <ul className={styles.timeline}>
            <li>
              <span className={styles.timelineYear}>2012</span>
              <div>
                <h3>Firm Founded</h3>
                <p>Consonragp Legal Partners opens its Brussels office with a focus on corporate and commercial law.</p>
              </div>
            </li>
            <li>
              <span className={styles.timelineYear}>2016</span>
              <div>
                <h3>Employment Practice Launch</h3>
                <p>Employment law experts join the firm, bolstering our ability to manage complex workforce matters.</p>
              </div>
            </li>
            <li>
              <span className={styles.timelineYear}>2019</span>
              <div>
                <h3>International Alliances</h3>
                <p>We formalise partnerships with leading firms in Paris, Frankfurt, and London to support cross-border mandates.</p>
              </div>
            </li>
            <li>
              <span className={styles.timelineYear}>2023</span>
              <div>
                <h3>Insights Platform</h3>
                <p>Launch of our Insights programme to keep clients apprised of legal developments shaping their industries.</p>
              </div>
            </li>
          </ul>
        </div>
      </section>

      <section className={`${styles.section} ${styles.partnersSection}`}>
        <div className="container">
          <h2>Partners</h2>
          <div className={styles.partnersGrid}>
            <article>
              <img src="https://picsum.photos/420/420?random=211" alt="Portrait of managing partner Anneke Verstraete" loading="lazy" />
              <h3>Anneke Verstraete</h3>
              <p>Managing Partner • Corporate &amp; M&amp;A</p>
              <p>
                Anneke advises boards and shareholders on strategic transactions, complex governance matters, and
                regulatory compliance across the EU.
              </p>
            </article>
            <article>
              <img src="https://picsum.photos/420/420?random=212" alt="Portrait of partner Olivier Lambert" loading="lazy" />
              <h3>Olivier Lambert</h3>
              <p>Partner • Commercial Litigation</p>
              <p>
                Olivier represents clients in Belgian courts and international arbitration, specialising in high-value commercial disputes.
              </p>
            </article>
            <article>
              <img src="https://picsum.photos/420/420?random=213" alt="Portrait of partner Sofia Janssens" loading="lazy" />
              <h3>Sofia Janssens</h3>
              <p>Partner • Employment &amp; Labour</p>
              <p>
                Sofia provides pragmatic guidance on workforce restructuring, labour relations, and executive compensation.
              </p>
            </article>
            <article>
              <img src="https://picsum.photos/420/420?random=214" alt="Portrait of partner Dries Meunier" loading="lazy" />
              <h3>Dries Meunier</h3>
              <p>Partner • Regulatory &amp; Contracts</p>
              <p>
                Dries helps clients navigate regulatory frameworks and craft robust commercial agreements across multiple jurisdictions.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;
```