```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Service | Consonragp Legal Partners</title>
        <meta
          name="description"
          content="Terms of service governing the use of Consonragp Legal Partners' website and legal information."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Terms of Service</h1>
        </div>
      </section>
      <section className={styles.section}>
        <div className="container">
          <article className={styles.content}>
            <h2>1. Introduction</h2>
            <p>
              These Terms of Service govern your use of the website operated by Consonragp Legal Partners (“CLP”). By
              accessing or using this website, you agree to be bound by these Terms.
            </p>

            <h2>2. No Legal Advice</h2>
            <p>
              The information on this website is provided for general information only and does not constitute legal
              advice. Please contact CLP directly for advice tailored to your specific circumstances.
            </p>

            <h2>3. Professional Relationship</h2>
            <p>
              Use of this website or communication through online forms does not create an attorney-client relationship.
              Such a relationship is established only upon written confirmation from CLP.
            </p>

            <h2>4. Intellectual Property</h2>
            <p>
              All content on this website, including logos, text, images, and graphics, is owned by CLP or licensed to
              CLP. You may not reproduce or distribute any content without prior written consent.
            </p>

            <h2>5. Limitation of Liability</h2>
            <p>
              CLP shall not be liable for any loss or damage arising from your use of this website or reliance on the
              information contained herein.
            </p>

            <h2>6. External Links</h2>
            <p>
              Our website may contain links to external sites. CLP is not responsible for the content or privacy
              practices of external sites.
            </p>

            <h2>7. Governing Law</h2>
            <p>
              These Terms are governed by Belgian law, and any disputes relating to these Terms shall be subject to the
              exclusive jurisdiction of the courts of Brussels.
            </p>

            <h2>8. Updates</h2>
            <p>
              CLP may revise these Terms at any time without notice. The updated Terms will be published on this page.
            </p>

            <h2>9. Contact</h2>
            <p>
              For questions regarding these Terms, please contact us at{' '}
              <a href="mailto:info@consonragp.com">info@consonragp.com</a>.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Terms;
```