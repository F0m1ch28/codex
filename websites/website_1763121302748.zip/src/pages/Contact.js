```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
    setErrors((prev) => ({
      ...prev,
      [event.target.name]: ''
    }));
  };

  const validateEmail = (email) => /\S+@\S+\.\S+/.test(email);

  const handleSubmit = (event) => {
    event.preventDefault();
    const newErrors = {};

    if (!formData.name.trim()) newErrors.name = 'Please enter your name.';
    if (!formData.email.trim() || !validateEmail(formData.email)) newErrors.email = 'Enter a valid email address.';
    if (!formData.message.trim() || formData.message.length < 20)
      newErrors.message = 'Please provide a message with at least 20 characters.';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setSubmitted(true);
    setFormData({ name: '', email: '', company: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Contact Consonragp Legal Partners | Brussels Law Firm</title>
        <meta
          name="description"
          content="Connect with Consonragp Legal Partners in Brussels. Schedule a consultation to discuss corporate, commercial, employment, or contract advisory matters."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Contact Us</h1>
          <p>
            We welcome confidential enquiries from corporate leaders, general counsel, and founders seeking precise legal
            support in Belgium.
          </p>
        </div>
      </section>

      <section className={`${styles.section} ${styles.contactSection}`}>
        <div className="container">
          <div className={styles.contactGrid}>
            <div className={styles.contactDetails}>
              <h2>Brussels Office</h2>
              <address>
                <span>Avenue Louise 250</span>
                <span>1050 Brussels, Belgium</span>
                <a href="tel:+3221234567">+32 2 123 4567</a>
                <a href="mailto:info@consonragp.com">info@consonragp.com</a>
              </address>
              <div className={styles.officeHours}>
                <h3>Office Hours</h3>
                <p>Monday to Friday: 08:30 – 19:00 CET</p>
                <p>Meetings by appointment only.</p>
              </div>
              <div className={styles.mapWrapper} aria-label="Map showing Consonragp Legal Partners location in Brussels">
                <iframe
                  title="Consonragp Legal Partners Brussels Location"
                  loading="lazy"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2518.534982181573!2d4.358417577189003!3d50.82594655930348!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c3c48ed92d8a41%3A0x948c7f035e7a92ed!2sAvenue%20Louise%20250%2C%201050%20Ixelles!5e0!3m2!1sen!2sbe!4v1700000000000!5m2!1sen!2sbe"
                  allowFullScreen
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>

            <div className={styles.formWrapper}>
              <h2>Request a Consultation</h2>
              <p>Share your enquiry. A member of our team will respond promptly.</p>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label htmlFor="name">
                  Full Name *
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'name-error' : undefined}
                    required
                  />
                  {errors.name && (
                    <span className={styles.error} id="name-error">
                      {errors.name}
                    </span>
                  )}
                </label>

                <label htmlFor="email">
                  Email *
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'email-error' : undefined}
                    required
                  />
                  {errors.email && (
                    <span className={styles.error} id="email-error">
                      {errors.email}
                    </span>
                  )}
                </label>

                <label htmlFor="company">
                  Company
                  <input
                    id="company"
                    name="company"
                    type="text"
                    value={formData.company}
                    onChange={handleChange}
                  />
                </label>

                <label htmlFor="message">
                  Message *
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    value={formData.message}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'message-error' : undefined}
                    required
                  />
                  {errors.message && (
                    <span className={styles.error} id="message-error">
                      {errors.message}
                    </span>
                  )}
                </label>

                <button type="submit" className={styles.submitButton}>
                  Submit Request
                </button>
                {submitted && <p className={styles.success}>Thank you. We will be in touch shortly.</p>}
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;
```