```javascript
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Clients counselled across Belgium', value: 180, suffix: '+' },
  { label: 'Cross-border matters navigated', value: 65, suffix: '' },
  { label: 'Languages spoken by our team', value: 6, suffix: '' },
  { label: 'Industry sectors served', value: 12, suffix: '' }
];

const testimonials = [
  {
    quote:
      'Consonragp Legal Partners guided us through a sensitive restructuring with precision and clarity. Their counsel was rigorous, empathetic, and business-savvy.',
    name: 'Elise Dupont',
    title: 'Chief People Officer, Global Tech Holdings'
  },
  {
    quote:
      'Their Brussels team combines deep corporate law expertise with seamless coordination across European jurisdictions. We could not have navigated our expansion without them.',
    name: 'Marc Stein',
    title: 'General Counsel, AlpenChem AG'
  },
  {
    quote:
      'Sharp analysis, timely responses, and a grounded understanding of our commercial reality. They are trusted partners for our most complex disputes.',
    name: 'Thomas Delvaux',
    title: 'CEO, BelTrans Logistics'
  }
];

const projects = [
  {
    title: 'Negotiation of cross-border supply agreements',
    category: 'Commercial',
    description: 'Structured risk allocation and compliance framework for EU-wide supplier roll-out.',
    image: 'https://picsum.photos/1200/800?random=401'
  },
  {
    title: 'Strategic acquisition of Belgian fintech',
    category: 'Corporate',
    description: 'Advised on due diligence, regulatory notifications, and deal documentation.',
    image: 'https://picsum.photos/1200/800?random=402'
  },
  {
    title: 'Workforce integration after merger',
    category: 'Employment',
    description: 'Led collective bargaining and harmonized policies across three jurisdictions.',
    image: 'https://picsum.photos/1200/800?random=403'
  },
  {
    title: 'High-stakes commercial arbitration',
    category: 'Commercial',
    description: 'Represented manufacturer in EUR 80M ICC arbitration seated in Brussels.',
    image: 'https://picsum.photos/1200/800?random=404'
  }
];

const faqItems = [
  {
    question: 'Which industries does Consonragp Legal Partners support?',
    answer:
      'We advise companies active in technology, finance, life sciences, mobility, energy, and consumer goods, among others. Our multidisciplinary team adapts to the nuances of each sector.'
  },
  {
    question: 'Do you handle cross-border corporate transactions?',
    answer:
      'Yes. Our Brussels-based attorneys coordinate regional and international transactions, working closely with trusted foreign counsel to ensure seamless execution.'
  },
  {
    question: 'Can we arrange an in-person consultation in Brussels?',
    answer:
      'Absolutely. We welcome clients at our Avenue Louise offices. Virtual consultations are also available to accommodate international schedules.'
  },
  {
    question: 'How do you approach dispute resolution?',
    answer:
      'We combine early case assessment with pragmatic settlement strategies while keeping litigation readiness at the forefront. Our team is experienced before Belgian courts and international tribunals.'
  }
];

const blogPosts = [
  {
    title: 'Belgian Corporate Governance Updates for 2024',
    excerpt:
      'Key amendments to the Belgian Companies and Associations Code require attention from boards and corporate secretaries before year-end.',
    date: 'March 12, 2024',
    link: '/insights'
  },
  {
    title: 'Managing Collective Redundancies: Lessons from Recent Case Law',
    excerpt:
      'A practical review of recent labour court decisions and how they influence redundancy planning and stakeholder communications.',
    date: 'February 26, 2024',
    link: '/insights'
  },
  {
    title: 'Cross-Border Commercial Contracts: Mitigating Supply Chain Risk',
    excerpt:
      'Contractual levers to secure continuity, allocate liability, and safeguard compliance across multi-jurisdictional supply chains.',
    date: 'January 30, 2024',
    link: '/insights'
  }
];

const Home = () => {
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('All');

  useEffect(() => {
    const intervals = statsData.map((stat, index) => {
      const increment = Math.max(1, Math.floor(stat.value / 40));
      return setInterval(() => {
        setStats((prev) => {
          const next = [...prev];
          if (next[index] < stat.value) {
            next[index] = Math.min(next[index] + increment, stat.value);
          }
          return next;
        });
      }, 60);
    });

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    projectFilter === 'All'
      ? projects
      : projects.filter((project) => project.category === projectFilter);

  return (
    <>
      <Helmet>
        <title>Brussels Law Firm | Consonragp Legal Partners</title>
        <meta
          name="description"
          content="Your trusted legal partner in Belgium for corporate law, commercial disputes, employment counsel, and strategic contract advisory services."
        />
      </Helmet>
      <section
        className={styles.hero}
        style={{ backgroundImage: "url('https://picsum.photos/1600/900?random=101')" }}
      >
        <div className={styles.heroContent}>
          <span className={styles.heroTag}>Brussels Attorneys</span>
          <h1 className={styles.heroTitle}>Your Trusted Legal Partner in Belgium</h1>
          <p className={styles.heroSubtitle}>
            Consonragp Legal Partners aligns legal strategy with business ambition. From corporate transactions to complex
            disputes, our Brussels-based firm delivers measured, responsive, and international-grade counsel.
          </p>
          <div className={styles.heroActions}>
            <a className={styles.primaryButton} href="/contact">
              Schedule Consultation
            </a>
            <a className={styles.secondaryButton} href="/practice-areas">
              Explore Practice Areas
            </a>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.introSection}`}>
        <div className="container">
          <div className={styles.introGrid}>
            <div className={styles.introText}>
              <h2 className={styles.sectionTitle}>Strategic Legal Counsel for Evolving Enterprises</h2>
              <p>
                We are a Brussels law firm built on collaboration, rigorous analysis, and absolute discretion. Our
                attorneys combine deep knowledge of Belgian law with international insight to deliver clear answers to
                corporate boards, general counsel, and founders navigating decisive moments.
              </p>
              <p>
                From cross-border M&amp;A and commercial disputes to employment transitions and long-term contract
                governance, Consonragp Legal Partners ensures that legal frameworks remain resilient, scalable, and
                aligned with organisational strategy.
              </p>
            </div>
            <div className={styles.introImageWrapper}>
              <img
                src="https://picsum.photos/900/700?random=102"
                alt="Modern Brussels law office meeting space"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.statsSection}`}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard}>
                <h3>
                  {stats[index]}
                  {stat.suffix}
                </h3>
                <p>{stat.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.practiceSection}`} id="practice-areas">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Practice Areas</h2>
            <p>
              Tailored teams deliver focused expertise across the core disciplines that drive business resilience and
              growth in Belgium and beyond.
            </p>
          </div>
          <div className={styles.practiceGrid}>
            <article className={styles.practiceCard}>
              <h3>Corporate Law</h3>
              <p>
                Governance, M&amp;A, restructurings, and capital markets counsel designed to safeguard stakeholder
                interests while enabling strategic expansion.
              </p>
              <ul>
                <li>Shareholder agreements and joint ventures</li>
                <li>Corporate governance compliance</li>
                <li>Transactions &amp; due diligence</li>
              </ul>
            </article>
            <article className={styles.practiceCard}>
              <h3>Commercial Litigation</h3>
              <p>
                Assertive representation in Belgian courts and international arbitration, grounded in precise case
                theory and industry understanding.
              </p>
              <ul>
                <li>Contractual and distribution disputes</li>
                <li>Interim relief &amp; enforcement</li>
                <li>Alternative dispute resolution</li>
              </ul>
            </article>
            <article className={styles.practiceCard}>
              <h3>Employment Law</h3>
              <p>
                Forward-looking employment strategies covering workforce mobility, collective bargaining, and executive
                engagements.
              </p>
              <ul>
                <li>HR advisory &amp; compliance</li>
                <li>Collective redundancies</li>
                <li>Executive employment arrangements</li>
              </ul>
            </article>
            <article className={styles.practiceCard}>
              <h3>Contract Advisory</h3>
              <p>
                End-to-end contract lifecycle support, capturing risk allocation and commercial objectives in every
                clause.
              </p>
              <ul>
                <li>Commercial contract negotiation</li>
                <li>Supply chain resilience</li>
                <li>Long-term partnership frameworks</li>
              </ul>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.approachSection}`}>
        <div className="container">
          <div className={styles.approachGrid}>
            <div className={styles.approachContent}>
              <h2 className={styles.sectionTitle}>Our Approach</h2>
              <p>
                We engage early to understand the full picture, align with your objectives, and identify the path that
                balances legal certainty with commercial agility. The result is pragmatic advice, delivered swiftly and
                supported by meticulous execution.
              </p>
              <div className={styles.approachSteps}>
                <div>
                  <span className={styles.stepNumber}>01</span>
                  <h3>Discover &amp; Align</h3>
                  <p>Immersive onboarding to grasp your operational drivers and risk profile.</p>
                </div>
                <div>
                  <span className={styles.stepNumber}>02</span>
                  <h3>Strategise</h3>
                  <p>Cross-functional teams craft legal strategies anchored in measurable outcomes.</p>
                </div>
                <div>
                  <span className={styles.stepNumber}>03</span>
                  <h3>Execute &amp; Guide</h3>
                  <p>We handle negotiations, documentation, and representation with absolute diligence.</p>
                </div>
              </div>
            </div>
            <div className={styles.approachImageWrapper}>
              <img
                src="https://picsum.photos/900/700?random=103"
                alt="Attorneys collaborating on legal strategy in Brussels"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.processSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>How We Work</h2>
            <p>Clear milestones and accountability define every mandate we undertake.</p>
          </div>
          <div className={styles.processGrid}>
            <div className={styles.processCard}>
              <h3>1. Briefing &amp; Scoping</h3>
              <p>We refine the mandate, confirm stakeholders, and set realistic timelines and deliverables.</p>
            </div>
            <div className={styles.processCard}>
              <h3>2. Structured Analysis</h3>
              <p>Our lawyers coordinate research, fact gathering, and risk assessments tailored to your sector.</p>
            </div>
            <div className={styles.processCard}>
              <h3>3. Advisory Delivery</h3>
              <p>We present actionable advice, scenario planning, and decision-ready documentation.</p>
            </div>
            <div className={styles.processCard}>
              <h3>4. Implementation Support</h3>
              <p>From negotiations to representation, we remain alongside your team through completion.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.whySection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Why Choose Consonragp Legal Partners</h2>
          </div>
          <div className={styles.whyGrid}>
            <article>
              <h3>Business-Centric Insight</h3>
              <p>We bring clarity to complex situations, translating legal considerations into board-level strategy.</p>
            </article>
            <article>
              <h3>International Reach</h3>
              <p>Our Brussels hub coordinates multi-jurisdictional projects with trusted partner firms across Europe.</p>
            </article>
            <article>
              <h3>Responsive &amp; Reliable</h3>
              <p>Clients rely on our rapid turnaround and consistent availability at critical decision points.</p>
            </article>
            <article>
              <h3>Measured Advocacy</h3>
              <p>We advocate fiercely while keeping negotiation channels open and reputational interests protected.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.testimonialSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Client Testimonials</h2>
          </div>
          <div className={styles.testimonialCarousel}>
            <blockquote key={activeTestimonial} className={styles.testimonialQuote}>
              “{testimonials[activeTestimonial].quote}”
            </blockquote>
            <div className={styles.testimonialMeta}>
              <p className={styles.testimonialName}>{testimonials[activeTestimonial].name}</p>
              <p className={styles.testimonialTitle}>{testimonials[activeTestimonial].title}</p>
            </div>
            <div className={styles.carouselDots} role="tablist" aria-label="Client testimonials">
              {testimonials.map((_, index) => (
                <button
                  type="button"
                  key={index}
                  className={`${styles.carouselDot} ${activeTestimonial === index ? styles.dotActive : ''}`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Show testimonial ${index + 1}`}
                  aria-selected={activeTestimonial === index}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.projectsSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Representative Matters</h2>
            <p>Illustrative engagements that highlight our cross-functional strengths.</p>
          </div>
          <div className={styles.filterBar} role="group" aria-label="Project filters">
            {['All', 'Corporate', 'Commercial', 'Employment'].map((category) => (
              <button
                type="button"
                key={category}
                className={`${styles.filterButton} ${projectFilter === category ? styles.filterActive : ''}`}
                onClick={() => setProjectFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img src={project.image} alt={`${project.title} case study`} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.teamPreview}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Leadership Team</h2>
            <p>
              Senior partners based in Brussels lead each engagement, bringing together specialist teams as needed.
            </p>
          </div>
          <div className={styles.teamGrid}>
            <article className={styles.teamCard}>
              <img src="https://picsum.photos/400/400?random=201" alt="Portrait of Anneke Verstraete" loading="lazy" />
              <div>
                <h3>Anneke Verstraete</h3>
                <p>Managing Partner • Corporate &amp; M&amp;A</p>
              </div>
            </article>
            <article className={styles.teamCard}>
              <img src="https://picsum.photos/400/400?random=202" alt="Portrait of Olivier Lambert" loading="lazy" />
              <div>
                <h3>Olivier Lambert</h3>
                <p>Partner • Commercial Litigation</p>
              </div>
            </article>
            <article className={styles.teamCard}>
              <img src="https://picsum.photos/400/400?random=203" alt="Portrait of Sofia Janssens" loading="lazy" />
              <div>
                <h3>Sofia Janssens</h3>
                <p>Partner • Employment &amp; Labour</p>
              </div>
            </article>
            <article className={styles.teamCard}>
              <img src="https://picsum.photos/400/400?random=204" alt="Portrait of Dries Meunier" loading="lazy" />
              <div>
                <h3>Dries Meunier</h3>
                <p>Partner • Regulatory &amp; Contracts</p>
              </div>
            </article>
          </div>
          <div className={styles.teamCTA}>
            <a href="/attorneys" className={styles.primaryButton}>
              Meet the Attorneys
            </a>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.faqSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Frequently Asked Questions</h2>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.blogSection}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Latest Insights</h2>
            <a href="/insights" className={styles.viewAll}>
              View all insights
            </a>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <a href={post.link} className={styles.readMore}>
                  Continue reading →
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.ctaSection}`}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Ready to discuss your next strategic move?</h2>
            <p>
              Contact our Brussels office to arrange a confidential consultation with the team best suited to your
              mandate.
            </p>
            <a className={styles.ctaButton} href="/contact">
              Schedule Consultation
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
```