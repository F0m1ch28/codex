<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Mensaje enviado | Petro Control España</title>
  <meta name="description" content="Confirmación de envío del formulario de contacto de Petro Control España.">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="canonical" href="https://www.petrocontrolespana.es/thanks.php">
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%230f4c81'/%3E%3Cpath d='M20 44c0-8 8-12 8-20 0-4-2-8-2-8h12s2 4 2 8c0 8-8 12-8 20' fill='%23f05a28'/%3E%3Ccircle cx='32' cy='20' r='6' fill='%23ff8c3a'/%3E%3C/svg%3E">
  <link rel="stylesheet" href="styles.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
</head>
<body>
  <header class="site-header" role="banner">
    <div class="container">
      <a class="brand" href="index.html">
        <span class="brand-logo" aria-hidden="true">PC</span>
        <span>Petro Control España</span>
      </a>
      <button class="nav-toggle" aria-expanded="false" aria-controls="primary-navigation" aria-label="Abrir navegación">☰</button>
      <nav class="site-nav" id="primary-navigation" role="navigation">
        <ul>
          <li><a href="index.html">Inicio</a></li>
          <li><a href="about.html">Quiénes Somos</a></li>
          <li><a href="solutions.html">Soluciones</a></li>
          <li><a href="technology.html">Tecnología</a></li>
          <li><a href="performance.html">Desempeño</a></li>
          <li><a href="projects.html">Proyectos</a></li>
          <li><a href="contact.php">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>
  <main>
    <section class="page-hero">
      <div class="container">
        <div class="hero-content">
          <h1>Hemos recibido tu solicitud</h1>
          <p>El equipo de Petro Control España revisará la información y se pondrá en contacto contigo en menos de 24 horas laborales.</p>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <div class="card">
          <h2 class="section-title">Próximos pasos</h2>
          <ul class="list-check">
            <li><span aria-hidden="true">✓</span><div>Analizamos los datos y definimos el equipo técnico adecuado.</div></li>
            <li><span aria-hidden="true">✓</span><div>Contactaremos por teléfono para concretar la agenda de evaluación.</div></li>
            <li><span aria-hidden="true">✓</span><div>Compartiremos un informe preliminar con las prioridades sugeridas.</div></li>
          </ul>
          <a class="btn btn-primary" href="index.html">Volver al inicio</a>
        </div>
      </div>
    </section>
  </main>
  <footer class="site-footer" role="contentinfo">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <a class="brand" href="index.html">
            <span class="brand-logo" aria-hidden="true">PC</span>
            <span>Petro Control España</span>
          </a>
          <p>Sistemas avanzados de monitorización y gestión inteligente para refinerías y plantas petroquímicas en España.</p>
        </div>
        <div>
          <h3>Compañía</h3>
          <div class="footer-nav">
            <a href="about.html">Historia y equipo</a>
            <a href="projects.html">Casos de estudio</a>
            <a href="performance.html">Indicadores</a>
          </div>
        </div>
        <div>
          <h3>Recursos</h3>
          <div class="footer-nav">
            <a href="technology.html">Tecnología</a>
            <a href="solutions.html">Herramientas</a>
            <a href="contact.php">Soporte operativo</a>
          </div>
        </div>
        <div>
          <h3>Legal</h3>
          <div class="footer-nav">
            <a href="privacy.html">Privacidad</a>
            <a href="cookies.html">Cookies</a>
            <a href="terms.html">Términos legales</a>
          </div>
        </div>
      </div>
      <div class="footer-meta">
        <span>© <span id="year">2024</span> Petro Control España</span>
        <span>Torre Cepsa, Paseo de la Castellana 259A, 28046 Madrid</span>
        <span>Tel: <a href="tel:+34913456789">+34 913 456 789</a></span>
        <span><a href="sitemap.xml">Mapa del sitio</a></span>
      </div>
    </div>
  </footer>
  <aside class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies" hidden>
    <div>
      <strong>Configuración de cookies</strong>
      <p>Utilizamos cookies técnicas para garantizar la operatividad del sitio y recopilar métricas anónimas de uso. Puedes aceptar o rechazar su aplicación.</p>
      <a href="cookies.html">Más información</a>
    </div>
    <div class="cookie-actions">
      <button class="btn-cookie decline" type="button">Rechazar</button>
      <button class="btn-cookie accept" type="button">Aceptar</button>
    </div>
  </aside>
  <script src="script.js" defer></script>
</body>
</html>