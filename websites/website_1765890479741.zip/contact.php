<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = htmlspecialchars($_POST["nombre"] ?? "");
    $empresa = htmlspecialchars($_POST["empresa"] ?? "");
    $email = htmlspecialchars($_POST["email"] ?? "");
    $telefono = htmlspecialchars($_POST["telefono"] ?? "");
    $area = htmlspecialchars($_POST["area"] ?? "");
    $mensaje = htmlspecialchars($_POST["mensaje"] ?? "");
    if ($nombre && $email && $telefono && $mensaje) {
        header("Location: thanks.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Contacto | Petro Control España</title>
  <meta name="description" content="Contacta con Petro Control España para solicitar una evaluación industrial o soporte especializado.">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta property="og:title" content="Contacto | Petro Control España">
  <meta property="og:description" content="Solicita evaluación industrial y soporte avanzado para refinerías.">
  <link rel="canonical" href="https://www.petrocontrolespana.es/contact.php">
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%230f4c81'/%3E%3Cpath d='M20 44c0-8 8-12 8-20 0-4-2-8-2-8h12s2 4 2 8c0 8-8 12-8 20' fill='%23f05a28'/%3E%3Ccircle cx='32' cy='20' r='6' fill='%23ff8c3a'/%3E%3C/svg%3E">
  <link rel="stylesheet" href="styles.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
</head>
<body>
  <header class="site-header" role="banner">
    <div class="container">
      <a class="brand" href="index.html">
        <span class="brand-logo" aria-hidden="true">PC</span>
        <span>Petro Control España</span>
      </a>
      <button class="nav-toggle" aria-expanded="false" aria-controls="primary-navigation" aria-label="Abrir navegación">☰</button>
      <nav class="site-nav" id="primary-navigation" role="navigation">
        <ul>
          <li><a href="index.html">Inicio</a></li>
          <li><a href="about.html">Quiénes Somos</a></li>
          <li><a href="solutions.html">Soluciones</a></li>
          <li><a href="technology.html">Tecnología</a></li>
          <li><a href="performance.html">Desempeño</a></li>
          <li><a href="projects.html">Proyectos</a></li>
          <li><a href="contact.php">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>
  <main>
    <section class="page-hero">
      <div class="container">
        <div class="hero-content">
          <h1>Solicitar Evaluación Industrial</h1>
          <p>Coordinamos sesiones técnicas, visitas de campo y análisis de datos para impulsar la excelencia operativa en refinerías españolas.</p>
        </div>
      </div>
    </section>
    <section class="section" aria-labelledby="contacto">
      <div class="container">
        <div class="grid two-columns">
          <div>
            <div class="contact-card">
              <h2 class="section-title" id="contacto">Datos de contacto</h2>
              <div class="contact-details">
                <div><strong>Dirección:</strong> Torre Cepsa, Paseo de la Castellana 259A, 28046 Madrid</div>
                <div><strong>Teléfono:</strong> <a href="tel:+34913456789">+34 913 456 789</a></div>
                <div><strong>Correo:</strong> <a href="mailto:contacto@petrocontrolespana.es">contacto@petrocontrolespana.es</a></div>
                <div><strong>Horarios:</strong> Lunes a viernes de 08:00 a 18:00</div>
              </div>
              <div class="map-embed">
                <iframe title="Ubicación Petro Control España" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.203389727266!2d-3.689861684604915!3d40.49544997935605!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd422ec016ec9e03%3A0x8d2d0d4aad0bceac!2sTorre%20Cepsa!5e0!3m2!1ses!2ses!4v1697050000000" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
              </div>
            </div>
          </div>
          <div>
            <form class="form" action="contact.php" method="post" data-validate>
              <div class="form-feedback" aria-live="assertive"></div>
              <div class="form-control">
                <label for="nombre">Nombre completo *</label>
                <input id="nombre" name="nombre" type="text" data-required="true" autocomplete="name" value="<?php echo $nombre ?? ''; ?>">
              </div>
              <div class="form-control">
                <label for="empresa">Empresa *</label>
                <input id="empresa" name="empresa" type="text" data-required="true" autocomplete="organization" value="<?php echo $empresa ?? ''; ?>">
              </div>
              <div class="form-control">
                <label for="email">Correo electrónico *</label>
                <input id="email" name="email" type="email" data-required="true" autocomplete="email" value="<?php echo $email ?? ''; ?>">
              </div>
              <div class="form-control">
                <label for="telefono">Teléfono *</label>
                <input id="telefono" name="telefono" type="tel" data-required="true" autocomplete="tel-national" value="<?php echo $telefono ?? ''; ?>">
              </div>
              <div class="form-control">
                <label for="area">Área de interés *</label>
                <select id="area" name="area" data-required="true">
                  <option value="" disabled selected>Selecciona una opción</option>
                  <option value="Monitorización de procesos">Monitorización de procesos</option>
                  <option value="Analítica energética">Analítica energética</option>
                  <option value="Ciberseguridad OT">Ciberseguridad OT</option>
                  <option value="Sala de control remota">Sala de control remota</option>
                </select>
              </div>
              <div class="form-control">
                <label for="mensaje">Mensaje *</label>
                <textarea id="mensaje" name="mensaje" data-required="true"><?php echo $mensaje ?? ''; ?></textarea>
              </div>
              <div class="notice">Al enviar este formulario aceptas nuestra <a href="privacy.html">política de privacidad</a>. Responderemos en un plazo máximo de 24 horas laborables.</div>
              <button class="btn btn-primary" type="submit">Enviar solicitud</button>
            </form>
          </div>
        </div>
      </div>
    </section>
  </main>
  <footer class="site-footer" role="contentinfo">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <a class="brand" href="index.html">
            <span class="brand-logo" aria-hidden="true">PC</span>
            <span>Petro Control España</span>
          </a>
          <p>Sistemas avanzados de monitorización y gestión inteligente para refinerías y plantas petroquímicas en España.</p>
        </div>
        <div>
          <h3>Compañía</h3>
          <div class="footer-nav">
            <a href="about.html">Historia y equipo</a>
            <a href="projects.html">Casos de estudio</a>
            <a href="performance.html">Indicadores</a>
          </div>
        </div>
        <div>
          <h3>Recursos</h3>
          <div class="footer-nav">
            <a href="technology.html">Tecnología</a>
            <a href="solutions.html">Herramientas</a>
            <a href="contact.php">Soporte operativo</a>
          </div>
        </div>
        <div>
          <h3>Legal</h3>
          <div class="footer-nav">
            <a href="privacy.html">Privacidad</a>
            <a href="cookies.html">Cookies</a>
            <a href="terms.html">Términos legales</a>
          </div>
        </div>
      </div>
      <div class="footer-meta">
        <span>© <span id="year">2024</span> Petro Control España</span>
        <span>Torre Cepsa, Paseo de la Castellana 259A, 28046 Madrid</span>
        <span>Tel: <a href="tel:+34913456789">+34 913 456 789</a></span>
        <span><a href="sitemap.xml">Mapa del sitio</a></span>
      </div>
    </div>
  </footer>
  <aside class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies" hidden>
    <div>
      <strong>Configuración de cookies</strong>
      <p>Utilizamos cookies técnicas para garantizar la operatividad del sitio y recopilar métricas anónimas de uso. Puedes aceptar o rechazar su aplicación.</p>
      <a href="cookies.html">Más información</a>
    </div>
    <div class="cookie-actions">
      <button class="btn-cookie decline" type="button">Rechazar</button>
      <button class="btn-cookie accept" type="button">Aceptar</button>
    </div>
  </aside>
  <script src="script.js" defer></script>
</body>
</html>