document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      siteNav.classList.toggle("open");
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".btn-cookie.accept");
  const declineBtn = document.querySelector(".btn-cookie.decline");
  const consentKey = "pceConsent";

  function setConsent(status) {
    localStorage.setItem(consentKey, status);
    if (cookieBanner) {
      cookieBanner.hidden = true;
    }
  }

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      cookieBanner.hidden = false;
    } else {
      cookieBanner.hidden = true;
    }
  }

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => setConsent("accepted"));
  }
  if (declineBtn) {
    declineBtn.addEventListener("click", () => setConsent("declined"));
  }

  const forms = document.querySelectorAll("form[data-validate]");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      const requiredFields = form.querySelectorAll("[data-required]");
      let hasError = false;
      requiredFields.forEach((field) => {
        if (!field.value.trim()) {
          field.setAttribute("aria-invalid", "true");
          hasError = true;
        } else {
          field.removeAttribute("aria-invalid");
        }
        if (field.type === "email") {
          const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailPattern.test(field.value.trim())) {
            field.setAttribute("aria-invalid", "true");
            hasError = true;
          }
        }
      });
      if (hasError) {
        event.preventDefault();
        form.querySelector(".form-feedback").textContent = "Revisa los campos obligatorios y el formato del correo electrónico.";
      }
    });
  });

  const counters = document.querySelectorAll("[data-counter]");
  if (counters.length) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target;
            const target = parseInt(el.dataset.counter, 10);
            const duration = 1600;
            let start = null;
            function step(timestamp) {
              if (!start) start = timestamp;
              const progress = Math.min((timestamp - start) / duration, 1);
              el.textContent = Math.floor(progress * target);
              if (progress < 1) {
                window.requestAnimationFrame(step);
              } else {
                el.textContent = target;
              }
            }
            window.requestAnimationFrame(step);
            obs.unobserve(el);
          }
        });
      },
      { threshold: 0.4 }
    );
    counters.forEach((counter) => observer.observe(counter));
  }
});