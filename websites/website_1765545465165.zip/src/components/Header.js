import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { HiMenuAlt3, HiX } from 'react-icons/hi';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 16);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.classList.add('no-scroll');
    } else {
      document.body.classList.remove('no-scroll');
    }
  }, [isMenuOpen]);

  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`} aria-label="Главная навигация сайта">
      <div className={`container ${styles.inner}`}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          <span className={styles.logoAccent}>Введите</span> заголовок
        </NavLink>
        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Основное меню">
          <NavLink
            to="/"
            onClick={closeMenu}
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
          >
            Главная
          </NavLink>
          <NavLink
            to="/uslugi"
            onClick={closeMenu}
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
          >
            Услуги
          </NavLink>
          <NavLink
            to="/o-kompanii"
            onClick={closeMenu}
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
          >
            О компании
          </NavLink>
          <NavLink
            to="/blog"
            onClick={closeMenu}
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
          >
            Блог
          </NavLink>
          <NavLink
            to="/kontakty"
            onClick={closeMenu}
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
          >
            Контакты
          </NavLink>
        </nav>
        <button
          type="button"
          className={styles.menuButton}
          onClick={toggleMenu}
          aria-label={isMenuOpen ? 'Закрыть меню' : 'Открыть меню'}
          aria-expanded={isMenuOpen}
        >
          {isMenuOpen ? <HiX aria-hidden="true" /> : <HiMenuAlt3 aria-hidden="true" />}
        </button>
      </div>
    </header>
  );
};

export default Header;