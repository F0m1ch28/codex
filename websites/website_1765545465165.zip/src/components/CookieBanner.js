import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'vvedite-zagolovok-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о cookie">
      <div className={styles.content}>
        <p className={styles.text}>
          Мы используем файлы cookie, чтобы анализировать трафик и улучшать пользовательский опыт. Продолжая пользоваться сайтом, вы соглашаетесь с нашей{' '}
          <a href="/politika-cookie" className={styles.link}>политикой использования cookie</a>.
        </p>
        <button type="button" className={styles.button} onClick={acceptCookies}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;