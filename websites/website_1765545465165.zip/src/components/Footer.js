import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-label="Подвал сайта">
    <div className={`container ${styles.grid}`}>
      <div className={styles.brand}>
        <span className={styles.logo}>
          <span className={styles.logoAccent}>Введите</span> заголовок
        </span>
        <p className={styles.tagline}>
          Помогаем командам выстраивать устойчивые цифровые экосистемы и ускорять развитие бизнеса.
        </p>
      </div>
      <div className={styles.column}>
        <h4 className={styles.heading}>Навигация</h4>
        <ul className={styles.list}>
          <li><NavLink to="/" className={styles.link}>Главная</NavLink></li>
          <li><NavLink to="/uslugi" className={styles.link}>Услуги</NavLink></li>
          <li><NavLink to="/o-kompanii" className={styles.link}>О компании</NavLink></li>
          <li><NavLink to="/blog" className={styles.link}>Блог</NavLink></li>
          <li><NavLink to="/kontakty" className={styles.link}>Контакты</NavLink></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4 className={styles.heading}>Документы</h4>
        <ul className={styles.list}>
          <li><NavLink to="/politika-konfidencialnosti" className={styles.link}>Политика конфиденциальности</NavLink></li>
          <li><NavLink to="/usloviya-ispolzovaniya" className={styles.link}>Условия использования</NavLink></li>
          <li><NavLink to="/politika-cookie" className={styles.link}>Политика использования cookie</NavLink></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4 className={styles.heading}>Контакты</h4>
        <ul className={styles.list}>
          <li>
            <span className={styles.label}>Адрес:</span>
            <span className={styles.value}>[Адрес будет указан позже]</span>
          </li>
          <li>
            <span className={styles.label}>Телефон:</span>
            <a className={styles.link} href="tel:+7XXXXXXXXXX">+7 (XXX) XXX-XX-XX</a>
          </li>
          <li>
            <span className={styles.label}>Email:</span>
            <a className={styles.link} href="mailto:info@vvedite-zagolovok.ru">info@vvedite-zagolovok.ru</a>
          </li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <p className={styles.copy}>© {new Date().getFullYear()} Введите заголовок. Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;