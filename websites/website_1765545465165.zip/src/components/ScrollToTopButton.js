import React, { useState, useEffect } from 'react';
import { HiArrowUp } from 'react-icons/hi';
import styles from './ScrollToTopButton.module.css';

const ScrollToTopButton = () => {
  const [isShown, setIsShown] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      setIsShown(window.scrollY > 240);
    };
    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const handleScroll = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <button
      type="button"
      className={`${styles.button} ${isShown ? styles.visible : ''}`}
      onClick={handleScroll}
      aria-label="Прокрутить страницу вверх"
    >
      <HiArrowUp aria-hidden="true" />
    </button>
  );
};

export default ScrollToTopButton;