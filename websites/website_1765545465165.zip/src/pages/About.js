import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const milestones = [
  {
    year: '2016',
    title: 'Основание команды',
    description: 'Команда стратегов и технологов объединяется, чтобы помогать компаниям в управлении цифровыми продуктами.'
  },
  {
    year: '2019',
    title: 'Выход на международные рынки',
    description: 'Запускаем проекты в Восточной Европе и Азии, адаптируя подход к локальным особенностям.'
  },
  {
    year: '2021',
    title: 'Создание исследовательского центра',
    description: 'Фокусируемся на изучении поведения пользователей, запускаем лабораторию по тестированию цифровых сценариев.'
  },
  {
    year: '2023',
    title: 'Партнёрские программы',
    description: 'Запускаем программы совместной работы с акселераторами и образовательными платформами.'
  }
];

const values = [
  {
    title: 'Партнёрство',
    description: 'Мы работаем как единая команда с заказчиком, не отделяя себя от его целей и задач.'
  },
  {
    title: 'Ответственность',
    description: 'Берём ответственность за результат и не боимся сложных решений.'
  },
  {
    title: 'Открытость',
    description: 'Делимся знаниями, показываем прогресс и всегда остаёмся на связи.'
  },
  {
    title: 'Любопытство',
    description: 'Постоянно исследуем, пробуем новое и ищем способы сделать продукт еще лучше.'
  }
];

const leadership = [
  {
    name: 'Владимир Сафронов',
    role: 'Управляющий партнёр',
    bio: 'До основания «Введите заголовок» руководил цифровыми проектами в крупной телеком-компании. Специализируется на системном подходе к трансформации.',
    photo: 'https://picsum.photos/400/400?random=61'
  },
  {
    name: 'Алина Громова',
    role: 'Директор по операционной эффективности',
    bio: 'Помогает командам выстраивать процессы, ответственный за культуру непрерывного улучшения.',
    photo: 'https://picsum.photos/400/400?random=62'
  },
  {
    name: 'Павел Дроздов',
    role: 'Руководитель по инновациям',
    bio: 'Следит за трендами и отвечает за пилотирование новых технологий в проектах клиентов.',
    photo: 'https://picsum.photos/400/400?random=63'
  }
];

const AboutPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>О компании | Введите заголовок</title>
      <meta
        name="description"
        content="Узнайте историю компании «Введите заголовок», наши ценности и команду, которая помогает клиентам реализовывать стратегические задачи."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1 className={styles.heroTitle}>О компании «Введите заголовок»</h1>
        <p className={styles.heroSubtitle}>
          Мы сформировали команду, которая не боится сложных задач и умеет сочетать стратегию, технологии и эмпатию. Каждый проект для нас — совместное путешествие с клиентом.
        </p>
      </div>
    </section>

    <section className={styles.mission}>
      <div className="container">
        <div className={styles.missionGrid}>
          <div className={styles.missionContent}>
            <h2 className={styles.sectionTitle}>Миссия</h2>
            <p>
              Мы создаём продукты и сервисы, которые приносят пользу людям и последствиями влияют на развитие бизнеса. Помогаем компаниям построить экосистемы, в которых удобно работать сотрудникам и клиентам.
            </p>
          </div>
          <div className={styles.missionIllustration}>
            <img
              src="https://picsum.photos/800/600?random=64"
              alt="Команда анализирует данные и строит стратегию"
            />
          </div>
        </div>
      </div>
    </section>

    <section className={styles.values}>
      <div className="container">
        <h2 className={styles.sectionTitle}>Наши ценности</h2>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.milestones}>
      <div className="container">
        <h2 className={styles.sectionTitle}>Этапы развития</h2>
        <div className={styles.timeline}>
          {milestones.map((item) => (
            <div key={item.year} className={styles.timelineItem}>
              <span className={styles.timelineYear}>{item.year}</span>
              <div className={styles.timelineContent}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <div className="container">
        <h2 className={styles.sectionTitle}>Лидеры практик</h2>
        <div className={styles.teamGrid}>
          {leadership.map((person) => (
            <article key={person.name} className={styles.teamCard}>
              <img src={person.photo} alt={person.name} className={styles.teamPhoto} />
              <div className={styles.teamBody}>
                <h3>{person.name}</h3>
                <span className={styles.teamRole}>{person.role}</span>
                <p>{person.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default AboutPage;