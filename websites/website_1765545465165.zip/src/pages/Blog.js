import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Customer journey как инструмент управления опытом',
    date: '12 января 2024',
    preview: 'Как создать карту пути клиента, если у вас сложная экосистема и много точек контакта.',
    image: 'https://picsum.photos/800/600?random=81',
    tags: ['Customer Journey', 'CX', 'Исследования'],
    id: 'customer-journey'
  },
  {
    title: 'Управление продуктом через систему OKR',
    date: '5 января 2024',
    preview: 'Рассказали, как выстроить связку стратегических целей и метрик продукта.',
    image: 'https://picsum.photos/800/600?random=82',
    tags: ['Стратегия', 'Операционный менеджмент'],
    id: 'okr'
  },
  {
    title: 'Облачные платформы для быстрого масштабирования',
    date: '28 декабря 2023',
    preview: 'Какие шаги важно пройти, чтобы внедрить облачную платформу без потрясений.',
    image: 'https://picsum.photos/800/600?random=83',
    tags: ['Технологии', 'Облако'],
    id: 'cloud-growth'
  },
  {
    title: 'Система продуктовой аналитики: с чего начать',
    date: '18 декабря 2023',
    preview: 'Определяем ключевые события, строим дашборды и делимся опытом обучения команды.',
    image: 'https://picsum.photos/800/600?random=84',
    tags: ['Аналитика', 'Данные'],
    id: 'data'
  }
];

const BlogPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Блог | Введите заголовок</title>
      <meta
        name="description"
        content="Блог «Введите заголовок»: делимся лучшими практиками цифровой трансформации, опытом внедрения технологий и исследованиями."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1 className={styles.heroTitle}>Блог и исследования</h1>
        <p className={styles.heroSubtitle}>
          Мы аккумулируем экспертизу команды, делимся кейсами и методологией, которые помогают запускать устойчивые изменения.
        </p>
      </div>
    </section>

    <section className={styles.posts}>
      <div className="container">
        <div className={styles.grid}>
          {posts.map((post) => (
            <article key={post.id} className={styles.card} id={post.id}>
              <img src={post.image} alt={post.title} className={styles.image} />
              <div className={styles.body}>
                <span className={styles.date}>{post.date}</span>
                <h2 className={styles.title}>{post.title}</h2>
                <p className={styles.preview}>{post.preview}</p>
                <ul className={styles.tags}>
                  {post.tags.map((tag) => (
                    <li key={tag} className={styles.tag}>{tag}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default BlogPage;