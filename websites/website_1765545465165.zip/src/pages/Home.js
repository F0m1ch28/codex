import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const statsData = [
  { label: 'Проектов завершено', value: 128 },
  { label: 'Лояльных клиентов', value: 76 },
  { label: 'Городов присутствия', value: 12 },
  { label: 'Сертифицированных экспертов', value: 58 }
];

const servicesPreview = [
  {
    title: 'Стратегическое планирование',
    description: 'Фокус на цифровой трансформации и выстраивании устойчивой продуктовой стратегии.',
    image: 'https://picsum.photos/600/400?random=15',
    link: '/uslugi#strategy'
  },
  {
    title: 'Интеграция технологий',
    description: 'Внедряем облачные сервисы, автоматизируем процессы и повышаем эффективность работы команд.',
    image: 'https://picsum.photos/600/400?random=16',
    link: '/uslugi#technology'
  },
  {
    title: 'Опыт клиента',
    description: 'Исследуем поведение пользователей и строим seamless journey во всех точках контакта.',
    image: 'https://picsum.photos/600/400?random=17',
    link: '/uslugi#cx'
  },
  {
    title: 'Аналитика и рост',
    description: 'Настраиваем системы аналитики, чтобы решать задачи развития бизнеса на основе данных.',
    image: 'https://picsum.photos/600/400?random=18',
    link: '/uslugi#analytics'
  }
];

const benefits = [
  {
    title: 'Междисциплинарная команда',
    description: 'Эксперты по стратегии, дизайну, аналитике и продукту работают как единый организм.',
    icon: '🧠'
  },
  {
    title: 'Прозрачные процессы',
    description: 'Каждый этап сопровождается понятной коммуникацией и четким планом действий.',
    icon: '🔍'
  },
  {
    title: 'Ориентация на результат',
    description: 'Фокус на влиянии на ключевые метрики заказчика и долгосрочном эффекте.',
    icon: '🚀'
  },
  {
    title: 'Гибкость и масштабируемость',
    description: 'Подстраиваемся под формат сотрудничества и масштаб задач в любой момент.',
    icon: '🧩'
  }
];

const processSteps = [
  {
    title: 'Диагностика',
    description: 'Погружаемся в контекст бизнеса, исследуем аудиторию и точки роста.',
    number: '01'
  },
  {
    title: 'Стратегия',
    description: 'Формируем дорожную карту развития и определяем KPI.',
    number: '02'
  },
  {
    title: 'Запуск',
    description: 'Реализуем решения, сопровождаем внедрение и обучаем команду заказчика.',
    number: '03'
  },
  {
    title: 'Рост',
    description: 'Поддерживаем постоянное развитие, анализируем эффект и корректируем курс.',
    number: '04'
  }
];

const projects = [
  {
    title: 'Цифровая экосистема «Новый город»',
    description: 'Создали единый портал услуг для жителей и бизнеса, интегрировав 12 внутренних систем.',
    image: 'https://picsum.photos/1200/800?random=21',
    category: 'Городские сервисы'
  },
  {
    title: 'Платформа лояльности Retail+',
    description: 'Объединили офлайн и онлайн программы, обеспечив рост повторных покупок на 35%.',
    image: 'https://picsum.photos/1200/800?random=22',
    category: 'Ритейл'
  },
  {
    title: 'Сервис поддержки пациентов',
    description: 'Разработали цифровой сценарий взаимодействия с пациентами и персоналом клиники.',
    image: 'https://picsum.photos/1200/800?random=23',
    category: 'Медицина'
  }
];

const testimonials = [
  {
    name: 'Анна Лисицына',
    role: 'Директор по развитию, «Городские инициативы»',
    quote: 'Команда «Введите заголовок» помогла нам выстроить цифровую экосистему так, чтобы жители реально почувствовали изменения. Бесшовное внедрение и уважительное отношение к процессам внутри города.',
    photo: 'https://picsum.photos/200/200?random=31'
  },
  {
    name: 'Максим Горюнов',
    role: 'Руководитель продуктового офиса, Retail+',
    quote: 'У ребят потрясающая дисциплина и внимание к деталям. На каждом этапе было ясно, зачем мы делаем ту или иную задачу.',
    photo: 'https://picsum.photos/200/200?random=32'
  }
];

const team = [
  {
    name: 'Ирина Алексеева',
    role: 'Партнёр по стратегии',
    description: '15 лет опыта в трансформации крупных компаний, автор продуктовых акселераторов.',
    photo: 'https://picsum.photos/400/400?random=41'
  },
  {
    name: 'Глеб Руднев',
    role: 'Директор по технологиям',
    description: 'Специалист по архитектуре облачных решений и интеграции сложных систем.',
    photo: 'https://picsum.photos/400/400?random=42'
  },
  {
    name: 'Мария Климова',
    role: 'Руководитель CX-направления',
    description: 'Исследователь пользовательского опыта, фасилитатор дизайн-мышления.',
    photo: 'https://picsum.photos/400/400?random=43'
  }
];

const blogPreview = [
  {
    title: 'Как выстроить customer journey в сложной экосистеме',
    date: '12 января 2024',
    image: 'https://picsum.photos/800/600?random=51',
    excerpt: 'Разбираем методологию картирования пути клиента и внедрения непрерывных улучшений.',
    link: '/blog#customer-journey'
  },
  {
    title: 'Облачные платформы как драйвер роста компании',
    date: '28 декабря 2023',
    image: 'https://picsum.photos/800/600?random=52',
    excerpt: 'Опыт внедрения масштабируемой архитектуры в быстрорастущем бизнесе.',
    link: '/blog#cloud-growth'
  },
  {
    title: 'Культура данных: зачем она нужна и как ее развивать',
    date: '14 декабря 2023',
    image: 'https://picsum.photos/800/600?random=53',
    excerpt: 'Инструменты и подходы, которые помогают принимать решения на основе данных.',
    link: '/blog#data-culture'
  }
];

const faqItems = [
  {
    question: 'С чего начинается сотрудничество?',
    answer: 'Мы проводим стартовую диагностическую сессию: обсуждаем цели, ограничения, ожидаемый эффект и определяем формат взаимодействия.'
  },
  {
    question: 'Работаете ли вы с распределёнными командами?',
    answer: 'Да. Мы выстроили гибридные процессы, которые позволяют эффективно взаимодействовать с распределёнными командами в разных часовых поясах.'
  },
  {
    question: 'Можно ли подключиться к отдельному этапу проекта?',
    answer: 'Мы подстраиваемся под запрос: берём на себя полный цикл или подключаемся к точечной задаче, например, исследованию или внедрению аналитики.'
  }
];

const HomePage = () => {
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [activeFaq, setActiveFaq] = useState(null);

  useEffect(() => {
    const animationDuration = 1200;
    const frameDuration = 30;
    const totalFrames = Math.round(animationDuration / frameDuration);
    const counters = statsData.map(() => 0);
    let frame = 0;

    const counterInterval = setInterval(() => {
      frame += 1;
      const progress = frame / totalFrames;
      const easedProgress = 1 - Math.pow(1 - progress, 3);

      statsData.forEach((stat, index) => {
        counters[index] = Math.round(stat.value * easedProgress);
      });

      setAnimatedStats([...counters]);

      if (frame === totalFrames) {
        clearInterval(counterInterval);
      }
    }, frameDuration);

    return () => clearInterval(counterInterval);
  }, []);

  const toggleFaq = (index) => {
    setActiveFaq((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Введите заголовок | Цифровые решения для роста бизнеса</title>
        <meta
          name="description"
          content="Введите заголовок — команда, которая создаёт цифровые продукты, усиливает процессы и помогает компаниям расти. Узнайте, как мы можем помочь вам."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <span className={styles.heroBadge}>Стратегия • Технологии • Опыт</span>
            <h1 className={styles.heroTitle}>
              Цифровая трансформация, <span>которая даёт результат</span>
            </h1>
            <p className={styles.heroSubtitle}>
              Мы объединяем стратегию, дизайн, технологии и аналитику, чтобы создавать устойчивые решения и усиливать ваш бизнес.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className={styles.primaryButton}>Связаться с нами</Link>
              <Link to="/o-kompanii" className={styles.secondaryButton}>Узнать больше</Link>
            </div>
          </div>
          <div className={styles.heroMedia}>
            <div className={styles.heroImageWrapper}>
              <img
                src="https://picsum.photos/1600/900?random=11"
                alt="Команда «Введите заголовок», обсуждающая цифровой проект"
                className={styles.heroImage}
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.about}>
        <div className="container">
          <div className={styles.aboutGrid}>
            <div className={styles.aboutContent}>
              <h2 className={styles.sectionTitle}>Кто мы</h2>
              <p className={styles.sectionText}>
                «Введите заголовок» — команда, которая помогает компаниям запускать новые продукты, перестраивать процессы и выстраивать сильную цифровую стратегию. Мы глубоко погружаемся в контекст, чтобы создавать решения, которые действительно работают.
              </p>
              <Link to="/o-kompanii" className={styles.linkButton}>История компании</Link>
            </div>
            <div className={styles.statsCard}>
              {statsData.map((stat, index) => (
                <div key={stat.label} className={styles.statItem}>
                  <span className={styles.statValue}>{animatedStats[index]}</span>
                  <span className={styles.statLabel}>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.sectionHeading}>
            <h2 className={styles.sectionTitle}>Наши фокусы</h2>
            <p className={styles.sectionText}>
              Мы собираем кросс-функциональные команды под конкретную задачу и погружаемся настолько глубоко, насколько это нужно.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesPreview.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceImageWrapper}>
                  <img src={service.image} alt={service.title} className={styles.serviceImage} />
                </div>
                <div className={styles.serviceBody}>
                  <h3 className={styles.serviceTitle}>{service.title}</h3>
                  <p className={styles.serviceDescription}>{service.description}</p>
                  <Link to={service.link} className={styles.moreLink}>Подробнее</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className="container">
          <div className={styles.sectionHeading}>
            <h2 className={styles.sectionTitle}>Почему с нами комфортно</h2>
            <p className={styles.sectionText}>
              Мы объединяем сильную экспертизу, выстроенные процессы и человеческое отношение. Поэтому наши партнерства длятся годами.
            </p>
          </div>
          <div className={styles.benefitsGrid}>
            {benefits.map((benefit) => (
              <div key={benefit.title} className={styles.benefitCard}>
                <span className={styles.benefitIcon} aria-hidden="true">{benefit.icon}</span>
                <h3 className={styles.benefitTitle}>{benefit.title}</h3>
                <p className={styles.benefitDescription}>{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHeading}>
            <h2 className={styles.sectionTitle}>Как мы работаем</h2>
            <p className={styles.sectionText}>
              Процесс выстроен таким образом, чтобы каждый этап был прозрачным, а результат — измеримым.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <div key={step.number} className={styles.processCard}>
                <span className={styles.processNumber}>{step.number}</span>
                <h3 className={styles.processTitle}>{step.title}</h3>
                <p className={styles.processDescription}>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionHeading}>
            <h2 className={styles.sectionTitle}>Кейсы и проекты</h2>
            <p className={styles.sectionText}>
              Каждая история — это совместный путь с командой клиента. Вместе мы создаём новое качество сервиса и заметный экономический эффект.
            </p>
          </div>
          <div className={styles.projectsGrid}>
            {projects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={project.title} className={styles.projectImage} />
                <div className={styles.projectBody}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3 className={styles.projectTitle}>{project.title}</h3>
                  <p className={styles.projectDescription}>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.people}>
        <div className="container">
          <div className={styles.sectionHeading}>
            <h2 className={styles.sectionTitle}>Команда и рекомендации</h2>
            <p className={styles.sectionText}>
              Мы ценим прозрачность и честность. Делимся обратной связью клиентов и знакомим вас с лидерами направлений.
            </p>
          </div>
          <div className={styles.peopleGrid}>
            <div className={styles.testimonials}>
              {testimonials.map((testimonial) => (
                <blockquote key={testimonial.name} className={styles.testimonialCard}>
                  <div className={styles.testimonialHeader}>
                    <img src={testimonial.photo} alt={testimonial.name} className={styles.testimonialPhoto} />
                    <div>
                      <cite className={styles.testimonialName}>{testimonial.name}</cite>
                      <p className={styles.testimonialRole}>{testimonial.role}</p>
                    </div>
                  </div>
                  <p className={styles.testimonialQuote}>{testimonial.quote}</p>
                </blockquote>
              ))}
            </div>
            <div className={styles.team}>
              {team.map((member) => (
                <article key={member.name} className={styles.teamCard}>
                  <img src={member.photo} alt={member.name} className={styles.teamPhoto} />
                  <div className={styles.teamBody}>
                    <h3 className={styles.teamName}>{member.name}</h3>
                    <span className={styles.teamRole}>{member.role}</span>
                    <p className={styles.teamDescription}>{member.description}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHeading}>
            <h2 className={styles.sectionTitle}>Свежие заметки</h2>
            <p className={styles.sectionText}>
              Делимся практикой и инсайтами, которые помогают принимать стратегические решения.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPreview.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} className={styles.blogImage} />
                <div className={styles.blogBody}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3 className={styles.blogTitle}>{post.title}</h3>
                  <p className={styles.blogExcerpt}>{post.excerpt}</p>
                  <Link to={post.link} className={styles.moreLink}>Читать статью</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={`container ${styles.ctaInner}`}>
          <div className={styles.ctaContent}>
            <h2 className={styles.ctaTitle}>Готовы обсудить ваш проект?</h2>
            <p className={styles.ctaText}>
              Заполните форму, и мы предложим формат взаимодействия, который будет комфортным именно вашей команде.
            </p>
            <Link to="/kontakty" className={styles.ctaButton}>Заполнить форму</Link>
          </div>
          <div className={styles.faq}>
            <h3 className={styles.faqTitle}>Частые вопросы</h3>
            <ul className={styles.faqList}>
              {faqItems.map((item, index) => (
                <li key={item.question} className={styles.faqItem}>
                  <button
                    type="button"
                    className={styles.faqButton}
                    onClick={() => toggleFaq(index)}
                    aria-expanded={activeFaq === index}
                  >
                    <span>{item.question}</span>
                    <span className={styles.faqToggle} aria-hidden="true">{activeFaq === index ? '−' : '+'}</span>
                  </button>
                  <div className={`${styles.faqAnswer} ${activeFaq === index ? styles.faqAnswerOpen : ''}`}>
                    <p>{item.answer}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;