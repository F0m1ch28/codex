import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialForm = {
  name: '',
  company: '',
  email: '',
  message: ''
};

const ContactsPage = () => {
  const [formData, setFormData] = useState(initialForm);
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateEmail = (email) => /\S+@\S+\.\S+/.test(email);

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setStatus({ type: 'error', message: 'Пожалуйста, заполните обязательные поля.' });
      return;
    }
    if (!validateEmail(formData.email)) {
      setStatus({ type: 'error', message: 'Пожалуйста, введите корректный адрес электронной почты.' });
      return;
    }
    setStatus({ type: 'success', message: 'Спасибо! Мы свяжемся с вами в ближайшее время.' });
    setFormData(initialForm);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Контакты | Введите заголовок</title>
        <meta
          name="description"
          content="Свяжитесь с командой «Введите заголовок». Мы обсудим ваши задачи и поможем подобрать формат сотрудничества."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1 className={styles.heroTitle}>Свяжитесь с нами</h1>
          <p className={styles.heroSubtitle}>
            Расскажите о вашей задаче, и мы подберём решение. Ответим в течение одного рабочего дня.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>Контактные данные</h2>
              <ul>
                <li>
                  <span className={styles.label}>Адрес</span>
                  <span className={styles.value}>[Адрес будет указан позже]</span>
                </li>
                <li>
                  <span className={styles.label}>Телефон</span>
                  <a href="tel:+7XXXXXXXXXX" className={styles.value}>+7 (XXX) XXX-XX-XX</a>
                </li>
                <li>
                  <span className={styles.label}>Email</span>
                  <a href="mailto:info@vvedite-zagolovok.ru" className={styles.value}>info@vvedite-zagolovok.ru</a>
                </li>
              </ul>
              <div className={styles.note}>
                <h3>Как мы работаем</h3>
                <p>
                  Начинаем с короткого знакомства, чтобы оценить задачи и предложить оптимальный формат. Уже на старте вы получите предварительный план работ и состав команды.
                </p>
              </div>
            </div>

            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Отправить заявку</h2>
              <div className={styles.field}>
                <label htmlFor="name">Имя*</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  placeholder="Как к вам обращаться"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="company">Компания</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  placeholder="Название компании"
                  value={formData.company}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Email*</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="Электронная почта"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Сообщение*</label>
                <textarea
                  id="message"
                  name="message"
                  placeholder="Расскажите о проекте или задаче"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  required
                />
              </div>
              {status.message && (
                <div className={`${styles.status} ${status.type === 'success' ? styles.success : styles.error}`}>
                  {status.message}
                </div>
              )}
              <button type="submit" className={styles.submitButton}>Отправить</button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactsPage;