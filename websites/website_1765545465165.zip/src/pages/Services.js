import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

const serviceCategories = [
  { id: 'all', name: 'Все направления' },
  { id: 'strategy', name: 'Стратегия' },
  { id: 'technology', name: 'Технологии' },
  { id: 'experience', name: 'Клиентский опыт' },
  { id: 'growth', name: 'Рост и аналитика' }
];

const services = [
  {
    id: 'strategy',
    title: 'Стратегия цифровой трансформации',
    description: 'Разрабатываем долгосрочные дорожные карты развития, определяем приоритеты и метрики успеха.',
    details: ['Исследование и аудит', 'Формирование vision', 'Дорожная карта инициатив'],
    image: 'https://picsum.photos/700/500?random=71'
  },
  {
    id: 'technology',
    title: 'Технологическая архитектура',
    description: 'Проектируем архитектуру, выбираем стек и настраиваем интеграции для устойчивых систем.',
    details: ['Архитектурный дизайн', 'Облачные решения', 'Интеграция продуктов'],
    image: 'https://picsum.photos/700/500?random=72'
  },
  {
    id: 'experience',
    title: 'Дизайн клиентского опыта',
    description: 'Создаём сервисные сценарии, которые упрощают жизнь клиентам и сотрудникам.',
    details: ['Customer journey', 'Сервис-дизайн', 'Дизайн-спринты'],
    image: 'https://picsum.photos/700/500?random=73'
  },
  {
    id: 'growth',
    title: 'Продуктовая аналитика и рост',
    description: 'Настраиваем измеримые воронки и помогаем находить точки роста на основе данных.',
    details: ['Системы аналитики', 'Эксперименты и A/B-тесты', 'Прогнозирование'],
    image: 'https://picsum.photos/700/500?random=74'
  },
  {
    id: 'strategy',
    title: 'Организация процесса управления продуктом',
    description: 'Помогаем выстроить продуктовые команды и процессы, чтобы идеи быстрее доходили до реализации.',
    details: ['Организационный дизайн', 'Наставничество', 'Система OKR'],
    image: 'https://picsum.photos/700/500?random=75'
  }
];

const ServicesPage = () => {
  const [activeCategory, setActiveCategory] = useState('all');

  const filteredServices =
    activeCategory === 'all'
      ? services
      : services.filter((service) => service.id === activeCategory);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Услуги | Введите заголовок</title>
        <meta
          name="description"
          content="Комплекс услуг компании «Введите заголовок»: стратегия, технологии, клиентский опыт и аналитика для устойчивого роста бизнеса."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1 className={styles.heroTitle}>Чем мы можем помочь</h1>
          <p className={styles.heroSubtitle}>
            Мы берём ответственность за результат и проводим компании через весь путь изменений: от диагностики до масштабирования решений.
          </p>
        </div>
      </section>

      <section className={styles.filters}>
        <div className="container">
          <div className={styles.filterBar} role="tablist" aria-label="Категории услуг">
            {serviceCategories.map((category) => (
              <button
                key={category.id}
                type="button"
                role="tab"
                aria-selected={activeCategory === category.id}
                className={`${styles.filterButton} ${activeCategory === category.id ? styles.filterButtonActive : ''}`}
                onClick={() => setActiveCategory(category.id)}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.list}>
        <div className="container">
          <div className={styles.cards}>
            {filteredServices.map((service) => (
              <article key={service.title} className={styles.card}>
                <div className={styles.cardMedia}>
                  <img src={service.image} alt={service.title} />
                </div>
                <div className={styles.cardBody}>
                  <span className={styles.cardBadge}>{serviceCategories.find((cat) => cat.id === service.id)?.name}</span>
                  <h2>{service.title}</h2>
                  <p>{service.description}</p>
                  <ul>
                    {service.details.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;