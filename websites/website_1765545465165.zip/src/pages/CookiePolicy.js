import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Политика использования Cookie | Введите заголовок</title>
      <meta
        name="description"
        content="Политика использования файлов cookie компании «Введите заголовок»."
      />
    </Helmet>
    <div className="container">
      <h1>Политика использования файлов cookie</h1>
      <p>Последнее обновление: 10 января 2024 года</p>

      <h2>1. Что такое cookie</h2>
      <p>
        Cookie — это небольшие файлы, которые сохраняются на вашем устройстве и помогают нам анализировать использование сайта и улучшать сервис.
      </p>

      <h2>2. Какие cookie мы используем</h2>
      <ul>
        <li>Технические cookie для корректной работы сайта;</li>
        <li>Аналитические cookie для понимания поведения пользователей;</li>
        <li>Функциональные cookie для сохранения ваших настроек.</li>
      </ul>

      <h2>3. Управление cookie</h2>
      <p>
        Вы можете изменить настройки cookie в вашем браузере. Обратите внимание, что отключение cookie может повлиять на работу сайта.
      </p>

      <h2>4. Контакты</h2>
      <p>
        Если у вас есть вопросы о нашей политике cookie, напишите нам на info@vvedite-zagolovok.ru.
      </p>
    </div>
  </div>
);

export default CookiePolicyPage;