import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage from './pages/Services';
import ContactsPage from './pages/Contact';
import BlogPage from './pages/Blog';
import PrivacyPolicyPage from './pages/PrivacyPolicy';
import TermsOfUsePage from './pages/TermsOfUse';
import CookiePolicyPage from './pages/CookiePolicy';

const ScrollToTopOnRouteChange = () => {
  const location = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);
  return null;
};

const App = () => {
  return (
    <>
      <ScrollToTopOnRouteChange />
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/uslugi" element={<ServicesPage />} />
          <Route path="/o-kompanii" element={<AboutPage />} />
          <Route path="/kontakty" element={<ContactsPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/politika-konfidencialnosti" element={<PrivacyPolicyPage />} />
          <Route path="/usloviya-ispolzovaniya" element={<TermsOfUsePage />} />
          <Route path="/politika-cookie" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </>
  );
};

export default App;