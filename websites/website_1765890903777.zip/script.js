const navToggle = document.querySelector(".nav-toggle");
const navigation = document.querySelector(".primary-navigation");
const cookieBanner = document.querySelector(".cookie-banner");
const acceptCookiesBtn = document.querySelector(".cookie-accept");
const declineCookiesBtn = document.querySelector(".cookie-decline");

if (navToggle && navigation) {
  navToggle.addEventListener("click", () => {
    const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
    navToggle.setAttribute("aria-expanded", String(!isExpanded));
    navigation.classList.toggle("active");
  });

  navigation.addEventListener("click", (event) => {
    if (event.target.classList.contains("nav-link")) {
      navigation.classList.remove("active");
      navToggle.setAttribute("aria-expanded", "false");
    }
  });
}

function showCookieBanner() {
  if (cookieBanner) {
    requestAnimationFrame(() => cookieBanner.classList.add("visible"));
  }
}

function hideCookieBanner() {
  if (cookieBanner) {
    cookieBanner.classList.remove("visible");
  }
}

function setCookieConsent(status) {
  const now = new Date();
  const expiryDays = 180;
  now.setTime(now.getTime() + expiryDays * 24 * 60 * 60 * 1000);
  const consentData = {
    status,
    updatedAt: now.toISOString(),
  };
  localStorage.setItem("hc-cookie-consent", JSON.stringify(consentData));
}

function getCookieConsent() {
  try {
    const stored = localStorage.getItem("hc-cookie-consent");
    return stored ? JSON.parse(stored) : null;
  } catch (error) {
    console.error("Impossibile leggere il consenso cookie:", error);
    return null;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const consent = getCookieConsent();
  if (!consent) {
    setTimeout(showCookieBanner, 600);
  }

  if (acceptCookiesBtn) {
    acceptCookiesBtn.addEventListener("click", () => {
      setCookieConsent("accepted");
      hideCookieBanner();
    });
  }

  if (declineCookiesBtn) {
    declineCookiesBtn.addEventListener("click", () => {
      setCookieConsent("declined");
      hideCookieBanner();
    });
  }
});