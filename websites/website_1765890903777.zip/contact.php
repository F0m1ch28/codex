<?php
$nome = isset($_POST["nome"]) ? htmlspecialchars($_POST["nome"], ENT_QUOTES, "UTF-8") : "";
$email = isset($_POST["email"]) ? htmlspecialchars($_POST["email"], ENT_QUOTES, "UTF-8") : "";
$telefono = isset($_POST["telefono"]) ? htmlspecialchars($_POST["telefono"], ENT_QUOTES, "UTF-8") : "";
$azienda = isset($_POST["azienda"]) ? htmlspecialchars($_POST["azienda"], ENT_QUOTES, "UTF-8") : "";
$messaggio = isset($_POST["messaggio"]) ? htmlspecialchars($_POST["messaggio"], ENT_QUOTES, "UTF-8") : "";
?>
<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8">
  <title>Contatti | Hydro Control Italia</title>
  <meta name="description" content="Modulo contatti Hydro Control Italia. Indirizzo, telefono, email e richiesta di valutazione energetica per centrali idroelettriche.">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta property="og:title" content="Contatti | Hydro Control Italia">
  <meta property="og:description" content="Richiedi una valutazione energetica per il tuo impianto idroelettrico con Hydro Control Italia.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.hydrocontrolitalia.it/contact.php">
  <meta property="og:image" content="https://picsum.photos/seed/hccontact/1200/630">
  <link rel="canonical" href="https://www.hydrocontrolitalia.it/contact.php">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="icon" type="image/svg+xml" href="/favicon.svg">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <a class="skip-link" href="#contenuto-principale">Salta al contenuto principale</a>
  <header class="site-header" role="banner">
    <div class="container">
      <a class="logo" href="index.html">
        <span>HC</span>
        Hydro Control Italia
      </a>
      <button class="nav-toggle" aria-expanded="false" aria-controls="site-navigation" aria-label="Apri menù di navigazione">☰</button>
      <nav class="primary-navigation" id="site-navigation" aria-label="Principale">
        <ul class="nav-list">
          <li><a class="nav-link" href="index.html">Home</a></li>
          <li><a class="nav-link" href="about.html">Chi siamo</a></li>
          <li><a class="nav-link" href="solutions.html">Soluzioni</a></li>
          <li><a class="nav-link" href="technology.html">Tecnologia</a></li>
          <li><a class="nav-link" href="performance.html">Performance</a></li>
          <li><a class="nav-link" href="projects.html">Progetti</a></li>
          <li><a class="nav-link nav-cta btn btn-outline" href="contact.php">Contatti</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main id="contenuto-principale">
    <section class="page-hero">
      <div class="container">
        <div class="section-header">
          <p class="section-pretitle">Contatti</p>
          <h1 class="section-title">Richiedi Valutazione Energetica</h1>
          <p class="section-description">Parla con i nostri ingegneri per progettare il monitoraggio e il controllo intelligente del tuo impianto idroelettrico.</p>
        </div>
      </div>
    </section>

    <section class="section section-muted">
      <div class="container contact-grid">
        <div>
          <div class="card">
            <h2>Modulo interattivo</h2>
            <form action="thanks.php" method="post">
              <div class="field-group">
                <label for="nome">Nome e Cognome</label>
                <input id="nome" name="nome" type="text" required placeholder="Inserisci il tuo nome completo" value="<?php echo $nome; ?>">
              </div>
              <div class="field-group">
                <label for="email">Email professionale</label>
                <input id="email" name="email" type="email" required placeholder="nome@azienda.it" value="<?php echo $email; ?>">
              </div>
              <div class="field-group">
                <label for="telefono">Telefono</label>
                <input id="telefono" name="telefono" type="tel" required placeholder="+39 02 0000 0000" value="<?php echo $telefono; ?>">
              </div>
              <div class="field-group">
                <label for="azienda">Azienda / Ente</label>
                <input id="azienda" name="azienda" type="text" placeholder="Nome azienda o ente" value="<?php echo $azienda; ?>">
              </div>
              <div class="field-group">
                <label for="potenza">Potenza installata impianto</label>
                <select id="potenza" name="potenza">
                  <option value="0-10MW">0 - 10 MW</option>
                  <option value="10-30MW">10 - 30 MW</option>
                  <option value="30-100MW">30 - 100 MW</option>
                  <option value="100+MW">Oltre 100 MW</option>
                </select>
              </div>
              <div class="field-group">
                <label for="messaggio">Messaggio</label>
                <textarea id="messaggio" name="messaggio" rows="5" placeholder="Descrivi le esigenze del tuo impianto"><?php echo $messaggio; ?></textarea>
              </div>
              <p class="text-small">I dati inviati saranno trattati in conformità alla <a href="privacy.html">Privacy Policy</a>.</p>
              <button class="btn" type="submit">Invia richiesta</button>
            </form>
          </div>
        </div>
        <div>
          <div class="card contact-details">
            <h2>Contatta il nostro team</h2>
            <div class="contact-item">
              <div class="contact-icon">📍</div>
              <div>
                <strong>Indirizzo</strong>
                <p>Torre Diamante, Via della Liberazione 15, 20124 Milano, Italia</p>
              </div>
            </div>
            <div class="contact-item">
              <div class="contact-icon">☎️</div>
              <div>
                <strong>Telefono</strong>
                <p><a class="footer-link" href="tel:+390298765432">+39 02 9876 5432</a></p>
              </div>
            </div>
            <div class="contact-item">
              <div class="contact-icon">✉️</div>
              <div>
                <strong>Email</strong>
                <p><a class="footer-link" href="mailto:contatti@hydrocontrolitalia.it">contatti@hydrocontrolitalia.it</a></p>
              </div>
            </div>
            <div class="status-message">
              Team operativo disponibile dal lunedì al venerdì, dalle 8:30 alle 18:30.
            </div>
          </div>
          <div class="map-embed">
            <iframe title="Mappa Hydro Control Italia Milano" src="https://maps.google.com/maps?q=Torre%20Diamante%20Milano&t=&z=14&ie=UTF8&iwloc=&output=embed" width="100%" height="320" style="border:0;" loading="lazy"></iframe>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer" role="contentinfo">
    <div class="container footer-grid">
      <div class="footer-brand">
        <a class="logo" href="index.html">
          <span>HC</span>
          Hydro Control Italia
        </a>
        <p>Sistemi avanzati di monitoraggio e gestione intelligente per impianti idroelettrici su larga scala in Italia.</p>
        <p>Torre Diamante, Via della Liberazione 15, 20124 Milano, Italia</p>
        <p><a class="footer-link" href="tel:+390298765432">+39 02 9876 5432</a> · <a class="footer-link" href="mailto:contatti@hydrocontrolitalia.it">contatti@hydrocontrolitalia.it</a></p>
      </div>
      <div class="footer-nav">
        <div class="footer-nav-column">
          <h4>Navigazione</h4>
          <a class="footer-link" href="about.html">Chi siamo</a>
          <a class="footer-link" href="solutions.html">Soluzioni</a>
          <a class="footer-link" href="technology.html">Tecnologia</a>
          <a class="footer-link" href="performance.html">Performance</a>
        </div>
        <div class="footer-nav-column">
          <h4>Supporto</h4>
          <a class="footer-link" href="projects.html">Progetti</a>
          <a class="footer-link" href="privacy.html">Privacy</a>
          <a class="footer-link" href="cookies.html">Cookie</a>
          <a class="footer-link" href="terms.html">Termini legali</a>
        </div>
      </div>
    </div>
    <div class="container footer-meta">
      <span>© <span id="year">2024</span> Hydro Control Italia. Tutti i diritti riservati.</span>
      <a class="footer-link" href="sitemap.xml">Sitemap</a>
    </div>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Preferenze cookie">
    <h2>Gestione dei cookie</h2>
    <p>Utilizziamo cookie tecnici per garantire il corretto funzionamento del sito e cookie di misurazione anonimizzati per migliorare l’esperienza. Puoi accettare o rifiutare in qualsiasi momento.</p>
    <div class="cookie-actions">
      <button class="cookie-accept" type="button">Accetta</button>
      <button class="cookie-decline" type="button">Rifiuta</button>
    </div>
    <p class="text-small">Consulta la nostra <a href="cookies.html">Cookie Policy</a> per dettagli.</p>
  </div>

  <script src="script.js" defer></script>
  <script>
    document.getElementById("year").textContent = new Date().getFullYear();
  </script>
</body>
</html>