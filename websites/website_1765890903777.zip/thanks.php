<?php
$nome = isset($_POST["nome"]) ? htmlspecialchars($_POST["nome"], ENT_QUOTES, "UTF-8") : "Cliente";
$email = isset($_POST["email"]) ? htmlspecialchars($_POST["email"], ENT_QUOTES, "UTF-8") : "";
$telefono = isset($_POST["telefono"]) ? htmlspecialchars($_POST["telefono"], ENT_QUOTES, "UTF-8") : "";
$azienda = isset($_POST["azienda"]) ? htmlspecialchars($_POST["azienda"], ENT_QUOTES, "UTF-8") : "";
$potenza = isset($_POST["potenza"]) ? htmlspecialchars($_POST["potenza"], ENT_QUOTES, "UTF-8") : "";
$messaggio = isset($_POST["messaggio"]) ? htmlspecialchars($_POST["messaggio"], ENT_QUOTES, "UTF-8") : "";
?>
<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8">
  <title>Grazie | Hydro Control Italia</title>
  <meta name="description" content="Ringraziamento per il contatto Hydro Control Italia. Scopri i prossimi passi e torna alla homepage.">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta property="og:title" content="Grazie | Hydro Control Italia">
  <meta property="og:description" content="La tua richiesta è stata ricevuta da Hydro Control Italia. Ti ricontatteremo a breve.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.hydrocontrolitalia.it/thanks.php">
  <meta property="og:image" content="https://picsum.photos/seed/hcthanks/1200/630">
  <link rel="canonical" href="https://www.hydrocontrolitalia.it/thanks.php">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="icon" type="image/svg+xml" href="/favicon.svg">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <a class="skip-link" href="#contenuto-principale">Salta al contenuto principale</a>
  <header class="site-header" role="banner">
    <div class="container">
      <a class="logo" href="index.html">
        <span>HC</span>
        Hydro Control Italia
      </a>
      <button class="nav-toggle" aria-expanded="false" aria-controls="site-navigation" aria-label="Apri menù di navigazione">☰</button>
      <nav class="primary-navigation" id="site-navigation" aria-label="Principale">
        <ul class="nav-list">
          <li><a class="nav-link" href="index.html">Home</a></li>
          <li><a class="nav-link" href="about.html">Chi siamo</a></li>
          <li><a class="nav-link" href="solutions.html">Soluzioni</a></li>
          <li><a class="nav-link" href="technology.html">Tecnologia</a></li>
          <li><a class="nav-link" href="performance.html">Performance</a></li>
          <li><a class="nav-link" href="projects.html">Progetti</a></li>
          <li><a class="nav-link nav-cta btn btn-outline" href="contact.php">Contatti</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main id="contenuto-principale">
    <section class="page-hero">
      <div class="container">
        <div class="section-header">
          <p class="section-pretitle">Grazie</p>
          <h1 class="section-title">Richiesta ricevuta correttamente</h1>
          <p class="section-description">Ciao <?php echo $nome; ?>, il nostro team analizzerà la tua richiesta e ti contatterà al più presto.</p>
        </div>
      </div>
    </section>

    <section class="section section-muted">
      <div class="container grid">
        <div class="card">
          <h2>Dettagli forniti</h2>
          <ul class="report-list">
            <li class="report-item"><strong>Email:</strong> <span><?php echo $email; ?></span></li>
            <li class="report-item"><strong>Telefono:</strong> <span><?php echo $telefono; ?></span></li>
            <li class="report-item"><strong>Azienda / Ente:</strong> <span><?php echo $azienda; ?></span></li>
            <li class="report-item"><strong>Potenza installata:</strong> <span><?php echo $potenza; ?></span></li>
            <li class="report-item"><strong>Messaggio:</strong> <span><?php echo nl2br($messaggio); ?></span></li>
          </ul>
        </div>
        <div class="card">
          <h2>Prossimi passi</h2>
          <p>Un consulente Hydro Control Italia ti contatterà per concordare una call tecnica, raccogliere ulteriori dati sull’impianto e predisporre una valutazione energetica completa.</p>
          <a class="btn" href="index.html">Torna alla homepage</a>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer" role="contentinfo">
    <div class="container footer-grid">
      <div class="footer-brand">
        <a class="logo" href="index.html">
          <span>HC</span>
          Hydro Control Italia
        </a>
        <p>Sistemi avanzati di monitoraggio e gestione intelligente per impianti idroelettrici su larga scala in Italia.</p>
        <p>Torre Diamante, Via della Liberazione 15, 20124 Milano, Italia</p>
        <p><a class="footer-link" href="tel:+390298765432">+39 02 9876 5432</a> · <a class="footer-link" href="mailto:contatti@hydrocontrolitalia.it">contatti@hydrocontrolitalia.it</a></p>
      </div>
      <div class="footer-nav">
        <div class="footer-nav-column">
          <h4>Navigazione</h4>
          <a class="footer-link" href="about.html">Chi siamo</a>
          <a class="footer-link" href="solutions.html">Soluzioni</a>
          <a class="footer-link" href="technology.html">Tecnologia</a>
          <a class="footer-link" href="performance.html">Performance</a>
        </div>
        <div class="footer-nav-column">
          <h4>Supporto</h4>
          <a class="footer-link" href="projects.html">Progetti</a>
          <a class="footer-link" href="privacy.html">Privacy</a>
          <a class="footer-link" href="cookies.html">Cookie</a>
          <a class="footer-link" href="terms.html">Termini legali</a>
        </div>
      </div>
    </div>
    <div class="container footer-meta">
      <span>© <span id="year">2024</span> Hydro Control Italia. Tutti i diritti riservati.</span>
      <a class="footer-link" href="sitemap.xml">Sitemap</a>
    </div>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Preferenze cookie">
    <h2>Gestione dei cookie</h2>
    <p>Utilizziamo cookie tecnici per garantire il corretto funzionamento del sito e cookie di misurazione anonimizzati per migliorare l’esperienza. Puoi accettare o rifiutare in qualsiasi momento.</p>
    <div class="cookie-actions">
      <button class="cookie-accept" type="button">Accetta</button>
      <button class="cookie-decline" type="button">Rifiuta</button>
    </div>
    <p class="text-small">Consulta la nostra <a href="cookies.html">Cookie Policy</a> per dettagli.</p>
  </div>

  <script src="script.js" defer></script>
  <script>
    document.getElementById("year").textContent = new Date().getFullYear();
  </script>
</body>
</html>