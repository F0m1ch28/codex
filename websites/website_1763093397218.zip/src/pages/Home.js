import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => (
  <>
    <Helmet>
      <title>TechSolutions Inc. | Innovative IT Consulting & Software Development</title>
      <meta
        name="description"
        content="Discover how TechSolutions Inc. delivers strategic IT consulting, enterprise software engineering, and cloud transformation to accelerate business growth."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={`container ${styles.heroInner}`}>
        <div className={styles.heroCopy}>
          <p className={styles.kicker}>Trusted Technology Partner</p>
          <h1>Innovative IT Solutions for Your Business</h1>
          <p className={styles.subtitle}>
            We combine strategic insight, engineering excellence, and cloud expertise to build resilient digital platforms that propel enterprises forward.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contact" className={styles.primaryButton}>Partner with us</Link>
            <Link to="/services" className={styles.secondaryButton}>Explore services</Link>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://picsum.photos/seed/techstrategy/640/480"
            alt="Technology consultants collaborating on digital strategy"
            className={styles.heroImage}
          />
        </div>
      </div>
    </section>

    <section className={styles.services}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Comprehensive IT Expertise</h2>
          <p>
            We help organizations modernize their technology landscape, streamline operations, and deliver customer value through dependable software.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          <div className={styles.serviceCard}>
            <h3>IT Strategy & Consulting</h3>
            <p>
              Align technology initiatives with business objectives through assessments, roadmaps, and governance models tailored to your unique context.
            </p>
          </div>
          <div className={styles.serviceCard}>
            <h3>Custom Software Engineering</h3>
            <p>
              Design, build, and scale bespoke applications with modern architectures, API-first integrations, and secure DevOps practices.
            </p>
          </div>
          <div className={styles.serviceCard}>
            <h3>Cloud Transformation</h3>
            <p>
              Plan and execute cloud migrations, optimize workloads, and leverage automation to enhance agility and cost efficiency.
            </p>
          </div>
          <div className={styles.serviceCard}>
            <h3>Managed Reliability</h3>
            <p>
              Deliver consistent uptime and proactive support with observability-driven managed services and continuous improvement cycles.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.aboutPreview}>
      <div className={`container ${styles.aboutInner}`}>
        <div className={styles.aboutImageWrapper}>
          <img
            src="https://picsum.photos/seed/innovationhub/720/480"
            alt="Developers reviewing software dashboards in an innovation hub"
            className={styles.aboutImage}
          />
        </div>
        <div className={styles.aboutContent}>
          <h2>Engineering Innovation with Purpose</h2>
          <p>
            Since our founding, TechSolutions Inc. has empowered enterprises across industries to reimagine their digital capabilities. Our consultants, architects, and engineers collaborate closely with stakeholders to deliver measurable outcomes.
          </p>
          <ul className={styles.highlights}>
            <li>Cross-functional teams spanning strategy, design, and engineering.</li>
            <li>Human-centered approach focused on adoption and long-term value.</li>
            <li>Proven delivery framework informed by decades of enterprise experience.</li>
          </ul>
          <Link to="/about" className={styles.linkButton}>Learn more about us</Link>
        </div>
      </div>
    </section>

    <section className={styles.ctaSection}>
      <div className="container">
        <div className={styles.ctaCard}>
          <h2>Ready to accelerate your digital roadmap?</h2>
          <p>
            Partner with TechSolutions Inc. to translate bold ideas into scalable platforms backed by rigorous engineering and dependable support.
          </p>
          <Link to="/contact" className={styles.primaryButton}>Start a conversation</Link>
        </div>
      </div>
    </section>
  </>
);

export default Home;