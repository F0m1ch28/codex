import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Understand how TechSolutions Inc. uses cookies and similar technologies to enhance website functionality and user experience."
      />
    </Helmet>
    <section className={styles.page}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p className={styles.updated}>Last updated: January 5, 2024</p>

        <p>
          This Cookie Policy explains how TechSolutions Inc. (“we”, “us”, or “our”) uses cookies and similar technologies when you visit our website.
        </p>

        <h2>What Are Cookies?</h2>
        <p>
          Cookies are small text files placed on your device to collect standard internet log information and visitor behavior data. They help us provide a more personalized and efficient experience.
        </p>

        <h2>Types of Cookies We Use</h2>
        <ul>
          <li><strong>Essential Cookies:</strong> Necessary for the website to function, enabling core features such as navigation.</li>
          <li><strong>Analytics Cookies:</strong> Collect aggregated data about website performance to help us improve user experience.</li>
          <li><strong>Preference Cookies:</strong> Remember your settings and preferences for subsequent visits.</li>
        </ul>

        <h2>Managing Cookies</h2>
        <p>
          You can control cookies through your browser settings. Most browsers allow you to block or delete cookies. Please note that disabling certain cookies may affect website functionality.
        </p>

        <h2>Third-Party Cookies</h2>
        <p>
          We may allow trusted third parties to set cookies to assist with analytics or embedded content. These third parties are responsible for their own cookie practices.
        </p>

        <h2>Changes to This Policy</h2>
        <p>
          We may update this Cookie Policy from time to time. Any changes will be posted on this page with an updated date.
        </p>

        <h2>Contact Us</h2>
        <p>
          For questions about this Cookie Policy, contact us at info@techsolutions.com.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;