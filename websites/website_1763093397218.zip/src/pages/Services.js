import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => (
  <>
    <Helmet>
      <title>IT Consulting & Software Services | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Explore TechSolutions Inc. services including IT consulting, custom software development, managed support, and cloud transformation tailored to enterprise needs."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Services that Move Your Business Forward</h1>
        <p>
          We deliver end-to-end technology services designed to align with your strategy, accelerate delivery, and create sustainable digital capabilities.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className={`container ${styles.grid}`}>
        <article className={styles.card}>
          <h2>IT Consulting & Advisory</h2>
          <p>
            Navigate complex technology decisions with clarity. Our consultants partner with leadership to define roadmaps, establish governance, and optimize processes.
          </p>
          <ul>
            <li>Enterprise architecture assessments</li>
            <li>Digital transformation planning</li>
            <li>Technology portfolio rationalization</li>
            <li>IT operating model modernization</li>
          </ul>
        </article>

        <article className={styles.card}>
          <h2>Custom Software Development</h2>
          <p>
            Build secure, scalable solutions tailored to your operations. We employ modern engineering practices to deliver reliable software that engages users and integrates seamlessly.
          </p>
          <ul>
            <li>Product discovery and UX strategy</li>
            <li>Agile delivery using CI/CD tooling</li>
            <li>API design and system integrations</li>
            <li>Quality engineering and test automation</li>
          </ul>
        </article>

        <article className={styles.card}>
          <h2>Managed Support & Optimization</h2>
          <p>
            Ensure the ongoing resilience of your mission-critical systems with proactive monitoring, rapid issue resolution, and continual improvement programs.
          </p>
          <ul>
            <li>24/7 incident and problem management</li>
            <li>Performance tuning and optimization</li>
            <li>Security patching and compliance</li>
            <li>Knowledge transfer and enablement</li>
          </ul>
        </article>

        <article className={styles.card}>
          <h2>Cloud Solutions & Migration</h2>
          <p>
            Unlock the full potential of the cloud with strategy, engineering, and automation that minimize risk and accelerate value realization across your workloads.
          </p>
          <ul>
            <li>Cloud readiness assessments</li>
            <li>Landing zone and platform engineering</li>
            <li>Application modernization and migration</li>
            <li>Cloud FinOps and governance frameworks</li>
          </ul>
        </article>
      </div>
    </section>

    <section className={styles.cta}>
      <div className="container">
        <div className={styles.ctaCard}>
          <h2>Let’s build the next era of your technology landscape.</h2>
          <p>Connect with our experts to discuss your current challenges and explore a tailored plan.</p>
          <Link to="/contact" className={styles.ctaButton}>Schedule a consultation</Link>
        </div>
      </div>
    </section>
  </>
);

export default Services;