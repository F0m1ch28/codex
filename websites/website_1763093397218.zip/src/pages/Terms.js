import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Service | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Review the TechSolutions Inc. Terms of Service covering service engagements, responsibilities, and use of this website."
      />
    </Helmet>
    <section className={styles.page}>
      <div className="container">
        <h1>Terms of Service</h1>
        <p className={styles.updated}>Last updated: January 5, 2024</p>

        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing or using the TechSolutions Inc. website, or by engaging our services, you agree to comply with and be bound by these Terms of Service. If you do not agree, please refrain from using our website or services.
        </p>

        <h2>2. Professional Services</h2>
        <p>
          All consulting and software development services are delivered pursuant to mutually executed agreements that define project scope, deliverables, responsibilities, and timelines. These agreements supersede any conflicting terms contained herein.
        </p>

        <h2>3. Intellectual Property</h2>
        <p>
          Unless otherwise stated in a written agreement, TechSolutions Inc. retains ownership of methodologies, frameworks, and tools used in the delivery of services. Clients maintain ownership of their data and any bespoke deliverables created specifically for them.
        </p>

        <h2>4. Confidentiality</h2>
        <p>
          We treat client information as confidential and implement appropriate safeguards. Both parties agree not to disclose confidential information without prior consent, except as required by law.
        </p>

        <h2>5. Limitation of Liability</h2>
        <p>
          To the fullest extent permitted by law, TechSolutions Inc. is not liable for indirect, incidental, or consequential damages arising from the use of our website or services. Our aggregate liability is limited to amounts paid for the specific services giving rise to the claim.
        </p>

        <h2>6. Third-Party Links</h2>
        <p>
          Our website may contain links to third-party sites. These links are provided for convenience and do not signify endorsement. TechSolutions Inc. is not responsible for the content or practices of third-party websites.
        </p>

        <h2>7. Changes to Terms</h2>
        <p>
          We reserve the right to update these Terms of Service. Changes will be posted on this page with an updated revision date. Continued use of the website or services constitutes acceptance of the revised terms.
        </p>

        <h2>8. Contact</h2>
        <p>
          For questions about these terms, please contact TechSolutions Inc. at info@techsolutions.com.
        </p>
      </div>
    </section>
  </>
);

export default Terms;