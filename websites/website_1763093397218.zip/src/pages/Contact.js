import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialForm = {
  name: '',
  email: '',
  company: '',
  message: '',
};

const Contact = () => {
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your name.';
    if (!formData.company.trim()) newErrors.company = 'Please enter your company or organization.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email address.';
    } else {
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(formData.email)) {
        newErrors.email = 'Please provide a valid email address.';
      }
    }
    if (!formData.message.trim()) newErrors.message = 'Please share a brief description of your needs.';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length) {
      setErrors(validation);
      return;
    }
    setSubmitted(true);
    setFormData(initialForm);
    setErrors({});
  };

  return (
    <>
      <Helmet>
        <title>Contact TechSolutions Inc. | IT Consulting & Software Services</title>
        <meta
          name="description"
          content="Contact TechSolutions Inc. to discuss IT consulting, custom software development, managed services, and cloud transformation initiatives."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Contact TechSolutions Inc.</h1>
          <p>
            Tell us about your technology goals and we will connect you with the right experts. We respond to all inquiries within one business day.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className={`container ${styles.grid}`}>
          <div className={styles.formCard}>
            <h2>Share your project with us</h2>
            {submitted && (
              <div className={styles.successMessage}>
                Thank you for reaching out. Our team will connect with you shortly.
              </div>
            )}
            <form onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Full name*</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={!!errors.name}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                  placeholder="Jane Doe"
                />
                {errors.name && <span id="name-error" className={styles.error}>{errors.name}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="company">Company / Organization*</label>
                <input
                  type="text"
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  aria-invalid={!!errors.company}
                  aria-describedby={errors.company ? 'company-error' : undefined}
                  placeholder="Your company name"
                />
                {errors.company && <span id="company-error" className={styles.error}>{errors.company}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="email">Business email*</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={!!errors.email}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                  placeholder="name@company.com"
                />
                {errors.email && <span id="email-error" className={styles.error}>{errors.email}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="message">How can we help?*</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={!!errors.message}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                  placeholder="Share a brief overview of your project goals or challenges."
                />
                {errors.message && <span id="message-error" className={styles.error}>{errors.message}</span>}
              </div>

              <button type="submit" className={styles.submitButton}>Submit inquiry</button>
            </form>
          </div>

          <div className={styles.infoCard}>
            <div className={styles.infoBlock}>
              <h2>Visit or connect</h2>
              <address>
                123 Tech Avenue<br />
                Silicon Valley, CA 94025, USA
              </address>
              <a href="tel:+15551234567">+1 (555) 123-4567</a>
              <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
            </div>
            <div className={styles.mapWrapper}>
              <img
                src="https://static-maps.yandex.ru/1.x/?lang=en_US&ll=-122.143019,37.441883&z=14&l=map&size=650,300"
                alt="Map showing the location of TechSolutions Inc. in Silicon Valley"
              />
            </div>
            <p className={styles.note}>
              We welcome both virtual and on-site consultations. Let us know your preferred format when you get in touch.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;