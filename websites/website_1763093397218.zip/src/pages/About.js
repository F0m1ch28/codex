import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>About TechSolutions Inc. | Mission, Values & Team</title>
      <meta
        name="description"
        content="Learn about TechSolutions Inc.'s mission, values, and team committed to delivering strategic IT consulting and enterprise-grade software solutions."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={`container ${styles.heroInner}`}>
        <div className={styles.text}>
          <h1>Purpose-Driven Technology Leadership</h1>
          <p>
            TechSolutions Inc. was founded on the belief that technology should empower people, not complicate their work. Our multidisciplinary teams bridge strategy, engineering, and operations to deliver lasting impact.
          </p>
        </div>
        <div className={styles.imageWrapper}>
          <img
            src="https://picsum.photos/seed/techteam/720/480"
            alt="TechSolutions team collaborating in a modern workspace"
          />
        </div>
      </div>
    </section>

    <section className={styles.valuesSection}>
      <div className="container">
        <h2>Our Mission & Values</h2>
        <div className={styles.valuesGrid}>
          <div className={styles.valueCard}>
            <h3>Mission</h3>
            <p>
              We enable organizations to adapt and thrive in a rapidly changing digital landscape by delivering technology solutions that are thoughtful, resilient, and human-centered.
            </p>
          </div>
          <div className={styles.valueCard}>
            <h3>Integrity</h3>
            <p>
              We build trusted partnerships through transparency, accountability, and a relentless focus on our clients’ best interests.
            </p>
          </div>
          <div className={styles.valueCard}>
            <h3>Innovation</h3>
            <p>
              We cultivate continuous learning and experimentation, ensuring the solutions we deliver are future-ready and scalable.
            </p>
          </div>
          <div className={styles.valueCard}>
            <h3>Empowerment</h3>
            <p>
              We mentor and enable our clients’ teams to embrace new tools and processes, unlocking sustainable success beyond each engagement.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.expertiseSection}>
      <div className={`container ${styles.expertiseInner}`}>
        <div className={styles.expertiseText}>
          <h2>Experienced, Multidisciplinary Experts</h2>
          <p>
            Our consultants, architects, and engineers bring decades of experience across finance, healthcare, manufacturing, and technology sectors. From modernization to greenfield innovation, we balance established best practices with cutting-edge methodologies.
          </p>
          <ul>
            <li>Certified cloud architects and DevOps engineers.</li>
            <li>Product strategists skilled in user research and service design.</li>
            <li>Security specialists focused on proactive risk mitigation.</li>
            <li>Program leaders experienced in complex enterprise delivery.</li>
          </ul>
        </div>
        <div className={styles.timeline}>
          <div className={styles.milestone}>
            <span className={styles.year}>2012</span>
            <p>TechSolutions Inc. is founded to bridge strategy and execution for enterprise IT teams.</p>
          </div>
          <div className={styles.milestone}>
            <span className={styles.year}>2016</span>
            <p>Expanded cloud-native engineering practice and launched managed DevOps services.</p>
          </div>
          <div className={styles.milestone}>
            <span className={styles.year}>2020</span>
            <p>Introduced dedicated innovation labs for rapid prototyping and emerging technology exploration.</p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.partnershipSection}>
      <div className="container">
        <h2>Our Approach to Client Partnerships</h2>
        <div className={styles.approachGrid}>
          <div className={styles.approachCard}>
            <h3>Collaborative Discovery</h3>
            <p>
              We listen first to understand your goals, then co-create solution blueprints that address immediate priorities and long-term aspirations.
            </p>
          </div>
          <div className={styles.approachCard}>
            <h3>Transparent Delivery</h3>
            <p>
              Teams operate with shared metrics, clear communication cadences, and iterative checkpoints to ensure alignment at every stage.
            </p>
          </div>
          <div className={styles.approachCard}>
            <h3>Continuous Evolution</h3>
            <p>
              Engagements conclude with actionable roadmaps and capability handoffs, empowering your teams to maintain momentum.
            </p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default About;