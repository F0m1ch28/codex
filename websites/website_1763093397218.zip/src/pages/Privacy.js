import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Read the TechSolutions Inc. Privacy Policy outlining how we collect, use, and protect personal information."
      />
    </Helmet>
    <section className={styles.page}>
      <div className="container">
        <h1>Privacy Policy</h1>
        <p className={styles.updated}>Last updated: January 5, 2024</p>

        <p>
          This Privacy Policy describes how TechSolutions Inc. (“we”, “us”, or “our”) collects, uses, and protects personal information obtained through our website and professional engagements.
        </p>

        <h2>Information We Collect</h2>
        <p>
          We collect information you voluntarily provide, such as contact details and project requirements submitted through forms or direct communication. We may also collect technical data, including IP addresses, browser types, and usage patterns, to enhance website performance.
        </p>

        <h2>How We Use Information</h2>
        <p>We use collected information to:</p>
        <ul>
          <li>Respond to inquiries and provide requested services.</li>
          <li>Improve our website, services, and client experience.</li>
          <li>Send relevant updates, subject to your communication preferences.</li>
          <li>Maintain security, comply with legal obligations, and enforce agreements.</li>
        </ul>

        <h2>Data Sharing</h2>
        <p>
          We do not sell personal information. We may share data with trusted service providers who support our operations, subject to confidentiality obligations, or when required by law.
        </p>

        <h2>Data Retention</h2>
        <p>
          We retain personal information for as long as necessary to fulfill the purposes outlined in this policy or as required by applicable laws and contractual obligations.
        </p>

        <h2>Your Rights</h2>
        <p>
          Depending on your jurisdiction, you may have rights to access, correct, or delete personal information. To exercise these rights, contact us at info@techsolutions.com.
        </p>

        <h2>Security</h2>
        <p>
          We implement administrative, technical, and physical safeguards to protect personal data against unauthorized access, alteration, or disclosure.
        </p>

        <h2>International Transfers</h2>
        <p>
          When transferring personal information across borders, we rely on appropriate safeguards to protect your data consistent with applicable laws.
        </p>

        <h2>Updates</h2>
        <p>
          We may update this Privacy Policy periodically. Changes will be posted on this page with a revised date.
        </p>

        <h2>Contact</h2>
        <p>
          For privacy inquiries, contact TechSolutions Inc. at info@techsolutions.com.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;