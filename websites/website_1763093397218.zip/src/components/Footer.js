import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.inner}`}>
      <div className={styles.brandBlock}>
        <p className={styles.brand}>
          <span className={styles.brandAccent}>TechSolutions</span> Inc.
        </p>
        <p className={styles.tagline}>
          Empowering organizations with resilient technology foundations and transformative software solutions.
        </p>
      </div>
      <div className={styles.grid}>
        <div className={styles.column}>
          <h4 className={styles.heading}>Company</h4>
          <ul className={styles.list}>
            <li><Link to="/about" className={styles.link}>About</Link></li>
            <li><Link to="/services" className={styles.link}>Services</Link></li>
            <li><Link to="/contact" className={styles.link}>Contact</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4 className={styles.heading}>Policies</h4>
          <ul className={styles.list}>
            <li><Link to="/privacy" className={styles.link}>Privacy Policy</Link></li>
            <li><Link to="/terms" className={styles.link}>Terms of Service</Link></li>
            <li><Link to="/cookie-policy" className={styles.link}>Cookie Policy</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4 className={styles.heading}>Contact</h4>
          <address className={styles.address}>
            123 Tech Avenue<br />
            Silicon Valley, CA 94025, USA
          </address>
          <a href="tel:+15551234567" className={styles.link}>+1 (555) 123-4567</a>
          <a href="mailto:info@techsolutions.com" className={styles.link}>info@techsolutions.com</a>
        </div>
      </div>
    </div>
    <div className={styles.bottomBar}>
      <div className="container">
        <p className={styles.copy}>© {new Date().getFullYear()} TechSolutions Inc. All rights reserved.</p>
      </div>
    </div>
  </footer>
);

export default Footer;