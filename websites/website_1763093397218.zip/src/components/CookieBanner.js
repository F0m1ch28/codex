import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('techsolutions-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('techsolutions-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          We use cookies to enhance your experience, analyze site performance, and deliver tailored content. By continuing to browse, you agree to our use of cookies. Learn more in our{' '}
          <Link to="/cookie-policy" className={styles.link}>Cookie Policy</Link>.
        </p>
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;