import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';
import HomePage from './pages/HomePage';
import ArticlesPage from './pages/ArticlesPage';
import InterviewsPage from './pages/InterviewsPage';
import ResearchArchivePage from './pages/ResearchArchivePage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import TermsOfServicePage from './pages/TermsOfServicePage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import CookiePolicyPage from './pages/CookiePolicyPage';
import styles from './App.module.css';

const App = () => {
  return (
    <div className={styles.appWrapper}>
      <a href="#contenu-principal" className={styles.skipLink}>
        Aller au contenu principal
      </a>
      <Header />
      <main id="contenu-principal" className={styles.mainContent} role="main">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/articles" element={<ArticlesPage />} />
          <Route path="/interviews" element={<InterviewsPage />} />
          <Route path="/recherche" element={<ResearchArchivePage />} />
          <Route path="/a-propos" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/conditions-generales" element={<TermsOfServicePage />} />
          <Route path="/politique-de-confidentialite" element={<PrivacyPolicyPage />} />
          <Route path="/politique-de-cookies" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTopButton />
      <CookieBanner />
    </div>
  );
};

export default App;