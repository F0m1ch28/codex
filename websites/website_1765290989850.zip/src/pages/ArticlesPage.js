import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ArticlesPage.module.css';

const articles = [
  {
    title: 'Panification et rythmes urbains : chronique d’une journée de boulangerie',
    summary:
      'Analyse des horaires de production et de vente dans trois arrondissements, avec un focus sur l’articulation entre nuit de pétrissage et matinée de distribution.',
    image: '/images/article-rythmes-urbains.jpg',
    date: '12 mars 2024',
    themes: ['Organisation', 'Vie de quartier', 'Savoir-faire'],
  },
  {
    title: 'Transmission des gestes : immersion dans un atelier école du Faubourg Saint-Antoine',
    summary:
      'Reportage sur un dispositif d’apprentissage où compagnons boulangers et historiennes collaborent pour documenter les gestes patrimoniaux.',
    image: '/images/article-transmission.jpg',
    date: '28 février 2024',
    themes: ['Transmission', 'Histoire', 'Formation'],
  },
  {
    title: 'De la meule de pierre au pétrin mécanique : trajectoires techniques depuis 1900',
    summary:
      'Retour sur l’évolution des équipements boulangers parisiens et sur les débats qu’elle suscite parmi les professionnels et les chercheuses.',
    image: '/images/article-equipements.jpg',
    date: '19 février 2024',
    themes: ['Innovation', 'Technique', 'Patrimoine'],
  },
  {
    title: 'Baguette de tradition : une appellation au croisement du droit et de la culture',
    summary:
      'Décodage des textes réglementaires et des pratiques artisanales qui coexistent derrière la mention “de tradition française”.',
    image: '/images/article-baguette.jpg',
    date: '5 février 2024',
    themes: ['Réglementation', 'Culture', 'Goût'],
  },
];

const ArticlesPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Articles | Parisian Bakeries Review</title>
        <meta
          name="description"
          content="Sélection d’articles analytiques consacrés aux boulangeries parisiennes et à leurs évolutions historiques, sociales et techniques."
        />
      </Helmet>
      <div className={styles.header}>
        <h1>Articles</h1>
        <p>
          Chaque article propose une lecture contextualisée des pratiques boulangères parisiennes, en croisant
          sources historiques, témoignages et observations directes.
        </p>
      </div>
      <div className={styles.grid}>
        {articles.map((article) => (
          <article key={article.title} className={styles.card}>
            <div className={styles.imageWrapper}>
              <img src={article.image} alt={article.title} loading="lazy" />
            </div>
            <div className={styles.cardContent}>
              <span className={styles.date}>{article.date}</span>
              <h2>{article.title}</h2>
              <p>{article.summary}</p>
              <ul className={styles.themeList}>
                {article.themes.map((theme) => (
                  <li key={theme}>{theme}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default ArticlesPage;