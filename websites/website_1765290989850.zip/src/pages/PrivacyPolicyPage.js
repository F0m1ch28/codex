import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PrivacyPolicyPage.module.css';

const PrivacyPolicyPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Politique de confidentialité | Parisian Bakeries Review</title>
        <meta
          name="description"
          content="Politique de confidentialité de Parisian Bakeries Review concernant les données personnelles collectées."
        />
      </Helmet>
      <h1>Politique de confidentialité</h1>
      <p>
        Cette politique décrit la manière dont Parisian Bakeries Review traite les données personnelles recueillies dans
        le cadre de ses activités éditoriales et de ses formulaires en ligne.
      </p>
      <section>
        <h2>Données collectées</h2>
        <p>
          Les seules informations collectées concernent les adresses électroniques fournies pour la lettre d’information
          et les données renseignées via le formulaire de contact. Aucune donnée sensible n’est sollicitée.
        </p>
      </section>
      <section>
        <h2>Finalités</h2>
        <p>
          Les informations servent exclusivement à adresser les publications de la rédaction ou à répondre aux demandes
          formulées. Aucun transfert à des tiers n’est réalisé.
        </p>
      </section>
      <section>
        <h2>Durée de conservation</h2>
        <p>
          Les adresses collectées pour la lettre d’information sont conservées tant que la personne souhaite recevoir les
          bulletins. Les messages de contact sont archivés pour une durée maximale de trois ans.
        </p>
      </section>
      <section>
        <h2>Droits des personnes concernées</h2>
        <p>
          Toute personne peut demander l’accès, la rectification ou la suppression de ses données en contactant
          la rédaction à l’adresse contact@parisianbakeriesreview.fr.
        </p>
      </section>
      <section>
        <h2>Sécurité</h2>
        <p>
          Des mesures techniques et organisationnelles protègent les informations contre tout accès non autorisé.
        </p>
      </section>
    </div>
  );
};

export default PrivacyPolicyPage;