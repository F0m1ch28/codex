import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ResearchArchivePage.module.css';

const dossiers = [
  {
    title: 'Les fournils coopératifs du XXᵉ siècle',
    description:
      'Compilation d’archives municipales et de témoignages sur les initiatives collectives de panification entre 1910 et 1970.',
    format: 'Dossier documentaire',
    year: 2023,
  },
  {
    title: 'Impact des farines locales sur le goût parisien',
    description:
      'Étude sensorielle réalisée avec six boulangeries partenaires et un panel de dégustation indépendant.',
    format: 'Étude comparative',
    year: 2022,
  },
  {
    title: 'Typologie des vitrines boulangères',
    description:
      'Analyse iconographique de 240 photographies anciennes et contemporaines, avec un focus sur l’exposition des pains.',
    format: 'Atlas visuel',
    year: 2021,
  },
  {
    title: 'Chroniques des nuits de pétrissage',
    description:
      'Journal de terrain réalisé auprès de cinq équipes boulangères, mettant en évidence les gestes répétitifs et la coordination des équipes.',
    format: 'Carnet ethnographique',
    year: 2020,
  },
];

const ResearchArchivePage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Archive de recherche | Parisian Bakeries Review</title>
        <meta
          name="description"
          content="Collection de dossiers analytiques consacrés à l’histoire et aux pratiques des boulangeries parisiennes."
        />
      </Helmet>
      <div className={styles.header}>
        <h1>Archive de recherche</h1>
        <p>
          Les dossiers de recherche rassemblent des enquêtes au long cours, des compilations d’archives et des analyses
          croisées. Chaque document précise le cadre méthodologique et les sources mobilisées.
        </p>
      </div>
      <div className={styles.list}>
        {dossiers.map((dossier) => (
          <article key={dossier.title} className={styles.item}>
            <div>
              <h2>{dossier.title}</h2>
              <p>{dossier.description}</p>
            </div>
            <div className={styles.meta}>
              <span>{dossier.format}</span>
              <span>Publication {dossier.year}</span>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default ResearchArchivePage;