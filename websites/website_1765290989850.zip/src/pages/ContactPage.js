import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    nom: '',
    email: '',
    objet: '',
    message: '',
  });
  const [status, setStatus] = useState('idle');
  const [feedback, setFeedback] = useState('');

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.nom || !formData.email || !formData.objet || !formData.message) {
      setFeedback('Chaque champ doit être complété afin de traiter la demande.');
      setStatus('error');
      return;
    }
    const emailPattern = /^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/;
    if (!emailPattern.test(formData.email)) {
      setFeedback('Une adresse électronique valide est nécessaire pour assurer le suivi.');
      setStatus('error');
      return;
    }
    setStatus('success');
    setFeedback('Le message a été transmis à la rédaction. Une réponse sera formulée dans les meilleurs délais.');
    setFormData({
      nom: '',
      email: '',
      objet: '',
      message: '',
    });
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact | Parisian Bakeries Review</title>
        <meta
          name="description"
          content="Coordonnées et formulaire de contact de la rédaction de Parisian Bakeries Review."
        />
      </Helmet>
      <section className={styles.infoSection}>
        <h1>Contact</h1>
        <p>
          Toute demande relative aux recherches, aux archives ou aux collaborations peut être adressée à la rédaction
          via les coordonnées suivantes.
        </p>
        <div className={styles.contactDetails}>
          <div>
            <h2>Coordonnées</h2>
            <address>
              <span>Parisian Bakeries Review</span>
              <span>17 Rue du Boulanger</span>
              <span>75005 Paris, France</span>
              <a href="tel:+33143295412">+33 1 43 29 54 12</a>
              <a href="mailto:contact@parisianbakeriesreview.fr">contact@parisianbakeriesreview.fr</a>
            </address>
          </div>
          <div>
            <h2>Horaires de réponse</h2>
            <p>
              Le secrétariat éditorial répond du lundi au vendredi entre 9h et 18h.
            </p>
            <p>
              Les demandes urgentes relatives aux enquêtes en cours peuvent être signalées dans le champ « Objet » du formulaire.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.formSection}>
        <h2>Formulaire de contact</h2>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="nom">Nom et prénom</label>
            <input
              id="nom"
              name="nom"
              type="text"
              value={formData.nom}
              onChange={handleChange}
              placeholder="Nom Prénom"
              aria-required="true"
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Adresse électronique</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="adresse@example.fr"
              aria-required="true"
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="objet">Objet</label>
            <input
              id="objet"
              name="objet"
              type="text"
              value={formData.objet}
              onChange={handleChange}
              placeholder="Objet de la demande"
              aria-required="true"
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="message">Message</label>
            <textarea
              id="message"
              name="message"
              rows="6"
              value={formData.message}
              onChange={handleChange}
              placeholder="Préciser le contexte de la prise de contact"
              aria-required="true"
            />
          </div>
          <button type="submit" className={styles.submitButton}>
            Envoyer
          </button>
          {feedback && (
            <p className={`${styles.feedback} ${status === 'error' ? styles.error : styles.success}`}>
              {feedback}
            </p>
          )}
        </form>
      </section>
    </div>
  );
};

export default ContactPage;