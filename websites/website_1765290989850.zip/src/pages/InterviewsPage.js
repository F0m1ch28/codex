import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './InterviewsPage.module.css';

const interviews = [
  {
    name: 'Marin Dupré',
    title: 'Boulanger compagnon du Devoir',
    image: '/images/interview-marin.jpg',
    excerpt:
      'L’atelier de Marin Dupré retrace l’histoire des farines utilisées à Paris et présente le rôle des levains liquides dans la texture des miches contemporaines.',
    focus: 'Transmission des savoir-faire',
  },
  {
    name: 'Professeure Anaïs Gervais',
    title: 'Sociologue des pratiques alimentaires',
    image: '/images/interview-gervais.jpg',
    excerpt:
      'Cette spécialiste étudie la fréquentation des boulangers de quartier et la manière dont chaque fournil devient un point d’ancrage social.',
    focus: 'Approche sociologique',
  },
  {
    name: 'Catherine Marchal',
    title: 'Responsable d’un moulin francilien',
    image: '/images/interview-marchal.jpg',
    excerpt:
      'Le moulin dirigé par Catherine Marchal adapte ses moutures aux demandes des artisans tout en respectant les contraintes patrimoniales des cahiers des charges parisiens.',
    focus: 'Filière blé et mouture',
  },
];

const InterviewsPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Interviews | Parisian Bakeries Review</title>
        <meta
          name="description"
          content="Entretiens avec boulangers, historiennes et spécialistes du patrimoine culinaire parisien."
        />
      </Helmet>
      <div className={styles.header}>
        <h1>Interviews</h1>
        <p>
          Les interviews mettent en lumière les voix des artisanes, des artisans, des chercheuses et des chercheurs
          qui font vivre le patrimoine boulanger parisien.
        </p>
      </div>
      <div className={styles.grid}>
        {interviews.map((interview) => (
          <article key={interview.name} className={styles.card}>
            <div className={styles.imageWrapper}>
              <img src={interview.image} alt={`Portrait de ${interview.name}`} loading="lazy" />
            </div>
            <div className={styles.cardContent}>
              <h2>{interview.name}</h2>
              <p className={styles.title}>{interview.title}</p>
              <p>{interview.excerpt}</p>
              <span className={styles.focus}>{interview.focus}</span>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default InterviewsPage;