import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './AboutPage.module.css';

const AboutPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>À propos | Parisian Bakeries Review</title>
        <meta
          name="description"
          content="Présentation de la mission éditoriale, de la méthodologie et de l’équipe de Parisian Bakeries Review."
        />
      </Helmet>
      <section className={styles.introSection}>
        <h1>À propos de Parisian Bakeries Review</h1>
        <p>
          Parisian Bakeries Review est un journal en ligne consacré à l’étude des boulangeries parisiennes. La rédaction
          enquête sur les pratiques de panification, interroge la transmission des savoir-faire et contextualise les
          enjeux socioculturels liés à ce patrimoine vivant.
        </p>
      </section>

      <section className={styles.missionSection}>
        <div className={styles.sectionHeader}>
          <h2>Mission éditoriale</h2>
        </div>
        <div className={styles.missionGrid}>
          <article>
            <h3>Documenter</h3>
            <p>
              Les enquêtes s’appuient sur des immersions prolongées dans les ateliers, des entretiens avec les artisanes
              et artisans, ainsi que sur l’analyse de fonds d’archives publics et privés.
            </p>
          </article>
          <article>
            <h3>Contextualiser</h3>
            <p>
              Chaque dossier met en relation les pratiques contemporaines avec les évolutions historiques, les cadres
              réglementaires et les dynamiques urbaines propres à Paris.
            </p>
          </article>
          <article>
            <h3>Partager</h3>
            <p>
              Les contenus diffusés éclairent la diversité des approches, qu’il s’agisse de sociologie du travail, de
              patrimoine culinaire ou d’histoire des techniques.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.methodSection}>
        <div className={styles.sectionHeader}>
          <h2>Méthodologie</h2>
        </div>
        <div className={styles.methodContent}>
          <p>
            Les membres de la rédaction combinent observation participante, analyse comparative et veille documentaire.
            Chaque publication mentionne les sources mobilisées, la durée de l’enquête et les conditions d’accès aux
            ateliers visités. Une charte éthique encadre la restitution des propos recueillis.
          </p>
          <ul>
            <li>Entretiens semi-directifs avec les professionnelles et professionnels du secteur.</li>
            <li>Relevés photographiques contextualisés, archivés dans une base interne consultable sur demande.</li>
            <li>Lecture des décrets municipaux et nationaux régissant le métier de boulanger.</li>
            <li>Collaboration avec des centres de recherche en histoire de l’alimentation.</li>
          </ul>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className={styles.sectionHeader}>
          <h2>Équipe éditoriale</h2>
        </div>
        <div className={styles.teamGrid}>
          <article className={styles.teamCard}>
            <img src="/images/equipe-riviere.jpg" alt="Portrait de Camille Rivière" loading="lazy" />
            <h3>Camille Rivière</h3>
            <p className={styles.teamRole}>Direction éditoriale</p>
            <p>
              Historienne de l’alimentation, elle coordonne les enquêtes de terrain et assure la cohérence scientifique
              des publications.
            </p>
          </article>
          <article className={styles.teamCard}>
            <img src="/images/equipe-lemarchand.jpg" alt="Portrait de Théo Lemarchand" loading="lazy" />
            <h3>Théo Lemarchand</h3>
            <p className={styles.teamRole}>Journaliste et photographe</p>
            <p>
              Spécialiste du reportage visuel, il documente les gestes des boulangers et produit les séries d’images
              avec les équipes de nuit.
            </p>
          </article>
          <article className={styles.teamCard}>
            <img src="/images/equipe-benyahia.jpg" alt="Portrait de Salma Benyahia" loading="lazy" />
            <h3>Salma Benyahia</h3>
            <p className={styles.teamRole}>Analyste des politiques publiques</p>
            <p>
              Elle décortique les textes juridiques et suit les évolutions réglementaires concernant les boulangeries
              parisiennes.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;