import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './TermsOfServicePage.module.css';

const TermsOfServicePage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Conditions générales | Parisian Bakeries Review</title>
        <meta
          name="description"
          content="Conditions générales d’utilisation de Parisian Bakeries Review."
        />
      </Helmet>
      <h1>Conditions générales d’utilisation</h1>
      <p>
        Les présentes conditions générales encadrent l’accès au site Parisian Bakeries Review et à son contenu éditorial.
      </p>
      <section>
        <h2>Article 1 — Objet</h2>
        <p>
          Le site présente des analyses et des contenus journalistiques consacrés aux boulangeries parisiennes.
          L’accès est libre et implique l’acceptation des présentes dispositions.
        </p>
      </section>
      <section>
        <h2>Article 2 — Propriété intellectuelle</h2>
        <p>
          L’ensemble des textes, photographies et éléments graphiques est protégé par le droit de la propriété
          intellectuelle. Toute reproduction totale ou partielle nécessite l’autorisation écrite de l’éditeur.
        </p>
      </section>
      <section>
        <h2>Article 3 — Responsabilité</h2>
        <p>
          Les informations publiées sont vérifiées avec soin. La rédaction ne saurait être tenue responsable d’un usage
          inapproprié ou d’une interprétation erronée des contenus.
        </p>
      </section>
      <section>
        <h2>Article 4 — Disponibilité du service</h2>
        <p>
          Le site est accessible 7 jours sur 7, sous réserve d’interruptions techniques nécessaires à la maintenance
          ou à l’actualisation des contenus.
        </p>
      </section>
      <section>
        <h2>Article 5 — Modification des conditions</h2>
        <p>
          Parisian Bakeries Review se réserve la possibilité de modifier les présentes conditions afin de refléter les
          évolutions légales ou éditoriales. La version consultable en ligne fait foi.
        </p>
      </section>
    </div>
  );
};

export default TermsOfServicePage;