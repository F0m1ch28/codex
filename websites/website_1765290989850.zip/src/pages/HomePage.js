import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './HomePage.module.css';

const researchThemes = [
  {
    title: 'Boulangeries parisiennes',
    description: 'Cartographie des adresses emblématiques et analyse des pratiques de quartier.',
    icon: '🥖',
  },
  {
    title: 'Tradition boulangère',
    description: 'Étude des gestes ancestraux transmis dans les fournils et ateliers.',
    icon: '🧺',
  },
  {
    title: 'Pain au levain',
    description: 'Observation des fermentations lentes et de leurs impacts sensoriels.',
    icon: '🍞',
  },
  {
    title: 'Histoire de la baguette',
    description: 'Chronologie des formes, pesées et appellations réglementées.',
    icon: '📜',
  },
  {
    title: 'Réglementation',
    description: 'Analyse des décrets municipaux et normes sanitaires contemporaines.',
    icon: '⚖️',
  },
  {
    title: 'Transmission des savoir-faire',
    description: 'Portraits d’artisans formateurs et dispositifs de compagnonnage.',
    icon: '🎓',
  },
];

const mapPoints = [
  { name: 'Le Marais', top: '28%', left: '56%' },
  { name: 'Montmartre', top: '12%', left: '48%' },
  { name: 'Saint-Germain-des-Prés', top: '42%', left: '52%' },
  { name: 'Belleville', top: '22%', left: '70%' },
  { name: 'Bastille', top: '36%', left: '64%' },
  { name: 'Batignolles', top: '20%', left: '40%' },
];

const HomePage = () => {
  const [featuredArticle, setFeaturedArticle] = useState(null);
  const [featuredInterview, setFeaturedInterview] = useState(null);
  const [hoveredDistrict, setHoveredDistrict] = useState('');

  useEffect(() => {
    const articleTimeout = setTimeout(() => {
      setFeaturedArticle({
        title: 'Chronologie des fours parisiens du XIXᵉ siècle',
        summary:
          'Cette enquête retrace l’évolution des installations de cuisson à Paris et éclaire les liens entre urbanisme et fournils.',
        image: '/images/article-four-historique.jpg',
        path: '/articles',
      });
    }, 300);

    const interviewTimeout = setTimeout(() => {
      setFeaturedInterview({
        name: 'Dr Élodie Marchand',
        role: 'Historienne du patrimoine culinaire',
        quote:
          '« Les fournils parisiens révèlent la manière dont la ville a apprivoisé le feu et orchestré la production alimentaire quotidienne. »',
        image: '/images/interview-historienne.jpg',
        path: '/interviews',
      });
    }, 450);

    return () => {
      clearTimeout(articleTimeout);
      clearTimeout(interviewTimeout);
    };
  }, []);

  return (
    <div className={styles.homePage}>
      <Helmet>
        <title>Parisian Bakeries Review | Revue d’étude des boulangeries parisiennes</title>
        <meta
          name="description"
          content="Analyse culturelle, historique et sociale des boulangeries parisiennes, de leurs savoir-faire et de leur rôle urbain."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="section-hero">
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <h1 id="section-hero" className={styles.heroTitle}>
            Parisian Bakeries Review
          </h1>
          <p className={styles.heroSubtitle}>
            Revue culturelle et analytique consacrée aux patrimoines boulangers de Paris.
          </p>
          <p className={styles.heroText}>
            La rédaction observe les ateliers, collecte les récits des artisans et contextualise les savoir-faire
            qui façonnent le quotidien des quartiers parisiens.
          </p>
        </div>
      </section>

      {featuredArticle && (
        <section className={styles.featuredSection} aria-labelledby="section-article">
          <div className={styles.sectionHeader}>
            <h2 id="section-article">Dernière étude publiée</h2>
            <span className={styles.sectionTag}>Analyse approfondie</span>
          </div>
          <div className={styles.featuredCard}>
            <div className={styles.featuredImageWrapper}>
              <img
                src={featuredArticle.image}
                alt="Illustration d’un four traditionnel parisien"
                loading="lazy"
              />
            </div>
            <div className={styles.featuredContent}>
              <h3>{featuredArticle.title}</h3>
              <p>{featuredArticle.summary}</p>
              <Link to={featuredArticle.path} className={styles.featuredLink}>
                Lire l&apos;article
              </Link>
            </div>
          </div>
        </section>
      )}

      <section className={styles.themesSection} aria-labelledby="section-themes">
        <div className={styles.sectionHeader}>
          <h2 id="section-themes">Chantiers de recherche</h2>
          <span className={styles.sectionTag}>Axes thématiques</span>
        </div>
        <div className={styles.themeGrid}>
          {researchThemes.map((theme) => (
            <article key={theme.title} className={styles.themeCard}>
              <span className={styles.themeIcon} aria-hidden="true">
                {theme.icon}
              </span>
              <h3 className={styles.themeTitle}>{theme.title}</h3>
              <p className={styles.themeDescription}>{theme.description}</p>
            </article>
          ))}
        </div>
      </section>

      {featuredInterview && (
        <section className={styles.interviewSection} aria-labelledby="section-interview">
          <div className={styles.sectionHeader}>
            <h2 id="section-interview">Entretien de la semaine</h2>
            <span className={styles.sectionTag}>Regards d’expertes et d’experts</span>
          </div>
          <div className={styles.interviewCard}>
            <div className={styles.interviewImageWrapper}>
              <img
                src={featuredInterview.image}
                alt={`Portrait de ${featuredInterview.name}`}
                loading="lazy"
              />
            </div>
            <div className={styles.interviewContent}>
              <h3>{featuredInterview.name}</h3>
              <p className={styles.interviewRole}>{featuredInterview.role}</p>
              <blockquote className={styles.interviewQuote}>{featuredInterview.quote}</blockquote>
              <Link to={featuredInterview.path} className={styles.featuredLink}>
                Lire l&apos;interview
              </Link>
            </div>
          </div>
        </section>
      )}

      <section className={styles.quoteSection} aria-labelledby="section-quote">
        <div className={styles.quoteContent}>
          <h2 id="section-quote">Citation de la semaine</h2>
          <blockquote>
            « Selon l’ethnologue Claire Besson, la file d’attente devant une boulangerie parisienne révèle la manière
            dont une communauté locale vit son quotidien, du premier café au dîner partagé. »
          </blockquote>
          <p className={styles.quoteSource}>Extrait de la conférence &laquo; Rituels urbains &raquo; (Institut de Paris, 2023)</p>
        </div>
      </section>

      <section className={styles.mapSection} aria-labelledby="section-map">
        <div className={styles.sectionHeader}>
          <h2 id="section-map">Géographie des enquêtes</h2>
          <span className={styles.sectionTag}>Observations par quartiers</span>
        </div>
        <div
          className={styles.mapWrapper}
          role="img"
          aria-label="Carte stylisée de Paris indiquant les quartiers suivis"
        >
          {mapPoints.map((point) => (
            <button
              key={point.name}
              type="button"
              className={styles.mapPoint}
              style={{ top: point.top, left: point.left }}
              onMouseEnter={() => setHoveredDistrict(point.name)}
              onMouseLeave={() => setHoveredDistrict('')}
              onFocus={() => setHoveredDistrict(point.name)}
              onBlur={() => setHoveredDistrict('')}
              aria-label={`Quartier étudié : ${point.name}`}
            />
          ))}
          {hoveredDistrict && <div className={styles.tooltip}>{hoveredDistrict}</div>}
        </div>
        <p className={styles.mapText}>
          Les dossiers de terrain couvrent les arrondissements centraux et périphériques, offrant une vision panoramique
          des pratiques boulangères parisiennes.
        </p>
      </section>

      <section className={styles.newsletterSection} aria-labelledby="section-newsletter">
        <div className={styles.newsletterContent}>
          <h2 id="section-newsletter">Restez informé(e) de nos publications</h2>
          <p>
            La rédaction diffuse un bulletin mensuel recensant études, entretiens et nouvelles immersions de terrain.
            Chaque édition met en perspective les tendances observées dans les fournils parisiens.
          </p>
          <NewsletterForm />
          <p className={styles.newsletterDisclaimer}>
            En envoyant ce formulaire, la personne confirme avoir pris connaissance de la{' '}
            <Link to="/politique-de-confidentialite">politique de confidentialité</Link>.
          </p>
        </div>
      </section>
    </div>
  );
};

const NewsletterForm = () => {
  const [email, setEmail] = useState('');
  const [feedback, setFeedback] = useState('');
  const [status, setStatus] = useState('idle');

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!email.trim() || !/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(email)) {
      setFeedback('Une adresse électronique valide est requise pour recevoir le bulletin.');
      setStatus('error');
      return;
    }
    setStatus('success');
    setFeedback('La demande de suivi éditorial a été enregistrée. La rédaction enverra la prochaine édition au courriel indiqué.');
    setEmail('');
  };

  return (
    <form className={styles.newsletterForm} onSubmit={handleSubmit} noValidate>
      <label htmlFor="newsletter-email" className={styles.newsletterLabel}>
        Adresse électronique
      </label>
      <div className={styles.newsletterControls}>
        <input
          type="email"
          id="newsletter-email"
          name="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="adresse@example.fr"
          className={styles.newsletterInput}
          aria-required="true"
        />
        <button type="submit" className={styles.newsletterButton}>
          S&apos;abonner
        </button>
      </div>
      {feedback && (
        <p className={`${styles.newsletterFeedback} ${status === 'error' ? styles.errorText : styles.successText}`}>
          {feedback}
        </p>
      )}
    </form>
  );
};

export default HomePage;