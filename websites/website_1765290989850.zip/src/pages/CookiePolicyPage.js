import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Politique de cookies | Parisian Bakeries Review</title>
        <meta
          name="description"
          content="Politique d’utilisation des cookies sur Parisian Bakeries Review."
        />
      </Helmet>
      <h1>Politique de cookies</h1>
      <p>
        Cette politique explique l’usage des cookies et traceurs lors de la consultation du site Parisian Bakeries Review.
      </p>
      <section>
        <h2>Cookies strictement nécessaires</h2>
        <p>
          Des cookies techniques garantissent le fonctionnement du site et la mémorisation des préférences de navigation,
          notamment le choix exprimé dans la bannière de consentement.
        </p>
      </section>
      <section>
        <h2>Mesure d’audience</h2>
        <p>
          Des cookies de mesure d’audience anonymisés fournissent des indicateurs statistiques sur la fréquentation des
          contenus. Aucune donnée individuelle n’est partagée avec des partenaires externes.
        </p>
      </section>
      <section>
        <h2>Gestion du consentement</h2>
        <p>
          Le bandeau d’information permet d’accepter, de refuser ou de personnaliser les cookies. Les choix peuvent être
          modifiés à tout moment en effaçant les cookies via le navigateur.
        </p>
      </section>
      <section>
        <h2>Contact</h2>
        <p>
          Pour toute question relative à cette politique, la rédaction peut être contactée à l’adresse
          contact@parisianbakeriesreview.fr.
        </p>
      </section>
    </div>
  );
};

export default CookiePolicyPage;