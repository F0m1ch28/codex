import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isCustomizing, setIsCustomizing] = useState(false);

  useEffect(() => {
    const storedChoice = window.localStorage.getItem('pbr-cookie-choice');
    if (!storedChoice) {
      const timer = setTimeout(() => setIsVisible(true), 800);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleChoice = (choice) => {
    window.localStorage.setItem('pbr-cookie-choice', choice);
    setIsVisible(false);
    setIsCustomizing(false);
  };

  const toggleCustomizing = () => {
    setIsCustomizing((prev) => !prev);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Bannière d'information sur les cookies">
      <div className={styles.content}>
        <p className={styles.text}>
          Ce site utilise des cookies pour améliorer l&apos;expérience de lecture et analyser le trafic anonyme. Consultez la{' '}
          <Link to="/politique-de-cookies" className={styles.link}>
            Politique de cookies
          </Link>
          .
        </p>
        {isCustomizing && (
          <div className={styles.customPanel}>
            <h4 className={styles.customTitle}>Paramétrage</h4>
            <ul className={styles.customList}>
              <li>
                Mesure d&apos;audience anonyme maintenue pour évaluer la consultation des dossiers de recherche.
              </li>
              <li>
                Aucun traceur à vocation publicitaire n&apos;est activé.
              </li>
            </ul>
          </div>
        )}
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.secondaryButton} onClick={toggleCustomizing}>
          Personnaliser
        </button>
        <button type="button" className={styles.secondaryButton} onClick={() => handleChoice('refuse')}>
          Refuser
        </button>
        <button type="button" className={styles.primaryButton} onClick={() => handleChoice('accept')}>
          Accepter
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;