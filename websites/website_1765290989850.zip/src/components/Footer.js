import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.inner}>
        <div className={styles.brand}>
          <span className={styles.brandTitle}>Parisian Bakeries Review</span>
          <p className={styles.brandText}>
            La rédaction documente les ateliers boulangers parisiens et analyse les évolutions d’un patrimoine vivant.
          </p>
        </div>
        <div className={styles.links}>
          <h3 className={styles.columnTitle}>Navigation</h3>
          <nav className={styles.footerNav} aria-label="Navigation secondaire">
            <Link to="/">Accueil</Link>
            <Link to="/articles">Articles</Link>
            <Link to="/interviews">Interviews</Link>
            <Link to="/recherche">Recherche</Link>
            <Link to="/a-propos">À propos</Link>
            <Link to="/contact">Contact</Link>
          </nav>
        </div>
        <div className={styles.contact}>
          <h3 className={styles.columnTitle}>Coordonnées</h3>
          <address className={styles.address}>
            <span>17 Rue du Boulanger</span>
            <span>75005 Paris</span>
            <span>France</span>
            <a href="tel:+33143295412">+33 1 43 29 54 12</a>
            <a href="mailto:contact@parisianbakeriesreview.fr">contact@parisianbakeriesreview.fr</a>
          </address>
        </div>
        <div className={styles.policies}>
          <h3 className={styles.columnTitle}>Informations</h3>
          <Link to="/conditions-generales">Conditions générales</Link>
          <Link to="/politique-de-confidentialite">Politique de confidentialité</Link>
          <Link to="/politique-de-cookies">Politique de cookies</Link>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <span>© {new Date().getFullYear()} Parisian Bakeries Review. Tous droits réservés.</span>
      </div>
    </footer>
  );
};

export default Footer;