import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => {
    setMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <div className={styles.logoGroup}>
          <span className={styles.logoText}>Parisian Bakeries Review</span>
          <span className={styles.tagline}>Revue culturelle et analytique</span>
        </div>
        <button
          type="button"
          className={styles.menuButton}
          onClick={handleToggle}
          aria-expanded={menuOpen}
          aria-controls="navigation-principale"
          aria-label={menuOpen ? 'Fermer le menu de navigation' : 'Ouvrir le menu de navigation'}
        >
          <span className={styles.menuIcon} />
        </button>
        <nav
          id="navigation-principale"
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Navigation principale"
        >
          <NavLink
            to="/"
            className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.activeNav}` : styles.navLink)}
            onClick={closeMenu}
          >
            Accueil
          </NavLink>
          <NavLink
            to="/articles"
            className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.activeNav}` : styles.navLink)}
            onClick={closeMenu}
          >
            Articles
          </NavLink>
          <NavLink
            to="/interviews"
            className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.activeNav}` : styles.navLink)}
            onClick={closeMenu}
          >
            Interviews
          </NavLink>
          <NavLink
            to="/recherche"
            className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.activeNav}` : styles.navLink)}
            onClick={closeMenu}
          >
            Recherche
          </NavLink>
          <NavLink
            to="/a-propos"
            className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.activeNav}` : styles.navLink)}
            onClick={closeMenu}
          >
            À propos
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.activeNav}` : styles.navLink)}
            onClick={closeMenu}
          >
            Contact
          </NavLink>
          <button
            type="button"
            className={styles.languageSwitch}
            aria-label="Langue française activée"
            aria-disabled="true"
            disabled
          >
            FR
          </button>
        </nav>
      </div>
    </header>
  );
};

export default Header;