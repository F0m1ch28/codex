document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".site-nav");
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!expanded).toString());
      nav.classList.toggle("open");
    });
  }

  const scrollBtn = document.getElementById("scrollTopBtn");
  if (scrollBtn) {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 400) {
        scrollBtn.classList.add("visible");
      } else {
        scrollBtn.classList.remove("visible");
      }
    });
    scrollBtn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const cookieAcceptBtn = document.getElementById("cookieAcceptBtn");
  const cookieConsentKey = "sensoriaCookieConsent";
  if (cookieBanner) {
    if (!localStorage.getItem(cookieConsentKey)) {
      cookieBanner.classList.add("visible");
    }
    if (cookieAcceptBtn) {
      cookieAcceptBtn.addEventListener("click", () => {
        localStorage.setItem(cookieConsentKey, "accepted");
        cookieBanner.classList.remove("visible");
      });
    }
  }

  window.history.scrollRestoration = "manual";
  window.scrollTo(0, 0);

  document.querySelectorAll("form.js-form").forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      const feedback = form.querySelector(".form-feedback");
      const successMessage = form.getAttribute("data-success-message") || "Thank you for your message.";
      if (feedback) {
        feedback.textContent = successMessage;
      }
      form.reset();
    });
  });

  const currentYearEl = document.querySelector(".current-year");
  if (currentYearEl) {
    currentYearEl.textContent = new Date().getFullYear();
  }

  const calendarGrid = document.getElementById("calendarGrid");
  const calendarMonth = document.getElementById("calendarMonth");
  if (calendarGrid && calendarMonth) {
    const classData = {
      "2024-06": [
        {
          date: "June 6",
          title: "Market Memory Workshop",
          time: "18:00 – 21:00",
          focus: "Seasonal produce mapping and collaborative meal"
        },
        {
          date: "June 12",
          title: "Fermentation Field Notes",
          time: "17:30 – 20:30",
          focus: "Koji, cedar vinegar, and lactic brines"
        },
        {
          date: "June 22",
          title: "Night Studio: Sensory Plating",
          time: "19:00 – 22:00",
          focus: "Color theory, light studies, and edible installations"
        }
      ],
      "2024-07": [
        {
          date: "July 4",
          title: "Smoke & Citrus Lab",
          time: "18:00 – 21:00",
          focus: "Charred aromatics and preserved citrus applications"
        },
        {
          date: "July 18",
          title: "Tactile Table: Summer Herbs",
          time: "17:00 – 20:00",
          focus: "Hands-on herb studies with tactile prompts"
        },
        {
          date: "July 27",
          title: "Community Sourdough Salon",
          time: "10:00 – 13:00",
          focus: "Wild yeast starters and bread scoring as art"
        }
      ],
      "2024-08": [
        {
          date: "August 8",
          title: "Forest Ferments Intensive",
          time: "18:00 – 21:00",
          focus: "Spruce tip garum and mushroom miso"
        },
        {
          date: "August 17",
          title: "Garden to Glass Mixology",
          time: "16:00 – 19:00",
          focus: "Botanical cocktails and sensory garnish lab"
        },
        {
          date: "August 29",
          title: "Diaspora Spice Residency",
          time: "18:30 – 21:30",
          focus: "Collaborative dinner with guest storyteller"
        }
      ]
    };

    const renderCalendar = month => {
      calendarGrid.innerHTML = "";
      const sessions = classData[month] || [];
      if (!sessions.length) {
        calendarGrid.innerHTML = `<p>No sessions scheduled for this month. Please check back soon.</p>`;
        return;
      }
      sessions.forEach(session => {
        const article = document.createElement("article");
        article.innerHTML = `
          <span>${session.date}</span>
          <h3>${session.title}</h3>
          <p><strong>Time:</strong> ${session.time}</p>
          <p>${session.focus}</p>
          <a class="text-link" href="#bookingForm">Request to join</a>
        `;
        calendarGrid.appendChild(article);
      });
    };

    renderCalendar(calendarMonth.value);
    calendarMonth.addEventListener("change", event => renderCalendar(event.target.value));
  }
});