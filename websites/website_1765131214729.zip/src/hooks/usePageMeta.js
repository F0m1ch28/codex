import { useEffect } from 'react';

const ensureDescriptionTag = () => {
  let descriptionTag = document.querySelector('meta[name="description"]');
  if (!descriptionTag) {
    descriptionTag = document.createElement('meta');
    descriptionTag.setAttribute('name', 'description');
    document.head.appendChild(descriptionTag);
  }
  return descriptionTag;
};

const usePageMeta = (title, description) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    if (description) {
      const descriptionTag = ensureDescriptionTag();
      descriptionTag.setAttribute('content', description);
    }
  }, [title, description]);
};

export default usePageMeta;