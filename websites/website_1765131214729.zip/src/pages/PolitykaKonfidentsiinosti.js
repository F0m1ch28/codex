import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './PolitykaKonfidentsiinosti.module.css';

const PolitykaKonfidentsiinosti = () => {
  usePageMeta(
    'Політика конфіденційності — AlphaShepherd Pro Training',
    'Дізнайтеся, як AlphaShepherd Pro Training обробляє персональні дані користувачів сайту.'
  );

  return (
    <div className={styles.page}>
      <div className="container">
        <h1>Політика конфіденційності</h1>
        <p>Останнє оновлення: 10 березня 2024 року</p>

        <section>
          <h2>1. Обробка даних</h2>
          <p>Ми обробляємо персональні дані лише для відповіді на запити клієнтів та організації тренувань. Дані не передаються третім особам без вашої згоди.</p>
        </section>

        <section>
          <h2>2. Форма зворотного зв’язку</h2>
          <p>При надсиланні форми ви вказуєте ім’я, email та місто. Ця інформація використовується для комунікації щодо послуг.</p>
        </section>

        <section>
          <h2>3. Права користувачів</h2>
          <p>Ви маєте право запитувати доступ, змінювати або видаляти свої дані. Зв’яжіться з нами через електронну адресу для реалізації права.</p>
        </section>

        <section>
          <h2>4. Захист інформації</h2>
          <p>Ми застосовуємо технічні та організаційні заходи для захисту даних від несанкціонованого доступу.</p>
        </section>
      </div>
    </div>
  );
};

export default PolitykaKonfidentsiinosti;