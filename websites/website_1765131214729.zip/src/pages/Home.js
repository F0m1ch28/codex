import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Home.module.css';

const statsData = [
  { label: 'років досвіду роботи з вівчарками', target: 12 },
  { label: 'успішних командних програм', target: 260 },
  { label: 'кінологічних семінарів у Польщі', target: 38 },
  { label: 'позитивних відгуків власників', target: 310 }
];

const servicesData = [
  {
    title: 'Базове послухання',
    description: 'Програма для формування стабільних навичок слухняності, належної поведінки вдома та у місті.',
    icon: '🎯'
  },
  {
    title: 'Поглиблена робота з драйвом',
    description: 'Контроль енергії та інстинктів вівчарки, мотиваційні тренування, відпрацювання складних команд.',
    icon: '⚡'
  },
  {
    title: 'Соціалізація та безпека',
    description: 'Знайомство з міськими подразниками, робота з дітьми та іншими тваринами, безпечний контакт із середовищем.',
    icon: '🤝'
  }
];

const processSteps = [
  { title: 'Глибинна діагностика', text: 'Аналіз характеру, рівня послуху та потреб німецької вівчарки під час стартової консультації.' },
  { title: 'Індивідуальний план', text: 'Розробка персональної програми тренувань з чіткими етапами розвитку та контрольними точками.' },
  { title: 'Польові тренування', text: 'Регулярні заняття у місті та на спеціальних майданчиках у Варшаві й Кракові, відпрацювання команд у реальних умовах.' },
  { title: 'Підтримка власника', text: 'Настанови для родини, відео-розбори домашніх завдань, адаптація плану під динаміку собаки.' }
];

const testimonialsData = [
  {
    name: 'Олег, Варшава',
    text: 'Після співпраці з AlphaShepherd наш Рекс зупинився тягнути повідець і навчився чекати команди навіть у найжвавіших місцях. Тренер дає чіткі інструкції та ділиться реальними кейсами.',
    role: 'Власник 2-річної німецької вівчарки'
  },
  {
    name: 'Марія, Краків',
    text: 'Ми шукали кінолога, який розуміє робочі якості породи. Програма з контролю драйву допомогла перенаправити енергію нашої вівчарки у кросфіт-активності та пошукові ігри.',
    role: 'Власниця молодої суки GSD'
  },
  {
    name: 'Анна, Варшава',
    text: 'Команда навчила мене працювати з голосом та жестами. Тепер моя собака безпечно поводиться поруч із дітьми і спокійно реагує на велосипедистів.',
    role: 'Мати двох дітей, власниця 4-річної вівчарки'
  }
];

const teamData = [
  {
    name: 'Артем Левандовський',
    role: 'Головний кінолог, спеціаліст із службових порід',
    bio: '12 років практики у дресируванні вівчарок, сертифікований тренер Польської кінологічної федерації.',
    image: 'https://picsum.photos/seed/team-alshepherd-1/400/400'
  },
  {
    name: 'Ірина Ковальська',
    role: 'Спеціалістка з поведінки та реабілітації',
    bio: 'Психолог тварин, дипломована консультантка з корекції поведінки собак у міському середовищі.',
    image: 'https://picsum.photos/seed/team-alshepherd-2/400/400'
  }
];

const projectsData = [
  {
    title: 'Випуск програми «Контроль драйву»',
    category: 'Поглиблена підготовка',
    description: 'Побудова надійного контакту та робота із самоконтролем для молодого кобеля з ліній захисту.',
    image: 'https://picsum.photos/seed/alphaproject-1/1200/800'
  },
  {
    title: 'Соціалізація у міському середовищі',
    category: 'Соціалізація',
    description: 'Тренування біля транспорту та торгових центрів, робота з відволікаючими факторами та акцент на безпеці.',
    image: 'https://picsum.photos/seed/alphaproject-2/1200/800'
  },
  {
    title: 'Програма «Сімейна гармонія»',
    category: 'Послухання',
    description: 'Побудова безпечної взаємодії з дітьми та гостями, регуляція емоційних реакцій.',
    image: 'https://picsum.photos/seed/alphaproject-3/1200/800'
  }
];

const blogData = [
  {
    title: '5 ключових акцентів у роботі з німецькою вівчаркою в місті',
    excerpt: 'Розглядаємо специфіку адаптації вівчарки до урбаністичного ритму Варшави та Кракова.',
    image: 'https://picsum.photos/seed/alphablog-1/800/600',
    link: '/posluhy'
  },
  {
    title: 'Як зберегти фокус собаки під час тренування',
    excerpt: 'Пояснюємо техніки мотивації та баланс між енергією і концентрацією.',
    image: 'https://picsum.photos/seed/alphablog-2/800/600',
    link: '/dlya-nimetskykh-vivcharok'
  },
  {
    title: 'Соціалізація з раннього віку: чек-лист для власника',
    excerpt: 'Перевірені сценарії та вправи для гармонійної поведінки у публічних просторах.',
    image: 'https://picsum.photos/seed/alphablog-3/800/600',
    link: '/pro-nas'
  }
];

const faqData = [
  {
    question: 'Як розпочати тренування з вашою командою?',
    answer: 'Залиште заявку у розділі «Контакти» або зателефонуйте. Ми призначимо діагностичну зустріч у Варшаві чи Кракові, щоб оцінити потреби вашої вівчарки та запропонувати індивідуальний план.'
  },
  {
    question: 'Яка тривалість одного тренування?',
    answer: 'Стандартне заняття триває 60–75 хвилин, залежно від поточних завдань, фізичного стану собаки та погодних умов. Частину вправ власник отримує для самостійного відпрацювання між сесіями.'
  },
  {
    question: 'Чи працюєте ви з проблемною поведінкою?',
    answer: 'Так, наші програми охоплюють корекцію надмірної збудливості, роботу з реактивністю, страхами та фіксацію на подразниках. Ми поєднуємо кінологічні та поведінкові підходи.'
  }
];

const Home = () => {
  usePageMeta(
    'AlphaShepherd Pro Training — Дресирування німецьких вівчарок у Варшаві та Кракові',
    'Професійне дресирування німецьких вівчарок: послухання, корекція поведінки, індивідуальні програми у Варшаві та Кракові. Команда AlphaShepherd Pro Training.'
  );

  const [statValues, setStatValues] = useState(statsData.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Усе');
  const [openFaq, setOpenFaq] = useState(null);

  const filters = useMemo(() => ['Усе', 'Послухання', 'Поглиблена підготовка', 'Соціалізація'], []);

  useEffect(() => {
    const timers = statsData.map((stat, index) => {
      const duration = 1600;
      const frameRate = 60;
      const totalFrames = Math.round((duration / 1000) * frameRate);
      let frame = 0;

      return setInterval(() => {
        frame += 1;
        setStatValues((prev) => {
          const next = [...prev];
          next[index] = Math.min(stat.target, Math.round((stat.target * frame) / totalFrames));
          return next;
        });
        if (frame >= totalFrames) {
          clearInterval(timers[index]);
        }
      }, 1000 / frameRate);
    });

    return () => {
      timers.forEach((timer) => clearInterval(timer));
    };
  }, []);

  useEffect(() => {
    const autoSlide = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonialsData.length);
    }, 7000);
    return () => clearInterval(autoSlide);
  }, []);

  const visibleProjects = useMemo(() => {
    if (projectFilter === 'Усе') return projectsData;
    return projectsData.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  return (
    <div className={styles.page}>
      <section className={styles.hero} aria-labelledby="hero-title">
        <div className={`container ${styles.heroContent}`}>
          <div>
            <p className={styles.heroEyebrow}>Професійне дресирування німецьких вівчарок</p>
            <h1 id="hero-title" className={styles.heroTitle}>
              Побудуйте надійний союз зі своєю вівчаркою разом із AlphaShepherd Pro Training
            </h1>
            <p className={styles.heroSubtitle}>
              Індивідуальні програми послуху, роботи з драйвом та соціалізації у Варшаві та Кракові. Ми знаємо, як поєднати природні інстинкти німецьких вівчарок із вимогами міського життя.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className="btn btnPrimary" aria-label="Записатися на консультацію з тренером">
                Записатися на консультацію
              </Link>
              <Link to="/dlya-nimetskykh-vivcharok" className="btn btnSecondary">
                Підхід до GSD
              </Link>
            </div>
            <div className={styles.heroDetails}>
              <span>• Варшава</span>
              <span>• Краків</span>
              <span>• Виїзні та польові тренування</span>
            </div>
          </div>
          <div className={styles.heroCard} aria-hidden="true">
            <p className={styles.heroCardTitle}>Результат = довіра + чіткість</p>
            <p className={styles.heroCardText}>
              Наші програми адаптовані до робочого характеру вівчарок: ми контролюємо драйв, підсилюємо мотивацію та розвиваємо самоконтроль без стресу для собаки.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Статистика команди">
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard}>
                <p className={styles.statValue}>{statValues[index]}+</p>
                <p className={styles.statLabel}>{stat.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.servicesSection} id="services">
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Наші ключові напрямки</p>
            <h2>Збалансовані програми навчання та підтримка власника</h2>
            <p>
              Ми формуємо план тренувань навколо життєвих цілей власника та темпераменту вівчарки. Кожний блок має вимірювані результати та супровід тренера між заняттями.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <span className={styles.serviceIcon} aria-hidden="true">{service.icon}</span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link className={styles.serviceLink} to="/posluhy">Дізнатися більше →</Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.specialSection} aria-labelledby="special-title">
        <div className="container">
          <div className={styles.specialContent}>
            <div>
              <p className={styles.sectionEyebrow}>Глибинна спеціалізація</p>
              <h2 id="special-title">Німецька вівчарка — собака з великим потенціалом</h2>
              <p>
                Наша команда знає стандарти робочих ліній і м’яко веде собаку від базового послуху до розширених сценаріїв: пошук предметів, охорона території, злагоджена взаємодія в сім’ї.
              </p>
              <ul className={styles.specialList}>
                <li>Контроль драйву без втрати мотивації</li>
                <li>Впевнене виконання команд у публічних місцях</li>
                <li>Налагодження контакту з власником і членами родини</li>
                <li>Підготовка до виступів і сертифікації</li>
              </ul>
              <Link to="/dlya-nimetskykh-vivcharok" className="btn btnPrimary">
                Наш підхід до породи
              </Link>
            </div>
            <div className={styles.specialImageWrapper} aria-hidden="true">
              <div className={styles.specialImage} role="presentation"></div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Як ми працюємо</p>
            <h2>Чотири кроки до гармонійної взаємодії</h2>
            <p>Ви завжди розумієте, які навички відпрацьовуємо, як виконувати домашні завдання та коли очікувати результат.</p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processCard}>
                <span className={styles.processNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection} aria-label="Відгуки клієнтів">
        <div className="container">
          <div className={styles.testimonialsHeader}>
            <p className={styles.sectionEyebrow}>Довіра власників</p>
            <h2>Відгуки клієнтів з Варшави та Кракова</h2>
          </div>
          <div className={styles.testimonialCard}>
            <p className={styles.testimonialText}>
              “{testimonialsData[testimonialIndex].text}”
            </p>
            <div className={styles.testimonialFooter}>
              <div>
                <p className={styles.testimonialName}>{testimonialsData[testimonialIndex].name}</p>
                <p className={styles.testimonialRole}>{testimonialsData[testimonialIndex].role}</p>
              </div>
              <div className={styles.testimonialControls}>
                <button
                  type="button"
                  onClick={() =>
                    setTestimonialIndex((prev) => (prev === 0 ? testimonialsData.length - 1 : prev - 1))
                  }
                  aria-label="Попередній відгук"
                >
                  ←
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setTestimonialIndex((prev) => (prev + 1) % testimonialsData.length)
                  }
                  aria-label="Наступний відгук"
                >
                  →
                </button>
              </div>
            </div>
          </div>
          <div className={styles.testimonialDots}>
            {testimonialsData.map((_, index) => (
              <button
                key={`dot-${index}`}
                type="button"
                aria-label={`Показати відгук ${index + 1}`}
                className={`${styles.dot} ${index === testimonialIndex ? styles.dotActive : ''}`}
                onClick={() => setTestimonialIndex(index)}
              ></button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.teamSection} aria-labelledby="team-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Команда</p>
            <h2 id="team-title">Ваші наставники у роботі з вівчаркою</h2>
            <p>Ми поєднуємо знання кінології, жорстких стандартів і любов до собак. Вчимо через конкретні рішення та підтримку.</p>
          </div>
          <div className={styles.teamGrid}>
            {teamData.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={`${member.name} — ${member.role}`} loading="lazy" />
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection} aria-labelledby="projects-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Кейси</p>
            <h2 id="projects-title">Приклади наших тренувальних програм</h2>
            <p>Кожний кейс — це індивідуальний план, адаптований до темпераменту та умов життя собаки.</p>
          </div>
          <div className={styles.filters}>
            {filters.map((filter) => (
              <button
                key={filter}
                type="button"
                className={`${styles.filterButton} ${projectFilter === filter ? styles.filterActive : ''}`}
                onClick={() => setProjectFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {visibleProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img src={project.image} alt={`${project.title} — ${project.category}`} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <p className={styles.projectCategory}>{project.category}</p>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection} aria-labelledby="faq-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>FAQ</p>
            <h2 id="faq-title">Поширені запитання</h2>
            <p>Ми зібрали відповіді на ключові запитання про підготовку німецьких вівчарок у містах Польщі.</p>
          </div>
          <div className={styles.accordion}>
            {faqData.map((item, index) => {
              const isOpen = openFaq === index;
              return (
                <div key={item.question} className={`${styles.accordionItem} ${isOpen ? styles.accordionOpen : ''}`}>
                  <button
                    type="button"
                    className={styles.accordionTrigger}
                    aria-expanded={isOpen}
                    onClick={() => setOpenFaq(isOpen ? null : index)}
                  >
                    <span>{item.question}</span>
                    <span aria-hidden="true">{isOpen ? '−' : '+'}</span>
                  </button>
                  {isOpen && (
                    <div className={styles.accordionContent}>
                      <p>{item.answer}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.blogSection} aria-labelledby="blog-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <p className={styles.sectionEyebrow}>Блог та інсайти</p>
            <h2 id="blog-title">Практичні матеріали для власників вівчарок</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogData.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImageWrapper}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.blogContent}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.blogLink}>Читати →</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection} id="contact">
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <p className={styles.sectionEyebrow}>Готові до нового рівня взаємодії?</p>
              <h2>Заплануйте стартову консультацію</h2>
              <p>Ми проаналізуємо потреби вашої вівчарки, підберемо формат занять у Варшаві або Кракові та визначимо перші кроки програми.</p>
            </div>
            <div className={styles.ctaActions}>
              <a className="btn btnPrimary" href="tel:+48123456789">Зателефонувати</a>
              <Link className="btn btnSecondary" to="/kontakty">Написати тренеру</Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;