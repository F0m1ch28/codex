import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './About.module.css';

const About = () => {
  usePageMeta(
    'Про AlphaShepherd Pro Training — команда кінологів у Варшаві та Кракові',
    'Дізнайтесь про команду AlphaShepherd Pro Training: цінності, методики, досвід тренерів з дресирування німецьких вівчарок у Польщі.'
  );

  return (
    <div className={styles.page}>
      <section className={styles.intro}>
        <div className="container">
          <p className={styles.eyebrow}>Про нас</p>
          <h1>AlphaShepherd Pro Training — команда, що говорить мовою німецьких вівчарок</h1>
          <p className={styles.subtitle}>
            Ми віримо, що партнерство людини та собаки вибудовується на взаємній довірі та послідовній роботі.
            Кожен наш тренер має глибоку практику з робочими лініями вівчарок та міжнародними стандартами підготовки.
          </p>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <div className={styles.valuesGrid}>
            <article>
              <h2>Філософія</h2>
              <p>
                Ми не пропонуємо готових шаблонів. Кожна програма створюється після діагностики поведінки собаки,
                обговорення умов життя та очікувань власника. Баланс між інстинктами та дисципліною — наш головний принцип.
              </p>
            </article>
            <article>
              <h2>Методика</h2>
              <p>
                Працюємо з позитивним підкріпленням, мотиваційними іграми, біомеханікою рухів та управлінням драйвом.
                Власник отримує зрозумілий план, відео-розбори та підтримку у впровадженні нових звичок.
              </p>
            </article>
            <article>
              <h2>Команда</h2>
              <p>
                Тренери AlphaShepherd — сертифіковані спеціалісти Польської кінологічної федерації, учасники профільних семінарів у Європі,
                ментори молодих кінологів. Ми навчаємо, як відчувати собаку, а не просто виконувати команди.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.timeline} aria-labelledby="timeline-title">
        <div className="container">
          <h2 id="timeline-title">Шлях команди</h2>
          <div className={styles.timelineGrid}>
            <article>
              <span className={styles.year}>2012</span>
              <h3>Перші виїзні тренування</h3>
              <p>Старт програми персональних занять з німецькими вівчарками у Варшаві та околицях.</p>
            </article>
            <article>
              <span className={styles.year}>2017</span>
              <h3>Інтенсиви та семінари</h3>
              <p>Запуск групових інтенсивів, співпраця з кінологічними клубами Кракова, організація майстер-класів.</p>
            </article>
            <article>
              <span className={styles.year}>2020</span>
              <h3>Онлайн супровід</h3>
              <p>Створення дистанційної підтримки для власників, відео-розбори занять і домашніх завдань.</p>
            </article>
            <article>
              <span className={styles.year}>2023</span>
              <h3>AlphaShepherd Pro Training</h3>
              <p>Оновлена програма з акцентом на міську адаптацію, роботу з драйвом і родинну гармонію.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.approach}>
        <div className="container">
          <div className={styles.approachContent}>
            <div>
              <h2>Що нас відрізняє</h2>
              <ul className={styles.list}>
                <li>Працюємо виключно з німецькими вівчарками та їх міксами</li>
                <li>Поєднуємо кінологію, поведінкову науку та фізичну підготовку</li>
                <li>Даємо власнику інструменти для самостійної підтримки результату</li>
                <li>Підтримуємо контакт навіть після завершення основного курсу</li>
              </ul>
            </div>
            <div className={styles.quoteBox}>
              <p>
                “Наша ціль — щоб кожна вівчарка відчувала себе впевнено та слухняно у будь-якій ситуації,
                а власник розумів, як керувати поведінкою без стресу та конфліктів.”
              </p>
              <p className={styles.quoteAuthor}>Артем Левандовський, засновник AlphaShepherd Pro Training</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;