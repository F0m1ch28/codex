import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './DlyaNimetskykhVivcharok.module.css';

const DlyaNimetskykhVivcharok = () => {
  usePageMeta(
    'Підхід до німецьких вівчарок — AlphaShepherd Pro Training',
    'AlphaShepherd Pro Training спеціалізується на німецьких вівчарках: контроль драйву, соціалізація, програми для робочих і сімейних собак у Варшаві та Кракові.'
  );

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Чому ми фокусуємося на німецьких вівчарках</h1>
          <p>
            Німецька вівчарка — собака з високим інтелектом, драйвом і потребою у чітких правилах.
            Наш досвід дозволяє працювати з різними лініями: робочими, виставковими та сімейними.
          </p>
        </div>
      </section>

      <section className={styles.traits}>
        <div className="container">
          <div className={styles.grid}>
            <article>
              <h2>Темперамент та нервова система</h2>
              <p>
                Ми оцінюємо рівень збудження, тягу до роботи, чутливість та реактивність. Це дозволяє підібрати правильний баланс між іграми, навантаженнями та відпочинком.
              </p>
            </article>
            <article>
              <h2>Фізична підготовка</h2>
              <p>
                Працюємо з біомеханікою руху, вправами на баланс і силу, щоб знизити ризик травм та зберегти здоров’я суглобів при активних тренуваннях.
              </p>
            </article>
            <article>
              <h2>Ментальні виклики</h2>
              <p>
                Розвиваємо здатність переключатися між роботами, довіряти власнику та виконувати завдання у складних умовах міста чи охоронної служби.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.focus}>
        <div className="container">
          <div className={styles.focusContent}>
            <h2>Що отримує власник</h2>
            <ul>
              <li>Індивідуальні сценарії тренувань з урахуванням конкретних завдань</li>
              <li>Глибоке розуміння сигналів собаки та алгоритми реагування</li>
              <li>План розвитку на 3–6 місяців із контрольними точками</li>
              <li>Постійний зворотний зв’язок та корекція поведінки</li>
            </ul>
          </div>
          <div className={styles.focusNote}>
            <p>
              Ми співпрацюємо з ветлікарями-ортопедами, кінологічними клубами та тренерами з nosework, щоб забезпечити всебічний розвиток вівчарки.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DlyaNimetskykhVivcharok;