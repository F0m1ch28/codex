import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Kontakty.module.css';

const Kontakty = () => {
  usePageMeta(
    'Контакти AlphaShepherd Pro Training — Варшава та Краків',
    'Зв’яжіться з AlphaShepherd Pro Training: телефон +48 123 456 789, email trener@sobaka-training.pl. Запис на дресирування німецьких вівчарок у Варшаві та Кракові.'
  );

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    city: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Вкажіть ваше ім’я.';
    if (!formData.email.trim()) newErrors.email = 'Вкажіть електронну пошту.';
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Перевірте формат email.';
    if (!formData.city.trim()) newErrors.city = 'Оберіть місто або регіон.';
    if (!formData.message.trim()) newErrors.message = 'Опишіть коротко ситуацію.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setSubmitted(true);
    setFormData({ name: '', email: '', city: '', message: '' });
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Зв’яжіться з нашою командою</h1>
          <p>
            Розкажіть нам про вашу вівчарку та очікування від тренувань. Ми відповімо протягом 24 годин і запропонуємо формат першої зустрічі.
          </p>
        </div>
      </section>

      <section className={styles.grid}>
        <div className="container">
          <div className={styles.layout}>
            <div className={styles.contactInfo}>
              <h2>Контактні дані</h2>
              <ul>
                <li><strong>Телефон:</strong> <a href="tel:+48123456789">+48 123 456 789</a></li>
                <li><strong>Email:</strong> <a href="mailto:trener@sobaka-training.pl">trener@sobaka-training.pl</a></li>
                <li><strong>Локації:</strong> Варшава, Краків та околиці</li>
                <li><strong>Формат:</strong> Виїзні заняття, польові тренування, гібридний супровід</li>
              </ul>
              <div className={styles.infoCard}>
                <h3>Робочий час</h3>
                <p>Пн–Сб: 08:00–20:00<br />Нд: за попереднім записом</p>
                <p className={styles.note}>У термінових випадках щодо безпеки собаки — телефонуйте у будь-який час.</p>
              </div>
            </div>

            <div className={styles.formWrapper}>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <div className={styles.formGroup}>
                  <label htmlFor="name">Ім’я</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    aria-invalid={!!errors.name}
                    aria-describedby={errors.name ? 'name-error' : undefined}
                    placeholder="Ваше ім’я"
                  />
                  {errors.name && <span id="name-error" className={styles.error}>{errors.name}</span>}
                </div>

                <div className={styles.formGroup}>
                  <label htmlFor="email">Електронна пошта</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    aria-invalid={!!errors.email}
                    aria-describedby={errors.email ? 'email-error' : undefined}
                    placeholder="name@email.com"
                  />
                  {errors.email && <span id="email-error" className={styles.error}>{errors.email}</span>}
                </div>

                <div className={styles.formGroup}>
                  <label htmlFor="city">Місто / район</label>
                  <input
                    id="city"
                    name="city"
                    type="text"
                    value={formData.city}
                    onChange={handleChange}
                    aria-invalid={!!errors.city}
                    aria-describedby={errors.city ? 'city-error' : undefined}
                    placeholder="Варшава, Краків або інше"
                  />
                  {errors.city && <span id="city-error" className={styles.error}>{errors.city}</span>}
                </div>

                <div className={styles.formGroup}>
                  <label htmlFor="message">Опишіть ситуацію</label>
                  <textarea
                    id="message"
                    name="message"
                    rows="4"
                    value={formData.message}
                    onChange={handleChange}
                    aria-invalid={!!errors.message}
                    aria-describedby={errors.message ? 'message-error' : undefined}
                    placeholder="Розкажіть про собаку, вік, ціль тренувань або виклики"
                  ></textarea>
                  {errors.message && <span id="message-error" className={styles.error}>{errors.message}</span>}
                </div>

                <button type="submit" className="btn btnPrimary">Надіслати заявку</button>

                {submitted && (
                  <div className={styles.success} role="status">
                    Дякуємо! Ми отримали вашу заявку та зв’яжемося найближчим часом.
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Kontakty;