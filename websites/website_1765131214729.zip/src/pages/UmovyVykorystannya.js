import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './UmovyVykorystannya.module.css';

const UmovyVykorystannya = () => {
  usePageMeta(
    'Умови використання — AlphaShepherd Pro Training',
    'Ознайомтеся з умовами використання вебсайту AlphaShepherd Pro Training.'
  );

  return (
    <div className={styles.page}>
      <div className="container">
        <h1>Умови використання</h1>
        <p>Останнє оновлення: 10 березня 2024 року</p>

        <section>
          <h2>1. Загальні положення</h2>
          <p>Цей вебсайт належить та керується командою AlphaShepherd Pro Training. Користуючись сайтом, ви погоджуєтесь дотримуватися цих умов.</p>
        </section>

        <section>
          <h2>2. Контент та інформація</h2>
          <p>Матеріали на сайті мають ознайомчий характер. Ми прагнемо актуальності інформації, але не гарантуємо її абсолютну повноту.</p>
        </section>

        <section>
          <h2>3. Відповідальність користувача</h2>
          <p>Ви зобов’язані використовувати сайт у відповідності до законодавства та не здійснювати дій, що можуть порушити роботу ресурсу.</p>
        </section>

        <section>
          <h2>4. Зміни умов</h2>
          <p>Ми можемо оновлювати ці умови. Про суттєві зміни повідомлятимемо на сторінці.</p>
        </section>

        <section>
          <h2>5. Контакти</h2>
          <p>З питаннями щодо умов використання звертайтеся на електронну адресу <a href="mailto:trener@sobaka-training.pl">trener@sobaka-training.pl</a>.</p>
        </section>
      </div>
    </div>
  );
};

export default UmovyVykorystannya;