import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './PolitykaCookie.module.css';

const PolitykaCookie = () => {
  usePageMeta(
    'Політика щодо файлів cookie — AlphaShepherd Pro Training',
    'Політика використання файлів cookie на сайті AlphaShepherd Pro Training.'
  );

  return (
    <div className={styles.page}>
      <div className="container">
        <h1>Політика щодо файлів cookie</h1>
        <p>Останнє оновлення: 10 березня 2024 року</p>

        <section>
          <h2>Що таке cookie?</h2>
          <p>Cookie — це невеликі файли, які зберігаються на вашому пристрої та допомагають нам покращувати роботу сайту.</p>
        </section>

        <section>
          <h2>Які cookie ми використовуємо?</h2>
          <ul>
            <li>Обов’язкові cookie — необхідні для базових функцій сайту.</li>
            <li>Аналітичні cookie — допомагають розуміти, як відвідувачі користуються сайтом.</li>
          </ul>
        </section>

        <section>
          <h2>Керування cookie</h2>
          <p>Ви можете змінити налаштування cookie у своєму браузері. Продовжуючи користування сайтом, ви погоджуєтесь із цією політикою.</p>
        </section>
      </div>
    </div>
  );
};

export default PolitykaCookie;