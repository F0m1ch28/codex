import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (menuOpen) {
      document.body.classList.add('no-scroll');
    } else {
      document.body.classList.remove('no-scroll');
    }
  }, [menuOpen]);

  return (
    <header className={styles.header} role="banner">
      <div className={`container ${styles.inner}`}>
        <NavLink to="/" className={styles.logoLink} aria-label="AlphaShepherd Pro Training - на головну">
          <img src={`${process.env.PUBLIC_URL}/images/logo.svg`} alt="Логотип AlphaShepherd Pro Training" className={styles.logo} />
          <span className={styles.brandText}>AlphaShepherd Pro Training</span>
        </NavLink>

        <button
          className={styles.menuToggle}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Перемикач головного меню"
        >
          <span className={styles.menuBar}></span>
          <span className={styles.menuBar}></span>
          <span className={styles.menuBar}></span>
        </button>

        <nav
          id="primary-navigation"
          className={`${styles.nav} ${menuOpen ? styles.open : ''}`}
          aria-label="Головна навігація"
        >
          <NavLink className={({ isActive }) => isActive ? `${styles.navLink} ${styles.active}` : styles.navLink} to="/">Головна</NavLink>
          <NavLink className={({ isActive }) => isActive ? `${styles.navLink} ${styles.active}` : styles.navLink} to="/pro-nas">Про нас</NavLink>
          <NavLink className={({ isActive }) => isActive ? `${styles.navLink} ${styles.active}` : styles.navLink} to="/posluhy">Послуги</NavLink>
          <NavLink className={({ isActive }) => isActive ? `${styles.navLink} ${styles.active}` : styles.navLink} to="/dlya-nimetskykh-vivcharok">Для німецьких вівчарок</NavLink>
          <NavLink className={({ isActive }) => isActive ? `${styles.navLink} ${styles.active}` : styles.navLink} to="/heohrafiya">Географія роботи</NavLink>
          <NavLink className={({ isActive }) => isActive ? `${styles.navLink} ${styles.active}` : styles.navLink} to="/kontakty">Контакти</NavLink>
          <NavLink className={({ isActive }) => isActive ? `${styles.ctaLink} ${styles.active}` : styles.ctaLink} to="/kontakty">
            Записатися
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;