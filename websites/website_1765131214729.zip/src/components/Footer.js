import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={`container ${styles.inner}`}>
        <div className={styles.brand}>
          <img
            src={`${process.env.PUBLIC_URL}/images/logo.svg`}
            alt="AlphaShepherd Pro Training логотип у футері"
            className={styles.logo}
          />
          <p className={styles.description}>
            AlphaShepherd Pro Training — команда професійних кінологів у Варшаві та Кракові. Ми допомагаємо власникам
            німецьких вівчарок розкрити потенціал улюбленця та налагодити надійне партнерство людини й собаки.
          </p>
          <div className={styles.contacts}>
            <a className={styles.contactLink} href="tel:+48123456789">+48 123 456 789</a>
            <a className={styles.contactLink} href="mailto:trener@sobaka-training.pl">trener@sobaka-training.pl</a>
            <p className={styles.address}>Послуги на виїзді у Варшаві та Кракові</p>
          </div>
        </div>

        <div className={styles.links}>
          <h3 className={styles.heading}>Сторінки</h3>
          <ul className={styles.linkList}>
            <li><NavLink className={styles.link} to="/">Головна</NavLink></li>
            <li><NavLink className={styles.link} to="/pro-nas">Про нас</NavLink></li>
            <li><NavLink className={styles.link} to="/posluhy">Послуги</NavLink></li>
            <li><NavLink className={styles.link} to="/dlya-nimetskykh-vivcharok">Для німецьких вівчарок</NavLink></li>
            <li><NavLink className={styles.link} to="/heohrafiya">Географія роботи</NavLink></li>
            <li><NavLink className={styles.link} to="/kontakty">Контакти</NavLink></li>
          </ul>
        </div>

        <div className={styles.policy}>
          <h3 className={styles.heading}>Правова інформація</h3>
          <ul className={styles.linkList}>
            <li><NavLink className={styles.link} to="/umovy-vykorystannya">Умови використання</NavLink></li>
            <li><NavLink className={styles.link} to="/polityka-konfidentsiinosti">Політика конфіденційності</NavLink></li>
            <li><NavLink className={styles.link} to="/polityka-cookie">Політика щодо файлів cookie</NavLink></li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} AlphaShepherd Pro Training. Усі права захищені.</p>
      </div>
    </footer>
  );
};

export default Footer;