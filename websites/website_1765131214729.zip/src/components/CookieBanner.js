import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const COOKIE_STORAGE_KEY = 'alphashepherd_cookie_acceptance';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(COOKIE_STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.message}>
        Ми використовуємо файли cookie для безпечної роботи сайту та аналізу взаємодії. Продовжуючи користування, ви погоджуєтесь із нашою&nbsp;
        <Link className={styles.link} to="/polityka-cookie">політикою щодо cookie</Link>.
      </p>
      <button className={styles.button} type="button" onClick={handleAccept} aria-label="Погодитися з використанням cookie">
        Добре
      </button>
    </div>
  );
};

export default CookieBanner;