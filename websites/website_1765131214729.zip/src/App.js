import React, { useEffect } from 'react';
import { Routes, Route, useLocation, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';

import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import DlyaNimetskykhVivcharok from './pages/DlyaNimetskykhVivcharok';
import Heohrafiya from './pages/Heohrafiya';
import Kontakty from './pages/Kontakty';
import UmovyVykorystannya from './pages/UmovyVykorystannya';
import PolitykaKonfidentsiinosti from './pages/PolitykaKonfidentsiinosti';
import PolitykaCookie from './pages/PolitykaCookie';

const App = () => {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }, [location.pathname]);

  return (
    <>
      <Header />
      <main id="main-content" className="appMain" tabIndex="-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/pro-nas" element={<About />} />
          <Route path="/posluhy" element={<Services />} />
          <Route path="/dlya-nimetskykh-vivcharok" element={<DlyaNimetskykhVivcharok />} />
          <Route path="/heohrafiya" element={<Heohrafiya />} />
          <Route path="/kontakty" element={<Kontakty />} />
          <Route path="/umovy-vykorystannya" element={<UmovyVykorystannya />} />
          <Route path="/polityka-konfidentsiinosti" element={<PolitykaKonfidentsiinosti />} />
          <Route path="/polityka-cookie" element={<PolitykaCookie />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </>
  );
};

export default App;