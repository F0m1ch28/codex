document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = siteNav ? siteNav.querySelectorAll('a') : [];
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-btn[data-cookie-action]');
    const consentKey = 'mortifcavr_cookie_consent';

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            siteNav.classList.toggle('open');
        });

        navLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.innerWidth < 1024) {
                    siteNav.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    function showCookieBanner() {
        if (cookieBanner && !localStorage.getItem(consentKey)) {
            cookieBanner.classList.add('show');
        }
    }

    function handleCookiePreference(action) {
        localStorage.setItem(consentKey, action);
        if (cookieBanner) {
            cookieBanner.classList.remove('show');
        }
    }

    if (cookieButtons && cookieButtons.length > 0) {
        cookieButtons.forEach(function (btn) {
            btn.addEventListener('click', function (event) {
                event.preventDefault();
                const action = btn.getAttribute('data-cookie-action');
                handleCookiePreference(action);
                window.location.href = btn.getAttribute('href');
            });
        });
    }

    showCookieBanner();
});