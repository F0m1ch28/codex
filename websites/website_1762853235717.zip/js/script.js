document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.getElementById("navToggle");
    const nav = document.getElementById("primaryNavigation");
    const scrollBtn = document.getElementById("scrollTopBtn");
    const cookieBanner = document.getElementById("cookieBanner");
    const acceptCookiesBtn = document.getElementById("acceptCookies");
    const currentYearSpan = document.getElementById("currentYear");
    const contactForm = document.getElementById("contactForm");
    const contactResponse = document.getElementById("contactResponse");
    const newsletterForm = document.getElementById("newsletterForm");
    const newsletterResponse = document.getElementById("newsletterResponse");

    if (navToggle && nav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", !expanded);
            nav.classList.toggle("open");
        });

        nav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                nav.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    window.addEventListener("scroll", () => {
        if (window.scrollY > 300) {
            scrollBtn.classList.add("show");
        } else {
            scrollBtn.classList.remove("show");
        }
    });

    if (scrollBtn) {
        scrollBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    if (currentYearSpan) {
        currentYearSpan.textContent = new Date().getFullYear();
    }

    const consentKey = "nva_cookie_consent";
    if (cookieBanner && localStorage.getItem(consentKey) !== "accepted") {
        cookieBanner.style.display = "block";
    }

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener("click", () => {
            localStorage.setItem(consentKey, "accepted");
            cookieBanner.style.display = "none";
        });
    }

    if (contactForm && contactResponse) {
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const requiredFields = ["fullName", "email", "topic", "message"];
            let valid = true;

            requiredFields.forEach(field => {
                const input = contactForm.querySelector(`[name="${field}"]`);
                if (input && !input.value.trim()) {
                    input.classList.add("error");
                    valid = false;
                } else if (input) {
                    input.classList.remove("error");
                }
            });

            const email = formData.get("email");
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (email && !emailPattern.test(email)) {
                const emailInput = contactForm.querySelector("#email");
                emailInput.classList.add("error");
                valid = false;
            }

            if (!valid) {
                contactResponse.textContent = "Please complete all required fields with valid information.";
                contactResponse.className = "form-response error";
                return;
            }

            contactForm.reset();
            contactResponse.textContent = "Thank you for reaching out. Our team will respond within one business day.";
            contactResponse.className = "form-response success";
        });
    }

    if (newsletterForm && newsletterResponse) {
        newsletterForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const emailInput = newsletterForm.querySelector("#newsletterEmail");
            const emailVal = emailInput.value.trim();
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(emailVal)) {
                emailInput.classList.add("error");
                newsletterResponse.textContent = "Enter a valid email address.";
                newsletterResponse.className = "form-response error";
                return;
            }
            emailInput.classList.remove("error");
            newsletterForm.reset();
            newsletterResponse.textContent = "Subscription successful. Look for our next quarterly intelligence brief.";
            newsletterResponse.className = "form-response success";
        });
    }
});