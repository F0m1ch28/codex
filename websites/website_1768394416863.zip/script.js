document.addEventListener("DOMContentLoaded", () => {
    const body = document.body;
    const navToggle = document.querySelector(".nav-toggle");
    const header = document.querySelector(".site-header");

    if (navToggle && header) {
        navToggle.addEventListener("click", () => {
            body.classList.toggle("nav-open");
        });

        document.addEventListener("click", (event) => {
            if (!header.contains(event.target)) {
                body.classList.remove("nav-open");
            }
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieAccept = document.querySelector(".cookie-accept");
    const cookieDecline = document.querySelector(".cookie-decline");
    const cookieStorageKey = "pianoanvny_cookie_consent";

    if (cookieBanner) {
        const storedPreference = localStorage.getItem(cookieStorageKey);
        if (storedPreference) {
            cookieBanner.classList.add("hidden");
        }

        const handleCookieChoice = (choice) => {
            localStorage.setItem(cookieStorageKey, choice);
            cookieBanner.classList.add("hidden");
        };

        if (cookieAccept) {
            cookieAccept.addEventListener("click", (event) => {
                handleCookieChoice("accepted");
                if (cookieAccept.tagName === "A") {
                    window.open(cookieAccept.href, "_blank", "noopener");
                    event.preventDefault();
                }
            });
        }

        if (cookieDecline) {
            cookieDecline.addEventListener("click", (event) => {
                handleCookieChoice("declined");
                if (cookieDecline.tagName === "A") {
                    window.open(cookieDecline.href, "_blank", "noopener");
                    event.preventDefault();
                }
            });
        }
    }
});