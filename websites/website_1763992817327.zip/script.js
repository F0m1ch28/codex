document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelector(".nav-links");

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      navLinks.classList.toggle("activo");
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
    });

    navLinks.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navLinks.classList.remove("activo");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".cookie-aceptar");
  const declineBtn = document.querySelector(".cookie-rechazar");
  const cookieKey = "traventiloraCookies";

  if (cookieBanner) {
    const cookieSetting = localStorage.getItem(cookieKey);
    if (!cookieSetting) {
      cookieBanner.style.display = "flex";
    }

    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => {
        localStorage.setItem(cookieKey, "accepted");
        cookieBanner.style.display = "none";
      });
    }

    if (declineBtn) {
      declineBtn.addEventListener("click", () => {
        localStorage.setItem(cookieKey, "declined");
        cookieBanner.style.display = "none";
      });
    }
  }
});