document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.getElementById('primary-navigation');
  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = primaryNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');
  const storageKey = 'cansystechCookieChoice';

  const currentChoice = localStorage.getItem(storageKey);
  if (!currentChoice && cookieBanner) {
    cookieBanner.classList.add('active');
  }

  const handleChoice = (choice) => {
    localStorage.setItem(storageKey, choice);
    if (cookieBanner) {
      cookieBanner.classList.remove('active');
    }
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => handleChoice('accepted'));
  }
  if (declineBtn) {
    declineBtn.addEventListener('click', () => handleChoice('declined'));
  }

  const path = window.location.pathname.replace(/\/+$/, '');
  if (path.endsWith('/history')) {
    window.location.replace('field-notes.html');
  } else if (path.endsWith('/infrastructure')) {
    window.location.replace('systems.html');
  } else if (path.endsWith('/resilience')) {
    window.location.replace('analysis.html');
  } else if (path.endsWith('/technology')) {
    window.location.replace('monitoring.html');
  }
});