import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Sobre Tavirel Mocandora | Nuestra historia y equipo</title>
      <meta
        name="description"
        content="Conoce la misión, los valores y el equipo multidisciplinario que impulsa Tavirel Mocandora en México."
      />
    </Helmet>
    <section className={styles.hero}>
      <div>
        <h1>Nacimos para honrar el trabajo silencioso del cuidado</h1>
        <p>
          Tavirel Mocandora surge en Ciudad de México como respuesta a una realidad compartida: familias que
          sostienen el bienestar de sus seres queridos con mucho amor, pero poca ayuda. Integrando tecnología,
          investigación social y acompañamiento terapéutico, diseñamos un ecosistema que abraza tanto a quien
          cuida como a quien recibe el cuidado.
        </p>
      </div>
      <div className={styles.heroImage} aria-hidden="true" />
    </section>

    <section className={styles.values}>
      <h2>Nuestros pilares</h2>
      <div className={styles.valuesGrid}>
        <article>
          <h3>Escucha profunda</h3>
          <p>
            Cada programa nace de entrevistas con familias cuidadoras mexicanas. Ajustamos constantemente las
            herramientas para que respondan a sus contextos culturales y económicos.
          </p>
        </article>
        <article>
          <h3>Innovación con propósito</h3>
          <p>
            Desarrollamos tecnología accesible que reduce la carga administrativa, promueve la seguridad y
            facilita decisiones informadas.
          </p>
        </article>
        <article>
          <h3>Bienestar integral</h3>
          <p>
            El cuidado no es solo físico. Integramos acompañamiento emocional, espacios de descanso y redes
            comunitarias para sostenerte en cada etapa.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.team}>
      <h2>Equipo multidisciplinario</h2>
      <div className={styles.teamGrid}>
        <article>
          <img src="https://picsum.photos/seed/directora/320/320" alt="Retrato de Ana Tavirel" loading="lazy" />
          <h3>Ana Tavirel</h3>
          <p>Directora general</p>
          <span>
            Socióloga y cuidadora familiar. Lidera la visión estratégica y mantiene el diálogo con comunidades
            de cuidados en todo México.
          </span>
        </article>
        <article>
          <img src="https://picsum.photos/seed/psicologa/320/320" alt="Retrato de Julieta Mocandora" loading="lazy" />
          <h3>Julieta Mocandora</h3>
          <p>Co-fundadora y psicoterapeuta</p>
          <span>
            Especialista en salud mental comunitaria. Diseña programas de acompañamiento emocional y capacita a
            nuestra red de profesionales.
          </span>
        </article>
        <article>
          <img src="https://picsum.photos/seed/tecnologia/320/320" alt="Retrato de Miguel Luna" loading="lazy" />
          <h3>Miguel Luna</h3>
          <p>Líder de producto</p>
          <span>
            Ingeniero con enfoque en accesibilidad. Garantiza que cada herramienta sea intuitiva, segura y
            disponible desde cualquier dispositivo.
          </span>
        </article>
      </div>
    </section>

    <section className={styles.commitment}>
      <div>
        <h2>Compromiso con el territorio mexicano</h2>
        <p>
          Colaboramos con hospitales públicos, organizaciones civiles y redes comunitarias para llevar
          acompañamiento a distintos estados del país. Creemos en una plataforma que se nutre de voces locales y
          promueve la solidaridad.
        </p>
      </div>
      <div>
        <ul>
          <li>Más de 40 talleres presenciales y virtuales impartidos desde 2021.</li>
          <li>
            Comunidad activa con participación de profesionales en enfermería, terapia ocupacional y trabajo
            social.
          </li>
          <li>Alianzas con universidades para documentar y medir el impacto del cuidado familiar.</li>
        </ul>
      </div>
    </section>
  </div>
);

export default About;