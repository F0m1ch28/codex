import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Política de cookies | Tavirel Mocandora</title>
      <meta
        name="description"
        content="Conoce cómo Tavirel Mocandora utiliza cookies para mejorar tu experiencia y proteger tu privacidad."
      />
    </Helmet>
    <section className={styles.section}>
      <h1>Política de cookies</h1>
      <p>
        Las cookies son pequeños archivos que se almacenan en tu dispositivo para recordar tus preferencias y
        optimizar la experiencia. Al continuar navegando en Tavirel Mocandora aceptas el uso descrito a
        continuación.
      </p>
      <h2>Tipos de cookies que utilizamos</h2>
      <ul>
        <li>
          <strong>Esenciales:</strong> Permiten el funcionamiento básico de la plataforma, como el inicio de sesión y
          la seguridad.
        </li>
        <li>
          <strong>De personalización:</strong> Guardan tus preferencias de idioma y las secciones que visitas con
          frecuencia.
        </li>
        <li>
          <strong>Analíticas:</strong> Nos ayudan a entender qué contenidos son más útiles para mejorar la plataforma.
        </li>
      </ul>
      <h2>Gestión de cookies</h2>
      <p>
        Puedes desactivar o eliminar las cookies desde la configuración de tu navegador. Ten en cuenta que algunas
        funciones podrían dejar de estar disponibles si se bloquean por completo.
      </p>
      <h2>Actualizaciones y contacto</h2>
      <p>
        Revisamos esta política regularmente. Cualquier cambio importante se comunicará en la plataforma.
        Preguntas adicionales pueden dirigirse a{' '}
        <a href="mailto:hola@tavirelmocandora.site">hola@tavirelmocandora.site</a>.
      </p>
    </section>
  </div>
);

export default CookiePolicy;