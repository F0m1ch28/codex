import React from 'react';
import styles from './PrivacyPolicy.module.css';

const PrivacyPolicy = ({ displayTitle = true }) => (
  <section className={styles.section} aria-labelledby="privacy-title">
    {displayTitle && (
      <h1 id="privacy-title" className={styles.heading}>
        Política de privacidad
      </h1>
    )}
    <div className={styles.content}>
      <p>
        En Tavirel Mocandora valoramos tu confianza y protegemos los datos personales que compartes con
        nosotros. Esta política explica cómo recabamos, utilizamos y resguardamos tu información.
      </p>
      <h2>Datos recolectados</h2>
      <p>
        Solicitamos datos de contacto, información sobre tu familia cuidadora y preferencias de seguimiento. No
        solicitamos datos financieros. Cualquier información sensible es opcional y se trata con controles de
        acceso estrictos.
      </p>
      <h2>Uso de la información</h2>
      <p>
        Utilizamos tus datos para personalizar los programas, coordinar sesiones con especialistas, generar
        recordatorios y enviar contenido relevante. No compartimos tus datos con terceros sin tu consentimiento.
      </p>
      <h2>Almacenamiento y seguridad</h2>
      <p>
        Implementamos encriptación y buenas prácticas de ciberseguridad. Revisamos nuestros protocolos de forma
        periódica para asegurar su vigencia. En caso de detectar cualquier incidente, te notificaremos de manera
        oportuna.
      </p>
      <h2>Derechos ARCO</h2>
      <p>
        Puedes acceder, rectificar, cancelar u oponerte al tratamiento de tus datos enviando un correo a{' '}
        <a href="mailto:hola@tavirelmocandora.site">hola@tavirelmocandora.site</a>. Atenderemos tu solicitud en
        un plazo máximo de 15 días hábiles.
      </p>
      <h2>Actualizaciones</h2>
      <p>
        Esta política puede modificarse para mejorar nuestros procesos. En ese caso, notificaremos mediante la
        plataforma y correo electrónico registrado.
      </p>
    </div>
  </section>
);

export default PrivacyPolicy;