import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  const valueCards = [
    {
      title: 'Empatía activa',
      description:
        'Escuchamos tu historia con respeto para que cada recomendación resuene con la realidad de tu familia.',
      icon: '🤝',
    },
    {
      title: 'Herramientas claras',
      description:
        'Simplificamos la coordinación de cuidados con tableros intuitivos, recordatorios y materiales descargables.',
      icon: '🧭',
    },
    {
      title: 'Acompañamiento constante',
      description:
        'La plataforma evoluciona contigo: desde el primer diagnóstico hasta los momentos de descanso y resiliencia.',
      icon: '🫶',
    },
  ];

  const highlightCards = [
    {
      title: 'Programas integrales',
      description:
        'Recorridos guiados por especialistas que incluyen acompañamiento emocional, organización del hogar y trámites.',
      link: '/programs',
      linkLabel: 'Explorar programas',
    },
    {
      title: 'Herramientas colaborativas',
      description:
        'Comparte agendas, tareas y notas importantes con familiares, cuidadores profesionales y personal de salud.',
      link: '/tools',
      linkLabel: 'Ver herramientas',
    },
    {
      title: 'Guía de primeros pasos',
      description:
        'Aprende a configurar tu cuenta y domina en minutos las funciones clave que alivian el día a día.',
      link: '/guide',
      linkLabel: 'Seguir la guía',
    },
  ];

  const testimonials = [
    {
      name: 'Rocío Hernández',
      role: 'Cuidadora de su mamá en Puebla',
      quote:
        '“Por primera vez siento que no estoy sola. El tablero colaborativo nos ayudó a repartir tareas y liberar mi mente.”',
      avatar: 'https://picsum.photos/seed/rocío/120/120',
    },
    {
      name: 'David Pérez',
      role: 'Papá cuidador en Querétaro',
      quote:
        '“Las cápsulas educativas nos dieron herramientas para hablar del tema en familia y tomar mejores decisiones.”',
      avatar: 'https://picsum.photos/seed/david/120/120',
    },
    {
      name: 'Fernanda Aguilar',
      role: 'Coordinadora de cuidados en CDMX',
      quote:
        '“Las alertas en tiempo real y la bitácora de bienestar cambiaron la manera en que trabajamos con nuestro médico.”',
      avatar: 'https://picsum.photos/seed/fernanda/120/120',
    },
  ];

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Tavirel Mocandora – Apoyo integral para familias cuidadoras</title>
        <meta
          name="description"
          content="Tavirel Mocandora ofrece programas, herramientas y guía profesional para que las familias cuidadoras en México se sientan acompañadas."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.overline}>Plataforma mexicana de apoyo familiar</p>
          <h1>Cuidar a quienes amas no debería sentirse abrumador.</h1>
          <p>
            En Tavirel Mocandora combinamos tecnología amable con orientación humana para que puedas coordinar
            citas, compartir responsabilidades y cuidar de ti mientras cuidas de los demás.
          </p>
          <div className={styles.heroActions}>
            <Link to="/programs" className={styles.primaryButton}>
              Descubre nuestros programas
            </Link>
            <Link to="/contact" className={styles.secondaryButton}>
              Solicitar acompañamiento
            </Link>
          </div>
        </div>
        <div className={styles.heroImage} aria-hidden="true" />
      </section>

      <section className={styles.values}>
        {valueCards.map((card) => (
          <article className={styles.valueCard} key={card.title}>
            <span className={styles.valueIcon} aria-hidden="true">
              {card.icon}
            </span>
            <h3>{card.title}</h3>
            <p>{card.description}</p>
          </article>
        ))}
      </section>

      <section className={styles.highlights}>
        <h2>Todo lo que necesitas en un mismo lugar</h2>
        <p>
          Reunimos recursos confiables, herramientas colaborativas y programas profesionales para que cuidar sea
          un trabajo compartido y lleno de dignidad.
        </p>
        <div className={styles.highlightGrid}>
          {highlightCards.map((item) => (
            <article className={styles.highlightCard} key={item.title}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <Link to={item.link}>{item.linkLabel}</Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.featured}>
        <div>
          <h2>Historias en movimiento</h2>
          <p>
            Capturamos momentos cotidianos que muestran el amor, la paciencia y la coordinación que hay detrás
            del cuidado. Son escenas que nos recuerdan la importancia de una red sólida.
          </p>
        </div>
        <div className={styles.gallery}>
          <img src="https://picsum.photos/seed/cuidado1/360/360" alt="Familia compartiendo una comida" loading="lazy" />
          <img src="https://picsum.photos/seed/cuidado2/360/360" alt="Cuidadores revisando notas juntos" loading="lazy" />
          <img src="https://picsum.photos/seed/cuidado3/360/360" alt="Momento de descanso familiar" loading="lazy" />
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Una comunidad para escuchar y aprender</h2>
          <p>
            Visita nuestro blog para encontrar consejos prácticos, relatos reales y talleres que fortalecen el
            bienestar emocional de toda la familia.
          </p>
        </div>
        <Link to="/blog" className={styles.primaryButton}>
          Ir al blog
        </Link>
      </section>

      <section className={styles.testimonials}>
        <h2>Voces que nos inspiran</h2>
        <div className={styles.testimonialGrid}>
          {testimonials.map((testimonial) => (
            <article className={styles.testimonialCard} key={testimonial.name}>
              <div className={styles.avatarBox}>
                <img src={testimonial.avatar} alt={testimonial.name} loading="lazy" />
              </div>
              <blockquote>{testimonial.quote}</blockquote>
              <p className={styles.person}>
                <strong>{testimonial.name}</strong>
                <span>{testimonial.role}</span>
              </p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.information}>
        <div>
          <h2>El cuidado familiar también necesita cuidados</h2>
          <p>
            Sabemos que el cansancio invisible y la carga emocional pueden pesar mucho. Por eso, cada sección de
            Tavirel Mocandora integra estrategias de autocuidado, conexiones comunitarias y apoyo profesional
            certificado.
          </p>
        </div>
        <ul className={styles.bullets}>
          <li>Mapeamos tus redes de apoyo para distribuir responsabilidades sin culpa.</li>
          <li>Integramos seguimiento clínico, emocional y administrativo en un solo tablero.</li>
          <li>Acompañamos con sesiones en línea, talleres y materiales descargables.</li>
        </ul>
      </section>

      <section className={styles.subscribe}>
        <div>
          <h2>Recibe orientación mensual</h2>
          <p>
            Compartimos novedades, eventos virtuales y herramientas diseñadas con familias cuidadoras mexicanas.
          </p>
        </div>
        <form
          className={styles.subscribeForm}
          onSubmit={(event) => {
            event.preventDefault();
          }}
        >
          <label htmlFor="email-subscribe" className="sr-only">
            Correo electrónico
          </label>
          <input id="email-subscribe" type="email" placeholder="Tu correo electrónico" required />
          <button type="submit">Quiero mantenerme al día</button>
        </form>
      </section>
    </div>
  );
};

export default Home;