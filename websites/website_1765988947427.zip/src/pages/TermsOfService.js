import React from 'react';
import styles from './TermsOfService.module.css';

const TermsOfService = ({ displayTitle = true }) => (
  <section className={styles.section} aria-labelledby="terms-title">
    {displayTitle && (
      <h1 id="terms-title" className={styles.heading}>
        Términos de servicio
      </h1>
    )}
    <div className={styles.content}>
      <p>
        Al acceder y utilizar la plataforma Tavirel Mocandora, aceptas respetar las siguientes condiciones. Nos
        reservamos el derecho de actualizar estos términos con el objetivo de mejorar la experiencia de las
        familias cuidadoras.
      </p>
      <h2>Uso adecuado de la plataforma</h2>
      <p>
        La plataforma está destinada a brindar orientación y herramientas para la organización del cuidado
        familiar. Se prohíbe utilizarla para fines ilícitos o que puedan afectar la seguridad de otras personas.
        Todo material descargable es para uso personal y no puede ser distribuido sin autorización.
      </p>
      <h2>Cuenta y confidencialidad</h2>
      <p>
        Te comprometes a mantener la confidencialidad de tus credenciales y notificarnos de inmediato ante
        cualquier uso no autorizado. Implementamos medidas de seguridad para proteger tu información, sin
        embargo, reconoces que ninguna transmisión electrónica es completamente infalible.
      </p>
      <h2>Servicios y disponibilidad</h2>
      <p>
        Trabajamos para mantener la plataforma accesible de forma continua. No obstante, podríamos realizar
        pausas programadas para mantenimiento o mejoras. En tales casos, se anunciará con anticipación.
      </p>
      <h2>Limitación de responsabilidad</h2>
      <p>
        Tomamos decisiones basadas en la información proporcionada por cada familia. No somos responsables por
        decisiones clínicas o legales externas. Recomendamos consultar a profesionales especializados cuando sea
        necesario.
      </p>
      <h2>Contacto</h2>
      <p>
        Ante dudas sobre estos términos escribe a{' '}
        <a href="mailto:hola@tavirelmocandora.site">hola@tavirelmocandora.site</a>.
      </p>
    </div>
  </section>
);

export default TermsOfService;