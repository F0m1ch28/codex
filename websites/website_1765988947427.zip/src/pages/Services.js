import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Programas de apoyo familiar | Tavirel Mocandora</title>
      <meta
        name="description"
        content="Conoce los programas personalizados de Tavirel Mocandora para fortalecer la organización, el bienestar y la conexión familiar."
      />
    </Helmet>
    <section className={styles.intro}>
      <h1>Programas que se adaptan a tu camino</h1>
      <p>
        Construimos itinerarios flexibles que combinan sesiones con especialistas, recursos descargables y
        herramientas digitales. Juntos diseñamos el plan que tu familia necesita para sentirse acompañada.
      </p>
    </section>

    <section className={styles.programs}>
      <article>
        <div className={styles.tag}>Programa 1</div>
        <h2>Raíces en calma</h2>
        <p>
          Ideal para familias que inician el proceso de cuidado. Incluye diagnóstico integral, agenda colaborativa,
          microcápsulas educativas y tres sesiones de contención emocional.
        </p>
        <ul>
          <li>Evaluación inicial con especialista en trabajo social.</li>
          <li>Implementación del tablero de cuidados con capacitación guiada.</li>
          <li>Seguimiento quincenal durante ocho semanas.</li>
        </ul>
      </article>

      <article>
        <div className={styles.tag}>Programa 2</div>
        <h2>Conexiones vivas</h2>
        <p>
          Pensado para redes familiares amplias. Incluye dinámicas de comunicación, sesiones grupales y uso
          avanzado de la bitácora de bienestar.
        </p>
        <ul>
          <li>Taller de acuerdos familiares y distribución de tareas.</li>
          <li>Integración de profesionales externos a la plataforma.</li>
          <li>Acompañamiento emocional continuo con psicoterapeuta.</li>
        </ul>
      </article>

      <article>
        <div className={styles.tag}>Programa 3</div>
        <h2>Horizonte resiliente</h2>
        <p>
          Para familias que enfrentan cuidados complejos o en transición. Combina consultoría jurídica básica,
          planeación financiera y estrategias de descanso programado.
        </p>
        <ul>
          <li>Sesiones con especialistas en cuidados paliativos y bioética.</li>
          <li>Mapeo de recursos comunitarios y apoyos públicos en tu estado.</li>
          <li>Plan de descanso para cuidadores principales con seguimiento mensual.</li>
        </ul>
      </article>
    </section>

    <section className={styles.extra}>
      <div>
        <h2>Personalizamos cada programa</h2>
        <p>
          Antes de iniciar, realizamos una entrevista en profundidad para entender tus prioridades, expectativas y
          capacidades actuales. El plan puede ajustarse conforme evoluciona la situación de cuidado.
        </p>
      </div>
      <div className={styles.infoBox}>
        <h3>Incluye acceso a:</h3>
        <ul>
          <li>Tablero digital y bitácora de bienestar con soporte continuo.</li>
          <li>Biblioteca de materiales enfocada en el contexto mexicano.</li>
          <li>Sesiones grupales mensuales con especialistas invitados.</li>
        </ul>
      </div>
    </section>
  </div>
);

export default Services;