import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [statusMessage, setStatusMessage] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Por favor, escribe tu nombre.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Necesitamos tu correo electrónico.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Ingresa un correo electrónico válido.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Cuéntanos brevemente cómo podemos ayudarte.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setStatusMessage('');
      return;
    }
    setStatusMessage('Gracias por escribirnos. Nuestro equipo te contactará en menos de 24 horas hábiles.');
    setFormData({ name: '', email: '', message: '' });
    setErrors({});
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contacto | Tavirel Mocandora</title>
        <meta
          name="description"
          content="Ponte en contacto con Tavirel Mocandora para recibir acompañamiento personalizado y resolver tus dudas."
        />
      </Helmet>
      <section className={styles.hero}>
        <div>
          <h1>Estamos listos para escucharte</h1>
          <p>
            Cuéntanos cómo podemos acompañarte y nos pondremos en contacto con una respuesta clara y humana. Si
            lo prefieres, agenda una videollamada introductoria sin presión.
          </p>
          <ul>
            <li>Asesoría personalizada para seleccionar el programa ideal.</li>
            <li>Demostraciones en vivo de nuestras herramientas digitales.</li>
            <li>Orientación emocional inicial para cuidadores principales.</li>
          </ul>
        </div>
        <div className={styles.infoCard}>
          <h2>Datos de contacto</h2>
          <p>Ciudad de México, MX</p>
          <a href="mailto:hola@tavirelmocandora.site">hola@tavirelmocandora.site</a>
          <p>Teléfono: +52 55 1234 5678</p>
        </div>
      </section>

      <section className={styles.formSection}>
        <h2>Envíanos un mensaje</h2>
        <form className={styles.form} noValidate onSubmit={handleSubmit}>
          <div className={styles.field}>
            <label htmlFor="name">Nombre</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="¿Cómo te llamas?"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Correo electrónico</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="nombre@correo.com"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="message">Mensaje</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Comparte tu situación o la ayuda que necesitas."
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </div>
          <button type="submit">Reach out to us. We're here to help.</button>
          {statusMessage && <p className={styles.success}>{statusMessage}</p>}
        </form>
      </section>
    </div>
  );
};

export default Contact;