import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className={styles.header} aria-label="Barra de navegación principal">
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          Tavirel Mocandora
        </NavLink>
        <button
          className={styles.menuButton}
          type="button"
          aria-label="Abrir menú"
          aria-expanded={isMenuOpen}
          onClick={toggleMenu}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={"${styles.nav} ${isMenuOpen ? styles.open : ''}"} aria-label="Secciones del sitio">
          <NavLink
            to="/"
            className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}
            onClick={closeMenu}
            end
          >
            Inicio
          </NavLink>
          <NavLink
            to="/guide"
            className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}
            onClick={closeMenu}
          >
            Guía
          </NavLink>
          <NavLink
            to="/programs"
            className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}
            onClick={closeMenu}
          >
            Programas
          </NavLink>
          <NavLink
            to="/tools"
            className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}
            onClick={closeMenu}
          >
            Herramientas
          </NavLink>
          <NavLink
            to="/blog"
            className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}
            onClick={closeMenu}
          >
            Blog
          </NavLink>
          <NavLink
            to="/about"
            className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}
            onClick={closeMenu}
          >
            Nosotros
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}
            onClick={closeMenu}
          >
            Contacto
          </NavLink>
          <NavLink
            to="/legal"
            className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}
            onClick={closeMenu}
          >
            Avisos legales
          </NavLink>
          <NavLink
            to="/cookies"
            className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}
            onClick={closeMenu}
          >
            Cookies
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;