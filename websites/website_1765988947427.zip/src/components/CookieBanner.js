import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    try {
      const consent = localStorage.getItem('tavirel_cookieConsent');
      if (consent !== 'accepted') {
        setIsVisible(true);
      }
    } catch (error) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    setIsVisible(false);
    try {
      localStorage.setItem('tavirel_cookieConsent', 'accepted');
    } catch (error) {
      // Ignorar almacenamiento no disponible
    }
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        Utilizamos cookies para personalizar tu experiencia y analizar el uso de la plataforma. Consulta nuestra{' '}
        <Link to="/cookies">política de cookies</Link> para conocer más detalles.
      </p>
      <button type="button" onClick={handleAccept}>
        Aceptar y continuar
      </button>
    </div>
  );
};

export default CookieBanner;