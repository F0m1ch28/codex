import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.brand}>
        <h2>Tavirel Mocandora</h2>
        <p>
          Plataforma mexicana que acompaña a familias cuidadoras con herramientas digitales y orientación
          humana.
        </p>
      </div>
      <div className={styles.columns}>
        <div>
          <h3>Explora</h3>
          <ul>
            <li>
              <Link to="/">Inicio</Link>
            </li>
            <li>
              <Link to="/programs">Programas</Link>
            </li>
            <li>
              <Link to="/tools">Herramientas</Link>
            </li>
            <li>
              <Link to="/blog">Blog</Link>
            </li>
          </ul>
        </div>
        <div>
          <h3>Recursos</h3>
          <ul>
            <li>
              <Link to="/guide">Guía de uso</Link>
            </li>
            <li>
              <Link to="/legal">Avisos legales</Link>
            </li>
            <li>
              <Link to="/cookies">Política de cookies</Link>
            </li>
          </ul>
        </div>
        <div>
          <h3>Contacto</h3>
          <ul>
            <li>Ciudad de México, MX</li>
            <li>
              <a href="mailto:hola@tavirelmocandora.site">hola@tavirelmocandora.site</a>
            </li>
            <li>Teléfono: +52 55 1234 5678</li>
          </ul>
          <div className={styles.social}>
            <a href="https://www.facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook">
              <span aria-hidden="true"></span>
            </a>
            <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram">
              <span aria-hidden="true"></span>
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
              <span aria-hidden="true"></span>
            </a>
          </div>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Tavirel Mocandora – Caregiving and Family Support. Todos los derechos reservados.</p>
    </div>
  </footer>
);

export default Footer;