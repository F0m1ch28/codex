import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';
import CookiePolicy from './pages/CookiePolicy';
import appStyles from './App.module.css';
import simpleStyles from './pages/SimplePage.module.css';

const GuidePage = () => (
  <div className={simpleStyles.page}>
    <Helmet>
      <title>Guía de uso | Tavirel Mocandora</title>
      <meta
        name="description"
        content="Descubre cómo aprovechar paso a paso las herramientas de Tavirel Mocandora para cuidar mejor a tu familia."
      />
    </Helmet>
    <header className={simpleStyles.header}>
      <h1>Guía paso a paso</h1>
      <p>
        Diseñamos esta guía para que puedas navegar la plataforma con tranquilidad, sin prisas y con la
        certeza de que cada herramienta tiene sentido en tu rutina de cuidados.
      </p>
    </header>
    <section className={simpleStyles.section}>
      <h2>1. Crea tu mapa de apoyos</h2>
      <p>
        Ingresa a tu tablero personal y completa el perfil familiar. Esta información nos permite recomendar
        recursos según tus horarios, redes de apoyo y prioridades médicas o emocionales.
      </p>
      <ol className={simpleStyles.list}>
        <li>Registra a cada integrante de la familia con sus necesidades específicas.</li>
        <li>Define horarios clave y alarmas para medicamentos o citas médicas.</li>
        <li>Invita a otros cuidadores para que participen en el seguimiento compartido.</li>
      </ol>
    </section>
    <section className={simpleStyles.section}>
      <h2>2. Activa alertas y recordatorios</h2>
      <p>
        Nuestro sistema sincroniza calendarios y envía notificaciones cálidas para que nada se te escape.
        Puedes personalizar tonos y canales de aviso según el nivel de prioridad.
      </p>
    </section>
    <section className={simpleStyles.section}>
      <h2>3. Aprende con microcápsulas</h2>
      <p>
        En el Centro de Aprendizaje encontrarás videos cortos, checklists descargables y ejercicios de cuidado
        emocional. Guarda tus favoritos y compártelos con tu familia.
      </p>
    </section>
    <section className={simpleStyles.section}>
      <h2>4. Pregunta y conecta</h2>
      <p>
        Usa nuestra función de consultoría para agendar sesiones virtuales con especialistas certificados.
        Antes de cada sesión puedes enviar tus preguntas para aprovechar el tiempo al máximo.
      </p>
    </section>
    <div className={simpleStyles.cta}>
      <p>¿Lista o listo para comenzar?</p>
      <Link className={simpleStyles.primaryLink} to="/tools">
        Conoce las herramientas clave
      </Link>
    </div>
  </div>
);

const ToolsPage = () => (
  <div className={simpleStyles.page}>
    <Helmet>
      <title>Herramientas digitales | Tavirel Mocandora</title>
      <meta
        name="description"
        content="Explora las herramientas digitales de Tavirel Mocandora para organizar cuidados, coordinar familia y cuidar tu bienestar."
      />
    </Helmet>
    <header className={simpleStyles.header}>
      <h1>Herramientas que alivian tu día</h1>
      <p>
        Cada función fue creada junto a familias cuidadoras mexicanas para ofrecerte un apoyo real, accesible
        y fácil de usar dondequiera que te encuentres.
      </p>
    </header>
    <section className={simpleStyles.grid}>
      <article className={simpleStyles.card}>
        <h2>Tablero de cuidados compartidos</h2>
        <p>
          Coordina tareas, citas y responsabilidades de manera visual. Las actualizaciones se reflejan en
          tiempo real para toda la familia.
        </p>
      </article>
      <article className={simpleStyles.card}>
        <h2>Bitácora de bienestar</h2>
        <p>
          Registra síntomas, estados de ánimo y observaciones clínicas. Genera reportes listos para compartir
          con profesionales de la salud.
        </p>
      </article>
      <article className={simpleStyles.card}>
        <h2>Biblioteca de recursos</h2>
        <p>
          Accede a guías, plantillas descargables y videos creados por especialistas locales. Todo el contenido
          está organizado por tema y nivel de urgencia.
        </p>
      </article>
      <article className={simpleStyles.card}>
        <h2>Red de apoyo comunitario</h2>
        <p>
          Conecta con grupos moderados de otras familias cuidadoras, comparte estrategias y encuentra alivio en
          conversaciones seguras.
        </p>
      </article>
    </section>
    <div className={simpleStyles.cta}>
      <p>¿Te gustaría recibir una demostración personalizada?</p>
      <Link className={simpleStyles.secondaryLink} to="/contact">
        Agenda una llamada de orientación
      </Link>
    </div>
  </div>
);

const BlogPage = () => {
  const posts = [
    {
      title: 'Tres rituales breves para reconectar con tu energía',
      excerpt:
        'Te compartimos prácticas sencillas para cuidar de ti mientras acompañas a tu ser querido, sin necesidad de grandes cambios.',
      author: 'María Domínguez, terapeuta familiar',
      image: 'https://picsum.photos/seed/blog1/640/420',
    },
    {
      title: 'Cómo preparar una visita médica colaborativa',
      excerpt:
        'Desde la bitácora de síntomas hasta las preguntas clave: todo lo que necesitas para aprovechar la consulta y regresar con claridad.',
      author: 'Equipo Clínico Tavirel Mocandora',
      image: 'https://picsum.photos/seed/blog2/640/420',
    },
    {
      title: 'Repartir responsabilidades sin perder la armonía',
      excerpt:
        'Hablamos con familias cuidadoras para encontrar acuerdos justos que respetan los ritmos de cada integrante.',
      author: 'Laura Villagrán, mediadora comunitaria',
      image: 'https://picsum.photos/seed/blog3/640/420',
    },
  ];

  return (
    <div className={simpleStyles.page}>
      <Helmet>
        <title>Blog y experiencias | Tavirel Mocandora</title>
        <meta
          name="description"
          content="Historias, consejos y aprendizajes compartidos por familias cuidadoras mexicanas."
        />
      </Helmet>
      <header className={simpleStyles.header}>
        <h1>Historias que inspiran y acompañan</h1>
        <p>
          Nuestro blog amplifica voces que viven el cuidado a diario. Aquí encontrarás relatos honestos,
          recomendaciones prácticas y ejercicios para fortalecer el bienestar familiar.
        </p>
      </header>
      <section className={simpleStyles.grid}>
        {posts.map((post) => (
          <article className={simpleStyles.postCard} key={post.title}>
            <img src={post.image} alt={post.title} loading="lazy" />
            <div className={simpleStyles.postBody}>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <p className={simpleStyles.postAuthor}>Por {post.author}</p>
              <span className={simpleStyles.tag}>Cuidado Familiar</span>
            </div>
          </article>
        ))}
      </section>
      <div className={simpleStyles.cta}>
        <p>¿Tienes una historia que pueda inspirar a otras familias?</p>
        <Link className={simpleStyles.primaryLink} to="/contact">
          Escríbenos y publicamos juntas
        </Link>
      </div>
    </div>
  );
};

const LegalPage = () => (
  <div className={simpleStyles.page}>
    <Helmet>
      <title>Avisos legales | Tavirel Mocandora</title>
      <meta
        name="description"
        content="Consulta los términos de servicio y la política de privacidad de Tavirel Mocandora."
      />
    </Helmet>
    <header className={simpleStyles.header}>
      <h1>Avisos legales</h1>
      <p>
        Queremos que utilices Tavirel Mocandora con confianza. Aquí encontrarás nuestras condiciones de uso y
        el compromiso con la protección de tus datos.
      </p>
    </header>
    <TermsOfService displayTitle={false} />
    <PrivacyPolicy displayTitle={false} />
  </div>
);

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);
  return null;
};

const AppRoutes = () => (
  <div className={appStyles.app}>
    <Header />
    <ScrollToTopOnRouteChange />
    <main className={appStyles.mainContent}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/guide" element={<GuidePage />} />
        <Route path="/programs" element={<Services />} />
        <Route path="/tools" element={<ToolsPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/legal" element={<LegalPage />} />
        <Route path="/cookies" element={<CookiePolicy />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTopButton />
  </div>
);

function App() {
  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  );
}

export default App;