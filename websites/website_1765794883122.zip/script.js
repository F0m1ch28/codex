document.addEventListener("DOMContentLoaded", () => {
  const yearEl = document.getElementById("year");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  /* Cookie Banner */
  const cookieBanner = document.querySelector(".cookie-banner");
  const cookieKey = "ccx-cookie-consent";
  if (cookieBanner) {
    const status = localStorage.getItem(cookieKey);
    if (!status) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add("visible");
      });
    }
    cookieBanner.addEventListener("click", (event) => {
      const action = event.target.closest("[data-action]");
      if (!action) return;
      const choice = action.dataset.action === "accept" ? "accepted" : "declined";
      localStorage.setItem(cookieKey, choice);
      cookieBanner.classList.remove("visible");
    });
  }

  /* Reveal on Scroll */
  const reveals = document.querySelectorAll(".reveal-on-scroll");
  if ("IntersectionObserver" in window && reveals.length) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    reveals.forEach((el) => observer.observe(el));
  } else {
    reveals.forEach((el) => el.classList.add("is-visible"));
  }

  /* Plan Selection Sync */
  const planButtons = document.querySelectorAll(".plan-select");
  const planCards = document.querySelectorAll("[data-plan-card]");
  const planRows = document.querySelectorAll("[data-plan-row]");
  const planSummary = document.getElementById("plan-summary");
  const planProjection = document.getElementById("plan-projection");
  const planMultiplier = document.getElementById("plan-multiplier");
  const registrationForm = document.getElementById("registration-form");
  const planSelect = registrationForm ? registrationForm.querySelector("#plan") : null;
  const hashRange = registrationForm ? registrationForm.querySelector("#hash-units") : null;
  const hashOutput = document.getElementById("hash-output");
  const planSpeed = document.getElementById("plan-speed");
  const selectedPlan = document.getElementById("selected-plan");
  const planDataMap = {
    "Plan 1": { price: "10", hash: 120, label: "Plan 1 · 10 USDT" },
    "Plan 2": { price: "50", hash: 600, label: "Plan 2 · 50 USDT" },
    "Plan 3": { price: "200", hash: 2800, label: "Plan 3 · 200 USDT" },
    "Plan 4": { price: "500", hash: 7200, label: "Plan 4 · 500 USDT" },
    "Plan 5": { price: "Custom", hash: 0, label: "Plan 5 · Custom Activation" }
  };

  const setPlanSelection = (planName) => {
    if (!planName || !planDataMap[planName]) return;
    const data = planDataMap[planName];
    localStorage.setItem("ccx-selected-plan", planName);

    planCards.forEach((card) => {
      card.classList.toggle("selected", card.dataset.planCard === planName);
    });
    planRows.forEach((row) => {
      row.classList.toggle("selected", row.dataset.planRow === planName);
    });

    if (planSelect) {
      planSelect.value = planName;
    }

    if (selectedPlan) {
      selectedPlan.textContent = data.label;
    }

    const multiplierValue = hashRange ? parseInt(hashRange.value, 10) : 1;
    updateHashProjection(planName, multiplierValue);

    if (planSummary) {
      planSummary.textContent = `${planName} · ${data.hash ? `${(data.hash / 1000).toFixed(data.hash >= 1000 ? 1 : 0)} ${data.hash >= 1000 ? "TH/s" : "GH/s"} baseline` : "Custom baseline"}`;
    }
  };

  const updateHashProjection = (planName, multiplier) => {
    const data = planDataMap[planName] || planDataMap["Plan 1"];
    const baseline = data.hash;
    if (planProjection && planMultiplier) {
      if (baseline > 0) {
        const projected = baseline * multiplier;
        const label = projected >= 1000 ? `${(projected / 1000).toFixed(2)} TH/s` : `${projected} GH/s`;
        planProjection.textContent = label;
      } else {
        planProjection.textContent = "Configurable with strategist";
      }
      planMultiplier.textContent = `${multiplier}x`;
    }
    if (hashOutput) {
      hashOutput.textContent = `${multiplier}x`;
    }
    if (planSpeed) {
      if (baseline > 0) {
        const projected = baseline * multiplier;
        const label = projected >= 1000 ? `${(projected / 1000).toFixed(2)} TH/s` : `${projected} GH/s`;
        planSpeed.textContent = label;
      } else {
        planSpeed.textContent = "Custom velocity";
      }
    }
  };

  planButtons.forEach((button) => {
    button.addEventListener("click", () => {
      setPlanSelection(button.dataset.plan);
      if (registrationForm) {
        registrationForm.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });
  });

  const storedPlan = localStorage.getItem("ccx-selected-plan") || "Plan 1";
  setPlanSelection(storedPlan);

  if (hashRange) {
    hashRange.addEventListener("input", () => {
      const multiplierValue = parseInt(hashRange.value, 10);
      const currentPlan = planSelect && planSelect.value ? planSelect.value : storedPlan;
      updateHashProjection(currentPlan, multiplierValue);
    });
  }

  if (planSelect) {
    planSelect.addEventListener("change", (event) => {
      const selected = event.target.value;
      setPlanSelection(selected);
    });
  }

  /* Registration Form Validation */
  if (registrationForm) {
    registrationForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const feedbackEl = document.getElementById("form-feedback");
      const formData = new FormData(registrationForm);
      const errors = [];

      if (!formData.get("fullName")?.trim()) errors.push("Full name is required.");
      const email = formData.get("email")?.trim();
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push("Enter a valid email address.");
      if (!formData.get("wallet")?.trim()) errors.push("Wallet address is required.");
      if (!formData.get("plan")) errors.push("Select a hash plan.");

      if (errors.length) {
        feedbackEl.textContent = errors.join(" ");
        feedbackEl.className = "feedback error";
        feedbackEl.style.display = "block";
        return;
      }

      feedbackEl.textContent = "Registration received! Our team will provision your hash introduction shortly.";
      feedbackEl.className = "feedback success";
      feedbackEl.style.display = "block";
      registrationForm.reset();
      localStorage.setItem("ccx-selected-plan", "Plan 1");
      setPlanSelection("Plan 1");
      if (hashRange) {
        hashRange.value = 3;
        updateHashProjection("Plan 1", 3);
      }
    });
  }

  /* Copy Wallet Address */
  const copyButton = document.querySelector("[data-copy-wallet]");
  if (copyButton) {
    copyButton.addEventListener("click", async () => {
      const address = copyButton.dataset.copyWallet;
      try {
        await navigator.clipboard.writeText(address);
        copyButton.textContent = "Copied!";
        setTimeout(() => {
          copyButton.textContent = "Copy Address";
        }, 2000);
      } catch (error) {
        const textEl = document.getElementById("wallet-address-text");
        if (textEl) {
          const range = document.createRange();
          range.selectNode(textEl);
          window.getSelection().removeAllRanges();
          window.getSelection().addRange(range);
        }
      }
    });
  }

  /* Smooth Scroll for Internal Links */
  document.querySelectorAll('a[href^="#"]').forEach((link) => {
    link.addEventListener("click", (event) => {
      const targetId = link.getAttribute("href").substring(1);
      const targetEl = document.getElementById(targetId);
      if (targetEl) {
        event.preventDefault();
        targetEl.scrollIntoView({ behavior: "smooth", block: "start" });
        history.pushState(null, "", `#${targetId}`);
      }
    });
  });
});