document.addEventListener("DOMContentLoaded", function () {
  const banner = document.getElementById("cookie-banner");
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  const decision = localStorage.getItem("raceCookieConsent");

  if (!decision && banner) {
    requestAnimationFrame(() => {
      banner.classList.add("is-visible");
    });
  }

  if (acceptBtn) {
    acceptBtn.addEventListener("click", function () {
      localStorage.setItem("raceCookieConsent", "accepted");
      hideBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", function () {
      localStorage.setItem("raceCookieConsent", "declined");
      hideBanner();
    });
  }

  function hideBanner() {
    if (banner) {
      banner.classList.remove("is-visible");
      banner.style.display = "none";
    }
  }
});