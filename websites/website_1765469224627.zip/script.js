document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });

    nav.addEventListener("click", (event) => {
      if (event.target.classList.contains("nav-link") && nav.classList.contains("is-open")) {
        nav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const cookieButtons = document.querySelectorAll("[data-cookie]");

  if (cookieBanner) {
    const preference = localStorage.getItem("cookiePreference");
    if (!preference) {
      cookieBanner.classList.remove("is-hidden");
    }

    cookieButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const choice = button.dataset.cookie;
        localStorage.setItem("cookiePreference", choice);
        cookieBanner.classList.add("is-hidden");
      });
    });
  }

  const form = document.querySelector("form[data-validate]");
  if (form) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const name = form.querySelector("#name");
      const email = form.querySelector("#email");
      const company = form.querySelector("#company");
      const message = form.querySelector("#message");
      const output = document.querySelector("#formMessage");

      const errors = [];

      if (!name.value.trim()) {
        errors.push("Please enter your name.");
      }
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!email.value.trim() || !emailPattern.test(email.value)) {
        errors.push("Please provide a valid work email.");
      }
      if (!company.value.trim()) {
        errors.push("Please share your company name.");
      }
      if (!message.value.trim()) {
        errors.push("Please outline your project goals.");
      }

      if (errors.length > 0) {
        output.textContent = errors.join(" ");
        output.style.color = "#B00020";
        return;
      }

      output.textContent = "Thank you. Our team will connect with you within two business days.";
      output.style.color = "#0A2463";
      form.reset();
    });
  }
});