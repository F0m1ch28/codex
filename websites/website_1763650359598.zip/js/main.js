document.addEventListener("DOMContentLoaded", () => {
  // Mobile Navigation Toggle
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".main-navigation");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      nav.classList.toggle("open");
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        nav.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  // Active Navigation Highlight
  const currentPage = document.body.dataset.page;
  if (currentPage) {
    document.querySelectorAll(".nav-list a").forEach((link) => {
      const href = link.getAttribute("href");
      if (href && href.replace(".html", "") === `${currentPage}`) {
        link.classList.add("active");
      } else if (currentPage === "home" && href === "index.html") {
        link.classList.add("active");
      }
    });
  }

  // Smooth scrolling for same-page anchors
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      const targetId = this.getAttribute("href");
      if (targetId.length > 1) {
        const target = document.querySelector(targetId);
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      }
    });
  });

  // Current Year in Footer
  const yearSpan = document.getElementById("current-year");
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  // Cookie Banner Logic
  const cookieBanner = document.querySelector(".cookie-banner");
  const cookieButtons = document.querySelectorAll("[data-cookie-action]");
  const cookieKey = "luminexCookieConsent";

  const setCookiePreference = (value) => {
    localStorage.setItem(cookieKey, value);
    cookieBanner.classList.remove("show");
  };

  const cookiePref = localStorage.getItem(cookieKey);
  if (!cookiePref && cookieBanner) {
    setTimeout(() => cookieBanner.classList.add("show"), 800);
  }

  cookieButtons.forEach((button) =>
    button.addEventListener("click", () => {
      const action = button.dataset.cookieAction;
      if (action === "accept") {
        setCookiePreference("accepted");
      } else {
        setCookiePreference("declined");
      }
    })
  );

  // Newsletter Form Handler
  document.querySelectorAll(".newsletter-form").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const input = form.querySelector("input[type='email']");
      if (input && input.validity.valid) {
        input.value = "";
        input.placeholder = "Subscribed!";
        form.querySelector("button").textContent = "Thank you";
        setTimeout(() => {
          input.placeholder = "you@company.com";
          form.querySelector("button").textContent = "Subscribe";
        }, 2500);
      } else if (input) {
        input.focus();
      }
    });
  });

  // Contact Form Validation
  const contactForm = document.getElementById("contact-form");
  if (contactForm) {
    const responseEl = contactForm.querySelector(".form-response");
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      let isValid = true;

      const validateField = (field) => {
        const errorSpan = field.parentElement.querySelector(".error-message");
        if (!field.checkValidity()) {
          isValid = false;
          if (errorSpan) {
            if (field.validity.valueMissing) {
              errorSpan.textContent = "This field is required.";
            } else if (field.validity.typeMismatch) {
              errorSpan.textContent = "Please enter a valid value.";
            } else {
              errorSpan.textContent = "Please correct this field.";
            }
          }
        } else if (errorSpan) {
          errorSpan.textContent = "";
        }
      };

      contactForm.querySelectorAll("input, select, textarea").forEach(validateField);

      if (isValid) {
        responseEl.textContent = "Thank you! Our team will reach out within 48 hours.";
        responseEl.style.color = "var(--color-success)";
        contactForm.reset();
      } else {
        responseEl.textContent = "Please review the highlighted fields.";
        responseEl.style.color = "var(--color-danger)";
      }
    });

    contactForm.querySelectorAll("input, select, textarea").forEach((field) => {
      field.addEventListener("input", () => {
        const errorSpan = field.parentElement.querySelector(".error-message");
        if (field.checkValidity() && errorSpan) {
          errorSpan.textContent = "";
        }
      });
    });
  }
});