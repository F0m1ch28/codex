document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    navMenu.classList.remove('open');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const consentChoice = localStorage.getItem('bufobokmfoCookieConsent');

    if (cookieBanner && !consentChoice) {
        cookieBanner.classList.add('active');
    }

    document.querySelectorAll('[data-cookie-consent]').forEach(button => {
        button.addEventListener('click', event => {
            event.preventDefault();
            const choice = button.getAttribute('data-cookie-consent');
            localStorage.setItem('bufobokmfoCookieConsent', choice);
            if (cookieBanner) {
                cookieBanner.classList.remove('active');
            }
            const destination = button.getAttribute('href');
            if (destination) {
                setTimeout(() => {
                    window.location.href = destination;
                }, 120);
            }
        });
    });
});