'use strict';

const DEFAULT_LANG = 'fr';
const LANG_STORAGE_KEY = 'site_lang';
const CONSENT_STORAGE_KEY = 'cookie_consent';

const I18N = {
  fr: {
    title: {
      index: 'danswholesaleplants | Orientation spatiale numérique',
      services: 'Services d’analyse spatiale | danswholesaleplants',
      about: 'Profil de recherche | danswholesaleplants',
      blog: 'Blog d’analyses spatiales | danswholesaleplants',
      post1: 'Cartographier les seuils attentionnels dans les halls publics | danswholesaleplants',
      post2: 'Signalétique numérique adaptative dans les gares intermodales | danswholesaleplants',
      post3: 'Accessibilité dans les réseaux de circulation verticale | danswholesaleplants',
      post4: 'Cartographies narratives pour les campus institutionnels | danswholesaleplants',
      post5: 'Mesurer les interactions piétonnes dans les quartiers gouvernementaux | danswholesaleplants',
      contact: 'Contact | danswholesaleplants',
      faq: 'FAQ | danswholesaleplants',
      terms: 'Conditions d’utilisation | danswholesaleplants',
      privacy: 'Politique de confidentialité | danswholesaleplants',
      cookies: 'Politique de cookies | danswholesaleplants',
      refund: 'Politique de remboursement | danswholesaleplants',
      disclaimer: 'Clause de non-responsabilité | danswholesaleplants',
      thankyou: 'Merci | danswholesaleplants',
      notFound: 'Page introuvable | danswholesaleplants'
    },
    meta: {
      index: 'Plateforme de recherche sur l’orientation spatiale, la signalétique numérique et les parcours utilisateurs dans les bâtiments publics en Belgique.',
      services: 'Présentation des services non commerciaux de danswholesaleplants pour analyser l’orientation spatiale dans les environnements publics belges.',
      about: 'Méthodologie et cadre collaboratif du laboratoire d’orientation spatiale de danswholesaleplants.',
      blog: 'Articles et études de cas consacrés à la navigation spatiale, aux plans interactifs et à l’accessibilité des espaces publics.',
      post1: 'Méthode pour cartographier les seuils attentionnels dans les halls publics et améliorer la signalétique numérique à Bruxelles.',
      post2: 'Approche pour une signalétique numérique adaptative dans les gares intermodales belges en synchronisant données et observations.',
      post3: 'Étude des réseaux de circulation verticale et indicateurs d’accessibilité dans les bâtiments administratifs publics.',
      post4: 'Cadre de cartographie narrative pour accompagner les campus institutionnels et les mobilités lentes.',
      post5: 'Analyse des interactions piétonnes autour des bâtiments gouvernementaux à Bruxelles afin d’améliorer la lisibilité urbaine.',
      contact: 'Coordonnées et formulaire pour joindre danswholesaleplants à Bruxelles.',
      faq: 'Questions fréquentes sur les analyses d’orientation spatiale menées par danswholesaleplants.',
      terms: 'Conditions d’utilisation encadrant l’accès au site danswholesaleplants.com.',
      privacy: 'Politique de confidentialité détaillant la collecte et l’usage des données par danswholesaleplants.',
      cookies: 'Politique de cookies décrivant les traceurs utilisés sur danswholesaleplants.com.',
      refund: 'Politique de remboursement précisant le traitement des demandes liées aux missions de conseil.',
      disclaimer: 'Clause de non-responsabilité concernant les informations publiées sur le site.',
      thankyou: 'Page de confirmation affichée après l’envoi d’un message à danswholesaleplants.',
      notFound: 'Page d’erreur affichée lorsque la ressource demandée est indisponible.'
    },
    brand: {
      name: 'danswholesaleplants'
    },
    header: {
      tagline: 'Design informationnel pour environnements publics complexes'
    },
    nav: {
      home: 'Accueil',
      services: 'Services',
      about: 'Profil',
      blog: 'Blog',
      faq: 'FAQ',
      contact: 'Contact'
    },
    buttons: {
      readMore: 'Lire l’analyse',
      learnMore: 'Comprendre l’approche',
      viewAll: 'Voir toutes les publications',
      openContact: 'Accéder au contact',
      backHome: 'Retour à l’accueil',
      backContact: 'Retour au contact',
      exploreBlog: 'Explorer le blog',
      viewMap: 'Afficher la carte'
    },
    aria: {
      menuToggle: 'Ouvrir ou fermer la navigation principale',
      languageSwitch: 'Changer de langue du site'
    },
    footer: {
      summary: 'Plateforme basée à Bruxelles dédiée à l’orientation spatiale, à la signalétique numérique et à la lisibilité des environnements publics complexes.',
      phone: 'Téléphone : +32 2 123 45 67',
      email: 'Courriel : contact@danswholesaleplants.com',
      address: 'Rue de la Loi 200, 1040 Bruxelles, Belgique',
      rights: '© {year} danswholesaleplants. Tous droits réservés.',
      cookieLink: 'Paramétrer les cookies',
      terms: 'Conditions d’utilisation',
      privacy: 'Politique de confidentialité',
      cookies: 'Politique de cookies',
      refund: 'Politique de remboursement',
      disclaimer: 'Clause de non-responsabilité'
    },
    home: {
      hero: {
        heading: 'Cartographier les seuils attentionnels pour des parcours publics fluides',
        lead: 'danswholesaleplants structure des diagnostics d’orientation spatiale pour les institutions belges. Nous étudions les relations entre signalétique numérique, architecture et expérience utilisateur afin de rendre les déplacements plus lisibles.',
        point1: 'Analyse multi-échelle des trajectoires piétonnes bruxelloises',
        point2: 'Signalétique numérique inclusive et adaptable',
        point3: 'Plans interactifs intégrés aux infrastructures publiques',
        button: 'Explorer nos axes de recherche',
        secondary: 'Consulter notre documentation',
        imageAlt: 'Visualisation numérique de flux piétons dans un hall public bruxellois'
      },
      featured: {
        title: 'Espaces complexes, lectures précises',
        intro: 'Nous combinons données spatiales, observation in situ et scénarios d’usage pour clarifier les environnements à forte densité fonctionnelle.',
        card1: {
          title: 'Cartographie comportementale',
          text: 'Repérage des zones de friction, identification des points d’attention et modélisation des rythmes de déplacement au sein des bâtiments publics.'
        },
        card2: {
          title: 'Protocoles de signalétique numérique',
          text: 'Conception de gabarits visuels et de logiques dynamiques pour des dispositifs d’affichage contextualisés en temps réel.'
        },
        card3: {
          title: 'Scénarios de flux hybrides',
          text: 'Mise en dialogue des flux piétons, cyclistes et de transports publics afin de limiter les conflits d’usage et de renforcer la lisibilité.'
        },
        card4: {
          title: 'Indicateurs d’accessibilité',
          text: 'Évaluation des parcours prioritaires, des continuités PMR et des points d’intelligibilité pour garantir une expérience inclusive.'
        }
      },
      orientation: {
        title: 'Laboratoire d’orientation spatiale',
        intro: 'Le laboratoire de danswholesaleplants assemble des capteurs, des observations qualitatives et des analyses cartographiques pour tester différentes configurations de guidage.',
        highlight1: {
          title: 'Capteurs situés',
          text: 'Collecte de données en continu sur les flows, les temps d’arrêt et les zones à forte densité afin de préciser les besoins d’orientation.'
        },
        highlight2: {
          title: 'Narration spatiale',
          text: 'Création de storytelling visuel reliant architecture, signalétique et repères numériques pour orienter sans surcharger.'
        },
        highlight3: {
          title: 'Boucles de validation',
          text: 'Tests utilisateurs, ateliers avec les équipes de terrain et itérations rapides pour ajuster les dispositifs avant déploiement.'
        },
        imageAlt: 'Équipe analysant des plans interactifs dans un laboratoire de signalétique'
      },
      recommendations: {
        title: 'Recommandations structurées',
        intro: 'Chaque mission s’achève par un corpus de recommandations hiérarchisées permettant de synchroniser décideurs, exploitants et publics.',
        card1: {
          lead: 'Atlas des usages',
          text: 'Cartographies synthétiques représentant les profils d’usagers, les plages horaires et les interactions clés pour guider la conception.'
        },
        card2: {
          lead: 'Matrices de signalétique',
          text: 'Tableaux de correspondance entre messages, supports et localisations afin de structurer des systèmes d’information cohérents.'
        },
        card3: {
          lead: 'Itérations d’accessibilité',
          text: 'Simulations successives intégrant normes européennes, retours terrain et critères sensoriels pour consolider l’inclusion.'
        }
      },
      testimonials: {
        title: 'Témoignages contextuels',
        intro: 'Institutions belges engagées dans la transformation de leurs espaces publics témoignent des impacts observés.',
        item1: {
          quote: 'Les cartographies produites ont révélé des couloirs sous-exploités et nous ont permis de redistribuer les flux sans travaux majeurs.',
          author: 'Anne-Michèle L., responsable infrastructure',
          context: 'Ville de Bruxelles'
        },
        item2: {
          quote: 'La méthodologie de tests successifs a clarifié les priorités d’affichage et simplifié la coordination entre les services opérationnels.',
          author: 'Jeroen V., coordinateur mobilité',
          context: 'Région de Bruxelles-Capitale'
        },
        item3: {
          quote: 'Le protocole d’accessibilité a offert une vision partagée entre architectes, gardiens et associations spécialisées.',
          author: 'Sabine D., direction des équipements',
          context: 'Institution culturelle fédérale'
        }
      },
      insights: {
        title: 'Dernières analyses',
        intro: 'Une sélection de publications met en lumière nos recherches actuelles sur la lisibilité des espaces complexes.',
        button: 'Voir toutes les publications'
      },
      callout: {
        title: 'Question sur un environnement complexe ?',
        text: 'La FAQ rassemble les réponses aux points récurrents concernant la navigation intérieure, la signalétique et les données spatiales.',
        button: 'Consulter la FAQ'
      }
    },
    services: {
      hero: {
        heading: 'Services d’analyse spatiale',
        lead: 'Nous accompagnons les gestionnaires d’espaces publics belges dans la compréhension de leurs parcours utilisateurs et la structuration de systèmes d’orientation adaptés.'
      },
      cards: {
        card1: {
          title: 'Diagnostic d’orientation',
          text: 'Étude complète des parcours d’entrée, de transition et de sortie incluant observations in situ, relevés photographiques et entretiens avec les équipes d’accueil.'
        },
        card2: {
          title: 'Cartes interactives',
          text: 'Conception de plans dynamiques connectés aux bases de données institutionnelles pour offrir des informations actualisées et contextualisées.'
        },
        card3: {
          title: 'Signalétique numérique inclusive',
          text: 'Définition des principes visuels, des typographies et des logiques de hiérarchisation pour des dispositifs numériques lisibles par tous.'
        },
        card4: {
          title: 'Modélisation des flux',
          text: 'Simulation des flux piétons et de leurs interactions avec les services de mobilité douce et collective pour réduire les frictions.'
        },
        card5: {
          title: 'Frameworks d’accessibilité',
          text: 'Grilles d’analyse intégrant normes, perception sensorielle et retours d’usagers afin de renforcer la continuité des parcours prioritaires.'
        },
        card6: {
          title: 'Évaluation post-occupation',
          text: 'Mesure des indicateurs de compréhension, d’usage et de satisfaction pour suivre l’impact des interventions dans le temps.'
        }
      },
      process: {
        title: 'Processus d’intervention',
        lead: 'Chaque mission suit un processus clair permettant d’articuler données, expériences vécues et décisions opérationnelles.',
        steps: {
          step1: {
            title: 'Immersion contextuelle',
            text: 'Cartographie des acteurs, repérage des points de repère et collecte de traces photographiques pour saisir l’identité du lieu.'
          },
          step2: {
            title: 'Cartographies de données',
            text: 'Croisement des données quantitatives et qualitatives afin de révéler les couloirs critiques et les zones d’attention.'
          },
          step3: {
            title: 'Cocréation d’expériences',
            text: 'Ateliers ciblés avec les usagers et les équipes internes pour prototyper des scénarios de guidage.'
          },
          step4: {
            title: 'Mesure et ajustement',
            text: 'Déploiement contrôlé puis suivi des indicateurs pour adapter les dispositifs selon les retours.'
          }
        }
      },
      principles: {
        title: 'Principes de travail',
        lead: 'Nos interventions reposent sur des principes précis afin de garantir une compréhension partagée des enjeux spatiaux.',
        items: {
          item1: {
            title: 'Transversalité',
            text: 'Croiser les regards des architectes, opérateurs de terrain, designers et experts en accessibilité.'
          },
          item2: {
            title: 'Traçabilité',
            text: 'Documenter chaque hypothèse, chaque jeu de données et chaque décision pour faciliter la gouvernance.'
          },
          item3: {
            title: 'Temporalité',
            text: 'Prendre en compte les cycles journaliers et saisonniers afin de proposer des dispositifs évolutifs.'
          }
        }
      },
      outcomes: {
        title: 'Livrables typiques',
        text: 'Les livrables sont conçus pour être réutilisés par les équipes internes et leurs partenaires techniques.',
        item1: 'Rapports cartographiques annotés',
        item2: 'Guides de signalétique numérique adaptative',
        item3: 'Matrices d’arborescences pour plans interactifs',
        item4: 'Tableaux de bord de suivi des flux piétons'
      },
      contactPrompt: {
        title: 'Coordination institutionnelle',
        text: 'Nous travaillons avec des équipes publiques, semi-publiques ou associatives souhaitant clarifier leurs espaces ouverts au public.',
        button: 'Accéder à la page contact'
      }
    },
    about: {
      hero: {
        heading: 'Profil de danswholesaleplants',
        lead: 'danswholesaleplants est un collectif basé à Bruxelles qui investigue la lisibilité des environnements bâtis, la signalétique numérique et les parcours utilisateurs dans les contextes publics.'
      },
      mission: {
        title: 'Mission',
        text1: 'Nous analysons les relations entre architecture, flux piétons et interfaces numériques pour rendre les déplacements intuitifs.',
        text2: 'Nos interventions se fondent sur des observations sensibles et des données mesurables afin de co-construire des environnements accessibles.'
      },
      layers: {
        title: 'Approche multi-échelles',
        lead: 'Chaque étude combine plusieurs niveaux de lecture pour articuler le détail et la vision d’ensemble.',
        items: {
          item1: {
            title: 'Échelle micro',
            text: 'Focalisation sur les gestes, les ralentissements et les micro-décisions prises par les usagers.'
          },
          item2: {
            title: 'Échelle méso',
            text: 'Analyse des séquences spatiales, des transitions et des intersections de flux.'
          },
          item3: {
            title: 'Échelle macro',
            text: 'Compréhension des réseaux urbains, des connexions intermodales et des polarités territoriales.'
          }
        }
      },
      research: {
        title: 'Protocoles de recherche',
        text: 'Nos protocoles allient sciences sociales, géomatique et design informationnel.',
        list: {
          item1: 'Observation participante et entretiens situés',
          item2: 'Analyse de données spatiales et de chronotopies',
          item3: 'Prototypage rapide de signalétique numérique',
          item4: 'Tests utilisateurs avec mesures d’attention'
        }
      },
      collab: {
        title: 'Collaborations',
        text1: 'Nous collaborons avec des institutions culturelles, des universités, des opérateurs de transport et des services administratifs.',
        text2: 'Ces partenariats permettent de confronter les hypothèses aux réalités de terrain et de capitaliser sur les retours d’expérience.'
      },
      timeline: {
        title: 'Étapes de structuration',
        items: {
          item1: {
            title: '2017-2019',
            text: 'Exploration initiale des problématiques de lisibilité dans les bâtiments publics bruxellois et constitution d’une base de données qualitative.'
          },
          item2: {
            title: '2020-2022',
            text: 'Développement d’outils d’analyse numérique, formalisation des ateliers de co-conception et premières cartographies interactives.'
          },
          item3: {
            title: 'Depuis 2023',
            text: 'Mise en place d’un laboratoire permanent d’orientation spatiale et extension des collaborations à d’autres villes belges.'
          }
        }
      },
      values: {
        title: 'Valeurs opérationnelles',
        items: {
          item1: {
            title: 'Attention aux usages',
            text: 'Chaque recommandation est ancrée dans les pratiques quotidiennes observées.'
          },
          item2: {
            title: 'Sobriété informative',
            text: 'Nous privilégions des dispositifs lisibles, pertinents et non invasifs.'
          },
          item3: {
            title: 'Transmission',
            text: 'Les méthodes sont documentées pour faciliter la reprise par les équipes en place.'
          }
        }
      },
      cta: {
        title: 'Poursuivre la lecture',
        text: 'Le blog décrit en détail nos études de cas, nos métriques d’orientation et nos outils cartographiques.',
        button: 'Explorer le blog'
      }
    },
    blog: {
      hero: {
        heading: 'Blog d’analyses spatiales',
        lead: 'Retours d’expérience, méthodologies et cartographies dédiées aux espaces publics complexes en Belgique.',
        note: 'Chaque article s’appuie sur des données recueillies sur le terrain et sur des simulations numériques.'
      },
      listing: {
        title: 'Toutes les publications',
        intro: 'Sélectionnez un article pour explorer les protocoles détaillés.'
      },
      callout: {
        title: 'Besoin d’un cadrage rapide ?',
        text: 'La FAQ synthétise les réponses aux questions récurrentes sur nos méthodes.',
        button: 'Accéder à la FAQ'
      }
    },
    posts: {
      post1: {
        title: 'Cartographier les seuils attentionnels dans les halls publics',
        meta: 'Analyse des seuils attentionnels et des points de friction dans les halls publics bruxellois, combinant observations qualitatives et capteurs numériques.',
        excerpt: 'Nous décrivons une méthode pour repérer les seuils attentionnels dans les halls publics, afin de guider la conception de signalétique numérique et de plans interactifs.',
        summary: 'L’étude décrite examine les halls publics à forte densité, identifie les seuils où l’attention se fragmente et propose des leviers de signalétique pour rétablir la continuité des parcours.',
        figure: 'Plan thermique des points d’attention dans un hall public.',
        imageAlt: 'Carte thermique d’un hall public',
        section1: {
          title: 'Identifier les zones de transition critiques',
          p1: 'Nous avons commencé par cartographier les entrées, sorties et noyaux de circulation de quatre halls publics bruxellois. Chaque zone a été observée durant différentes plages horaires, ce qui a permis de distinguer des micro-séquences de déplacement. Les seuils attentionnels apparaissent lorsque les usagers interrompent leur trajectoire pour rechercher un repère, un service ou un lien modal.',
          p2: 'Les relevés photographiques et les notes d’observation ont été complétés par une analyse des signaux sonores et lumineux. Cette approche sensorielle révèle des contrastes qui captent l’attention et des zones d’ombre où les informations disparaissent. Les cartes générées combinent densités de présence et trajectoires réelles, offrant un support solide pour les discussions avec les gestionnaires.',
          sub1: 'Typologie des interruptions',
          p3: 'Les ruptures d’attention se classent en trois familles : la recherche de direction, la vérification d’information et la coordination avec d’autres usagers. Chaque famille est associée à des lieux précis, par exemple les jonctions entre escaliers et ascenseurs ou les grands écrans d’information. Cette typologie facilite le choix du support de signalétique le plus pertinent.'
        },
        section2: {
          title: 'Aligner signalétique et perception',
          p1: 'La deuxième phase confronte la cartographie aux dispositifs existants. Nous avons analysé la hauteur, la lumière et la lisibilité des panneaux physiques, ainsi que les scripts des écrans numériques. Cette comparaison met en évidence des décalages entre l’information fournie et les questions réellement posées par les usagers à chaque seuil.',
          p2: 'Les simulations réalisées avec un modèle de parcours piéton ont permis de tester différentes combinaisons d’affichage. En ajustant les messages, la taille des caractères et le rythme d’apparition, nous obtenons une réduction notable des hésitations observées sur le terrain.',
          sub1: 'Vers des boucles de rétroaction',
          p3: 'Les opérateurs des halls publics ont été intégrés dans des ateliers pour commenter les scénarios produits. Leurs retours ont conduit à la création d’une boucle de rétroaction simple : collecte quotidienne de données, ajustement des contenus numériques et vérification hebdomadaire avec un panel d’usagers.',
          p4: 'Grâce à cette boucle, les halls étudiés bénéficient d’une meilleure continuité attentionnelle. Les temps d’arrêt diminuent, les flux se régulent et les espaces deviennent plus intuitifs, sans ajout massif d’équipements.'
        }
      },
      post2: {
        title: 'Signalétique numérique adaptative dans les gares intermodales',
        meta: 'Étude d’un protocole de signalétique numérique adaptative dans les gares intermodales belges, avec une attention portée aux changements de flux et aux repères sensoriels.',
        excerpt: 'Méthodologie pour concevoir une signalétique numérique adaptative dans une gare intermodale, en croisant données de flux et scénarios d’usage.',
        summary: 'Cette étude examine une gare intermodale bruxelloise et décrit la démarche adoptée pour synchroniser la signalétique numérique avec les variations d’affluence et les besoins d’accessibilité.',
        figure: 'Interface numérique affichant des correspondances en temps réel dans une gare.',
        imageAlt: 'Signalétique numérique dans une gare intermodale',
        section1: {
          title: 'Observer les rythmes intermodaux',
          p1: 'Les gares intermodales articulent trains, tramways, bus et mobilités douces. Pour saisir ces rythmes, nous avons combiné les données d’horaires, les flux en temps réel et les observations in situ. L’objectif était d’établir une base de référence capable d’indiquer précisément quand et où l’information doit se densifier.',
          p2: 'Nous avons remarqué des pics ponctuels, liés aux arrivées simultanées de plusieurs modes. Dans ces moments, l’attention des usagers se fragmente et la recherche de repères devient critique. Les cartes générées positionnent les écrans et bornes successives, montrant les redondances et les zones peu couvertes.',
          sub1: 'Cartographier les demandes d’information',
          p3: 'Les équipes de terrain ont recensé les questions les plus fréquentes posées aux guichets et aux agents mobiles. En les géolocalisant, nous avons pu relier chaque requête à une zone précise. Les besoins d’information sont ainsi priorisés : correspondances, plateformes accessibles, repères pour personnes à mobilité réduite.'
        },
        section2: {
          title: 'Concevoir une interface contextuelle',
          p1: 'Une fois la demande cartographiée, nous avons développé une interface qui adapte les contenus en fonction des flux. Les modules de la signalétique numérique se reconfigurent selon l’heure, la densité et les incidents éventuels. Cette adaptabilité évite la surcharge visuelle et renforce la pertinence des messages.',
          p2: 'Chaque module possède un état par défaut et des états de renforcement. Lorsque les flux augmentent, le contraste s’accroît, les pictogrammes se simplifient et les textes deviennent plus directs. À l’inverse, lors des périodes calmes, l’interface adopte une posture plus informative, en fournissant des détails sur les services annexes.',
          sub1: 'Assurer le pilotage quotidien',
          p3: 'Pour garantir la cohérence de l’ensemble, nous avons mis en place un tableau de bord simple destiné aux équipes locales. Ce tableau de bord agrège les données, propose des recommandations et archive les ajustements réalisés. Il constitue la mémoire du système et facilite les échanges entre services.',
          p4: 'Au terme du projet pilote, la gare intermodale dispose d’une signalétique numérique stable, capable de répondre aux variations quotidiennes tout en conservant une identité visuelle claire. Les usagers bénéficient d’une navigation plus intuitive et les équipes opérationnelles conservent la maîtrise du dispositif.'
        }
      },
      post3: {
        title: 'Accessibilité dans les réseaux de circulation verticale',
        meta: 'Étude des réseaux de circulation verticale et des repères d’accessibilité dans les bâtiments publics à forte densité verticale en Belgique.',
        excerpt: 'Analyse des ascenseurs, escaliers mécaniques et escaliers dans un complexe public, avec focus sur l’accessibilité et la lisibilité.',
        summary: 'Ce texte explore la manière d’articuler escaliers, ascenseurs et rampes pour garantir une circulation verticale inclusive au sein d’un pôle administratif.',
        figure: 'Schéma des circulations verticales dans un atrium public.',
        imageAlt: 'Circulation verticale avec escaliers et ascenseur',
        section1: {
          title: 'Cartographier les choix de trajectoire',
          p1: 'Notre intervention s’est déroulée dans un pôle administratif comprenant douze niveaux accessibles au public. Nous avons suivi des groupes d’usagers pour enregistrer leurs décisions face aux différents dispositifs verticaux. Les données collectées dévoilent une logique d’évitement des zones peu éclairées et un attrait pour les parcours offrant des repères visuels clairs.',
          p2: 'Les ascenseurs principaux concentrent la majorité des flux, créant des temps d’attente importants. À l’inverse, certains escaliers restent sous-utilisés faute de signalétique ou de perception de sécurité suffisante. Les cartes réalisées superposent l’offre existante et les trajectoires effectives.',
          sub1: 'Repères sensoriels',
          p3: 'Les repères sonores, tactiles et visuels ont été évalués. La présence d’un éclairage continu, de textures différenciées et de contrastes marqués contribue fortement à la compréhension des parcours verticaux. Ces éléments ont servi de base pour élaborer des recommandations d’orientation.'
        },
        section2: {
          title: 'Hiérarchiser les accès prioritaires',
          p1: 'Nous avons défini des parcours prioritaires reliant les services les plus fréquentés. Chaque parcours est décrit par un enchaînement d’actions simples : identifier le point de départ, repérer le support d’information, confirmer la direction et atteindre le palier cible.',
          p2: 'Cette hiérarchisation permet de clarifier la place de chaque dispositif vertical. Les ascenseurs deviennent des axes principaux, les escaliers mécaniques servent de dérivations et les escaliers traditionnels complètent la grille pour les usagers souhaitant un itinéraire alternatif.',
          sub1: 'Boucles d’amélioration continue',
          p3: 'Une démarche d’amélioration continue associe les agents d’accueil, les services techniques et des associations spécialisées. Ensemble, ils évaluent régulièrement l’efficacité des repères et ajustent la signalétique, par exemple en renforçant les contrastes ou en ajoutant des messages sonores.',
          p4: 'Les premiers retours montrent une répartition plus équilibrée des flux, une diminution des temps d’attente et une expérience plus sereine pour les personnes ayant besoin d’un guidage renforcé.'
        }
      },
      post4: {
        title: 'Cartographies narratives pour les campus institutionnels',
        meta: 'Construction de cartographies narratives pour améliorer la compréhension des campus institutionnels et accompagner les parcours quotidiens.',
        excerpt: 'Un protocole de cartographie narrative aide à situer les repères clés d’un campus institutionnel et à synchroniser les usages.',
        summary: 'Nous décrivons comment la cartographie narrative permet d’articuler identité institutionnelle, signalétique numérique et mobilités lentes sur un campus étendu.',
        figure: 'Carte narrative illustrant un campus institutionnel.',
        imageAlt: 'Cartographie narrative d’un campus institutionnel',
        section1: {
          title: 'Comprendre les trajectoires quotidiennes',
          p1: 'Le campus étudié accueille des services administratifs, des espaces d’accueil et des zones de formation. Les usagers parcourent régulièrement de longues distances entre bâtiments. L’enjeu consiste à traduire cette complexité en repères compréhensibles sans surcharger l’espace de panneaux.',
          p2: 'Nous avons conduit des marches exploratoires avec différents profils d’usagers pour identifier les repères naturels, les obstacles et les zones de confusion. Les entretiens qui ont suivi offrent une narration fine des déplacements, révélant les moments clés où un soutien informationnel est nécessaire.',
          sub1: 'Collecte d’histoires spatiales',
          p3: 'Les récits recueillis ont été transcrits sous la forme de séquences, chacune associée à une carte schématique. Cette méthode révèle les émotions, les attentes et les stratégies développées par les usagers. La dimension narrative devient un outil pour prioriser les interventions.'
        },
        section2: {
          title: 'Construire une cartographie sensible',
          p1: 'À partir des récits, nous avons conçu une cartographie narrative combinant plans vectoriels, icônes et éléments textuels. Chaque portion du campus est racontée par des mots-clés, des couleurs et des micro-illustrations qui reflètent l’identité institutionnelle.',
          p2: 'La cartographie s’accompagne de modules numériques où l’information contextuelle apparaît en fonction de la position de l’usager. Les plans imprimés et les interfaces partagent la même grammaire visuelle, assurant une cohérence d’ensemble.',
          sub1: 'Activation et appropriation',
          p3: 'Des ateliers ont permis aux équipes internes de s’approprier la cartographie et d’imaginer des scénarios d’animation. Certaines zones ont été mises en valeur par des installations temporaires, d’autres par des parcours commentés organisés avec les usagers.',
          p4: 'Cette dynamique renforce le sentiment d’orientation partagée. Les usagers se déplacent avec plus de confiance et les équipes disposent d’un support pour expliquer l’organisation du campus.'
        }
      },
      post5: {
        title: 'Mesurer les interactions piétonnes dans les quartiers gouvernementaux',
        meta: 'Analyse des interactions piétonnes dans les quartiers gouvernementaux de Bruxelles afin d’optimiser la lisibilité urbaine et la sécurité des parcours.',
        excerpt: 'Nous analysons les interactions piétonnes autour des sièges gouvernementaux pour proposer des recommandations de lisibilité et de guidage.',
        summary: 'L’étude suit les piétons dans un quartier gouvernemental et identifie les leviers de navigation visuelle et numérique nécessaires pour orchestrer les déplacements quotidiens.',
        figure: 'Graphique des interactions piétonnes près des bâtiments gouvernementaux.',
        imageAlt: 'Passants devant un bâtiment gouvernemental',
        section1: {
          title: 'Observer la dynamique urbaine',
          p1: 'Le quartier analysé regroupe des bâtiments gouvernementaux, des restaurants et des axes de transport. Les flux varient fortement entre horaires administratifs et événements ponctuels. Nous avons installé des capteurs anonymisés et réalisé des observations directes pour comprendre ces rythmes.',
          p2: 'Les données montrent des mouvements transversaux reliant les transports publics aux lieux de réunion. Certains axes restent difficiles à lire en raison de la densité des signaux visuels et de la présence de barrières temporaires.',
          sub1: 'Typologie des interactions',
          p3: 'Nous avons classé les interactions en quatre catégories : croisement rapide, regroupement, attente encadrée et orientation collaborative. Cette typologie éclaire la manière dont les piétons s’entraident pour trouver leur chemin et comment la signalétique peut soutenir ces pratiques.'
        },
        section2: {
          title: 'Mettre en place un guidage multiniveau',
          p1: 'Sur la base des observations, nous avons conçu un système de guidage combinant marquages au sol, colonnes d’information et applications web. Chaque niveau relaie des informations complémentaires, évitant les redondances tout en offrant plusieurs portes d’entrée.',
          p2: 'Le système prend en compte la nécessité de messages multilingues et de repères simples pour les visiteurs ponctuels. Les supports numériques proposent des itinéraires selon les contraintes de sécurité et les temps de déplacement.',
          sub1: 'Évaluer l’impact',
          p3: 'Un protocole d’évaluation a été mis en place avec les services de sécurité et de communication. Les indicateurs portent sur la fluidité, la compréhension et le ressenti des usagers. Les premiers relevés montrent une diminution des demandes d’orientation adressées aux agents.',
          p4: 'Ce projet ouvre la voie à une concertation continue entre services publics et citoyens afin de maintenir une lisibilité urbaine élevée dans un contexte institutionnel sensible.'
        }
      }
    },
    contact: {
      hero: {
        heading: 'Entrer en contact',
        lead: 'Nos analystes répondent aux institutions souhaitant clarifier leurs dispositifs d’orientation spatiale.'
      },
      intro: 'Nous travaillons depuis Bruxelles et intervenons dans toute la Belgique sur des projets d’espaces publics complexes.',
      address: {
        title: 'Adresse',
        text: 'Rue de la Loi 200, 1040 Bruxelles, Belgique'
      },
      phone: {
        title: 'Téléphone',
        text: '+32 2 123 45 67'
      },
      email: {
        title: 'Courriel',
        text: 'contact@danswholesaleplants.com'
      },
      hours: {
        title: 'Disponibilités',
        text: 'Du lundi au vendredi, 9h00 - 17h30 (CET).'
      },
      form: {
        title: 'Formulaire de prise de contact',
        lead: 'Merci de détailler votre contexte afin que nous puissions orienter la discussion.',
        fields: {
          name: {
            label: 'Nom complet',
            placeholder: 'Votre nom'
          },
          email: {
            label: 'Adresse électronique',
            placeholder: 'vous@organisation.be'
          },
          phone: {
            label: 'Numéro de téléphone',
            placeholder: '+32 ...'
          },
          organization: {
            label: 'Organisation',
            placeholder: 'Nom de l’entité'
          },
          message: {
            label: 'Description du contexte',
            placeholder: 'Expliquez les enjeux d’orientation rencontrés'
          }
        },
        submit: 'Envoyer la demande',
        notice: 'Les informations partagées servent uniquement à analyser votre demande et ne sont pas communiquées à des tiers.'
      },
      map: {
        caption: 'Localisation de notre base à Bruxelles'
      }
    },
    faq: {
      hero: {
        heading: 'Foire aux questions',
        lead: 'Réponses aux questions fréquemment posées par les institutions publiques belges concernant nos analyses d’orientation spatiale.'
      },
      items: {
        q1: 'Comment démarrez-vous une étude d’orientation ?',
        a1: 'Nous commençons par une immersion sur site, des entretiens avec les équipes et l’analyse des plans existants pour définir les premières hypothèses.',
        q2: 'Quels types de données collectez-vous ?',
        a2: 'Nous combinons relevés vidéo anonymisés, capteurs de comptage, observations manuelles et retours utilisateurs pour croiser les perspectives.',
        q3: 'Comment assurez-vous la prise en compte de l’accessibilité ?',
        a3: 'Un référentiel dédié reprend les critères sensoriels, les normes et les retours associatifs, ce qui permet d’intégrer l’accessibilité dès la phase d’analyse.',
        q4: 'Travaillez-vous uniquement à Bruxelles ?',
        a4: 'Nous sommes basés à Bruxelles mais intervenons sur tout le territoire belge, en adaptant nos méthodologies aux contextes locaux.',
        q5: 'Intervenez-vous sur des projets en cours de conception ?',
        a5: 'Oui, nous collaborons avec les équipes de maîtrise d’œuvre pour intégrer les questions d’orientation dès les premières phases de projet.',
        q6: 'Proposez-vous un suivi après déploiement ?',
        a6: 'Nous pouvons accompagner les équipes dans la mesure d’impact et l’ajustement des dispositifs sur la durée.'
      },
      callout: {
        title: 'Autres questions',
        text: 'Pour des cas spécifiques ou des environnements atypiques, contactez-nous directement via le formulaire.',
        button: 'Aller au formulaire de contact'
      }
    },
    terms: {
      hero: {
        heading: 'Conditions d’utilisation',
        lead: 'Ces conditions définissent le cadre d’utilisation du site dans le respect des pratiques et réglementations belges.'
      },
      lastUpdated: 'Dernière mise à jour : mars 2024.',
      sections: {
        section1: {
          title: '1. Objet',
          text: 'Le présent document précise les règles encadrant l’utilisation du site dans le but d’informer sur les travaux de danswholesaleplants liés à l’orientation spatiale.'
        },
        section2: {
          title: '2. Acceptation',
          text: 'En accédant au site, l’utilisateur accepte sans réserve ces conditions ainsi que toute modification ultérieure publiée sur cette page.'
        },
        section3: {
          title: '3. Public concerné',
          text: 'Le site s’adresse principalement aux institutions, partenaires et professionnels intéressés par les sujets d’orientation spatiale dans les espaces publics.'
        },
        section4: {
          title: '4. Accès au site',
          text: 'L’accès ne requiert aucun frais pour les utilisateurs et peut être suspendu temporairement pour maintenance ou mise à jour technique.'
        },
        section5: {
          title: '5. Propriété intellectuelle',
          text: 'Les contenus rédactionnels, visuels et cartographiques sont protégés et ne peuvent être reproduits sans autorisation écrite préalable.'
        },
        section6: {
          title: '6. Publications',
          text: 'Les articles publiés reflètent l’état des recherches au moment de leur rédaction et peuvent évoluer en fonction des projets.'
        },
        section7: {
          title: '7. Données fournies',
          text: 'Les informations transmises via les formulaires doivent être exactes afin de permettre une réponse adaptée aux demandes.'
        },
        section8: {
          title: '8. Responsabilités',
          text: 'danswholesaleplants s’efforce d’assurer l’exactitude des informations mais ne peut garantir l’absence d’erreurs ou d’omissions.'
        },
        section9: {
          title: '9. Liens externes',
          text: 'Les liens externes présents sur le site sont proposés pour convenance et n’impliquent pas de validation des contenus tiers.'
        },
        section10: {
          title: '10. Sécurité',
          text: 'Des mesures raisonnables sont mises en œuvre pour protéger le site, mais l’utilisateur est invité à se prémunir contre les risques techniques.'
        },
        section11: {
          title: '11. Modifications',
          text: 'Les conditions peuvent être mises à jour sans préavis. Les utilisateurs sont invités à les consulter régulièrement.'
        },
        section12: {
          title: '12. Droit applicable',
          text: 'Ces conditions sont régies par le droit belge et tout litige relève des juridictions de Bruxelles.'
        },
        section13: {
          title: '13. Contact',
          text: 'Toute question concernant ces conditions peut être adressée à contact@danswholesaleplants.com.'
        },
        section14: {
          title: '14. Divisibilité',
          text: 'Si une clause est déclarée nulle, les autres dispositions restent applicables.'
        }
      }
    },
    privacy: {
      hero: {
        heading: 'Politique de confidentialité',
        lead: 'Cette politique explique quelles données sont traitées lors de l’utilisation du site et comment elles sont protégées.'
      },
      sections: {
        section1: {
          title: '1. Données collectées',
          text: 'Nous collectons les informations saisies dans le formulaire de contact ainsi que des données techniques minimales pour assurer le bon fonctionnement du site.'
        },
        section2: {
          title: '2. Finalités',
          text: 'Les données servent à répondre aux demandes et à améliorer la compréhension des usages du site.'
        },
        section3: {
          title: '3. Bases légales',
          text: 'Le traitement repose sur l’intérêt légitime d’informer sur nos activités et sur le consentement explicite fourni via le formulaire.'
        },
        section4: {
          title: '4. Conservation',
          text: 'Les données de contact sont conservées le temps nécessaire à l’échange puis archivées de manière sécurisée.'
        },
        section5: {
          title: '5. Partage',
          text: 'Aucune donnée n’est partagée avec des tiers, sauf obligation légale ou accord spécifique de la personne concernée.'
        },
        section6: {
          title: '6. Droits des personnes',
          text: 'Conformément au RGPD, vous disposez d’un droit d’accès, de rectification, d’opposition et d’effacement.'
        },
        section7: {
          title: '7. Exercice des droits',
          text: 'Les demandes peuvent être adressées à contact@danswholesaleplants.com. Une réponse sera fournie dans un délai raisonnable.'
        },
        section8: {
          title: '8. Sécurité',
          text: 'Des mesures techniques et organisationnelles sont mises en place pour protéger les données contre l’accès non autorisé.'
        },
        section9: {
          title: '9. Cookies',
          text: 'Les cookies utilisés sont décrits dans la politique de cookies. Ils peuvent être configurés via le bandeau dédié.'
        },
        section10: {
          title: '10. Mise à jour',
          text: 'Cette politique peut être actualisée pour refléter les évolutions légales ou techniques. La date de révision est indiquée en tête de page.'
        }
      }
    },
    cookiesPage: {
      hero: {
        heading: 'Politique de cookies',
        lead: 'Cette page décrit les cookies utilisés sur le site et les moyens de paramétrer vos préférences.'
      },
      intro: 'Le site utilise des cookies strictement nécessaires au fonctionnement et d’autres cookies soumis à consentement.',
      usage: 'Nous mesurons uniquement des indicateurs anonymisés pour comprendre les parcours de navigation et améliorer l’ergonomie.',
      management: 'Vous pouvez gérer vos préférences à tout moment via le bandeau ou le bouton présent en pied de page.',
      table: {
        title: 'Tableau récapitulatif des cookies',
        headers: {
          name: 'Nom',
          provider: 'Fournisseur',
          type: 'Type',
          purpose: 'Finalité',
          duration: 'Durée'
        },
        rows: {
          row1: {
            name: 'site_lang',
            provider: 'danswholesaleplants',
            type: 'Nécessaire',
            purpose: 'Enregistrer la langue sélectionnée',
            duration: '12 mois'
          },
          row2: {
            name: 'cookie_consent',
            provider: 'danswholesaleplants',
            type: 'Nécessaire',
            purpose: 'Mémoriser les préférences de cookies',
            duration: '12 mois'
          },
          row3: {
            name: 'navigation_context',
            provider: 'danswholesaleplants',
            type: 'Préférences',
            purpose: 'Conserver temporairement la section consultée pour améliorer la reprise de navigation',
            duration: '24 heures'
          },
          row4: {
            name: 'analytics_view',
            provider: 'danswholesaleplants',
            type: 'Analytique',
            purpose: 'Mesurer de manière agrégée la consultation des pages',
            duration: '13 mois'
          }
        }
      },
      note: 'Les cookies de préférences et d’analytique ne sont activés qu’après votre consentement.',
      contact: 'Pour toute question relative aux cookies, écrivez à contact@danswholesaleplants.com.'
    },
    refund: {
      hero: {
        heading: 'Politique de remboursement',
        lead: 'Ce site ne propose pas de transaction commerciale mais cette politique précise la manière dont les demandes liées aux prestations sont traitées.'
      },
      sections: {
        section1: {
          title: '1. Champ d’application',
          text: 'La présente politique s’applique aux prestations de conseil et aux études menées par danswholesaleplants pour les institutions partenaires.'
        },
        section2: {
          title: '2. Absence de transactions en ligne',
          text: 'Aucune vente directe n’est effectuée via le site et aucun paiement en ligne n’est collecté.'
        },
        section3: {
          title: '3. Consultations préalables',
          text: 'Avant toute intervention, un cadrage est réalisé afin de définir précisément les livrables et éviter les incompréhensions.'
        },
        section4: {
          title: '4. Ajustements de livrables',
          text: 'Si un livrable nécessite des ajustements, ceux-ci sont discutés avec la structure commanditaire pour convenir d’un plan d’action.'
        },
        section5: {
          title: '5. Annulation de rendez-vous',
          text: 'En cas d’annulation d’un rendez-vous, les parties s’engagent à proposer rapidement une nouvelle date.'
        },
        section6: {
          title: '6. Cas exceptionnels',
          text: 'Les demandes exceptionnelles sont examinées au cas par cas pour garantir une solution équilibrée.'
        },
        section7: {
          title: '7. Délai de traitement',
          text: 'Les demandes sont traitées dans un délai raisonnable, généralement inférieur à quinze jours ouvrables.'
        },
        section8: {
          title: '8. Documentation',
          text: 'Chaque échange est documenté afin de conserver une trace claire des décisions.'
        },
        section9: {
          title: '9. Contact',
          text: 'Les questions relatives à cette politique peuvent être adressées à contact@danswholesaleplants.com.'
        },
        section10: {
          title: '10. Mise à jour',
          text: 'La politique est susceptible d’évoluer pour refléter les pratiques en cours.'
        }
      }
    },
    disclaimer: {
      hero: {
        heading: 'Clause de non-responsabilité',
        lead: 'Cette clause précise les limites de responsabilité liées aux informations publiées sur le site.'
      },
      sections: {
        section1: {
          title: 'Information',
          text: 'Les contenus sont fournis à titre informatif et ne constituent pas un avis professionnel ou juridique.'
        },
        section2: {
          title: 'Exactitude',
          text: 'Malgré le soin apporté, nous ne garantissons pas l’exhaustivité ou l’actualité permanente des informations.'
        },
        section3: {
          title: 'Utilisation des données',
          text: 'Toute utilisation des données ou méthodologies décrites se fait sous la responsabilité de l’utilisateur.'
        },
        section4: {
          title: 'Références externes',
          text: 'Les références à des sites externes ne valent pas validation de leurs contenus.'
        },
        section5: {
          title: 'Responsabilité de l’utilisateur',
          text: 'L’utilisateur reste responsable des décisions prises sur la base des informations publiées.'
        },
        section6: {
          title: 'Évolutions',
          text: 'Cette clause peut être ajustée sans préavis pour refléter l’évolution de nos pratiques.'
        }
      }
    },
    thankyou: {
      hero: {
        heading: 'Merci pour votre message',
        lead: 'Votre demande a bien été transmise. Nous reviendrons vers vous après analyse.'
      },
      action: 'Retour à l’accueil'
    },
    notFound: {
      hero: {
        heading: 'Page introuvable',
        lead: 'La ressource demandée n’existe plus ou a changé d’adresse.'
      },
      action: 'Revenir à l’accueil'
    },
    cookieBanner: {
      title: 'Gestion des cookies',
      description: 'Nous utilisons des cookies pour assurer le fonctionnement du site et améliorer l’expérience. Vous pouvez ajuster vos préférences.',
      necessary: 'Nécessaires (toujours actifs)',
      preferences: 'Préférences',
      analytics: 'Analytique',
      marketing: 'Marketing',
      accept: 'Tout accepter',
      decline: 'Tout refuser',
      save: 'Enregistrer les préférences',
      manage: 'Afficher les détails'
    },
    toasts: {
      formSuccess: 'Formulaire envoyé. Nous vous répondrons rapidement.',
      formError: 'Veuillez vérifier les champs du formulaire.'
    }
  },
  en: {
    title: {
      index: 'danswholesaleplants | Digital spatial wayfinding',
      services: 'Spatial analysis services | danswholesaleplants',
      about: 'Research profile | danswholesaleplants',
      blog: 'Spatial analysis blog | danswholesaleplants',
      post1: 'Mapping attentional thresholds in public halls | danswholesaleplants',
      post2: 'Adaptive digital signage in intermodal hubs | danswholesaleplants',
      post3: 'Accessibility within vertical circulation networks | danswholesaleplants',
      post4: 'Narrative cartographies for institutional campuses | danswholesaleplants',
      post5: 'Measuring pedestrian interactions in governmental districts | danswholesaleplants',
      contact: 'Contact | danswholesaleplants',
      faq: 'FAQ | danswholesaleplants',
      terms: 'Terms of use | danswholesaleplants',
      privacy: 'Privacy policy | danswholesaleplants',
      cookies: 'Cookie policy | danswholesaleplants',
      refund: 'Refund policy | danswholesaleplants',
      disclaimer: 'Disclaimer | danswholesaleplants',
      thankyou: 'Thank you | danswholesaleplants',
      notFound: 'Page not found | danswholesaleplants'
    },
    meta: {
      index: 'Research platform dedicated to spatial orientation, digital signage and user journeys within Belgian public buildings.',
      services: 'Overview of non-commercial spatial analysis services provided by danswholesaleplants for public environments in Belgium.',
      about: 'Background, methodology and collaborative principles guiding danswholesaleplants’ spatial wayfinding laboratory.',
      blog: 'Articles and case studies about spatial navigation, interactive mapping and accessibility.',
      post1: 'Method for mapping attentional thresholds in public halls to improve digital signage and pedestrian flows in Brussels.',
      post2: 'Approach to deliver adaptive digital signage within Belgian intermodal hubs by synchronising data and field observations.',
      post3: 'Study on vertical circulation networks and accessibility benchmarks in public administration buildings.',
      post4: 'Narrative cartography framework supporting institutional campuses and slow mobility.',
      post5: 'Assessment of pedestrian interactions around governmental buildings in Brussels to reinforce urban legibility.',
      contact: 'Contact details and form to reach danswholesaleplants in Brussels.',
      faq: 'Frequently asked questions about spatial orientation analyses conducted by danswholesaleplants.',
      terms: 'Terms of use governing access to the danswholesaleplants website.',
      privacy: 'Privacy policy explaining how personal data is collected and used by danswholesaleplants.',
      cookies: 'Cookie policy describing the cookies used on danswholesaleplants.com.',
      refund: 'Refund policy outlining how requests related to consulting engagements are handled.',
      disclaimer: 'Disclaimer describing the limitations of the information published on the site.',
      thankyou: 'Confirmation page displayed after sending a message to danswholesaleplants.',
      notFound: 'Error page displayed when the requested resource is unavailable.'
    },
    brand: {
      name: 'danswholesaleplants'
    },
    header: {
      tagline: 'Information design for complex public environments'
    },
    nav: {
      home: 'Home',
      services: 'Services',
      about: 'About',
      blog: 'Blog',
      faq: 'FAQ',
      contact: 'Contact'
    },
    buttons: {
      readMore: 'Read the analysis',
      learnMore: 'Understand the approach',
      viewAll: 'View all publications',
      openContact: 'Go to contact',
      backHome: 'Back to home',
      backContact: 'Back to contact',
      exploreBlog: 'Explore the blog',
      viewMap: 'View the map'
    },
    aria: {
      menuToggle: 'Open or close the main navigation',
      languageSwitch: 'Switch site language'
    },
    footer: {
      summary: 'Brussels-based platform dedicated to spatial orientation, digital signage and the readability of complex public environments.',
      phone: 'Phone: +32 2 123 45 67',
      email: 'Email: contact@danswholesaleplants.com',
      address: 'Rue de la Loi 200, 1040 Brussels, Belgium',
      rights: '© {year} danswholesaleplants. All rights reserved.',
      cookieLink: 'Cookie preferences',
      terms: 'Terms of use',
      privacy: 'Privacy policy',
      cookies: 'Cookie policy',
      refund: 'Refund policy',
      disclaimer: 'Disclaimer'
    },
    home: {
      hero: {
        heading: 'Mapping attentional thresholds for fluid public journeys',
        lead: 'danswholesaleplants builds spatial wayfinding diagnostics for Belgian institutions. We study the interplay between digital signage, architecture and user experience to make movements more legible.',
        point1: 'Multi-scale analysis of pedestrian trajectories in Brussels',
        point2: 'Adaptive and inclusive digital signage protocols',
        point3: 'Interactive maps integrated within public infrastructures',
        button: 'Explore our research tracks',
        secondary: 'Review our documentation',
        imageAlt: 'Digital visualization of pedestrian flows across a public hall in Brussels'
      },
      featured: {
        title: 'Complex spaces, precise readings',
        intro: 'We combine spatial data, field observation and usage scenarios to clarify high-density environments.',
        card1: {
          title: 'Behavioural cartography',
          text: 'Identify friction zones, focus points and movement rhythms across public buildings.'
        },
        card2: {
          title: 'Digital signage protocols',
          text: 'Design visual templates and dynamic logics for real-time contextual displays.'
        },
        card3: {
          title: 'Hybrid flow scenarios',
          text: 'Stage pedestrian, cycling and public transport flows to limit conflicts and reinforce legibility.'
        },
        card4: {
          title: 'Accessibility indicators',
          text: 'Assess priority journeys, inclusive continuity and intelligibility checkpoints for all audiences.'
        }
      },
      orientation: {
        title: 'Spatial orientation laboratory',
        intro: 'Our laboratory assembles sensors, qualitative observation and cartographic analysis to test distinct guidance configurations.',
        highlight1: {
          title: 'Situated sensors',
          text: 'Continuous data capture on flows, dwell times and high-density areas to specify orientation needs.'
        },
        highlight2: {
          title: 'Spatial storytelling',
          text: 'Build visual narratives linking architecture, signage and digital landmarks without overload.'
        },
        highlight3: {
          title: 'Validation loops',
          text: 'User testing, workshops with field teams and rapid iterations before deployment.'
        },
        imageAlt: 'Team analysing interactive maps inside a signage laboratory'
      },
      recommendations: {
        title: 'Structured recommendations',
        intro: 'Each assignment concludes with a hierarchy of recommendations aligning decision-makers, operators and audiences.',
        card1: {
          lead: 'Usage atlas',
          text: 'Synthetic maps representing user profiles, time slots and key interactions to guide design.'
        },
        card2: {
          lead: 'Signage matrices',
          text: 'Correspondence tables between messages, media and locations to structure coherent information systems.'
        },
        card3: {
          lead: 'Accessibility iterations',
          text: 'Successive simulations combining European standards, field feedback and sensory criteria to consolidate inclusion.'
        }
      },
      testimonials: {
        title: 'Contextual testimonials',
        intro: 'Belgian institutions engaged in transforming public spaces share the impacts they observed.',
        item1: {
          quote: 'The produced cartographies revealed underused corridors and helped redistribute flows without major works.',
          author: 'Anne-Michèle L., infrastructure manager',
          context: 'City of Brussels'
        },
        item2: {
          quote: 'The iterative testing methodology clarified signage priorities and simplified coordination between operational teams.',
          author: 'Jeroen V., mobility coordinator',
          context: 'Brussels-Capital Region'
        },
        item3: {
          quote: 'The accessibility protocol offered a shared view between architects, stewards and specialised associations.',
          author: 'Sabine D., equipment director',
          context: 'Federal cultural institution'
        }
      },
      insights: {
        title: 'Latest insights',
        intro: 'A selection of publications highlights our current research on the legibility of complex environments.',
        button: 'View all publications'
      },
      callout: {
        title: 'Question about a complex environment?',
        text: 'Our FAQ gathers recurring answers on indoor navigation, signage systems and spatial data.',
        button: 'Consult the FAQ'
      }
    },
    services: {
      hero: {
        heading: 'Spatial analysis services',
        lead: 'We support Belgian public operators in understanding user journeys and structuring appropriate wayfinding systems.'
      },
      cards: {
        card1: {
          title: 'Wayfinding diagnostics',
          text: 'Comprehensive study of entries, transitions and exits including field observation, photographic surveys and interviews with front-line teams.'
        },
        card2: {
          title: 'Interactive maps',
          text: 'Design of dynamic plans connected to institutional databases to deliver updated, contextual information.'
        },
        card3: {
          title: 'Inclusive digital signage',
          text: 'Definition of visual principles, typography and hierarchy logics for readable digital displays.'
        },
        card4: {
          title: 'Flow modelling',
          text: 'Simulation of pedestrian flows and their interaction with soft and collective mobility to reduce friction.'
        },
        card5: {
          title: 'Accessibility frameworks',
          text: 'Assessment grids integrating standards, sensory perception and user feedback to strengthen priority journeys.'
        },
        card6: {
          title: 'Post-occupancy evaluation',
          text: 'Measurement of comprehension, usage and satisfaction indicators to monitor long-term impact.'
        }
      },
      process: {
        title: 'Intervention process',
        lead: 'Each assignment follows a clear process linking data, lived experience and operational decisions.',
        steps: {
          step1: {
            title: 'Context immersion',
            text: 'Map stakeholders, identify landmarks and collect photographic traces to grasp the site’s identity.'
          },
          step2: {
            title: 'Data cartographies',
            text: 'Cross quantitative and qualitative inputs to reveal critical corridors and attention zones.'
          },
          step3: {
            title: 'Co-creating experiences',
            text: 'Targeted workshops with users and internal teams to prototype guidance scenarios.'
          },
          step4: {
            title: 'Measure and adjust',
            text: 'Controlled roll-out followed by indicator tracking to refine the devices according to feedback.'
          }
        }
      },
      principles: {
        title: 'Working principles',
        lead: 'Our interventions rely on explicit principles to guarantee a shared understanding of spatial issues.',
        items: {
          item1: {
            title: 'Transversality',
            text: 'Combine insights from architects, field operators, designers and accessibility experts.'
          },
          item2: {
            title: 'Traceability',
            text: 'Document every hypothesis, dataset and decision to ease governance.'
          },
          item3: {
            title: 'Temporal awareness',
            text: 'Consider daily and seasonal cycles to propose evolving devices.'
          }
        }
      },
      outcomes: {
        title: 'Typical deliverables',
        text: 'Deliverables are designed for re-use by internal teams and their technical partners.',
        item1: 'Annotated cartographic reports',
        item2: 'Adaptive digital signage guidelines',
        item3: 'Interactive plan tree matrices',
        item4: 'Pedestrian flow monitoring dashboards'
      },
      contactPrompt: {
        title: 'Institutional coordination',
        text: 'We collaborate with public, semi-public and associative teams seeking to clarify their publicly accessible spaces.',
        button: 'Access the contact page'
      }
    },
    about: {
      hero: {
        heading: 'About danswholesaleplants',
        lead: 'danswholesaleplants is a Brussels-based collective investigating the readability of built environments, digital signage and user journeys across public contexts.'
      },
      mission: {
        title: 'Mission',
        text1: 'We analyse relationships between architecture, pedestrian flows and digital interfaces to make journeys intuitive.',
        text2: 'Our interventions rely on sensitive observation and measurable data to co-create accessible environments.'
      },
      layers: {
        title: 'Multi-scale approach',
        lead: 'Each study combines several layers to connect detail and overall vision.',
        items: {
          item1: {
            title: 'Micro scale',
            text: 'Focus on gestures, slowdowns and micro-decisions made by users.'
          },
          item2: {
            title: 'Meso scale',
            text: 'Analyse spatial sequences, transitions and flow intersections.'
          },
          item3: {
            title: 'Macro scale',
            text: 'Understand urban networks, intermodal connections and territorial polarities.'
          }
        }
      },
      research: {
        title: 'Research protocols',
        text: 'Our protocols mix social sciences, geomatics and information design.',
        list: {
          item1: 'Participant observation and situated interviews',
          item2: 'Spatial data analysis and chronotopic studies',
          item3: 'Rapid prototyping of digital signage',
          item4: 'User testing with attention metrics'
        }
      },
      collab: {
        title: 'Collaboration',
        text1: 'We collaborate with cultural institutions, universities, transport operators and administrative services.',
        text2: 'These partnerships confront hypotheses with field realities and capture feedback.'
      },
      timeline: {
        title: 'Structural milestones',
        items: {
          item1: {
            title: '2017-2019',
            text: 'Initial exploration of readability issues in Brussels public buildings and creation of a qualitative database.'
          },
          item2: {
            title: '2020-2022',
            text: 'Development of digital analysis tools, formalisation of co-design workshops and first interactive maps.'
          },
          item3: {
            title: 'Since 2023',
            text: 'Set-up of a permanent wayfinding laboratory and expansion to other Belgian cities.'
          }
        }
      },
      values: {
        title: 'Operational values',
        items: {
          item1: {
            title: 'Attention to usage',
            text: 'Each recommendation is anchored in observed everyday practices.'
          },
          item2: {
            title: 'Information sobriety',
            text: 'We favour readable, relevant and non-invasive devices.'
          },
          item3: {
            title: 'Knowledge transfer',
            text: 'Methods are documented to facilitate handover to onsite teams.'
          }
        }
      },
      cta: {
        title: 'Continue reading',
        text: 'The blog details case studies, wayfinding metrics and cartographic tools.',
        button: 'Explore the blog'
      }
    },
    blog: {
      hero: {
        heading: 'Spatial analysis blog',
        lead: 'Field insights, methodologies and cartographies dedicated to complex public environments in Belgium.',
        note: 'Each article is grounded in field data and digital simulations.'
      },
      listing: {
        title: 'All publications',
        intro: 'Select an article to explore the detailed protocols.'
      },
      callout: {
        title: 'Need a quick overview?',
        text: 'The FAQ summarises recurring answers about our methods.',
        button: 'Visit the FAQ'
      }
    },
    posts: {
      post1: {
        title: 'Mapping attentional thresholds in public halls',
        meta: 'Method for mapping attentional thresholds in public halls to improve digital signage and pedestrian flows in Brussels.',
        excerpt: 'We describe a method to spot attentional thresholds inside public halls and use them to guide digital signage and interactive maps.',
        summary: 'The study examines dense public halls, identifies attention breaks and proposes signage levers to restore journey continuity.',
        figure: 'Heat map of attention points inside a public hall.',
        imageAlt: 'Thermal map inside a public hall',
        section1: {
          title: 'Identifying critical transition zones',
          p1: 'We started by mapping entrances, exits and circulation cores across four Brussels public halls. Each zone was observed at different times, highlighting micro-sequences of movement. Attentional thresholds appear where users interrupt their path to search for a landmark, a service or a modal connection.',
          p2: 'Photographic surveys and observation notes were combined with an analysis of sound and light signals. This sensory approach reveals contrasts that capture attention and shadow areas where information disappears. The resulting maps blend presence densities and actual trajectories, providing a solid basis for discussions with facility managers.',
          sub1: 'Typology of interruptions',
          p3: 'Attention breaks fall into three families: direction finding, information checking and coordination with other users. Each family is linked to specific locations, such as stair-lift junctions or large information screens. This typology eases the choice of the most relevant signage medium.'
        },
        section2: {
          title: 'Aligning signage and perception',
          p1: 'The second phase compares the cartography with existing devices. We analysed the height, light and readability of physical panels as well as the scripts used on digital screens. The comparison highlights gaps between the provided information and the questions actually raised at each threshold.',
          p2: 'Simulations with a pedestrian journey model allowed us to test various display combinations. By tuning messages, font sizes and appearance rhythm, we obtain a noticeable reduction in hesitation observed on site.',
          sub1: 'Towards feedback loops',
          p3: 'Public hall operators joined workshops to comment on the scenarios. Their feedback led to a simple feedback loop: daily data collection, digital content adjustment and weekly verification with a user panel.',
          p4: 'Thanks to this loop, the studied halls enjoy a better attentional continuity. Dwell times decrease, flows become more regular and spaces feel more intuitive without massive equipment additions.'
        }
      },
      post2: {
        title: 'Adaptive digital signage in intermodal hubs',
        meta: 'Approach to deliver adaptive digital signage within Belgian intermodal hubs by synchronising data and field observations.',
        excerpt: 'Methodology for designing adaptive digital signage in an intermodal hub by crossing flow data and use scenarios.',
        summary: 'This study examines a Brussels intermodal hub and outlines how digital signage can synchronise with flow variations and accessibility needs.',
        figure: 'Digital interface displaying live connections inside a transport hub.',
        imageAlt: 'Digital signage inside an intermodal hub',
        section1: {
          title: 'Observing intermodal rhythms',
          p1: 'Intermodal hubs connect trains, trams, buses and soft mobility. To capture these rhythms we combined timetable data, live flow metrics and field observations. The objective was to build a reference baseline indicating when and where information density must increase.',
          p2: 'We identified punctual peaks linked to concurrent arrivals of several modes. During those moments, user attention fragments and wayfinding becomes critical. The generated maps position screens and kiosks in sequence, exposing redundancies and under-covered areas.',
          sub1: 'Mapping information requests',
          p3: 'Field teams recorded the most frequent questions asked at desks and by mobile staff. By geo-referencing these queries we could relate each to a precise zone. Information needs are therefore prioritised: connections, accessible platforms, cues for reduced-mobility travellers.'
        },
        section2: {
          title: 'Designing a contextual interface',
          p1: 'Once demands were mapped, we developed an interface adapting content according to flows. Digital signage modules reconfigure based on time, density and potential incidents. This adaptability avoids visual overload and increases message relevance.',
          p2: 'Each module has a default state and reinforcement states. When flows surge, contrast rises, pictograms simplify and texts become more direct. During calmer periods, the interface turns more informative, detailing ancillary services.',
          sub1: 'Ensuring daily governance',
          p3: 'To keep coherence, we created a straightforward dashboard for local teams. It aggregates data, proposes recommendations and archives adjustments. It acts as the system’s memory and supports interdepartmental exchanges.',
          p4: 'At the end of the pilot, the hub benefits from stable digital signage able to respond to daily variations while keeping a clear visual identity. Users navigate more intuitively and operational teams retain control.'
        }
      },
      post3: {
        title: 'Accessibility within vertical circulation networks',
        meta: 'Study on vertical circulation networks and accessibility benchmarks in public administration buildings.',
        excerpt: 'Analyse lifts, escalators and stairs inside a public complex with a focus on accessibility and legibility.',
        summary: 'The text explores how to articulate stairs, lifts and ramps to secure inclusive vertical movement inside an administrative hub.',
        figure: 'Diagram of vertical circulation inside a public atrium.',
        imageAlt: 'Vertical circulation with stairs and lift',
        section1: {
          title: 'Mapping trajectory choices',
          p1: 'Our intervention took place in an administrative hub with twelve publicly accessible levels. We shadowed user groups to record their decisions when facing different vertical devices. The data reveals avoidance of poorly lit zones and preference for routes offering clear visual cues.',
          p2: 'Main lifts concentrate most flows, generating significant waiting times. Conversely, some staircases remain underused due to limited signage or perceived safety gaps. The produced maps overlay the existing offer and effective trajectories.',
          sub1: 'Sensory cues',
          p3: 'We assessed sound, tactile and visual cues. Continuous lighting, differentiated textures and strong contrasts greatly support the understanding of vertical journeys. These elements shaped our wayfinding recommendations.'
        },
        section2: {
          title: 'Prioritising access routes',
          p1: 'We defined priority journeys linking the busiest services. Each is described by a sequence of simple actions: identify the starting point, spot the information support, confirm direction and reach the target floor.',
          p2: 'This hierarchy clarifies the role of every vertical device. Lifts become main axes, escalators provide diversions and traditional stairs complete the grid for alternative itineraries.',
          sub1: 'Continuous improvement loops',
          p3: 'An improvement approach gathers reception staff, technical services and specialised associations. Together they periodically evaluate cues and adjust signage, for instance by reinforcing contrasts or adding audio messages.',
          p4: 'Initial feedback shows a more balanced flow distribution, reduced waiting times and a calmer experience for users needing reinforced guidance.'
        }
      },
      post4: {
        title: 'Narrative cartographies for institutional campuses',
        meta: 'Narrative cartography framework supporting institutional campuses and slow mobility.',
        excerpt: 'A narrative mapping protocol helps locate key landmarks on an institutional campus and synchronise everyday usage.',
        summary: 'We describe how narrative cartography integrates institutional identity, digital signage and slow mobility across an extensive campus.',
        figure: 'Narrative map illustrating an institutional campus.',
        imageAlt: 'Narrative map of an institutional campus',
        section1: {
          title: 'Understanding everyday trajectories',
          p1: 'The studied campus hosts administrative services, reception areas and training zones. Users frequently cover long distances between buildings. The challenge is to translate this complexity into meaningful cues without saturating the environment with panels.',
          p2: 'We conducted exploratory walks with diverse user profiles to identify natural landmarks, obstacles and confusion points. Subsequent interviews deliver a detailed narrative of movements and highlight the moments when guidance support is needed.',
          sub1: 'Collecting spatial stories',
          p3: 'The collected stories were transcribed into sequences, each linked to a schematic map. The method reveals emotions, expectations and strategies deployed by users. The narrative dimension becomes a tool to prioritise interventions.'
        },
        section2: {
          title: 'Building a sensitive cartography',
          p1: 'From the stories we designed a narrative map combining vector plans, icons and textual elements. Each campus segment is described by keywords, colours and micro-illustrations reflecting the institutional identity.',
          p2: 'The cartography is paired with digital modules that reveal contextual information according to user position. Printed plans and interfaces share the same visual grammar, ensuring coherence.',
          sub1: 'Activation and appropriation',
          p3: 'Workshops enabled internal teams to adopt the map and imagine activation scenarios. Some areas were enhanced with temporary installations, others with guided routes co-created with users.',
          p4: 'This dynamic strengthens shared orientation. Users move with greater confidence and teams gain a support to explain how the campus is organised.'
        }
      },
      post5: {
        title: 'Measuring pedestrian interactions in governmental districts',
        meta: 'Assessment of pedestrian interactions around governmental buildings in Brussels to reinforce urban legibility.',
        excerpt: 'We analyse pedestrian interactions around governmental headquarters to issue legibility and guidance recommendations.',
        summary: 'The study follows pedestrians inside a governmental district and identifies the visual and digital guidance levers required to orchestrate daily movements.',
        figure: 'Graph showing pedestrian interactions near governmental buildings.',
        imageAlt: 'Pedestrians near a governmental building',
        section1: {
          title: 'Observing urban dynamics',
          p1: 'The analysed district brings together governmental buildings, restaurants and transport axes. Flows vary strongly between administrative schedules and punctual events. We installed anonymised sensors and conducted direct observation to understand these rhythms.',
          p2: 'Data reveals transverse movements linking public transport to meeting venues. Some axes remain difficult to read because of dense visual signals and temporary barriers.',
          sub1: 'Interaction typology',
          p3: 'We classified interactions into four categories: quick crossings, group gatherings, managed waiting and collaborative wayfinding. The typology sheds light on how pedestrians support each other and how signage can reinforce these practices.'
        },
        section2: {
          title: 'Deploying multi-level guidance',
          p1: 'Based on observations we designed a guidance system combining ground markings, information columns and web applications. Each level delivers complementary information, avoiding redundancy while offering multiple entry points.',
          p2: 'The system accounts for multilingual messages and simple cues for occasional visitors. Digital supports propose itineraries compatible with security constraints and travel times.',
          sub1: 'Assessing impact',
          p3: 'An evaluation protocol was set up with security and communication services. Indicators cover flow fluidity, understanding and user perception. Early readings show fewer orientation requests addressed to staff.',
          p4: 'The project opens the way for continuous dialogue between public services and citizens to maintain high urban legibility within a sensitive institutional context.'
        }
      }
    },
    contact: {
      hero: {
        heading: 'Get in touch',
        lead: 'Our analysts respond to institutions seeking to clarify their spatial wayfinding systems.'
      },
      intro: 'We operate from Brussels and work across Belgium on complex public-space projects.',
      address: {
        title: 'Address',
        text: 'Rue de la Loi 200, 1040 Brussels, Belgium'
      },
      phone: {
        title: 'Phone',
        text: '+32 2 123 45 67'
      },
      email: {
        title: 'Email',
        text: 'contact@danswholesaleplants.com'
      },
      hours: {
        title: 'Availability',
        text: 'Monday to Friday, 9:00 - 17:30 (CET).'
      },
      form: {
        title: 'Contact form',
        lead: 'Please describe your context so we can orient the discussion.',
        fields: {
          name: {
            label: 'Full name',
            placeholder: 'Your name'
          },
          email: {
            label: 'Email address',
            placeholder: 'you@organisation.be'
          },
          phone: {
            label: 'Phone number',
            placeholder: '+32 ...'
          },
          organization: {
            label: 'Organisation',
            placeholder: 'Entity name'
          },
          message: {
            label: 'Context description',
            placeholder: 'Explain the wayfinding challenges you face'
          }
        },
        submit: 'Send request',
        notice: 'Shared information is used solely to review your request and is not passed on to third parties.'
      },
      map: {
        caption: 'Location of our base in Brussels'
      }
    },
    faq: {
      hero: {
        heading: 'Frequently asked questions',
        lead: 'Answers to frequent questions from Belgian public institutions about our spatial wayfinding analyses.'
      },
      items: {
        q1: 'How do you initiate a wayfinding study?',
        a1: 'We begin with onsite immersion, interviews with teams and review of existing plans to define the first hypotheses.',
        q2: 'What types of data do you collect?',
        a2: 'We combine anonymised video counts, sensors, manual observations and user feedback to cross perspectives.',
        q3: 'How do you address accessibility?',
        a3: 'A dedicated framework covers sensory criteria, regulations and feedback from associations, ensuring accessibility is embedded from the analysis stage.',
        q4: 'Do you only work in Brussels?',
        a4: 'We are based in Brussels but intervene across Belgium, adapting our methods to local contexts.',
        q5: 'Can you work on ongoing design projects?',
        a5: 'Yes, we collaborate with design teams to integrate wayfinding questions from the early project phases.',
        q6: 'Do you offer post-deployment follow-up?',
        a6: 'We can support teams in impact measurement and in adjusting devices over time.'
      },
      callout: {
        title: 'Other questions',
        text: 'For specific cases or atypical environments, contact us directly through the form.',
        button: 'Go to the contact form'
      }
    },
    terms: {
      hero: {
        heading: 'Terms of use',
        lead: 'These terms define the framework for using the site in line with Belgian practices and regulations.'
      },
      lastUpdated: 'Last updated: March 2024.',
      sections: {
        section1: {
          title: '1. Purpose',
          text: 'This document sets the rules governing use of the site, which informs about danswholesaleplants’ work on spatial orientation.'
        },
        section2: {
          title: '2. Acceptance',
          text: 'By accessing the site, the user accepts these terms and any later changes published on this page.'
        },
        section3: {
          title: '3. Target audience',
          text: 'The site is primarily aimed at institutions, partners and professionals interested in spatial wayfinding topics.'
        },
        section4: {
          title: '4. Site access',
          text: 'Access does not require any fee and may be temporarily suspended for maintenance or technical updates.'
        },
        section5: {
          title: '5. Intellectual property',
          text: 'Editorial, visual and cartographic content is protected and may not be reproduced without prior written permission.'
        },
        section6: {
          title: '6. Publications',
          text: 'Articles reflect the state of research at the time of writing and may evolve with new projects.'
        },
        section7: {
          title: '7. Provided data',
          text: 'Information submitted through forms must be accurate so we can respond appropriately.'
        },
        section8: {
          title: '8. Responsibilities',
          text: 'danswholesaleplants strives to ensure accuracy but cannot guarantee the absence of errors or omissions.'
        },
        section9: {
          title: '9. External links',
          text: 'External links are provided for convenience and do not imply endorsement of third-party content.'
        },
        section10: {
          title: '10. Security',
          text: 'Reasonable measures are used to protect the site, but users should guard against technical risks.'
        },
        section11: {
          title: '11. Changes',
          text: 'These terms may be updated without notice. Users are encouraged to check them regularly.'
        },
        section12: {
          title: '12. Applicable law',
          text: 'These terms are governed by Belgian law and disputes fall under Brussels jurisdiction.'
        },
        section13: {
          title: '13. Contact',
          text: 'Questions regarding these terms can be sent to contact@danswholesaleplants.com.'
        },
        section14: {
          title: '14. Severability',
          text: 'If any clause is declared void, the remaining provisions remain in force.'
        }
      }
    },
    privacy: {
      hero: {
        heading: 'Privacy policy',
        lead: 'This policy explains which data is processed when using the site and how it is protected.'
      },
      sections: {
        section1: {
          title: '1. Data collected',
          text: 'We collect information entered in the contact form and minimal technical data to ensure proper site operation.'
        },
        section2: {
          title: '2. Purposes',
          text: 'Data is used to respond to requests and improve our understanding of site usage.'
        },
        section3: {
          title: '3. Legal bases',
          text: 'Processing is based on our legitimate interest in sharing information and on explicit consent given via the form.'
        },
        section4: {
          title: '4. Retention',
          text: 'Contact data is kept for the duration of the exchange then archived securely.'
        },
        section5: {
          title: '5. Sharing',
          text: 'No data is shared with third parties unless required by law or specifically agreed with the person concerned.'
        },
        section6: {
          title: '6. Individual rights',
          text: 'Under GDPR you have rights to access, rectification, objection and erasure.'
        },
        section7: {
          title: '7. Exercising rights',
          text: 'Requests can be sent to contact@danswholesaleplants.com. A response will be provided within a reasonable timeframe.'
        },
        section8: {
          title: '8. Security',
          text: 'Technical and organisational measures protect data from unauthorised access.'
        },
        section9: {
          title: '9. Cookies',
          text: 'Cookies used are described in the cookie policy and may be configured via the dedicated banner.'
        },
        section10: {
          title: '10. Updates',
          text: 'This policy may be updated to reflect legal or technical changes. The revision date appears at the top of the page.'
        }
      }
    },
    cookiesPage: {
      hero: {
        heading: 'Cookie policy',
        lead: 'This page describes the cookies used on the site and how to manage your preferences.'
      },
      intro: 'The site uses strictly necessary cookies and additional cookies subject to consent.',
      usage: 'We only measure anonymised indicators to understand navigation paths and improve ergonomics.',
      management: 'You can manage your preferences at any time through the banner or the footer button.',
      table: {
        title: 'Cookie overview',
        headers: {
          name: 'Name',
          provider: 'Provider',
          type: 'Type',
          purpose: 'Purpose',
          duration: 'Duration'
        },
        rows: {
          row1: {
            name: 'site_lang',
            provider: 'danswholesaleplants',
            type: 'Necessary',
            purpose: 'Store the selected language',
            duration: '12 months'
          },
          row2: {
            name: 'cookie_consent',
            provider: 'danswholesaleplants',
            type: 'Necessary',
            purpose: 'Remember cookie preferences',
            duration: '12 months'
          },
          row3: {
            name: 'navigation_context',
            provider: 'danswholesaleplants',
            type: 'Preferences',
            purpose: 'Temporarily store the visited section to improve navigation recovery',
            duration: '24 hours'
          },
          row4: {
            name: 'analytics_view',
            provider: 'danswholesaleplants',
            type: 'Analytics',
            purpose: 'Measure page consultation in aggregate form',
            duration: '13 months'
          }
        }
      },
      note: 'Preference and analytics cookies are activated only after you provide consent.',
      contact: 'For any cookie-related question, contact: contact@danswholesaleplants.com.'
    },
    refund: {
      hero: {
        heading: 'Refund policy',
        lead: 'The site does not facilitate commercial transactions, yet this policy explains how requests linked to consulting engagements are handled.'
      },
      sections: {
        section1: {
          title: '1. Scope',
          text: 'This policy applies to consulting and studies delivered by danswholesaleplants for partner institutions.'
        },
        section2: {
          title: '2. No online transactions',
          text: 'No direct sale is made through the site and no online payment is collected.'
        },
        section3: {
          title: '3. Preliminary briefings',
          text: 'Before any intervention, a scoping phase defines deliverables to avoid misunderstandings.'
        },
        section4: {
          title: '4. Deliverable adjustments',
          text: 'If a deliverable needs adjustments, they are discussed with the commissioning structure to build an action plan.'
        },
        section5: {
          title: '5. Meeting cancellation',
          text: 'In case of a cancelled meeting, parties agree to propose a new date promptly.'
        },
        section6: {
          title: '6. Exceptional cases',
          text: 'Exceptional requests are reviewed individually to ensure a balanced solution.'
        },
        section7: {
          title: '7. Processing time',
          text: 'Requests are handled within a reasonable time, generally under fifteen business days.'
        },
        section8: {
          title: '8. Documentation',
          text: 'Each exchange is documented to keep a clear record of decisions.'
        },
        section9: {
          title: '9. Contact',
          text: 'Questions about this policy can be sent to contact@danswholesaleplants.com.'
        },
        section10: {
          title: '10. Updates',
          text: 'This policy may evolve to reflect current practices.'
        }
      }
    },
    disclaimer: {
      hero: {
        heading: 'Disclaimer',
        lead: 'This statement clarifies the limits of responsibility regarding the information published on the site.'
      },
      sections: {
        section1: {
          title: 'Information',
          text: 'Content is provided for information purposes and does not constitute professional or legal advice.'
        },
        section2: {
          title: 'Accuracy',
          text: 'Despite careful attention we do not guarantee permanent completeness or accuracy.'
        },
        section3: {
          title: 'Data use',
          text: 'Any use of the described data or methods remains under the user’s responsibility.'
        },
        section4: {
          title: 'External references',
          text: 'References to external sites do not imply endorsement of their content.'
        },
        section5: {
          title: 'User responsibility',
          text: 'Users remain responsible for decisions made using the published information.'
        },
        section6: {
          title: 'Updates',
          text: 'This disclaimer may be adjusted without notice to reflect evolving practices.'
        }
      }
    },
    thankyou: {
      hero: {
        heading: 'Thank you for your message',
        lead: 'Your request has been received. We will get back to you after review.'
      },
      action: 'Back to home'
    },
    notFound: {
      hero: {
        heading: 'Page not found',
        lead: 'The requested resource no longer exists or has moved.',
        action: 'Return home'
      },
      action: 'Return home'
    },
    cookieBanner: {
      title: 'Cookie management',
      description: 'We use cookies to ensure site operation and enhance your experience. Adjust your preferences below.',
      necessary: 'Necessary (always on)',
      preferences: 'Preferences',
      analytics: 'Analytics',
      marketing: 'Marketing',
      accept: 'Accept all',
      decline: 'Decline all',
      save: 'Save preferences',
      manage: 'Show details'
    },
    toasts: {
      formSuccess: 'Form submitted. We will reply shortly.',
      formError: 'Please check the form fields.'
    }
  }
};

let currentLang = DEFAULT_LANG;
let consentState = null;

function getTranslation(dictionary, path) {
  if (!dictionary || !path) return undefined;
  return path.split('.').reduce((accumulator, key) => (accumulator && Object.prototype.hasOwnProperty.call(accumulator, key) ? accumulator[key] : undefined), dictionary);
}

function formatValue(value) {
  if (typeof value === 'string') {
    return value.replace('{year}', String(new Date().getFullYear()));
  }
  return value;
}

function applyLanguage(lang) {
  const dictionary = I18N[lang] ? I18N[lang] : I18N[DEFAULT_LANG];
  currentLang = lang;
  try {
    localStorage.setItem(LANG_STORAGE_KEY, lang);
  } catch (error) {
    /* ignore storage errors */
  }
  setCookie('site_lang', lang, 365);
  document.documentElement.lang = lang;

  const titleElements = document.querySelectorAll('title[data-i18n-title]');
  titleElements.forEach((titleElement) => {
    const key = titleElement.dataset.i18nTitle;
    const translation = formatValue(getTranslation(dictionary, key));
    if (translation !== undefined) {
      titleElement.textContent = translation;
      document.title = translation;
    }
  });

  const metaElements = document.querySelectorAll('meta[data-i18n-meta]');
  metaElements.forEach((meta) => {
    const key = meta.dataset.i18nMeta;
    const translation = formatValue(getTranslation(dictionary, key));
    if (translation !== undefined) {
      meta.setAttribute('content', translation);
    }
  });

  const textElements = document.querySelectorAll('[data-i18n]');
  textElements.forEach((element) => {
    const key = element.dataset.i18n;
    const translation = formatValue(getTranslation(dictionary, key));
    if (translation !== undefined) {
      element.textContent = translation;
    }
  });

  const placeholderElements = document.querySelectorAll('[data-i18n-placeholder]');
  placeholderElements.forEach((element) => {
    const key = element.dataset.i18nPlaceholder;
    const translation = formatValue(getTranslation(dictionary, key));
    if (translation !== undefined) {
      element.setAttribute('placeholder', translation);
    }
  });

  const altElements = document.querySelectorAll('[data-i18n-alt]');
  altElements.forEach((element) => {
    const key = element.dataset.i18nAlt;
    const translation = formatValue(getTranslation(dictionary, key));
    if (translation !== undefined) {
      element.setAttribute('alt', translation);
    }
  });

  const ariaElements = document.querySelectorAll('[data-i18n-aria]');
  ariaElements.forEach((element) => {
    const key = element.dataset.i18nAria;
    const translation = formatValue(getTranslation(dictionary, key));
    if (translation !== undefined) {
      element.setAttribute('aria-label', translation);
    }
  });

  updateLanguageButtons(lang);
}

function updateLanguageButtons(lang) {
  const buttons = document.querySelectorAll('[data-lang]');
  buttons.forEach((button) => {
    button.classList.toggle('active', button.dataset.lang === lang);
  });
}

function setupLanguageSwitch() {
  const buttons = document.querySelectorAll('[data-lang]');
  buttons.forEach((button) => {
    button.addEventListener('click', () => {
      const lang = button.dataset.lang;
      applyLanguage(lang);
    });
  });
}

function highlightActiveNav() {
  const pageKey = document.body.dataset.page;
  const navLinks = document.querySelectorAll('.nav-links a');
  navLinks.forEach((link) => {
    link.classList.toggle('active', link.dataset.nav === pageKey);
  });
}

function setupNavigation() {
  const nav = document.querySelector('.primary-nav');
  const toggle = document.querySelector('.menu-toggle');
  if (!nav || !toggle) return;

  const closeNav = () => {
    nav.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
  };

  toggle.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
  });

  const navLinks = nav.querySelectorAll('.nav-links a');
  navLinks.forEach((link) => {
    link.addEventListener('click', () => {
      closeNav();
    });
  });

  document.addEventListener('click', (event) => {
    if (!nav.contains(event.target) && !toggle.contains(event.target)) {
      closeNav();
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      closeNav();
    }
  });
}

function setupFadeObserver() {
  const fadeItems = document.querySelectorAll('.fade-item');
  if (!('IntersectionObserver' in window) || fadeItems.length === 0) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  fadeItems.forEach((item) => observer.observe(item));
}

function loadConsent() {
  try {
    const stored = localStorage.getItem(CONSENT_STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      return { ...getDefaultConsent(), ...parsed };
    }
  } catch (error) {
    return getDefaultConsent();
  }
  return getDefaultConsent();
}

function getDefaultConsent() {
  return {
    necessary: true,
    preferences: false,
    analytics: false,
    marketing: false,
    confirmed: false,
    updatedAt: new Date().toISOString()
  };
}

function persistConsent(state) {
  const base = { ...getDefaultConsent(), ...state };
  try {
    localStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify(base));
  } catch (error) {
    /* ignore storage errors */
  }
  setCookie('cookie_consent', JSON.stringify({
    preferences: base.preferences,
    analytics: base.analytics,
    marketing: base.marketing,
    confirmed: base.confirmed
  }), 365);
  consentState = base;
}

function updateToggleUI(toggles, state) {
  toggles.forEach((toggle) => {
    const key = toggle.dataset.consentToggle;
    if (key && Object.prototype.hasOwnProperty.call(state, key)) {
      toggle.checked = Boolean(state[key]);
    }
  });
}

function updateConsentState(state, key, value) {
  const nextState = state ? { ...state } : getDefaultConsent();
  if (key !== 'necessary') {
    nextState[key] = value;
  }
  nextState.updatedAt = new Date().toISOString();
  return nextState;
}

function showBanner(banner) {
  if (banner) {
    banner.dataset.visible = 'true';
  }
}

function hideBanner(banner) {
  if (banner) {
    banner.dataset.visible = 'false';
  }
}

function setCookie(name, value, days) {
  let expires = '';
  if (typeof days === 'number') {
    const date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    expires = '; expires=' + date.toUTCString();
  }
  document.cookie = `${name}=${encodeURIComponent(value)}${expires}; path=/`;
}

function deleteCookie(name) {
  document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
}

function updateOptionalCookies(state) {
  if (state.preferences) {
    setCookie('navigation_context', document.body.dataset.page || 'home', 1);
  } else {
    deleteCookie('navigation_context');
  }
  if (state.analytics) {
    setCookie('analytics_view', String(Date.now()), 395);
  } else {
    deleteCookie('analytics_view');
  }
  if (state.marketing === false) {
    deleteCookie('marketing_token');
  }
}

function initCookieBanner() {
  const banner = document.querySelector('[data-cookie-banner]');
  if (!banner) return;

  const panel = banner.querySelector('[data-cookie-panel]');
  const manageButton = banner.querySelector('[data-cookie-manage]');
  const acceptButton = banner.querySelector('[data-cookie-accept]');
  const declineButton = banner.querySelector('[data-cookie-decline]');
  const saveButton = banner.querySelector('[data-cookie-save]');
  const toggles = banner.querySelectorAll('[data-consent-toggle]');
  const footerButton = document.querySelector('[data-cookie-open]');

  consentState = loadConsent();
  updateToggleUI(toggles, consentState);

  if (consentState.confirmed) {
    hideBanner(banner);
    updateOptionalCookies(consentState);
  } else {
    showBanner(banner);
  }

  toggles.forEach((toggle) => {
    if (toggle.disabled) return;
    toggle.addEventListener('change', () => {
      const key = toggle.dataset.consentToggle;
      const checked = toggle.checked;
      consentState = updateConsentState(consentState, key, checked);
      persistConsent(consentState);
    });
  });

  manageButton?.setAttribute('aria-expanded', panel && panel.hasAttribute('hidden') ? 'false' : 'true');
  manageButton?.addEventListener('click', () => {
    if (!panel) return;
    if (panel.hasAttribute('hidden')) {
      panel.removeAttribute('hidden');
      manageButton.setAttribute('aria-expanded', 'true');
    } else {
      panel.setAttribute('hidden', '');
      manageButton.setAttribute('aria-expanded', 'false');
    }
  });

  acceptButton?.addEventListener('click', () => {
    const updated = {
      necessary: true,
      preferences: true,
      analytics: true,
      marketing: true,
      confirmed: true,
      updatedAt: new Date().toISOString()
    };
    persistConsent(updated);
    updateToggleUI(toggles, updated);
    updateOptionalCookies(updated);
    hideBanner(banner);
  });

  declineButton?.addEventListener('click', () => {
    const updated = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      confirmed: true,
      updatedAt: new Date().toISOString()
    };
    persistConsent(updated);
    updateToggleUI(toggles, updated);
    updateOptionalCookies(updated);
    hideBanner(banner);
  });

  saveButton?.addEventListener('click', () => {
    const updated = {
      necessary: true,
      preferences: Boolean(banner.querySelector('[data-consent-toggle="preferences"]')?.checked),
      analytics: Boolean(banner.querySelector('[data-consent-toggle="analytics"]')?.checked),
      marketing: Boolean(banner.querySelector('[data-consent-toggle="marketing"]')?.checked),
      confirmed: true,
      updatedAt: new Date().toISOString()
    };
    persistConsent(updated);
    updateToggleUI(toggles, updated);
    updateOptionalCookies(updated);
    hideBanner(banner);
  });

  footerButton?.addEventListener('click', () => {
    showBanner(banner);
    if (panel) {
      panel.removeAttribute('hidden');
      manageButton?.setAttribute('aria-expanded', 'true');
    }
  });
}

function showToast(message, type = '') {
  if (!message) return;
  let container = document.querySelector('[data-toast-container]');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    container.dataset.toastContainer = '';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add('hide');
    toast.remove();
  }, 4500);
}

function initContactForm() {
  const form = document.querySelector('[data-contact-form]');
  if (!form) return;

  form.addEventListener('submit', (event) => {
    if (!form.checkValidity()) {
      event.preventDefault();
      form.reportValidity();
      const errorMessage = formatValue(getTranslation(I18N[currentLang], 'toasts.formError'));
      showToast(errorMessage, 'error');
      return;
    }
    event.preventDefault();
    const successMessage = formatValue(getTranslation(I18N[currentLang], 'toasts.formSuccess'));
    showToast(successMessage, 'success');
    setTimeout(() => {
      form.submit();
    }, 900);
  });
}

function initialiseLanguage() {
  let initialLang = DEFAULT_LANG;
  try {
    const storedLang = localStorage.getItem(LANG_STORAGE_KEY);
    if (storedLang && I18N[storedLang]) {
      initialLang = storedLang;
    } else if (navigator.language && navigator.language.toLowerCase().startsWith('en')) {
      initialLang = 'en';
    }
  } catch (error) {
    if (navigator.language && navigator.language.toLowerCase().startsWith('en')) {
      initialLang = 'en';
    }
  }
  applyLanguage(initialLang);
}

document.addEventListener('DOMContentLoaded', () => {
  initialiseLanguage();
  setupLanguageSwitch();
  setupNavigation();
  highlightActiveNav();
  setupFadeObserver();
  initCookieBanner();
  initContactForm();
});