document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-link');

    if (navToggle) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-active');
            siteNav.classList.toggle('is-open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (siteNav.classList.contains('is-open')) {
                    siteNav.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const cookieButtons = document.querySelectorAll('[data-cookie-choice]');

    if (cookieBanner) {
        const storedChoice = localStorage.getItem('du_cookie_choice');
        if (!storedChoice) {
            cookieBanner.classList.add('is-visible');
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const choice = button.getAttribute('data-cookie-choice');
                localStorage.setItem('du_cookie_choice', choice);
                cookieBanner.classList.remove('is-visible');
                window.open('cookies.html', '_blank', 'noopener');
            });
        });
    }
});