document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-navigation');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            primaryNav.classList.toggle('is-open');
        });

        const navLinks = primaryNav.querySelectorAll('a');
        navLinks.forEach((link) => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                primaryNav.classList.remove('is-open');
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 1024) {
                navToggle.setAttribute('aria-expanded', 'false');
                primaryNav.classList.remove('is-open');
            }
        });
    }

    const consentKey = 'hingejrknfCookieConsent';
    const cookieBanner = document.querySelector('.cookie-banner');

    if (cookieBanner) {
        let storedConsent = null;
        try {
            storedConsent = localStorage.getItem(consentKey);
        } catch (error) {
            storedConsent = null;
        }

        if (!storedConsent) {
            cookieBanner.classList.add('is-visible');
        }

        const acceptBtn = cookieBanner.querySelector('[data-cookie-action="accept"]');
        const declineBtn = cookieBanner.querySelector('[data-cookie-action="decline"]');

        const setConsent = (value) => {
            try {
                localStorage.setItem(consentKey, value);
            } catch (error) {
                // ignore storage errors
            }
            cookieBanner.classList.remove('is-visible');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => setConsent('accepted'));
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => setConsent('declined'));
        }
    }
});