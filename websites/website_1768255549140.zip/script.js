(function() {
    const banner = document.getElementById('cookieBanner');
    if (!banner) return;

    const consent = localStorage.getItem('bacchiphroCookieConsent');
    if (!consent) {
        banner.classList.add('active');
    }

    banner.addEventListener('click', function(event) {
        const action = event.target.getAttribute('data-action');
        if (!action) return;

        if (action === 'accept') {
            localStorage.setItem('bacchiphroCookieConsent', 'accepted');
        }

        if (action === 'decline') {
            localStorage.setItem('bacchiphroCookieConsent', 'declined');
        }

        banner.classList.remove('active');
    });
})();