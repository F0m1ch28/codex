import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.brand}>
        <span className={styles.logo}>TechSolutions</span>
        <p className={styles.description}>
          IT-консалтинг и разработка программного обеспечения для компаний, которые стремятся к цифровому лидерству.
        </p>
        <div className={styles.contacts}>
          <a href="tel:+74951234567" className={styles.contactLink}>
            +7 (495) 123-45-67
          </a>
          <a href="mailto:info@techsolutions.ru" className={styles.contactLink}>
            info@techsolutions.ru
          </a>
          <p className={styles.address}>
            123060, г. Москва, ул. Маршала Катукова, д. 16, корп. 3, БЦ &laquo;Катуков Плаза&raquo;, офис 405
          </p>
        </div>
      </div>
      <div className={styles.links}>
        <div>
          <h4 className={styles.heading}>Разделы</h4>
          <NavLink to="/" className={styles.link}>
            Главная
          </NavLink>
          <NavLink to="/uslugi" className={styles.link}>
            Услуги
          </NavLink>
          <NavLink to="/kejsy" className={styles.link}>
            Кейсы
          </NavLink>
          <NavLink to="/blog" className={styles.link}>
            Блог
          </NavLink>
        </div>
        <div>
          <h4 className={styles.heading}>Юридическая информация</h4>
          <NavLink to="/pravila" className={styles.link}>
            Правила использования
          </NavLink>
          <NavLink to="/konfidencialnost" className={styles.link}>
            Политика конфиденциальности
          </NavLink>
          <NavLink to="/politika-cookie" className={styles.link}>
            Политика Cookie
          </NavLink>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} TechSolutions. Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;