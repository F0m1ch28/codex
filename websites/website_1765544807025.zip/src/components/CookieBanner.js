import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    try {
      const storedChoice = localStorage.getItem('techsolutions-cookie-consent');
      if (!storedChoice) {
        setIsVisible(true);
      }
    } catch {
      setIsVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    try {
      localStorage.setItem('techsolutions-cookie-consent', choice);
    } catch {
      // ignore
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о Cookie">
      <p className={styles.text}>
        Мы используем файлы cookie, чтобы сделать работу сайта удобнее и безопаснее. Продолжая пользоваться сайтом, вы
        соглашаетесь с условиями обработки данных.
      </p>
      <div className={styles.actions}>
        <button className={styles.accept} type="button" onClick={() => handleChoice('accepted')}>
          Принять
        </button>
        <button className={styles.decline} type="button" onClick={() => handleChoice('declined')}>
          Отклонить
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;