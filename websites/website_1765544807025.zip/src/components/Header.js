import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => {
    setMenuOpen((prev) => !prev);
  };

  const handleClose = () => {
    setMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} onClick={handleClose} aria-label="TechSolutions">
          TechSolutions
        </NavLink>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Основная навигация">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.activeLink : ''}`
            }
            onClick={handleClose}
          >
            Главная
          </NavLink>
          <NavLink
            to="/uslugi"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.activeLink : ''}`
            }
            onClick={handleClose}
          >
            Услуги
          </NavLink>
          <NavLink
            to="/o-kompanii"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.activeLink : ''}`
            }
            onClick={handleClose}
          >
            О компании
          </NavLink>
          <NavLink
            to="/kejsy"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.activeLink : ''}`
            }
            onClick={handleClose}
          >
            Кейсы
          </NavLink>
          <NavLink
            to="/blog"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.activeLink : ''}`
            }
            onClick={handleClose}
          >
            Блог
          </NavLink>
          <NavLink
            to="/kontakty"
            className={({ isActive }) =>
              `${styles.navLink} ${isActive ? styles.activeLink : ''}`
            }
            onClick={handleClose}
          >
            Контакты
          </NavLink>
        </nav>
        <button
          className={styles.mobileToggle}
          type="button"
          onClick={handleToggle}
          aria-expanded={menuOpen}
          aria-controls="mobile-nav"
          aria-label="Меню"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;