import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contacts.module.css';

const initialForm = {
  name: '',
  email: '',
  company: '',
  message: '',
  agreement: false,
};

const Contacts = () => {
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Пожалуйста, введите имя.';
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите рабочий email.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/u.test(formData.email.trim())) {
      newErrors.email = 'Проверьте корректность email.';
    }
    if (!formData.message.trim()) newErrors.message = 'Опишите задачу или вопрос.';
    if (!formData.agreement) newErrors.agreement = 'Необходимо согласие на обработку данных.';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      setStatus('');
      return;
    }
    setErrors({});
    setStatus('Спасибо! Мы свяжемся с вами в течение двух рабочих дней.');
    setFormData(initialForm);
  };

  return (
    <>
      <Helmet>
        <title>Свяжитесь с TechSolutions — контакты</title>
        <meta
          name="description"
          content="Контакты TechSolutions: адрес в Москве, телефон, email. Оставьте заявку на консультацию по IT-консалтингу или разработке."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.container}>
          <h1>Контакты</h1>
          <p>
            Мы открыты к новым проектам и инициативам. Заполните форму или свяжитесь с нами удобным способом — команда
            ответит в ближайшее время.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className={styles.containerGrid}>
          <div className={styles.info}>
            <h2>Офис в Москве</h2>
            <p className={styles.address}>
              123060, г. Москва, ул. Маршала Катукова, д. 16, корп. 3, БЦ &laquo;Катуков Плаза&raquo;, офис 405
            </p>
            <div className={styles.infoList}>
              <div>
                <span>Телефон</span>
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </div>
              <div>
                <span>Email</span>
                <a href="mailto:info@techsolutions.ru">info@techsolutions.ru</a>
              </div>
            </div>
            <div className={styles.mapWrapper}>
              <img
                src="https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&w=900&q=80"
                alt="Офис TechSolutions в Москве"
              />
            </div>
          </div>
          <div className={styles.formWrapper}>
            <h2>Оставьте заявку</h2>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <label htmlFor="name">
                Имя и фамилия
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                  placeholder="Например, Анна Иванова"
                />
                {errors.name && (
                  <span id="name-error" className={styles.error}>
                    {errors.name}
                  </span>
                )}
              </label>
              <label htmlFor="email">
                Рабочий email
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                  placeholder="name@company.ru"
                />
                {errors.email && (
                  <span id="email-error" className={styles.error}>
                    {errors.email}
                  </span>
                )}
              </label>
              <label htmlFor="company">
                Компания
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="Название вашей компании"
                />
              </label>
              <label htmlFor="message">
                Опишите задачу
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                  placeholder="Рассказать о проекте, сроках и ключевых ожиданиях"
                />
                {errors.message && (
                  <span id="message-error" className={styles.error}>
                    {errors.message}
                  </span>
                )}
              </label>
              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  name="agreement"
                  checked={formData.agreement}
                  onChange={handleChange}
                />
                <span>
                  Согласен(а) на обработку персональных данных и получение коммуникаций от TechSolutions.
                </span>
              </label>
              {errors.agreement && <span className={styles.error}>{errors.agreement}</span>}
              <button type="submit" className={styles.submitButton}>
                Отправить запрос
              </button>
              {status && <p className={styles.status}>{status}</p>}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contacts;