import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CaseStudies.module.css';

const cases = [
  {
    title: 'Внедрение CRM для ритейла',
    industry: 'Ритейл',
    challenge:
      'Необходимость объединить данные офлайн и онлайн продаж, обеспечить единый профиль клиента и автоматизировать персонализацию кампаний.',
    solution:
      'Спроектирована модульная CRM с интеграцией ERP и e-commerce платформы, разработаны клиентские сегменты и сквозная аналитика.',
    result: [
      'Рост повторных покупок на 32% за 6 месяцев',
      '99,8% доступность системы в период акций',
      'Автоматизация 18 маркетинговых сценариев',
    ],
    image: 'https://images.unsplash.com/photo-1515165562835-c4c23cd7ddc3?auto=format&fit=crop&w=1100&q=80',
  },
  {
    title: 'Разработка мобильного приложения для логистики',
    industry: 'Логистика',
    challenge:
      'Быстро растущая логистическая сеть требовала контроля SLA и онлайн мониторинга перевозок для диспетчеров и клиентов.',
    solution:
      'Создано мобильное приложение с GPS-трекингом, push-уведомлениями и аналитикой, настроены интеграции с TMS и BI.',
    result: [
      'Сокращение времени обработки заказа на 18%',
      'Повышение удовлетворенности клиентов на 21%',
      'Прозрачность статусов доставки в режиме реального времени',
    ],
    image: 'https://images.unsplash.com/photo-1549921296-3b4a4f3d7c6b?auto=format&fit=crop&w=1100&q=80',
  },
  {
    title: 'Миграция в облако для финансового сектора',
    industry: 'Банковские услуги',
    challenge:
      'Доработанные локальные системы не масштабировались. Требовалось обеспечить устойчивость и безопасность, сохранив контроль над затратами.',
    solution:
      'Реализована поэтапная миграция критичных сервисов в гибридное облако, внедрены DevSecOps практики и мониторинг.',
    result: [
      'Снижение расходов на инфраструктуру на 27%',
      'Ускорение вывода обновлений с 2 недель до 3 дней',
      'Соответствие требованиям регуляторов по безопасности',
    ],
    image: 'https://images.unsplash.com/photo-1518544889280-99b26fd1171f?auto=format&fit=crop&w=1100&q=80',
  },
];

const CaseStudies = () => (
  <>
    <Helmet>
      <title>Кейсы TechSolutions — успешные проекты</title>
      <meta
        name="description"
        content="Кейсы TechSolutions: внедрение CRM для ритейла, разработка мобильного приложения для логистики, миграция в облако для финансового сектора."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.container}>
        <h1>Решения, подтвержденные результатами</h1>
        <p>
          Мы реализуем проекты для компаний разного масштаба — от динамичных стартапов до крупных корпораций. Ниже —
          примеры того, как мы помогаем достигать стратегических целей.
        </p>
      </div>
    </section>
    <section className={styles.list}>
      <div className={styles.container}>
        {cases.map((caseItem) => (
          <article key={caseItem.title} className={styles.case}>
            <div className={styles.caseImage}>
              <img src={caseItem.image} alt={caseItem.title} />
            </div>
            <div className={styles.caseContent}>
              <span className={styles.industry}>{caseItem.industry}</span>
              <h2>{caseItem.title}</h2>
              <div className={styles.caseDetail}>
                <h3>Задача</h3>
                <p>{caseItem.challenge}</p>
              </div>
              <div className={styles.caseDetail}>
                <h3>Решение</h3>
                <p>{caseItem.solution}</p>
              </div>
              <div className={styles.caseDetail}>
                <h3>Результаты</h3>
                <ul>
                  {caseItem.result.map((result) => (
                    <li key={result}>{result}</li>
                  ))}
                </ul>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default CaseStudies;