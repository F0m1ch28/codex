import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const milestones = [
  {
    year: '2010',
    title: 'Основание TechSolutions',
    description: 'Команда архитекторов и консультантов объединилась для запуска компании в Москве.',
  },
  {
    year: '2015',
    title: 'Фокус на цифровые платформы',
    description: 'Запустили направление разработки корпоративных платформ и мобильных приложений.',
  },
  {
    year: '2019',
    title: 'Выход на облачные услуги',
    description: 'Сформировали центр компетенций по облачной инфраструктуре и DevOps.',
  },
  {
    year: '2023',
    title: 'Инновации и AI',
    description: 'Интегрировали AI и аналитику данных в портфель решений для клиентов из разных отраслей.',
  },
];

const team = [
  {
    name: 'Екатерина Мельникова',
    role: 'Директор по консалтингу',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80',
  },
  {
    name: 'Сергей Колесников',
    role: 'Технический директор',
    image: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=600&q=80',
  },
  {
    name: 'Марина Королёва',
    role: 'Руководитель направления кибербезопасности',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80&sat=-100',
  },
  {
    name: 'Алексей Громов',
    role: 'Lead Solution Architect',
    image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=600&q=80',
  },
];

const About = () => (
  <>
    <Helmet>
      <title>О компании TechSolutions</title>
      <meta
        name="description"
        content="TechSolutions — команда экспертов в области IT-консалтинга, разработки ПО и цифровой трансформации с офисом в Москве."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.container}>
        <h1>TechSolutions — команда технологических лидеров</h1>
        <p>
          Мы создаем комплексные решения для компаний, которые хотят быстрее адаптироваться к изменениям рынка. Наша
          экспертиза охватывает стратегический консалтинг, архитектуру, разработку, DevOps и кибербезопасность.
        </p>
      </div>
    </section>

    <section className={styles.values}>
      <div className={styles.container}>
        <h2>Наш подход</h2>
        <div className={styles.valuesGrid}>
          <div className={styles.valueCard}>
            <h3>Лидерство через партнерство</h3>
            <p>
              Мы вовлекаем ключевые команды заказчика в каждый этап проекта, обеспечивая прозрачность и передачу знаний.
            </p>
          </div>
          <div className={styles.valueCard}>
            <h3>Стабильность решений</h3>
            <p>
              Создаем архитектуру, которая выдерживает рост нагрузки и обеспечивает отказоустойчивость даже в пиковые
              периоды.
            </p>
          </div>
          <div className={styles.valueCard}>
            <h3>Ответственность за результат</h3>
            <p>
              Фокусируемся на бизнес-эффекте: рост выручки, повышение эффективности, снижение затрат и рисков.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.milestones}>
      <div className={styles.container}>
        <h2>Ключевые вехи</h2>
        <div className={styles.timeline}>
          {milestones.map((item) => (
            <article key={item.year} className={styles.timelineItem}>
              <span className={styles.year}>{item.year}</span>
              <div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <div className={styles.container}>
        <h2>Руководящая команда</h2>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`Фото: ${member.name}`} />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.statement}>
      <div className={styles.container}>
        <blockquote>
          <p>
            «Мы верим, что технологии должны быть источником устойчивого роста. Поэтому каждое решение TechSolutions
            строится на принципах прозрачности, безопасности и стремления к бизнес-эффекту».
          </p>
          <cite>— Команда TechSolutions</cite>
        </blockquote>
      </div>
    </section>
  </>
);

export default About;