import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'IT-консалтинг',
    description:
      'Комплексный аудит IT-ландшафта, стратегическое планирование, разработка дорожной карты цифровых инициатив и контроль реализации.',
    points: [
      'Анализ бизнес-процессов и KPI',
      'Оптимизация портфеля проектов',
      'Рекомендации по архитектуре и технологиям',
    ],
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1000&q=80',
  },
  {
    title: 'Разработка программного обеспечения',
    description:
      'Создаем кастомные решения для сложных бизнес-задач: корпоративные порталы, интеграционные шины, мобильные приложения и аналитические платформы.',
    points: [
      'Микросервисная архитектура',
      'CI/CD и автоматизация тестирования',
      'Интеграция с существующими системами',
    ],
    image: 'https://images.unsplash.com/photo-1518779578993-ec3579fee39f?auto=format&fit=crop&w=1000&q=80',
  },
  {
    title: 'Digital-трансформация',
    description:
      'Помогаем трансформировать операционную модель бизнеса, внедряем инструменты управления данными, автоматизируем процессы.',
    points: [
      'Цифровые двойники процессов',
      'Управление изменениями и обучение команд',
      'Контроль и аналитика результатов',
    ],
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1000&q=80',
  },
  {
    title: 'Облачные решения',
    description:
      'Проектируем, мигрируем и поддерживаем инфраструктуры в облаке. Обеспечиваем гибкость, отказоустойчивость и безопасность.',
    points: [
      'Гибридные и мультиоблачные стратегии',
      'Оптимизация стоимости владения',
      'Непрерывный мониторинг и DevOps',
    ],
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1000&q=80',
  },
  {
    title: 'Кибербезопасность',
    description:
      'Комплексный подход к защите инфраструктуры, данных и приложений. От оценки рисков до внедрения систем мониторинга.',
    points: [
      'Аудит безопасности и тесты на проникновение',
      'SIEM, SOAR и SOC-услуги',
      'Обучение и моделирование инцидентов',
    ],
    image: 'https://images.unsplash.com/photo-1535223289827-42f1e9919769?auto=format&fit=crop&w=1000&q=80',
  },
];

const Services = () => (
  <>
    <Helmet>
      <title>Услуги TechSolutions — IT-консалтинг и разработка</title>
      <meta
        name="description"
        content="IT-консалтинг, разработка программного обеспечения, облачные решения, кибербезопасность и digital-трансформация от TechSolutions."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.container}>
        <h1>Услуги TechSolutions</h1>
        <p>
          Проводим компании через полный цикл цифровой трансформации: от стратегии и архитектуры до внедрения и
          сопровождения. Каждая услуга нацелена на измеримый бизнес-результат.
        </p>
      </div>
    </section>

    <section className={styles.servicesList}>
      <div className={styles.container}>
        {services.map((service) => (
          <article key={service.title} className={styles.serviceItem}>
            <div className={styles.serviceImage}>
              <img src={service.image} alt={service.title} />
            </div>
            <div className={styles.serviceContent}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <ul>
                {service.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.cta}>
      <div className={styles.container}>
        <h2>Нужна консультация по вашему проекту?</h2>
        <p>
          Расскажите о задаче — мы подготовим предварительную оценку и план внедрения за 5 рабочих дней.
        </p>
      </div>
    </section>
  </>
);

export default Services;