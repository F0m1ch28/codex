import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Тренды в IT-консалтинге на 2024 год',
    date: '15 января 2024',
    summary:
      'Рассматриваем ключевые тренды: рост спроса на data-driven подходы, комплексные программы кибербезопасности и внедрение AI платформ на уровне предприятия.',
  },
  {
    title: 'Как выбрать технологический стек для вашего проекта',
    date: '28 декабря 2023',
    summary:
      'Пошаговая методика оценки технологий — с точки зрения бизнес-целей, требований безопасности, наличия экспертизы и стоимости владения.',
  },
  {
    title: '5 шагов к успешной digital-трансформации',
    date: '10 ноября 2023',
    summary:
      'Системный подход к трансформации: диагностика процессов, формирование дорожной карты, пилотные инициативы, масштабирование и управление изменениями.',
  },
];

const Blog = () => (
  <>
    <Helmet>
      <title>Блог TechSolutions — аналитика и практика</title>
      <meta
        name="description"
        content="Статьи TechSolutions о трендах IT-консалтинга, выборе технологического стека и практическом подходе к digital-трансформации."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.container}>
        <h1>Блог TechSolutions</h1>
        <p>
          Делимся опытом и наблюдениями о цифровой трансформации, архитектуре систем, облачных технологиях и
          кибербезопасности.
        </p>
      </div>
    </section>
    <section className={styles.posts}>
      <div className={styles.container}>
        {posts.map((post) => (
          <article key={post.title} className={styles.postCard}>
            <div className={styles.postMeta}>{post.date}</div>
            <h2>{post.title}</h2>
            <p>{post.summary}</p>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Blog;