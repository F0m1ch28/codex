import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const servicesPreview = [
  {
    title: 'IT-консалтинг',
    description:
      'Анализ бизнес-процессов, разработка стратегии цифровизации и подбор оптимальных технологий для масштабирования.',
    image: 'https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Разработка ПО',
    description:
      'Создаем корпоративные системы, веб-платформы и мобильные приложения с учетом требований безопасности и масштабируемости.',
    image: 'https://images.unsplash.com/photo-1517430816045-df4b7de11d1d?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Digital-трансформация',
    description:
      'Помогаем перестроить операционные модели компании, внедряем KPI и автоматизацию для управления изменениями.',
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
  },
  {
    title: 'Облачные решения',
    description:
      'Проектируем и поддерживаем гибридные и мультиоблачные инфраструктуры, оптимизируя затраты и доступность.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80',
  },
];

const processSteps = [
  {
    title: 'Исследование и аудит',
    text: 'Глубоко анализируем IT-ландшафт, собираем требования и определяем зоны роста.',
  },
  {
    title: 'Дизайн решения',
    text: 'Создаем дорожную карту, архитектуру и прототипы с учетом бизнес-целей.',
  },
  {
    title: 'Разработка и внедрение',
    text: 'Реализуем решения итеративно, интегрируя с существующими системами.',
  },
  {
    title: 'Сопровождение и развитие',
    text: 'Обеспечиваем поддержку, оптимизацию и развитие продукта после запуска.',
  },
];

const casePreviews = [
  {
    title: 'Внедрение CRM для ритейла',
    result: 'Повышение конверсии повторных покупок на 32% за 6 месяцев.',
    image: 'https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Приложение для логистики',
    result: 'Сокращение времени доставки на 18% за счет аналитики в реальном времени.',
    image: 'https://images.unsplash.com/photo-1549921296-3b4a4f3d7c6b?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Миграция в облако финсектора',
    result: 'Снижение затрат на инфраструктуру на 27% без компромиссов по безопасности.',
    image: 'https://images.unsplash.com/photo-1517148815978-75f6acaaf32c?auto=format&fit=crop&w=900&q=80',
  },
];

const testimonials = [
  {
    name: 'Анна Воронова',
    role: 'Директор по цифровому развитию, RetailOne',
    quote:
      'Команда TechSolutions помогла выстроить единую платформу взаимодействия с клиентами. Мы увидели результаты уже в первый квартал.',
    avatar: 'https://i.pravatar.cc/200?img=32',
  },
  {
    name: 'Игорь Петров',
    role: 'COO, LogisticsPro',
    quote:
      'Благодаря внедренному мобильному приложению и аналитике в реальном времени мы повысили прозрачность цепочки поставок.',
    avatar: 'https://i.pravatar.cc/200?img=48',
  },
];

const blogPreview = [
  {
    title: 'Тренды в IT-консалтинге на 2024 год',
    excerpt:
      'Переход на data-driven управление, консалтинг по устойчивому развитию и глубокая интеграция AI становятся стандартом отрасли.',
  },
  {
    title: 'Как выбрать технологический стек для вашего проекта',
    excerpt:
      'Разбираемся, какие факторы учитывать при выборе технологического стека, чтобы решение оставалось масштабируемым и безопасным.',
  },
  {
    title: '5 шагов к успешной digital-трансформации',
    excerpt:
      'Пошаговая методология цифровой трансформации: от диагностики процессов до обучения команд и измерения эффекта.',
  },
];

const Home = () => (
  <>
    <Helmet>
      <title>TechSolutions — IT-консалтинг и разработка в Москве</title>
      <meta
        name="description"
        content="TechSolutions — партнер по IT-консалтингу, разработке программного обеспечения, digital-трансформации, облачным решениям и кибербезопасности."
      />
      <meta
        name="keywords"
        content="IT-консалтинг, разработка программного обеспечения, digital-трансформация, облачные решения, кибербезопасность, TechSolutions"
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <p className={styles.tagline}>IT-консалтинг • Разработка ПО • Digital-трансформация</p>
        <h1 className={styles.heroTitle}>Цифровые решения, которые ускоряют рост вашего бизнеса</h1>
        <p className={styles.heroText}>
          Мы соединяем стратегию, технологии и опыт управления проектами, чтобы создавать масштабируемые цифровые
          продукты и инфраструктуры. TechSolutions — ваш партнер в трансформации бизнес-модели.
        </p>
        <div className={styles.heroActions}>
          <Link to="/kontakty" className={styles.primaryButton}>
            Обсудить проект
          </Link>
          <Link to="/uslugi" className={styles.secondaryButton}>
            Наши услуги
          </Link>
        </div>
        <div className={styles.heroStats} aria-label="Ключевые показатели TechSolutions">
          <div>
            <span className={styles.statNumber}>120+</span>
            <span className={styles.statLabel}>завершенных проектов</span>
          </div>
          <div>
            <span className={styles.statNumber}>18 лет</span>
            <span className={styles.statLabel}>средний опыт экспертов</span>
          </div>
          <div>
            <span className={styles.statNumber}>24/7</span>
            <span className={styles.statLabel}>поддержка критичных систем</span>
          </div>
        </div>
      </div>
      <figure className={styles.heroImageWrapper}>
        <img
          src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80"
          alt="Команда IT-специалистов TechSolutions"
          className={styles.heroImage}
        />
      </figure>
    </section>

    <section className={styles.services} id="services">
      <div className={styles.sectionHeader}>
        <h2>Наши ключевые компетенции</h2>
        <p>
          Комбинируем стратегический подход и современную инженерию, чтобы обеспечить устойчивое конкурентное
          преимущество.
        </p>
      </div>
      <div className={styles.servicesGrid}>
        {servicesPreview.map((service) => (
          <article key={service.title} className={styles.serviceCard}>
            <figure className={styles.serviceImageWrapper}>
              <img src={service.image} alt={service.title} />
            </figure>
            <div className={styles.serviceContent}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </div>
          </article>
        ))}
      </div>
      <div className={styles.sectionFooter}>
        <Link to="/uslugi" className={styles.linkButton}>
          Посмотреть все услуги
        </Link>
      </div>
    </section>

    <section className={styles.why}>
      <div className={styles.sectionHeader}>
        <h2>Почему компании выбирают TechSolutions</h2>
        <p>
          Сбалансированный подход к стратегии, архитектуре и внедрению помогает нам обеспечивать измеримый эффект и
          прозрачность для бизнеса.
        </p>
      </div>
      <div className={styles.whyGrid}>
        <div className={styles.whyCard}>
          <h3>Фокус на результат</h3>
          <p>Работаем с измеримыми бизнес-метриками, настраиваем контроль и поддержку изменений.</p>
        </div>
        <div className={styles.whyCard}>
          <h3>Стандарты безопасности</h3>
          <p>Соответствие требованиям регуляторов и международным стандартам по защите данных и киберустойчивости.</p>
        </div>
        <div className={styles.whyCard}>
          <h3>Кросс-функциональные команды</h3>
          <p>В проект вовлечены архитекторы, аналитики, DevOps, эксперты по данным и менеджеры внедрения.</p>
        </div>
        <div className={styles.whyCard}>
          <h3>Скорость и гибкость</h3>
          <p>Используем гибридные методологии управления проектами, сохраняя прозрачность и контроль.</p>
        </div>
      </div>
    </section>

    <section className={styles.process}>
      <div className={styles.sectionHeader}>
        <h2>От идеи до масштабирования</h2>
        <p>Наша методология покрывает полный цикл внедрения IT-решений.</p>
      </div>
      <div className={styles.processGrid}>
        {processSteps.map((step, index) => (
          <article key={step.title} className={styles.processCard}>
            <span className={styles.stepNumber}>{index + 1}</span>
            <h3>{step.title}</h3>
            <p>{step.text}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.cases}>
      <div className={styles.sectionHeader}>
        <h2>Избранные кейсы</h2>
        <p>Мы помогаем компаниям разных отраслей ускорять цифровые инициативы.</p>
      </div>
      <div className={styles.casesGrid}>
        {casePreviews.map((caseItem) => (
          <article key={caseItem.title} className={styles.caseCard}>
            <figure className={styles.caseImageWrapper}>
              <img src={caseItem.image} alt={caseItem.title} />
            </figure>
            <div className={styles.caseContent}>
              <h3>{caseItem.title}</h3>
              <p>{caseItem.result}</p>
            </div>
          </article>
        ))}
      </div>
      <div className={styles.sectionFooter}>
        <Link to="/kejsy" className={styles.linkButton}>
          Все кейсы
        </Link>
      </div>
    </section>

    <section className={styles.testimonials}>
      <div className={styles.sectionHeader}>
        <h2>Отзывы клиентов</h2>
        <p>Доверие лидеров рынка подтверждает эффективность наших решений.</p>
      </div>
      <div className={styles.testimonialGrid}>
        {testimonials.map((testimonial) => (
          <blockquote key={testimonial.name} className={styles.testimonialCard}>
            <div className={styles.testimonialHeader}>
              <img src={testimonial.avatar} alt={`Фото клиента ${testimonial.name}`} />
              <div>
                <p className={styles.testimonialName}>{testimonial.name}</p>
                <p className={styles.testimonialRole}>{testimonial.role}</p>
              </div>
            </div>
            <p className={styles.testimonialQuote}>{testimonial.quote}</p>
          </blockquote>
        ))}
      </div>
    </section>

    <section className={styles.blog}>
      <div className={styles.sectionHeader}>
        <h2>Последние статьи</h2>
        <p>Аналитика, практики и инсайты команды TechSolutions.</p>
      </div>
      <div className={styles.blogGrid}>
        {blogPreview.map((post) => (
          <article key={post.title} className={styles.blogCard}>
            <h3>{post.title}</h3>
            <p>{post.excerpt}</p>
            <Link to="/blog" className={styles.readMore}>
              Читать в блоге
            </Link>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.contactCta}>
      <div className={styles.contactContent}>
        <h2>Готовы к digital-трансформации?</h2>
        <p>
          Расскажите нам о своих целях — и мы предложим путь, в котором технологии станут инструментом устойчивого
          роста.
        </p>
        <Link to="/kontakty" className={styles.primaryButtonLight}>
          Связаться с TechSolutions
        </Link>
      </div>
    </section>
  </>
);

export default Home;