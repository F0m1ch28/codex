document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.mobile-nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', function () {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      primaryNav.classList.toggle('nav-open');
    });

    primaryNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.innerWidth < 768) {
          navToggle.setAttribute('aria-expanded', 'false');
          primaryNav.classList.remove('nav-open');
        }
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const acceptButton = cookieBanner.querySelector('[data-cookie-action="accept"]');
    const declineButton = cookieBanner.querySelector('[data-cookie-action="decline"]');
    const storageKey = 'finance101CookiePreference';

    const storedPreference = localStorage.getItem(storageKey);
    if (storedPreference) {
      cookieBanner.classList.add('hidden');
    } else {
      cookieBanner.classList.remove('hidden');
    }

    const setPreference = function (value) {
      localStorage.setItem(storageKey, value);
      cookieBanner.classList.add('hidden');
    };

    if (acceptButton) {
      acceptButton.addEventListener('click', function () {
        setPreference('accepted');
      });
    }

    if (declineButton) {
      declineButton.addEventListener('click', function () {
        setPreference('declined');
      });
    }
  }
});