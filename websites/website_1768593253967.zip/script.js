const navToggle = document.querySelector('.nav-toggle');
const navigation = document.querySelector('.navigation');
if (navToggle && navigation) {
    navToggle.addEventListener('click', () => {
        navigation.classList.toggle('is-visible');
        navToggle.setAttribute('aria-expanded', navigation.classList.contains('is-visible'));
    });
}

const cookieBanner = document.querySelector('.cookie-banner');
const cookieAccept = document.querySelector('.cookie-accept');
const cookieDecline = document.querySelector('.cookie-decline');

function handleCookieConsent(value) {
    localStorage.setItem('vg_cookie_consent', value);
    if (cookieBanner) {
        cookieBanner.classList.remove('is-visible');
    }
}

if (cookieBanner) {
    const consent = localStorage.getItem('vg_cookie_consent');
    if (!consent) {
        setTimeout(() => {
            cookieBanner.classList.add('is-visible');
        }, 800);
    }
}

if (cookieAccept) {
    cookieAccept.addEventListener('click', () => handleCookieConsent('accepted'));
}
if (cookieDecline) {
    cookieDecline.addEventListener('click', () => handleCookieConsent('declined'));
}

const layerButtons = document.querySelectorAll('[data-layer]');
const layerDescriptions = document.querySelectorAll('.layer-description');

layerButtons.forEach(button => {
    button.addEventListener('click', () => {
        const target = button.getAttribute('data-layer');
        layerButtons.forEach(btn => btn.classList.remove('is-active'));
        button.classList.add('is-active');
        layerDescriptions.forEach(desc => {
            desc.classList.toggle('is-visible', desc.id === target);
        });
    });
});

const filterButtons = document.querySelectorAll('[data-filter]');
const systemCards = document.querySelectorAll('[data-category]');

filterButtons.forEach(button => {
    button.addEventListener('click', () => {
        const filter = button.getAttribute('data-filter');
        filterButtons.forEach(btn => btn.classList.remove('is-active'));
        button.classList.add('is-active');
        systemCards.forEach(card => {
            const category = card.getAttribute('data-category');
            card.style.display = filter === 'all' || filter === category ? 'grid' : 'none';
        });
    });
});

const accordions = document.querySelectorAll('.accordion-trigger');
accordions.forEach(trigger => {
    trigger.addEventListener('click', () => {
        const content = trigger.nextElementSibling;
        const expanded = trigger.getAttribute('aria-expanded') === 'true';
        trigger.setAttribute('aria-expanded', String(!expanded));
        content.classList.toggle('is-open');
    });
});