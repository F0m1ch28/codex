document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      siteNav.classList.toggle('is-open');
    });
  }

  const banner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie="accept"]');
  const declineBtn = document.querySelector('[data-cookie="decline"]');
  const storageKey = 'epr-cookie-consent';

  if (banner) {
    let consent = null;
    try {
      consent = window.localStorage.getItem(storageKey);
    } catch (error) {
      consent = null;
    }

    if (!consent) {
      requestAnimationFrame(() => banner.classList.add('visible'));
    }

    const handleConsent = (value) => {
      try {
        window.localStorage.setItem(storageKey, value);
      } catch (error) {
        console.warn('Stockage local indisponible pour le consentement aux cookies.');
      }
      banner.classList.remove('visible');
    };

    acceptBtn?.addEventListener('click', () => handleConsent('accepted'));
    declineBtn?.addEventListener('click', () => handleConsent('declined'));
  }
});