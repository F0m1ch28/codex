```javascript
import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'techsolutions_cookie_consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          We use cookies to make this website more reliable, personalize your
          experience, and understand how it is used. By clicking “Accept” you
          agree to our use of cookies.
        </p>
        <div className={styles.actions}>
          <a href="/cookie-policy" className={styles.link}>
            Learn more
          </a>
          <button onClick={acceptCookies} className={styles.button}>
            Accept
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;
```