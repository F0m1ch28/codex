document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".nav");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.getAttribute("data-open") === "true";
      nav.setAttribute("data-open", String(!isOpen));
      navToggle.setAttribute("aria-expanded", String(!isOpen));
    });

    document.addEventListener("click", (event) => {
      if (!nav.contains(event.target) && event.target !== navToggle) {
        nav.setAttribute("data-open", "false");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const consent = localStorage.getItem("cookieConsent");
    if (consent === "accepted" || consent === "declined") {
      cookieBanner.hidden = true;
    }

    const acceptButton = cookieBanner.querySelector("[data-accept]");
    const declineButton = cookieBanner.querySelector("[data-decline]");

    const handleConsent = (value) => {
      localStorage.setItem("cookieConsent", value);
      cookieBanner.hidden = true;
    };

    if (acceptButton) {
      acceptButton.addEventListener("click", () => handleConsent("accepted"));
    }

    if (declineButton) {
      declineButton.addEventListener("click", () => handleConsent("declined"));
    }
  }
});