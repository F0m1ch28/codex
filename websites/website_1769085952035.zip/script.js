document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');
  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('.cookie-accept');
  const declineBtn = document.querySelector('.cookie-decline');
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.setAttribute('role', 'status');
  toast.setAttribute('aria-live', 'polite');
  body.appendChild(toast);

  const showToast = (message) => {
    toast.textContent = message;
    toast.classList.add('visible');
    setTimeout(() => toast.classList.remove('visible'), 2600);
  };

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      primaryNav.classList.toggle('active');
      navToggle.classList.toggle('open');
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (event) => {
      const targetId = anchor.getAttribute('href').substring(1);
      const target = document.getElementById(targetId);
      if (target) {
        event.preventDefault();
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  if (cookieBanner) {
    const storedChoice = localStorage.getItem('cookieChoice');
    if (!storedChoice) {
      cookieBanner.classList.add('active');
    }
    const handleChoice = (choice) => {
      localStorage.setItem('cookieChoice', choice);
      cookieBanner.classList.remove('active');
      showToast(choice === 'accepted' ? 'Preferencias guardadas' : 'Preferencias registradas');
    };
    if (acceptBtn) acceptBtn.addEventListener('click', () => handleChoice('accepted'));
    if (declineBtn) declineBtn.addEventListener('click', () => handleChoice('declined'));
  }

  const observer = new IntersectionObserver(
    (entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.18 }
  );

  document.querySelectorAll('.fade-in').forEach((el) => observer.observe(el));

  const timelineSteps = document.querySelectorAll('[data-timeline-step]');
  let timelineIndex = 0;
  if (timelineSteps.length > 0) {
    const advanceTimeline = () => {
      timelineSteps.forEach((step, index) => {
        step.classList.toggle('active', index === timelineIndex);
      });
      timelineIndex = (timelineIndex + 1) % timelineSteps.length;
    };
    advanceTimeline();
    setInterval(advanceTimeline, 4200);
  }

  const regionButtons = document.querySelectorAll('[data-region]');
  const regionCards = document.querySelectorAll('[data-region-card]');
  const mapRegions = document.querySelectorAll('.map-region');
  const mapDetails = document.querySelector('.map-details');

  const updateRegion = (regionKey) => {
    regionButtons.forEach((btn) => btn.classList.toggle('active', btn.dataset.region === regionKey));
    regionCards.forEach((card) => {
      card.classList.toggle('hidden', card.dataset.regionCard !== regionKey && regionKey !== 'general');
    });
    mapRegions.forEach((regionEl) => {
      regionEl.classList.toggle('active', regionEl.dataset.region === regionKey);
    });
    if (mapDetails && regionKey !== 'general') {
      const detail = mapDetails.querySelector(`[data-detail="${regionKey}"]`);
      mapDetails.querySelectorAll('[data-detail]').forEach((el) => {
        el.hidden = el.dataset.detail !== regionKey;
      });
      if (detail) detail.hidden = false;
    }
    if (mapDetails && regionKey === 'general') {
      mapDetails.querySelectorAll('[data-detail]').forEach((el) => {
        el.hidden = el.dataset.detail !== 'general';
      });
    }
  };

  regionButtons.forEach((button) => {
    button.addEventListener('click', () => updateRegion(button.dataset.region));
  });

  mapRegions.forEach((regionEl) => {
    regionEl.addEventListener('click', () => updateRegion(regionEl.dataset.region));
    regionEl.addEventListener('keypress', (event) => {
      if (event.key === 'Enter') updateRegion(regionEl.dataset.region);
    });
  });

  updateRegion('general');

  const chartCanvas = document.querySelector('#comparativeChart');
  if (chartCanvas) {
    const ctx = chartCanvas.getContext('2d');
    const data = [
      { label: 'Madrid', energy: 78, health: 68 },
      { label: 'Castilla y León', energy: 64, health: 72 },
      { label: 'Aragón', energy: 70, health: 66 },
      { label: 'Murcia', energy: 62, health: 74 },
      { label: 'Cantabria', energy: 58, health: 69 }
    ];
    const drawChart = () => {
      const { width, height } = chartCanvas;
      ctx.clearRect(0, 0, width, height);
      const padding = 60;
      const barWidth = (width - padding * 2) / data.length / 2.5;
      const maxValue = 100;
      ctx.font = '14px Inter';
      ctx.fillStyle = 'rgba(55, 71, 79, 0.6)';
      ctx.textAlign = 'center';
      data.forEach((item, index) => {
        const baseX = padding + index * barWidth * 2.5;
        const energyHeight = ((height - padding * 2) * item.energy) / maxValue;
        const healthHeight = ((height - padding * 2) * item.health) / maxValue;
        ctx.fillStyle = 'rgba(94, 53, 177, 0.7)';
        ctx.fillRect(baseX, height - padding - energyHeight, barWidth, energyHeight);
        ctx.fillStyle = 'rgba(0, 172, 193, 0.75)';
        ctx.fillRect(baseX + barWidth + 12, height - padding - healthHeight, barWidth, healthHeight);
        ctx.fillStyle = 'rgba(55, 71, 79, 0.85)';
        ctx.fillText(item.label, baseX + barWidth + 6, height - padding + 24);
      });
      ctx.strokeStyle = 'rgba(55, 71, 79, 0.25)';
      ctx.beginPath();
      ctx.moveTo(padding, padding);
      ctx.lineTo(padding, height - padding);
      ctx.lineTo(width - padding, height - padding);
      ctx.stroke();
    };
    drawChart();
    window.addEventListener('resize', drawChart);
  }

  const aragonCarousel = document.querySelector('[data-aragon-carousel]');
  if (aragonCarousel) {
    const track = aragonCarousel.querySelector('.carousel-track');
    const slides = Array.from(track.children);
    const nextBtn = aragonCarousel.querySelector('[data-carousel-next]');
    const prevBtn = aragonCarousel.querySelector('[data-carousel-prev]');
    let currentSlide = 0;

    const updateCarousel = () => {
      const width = aragonCarousel.offsetWidth;
      track.style.transform = `translateX(-${currentSlide * width}px)`;
      slides.forEach((slide, index) => {
        slide.classList.toggle('active', index === currentSlide);
      });
    };

    nextBtn.addEventListener('click', () => {
      currentSlide = (currentSlide + 1) % slides.length;
      updateCarousel();
    });

    prevBtn.addEventListener('click', () => {
      currentSlide = (currentSlide - 1 + slides.length) % slides.length;
      updateCarousel();
    });

    window.addEventListener('resize', updateCarousel);
    updateCarousel();
  }

  const dashboardControls = document.querySelectorAll('[data-dashboard-control]');
  const dashboardCards = document.querySelectorAll('[data-dashboard-card]');
  dashboardControls.forEach((control) => {
    control.addEventListener('click', () => {
      const metric = control.dataset.dashboardControl;
      dashboardControls.forEach((btn) => btn.classList.toggle('active', btn.dataset.dashboardControl === metric));
      dashboardCards.forEach((card) => {
        const isActive = card.dataset.dashboardCard === metric;
        card.classList.toggle('active', isActive);
        card.hidden = !isActive;
      });
    });
  });

  if (dashboardControls.length > 0) {
    dashboardControls[0].click();
  }

  document.querySelectorAll('form[data-global-form]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      const requiredFields = form.querySelectorAll('[required]');
      let valid = true;
      requiredFields.forEach((field) => {
        if (!formData.get(field.getAttribute('name'))) {
          valid = false;
          field.classList.add('invalid');
        } else {
          field.classList.remove('invalid');
        }
      });
      if (!valid) {
        showToast('Por favor, complete los campos necesarios');
        return;
      }
      showToast('Enviando información');
      setTimeout(() => {
        window.location.href = form.getAttribute('action') || 'exito.html';
      }, 1200);
    });
  });
});