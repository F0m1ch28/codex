(function() {
  "use strict";

  function generateDynamicImages() {
    var nodes = document.querySelectorAll("canvas[data-type]");
    if (!nodes.length) {
      return;
    }
    nodes.forEach(function(canvas, index) {
      var rect = canvas.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) {
        rect = { width: canvas.parentElement ? canvas.parentElement.clientWidth : 320, height: canvas.parentElement ? canvas.parentElement.clientHeight : 180 };
      }
      var type = canvas.dataset.type || "default";
      var baseSeed = parseInt(canvas.dataset.seed || "0", 10);
      if (!baseSeed) {
        baseSeed = hashString(type) + index * 1337;
      }
      var ctx = canvas.getContext("2d");
      var dpr = window.devicePixelRatio || 1;
      var width = Math.max(320, Math.floor(rect.width));
      var height = Math.max(180, Math.floor(rect.height));
      setCanvasResolution(canvas, ctx, width, height, dpr);
      var rng = createRNG(baseSeed + width + height);
      ctx.save();
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      switch (type) {
        case "solar":
          drawRealisticSolarPanels(ctx, width * dpr, height * dpr, rng);
          break;
        case "wind":
          drawRealisticWindTurbines(ctx, width * dpr, height * dpr, rng);
          break;
        case "hybrid":
          drawRealisticHybridSystem(ctx, width * dpr, height * dpr, rng);
          break;
        case "dashboard":
          drawRealisticDashboard(ctx, width * dpr, height * dpr, rng);
          break;
        case "team":
          drawRealisticTeam(ctx, width * dpr, height * dpr, rng);
          break;
        case "environment":
          drawRealisticEnvironment(ctx, width * dpr, height * dpr, rng);
          break;
        case "map":
          drawRealisticMap(ctx, width * dpr, height * dpr, rng);
          break;
        default:
          drawDefaultScene(ctx, width * dpr, height * dpr, rng);
          break;
      }
      ctx.restore();
    });
  }

  function setCanvasResolution(canvas, ctx, width, height, dpr) {
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = width + "px";
    canvas.style.height = height + "px";
    ctx.resetTransform();
    ctx.scale(dpr, dpr);
  }

  function createRNG(seed) {
    var value = seed || 1;
    return function() {
      value = Math.imul(value ^ 0x6d2b79f5, value | 1);
      value ^= value + Math.imul(value ^ (value >>> 15), 1 | value);
      value = (value + (value << 3)) | 0;
      var t = ((value >>> 0) / 4294967296);
      return t;
    };
  }

  function hashString(str) {
    var hash = 0;
    for (var i = 0; i < str.length; i++) {
      hash = Math.imul(31, hash) + str.charCodeAt(i) | 0;
    }
    return Math.abs(hash);
  }

  function drawSky(ctx, width, height, rng) {
    var topHue = 205 + Math.floor(rng() * 10);
    var gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, "hsl(" + topHue + ", 72%, " + (60 + Math.floor(rng() * 5)) + "%)");
    gradient.addColorStop(0.45, "hsl(" + (topHue - 5) + ", 68%, 68%)");
    gradient.addColorStop(1, "hsl(" + (topHue - 10) + ", 55%, 82%)");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
  }

  function drawSun(ctx, width, height, rng) {
    var sunX = width * (0.15 + rng() * 0.3);
    var sunY = height * (0.2 + rng() * 0.1);
    var radius = Math.min(width, height) * (0.08 + rng() * 0.05);
    var gradient = ctx.createRadialGradient(sunX, sunY, radius * 0.1, sunX, sunY, radius);
    gradient.addColorStop(0, "rgba(255, 255, 255, 0.95)");
    gradient.addColorStop(0.45, "rgba(255, 246, 200, 0.7)");
    gradient.addColorStop(1, "rgba(255, 246, 200, 0)");
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(sunX, sunY, radius, 0, Math.PI * 2);
    ctx.fill();
  }

  function drawDistantHills(ctx, width, height, rng, tint) {
    var hillCount = 3 + Math.floor(rng() * 3);
    for (var i = 0; i < hillCount; i++) {
      var baseY = height * (0.55 + i * 0.06);
      var hillHeight = height * (0.08 + rng() * 0.12);
      var hillWidth = width * (0.5 + rng() * 0.5);
      var startX = -width * 0.1 + rng() * width * 0.2;
      var gradient = ctx.createLinearGradient(0, baseY - hillHeight, 0, baseY + hillHeight);
      gradient.addColorStop(0, "rgba(" + tint.r + ", " + tint.g + ", " + tint.b + ", " + (0.12 + i * 0.12) + ")");
      gradient.addColorStop(1, "rgba(" + (tint.r - 10) + ", " + (tint.g - 8) + ", " + (tint.b - 4) + ", " + (0.2 + i * 0.15) + ")");
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.moveTo(startX, baseY);
      var controlCount = 5;
      for (var j = 0; j <= controlCount; j++) {
        var t = j / controlCount;
        var controlX = startX + hillWidth * t;
        var controlY = baseY - hillHeight * Math.sin(Math.PI * t) * (0.8 + rng() * 0.4);
        ctx.quadraticCurveTo(controlX - hillWidth / controlCount / 2, controlY, controlX, baseY);
      }
      ctx.lineTo(startX + hillWidth, height);
      ctx.lineTo(startX, height);
      ctx.closePath();
      ctx.fill();
    }
  }

  function drawClouds(ctx, width, height, rng) {
    var cloudLayers = 4;
    for (var layer = 0; layer < cloudLayers; layer++) {
      var cloudCount = 3 + Math.floor(rng() * 4);
      var opacity = 0.12 + layer * 0.08;
      for (var c = 0; c < cloudCount; c++) {
        var cloudWidth = width * (0.18 + rng() * 0.22) * (1 - layer * 0.1);
        var cloudHeight = height * (0.08 + rng() * 0.06) * (1 - layer * 0.1);
        var x = rng() * width;
        var y = height * (0.05 + layer * 0.12) + rng() * height * 0.04;
        ctx.fillStyle = "rgba(255,255,255," + opacity + ")";
        ctx.beginPath();
        var segments = 6 + Math.floor(rng() * 3);
        for (var s = 0; s < segments; s++) {
          var localX = x + Math.sin((s / (segments - 1)) * Math.PI) * cloudWidth;
          var localY = y + (rng() - 0.5) * cloudHeight * 0.4;
          var radius = cloudHeight * (0.4 + rng() * 0.4);
          ctx.arc(localX, localY, radius, 0, Math.PI * 2);
        }
        ctx.closePath();
        ctx.fill();
      }
    }
  }

  function drawGround(ctx, width, height, rng, hue) {
    var baseY = height * 0.7;
    var gradient = ctx.createLinearGradient(0, baseY, 0, height);
    gradient.addColorStop(0, "hsl(" + hue + ", 45%, 56%)");
    gradient.addColorStop(1, "hsl(" + (hue - 10) + ", 55%, 40%)");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, baseY, width, height);

    ctx.strokeStyle = "rgba(255,255,255,0.15)";
    ctx.lineWidth = Math.max(1, width * 0.0015);
    var contourCount = 5;
    for (var i = 0; i < contourCount; i++) {
      var y = baseY + (height - baseY) * (i / contourCount);
      ctx.beginPath();
      ctx.moveTo(0, y);
      for (var x = 0; x <= width; x += width / 50) {
        var offset = Math.sin((x / width) * Math.PI * 4 + rng() * Math.PI) * height * 0.01;
        ctx.lineTo(x, y + offset);
      }
      ctx.stroke();
    }
  }

  function drawRealisticSolarPanels(ctx, width, height, rng) {
    drawSky(ctx, width, height, rng);
    drawSun(ctx, width, height, rng);
    drawClouds(ctx, width, height, rng);
    drawDistantHills(ctx, width, height, rng, { r: 34, g: 72, b: 118 });
    drawGround(ctx, width, height, rng, 128);
    var baseY = height * 0.7;
    var rowCount = 3;
    for (var row = 0; row < rowCount; row++) {
      var panelsPerRow = 6;
      var rowDepth = row / rowCount;
      var panelWidth = width * 0.16 * (1 - rowDepth * 0.2);
      var panelHeight = height * 0.12 * (1 - rowDepth * 0.25);
      var rowOffsetY = baseY - height * 0.08 * row - panelHeight * 0.5;
      for (var col = 0; col < panelsPerRow; col++) {
        var spacing = width * 0.15 + row * 6;
        var panelX = width * 0.15 + col * spacing * (1 - rowDepth * 0.15) + rng() * width * 0.01;
        var panelY = rowOffsetY - Math.sin(col * 0.5) * height * 0.01;
        var tilt = Math.PI / 12;
        var gradient = ctx.createLinearGradient(panelX, panelY, panelX + panelWidth, panelY + panelHeight * Math.tan(tilt));
        gradient.addColorStop(0, "rgba(24, 39, 68, 0.92)");
        gradient.addColorStop(0.4, "rgba(34, 63, 104, 0.96)");
        gradient.addColorStop(1, "rgba(19, 30, 49, 0.85)");
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.moveTo(panelX, panelY);
        ctx.lineTo(panelX + panelWidth, panelY - panelWidth * Math.tan(tilt));
        ctx.lineTo(panelX + panelWidth, panelY + panelHeight - panelWidth * Math.tan(tilt));
        ctx.lineTo(panelX, panelY + panelHeight);
        ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = "rgba(255,255,255,0.35)";
        ctx.lineWidth = Math.max(1, panelWidth * 0.02);
        ctx.stroke();

        ctx.strokeStyle = "rgba(255,255,255,0.12)";
        ctx.lineWidth = Math.max(1, panelWidth * 0.01);
        for (var seg = 1; seg < 6; seg++) {
          var frac = seg / 6;
          ctx.beginPath();
          ctx.moveTo(panelX + panelWidth * frac, panelY - panelWidth * Math.tan(tilt) * frac);
          ctx.lineTo(panelX + panelWidth * frac, panelY + panelHeight - panelWidth * Math.tan(tilt) * frac);
          ctx.stroke();
        }
        ctx.strokeStyle = "rgba(255,255,255,0.15)";
        ctx.beginPath();
        ctx.moveTo(panelX, panelY + panelHeight * 0.3);
        ctx.lineTo(panelX + panelWidth, panelY + panelHeight * 0.3 - panelWidth * Math.tan(tilt));
        ctx.moveTo(panelX, panelY + panelHeight * 0.6);
        ctx.lineTo(panelX + panelWidth, panelY + panelHeight * 0.6 - panelWidth * Math.tan(tilt));
        ctx.stroke();

        ctx.fillStyle = "rgba(14, 24, 40, 0.8)";
        ctx.beginPath();
        ctx.moveTo(panelX, panelY + panelHeight);
        ctx.lineTo(panelX + panelWidth, panelY + panelHeight - panelWidth * Math.tan(tilt));
        ctx.lineTo(panelX + panelWidth * 1.02, panelY + panelHeight - panelWidth * Math.tan(tilt) + height * 0.05);
        ctx.lineTo(panelX + panelWidth * 0.02, panelY + panelHeight + height * 0.05);
        ctx.closePath();
        ctx.fill();
      }
    }
    drawForegroundDetails(ctx, width, height, rng);
  }

  function drawRealisticWindTurbines(ctx, width, height, rng) {
    drawSky(ctx, width, height, rng);
    drawSun(ctx, width, height, rng);
    drawClouds(ctx, width, height, rng);
    drawDistantHills(ctx, width, height, rng, { r: 46, g: 88, b: 126 });
    drawGround(ctx, width, height, rng, 140);
    var baseY = height * 0.68;
    var turbineCount = 5;
    for (var i = 0; i < turbineCount; i++) {
      var depth = i / turbineCount;
      var x = width * (0.12 + depth * 0.15) + rng() * width * 0.6;
      var towerHeight = height * (0.45 + depth * 0.2);
      var towerWidth = width * (0.009 + depth * 0.005);
      var towerBaseY = baseY;
      drawWindTurbine(ctx, x, towerBaseY, towerWidth, towerHeight, depth, rng);
    }
    drawForegroundDetails(ctx, width, height, rng);
  }

  function drawWindTurbine(ctx, baseX, baseY, towerWidth, towerHeight, depth, rng) {
    var shade = 220 + Math.floor(depth * 20);
    ctx.fillStyle = "rgba(" + shade + "," + shade + "," + shade + ",0.95)";
    ctx.beginPath();
    ctx.moveTo(baseX - towerWidth * 0.6, baseY);
    ctx.lineTo(baseX + towerWidth * 0.6, baseY);
    ctx.lineTo(baseX + towerWidth * 0.2, baseY - towerHeight);
    ctx.lineTo(baseX - towerWidth * 0.2, baseY - towerHeight);
    ctx.closePath();
    ctx.fill();

    ctx.lineWidth = towerWidth * 0.3;
    ctx.strokeStyle = "rgba(140,140,140,0.5)";
    ctx.beginPath();
    ctx.moveTo(baseX, baseY);
    ctx.lineTo(baseX, baseY - towerHeight);
    ctx.stroke();

    var hubY = baseY - towerHeight;
    var hubRadius = towerWidth * (6 + depth * 5);
    ctx.fillStyle = "rgba(" + (shade - 20) + "," + (shade - 20) + "," + (shade - 20) + ",0.92)";
    ctx.beginPath();
    ctx.arc(baseX, hubY, hubRadius, 0, Math.PI * 2);
    ctx.fill();

    var bladeLength = towerHeight * (0.55 + depth * 0.1);
    var bladeWidth = towerWidth * (3.6 + depth * 2.2);
    var bladeCount = 3;
    for (var b = 0; b < bladeCount; b++) {
      var angle = (b / bladeCount) * Math.PI * 2 + rng() * 0.2;
      ctx.save();
      ctx.translate(baseX, hubY);
      ctx.rotate(angle);
      var gradient = ctx.createLinearGradient(0, 0, bladeLength, 0);
      gradient.addColorStop(0, "rgba(" + (shade + 10) + "," + (shade + 10) + "," + (shade + 10) + ",0.96)");
      gradient.addColorStop(1, "rgba(" + (shade - 10) + "," + (shade - 10) + "," + (shade - 10) + ",0.82)");
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.moveTo(0, -bladeWidth * 0.5);
      ctx.quadraticCurveTo(bladeLength * 0.2, -bladeWidth, bladeLength * 0.85, -bladeWidth * 0.3);
      ctx.lineTo(bladeLength, 0);
      ctx.lineTo(bladeLength * 0.85, bladeWidth * 0.3);
      ctx.quadraticCurveTo(bladeLength * 0.2, bladeWidth, 0, bladeWidth * 0.5);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }

  function drawRealisticHybridSystem(ctx, width, height, rng) {
    drawSky(ctx, width, height, rng);
    drawSun(ctx, width, height, rng);
    drawClouds(ctx, width, height, rng);
    drawDistantHills(ctx, width, height, rng, { r: 44, g: 94, b: 128 });
    drawGround(ctx, width, height, rng, 134);
    var baseY = height * 0.7;
    var solarRows = 2;
    for (var row = 0; row < solarRows; row++) {
      var panelsPerRow = 4;
      var rowDepth = row / solarRows;
      var panelWidth = width * 0.18 * (1 - rowDepth * 0.12);
      var panelHeight = height * 0.1 * (1 - rowDepth * 0.15);
      var rowY = baseY - height * 0.06 * row - panelHeight * 0.4;
      for (var col = 0; col < panelsPerRow; col++) {
        var panelX = width * 0.1 + col * width * 0.2 + rng() * width * 0.01;
        var tilt = Math.PI / 14;
        var gradient = ctx.createLinearGradient(panelX, rowY, panelX + panelWidth, rowY + panelHeight * Math.tan(tilt));
        gradient.addColorStop(0, "rgba(28,46,74,0.92)");
        gradient.addColorStop(1, "rgba(20,36,62,0.85)");
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.moveTo(panelX, rowY);
        ctx.lineTo(panelX + panelWidth, rowY - panelWidth * Math.tan(tilt));
        ctx.lineTo(panelX + panelWidth, rowY + panelHeight - panelWidth * Math.tan(tilt));
        ctx.lineTo(panelX, rowY + panelHeight);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.2)";
        ctx.lineWidth = Math.max(1, panelWidth * 0.015);
        ctx.stroke();
      }
    }
    var turbineCount = 3;
    for (var i = 0; i < turbineCount; i++) {
      var depth = i / turbineCount;
      var x = width * 0.5 + i * width * 0.15;
      var towerHeight = height * (0.38 + depth * 0.15);
      var towerWidth = width * (0.009 + depth * 0.004);
      drawWindTurbine(ctx, x, baseY - height * 0.02 * i, towerWidth, towerHeight, depth, rng);
    }
    drawBatteryContainers(ctx, width, height, rng);
    drawForegroundDetails(ctx, width, height, rng);
  }

  function drawBatteryContainers(ctx, width, height, rng) {
    var baseY = height * 0.74;
    var containerCount = 3;
    for (var i = 0; i < containerCount; i++) {
      var containerWidth = width * 0.14;
      var containerHeight = height * 0.12;
      var x = width * 0.12 + i * (containerWidth + width * 0.04);
      var y = baseY - containerHeight;
      ctx.fillStyle = "rgba(235, 240, 248, 0.92)";
      ctx.fillRect(x, y, containerWidth, containerHeight);
      ctx.strokeStyle = "rgba(120, 140, 170, 0.5)";
      ctx.lineWidth = containerWidth * 0.03;
      ctx.strokeRect(x, y, containerWidth, containerHeight);
      ctx.fillStyle = "rgba(26, 126, 242, 0.15)";
      ctx.fillRect(x + containerWidth * 0.08, y + containerHeight * 0.2, containerWidth * 0.12, containerHeight * 0.6);
      ctx.fillStyle = "rgba(18, 184, 134, 0.2)";
      ctx.fillRect(x + containerWidth * 0.3, y + containerHeight * 0.28, containerWidth * 0.4, containerHeight * 0.18);
      ctx.fillStyle = "rgba(26, 126, 242, 0.35)";
      ctx.beginPath();
      ctx.arc(x + containerWidth * 0.75, y + containerHeight * 0.55, containerHeight * 0.18, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function drawRealisticDashboard(ctx, width, height, rng) {
    var gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, "rgba(12, 28, 48, 0.98)");
    gradient.addColorStop(1, "rgba(18, 40, 66, 0.96)");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    var panelMargin = width * 0.06;
    var panelWidth = width - panelMargin * 2;
    var panelHeight = height - panelMargin * 2;
    ctx.fillStyle = "rgba(18, 24, 36, 0.7)";
    ctx.fillRect(panelMargin, panelMargin, panelWidth, panelHeight);

    ctx.strokeStyle = "rgba(36, 96, 180, 0.6)";
    ctx.lineWidth = 2;
    ctx.strokeRect(panelMargin, panelMargin, panelWidth, panelHeight);

    var gridRows = 6;
    var gridCols = 10;
    ctx.strokeStyle = "rgba(48, 92, 140, 0.4)";
    ctx.lineWidth = 1;
    for (var i = 1; i < gridRows; i++) {
      var y = panelMargin + (panelHeight / gridRows) * i;
      ctx.beginPath();
      ctx.moveTo(panelMargin, y);
      ctx.lineTo(panelMargin + panelWidth, y);
      ctx.stroke();
    }
    for (var j = 1; j < gridCols; j++) {
      var x = panelMargin + (panelWidth / gridCols) * j;
      ctx.beginPath();
      ctx.moveTo(x, panelMargin);
      ctx.lineTo(x, panelMargin + panelHeight);
      ctx.stroke();
    }

    var chartX = panelMargin + panelWidth * 0.08;
    var chartY = panelMargin + panelHeight * 0.15;
    var chartWidth = panelWidth * 0.56;
    var chartHeight = panelHeight * 0.5;
    ctx.fillStyle = "rgba(20, 36, 58, 0.9)";
    ctx.fillRect(chartX, chartY, chartWidth, chartHeight);

    ctx.strokeStyle = "rgba(88, 204, 154, 0.8)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (var p = 0; p <= 40; p++) {
      var t = p / 40;
      var xPos = chartX + chartWidth * t;
      var yPos = chartY + chartHeight * (1 - Math.pow(t, 1.5) * 0.8 + (rng() - 0.5) * 0.12);
      if (p === 0) {
        ctx.moveTo(xPos, yPos);
      } else {
        ctx.lineTo(xPos, yPos);
      }
    }
    ctx.stroke();

    ctx.fillStyle = "rgba(26, 126, 242, 0.75)";
    for (var bar = 0; bar < 12; bar++) {
      var barWidth = chartWidth / 14;
      var barHeight = chartHeight * (0.25 + rng() * 0.6);
      var xBar = chartX + barWidth * 0.5 + bar * barWidth * 1.1;
      var yBar = chartY + chartHeight - barHeight;
      ctx.fillRect(xBar, yBar, barWidth, barHeight);
    }

    ctx.fillStyle = "rgba(255, 255, 255, 0.72)";
    ctx.font = "bold " + Math.round(height * 0.05) + "px " + getFontFamily();
    ctx.fillText("Operations Overview", panelMargin + panelWidth * 0.08, panelMargin + panelHeight * 0.08);

    ctx.font = "600 " + Math.round(height * 0.035) + "px " + getFontFamily();
    ctx.fillStyle = "rgba(141, 201, 255, 0.85)";
    ctx.fillText("Fleet Availability 98.4%", panelMargin + panelWidth * 0.08, panelMargin + panelHeight * 0.75);

    ctx.fillStyle = "rgba(18, 184, 134, 0.9)";
    ctx.fillRect(panelMargin + panelWidth * 0.08, panelMargin + panelHeight * 0.78, panelWidth * 0.22, panelHeight * 0.12);
    ctx.fillStyle = "rgba(255,255,255,0.85)";
    ctx.font = "500 " + Math.round(height * 0.03) + "px " + getFontFamily();
    ctx.fillText("Grid Services ↑12%", panelMargin + panelWidth * 0.09, panelMargin + panelHeight * 0.83);

    ctx.fillStyle = "rgba(18, 184, 134, 0.8)";
    ctx.beginPath();
    ctx.arc(panelMargin + panelWidth * 0.72, panelMargin + panelHeight * 0.32, panelHeight * 0.18, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "rgba(26, 126, 242, 0.82)";
    ctx.beginPath();
    ctx.moveTo(panelMargin + panelWidth * 0.72, panelMargin + panelHeight * 0.14);
    ctx.lineTo(panelMargin + panelWidth * 0.85, panelMargin + panelHeight * 0.42);
    ctx.lineTo(panelMargin + panelWidth * 0.59, panelMargin + panelHeight * 0.42);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "rgba(20, 36, 58, 0.9)";
    ctx.beginPath();
    ctx.arc(panelMargin + panelWidth * 0.72, panelMargin + panelHeight * 0.32, panelHeight * 0.11, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "rgba(141, 201, 255, 0.9)";
    ctx.font = "600 " + Math.round(height * 0.028) + "px " + getFontFamily();
    ctx.fillText("Storage Charge 68%", panelMargin + panelWidth * 0.58, panelMargin + panelHeight * 0.68);

    drawForegroundGlare(ctx, width, height);
  }

  function drawRealisticTeam(ctx, width, height, rng) {
    var gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, "rgba(16, 46, 80, 0.95)");
    gradient.addColorStop(1, "rgba(28, 62, 102, 0.9)");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    var floorGradient = ctx.createLinearGradient(0, height * 0.6, 0, height);
    floorGradient.addColorStop(0, "rgba(12, 28, 44, 0.9)");
    floorGradient.addColorStop(1, "rgba(20, 32, 48, 0.98)");
    ctx.fillStyle = floorGradient;
    ctx.fillRect(0, height * 0.6, width, height * 0.4);

    var figureCount = 4;
    for (var i = 0; i < figureCount; i++) {
      var x = width * (0.2 + i * 0.18);
      var baseY = height * 0.86;
      var scale = 0.9 + rng() * 0.2;
      drawFigure(ctx, x, baseY, scale, rng);
    }

    ctx.strokeStyle = "rgba(80, 120, 180, 0.25)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(width * 0.1, height * 0.6);
    ctx.lineTo(width * 0.9, height * 0.6);
    ctx.stroke();

    addAmbientLight(ctx, width, height, rng);
  }

  function drawFigure(ctx, baseX, baseY, scale, rng) {
    var bodyHeight = 120 * scale;
    var bodyWidth = 36 * scale;
    var headRadius = 18 * scale;
    var tint = "hsl(" + (210 + rng() * 40) + ", 40%, 60%)";

    var gradient = ctx.createLinearGradient(baseX - bodyWidth * 0.5, baseY - bodyHeight, baseX + bodyWidth * 0.5, baseY);
    gradient.addColorStop(0, "rgba(255,255,255,0.14)");
    gradient.addColorStop(1, tint);
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.moveTo(baseX - bodyWidth * 0.5, baseY);
    ctx.quadraticCurveTo(baseX - bodyWidth * 0.3, baseY - bodyHeight * 0.3, baseX - bodyWidth * 0.2, baseY - bodyHeight * 0.7);
    ctx.quadraticCurveTo(baseX, baseY - bodyHeight * 1.05, baseX + bodyWidth * 0.2, baseY - bodyHeight * 0.7);
    ctx.quadraticCurveTo(baseX + bodyWidth * 0.3, baseY - bodyHeight * 0.3, baseX + bodyWidth * 0.5, baseY);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "rgba(240, 210, 180, 0.85)";
    ctx.beginPath();
    ctx.arc(baseX, baseY - bodyHeight - headRadius * 0.2, headRadius, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = "rgba(255, 255, 255, 0.35)";
    ctx.lineWidth = 2 * scale;
    ctx.beginPath();
    ctx.moveTo(baseX, baseY - bodyHeight * 0.55);
    ctx.lineTo(baseX + bodyWidth * 0.25, baseY - bodyHeight * 0.15);
    ctx.moveTo(baseX, baseY - bodyHeight * 0.55);
    ctx.lineTo(baseX - bodyWidth * 0.25, baseY - bodyHeight * 0.15);
    ctx.stroke();

    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.beginPath();
    ctx.ellipse(baseX, baseY + 6 * scale, bodyWidth, 10 * scale, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  function drawRealisticEnvironment(ctx, width, height, rng) {
    drawSky(ctx, width, height, rng);
    drawSun(ctx, width, height, rng);
    drawClouds(ctx, width, height, rng);
    drawDistantHills(ctx, width, height, rng, { r: 40, g: 106, b: 116 });
    drawGround(ctx, width, height, rng, 130);
    drawWater(ctx, width, height, rng);
    drawTrees(ctx, width, height, rng);
    addWildlife(ctx, width, height, rng);
  }

  function drawWater(ctx, width, height, rng) {
    var waterY = height * 0.6;
    ctx.fillStyle = "rgba(36, 120, 168, 0.65)";
    ctx.fillRect(0, waterY, width, height - waterY);

    var waveCount = 6;
    ctx.strokeStyle = "rgba(255,255,255,0.25)";
    ctx.lineWidth = Math.max(1, width * 0.002);
    for (var i = 0; i < waveCount; i++) {
      var y = waterY + i * height * 0.04;
      ctx.beginPath();
      for (var x = 0; x <= width; x += width / 60) {
        var offset = Math.sin(x / width * Math.PI * 4 + i) * height * 0.01 + rng() * height * 0.005;
        ctx.lineTo(x, y + offset);
      }
      ctx.stroke();
    }
  }

  function drawTrees(ctx, width, height, rng) {
    var treeCount = 16;
    for (var i = 0; i < treeCount; i++) {
      var depth = rng();
      var baseX = width * depth;
      var baseY = height * (0.7 + rng() * 0.1);
      var treeHeight = height * (0.12 + depth * 0.18);
      ctx.fillStyle = "rgba(90, 120, 80, 0.9)";
      ctx.fillRect(baseX - width * 0.004, baseY - treeHeight * 0.2, width * 0.008, treeHeight * 0.2);
      var foliageRadius = treeHeight * 0.5;
      var shading = ctx.createRadialGradient(baseX - foliageRadius * 0.2, baseY - treeHeight * 0.6, foliageRadius * 0.2, baseX, baseY - treeHeight * 0.4, foliageRadius);
      shading.addColorStop(0, "rgba(76, 142, 92, 0.95)");
      shading.addColorStop(1, "rgba(34, 74, 52, 0.9)");
      ctx.fillStyle = shading;
      ctx.beginPath();
      ctx.moveTo(baseX, baseY - treeHeight);
      ctx.quadraticCurveTo(baseX + foliageRadius, baseY - treeHeight * 0.4, baseX, baseY);
      ctx.quadraticCurveTo(baseX - foliageRadius, baseY - treeHeight * 0.4, baseX, baseY - treeHeight);
      ctx.fill();
    }
  }

  function addWildlife(ctx, width, height, rng) {
    var birdCount = 6;
    ctx.strokeStyle = "rgba(40, 45, 60, 0.55)";
    ctx.lineWidth = 2;
    for (var i = 0; i < birdCount; i++) {
      var x = width * (0.2 + rng() * 0.6);
      var y = height * (0.2 + rng() * 0.2);
      var spread = width * 0.04;
      ctx.beginPath();
      ctx.moveTo(x - spread, y);
      ctx.quadraticCurveTo(x, y - spread * 0.3, x + spread, y);
      ctx.stroke();
    }
  }

  function drawRealisticMap(ctx, width, height, rng) {
    var backgroundGradient = ctx.createLinearGradient(0, 0, width, height);
    backgroundGradient.addColorStop(0, "rgba(18, 30, 46, 0.95)");
    backgroundGradient.addColorStop(1, "rgba(32, 54, 84, 0.92)");
    ctx.fillStyle = backgroundGradient;
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = "rgba(255,255,255,0.05)";
    ctx.lineWidth = 1;
    var lines = 20;
    for (var i = 1; i < lines; i++) {
      var pos = (width / lines) * i;
      ctx.beginPath();
      ctx.moveTo(pos, 0);
      ctx.lineTo(pos, height);
      ctx.stroke();
      pos = (height / lines) * i;
      ctx.beginPath();
      ctx.moveTo(0, pos);
      ctx.lineTo(width, pos);
      ctx.stroke();
    }

    ctx.fillStyle = "rgba(46, 152, 173, 0.85)";
    var continentPaths = createMapShapes(width, height, rng);
    continentPaths.forEach(function(path) {
      ctx.beginPath();
      ctx.moveTo(path[0].x, path[0].y);
      for (var i = 1; i < path.length; i++) {
        ctx.lineTo(path[i].x, path[i].y);
      }
      ctx.closePath();
      ctx.fill();
    });

    ctx.fillStyle = "rgba(255, 198, 92, 0.95)";
    var pinCount = 7;
    for (var p = 0; p < pinCount; p++) {
      var px = width * (0.15 + rng() * 0.7);
      var py = height * (0.2 + rng() * 0.6);
      ctx.beginPath();
      ctx.arc(px, py, width * 0.012, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(px, py + width * 0.012);
      ctx.lineTo(px, py + width * 0.04);
      ctx.strokeStyle = "rgba(255, 198, 92, 0.6)";
      ctx.lineWidth = width * 0.004;
      ctx.stroke();
    }

    ctx.strokeStyle = "rgba(18, 184, 134, 0.5)";
    ctx.lineWidth = width * 0.003;
    ctx.beginPath();
    ctx.moveTo(width * 0.2, height * 0.75);
    ctx.bezierCurveTo(width * 0.35, height * 0.5, width * 0.55, height * 0.7, width * 0.78, height * 0.33);
    ctx.stroke();

    ctx.setLineDash([8, 6]);
    ctx.strokeStyle = "rgba(26, 126, 242, 0.45)";
    ctx.lineWidth = width * 0.0025;
    ctx.beginPath();
    ctx.moveTo(width * 0.35, height * 0.4);
    ctx.quadraticCurveTo(width * 0.5, height * 0.15, width * 0.68, height * 0.48);
    ctx.stroke();
    ctx.setLineDash([]);

    drawForegroundGlare(ctx, width, height);
  }

  function createMapShapes(width, height, rng) {
    var shapes = [];
    var continentCount = 3 + Math.floor(rng() * 2);
    for (var c = 0; c < continentCount; c++) {
      var points = [];
      var centerX = width * (0.2 + c * 0.25 + rng() * 0.1);
      var centerY = height * (0.3 + rng() * 0.4);
      var radius = Math.min(width, height) * (0.12 + rng() * 0.08);
      var pointCount = 10 + Math.floor(rng() * 6);
      for (var p = 0; p < pointCount; p++) {
        var angle = (Math.PI * 2 * p) / pointCount;
        var radiusOffset = radius * (0.6 + rng() * 0.5);
        points.push({
          x: centerX + Math.cos(angle) * radiusOffset,
          y: centerY + Math.sin(angle) * radiusOffset
        });
      }
      shapes.push(points);
    }
    return shapes;
  }

  function drawRealisticSolarArrayInDefault(ctx, width, height, rng) {
    var baseY = height * 0.72;
    var panelCount = 4;
    for (var i = 0; i < panelCount; i++) {
      var panelWidth = width * 0.18;
      var panelHeight = height * 0.12;
      var x = width * 0.18 + i * (panelWidth + width * 0.04);
      var y = baseY - panelHeight;
      var gradient = ctx.createLinearGradient(x, y, x + panelWidth, y + panelHeight * 0.2);
      gradient.addColorStop(0, "rgba(24, 48, 78, 0.94)");
      gradient.addColorStop(1, "rgba(15, 24, 39, 0.85)");
      ctx.fillStyle = gradient;
      ctx.fillRect(x, y, panelWidth, panelHeight);
      ctx.fillStyle = "rgba(255,255,255,0.12)";
      for (var col = 1; col < 6; col++) {
        var cx = x + panelWidth * (col / 6);
        ctx.fillRect(cx, y, panelWidth * 0.004, panelHeight);
      }
    }
  }

  function drawRealisticMapOverlay(ctx, width, height, rng) {
    ctx.strokeStyle = "rgba(255,255,255,0.2)";
    ctx.lineWidth = width * 0.002;
    ctx.beginPath();
    ctx.moveTo(width * 0.6, height * 0.78);
    ctx.bezierCurveTo(width * 0.7, height * 0.6, width * 0.85, height * 0.5, width * 0.78, height * 0.32);
    ctx.stroke();
    ctx.fillStyle = "rgba(18, 184, 134, 0.32)";
    ctx.beginPath();
    ctx.arc(width * 0.78, height * 0.32, width * 0.05, 0, Math.PI * 2);
    ctx.fill();
  }

  function drawDefaultScene(ctx, width, height, rng) {
    drawSky(ctx, width, height, rng);
    drawSun(ctx, width, height, rng);
    drawClouds(ctx, width, height, rng);
    drawDistantHills(ctx, width, height, rng, { r: 44, g: 93, b: 120 });
    drawGround(ctx, width, height, rng, 135);
    drawRealisticSolarArrayInDefault(ctx, width, height, rng);
    drawRealisticMapOverlay(ctx, width, height, rng);
    drawForegroundDetails(ctx, width, height, rng);
  }

  function drawForegroundDetails(ctx, width, height, rng) {
    ctx.fillStyle = "rgba(18, 184, 134, 0.15)";
    var highlightWidth = width * 0.6;
    var highlightHeight = height * 0.15;
    ctx.beginPath();
    ctx.ellipse(width * 0.5, height * 0.78, highlightWidth, highlightHeight, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = "rgba(255,255,255,0.1)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(width * 0.1, height * 0.74);
    ctx.lineTo(width * 0.9, height * 0.74);
    ctx.stroke();
  }

  function drawForegroundGlare(ctx, width, height) {
    var glare = ctx.createLinearGradient(0, 0, width, 0);
    glare.addColorStop(0, "rgba(255,255,255,0.16)");
    glare.addColorStop(0.25, "rgba(255,255,255,0.05)");
    glare.addColorStop(0.75, "rgba(255,255,255,0.08)");
    glare.addColorStop(1, "rgba(255,255,255,0.12)");
    ctx.fillStyle = glare;
    ctx.fillRect(0, 0, width, height);
  }

  function getFontFamily() {
    return "\"Segoe UI\", \"Roboto\", \"Helvetica Neue\", Arial, sans-serif";
  }

  var resizeTimer = null;
  window.addEventListener("resize", function() {
    if (resizeTimer) {
      window.clearTimeout(resizeTimer);
    }
    resizeTimer = window.setTimeout(function() {
      generateDynamicImages();
    }, 150);
  });

  function syncYear() {
    var yearSpans = document.querySelectorAll("[data-year]");
    var year = new Date().getFullYear();
    yearSpans.forEach(function(node) {
      node.textContent = String(year);
    });
  }

  window.addEventListener("load", function() {
    syncYear();
    generateDynamicImages();
  });

  window.addEventListener("pageshow", function() {
    syncYear();
    generateDynamicImages();
  });
})();