document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (toggle && navLinks) {
        toggle.addEventListener('click', () => {
            navLinks.classList.toggle('is-open');
        });
    }

    const filterButtons = document.querySelectorAll('[data-filter]');
    const filterTargets = document.querySelectorAll('.filter-target');

    if (filterButtons.length && filterTargets.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const choice = button.getAttribute('data-filter');
                filterButtons.forEach(btn => btn.classList.remove('is-active'));
                button.classList.add('is-active');

                filterTargets.forEach(card => {
                    const categories = card.getAttribute('data-category').split(',');
                    if (choice === 'all' || categories.includes(choice)) {
                        card.style.display = '';
                        requestAnimationFrame(() => {
                            card.style.opacity = '1';
                        });
                    } else {
                        card.style.opacity = '0';
                        setTimeout(() => {
                            card.style.display = 'none';
                        }, 200);
                    }
                });
            });
        });
    }

    document.querySelectorAll('.story-carousel').forEach(carousel => {
        const track = carousel.querySelector('.story-track');
        const slides = Array.from(track.children);
        const prevBtn = carousel.querySelector('.carousel-nav.prev');
        const nextBtn = carousel.querySelector('.carousel-nav.next');
        const dots = carousel.querySelectorAll('.carousel-dot');
        let index = 0;

        const updateCarousel = () => {
            track.style.transform = `translateX(-${index * 100}%)`;
            dots.forEach((dot, idx) => {
                dot.classList.toggle('is-active', idx === index);
            });
        };

        if (prevBtn && nextBtn) {
            prevBtn.addEventListener('click', () => {
                index = (index - 1 + slides.length) % slides.length;
                updateCarousel();
            });

            nextBtn.addEventListener('click', () => {
                index = (index + 1) % slides.length;
                updateCarousel();
            });
        }

        dots.forEach((dot, idx) => {
            dot.addEventListener('click', () => {
                index = idx;
                updateCarousel();
            });
        });

        updateCarousel();
    });

    document.querySelectorAll('[data-comment-board]').forEach(board => {
        const nameInput = board.querySelector('[data-comment-name]');
        const messageInput = board.querySelector('[data-comment-message]');
        const addButton = board.querySelector('[data-comment-submit]');
        const list = board.querySelector('[data-comment-list]');

        if (addButton && nameInput && messageInput && list) {
            addButton.addEventListener('click', () => {
                const name = nameInput.value.trim();
                const message = messageInput.value.trim();
                if (!name || !message) {
                    return;
                }
                const entry = document.createElement('div');
                entry.className = 'comment-entry';
                const timestamp = new Date().toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
                entry.innerHTML = `<strong>${name} — <span style="font-weight:400;color:var(--color-mid);">${timestamp}</span></strong><p>${message}</p>`;
                list.prepend(entry);
                nameInput.value = '';
                messageInput.value = '';
            });
        }
    });

    const banner = document.getElementById('cookie-banner');
    const cookieChoices = document.querySelectorAll('.cookie-choice');
    const storageKey = 'genuscayqg_cookie_choice';

    const setChoice = (choice) => {
        try {
            localStorage.setItem(storageKey, JSON.stringify({ choice, timestamp: Date.now() }));
        } catch (error) {
            console.warn('Cookie preference could not be stored.', error);
        }
        if (banner) {
            banner.classList.remove('is-visible');
        }
    };

    if (banner) {
        const saved = localStorage.getItem(storageKey);
        if (!saved) {
            setTimeout(() => {
                banner.classList.add('is-visible');
            }, 800);
        }
    }

    cookieChoices.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const choice = link.getAttribute('data-choice') || 'accepted';
            setChoice(choice);
        });
    });
});