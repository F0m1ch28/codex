import React from "react";
import { Link } from "react-router-dom";

function HomePage() {
  return (
    <div className="page">
      <section className="hero">
        <div className="hero__content">
          <span className="hero__badge">Стратегии роста на основе данных</span>
          <h1 className="hero__title">
            Сайт компании: комплексные бизнес-решения для ускорения успеха.
          </h1>
          <p className="hero__subtitle">
            Мы объединяем стратегию, аналитику и технологии, чтобы помочь компаниям эффективно масштабироваться и выходить на новые рынки.
          </p>
          <div className="hero__actions">
            <Link to="/services" className="btn">
              Наши услуги
            </Link>
            <Link to="/contact" className="btn btn--secondary">
              Связаться с нами
            </Link>
          </div>
        </div>
        <div className="hero__visual">
          <div className="hero__card">
            <h3>Ключевые показатели</h3>
            <ul>
              <li>+35% рост выручки клиентов</li>
              <li>20 стран присутствия проектов</li>
              <li>100+ реализованных инициатив</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="section">
        <h2 className="section__title">Почему выбирают нас</h2>
        <div className="features-grid">
          <div className="feature-card">
            <h3>Экспертиза</h3>
            <p>
              Команда с многолетним опытом в стратегическом консалтинге, развитии цифровых продуктов и управлении трансформацией.
            </p>
          </div>
          <div className="feature-card">
            <h3>Инновации</h3>
            <p>
              Применяем лучшие технологии и аналитические инструменты, чтобы быстро выявлять возможности и устранять риски.
            </p>
          </div>
          <div className="feature-card">
            <h3>Поддержка</h3>
            <p>
              Сопровождаем клиентов на каждом этапе реализации, обеспечивая прозрачность и измеримый результат.
            </p>
          </div>
        </div>
      </section>

      <section className="section section--accent">
        <div className="section__content">
          <h2 className="section__title section__title--light">
            Результат, который работает на ваш бизнес
          </h2>
          <p className="section__text section__text--light">
            Сайт компании помогает организациям масштабировать операции, оптимизировать процессы и повышать конкурентоспособность благодаря комплексной поддержке.
          </p>
          <Link to="/about" className="btn btn--light">
            Узнать подробнее
          </Link>
        </div>
      </section>

      <section className="section">
        <h2 className="section__title">Ключевые направления работы</h2>
        <div className="stats-grid">
          <div className="stat-card">
            <span className="stat-card__value">01</span>
            <p className="stat-card__text">Стратегическое планирование и аналитика</p>
          </div>
          <div className="stat-card">
            <span className="stat-card__value">02</span>
            <p className="stat-card__text">Цифровая трансформация процессов</p>
          </div>
          <div className="stat-card">
            <span className="stat-card__value">03</span>
            <p className="stat-card__text">Развитие международного присутствия</p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default HomePage;