import React from "react";

function ServicesPage() {
  const services = [
    {
      title: "Стратегический консалтинг",
      description:
        "Разработка стратегий роста, формирование сбалансированных портфелей продуктов, оценка потенциала рынков и моделирование финансовых сценариев.",
    },
    {
      title: "Цифровая трансформация",
      description:
        "Анализ текущих процессов, разработка цифровых дорожных карт, внедрение ERP/CRM решений и автоматизация ключевых бизнес-функций.",
    },
    {
      title: "Аналитика и BI",
      description:
        "Создание систем мониторинга показателей, разработка BI-дашбордов, внедрение интеллектуальной отчетности и data governance.",
    },
    {
      title: "Выход на международные рынки",
      description:
        "Маркетинговые исследования, локализация предложений, построение партнерских сетей и сопровождение экспортных операций.",
    },
    {
      title: "Управление изменениями",
      description:
        "Коммуникационные программы, обучение команд, управленческий коучинг и поддержка внедрения изменений в организации.",
    },
  ];

  return (
    <div className="page">
      <section className="section">
        <h1 className="section__title">Услуги</h1>
        <p className="section__text">
          Мы предлагаем полный спектр услуг, направленных на создание устойчивого конкурентного преимущества. Наши решения нацелены на усиление бизнес-процессов, оптимизацию затрат и раскрытие потенциала данных.
        </p>
      </section>

      <section className="section">
        <div className="services-grid">
          {services.map((service) => (
            <div className="service-card" key={service.title}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section section--accent">
        <div className="section__content">
          <h2 className="section__title section__title--light">
            Нужна индивидуальная стратегия?
          </h2>
          <p className="section__text section__text--light">
            Свяжитесь с нами, чтобы обсудить задачу и получить персональное предложение по развитию вашего бизнеса.
          </p>
          <a href="mailto:info@site-kompanii.ru" className="btn btn--light">
            Запросить консультацию
          </a>
        </div>
      </section>
    </div>
  );
}

export default ServicesPage;