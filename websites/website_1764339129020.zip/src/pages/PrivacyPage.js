import React from "react";

function PrivacyPage() {
  return (
    <div className="page">
      <section className="section">
        <h1 className="section__title">Политика конфиденциальности</h1>
        <p className="section__text">
          ООО «Сайт компании» уважает конфиденциальность пользователей и придерживается принципов защиты персональных данных в соответствии с действующим законодательством.
        </p>
        <h2 className="section__subtitle">1. Какие данные мы собираем</h2>
        <p className="section__text">
          Мы можем получать имя, контактные данные, информацию о компании, а также технические данные (IP-адрес, тип устройства, cookies) для улучшения работы сайта.
        </p>
        <h2 className="section__subtitle">2. Цели обработки</h2>
        <p className="section__text">
          Данные используются для обратной связи, предоставления услуг, аналитики трафика и персонализации контента.
        </p>
        <h2 className="section__subtitle">3. Передача данных</h2>
        <p className="section__text">
          Мы не передаём персональные данные третьим лицам без согласия, за исключением случаев, предусмотренных законом или необходимых для исполнения обязательств.
        </p>
        <h2 className="section__subtitle">4. Безопасность</h2>
        <p className="section__text">
          Компания применяет организационные и технические меры, чтобы защитить данные от несанкционированного доступа, изменения или раскрытия.
        </p>
        <h2 className="section__subtitle">5. Права пользователей</h2>
        <p className="section__text">
          Вы можете запросить доступ, обновление или удаление ваших данных, отправив запрос на info@site-kompanii.ru.
        </p>
        <h2 className="section__subtitle">6. Cookies</h2>
        <p className="section__text">
          Мы используем файлы cookie для анализа активности и повышения удобства. Вы можете управлять настройками cookie в браузере или через баннер на сайте.
        </p>
        <h2 className="section__subtitle">7. Обновления политики</h2>
        <p className="section__text">
          Политика может меняться. Актуальная версия публикуется на этой странице. Рекомендуем периодически проверять обновления.
        </p>
      </section>
    </div>
  );
}

export default PrivacyPage;