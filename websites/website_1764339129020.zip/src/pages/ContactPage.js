import React from "react";

function ContactPage() {
  return (
    <div className="page">
      <section className="section">
        <h1 className="section__title">Контакты</h1>
        <p className="section__text">
          Мы готовы обсудить ваши задачи и предложить решения, соответствующие целям бизнеса. Выберите удобный способ связи.
        </p>
        <div className="contact-grid">
          <div className="contact-card">
            <h3>ООО «Сайт компании»</h3>
            <p>Москва, ул. Пушкина, д. 10</p>
            <p>
              Телефон:{" "}
              <a href="tel:+74951234567">
                +7 (495) 123-45-67
              </a>
            </p>
            <p>
              Email:{" "}
              <a href="mailto:info@site-kompanii.ru">
                info@site-kompanii.ru
              </a>
            </p>
            <p>График: Пн-Пт, 09:00–18:00 (мск)</p>
          </div>
          <form className="contact-form">
            <h3>Напишите нам</h3>
            <label className="form-field">
              <span>Имя</span>
              <input type="text" name="name" placeholder="Ваше имя" required />
            </label>
            <label className="form-field">
              <span>Email</span>
              <input type="email" name="email" placeholder="Ваш email" required />
            </label>
            <label className="form-field">
              <span>Компания</span>
              <input type="text" name="company" placeholder="Название компании" />
            </label>
            <label className="form-field">
              <span>Сообщение</span>
              <textarea name="message" rows="4" placeholder="Опишите запрос" required />
            </label>
            <button type="submit" className="btn">
              Отправить
            </button>
            <p className="form-disclaimer">
              Отправляя форму, вы соглашаетесь с{" "}
              <a href="/privacy">Политикой конфиденциальности</a>.
            </p>
          </form>
        </div>
      </section>
    </div>
  );
}

export default ContactPage;