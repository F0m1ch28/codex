import React from "react";

function ImprintPage() {
  return (
    <div className="page">
      <section className="section">
        <h1 className="section__title">Импринт</h1>
        <p className="section__text">
          ООО «Сайт компании»
        </p>
        <p className="section__text">
          Юридический адрес: Москва, ул. Пушкина, д. 10
        </p>
        <p className="section__text">
          Телефон: +7 (495) 123-45-67
        </p>
        <p className="section__text">
          Email: info@site-kompanii.ru
        </p>
        <p className="section__text">
          Генеральный директор: Анна Смирнова
        </p>
        <p className="section__text">
          ОГРН: 0000000000000
        </p>
        <p className="section__text">
          ИНН: 0000000000
        </p>
        <p className="section__text">
          Настоящая страница содержит обязательную информацию об операторе сайта согласно требованиям законодательства.
        </p>
      </section>
    </div>
  );
}

export default ImprintPage;