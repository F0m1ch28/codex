import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  return (
    <header className="header">
      <div className="header__inner">
        <Link to="/" className="header__logo">
          Сайт компании
        </Link>
        <button
          className="header__toggle"
          aria-label="Открыть меню"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`header__nav ${menuOpen ? "header__nav--open" : ""}`}>
          <Link to="/" className="header__link">
            Главная
          </Link>
          <Link to="/about" className="header__link">
            О компании
          </Link>
          <Link to="/services" className="header__link">
            Услуги
          </Link>
          <Link to="/contact" className="header__link">
            Контакты
          </Link>
          <Link to="/terms" className="header__link">
            Условия
          </Link>
          <Link to="/privacy" className="header__link">
            Конфиденциальность
          </Link>
          <Link to="/imprint" className="header__link">
            Импринт
          </Link>
        </nav>
      </div>
    </header>
  );
}

export default Header;