import React, { useEffect, useState } from "react";

const STORAGE_KEY = "cookieConsentStatus";

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const savedStatus = localStorage.getItem(STORAGE_KEY);
    if (!savedStatus) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem(STORAGE_KEY, choice);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner">
      <div className="cookie-banner__content">
        <p>
          Мы используем файлы cookie для улучшения работы сайта, анализа трафика и персонализации контента. Вы можете принять или отклонить использование необязательныхcookie.
        </p>
        <div className="cookie-banner__actions">
          <button
            className="btn btn--secondary"
            onClick={() => handleChoice("declined")}
          >
            Отклонить
          </button>
          <button className="btn" onClick={() => handleChoice("accepted")}>
            Принять
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;