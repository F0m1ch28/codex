import React from "react";
import { Link } from "react-router-dom";

const contactInfo = {
  company: "ООО «Сайт компании»",
  address: "Москва, ул. Пушкина, д. 10",
  phone: "+7 (495) 123-45-67",
  email: "info@site-kompanii.ru",
};

function Footer() {
  return (
    <footer className="footer">
      <div className="footer__grid">
        <div>
          <h3 className="footer__title">О компании</h3>
          <p>
            ООО «Сайт компании» предоставляет комплексные решения для ускоренного роста бизнеса на международных рынках.
          </p>
        </div>
        <div>
          <h3 className="footer__title">Контакты</h3>
          <ul className="footer__list">
            <li>{contactInfo.company}</li>
            <li>{contactInfo.address}</li>
            <li>
              Тел.: <a href={`tel:${contactInfo.phone.replace(/[^+\d]/g, "")}`}>{contactInfo.phone}</a>
            </li>
            <li>
              Email: <a href={`mailto:${contactInfo.email}`}>{contactInfo.email}</a>
            </li>
          </ul>
        </div>
        <div>
          <h3 className="footer__title">Юридическая информация</h3>
          <ul className="footer__list footer__list--links">
            <li>
              <Link to="/terms">Условия использования</Link>
            </li>
            <li>
              <Link to="/privacy">Политика конфиденциальности</Link>
            </li>
            <li>
              <Link to="/imprint">Импринт</Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="footer__bottom">
        <span>© {new Date().getFullYear()} ООО «Сайт компании». Все права защищены.</span>
      </div>
    </footer>
  );
}

export default Footer;