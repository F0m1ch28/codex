document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector("[data-js='nav-toggle']");
  const nav = document.querySelector("[data-js='site-nav']");
  const header = document.querySelector("[data-js='site-header']");
  const yearEl = document.getElementById("current-year");
  const animatedElements = document.querySelectorAll("[data-animate]");
  const valuesList = document.querySelector("[data-js='values-list']");

  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
      if (isOpen) {
        navToggle.setAttribute("aria-label", "Close menu");
      } else {
        navToggle.setAttribute("aria-label", "Open menu");
      }
    });

    nav.addEventListener("click", (event) => {
      if (event.target instanceof HTMLAnchorElement && nav.classList.contains("is-open")) {
        nav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  const handleScroll = () => {
    if (!header) return;
    if (window.scrollY > 24) {
      header.classList.add("is-scrolled");
    } else {
      header.classList.remove("is-scrolled");
    }
  };

  handleScroll();
  window.addEventListener("scroll", handleScroll, { passive: true });

  if ("IntersectionObserver" in window && animatedElements.length > 0) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.1
      }
    );

    animatedElements.forEach((element) => observer.observe(element));
  } else {
    animatedElements.forEach((element) => element.classList.add("is-visible"));
  }

  if (valuesList) {
    fetch("assets/values.json")
      .then((response) => {
        if (!response.ok) throw new Error("Unable to load values");
        return response.json();
      })
      .then((data) => {
        if (!Array.isArray(data.values)) return;
        valuesList.innerHTML = "";
        data.values.forEach((value) => {
          const item = document.createElement("li");
          item.className = "values-list__item";
          const title = document.createElement("h3");
          title.className = "values-list__title";
          title.textContent = value.title;
          const description = document.createElement("p");
          description.className = "values-list__description";
          description.textContent = value.description;
          item.appendChild(title);
          item.appendChild(description);
          valuesList.appendChild(item);
        });
      })
      .catch(() => {
        // Leave default static list if fetch fails
      });
  }
});