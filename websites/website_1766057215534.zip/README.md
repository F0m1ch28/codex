# Verdant Horizons Eco Retreat

Verdant Horizons is a multi-page eco-luxury retreat website designed to showcase immersive nature experiences, regenerative architecture, and holistic wellness rituals.

## Structure
- `index.html` — Landing page with hero, signature experiences, and testimonials.
- `about.html` — Retreat story, timeline, and core values dynamically loaded via JSON.
- `services.html` — Detailed overview of seasonal programs and enhancements.
- `contact.html` — Reservation inquiry form with concierge details.

## Technology
- Semantic HTML5 with accessible navigation and focus handling.
- Modern CSS architecture emphasizing reusable utility classes, responsive grids, and fluid typography.
- Adaptive imagery implemented with `<picture>`, `srcset`, and `sizes`, referencing real Pexels assets at multiple breakpoints.
- JavaScript handles navigation toggling, header state, intersection-based animations, and dynamic value rendering from `assets/values.json`.

## Assets
- `styles.css` — Global styles, responsive layout, and component definitions.
- `script.js` — Progressive enhancement scripts.
- `assets/pattern.svg` — SVG background pattern applied to accent sections.
- `assets/values.json` — Source data for guiding values on the About page.

## Usage
1. Serve files via any static host.
2. Update `form` action in `contact.html` with your endpoint.
3. Replace `favicon.png` if a custom mark is preferred.
4. Adjust URLs in `sitemap.xml` and `robots.txt` for your production domain.

## Licensing
Imagery is sourced from Pexels and subject to the Pexels license. Ensure compliance with trademark usage for Verdant Horizons branding.