import React, { useState, useEffect, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const statsData = [
  { label: 'Successful launches', value: 160 },
  { label: 'Enterprise clients', value: 85 },
  { label: 'Strategic partnerships', value: 40 },
  { label: 'Countries served', value: 22 }
];

const servicesData = [
  {
    title: 'Custom Software Development',
    description:
      'Build resilient platforms tailored to your business operations with scalable architecture and human-centered design.',
    link: '/services#custom-software'
  },
  {
    title: 'Cloud Solutions',
    description:
      'Modernize infrastructure, optimize costs, and accelerate delivery through secure, cloud-native ecosystems.',
    link: '/services#cloud-solutions'
  },
  {
    title: 'IT Consulting',
    description:
      'Align technology with strategy through executive-level advisory, assessments, and roadmaps that unlock growth.',
    link: '/services#it-consulting'
  },
  {
    title: 'Digital Transformation',
    description:
      'Reimagine experiences, streamline workflows, and cultivate high-performing digital cultures at scale.',
    link: '/services#digital-transformation'
  }
];

const whyItems = [
  {
    title: 'Strategic partnership',
    description: 'We integrate with your strategy, co-creating measurable value from the first sprint.'
  },
  {
    title: 'Engineering excellence',
    description: 'Our teams blend product vision with rigorous engineering, ensuring quality at every release.'
  },
  {
    title: 'Velocity with control',
    description: 'Disciplined agile delivery keeps momentum high while maintaining secure, compliant systems.'
  },
  {
    title: 'Human-centered approach',
    description: 'We design experiences around the people that rely on them—customers, employees, and stakeholders.'
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Discover & Align',
    description:
      'We deep dive into your objectives, user journeys, and operating realities to establish a shared vision and success metrics.'
  },
  {
    step: '02',
    title: 'Design & Validate',
    description:
      'Rapid co-creation and prototyping validate assumptions early, aligning teams, users, and stakeholders on direction.'
  },
  {
    step: '03',
    title: 'Build & Integrate',
    description:
      'Our cross-functional squads build iteratively with automated QA, security reviews, and transparent communication.'
  },
  {
    step: '04',
    title: 'Launch & Scale',
    description:
      'After launch we continue to monitor, optimize, and scale, ensuring long-term reliability and continuous improvement.'
  }
];

const testimonialsData = [
  {
    quote:
      'TechSolutions helped us reimagine our global supply chain platform. Their team quickly aligned with our enterprise standards while bringing fresh ideas. We delivered a launch-ready solution in record time.',
    name: 'Emily Carter',
    role: 'Chief Operations Officer, NexaLogix'
  },
  {
    quote:
      'From roadmap to rollout, they were embedded partners. The engineering craftsmanship and focus on change management drove adoption across 14 markets without disruption.',
    name: 'Liam Patel',
    role: 'VP Digital Transformation, Horizon Retail Group'
  },
  {
    quote:
      'Their leadership team is exceptional. They anticipate risks, communicate with clarity, and continuously look for ways to create value. We trust them with our most critical initiatives.',
    name: 'Sophia Nguyen',
    role: 'Head of Technology, Meridian Health Systems'
  }
];

const teamMembers = [
  {
    name: 'Jordan Blake',
    role: 'Chief Technology Officer',
    bio: 'Architects enterprise-grade systems with a passion for resilient cloud ecosystems and mentoring engineering leaders.',
    image: 'https://picsum.photos/400/400?random=301'
  },
  {
    name: 'Priya Desai',
    role: 'Director of Product Strategy',
    bio: 'Bridges business vision with design thinking to craft digital experiences that move metrics and inspire teams.',
    image: 'https://picsum.photos/400/400?random=302'
  },
  {
    name: 'Marcus Chen',
    role: 'Head of Delivery',
    bio: 'Drives outcome-based delivery, ensuring every program progresses with transparency, accountability, and velocity.',
    image: 'https://picsum.photos/400/400?random=303'
  },
  {
    name: 'Isabella Reyes',
    role: 'Principal Cloud Architect',
    bio: 'Specializes in multi-cloud architectures, security posture, and automation strategies for complex enterprises.',
    image: 'https://picsum.photos/400/400?random=304'
  }
];

const projectsData = [
  {
    title: 'Intelligent Logistics Platform',
    category: 'Cloud Solutions',
    description:
      'Modernized a legacy ecosystem into a unified, cloud-native platform that orchestrates global freight in real time.',
    image: 'https://picsum.photos/1200/800?random=401'
  },
  {
    title: 'Digital Patient Companion',
    category: 'Digital Transformation',
    description:
      'Designed and delivered a regulatory-compliant mobile experience supporting personalized care and remote monitoring.',
    image: 'https://picsum.photos/1200/800?random=402'
  },
  {
    title: 'AI-Powered Portfolio Hub',
    category: 'Custom Software',
    description:
      'Created an AI-assisted analytics suite that empowers investment teams with predictive insights and scenario modeling.',
    image: 'https://picsum.photos/1200/800?random=403'
  },
  {
    title: 'Global Workforce Portal',
    category: 'IT Consulting',
    description:
      'Led the enterprise strategy and implementation of a unified portal enabling hybrid collaboration across 60,000 employees.',
    image: 'https://picsum.photos/1200/800?random=404'
  }
];

const faqData = [
  {
    question: 'How do you structure project teams?',
    answer:
      'We assemble cross-functional squads tailored to each engagement, blending product strategists, UX specialists, solution architects, engineers, and delivery leads. Teams scale dynamically based on roadmap priorities.'
  },
  {
    question: 'Which industries do you specialize in?',
    answer:
      'We bring deep experience across healthcare, financial services, logistics, retail, and high-growth SaaS organizations, applying sector-specific insights and compliance expertise.'
  },
  {
    question: 'What is your approach to knowledge transfer?',
    answer:
      'Our engagements include thorough documentation, collaborative workshops, and enablement sessions to ensure your teams are confident operating and evolving the solutions we build together.'
  },
  {
    question: 'Can you integrate with our existing vendors?',
    answer:
      'Absolutely. We regularly collaborate with internal teams and external partners, establishing clear communication rhythms and integration plans to align everyone around shared outcomes.'
  }
];

const blogPosts = [
  {
    title: 'Building Future-Ready Platforms with Composable Architecture',
    date: 'January 10, 2024',
    excerpt:
      'Explore how modular, composable patterns accelerate delivery, reduce technical debt, and create adaptable ecosystems ready for what’s next.',
    link: '/blog'
  },
  {
    title: 'Designing Responsible AI: Frameworks for Enterprise Leaders',
    date: 'December 20, 2023',
    excerpt:
      'Responsible AI requires more than compliance. We outline guiding principles to responsibly innovate while protecting trust.',
    link: '/blog'
  },
  {
    title: 'Scaling Product Delivery with Secure DevOps Pipelines',
    date: 'November 30, 2023',
    excerpt:
      'Learn how our teams blend governance, automation, and developer velocity to ship secure software without sacrificing speed.',
    link: '/blog'
  }
];

const Home = () => {
  const [statsVisible, setStatsVisible] = useState(false);
  const [countValues, setCountValues] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('All');
  const [faqOpen, setFaqOpen] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });
  const [formErrors, setFormErrors] = useState({});
  const [formSuccess, setFormSuccess] = useState('');
  const statsRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setStatsVisible(true);
          }
        });
      },
      { threshold: 0.4 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => {
      if (statsRef.current) {
        observer.unobserve(statsRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!statsVisible) return;

    const duration = 1400;
    const start = performance.now();

    const animate = (timestamp) => {
      const progress = Math.min((timestamp - start) / duration, 1);

      const updatedValues = statsData.map((stat) =>
        Math.floor(stat.value * progress)
      );
      setCountValues(updatedValues);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [statsVisible]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const categories = ['All', ...new Set(projectsData.map((project) => project.category))];
  const filteredProjects =
    activeCategory === 'All'
      ? projectsData
      : projectsData.filter((project) => project.category === activeCategory);

  const handleFaqToggle = (index) => {
    setFaqOpen((prev) => (prev === index ? null : index));
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    setFormErrors((prev) => ({
      ...prev,
      [name]: ''
    }));
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.name.trim()) errors.name = 'Please enter your name.';
    if (!formData.email.trim()) {
      errors.email = 'Please enter your email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Please provide a valid email address.';
    }
    if (!formData.message.trim()) errors.message = 'Please share a short message.';
    return errors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const errors = validateForm();
    if (Object.keys(errors).length) {
      setFormErrors(errors);
      setFormSuccess('');
      return;
    }

    setFormSuccess('Thank you for reaching out. Our consultants will contact you shortly.');
    setFormData({
      name: '',
      email: '',
      company: '',
      message: ''
    });
  };

  return (
    <>
      <Helmet>
        <title>TechSolutions | IT Consulting & Software Development Experts</title>
        <meta
          name="description"
          content="TechSolutions delivers strategic IT consulting, custom software development, cloud solutions, and digital transformation that empower organizations to move faster with confidence."
        />
        <link rel="canonical" href="https://www.techsolutions.com/" />
      </Helmet>
      <section
        className={styles.hero}
        style={{
          backgroundImage: 'url(https://picsum.photos/1600/900?random=101)'
        }}
      >
        <div className={styles.heroOverlay}>
          <div className="container">
            <div className={styles.heroContent}>
              <span className={styles.heroBadge}>IT Consulting & Engineering</span>
              <h1 className={styles.heroTitle}>
                Build technology that outpaces change, empowers teams, and delights customers.
              </h1>
              <p className={styles.heroSubtitle}>
                We translate complex ambitions into resilient digital platforms through strategy,
                design, and engineering excellence—all anchored in measurable outcomes.
              </p>
              <div className={styles.heroActions}>
                <Link to="/contact" className="btn btn-primary">
                  Talk to an expert
                </Link>
                <Link to="/services" className="btn btn-secondary">
                  Explore services
                </Link>
              </div>
              <div className={styles.heroStats}>
                <div>
                  <span>2x faster</span>
                  <p>Average time-to-market acceleration</p>
                </div>
                <div>
                  <span>98%</span>
                  <p>Client satisfaction across programs</p>
                </div>
                <div>
                  <span>15M+</span>
                  <p>Users impacted by our solutions</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats} ref={statsRef} aria-label="Company achievements">
        <div className="container">
          <div className={styles.statsCard}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statItem}>
                <strong aria-live="polite">
                  {countValues[index]}
                  {stat.label === 'Successful launches' ? '+' : ''}
                </strong>
                <span>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.about}>
        <div className="container">
          <div className={styles.aboutContent}>
            <div className={styles.aboutText}>
              <span className="section-tag">About TechSolutions</span>
              <h2>We help ambitious organizations design, build, and scale digital experiences.</h2>
              <p>
                TechSolutions is an independent consultancy built by technologists, product leaders,
                and change agents. We partner with executives who are ready to modernize legacy
                systems, launch new ventures, and cultivate stronger customer experiences.
              </p>
              <p>
                Our teams embed alongside yours to align strategy, streamline delivery, and unlock
                growth. We believe in transparent collaboration, evidence-based decisions, and
                technology that empowers people.
              </p>
              <Link to="/about" className="btn btn-link">
                Discover our story
              </Link>
            </div>
            <div className={styles.aboutImageWrapper}>
              <img
                src="https://picsum.photos/800/600?random=202"
                alt="TechSolutions consultants collaborating over digital strategy"
                className={styles.aboutImage}
              />
              <div className={styles.aboutBadge}>
                <span>Enterprise-ready from day one</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.services} id="services">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className="section-tag">Services</span>
              <h2>Expertise that meets you where you are and elevates where you can go next.</h2>
            </div>
            <p>
              From strategic advisory to production-grade engineering, we tailor every engagement to
              your mission-critical priorities—always with clarity, velocity, and measurable impact.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <article className={styles.serviceCard} key={service.title}>
                <div className={styles.serviceIndicator} aria-hidden="true" />
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to={service.link} className={styles.cardLink}>
                  Learn more →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.why}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className="section-tag">Why TechSolutions</span>
              <h2>Strategic partners committed to building sustainable value.</h2>
            </div>
            <p>
              The right partner brings clarity, momentum, and trust. We earn that trust by deeply
              understanding your vision, architecting for resilience, and delivering with empathy.
            </p>
          </div>
          <div className={styles.whyGrid}>
            {whyItems.map((item) => (
              <article className={styles.whyCard} key={item.title}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process} id="process">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className="section-tag">Our Process</span>
              <h2>A collaborative journey from vision to sustained outcomes.</h2>
            </div>
            <p>
              We blend strategic insight with pragmatic execution. This framework keeps teams aligned
              and ensures each milestone drives tangible business value.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article className={styles.processCard} key={step.step}>
                <span className={styles.processStep}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Client testimonials">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className="section-tag">Testimonials</span>
              <h2>Trusted by leaders navigating complex change.</h2>
            </div>
          </div>
          <div className={styles.testimonialCard}>
            <p className={styles.testimonialQuote}>
              “{testimonialsData[currentTestimonial].quote}”
            </p>
            <div className={styles.testimonialMeta}>
              <span>{testimonialsData[currentTestimonial].name}</span>
              <p>{testimonialsData[currentTestimonial].role}</p>
            </div>
            <div className={styles.testimonialControls}>
              {testimonialsData.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  className={`${styles.dot} ${
                    currentTestimonial === index ? styles.dotActive : ''
                  }`}
                  aria-label={`Show testimonial ${index + 1}`}
                  onClick={() => setCurrentTestimonial(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team} id="team">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className="section-tag">Leadership</span>
              <h2>Seasoned experts who stay close to the work.</h2>
            </div>
            <p>
              Every engagement is guided by hands-on leaders who bring decades of experience across
              strategy, design, engineering, and change management.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article className={styles.teamCard} key={member.name}>
                <div className={styles.teamImageWrapper}>
                  <img src={member.image} alt={`${member.name}, ${member.role}`} />
                </div>
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects} id="projects">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className="section-tag">Projects</span>
              <h2>Where strategy meets execution.</h2>
            </div>
            <p>
              Explore a selection of recent engagements where we transformed ambition into
              operational reality.
            </p>
          </div>
          <div className={styles.filterBar} role="tablist" aria-label="Project filters">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={activeCategory === category}
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterActive : ''
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article className={styles.projectCard} key={project.title}>
                <div className={styles.projectImageWrapper}>
                  <img src={project.image} alt={`${project.title} project showcase`} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/case-studies" className={styles.cardLink}>
                    View case study →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq} id="faq">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className="section-tag">FAQ</span>
              <h2>Answers to common questions.</h2>
            </div>
          </div>
          <div className={styles.faqList} role="list">
            {faqData.map((item, index) => (
              <div className={styles.faqItem} key={item.question} role="listitem">
                <button
                  type="button"
                  className={styles.faqButton}
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={faqOpen === index}
                >
                  <span>{item.question}</span>
                  <span>{faqOpen === index ? '−' : '+'}</span>
                </button>
                {faqOpen === index && <p className={styles.faqAnswer}>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog} id="insights">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className="section-tag">Insights</span>
              <h2>Fresh perspectives from our leadership team.</h2>
            </div>
            <p>
              Stay ahead with thoughtful commentary on the forces reshaping technology, operations,
              and customer experience.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article className={styles.blogCard} key={post.title}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.cardLink}>
                  Read article →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Ready to accelerate your next initiative?</h2>
              <p>
                Let’s design a roadmap, align your teams, and deliver the technology your business
                deserves. We’ll respond within one business day.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <Link to="/contact" className="btn btn-primary">
                Schedule a consultation
              </Link>
              <Link to="/case-studies" className="btn btn-secondary">
                View results
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.contact} id="contact">
        <div className="container">
          <div className={styles.contactGrid}>
            <div className={styles.contactInfo}>
              <span className="section-tag">Contact</span>
              <h2>Share your goals. We’ll bring a plan.</h2>
              <p>
                Whether you’re modernizing a core platform or launching a new digital product, our
                consultants are ready to collaborate. Let’s unlock the next chapter together.
              </p>
              <ul className={styles.contactList}>
                <li>
                  <strong>Address:</strong> 123 Tech Avenue, San Francisco, CA 94105, USA
                </li>
                <li>
                  <strong>Phone:</strong>{' '}
                  <a href="tel:+15551234567">+1 (555) 123-4567</a>
                </li>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
                </li>
              </ul>
            </div>
            <form className={styles.contactForm} onSubmit={handleSubmit} noValidate>
              <div className={styles.formGroup}>
                <label htmlFor="home-name">Name *</label>
                <input
                  id="home-name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleInputChange}
                  aria-invalid={Boolean(formErrors.name)}
                />
                {formErrors.name && <span className={styles.error}>{formErrors.name}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="home-email">Email *</label>
                <input
                  id="home-email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  aria-invalid={Boolean(formErrors.email)}
                />
                {formErrors.email && <span className={styles.error}>{formErrors.email}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="home-company">Company</label>
                <input
                  id="home-company"
                  name="company"
                  type="text"
                  value={formData.company}
                  onChange={handleInputChange}
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="home-message">How can we help? *</label>
                <textarea
                  id="home-message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleInputChange}
                  aria-invalid={Boolean(formErrors.message)}
                />
                {formErrors.message && <span className={styles.error}>{formErrors.message}</span>}
              </div>
              <button type="submit" className="btn btn-primary">
                Submit message
              </button>
              {formSuccess && (
                <p className={styles.success} role="status" aria-live="polite">
                  {formSuccess}
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;