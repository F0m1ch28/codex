import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    subject: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [confirmation, setConfirmation] = useState('');

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
    setErrors((prev) => ({
      ...prev,
      [event.target.name]: ''
    }));
  };

  const validate = () => {
    const validation = {};
    if (!formData.name.trim()) validation.name = 'Please enter your full name.';
    if (!formData.email.trim()) {
      validation.email = 'Please provide a business email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      validation.email = 'The email format appears invalid.';
    }
    if (!formData.subject.trim()) validation.subject = 'Please add a subject.';
    if (!formData.message.trim()) validation.message = 'Please include a detailed message.';
    return validation;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const result = validate();
    if (Object.keys(result).length) {
      setErrors(result);
      setConfirmation('');
      return;
    }
    setConfirmation('Thank you for your message. Our team will respond within one business day.');
    setFormData({
      name: '',
      email: '',
      company: '',
      subject: '',
      message: ''
    });
  };

  return (
    <>
      <Helmet>
        <title>Contact TechSolutions | IT Consulting Experts</title>
        <meta
          name="description"
          content="Contact TechSolutions for strategic IT consulting, custom software, cloud solutions, and digital transformation services. Let's move your vision forward."
        />
        <link rel="canonical" href="https://www.techsolutions.com/contact" />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-tag">Contact</span>
            <h1>Let’s explore how we can collaborate.</h1>
            <p>
              Share your goals and challenges. Our experts will assemble the right team and respond
              quickly to start shaping a tailored engagement.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.contactGrid}>
            <div className={styles.infoCard}>
              <h2>Global headquarters</h2>
              <address>
                <span>123 Tech Avenue</span>
                <span>San Francisco, CA 94105</span>
                <span>USA</span>
              </address>
              <div className={styles.infoList}>
                <div>
                  <strong>Phone</strong>
                  <a href="tel:+15551234567">+1 (555) 123-4567</a>
                </div>
                <div>
                  <strong>Email</strong>
                  <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
                </div>
              </div>
              <p>
                Prefer to meet in person? We host collaborative workshops at our San Francisco
                studio and can arrange sessions at your offices globally.
              </p>
            </div>
            <form className={styles.formCard} onSubmit={handleSubmit} noValidate>
              <div className={styles.formGroup}>
                <label htmlFor="contact-name">Name *</label>
                <input
                  id="contact-name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="contact-email">Email *</label>
                <input
                  id="contact-email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="contact-company">Company</label>
                <input
                  id="contact-company"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="contact-subject">Subject *</label>
                <input
                  id="contact-subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.subject)}
                />
                {errors.subject && <span className={styles.error}>{errors.subject}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="contact-message">Message *</label>
                <textarea
                  id="contact-message"
                  name="message"
                  rows="6"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className="btn btn-primary">
                Submit inquiry
              </button>
              {confirmation && (
                <p className={styles.confirmation} role="status" aria-live="polite">
                  {confirmation}
                </p>
              )}
            </form>
          </div>
          <div className={styles.mapWrapper} aria-label="Office location map">
            <iframe
              title="TechSolutions San Francisco Office"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.2668881239364!2d-122.39687772347782!3d37.78970001189948!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858064f0ee6abf%3A0x4a5b6f3c95bb4c88!2s123%20Tech%20Ave%2C%20San%20Francisco%2C%20CA%2094105!5e0!3m2!1sen!2sus!4v1705339398000!5m2!1sen!2sus"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;