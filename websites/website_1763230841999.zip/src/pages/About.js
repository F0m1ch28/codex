import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './About.module.css';

const values = [
  {
    title: 'Lead with empathy',
    description:
      'We listen actively, respecting diverse perspectives and shaping solutions that empower the people they impact.'
  },
  {
    title: 'Elevate craft',
    description:
      'Our teams obsess over details, from pixel-perfect designs to resilient integrations, delivering excellence at every layer.'
  },
  {
    title: 'Deliver with integrity',
    description:
      'Transparency, accountability, and clear communication are embedded in our ways of working and relationships.'
  },
  {
    title: 'Champion outcomes',
    description:
      'Success is measured by progress toward your strategic goals. We continuously track, learn, and optimize to deliver value.'
  }
];

const milestones = [
  {
    year: '2012',
    title: 'TechSolutions is founded',
    description:
      'A group of product strategists and engineers launch TechSolutions to help enterprises innovate with agility.'
  },
  {
    year: '2015',
    title: 'Global delivery expansion',
    description:
      'We establish hubs in San Francisco and Austin, enabling hybrid teams and follow-the-sun collaboration.'
  },
  {
    year: '2019',
    title: 'Cloud excellence recognition',
    description:
      'TechSolutions becomes an accredited partner with major cloud providers, deepening specialization in cloud-native platforms.'
  },
  {
    year: '2023',
    title: 'Sustained growth',
    description:
      'We celebrate more than 150 launches, 85 enterprise relationships, and industry recognition for delivery excellence.'
  }
];

const leadership = [
  {
    name: 'Alexandra Morgan',
    role: 'Chief Executive Officer',
    statement:
      '“We founded TechSolutions to help organizations use technology as a catalyst for transformation. Our mission is to guide teams through the hard work of change with empathy and precision.”'
  },
  {
    name: 'Daniel Kim',
    role: 'Chief Strategy Officer',
    statement:
      '“The problems worth solving are rarely simple. We partner with leaders to bring clarity to ambiguity and translate vision into executable roadmaps.”'
  }
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>About TechSolutions | Strategic IT Consulting & Engineering</title>
        <meta
          name="description"
          content="Learn how TechSolutions partners with enterprises to design, build, and scale mission-critical digital experiences through strategy, product, and engineering excellence."
        />
        <link rel="canonical" href="https://www.techsolutions.com/about" />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-tag">About TechSolutions</span>
            <h1>We build technology that advances business and uplifts people.</h1>
            <p>
              TechSolutions was born from a belief that enterprise technology should be strategic,
              intuitive, and relentlessly focused on the human experience. Over the last decade,
              we’ve partnered with global leaders to modernize legacy ecosystems, launch new
              ventures, and drive transformation that sticks.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionGrid}>
            <article className={styles.missionCard}>
              <h2>Our mission</h2>
              <p>
                Empower organizations to innovate faster, operate smarter, and deliver experiences
                people trust. We align technology investments with strategic ambition, ensuring every
                initiative is designed for measurable impact.
              </p>
            </article>
            <article className={styles.missionCard}>
              <h2>Our approach</h2>
              <p>
                We partner shoulder-to-shoulder with your teams, combining executive-level advisory,
                product strategy, and engineering execution. By blending deep domain expertise with
                a people-first mindset, we bring clarity to complexity and momentum to delivery.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <div className="section-header">
            <h2>Values that guide every engagement.</h2>
            <p>
              Our values shape how we collaborate, how we make decisions, and how we show up for
              clients every day.
            </p>
          </div>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article className={styles.valueCard} key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.milestones}>
        <div className="container">
          <div className="section-header">
            <h2>A decade of momentum.</h2>
            <p>Over ten years of delivering mission-critical platforms and experiences for our clients.</p>
          </div>
          <div className={styles.timeline}>
            {milestones.map((item) => (
              <div className={styles.timelineItem} key={item.year}>
                <div className={styles.timelineYear}>{item.year}</div>
                <div className={styles.timelineContent}>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.leadership}>
        <div className="container">
          <div className="section-header">
            <h2>Leadership committed to staying close to the work.</h2>
            <p>
              Our executive team remains hands-on to ensure every partnership is grounded in
              strategic clarity and delivered with excellence.
            </p>
          </div>
          <div className={styles.leadershipGrid}>
            {leadership.map((leader) => (
              <article className={styles.leadershipCard} key={leader.name}>
                <h3>{leader.name}</h3>
                <span>{leader.role}</span>
                <p>{leader.statement}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.partners}>
        <div className="container">
          <div className={styles.partnersCard}>
            <div>
              <h2>Partner with TechSolutions.</h2>
              <p>
                We’re ready to meet you at any stage—vision, product discovery, architecture, or
                delivery. Together, we can build technology that earns trust and accelerates growth.
              </p>
            </div>
            <Link to="/contact" className="btn btn-primary">
              Start the conversation
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;