import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Services.module.css';

const services = [
  {
    id: 'custom-software',
    title: 'Custom Software Development',
    summary:
      'Design, build, and evolve resilient platforms tuned to your operational imperatives and customer expectations.',
    bullets: [
      'Product discovery, UX design, and prototyping',
      'Full-stack engineering across web, mobile, and platform',
      'API-first architecture, microservices, and integration',
      'Automated testing, CI/CD pipelines, and release management'
    ]
  },
  {
    id: 'cloud-solutions',
    title: 'Cloud Solutions',
    summary:
      'Architect secure, scalable cloud ecosystems that unlock agility, optimize spend, and accelerate innovation.',
    bullets: [
      'Cloud strategy assessments and roadmap development',
      'Migration, modernization, and hybrid architectures',
      'Infrastructure-as-code, containerization, and orchestration',
      'Observability, FinOps, and reliability engineering'
    ]
  },
  {
    id: 'it-consulting',
    title: 'IT Consulting',
    summary:
      'Align technology assets with business objectives through evidence-based advisory and actionable roadmaps.',
    bullets: [
      'Enterprise architecture and governance',
      'Technology due diligence and portfolio rationalization',
      'Program management, PMO enablement, and change leadership',
      'Security, risk, and compliance assessments'
    ]
  },
  {
    id: 'digital-transformation',
    title: 'Digital Transformation',
    summary:
      'Cultivate connected experiences, modernized workflows, and data-driven decision-making across the organization.',
    bullets: [
      'Digital strategy and operating model design',
      'Customer and employee experience innovation',
      'Process automation, AI, and analytics activation',
      'Change management, training, and adoption programs'
    ]
  }
];

const accelerators = [
  {
    title: 'Innovation Sprints',
    description:
      'Focused 4-6 week engagements to validate concepts, de-risk investments, and align stakeholders before build.'
  },
  {
    title: 'Technology Health Checks',
    description:
      'Comprehensive assessments that uncover bottlenecks, quantify risks, and deliver actionable modernization plans.'
  },
  {
    title: 'Cloud Landing Zones',
    description:
      'Rapid deployment of secure, compliant, and scalable foundations tailored to enterprise governance requirements.'
  }
];

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Services | TechSolutions IT Consulting & Engineering</title>
        <meta
          name="description"
          content="Explore TechSolutions services: custom software development, cloud solutions, IT consulting, and digital transformation tailored to accelerate enterprise innovation."
        />
        <link rel="canonical" href="https://www.techsolutions.com/services" />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-tag">What we do</span>
            <h1>End-to-end expertise for mission-critical digital initiatives.</h1>
            <p>
              We tailor capabilities to your goals—whether you need strategic advisory, design and
              engineering, or a dedicated partner to deliver transformation across the enterprise.
            </p>
            <Link to="/contact" className="btn btn-primary">
              Plan your next project
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article key={service.id} className={styles.serviceCard} id={service.id}>
                <h2>{service.title}</h2>
                <p>{service.summary}</p>
                <ul>
                  {service.bullets.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.accelerators}>
        <div className="container">
          <div className="section-header">
            <h2>Acceleration programs that reduce risk and amplify impact.</h2>
            <p>
              Leverage curated engagements crafted from years of experience helping enterprises ship
              faster with confidence.
            </p>
          </div>
          <div className={styles.acceleratorGrid}>
            {accelerators.map((item) => (
              <article key={item.title} className={styles.acceleratorCard}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Let’s architect what’s next.</h2>
              <p>
                Tell us about your objectives and we’ll assemble the right mix of strategists,
                designers, architects, and engineers to deliver them.
              </p>
            </div>
            <Link to="/contact" className="btn btn-secondary">
              Contact TechSolutions
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;