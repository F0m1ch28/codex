import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './CaseStudies.module.css';

const caseStudies = [
  {
    title: 'Global Supply Chain Reinvention',
    sector: 'Logistics',
    outcome:
      'Deployed a unified, cloud-native logistics platform that increased fulfillment accuracy by 34% and improved visibility across 120 countries.',
    highlights: [
      'Modern microservices architecture connected legacy ERPs and real-time telemetry',
      'New analytics stack enabled predictive routing and inventory optimization',
      'Change management program ensured adoption across 2,400 operations leaders'
    ],
    image: 'https://picsum.photos/1200/800?random=501'
  },
  {
    title: 'Digital Health Ecosystem',
    sector: 'Healthcare',
    outcome:
      'Delivered a HIPAA-compliant digital companion enabling personalized care journeys and telehealth support for 3.2M patients.',
    highlights: [
      'Co-created patient personas and service blueprints with clinicians',
      'Implemented secure data integrations across EMR, IoT, and analytics platforms',
      'Scaled adoption through tailored training and clinical ambassador programs'
    ],
    image: 'https://picsum.photos/1200/800?random=502'
  },
  {
    title: 'Banking Experience Transformation',
    sector: 'Financial Services',
    outcome:
      'Redesigned digital banking for retail and small business customers, increasing digital engagement by 48% within six months.',
    highlights: [
      'Introduced design system improving accessibility and reducing development effort by 30%',
      'Migrated to cloud-native services with automated security and compliance controls',
      'Delivered continuous innovation pipeline with joint product and engineering teams'
    ],
    image: 'https://picsum.photos/1200/800?random=503'
  }
];

const CaseStudies = () => {
  return (
    <>
      <Helmet>
        <title>Case Studies | TechSolutions Client Success Stories</title>
        <meta
          name="description"
          content="Discover how TechSolutions partners with enterprises to deliver transformative results across logistics, healthcare, financial services, and more."
        />
        <link rel="canonical" href="https://www.techsolutions.com/case-studies" />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-tag">Case Studies</span>
            <h1>Real partnerships. Measurable outcomes.</h1>
            <p>
              Explore how we collaborate with ambitious teams to transform critical journeys,
              modernize platforms, and achieve lasting impact.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.caseStudies}>
        <div className="container">
          <div className={styles.grid}>
            {caseStudies.map((study) => (
              <article key={study.title} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img src={study.image} alt={`${study.title} project`} />
                </div>
                <div className={styles.cardContent}>
                  <span className={styles.sector}>{study.sector}</span>
                  <h2>{study.title}</h2>
                  <p>{study.outcome}</p>
                  <ul>
                    {study.highlights.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <h2>Let’s build your next success story.</h2>
            <p>
              Connect with our consultants to explore how TechSolutions can help deliver the results
              you need—on time and with confidence.
            </p>
            <Link to="/contact" className="btn btn-primary">
              Start the conversation
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default CaseStudies;