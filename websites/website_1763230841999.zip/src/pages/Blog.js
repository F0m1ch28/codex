import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Navigating the Shift to Composable Architecture',
    date: 'January 2024',
    readingTime: '7 min read',
    excerpt:
      'Composable thinking is reshaping enterprise technology. We break down how to evolve architecture, teams, and governance to make it real.',
    image: 'https://picsum.photos/800/600?random=601'
  },
  {
    title: 'Crafting Change Enablement for Digital Transformation',
    date: 'December 2023',
    readingTime: '6 min read',
    excerpt:
      'Transformation succeeds when people embrace new ways of working. Discover our framework for powerful change enablement.',
    image: 'https://picsum.photos/800/600?random=602'
  },
  {
    title: 'Data Product Leadership: Turning Insights into Action',
    date: 'November 2023',
    readingTime: '5 min read',
    excerpt:
      'Great data products blend trust, usability, and timely insight. Learn how our teams partner with business leaders to operationalize analytics.',
    image: 'https://picsum.photos/800/600?random=603'
  }
];

const Blog = () => {
  return (
    <>
      <Helmet>
        <title>TechSolutions Blog | Insights on Technology & Transformation</title>
        <meta
          name="description"
          content="Stay informed with TechSolutions insights covering digital strategy, product innovation, cloud modernization, and transformation leadership."
        />
        <link rel="canonical" href="https://www.techsolutions.com/blog" />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="section-tag">Blog</span>
            <h1>Insights for leaders shaping what’s next.</h1>
            <p>
              Practical strategies, frameworks, and stories from the teams delivering transformation
              across industries.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.posts}>
        <div className="container">
          <div className={styles.grid}>
            {posts.map((post) => (
              <article key={post.title} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img src={post.image} alt={post.title} />
                </div>
                <div className={styles.cardContent}>
                  <span>{post.date} · {post.readingTime}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <button type="button" className={styles.readButton}>
                    Coming soon
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;