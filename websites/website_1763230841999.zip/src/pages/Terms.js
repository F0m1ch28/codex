import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Service | TechSolutions</title>
        <meta
          name="description"
          content="Review the TechSolutions Terms of Service governing access to our website and professional consulting services."
        />
        <link rel="canonical" href="https://www.techsolutions.com/terms" />
      </Helmet>
      <section className={styles.legal}>
        <div className="container">
          <h1>Terms of Service</h1>
          <p className={styles.updated}>Last updated: January 15, 2024</p>
          <h2>1. Agreement to terms</h2>
          <p>
            By accessing the TechSolutions website or engaging with our services, you agree to these
            Terms of Service. If you do not agree, please discontinue use immediately.
          </p>
          <h2>2. Use of content</h2>
          <p>
            All materials provided on this site, including text, graphics, and assets, are owned by
            TechSolutions. You may not reproduce, distribute, or modify any content without prior
            written consent.
          </p>
          <h2>3. Professional services</h2>
          <p>
            The scope, deliverables, and responsibilities for professional services are defined in
            individual agreements. Those agreements supersede any conflicting terms presented here.
          </p>
          <h2>4. Disclaimers</h2>
          <p>
            Information on this site is provided for general guidance and does not constitute
            specific technical, legal, or financial advice. TechSolutions is not liable for actions
            taken based on the content presented.
          </p>
          <h2>5. Limitation of liability</h2>
          <p>
            To the fullest extent permitted by law, TechSolutions is not liable for any indirect,
            incidental, or consequential damages arising from your use of the website or services.
          </p>
          <h2>6. Governing law</h2>
          <p>
            These Terms are governed by the laws of the State of California, without regard to
            conflict of law principles.
          </p>
          <h2>7. Contact</h2>
          <p>
            Questions about these Terms? Contact us at{' '}
            <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
          </p>
        </div>
      </section>
    </>
  );
};

export default Terms;