import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | TechSolutions</title>
        <meta
          name="description"
          content="Learn how TechSolutions collects, uses, and protects personal data across our digital properties and services."
        />
        <link rel="canonical" href="https://www.techsolutions.com/privacy" />
      </Helmet>
      <section className={styles.legal}>
        <div className="container">
          <h1>Privacy Policy</h1>
          <p className={styles.updated}>Last updated: January 15, 2024</p>
          <h2>Information we collect</h2>
          <p>
            We collect information that you provide directly, such as when you request information,
            subscribe to updates, or engage our services. We may also collect limited technical data
            through cookies or analytics tools.
          </p>
          <h2>How we use information</h2>
          <p>
            TechSolutions uses information to respond to inquiries, deliver requested services,
            improve our offerings, and comply with legal obligations. We do not sell personal data.
          </p>
          <h2>Sharing data</h2>
          <p>
            We may share information with trusted vendors who assist in providing services, subject
            to confidentiality agreements. We may disclose information if required by law or to
            protect our rights.
          </p>
          <h2>Security</h2>
          <p>
            We implement safeguards designed to protect information from unauthorized access. While
            no system is completely secure, we strive to maintain industry-leading practices.
          </p>
          <h2>Your choices</h2>
          <p>
            You can request access, correction, or deletion of your personal data by contacting{' '}
            <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>. We will respond to
            all valid requests in accordance with applicable laws.
          </p>
          <h2>Updates</h2>
          <p>
            We may update this policy periodically. Significant changes will be posted on this page
            with an updated effective date.
          </p>
        </div>
      </section>
    </>
  );
};

export default Privacy;