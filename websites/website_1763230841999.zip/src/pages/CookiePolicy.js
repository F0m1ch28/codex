import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | TechSolutions</title>
        <meta
          name="description"
          content="Understand how TechSolutions uses cookies and similar technologies to enhance your browsing experience."
        />
        <link rel="canonical" href="https://www.techsolutions.com/cookie-policy" />
      </Helmet>
      <section className={styles.legal}>
        <div className="container">
          <h1>Cookie Policy</h1>
          <p className={styles.updated}>Last updated: January 15, 2024</p>
          <h2>What are cookies?</h2>
          <p>
            Cookies are small data files stored on your device when you visit a website. They help us
            understand how our site is used and enhance your experience.
          </p>
          <h2>Types of cookies we use</h2>
          <ul className={styles.list}>
            <li>
              <strong>Essential cookies:</strong> Required for core website functionality and security.
            </li>
            <li>
              <strong>Performance cookies:</strong> Help us analyze site traffic and improve user journeys.
            </li>
            <li>
              <strong>Functional cookies:</strong> Remember preferences to provide a personalized experience.
            </li>
          </ul>
          <h2>Managing cookies</h2>
          <p>
            You can control or disable cookies through your browser settings. Please note that
            disabling certain cookies may affect site performance.
          </p>
          <h2>Contact</h2>
          <p>
            If you have questions about this Cookie Policy, contact us at{' '}
            <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
          </p>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;