import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brandColumn}>
            <Link to="/" className={styles.logo} aria-label="TechSolutions home">
              <span>Tech</span>Solutions
            </Link>
            <p className={styles.tagline}>
              Partnering with ambitious teams to build resilient, human-centered technology.
            </p>
          </div>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Company</h3>
            <ul className={styles.list}>
              <li><Link to="/about">About</Link></li>
              <li><Link to="/services">Services</Link></li>
              <li><Link to="/case-studies">Case Studies</Link></li>
              <li><Link to="/blog">Blog</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Legal</h3>
            <ul className={styles.list}>
              <li><Link to="/terms">Terms of Service</Link></li>
              <li><Link to="/privacy">Privacy Policy</Link></li>
              <li><Link to="/cookie-policy">Cookie Policy</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Contact</h3>
            <address className={styles.address}>
              <span>123 Tech Avenue</span>
              <span>San Francisco, CA 94105</span>
              <span>USA</span>
              <a href="tel:+15551234567">+1 (555) 123-4567</a>
              <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
            </address>
          </div>
        </div>
        <div className={styles.bottomBar}>
          <p>© {year} TechSolutions. All rights reserved.</p>
          <div className={styles.bottomLinks}>
            <Link to="/privacy">Privacy</Link>
            <Link to="/terms">Terms</Link>
            <Link to="/cookie-policy">Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;