import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('techsolutions_cookie_consent');
    if (!consent) {
      const bannerTimer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(bannerTimer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('techsolutions_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          We use cookies to enhance your experience, analyze traffic, and improve our services. By
          clicking “Accept”, you agree to our use of cookies as described in our Cookie Policy.
        </p>
      </div>
      <button type="button" className="btn btn-primary" onClick={acceptCookies}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;