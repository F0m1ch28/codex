document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.getElementById("navToggle");
    const navMenu = document.getElementById("navMenu");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navMenu.classList.toggle("open");
        });

        navMenu.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 768) {
                    navMenu.classList.remove("open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookieBanner");
    const acceptBtn = document.getElementById("acceptCookies");
    const declineBtn = document.getElementById("declineCookies");
    const customizeBtn = document.getElementById("customizeCookies");
    const storageKey = "lungerecwbCookieConsent";

    if (cookieBanner) {
        const consentStatus = localStorage.getItem(storageKey);
        if (consentStatus) {
            cookieBanner.classList.add("hidden");
        } else {
            cookieBanner.classList.remove("hidden");
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => {
                localStorage.setItem(storageKey, "accepted");
                cookieBanner.classList.add("hidden");
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", () => {
                localStorage.setItem(storageKey, "declined");
                cookieBanner.classList.add("hidden");
            });
        }

        if (customizeBtn) {
            customizeBtn.addEventListener("click", () => {
                localStorage.setItem(storageKey, "customize");
                window.location.href = "cookies.html";
            });
        }
    }
});