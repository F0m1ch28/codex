document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.site-nav');

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            navigation.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', navigation.classList.contains('open'));
        });

        navigation.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navigation.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('genusgsfyb-cookie-consent');
        if (!storedConsent) {
            cookieBanner.classList.add('active');
        }

        cookieBanner.querySelectorAll('[data-decision]').forEach(btn => {
            btn.addEventListener('click', function (event) {
                event.preventDefault();
                const decision = this.getAttribute('data-decision');
                localStorage.setItem('genusgsfyb-cookie-consent', decision);
                cookieBanner.classList.remove('active');
            });
        });
    }

    const filterButtons = document.querySelectorAll('[data-filter]');
    const courseCards = document.querySelectorAll('[data-category]');
    if (filterButtons.length && courseCards.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const category = button.getAttribute('data-filter');
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');

                courseCards.forEach(card => {
                    const categories = card.getAttribute('data-category').split(',');
                    if (category === 'all' || categories.includes(category)) {
                        card.style.display = 'grid';
                        requestAnimationFrame(() => {
                            card.style.opacity = '1';
                            card.style.transform = 'translateY(0)';
                        });
                    } else {
                        card.style.opacity = '0';
                        card.style.transform = 'translateY(12px)';
                        setTimeout(() => {
                            card.style.display = 'none';
                        }, 180);
                    }
                });
            });
        });
    }

    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            faqItems.forEach(el => el.classList.remove('active'));
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });
});