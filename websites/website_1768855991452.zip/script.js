document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const isOpen = navMenu.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const banner = document.querySelector('.cookie-banner');
  if (!banner) {
    return;
  }

  const COOKIE_KEY = 'strategicSageCookieConsent';
  const storedConsent = localStorage.getItem(COOKIE_KEY);

  if (storedConsent === 'accepted' || storedConsent === 'declined') {
    banner.classList.add('is-hidden');
  } else {
    banner.classList.add('is-visible');
  }

  const handleConsent = (state) => {
    localStorage.setItem(COOKIE_KEY, state);
    banner.classList.remove('is-visible');
    banner.classList.add('is-hidden');
  };

  banner.querySelectorAll('[data-action="accept"]').forEach(button => {
    button.addEventListener('click', () => handleConsent('accepted'));
  });

  banner.querySelectorAll('[data-action="decline"]').forEach(button => {
    button.addEventListener('click', () => handleConsent('declined'));
  });
});