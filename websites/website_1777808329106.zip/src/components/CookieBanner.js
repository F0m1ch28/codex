import React, { useEffect, useState } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookieConsent');
    if (!consent) {
      setTimeout(() => setVisible(true), 800);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookieConsent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-banner__content">
        <p>
          Мы используем cookies, чтобы улучшить персонализацию контента и анализировать трафик.
          Продолжая пользоваться сайтом, вы соглашаетесь с нашей Политикой Cookies.
        </p>
        <button className="btn btn-secondary" onClick={handleAccept}>
          Понятно
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;