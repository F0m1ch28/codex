import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 16);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const linkClassName = ({ isActive }) =>
    `nav-link ${isActive ? 'active-link' : ''}`;

  return (
    <header
      className={`site-header ${scrolled ? 'site-header--scrolled' : ''}`}
      role="banner"
    >
      <div className="container header-container">
        <div className="logo" aria-label="Навигация сайта">
          <NavLink to="/" className="logo-link" onClick={() => setMenuOpen(false)}>
            <span className="logo-mark">G</span>
            <span className="logo-text">Gambling&nbsp;Observer</span>
          </NavLink>
        </div>
        <button
          className={`menu-toggle ${menuOpen ? 'menu-toggle--open' : ''}`}
          aria-controls="primary-navigation"
          aria-expanded={menuOpen}
          onClick={toggleMenu}
        >
          <span className="sr-only">Переключить меню</span>
          <span className="menu-toggle-bar" />
          <span className="menu-toggle-bar" />
          <span className="menu-toggle-bar" />
        </button>
        <nav
          id="primary-navigation"
          className={`main-navigation ${menuOpen ? 'main-navigation--open' : ''}`}
          aria-label="Основная навигация"
        >
          <NavLink to="/catalog" className={linkClassName} onClick={() => setMenuOpen(false)}>
            Каталог казино
          </NavLink>
          <NavLink to="/compare" className={linkClassName} onClick={() => setMenuOpen(false)}>
            Сравнение
          </NavLink>
          <NavLink to="/about" className={linkClassName} onClick={() => setMenuOpen(false)}>
            О проекте
          </NavLink>
          <NavLink to="/services" className={linkClassName} onClick={() => setMenuOpen(false)}>
            Услуги
          </NavLink>
          <NavLink to="/contact" className={linkClassName} onClick={() => setMenuOpen(false)}>
            Контакты
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;