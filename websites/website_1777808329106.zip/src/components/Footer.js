import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="site-footer" role="contentinfo">
      <div className="container footer-grid">
        <div>
          <h3 className="footer-title">Gambling Observer</h3>
          <p className="footer-description">
            Независимый гид по онлайн-казино. Мы анализируем площадки, бонусы и условия, чтобы
            помочь совершеннолетним пользователям принимать взвешенные решения.
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Навигация</h4>
          <ul className="footer-links">
            <li>
              <Link to="/catalog">Каталог казино</Link>
            </li>
            <li>
              <Link to="/compare">Сравнение условий</Link>
            </li>
            <li>
              <Link to="/about">О проекте</Link>
            </li>
            <li>
              <Link to="/services">Услуги</Link>
            </li>
            <li>
              <Link to="/contact">Контакты</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="footer-heading">Документы</h4>
          <ul className="footer-links">
            <li>
              <Link to="/terms">Условия использования</Link>
            </li>
            <li>
              <Link to="/privacy">Политика конфиденциальности</Link>
            </li>
            <li>
              <Link to="/cookies">Политика Cookies</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="footer-heading">Ответственная игра</h4>
          <p className="footer-description">
            Азартные игры доступны только совершеннолетним. Играйте осознанно и устанавливайте
            личные лимиты. При признаках зависимости обратитесь к профильным специалистам.
          </p>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Gambling Observer. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;