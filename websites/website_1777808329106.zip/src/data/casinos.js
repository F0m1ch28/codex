const casinos = [
  {
    id: 1,
    name: 'Астра Плей',
    slug: 'astra-play',
    rating: 4.8,
    bonus: '150% на первый депозит + 120 фриспинов',
    bonusType: 'welcome',
    wager: '35x',
    minDeposit: '1 000 ₽',
    maxWithdrawal: '500 000 ₽ в месяц',
    payoutSpeed: 'До 24 часов',
    license: 'Curaçao eGaming',
    licenseNumber: 'GLH-2020-001',
    established: 2020,
    image: 'https://picsum.photos/seed/casino01/800/520',
    shortDescription: 'Современная платформа с турнирами и расширенной VIP-программой.',
    reviewSummary:
      'Астра Плей делает ставку на разнообразие и геймификацию. На сайте более 5 000 слотов, гибкие бонусы и прозрачные лимиты по выводу.',
    features: [
      'Программа лояльности с 10 уровнями и персональными менеджерами',
      'Турниры со смешанными призовыми фондами и начислением очков',
      'Ночная поддержка с приоритетом для постоянных клиентов'
    ],
    pros: [
      'Широкий выбор платежных систем и криптовалют',
      'Регулярный рейкбэк до 12%',
      'Подробные условия бонусов без скрытых пунктов'
    ],
    cons: [
      'Нет поддержки по телефону',
      'Вейджер приветственного пакета выше среднего'
    ],
    games: ['Слоты', 'Live казино', 'Блэкджек', 'Краш-игры', 'Турниры'],
    categories: ['slots', 'live', 'poker'],
    tags: ['crypto', 'cashback'],
    paymentMethods: ['Банковские карты', 'ЮMoney', 'Piastrix', 'Cryptocurrency'],
    currencies: ['RUB', 'EUR', 'USDT', 'KZT'],
    support: {
      channels: ['Live чат', 'Email'],
      schedule: '24/7'
    },
    security: 'Шифрование SSL 256-bit, независимый аудит RNG раз в квартал',
    topGames: ['Book of Sun', 'Crazy Time', 'Lightning Roulette', 'Sweet Bonanza'],
    restrictions: 'Не принимает игроков младше 18 лет и жителей некоторых регионов.',
    responsibleGaming: 'Настраиваемые лимиты по депозитам, ставкам и времени сессии.'
  },
  {
    id: 2,
    name: 'Кварц Казино',
    slug: 'kvarts-casino',
    rating: 4.6,
    bonus: 'Кэшбэк до 20% без отыгрыша',
    bonusType: 'cashback',
    wager: '0x',
    minDeposit: '500 ₽',
    maxWithdrawal: '300 000 ₽ в неделю',
    payoutSpeed: '12-36 часов',
    license: 'MGA',
    licenseNumber: 'MGA/B2C/612/2021',
    established: 2019,
    image: 'https://picsum.photos/seed/casino02/800/520',
    shortDescription: 'Платформа для ответственной игры с гибкими лимитами и лайв-столами.',
    reviewSummary:
      'Кварц Казино популярно среди осторожных игроков за счёт прозрачного кэшбэка и контроля лимитов. Обширная коллекция live-игр и русскоязычные столы.',
    features: [
      'Кэшбэк без отыгрыша каждую пятницу',
      'Стол заказов для live-игр с русскими дилерами',
      'Регулярные образовательные вебинары по ответственной игре'
    ],
    pros: [
      'Качество локализации и поддержка на русском',
      'Минимальный депозит 500 ₽',
      'Открытая статистика RTP по каждому провайдеру'
    ],
    cons: [
      'Нет отдельного приложения, только мобильная версия',
      'Ограничение по выводу в выходные'
    ],
    games: ['Live казино', 'Рулетка', 'Баккара', 'Слоты', 'Настольные игры'],
    categories: ['live', 'roulette', 'slots'],
    tags: ['cashback', 'loyalty'],
    paymentMethods: ['Банковские карты', 'QIWI', 'Skrill'],
    currencies: ['RUB', 'EUR', 'USD'],
    support: {
      channels: ['Live чат', 'Email', 'Telegram-бот'],
      schedule: 'Ежедневно с 08:00 до 02:00 (МСК)'
    },
    security: 'Решения Comodo SSL, двухфакторная аутентификация',
    topGames: ['Immersive Roulette', 'Monopoly Live', 'Gonzo’s Quest'],
    restrictions: 'Требуется верификация личности перед выводом.',
    responsibleGaming: 'Самоисключение до 6 месяцев, тест на склонность к зависимости.'
  },
  {
    id: 3,
    name: 'Неон Вегас',
    slug: 'neon-vegas',
    rating: 4.7,
    bonus: '200 фриспинов за регистрацию и первый депозит',
    bonusType: 'freespins',
    wager: '25x',
    minDeposit: '700 ₽',
    maxWithdrawal: '250 000 ₽ в месяц',
    payoutSpeed: 'До 48 часов',
    license: 'Curaçao eGaming',
    licenseNumber: 'GLH-OCCHKTW0706012021',
    established: 2021,
    image: 'https://picsum.photos/seed/casino03/800/520',
    shortDescription: 'Яркий выбор слотов, турниры и коллекция джекпотов с живой статистикой.',
    reviewSummary:
      'Неон Вегас привлекает фанатов слотов за счёт бонусов с умеренным вейджером и постоянных гонок за очки. Сильная аналитика по провайдерам.',
    features: [
      'Отслеживание прогресса фриспинов в реальном времени',
      'Джекпоты с динамическими таблицами лидеров',
      'Коллекции игр по тематическим подборкам'
    ],
    pros: [
      'Обновление каталога каждые две недели',
      'Прозрачные отчёты по сумме выплат',
      'Геймификация с наградами за задания'
    ],
    cons: [
      'Нет возможности скрыть баланс во время стримов',
      'Верификация может занять до 48 часов'
    ],
    games: ['Слоты', 'Джекпоты', 'Краш-игры', 'Live казино'],
    categories: ['slots', 'jackpot', 'live'],
    tags: ['freespins', 'tournaments'],
    paymentMethods: ['Банковские карты', 'Piastrix', 'Cryptocurrency'],
    currencies: ['RUB', 'EUR', 'PLN', 'USDT'],
    support: {
      channels: ['Live чат', 'Email'],
      schedule: 'Круглосуточно'
    },
    security: 'Шифрование TLS 1.3, сертификация eCOGRA',
    topGames: ['Gates of Olympus', 'Starburst', 'Mega Moolah'],
    restrictions: 'Не доступно в некоторых странах СНГ.',
    responsibleGaming: 'Лимиты на проигрыш, напоминания о времени, кнопка «Пауза».'
  },
  {
    id: 4,
    name: 'Сфера Бет',
    slug: 'sfera-bet',
    rating: 4.5,
    bonus: 'Бездепозитный бонус 50₽ + 50 фриспинов',
    bonusType: 'no-deposit',
    wager: '40x',
    minDeposit: 'Нет минимального депозита для старта',
    maxWithdrawal: '150 000 ₽ в месяц',
    payoutSpeed: '1-3 банковских дня',
    license: 'Gibraltar Regulatory Authority',
    licenseNumber: 'GRA/782/B2',
    established: 2018,
    image: 'https://picsum.photos/seed/casino04/800/520',
    shortDescription: 'Универсальная площадка с единой учётной записью для ставок и казино.',
    reviewSummary:
      'Сфера Бет объединяет ставки на спорт и казино в единой экосистеме. Бездепозитный бонус привлекает новичков, а статистика позволяет анализировать игру.',
    features: [
      'Общий кошелёк для казино и спорта',
      'Нейросетевые рекомендации по слотам',
      'Маркетплейс промокодов от провайдеров'
    ],
    pros: [
      'Доступен бездепозитный бонус при верификации',
      'Расширенная аналитика по ставкам',
      'Поддержка Telegram-бота'
    ],
    cons: [
      'Подтверждение личности обязательно до первого вывода',
      'Интерфейс перегружен для мобильных устройств'
    ],
    games: ['Слоты', 'Live казино', 'Ставки на спорт', 'Кено', 'ТВ-игры'],
    categories: ['slots', 'sports', 'live'],
    tags: ['no-deposit', 'sportsbook'],
    paymentMethods: ['Банковские карты', 'Mir', 'Neteller', 'Cryptocurrency'],
    currencies: ['RUB', 'USD', 'EUR', 'BTC'],
    support: {
      channels: ['Live чат', 'Email', 'FAQ-центр'],
      schedule: '24/7'
    },
    security: 'Аппаратные HSM, мониторинг подозрительных транзакций',
    topGames: ['JetX', 'Lightning Dice', 'Hot Fiesta'],
    restrictions: 'Требует подтверждение возраста и источника средств.',
    responsibleGaming: 'Самоограничение по депозитам и сессиям, поддержка GamCare.'
  }
];

export default casinos;