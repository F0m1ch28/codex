import React from 'react';
import { Link, useParams } from 'react-router-dom';
import casinos from '../data/casinos';
import usePageMeta from '../hooks/usePageMeta';

const CasinoDetail = () => {
  const { slug } = useParams();
  const casino = casinos.find((item) => item.slug === slug);

  usePageMeta({
    title: casino
      ? `${casino.name} — обзор казино, бонусы и вывод средств`
      : 'Казино не найдено | Gambling Observer',
    description: casino
      ? `Подробный обзор ${casino.name}: бонусы, вейджер ${casino.wager}, способы пополнения и скорость вывода.`
      : 'Страница не найдена.',
    keywords: casino
      ? `обзор ${casino.name}, бонусы, вывод средств, рейтинг казино`
      : 'ошибка 404'
  });

  if (!casino) {
    return (
      <div className="page section-padding">
        <div className="container narrow">
          <h1>Казино не найдено</h1>
          <p>
            Возможно, страница была удалена или временно недоступна. Перейдите в каталог, чтобы
            выбрать другую площадку.
          </p>
          <Link to="/catalog" className="btn btn-primary">
            В каталог
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <section className="casino-hero" aria-labelledby="casino-title">
        <div className="casino-hero__overlay" />
        <div
          className="casino-hero__image"
          style={{ backgroundImage: `url(${casino.image})` }}
          role="img"
          aria-label={`Изображение ${casino.name}`}
        />
        <div className="container casino-hero__content">
          <p className="eyebrow">Обзор казино</p>
          <h1 id="casino-title">{casino.name}</h1>
          <p>{casino.shortDescription}</p>
          <div className="casino-hero__meta">
            <span className="casino-hero__rating" aria-label={`Рейтинг ${casino.rating.toFixed(1)}`}>
              ★ {casino.rating.toFixed(1)}
            </span>
            <span>{casino.license}</span>
            <span>Основано: {casino.established}</span>
            <span>Лицензия: {casino.licenseNumber}</span>
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container">
          <div className="casino-layout">
            <div className="casino-main">
              <article className="casino-section">
                <h2>Итоговая оценка</h2>
                <p>{casino.reviewSummary}</p>
                <div className="casino-highlights">
                  <div>
                    <p className="highlight-title">Приветственный бонус</p>
                    <p>{casino.bonus}</p>
                  </div>
                  <div>
                    <p className="highlight-title">Вейджер</p>
                    <p>{casino.wager}</p>
                  </div>
                  <div>
                    <p className="highlight-title">Минимальный депозит</p>
                    <p>{casino.minDeposit}</p>
                  </div>
                  <div>
                    <p className="highlight-title">Максимальный вывод</p>
                    <p>{casino.maxWithdrawal}</p>
                  </div>
                </div>
              </article>

              <article className="casino-section">
                <h2>Преимущества и ограничения</h2>
                <div className="pros-cons">
                  <div>
                    <h3>Плюсы</h3>
                    <ul>
                      {casino.pros.map((item) => (
                        <li key={item}>{item}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3>Минусы</h3>
                    <ul>
                      {casino.cons.map((item) => (
                        <li key={item}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </article>

              <article className="casino-section">
                <h2>Ассортимент игр</h2>
                <p>
                  Любителям разнообразия понравятся следующие направления. Отдельно отметим
                  подборку топовых игр, которая обновляется ежемесячно.
                </p>
                <ul className="pill-list">
                  {casino.games.map((game) => (
                    <li key={game}>{game}</li>
                  ))}
                </ul>
                <div className="top-games">
                  <h3>Хиты месяца</h3>
                  <ul>
                    {casino.topGames.map((game) => (
                      <li key={game}>{game}</li>
                    ))}
                  </ul>
                </div>
              </article>

              <article className="casino-section">
                <h2>Платежи и верификация</h2>
                <p>
                  Казино поддерживает популярные методы оплаты. Обратите внимание на лимиты и
                  требования KYC перед выводом средств.
                </p>
                <div className="payment-grid">
                  <div>
                    <h3>Способы оплаты</h3>
                    <ul>
                      {casino.paymentMethods.map((method) => (
                        <li key={method}>{method}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3>Валюта аккаунта</h3>
                    <ul>
                      {casino.currencies.map((currency) => (
                        <li key={currency}>{currency}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3>Скорость выплат</h3>
                    <p>{casino.payoutSpeed}</p>
                  </div>
                </div>
              </article>

              <article className="casino-section">
                <h2>Поддержка и безопасность</h2>
                <ul className="info-list">
                  <li>
                    <strong>Поддержка:</strong> {casino.support.channels.join(', ')} (режим{' '}
                    {casino.support.schedule})
                  </li>
                  <li>
                    <strong>Безопасность:</strong> {casino.security}
                  </li>
                  <li>
                    <strong>Ответственная игра:</strong> {casino.responsibleGaming}
                  </li>
                  <li>
                    <strong>Ограничения:</strong> {casino.restrictions}
                  </li>
                </ul>
              </article>
            </div>

            <aside className="casino-sidebar" aria-label="Быстрая информация">
              <div className="sidebar-card">
                <h3>Ключевые особенности</h3>
                <ul>
                  {casino.features.map((feature) => (
                    <li key={feature}>{feature}</li>
                  ))}
                </ul>
              </div>
              <div className="sidebar-card">
                <h3>Категории</h3>
                <ul className="pill-list">
                  {casino.categories.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
              <Link to="/compare" className="btn btn-primary btn-full">
                Сравнить с другими
              </Link>
              <Link to="/catalog" className="btn btn-ghost btn-full">
                Вернуться в каталог
              </Link>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CasinoDetail;