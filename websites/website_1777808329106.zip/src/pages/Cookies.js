import React from 'react';
import usePageMeta from '../hooks/usePageMeta';

const Cookies = () => {
  usePageMeta({
    title: 'Политика использования Cookies | Gambling Observer',
    description:
      'Подробнее о том, какие файлы cookies мы применяем и как вы можете управлять своими настройками.',
    keywords: 'cookies, политика cookies, настройки cookies'
  });

  return (
    <div className="page section-padding">
      <div className="container narrow legal-text">
        <h1>Политика cookies</h1>
        <p>Последнее обновление: 1 января 2024 года</p>

        <h2>1. Что такое cookies</h2>
        <p>
          Cookies — небольшие текстовые файлы, которые сохраняются в браузере. Они помогают запомнить
          ваши предпочтения и анализировать посещаемость.
        </p>

        <h2>2. Какие cookies мы используем</h2>
        <ul>
          <li><strong>Функциональные:</strong> обеспечивают работу сайта.</li>
          <li><strong>Аналитические:</strong> помогают понимать, какие страницы востребованы.</li>
        </ul>

        <h2>3. Управление cookies</h2>
        <p>
          Вы можете удалить или отключить cookies в настройках браузера. Однако это может повлиять на
          работу некоторых элементов сайта.
        </p>

        <h2>4. Согласие</h2>
        <p>
          Посещая наш сайт, вы соглашаетесь на использование cookies. Вы можете изменить своё решение
          в любое время, очистив cookies в браузере.
        </p>
      </div>
    </div>
  );
};

export default Cookies;