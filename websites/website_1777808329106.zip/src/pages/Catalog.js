import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import casinos from '../data/casinos';
import usePageMeta from '../hooks/usePageMeta';

const Catalog = () => {
  usePageMeta({
    title: 'Каталог казино | Фильтры по бонусам, играм и рейтингам',
    description:
      'Удобный каталог онлайн-казино с фильтрами по бонусам, вейджеру, типу игр и способам оплаты. Подберите площадку под свой стиль.',
    keywords: 'каталог казино, фильтр казино, рейтинг казино, бонусы'
  });

  const [search, setSearch] = useState('');
  const [minRating, setMinRating] = useState(0);
  const [bonusType, setBonusType] = useState('all');
  const [category, setCategory] = useState('all');

  const filteredCasinos = useMemo(() => {
    return casinos.filter((casino) => {
      const matchesSearch = casino.name.toLowerCase().includes(search.toLowerCase());
      const matchesRating = casino.rating >= minRating;
      const matchesBonus = bonusType === 'all' || casino.bonusType === bonusType;
      const matchesCategory = category === 'all' || casino.categories.includes(category);
      return matchesSearch && matchesRating && matchesBonus && matchesCategory;
    });
  }, [search, minRating, bonusType, category]);

  return (
    <div className="page section-padding">
      <div className="container">
        <header className="page-header">
          <p className="eyebrow">Каталог</p>
          <h1>Выберите подходящее казино</h1>
          <p>
            Настройте фильтры, чтобы найти площадку с нужными лимитами, бонусами и набором игр.
            Мы добавляем только лицензированные проекты.
          </p>
        </header>

        <div className="catalog-filters" aria-label="Фильтры каталога">
          <div className="form-field">
            <label htmlFor="search">Поиск</label>
            <input
              id="search"
              type="search"
              placeholder="Название казино"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>
          <div className="form-field">
            <label htmlFor="rating">Минимальный рейтинг: {minRating.toFixed(1)}</label>
            <input
              id="rating"
              type="range"
              min="0"
              max="5"
              step="0.1"
              value={minRating}
              onChange={(event) => setMinRating(Number(event.target.value))}
            />
          </div>
          <div className="form-field">
            <label htmlFor="bonusType">Тип бонуса</label>
            <select
              id="bonusType"
              value={bonusType}
              onChange={(event) => setBonusType(event.target.value)}
            >
              <option value="all">Все бонусы</option>
              <option value="welcome">Приветственный</option>
              <option value="cashback">Кэшбэк</option>
              <option value="freespins">Фриспины</option>
              <option value="no-deposit">Бездепозитный</option>
            </select>
          </div>
          <div className="form-field">
            <label htmlFor="categoryFilter">Категория игр</label>
            <select
              id="categoryFilter"
              value={category}
              onChange={(event) => setCategory(event.target.value)}
            >
              <option value="all">Все категории</option>
              <option value="slots">Слоты</option>
              <option value="live">Live казино</option>
              <option value="poker">Покер</option>
              <option value="roulette">Рулетка</option>
              <option value="jackpot">Джекпоты</option>
              <option value="sports">Ставки на спорт</option>
            </select>
          </div>
        </div>

        <div className="catalog-grid">
          {filteredCasinos.map((casino) => (
            <article key={casino.id} className="catalog-card">
              <div
                className="catalog-card__image"
                style={{ backgroundImage: `url(${casino.image})` }}
                role="img"
                aria-label={`Казино ${casino.name}`}
              />
              <div className="catalog-card__body">
                <div className="catalog-card__rating">
                  <span>★</span> {casino.rating.toFixed(1)}
                </div>
                <h2>{casino.name}</h2>
                <p>{casino.shortDescription}</p>
                <ul className="catalog-card__list">
                  <li>
                    <strong>Бонус:</strong> {casino.bonus}
                  </li>
                  <li>
                    <strong>Вейджер:</strong> {casino.wager}
                  </li>
                  <li>
                    <strong>Игры:</strong> {casino.games.join(', ')}
                  </li>
                  <li>
                    <strong>Выплаты:</strong> {casino.payoutSpeed}
                  </li>
                </ul>
                <Link to={`/casino/${casino.slug}`} className="btn btn-secondary">
                  Читать обзор
                </Link>
              </div>
            </article>
          ))}
        </div>

        {filteredCasinos.length === 0 && (
          <p className="empty-state">По выбранным параметрам площадки не найдены. Попробуйте изменить фильтры.</p>
        )}
      </div>
    </div>
  );
};

export default Catalog;