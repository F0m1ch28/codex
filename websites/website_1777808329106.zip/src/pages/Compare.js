import React, { useMemo, useState } from 'react';
import casinos from '../data/casinos';
import usePageMeta from '../hooks/usePageMeta';

const Compare = () => {
  usePageMeta({
    title: 'Сравнение казино | Таблица бонусов и лимитов',
    description:
      'Сравните бонусы, лимиты по выводу, вейджеры и поддержку разных казино. Удобная таблица для взвешенного выбора.',
    keywords: 'сравнение казино, таблица бонусов, лимиты вывода, вейджер'
  });

  const [selectedCasinos, setSelectedCasinos] = useState(casinos.map((casino) => casino.slug));

  const handleToggle = (slug) => {
    setSelectedCasinos((prev) =>
      prev.includes(slug) ? prev.filter((item) => item !== slug) : [...prev, slug]
    );
  };

  const comparisonList = useMemo(
    () => casinos.filter((casino) => selectedCasinos.includes(casino.slug)),
    [selectedCasinos]
  );

  return (
    <div className="page section-padding">
      <div className="container">
        <header className="page-header">
          <p className="eyebrow">Сравнение</p>
          <h1>Сравните условия казино</h1>
          <p>
            Выберите интересующие площадки и сравните их по ключевым параметрам: бонусы, лимиты,
            скорость выплат, вейджер, набор игр и каналы поддержки.
          </p>
        </header>

        <div className="compare-selector" role="group" aria-label="Выбор казино для сравнения">
          {casinos.map((casino) => (
            <label key={casino.slug} className="compare-checkbox">
              <input
                type="checkbox"
                checked={selectedCasinos.includes(casino.slug)}
                onChange={() => handleToggle(casino.slug)}
              />
              <span>{casino.name}</span>
            </label>
          ))}
        </div>

        {comparisonList.length > 0 ? (
          <div className="compare-table-wrapper" role="region" aria-live="polite">
            <table className="compare-table">
              <thead>
                <tr>
                  <th scope="col">Казино</th>
                  <th scope="col">Бонус</th>
                  <th scope="col">Вейджер</th>
                  <th scope="col">Мин. депозит</th>
                  <th scope="col">Макс. вывод</th>
                  <th scope="col">Игры</th>
                  <th scope="col">Платежи</th>
                  <th scope="col">Поддержка</th>
                </tr>
              </thead>
              <tbody>
                {comparisonList.map((casino) => (
                  <tr key={casino.slug}>
                    <th scope="row">{casino.name}</th>
                    <td>{casino.bonus}</td>
                    <td>{casino.wager}</td>
                    <td>{casino.minDeposit}</td>
                    <td>{casino.maxWithdrawal}</td>
                    <td>{casino.games.join(', ')}</td>
                    <td>{casino.paymentMethods.join(', ')}</td>
                    <td>
                      {casino.support.channels.join(', ')} ({casino.support.schedule})
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="compare-note">
              Советы: обращайте внимание на вейджер и ограничения по выводу. Если бонус без отыгрыша,
              он может иметь ограничение по максимальному выигрышу. Перед началом игры обязательно
              прочитайте правила площадки.
            </p>
          </div>
        ) : (
          <p className="empty-state">Выберите хотя бы одну площадку для сравнения.</p>
        )}
      </div>
    </div>
  );
};

export default Compare;