import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import casinos from '../data/casinos';
import usePageMeta from '../hooks/usePageMeta';

const Home = () => {
  usePageMeta({
    title: 'Обзоры казино и честные рейтинги | Gambling Observer',
    description:
      'Актуальные обзоры онлайн-казино, честные рейтинги, сравнение бонусов и аналитика для ответственной игры. Подборки лучших площадок и советы экспертов.',
    keywords:
      'обзор казино, рейтинг казино, сравнение бонусов, отзывы игроков, лучшие слоты'
  });

  const topCasinos = useMemo(
    () => [...casinos].sort((a, b) => b.rating - a.rating).slice(0, 3),
    []
  );

  const statsConfig = useMemo(
    () => [
      { label: 'Проверенных казино в базе', value: 124, suffix: '+' },
      { label: 'Актуальных бонусов', value: 58 },
      { label: 'Читателей каждый месяц', value: 27000, suffix: '+' }
    ],
    []
  );
  const [animatedStats, setAnimatedStats] = useState(
    statsConfig.map((item) => ({ ...item, display: 0 }))
  );
  const [hasAnimatedStats, setHasAnimatedStats] = useState(false);
  const statsRef = useRef(null);

  useEffect(() => {
    const node = statsRef.current;
    if (!node || hasAnimatedStats) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setHasAnimatedStats(true);
          statsConfig.forEach((item, index) => {
            const duration = 1200 + index * 180;
            const start = performance.now();
            const animate = (time) => {
              const elapsed = time - start;
              const progress = Math.min(elapsed / duration, 1);
              const value = Math.floor(progress * item.value);
              setAnimatedStats((prev) =>
                prev.map((stat, i) =>
                  i === index ? { ...stat, display: value } : stat
                )
              );
              if (progress < 1) {
                requestAnimationFrame(animate);
              } else {
                setAnimatedStats((prev) =>
                  prev.map((stat, i) =>
                    i === index ? { ...stat, display: item.value } : stat
                  )
                );
              }
            };
            requestAnimationFrame(animate);
          });
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );

    observer.observe(node);

    return () => observer.disconnect();
  }, [statsConfig, hasAnimatedStats]);

  const advantages = [
    {
      title: 'Объективность',
      description: 'Проверяем каждый факт: лицензии, лимиты, условия бонусов и отзывы игроков.',
      icon: '🧭'
    },
    {
      title: 'Детальность',
      description: 'Разбираем бонусную политику, провайдеров, каналы поддержки и скорость выплат.',
      icon: '🧬'
    },
    {
      title: 'Сравнение',
      description: 'Находите площадку по рейтингу, типу игр, бонусам и способам пополнения.',
      icon: '⚖️'
    },
    {
      title: 'Безопасность',
      description: 'Следим за сертификацией RNG, шифрованием и практикой ответственной игры.',
      icon: '🛡️'
    }
  ];

  const categories = [
    {
      key: 'slots',
      title: 'Слоты',
      description: 'Топ провайдеров, RTP, джекпоты и эксклюзивные подборки.',
      image: 'https://picsum.photos/seed/category1/720/480'
    },
    {
      key: 'live',
      title: 'Live Casino',
      description: 'Рулетка, блэкджек и шоу-игры с дилерами на русском.',
      image: 'https://picsum.photos/seed/category2/720/480'
    },
    {
      key: 'poker',
      title: 'Покер',
      description: 'Кэш-столы, турниры, рейкбэк и обзоры софта.',
      image: 'https://picsum.photos/seed/category3/720/480'
    },
    {
      key: 'sports',
      title: 'Ставки + казино',
      description: 'Единый кошелек для ставок и слотов, live-статистика.',
      image: 'https://picsum.photos/seed/category4/720/480'
    }
  ];

  const processSteps = [
    {
      step: 1,
      title: 'Сбор данных',
      description: 'Проверяем лицензии, читаем пользовательские соглашения, анализируем платежные опции.'
    },
    {
      step: 2,
      title: 'Тестирование',
      description: 'Делаем реальные депозиты, активируем бонусы, выводим средства и фиксируем скорость.'
    },
    {
      step: 3,
      title: 'Аналитика',
      description: 'Сравниваем коэффициенты, условия отыгрыша, уровень поддержки и список провайдеров.'
    },
    {
      step: 4,
      title: 'Публикация',
      description: 'Готовим обзор, выставляем рейтинг и обновляем данные при каждом изменении.'
    }
  ];

  const testimonials = [
    {
      name: 'Ирина С.',
      role: 'Коллекционер бонусов',
      quote:
        'Благодаря разделу сравнения нашла площадку с честным кэшбэком без отыгрыша. Очень нравится подробность обзоров.',
      avatar: 'https://picsum.photos/seed/review1/96/96'
    },
    {
      name: 'Владимир К.',
      role: 'Игрок в live-рулетку',
      quote:
        'Оценил фильтры по провайдерам и лицензиям. Помогли подобрать казино с локализованными столами и быстрым выводом.',
      avatar: 'https://picsum.photos/seed/review2/96/96'
    },
    {
      name: 'Анна Л.',
      role: 'Новичок',
      quote:
        'После тестов на ответственную игру убедилась, что мне подходит только площадка с жёсткими лимитами. Спасибо за подсказки!',
      avatar: 'https://picsum.photos/seed/review3/96/96'
    }
  ];
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const team = [
    {
      name: 'Алексей Марков',
      role: 'Аналитик бонусов',
      bio: '10 лет в индустрии азартных игр, специализация — бонусные программы и вейджеры.',
      image: 'https://picsum.photos/seed/team1/400/400'
    },
    {
      name: 'Мария Ким',
      role: 'Эксперт по ответственному гемблингу',
      bio: 'Сертифицированный консультант, помогает игрокам выстраивать безопасные привычки.',
      image: 'https://picsum.photos/seed/team2/400/400'
    },
    {
      name: 'Даниил Горин',
      role: 'Обозреватель live-игр',
      bio: 'Проводит тесты live-столов, оценивает стабильность соединения и навыки дилеров.',
      image: 'https://picsum.photos/seed/team3/400/400'
    }
  ];

  const projects = [
    {
      id: 1,
      title: 'Серия обзоров «Честные слоты»',
      category: 'slots',
      description:
        'Анализировали 150 популярных слотов, сравнили RTP, волатильность и бонусные механики.',
      image: 'https://picsum.photos/seed/project1/960/640'
    },
    {
      id: 2,
      title: 'Гайд по live-казино для новичков',
      category: 'live',
      description:
        'Собрали рекомендации по выбору столов, описали регламент и требования к соединению.',
      image: 'https://picsum.photos/seed/project2/960/640'
    },
    {
      id: 3,
      title: 'Исследование кэшбэк-программ',
      category: 'analytics',
      description:
        'Проанализировали 32 казино и вывели формулу реального возврата средств для разных статусов.',
      image: 'https://picsum.photos/seed/project3/960/640'
    },
    {
      id: 4,
      title: 'Интерактивный рейтинг быстрого вывода',
      category: 'payments',
      description:
        'Сделали рейтинг по времени выплат и добавили фильтр по методам пополнения.',
      image: 'https://picsum.photos/seed/project4/960/640'
    }
  ];
  const [projectFilter, setProjectFilter] = useState('all');

  const blogPosts = [
    {
      id: 1,
      title: 'Как читать условия бонусов и не попасть в ловушку',
      summary:
        'Разбираем типичные формулировки в правилах бонусов. Показываем реальные примеры расчёта вейджера.',
      image: 'https://picsum.photos/seed/blog1/760/520',
      date: '10 января 2024'
    },
    {
      id: 2,
      title: 'Ответственная игра: чек-лист самооценки',
      summary:
        '10 вопросов, которые помогут оценить отношение к азарту. Советы от сертифицированных консультантов.',
      image: 'https://picsum.photos/seed/blog2/760/520',
      date: '22 декабря 2023'
    },
    {
      id: 3,
      title: 'Лучшие live-столы с русскоязычными дилерами',
      summary:
        'Подборка площадок, где можно поиграть в рулетку и блэкджек с дилерами, говорящими по-русски.',
      image: 'https://picsum.photos/seed/blog3/760/520',
      date: '4 декабря 2023'
    }
  ];

  const faqs = [
    {
      question: 'Как мы формируем рейтинг казино?',
      answer:
        'Оцениваем лицензии, скорость выплат, честность бонусов, поддержку, репутацию среди игроков и работу службы безопасности. Каждое казино проходит тестовую проверку.'
    },
    {
      question: 'Что учитывать при выборе бонуса?',
      answer:
        'Смотрите на вейджер, лимит по ставке, срок действия и максимальный выигрыш. Мы выделяем бонусы с прозрачными условиями и указываем потенциальные ограничения.'
    },
    {
      question: 'Как быстро выводятся средства?',
      answer:
        'В таблицах обзоров мы указываем среднее время вывода по методам. Быстрее всего работают электронные кошельки и криптовалюты, но всё зависит от политики конкретного казино.'
    },
    {
      question: 'Есть ли рекомендации по ответственной игре?',
      answer:
        'Да. Мы рекомендуем устанавливать личные лимиты, использовать функции самоисключения и проходить самооценочные тесты. На сайте собраны ссылки на организации помощи.'
    }
  ];

  const [openFaqIndex, setOpenFaqIndex] = useState(0);

  return (
    <div className="page">
      <section className="hero">
        <div className="container hero__content">
          <div className="hero__text">
            <p className="eyebrow">Независимый гид</p>
            <h1>Обзоры казино, которым можно доверять</h1>
            <p className="hero__subtitle">
              Мы анализируем лицензии, бонусы, выплаты и уровень безопасности. Выбирайте площадку
              осознанно, а мы обновим рейтинг при каждом изменении условий.
            </p>
            <div className="hero__actions">
              <Link to="/catalog" className="btn btn-primary">
                Перейти в каталог
              </Link>
              <Link to="/compare" className="btn btn-ghost">
                Сравнить условия
              </Link>
            </div>
            <div className="hero__note">
              <span>18+</span>
              <p>Азартные игры предназначены только для совершеннолетних. Играйте ответственно.</p>
            </div>
          </div>
          <div className="hero__visual" aria-hidden="true">
            <div className="hero__image" />
          </div>
        </div>
      </section>

      <section className="advantages section-padding" aria-labelledby="advantages-heading">
        <div className="container">
          <header className="section-header">
            <h2 id="advantages-heading">Почему игроки выбирают нас</h2>
            <p>
              Мы проводим глубокую аналитику и публикуем честные обзоры, чтобы вы всегда понимали
              условия до регистрации.
            </p>
          </header>
          <div className="advantage-grid">
            {advantages.map((item) => (
              <article key={item.title} className="advantage-card">
                <div className="advantage-icon" aria-hidden="true">
                  {item.icon}
                </div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
          <div className="stats-grid" ref={statsRef} role="group" aria-label="Ключевые показатели">
            {animatedStats.map((stat) => (
              <div key={stat.label} className="stat-card">
                <p className="stat-value">
                  {stat.display}
                  {stat.suffix || ''}
                </p>
                <p className="stat-label">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="popular section-padding" aria-labelledby="popular-heading">
        <div className="container">
          <header className="section-header">
            <h2 id="popular-heading">Популярные казино этой недели</h2>
            <p>Подборка площадок с высоким рейтингом, быстрыми выплатами и прозрачными условиями.</p>
          </header>
          <div className="card-grid">
            {topCasinos.map((casino) => (
              <article key={casino.id} className="casino-card">
                <div
                  className="casino-card__image"
                  style={{ backgroundImage: `url(${casino.image})` }}
                  role="img"
                  aria-label={`Изображение казино ${casino.name}`}
                />
                <div className="casino-card__body">
                  <div className="casino-card__rating">
                    <span className="rating-star" aria-hidden="true">
                      ★
                    </span>
                    <span className="rating-value">{casino.rating.toFixed(1)}</span>
                  </div>
                  <h3>{casino.name}</h3>
                  <p className="casino-card__description">{casino.shortDescription}</p>
                  <ul className="casino-card__features">
                    <li>
                      <strong>Бонус:</strong> {casino.bonus}
                    </li>
                    <li>
                      <strong>Вейджер:</strong> {casino.wager}
                    </li>
                    <li>
                      <strong>Выплаты:</strong> {casino.payoutSpeed}
                    </li>
                  </ul>
                  <Link to={`/casino/${casino.slug}`} className="btn btn-secondary">
                    Подробнее
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="categories section-padding" aria-labelledby="categories-heading">
        <div className="container">
          <header className="section-header">
            <h2 id="categories-heading">Найдите свой формат игры</h2>
            <p>Используйте каталог и фильтры, чтобы подобрать площадку под любимые категории.</p>
          </header>
          <div className="category-grid">
            {categories.map((category) => (
              <article key={category.key} className="category-card">
                <div
                  className="category-card__image"
                  style={{ backgroundImage: `url(${category.image})` }}
                  role="img"
                  aria-label={`Категория ${category.title}`}
                />
                <div className="category-card__content">
                  <h3>{category.title}</h3>
                  <p>{category.description}</p>
                  <Link to="/catalog" className="category-card__link">
                    Смотреть площадки →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="process section-padding" aria-labelledby="process-heading">
        <div className="container">
          <header className="section-header">
            <h2 id="process-heading">Как мы создаём обзоры</h2>
            <p>Методология построена на реальных тестах и прозрачных критериях оценки.</p>
          </header>
          <div className="process-steps" role="list">
            {processSteps.map((step) => (
              <div key={step.step} className="process-step" role="listitem">
                <span className="process-step__number" aria-hidden="true">
                  {step.step < 10 ? `0${step.step}` : step.step}
                </span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="projects section-padding" aria-labelledby="projects-heading">
        <div className="container">
          <header className="section-header projects-header">
            <div>
              <h2 id="projects-heading">Исследования и спецпроекты</h2>
              <p>
                Глубокие аналитические материалы, призванные помочь игрокам и индустрии строить
                честный и прозрачный рынок.
              </p>
            </div>
            <div className="projects-filters" role="group" aria-label="Фильтр проектов">
              <button
                type="button"
                className={`filter-chip ${projectFilter === 'all' ? 'filter-chip--active' : ''}`}
                onClick={() => setProjectFilter('all')}
              >
                Все
              </button>
              <button
                type="button"
                className={`filter-chip ${projectFilter === 'slots' ? 'filter-chip--active' : ''}`}
                onClick={() => setProjectFilter('slots')}
              >
                Слоты
              </button>
              <button
                type="button"
                className={`filter-chip ${projectFilter === 'live' ? 'filter-chip--active' : ''}`}
                onClick={() => setProjectFilter('live')}
              >
                Live
              </button>
              <button
                type="button"
                className={`filter-chip ${projectFilter === 'analytics' ? 'filter-chip--active' : ''}`}
                onClick={() => setProjectFilter('analytics')}
              >
                Аналитика
              </button>
              <button
                type="button"
                className={`filter-chip ${projectFilter === 'payments' ? 'filter-chip--active' : ''}`}
                onClick={() => setProjectFilter('payments')}
              >
                Платежи
              </button>
            </div>
          </header>
          <div className="project-grid">
            {projects
              .filter((project) => projectFilter === 'all' || project.category === projectFilter)
              .map((project) => (
                <article key={project.id} className="project-card">
                  <div
                    className="project-card__image"
                    style={{ backgroundImage: `url(${project.image})` }}
                    role="img"
                    aria-label={`Проект: ${project.title}`}
                  />
                  <div className="project-card__content">
                    <p className="project-card__tag">
                      {project.category === 'slots' && 'Слоты'}
                      {project.category === 'live' && 'Live казино'}
                      {project.category === 'analytics' && 'Аналитика'}
                      {project.category === 'payments' && 'Платежи'}
                    </p>
                    <h3>{project.title}</h3>
                    <p>{project.description}</p>
                    <Link to="/services" className="project-card__link">
                      Узнать подробнее →
                    </Link>
                  </div>
                </article>
              ))}
          </div>
        </div>
      </section>

      <section className="testimonials section-padding" aria-labelledby="testimonials-heading">
        <div className="container">
          <header className="section-header">
            <h2 id="testimonials-heading">Что говорят читатели</h2>
            <p>Мы ценим обратную связь и постоянно улучшаем обзоры и инструменты.</p>
          </header>
          <div className="testimonial-carousel" role="region" aria-live="polite">
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`testimonial-card ${
                  index === activeTestimonial ? 'testimonial-card--active' : ''
                }`}
                hidden={index !== activeTestimonial}
              >
                <img
                  src={testimonial.avatar}
                  alt={`Фото: ${testimonial.name}`}
                  className="testimonial-avatar"
                  loading="lazy"
                />
                <blockquote>
                  <p>“{testimonial.quote}”</p>
                </blockquote>
                <footer>
                  <p className="testimonial-name">{testimonial.name}</p>
                  <p className="testimonial-role">{testimonial.role}</p>
                </footer>
              </article>
            ))}
            <div className="testimonial-controls" aria-label="Переключение отзывов">
              <button
                type="button"
                className="carousel-dot"
                aria-label="Предыдущий отзыв"
                onClick={() =>
                  setActiveTestimonial(
                    (prev) => (prev - 1 + testimonials.length) % testimonials.length
                  )
                }
              >
                ←
              </button>
              <button
                type="button"
                className="carousel-dot"
                aria-label="Следующий отзыв"
                onClick={() =>
                  setActiveTestimonial((prev) => (prev + 1) % testimonials.length)
                }
              >
                →
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="team section-padding" aria-labelledby="team-heading">
        <div className="container">
          <header className="section-header">
            <h2 id="team-heading">Команда экспертов</h2>
            <p>Каждый материал проходит тройную проверку — аналитика, редакция, ответственный гемблинг.</p>
          </header>
          <div className="team-grid">
            {team.map((member) => (
              <article key={member.name} className="team-card">
                <img
                  src={member.image}
                  alt={`Эксперт: ${member.name}`}
                  className="team-card__image"
                  loading="lazy"
                />
                <div className="team-card__content">
                  <h3>{member.name}</h3>
                  <p className="team-card__role">{member.role}</p>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="blog section-padding" aria-labelledby="blog-heading">
        <div className="container">
          <header className="section-header">
            <h2 id="blog-heading">Свежие материалы</h2>
            <p>Читайте аналитические статьи и гайды по ответственной игре.</p>
          </header>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article key={post.id} className="blog-card">
                <div
                  className="blog-card__image"
                  style={{ backgroundImage: `url(${post.image})` }}
                  role="img"
                  aria-label={`Иллюстрация к статье: ${post.title}`}
                />
                <div className="blog-card__content">
                  <p className="blog-card__date">{post.date}</p>
                  <h3>{post.title}</h3>
                  <p>{post.summary}</p>
                  <Link to="/services" className="blog-card__link">
                    Читать далее →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq section-padding" aria-labelledby="faq-heading">
        <div className="container">
          <header className="section-header">
            <h2 id="faq-heading">Частые вопросы</h2>
            <p>Собрали ответы на вопросы, которые чаще всего задают наши читатели.</p>
          </header>
          <div className="faq-accordion" role="tablist">
            {faqs.map((faq, index) => (
              <div key={faq.question} className="faq-item">
                <button
                  type="button"
                  className="faq-question"
                  aria-expanded={openFaqIndex === index}
                  aria-controls={`faq-panel-${index}`}
                  onClick={() => setOpenFaqIndex(openFaqIndex === index ? -1 : index)}
                >
                  <span>{faq.question}</span>
                  <span aria-hidden="true">{openFaqIndex === index ? '−' : '+'}</span>
                </button>
                <div
                  id={`faq-panel-${index}`}
                  className={`faq-answer ${openFaqIndex === index ? 'faq-answer--open' : ''}`}
                  role="region"
                  aria-hidden={openFaqIndex !== index}
                >
                  <p>{faq.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="cta section-padding" aria-labelledby="cta-heading">
        <div className="container cta-container">
          <div className="cta-content">
            <h2 id="cta-heading">Выбирайте казино осознанно</h2>
            <p>
              Перейдите в каталог, отфильтруйте площадки по бонусам, лимитам, провайдерам и выбору
              валют. Мы поможем подобрать площадку под ваш стиль игры.
            </p>
          </div>
          <Link to="/catalog" className="btn btn-primary btn-large">
            Подобрать площадку
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;