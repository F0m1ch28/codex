import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';

const Contact = () => {
  usePageMeta({
    title: 'Контакты Gambling Observer | Обратная связь',
    description:
      'Свяжитесь с командой Gambling Observer. Принимаем предложения по улучшению сайта и запросы на аналитические исследования.',
    keywords: 'контакты, обратная связь, предложения, сотрудничество'
  });

  const [formData, setFormData] = useState({ name: '', email: '', message: '', consent: false });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const validationErrors = {};
    if (!formData.name.trim()) validationErrors.name = 'Введите имя';
    if (!formData.email.match(/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/)) validationErrors.email = 'Введите корректный email';
    if (!formData.message.trim()) validationErrors.message = 'Напишите сообщение';
    if (!formData.consent) validationErrors.consent = 'Подтвердите согласие с условиями';
    setErrors(validationErrors);
    return Object.keys(validationErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setFormData({ name: '', email: '', message: '', consent: false });
  };

  return (
    <div className="page section-padding">
      <div className="container narrow">
        <header className="page-header">
          <p className="eyebrow">Контакты</p>
          <h1>Напишите нам</h1>
          <p>
            Мы открыты для обратной связи: предложения по сайту, замеченные неточности, запросы на
            исследование рынка. Ответим в течение 2-3 рабочих дней.
          </p>
        </header>

        <form className="contact-form" onSubmit={handleSubmit} noValidate>
          <div className="form-field">
            <label htmlFor="name">Имя</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Как к вам обращаться?"
              value={formData.name}
              onChange={(event) => setFormData((prev) => ({ ...prev, name: event.target.value }))}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'name-error' : undefined}
            />
            {errors.name && (
              <span id="name-error" className="field-error">
                {errors.name}
              </span>
            )}
          </div>

          <div className="form-field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="example@mail.com"
              value={formData.email}
              onChange={(event) => setFormData((prev) => ({ ...prev, email: event.target.value }))}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'email-error' : undefined}
            />
            {errors.email && (
              <span id="email-error" className="field-error">
                {errors.email}
              </span>
            )}
          </div>

          <div className="form-field">
            <label htmlFor="message">Сообщение</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Расскажите о запросе"
              value={formData.message}
              onChange={(event) =>
                setFormData((prev) => ({ ...prev, message: event.target.value }))
              }
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'message-error' : undefined}
            />
            {errors.message && (
              <span id="message-error" className="field-error">
                {errors.message}
              </span>
            )}
          </div>

          <div className="form-checkbox">
            <input
              id="consent"
              name="consent"
              type="checkbox"
              checked={formData.consent}
              onChange={(event) =>
                setFormData((prev) => ({ ...prev, consent: event.target.checked }))
              }
            />
            <label htmlFor="consent">
              Согласен(а) с{' '}
              <a href="/privacy" className="inline-link">
                политикой конфиденциальности
              </a>{' '}
              и подтверждаю, что мне есть 18 лет.
            </label>
          </div>
          {errors.consent && <span className="field-error">{errors.consent}</span>}

          <button type="submit" className="btn btn-primary">
            Отправить сообщение
          </button>

          {submitted && (
            <p className="form-success" role="status">
              Спасибо! Мы получили ваше сообщение и свяжемся в ближайшее время.
            </p>
          )}
        </form>
      </div>
    </div>
  );
};

export default Contact;