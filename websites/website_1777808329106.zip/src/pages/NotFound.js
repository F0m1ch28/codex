import React from 'react';
import { Link } from 'react-router-dom';
import usePageMeta from '../hooks/usePageMeta';

const NotFound = () => {
  usePageMeta({
    title: 'Страница не найдена | Gambling Observer',
    description: 'Страница не найдена. Перейдите в каталог казино или на главную страницу.',
    keywords: '404, страница не найдена'
  });

  return (
    <div className="page section-padding">
      <div className="container narrow">
        <h1>Страница не найдена</h1>
        <p>
          Похоже, вы перешли по устаревшей ссылке или опечатались в адресе. Вернитесь на главную или
          посмотрите каталог казино.
        </p>
        <div className="notfound-actions">
          <Link to="/" className="btn btn-primary">
            На главную
          </Link>
          <Link to="/catalog" className="btn btn-secondary">
            Каталог казино
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;