import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';

const servicesData = [
  {
    id: 1,
    title: 'Проверка казино под запрос',
    summary: 'Тест-драйв площадки с реальными депозитами и выводом средств.',
    details:
      'Разрабатываем чек-лист проверки под ваш сценарий, фиксируем скорость выплат, анализируем бонусную политику и предоставляем отчёт с рекомендациями.'
  },
  {
    id: 2,
    title: 'Аудит бонусной программы',
    summary: 'Глубокий анализ условий отыгрыша, лимитов и скрытых ограничений.',
    details:
      'Сравниваем данные с рынком, подсчитываем реальную выгоду и находим потенциальные риски. Предоставляем калькулятор для собственных расчётов.'
  },
  {
    id: 3,
    title: 'Консультации по ответственной игре',
    summary: 'Персональный план лимитов и контроль привычек.',
    details:
      'Сертифицированный специалист поможет настроить лимиты, провести самооценку и подобрать организации для дополнительной поддержки.'
  },
  {
    id: 4,
    title: 'Маркетинговые исследования',
    summary: 'Анализ поведения игроков и трендов азартной индустрии.',
    details:
      'Мы собираем инсайты о предпочтениях игроков, сегментируем аудиторию и составляем отчёт с рекомендациями для легальных операторов.'
  }
];

const Services = () => {
  usePageMeta({
    title: 'Услуги Gambling Observer | Аналитика и проверка казино',
    description:
      'Проверка казино под запрос, аудит бонусов, консультации по ответственной игре и маркетинговые исследования.',
    keywords: 'услуги, аудит казино, проверка бонусов, консультации, ответственная игра'
  });

  const [activeService, setActiveService] = useState(servicesData[0].id);

  return (
    <div className="page section-padding">
      <div className="container narrow">
        <header className="page-header">
          <p className="eyebrow">Наши услуги</p>
          <h1>Профессиональная аналитика азартного рынка</h1>
          <p>
            Мы предоставляем услуги для игроков, медиа и легальных операторов. Все консультации
            доступны только совершеннолетним пользователям.
          </p>
        </header>

        <div className="services-split">
          <div className="services-list" role="tablist" aria-label="Список услуг">
            {servicesData.map((service) => (
              <button
                key={service.id}
                type="button"
                role="tab"
                aria-selected={activeService === service.id}
                className={`service-item ${activeService === service.id ? 'service-item--active' : ''}`}
                onClick={() => setActiveService(service.id)}
              >
                <h3>{service.title}</h3>
                <p>{service.summary}</p>
              </button>
            ))}
          </div>
          <div className="services-details" role="tabpanel">
            {servicesData
              .filter((service) => service.id === activeService)
              .map((service) => (
                <div key={service.id}>
                  <h2>{service.title}</h2>
                  <p>{service.details}</p>
                  <ul className="service-bullets">
                    <li>Пошаговый отчёт с доказательствами</li>
                    <li>Конфиденциальность и защита данных</li>
                    <li>Только лицензированные площадки и проверенные источники</li>
                  </ul>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;