document.addEventListener("DOMContentLoaded", function () {
  const banner = document.getElementById("cookieBanner");
  const acceptBtn = document.getElementById("cookieAccept");
  const declineBtn = document.getElementById("cookieDecline");

  if (!banner) {
    return;
  }

  const cookieChoice = localStorage.getItem("st_cookie_choice");

  if (!cookieChoice) {
    banner.classList.add("visible");
  }

  acceptBtn.addEventListener("click", function () {
    localStorage.setItem("st_cookie_choice", "accepted");
    banner.classList.remove("visible");
  });

  declineBtn.addEventListener("click", function () {
    localStorage.setItem("st_cookie_choice", "declined");
    banner.classList.remove("visible");
  });
});