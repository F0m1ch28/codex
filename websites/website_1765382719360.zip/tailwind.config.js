/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#0C1E3B",
        accent: "#00D9FF",
        verdant: "#10B981",
        light: "#FAFBFC",
        graphite: "#1F2937"
      },
      fontFamily: {
        sans: ["Inter", "sans-serif"],
        display: ["Outfit", "sans-serif"],
        mono: ["Fira Code", "monospace"]
      },
      boxShadow: {
        glow: "0 0 25px rgba(0, 217, 255, 0.35)"
      },
      backgroundImage: {
        "node-grid": "radial-gradient(circle at center, rgba(0,217,255,0.15) 0, rgba(12,30,59,0.05) 45%, rgba(12,30,59,0) 70%)"
      }
    }
  },
  plugins: []
};