import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTopButton from "./components/ScrollToTopButton";
import Home from "./pages/Home";
import QuienesSomos from "./pages/QuienesSomos";
import TecnologiasSmartGrid from "./pages/TecnologiasSmartGrid";
import ProyectosPiloto from "./pages/ProyectosPiloto";
import RecursosTecnicos from "./pages/RecursosTecnicos";
import Blog from "./pages/Blog";
import Colabora from "./pages/Colabora";
import Legal from "./pages/Legal";
import Privacidad from "./pages/Privacidad";
import PoliticaCookies from "./pages/PoliticaCookies";

const RouteScrollRestorer: React.FC = () => {
  const { pathname } = useLocation();
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [pathname]);
  return null;
};

const App: React.FC = () => {
  return (
    <div className="flex min-h-screen flex-col bg-light text-primary">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:rounded-md focus:bg-accent focus:px-4 focus:py-2 focus:text-primary"
      >
        Saltar al contenido principal
      </a>
      <Header />
      <RouteScrollRestorer />
      <main id="main-content" className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/quienes-somos" element={<QuienesSomos />} />
          <Route path="/tecnologias-smart-grid" element={<TecnologiasSmartGrid />} />
          <Route path="/proyectos-piloto" element={<ProyectosPiloto />} />
          <Route path="/recursos-tecnicos" element={<RecursosTecnicos />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/colabora" element={<Colabora />} />
          <Route path="/legal" element={<Legal />} />
          <Route path="/privacidad" element={<Privacidad />} />
          <Route path="/politica-de-cookies" element={<PoliticaCookies />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;