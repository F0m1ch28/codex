import React from "react";
import { Helmet } from "react-helmet-async";

const PoliticaCookies: React.FC = () => (
  <>
    <Helmet>
      <title>Política de Cookies | RedInteligente España</title>
      <meta
        name="description"
        content="Información sobre el uso de cookies en la plataforma RedInteligente España."
      />
      <link rel="canonical" href="https://redinteligente.com/politica-de-cookies" />
      <meta property="og:title" content="Política de Cookies | RedInteligente España" />
      <meta property="og:description" content="Detalles sobre cookies técnicas y analíticas utilizadas por RedInteligente España." />
      <meta property="og:image" content="https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1600&q=80" />
    </Helmet>
    <section className="bg-white py-20">
      <div className="mx-auto w-full max-w-4xl px-4 lg:px-8">
        <h1 className="font-display text-3xl font-semibold text-primary">Política de Cookies</h1>
        <p className="mt-4 text-sm text-primary/70">
          Utilizamos cookies estrictamente necesarias para el funcionamiento de la plataforma y cookies analíticas para entender el rendimiento de la red inteligente.
        </p>
        <div className="mt-8 space-y-6 text-sm text-primary/75">
          <section>
            <h2 className="text-lg font-semibold text-primary">Cookies técnicas</h2>
            <p>
              Permiten la navegación y el uso correcto de funcionalidades como el monitor de flujo, autenticación de usuarios autorizados y ajustes de visualización.
            </p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-primary">Cookies analíticas</h2>
            <p>
              Analizan visitas, comportamiento anónimo y tiempos de respuesta de los paneles. El consentimiento se solicita mediante el banner de cookies.
            </p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-primary">Gestión</h2>
            <p>
              En cualquier momento puedes retirar o cambiar tu consentimiento contactando con info@redinteligente.com o ajustando los parámetros del navegador.
            </p>
          </section>
        </div>
      </div>
    </section>
  </>
);

export default PoliticaCookies;