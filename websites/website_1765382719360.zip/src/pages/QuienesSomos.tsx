import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const milestones = [
  { year: "2018", detail: "Creación del hub de innovación junto a universidades públicas y operadores regionales." },
  { year: "2020", detail: "Primera microrred urbana integrada con respuesta flexible y almacenamiento distribuido." },
  { year: "2022", detail: "Despliegue de analítica predictiva y digital twins en nodos de media tensión." },
  { year: "2023", detail: "Expansión a proyectos interregionales con integración de movilidad eléctrica." }
];

const values = [
  { title: "Transparencia de datos", description: "Visibilidad en tiempo real de indicadores de red con estándares abiertos." },
  { title: "Colaboración multiactor", description: "Trabajamos junto a distribuidoras, startups, municipios y ciudadanía." },
  { title: "Innovación responsable", description: "Probamos tecnologías emergentes priorizando la resiliencia y la ciberseguridad." }
];

const QuienesSomos: React.FC = () => (
  <>
    <Helmet>
      <title>Quiénes Somos | RedInteligente España</title>
      <meta
        name="description"
        content="Conoce al equipo de RedInteligente España: expertos en smart grids, IoT energético y microrredes colaborativas."
      />
      <link rel="canonical" href="https://redinteligente.com/quienes-somos" />
      <meta property="og:title" content="Quiénes Somos | RedInteligente España" />
      <meta property="og:description" content="Equipo multidisciplinar dedicado a las redes inteligentes y la innovación energética." />
      <meta property="og:image" content="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1600&q=80" />
    </Helmet>
    <section className="bg-node-grid py-20">
      <div className="mx-auto w-full max-w-5xl px-4 text-center lg:px-8">
        <h1 className="font-display text-4xl font-semibold text-primary">Somos RedInteligente España</h1>
        <p className="mt-4 text-base text-primary/70">
          Un ecosistema de especialistas en ingeniería eléctrica, analítica de datos y gobernanza energética que impulsan redes inteligentes para un país neutro en carbono.
        </p>
      </div>
    </section>
    <section className="bg-white py-16">
      <div className="mx-auto w-full max-w-6xl px-4 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[2fr,3fr]">
          <div>
            <h2 className="font-display text-2xl font-semibold text-primary">Visión</h2>
            <p className="mt-4 text-sm leading-relaxed text-primary/70">
              Aspiramos a que cada barrio, industria y municipio pueda operar microrredes resilientes interoperando con la red nacional. Apostamos por la participación activa de la ciudadanía para construir un ecosistema energético transparente y sostenible.
            </p>
            <h2 className="mt-10 font-display text-2xl font-semibold text-primary">Valores</h2>
            <ul className="mt-6 space-y-4">
              {values.map((value) => (
                <li key={value.title} className="rounded-2xl border border-primary/10 bg-light p-5">
                  <h3 className="text-lg font-semibold text-primary">{value.title}</h3>
                  <p className="mt-2 text-sm text-primary/70">{value.description}</p>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2 className="font-display text-2xl font-semibold text-primary">Cronología</h2>
            <div className="mt-6 space-y-6 border-l border-primary/20 pl-6">
              {milestones.map((milestone) => (
                <div key={milestone.year} className="relative">
                  <span className="absolute -left-[33px] mt-1 h-4 w-4 rounded-full border-2 border-primary bg-light" />
                  <h3 className="font-mono text-sm text-accent">{milestone.year}</h3>
                  <p className="mt-2 text-sm text-primary/70">{milestone.detail}</p>
                </div>
              ))}
            </div>
            <div className="mt-10 rounded-3xl border border-primary/10 bg-white p-6 shadow-card">
              <h3 className="font-display text-xl font-semibold text-primary">Equipo central</h3>
              <p className="mt-3 text-sm text-primary/70">
                Ingeniería eléctrica, ciencia de datos, regulación energética, urbanismo y ciberseguridad conviven en equipos ágiles que operan desde Madrid, Barcelona y Valencia.
              </p>
              <motion.img
                className="mt-6 h-60 w-full rounded-2xl object-cover"
                src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1600&q=80"
                alt="Equipo colaborando en el hub de innovación"
                initial={{ opacity: 0.6 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default QuienesSomos;