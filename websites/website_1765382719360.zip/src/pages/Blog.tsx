import React from "react";
import { Helmet } from "react-helmet-async";

const posts = [
  {
    title: "Microrredes residenciales: aprendizajes de la comunidad de Valdebebas",
    excerpt: "Sensores de consumo, fotovoltaica comunitaria y algoritmos de flexibilidad en un mismo ecosistema.",
    date: "01/02/2024",
    image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&w=1200&q=80"
  },
  {
    title: "Claves para integrar almacenamiento distribuido en redes urbanas",
    excerpt: "Modelado energético, interoperabilidad y coordinación con operadores de distribución.",
    date: "18/01/2024",
    image: "https://images.unsplash.com/photo-1541976590-713941681591?auto=format&fit=crop&w=1200&q=80"
  },
  {
    title: "IoT energético: cómo diseñar una telemetría robusta",
    excerpt: "Protocolos, segmentación de redes y control de calidad de datos en ambientes industriales.",
    date: "05/01/2024",
    image: "https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7?auto=format&fit=crop&w=1200&q=80"
  }
];

const Blog: React.FC = () => (
  <>
    <Helmet>
      <title>Blog | RedInteligente España</title>
      <meta
        name="description"
        content="Noticias y análisis sobre smart grids, IoT energético, microrredes y automatización eléctrica en España."
      />
      <link rel="canonical" href="https://redinteligente.com/blog" />
      <meta property="og:title" content="Blog | RedInteligente España" />
      <meta property="og:description" content="Últimas novedades y análisis del ecosistema de redes inteligentes." />
      <meta property="og:image" content="https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=1600&q=80" />
    </Helmet>
    <section className="bg-white py-20">
      <div className="mx-auto w-full max-w-6xl px-4 lg:px-8">
        <h1 className="font-display text-4xl font-semibold text-primary">Blog RedInteligente</h1>
        <p className="mt-4 text-sm text-primary/70">
          Tendencias, pilotos y experiencias de campo en smart grids y microrredes.
        </p>
        <div className="mt-10 grid gap-8 md:grid-cols-3">
          {posts.map((post) => (
            <article key={post.title} className="rounded-3xl border border-primary/10 bg-light shadow-sm">
              <img src={post.image} alt={post.title} className="h-48 w-full rounded-t-3xl object-cover" />
              <div className="space-y-3 p-5">
                <span className="text-xs uppercase tracking-wide text-primary/50">{post.date}</span>
                <h2 className="text-lg font-semibold text-primary">{post.title}</h2>
                <p className="text-sm text-primary/70">{post.excerpt}</p>
                <button className="text-sm font-semibold text-accent underline" type="button">
                  Leer más
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Blog;