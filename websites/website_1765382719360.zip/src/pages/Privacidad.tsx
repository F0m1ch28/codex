import React from "react";
import { Helmet } from "react-helmet-async";

const Privacidad: React.FC = () => (
  <>
    <Helmet>
      <title>Política de Privacidad | RedInteligente España</title>
      <meta
        name="description"
        content="Política de privacidad de RedInteligente España sobre el tratamiento de datos personales."
      />
      <link rel="canonical" href="https://redinteligente.com/privacidad" />
      <meta property="og:title" content="Política de Privacidad | RedInteligente España" />
      <meta property="og:description" content="Información sobre protección de datos personales en RedInteligente España." />
      <meta property="og:image" content="https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1600&q=80" />
    </Helmet>
    <section className="bg-light py-20">
      <div className="mx-auto w-full max-w-4xl px-4 lg:px-8">
        <h1 className="font-display text-3xl font-semibold text-primary">Política de Privacidad</h1>
        <p className="mt-4 text-sm text-primary/70">
          Cumplimos con el Reglamento (UE) 2016/679 y la Ley Orgánica 3/2018 en materia de protección de datos.
        </p>
        <div className="mt-8 space-y-6 text-sm leading-relaxed text-primary/75">
          <section>
            <h2 className="text-lg font-semibold text-primary">Responsable del tratamiento</h2>
            <p>
              RedInteligente España, con domicilio en Paseo de la Castellana 141, 28046 Madrid. Contacto: info@redinteligente.com
            </p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-primary">Finalidad</h2>
            <p>
              Gestionar solicitudes de colaboración, difundir contenidos técnicos y enviar comunicaciones relacionadas con la actividad de smart grids.
            </p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-primary">Legitimación</h2>
            <p>
              Consentimiento expreso del usuario, cumplimiento de obligaciones legales y ejecución de relaciones contractuales.
            </p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-primary">Conservación</h2>
            <p>
              Los datos se conservan mientras exista relación con RedInteligente y se mantengan fines compatibles. Posteriormente se eliminarán de forma segura.
            </p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-primary">Derechos</h2>
            <p>
              Puedes ejercer derechos de acceso, rectificación, supresión, oposición, limitación y portabilidad escribiendo a info@redinteligente.com.
            </p>
          </section>
        </div>
      </div>
    </section>
  </>
);

export default Privacidad;