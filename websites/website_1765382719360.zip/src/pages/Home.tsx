import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import FlowMonitor from "../components/FlowMonitor";
import MicrogridMap from "../components/MicrogridMap";
import DemandSimulator from "../components/DemandSimulator";

const heroStats = [
  { label: "Medidores inteligentes conectados", value: "480K" },
  { label: "Microrredes activas", value: "128" },
  { label: "Sensores IoT monitorizados", value: "1.9M" }
];

const galleryItems = [
  {
    title: "Sensores de calidad de energía",
    description: "Analizadores instalados en subestaciones urbanas.",
    image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&w=1600&q=80"
  },
  {
    title: "Pasarelas IoT industriales",
    description: "Protocolos Modbus, MQTT y Edge AI en tiempo real.",
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1600&q=80"
  },
  {
    title: "Centro de control digital",
    description: "Operación coordinada de redes inteligentes.",
    image: "https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=1600&q=80"
  },
  {
    title: "Infraestructura de carga urbana",
    description: "Integración con microrredes y almacenamiento distribuido.",
    image: "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1600&q=80"
  },
  {
    title: "Sensórica ambiental",
    description: "Correlación de clima y demanda eléctrica.",
    image: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=1600&q=80"
  },
  {
    title: "Análisis de datos energéticos",
    description: "Exploración visual de patrones en red.",
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1600&q=80"
  }
];

const urbanCases = [
  {
    city: "Barcelona",
    focus: "Distrito 22@ como laboratorio vivo de microrredes y flexibilidad urbana.",
    metric: "Reducción media de picos: 17%",
    partners: ["Ajuntament de Barcelona", "Universitat Politècnica"],
    image: "https://images.unsplash.com/photo-1546539782-6fc531453083?auto=format&fit=crop&w=1200&q=80"
  },
  {
    city: "Madrid",
    focus: "Integración de edificios públicos en programas de respuesta a la demanda.",
    metric: "Consumo optimizado: -12% en horarios punta",
    partners: ["Comunidad de Madrid", "Operador DSO"],
    image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1200&q=80"
  },
  {
    city: "Valencia",
    focus: "Microrred portuaria con almacenamiento distribuido y predicción meteorológica.",
    metric: "Tiempo de isla máxima: 4 horas",
    partners: ["Autoridad Portuaria", "Startup BlueGrid"],
    image: "https://images.unsplash.com/photo-1496568816309-51d7c20e3b21?auto=format&fit=crop&w=1200&q=80"
  },
  {
    city: "Bilbao",
    focus: "Industria 4.0 con monitoreo IoT de procesos termoeléctricos.",
    metric: "Disponibilidad de red: 99.4%",
    partners: ["Cluster Energía País Vasco", "CIC energiGUNE"],
    image: "https://images.unsplash.com/photo-1529429617124-aee3275c7c9e?auto=format&fit=crop&w=1200&q=80"
  }
];

const Home: React.FC = () => {
  const [newsletterEmail, setNewsletterEmail] = React.useState("");
  const [newsletterSector, setNewsletterSector] = React.useState("Distribuidora");
  const [newsletterFeedback, setNewsletterFeedback] = React.useState<string | null>(null);

  const handleNewsletterSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    console.log("Newsletter:", { email: newsletterEmail, sector: newsletterSector });
    setNewsletterFeedback("Gracias por unirte a la red de conocimiento energético.");
    setNewsletterEmail("");
  };

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "RedInteligente España",
    "url": "https://redinteligente.com/",
    "publisher": {
      "@type": "Organization",
      "name": "RedInteligente España",
      "url": "https://redinteligente.com",
      "contactPoint": {
        "@type": "ContactPoint",
        "contactType": "Atención técnica",
        "telephone": "+34 917 89 34 56",
        "email": "info@redinteligente.com",
        "areaServed": "ES",
        "availableLanguage": ["es"]
      },
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Paseo de la Castellana 141",
        "addressLocality": "Madrid",
        "postalCode": "28046",
        "addressCountry": "ES"
      }
    },
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://redinteligente.com/buscar?q={search_term_string}",
      "query-input": "required name=search_term_string"
    }
  };

  const orgJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "RedInteligente España",
    "url": "https://redinteligente.com",
    "logo": "https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=512&q=80",
    "sameAs": ["https://www.linkedin.com"],
    "contactPoint": [
      {
        "@type": "ContactPoint",
        "telephone": "+34 917 89 34 56",
        "contactType": "Atención técnica",
        "availableLanguage": ["es"]
      }
    ],
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Paseo de la Castellana 141",
      "addressLocality": "Madrid",
      "postalCode": "28046",
      "addressCountry": "ES"
    }
  };

  return (
    <>
      <Helmet>
        <title>RedInteligente España | La Red Inteligente de Futuro</title>
        <meta
          name="description"
          content="Plataforma española de smart grids, IoT energético y microrredes. Visualiza flujos, proyectos piloto y recursos técnicos para redes inteligentes modernas."
        />
        <link rel="canonical" href="https://redinteligente.com/" />
        <meta property="og:title" content="RedInteligente España | La Red Inteligente de Futuro" />
        <meta
          property="og:description"
          content="Ecosistema digital para smart grids, microrredes y automatización eléctrica en España."
        />
        <meta property="og:url" content="https://redinteligente.com/" />
        <meta property="og:image" content="https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=1600&q=80" />
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
        <script type="application/ld+json">{JSON.stringify(orgJsonLd)}</script>
      </Helmet>

      <section className="relative overflow-hidden bg-node-grid">
        <div className="absolute inset-0 bg-gradient-to-br from-light via-light/70 to-accent/5" />
        <div className="relative mx-auto flex w-full max-w-7xl flex-col gap-12 px-4 pb-16 pt-20 lg:flex-row lg:items-center lg:gap-16 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="lg:w-1/2"
          >
            <span className="inline-flex items-center rounded-full border border-accent/60 bg-white/80 px-4 py-2 font-mono text-xs uppercase tracking-[0.3em] text-accent">
              La Red del Futuro
            </span>
            <h1 className="mt-6 font-display text-4xl font-semibold leading-tight text-primary sm:text-5xl">
              Inteligencia distribuida para una España con redes energéticas coordinadas
            </h1>
            <p className="mt-5 text-lg text-primary/70">
              RedInteligente España articula sensores, analítica y participación ciudadana para materializar microrredes robustas, resilientes y conectadas.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <a
                href="#monitor"
                className="rounded-full bg-primary px-6 py-3 text-sm font-semibold text-light shadow-lg shadow-primary/20 transition hover:bg-accent hover:text-primary"
              >
                Explorar monitor de flujo
              </a>
              <a
                href="#casos-urbanos"
                className="rounded-full border border-primary px-6 py-3 text-sm font-semibold text-primary transition hover:border-accent hover:text-accent"
              >
                Casos urbanos conectados
              </a>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:w-1/2"
          >
            <div className="rounded-3xl border border-primary/10 bg-white/70 p-8 shadow-card backdrop-blur">
              <h2 className="font-display text-xl font-semibold text-primary">Indicadores vivos de red</h2>
              <p className="mt-3 text-sm text-primary/70">
                Datos sintetizados de la plataforma en tiempo casi real.
              </p>
              <dl className="mt-6 grid gap-6 sm:grid-cols-3">
                {heroStats.map((stat) => (
                  <div key={stat.label}>
                    <dt className="text-xs uppercase tracking-wide text-primary/60">{stat.label}</dt>
                    <dd className="mt-2 font-display text-3xl font-semibold text-gradient">{stat.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </motion.div>
        </div>
      </section>

      <section id="monitor" className="bg-white py-16">
        <div className="mx-auto flex w-full max-w-7xl flex-col gap-8 px-4 lg:flex-row lg:items-center lg:gap-14 lg:px-8">
          <div className="lg:w-2/5">
            <h2 className="font-display text-3xl font-semibold text-primary">Monitor de flujo energético</h2>
            <p className="mt-4 text-sm leading-relaxed text-primary/70">
              Visualiza cómo se redistribuye la energía entre nodos estratégicos. Analizamos latencias, resiliencia y equilibrio de carga para garantizar la operación coordinada.
            </p>
            <ul className="mt-6 space-y-2 text-sm text-primary/80">
              <li>• Detección de congestiones en tiempo real</li>
              <li>• Algoritmos predictivos de flujo bidireccional</li>
              <li>• Sincronización con agregadores de recursos distribuidos</li>
            </ul>
          </div>
          <div className="lg:w-3/5">
            <FlowMonitor />
          </div>
        </div>
      </section>

      <section id="mapa" className="bg-light py-16">
        <div className="mx-auto w-full max-w-7xl px-4 lg:px-8">
          <div className="mb-10 max-w-3xl">
            <h2 className="font-display text-3xl font-semibold text-primary">Mapa de microrredes</h2>
            <p className="mt-4 text-sm text-primary/70">
              Operamos un mapa vivo de microrredes. Cada punto refleja la intensidad de los proyectos piloto y su foco de innovación.
            </p>
          </div>
          <MicrogridMap />
        </div>
      </section>

      <section id="galeria" className="bg-white py-16">
        <div className="mx-auto w-full max-w-7xl px-4 lg:px-8">
          <div className="mb-10 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-2xl">
              <h2 className="font-display text-3xl font-semibold text-primary">Galería IoT</h2>
              <p className="mt-4 text-sm text-primary/70">
                Dispositivos y sensores desplegados en la red para habilitar mediciones críticas y automatización distribuida.
              </p>
            </div>
          </div>
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {galleryItems.map((item) => (
              <motion.article
                key={item.title}
                whileHover={{ translateY: -8 }}
                className="group overflow-hidden rounded-2xl border border-primary/10 bg-white shadow-sm transition"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="space-y-2 p-4">
                  <h3 className="text-lg font-semibold text-primary">{item.title}</h3>
                  <p className="text-sm text-primary/70">{item.description}</p>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section id="simulador" className="bg-light py-16">
        <div className="mx-auto w-full max-w-7xl px-4 lg:px-8">
          <DemandSimulator />
        </div>
      </section>

      <section id="casos-urbanos" className="bg-white py-16">
        <div className="mx-auto w-full max-w-7xl px-4 lg:px-8">
          <div className="mb-10 max-w-3xl">
            <h2 className="font-display text-3xl font-semibold text-primary">Casos urbanos conectados</h2>
            <p className="mt-4 text-sm text-primary/70">
              Colaboramos con ciudades españolas para co-crear microrredes estratégicas, integrando almacenamiento, vehículos eléctricos y participación ciudadana.
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            {urbanCases.map((item) => (
              <motion.article
                key={item.city}
                whileHover={{ translateY: -6 }}
                className="overflow-hidden rounded-3xl border border-primary/10 bg-white shadow-card"
              >
                <img
                  src={item.image}
                  alt={`Proyecto urbano en ${item.city}`}
                  className="h-48 w-full object-cover"
                />
                <div className="space-y-3 p-6">
                  <h3 className="text-xl font-semibold text-primary">{item.city}</h3>
                  <p className="text-sm text-primary/70">{item.focus}</p>
                  <p className="text-sm font-medium text-verdant">{item.metric}</p>
                  <p className="text-xs uppercase tracking-wide text-primary/50">
                    Alianzas: {item.partners.join(", ")}
                  </p>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section id="newsletter" className="bg-primary py-16">
        <div className="mx-auto w-full max-w-4xl px-4 text-light lg:px-8">
          <div className="rounded-3xl bg-glass p-8">
            <h2 className="font-display text-3xl font-semibold text-light">Newsletter técnica</h2>
            <p className="mt-3 text-sm text-light/70">
              Recibe indicadores, hojas técnicas y alertas de los proyectos piloto de RedInteligente.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="mt-6 grid gap-4 md:grid-cols-[2fr,1fr,auto]">
              <label className="flex flex-col text-sm text-light/80">
                Email profesional
                <input
                  required
                  type="email"
                  value={newsletterEmail}
                  onChange={(event) => setNewsletterEmail(event.target.value)}
                  placeholder="nombre@organizacion.es"
                  className="mt-2 rounded-xl border border-white/30 bg-white/20 px-4 py-3 text-light placeholder:text-light/60"
                />
              </label>
              <label className="flex flex-col text-sm text-light/80">
                Sector
                <select
                  value={newsletterSector}
                  onChange={(event) => setNewsletterSector(event.target.value)}
                  className="mt-2 rounded-xl border border-white/30 bg-white/20 px-4 py-3 text-light"
                >
                  <option value="Distribuidora">Distribuidora</option>
                  <option value="Municipio">Municipio</option>
                  <option value="Startup">Startup</option>
                  <option value="Universidad">Universidad</option>
                  <option value="Industrial">Industrial</option>
                </select>
              </label>
              <button
                type="submit"
                className="mt-6 rounded-xl bg-accent px-6 py-3 font-semibold text-primary transition hover:bg-light hover:text-primary md:mt-auto"
              >
                Unirme
              </button>
            </form>
            {newsletterFeedback && (
              <p className="mt-4 text-xs text-verdant">
                {newsletterFeedback}
              </p>
            )}
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;