import React from "react";
import { Helmet } from "react-helmet-async";

const Colabora: React.FC = () => {
  const [formState, setFormState] = React.useState({ nombre: "", email: "", mensaje: "" });
  const [feedback, setFeedback] = React.useState<string | null>(null);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    console.log("Solicitud de colaboración", formState);
    setFeedback("Gracias por escribirnos. Nos pondremos en contacto pronto.");
    setFormState({ nombre: "", email: "", mensaje: "" });
  };

  return (
    <>
      <Helmet>
        <title>Colabora | RedInteligente España</title>
        <meta
          name="description"
          content="Conecta con RedInteligente España para proyectos de smart grid, IoT energético y microrredes colaborativas."
        />
        <link rel="canonical" href="https://redinteligente.com/colabora" />
        <meta property="og:title" content="Colabora | RedInteligente España" />
        <meta property="og:description" content="Propuestas de colaboración en innovación energética y redes inteligentes." />
        <meta property="og:image" content="https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1600&q=80" />
      </Helmet>
      <section className="bg-node-grid py-20">
        <div className="mx-auto w-full max-w-5xl px-4 text-center lg:px-8">
          <h1 className="font-display text-4xl font-semibold text-primary">Colabora con nuestro hub</h1>
          <p className="mt-4 text-base text-primary/70">
            Buscamos alianzas con empresas, administraciones y centros de investigación que quieran avanzar en smart grids y microrredes.
          </p>
        </div>
      </section>
      <section className="bg-white py-16">
        <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 lg:grid-cols-2 lg:px-8">
          <form onSubmit={handleSubmit} className="space-y-5 rounded-3xl border border-primary/10 bg-light p-6 shadow-sm">
            <h2 className="text-2xl font-semibold text-primary">Escríbenos</h2>
            <label className="block text-sm font-medium text-primary/70">
              Nombre
              <input
                type="text"
                required
                value={formState.nombre}
                onChange={(event) => setFormState((prev) => ({ ...prev, nombre: event.target.value }))}
                className="mt-2 w-full rounded-xl border border-primary/10 bg-white px-4 py-3 text-primary"
                placeholder="Nombre completo"
              />
            </label>
            <label className="block text-sm font-medium text-primary/70">
              Email
              <input
                type="email"
                required
                value={formState.email}
                onChange={(event) => setFormState((prev) => ({ ...prev, email: event.target.value }))}
                className="mt-2 w-full rounded-xl border border-primary/10 bg-white px-4 py-3 text-primary"
                placeholder="correo@organizacion.es"
              />
            </label>
            <label className="block text-sm font-medium text-primary/70">
              Mensaje
              <textarea
                required
                value={formState.mensaje}
                onChange={(event) => setFormState((prev) => ({ ...prev, mensaje: event.target.value }))}
                rows={6}
                className="mt-2 w-full rounded-xl border border-primary/10 bg-white px-4 py-3 text-primary"
                placeholder="Cuéntanos tu iniciativa o propuesta."
              />
            </label>
            <button
              type="submit"
              className="w-full rounded-full bg-primary px-5 py-3 text-sm font-semibold text-light transition hover:bg-accent hover:text-primary"
            >
              Enviar propuesta
            </button>
            {feedback && <p className="text-sm text-verdant">{feedback}</p>}
          </form>
          <div className="space-y-6">
            <div className="rounded-3xl border border-primary/10 bg-white p-6 shadow-card">
              <h3 className="text-xl font-semibold text-primary">Oficina Madrid</h3>
              <p className="mt-2 text-sm text-primary/70">Paseo de la Castellana 141, 28046 Madrid</p>
              <p className="mt-2 text-sm text-primary/70">Teléfono: +34 917 89 34 56</p>
              <p className="mt-2 text-sm text-primary/70">Email: info@redinteligente.com</p>
              <iframe
                title="Ubicación RedInteligente España"
                className="mt-4 h-64 w-full rounded-2xl border border-primary/10"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.28467602002!2d-3.685196623423909!3d40.46293995325716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd422f67ce4f0f6b%3A0xf640f34cc0000!2sP.%20de%20la%20Castellana%2C%20141%2C%20Chamart%C3%ADn%2C%2028046%20Madrid!5e0!3m2!1ses!2ses!4v1707040000000"
                loading="lazy"
              />
            </div>
            <div className="rounded-3xl border border-primary/10 bg-light p-6">
              <h3 className="font-semibold text-primary">Áreas de colaboración</h3>
              <ul className="mt-3 space-y-2 text-sm text-primary/70">
                <li>• Pilotos de microrredes urbanas o industriales.</li>
                <li>• Analítica avanzada aplicada a redes inteligentes.</li>
                <li>• Programas de flexibilidad y participación ciudadana.</li>
                <li>• Formación y transferencia tecnológica con universidades.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Colabora;