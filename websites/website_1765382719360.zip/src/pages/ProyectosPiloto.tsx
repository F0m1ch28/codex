import React from "react";
import { Helmet } from "react-helmet-async";

const pilots = [
  {
    name: "Microrred resiliente Madrid Norte",
    description: "Integración de edificios de oficinas, movilidad eléctrica y almacenamiento híbrido para suavizar picos de demanda.",
    highlights: ["Control predictivo de 5 subestaciones", "Coordina 280 cargadores bidireccionales", "Balance neto con generación fotovoltaica"]
  },
  {
    name: "Isla energética en Barrios de Barcelona",
    description: "Proyecto comunitario con participación ciudadana y plataforma blockchain privada para trazabilidad energética.",
    highlights: ["Sensores de calidad de aire asociados a demanda", "Participación de 3 cooperativas energéticas", "Respuesta en 5 minutos a alertas de congestión"]
  },
  {
    name: "Cadena logística valenciana",
    description: "Microrred portuaria con previsión meteorológica y coordinación de almacenamientos distribuidos para suministro crítico.",
    highlights: ["Reducción del 15% en consumo intensivo", "Gemelo digital para simulación de atraques", "Integración con hidrógeno verde en pruebas"]
  }
];

const ProyectosPiloto: React.FC = () => (
  <>
    <Helmet>
      <title>Proyectos Piloto | RedInteligente España</title>
      <meta
        name="description"
        content="Casos piloto de smart grid en Madrid, Barcelona y Valencia que demuestran la eficacia de microrredes y respuesta a la demanda."
      />
      <link rel="canonical" href="https://redinteligente.com/proyectos-piloto" />
      <meta property="og:title" content="Proyectos Piloto | RedInteligente España" />
      <meta property="og:description" content="Microrredes resilientes, movilidad eléctrica y agregación de demanda en ciudades españolas." />
      <meta property="og:image" content="https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1600&q=80" />
    </Helmet>
    <section className="bg-white py-20">
      <div className="mx-auto w-full max-w-6xl px-4 lg:px-8">
        <h1 className="font-display text-4xl font-semibold text-primary">Proyectos piloto en marcha</h1>
        <p className="mt-4 max-w-3xl text-sm text-primary/70">
          Cada piloto se diseña con datos abiertos, métricas verificables y supervisión de agentes independientes. Compartimos aprendizajes para acelerar la adopción de smart grids en todo el territorio.
        </p>
        <div className="mt-12 space-y-10">
          {pilots.map((pilot) => (
            <article key={pilot.name} className="rounded-3xl border border-primary/10 bg-light p-6 shadow-sm">
              <h2 className="text-2xl font-semibold text-primary">{pilot.name}</h2>
              <p className="mt-3 text-sm text-primary/70">{pilot.description}</p>
              <ul className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {pilot.highlights.map((highlight) => (
                  <li key={highlight} className="rounded-2xl border border-primary/10 bg-white px-4 py-3 text-xs font-medium uppercase tracking-wide text-primary/70">
                    {highlight}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default ProyectosPiloto;