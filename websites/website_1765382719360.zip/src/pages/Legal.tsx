import React from "react";
import { Helmet } from "react-helmet-async";

const Legal: React.FC = () => (
  <>
    <Helmet>
      <title>Términos de Uso | RedInteligente España</title>
      <meta
        name="description"
        content="Términos y condiciones de uso de la plataforma digital RedInteligente España."
      />
      <link rel="canonical" href="https://redinteligente.com/legal" />
      <meta property="og:title" content="Términos de Uso | RedInteligente España" />
      <meta property="og:description" content="Condiciones generales para utilizar los servicios digitales de RedInteligente España." />
      <meta property="og:image" content="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1600&q=80" />
    </Helmet>
    <section className="bg-white py-20">
      <div className="mx-auto w-full max-w-4xl px-4 lg:px-8">
        <h1 className="font-display text-3xl font-semibold text-primary">Términos de Uso</h1>
        <p className="mt-4 text-sm text-primary/70">
          El presente documento regula el acceso y utilización del dominio redinteligente.com y sus servicios digitales asociados.
        </p>
        <div className="mt-8 space-y-6 text-sm leading-relaxed text-primary/75">
          <section>
            <h2 className="text-lg font-semibold text-primary">1. Titularidad</h2>
            <p>
              RedInteligente España opera la plataforma desde Paseo de la Castellana 141, 28046 Madrid. Para consultas, contáctanos en info@redinteligente.com o al +34 917 89 34 56.
            </p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-primary">2. Condiciones de uso</h2>
            <p>
              El usuario se compromete a utilizar la información de forma lícita, respetando la propiedad intelectual y evitando usos que comprometan la seguridad de la red o la privacidad de terceros.
            </p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-primary">3. Propiedad intelectual</h2>
            <p>
              Los contenidos técnicos, visuales y marcas de RedInteligente España están protegidos por la normativa española y comunitaria.
            </p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-primary">4. Responsabilidad</h2>
            <p>
              RedInteligente España mantiene la plataforma con estándares de calidad y seguridad, sin garantizar disponibilidad absoluta. El uso de la información es responsabilidad del usuario.
            </p>
          </section>
        </div>
      </div>
    </section>
  </>
);

export default Legal;