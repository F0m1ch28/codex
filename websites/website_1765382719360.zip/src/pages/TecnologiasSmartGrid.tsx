import React from "react";
import { Helmet } from "react-helmet-async";

const technologies = [
  {
    title: "Plataforma de orquestación de datos",
    description: "Ingesta de telemetría en milisegundos desde medidores inteligentes, SCADA y sensores ambientales, con procesamiento edge-to-cloud."
  },
  {
    title: "Gemelos digitales de microrredes",
    description: "Modelado de activos y cargas, simulación de contingencias, evaluación de resiliencia y estrategias de restauración automática."
  },
  {
    title: "Respuesta a la demanda",
    description: "Algoritmos de agregación de cargas flexibles, incentivos dinámicos y coordinación con operadores del sistema para reducir picos."
  },
  {
    title: "Seguridad y fiabilidad",
    description: "Ciberseguridad IoT con autenticación de dispositivos, detección de anomalías y microsegmentación de comunicaciones."
  }
];

const TecnologiasSmartGrid: React.FC = () => (
  <>
    <Helmet>
      <title>Tecnologías Smart Grid | RedInteligente España</title>
      <meta
        name="description"
        content="Descubre las tecnologías de smart grid, IoT energético y automatización eléctrica desplegadas por RedInteligente España."
      />
      <link rel="canonical" href="https://redinteligente.com/tecnologias-smart-grid" />
      <meta property="og:title" content="Tecnologías Smart Grid | RedInteligente España" />
      <meta property="og:description" content="Soluciones IoT, gemelos digitales y respuesta a la demanda para redes inteligentes." />
      <meta property="og:image" content="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1600&q=80" />
    </Helmet>
    <section className="bg-primary/95 py-20 text-light">
      <div className="mx-auto w-full max-w-5xl px-4 text-center lg:px-8">
        <h1 className="font-display text-4xl font-semibold">Tecnologías Smart Grid</h1>
        <p className="mt-4 text-base text-light/70">
          Arquitectura modular, estándar y segura para operar redes inteligentes con visión integral de los activos distribuidos.
        </p>
      </div>
    </section>
    <section className="bg-white py-16">
      <div className="mx-auto w-full max-w-6xl px-4 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-2">
          {technologies.map((item) => (
            <article key={item.title} className="rounded-3xl border border-primary/10 bg-light p-6 shadow-sm">
              <h2 className="font-display text-xl font-semibold text-primary">{item.title}</h2>
              <p className="mt-3 text-sm text-primary/70">{item.description}</p>
            </article>
          ))}
        </div>
        <div className="mt-12 grid gap-8 lg:grid-cols-2">
          <div className="rounded-3xl border border-primary/10 bg-white p-6 shadow-card">
            <h3 className="font-display text-lg font-semibold text-primary">Arquitectura de referencia</h3>
            <p className="mt-3 text-sm text-primary/70">
              La plataforma utiliza un backbone de eventos, microservicios y APIs REST/GraphQL. Las pasarelas edge normalizan protocolos (IEC 104, Modbus, MQTT) y los envían al lago de datos para analítica en streaming.
            </p>
            <pre className="mt-5 overflow-x-auto rounded-xl bg-primary/90 p-4 font-mono text-xs text-light">
{`edgeGateway
  .connect("mqtt://broker.redinteligente.com")
  .collect(smartMeters)
  .stream((payload) => {
    const harmonics = analytics.extractHarmonics(payload);
    bus.publish("grid.events.harmonics", harmonics);
  });`}
            </pre>
          </div>
          <div className="rounded-3xl border border-primary/10 bg-white p-6 shadow-card">
            <h3 className="font-display text-lg font-semibold text-primary">Interoperabilidad y estándares</h3>
            <ul className="mt-4 space-y-3 text-sm text-primary/70">
              <li>• Arquitecturas basadas en CIM, OpenADR, IEC 61850.</li>
              <li>• API pública para integradores certificados.</li>
              <li>• Modelos de datos semánticos para compartición entre actores.</li>
              <li>• Paneles de observabilidad con métricas de latencia, disponibilidad y ciberseguridad.</li>
            </ul>
            <img
              src="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1600&q=80"
              alt="Centro de control con tecnologías inteligentes"
              className="mt-6 h-52 w-full rounded-2xl object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  </>
);

export default TecnologiasSmartGrid;