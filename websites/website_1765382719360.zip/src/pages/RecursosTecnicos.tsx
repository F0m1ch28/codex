import React from "react";
import { Helmet } from "react-helmet-async";

const resources = [
  {
    title: "Guía de despliegue de medidores inteligentes",
    type: "Manual técnico",
    link: "https://example.com/manual-medidores.pdf",
    description: "Buenas prácticas de instalación, ciberseguridad y mantenimiento de medidores de última generación."
  },
  {
    title: "Plantilla de datos para analítica energética",
    type: "Dataset",
    link: "https://example.com/dataset-energias.csv",
    description: "Modelo de datos de RedInteligente para correlacionar demanda, clima y movilidad."
  },
  {
    title: "Cuaderno Jupyter de respuesta a la demanda",
    type: "Notebook",
    link: "https://example.com/notebook-respuesta.ipynb",
    description: "Ejemplo de clustering de cargas y predicción de flexibilidad en microrredes."
  },
  {
    title: "Checklist de microrred segura",
    type: "Checklist",
    link: "https://example.com/checklist-microrred.pdf",
    description: "Elementos técnicos y organizativos para garantizar continuidad de servicio y ciberseguridad."
  }
];

const RecursosTecnicos: React.FC = () => (
  <>
    <Helmet>
      <title>Recursos Técnicos | RedInteligente España</title>
      <meta
        name="description"
        content="Descarga guías, datasets y notebooks para desplegar smart grids, IoT energético y microrredes seguras."
      />
      <link rel="canonical" href="https://redinteligente.com/recursos-tecnicos" />
      <meta property="og:title" content="Recursos Técnicos | RedInteligente España" />
      <meta property="og:description" content="Manuales, datasets y herramientas para profesionales de redes inteligentes." />
      <meta property="og:image" content="https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1600&q=80" />
    </Helmet>
    <section className="bg-light py-20">
      <div className="mx-auto w-full max-w-5xl px-4 lg:px-8">
        <h1 className="font-display text-3xl font-semibold text-primary">Recursos técnicos</h1>
        <p className="mt-4 text-sm text-primary/70">
          Documentación abierta para acelerar proyectos de smart grid, automatización eléctrica y microrredes.
        </p>
        <div className="mt-10 space-y-6">
          {resources.map((resource) => (
            <article key={resource.title} className="rounded-3xl border border-primary/10 bg-white p-6 shadow-sm">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-primary">{resource.title}</h2>
                  <p className="mt-2 text-sm text-primary/60">{resource.description}</p>
                </div>
                <a
                  href={resource.link}
                  className="inline-flex items-center rounded-full border border-primary px-5 py-2 text-sm font-semibold text-primary transition hover:border-accent hover:text-accent"
                >
                  {resource.type}
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default RecursosTecnicos;