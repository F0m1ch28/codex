import React from "react";
import * as d3 from "d3";

type NodeDatum = {
  x: number;
  y: number;
  label: string;
};

const FlowMonitor: React.FC = () => {
  const svgRef = React.useRef<SVGSVGElement | null>(null);

  React.useEffect(() => {
    const svgElement = svgRef.current;
    if (!svgElement) return;

    const width = 680;
    const height = 220;

    const svg = d3
      .select(svgElement)
      .attr("viewBox", `0 0 ${width} ${height}`)
      .attr("role", "img")
      .attr("aria-labelledby", "flowMonitorTitle flowMonitorDesc");

    svg.selectAll("*").remove();

    svg.append("title").attr("id", "flowMonitorTitle").text("Monitor de flujo energético en tiempo real");
    svg.append("desc").attr("id", "flowMonitorDesc").text("Visualización simplificada del flujo eléctrico entre nodos inteligentes.");

    svg
      .append("rect")
      .attr("x", 0)
      .attr("y", 0)
      .attr("width", width)
      .attr("height", height)
      .attr("fill", "url(#grid-background)");

    const defs = svg.append("defs");

    const gradient = defs.append("linearGradient").attr("id", "flowGradient").attr("gradientUnits", "userSpaceOnUse").attr("x1", 0).attr("x2", width);
    gradient.append("stop").attr("offset", "0%").attr("stop-color", "#00D9FF");
    gradient.append("stop").attr("offset", "50%").attr("stop-color", "#10B981");
    gradient.append("stop").attr("offset", "100%").attr("stop-color", "#00D9FF");

    const bgPattern = defs.append("pattern").attr("id", "grid-background").attr("width", 30).attr("height", 30).attr("patternUnits", "userSpaceOnUse");
    bgPattern.append("rect").attr("width", 30).attr("height", 30).attr("fill", "#0C1E3B08");
    bgPattern.append("circle").attr("cx", 1.5).attr("cy", 1.5).attr("r", 1.2).attr("fill", "#00D9FF20");

    const nodes: NodeDatum[] = [
      { x: 70, y: 120, label: "Subestación Norte" },
      { x: 200, y: 70, label: "Nodo Solar" },
      { x: 320, y: 140, label: "Centro de Control" },
      { x: 460, y: 80, label: "Nodo Eólico" },
      { x: 580, y: 120, label: "Microrred Urbana" }
    ];

    const lineGenerator = d3
      .line<NodeDatum>()
      .x((d) => d.x)
      .y((d) => d.y)
      .curve(d3.curveCatmullRom.alpha(0.8));

    const path = svg
      .append("path")
      .datum(nodes)
      .attr("d", lineGenerator)
      .attr("fill", "none")
      .attr("stroke", "url(#flowGradient)")
      .attr("stroke-width", 6)
      .attr("stroke-linecap", "round")
      .attr("stroke-dasharray", "6 10")
      .attr("opacity", 0.9);

    const totalLength = (path.node() as SVGPathElement).getTotalLength();

    const animateFlow = () => {
      path
        .attr("stroke-dasharray", `${totalLength} ${totalLength}`)
        .attr("stroke-dashoffset", totalLength)
        .transition()
        .duration(3600)
        .ease(d3.easeCubicInOut)
        .attr("stroke-dashoffset", 0)
        .on("end", animateFlow);
    };

    animateFlow();

    const circles = svg
      .selectAll<SVGCircleElement, NodeDatum>("circle")
      .data(nodes)
      .enter()
      .append("circle")
      .attr("cx", (d) => d.x)
      .attr("cy", (d) => d.y)
      .attr("r", 8)
      .attr("fill", "#10B981")
      .attr("stroke", "#FFFFFF")
      .attr("stroke-width", 2);

    const pulse = () => {
      circles
        .transition()
        .duration(1100)
        .attr("r", 12)
        .attr("fill", "#00D9FF")
        .transition()
        .duration(1100)
        .attr("r", 8)
        .attr("fill", "#10B981")
        .on("end", pulse);
    };
    pulse();

    svg
      .selectAll<SVGTextElement, NodeDatum>("text")
      .data(nodes)
      .enter()
      .append("text")
      .attr("x", (d) => d.x)
      .attr("y", (d) => d.y - 18)
      .attr("text-anchor", "middle")
      .attr("fill", "#0C1E3B")
      .attr("font-size", 12)
      .attr("font-family", "Outfit, sans-serif")
      .text((d) => d.label);

    return () => {
      path.interrupt();
      circles.interrupt();
    };
  }, []);

  return <svg ref={svgRef} className="w-full" />;
};

export default FlowMonitor;