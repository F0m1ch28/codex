import React from "react";
import { Link } from "react-router-dom";

const Footer: React.FC = () => {
  return (
    <footer className="border-t border-slate-200 bg-primary text-light">
      <div className="mx-auto grid w-full max-w-7xl gap-10 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4 lg:px-8">
        <div>
          <h3 className="font-display text-lg font-semibold uppercase tracking-[0.4em] text-accent">
            RedInteligente
          </h3>
          <p className="mt-4 text-sm leading-relaxed text-light/80">
            Plataforma digital energética con foco en smart grids, microrredes y automatización inteligente para acelerar la transición energética en España.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-semibold uppercase tracking-wider text-accent">Navegación</h4>
          <ul className="mt-4 space-y-2 text-sm text-light/80">
            <li><Link to="/" className="transition-colors hover:text-accent">Inicio</Link></li>
            <li><Link to="/quienes-somos" className="transition-colors hover:text-accent">Quiénes Somos</Link></li>
            <li><Link to="/tecnologias-smart-grid" className="transition-colors hover:text-accent">Tecnologías Smart Grid</Link></li>
            <li><Link to="/proyectos-piloto" className="transition-colors hover:text-accent">Proyectos Piloto</Link></li>
            <li><Link to="/recursos-tecnicos" className="transition-colors hover:text-accent">Recursos Técnicos</Link></li>
            <li><Link to="/blog" className="transition-colors hover:text-accent">Blog</Link></li>
            <li><Link to="/colabora" className="transition-colors hover:text-accent">Colabora</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold uppercase tracking-wider text-accent">Contacto</h4>
          <address className="mt-4 space-y-2 text-sm not-italic text-light/80">
            <p>Paseo de la Castellana 141, 28046 Madrid</p>
            <p>Teléfono: <a className="hover:text-accent" href="tel:+34917893456">+34 917 89 34 56</a></p>
            <p>Email: <a className="hover:text-accent" href="mailto:info@redinteligente.com">info@redinteligente.com</a></p>
          </address>
        </div>
        <div>
          <h4 className="text-sm font-semibold uppercase tracking-wider text-accent">Legal</h4>
          <ul className="mt-4 space-y-2 text-sm text-light/80">
            <li><Link to="/legal" className="transition-colors hover:text-accent">Términos de Uso</Link></li>
            <li><Link to="/privacidad" className="transition-colors hover:text-accent">Política de Privacidad</Link></li>
            <li><Link to="/politica-de-cookies" className="transition-colors hover:text-accent">Política de Cookies</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-slate-700/60 bg-primary/90">
        <div className="mx-auto flex w-full max-w-7xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs text-light/60 sm:flex-row lg:px-8">
          <span>© {new Date().getFullYear()} RedInteligente España. Todos los derechos reservados.</span>
          <span className="font-mono">Dominio: redinteligente.com</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;