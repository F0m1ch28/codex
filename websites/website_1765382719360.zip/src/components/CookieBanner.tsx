import React from "react";
import { Link } from "react-router-dom";

const CookieBanner: React.FC = () => {
  const [visible, setVisible] = React.useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    return window.localStorage.getItem("ri-cookie-consent") !== "accepted";
  });

  const acceptCookies = () => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem("ri-cookie-consent", "accepted");
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <aside
      role="dialog"
      aria-live="polite"
      className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-3xl rounded-2xl border border-primary/10 bg-light p-5 shadow-xl md:flex md:items-center md:justify-between"
    >
      <div className="md:max-w-lg">
        <h2 className="text-base font-semibold text-primary">Configuración de cookies</h2>
        <p className="mt-2 text-sm text-primary/80">
          Utilizamos cookies propias para mejorar la experiencia y monitorizar el rendimiento de la red inteligente. Puedes ampliar la información en nuestra{" "}
          <Link to="/politica-de-cookies" className="font-medium text-accent underline">
            Política de Cookies
          </Link>.
        </p>
      </div>
      <button
        type="button"
        onClick={acceptCookies}
        className="mt-4 w-full rounded-full bg-primary px-5 py-2 text-sm font-semibold text-light transition hover:bg-accent hover:text-primary md:ml-6 md:mt-0 md:w-auto"
      >
        Aceptar
      </button>
    </aside>
  );
};

export default CookieBanner;