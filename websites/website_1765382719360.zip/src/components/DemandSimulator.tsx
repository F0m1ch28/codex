import React from "react";
import * as d3 from "d3";

const DemandSimulator: React.FC = () => {
  const svgRef = React.useRef<SVGSVGElement | null>(null);
  const [participation, setParticipation] = React.useState<number>(60);

  React.useEffect(() => {
    const svgElement = svgRef.current;
    if (!svgElement) return;

    const width = 680;
    const height = 260;
    const margin = { top: 30, right: 24, bottom: 36, left: 48 };

    const svg = d3.select(svgElement).attr("viewBox", `0 0 ${width} ${height}`).attr("role", "img").attr("aria-label", "Simulación de demanda energética");

    svg.selectAll("*").remove();

    const hours = d3.range(0, 24);
    const baseCurve = hours.map((hour) => {
      const base = 45 + 25 * Math.sin((hour / 24) * Math.PI * 2 - Math.PI / 2);
      const modulation = (participation - 60) * 0.4;
      return base - modulation * Math.cos((hour / 24) * Math.PI * 4);
    });

    const xScale = d3.scaleLinear().domain([0, 23]).range([margin.left, width - margin.right]);
    const yScale = d3.scaleLinear().domain([0, 110]).range([height - margin.bottom, margin.top]);

    const area = d3
      .area<number>()
      .x((_, index) => xScale(index))
      .y0(yScale(20))
      .y1((d) => yScale(d))
      .curve(d3.curveCatmullRom.alpha(0.5));

    svg
      .append("path")
      .datum(baseCurve)
      .attr("fill", "#00D9FF30")
      .attr("stroke", "#00D9FF")
      .attr("stroke-width", 3)
      .attr("d", area);

    const axisX = d3.axisBottom(xScale).ticks(6).tickFormat((d) => `${d}h`);
    const axisY = d3.axisLeft(yScale).ticks(5).tickFormat((d) => `${d} MW`);

    svg
      .append("g")
      .attr("transform", `translate(0, ${height - margin.bottom})`)
      .attr("color", "#0C1E3B")
      .call(axisX);

    svg
      .append("g")
      .attr("transform", `translate(${margin.left}, 0)`)
      .attr("color", "#0C1E3B")
      .call(axisY);

    svg
      .append("text")
      .attr("x", margin.left)
      .attr("y", margin.top - 12)
      .attr("fill", "#0C1E3B")
      .attr("font-size", 14)
      .attr("font-family", "Outfit, sans-serif")
      .text("Respuesta a la demanda (MW)");

    svg
      .append("line")
      .attr("x1", margin.left)
      .attr("x2", width - margin.right)
      .attr("y1", yScale(60))
      .attr("y2", yScale(60))
      .attr("stroke", "#10B981")
      .attr("stroke-dasharray", "4 4")
      .attr("stroke-width", 1.5);

    return () => {
      svg.selectAll("*").interrupt();
    };
  }, [participation]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="text-lg font-semibold text-primary">Simulador de demanda flexible</h3>
          <p className="text-sm text-primary/70">
            Ajusta el nivel de participación ciudadana en programas de respuesta a la demanda y observa el efecto proyectado.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <label htmlFor="participation-slider" className="text-sm font-medium text-primary">
            Participación:
          </label>
          <input
            id="participation-slider"
            type="range"
            min={40}
            max={90}
            value={participation}
            onChange={(event) => setParticipation(Number(event.target.value))}
            className="h-2 w-48 rounded-lg bg-primary/20 accent-accent"
          />
          <span className="font-mono text-sm text-primary">{participation}%</span>
        </div>
      </div>
      <svg ref={svgRef} className="w-full rounded-xl border border-primary/10 bg-white/70 shadow-sm backdrop-blur" />
      <p className="text-xs text-primary/60">
        El modelo utiliza una curva generada con datos sintéticos para ilustrar el potencial de flexibilización mediante microrredes activas y agregadores locales.
      </p>
    </div>
  );
};

export default DemandSimulator;