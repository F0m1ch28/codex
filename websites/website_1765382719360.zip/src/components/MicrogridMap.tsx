import React from "react";
import * as d3 from "d3";

type City = {
  name: string;
  coords: [number, number];
  focus: string;
  intensity: number;
};

const cities: City[] = [
  { name: "Madrid", coords: [-3.7038, 40.4168], focus: "Gemelo digital de red y respuesta a la demanda", intensity: 0.92 },
  { name: "Barcelona", coords: [2.1734, 41.3851], focus: "Microrred urbana conectada a movilidad eléctrica", intensity: 0.87 },
  { name: "Valencia", coords: [-0.3763, 39.4699], focus: "Monitorización IoT para puertos energéticamente eficientes", intensity: 0.81 },
  { name: "Sevilla", coords: [-5.9845, 37.3891], focus: "Flexibilidad térmica en edificios públicos", intensity: 0.76 },
  { name: "Bilbao", coords: [-2.9349, 43.2630], focus: "Almacenamiento distribuido y control predictivo", intensity: 0.84 }
];

const outlineCoordinates: [number, number][] = [
  [-9.5, 43.3],
  [-8.7, 42.2],
  [-7.0, 43.0],
  [-5.0, 43.5],
  [-3.0, 43.8],
  [-1.0, 43.4],
  [1.0, 43.2],
  [3.0, 42.5],
  [3.2, 41.0],
  [1.5, 40.0],
  [0.5, 39.0],
  [-1.0, 38.3],
  [-2.5, 37.2],
  [-4.5, 36.8],
  [-6.5, 36.6],
  [-8.5, 37.5],
  [-9.3, 39.0],
  [-9.5, 40.5],
  [-9.5, 43.3]
];

const MicrogridMap: React.FC = () => {
  const svgRef = React.useRef<SVGSVGElement | null>(null);
  const [activeCity, setActiveCity] = React.useState<City | null>(cities[0]);

  React.useEffect(() => {
    const svgElement = svgRef.current;
    if (!svgElement) return;

    const width = 700;
    const height = 420;

    const svg = d3
      .select(svgElement)
      .attr("viewBox", `0 0 ${width} ${height}`)
      .attr("role", "img")
      .attr("aria-labelledby", "microgridMapTitle microgridMapDesc");

    svg.selectAll("*").remove();

    svg.append("title").attr("id", "microgridMapTitle").text("Mapa de microrredes activas en España");
    svg.append("desc").attr("id", "microgridMapDesc").text("Ubicación de proyectos piloto de RedInteligente España.");

    svg
      .append("rect")
      .attr("width", width)
      .attr("height", height)
      .attr("fill", "#0C1E3B0D");

    const projection = d3.geoMercator().center([-3.3, 40.0]).scale(1500).translate([width / 2, height / 1.8]);
    const geoPath = d3.geoPath().projection(projection);

    const polygonFeature: GeoJSON.Feature<GeoJSON.Polygon> = {
      type: "Feature",
      geometry: {
        type: "Polygon",
        coordinates: [outlineCoordinates]
      },
      properties: {}
    };

    svg
      .append("path")
      .datum(polygonFeature)
      .attr("d", geoPath as any)
      .attr("fill", "#0C1E3B")
      .attr("stroke", "#00D9FF")
      .attr("stroke-width", 1.2)
      .attr("opacity", 0.1);

    const radiusScale = d3.scaleLinear().domain([0.7, 1]).range([10, 20]);

    const cityGroup = svg.append("g");

    cityGroup
      .selectAll("circle")
      .data(cities)
      .enter()
      .append("circle")
      .attr("cx", (d) => {
        const [x] = projection(d.coords) ?? [0, 0];
        return x;
      })
      .attr("cy", (d) => {
        const [, y] = projection(d.coords) ?? [0, 0];
        return y;
      })
      .attr("r", (d) => radiusScale(d.intensity))
      .attr("fill", "#00D9FF")
      .attr("fill-opacity", 0.75)
      .attr("stroke", "#0C1E3B")
      .attr("stroke-width", 1.2)
      .on("mouseenter", (_, d) => setActiveCity(d))
      .on("focus", (_, d) => setActiveCity(d))
      .append("title")
      .text((d) => `${d.name}: ${d.focus}`);

    cityGroup
      .selectAll("text")
      .data(cities)
      .enter()
      .append("text")
      .attr("x", (d) => {
        const [x] = projection(d.coords) ?? [0, 0];
        return x + 14;
      })
      .attr("y", (d) => {
        const [, y] = projection(d.coords) ?? [0, 0];
        return y + 4;
      })
      .attr("fill", "#0C1E3B")
      .attr("font-size", 12)
      .attr("font-family", "Outfit, sans-serif")
      .text((d) => d.name);

    return () => {
      svg.selectAll("*").interrupt();
    };
  }, []);

  return (
    <div className="space-y-4">
      <svg ref={svgRef} className="w-full" />
      {activeCity && (
        <div className="rounded-xl border border-primary/10 bg-white/80 p-4 shadow-sm backdrop-blur">
          <h4 className="text-lg font-semibold text-primary">{activeCity.name}</h4>
          <p className="mt-2 text-sm text-primary/80">{activeCity.focus}</p>
          <p className="mt-1 text-sm font-mono text-verdant">Índice de intensidad: {Math.round(activeCity.intensity * 100)}%</p>
        </div>
      )}
    </div>
  );
};

export default MicrogridMap;