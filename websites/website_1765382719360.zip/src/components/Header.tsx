import React from "react";
import { NavLink } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

const navItems = [
  { path: "/", label: "Inicio" },
  { path: "/quienes-somos", label: "Quiénes Somos" },
  { path: "/tecnologias-smart-grid", label: "Tecnologías" },
  { path: "/proyectos-piloto", label: "Proyectos Piloto" },
  { path: "/recursos-tecnicos", label: "Recursos Técnicos" },
  { path: "/blog", label: "Blog" },
  { path: "/colabora", label: "Colabora" }
];

const Header: React.FC = () => {
  const [menuOpen, setMenuOpen] = React.useState(false);

  React.useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setMenuOpen(false);
      }
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-light/90 backdrop-blur-md">
      <div className="mx-auto flex w-full max-w-7xl items-center justify-between px-4 py-3 lg:px-8">
        <NavLink to="/" className="flex items-center gap-2 font-display text-xl font-semibold uppercase tracking-[0.2em] text-primary hover:text-accent transition-colors">
          <span className="rounded-full bg-accent px-2 py-1 text-sm font-bold text-primary shadow-glow">
            RI
          </span>
          RedInteligente
        </NavLink>
        <nav className="hidden lg:block" aria-label="Principal">
          <ul className="flex items-center gap-6 text-sm font-medium">
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `relative px-2 py-1 transition-colors hover:text-accent ${isActive ? "text-accent" : "text-primary"}`
                  }
                >
                  {({ isActive }) => (
                    <>
                      {item.label}
                      {isActive && (
                        <motion.span
                          layoutId="activeIndicator"
                          className="absolute -bottom-1 left-0 right-0 h-[3px] rounded-full bg-accent"
                        />
                      )}
                    </>
                  )}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <button
          type="button"
          className="lg:hidden"
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-controls="mobile-menu"
          aria-label="Abrir menú de navegación"
        >
          <span className="sr-only">Abrir menú</span>
          <div className="h-6 w-6">
            <span
              className={`block h-[2px] w-full bg-primary transition-transform ${menuOpen ? "translate-y-[7px] rotate-45" : ""}`}
            />
            <span
              className={`mt-[6px] block h-[2px] w-full bg-primary transition-opacity ${menuOpen ? "opacity-0" : "opacity-100"}`}
            />
            <span
              className={`mt-[6px] block h-[2px] w-full bg-primary transition-transform ${menuOpen ? "-translate-y-[7px] -rotate-45" : ""}`}
            />
          </div>
        </button>
      </div>
      <AnimatePresence>
        {menuOpen && (
          <motion.nav
            id="mobile-menu"
            aria-label="Menú móvil"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-slate-200 bg-light px-4 pb-4 pt-2 shadow-lg lg:hidden"
          >
            <ul className="flex flex-col gap-2 text-sm font-medium">
              {navItems.map((item) => (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    onClick={() => setMenuOpen(false)}
                    className={({ isActive }) =>
                      `block rounded-md px-3 py-2 transition-colors ${isActive ? "bg-primary/10 text-primary" : "text-primary hover:bg-primary/5"}`
                    }
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;