document.addEventListener("DOMContentLoaded", function () {
  const currentYearElement = document.getElementById("current-year");
  if (currentYearElement) {
    const currentYear = new Date().getFullYear();
    currentYearElement.textContent = currentYear;
  }

  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelector(".nav-links");

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", function () {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!expanded).toString());
      navLinks.classList.toggle("open");
    });

    navLinks.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        navLinks.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });

    window.addEventListener("resize", function () {
      if (window.innerWidth >= 600) {
        navLinks.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const consentKey = "itebCookieConsent";

  function hideCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
  }

  function showCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add("active");
    }
  }

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      showCookieBanner();
    }

    cookieBanner.addEventListener("click", function (event) {
      const target = event.target;
      if (target.matches("[data-action='accept']")) {
        localStorage.setItem(consentKey, "accepted");
        hideCookieBanner();
      }
      if (target.matches("[data-action='decline']")) {
        localStorage.setItem(consentKey, "declined");
        hideCookieBanner();
      }
    });
  }
});