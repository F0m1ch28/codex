document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle")
    const navList = document.querySelector(".nav-list")

    if (navToggle && navList) {
        navToggle.addEventListener("click", () => {
            const isOpen = navList.classList.toggle("open")
            navToggle.setAttribute("aria-expanded", isOpen)
        })
    }

    const cookieBanner = document.getElementById("cookie-banner")
    const acceptBtn = document.getElementById("cookie-accept")
    const declineBtn = document.getElementById("cookie-decline")
    const customizeBtn = document.getElementById("cookie-customize")
    const consentKey = "dogtagyxrj_cookie_consent"

    if (cookieBanner) {
        const consent = localStorage.getItem(consentKey)
        if (!consent) {
            cookieBanner.classList.add("show")
        }

        const handleConsent = (value) => {
            localStorage.setItem(consentKey, value)
            cookieBanner.classList.remove("show")
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => handleConsent("accepted"))
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", () => handleConsent("declined"))
        }

        if (customizeBtn) {
            customizeBtn.addEventListener("click", () => {
                window.location.href = "cookies.html"
            })
        }
    }
})