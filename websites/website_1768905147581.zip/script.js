document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.querySelector(".nav-menu");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!expanded).toString());
      navMenu.classList.toggle("is-open");
    });

    navMenu.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (window.innerWidth < 1024) {
          navMenu.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const consent = localStorage.getItem("civicDigestCookieConsent");
    if (!consent) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add("visible");
      });
    }

    const closeBanner = (decision) => {
      localStorage.setItem("civicDigestCookieConsent", decision);
      cookieBanner.classList.remove("visible");
    };

    const acceptBtn = cookieBanner.querySelector(".cookie-accept");
    const declineBtn = cookieBanner.querySelector(".cookie-decline");

    acceptBtn?.addEventListener("click", () => closeBanner("accepted"));
    declineBtn?.addEventListener("click", () => closeBanner("declined"));
  }
});