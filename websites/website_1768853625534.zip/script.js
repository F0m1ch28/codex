document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.getElementById("primaryNav");

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", function () {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      primaryNav.classList.toggle("is-open");
    });

    primaryNav.querySelectorAll(".nav-link").forEach(function (link) {
      link.addEventListener("click", function () {
        if (primaryNav.classList.contains("is-open")) {
          primaryNav.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const cookieBanner = document.getElementById("cookieBanner");
  if (cookieBanner) {
    const storedChoice = localStorage.getItem("financialwise-cookie-choice");
    if (storedChoice) {
      cookieBanner.classList.add("is-hidden");
    }
    cookieBanner.querySelectorAll(".cookie-choice").forEach(function (choiceLink) {
      choiceLink.addEventListener("click", function (event) {
        event.preventDefault();
        const choice = choiceLink.dataset.choice || "accepted";
        localStorage.setItem("financialwise-cookie-choice", choice);
        cookieBanner.classList.add("is-hidden");
      });
    });
  }
});