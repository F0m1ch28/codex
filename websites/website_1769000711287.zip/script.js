document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const navigation = document.getElementById('primary-navigation');

  if (navToggle && navigation) {
    navToggle.addEventListener('click', () => {
      const isVisible = navigation.getAttribute('data-visible') === 'true';
      navigation.setAttribute('data-visible', String(!isVisible));
      navToggle.setAttribute('aria-expanded', String(!isVisible));
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const cookieAccept = document.getElementById('cookie-accept');
  const cookieReject = document.getElementById('cookie-reject');

  if (cookieBanner && cookieAccept && cookieReject) {
    const storedChoice = localStorage.getItem('cookieChoice');
    if (!storedChoice) {
      cookieBanner.classList.add('active');
    }

    const handleChoice = (choice) => {
      localStorage.setItem('cookieChoice', choice);
      cookieBanner.classList.remove('active');
    };

    cookieAccept.addEventListener('click', () => handleChoice('accepted'));
    cookieReject.addEventListener('click', () => handleChoice('rejected'));
  }
});