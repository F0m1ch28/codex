document.addEventListener('DOMContentLoaded', function () {
    const banner = document.getElementById('cookieBanner');
    if (!banner) return;

    const choice = localStorage.getItem('spewdpwzCookieChoice');
    if (!choice) {
        banner.classList.add('show');
    }

    const buttons = banner.querySelectorAll('.cookie-btn');
    buttons.forEach((btn) => {
        btn.addEventListener('click', function (event) {
            event.preventDefault();
            const userChoice = btn.dataset.choice || 'accept';
            localStorage.setItem('spewdpwzCookieChoice', userChoice);
            banner.classList.remove('show');
            const target = btn.getAttribute('href') || 'cookies.html';
            window.open(target, '_blank', 'noopener');
        });
    });
});