document.addEventListener("DOMContentLoaded", () => {
  const yearEl = document.getElementById("current-year");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  const banner = document.querySelector(".cookie-banner");
  if (!banner) return;

  const showBanner = () => {
    banner.classList.add("is-visible");
    banner.setAttribute("aria-hidden", "false");
  };

  const hideBanner = () => {
    banner.classList.remove("is-visible");
    banner.setAttribute("aria-hidden", "true");
  };

  const storedConsent = localStorage.getItem("cookieConsent");
  if (!storedConsent) {
    requestAnimationFrame(showBanner);
  } else {
    banner.setAttribute("aria-hidden", "true");
  }

  banner.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;

    if (target.matches("[data-action='accept']")) {
      localStorage.setItem("cookieConsent", "accepted");
      hideBanner();
    }

    if (target.matches("[data-action='decline']")) {
      localStorage.setItem("cookieConsent", "declined");
      hideBanner();
    }
  });
});