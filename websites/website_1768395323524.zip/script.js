const navToggleButtons = document.querySelectorAll('.nav-toggle');
const cookieBanners = document.querySelectorAll('.cookie-banner');

navToggleButtons.forEach((button) => {
    button.addEventListener('click', () => {
        const navMenu = button.parentElement.querySelector('.nav-menu');
        const isOpen = navMenu.classList.toggle('open');
        button.classList.toggle('open', isOpen);
        button.setAttribute('aria-expanded', isOpen.toString());
    });
});

document.querySelectorAll('.nav-menu a').forEach((link) => {
    link.addEventListener('click', () => {
        navToggleButtons.forEach((button) => {
            const navMenu = button.parentElement.querySelector('.nav-menu');
            if (navMenu.classList.contains('open')) {
                navMenu.classList.remove('open');
                button.classList.remove('open');
                button.setAttribute('aria-expanded', 'false');
            }
        });
    });
});

const COOKIE_STORAGE_KEY = 'stabilpkke_cookie_choice';

function hideCookieBanners() {
    cookieBanners.forEach((banner) => {
        banner.classList.add('hidden');
    });
}

const storedChoice = localStorage.getItem(COOKIE_STORAGE_KEY);
if (storedChoice) {
    hideCookieBanners();
} else {
    cookieBanners.forEach((banner) => {
        const acceptButton = banner.querySelector('.cookie-button.accept');
        const declineButton = banner.querySelector('.cookie-button.decline');

        const handleChoice = (choice) => {
            localStorage.setItem(COOKIE_STORAGE_KEY, choice);
            hideCookieBanners();
            window.location.href = 'cookies.html#accept-notice';
        };

        acceptButton.addEventListener('click', () => handleChoice('accepted'));
        declineButton.addEventListener('click', () => handleChoice('declined'));
    });
}