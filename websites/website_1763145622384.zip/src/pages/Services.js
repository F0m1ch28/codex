import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const serviceGroups = [
  {
    title: 'Брендинг и айдентика',
    items: [
      'Разработка платформы бренда и визуального языка',
      'Названия, tone of voice и визуальные гайды',
      'Брендбуки, гайдлайны и носители коммуникации'
    ],
    illustration: 'https://picsum.photos/id/1067/520/380'
  },
  {
    title: 'Дигитал и мультимедиа',
    items: [
      'UI/UX дизайн сайтов и приложений',
      'Анимация, motion-графика и промо-ролики',
      'Интерактивные презентации и digital-кампании'
    ],
    illustration: 'https://picsum.photos/id/1070/520/380'
  },
  {
    title: 'Арт-проекты и пространства',
    items: [
      'Экспозиционный дизайн и пространственные инсталляции',
      'Муралы, арт-объекты и скульптуры',
      'Кураторство выставок, сценография событий'
    ],
    illustration: 'https://picsum.photos/id/1084/520/380'
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Исследование и инсайты',
    description:
      'Погружаемся в контекст бренда, проводим интервью, анализируем аудиторию и атмосферу будущего проекта.'
  },
  {
    step: '02',
    title: 'Концепция и визуальный язык',
    description:
      'Создаём Moodboard, подбираем палитру, тестируем композиции и типографику, формируем визуальную концепцию.'
  },
  {
    step: '03',
    title: 'Продакшн и арт-дирекшн',
    description:
      'Реализуем выбранную идею: иллюстрируем, моделируем, анимируем и готовим материалы для внедрения.'
  },
  {
    step: '04',
    title: 'Сопровождение и развитие',
    description:
      'Помогаем внедрять визуальные стандарты, обучаем команды, поддерживаем долгосрочные проекты.'
  }
];

const Services = () => (
  <>
    <Helmet>
      <title>Услуги ArtVista — брендинг, дизайн, арт-проекты</title>
      <meta
        name="description"
        content="Услуги студии ArtVista: айдентика, цифровой дизайн, арт-инсталляции, кураторство и мультимедийные проекты."
      />
      <meta
        name="keywords"
        content="брендинг, дизайн, арт-проект, творческая студия, визуальное решение"
      />
    </Helmet>
    <section className={`${styles.hero} container`}>
      <h1>Полный цикл творческих услуг для брендов, арт-проектов и пространств.</h1>
      <p>
        Мы создаём эстетичные и продуманные решения: от разработки стратегий и визуальных систем до
        полноценного сопровождения. Наш подход сочетает художественную смелость с глубоким
        исследованием целей проекта.
      </p>
    </section>

    <section className={`${styles.servicesGrid} container`}>
      {serviceGroups.map((group) => (
        <article key={group.title} className={styles.serviceBlock}>
          <div className={styles.serviceText}>
            <h2>{group.title}</h2>
            <ul>
              {group.items.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
          <div className={styles.serviceImage}>
            <img src={group.illustration} alt={`Услуги ArtVista: ${group.title}`} />
          </div>
        </article>
      ))}
    </section>

    <section className={styles.processSection}>
      <div className="container">
        <div className={styles.processHeader}>
          <h2>Как мы работаем</h2>
          <p>
            В центре каждого проекта — совместное создание и прозрачность. Мы ведём диалог на всех
            стадиях, чтобы добиться выразительного результата.
          </p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <article key={step.step}>
              <span>{step.step}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Services;