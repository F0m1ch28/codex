import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { to: '/', label: 'Главная' },
  { to: '/services', label: 'Услуги' },
  { to: '/portfolio', label: 'Портфолио' },
  { to: '/blog', label: 'Блог' },
  { to: '/about', label: 'О нас' },
  { to: '/contact', label: 'Контакты' }
];

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);
  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={`${styles.headerInner} container`}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          Art<span>Vista</span>
        </NavLink>
        <button
          className={styles.burger}
          type="button"
          onClick={toggleMenu}
          aria-label="Открыть меню"
          aria-expanded={isMenuOpen}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`}>
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.to} className={styles.navItem}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                  onClick={closeMenu}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <div className={styles.navCta}>
            <NavLink to="/contact" className={styles.navButton} onClick={closeMenu}>
              Обсудить проект
            </NavLink>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;