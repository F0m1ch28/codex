import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={styles.inner}>
      <div className={styles.brand}>
        <h3>Explore Belgia</h3>
        <p>
          Friendly, expert travel wisdom crafted to help you experience Belgium&apos;s landscapes, heritage, and rhythm like a local.
        </p>
        <div className={styles.tagline}>
          <span>Exploring Belgium</span>
        </div>
      </div>
      <div className={styles.links}>
        <h4>Navigate</h4>
        <NavLink to="/guide">Practical Guide</NavLink>
        <NavLink to="/programs">Programs</NavLink>
        <NavLink to="/tools">Travel Tools</NavLink>
        <NavLink to="/blog">Travel Journal</NavLink>
        <NavLink to="/about">About Us</NavLink>
      </div>
      <div className={styles.links}>
        <h4>Legal</h4>
        <NavLink to="/legal">Overview</NavLink>
        <NavLink to="/legal/terms">Terms of Service</NavLink>
        <NavLink to="/legal/privacy">Privacy Policy</NavLink>
        <NavLink to="/legal/cookies">Cookie Policy</NavLink>
      </div>
      <div className={styles.contact}>
        <h4>Get in Touch</h4>
        <p>Email: <a href="mailto:hello@explorebelgia.com">hello@explorebelgia.com</a></p>
        <p>Phone: Contact us via form</p>
        <p>Address: Exploring Belgium</p>
      </div>
    </div>
    <div className={styles.bottom}>
      <small>© {new Date().getFullYear()} Explore Belgia. All rights reserved.</small>
    </div>
  </footer>
);

export default Footer;