import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const storedConsent = window.localStorage.getItem('exploreBelgiaCookieConsent');
    if (!storedConsent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem('exploreBelgiaCookieConsent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent notice">
      <div className={styles.content}>
        <p>
          We use cookies to ensure you enjoy a smooth and tailored browsing experience across Explore Belgia. Learn more in our{' '}
          <Link to="/legal/cookies">cookie policy</Link>.
        </p>
      </div>
      <button type="button" onClick={acceptCookies} className={styles.button}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;