import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  subject: '',
  message: ''
};

const ContactPage = () => {
  const [formData, setFormData] = React.useState(initialFormState);
  const [errors, setErrors] = React.useState({});
  const [status, setStatus] = React.useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please let us know your name.';
    if (!formData.email.trim() || !/^\S+@\S+\.\S+$/.test(formData.email)) newErrors.email = 'A valid email helps us reply promptly.';
    if (!formData.subject.trim()) newErrors.subject = 'What would you like to discuss?';
    if (!formData.message.trim()) newErrors.message = 'Share a few details about your plans.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setStatus('Thank you! Your message is on its way. We will reply within two working days.');
      setFormData(initialFormState);
    } else {
      setStatus('');
    }
  };

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Contact Explore Belgia</title>
        <meta name="description" content="Contact the Explore Belgia team for custom itineraries, travel questions, or collaboration ideas." />
      </Helmet>

      <header className={styles.header}>
        <h1>Let’s plan your Belgian chapter</h1>
        <p>
          Share a glimpse of your travel dreams, and we&apos;ll respond with actionable ideas, resources, and next steps tailored to your group.
        </p>
      </header>

      <section className={styles.content}>
        <div className={styles.details}>
          <h2>Contact details</h2>
          <p>Email: <a href="mailto:hello@explorebelgia.com">hello@explorebelgia.com</a></p>
          <p>Phone: Contact us via form</p>
          <p>Address: Exploring Belgium</p>
          <p>Hours: Monday – Friday, 9:00–17:00 CET</p>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Name</label>
            <input
              id="name"
              type="text"
              value={formData.name}
              onChange={(event) => setFormData({ ...formData, name: event.target.value })}
              aria-invalid={!!errors.name}
              aria-describedby={errors.name ? 'name-error' : undefined}
              required
            />
            {errors.name && <span id="name-error" className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              value={formData.email}
              onChange={(event) => setFormData({ ...formData, email: event.target.value })}
              aria-invalid={!!errors.email}
              aria-describedby={errors.email ? 'email-error' : undefined}
              required
            />
            {errors.email && <span id="email-error" className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="subject">Subject</label>
            <input
              id="subject"
              type="text"
              value={formData.subject}
              onChange={(event) => setFormData({ ...formData, subject: event.target.value })}
              aria-invalid={!!errors.subject}
              aria-describedby={errors.subject ? 'subject-error' : undefined}
              required
            />
            {errors.subject && <span id="subject-error" className={styles.error}>{errors.subject}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="message">Message</label>
            <textarea
              id="message"
              rows="6"
              value={formData.message}
              onChange={(event) => setFormData({ ...formData, message: event.target.value })}
              aria-invalid={!!errors.message}
              aria-describedby={errors.message ? 'message-error' : undefined}
              required
            />
            {errors.message && <span id="message-error" className={styles.error}>{errors.message}</span>}
          </div>
          <button type="submit" className={styles.submit}>
            Send message
          </button>
          {status && <p className={styles.status}>{status}</p>}
        </form>
      </section>
    </div>
  );
};

export default ContactPage;