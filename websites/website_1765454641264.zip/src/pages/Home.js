import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import blogPosts from '../data/blogPosts';
import styles from './Home.module.css';

const statsData = [
  { label: 'Curated Itineraries', value: 48 },
  { label: 'Hidden Viewpoints', value: 112 },
  { label: 'Local Experts', value: 27 },
  { label: 'Happy Travelers', value: 820 }
];

const travelThemes = [
  {
    title: 'Historic Heartlands',
    description: 'Walk through UNESCO-listed squares, gothic cathedrals, and royal galleries with stories anchored in Belgium’s layered past.',
    image: 'https://images.unsplash.com/photo-1529921879218-f99546d03a9b?auto=format&fit=crop&w=800&q=80',
    link: '/programs#Historic'
  },
  {
    title: 'Gastronomic Strolls',
    description: 'Pair farm-to-table dining, craft breweries, and chocolate ateliers for a flavorful itinerary in every season.',
    image: 'https://images.unsplash.com/photo-1543362906-acfc16c67564?auto=format&fit=crop&w=800&q=80',
    link: '/programs#Gastronomic'
  },
  {
    title: 'Nature & Wellness',
    description: 'Unwind amid coastal dunes, forested valleys, and healing springs, balancing soft adventure with slow travel.',
    image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=800&q=80',
    link: '/programs#Outdoor'
  }
];

const processSteps = [
  { step: '01', title: 'Discover Your Vibe', text: 'Share your travel rhythm, passions, and must-sees through our quick inspiration canvas.' },
  { step: '02', title: 'Shape the Journey', text: 'We blend local insight, seasonal highlights, and seamless logistics into a bespoke roadmap.' },
  { step: '03', title: 'Travel With Confidence', text: 'Navigate Belgium with curated tips, responsive support, and tools that keep you in the loop.' }
];

const signatureRoutes = [
  {
    id: 1,
    title: 'Art Nouveau Lines in Brussels',
    category: 'Historic',
    description: 'Follow Victor Horta’s masterpieces, tucked-away townhouses, and cafés buzzing with design students.',
    image: 'https://images.unsplash.com/photo-1520949146677-0919c8bd6e33?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 2,
    title: 'Flemish Coastal Slow Ride',
    category: 'Coastal',
    description: 'Cycle the North Sea coastline past Belle Époque villas and seaside nature reserves at your pace.',
    image: 'https://images.unsplash.com/photo-1529059997568-3d847b1154f4?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 3,
    title: 'Meuse River Citadel Trail',
    category: 'Nature',
    description: 'Pair dramatic viewpoints with citadel history and river cruises in Namur and Dinant.',
    image: 'https://images.unsplash.com/photo-1470770903676-69b98201ea1c?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 4,
    title: 'Ghent Canals & Contemporary Art',
    category: 'Historic',
    description: 'Blend cathedral quiet with vibrant street art on a curated walk through Ghent’s creative quarters.',
    image: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=80'
  }
];

const testimonials = [
  {
    quote: 'Every suggestion felt personal. Explore Belgia led us from Bruges’ serene dawn lights to jazz bars in Antwerp we never would have found.',
    name: 'Emily & Jacob A.',
    location: 'Seattle, USA',
    image: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80'
  },
  {
    quote: 'The bilingual tips and rail insights made traveling with grandparents effortless. The Ardennes picnic spot was the highlight.',
    name: 'The Van der Meer Family',
    location: 'Rotterdam, NL',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80'
  },
  {
    quote: 'From art nouveau maps to the perfect beer-pairing workshop, the planning blended culture with play perfectly.',
    name: 'Sofia Martins',
    location: 'Lisbon, PT',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80'
  }
];

const teamMembers = [
  {
    name: 'Claire Verbeke',
    role: 'Cultural Curator',
    bio: 'Former museum educator who now designs story-rich walks across Flemish cities.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Hugo Maes',
    role: 'Outdoor Specialist',
    bio: 'Topographic-map enthusiast guiding travelers through the Ardennes and Hautes Fagnes.',
    image: 'https://images.unsplash.com/photo-1502685104226-ee32379fefbe?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Lina Moreau',
    role: 'Wellness & Culinary Lead',
    bio: 'Spa-town native connecting guests with chefs, chocolatiers, and thermal retreats.',
    image: 'https://images.unsplash.com/photo-1544723795-43253723d2d7?auto=format&fit=crop&w=400&q=80'
  }
];

const faqItems = [
  {
    question: 'When is the best time to explore Belgium?',
    answer:
      'Spring (April–June) brings mild weather and blooming parks, while autumn (September–October) highlights vineyard harvests and crisp canal reflections. Winter markets add sparkle for festive travelers.'
  },
  {
    question: 'Do I need to speak Dutch or French?',
    answer:
      'English is widely understood, especially in cities. Still, knowing “Dank je” (Dutch) or “Merci” (French) is always appreciated and opens doors to warmer conversations.'
  },
  {
    question: 'How do you tailor itineraries?',
    answer:
      'We begin with a discovery questionnaire, then curate experiences considering accessibility, dietary needs, pace preferences, and any personal passions you share with us.'
  }
];

const HomePage = () => {
  const [displayedStats, setDisplayedStats] = React.useState(statsData.map(() => 0));
  const [activeFilter, setActiveFilter] = React.useState('All');
  const [activeTestimonial, setActiveTestimonial] = React.useState(0);
  const [faqOpenIndex, setFaqOpenIndex] = React.useState(0);
  const [newsletterEmail, setNewsletterEmail] = React.useState('');
  const [newsletterStatus, setNewsletterStatus] = React.useState(null);

  React.useEffect(() => {
    const duration = 1200;
    const startTime = performance.now();

    let animationFrame;

    const animate = (currentTime) => {
      const progress = Math.min((currentTime - startTime) / duration, 1);
      const updated = statsData.map((stat, index) =>
        Math.floor(stat.value * progress) > displayedStats[index]
          ? Math.floor(stat.value * progress)
          : displayedStats[index]
      );
      setDisplayedStats(updated);
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  React.useEffect(() => {
    const rotation = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(rotation);
  }, []);

  const filteredRoutes =
    activeFilter === 'All' ? signatureRoutes : signatureRoutes.filter((route) => route.category === activeFilter);

  const handleFaqToggle = (index) => {
    setFaqOpenIndex((prev) => (prev === index ? -1 : index));
  };

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    if (!newsletterEmail.trim() || !/^\S+@\S+\.\S+$/.test(newsletterEmail)) {
      setNewsletterStatus('Please enter a valid email address.');
      return;
    }
    setNewsletterStatus('Thanks for joining our travel circle! Expect stories soon.');
    setNewsletterEmail('');
  };

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Explore Belgia | Friendly Expert Guide to Belgium</title>
        <meta
          name="description"
          content="Plan your Belgian escape with curated itineraries, travel insights, and local voices. Explore Belgia blends inspiration and practical know-how for every traveler."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.pill}>Belgium, beautifully decoded</span>
          <h1>
            Travel Belgium with
            <span> friendly expertise</span>
          </h1>
          <p>
            From canal-side dawns in Bruges to sunset terraces in Dinant, Explore Belgia shares immersive itineraries,
            thoughtful logistics, and local whispers tailored to the way you like to travel.
          </p>
          <div className={styles.heroActions}>
            <Link to="/guide" className={styles.primaryButton}>
              Start with the essential guide
            </Link>
            <Link to="/programs" className={styles.secondaryButton}>
              Browse signature programs
            </Link>
          </div>
          <div className={styles.heroStats}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <strong>{displayedStats[index]}+</strong>
                <span>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://images.unsplash.com/photo-1467269204594-9661b134dd2b?auto=format&fit=crop&w=1200&q=80"
            alt="Sunrise over the medieval roofs of Bruges"
          />
        </div>
      </section>

      <section className={styles.themes}>
        <div className={styles.sectionHeader}>
          <h2>Curated journeys for every travel rhythm</h2>
          <p>
            Whether you chase architectural details, chase flavors, or chase iconic landscapes, these themes guide your next Belgian chapter.
          </p>
        </div>
        <div className={styles.themeGrid}>
          {travelThemes.map((theme) => (
            <article key={theme.title} className={styles.themeCard}>
              <img src={theme.image} alt={`${theme.title} in Belgium`} loading="lazy" />
              <div className={styles.themeContent}>
                <h3>{theme.title}</h3>
                <p>{theme.description}</p>
                <Link to={theme.link} className={styles.link}>
                  Explore itineraries →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <h2>Your journey, thoughtfully choreographed</h2>
          <p>We partner with you every step of the way, from dream to departure to golden memories.</p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <div key={step.step} className={styles.processCard}>
              <span>{step.step}</span>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.routes}>
        <div className={styles.routesHeader}>
          <h2>Signature scenic routes</h2>
          <div className={styles.filters}>
            {['All', 'Historic', 'Coastal', 'Nature'].map((filter) => (
              <button
                type="button"
                key={filter}
                className={`${styles.filterButton} ${activeFilter === filter ? styles.filterActive : ''}`}
                onClick={() => setActiveFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
        <div className={styles.routeGrid}>
          {filteredRoutes.map((route) => (
            <article key={route.id} className={styles.routeCard}>
              <img src={route.image} alt={route.title} loading="lazy" />
              <div className={styles.routeContent}>
                <span>{route.category}</span>
                <h3>{route.title}</h3>
                <p>{route.description}</p>
                <Link to="/guide" className={styles.link}>
                  Add to my plan →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <h2>Traveler voices</h2>
          <p>Stories from exploring friends who trusted us to frame their Belgian chapters.</p>
        </div>
        <div className={styles.testimonialSlider}>
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.name}
              className={`${styles.testimonialCard} ${index === activeTestimonial ? styles.testimonialActive : ''}`}
            >
              <img src={testimonial.image} alt={`${testimonial.name} portrait`} />
              <blockquote>“{testimonial.quote}”</blockquote>
              <p className={styles.person}>{testimonial.name}</p>
              <p className={styles.location}>{testimonial.location}</p>
            </article>
          ))}
          <div className={styles.sliderDots}>
            {testimonials.map((testimonial, index) => (
              <button
                type="button"
                key={testimonial.name}
                onClick={() => setActiveTestimonial(index)}
                className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                aria-label={`Show testimonial from ${testimonial.name}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className={styles.sectionHeader}>
          <h2>Meet the Explore Belgia hosts</h2>
          <p>Our multilingual team lives and breathes Belgian culture, ready to share hidden gems and practical wisdom.</p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
              <h3>{member.name}</h3>
              <p className={styles.role}>{member.role}</p>
              <p>{member.bio}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.information}>
        <div className={styles.infoColumn}>
          <h2>Travel journal highlights</h2>
          <p>Dive deeper with reflections and insider notes from recent journeys across Belgium.</p>
          <div className={styles.blogList}>
            {blogPosts.slice(0, 3).map((post) => (
              <article key={post.slug} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div>
                  <span>{post.readTime}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={`/blog/${post.slug}`} className={styles.link}>
                    Read story →
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <Link to="/blog" className={styles.primaryButton}>
            View all stories
          </Link>
        </div>
        <div className={styles.infoColumn}>
          <h2>Frequently asked questions</h2>
          <div className={styles.accordion}>
            {faqItems.map((item, index) => (
              <div key={item.question} className={styles.accordionItem}>
                <button
                  type="button"
                  onClick={() => handleFaqToggle(index)}
                  className={styles.accordionButton}
                  aria-expanded={faqOpenIndex === index}
                >
                  <span>{item.question}</span>
                  <span className={styles.accordionIcon}>{faqOpenIndex === index ? '−' : '+'}</span>
                </button>
                {faqOpenIndex === index && <p className={styles.accordionContent}>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Stay in the loop with seasonal insights</h2>
          <p>
            Join our monthly dispatch for timely tips — think coastal sunrise guides, festival etiquette, and limited workshops across Belgium.
          </p>
          <form className={styles.ctaForm} onSubmit={handleNewsletterSubmit}>
            <label htmlFor="newsletter-email" className="sr-only">
              Email address
            </label>
            <input
              id="newsletter-email"
              type="email"
              placeholder="you@example.com"
              value={newsletterEmail}
              onChange={(event) => setNewsletterEmail(event.target.value)}
              required
            />
            <button type="submit">Subscribe</button>
          </form>
          {newsletterStatus && <p className={styles.ctaStatus}>{newsletterStatus}</p>}
        </div>
        <div className={styles.ctaVisual}>
          <img
            src="https://images.unsplash.com/photo-1500534314209-a25ddb2bd6e0?auto=format&fit=crop&w=1200&q=80"
            alt="Travelers enjoying a scenic view in Belgium"
          />
        </div>
      </section>
    </div>
  );
};

export default HomePage;