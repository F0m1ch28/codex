import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import blogPosts from '../data/blogPosts';
import styles from './Blog.module.css';

const BlogPage = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Travel Journal | Explore Belgia</title>
      <meta
        name="description"
        content="Read travel stories and insights from Belgium: chocolatiers, gothic gems, and outdoor escapes curated by Explore Belgia."
      />
    </Helmet>

    <header className={styles.header}>
      <h1>Travel journal & stories</h1>
      <p>
        Slow down with narratives from Belgium&apos;s cobbled lanes, forested valleys, and buzzing neighborhoods. Each story is
        penned by our team or trusted locals.
      </p>
    </header>

    <div className={styles.grid}>
      {blogPosts.map((post) => (
        <article key={post.slug} className={styles.card}>
          <img src={post.image} alt={post.title} loading="lazy" />
          <div className={styles.content}>
            <div className={styles.meta}>
              <span>{post.date}</span>
              <span>{post.readTime}</span>
            </div>
            <h2>{post.title}</h2>
            <p>{post.excerpt}</p>
            <div className={styles.tags}>
              {post.tags.map((tag) => (
                <span key={tag}>{tag}</span>
              ))}
            </div>
            <Link to={`/blog/${post.slug}`} className={styles.link}>
              Read full story →
            </Link>
          </div>
        </article>
      ))}
    </div>
  </div>
);

export default BlogPage;