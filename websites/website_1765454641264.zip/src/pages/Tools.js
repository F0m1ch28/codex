import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const weatherSnapshots = [
  { city: 'Brussels', icon: '🌤️', temp: '18°C', tip: 'Pack a light layer for breezy evenings on the Grand-Place.' },
  { city: 'Bruges', icon: '⛅', temp: '17°C', tip: 'Canals add cool humidity — carry a scarf for boat rides.' },
  { city: 'Liège', icon: '🌦️', temp: '16°C', tip: 'Quick showers pass by fast, keep a compact umbrella just in case.' }
];

const ToolsPage = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Travel Tools | Explore Belgia</title>
      <meta
        name="description"
        content="Interactive map, weather snapshots, language tips, and time zone helpers to prepare for a seamless Belgian getaway."
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Travel tools to keep you oriented</h1>
      <p>
        Bookmark these essentials to stay informed on the move. From maps and weather to local time and language support, Explore Belgia keeps everything in one calm space.
      </p>
    </header>

    <section className={styles.section}>
      <h2>Interactive map</h2>
      <p>
        Explore key highlights, scenic routes, and recommended neighborhoods. Zoom in to reveal hidden cafés, markets, and slow-travel locations curated by our team.
      </p>
      <div className={styles.mapWrapper}>
        <iframe
          title="Explore Belgia Map"
          src="https://www.google.com/maps/d/embed?mid=1NyLVwWsFHwhu5VfHZK43NOzHiP2he0s&ehbc=2E312F"
          loading="lazy"
        />
      </div>
    </section>

    <section className={styles.section}>
      <h2>Weather at a glance</h2>
      <div className={styles.weatherGrid}>
        {weatherSnapshots.map((snapshot) => (
          <article key={snapshot.city} className={styles.weatherCard}>
            <span className={styles.icon}>{snapshot.icon}</span>
            <h3>{snapshot.city}</h3>
            <strong>{snapshot.temp}</strong>
            <p>{snapshot.tip}</p>
          </article>
        ))}
      </div>
      <p className={styles.note}>
        Temperatures reflect typical late spring conditions. Check local forecasts 48 hours before departure for current values.
      </p>
    </section>

    <section className={styles.section}>
      <h2>Time & connectivity</h2>
      <div className={styles.grid}>
        <article>
          <h3>Local time</h3>
          <p>
            Belgium operates on Central European Time (GMT+1) and observes daylight saving (GMT+2 from late March to late October). Set your watch ahead before landing to ease into local rhythm.
          </p>
        </article>
        <article>
          <h3>Connectivity</h3>
          <p>
            Free Wi-Fi is common in cafés and train stations. Consider purchasing a prepaid SIM from providers like Proximus or Orange. EU visitors can rely on roaming agreements without extra setup.
          </p>
        </article>
        <article>
          <h3>Power plugs</h3>
          <p>
            Belgium uses Type E outlets (230V). Travelers from North America or the UK will need adapters. Pack a universal adapter with USB-C ports for easier charging.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.section}>
      <h2>Language & etiquette quick cards</h2>
      <div className={styles.cards}>
        <article>
          <h3>Greetings</h3>
          <p>Start with a friendly “Bonjour” in the south or “Goeiedag” in the north. When in doubt, smile and use English — most locals will happily switch languages.</p>
        </article>
        <article>
          <h3>Dining customs</h3>
          <p>It’s polite to keep your hands visible on the table. Ask before splitting the bill; many restaurants prefer one payment, especially at lunch.</p>
        </article>
        <article>
          <h3>Public transport</h3>
          <p>Queue at tram stops, allow passengers to exit first, and greet the driver when boarding regional buses. Validate tickets each time you ride.</p>
        </article>
      </div>
    </section>
  </div>
);

export default ToolsPage;