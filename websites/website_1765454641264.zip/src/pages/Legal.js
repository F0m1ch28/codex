import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Legal.module.css';

const LegalPage = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Legal Information | Explore Belgia</title>
      <meta name="description" content="Explore Belgia legal information including terms of service, privacy policy, and cookie policy." />
    </Helmet>
    <header className={styles.header}>
      <h1>Legal center</h1>
      <p>
        Transparency matters. Review our terms of service, privacy commitments, and cookie practices to understand how we operate and protect your information.
      </p>
    </header>
    <div className={styles.grid}>
      <Link to="/legal/terms" className={styles.card}>
        <h2>Terms of Service</h2>
        <p>Understand the conditions for using Explore Belgia resources and planning tools.</p>
      </Link>
      <Link to="/legal/privacy" className={styles.card}>
        <h2>Privacy Policy</h2>
        <p>Discover how we collect, use, and safeguard personal information you share with us.</p>
      </Link>
      <Link to="/legal/cookies" className={styles.card}>
        <h2>Cookie Policy</h2>
        <p>Learn about the cookies we use, why we use them, and how you can adjust your preferences.</p>
      </Link>
    </div>
  </div>
);

export default LegalPage;