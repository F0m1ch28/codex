import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Guide.module.css';

const GuidePage = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Belgium Travel Guide | Explore Belgia</title>
      <meta
        name="description"
        content="Practical advice for traveling Belgium: transport tips, cultural etiquette, language essentials, and seasonal guidance."
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Practical guide to traveling Belgium with ease</h1>
      <p>
        Lean on insider knowledge for smooth days across Belgium&apos;s regions. This guide covers transport essentials,
        language nuances, cultural etiquette, and the best times to uncover each province.
      </p>
    </header>

    <section className={styles.section}>
      <h2>Getting around with confidence</h2>
      <div className={styles.grid}>
        <article>
          <h3>Rail networks</h3>
          <p>
            The national operator, SNCB/NMBS, connects major cities with frequent services. Opt for weekend passes for
            discounted fares, and always validate tickets before boarding. Brussels Midi is the central hub, while
            Antwerp, Ghent, and Liège stations host luggage lockers and tourist information desks.
          </p>
        </article>
        <article>
          <h3>Trams, buses & metro</h3>
          <p>
            Brussels, Antwerp, Ghent, and the coastal region rely on efficient tram and bus networks. Purchase a reloadable
            MOBIB card for cash-free travel. Remember to tap in at the start of every ride, even when changing vehicles.
          </p>
        </article>
        <article>
          <h3>Driving & cycling</h3>
          <p>
            Belgian roads are well maintained, though city centers often favor pedestrians and cyclists. Renting a bike is
            effortless with share systems such as Blue-bike. If you drive, keep reflective jackets and warning triangles in
            the car — they are mandatory.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.section}>
      <h2>Language & communication</h2>
      <div className={styles.languageTips}>
        <div>
          <h3>Key phrases</h3>
          <ul>
            <li><strong>Dank je</strong> (Dutch) / <strong>Merci</strong> (French) — Thank you</li>
            <li><strong>Goeiedag</strong> / <strong>Bonjour</strong> — Good day</li>
            <li><strong>Mag ik ... alstublieft?</strong> / <strong>Puis-je ... s’il vous plaît?</strong> — May I have ... please?</li>
          </ul>
        </div>
        <div>
          <h3>Regional nuances</h3>
          <p>
            Dutch (Flemish) is spoken in the north, French in the south, and German in the east. In Brussels, expect a
            bilingual mix. English is widely understood in hospitality settings, but opening with local greetings is viewed
            as a sign of respect.
          </p>
        </div>
      </div>
    </section>

    <section className={styles.section}>
      <h2>Cultural etiquette</h2>
      <div className={styles.etiquetteGrid}>
        <article>
          <h3>Dining</h3>
          <p>
            Reservations are recommended, especially in smaller towns. Meals often begin with bread and butter; wait for the
            host to start before eating. Tipping is appreciated (around 5-10%) though service charges are usually included.
          </p>
        </article>
        <article>
          <h3>Social settings</h3>
          <p>
            Belgians value punctuality. For informal gatherings, a small box of pralines or local beer makes an excellent
            gift. Keep greetings relaxed with a handshake; cheek kisses vary by region and relationship.
          </p>
        </article>
        <article>
          <h3>Festivals & events</h3>
          <p>
            Many towns celebrate seasonal kermis fairs and processions. Observe local customs — in Binche, for instance,
            costumed Gilles distribute oranges, and spectators respectfully return them rather than eating immediately.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.section}>
      <h2>Seasonal planning</h2>
      <div className={styles.seasonCards}>
        <article>
          <h3>Spring</h3>
          <p>Tulip gardens bloom, the Hallerbos forest turns lavender with bluebells, and Easter markets brighten town squares.</p>
        </article>
        <article>
          <h3>Summer</h3>
          <p>Music festivals thrive, coastal breezes refresh, and extended daylight invites canal cruises well into the evening.</p>
        </article>
        <article>
          <h3>Autumn</h3>
          <p>Vineyards in Wallonia glow gold, Trappist breweries release seasonal brews, and castle parks transform into foliage wonders.</p>
        </article>
        <article>
          <h3>Winter</h3>
          <p>Bruges, Leuven, and Liège host atmospheric holiday markets. Pair city visits with thermal spa retreats in Spa or Chaudfontaine.</p>
        </article>
      </div>
    </section>

    <section className={styles.section}>
      <h2>Useful travel reminders</h2>
      <ul className={styles.reminders}>
        <li>Carry a debit card that supports contactless payments; cash is less common outside markets.</li>
        <li>Shops often close on Sundays except in tourist districts. Plan grocery runs accordingly.</li>
        <li>Pack a layered wardrobe — Belgium’s maritime climate can shift from sunshine to mist within hours.</li>
        <li>Save the emergency number 112, valid across the country for police, fire, and medical assistance.</li>
      </ul>
    </section>
  </div>
);

export default GuidePage;