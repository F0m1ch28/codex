import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const milestones = [
  { year: '2016', text: 'Claire and Lina met during a Brussels heritage project and began designing walking tours.' },
  { year: '2018', text: 'Hugo joined after mapping bike itineraries for the Ardennes, adding outdoor expertise.' },
  { year: '2021', text: 'Explore Belgia launched as a digital companion for slow travelers and culture lovers.' },
  { year: '2023', text: 'Introduced multilingual local host network covering all Belgian provinces.' }
];

const AboutPage = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>About Explore Belgia</title>
      <meta
        name="description"
        content="Learn about the Explore Belgia team, our story, and how we craft immersive Belgian travel experiences."
      />
    </Helmet>

    <header className={styles.header}>
      <h1>Our story</h1>
      <p>
        Explore Belgia began as a friendly project between local guides who wanted travelers to feel welcomed, informed,
        and inspired. Today, we are a collective of storytellers, planners, and on-the-ground hosts devoted to sharing Belgium’s hidden narratives.
      </p>
    </header>

    <section className={styles.section}>
      <h2>Why we do what we do</h2>
      <div className={styles.contentGrid}>
        <article>
          <h3>People first</h3>
          <p>We focus on genuine connections — pairing travelers with generous locals, artisans, and guides eager to share their passions.</p>
        </article>
        <article>
          <h3>Sustainable rhythms</h3>
          <p>We encourage slow travel, support public transport, and highlight eco-conscious businesses across Belgium.</p>
        </article>
        <article>
          <h3>Curiosity & craft</h3>
          <p>Each itinerary is handcrafted, blending iconic highlights with unexpected detours based on careful research.</p>
        </article>
      </div>
    </section>

    <section className={styles.timeline}>
      <h2>Milestones</h2>
      <div className={styles.milestones}>
        {milestones.map((item) => (
          <div key={item.year} className={styles.milestone}>
            <span>{item.year}</span>
            <p>{item.text}</p>
          </div>
        ))}
      </div>
    </section>

    <section className={styles.values}>
      <div className={styles.valuesContent}>
        <h2>Our promises</h2>
        <ul>
          <li>Respect every region’s identity and promote dialogue between cultures.</li>
          <li>Share transparent advice without commercial influence or commissions.</li>
          <li>Champion accessibility by offering alternative routes and step-free options whenever possible.</li>
        </ul>
        <a href="/contact" className={styles.link}>
          Say hello →
        </a>
      </div>
      <div className={styles.valuesVisual}>
        <img
          src="https://images.unsplash.com/photo-1521295121783-8a321d551ad2?auto=format&fit=crop&w=1000&q=80"
          alt="Explore Belgia team planning routes together"
        />
      </div>
    </section>
  </div>
);

export default AboutPage;