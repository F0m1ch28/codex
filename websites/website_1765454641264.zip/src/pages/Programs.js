import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programs.module.css';

const programThemes = [
  {
    id: 'Historic',
    title: 'Historic narratives',
    description: 'Trace Belgium’s storied past with cathedral climbs, canal cruises, and castle nights.',
    highlights: [
      'Medieval Bruges sunrise walk with private historian',
      'Ghent light festival itinerary with canal boat charter',
      'Namur citadel evening climb with panoramic picnic'
    ],
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1100&q=80'
  },
  {
    id: 'Gastronomic',
    title: 'Gastronomic adventures',
    description: 'Indulge in slow food markets, award-winning chocolatiers, and craft brews across the regions.',
    highlights: [
      'Chocolate tempering masterclass in Brussels’ Sablon',
      'Antwerp design district tasting tour with a culinary guide',
      'Liège waffle workshop paired with coffee cupping'
    ],
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=1100&q=80'
  },
  {
    id: 'Family',
    title: 'Family discoveries',
    description: 'Keep every generation engaged with interactive museums, outdoor play, and accessible navigation.',
    highlights: [
      'Mini-Europe mission trail with kid-friendly audio stories',
      'Pairi Daiza wildlife reserve sleepover in nature lodges',
      'De Panne coastal tram treasure hunt and dune safari'
    ],
    image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1100&q=80'
  },
  {
    id: 'Outdoor',
    title: 'Nature & wellness escapes',
    description: 'Breathe in the Ardennes pine forests, coastal dunes, and thermal springs — balanced with rest.',
    highlights: [
      'Forest bathing and waterfall hikes in the Semois Valley',
      'E-bike coastal ride with North Sea yoga session',
      'Thermal spa day in Spa with aromatherapy workshop'
    ],
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1100&q=80'
  }
];

const ProgramsPage = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Curated Programs | Explore Belgia</title>
      <meta
        name="description"
        content="Browse curated Belgian travel programs themed around history, gastronomy, family adventures, and nature escapes."
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Curated programs for every explorer</h1>
      <p>
        Each program blends iconic experiences with lesser-known treasures. Use them as inspiration or request a tailored itinerary that matches your travel rhythm.
      </p>
    </header>

    <div className={styles.programList}>
      {programThemes.map((program) => (
        <section key={program.id} id={program.id} className={styles.program}>
          <div className={styles.visual}>
            <img src={program.image} alt={`${program.title} in Belgium`} />
          </div>
          <div className={styles.content}>
            <span className={styles.label}>{program.id} theme</span>
            <h2>{program.title}</h2>
            <p>{program.description}</p>
            <h3>Highlights</h3>
            <ul>
              {program.highlights.map((highlight) => (
                <li key={highlight}>{highlight}</li>
              ))}
            </ul>
          </div>
        </section>
      ))}
    </div>

    <section className={styles.custom}>
      <div>
        <h2>Want a bespoke experience?</h2>
        <p>
          Tell us about your interests, dietary preferences, accessibility needs, and pace. We&apos;ll craft a day-by-day plan with reservations, transit guidance, and on-call support.
        </p>
      </div>
      <a href="/contact" className={styles.ctaLink}>
        Start a custom itinerary →
      </a>
    </section>
  </div>
);

export default ProgramsPage;