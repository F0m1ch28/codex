import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const TermsPage = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Terms of Service | Explore Belgia</title>
      <meta name="description" content="Review the Explore Belgia terms of service for using our website and resources." />
    </Helmet>
    <h1>Terms of Service</h1>
    <p>Last updated: March 2024</p>

    <section>
      <h2>1. Acceptance of terms</h2>
      <p>
        By accessing Explore Belgia, you agree to these Terms of Service. If you do not agree, please discontinue use.
        We may update these terms occasionally; continued use indicates acceptance of any changes.
      </p>
    </section>

    <section>
      <h2>2. Use of resources</h2>
      <p>
        Content is provided for personal travel planning. Redistribution or commercial use requires prior written consent.
        We strive for accuracy but cannot guarantee that all information remains current; always verify critical details such as transportation schedules.
      </p>
    </section>

    <section>
      <h2>3. Third-party links</h2>
      <p>
        Our site references external websites for convenience. We have no control over their content or policies and are not responsible for any outcomes related to their use.
      </p>
    </section>

    <section>
      <h2>4. Liability</h2>
      <p>
        Explore Belgia is not liable for indirect or consequential damages arising from the use of our guides or recommendations. Travel decisions remain your responsibility; please adhere to local laws and safety guidelines.
      </p>
    </section>

    <section>
      <h2>5. Contact</h2>
      <p>
        Questions about these terms? Reach us at <a href="mailto:hello@explorebelgia.com">hello@explorebelgia.com</a>.
      </p>
    </section>
  </div>
);

export default TermsPage;