import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const PrivacyPage = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Privacy Policy | Explore Belgia</title>
      <meta name="description" content="Learn how Explore Belgia collects and protects your personal information." />
    </Helmet>
    <h1>Privacy Policy</h1>
    <p>Last updated: March 2024</p>

    <section>
      <h2>Information we collect</h2>
      <p>
        We collect information you provide directly, such as contact details submitted via forms, and data collected automatically, including site usage analytics and cookie identifiers.
      </p>
    </section>

    <section>
      <h2>How we use information</h2>
      <ul>
        <li>To respond to inquiries and send requested resources.</li>
        <li>To improve website performance and user experience.</li>
        <li>To share newsletters, when you opt in.</li>
      </ul>
    </section>

    <section>
      <h2>Data protection</h2>
      <p>
        We implement security measures to protect personal data and do not sell or trade personal information. Access is limited to team members who require the data to deliver services.
      </p>
    </section>

    <section>
      <h2>Your rights</h2>
      <p>
        You may request access, correction, or deletion of your personal data at any time by emailing{' '}
        <a href="mailto:hello@explorebelgia.com">hello@explorebelgia.com</a>. You can also unsubscribe from newsletters via the link provided in each email.
      </p>
    </section>

    <section>
      <h2>Contact</h2>
      <p>For privacy-related questions, email us at hello@explorebelgia.com.</p>
    </section>
  </div>
);

export default PrivacyPage;