import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicyPage = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Cookie Policy | Explore Belgia</title>
      <meta name="description" content="Understand how Explore Belgia uses cookies and how you can manage preferences." />
    </Helmet>
    <h1>Cookie Policy</h1>
    <p>Last updated: March 2024</p>

    <section>
      <h2>What are cookies?</h2>
      <p>Cookies are small text files stored on your device to help websites remember preferences and improve performance.</p>
    </section>

    <section>
      <h2>How we use cookies</h2>
      <ul>
        <li><strong>Essential cookies:</strong> Enable core functionality such as navigation.</li>
        <li><strong>Analytics cookies:</strong> Help us understand how visitors interact with our site to enhance content.</li>
      </ul>
    </section>

    <section>
      <h2>Managing cookies</h2>
      <p>
        Most browsers allow you to manage or disable cookies through settings. Note that disabling cookies may affect how certain features function.
      </p>
    </section>

    <section>
      <h2>Contact</h2>
      <p>If you have questions about this policy, contact us at hello@explorebelgia.com.</p>
    </section>
  </div>
);

export default CookiePolicyPage;