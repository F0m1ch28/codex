import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import blogPosts from '../data/blogPosts';
import styles from './BlogPost.module.css';

const BlogPostPage = () => {
  const { slug } = useParams();
  const post = blogPosts.find((item) => item.slug === slug);

  if (!post) {
    return (
      <div className={styles.notFound}>
        <h1>Story not found</h1>
        <p>We couldn’t locate this article. Explore other travel stories instead.</p>
        <Link to="/blog" className={styles.backLink}>
          Back to travel journal
        </Link>
      </div>
    );
  }

  return (
    <article className={styles.wrapper}>
      <Helmet>
        <title>{post.title} | Explore Belgia</title>
        <meta name="description" content={post.excerpt} />
      </Helmet>
      <header className={styles.header}>
        <span>{post.date} · {post.readTime}</span>
        <h1>{post.title}</h1>
        <p className={styles.excerpt}>{post.excerpt}</p>
        <div className={styles.author}>By {post.author}</div>
      </header>
      <div className={styles.hero}>
        <img src={post.heroImage} alt={post.title} />
      </div>
      <div className={styles.content}>
        {post.content.map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
      </div>
      <div className={styles.tags}>
        {post.tags.map((tag) => (
          <span key={tag}>{tag}</span>
        ))}
      </div>
      <Link to="/blog" className={styles.backLink}>
        ← Back to travel journal
      </Link>
    </article>
  );
};

export default BlogPostPage;