const blogPosts = [
  {
    slug: 'belgian-chocolate-journey',
    title: 'Inside Belgium’s Chocolate Atelier Scene',
    excerpt: 'Step behind the marble counters and meet artisans who temper cacao into edible art across Brussels, Bruges, and Antwerp.',
    image: 'https://images.unsplash.com/photo-1583228475373-84d2010afa4c?auto=format&fit=crop&w=1200&q=80',
    heroImage: 'https://images.unsplash.com/photo-1611765083444-1c7d34631638?auto=format&fit=crop&w=1400&q=80',
    date: 'March 12, 2024',
    readTime: '6 min read',
    author: 'Claire Verbeke',
    tags: ['Gastronomy', 'Handcraft'],
    content: [
      'Belgium’s chocolate heritage is more than a sweet reputation — it is a centuries-old culture of precision, patience, and partnerships with sustainable cocoa growers.',
      'Begin in Brussels’ Sablon district where ateliers experiment with regional botanicals such as sea buckthorn and elderflower, then glide north to Bruges to discover pralines infused with West Flanders dairy.',
      'Along the way, schedule tastings in small batches, learn to temper chocolate during intimate workshops, and note the etiquette: savor slowly and pair with a light-bodied Gueuze to highlight the cacao’s floral notes.'
    ]
  },
  {
    slug: 'gothic-gems-of-ghent',
    title: 'Tracing Gothic Gems Through Ghent',
    excerpt: 'A walking route that layers cathedrals, canals, and contemporary art installations in Flanders’ creative capital.',
    image: 'https://images.unsplash.com/photo-1529921879218-f99546d03a9b?auto=format&fit=crop&w=1200&q=80',
    heroImage: 'https://images.unsplash.com/photo-1491554203631-4e0a57b2fe19?auto=format&fit=crop&w=1400&q=80',
    date: 'February 24, 2024',
    readTime: '7 min read',
    author: 'Jonas De Wilde',
    tags: ['Architecture', 'Heritage'],
    content: [
      'Ghent rewards patient wanderers with layered stories. Start at Saint Bavo’s Cathedral to admire the Adoration of the Mystic Lamb before slipping into the labyrinth of Patershol.',
      'Cycle along the Leie River to discover street art curated under the city’s “Sorry, Not Sorry” initiative, revealing how Ghent’s creative scene dialogues with its medieval towers.',
      'Finish at the Gravensteen castle at dusk when the stone walls glow amber and evening carillons float across Vrijdagmarkt.'
    ]
  },
  {
    slug: 'ardennes-outdoor-escape',
    title: 'Wild Escapes in the Belgian Ardennes',
    excerpt: 'From misty valleys to fortified towns, this three-day itinerary balances adrenaline and calm in southern Belgium.',
    image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1200&q=80',
    heroImage: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1400&q=80',
    date: 'January 30, 2024',
    readTime: '8 min read',
    author: 'Lina Moreau',
    tags: ['Nature', 'Outdoor'],
    content: [
      'Base yourself in Dinant to paddle through the Meuse River gorge at sunrise, then ascend to the citadel via cable car for sweeping views across Namur province.',
      'Wind south into the Semois Valley for forest bathing along the Frahan panorama trail and explore artisan smokehouses that prepare the region’s iconic cured ham.',
      'Conclude in Spa with its UNESCO-recognized thermal waters — the perfect restorative finale after pine-scented adventures.'
    ]
  }
];

export default blogPosts;