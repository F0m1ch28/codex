document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.getElementById("navToggle");
    const primaryNav = document.getElementById("primaryNav");

    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            primaryNav.classList.toggle("open");
            if (!expanded) {
                primaryNav.querySelectorAll("a")[0].focus();
            }
        });

        primaryNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                if (primaryNav.classList.contains("open")) {
                    navToggle.setAttribute("aria-expanded", "false");
                    primaryNav.classList.remove("open");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookieBanner");
    const acceptCookies = document.getElementById("acceptCookies");
    const declineCookies = document.getElementById("declineCookies");
    const cookiePreference = localStorage.getItem("citronaCookiePreference");

    if (cookieBanner && !cookiePreference) {
        setTimeout(() => {
            cookieBanner.classList.add("active");
        }, 600);
    }

    function closeBanner(choice) {
        if (!cookieBanner) return;
        cookieBanner.classList.remove("active");
        localStorage.setItem("citronaCookiePreference", choice);
    }

    if (acceptCookies) {
        acceptCookies.addEventListener("click", () => closeBanner("accepted"));
    }

    if (declineCookies) {
        declineCookies.addEventListener("click", () => closeBanner("declined"));
    }
});