document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.getElementById("navToggle");
  const primaryNavigation = document.getElementById("primary-navigation");

  if (navToggle && primaryNavigation) {
    navToggle.addEventListener("click", () => {
      const isOpen = primaryNavigation.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
  }

  const cookieBanner = document.getElementById("cookieBanner");
  const cookieAccept = document.getElementById("cookieAccept");
  const cookieDecline = document.getElementById("cookieDecline");
  const cookieKey = "qazaqMediaCookieConsent";

  function hideCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add("hidden");
    }
  }

  function showCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove("hidden");
    }
  }

  if (cookieBanner && cookieAccept && cookieDecline) {
    const storedConsent = localStorage.getItem(cookieKey);

    if (!storedConsent) {
      showCookieBanner();
    }

    cookieAccept.addEventListener("click", function () {
      localStorage.setItem(cookieKey, "accepted");
      hideCookieBanner();
    });

    cookieDecline.addEventListener("click", function () {
      localStorage.setItem(cookieKey, "declined");
      hideCookieBanner();
    });
  }

  const yearElement = document.getElementById("currentYear");
  if (yearElement) {
    yearElement.textContent = String(new Date().getFullYear());
  }

  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    const formStatus = document.getElementById("formStatus");
    contactForm.addEventListener("submit", function (event) {
      if (!contactForm.checkValidity()) {
        event.preventDefault();
        contactForm.reportValidity();
        if (formStatus) {
          formStatus.textContent = "Толық емес немесе қате деректер бар. Өрістерді тексеріңіз.";
          formStatus.style.color = "#DC2626";
        }
      } else {
        event.preventDefault();
        if (formStatus) {
          formStatus.textContent = "Хабарламаңыз сәтті жіберілді! Жақын арада жауап береміз.";
          formStatus.style.color = "#1E3A8A";
        }
        contactForm.reset();
      }
    });
  }
});