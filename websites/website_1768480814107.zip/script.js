document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.getElementById("primary-navigation");
    const navLinks = document.querySelectorAll(".nav-links a");
    const cookieBanner = document.getElementById("cookie-banner");
    const acceptButton = document.getElementById("cookie-accept");
    const declineButton = document.getElementById("cookie-decline");
    const currentYearSpan = document.getElementById("current-year");

    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!isExpanded));
            primaryNav.classList.toggle("is-open");
        });

        navLinks.forEach(link => {
            link.addEventListener("click", () => {
                navToggle.setAttribute("aria-expanded", "false");
                primaryNav.classList.remove("is-open");
            });
        });
    }

    if (cookieBanner && acceptButton && declineButton) {
        const consent = localStorage.getItem("gcCookieConsent");
        if (!consent) {
            cookieBanner.classList.add("show");
        }

        const handleConsent = (value) => {
            localStorage.setItem("gcCookieConsent", value);
            cookieBanner.classList.remove("show");
        };

        acceptButton.addEventListener("click", () => handleConsent("accepted"));
        declineButton.addEventListener("click", () => handleConsent("declined"));
    }

    if (currentYearSpan) {
        currentYearSpan.textContent = String(new Date().getFullYear());
    }
});