import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Meta from '../components/Meta';
import styles from './Home.module.css';

const statsData = [
  {
    label: 'відпрацьованих занять за минулий рік',
    value: 1280,
  },
  {
    label: 'німецьких вівчарок у постійній програмі',
    value: 96,
  },
  {
    label: 'сертифікованих кінологів у команді',
    value: 7,
  },
  {
    label: 'підготовлених команд охорони',
    value: 38,
  },
];

const expertisePoints = [
  {
    title: 'Глибинна соціалізація',
    description:
      'Поступово занурюємо собаку у реальні міські умови Варшави та Кракова, щоб закріпити спокій та контроль.',
  },
  {
    title: 'Побудова комунікації з власником',
    description:
      'Відпрацьовуємо чіткі команди, ритуали взаємодії та роль лідера, щоб собака обирала вас навіть у стресі.',
  },
  {
    title: 'Сервісні навички та захист',
    description:
      'Спеціальні сценарії для службових завдань: охорона, пошук, робота з предметами, ОКД для вівчарок.',
  },
];

const servicesData = [
  {
    title: 'Стартова діагностика та план розвитку',
    description:
      'Комплексна оцінка темпераменту, мотивацій та поведінкових тригерів з формуванням покрокового маршруту навчання.',
    image: 'https://picsum.photos/800/600?random=2',
  },
  {
    title: 'ОКД та слухняність у місті',
    description:
      'Від базових команд до ідеального контролю в середовищі великого міста. Акцент на чіткість, витримку та мотивацію.',
    image: 'https://picsum.photos/800/600?random=12',
  },
  {
    title: 'Поведенкова корекція та ресоціалізація',
    description:
      'Опрацьовуємо агресію, тривожність, гіперактивність. Формуємо стійкі шаблони бажаної поведінки.',
    image: 'https://picsum.photos/800/600?random=22',
  },
];

const processSteps = [
  {
    title: 'Знайомство та тест-день',
    description:
      'Перший виїзд кінолога, знайомство з собакою, перевірка реактивності, мотивації та комунікації з господарем.',
  },
  {
    title: 'Індивідуальний план навчання',
    description:
      'Визначаємо блоки: слухняність, соціалізація, робота з подразниками, сервісні сценарії. Узгоджуємо графік.',
  },
  {
    title: 'Системні тренування',
    description:
      'Працюємо за модульною схемою: щоденні мікро-завдання, виїзди кінолога, контроль прогресу та корекція.',
  },
  {
    title: 'Атестація та супровід',
    description:
      'Фінальне тестування, розробка плану підтримки, консультації on demand та виїзди у складні ситуації.',
  },
];

const projectsData = [
  {
    title: 'K9 Warsaw Security',
    description:
      'Підготовка двох німецьких вівчарок для служби охорони бізнес-парку: від соціалізації до затримання.',
    category: 'Охорона',
    image: 'https://picsum.photos/1200/800?random=4',
  },
  {
    title: 'Реабілітація Лекси',
    description:
      'Робота з реактивною вівчаркою, що боялася транспорту. 12 тижнів інтенсивної ресоціалізації у Кракові.',
    category: 'Корекція поведінки',
    image: 'https://picsum.photos/1200/800?random=14',
  },
  {
    title: 'ОКД для молодих собак',
    description:
      'Групова програма слухняності для цуценят у Варшаві: 16 учасників, градація складності, сертифікація.',
    category: 'ОКД',
    image: 'https://picsum.photos/1200/800?random=24',
  },
];

const testimonialsData = [
  {
    author: 'Марія, Варшава',
    role: 'Власниця вівчарки Асті',
    quote:
      'Через високий драйв моя Асті не могла зосередитися у місті. Команда показала, як працювати з енергією, а не проти неї. Тепер маємо стабільну слухняність та добросовісний захист.',
  },
  {
    author: 'Мацей, Краків',
    role: 'Менеджер об’єкту, керівник K9',
    quote:
      'Отримали дві готові до служби вівчарки з чітким протоколом. Кінологи супроводжували запуск охорони, проводили інструктажі та періодичні атестації.',
  },
  {
    author: 'Олена, Варшава',
    role: 'Власниця цуценяти Бруно',
    quote:
      'Стартували з 3-місячним цуценям. Базові команди, ігрові вправи та контроль збудження дали чудовий фундамент. Особливо цінно, що мене навчали взаємодіяти з собакою самостійно.',
  },
];

const faqData = [
  {
    question: 'Скільки часу потрібно для базового курсу ОКД?',
    answer:
      'Середній термін — 10–12 тижнів із частотою 2-3 виїзди на тиждень плюс самостійні мікрозавдання. Графік адаптуємо під собаку та власника.',
  },
  {
    question: 'Чи працюєте ви з проблемною поведінкою дорослих собак?',
    answer:
      'Так. Починаємо з діагностики, визначаємо тригери та причини поведінки. Далі складаємо програму ресоціалізації та корекції з регулярним моніторингом.',
  },
  {
    question: 'Чи можна комбінувати онлайн-супровід і виїзди?',
    answer:
      'Так, але базові навички та корекція вимагають живої роботи. Онлайн-формат використовуємо для підтримки між заняттями та роз’яснення домашніх завдань.',
  },
  {
    question: 'Чи готуєте ви вівчарок до виставок або спортивних змагань?',
    answer:
      'Ми фокусуємось на прикладних завданнях: охорона, пошук, службові функції та повна керованість у місті. Для виставкових підготовок співпрацюємо з вузькопрофільними тренерами.',
  },
];

const blogPosts = [
  {
    title: 'Як сформувати стабільну витримку німецької вівчарки в місті',
    excerpt:
      'Поділяємо підхід, який працює у Варшаві: поступове ускладнення подразників, контроль уваги та баланс мотивацій.',
    date: '12 квітня 2024',
    image: 'https://picsum.photos/800/600?random=34',
  },
  {
    title: 'Чому вівчарка ідеально підходить для охоронних задач',
    excerpt:
      'Розбираємо робочі якості породи, схеми тренувань і приклади з наших кейсів у бізнес-центрах Кракова.',
    date: '29 березня 2024',
    image: 'https://picsum.photos/800/600?random=44',
  },
  {
    title: '5 сигналів, що поведінка потребує корекції',
    excerpt:
      'Від небажання контактувати до переслідування транспорту — як розпізнати тривожні дзвіночки та діяти вчасно.',
    date: '15 березня 2024',
    image: 'https://picsum.photos/800/600?random=54',
  },
];

const cityCoverage = [
  {
    city: 'Варшава',
    description:
      'Працюємо у всіх районах столиці, включно з бізнес-парками, парками та приватними територіями.',
    image: 'https://picsum.photos/800/600?random=64',
  },
  {
    city: 'Краків',
    description:
      'Супровід приватних клієнтів та корпоративних K9-програм у межах міста та передмістя.',
    image: 'https://picsum.photos/800/600?random=74',
  },
];

const projectCategories = ['Усі', 'ОКД', 'Корекція поведінки', 'Охорона'];

const HomePage = () => {
  const [counts, setCounts] = useState(statsData.map(() => 0));
  const [activeProjectCategory, setActiveProjectCategory] = useState('Усі');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [openFAQItem, setOpenFAQItem] = useState(null);

  useEffect(() => {
    let animationFrame;
    const startTime = performance.now();
    const duration = 1500;

    const animate = (time) => {
      const progress = Math.min((time - startTime) / duration, 1);
      const nextCounts = statsData.map((item) =>
        Math.round(item.value * progress)
      );
      setCounts(nextCounts);

      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const interval = window.setInterval(() => {
      setCurrentTestimonial((prev) =>
        prev + 1 < testimonialsData.length ? prev + 1 : 0
      );
    }, 6000);

    return () => window.clearInterval(interval);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeProjectCategory === 'Усі') {
      return projectsData;
    }
    return projectsData.filter(
      (project) => project.category === activeProjectCategory
    );
  }, [activeProjectCategory]);

  const toggleFAQ = (index) => {
    setOpenFAQItem((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Meta
        title="Професійне дресерування собак | Варшава та Краків"
        description="Команда кінологів із фокусом на німецьких вівчарках: індивідуальні програми ОКД, корекція поведінки, підготовка до охоронної служби у Варшаві та Кракові."
      />

      <section className={styles.hero}>
        <div className={`container ${styles.heroGrid}`}>
          <div className={styles.heroContent}>
            <span className={styles.badge}>
              Німецькі вівчарки — наша спеціалізація
            </span>
            <h1 className={styles.heroTitle}>
              Сильний характер + повний контроль. Розкриваємо потенціал вашої
              вівчарки професійно.
            </h1>
            <p className={styles.heroSubtitle}>
              10+ років готуємо вівчарок до життя у великому місті, службових
              задач та відповідального захисту. Власний кінологічний протокол,
              локальні майданчики у Варшаві та Кракові.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className={styles.primaryButton}>
                Замовити консультацію
              </Link>
              <Link to="/posluhy" className={styles.secondaryButton}>
                Переглянути програми
              </Link>
            </div>
            <ul className={styles.heroHighlights}>
              <li>Виїзди на вашу локацію</li>
              <li>Робота з поведінковими викликами</li>
              <li>Атестація та супровід після курсу</li>
            </ul>
          </div>
          <div className={styles.heroMedia}>
            <img
              src="https://picsum.photos/1600/900?random=1"
              alt="Німецька вівчарка під час тренування з кінологом"
            />
          </div>
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Наші показники">
        <div className={`container ${styles.statsWrapper}`}>
          {statsData.map((item, index) => (
            <article className={styles.statCard} key={item.label}>
              <span className={styles.statNumber}>
                {counts[index].toLocaleString('uk-UA')}
              </span>
              <p className={styles.statLabel}>{item.label}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.expertiseSection}>
        <div className={`container ${styles.expertiseGrid}`}>
          <div className={styles.expertiseIntro}>
            <h2>Підхід, розроблений саме для вівчарок</h2>
            <p>
              Враховуємо робочу натуру породи, високу навчальність та
              чутливість до лідерства. Працюємо із собаками різного віку: від
              3-місячних цуценят до дорослих службових собак.
            </p>
            <Link to="/pro-nas" className={styles.linkButton}>
              Познайомитися з командою
            </Link>
          </div>
          <div className={styles.expertiseList}>
            {expertisePoints.map((point) => (
              <article key={point.title} className={styles.expertiseItem}>
                <h3>{point.title}</h3>
                <p>{point.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Флагманські програми</h2>
            <p>
              Кожен курс адаптуємо під конкретну собаку та сім’ю. Тренер веде
              вас від першого дня до фінальної атестації.
            </p>
          </header>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceImageWrapper}>
                  <img src={service.image} alt={service.title} />
                </div>
                <div className={styles.serviceContent}>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <Link to="/posluhy" className={styles.serviceLink}>
                    Детальніше про програму
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Як відбувається співпраця</h2>
            <p>
              Прозорий маршрут навчання: ви бачите цілі, прогрес і наступні
              кроки.
            </p>
          </header>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processStep}>
                <span className={styles.stepBadge}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Реальні кейси</h2>
            <p>Фільтруйте за напрямом, що близький до вашого запиту.</p>
          </header>
          <div className={styles.filterBar} role="tablist">
            {projectCategories.map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={activeProjectCategory === category}
                className={`${styles.filterButton} ${
                  activeProjectCategory === category ? styles.filterActive : ''
                }`}
                onClick={() => setActiveProjectCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img src={project.image} alt={project.title} />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>
                    {project.category}
                  </span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/kontakty" className={styles.projectLink}>
                    Обговорити подібний проект
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        className={styles.testimonialsSection}
        aria-labelledby="testimonials-heading"
      >
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2 id="testimonials-heading">Відгуки клієнтів</h2>
            <p>Історії власників, які тренуються з нами.</p>
          </header>
          <div className={styles.testimonialWrapper}>
            <article
              className={styles.testimonialCard}
              aria-live="polite"
              aria-atomic="true"
              key={testimonialsData[currentTestimonial].author}
            >
              <p className={styles.testimonialQuote}>
                “{testimonialsData[currentTestimonial].quote}”
              </p>
              <div className={styles.testimonialAuthor}>
                <strong>{testimonialsData[currentTestimonial].author}</strong>
                <span>{testimonialsData[currentTestimonial].role}</span>
              </div>
            </article>
            <div className={styles.testimonialControls}>
              <button
                type="button"
                aria-label="Попередній відгук"
                onClick={() =>
                  setCurrentTestimonial((prev) =>
                    prev - 1 >= 0 ? prev - 1 : testimonialsData.length - 1
                  )
                }
              >
                ←
              </button>
              <button
                type="button"
                aria-label="Наступний відгук"
                onClick={() =>
                  setCurrentTestimonial((prev) =>
                    prev + 1 < testimonialsData.length ? prev + 1 : 0
                  )
                }
              >
                →
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Поширені питання</h2>
            <p>Підготували відповіді на ключові моменти співпраці.</p>
          </header>
          <div className={styles.faqList}>
            {faqData.map((faq, index) => {
              const isOpen = openFAQItem === index;
              return (
                <div
                  key={faq.question}
                  className={`${styles.faqItem} ${
                    isOpen ? styles.faqItemOpen : ''
                  }`}
                >
                  <button
                    type="button"
                    className={styles.faqButton}
                    onClick={() => toggleFAQ(index)}
                    aria-expanded={isOpen}
                  >
                    <span>{faq.question}</span>
                    <span aria-hidden="true">{isOpen ? '−' : '+'}</span>
                  </button>
                  {isOpen && <p className={styles.faqAnswer}>{faq.answer}</p>}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Блог та аналітика</h2>
            <p>Ділимося інсайтами про роботу з вівчарками в умовах великого міста.</p>
          </header>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImage}>
                  <img src={post.image} alt={post.title} />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/posluhy" className={styles.blogLink}>
                    Читати рекомендації
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.coverageSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Регіони роботи</h2>
            <p>
              Виїжджаємо на об’єкти, парки, приватні тренувальні майданчики у
              Варшаві та Кракові.
            </p>
          </header>
          <div className={styles.coverageGrid}>
            {cityCoverage.map((city) => (
              <article key={city.city} className={styles.coverageCard}>
                <div className={styles.coverageImage}>
                  <img src={city.image} alt={city.city} />
                </div>
                <div className={styles.coverageContent}>
                  <h3>{city.city}</h3>
                  <p>{city.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={`container ${styles.ctaInner}`}>
          <div className={styles.ctaContent}>
            <h2>Почнімо роботу над вашим тандемом уже зараз</h2>
            <p>
              Залиште заявку — узгодимо зустріч на зручній локації та створимо
              план, який підкреслить природні сильні сторони вашої вівчарки.
            </p>
          </div>
          <Link to="/kontakty" className={styles.ctaButton}>
            Записатися на діагностику
          </Link>
        </div>
      </section>
    </>
  );
};

export default HomePage;