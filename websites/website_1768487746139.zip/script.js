document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieButtons = document.querySelectorAll('[data-cookie-choice]');
    const consentKey = 'televiihjpCookieConsent';

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('active');
        });

        navMenu.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.innerWidth < 1024) {
                    navMenu.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (!storedConsent) {
            cookieBanner.classList.add('is-visible');
        }

        cookieButtons.forEach(function (btn) {
            btn.addEventListener('click', function (event) {
                event.preventDefault();
                const choice = btn.getAttribute('data-cookie-choice');
                const redirectTarget = btn.getAttribute('data-redirect');
                localStorage.setItem(consentKey, choice);
                cookieBanner.classList.remove('is-visible');
                if (redirectTarget) {
                    window.location.href = redirectTarget;
                }
            });
        });
    }
});