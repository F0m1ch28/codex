document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.primary-navigation');
    const cookieBanner = document.getElementById('cookie-banner');
    const consentButtons = document.querySelectorAll('[data-consent]');
    const closeNav = () => {
        navigation.classList.remove('open');
        navToggle.classList.remove('is-active');
    };

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.classList.toggle('is-active');
            navigation.classList.toggle('open', isExpanded);
            navToggle.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
        });

        navigation.addEventListener('click', (event) => {
            if (event.target.closest('a')) {
                closeNav();
            }
        });
    }

    const storedConsent = localStorage.getItem('scrb-cookie-consent');
    if (!storedConsent && cookieBanner) {
        cookieBanner.classList.add('active');
    }

    consentButtons.forEach((button) => {
        button.addEventListener('click', (event) => {
            event.preventDefault();
            const value = button.getAttribute('data-consent');
            localStorage.setItem('scrb-cookie-consent', value);
            if (cookieBanner) {
                cookieBanner.classList.remove('active');
            }
            const targetUrl = button.getAttribute('href');
            if (targetUrl) {
                window.open(targetUrl, '_blank');
            }
        });
    });
});