document.addEventListener('DOMContentLoaded', function () {
    const nav = document.querySelector('.site-nav');
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelectorAll('.nav-list a');

    if (menuToggle && nav) {
        menuToggle.addEventListener('click', () => {
            nav.classList.toggle('open');
            menuToggle.setAttribute('aria-expanded', nav.classList.contains('open'));
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (nav.classList.contains('open')) {
                    nav.classList.remove('open');
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('[data-cookie-banner]');
    const acceptCookiesBtn = document.querySelector('[data-accept-cookies]');
    const declineCookiesBtn = document.querySelector('[data-decline-cookies]');
    const cookiePreference = localStorage.getItem('atlanticCookiePreference');

    if (!cookiePreference && cookieBanner) {
        cookieBanner.classList.add('active');
    }

    function handleCookieChoice(choice) {
        localStorage.setItem('atlanticCookiePreference', choice);
        if (cookieBanner) {
            cookieBanner.classList.remove('active');
        }
    }

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', () => handleCookieChoice('accepted'));
    }

    if (declineCookiesBtn) {
        declineCookiesBtn.addEventListener('click', () => handleCookieChoice('declined'));
    }

    const layerButtons = document.querySelectorAll('[data-layer-toggle]');
    const mapLayers = document.querySelectorAll('[data-map-layer]');

    function setActiveLayer(target) {
        mapLayers.forEach(layer => {
            if (layer.dataset.mapLayer === target) {
                layer.classList.add('active');
            } else {
                layer.classList.remove('active');
            }
        });
        layerButtons.forEach(button => {
            if (button.dataset.layerToggle === target) {
                button.classList.add('active');
            } else {
                button.classList.remove('active');
            }
        });
    }

    if (layerButtons.length && mapLayers.length) {
        layerButtons.forEach(button => {
            button.addEventListener('click', () => {
                const target = button.dataset.layerToggle;
                setActiveLayer(target);
            });
        });
        const firstLayer = layerButtons[0];
        if (firstLayer) {
            setActiveLayer(firstLayer.dataset.layerToggle);
        }
    }

    const timelineSteps = document.querySelectorAll('[data-timeline-step]');
    const timelineDisplay = document.querySelector('[data-timeline-display]');

    function activateTimelineStep(stepElement) {
        if (!stepElement || !timelineDisplay) return;
        const heading = stepElement.dataset.timelineHeading || '';
        const body = stepElement.dataset.timelineBody || '';
        timelineDisplay.innerHTML = `
            <h3>${heading}</h3>
            <p>${body}</p>
        `;
        timelineSteps.forEach(step => step.classList.remove('active'));
        stepElement.classList.add('active');
    }

    if (timelineSteps.length && timelineDisplay) {
        timelineSteps.forEach(step => {
            step.addEventListener('click', () => activateTimelineStep(step));
            step.addEventListener('keyup', event => {
                if (event.key === 'Enter') {
                    activateTimelineStep(step);
                }
            });
        });
        activateTimelineStep(timelineSteps[0]);
    }

    const filterButtons = document.querySelectorAll('[data-filter]');
    const filterItems = document.querySelectorAll('[data-category]');
    if (filterButtons.length && filterItems.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const category = button.dataset.filter;
                filterButtons.forEach(btn => btn.classList.toggle('active', btn === button));
                filterItems.forEach(item => {
                    if (category === 'all' || item.dataset.category === category) {
                        item.style.display = 'flex';
                        requestAnimationFrame(() => {
                            item.style.opacity = '1';
                        });
                    } else {
                        item.style.opacity = '0';
                        setTimeout(() => {
                            item.style.display = 'none';
                        }, 200);
                    }
                });
            });
        });
        if (filterButtons[0]) {
            filterButtons[0].click();
        }
    }
});