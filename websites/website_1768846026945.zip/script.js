document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".mobile-nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = siteNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        siteNav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  if (cookieBanner) {
    const storedConsent = window.localStorage.getItem("pfbcCookieConsent");
    if (storedConsent) {
      cookieBanner.classList.add("is-hidden");
    }
    const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
    const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
    const handleChoice = (choice) => {
      window.localStorage.setItem("pfbcCookieConsent", choice);
      cookieBanner.classList.add("is-hidden");
    };
    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => handleChoice("accepted"));
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => handleChoice("declined"));
    }
  }
});