document.addEventListener('DOMContentLoaded', () => {
  const banner = document.getElementById('cookie-banner');
  if (!banner) return;

  const consentStatus = localStorage.getItem('bilimqala-cookie-consent');

  if (consentStatus) {
    banner.classList.add('is-hidden');
  }

  const acceptBtn = banner.querySelector('[data-consent="accept"]');
  const declineBtn = banner.querySelector('[data-consent="decline"]');

  const handleConsent = (value) => {
    localStorage.setItem('bilimqala-cookie-consent', value);
    banner.classList.add('is-hidden');
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => handleConsent('accepted'));
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => handleConsent('declined'));
  }
});