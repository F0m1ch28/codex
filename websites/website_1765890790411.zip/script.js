(function () {
    const bannerSelector = '.cookie-banner';
    const acceptSelector = '[data-cookie-accept]';
    const declineSelector = '[data-cookie-decline]';
    const storageKey = 'iteb-cookie-consent';

    function setConsent(value) {
        try {
            localStorage.setItem(storageKey, value);
        } catch (error) {
            document.cookie = storageKey + '=' + encodeURIComponent(value) + ';path=/;max-age=' + 60 * 60 * 24 * 180;
        }
    }

    function getConsent() {
        try {
            return localStorage.getItem(storageKey);
        } catch (error) {
            const match = document.cookie.match(new RegExp('(^| )' + storageKey + '=([^;]+)'));
            return match ? decodeURIComponent(match[2]) : null;
        }
    }

    function initBanner() {
        const banner = document.querySelector(bannerSelector);
        if (!banner) {
            return;
        }
        const consent = getConsent();
        if (!consent) {
            banner.classList.add('visible');
        }
        const acceptBtn = banner.querySelector(acceptSelector);
        const declineBtn = banner.querySelector(declineSelector);

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                setConsent('accepted');
                banner.classList.remove('visible');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                setConsent('declined');
                banner.classList.remove('visible');
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initBanner);
    } else {
        initBanner();
    }
})();