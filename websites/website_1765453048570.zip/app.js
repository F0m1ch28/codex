"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector("[data-nav-toggle]");
  const nav = document.querySelector("[data-nav]");
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("is-open");
      navToggle.classList.toggle("is-open", isOpen);
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        nav.classList.remove("is-open");
        navToggle.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const formatCurrency = (value) =>
    value.toLocaleString("en-CA", {
      style: "currency",
      currency: "CAD",
      maximumFractionDigits: 0,
    });

  const formatPercent = (value) => `${value.toFixed(1)}%`;

  document.querySelectorAll("[data-kpi-form]").forEach((form) => {
    const output = form.querySelector("[data-kpi-output]");
    if (!output) return;

    const incrementalEl = output.querySelector("[data-kpi-incremental]");
    const netImpactEl = output.querySelector("[data-kpi-net-impact]");
    const roiEl = output.querySelector("[data-kpi-roi]");

    const inputs = {
      revenue: form.querySelector('[name="current-revenue"]'),
      margin: form.querySelector('[name="net-margin"]'),
      efficiency: form.querySelector('[name="efficiency-gain"]'),
      investment: form.querySelector('[name="system-investment"]'),
    };

    const updateOutput = () => {
      const revenue = Number(inputs.revenue?.value) || 0;
      const margin = Number(inputs.margin?.value) || 0;
      const efficiency = Number(inputs.efficiency?.value) || 0;
      const investment = Number(inputs.investment?.value) || 0;

      const incrementalRevenue = revenue * (efficiency / 100);
      const netImpact = incrementalRevenue * (margin / 100);
      const roi = investment > 0 ? (netImpact / investment) * 100 : 0;

      incrementalEl.textContent = formatCurrency(incrementalRevenue);
      netImpactEl.textContent = formatCurrency(netImpact);
      roiEl.textContent = formatPercent(roi);
    };

    Object.values(inputs).forEach((input) => {
      input?.addEventListener("input", updateOutput);
    });

    updateOutput();
  });

  document.querySelectorAll("[data-dashboard]").forEach((dashboard) => {
    const chart = dashboard.querySelector("[data-dashboard-chart]");
    const label = dashboard.querySelector("[data-dashboard-label]");
    const controls = dashboard.querySelectorAll("[data-dashboard-trigger]");

    if (!chart || !label || controls.length === 0) return;

    const renderPoints = (points) => {
      chart.innerHTML = "";
      points.forEach((value, index) => {
        const wrapper = document.createElement("div");
        wrapper.className = "chart-bar";
        wrapper.style.setProperty("--value", Math.max(4, Math.min(value, 100)));
        wrapper.setAttribute("data-value", value);

        const barLabel = document.createElement("span");
        barLabel.className = "chart-bar__label";
        barLabel.textContent = `W${index + 1}`;

        chart.appendChild(wrapper);
        chart.appendChild(barLabel);
      });
    };

    const activate = (button) => {
      controls.forEach((btn) => btn.classList.remove("is-active"));
      button.classList.add("is-active");
      const dataPoints = button.dataset.points
        .split(",")
        .map((n) => Number(n.trim()) || 0);
      renderPoints(dataPoints);
      label.textContent = button.dataset.label || "Dashboard view";
    };

    controls.forEach((button) => {
      button.addEventListener("click", () => activate(button));
    });

    activate(controls[0]);
  });

  const cookieBanner = document.getElementById("cookie-banner");
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
    const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
    const storageKey = "maple-cookie-consent";
    const storedPreference = localStorage.getItem(storageKey);

    if (!storedPreference) {
      cookieBanner.classList.add("is-visible");
    }

    const handleChoice = (value) => {
      localStorage.setItem(storageKey, value);
      cookieBanner.classList.remove("is-visible");
    };

    acceptBtn?.addEventListener("click", () => handleChoice("accepted"));
    declineBtn?.addEventListener("click", () => handleChoice("declined"));
  }
});