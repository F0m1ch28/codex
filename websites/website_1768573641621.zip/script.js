document.addEventListener("DOMContentLoaded", function () {
    const header = document.querySelector(".site-header");
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelectorAll(".nav-menu a");

    if (navToggle && header) {
        navToggle.addEventListener("click", () => {
            header.classList.toggle("nav-open");
        });
    }

    navLinks.forEach((link) => {
        link.addEventListener("click", () => {
            if (header.classList.contains("nav-open")) {
                header.classList.remove("nav-open");
            }
        });
    });

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptButton = document.querySelector(".cookie-accept");
    const declineButton = document.querySelector(".cookie-decline");
    const storageKey = "nigerhbfx-cookie-consent";

    if (cookieBanner) {
        const existingConsent = localStorage.getItem(storageKey);
        if (existingConsent) {
            cookieBanner.style.display = "none";
        }

        if (acceptButton) {
            acceptButton.addEventListener("click", () => {
                localStorage.setItem(storageKey, "accepted");
                cookieBanner.style.display = "none";
            });
        }

        if (declineButton) {
            declineButton.addEventListener("click", () => {
                localStorage.setItem(storageKey, "declined");
                cookieBanner.style.display = "none";
            });
        }
    }
});