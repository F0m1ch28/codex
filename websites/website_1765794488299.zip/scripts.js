document.addEventListener("DOMContentLoaded", function () {
  const banner = document.getElementById("cookieBanner");
  if (!banner) return;

  const acceptBtn = document.getElementById("cookieAccept");
  const declineBtn = document.getElementById("cookieDecline");
  const storageKey = "taid_cookie_preference";

  const preference = localStorage.getItem(storageKey);

  if (!preference) {
    setTimeout(() => {
      banner.classList.add("is-visible");
    }, 650);
  }

  const setPreference = (value) => {
    localStorage.setItem(storageKey, value);
    banner.classList.remove("is-visible");
  };

  acceptBtn.addEventListener("click", () => {
    setPreference("accepted");
  });

  declineBtn.addEventListener("click", () => {
    setPreference("declined");
  });
});