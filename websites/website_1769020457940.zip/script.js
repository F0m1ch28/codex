document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");
  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      primaryNav.classList.toggle("nav-open");
    });
  }

  const cookieBanner = document.getElementById("cookieBanner");
  if (cookieBanner) {
    const storedChoice = localStorage.getItem("adaraCookieChoice");
    if (storedChoice) {
      cookieBanner.style.display = "none";
    } else {
      cookieBanner.removeAttribute("hidden");
    }

    const acceptBtn = cookieBanner.querySelector("[data-cookie-consent='accept']");
    const declineBtn = cookieBanner.querySelector("[data-cookie-consent='decline']");

    const handleChoice = (choice) => {
      localStorage.setItem("adaraCookieChoice", choice);
      cookieBanner.style.display = "none";
    };

    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => handleChoice("accepted"));
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => handleChoice("declined"));
    }
  }
});