document.addEventListener("DOMContentLoaded", function () {
  const cookieBanner = document.querySelector(".cookie-banner");
  if (!cookieBanner) return;

  const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
  const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
  const status = localStorage.getItem("cookieConsent");

  if (!status) {
    cookieBanner.classList.add("active");
  }

  acceptBtn.addEventListener("click", function () {
    localStorage.setItem("cookieConsent", "accepted");
    cookieBanner.classList.remove("active");
  });

  declineBtn.addEventListener("click", function () {
    localStorage.setItem("cookieConsent", "declined");
    cookieBanner.classList.remove("active");
  });
});