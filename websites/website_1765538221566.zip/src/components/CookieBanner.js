import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'toy-delights-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem(COOKIE_KEY);
    if (!storedConsent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (choice) => {
    localStorage.setItem(COOKIE_KEY, choice);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie melding">
      <div className={styles.content}>
        <h2>Koekjes bij de thee?</h2>
        <p>
          Wij gebruiken cookies om onze speelervaring te verbeteren, bezoek te analyseren en warme, persoonlijke service te bieden.
          Kies zelf waarmee je je prettig voelt.
        </p>
        <div className={styles.actions}>
          <button onClick={() => handleConsent('accepted')} className={styles.accept}>
            Accepteren
          </button>
          <button onClick={() => handleConsent('declined')} className={styles.decline}>
            Weigeren
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;