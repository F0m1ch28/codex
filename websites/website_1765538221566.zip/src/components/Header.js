import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isShrunk, setIsShrunk] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsShrunk(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${isShrunk ? styles.shrunk : ''}`}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} aria-label="Toy Delights - startpagina">
          <span className={styles.logoIcon} aria-hidden="true">✨</span>
          <span className={styles.logoText}>Toy Delights</span>
        </NavLink>

        <button
          className={styles.menuToggle}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-expanded={menuOpen}
          aria-controls="hoofdmenu"
          aria-label={menuOpen ? 'Sluit navigatie' : 'Open navigatie'}
        >
          <span />
          <span />
          <span />
        </button>

        <nav
          id="hoofdmenu"
          className={`${styles.nav} ${menuOpen ? styles.open : ''}`}
          aria-label="Hoofdnavigatie"
        >
          <NavLink to="/" className={({ isActive }) => isActive ? styles.activeLink : ''} onClick={closeMenu}>
            Home
          </NavLink>
          <NavLink to="/gids" className={({ isActive }) => isActive ? styles.activeLink : ''} onClick={closeMenu}>
            Speelgoedgids
          </NavLink>
          <NavLink to="/programmas" className={({ isActive }) => isActive ? styles.activeLink : ''} onClick={closeMenu}>
            Programma's
          </NavLink>
          <NavLink to="/tools" className={({ isActive }) => isActive ? styles.activeLink : ''} onClick={closeMenu}>
            Tools
          </NavLink>
          <NavLink to="/blog" className={({ isActive }) => isActive ? styles.activeLink : ''} onClick={closeMenu}>
            Blog
          </NavLink>
          <NavLink to="/over-ons" className={({ isActive }) => isActive ? styles.activeLink : ''} onClick={closeMenu}>
            Over ons
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => isActive ? styles.activeLink : ''} onClick={closeMenu}>
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;