import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.brand}>
          <div className={styles.logoCircle} aria-hidden="true">🎠</div>
          <div>
            <h2>Toy Delights</h2>
            <p>
              Speelgoed dat het hart verwarmt en nieuwsgierigheid prikkelt. Vanuit Brussel verspreiden we speelvreugde door heel België.
            </p>
          </div>
        </div>

        <div className={styles.columns}>
          <div>
            <h3>Navigatie</h3>
            <ul>
              <li><NavLink to="/">Home</NavLink></li>
              <li><NavLink to="/gids">Speelgoedgids</NavLink></li>
              <li><NavLink to="/programmas">Programma's</NavLink></li>
              <li><NavLink to="/tools">Educatieve Tools</NavLink></li>
              <li><NavLink to="/blog">Blog</NavLink></li>
              <li><NavLink to="/over-ons">Over ons</NavLink></li>
              <li><NavLink to="/contact">Contact</NavLink></li>
            </ul>
          </div>

          <div>
            <h3>Contact</h3>
            <ul className={styles.contactList}>
              <li>
                <span className={styles.contactLabel}>Adres:</span>
                Toy Delights, Speelgoedstraat 123, 1000 Brussel, België
              </li>
              <li>
                <span className={styles.contactLabel}>Telefoon:</span>
                <a href="tel:+3221234567">+32 2 123 45 67</a>
              </li>
              <li>
                <span className={styles.contactLabel}>E-mail:</span>
                <a href="mailto:info@toydelights.be">info@toydelights.be</a>
              </li>
            </ul>
          </div>

          <div>
            <h3>Documenten</h3>
            <ul>
              <li><NavLink to="/algemene-voorwaarden">Algemene voorwaarden</NavLink></li>
              <li><NavLink to="/privacybeleid">Privacybeleid</NavLink></li>
              <li><NavLink to="/cookiebeleid">Cookiebeleid</NavLink></li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>&copy; {year} Toy Delights. Alle rechten voorbehouden.</p>
      </div>
    </footer>
  );
};

export default Footer;