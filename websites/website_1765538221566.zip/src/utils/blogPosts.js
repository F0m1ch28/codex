const blogPosts = [
  {
    slug: 'het-belang-van-vrij-spelen',
    title: 'Het belang van vrij spelen in een druk schema',
    date: '12 september 2023',
    readtime: '6 min leestijd',
    summary: 'Hoe je micro-momenten van fantasie inbouwt wanneer de agenda vol staat met hobby’s en huiswerk.',
    content: [
      'Vrij spelen is geen luxe, maar een basisbehoefte die kinderen helpt emoties te verwerken en creatief te denken. Toch is de agenda van veel gezinnen volgeladen.',
      'Start met het creëren van speelvensters: 20 minuten na school zonder schermen of opdrachten. Bied open materiaal zoals blokken, poppen of verkleedkleren en observeer zonder te sturen.',
      'Durf activiteiten te schrappen wanneer je merkt dat je kind moe is. Vrije tijd levert vaak meer rust op dan een extra naschoolse activiteit.',
      'Laat kinderen zelf opruimen op hun tempo en sluit af met een kort gesprek over hun spel. Zo voelen ze zich gezien en gehoord.'
    ]
  },
  {
    slug: 'ontwikkelingsspeelgoed-voor-peuters',
    title: 'Ontwikkelingsspeelgoed voor peuters met een gevoelig karakter',
    date: '2 augustus 2023',
    readtime: '8 min leestijd',
    summary: 'Selectie van materialen en spelvormen die peuters met prikkelgevoeligheid helpen floreren.',
    content: [
      'Peuters met een gevoelig karakter hebben behoefte aan zachte overgangen en voorspelbaarheid. Kies speelgoed dat tactiel rijk is maar niet overweldigend.',
      'Verzamel sets met natuurlijke kleuren en verschillende texturen. Combineer bijvoorbeeld houten kralen met vilten figuren en zachte stoffen.',
      'Bied rollenspel aan waarin het kind gevoelens kan uitdrukken. Poppen met neutrale gezichten laten ruimte voor eigen interpretatie.',
      'Creëer een rustig hoekje met dempende verlichting en zachte muziek zodat het kind kan ontladen na intense momenten.'
    ]
  },
  {
    slug: 'stem-projecten-voor-gezinnen',
    title: 'STEM-projecten die gezinnen dichter bij elkaar brengen',
    date: '18 juli 2023',
    readtime: '7 min leestijd',
    summary: 'Samen experimenteren schept verbinding en ontwikkelt probleemoplossend vermogen. Ontdek drie projecten voor elke leeftijd.',
    content: [
      'STEM hoeft niet ingewikkeld te zijn. Start met huis-tuin-en-keukenexperimenten zoals een vulkaan van baksoda voor kleuters.',
      'Voor lagere schoolkinderen kan je bruggen bouwen met recyclagemateriaal. Bespreek welke vormen het meest stabiel zijn.',
      'Tieners kan je uitdagen om een simpele robot te programmeren met blokcode. Laat hen uitleggen wat ze doen zodat iedereen mee is.',
      'Belangrijk is samen reflecteren: wat werkte goed, wat doen we anders, en hoe voelde iedereen zich tijdens het experiment?'
    ]
  },
  {
    slug: 'samen-speelgoed-duurzamer-maken',
    title: 'Samen speelgoed duurzamer maken',
    date: '30 mei 2023',
    readtime: '5 min leestijd',
    summary: 'Van reparatiecafés tot speelgoedruil: stappen om minder weg te gooien en meer te delen.',
    content: [
      'Duurzaamheid start met bewust kiezen. Koop minder, maar kies voor kwaliteit die je kan herstellen.',
      'Organiseer met buren een ruilnamiddag. Leg duidelijke regels vast over de staat van het speelgoed.',
      'Leer kinderen waarom zorg dragen voor hun speelgoed belangrijk is. Repareer samen kleine beschadigingen.',
      'Lever kapot speelgoed in bij herstelpunten of recycleersites zodat materialen een tweede leven krijgen.'
    ]
  }
];

export default blogPosts;