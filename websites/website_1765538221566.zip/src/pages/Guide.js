import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Guide.module.css';

const ageGroups = [
  {
    title: '0-12 maanden',
    description: 'Een zachte wereld vol contrast, textuur en warme klanken.',
    development: [
      'Zintuiglijke prikkels introduceren (zien, voelen, horen)',
      'Grove motoriek stimuleren via rollen en reiken',
      'Veilige hechting ondersteunen met voorspelbare rituelen'
    ],
    toys: [
      'Zacht knuffeldoekje met verschillende stofjes',
      'Rammelaar met natuurlijke materialen',
      'Activiteitenmat met contrastkleuren en spiegel'
    ]
  },
  {
    title: '1-3 jaar',
    description: 'Kleine ontdekkingsreizigers die elke dag nieuwe woorden en bewegingen oefenen.',
    development: [
      'Fijne motoriek verfijnen door stapelen en sorteren',
      'Eerste rollenspelen en symbolisch denken stimuleren',
      'Taalrijke omgeving bieden vol benoemen en zingen'
    ],
    toys: [
      'Stapeltoren met verschillende afmetingen',
      'Trekspeelgoed dat het stappen ondersteunt',
      'Houten puzzels met knoppen voor kleine handen'
    ]
  },
  {
    title: '3-6 jaar',
    description: 'Fantasie explodeert en de wereld wordt een speelveld vol verhalen.',
    development: [
      'Creatief denken en probleemoplossing aanmoedigen',
      'Samen leren spelen en beurt nemen',
      'Hand-oogcoördinatie en fijne motoriek versterken'
    ],
    toys: [
      'Rollenspelsets zoals een dokterskoffer of winkel',
      'Kunstmaterialen: uitwasbare verf, klei, kleurpotloden',
      'Magnetische constructies voor ruimtelijk inzicht'
    ]
  },
  {
    title: '6+ jaar',
    description: 'Groeiende zelfstandigheid en nieuwsgierigheid naar hoe dingen werken.',
    development: [
      'Logisch denken en analytische vaardigheden prikkelen',
      'Doorzettingsvermogen opbouwen met uitdagende projecten',
      'Samenwerken en delen binnen vriendengroepen'
    ],
    toys: [
      'STEM bouwkits met motoren en licht',
      'Strategische bordspellen met duidelijke regels',
      'Wetenschapssets voor experimenten thuis'
    ]
  }
];

const GuidePage = () => {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <>
      <Helmet>
        <title>Speelgoedgids | Toy Delights</title>
        <meta
          name="description"
          content="Vind in onze speelgoedgids de beste tips per leeftijdsgroep. Toy Delights begeleidt je van eerste stapjes tot nieuwsgierige onderzoekers."
        />
      </Helmet>
      <section className={styles.guideIntro}>
        <h1>Onze Speelgoedgids per Levensfase</h1>
        <p>
          Elk kind ontwikkelt zich in eigen tempo. Deze gids biedt zachte ankerpunten waarmee je speelgoed
          selecteert dat aansluit bij de behoefte van jouw gezin. Klik op een leeftijdsblok voor tips, doelen en een selectie warme favorieten.
        </p>
      </section>

      <section className={styles.accordion} aria-label="Leeftijdsgroepen">
        {ageGroups.map((group, index) => {
          const isOpen = openIndex === index;
          return (
            <article className={`${styles.panel} ${isOpen ? styles.open : ''}`} key={group.title}>
              <button
                className={styles.panelHeader}
                onClick={() => setOpenIndex(isOpen ? -1 : index)}
                aria-expanded={isOpen}
              >
                <div>
                  <h2>{group.title}</h2>
                  <p>{group.description}</p>
                </div>
                <span aria-hidden="true">{isOpen ? '−' : '+'}</span>
              </button>
              {isOpen && (
                <div className={styles.panelBody}>
                  <div>
                    <h3>Ontwikkelingsfocus</h3>
                    <ul>
                      {group.development.map(item => <li key={item}>{item}</li>)}
                    </ul>
                  </div>
                  <div>
                    <h3>Aanraders</h3>
                    <ul>
                      {group.toys.map(item => <li key={item}>{item}</li>)}
                    </ul>
                  </div>
                </div>
              )}
            </article>
          );
        })}
      </section>
    </>
  );
};

export default GuidePage;