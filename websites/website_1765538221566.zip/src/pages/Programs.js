import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Programs.module.css';

const ProgramsPage = () => {
  return (
    <>
      <Helmet>
        <title>Programma's &amp; Veiligheid | Toy Delights</title>
        <meta
          name="description"
          content="Lees hoe Toy Delights werkt met veiligheidscertificaten, eco-partners en langdurige kwaliteitsprogramma's voor speelgoed."
        />
      </Helmet>
      <section className={styles.header}>
        <h1>Onze Programma's voor Veiligheid en Duurzaamheid</h1>
        <p>
          Toy Delights bouwt bruggen tussen gezinnen, lokale scholen en eco-bewuste producenten. We combineren internationale normen
          met een warme Belgische insteek zodat elk product vertrouwen uitstraalt.
        </p>
      </section>

      <section className={styles.programGrid}>
        <article>
          <h2>Veiligheidsatelier</h2>
          <p>
            In ons atelier in Brussel onderwerpen we elk product aan een intensief testtraject. We volgen onder meer de EN71-normen,
            controleren op kleine onderdelen, chemische stoffen en slijtage. Ouders ontvangen transparante rapporten zodat ze precies weten wat hun kind in handen krijgt.
          </p>
          <ul>
            <li>15-punten checklist voor mechanische en fysieke veiligheid</li>
            <li>Ultrasoon gereinigde testomgeving</li>
            <li>In-house kinderfysioloog voor ergonomische beoordeling</li>
          </ul>
        </article>

        <article>
          <h2>Eco Partnerschap</h2>
          <p>
            We selecteren producenten die inzetten op hernieuwbare materialen, eerlijke arbeidsomstandigheden en korte ketens.
            Elk partnerschap bevat meetbare doelstellingen rond recyclage en energieverbruik.
          </p>
          <ul>
            <li>Gebruik van FSC-gecertificeerd hout en bioplastics</li>
            <li>Herbruikbare verpakkingen met minimale inkt</li>
            <li>Jaarlijkse audit van CO₂-voetafdruk en watergebruik</li>
          </ul>
        </article>

        <article>
          <h2>Educatieve Co-creatie</h2>
          <p>
            Met leerkrachten, logopedisten en ouders co-creëren we speeltrajecten die aansluiten bij Vlaamse en Waalse leerplannen.
            Zo krijgt elk product een praktische handleiding boordevol spelideeën.
          </p>
          <ul>
            <li>Workshops voor leerkrachten en zorgprofessionals</li>
            <li>Leeftijdsgebonden speelplannen met leerdoelen</li>
            <li>Toegankelijke video-tutorials voor thuisgebruik</li>
          </ul>
        </article>
      </section>

      <section className={styles.commitment}>
        <div>
          <h2>Ons engagement in drie beloftes</h2>
          <p>
            We blijven luisteren naar gezinnen en passen onze programma's aan waar nodig. Feedback wordt verzameld via ouderpanels,
            scholen en kindertherapeuten, en vertaald naar concrete verbeteringen.
          </p>
        </div>
        <div className={styles.promiseList}>
          <article>
            <h3>Transparantie</h3>
            <p>Volledige inzage in materiaalbronnen, testresultaten en certificeringen.</p>
          </article>
          <article>
            <h3>Inclusiviteit</h3>
            <p>Speelgoed dat verschillende culturele achtergronden en talenten weerspiegelt.</p>
          </article>
          <article>
            <h3>Langdurige ondersteuning</h3>
            <p>Van aftersales tot reparatieadvies: we blijven beschikbaar na elke aankoop.</p>
          </article>
        </div>
      </section>
    </>
  );
};

export default ProgramsPage;