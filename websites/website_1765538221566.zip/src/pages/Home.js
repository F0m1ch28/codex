import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const featuredToys = [
  {
    title: 'Wonderlijke Bouwblokken',
    age: '2-4 jaar',
    description: 'Stimuleer motoriek en fantasie met duurzame houten blokken in vrolijke kleuren.',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Muzikale Regenboog',
    age: '3-6 jaar',
    description: 'Een xylofoon met lichtspel die ritmegevoel en luistervaardigheden versterkt.',
    image: 'https://images.unsplash.com/photo-1511452885600-a3d2c9148e58?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Ontdek-doos Safari',
    age: '4-7 jaar',
    description: 'Rollenspelset met vriendelijke dieren en verhalenkaartjes voor eindeloos speelplezier.',
    image: 'https://images.unsplash.com/photo-1502980426475-b83966705988?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'STEM Robotvriend',
    age: '6-9 jaar',
    description: 'Leer coderen door bewegingen en lichtjes te programmeren via kindvriendelijke kaarten.',
    image: 'https://images.unsplash.com/photo-1588072432836-e10032774350?auto=format&fit=crop&w=900&q=80'
  }
];

const newArrivals = [
  {
    title: 'Dromerige Stapeltoren',
    age: '0-12 maanden',
    description: 'Zachte siliconen ringen die veilig beetgepakt kunnen worden en het zicht prikkelen.',
    image: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Groene Keukenset',
    age: '3-6 jaar',
    description: 'Gemaakt van gerecycleerde materialen met focus op rollen, tellen en delen.',
    image: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Sterrenhemel Projector',
    age: '2-5 jaar',
    description: 'Rustige lichtprojecties met begeleidende verhaaltjes voor bedtijdrituelen.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=80'
  }
];

const statsData = [
  { value: '12.000+', label: 'Blije families in België' },
  { value: '320', label: 'Geteste speelgoedcollecties' },
  { value: '28', label: 'Educatieve partners' },
  { value: '100%', label: 'Veiligheidstesten geslaagd' }
];

const HomePage = () => {
  const [highlightIndex, setHighlightIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setHighlightIndex(prev => (prev + 1) % statsData.length);
    }, 4500);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <Helmet>
        <title>Toy Delights | Speelgoed dat harten raakt</title>
        <meta
          name="description"
          content="Ontdek het warme en veilige speelgoedaanbod van Toy Delights. Van duurzame bouwsets tot interactieve STEM-projecten, met zorg geselecteerd voor Belgische gezinnen."
        />
      </Helmet>
      <section className={styles.heroSection} aria-labelledby="hero-title">
        <div className={styles.heroContent}>
          <span className={styles.heroTag}>Vanuit Brussel met liefde voor spelen</span>
          <h1 id="hero-title">Samen bouwen we aan verwondering en vertrouwen</h1>
          <p>
            Toy Delights is jouw betrouwbare kompas voor veilig, duurzaam en leerrijk speelgoed.
            Wij gidsen ouders in elke groeifase en laten kinderen volop stralen in hun ontdekkingsreis.
          </p>
          <div className={styles.heroActions}>
            <Link to="/gids" className={styles.ctaPrimary}>
              Ontdek de Speelgoedgids
            </Link>
            <Link to="/contact" className={styles.ctaSecondary}>
              Plan een persoonlijk advies
            </Link>
          </div>
          <div className={styles.heroAssurance}>
            <span aria-hidden="true">🛡️</span>
            <p>Elke selectie wordt intern getest op veiligheid, educatieve waarde en speelplezier.</p>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=1200&q=80"
            alt="Kind dat glimlachend speelt met educatief speelgoed"
          />
          <div className={styles.heroCard}>
            <h3>Elke dag speelgeluk</h3>
            <p>Van eerste lach tot grote sprongen: wij staan naast je gezin.</p>
          </div>
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Trots op onze impact">
        <div className={styles.statsGrid}>
          {statsData.map((item, index) => (
            <article
              key={item.label}
              className={`${styles.statCard} ${highlightIndex === index ? styles.statActive : ''}`}
            >
              <h3>{item.value}</h3>
              <p>{item.label}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.featuredSection}>
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Uitgelichte Speelgoedselecties</h2>
          <p className="sectionSubtitle">
            Zorgvuldig gekozen favorieten die de ontwikkeling voeden én de fantasie laten rondvliegen.
          </p>
        </div>
        <div className={styles.cardGrid}>
          {featuredToys.map(toy => (
            <article key={toy.title} className={styles.toyCard}>
              <div className={styles.imageWrapper}>
                <img src={toy.image} alt={`Speelgoed: ${toy.title}`} />
              </div>
              <div className={styles.toyContent}>
                <span className={styles.ageBadge}>{toy.age}</span>
                <h3>{toy.title}</h3>
                <p>{toy.description}</p>
                <button type="button" className={styles.cardButton} aria-label={`Lees meer over ${toy.title}`}>
                  Laat je inspireren
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.newArrivalSection}>
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Nieuwe Aanwinsten</h2>
          <p className="sectionSubtitle">
            Vers van de pers en klaar om nieuwe avonturen te creëren in Belgische speelkamers.
          </p>
        </div>
        <div className={styles.arrivalGrid}>
          {newArrivals.map(toy => (
            <article key={toy.title} className={styles.arrivalCard}>
              <img src={toy.image} alt={`Nieuw speelgoed: ${toy.title}`} />
              <div>
                <span className={styles.ageBadge}>{toy.age}</span>
                <h3>{toy.title}</h3>
                <p>{toy.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.whySection}>
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Waarom Toy Delights?</h2>
          <p className="sectionSubtitle">
            Omdat we ouders ontzorgen en kinderen laten groeien met zorg, kwaliteit en verwondering.
          </p>
        </div>
        <div className={styles.whyGrid}>
          <article>
            <div className={styles.whyIcon} aria-hidden="true">🧪</div>
            <h3>Diepgaande veiligheid</h3>
            <p>
              Elk stuk speelgoed doorloopt vijftien testmomenten op duurzaamheid, materialen en gebruiksgemak voor kleine handen.
            </p>
          </article>
          <article>
            <div className={styles.whyIcon} aria-hidden="true">🎓</div>
            <h3>Educatieve kracht</h3>
            <p>
              We koppelen ontwikkelingsdoelen aan speelideeën, zodat je altijd weet welke vaardigheden worden gestimuleerd.
            </p>
          </article>
          <article>
            <div className={styles.whyIcon} aria-hidden="true">🌱</div>
            <h3>Liefde voor de planeet</h3>
            <p>
              Van FSC-hout tot gerecyclede kunststoffen: onze partners bewijzen dat milieuvriendelijk en stevig perfect samengaan.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.interactiveSection}>
        <div className={styles.interactiveContent}>
          <h2>Interactieve Fun</h2>
          <p>
            Duik in onze digitale speelkamer vol kleurtests, verhaalmakers en mini-puzzels.
            Perfect voor een rustig moment thuis of een klasactiviteit vol lachjes.
          </p>
          <Link to="/tools" className={styles.ctaPrimary}>
            Ga naar de tools
          </Link>
        </div>
        <div className={styles.interactiveVisual}>
          <img
            src="https://images.unsplash.com/photo-1522176273495-54f08a0d9299?auto=format&fit=crop&w=1000&q=80"
            alt="Twee kinderen die samenwerken aan een creatief project"
          />
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Warmte uit onze gemeenschap</h2>
          <p className="sectionSubtitle">Beluister de verhalen van gezinnen die we begeleiden.</p>
        </div>
        <div className={styles.testimonialGrid}>
          <article className={styles.testimonialCard}>
            <div className={styles.quoteIcon} aria-hidden="true">“</div>
            <p>
              Dankzij Toy Delights voel ik me als jonge ouder niet langer verloren in het oerwoud van speelgoed.
              Elk pakket dat we ontvangen, heeft een duidelijke handleiding en warme tips.
            </p>
            <span className={styles.testimonialName}>Sarah en Noor (Gent)</span>
          </article>
          <article className={styles.testimonialCard}>
            <div className={styles.quoteIcon} aria-hidden="true">“</div>
            <p>
              De ondersteuning voor scholen is fantastisch. Onze kleuterklas geniet van circulaire speelsets die makkelijk te reinigen zijn.
            </p>
            <span className={styles.testimonialName}>Meester Tom (Brussel)</span>
          </article>
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className={styles.blogHeader}>
          <h2>Laatste inzichten uit de blog</h2>
          <p>Praktische verhalen voor elke speelfase en inspirerende activiteiten voor thuis.</p>
          <Link to="/blog" className={styles.ctaSecondary}>
            Bekijk alle artikels
          </Link>
        </div>
        <div className={styles.blogCards}>
          <article>
            <span className={styles.blogDate}>12 september 2023</span>
            <h3>Het belang van vrij spelen in een druk schema</h3>
            <p>
              Leren hoe je micro-momenten van fantasie inbouwt tussen zwemles, huiswerk en gezinsmaaltijden.
            </p>
            <Link to="/blog/het-belang-van-vrij-spelen" className={styles.blogLink}>
              Lees Meer →
            </Link>
          </article>
          <article>
            <span className={styles.blogDate}>2 augustus 2023</span>
            <h3>Ontwikkelingsspeelgoed voor peuters met een gevoelig karakter</h3>
            <p>
              Welke texturen, kleuren en geluiden helpen peuters zich veilig en zacht gestimuleerd te voelen?
            </p>
            <Link to="/blog/ontwikkelingsspeelgoed-voor-peuters" className={styles.blogLink}>
              Lees Meer →
            </Link>
          </article>
          <article>
            <span className={styles.blogDate}>18 juli 2023</span>
            <h3>STEM-projecten die gezinnen dichter bij elkaar brengen</h3>
            <p>
              Gezamenlijke uitdagingen die techniek toegankelijk maken en samenwerken bevorderen.
            </p>
            <Link to="/blog/stem-projecten-voor-gezinnen" className={styles.blogLink}>
              Lees Meer →
            </Link>
          </article>
        </div>
      </section>
    </>
  );
};

export default HomePage;