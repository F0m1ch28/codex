import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Blog.module.css';
import blogPosts from '../utils/blogPosts';

const BlogPage = () => {
  return (
    <>
      <Helmet>
        <title>Blog &amp; inspiratie | Toy Delights</title>
        <meta
          name="description"
          content="Lees warme verhalen en praktische tips over spelen, leren en verbinden. Toy Delights deelt inzichten van experten en ouders."
        />
      </Helmet>
      <section className={styles.header}>
        <h1>Spelenderwijs leren &amp; leven</h1>
        <p>
          Elk verhaal in onze blog is geschreven of samengesteld in samenwerking met kinderexperten, ouders en leerkrachten.
          We vieren kleine overwinningen en reiken tools aan voor uitdagende momenten.
        </p>
      </section>

      <section className={styles.blogList}>
        {blogPosts.map(post => (
          <article key={post.slug} className={styles.blogCard}>
            <div className={styles.meta}>
              <span>{post.date}</span>
              <span>{post.readtime}</span>
            </div>
            <h2>{post.title}</h2>
            <p>{post.summary}</p>
            <Link to={`/blog/${post.slug}`} className={styles.readMore}>
              Lees Meer
            </Link>
          </article>
        ))}
      </section>
    </>
  );
};

export default BlogPage;