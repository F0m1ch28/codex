import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Hanne De Wilde',
    role: 'Oprichtster & Speelgoedcurator',
    description: 'Onderwijspedagoge met een passie voor duurzame materialen en speelse ruimtes.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Amir Ben Salah',
    role: 'Head of Veiligheid',
    description: 'Ingenieur en vader van twee die internationale normen vertaalt naar tastbare geruststelling.',
    image: 'https://images.unsplash.com/photo-1520342868574-5fa3804e551c?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Lotte Van Acker',
    role: 'Community & Oudercoaching',
    description: 'Kinderpsychologe die ouderpanels begeleidt en warme trajecten uitwerkt.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80'
  }
];

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>Over Toy Delights | Missie &amp; team</title>
        <meta
          name="description"
          content="Leer Toy Delights kennen: onze missie, waarden en het team dat veiligheid en speelplezier centraal plaatst voor Belgische gezinnen."
        />
      </Helmet>
      <section className={styles.hero}>
        <div>
          <h1>Een hart voor spel, geworteld in België</h1>
          <p>
            Toy Delights werd geboren uit een eenvoudige vraag: hoe kiezen we speelgoed dat zowel veilig,
            duurzaam als betekenisvol is? Sinds 2011 beantwoorden we die vraag met een glimlach, een luisterend oor en een
            zorgvuldig samengestelde collectie.
          </p>
        </div>
        <img
          src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1000&q=80"
          alt="Team van Toy Delights dat samenwerkt aan een speelgoedcollectie"
        />
      </section>

      <section className={styles.values}>
        <h2>Onze waarden</h2>
        <div className={styles.valueGrid}>
          <article>
            <h3>Verbinding</h3>
            <p>We brengen gezinnen, scholen en producenten samen rondom speelse groei.</p>
          </article>
          <article>
            <h3>Zachtheid</h3>
            <p>Elke beslissing is doordrenkt met empathie voor kinderen en hun unieke tempo.</p>
          </article>
          <article>
            <h3>Verantwoordelijkheid</h3>
            <p>We kiezen voor partners die eerlijke lonen betalen en recyclage ernstig nemen.</p>
          </article>
        </div>
      </section>

      <section className={styles.timeline}>
        <h2>Onze reis tot nu</h2>
        <ul>
          <li>
            <span>2011</span>
            <p>Opening van de eerste speelse showroom in Brussel na een rondreis langs Europese speelgoedmakers.</p>
          </li>
          <li>
            <span>2016</span>
            <p>Start van het veiligheidslab en samenwerking met kinderfysiologen en logopedisten.</p>
          </li>
          <li>
            <span>2020</span>
            <p>Lancering van circulaire huurconcepten voor kinderopvang en kleuterklassen.</p>
          </li>
          <li>
            <span>2023</span>
            <p>Uitbouw van digitale tools en ouderworkshops met hybride format.</p>
          </li>
        </ul>
      </section>

      <section className={styles.team}>
        <h2>Het team achter de glimlach</h2>
        <div className={styles.teamGrid}>
          {teamMembers.map(member => (
            <article key={member.name}>
              <img src={member.image} alt={`${member.name}, ${member.role}`} />
              <div>
                <h3>{member.name}</h3>
                <p className={styles.role}>{member.role}</p>
                <p>{member.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default AboutPage;