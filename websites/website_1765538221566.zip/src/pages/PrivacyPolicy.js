import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const PrivacyPolicyPage = () => (
  <>
    <Helmet>
      <title>Privacybeleid | Toy Delights</title>
      <meta
        name="description"
        content="Ontdek hoe Toy Delights zorgvuldig omgaat met persoonsgegevens en privacy."
      />
    </Helmet>
    <section className={styles.legal}>
      <h1>Privacybeleid</h1>
      <p>
        We behandelen je persoonsgegevens met de grootste zorg. Toy Delights verzamelt enkel data die nodig is om je
        bestellingen te verwerken, advies te geven of onze community te informeren.
      </p>
      <h2>Welke gegevens verzamelen we?</h2>
      <ul>
        <li>Contactgegevens zoals naam, adres, e-mail en telefoonnummer.</li>
        <li>Aankoopgeschiedenis om passende aanbevelingen te kunnen doen.</li>
        <li>Feedback uit enquêtes voor productverbetering.</li>
      </ul>
      <h2>Hoe gebruiken we je gegevens?</h2>
      <p>
        Gegevens worden gebruikt om bestellingen uit te voeren, klantenservice te leveren en je te informeren over relevante activiteiten.
        We delen geen gegevens met derden voor marketingdoeleinden zonder expliciete toestemming.
      </p>
      <h2>Je rechten</h2>
      <p>
        Je hebt het recht om je gegevens in te zien, te corrigeren of te laten verwijderen. Stuur hiervoor een e-mail naar privacy@toydelights.be.
      </p>
    </section>
  </>
);

export default PrivacyPolicyPage;