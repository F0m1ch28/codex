import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const CookiePolicyPage = () => (
  <>
    <Helmet>
      <title>Cookiebeleid | Toy Delights</title>
      <meta
        name="description"
        content="Lees alles over het gebruik van cookies op de website van Toy Delights."
      />
    </Helmet>
    <section className={styles.legal}>
      <h1>Cookiebeleid</h1>
      <p>
        Onze website gebruikt cookies om de gebruikerservaring te verbeteren en inzichten te verwerven over het gebruik van onze pagina's.
        We plaatsen nooit cookies zonder jouw toestemming die niet noodzakelijk zijn voor de werking van de site.
      </p>
      <h2>Soorten cookies</h2>
      <ul>
        <li><strong>Functionele cookies:</strong> zorgen ervoor dat de website correct werkt.</li>
        <li><strong>Analytische cookies:</strong> helpen ons begrijpen welke pagina's het meest bezocht worden.</li>
        <li><strong>Voorkeurscookies:</strong> onthouden jouw taalkeuze en voorkeuren.</li>
      </ul>
      <h2>Cookie-instellingen beheren</h2>
      <p>
        Via onze cookiebanner kan je je voorkeuren aanpassen. Je kan cookies ook verwijderen in je browserinstellingen.
        Houd er rekening mee dat bepaalde functies dan minder goed kunnen werken.
      </p>
    </section>
  </>
);

export default CookiePolicyPage;