import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './BlogPost.module.css';
import blogPosts from '../utils/blogPosts';

const BlogPostPage = () => {
  const { slug } = useParams();
  const post = blogPosts.find(item => item.slug === slug);

  if (!post) {
    return (
      <section className={styles.notFound}>
        <h1>Artikel niet gevonden</h1>
        <p>We konden dit verhaal niet terugvinden. Probeer een andere blogpost of keer terug naar het overzicht.</p>
        <Link to="/blog" className={styles.backLink}>Terug naar de blog</Link>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{`${post.title} | Toy Delights`}</title>
        <meta name="description" content={post.summary} />
      </Helmet>
      <article className={styles.article}>
        <header className={styles.articleHeader}>
          <span className={styles.date}>{post.date}</span>
          <h1>{post.title}</h1>
          <p className={styles.summary}>{post.summary}</p>
        </header>
        <div className={styles.content}>
          {post.content.map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
        </div>
        <footer className={styles.articleFooter}>
          <Link to="/blog">← Terug naar alle artikelen</Link>
        </footer>
      </article>
    </>
  );
};

export default BlogPostPage;