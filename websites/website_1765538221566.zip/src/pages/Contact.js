import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    naam: '',
    email: '',
    bericht: ''
  });
  const [errors, setErrors] = useState({});
  const [feedback, setFeedback] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.naam.trim()) {
      newErrors.naam = 'Gelieve je naam in te vullen.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Gelieve je e-mailadres in te vullen.';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.email)) {
      newErrors.email = 'Dit lijkt geen geldig e-mailadres. Controleer even.';
    }
    if (!formData.bericht.trim()) {
      newErrors.bericht = 'Vertel ons waar we mee mogen helpen.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      setFeedback('');
      return;
    }
    setFeedback('Bedankt voor je bericht! We nemen binnen twee werkdagen contact op.');
    setFormData({ naam: '', email: '', bericht: '' });
    setErrors({});
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <>
      <Helmet>
        <title>Contact | Toy Delights</title>
        <meta
          name="description"
          content="Neem contact op met Toy Delights. We helpen je graag met persoonlijk speelgoedadvies voor jouw gezin of organisatie."
        />
      </Helmet>
      <section className={styles.contactSection}>
        <div className={styles.intro}>
          <h1>We luisteren graag naar jouw verhaal</h1>
          <p>
            Heb je een vraag over een product, een adviestraject nodig of wil je een samenwerking verkennen?
            Laat een bericht achter en we reageren met volle aandacht.
          </p>
        </div>
        <div className={styles.layout}>
          <form onSubmit={handleSubmit} noValidate>
            <label htmlFor="naam">Naam*</label>
            <input
              id="naam"
              name="naam"
              type="text"
              value={formData.naam}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={errors.naam ? 'true' : 'false'}
            />
            {errors.naam && <span className={styles.error}>{errors.naam}</span>}

            <label htmlFor="email">E-mail*</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={errors.email ? 'true' : 'false'}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}

            <label htmlFor="bericht">Bericht*</label>
            <textarea
              id="bericht"
              name="bericht"
              rows="6"
              value={formData.bericht}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={errors.bericht ? 'true' : 'false'}
            />
            {errors.bericht && <span className={styles.error}>{errors.bericht}</span>}

            <button type="submit">Verstuur</button>
            {feedback && <div className={styles.feedback} role="status">{feedback}</div>}
          </form>

          <aside className={styles.contactInfo}>
            <h2>Contactgegevens</h2>
            <ul>
              <li>
                <span>Adres</span>
                Toy Delights, Speelgoedstraat 123, 1000 Brussel, België
              </li>
              <li>
                <span>Telefoon</span>
                <a href="tel:+3221234567">+32 2 123 45 67</a>
              </li>
              <li>
                <span>E-mail</span>
                <a href="mailto:info@toydelights.be">info@toydelights.be</a>
              </li>
            </ul>
            <div className={styles.visitCard}>
              <h3>Openingsuren showroom</h3>
              <p>Ma - Vr: 09:30 - 17:30</p>
              <p>Zaterdag: 10:00 - 16:00</p>
              <p>Zondag en feestdagen: op afspraak</p>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
};

export default ContactPage;