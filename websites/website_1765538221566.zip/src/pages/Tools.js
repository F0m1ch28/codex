import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Tools.module.css';

const palette = [
  { color: '#FF6B6B', label: 'Zonsondergang Rood' },
  { color: '#FFD166', label: 'Zonnestraal Geel' },
  { color: '#87CEEB', label: 'Hemelblauw' },
  { color: '#8bd7c3', label: 'Mintgroen' },
  { color: '#6C5CE7', label: 'Dromerige Paars' }
];

const storyCharacters = ['Aiko de astronaut', 'Luna de leeuwin', 'Milo de muzikant', 'Zara de zoemer'];
const storySettings = ['een zwevende speelgoedwinkel', 'een kleurrijk bos', 'een regenbooglaboratorium', 'een strand met pratende schelpen'];
const storyTwists = ['vindt een verborgen melodie', 'redt een vriend met supergeduld', 'ontdekt een nieuwe kleur', 'bouwt een brug van vriendelijkheid'];

const puzzlePieces = [
  { id: 'vorm', label: 'Vormenheld', target: 'vorm' },
  { id: 'kleur', label: 'Kleurenkampioen', target: 'kleur' },
  { id: 'ritme', label: 'Ritmevriend', target: 'ritme' }
];

const ToolsPage = () => {
  const [activeColor, setActiveColor] = useState(palette[0]);
  const [story, setStory] = useState('');
  const [assignments, setAssignments] = useState({});
  const [completed, setCompleted] = useState(false);

  const generateStory = () => {
    const character = storyCharacters[Math.floor(Math.random() * storyCharacters.length)];
    const setting = storySettings[Math.floor(Math.random() * storySettings.length)];
    const twist = storyTwists[Math.floor(Math.random() * storyTwists.length)];
    setStory(
      `${character} reist naar ${setting} en ${twist}. Samen bedenken jullie een plan waardoor elke vriend een glimlach deelt.`
    );
  };

  const handleDrop = (event, target) => {
    event.preventDefault();
    const pieceId = event.dataTransfer.getData('text/plain');
    if (!pieceId) return;
    setAssignments(prev => {
      const updated = { ...prev, [target]: pieceId };
      const allMatched = ['vorm', 'kleur', 'ritme'].every(key => updated[key] === key);
      setCompleted(allMatched);
      return updated;
    });
  };

  const handleDragStart = (event, piece) => {
    event.dataTransfer.setData('text/plain', piece.target);
  };

  return (
    <>
      <Helmet>
        <title>Educatieve Tools | Toy Delights</title>
        <meta
          name="description"
          content="Speel met onze gratis online tools: kleurpaletten, verhalengenerator en een speelse puzzel die kinderen prikkelt tot leren."
        />
      </Helmet>
      <section className={styles.header}>
        <h1>Digitale Speeltafel</h1>
        <p>
          Hier vind je kleine, educatieve ervaringen die kinderen nieuwsgierig maken en ouders praktische handvatten geven.
          Alles is ontworpen om snel te starten, zonder installatie, en stimuleert creativiteit, taal en samenwerking.
        </p>
      </section>

      <section className={styles.palette}>
        <div className={styles.paletteIntro}>
          <h2>Kleurpalet voor mini-artiesten</h2>
          <p>Kies een kleur en zie hoe het moodboard tot leven komt. Gebruik het als startpunt voor een tekening of collage.</p>
        </div>
        <div className={styles.swatches} role="list" aria-label="Kleurenpalet">
          {palette.map(option => (
            <button
              key={option.color}
              onClick={() => setActiveColor(option)}
              style={{ backgroundColor: option.color }}
              className={`${styles.swatch} ${activeColor.color === option.color ? styles.swatchActive : ''}`}
              aria-label={`Selecteer kleur ${option.label}`}
            />
          ))}
        </div>
        <div className={styles.preview} style={{ backgroundColor: activeColor.color }}>
          <p>{activeColor.label}</p>
        </div>
      </section>

      <section className={styles.storyGenerator}>
        <h2>Verhalengenerator</h2>
        <p>
          Klik op de knop, lees het verhaaltje luidop en nodig je kind uit om het einde mee te verzinnen. Ideaal voor taalontwikkeling en empathie.
        </p>
        <button className={styles.generateButton} onClick={generateStory}>
          Maak een nieuw verhaal
        </button>
        {story && (
          <blockquote className={styles.storyOutput}>
            {story}
          </blockquote>
        )}
      </section>

      <section className={styles.puzzleSection}>
        <div>
          <h2>Teamwerk Puzzel</h2>
          <p>
            Sleep de kaartjes naar de juiste begeleiders. Elk kaartje sluit aan bij een vaardigheid die we met onze speelgoedcollecties versterken.
          </p>
        </div>
        <div className={styles.puzzleBoard}>
          <div className={styles.draggables}>
            {puzzlePieces.map(piece => (
              <div
                key={piece.id}
                draggable
                onDragStart={(event) => handleDragStart(event, piece)}
                className={styles.draggable}
                role="button"
                tabIndex={0}
              >
                {piece.label}
              </div>
            ))}
          </div>
          <div className={styles.dropzones}>
            <div
              className={styles.dropzone}
              onDragOver={(event) => event.preventDefault()}
              onDrop={(event) => handleDrop(event, 'vorm')}
            >
              <h3>Vormencoach</h3>
              <p>{assignments.vorm ? 'Goed gedaan!' : 'Sleep hier de juiste helper.'}</p>
            </div>
            <div
              className={styles.dropzone}
              onDragOver={(event) => event.preventDefault()}
              onDrop={(event) => handleDrop(event, 'kleur')}
            >
              <h3>Kleurenexpert</h3>
              <p>{assignments.kleur ? 'Juist geplaatst!' : 'Zoek de kleurenkampioen.'}</p>
            </div>
            <div
              className={styles.dropzone}
              onDragOver={(event) => event.preventDefault()}
              onDrop={(event) => handleDrop(event, 'ritme')}
            >
              <h3>Ritmemeester</h3>
              <p>{assignments.ritme ? 'Perfecte match!' : 'Wie houdt het ritme bij?'}</p>
            </div>
          </div>
        </div>
        {completed && (
          <div className={styles.successMessage} role="status">
            Fantastisch teamwork! Vier dit moment met een high-five of een dansje.
          </div>
        )}
      </section>
    </>
  );
};

export default ToolsPage;