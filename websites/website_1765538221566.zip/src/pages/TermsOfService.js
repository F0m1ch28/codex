import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const TermsOfServicePage = () => (
  <>
    <Helmet>
      <title>Algemene voorwaarden | Toy Delights</title>
      <meta
        name="description"
        content="Lees de algemene voorwaarden van Toy Delights voor bestellingen, leveringen en serviceafspraken."
      />
    </Helmet>
    <section className={styles.legal}>
      <h1>Algemene voorwaarden</h1>
      <p>
        Deze voorwaarden bepalen de relatie tussen Toy Delights en haar klanten. Door gebruik te maken van onze diensten
        ga je akkoord met de onderstaande bepalingen. Voor vragen kan je steeds terecht bij ons team via info@toydelights.be.
      </p>
      <h2>Bestellingen &amp; betalingen</h2>
      <ul>
        <li>Alle prijzen zijn inclusief btw tenzij anders vermeld.</li>
        <li>Bestellingen worden bevestigd via e-mail en zijn definitief na ontvangst van betaling.</li>
        <li>Gespreide betalingen voor professionele klanten zijn mogelijk na schriftelijke afspraak.</li>
      </ul>
      <h2>Levering &amp; retour</h2>
      <ul>
        <li>We leveren binnen België via betrouwbare logistieke partners met track &amp; trace.</li>
        <li>Je hebt 30 dagen bedenktijd voor ongebruikt speelgoed in originele verpakking.</li>
        <li>Veiligheids- en hygiëneproducten kunnen enkel worden geretourneerd indien ongeopend.</li>
      </ul>
      <h2>Aansprakelijkheid</h2>
      <p>
        Toy Delights waarborgt de veiligheid van haar producten conform Europese regelgeving. We vragen gebruikers om
        de leeftijdsindicaties te respecteren en toezicht te bieden waar nodig.
      </p>
    </section>
  </>
);

export default TermsOfServicePage;