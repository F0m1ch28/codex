import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/Home';
import GuidePage from './pages/Guide';
import ProgramsPage from './pages/Programs';
import ToolsPage from './pages/Tools';
import BlogPage from './pages/Blog';
import BlogPostPage from './pages/BlogPost';
import AboutPage from './pages/About';
import ContactPage from './pages/Contact';
import TermsOfServicePage from './pages/TermsOfService';
import PrivacyPolicyPage from './pages/PrivacyPolicy';
import CookiePolicyPage from './pages/CookiePolicy';
import ServicesPage from './pages/Services';
import styles from './App.module.css';

function App() {
  return (
    <div className={styles.appWrapper}>
      <a href="#hoofdinhoud" className={styles.skipLink}>
        Ga naar hoofdinhoud
      </a>
      <Header />
      <CookieBanner />
      <main id="hoofdinhoud" className={styles.mainContent}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/gids" element={<GuidePage />} />
          <Route path="/programmas" element={<ProgramsPage />} />
          <Route path="/diensten" element={<ServicesPage />} />
          <Route path="/tools" element={<ToolsPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/blog/:slug" element={<BlogPostPage />} />
          <Route path="/over-ons" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/algemene-voorwaarden" element={<TermsOfServicePage />} />
          <Route path="/privacybeleid" element={<PrivacyPolicyPage />} />
          <Route path="/cookiebeleid" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}

export default App;