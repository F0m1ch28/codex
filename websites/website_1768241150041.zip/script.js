document.addEventListener("DOMContentLoaded", function () {
    const yearSpan = document.querySelector(".current-year");
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const storedChoice = localStorage.getItem("genuscayqg_cookie_consent");

    if (cookieBanner && storedChoice) {
        cookieBanner.classList.add("hidden");
    }

    window.recordCookieChoice = function (choice) {
        localStorage.setItem("genuscayqg_cookie_consent", choice);
        if (cookieBanner) {
            cookieBanner.classList.add("hidden");
        }
    };

    const cookieButtons = document.querySelectorAll("[data-cookie-choice]");
    cookieButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            const choice = this.getAttribute("data-cookie-choice");
            recordCookieChoice(choice);
        });
    });
});