document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.getElementById('nav-toggle');
  const navMenu = document.getElementById('primary-navigation');
  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('active');
      document.body.classList.toggle('modal-open', !expanded);
    });

    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        navToggle.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('modal-open');
      });
    });
  }

  const yearElement = document.getElementById('current-year');
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');
  const cookieKey = 'planresearchCookieConsent';

  const setCookiePreference = value => {
    try {
      localStorage.setItem(cookieKey, value);
    } catch (error) {
      console.error('Unable to access localStorage', error);
    }
  };

  const getCookiePreference = () => {
    try {
      return localStorage.getItem(cookieKey);
    } catch (error) {
      console.error('Unable to access localStorage', error);
      return null;
    }
  };

  if (cookieBanner) {
    const preference = getCookiePreference();
    if (!preference) {
      cookieBanner.classList.add('show');
    }

    const handleChoice = choice => {
      setCookiePreference(choice);
      cookieBanner.classList.remove('show');
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => handleChoice('accepted'));
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', () => handleChoice('declined'));
    }
  }

  const toast = document.getElementById('form-toast');
  const showToast = message => {
    if (!toast) return;
    const [titleEl, messageEl] = toast.children;
    if (titleEl && titleEl.tagName === 'STRONG') {
      titleEl.textContent = 'Message sent';
    }
    if (messageEl) {
      messageEl.textContent = message;
    }
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
    }, 2600);
  };

  const forms = document.querySelectorAll('form.js-contact-form');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      showToast('Redirecting to confirmation page.');
      setTimeout(() => {
        window.location.href = form.action || 'thank-you.html';
      }, 1200);
    });
  });

  const animatedElements = document.querySelectorAll('[data-animate]');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animated');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.2
    });
    animatedElements.forEach(element => observer.observe(element));
  } else {
    animatedElements.forEach(element => element.classList.add('animated'));
  }
});