import React, { useEffect, useState } from 'react';

const setDocumentMeta = (title, description) => {
  if (title) {
    document.title = title;
  }
  if (description) {
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'description');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', description);
  }
};

const Contact = () => {
  useEffect(() => {
    setDocumentMeta(
      'Contacto | Luna Rejo StAmira',
      'Escríbenos para recibir acompañamiento personalizado en hábitos climáticamente inteligentes.'
    );
  }, []);

  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    tema: '',
    mensaje: '',
  });
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.nombre.trim()) {
      newErrors.nombre = 'Por favor, escribe tu nombre.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Necesitamos tu correo electrónico.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'El formato del correo electrónico no es válido.';
    }
    if (!formData.tema.trim()) {
      newErrors.tema = 'Indica el tema principal de tu mensaje.';
    }
    if (!formData.mensaje.trim()) {
      newErrors.mensaje = 'Cuéntanos cómo podemos apoyarte.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      setSuccess('');
      return;
    }
    setSuccess('Gracias por tu mensaje. Te responderemos en menos de 48 horas.');
    setFormData({
      nombre: '',
      email: '',
      tema: '',
      mensaje: '',
    });
  };

  return (
    <section className="page-section contact-page">
      <div className="container contact-grid">
        <div className="contact-info">
          <span className="eyebrow">Conversemos</span>
          <h1>Cuéntanos cómo deseas impulsar hábitos climáticos</h1>
          <p>
            Completa el formulario y comparte los detalles de tu comunidad, hogar u organización.
            Te contactaremos pronto para diseñar una ruta a tu medida.
          </p>
          <ul className="contact-details">
            <li>
              <strong>Dirección:</strong> [Pendiente de actualizar]
            </li>
            <li>
              <strong>Email:</strong> [Pendiente de actualizar]
            </li>
            <li>
              <strong>Teléfono:</strong> [Pendiente de actualizar]
            </li>
          </ul>
          <p>
            Nuestro horario de atención es de lunes a viernes, 9:00 a 18:00 (hora del centro de
            México).
          </p>
        </div>
        <div className="contact-form-wrapper">
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="nombre">Nombre completo</label>
              <input
                id="nombre"
                name="nombre"
                type="text"
                value={formData.nombre}
                onChange={handleChange}
                aria-invalid={Boolean(errors.nombre)}
                aria-describedby={errors.nombre ? 'error-nombre' : undefined}
              />
              {errors.nombre && (
                <span className="form-error" id="error-nombre">
                  {errors.nombre}
                </span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="email">Correo electrónico</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'error-email' : undefined}
              />
              {errors.email && (
                <span className="form-error" id="error-email">
                  {errors.email}
                </span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="tema">Tema de interés</label>
              <input
                id="tema"
                name="tema"
                type="text"
                value={formData.tema}
                onChange={handleChange}
                aria-invalid={Boolean(errors.tema)}
                aria-describedby={errors.tema ? 'error-tema' : undefined}
              />
              {errors.tema && (
                <span className="form-error" id="error-tema">
                  {errors.tema}
                </span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="mensaje">Mensaje</label>
              <textarea
                id="mensaje"
                name="mensaje"
                rows="6"
                value={formData.mensaje}
                onChange={handleChange}
                aria-invalid={Boolean(errors.mensaje)}
                aria-describedby={errors.mensaje ? 'error-mensaje' : undefined}
              />
              {errors.mensaje && (
                <span className="form-error" id="error-mensaje">
                  {errors.mensaje}
                </span>
              )}
            </div>
            <button type="submit" className="btn primary">
              Enviar mensaje
            </button>
            {success && (
              <p className="form-success" role="status">
                {success}
              </p>
            )}
          </form>
        </div>
      </div>
    </section>
  );
};

export default Contact;