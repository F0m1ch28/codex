import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const setDocumentMeta = (title, description) => {
  if (title) {
    document.title = title;
  }
  if (description) {
    let metaTag = document.querySelector('meta[name="description"]');
    if (!metaTag) {
      metaTag = document.createElement('meta');
      metaTag.setAttribute('name', 'description');
      document.head.appendChild(metaTag);
    }
    metaTag.setAttribute('content', description);
  }
};

const ImageWithLoader = ({ src, alt, className }) => {
  const [loaded, setLoaded] = useState(false);
  return (
    <div className={`image-wrapper ${loaded ? 'loaded' : ''}`}>
      <img
        src={src}
        alt={alt}
        loading="lazy"
        onLoad={() => setLoaded(true)}
        className={`${className} ${loaded ? 'image-loaded' : ''}`}
      />
    </div>
  );
};

const Home = () => {
  useEffect(() => {
    setDocumentMeta(
      'Luna Rejo StAmira | Hábitos climáticamente inteligentes en México',
      'Plataforma mexicana que impulsa hábitos climáticos accesibles, inspiradores y basados en evidencia para tu vida cotidiana.'
    );
  }, []);

  const pilares = [
    {
      titulo: 'Ciencia cercana',
      descripcion:
        'Traducimos evidencia climática en recomendaciones claras y contextualizadas para hogares mexicanos.',
      icono: '🔍',
    },
    {
      titulo: 'Cuidado humano',
      descripcion:
        'Diseñamos acompañamiento cálido que respeta tus ritmos y celebra cada logro con empatía.',
      icono: '💚',
    },
    {
      titulo: 'Acción comunitaria',
      descripcion:
        'Potenciamos redes locales para que compartir aprendizajes sea parte de la rutina.',
      icono: '🤝',
    },
    {
      titulo: 'Creatividad cotidiana',
      descripcion:
        'Transformamos actividades diarias en oportunidades para reducir emisiones y regenerar entornos.',
      icono: '🌱',
    },
  ];

  const servicios = [
    {
      titulo: 'Ruta Esencial 30 días',
      descripcion:
        'Programa introductorio con micro-hábitos semanales, hoja de ruta personalizada y seguimiento por WhatsApp.',
    },
    {
      titulo: 'Mentoría Hogares Circulares',
      descripcion:
        'Sesiones virtuales para familias que desean medir su impacto y alcanzar metas colectivas.',
    },
    {
      titulo: 'Laboratorio de Equipos Sostenibles',
      descripcion:
        'Taller para organizaciones que quieren integrar hábitos climáticos en su cultura diaria.',
    },
  ];

  const testimonios = [
    {
      nombre: 'María Fernanda López',
      rol: 'Coordinadora vecinal, Puebla',
      cita:
        '“Con Luna Rejo StAmira logramos reducir en 18% el consumo eléctrico de nuestro edificio y ahora realizamos círculos de aprendizaje mensuales.”',
      imagen: 'https://picsum.photos/seed/maria/160/160',
    },
    {
      nombre: 'Diego Hernández',
      rol: 'Docente comunitario, Oaxaca',
      cita:
        '“La guía de hábitos nos ayudó a crear un calendario escolar que integra huertos, movilidad activa y bienestar emocional.”',
      imagen: 'https://picsum.photos/seed/diego/160/160',
    },
    {
      nombre: 'Cecilia Nájera',
      rol: 'Fundadora de colectivo juvenil, CDMX',
      cita:
        '“Las herramientas digitales son clarísimas. Cada avance se celebra y nos anima a invitar a más jóvenes.”',
      imagen: 'https://picsum.photos/seed/cecilia/160/160',
    },
  ];

  const team = [
    {
      nombre: 'Luna Rejo',
      cargo: 'Estratega Climática',
      imagen: 'https://picsum.photos/seed/luna/220/220',
    },
    {
      nombre: 'Amira González',
      cargo: 'Diseñadora de Experiencias',
      imagen: 'https://picsum.photos/seed/amira/220/220',
    },
    {
      nombre: 'Santiago Ortiz',
      cargo: 'Investigador Comunitario',
      imagen: 'https://picsum.photos/seed/santiago/220/220',
    },
  ];

  return (
    <div className="home-page">
      <section className="hero-section">
        <div className="container hero-content">
          <div className="hero-text">
            <span className="eyebrow">Hábitos climáticamente inteligentes</span>
            <h1>
              Acciona cambios profundos con gestos diarios cargados de esperanza y ciencia
            </h1>
            <p>
              En Luna Rejo StAmira acompañamos a hogares y equipos mexicanos a integrar hábitos que
              cuidan el clima, sin perder calidez ni creatividad. Creemos en procesos accesibles,
              medibles y llenos de inspiración.
            </p>
            <div className="hero-actions">
              <Link className="btn primary" to="/guia">
                Explorar la guía
              </Link>
              <Link className="btn outline" to="/programas">
                Ver programas
              </Link>
            </div>
            <div className="hero-stats">
              <div>
                <strong>+480</strong>
                <span>Hábitos activados en hogares mexicanos</span>
              </div>
              <div>
                <strong>92%</strong>
                <span>Personas mantienen los cambios después de 6 meses</span>
              </div>
            </div>
          </div>
          <div className="hero-visual">
            <div className="hero-image">
              <img
                src="https://picsum.photos/seed/habitos/760/780"
                alt="Personas colaborando en acciones climáticas cotidianas"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="section pilares">
        <div className="container">
          <header className="section-header">
            <span className="eyebrow">Nuestros pilares</span>
            <h2>Contención, claridad y acción colectiva para transformar rutinas</h2>
            <p>
              Unimos conocimiento científico con una actitud cercana para que cada gesto cotidiano
              reduzca emisiones, regenere comunidades y contagie entusiasmo.
            </p>
          </header>
          <div className="feature-grid">
            {pilares.map((pilar) => (
              <article key={pilar.titulo} className="feature-card">
                <span className="feature-icon" aria-hidden="true">
                  {pilar.icono}
                </span>
                <h3>{pilar.titulo}</h3>
                <p>{pilar.descripcion}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section programas-preview">
        <div className="container">
          <header className="section-header">
            <span className="eyebrow">Programas destacados</span>
            <h2>Escoge la ruta que mejor acompaña tu momento climático</h2>
            <p>
              Diseñamos experiencias flexibles que se adaptan a distintos niveles de compromiso y
              disponibilidad de tiempo. Todas incluyen seguimiento, retroalimentación y celebraciones.
            </p>
          </header>
          <div className="card-grid">
            {servicios.map((servicio) => (
              <article key={servicio.titulo} className="card program-card">
                <h3>{servicio.titulo}</h3>
                <p>{servicio.descripcion}</p>
                <Link className="link-arrow" to="/programas">
                  Conocer más
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section impacto">
        <div className="container impacto-grid">
          <div>
            <h2>Creamos métricas que celebran el progreso integral</h2>
            <p>
              Evaluamos energía, bienestar emocional, colaboración comunitaria y regeneración de
              espacios. Porque cuidar el clima también significa sentirnos parte de algo más grande.
            </p>
            <Link className="btn secondary" to="/herramientas">
              Medir mi impacto
            </Link>
          </div>
          <div className="impact-stats">
            <div className="impact-card">
              <strong>36%</strong>
              <span>Reducción promedio en desperdicio alimentario</span>
            </div>
            <div className="impact-card">
              <strong>4.2</strong>
              <span>Puntos de bienestar emocional ganados en tres meses</span>
            </div>
            <div className="impact-card">
              <strong>128</strong>
              <span>Comunidades activas en la red Luna Rejo StAmira</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section testimonios">
        <div className="container">
          <header className="section-header">
            <span className="eyebrow">Voces de la comunidad</span>
            <h2>Experiencias reales que demuestran que el cambio es posible</h2>
          </header>
          <div className="testimonial-grid">
            {testimonios.map((testimonio) => (
              <article key={testimonio.nombre} className="testimonial-card">
                <ImageWithLoader
                  src={testimonio.imagen}
                  alt={testimonio.nombre}
                  className="testimonial-avatar"
                />
                <blockquote>{testimonio.cita}</blockquote>
                <div className="testimonial-author">
                  <strong>{testimonio.nombre}</strong>
                  <span>{testimonio.rol}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section herramientas-resumen">
        <div className="container herramientas-grid">
          <div>
            <span className="eyebrow">Recursos en línea</span>
            <h2>Herramientas accesibles para sostener tus nuevos hábitos</h2>
            <p>
              Desde paneles de datos hasta plantillas descargables, nuestra biblioteca crece cada
              mes con aportes de especialistas y de la propia comunidad.
            </p>
            <ul className="list-check">
              <li>Cuadernos digitales editables y listos para imprimir</li>
              <li>Recordatorios inteligentes vía correo y SMS</li>
              <li>Mapa de proveedores responsables en México</li>
            </ul>
            <Link className="btn outline" to="/herramientas">
              Ver recursos
            </Link>
          </div>
          <div className="herramientas-visual">
            <img
              src="https://picsum.photos/seed/herramientas/720/520"
              alt="Panel de herramientas climáticas"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="section equipo">
        <div className="container">
          <header className="section-header">
            <span className="eyebrow">Equipo Luna Rejo StAmira</span>
            <h2>Personas que combinan sensibilidad social y análisis climático</h2>
          </header>
          <div className="team-grid">
            {team.map((miembro) => (
              <article key={miembro.nombre} className="team-card">
                <ImageWithLoader
                  src={miembro.imagen}
                  alt={miembro.nombre}
                  className="team-photo"
                />
                <h3>{miembro.nombre}</h3>
                <p>{miembro.cargo}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section cta-final">
        <div className="container cta-final-inner">
          <div>
            <h2>¿Listas y listos para un estilo de vida climáticamente inteligente?</h2>
            <p>
              Da el primer paso con nuestra guía gratuita, súmate a un programa o escribe para
              diseñar una experiencia a tu medida. Cada acción cuenta y deseamos acompañarte.
            </p>
          </div>
          <div className="cta-final-actions">
            <Link className="btn primary" to="/contacto">
              Solicitar acompañamiento
            </Link>
            <Link className="btn outline" to="/blog">
              Inspirarme con historias
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;