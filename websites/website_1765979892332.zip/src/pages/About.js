import React, { useEffect } from 'react';

const setDocumentMeta = (title, description) => {
  if (title) {
    document.title = title;
  }
  if (description) {
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'description');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', description);
  }
};

const About = () => {
  useEffect(() => {
    setDocumentMeta(
      'Sobre Luna Rejo StAmira | Nuestra historia y misión',
      'Conoce la trayectoria, misión y valores de Luna Rejo StAmira, comunidad mexicana dedicada a los hábitos climáticamente inteligentes.'
    );
  }, []);

  const valores = [
    {
      titulo: 'Esperanza activa',
      descripcion:
        'Convertimos la esperanza en planes concretos que movilizan a personas y barrios enteros.',
    },
    {
      titulo: 'Interseccionalidad',
      descripcion:
        'Reconocemos las diversas realidades mexicanas y proponemos soluciones que respetan contextos culturales y económicos.',
    },
    {
      titulo: 'Aprendizaje constante',
      descripcion:
        'Medimos, escuchamos y actualizamos nuestras herramientas con datos y retroalimentación comunitaria.',
    },
    {
      titulo: 'Cuidado colectivo',
      descripcion:
        'Creemos que ninguna persona avanza sola. Tejemos redes de apoyo para sostener los hábitos en el tiempo.',
    },
  ];

  const hitos = [
    {
      año: '2019',
      texto:
        'Luna R. y Amira G. fundan una plataforma educativa para traducir reportes climáticos en recursos comprensibles.',
    },
    {
      año: '2020',
      texto:
        'Primer piloto con 30 familias en Querétaro. Logramos reducir un 22% el consumo de agua en tres meses.',
    },
    {
      año: '2021',
      texto:
        'Creamos la red “Comunidades que Abrazan el Clima” con líderes de colonias en CDMX, Puebla y Mérida.',
    },
    {
      año: '2023',
      texto:
        'Lanzamos el laboratorio de hábitos climáticos para organizaciones y alcanzamos 100 voluntarios activos.',
    },
  ];

  return (
    <section className="page-section about-page">
      <div className="container narrow">
        <header className="page-header">
          <span className="eyebrow">Quiénes somos</span>
          <h1>La historia de Luna Rejo StAmira</h1>
          <p>
            Nacimos de una amistad que combina rigor científico y diseño empático. Creemos que los
            hábitos climáticamente inteligentes florecen cuando las personas se sienten acompañadas,
            escuchadas y motivadas por historias reales.
          </p>
        </header>
        <div className="about-story">
          <p>
            Todo comenzó en un taller comunitario en la colonia Juárez, Ciudad de México, donde
            facilitamos una conversación entre vecinas sobre la ansiedad climática. Al final del
            encuentro, acordamos crear recursos que respondieran a la pregunta más recurrente: “¿Por
            dónde empiezo?”. Desde entonces, Luna Rejo StAmira se convirtió en un laboratorio vivo
            que integra investigación, diseño de experiencias y participación ciudadana.
          </p>
          <p>
            Nuestro equipo interdisciplinario trabaja con metodologías de diseño regenerativo,
            investigación aplicada y pedagogía crítica. Cada programa se cocrea con las personas
            participantes para asegurar que los hábitos se sostengan y se multipliquen.
          </p>
        </div>
        <section className="timeline">
          {hitos.map((hito) => (
            <article key={hito.año} className="timeline-step">
              <div className="timeline-number">{hito.año}</div>
              <div>
                <h2>{hito.año}</h2>
                <p>{hito.texto}</p>
              </div>
            </article>
          ))}
        </section>
        <section className="values-section">
          <h2>Nuestros valores guían cada acompañamiento</h2>
          <div className="feature-grid">
            {valores.map((valor) => (
              <article key={valor.titulo} className="feature-card">
                <h3>{valor.titulo}</h3>
                <p>{valor.descripcion}</p>
              </article>
            ))}
          </div>
        </section>
        <section className="about-mission">
          <h2>Misión & Visión</h2>
          <div className="mission-box">
            <div>
              <h3>Misión</h3>
              <p>
                Acompañar a personas y organizaciones mexicanas a integrar hábitos climáticamente
                inteligentes que combinen bienestar, justicia social y regeneración ambiental.
              </p>
            </div>
            <div>
              <h3>Visión</h3>
              <p>
                Tejer una red nacional de comunidades que encuentren placer y propósito al cuidar el
                clima, celebrando cada gesto cotidiano que construye futuros deseables.
              </p>
            </div>
          </div>
        </section>
      </div>
    </section>
  );
};

export default About;