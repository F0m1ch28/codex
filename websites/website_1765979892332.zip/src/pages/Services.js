import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

const setDocumentMeta = (title, description) => {
  if (title) {
    document.title = title;
  }
  if (description) {
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'description');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', description);
  }
};

const ProgramsPage = () => {
  useEffect(() => {
    setDocumentMeta(
      'Programas de hábitos climáticos | Luna Rejo StAmira',
      'Descubre los programas de Luna Rejo StAmira para integrar hábitos climáticamente inteligentes con seguimiento cercano y herramientas útiles.'
    );
  }, []);

  const programas = [
    {
      nombre: 'Ruta Esencial 30 días',
      descripcion:
        'Inicia tu transición climática con cuatro semanas temáticas: energía, agua, consumo y bienestar. Incluye sesiones grupales, recordatorios digitales y tablero de progreso.',
      ideal:
        'Ideal para hogares que desean comenzar con claridad y requieren acompañamiento paso a paso.',
      elementos: ['4 sesiones en vivo', 'Tablero de indicadores', 'Guía descargable'],
    },
    {
      nombre: 'Mentoría Hogares Circulares',
      descripcion:
        'Acompañamiento personalizado para familias que buscan metas avanzadas. Analizamos hábitos actuales, definimos indicadores y damos seguimiento quincenal durante 12 semanas.',
      ideal:
        'Especial para familias que ya iniciaron cambios y desean consolidarlos con apoyo experto.',
      elementos: ['Diagnóstico inicial', 'Mentoría personalizada', 'Reportes mensuales'],
    },
    {
      nombre: 'Laboratorio de Equipos Sostenibles',
      descripcion:
        'Experiencia inmersiva para organizaciones. Diseñamos rituales climáticos para reuniones, espacios de trabajo y proyectos colaborativos.',
      ideal:
        'Perfecto para empresas, colectivos y escuelas que desean fortalecer una cultura climática.',
      elementos: ['Workshop presencial o virtual', 'Kit de herramientas', 'Plan de acción escalable'],
    },
  ];

  return (
    <section className="page-section programas-page">
      <div className="container">
        <header className="page-header">
          <span className="eyebrow">Programas</span>
          <h1>Estructuras dinámicas para sostener hábitos climáticos</h1>
          <p>
            Nuestros programas combinan acompañamiento humano, herramientas digitales y comunidades
            de aprendizaje para asegurar que los cambios se mantengan en el tiempo.
          </p>
        </header>
        <div className="programs-list">
          {programas.map((programa) => (
            <article key={programa.nombre} className="program-card-detail">
              <header>
                <h2>{programa.nombre}</h2>
                <p>{programa.descripcion}</p>
              </header>
              <div className="program-body">
                <div>
                  <h3>¿Para quién es?</h3>
                  <p>{programa.ideal}</p>
                </div>
                <div>
                  <h3>Incluye</h3>
                  <ul>
                    {programa.elementos.map((elem) => (
                      <li key={elem}>{elem}</li>
                    ))}
                  </ul>
                </div>
              </div>
              <footer>
                <Link className="btn outline" to="/contacto">
                  Solicitar información
                </Link>
              </footer>
            </article>
          ))}
        </div>
        <section className="programs-extra">
          <h2>¿Cómo trabajaremos juntos?</h2>
          <div className="steps-grid">
            <article>
              <span className="step-number">1</span>
              <h3>Sesión de descubrimiento</h3>
              <p>
                Exploramos tus motivaciones, contexto y recursos disponibles para adaptar la ruta de
                acompañamiento desde el inicio.
              </p>
            </article>
            <article>
              <span className="step-number">2</span>
              <h3>Diseño colaborativo</h3>
              <p>
                Co-creamos un plan con metas claras, indicadores amigables y rituales que celebren
                cada avance.
              </p>
            </article>
            <article>
              <span className="step-number">3</span>
              <h3>Seguimiento y celebración</h3>
              <p>
                Medimos el progreso, registramos aprendizajes y reconocemos los logros colectivos con
                celebraciones inspiradoras.
              </p>
            </article>
          </div>
        </section>
      </div>
    </section>
  );
};

export default ProgramsPage;