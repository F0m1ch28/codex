import React, { useEffect } from 'react';
import PrivacyPolicy from './PrivacyPolicy';

const setDocumentMeta = (title, description) => {
  if (title) {
    document.title = title;
  }
  if (description) {
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'description');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', description);
  }
};

const CookiePolicy = () => (
  <section id="cookies" className="legal-section">
    <h2>Política de cookies</h2>
    <p>
      En Luna Rejo StAmira utilizamos cookies propias y analíticas para comprender el uso de nuestro
      sitio y mejorar la experiencia de navegación. No empleamos cookies con fines publicitarios.
    </p>
    <ul>
      <li>
        <strong>Cookies esenciales:</strong> permiten el funcionamiento básico del sitio y no
        almacenan datos personales.
      </li>
      <li>
        <strong>Cookies analíticas:</strong> recopilamos métricas anónimas sobre la interacción con
        contenidos para mejorar nuestros recursos.
      </li>
    </ul>
    <p>
      Puedes gestionar tus preferencias directamente en tu navegador o escribirnos para solicitar
      más información sobre nuestras prácticas.
    </p>
  </section>
);

const TermsOfUse = () => (
  <section id="terminos" className="legal-section">
    <h2>Términos de uso</h2>
    <p>
      Bienvenida y bienvenido a Luna Rejo StAmira. Al acceder a nuestro sitio web confirmas que
      utilizarás los contenidos de forma responsable y respetarás los derechos de autor
      correspondientes.
    </p>
    <ul>
      <li>
        Los recursos compartidos son de uso personal o educativo. Para emplearlos con fines
        comerciales solicita autorización escrita.
      </li>
      <li>
        La información publicada puede actualizarse sin previo aviso. Te recomendamos revisar esta
        sección con frecuencia.
      </li>
      <li>
        Los enlaces externos se ofrecen como referencia. No somos responsables del contenido de
        sitios de terceros.
      </li>
      <li>
        Cualquier comentario enviado podrá ser utilizado de forma anónima para comunicar logros de la
        comunidad.
      </li>
    </ul>
    <p>
      Si tienes preguntas, contáctanos para recibir orientación detallada sobre el uso de nuestros
      contenidos.
    </p>
  </section>
);

const LegalPage = () => {
  useEffect(() => {
    setDocumentMeta(
      'Aviso legal | Luna Rejo StAmira',
      'Consulta los términos de uso, aviso de privacidad y política de cookies de Luna Rejo StAmira.'
    );
  }, []);

  return (
    <section className="page-section legal-page">
      <div className="container narrow">
        <header className="page-header">
          <span className="eyebrow">Avisos legales</span>
          <h1>Condiciones de uso y avisos de privacidad</h1>
          <p>
            Ponemos a tu disposición la información clave sobre el uso de este sitio, el tratamiento
            de datos personales y nuestras prácticas relacionadas con cookies.
          </p>
        </header>
        <TermsOfUse />
        <PrivacyPolicy embedded />
        <CookiePolicy />
      </div>
    </section>
  );
};

export default LegalPage;