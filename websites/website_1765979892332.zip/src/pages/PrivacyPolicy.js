import React, { useEffect } from 'react';

const setDocumentMeta = (title, description) => {
  if (title) {
    document.title = title;
  }
  if (description) {
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'description');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', description);
  }
};

const PrivacyPolicy = ({ embedded = false }) => {
  useEffect(() => {
    if (!embedded) {
      setDocumentMeta(
        'Política de privacidad | Luna Rejo StAmira',
        'Conoce cómo Luna Rejo StAmira protege y administra la información personal proporcionada por quienes nos contactan.'
      );
    }
  }, [embedded]);

  return (
    <section id="privacidad" className="legal-section">
      <h2>Política de privacidad</h2>
      <p>
        Luna Rejo StAmira respeta y protege los datos personales que compartes a través de nuestros
        formularios o canales de contacto. Solo solicitamos información necesaria para responder a
        tus solicitudes y ofrecerte recursos personalizados.
      </p>
      <h3>Datos recopilados</h3>
      <ul>
        <li>Nombre y datos de contacto para establecer comunicación contigo.</li>
        <li>Información sobre tus intereses para personalizar el acompañamiento.</li>
      </ul>
      <h3>Uso de la información</h3>
      <p>
        Empleamos la información para responder mensajes, enviar materiales solicitados y compartir
        novedades relevantes. No vendemos ni transferimos datos personales a terceros.
      </p>
      <h3>Conservación y seguridad</h3>
      <p>
        La información se resguarda en plataformas seguras con controles de acceso. Si deseas
        actualizar o eliminar tus datos, escríbenos y atenderemos tu solicitud en máximo quince días
        hábiles.
      </p>
      <h3>Actualizaciones</h3>
      <p>
        Podemos actualizar esta política para reflejar nuevas prácticas. Revisa la fecha de última
        modificación y contáctanos si tienes dudas.
      </p>
    </section>
  );
};

export default PrivacyPolicy;