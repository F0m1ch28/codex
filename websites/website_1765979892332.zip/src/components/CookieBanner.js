import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const STORAGE_KEY = 'lrs-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <p>
        Utilizamos cookies analíticas para mejorar tu experiencia y comprender cómo se aplican los hábitos climáticos.
        Consulta nuestro <Link to="/legal#privacidad">aviso de privacidad</Link>.
      </p>
      <button className="btn primary" onClick={handleAccept}>
        Aceptar
      </button>
    </div>
  );
};

export default CookieBanner;