import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';

const Header = () => {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  return (
    <header className="site-header" role="banner">
      <div className="container nav-container">
        <Link to="/" className="brand" aria-label="Inicio Luna Rejo StAmira">
          <span className="brand-mark">Luna</span> Rejo StAmira
        </Link>
        <button
          className={`nav-toggle ${open ? 'open' : ''}`}
          aria-expanded={open}
          aria-controls="primary-navigation"
          onClick={() => setOpen((prev) => !prev)}
        >
          <span className="sr-only">Menú</span>
          <span />
          <span />
          <span />
        </button>
        <nav
          id="primary-navigation"
          className={`navigation ${open ? 'visible' : ''}`}
          aria-label="Menú principal"
        >
          <NavLink end to="/">
            Inicio
          </NavLink>
          <NavLink to="/guia">Guía</NavLink>
          <NavLink to="/programas">Programas</NavLink>
          <NavLink to="/herramientas">Herramientas</NavLink>
          <NavLink to="/blog">Blog</NavLink>
          <NavLink to="/nosotros">Nosotros</NavLink>
          <NavLink to="/contacto">Contacto</NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;