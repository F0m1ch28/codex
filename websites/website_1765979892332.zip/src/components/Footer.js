import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="site-footer" role="contentinfo">
    <div className="container footer-grid">
      <div className="footer-column">
        <h2 className="footer-brand">
          <span className="brand-mark">Luna</span> Rejo StAmira
        </h2>
        <p>
          Acompañamos a hogares y organizaciones mexicanas a crear hábitos climáticamente
          inteligentes con calidez humana y rigor científico.
        </p>
        <div className="footer-social">
          <a
            href="https://www.instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram de Luna Rejo StAmira"
          >
            <span aria-hidden="true">🌙</span>
          </a>
          <a
            href="https://www.linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn de Luna Rejo StAmira"
          >
            <span aria-hidden="true">🔗</span>
          </a>
          <a
            href="https://www.youtube.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="YouTube de Luna Rejo StAmira"
          >
            <span aria-hidden="true">▶︎</span>
          </a>
        </div>
      </div>
      <div className="footer-column">
        <h3>Explora</h3>
        <ul>
          <li><Link to="/guia">Guía paso a paso</Link></li>
          <li><Link to="/programas">Programas</Link></li>
          <li><Link to="/herramientas">Herramientas</Link></li>
          <li><Link to="/blog">Blog</Link></li>
        </ul>
      </div>
      <div className="footer-column">
        <h3>Comunidad</h3>
        <ul>
          <li><Link to="/nosotros">Nuestra historia</Link></li>
          <li><Link to="/contacto">Solicita acompañamiento</Link></li>
          <li><Link to="/legal">Avisos legales</Link></li>
          <li><Link to="/legal/privacidad">Política de privacidad</Link></li>
        </ul>
      </div>
      <div className="footer-column">
        <h3>Contacto</h3>
        <ul className="contact-list">
          <li><strong>Dirección:</strong> [Pendiente de actualizar]</li>
          <li><strong>Email:</strong> [Pendiente de actualizar]</li>
          <li><strong>Teléfono:</strong> [Pendiente de actualizar]</li>
        </ul>
        <p className="footer-note">
          Escríbenos y cuéntanos qué hábitos climáticos deseas fortalecer. Respondemos en menos de 48 horas.
        </p>
      </div>
    </div>
    <div className="footer-bottom">
      <p>© {new Date().getFullYear()} Luna Rejo StAmira. Todos los derechos reservados.</p>
    </div>
  </footer>
);

export default Footer;