import React, { useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import ProgramsPage from './pages/Services';
import Contact from './pages/Contact';
import LegalPage from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';

const setDocumentMeta = (title, description) => {
  if (title) {
    document.title = title;
  }
  if (description) {
    let metaTag = document.querySelector('meta[name="description"]');
    if (!metaTag) {
      metaTag = document.createElement('meta');
      metaTag.setAttribute('name', 'description');
      document.head.appendChild(metaTag);
    }
    metaTag.setAttribute('content', description);
  }
};

const blogPosts = [
  {
    slug: 'consejos-ahorro-energia',
    title: 'Consejos diarios para ahorrar energía en casa',
    description:
      'Reduce el consumo energético con acciones sencillas y hábitos climáticamente inteligentes para tu hogar.',
    date: '2024-03-02',
    image: 'https://picsum.photos/seed/energia/960/540',
    intro:
      'El consumo energético del hogar representa una parte significativa de nuestra huella ambiental. Con pequeñas decisiones diarias podemos reducir emisiones y proteger el clima.',
    sections: [
      {
        heading: 'Evalúa tus electrodomésticos',
        content:
          'Revisa la antigüedad y eficiencia de refrigeradores, lavadoras y equipos de aire acondicionado. Si un aparato consume en modo de espera, utiliza multicontactos con apagador y desconecta por completo cuando no esté en uso.',
      },
      {
        heading: 'Iluminación responsable',
        content:
          'Sustituye lámparas incandescentes por LED cálidas. Combina iluminación natural con cortinas claras y limpia los focos con regularidad para aprovechar su potencia real.',
      },
      {
        heading: 'Pequeñas acciones de gran impacto',
        content:
          'Al cocinar, tapa ollas para conservar el calor, ajusta el termostato de tu refrigerador a 4 °C y plancha de una sola vez para evitar múltiples ciclos de calentamiento.',
      },
    ],
    conclusion:
      'Implementar estos cambios crea un efecto dominó en tu comunidad. Comparte tus hallazgos y motiva a tus vecinos a sumarse a los hábitos climáticamente inteligentes.',
    tags: ['Eficiencia energética', 'Hogar', 'Hábitos diarios'],
  },
  {
    slug: 'huella-carbono-hogar',
    title: 'Calcula y reduce la huella de carbono de tu hogar',
    description:
      'Aprende a medir el impacto de tus actividades domésticas y a trazar un plan realista de reducción.',
    date: '2024-02-15',
    image: 'https://picsum.photos/seed/carbono/960/540',
    intro:
      'Conocer la huella de carbono es el primer paso para transformarla. Analiza tus consumos, establece metas concretas y haz seguimiento para ver el progreso.',
    sections: [
      {
        heading: 'Recolecta tus datos',
        content:
          'Junta recibos de electricidad, gas, agua y transporte. Incluye también compras frecuentes como alimentos y productos de limpieza.',
      },
      {
        heading: 'Usa calculadoras confiables',
        content:
          'Apóyate en calculadoras validadas por organizaciones ambientales mexicanas. Introduce tus datos y genera un informe base.',
      },
      {
        heading: 'Diseña un plan mensual',
        content:
          'Define metas por categoría: reducir kWh, optimizar el transporte compartido o elegir proveedores con compromisos climáticos. Anota tus avances cada cuatro semanas.',
      },
    ],
    conclusion:
      'Medir, actuar y compartir resultados es una poderosa combinación para movilizar a más personas hacia estilos de vida responsables.',
    tags: ['Huella de carbono', 'Planeación', 'Seguimiento'],
  },
  {
    slug: 'rutinas-matutinas-climaticas',
    title: 'Rutinas matutinas para iniciar el día con enfoque climático',
    description:
      'Descubre rituales inspiradores que alinean tu energía personal con acciones de cuidado ambiental desde temprano.',
    date: '2024-01-30',
    image: 'https://picsum.photos/seed/manana/960/540',
    intro:
      'Cómo iniciamos el día influye en nuestras decisiones posteriores. Diseñar una rutina mañanera con gestos conscientes nos conecta con el propósito climático.',
    sections: [
      {
        heading: 'Respira y agradece',
        content:
          'Antes de revisar el teléfono, abre la ventana, respira tres veces profundamente y agradece por un recurso natural que disfrutas cotidianamente.',
      },
      {
        heading: 'Hidratación responsable',
        content:
          'Llena tu termo reutilizable con agua filtrada y agrega una etiqueta motivadora. Evita comprar botellas desechables durante la jornada.',
      },
      {
        heading: 'Agenda ecológica',
        content:
          'Revisa tu agenda del día e identifica oportunidades para caminar, compartir transporte o consumir alimentos locales de temporada.',
      },
    ],
    conclusion:
      'Una rutina consciente se convierte en brújula personal. Ajusta estos pasos a tu estilo y comparte tus rituales con tu red para multiplicar la inspiración.',
    tags: ['Bienestar', 'Rutinas', 'Clima'],
  },
];

const GuidePage = () => {
  useEffect(() => {
    setDocumentMeta(
      'Guía de hábitos diarios | Luna Rejo StAmira',
      'Pasos claros para integrar hábitos climáticamente inteligentes en tu vida diaria con el respaldo de Luna Rejo StAmira.'
    );
  }, []);

  const pasos = [
    {
      titulo: 'Observa y registra tu línea base',
      detalle:
        'Dedica una semana a documentar tus consumos de energía, agua, transporte y generación de residuos. Usa nuestro Cuaderno Circular para señalar momentos clave.',
    },
    {
      titulo: 'Define una intención por categoría',
      detalle:
        'Selecciona una meta por energía, movilidad, consumo y bienestar. Asegúrate de que sea específica, medible y alcanzable en 30 días.',
    },
    {
      titulo: 'Transforma la intención en micro-hábitos',
      detalle:
        'Descompone cada meta en acciones pequeñas. Por ejemplo, “apagar regadera mientras enjabonamos” o “caminar al mercado los jueves”.',
    },
    {
      titulo: 'Activa recordatorios positivos',
      detalle:
        'Coloca señales visibles en tu hogar y configura recordatorios amistosos en tu teléfono. Refuerza con frases motivadoras.',
    },
    {
      titulo: 'Evalúa y ajusta semanalmente',
      detalle:
        'Cada domingo reflexiona: ¿qué funcionó, qué puedes mejorar y qué apoyo necesitas? Actualiza tu plan sin juzgarte.',
    },
  ];

  return (
    <section className="page-section">
      <div className="container narrow">
        <header className="page-header">
          <span className="eyebrow">Guía práctica</span>
          <h1>Integra hábitos climáticamente inteligentes sin complicaciones</h1>
          <p>
            Esta guía está diseñada para las familias mexicanas que valoran la claridad. Con ella
            podrás cambiar tu estilo de vida a un ritmo que respeta tu realidad y celebra cada avance.
          </p>
        </header>
        <div className="timeline">
          {pasos.map((paso, index) => (
            <article key={paso.titulo} className="timeline-step">
              <div className="timeline-number">{index + 1}</div>
              <div>
                <h2>{paso.titulo}</h2>
                <p>{paso.detalle}</p>
              </div>
            </article>
          ))}
        </div>
        <div className="cta-block">
          <h3>Convierte los pasos en acción con apoyo experto</h3>
          <p>
            Descarga la plantilla de seguimiento, inscríbete a un programa y consulta las
            herramientas recomendadas para mantener tu motivación alta.
          </p>
          <div className="cta-actions">
            <Link className="btn primary" to="/programas">
              Ver programas
            </Link>
            <Link className="btn outline" to="/herramientas">
              Explorar herramientas
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

const ToolsPage = () => {
  useEffect(() => {
    setDocumentMeta(
      'Herramientas climáticamente inteligentes | Luna Rejo StAmira',
      'Recursos digitales y físicos para mantener tus hábitos climáticos alineados y medir tu progreso sin estrés.'
    );
  }, []);

  const tools = [
    {
      titulo: 'Cuaderno circular digital',
      descripcion:
        'Plantilla editable para monitorear energía, agua, movilidad y bienestar emocional. Incluye indicadores semanales y mensajes de inspiración.',
      enlace: '/contacto',
      tipo: 'Plantilla editable',
    },
    {
      titulo: 'Panel de progreso comunitario',
      descripcion:
        'Acceso interactivo para visualizar los avances colectivos de la comunidad Luna Rejo StAmira. Perfecto para nutrir el sentido de pertenencia.',
      enlace: '/programas',
      tipo: 'Dashboard colaborativo',
    },
    {
      titulo: 'Checklist de compras con enfoque climático',
      descripcion:
        'Lista imprimible para que cada visita al mercado sea una oportunidad de elegir ingredientes locales, reducir empaques y apoyar a productores responsables.',
      enlace: '/blog/huella-carbono-hogar',
      tipo: 'Recurso descargable',
    },
  ];

  return (
    <section className="page-section">
      <div className="container">
        <header className="page-header">
          <span className="eyebrow">Herramientas esenciales</span>
          <h1>Recursos para monitorear, celebrar y compartir tus avances</h1>
          <p>
            Cada herramienta fue creada para adaptarse a distintas realidades mexicanas. Selecciona
            la que mejor resuene con tu ritmo y añade tus propias ideas.
          </p>
        </header>
        <div className="card-grid">
          {tools.map((tool) => (
            <article key={tool.titulo} className="card tool-card">
              <span className="tag">{tool.tipo}</span>
              <h2>{tool.titulo}</h2>
              <p>{tool.descripcion}</p>
              <Link to={tool.enlace} className="link-arrow">
                Activar herramienta
              </Link>
            </article>
          ))}
        </div>
        <div className="insight-box">
          <h3>¿Buscas algo personalizado?</h3>
          <p>
            Escríbenos y comparte el contexto de tu hogar o comunidad. Diseñaremos una herramienta a
            medida para tus hábitos climáticos.
          </p>
          <Link className="btn secondary" to="/contacto">
            Hablemos
          </Link>
        </div>
      </div>
    </section>
  );
};

const BlogPage = ({ posts }) => {
  useEffect(() => {
    setDocumentMeta(
      'Blog de hábitos climáticos | Luna Rejo StAmira',
      'Ideas frescas, historias reales y consejos prácticos para vivir con enfoque climático todos los días.'
    );
  }, []);

  return (
    <section className="page-section">
      <div className="container">
        <header className="page-header">
          <span className="eyebrow">Blog Luna Rejo StAmira</span>
          <h1>Historias y aprendizajes para inspirar tu próxima acción climática</h1>
          <p>
            Nuestro equipo y comunidad comparten hallazgos, retos y victorias para demostrar que los
            hábitos climáticos se construyen paso a paso.
          </p>
        </header>
        <div className="card-grid">
          {posts.map((post) => (
            <article key={post.slug} className="card blog-card">
              <div className="card-image-wrapper">
                <img
                  src={post.image}
                  alt={post.title}
                  loading="lazy"
                  className="card-image"
                />
              </div>
              <div className="card-body">
                <span className="tag">
                  {new Date(post.date).toLocaleDateString('es-MX', {
                    day: '2-digit',
                    month: 'long',
                    year: 'numeric',
                  })}
                </span>
                <h2>{post.title}</h2>
                <p>{post.description}</p>
                <Link className="link-arrow" to={`/blog/${post.slug}`}>
                  Leer artículo completo
                </Link>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

const BlogArticle = ({ post }) => {
  useEffect(() => {
    setDocumentMeta(
      `${post.title} | Luna Rejo StAmira`,
      post.description
    );
  }, [post]);

  return (
    <article className="page-section">
      <div className="container narrow">
        <header className="page-header">
          <span className="eyebrow">
            {new Date(post.date).toLocaleDateString('es-MX', {
              day: '2-digit',
              month: 'long',
              year: 'numeric',
            })}
          </span>
          <h1>{post.title}</h1>
          <p>{post.intro}</p>
          <div className="article-tags">
            {post.tags.map((tag) => (
              <span key={tag} className="tag">
                {tag}
              </span>
            ))}
          </div>
        </header>
        <div className="article-hero">
          <img src={post.image} alt={post.title} loading="lazy" />
        </div>
        <div className="article-content">
          {post.sections.map((section) => (
            <section key={section.heading}>
              <h2>{section.heading}</h2>
              <p>{section.content}</p>
            </section>
          ))}
        </div>
        <footer className="article-footer">
          <p>{post.conclusion}</p>
          <Link className="btn outline" to="/blog">
            Volver al blog
          </Link>
        </footer>
      </div>
    </article>
  );
};

const NotFound = () => {
  useEffect(() => {
    setDocumentMeta(
      'Página no encontrada | Luna Rejo StAmira',
      'El contenido que buscas no existe o fue trasladado.'
    );
  }, []);

  return (
    <section className="page-section">
      <div className="container narrow center-text">
        <h1>Ups, no encontramos esa página</h1>
        <p>
          Tal vez el contenido fue actualizado. Revisa nuestro menú principal o vuelve a la página
          de inicio para continuar explorando hábitos climáticos.
        </p>
        <Link className="btn primary" to="/">
          Ir a inicio
        </Link>
      </div>
    </section>
  );
};

const App = () => {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <div className="app-shell">
      <Header />
      <main id="contenido-principal">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/guia" element={<GuidePage />} />
          <Route path="/programas" element={<ProgramsPage />} />
          <Route path="/herramientas" element={<ToolsPage />} />
          <Route path="/blog" element={<BlogPage posts={blogPosts} />} />
          {blogPosts.map((post) => (
            <Route
              key={post.slug}
              path={`/blog/${post.slug}`}
              element={<BlogArticle post={post} />}
            />
          ))}
          <Route path="/nosotros" element={<About />} />
          <Route path="/contacto" element={<Contact />} />
          <Route path="/legal" element={<LegalPage />} />
          <Route path="/legal/privacidad" element={<PrivacyPolicy />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;