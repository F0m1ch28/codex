import { useEffect } from 'react';

function MetaHelmet({ title, description, keywords }) {
  useEffect(() => {
    if (title) {
      document.title = title;
    }

    const ensureMeta = (name, content) => {
      let metaTag = document.querySelector(`meta[name="${name}"]`);
      if (!metaTag) {
        metaTag = document.createElement('meta');
        metaTag.setAttribute('name', name);
        document.head.appendChild(metaTag);
      }
      metaTag.setAttribute('content', content);
    };

    if (description) {
      ensureMeta('description', description);
    }
    if (keywords) {
      ensureMeta('keywords', keywords);
    }
  }, [title, description, keywords]);

  return null;
}

export default MetaHelmet;