import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Главная', exact: true },
  { path: '/categories', label: 'Категории' },
  { path: '/video-covers', label: 'Обложки' },
  { path: '/avatars', label: 'Аватарки' },
  { path: '/stream-banners', label: 'Баннеры' },
  { path: '/youtube-thumbnails', label: 'YouTube' },
  { path: '/social-media-graphics', label: 'Соцсети' },
  { path: '/about', label: 'О нас' },
  { path: '/contact', label: 'Контакты' }
];

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header} role="banner">
      <div className="container">
        <div className={styles.inner}>
          <Link to="/" className={styles.logo} aria-label="DigitalCovers — на главную">
            <span className={styles.logoMark}>DC</span>
            <span className={styles.logoText}>DigitalCovers</span>
          </Link>

          <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Главное меню">
            <ul>
              {navItems.map((item) => (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    className={({ isActive }) =>
                      isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                    }
                    onClick={closeMenu}
                    end={item.exact}
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>

          <button
            type="button"
            className={styles.menuToggle}
            onClick={toggleMenu}
            aria-expanded={menuOpen}
            aria-controls="primary-navigation"
            aria-label="Открыть меню"
          >
            <span className={styles.menuLine} />
            <span className={styles.menuLine} />
            <span className={styles.menuLine} />
          </button>
        </div>
      </div>
    </header>
  );
}

export default Header;