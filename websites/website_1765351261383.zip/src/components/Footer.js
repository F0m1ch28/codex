import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className="container">
        <div className={styles.grid}>
          <div>
            <h3 className={styles.title}>DigitalCovers</h3>
            <p className={styles.text}>
              Онлайн-магазин готовой цифровой графики. Помогаем блогерам,
              создателям контента и брендам выглядеть ярко на каждой платформе.
            </p>
            <p className={styles.textSmall}>Работаем международно, доставка мгновенная.</p>
          </div>
          <div>
            <h4 className={styles.subtitle}>Навигация</h4>
            <ul className={styles.links}>
              <li><Link to="/">Главная</Link></li>
              <li><Link to="/categories">Категории</Link></li>
              <li><Link to="/services">Решения</Link></li>
              <li><Link to="/about">О компании</Link></li>
              <li><Link to="/contact">Контакты</Link></li>
            </ul>
          </div>
          <div>
            <h4 className={styles.subtitle}>Правовая информация</h4>
            <ul className={styles.links}>
              <li><Link to="/terms">Условия использования</Link></li>
              <li><Link to="/privacy">Политика конфиденциальности</Link></li>
              <li><Link to="/cookie-policy">Политика cookies</Link></li>
            </ul>
          </div>
          <div>
            <h4 className={styles.subtitle}>Контакты</h4>
            <address className={styles.contact}>
              <span>Адрес: ул. Цифровая, 15, Москва, Россия, 123456</span>
              <a href="tel:+79991234567">Телефон: +7 (999) 123-45-67</a>
              <a href="mailto:info@digitalcovers.ru">Email: info@digitalcovers.ru</a>
            </address>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>© {new Date().getFullYear()} DigitalCovers. Все права защищены.</p>
          <p className={styles.bottomNote}>Создаём визуальную историю брендов и каналов.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;