import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_STORAGE_KEY = 'digitalcovers-cookie-consent';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(COOKIE_STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem(COOKIE_STORAGE_KEY, 'declined');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о cookies">
      <div className={styles.content}>
        <p>
          Мы используем cookies, чтобы сайт работал стабильно и адаптировался под ваши предпочтения.
          Продолжая пользоваться DigitalCovers, вы соглашаетесь с обработкой cookies.
        </p>
        <div className={styles.actions}>
          <button type="button" className={styles.accept} onClick={handleAccept}>
            Согласиться
          </button>
          <button type="button" className={styles.decline} onClick={handleDecline}>
            Отклонить
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;