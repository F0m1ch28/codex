import React from 'react';
import MetaHelmet from '../components/MetaHelmet';
import styles from './ProductPage.module.css';

const thumbnails = [
  {
    title: 'Bold Stories',
    image: 'https://picsum.photos/seed/ytthumb1/1200/800',
    description: 'Контрастные цвета и выразительные лица, акцент на эмоциях и сюжетной линии.'
  },
  {
    title: 'Tech Breakdown',
    image: 'https://picsum.photos/seed/ytthumb2/1200/800',
    description: 'Структурированный дизайн с инфографикой для образовательных и обзорных роликов.'
  },
  {
    title: 'Fast Entertainment',
    image: 'https://picsum.photos/seed/ytthumb3/1200/800',
    description: 'Графика с динамическими вспышками и крупными цифрами для челленджей и реакций.'
  }
];

const features = [
  'Отдельные версии для мобильной и десктопной выдачи',
  'Правильные поля безопасности под текст',
  'Экспорт в PNG, JPG и готовые шаблоны',
  'Цветокоррекция с учётом YouTube Dark Mode'
];

function YouTubeThumbnailsPage() {
  return (
    <div className={styles.wrapper}>
      <MetaHelmet
        title="YouTube миниатюры — DigitalCovers"
        description="Готовые миниатюры для YouTube: CTR-ориентированные дизайны с адаптацией под тёмную и светлую темы."
        keywords="YouTube миниатюры, thumbnail design"
      />
      <div className="container">
        <header className={styles.header}>
          <h1>Миниатюры для YouTube</h1>
          <p>
            Подборки миниатюр, созданных с фокусом на удержание внимания в ленте и соответствие актуальным трендам платформы.
          </p>
        </header>

        <section className={styles.showcase}>
          {thumbnails.map((item) => (
            <figure key={item.title} className={styles.showcaseCard}>
              <img src={item.image} alt={`Миниатюра DigitalCovers ${item.title}`} loading="lazy" />
              <figcaption>
                <h2>{item.title}</h2>
                <p>{item.description}</p>
              </figcaption>
            </figure>
          ))}
        </section>

        <section className={styles.features}>
          <h2>Преимущества коллекции</h2>
          <ul>
            {features.map((feature) => (
              <li key={feature}>{feature}</li>
            ))}
          </ul>
        </section>

        <section className={styles.action}>
          <h2>Выберите идеальную миниатюру</h2>
          <p>Подберите серию, отражающую содержание и эмоцию ролика. Мы поможем с настройками и тестами.</p>
        </section>
      </div>
    </div>
  );
}

export default YouTubeThumbnailsPage;