import React from 'react';
import MetaHelmet from '../components/MetaHelmet';
import styles from './ProductPage.module.css';

const banners = [
  {
    title: 'Ultimate Stream Kit',
    image: 'https://picsum.photos/seed/stream1/1200/800',
    description: 'Комплект экранов ожидания, «скоро вернусь» и панелей донатов в едином стиле.'
  },
  {
    title: 'Esports Arena',
    image: 'https://picsum.photos/seed/stream2/1200/800',
    description: 'Неоновые акценты и динамическая типографика для игровых стримов и киберспортивных лиг.'
  },
  {
    title: 'Cozy Broadcast',
    image: 'https://picsum.photos/seed/stream3/1200/800',
    description: 'Тёплые оттенки, тактильные текстуры и анимированные детали для уютных трансляций.'
  }
];

const features = [
  'Разрешения под Twitch, YouTube Live, Trovo и VK Play',
  'Editable-версии для Adobe After Effects и Photoshop',
  'Панели о канале, расписание, соцсети и партнёры',
  'Лёгкий экспорт статичных и анимированных форматов'
];

function StreamBannersPage() {
  return (
    <div className={styles.wrapper}>
      <MetaHelmet
        title="Баннеры для стримов — DigitalCovers"
        description="Готовые баннеры и overlay-наборы для стримов: экраны ожидания, панели и брендинг трансляций."
        keywords="баннеры стримов, overlays, Twitch баннеры"
      />
      <div className="container">
        <header className={styles.header}>
          <h1>Баннеры для стримов</h1>
          <p>
            Создаём визуальные наборы, которые помогают выделиться в прямом эфире и сохранить грамотную структуру контента.
            Каждый комплект тестируется на популярных платформах.
          </p>
        </header>

        <section className={styles.showcase}>
          {banners.map((item) => (
            <figure key={item.title} className={styles.showcaseCard}>
              <img src={item.image} alt={`Баннер DigitalCovers ${item.title}`} loading="lazy" />
              <figcaption>
                <h2>{item.title}</h2>
                <p>{item.description}</p>
              </figcaption>
            </figure>
          ))}
        </section>

        <section className={styles.features}>
          <h2>Компоненты набора</h2>
          <ul>
            {features.map((feature) => (
              <li key={feature}>{feature}</li>
            ))}
          </ul>
        </section>

        <section className={styles.action}>
          <h2>Соберите уникальную трансляцию</h2>
          <p>Подберите комплект баннеров и overlays, а мы подскажем, как быстро настроить их под ваш поток.</p>
        </section>
      </div>
    </div>
  );
}

export default StreamBannersPage;