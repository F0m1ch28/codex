import React from 'react';
import { Link } from 'react-router-dom';
import MetaHelmet from '../components/MetaHelmet';
import styles from './Categories.module.css';

const categoriesData = [
  {
    title: 'Обложки для видео',
    description: 'Серии обложек с акцентом на storytelling, продуманным типографическим блоком и правильным ритмом.',
    link: '/video-covers'
  },
  {
    title: 'Аватарки',
    description: 'Подборка статичных и анимированных аватарок для Twitch, YouTube и соцсетей, готовых к мгновенному использованию.',
    link: '/avatars'
  },
  {
    title: 'Баннеры для стримов',
    description: 'Линейки баннеров с call-to-action, расписанием трансляций и блоком партнёрских логотипов.',
    link: '/stream-banners'
  },
  {
    title: 'YouTube миниатюры',
    description: 'Смелые контрастные миниатюры, оптимизированные под рекомендации и мобильный просмотр.',
    link: '/youtube-thumbnails'
  },
  {
    title: 'Графика для соцсетей',
    description: 'Пакеты постов, сторис и хайлайтов в единой стилистике с гибкой системой слоёв.',
    link: '/social-media-graphics'
  },
  {
    title: 'Маркетинговые наборы',
    description: 'Комплексные решения: лэндинговые хедеры, email-блоки, обложки подкастов и рекламные тизеры.',
    link: '/services'
  }
];

function CategoriesPage() {
  return (
    <div className={styles.wrapper}>
      <MetaHelmet
        title="Категории продуктов DigitalCovers"
        description="Изучите категории цифровых товаров DigitalCovers: обложки, баннеры, миниатюры и графические наборы."
        keywords="категории, цифровые товары, DigitalCovers"
      />
      <div className="container">
        <header className={styles.header}>
          <h1>Категории DigitalCovers</h1>
          <p>
            Коллекции создаются редакторской командой дизайнеров, иллюстраторов и motion-специалистов.
            Каждая категория включает десятки вариаций и универсальные шаблоны.
          </p>
        </header>

        <div className={styles.grid}>
          {categoriesData.map((category) => (
            <article key={category.title} className={styles.card}>
              <h2>{category.title}</h2>
              <p>{category.description}</p>
              <Link to={category.link} className={styles.cardLink}>Подробнее →</Link>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}

export default CategoriesPage;