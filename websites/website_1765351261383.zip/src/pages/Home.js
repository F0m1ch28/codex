import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import MetaHelmet from '../components/MetaHelmet';
import styles from './Home.module.css';

const categories = [
  {
    title: 'Обложки для видео',
    description: 'Динамичные обложки для роликов и сериалов, создающие мгновенный интерес.',
    link: '/video-covers',
    icon: '🎬'
  },
  {
    title: 'Аватарки',
    description: 'Профессиональные портреты и символы, подчёркивающие индивидуальность аккаунта.',
    link: '/avatars',
    icon: '👤'
  },
  {
    title: 'Баннеры для стримов',
    description: 'Анимированные и статичные баннеры для панелей стримеров и событий.',
    link: '/stream-banners',
    icon: '🎮'
  },
  {
    title: 'YouTube миниатюры',
    description: 'Миниатюры, которые увеличивают CTR и выделяют ваш контент в ленте.',
    link: '/youtube-thumbnails',
    icon: '▶️'
  },
  {
    title: 'Графика для соцсетей',
    description: 'Пакеты постов, stories и highlights для Instagram, TikTok, VK и других платформ.',
    link: '/social-media-graphics',
    icon: '📱'
  },
  {
    title: 'Маркетинговые наборы',
    description: 'Комплекты визуальных материалов для запуска и поддержки кампаний.',
    link: '/services',
    icon: '🌐'
  }
];

const advantages = [
  {
    title: 'Безупречное качество',
    description: 'Каждый макет собирается по гайдам платформ и визуальной айдентике DigitalCovers.'
  },
  {
    title: 'Уникальные решения',
    description: 'Редакторские коллекции обновляются еженедельно — будьте первыми с трендовой графикой.'
  },
  {
    title: 'Мгновенный доступ',
    description: 'После покупки файл доступен сразу с вариантами под разные форматы и расширениями.'
  }
];

const processSteps = [
  { title: 'Выберите дизайн', description: 'Отфильтруйте коллекцию по цвету, настроению и категории.' },
  { title: 'Скачайте макеты', description: 'Получите архив с PSD/FIG, PNG и кратким гайдом по адаптации.' },
  { title: 'Используйте в контенте', description: 'Опубликуйте готовую графику или внесите правки под свой стиль.' }
];

const testimonials = [
  'Обложки DigitalCovers дали моим видео +47% CTR за две недели. Лёгкая адаптация под брендовые цвета и понятный гайд по публикации.',
  'Каждый набор включает версии под разные платформы. Экономим часы работы команды и быстрее запускаем кампании.',
  'Сервис гибкий, всегда свежие коллекции. Поддержка помогла адаптировать пакет под Twitch и вертикальные шоты.'
];

const statsTargets = [
  { label: 'Готовых макетов', value: 4200 },
  { label: 'Брендов в портфолио', value: 120 },
  { label: 'Профессиональных дизайнеров', value: 68 },
  { label: 'Процент довольных клиентов', value: 98 }
];

function HomePage() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [stats, setStats] = useState(statsTargets.map(() => 0));

  useEffect(() => {
    let animationFrame;
    const startTime = performance.now();
    const duration = 1500;

    const animate = (time) => {
      const progress = Math.min((time - startTime) / duration, 1);
      setStats(statsTargets.map((target) => Math.round(target.value * progress)));
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  const currentTestimonial = useMemo(() => testimonials[activeTestimonial], [activeTestimonial]);

  const handlePrev = () => {
    setActiveTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const handleNext = () => {
    setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  return (
    <div className={styles.home}>
      <MetaHelmet
        title="DigitalCovers — профессиональная графика для вашего контента"
        description="DigitalCovers предлагает готовые обложки для видео, аватарки, баннеры для стримов и графику для социальных сетей. Международная доставка цифровых продуктов."
        keywords="DigitalCovers, обложки для видео, баннеры для стримов, миниатюры YouTube, графика для соцсетей"
      />

      <section
        className={styles.hero}
        style={{ backgroundImage: 'linear-gradient(120deg, rgba(24,33,77,0.85), rgba(99,102,241,0.75)), url("https://picsum.photos/1600/900?random=11")' }}
      >
        <div className={`container ${styles.heroContent}`}>
          <div>
            <p className={styles.heroEyebrow}>DigitalCovers</p>
            <h1 className={styles.heroTitle}>Профессиональная графика для вашего контента</h1>
            <p className={styles.heroText}>
              Авторские обложки, миниатюры и графические пакеты под любые платформы.
              Готовые решения, которые усиливают бренд и экономят драгоценное время команды.
            </p>
            <div className={styles.heroActions}>
              <Link to="/categories" className={styles.heroPrimary}>Найти дизайн</Link>
              <Link to="/about" className={styles.heroSecondary}>Узнать о DigitalCovers</Link>
            </div>
          </div>
          <div className={styles.heroStats}>
            {statsTargets.map((item, index) => (
              <div key={item.label} className={styles.heroStatCard}>
                <span className={styles.heroStatNumber}>
                  {stats[index]}
                  {item.label.includes('%') ? '%' : ''}
                  {item.label === 'Процент довольных клиентов' && stats[index] && stats[index] >= 98 ? '%' : ''}
                </span>
                <span className={styles.heroStatLabel}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.categories}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Категории продуктов</h2>
            <p>Выберите формат и мгновенно скачайте дизайн в нужном разрешении.</p>
          </div>
          <div className={styles.categoriesGrid}>
            {categories.map((category) => (
              <Link key={category.title} to={category.link} className={styles.categoryCard}>
                <div className={styles.categoryIcon} aria-hidden="true">{category.icon}</div>
                <h3>{category.title}</h3>
                <p>{category.description}</p>
                <span className={styles.categoryLink}>Перейти →</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.advantages}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Почему DigitalCovers</h2>
            <p>Мы объединяем тренды, опыт дизайнеров и аналитику контент-платформ.</p>
          </div>
          <div className={styles.advantagesGrid}>
            {advantages.map((advantage) => (
              <article key={advantage.title} className={styles.advantageCard}>
                <h3>{advantage.title}</h3>
                <p>{advantage.description}</p>
              </article>
            ))}
          </div>
          <div className={styles.statsRow}>
            {statsTargets.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statNumber}>
                  {stats[index]}
                  {stat.label === 'Процент довольных клиентов' ? '%' : '+'}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Как это работает</h2>
            <p>Три шага от идеи до публикации нового визуального стиля.</p>
          </div>
          <ol className={styles.processList}>
            {processSteps.map((step, index) => (
              <li key={step.title} className={styles.processItem}>
                <span className={styles.processNumber}>{index + 1}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Отзывы</h2>
            <p>Цифровые креаторы о сотрудничестве с DigitalCovers.</p>
          </div>
          <div className={styles.testimonialCard}>
            <p className={styles.testimonialText} aria-live="polite">{currentTestimonial}</p>
            <div className={styles.testimonialControls}>
              <button type="button" onClick={handlePrev} aria-label="Предыдущий отзыв">←</button>
              <span className={styles.testimonialCounter}>
                {activeTestimonial + 1}
                {' '}
                /
                {' '}
                {testimonials.length}
              </span>
              <button type="button" onClick={handleNext} aria-label="Следующий отзыв">→</button>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaBox}>
            <h2>Начните улучшать свой контент сегодня</h2>
            <p>Подберите дизайн, который поможет вашим роликам, стримам и постам выделиться.</p>
            <div className={styles.ctaActions}>
              <Link to="/services" className={styles.heroPrimary}>Исследовать решения</Link>
              <Link to="/contact" className={styles.ctaSecondary}>Связаться с нами</Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default HomePage;