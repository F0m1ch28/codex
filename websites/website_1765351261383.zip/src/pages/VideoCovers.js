import React from 'react';
import MetaHelmet from '../components/MetaHelmet';
import styles from './ProductPage.module.css';

const showcase = [
  {
    title: 'Cinematic Pulse',
    image: 'https://picsum.photos/seed/videocover1/1200/800',
    description: 'Глубокие тени, выразительный шрифт и динамичный градиентный фон для премьерных роликов.'
  },
  {
    title: 'Tech Insight',
    image: 'https://picsum.photos/seed/videocover2/1200/800',
    description: 'Упорядоченный лэйаут и яркие акцентные элементы для обзорных видео и гайдлайнов.'
  },
  {
    title: 'Lifestyle Flow',
    image: 'https://picsum.photos/seed/videocover3/1200/800',
    description: 'Тёплая палитра, реалистичные mockup-фотографии и гибкая сетка для влогов и интервью.'
  }
];

const features = [
  'Соответствие рекомендациям YouTube и ВКонтакте',
  'PSD и Figma-файлы с организованной структурой слоёв',
  'Версии под горизонтальные и вертикальные обложки',
  'Бонусный гайд по адаптации цвета и текста'
];

function VideoCoversPage() {
  return (
    <div className={styles.wrapper}>
      <MetaHelmet
        title="Обложки для видео — DigitalCovers"
        description="Коллекция обложек для видеоконтента: премьеры, обзоры, лайфстайл. Готовые шаблоны PSD и Figma."
        keywords="обложки для видео, video cover, шаблоны обложек"
      />
      <div className="container">
        <header className={styles.header}>
          <h1>Обложки для видео</h1>
          <p>
            Визуально выразительные обложки, которые увеличивают кликабельность и поддерживают айдентику канала.
            Каждая серия проходит проверку на разных устройствах и адаптируется под платформы.
          </p>
        </header>

        <section className={styles.showcase}>
          {showcase.map((item) => (
            <figure key={item.title} className={styles.showcaseCard}>
              <img src={item.image} alt={`Пример обложки DigitalCovers ${item.title}`} loading="lazy" />
              <figcaption>
                <h2>{item.title}</h2>
                <p>{item.description}</p>
              </figcaption>
            </figure>
          ))}
        </section>

        <section className={styles.features}>
          <h2>Что входит в набор</h2>
          <ul>
            {features.map((feature) => (
              <li key={feature}>{feature}</li>
            ))}
          </ul>
        </section>

        <section className={styles.action}>
          <h2>Готовы подобрать коллекцию?</h2>
          <p>Перейдите в общий каталог и выберите серию обложек под ваш формат контента.</p>
        </section>
      </div>
    </div>
  );
}

export default VideoCoversPage;