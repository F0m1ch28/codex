import React from 'react';
import MetaHelmet from '../components/MetaHelmet';
import styles from './About.module.css';

const timeline = [
  { year: '2019', event: 'Старт команды DigitalCovers и первая коллекция обложек для YouTube.' },
  { year: '2020', event: 'Запуск пакетов для стримов и интеграция с международными маркетплейсами.' },
  { year: '2022', event: 'Создание редакторского отделения и каталога для брендов и агентств.' },
  { year: '2023', event: 'Выход на международный рынок и расширение продуктовой линейки.' }
];

const team = [
  {
    name: 'Марина Михайлова',
    role: 'Арт-директор',
    image: 'https://picsum.photos/seed/team1/400/400',
    description: 'Куратор визуальной платформы DigitalCovers и автор стилистических гидов.'
  },
  {
    name: 'Рашид Абдуллаев',
    role: 'Lead Motion Designer',
    image: 'https://picsum.photos/seed/team2/400/400',
    description: 'Разрабатывает анимированные overlays и обучает команду motion-направлению.'
  },
  {
    name: 'Виктория Соколова',
    role: 'Head of Content',
    image: 'https://picsum.photos/seed/team3/400/400',
    description: 'Анализирует тренды платформ и формирует пакетные предложения.'
  }
];

const values = [
  { title: 'Креативность', description: 'Мы объединяем визуальный язык и аналитику, чтобы дизайн был не только красивым, но и эффективным.' },
  { title: 'Скорость', description: 'Весь контент готов к публикации сразу — без долгих согласований и ожиданий.' },
  { title: 'Поддержка', description: 'Помогаем внедрить дизайн, настройть шаблоны и делимся best practices.' }
];

function AboutPage() {
  return (
    <div className={styles.wrapper}>
      <MetaHelmet
        title="О компании DigitalCovers"
        description="DigitalCovers — команда дизайнеров и стратегов. Создаём цифровую графику для видео, стримов и социальных сетей."
        keywords="о компании, DigitalCovers, дизайнерская команда"
      />
      <div className="container">
        <header className={styles.header}>
          <h1>О DigitalCovers</h1>
          <p>
            DigitalCovers — международная команда дизайнеров, контент-стратегов и motion-специалистов.
            Мы создаём цифровые продукты, которые помогают создателям контента и брендам быстро запускать визуальные кампании.
          </p>
        </header>

        <section className={styles.values}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h2>{value.title}</h2>
              <p>{value.description}</p>
            </article>
          ))}
        </section>

        <section className={styles.timeline}>
          <h2>Как развивалась компания</h2>
          <ul>
            {timeline.map((item) => (
              <li key={item.year}>
                <span className={styles.timelineYear}>{item.year}</span>
                <p>{item.event}</p>
              </li>
            ))}
          </ul>
        </section>

        <section className={styles.team}>
          <h2>Команда</h2>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img src={member.image} alt={member.name} loading="lazy" />
                </div>
                <div>
                  <h3>{member.name}</h3>
                  <span className={styles.teamRole}>{member.role}</span>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

export default AboutPage;