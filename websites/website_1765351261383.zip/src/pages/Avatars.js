import React from 'react';
import MetaHelmet from '../components/MetaHelmet';
import styles from './ProductPage.module.css';

const avatars = [
  {
    title: 'Stream Persona',
    image: 'https://picsum.photos/seed/avatar1/1200/800',
    description: 'Контрастная подсветка и фирменные формы под стилистику каналов Twitch и Kick.'
  },
  {
    title: 'Creator Portrait',
    image: 'https://picsum.photos/seed/avatar2/1200/800',
    description: 'Чистая геометрия и адаптивная сетка для социальных сетей и подписных сервисов.'
  },
  {
    title: 'Brand Icon',
    image: 'https://picsum.photos/seed/avatar3/1200/800',
    description: 'Минималистичный знак для телеграм-каналов и закрытых комьюнити.'
  }
];

const features = [
  'Форматы PNG, SVG, WEBP и PSD',
  'Версии под светлую и тёмную темы интерфейсов',
  'Инструкции по правильному масштабированию',
  'Опциональные анимированные варианты'
];

function AvatarsPage() {
  return (
    <div className={styles.wrapper}>
      <MetaHelmet
        title="Аватарки для брендов и авторов — DigitalCovers"
        description="Готовые аватарки DigitalCovers: портреты, брендовые иконки и анимированные версии для социальных сетей."
        keywords="аватарки, иконки, брендинг"
      />
      <div className="container">
        <header className={styles.header}>
          <h1>Аватарки DigitalCovers</h1>
          <p>
            Уникальные аватарки, подчеркивающие стиль канала и легко узнаваемые на любых носителях.
            Мы делаем акцент на читаемости и работе в маленьком размере.
          </p>
        </header>

        <section className={styles.showcase}>
          {avatars.map((item) => (
            <figure key={item.title} className={styles.showcaseCard}>
              <img src={item.image} alt={`Пример аватарки DigitalCovers ${item.title}`} loading="lazy" />
              <figcaption>
                <h2>{item.title}</h2>
                <p>{item.description}</p>
              </figcaption>
            </figure>
          ))}
        </section>

        <section className={styles.features}>
          <h2>Преимущества пакета</h2>
          <ul>
            {features.map((feature) => (
              <li key={feature}>{feature}</li>
            ))}
          </ul>
        </section>

        <section className={styles.action}>
          <h2>Наборы готовы к загрузке</h2>
          <p>Загляните в каталог и подберите стиль, который соответствует вашей аудитории.</p>
        </section>
      </div>
    </div>
  );
}

export default AvatarsPage;