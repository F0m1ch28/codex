import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import MetaHelmet from '../components/MetaHelmet';
import styles from './Services.module.css';

const serviceCards = [
  {
    title: 'Комплекты для запусков',
    description: 'Готовые пакеты графики для анонсов, тизеров и pre-launch активностей.',
    benefit: 'Поддержка email, соцсетей и landing page.'
  },
  {
    title: 'Стриминговые наборы',
    description: 'Overlay-композиции, панели донатов и экранные шаблоны для трансляций.',
    benefit: 'Модульные блоки и адаптивность под разные платформы.'
  },
  {
    title: 'Контентные коллекции',
    description: 'Шаблоны для регулярных рубрик и контент-планов брендов.',
    benefit: 'Встроенные варианты цветовых схем и типографики.'
  }
];

const portfolioItems = [
  { title: 'Creator Launch Kit', category: 'launch', image: 'https://picsum.photos/seed/portfolio1/800/600' },
  { title: 'E-sports Overlay', category: 'stream', image: 'https://picsum.photos/seed/portfolio2/800/600' },
  { title: 'Shorts Booster', category: 'video', image: 'https://picsum.photos/seed/portfolio3/800/600' },
  { title: 'Event Promo Pack', category: 'launch', image: 'https://picsum.photos/seed/portfolio4/800/600' },
  { title: 'Edu Channel Graphics', category: 'video', image: 'https://picsum.photos/seed/portfolio5/800/600' },
  { title: 'Community Social Kit', category: 'social', image: 'https://picsum.photos/seed/portfolio6/800/600' }
];

const blogPreview = [
  {
    title: 'Как выбрать визуальный язык YouTube-канала',
    excerpt: 'Пошаговый чек-лист DigitalCovers для настройки сетки миниатюр и обложек.',
    link: '/categories'
  },
  {
    title: '5 трендов графики для стримингов',
    excerpt: 'Прозрачные панели, адаптивные анимации и современные типографические решения.',
    link: '/stream-banners'
  },
  {
    title: 'Как поддерживать единый стиль в соцсетях',
    excerpt: 'Авторский гайд по созданию контентных коллекций и сеток постов.',
    link: '/social-media-graphics'
  }
];

const filters = [
  { key: 'all', label: 'Все проекты' },
  { key: 'launch', label: 'Запуски' },
  { key: 'stream', label: 'Стримы' },
  { key: 'video', label: 'Видео' },
  { key: 'social', label: 'Соцсети' }
];

const faqItems = [
  {
    question: 'Можно ли адаптировать дизайн под брендбук?',
    answer: 'Да, каждый набор включает основные цвета и шрифты. Вы можете заменить их на свои в Figma/PSD. По запросу команда DigitalCovers подготовит адаптацию.'
  },
  {
    question: 'Как быстро я получу файлы после оплаты?',
    answer: 'Файлы доступны сразу в личном кабинете и приходят на email. Скачивание не ограничено по времени.'
  },
  {
    question: 'Есть ли лицензия на коммерческое использование?',
    answer: 'Да, стандартная лицензия DigitalCovers позволяет использовать материалы в коммерческих и промоцелях с указанием авторства DigitalCovers.'
  }
];

function ServicesPage() {
  const [activeFilter, setActiveFilter] = useState('all');

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'all') return portfolioItems;
    return portfolioItems.filter((item) => item.category === activeFilter);
  }, [activeFilter]);

  return (
    <div className={styles.wrapper}>
      <MetaHelmet
        title="Решения и сервисы DigitalCovers"
        description="Комплексные наборы графики DigitalCovers: готовые решения для запусков, стримов и социальных сетей."
        keywords="решения DigitalCovers, графические пакеты, маркетинговые наборы"
      />
      <div className="container">
        <header className={styles.hero}>
          <div>
            <h1>Решения DigitalCovers</h1>
            <p>
              Сфокусируйтесь на контенте, а визуальную часть доверьте DigitalCovers.
              Мы предлагаем наборы, которые адаптируются под кампании, стримы и социальные сети.
            </p>
          </div>
          <Link to="/contact" className={styles.heroButton}>Запросить консультацию</Link>
        </header>

        <section className={styles.services}>
          {serviceCards.map((card) => (
            <article key={card.title} className={styles.serviceCard}>
              <h2>{card.title}</h2>
              <p>{card.description}</p>
              <span>{card.benefit}</span>
            </article>
          ))}
        </section>

        <section className={styles.portfolio}>
          <div className={styles.sectionHeader}>
            <h2>Портфолио проектов</h2>
            <p>Отфильтруйте примеры по формату, чтобы увидеть подходящие решения.</p>
          </div>
          <div className={styles.filters} role="tablist" aria-label="Фильтр проектов">
            {filters.map((filter) => (
              <button
                key={filter.key}
                type="button"
                className={`${styles.filterButton} ${activeFilter === filter.key ? styles.filterActive : ''}`}
                onClick={() => setActiveFilter(filter.key)}
                aria-pressed={activeFilter === filter.key}
              >
                {filter.label}
              </button>
            ))}
          </div>
          <div className={styles.portfolioGrid}>
            {filteredProjects.map((project) => (
              <figure key={project.title} className={styles.portfolioCard}>
                <img src={project.image} alt={`Пример проекта DigitalCovers ${project.title}`} loading="lazy" />
                <figcaption>
                  <h3>{project.title}</h3>
                  <span className={styles.portfolioTag}>{project.category}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </section>

        <section className={styles.blog}>
          <h2>DigitalCovers Insights</h2>
          <div className={styles.blogGrid}>
            {blogPreview.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.blogLink}>Читать →</Link>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.faq}>
          <h2>FAQ</h2>
          <div className={styles.faqList}>
            {faqItems.map((item) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

export default ServicesPage;