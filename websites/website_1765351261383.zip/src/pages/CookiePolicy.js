import React from 'react';
import MetaHelmet from '../components/MetaHelmet';
import styles from './Legal.module.css';

function CookiePolicyPage() {
  return (
    <div className={styles.wrapper}>
      <MetaHelmet
        title="Политика cookies — DigitalCovers"
        description="Политика использования cookies DigitalCovers."
        keywords="cookies, политика cookies"
      />
      <div className="container">
        <header className={styles.header}>
          <h1>Политика cookies</h1>
          <p>Описание способов использования файлов cookies на сайте digitalcovers.ru.</p>
        </header>

        <section className={styles.section}>
          <h2>1. Что такое cookies</h2>
          <p>
            Cookies — небольшие файлы, сохраняемые браузером для улучшения работы сайта и сохранения пользовательских настроек.
          </p>
        </section>

        <section className={styles.section}>
          <h2>2. Типы cookies</h2>
          <ul>
            <li><strong>Обязательные:</strong> обеспечивают корректную работу сайта и авторизацию.</li>
            <li><strong>Аналитические:</strong> помогают оценивать посещаемость и улучшать контент.</li>
            <li><strong>Функциональные:</strong> запоминают ваши настройки интерфейса.</li>
          </ul>
        </section>

        <section className={styles.section}>
          <h2>3. Управление cookies</h2>
          <p>
            Пользователь может изменить настройки cookies в браузере. При отключении некоторых файлов функциональность сайта может быть ограничена.
          </p>
        </section>

        <section className={styles.section}>
          <h2>4. Контакты</h2>
          <p>
            Вопросы по cookies направляйте на info@digitalcovers.ru или звоните по номеру +7 (999) 123-45-67.
          </p>
        </section>
      </div>
    </div>
  );
}

export default CookiePolicyPage;