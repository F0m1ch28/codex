import React, { useState } from 'react';
import MetaHelmet from '../components/MetaHelmet';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  message: ''
};

function ContactPage() {
  const [form, setForm] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Введите ваше имя';
    if (!form.email.trim()) {
      newErrors.email = 'Введите email';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = 'Укажите корректный email';
    }
    if (!form.message.trim()) newErrors.message = 'Опишите ваш запрос';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setForm(initialState);
  };

  return (
    <div className={styles.wrapper}>
      <MetaHelmet
        title="Контакты DigitalCovers"
        description="Свяжитесь с DigitalCovers: электронная почта, телефон, адрес и форма обратной связи."
        keywords="контакты DigitalCovers, поддержка, связь"
      />
      <div className="container">
        <header className={styles.header}>
          <h1>Свяжитесь с нами</h1>
          <p>
            Команда DigitalCovers поможет подобрать коллекцию, адаптировать дизайн и ответит на любые вопросы.
          </p>
        </header>

        <div className={styles.layout}>
          <section className={styles.info}>
            <h2>Контактные данные</h2>
            <ul>
              <li><strong>Адрес:</strong> ул. Цифровая, 15, Москва, Россия, 123456</li>
              <li><strong>Телефон:</strong> <a href="tel:+79991234567">+7 (999) 123-45-67</a></li>
              <li><strong>Email:</strong> <a href="mailto:info@digitalcovers.ru">info@digitalcovers.ru</a></li>
            </ul>
            <p className={styles.note}>
              Мы работаем в международном формате и подбираем цифровые решения вне зависимости от часового пояса.
            </p>
          </section>

          <section className={styles.formSection}>
            <h2>Форма обращения</h2>
            {submitted && (
              <div className={styles.success} role="status">
                Спасибо! Мы получили ваше сообщение и свяжемся в течение рабочего дня.
              </div>
            )}
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <label htmlFor="name">
                Имя
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={form.name}
                  onChange={handleChange}
                  placeholder="Как к вам обращаться"
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                />
                {errors.name && <span id="name-error" className={styles.error}>{errors.name}</span>}
              </label>

              <label htmlFor="email">
                Email
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={form.email}
                  onChange={handleChange}
                  placeholder="example@digitalcovers.ru"
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                />
                {errors.email && <span id="email-error" className={styles.error}>{errors.email}</span>}
              </label>

              <label htmlFor="message">
                Сообщение
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={form.message}
                  onChange={handleChange}
                  placeholder="Расскажите о проекте или вопросе"
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                />
                {errors.message && <span id="message-error" className={styles.error}>{errors.message}</span>}
              </label>

              <button type="submit" className={styles.submit}>Отправить сообщение</button>
            </form>
          </section>
        </div>
      </div>
    </div>
  );
}

export default ContactPage;