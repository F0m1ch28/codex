import React from 'react';
import MetaHelmet from '../components/MetaHelmet';
import styles from './Legal.module.css';

function PrivacyPage() {
  return (
    <div className={styles.wrapper}>
      <MetaHelmet
        title="Политика конфиденциальности — DigitalCovers"
        description="Политика конфиденциальности DigitalCovers: обработка и хранение персональных данных."
        keywords="политика конфиденциальности, DigitalCovers"
      />
      <div className="container">
        <header className={styles.header}>
          <h1>Политика конфиденциальности</h1>
          <p>Как DigitalCovers обрабатывает и хранит персональные данные пользователей.</p>
        </header>

        <section className={styles.section}>
          <h2>1. Сбор данных</h2>
          <p>
            Мы собираем только информацию, которую пользователь предоставляет добровольно: имя, email, контактные данные и сведения о проекте.
          </p>
        </section>

        <section className={styles.section}>
          <h2>2. Цели обработки</h2>
          <ul>
            <li>Предоставление доступа к цифровым продуктам и поддержке.</li>
            <li>Информирование об обновлениях коллекций и сервисов DigitalCovers.</li>
            <li>Анализ качества обслуживания и улучшение пользовательского опыта.</li>
          </ul>
        </section>

        <section className={styles.section}>
          <h2>3. Хранение данных</h2>
          <p>
            Данные хранятся на защищённых серверах и удаляются по запросу пользователя. Мы не передаём информацию третьим лицам без согласия.
          </p>
        </section>

        <section className={styles.section}>
          <h2>4. Cookies</h2>
          <p>
            Мы используем cookies для персонализации интерфейса и аналитики. Пользователь может отказаться от cookies, используя настройки браузера.
          </p>
        </section>

        <section className={styles.section}>
          <h2>5. Контакты</h2>
          <p>
            По вопросам конфиденциальности пишите на info@digitalcovers.ru или звоните по номеру +7 (999) 123-45-67.
          </p>
        </section>
      </div>
    </div>
  );
}

export default PrivacyPage;