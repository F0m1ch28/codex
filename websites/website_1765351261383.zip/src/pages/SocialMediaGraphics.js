import React from 'react';
import MetaHelmet from '../components/MetaHelmet';
import styles from './ProductPage.module.css';

const graphics = [
  {
    title: 'Social Pulse Pack',
    image: 'https://picsum.photos/seed/social1/1200/800',
    description: 'Универсальные шаблоны для Instagram, TikTok и VK с акцентом на сторителлинг и интерактив.'
  },
  {
    title: 'Brand Stories',
    image: 'https://picsum.photos/seed/social2/1200/800',
    description: 'Вертикальные и квадратные макеты со слотом для пользовательского контента и CTA.'
  },
  {
    title: 'Campaign Sprint',
    image: 'https://picsum.photos/seed/social3/1200/800',
    description: 'Набор для быстрых запусков: посты, истории, баннеры и рекламные креативы.'
  }
];

const features = [
  'Поддержка основных сеток социальных платформ',
  'Варианты для сезонных и evergreen-кампаний',
  'Редактируемые шрифтовые стили и палитры',
  'Гайды по публикации и motion-сценарии'
];

function SocialMediaGraphicsPage() {
  return (
    <div className={styles.wrapper}>
      <MetaHelmet
        title="Графика для социальных сетей — DigitalCovers"
        description="Комплекты графики DigitalCovers для соцсетей: посты, stories, highlights и рекламные креативы."
        keywords="графика для соцсетей, social media design"
      />
      <div className="container">
        <header className={styles.header}>
          <h1>Графика для социальных сетей</h1>
          <p>
            Поддерживайте единую визуальную линию во всех каналах. Наши наборы созданы с учётом сценариев взаимодействия аудитории.
          </p>
        </header>

        <section className={styles.showcase}>
          {graphics.map((item) => (
            <figure key={item.title} className={styles.showcaseCard}>
              <img src={item.image} alt={`Графический набор DigitalCovers ${item.title}`} loading="lazy" />
              <figcaption>
                <h2>{item.title}</h2>
                <p>{item.description}</p>
              </figcaption>
            </figure>
          ))}
        </section>

        <section className={styles.features}>
          <h2>Что вы получаете</h2>
          <ul>
            {features.map((feature) => (
              <li key={feature}>{feature}</li>
            ))}
          </ul>
        </section>

        <section className={styles.action}>
          <h2>Ускорьте производство контента</h2>
          <p>Воспользуйтесь коллекциями DigitalCovers, чтобы быстро адаптировать визуальную стратегию под новые кампании.</p>
        </section>
      </div>
    </div>
  );
}

export default SocialMediaGraphicsPage;