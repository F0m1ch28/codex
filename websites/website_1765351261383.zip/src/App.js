import React from 'react';
import { Routes, Route, Outlet } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import HomePage from './pages/Home';
import CategoriesPage from './pages/Categories';
import VideoCoversPage from './pages/VideoCovers';
import AvatarsPage from './pages/Avatars';
import StreamBannersPage from './pages/StreamBanners';
import YouTubeThumbnailsPage from './pages/YouTubeThumbnails';
import SocialMediaGraphicsPage from './pages/SocialMediaGraphics';
import AboutPage from './pages/About';
import ContactPage from './pages/Contact';
import TermsPage from './pages/Terms';
import PrivacyPage from './pages/Privacy';
import CookiePolicyPage from './pages/CookiePolicy';
import ServicesPage from './pages/Services';

const Layout = () => (
  <>
    <Header />
    <main className="main-content" id="main-content">
      <Outlet />
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTop />
  </>
);

function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="categories" element={<CategoriesPage />} />
        <Route path="video-covers" element={<VideoCoversPage />} />
        <Route path="avatars" element={<AvatarsPage />} />
        <Route path="stream-banners" element={<StreamBannersPage />} />
        <Route path="youtube-thumbnails" element={<YouTubeThumbnailsPage />} />
        <Route path="social-media-graphics" element={<SocialMediaGraphicsPage />} />
        <Route path="services" element={<ServicesPage />} />
        <Route path="about" element={<AboutPage />} />
        <Route path="contact" element={<ContactPage />} />
        <Route path="terms" element={<TermsPage />} />
        <Route path="privacy" element={<PrivacyPage />} />
        <Route path="cookie-policy" element={<CookiePolicyPage />} />
      </Route>
    </Routes>
  );
}

export default App;