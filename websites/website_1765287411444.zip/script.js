document.addEventListener("DOMContentLoaded", () => {
    const currentPage = document.body.dataset.page;
    const navLinks = document.querySelectorAll("[data-page-link]");
    navLinks.forEach((link) => {
        if (link.dataset.pageLink === currentPage) {
            link.classList.add("is-active");
            link.setAttribute("aria-current", "page");
        }
    });

    const cookieBanner = document.getElementById("cookie-banner");
    if (!cookieBanner) return;

    const consent = localStorage.getItem("hsfr-cookie-consent");
    if (!consent) {
        cookieBanner.classList.add("is-visible");
        cookieBanner.setAttribute("aria-hidden", "false");
    } else {
        cookieBanner.setAttribute("aria-hidden", "true");
    }

    const acceptButton = document.getElementById("cookie-accept");
    const declineButton = document.getElementById("cookie-decline");

    const hideBanner = () => {
        cookieBanner.classList.remove("is-visible");
        cookieBanner.setAttribute("aria-hidden", "true");
    };

    if (acceptButton) {
        acceptButton.addEventListener("click", () => {
            localStorage.setItem("hsfr-cookie-consent", "accepted");
            hideBanner();
        });
    }

    if (declineButton) {
        declineButton.addEventListener("click", () => {
            localStorage.setItem("hsfr-cookie-consent", "declined");
            hideBanner();
        });
    }
});