import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Helmet } from "react-helmet";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Solutions from "./pages/Solutions";
import Hardware from "./pages/Hardware";
import Integrationen from "./pages/Integrationen";
import Ressourcen from "./pages/Ressourcen";
import Sicherheit from "./pages/Sicherheit";
import Kontakt from "./pages/Kontakt";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import CookiePolicy from "./pages/CookiePolicy";
import styles from "./App.module.css";

function App() {
  return (
    <Router>
      <Helmet>
        <html lang="de" />
        <meta name="theme-color" content="#0F172A" />
      </Helmet>
      <a className="skipLink" href="#mainContent">
        Zum Hauptinhalt springen
      </a>
      <div className={styles.appWrapper}>
        <Header />
        <ScrollToTop />
        <main id="mainContent" className={styles.mainContent}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/über-uns" element={<About />} />
            <Route path="/funktionen" element={<Services />} />
            <Route path="/lösungen" element={<Solutions />} />
            <Route path="/hardware" element={<Hardware />} />
            <Route path="/integrationen" element={<Integrationen />} />
            <Route path="/ressourcen" element={<Ressourcen />} />
            <Route path="/sicherheit" element={<Sicherheit />} />
            <Route path="/kontakt" element={<Kontakt />} />
            <Route path="/rechtliches" element={<Terms />} />
            <Route path="/datenschutz" element={<Privacy />} />
            <Route path="/cookie-richtlinie" element={<CookiePolicy />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
      </div>
    </Router>
  );
}

export default App;