import React, { useState, useEffect } from "react";
import styles from "./CookieBanner.module.css";

const STORAGE_KEY = "klyvratica_cookie_consent";

function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleConsent = (value) => {
    window.localStorage.setItem(STORAGE_KEY, value);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Wir verwenden Cookies, um die Nutzung unserer Plattform zu analysieren
          und Funktionen zu verbessern. Details findest du in unserer{" "}
          <a href="/datenschutz">Datenschutzinformation</a>.
        </p>
        <div className={styles.actions}>
          <button
            type="button"
            className="btnSecondary"
            onClick={() => handleConsent("declined")}
          >
            Ablehnen
          </button>
          <button
            type="button"
            className="btnPrimary"
            onClick={() => handleConsent("accepted")}
          >
            Zustimmen
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;