import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brand}>
            <h3>Klyvratica</h3>
            <p>
              Smart-Store-Plattform aus Köln. Wir verbinden Menschen, Waren und
              Geräte zu einer verlässlichen Einkaufserfahrung.
            </p>
            <address className={styles.address}>
              <span>Schildergasse 72</span>
              <span>50667 Köln</span>
              <span>Deutschland</span>
              <a href="tel:+4922129123456">+49 221 29123456</a>
              <a href="mailto:hallo@klyvratica.com">hallo@klyvratica.com</a>
            </address>
          </div>
          <div>
            <h4>Navigieren</h4>
            <ul className={styles.linkList}>
              <li>
                <NavLink to="/funktionen">Funktionen</NavLink>
              </li>
              <li>
                <NavLink to="/lösungen">Lösungen</NavLink>
              </li>
              <li>
                <NavLink to="/hardware">Hardware</NavLink>
              </li>
              <li>
                <NavLink to="/integrationen">Integrationen</NavLink>
              </li>
              <li>
                <NavLink to="/ressourcen">Ressourcen</NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h4>Recht &amp; Vertrauen</h4>
            <ul className={styles.linkList}>
              <li>
                <NavLink to="/sicherheit">Sicherheit</NavLink>
              </li>
              <li>
                <NavLink to="/rechtliches">Nutzungsbedingungen</NavLink>
              </li>
              <li>
                <NavLink to="/datenschutz">Datenschutz</NavLink>
              </li>
              <li>
                <NavLink to="/cookie-richtlinie">Cookie-Richtlinie</NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h4>Folge uns</h4>
            <ul className={styles.socialList}>
              <li>
                <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
                  LinkedIn
                </a>
              </li>
              <li>
                <a href="https://www.instagram.com" target="_blank" rel="noreferrer">
                  Instagram
                </a>
              </li>
              <li>
                <a href="https://www.youtube.com" target="_blank" rel="noreferrer">
                  YouTube
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className={styles.legal}>
          <p>© {new Date().getFullYear()} Klyvratica. Alle Rechte vorbehalten.</p>
          <p>Smart-Store-Intelligenz aus Köln für den stationären Handel.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;