import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import styles from "./Header.module.css";

const navItems = [
  { path: "/", label: "Start" },
  { path: "/funktionen", label: "Funktionen" },
  { path: "/lösungen", label: "Lösungen" },
  { path: "/hardware", label: "Hardware" },
  { path: "/integrationen", label: "Integrationen" },
  { path: "/ressourcen", label: "Ressourcen" },
  { path: "/sicherheit", label: "Sicherheit" },
  { path: "/über-uns", label: "Über uns" },
  { path: "/kontakt", label: "Kontakt" }
];

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header} aria-label="Hauptnavigation">
      <div className={`container ${styles.headerInner}`}>
        <div className={styles.branding}>
          <NavLink to="/" className={styles.logo} onClick={closeMenu}>
            <span aria-hidden="true">⚡</span>
            <span className={styles.logoText}>Klyvratica</span>
          </NavLink>
        </div>
        <button
          className={styles.menuButton}
          onClick={toggleMenu}
          aria-expanded={menuOpen}
          aria-controls="hauptnavigation"
        >
          <span className={styles.menuIcon} aria-hidden="true"></span>
          <span className="sr-only">Navigation öffnen</span>
        </button>
        <nav
          id="hauptnavigation"
          className={`${styles.nav} ${menuOpen ? styles.open : ""}`}
        >
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ""}`
                  }
                  onClick={closeMenu}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <NavLink
            to="/kontakt"
            className={`${styles.ctaButton} btnPrimary`}
            onClick={closeMenu}
          >
            Demo anfragen
          </NavLink>
        </nav>
      </div>
    </header>
  );
}

export default Header;