import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Legal.module.css";

function Terms() {
  return (
    <>
      <Helmet>
        <title>Klyvratica Nutzungsbedingungen</title>
        <meta
          name="description"
          content="Nutzungsbedingungen der Klyvratica Smart-Store-Plattform."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Nutzungsbedingungen</h1>
          <p>Stand: Januar 2024</p>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.content}`}>
        <div className="container">
          <h2>1. Geltungsbereich</h2>
          <p>
            Diese Nutzungsbedingungen gelten für alle Verträge und Leistungen rund
            um die Nutzung der Klyvratica Smart-Store-Plattform sowie der zugehörigen
            Services. Abweichende Bedingungen finden nur Anwendung, wenn sie
            schriftlich bestätigt wurden.
          </p>

          <h2>2. Leistungen</h2>
          <p>
            Klyvratica stellt eine modulare Softwareplattform zur Verfügung, die
            Handelsunternehmen beim Betrieb vernetzter Stores unterstützt. Inhalte
            und Funktionen werden gemeinsam definiert und in Service-Level-Vereinbarungen
            dokumentiert.
          </p>

          <h2>3. Zugang & Sicherheit</h2>
          <p>
            Nutzerinnen erhalten personalisierte Zugänge. Der Schutz dieser Zugänge
            liegt in ihrer Verantwortung. Zugriffe werden protokolliert, um
            Missbrauch vorzubeugen. Klyvratica kann bei Sicherheitsbedenken Zugänge
            temporär sperren.
          </p>

          <h2>4. Mitwirkungspflichten</h2>
          <p>
            Kundinnen stellen sicher, dass notwendige Informationen, Kontaktpersonen
            sowie technische Voraussetzungen bereitstehen. Verzögerungen durch
            fehlende Mitwirkung können Zeitpläne beeinflussen.
          </p>

          <h2>5. Haftung</h2>
          <p>
            Klyvratica haftet für Vorsatz und grobe Fahrlässigkeit. Bei leichter
            Fahrlässigkeit besteht Haftung nur bei Verletzung wesentlicher
            Vertragspflichten (Kardinalpflichten) und begrenzt auf vorhersehbare,
            vertragstypische Schäden.
          </p>

          <h2>6. Geistiges Eigentum</h2>
          <p>
            Sämtliche Rechte an Software, Dokumentationen und Materialien verbleiben
            bei Klyvratica, soweit nicht ausdrücklich anders vereinbart. Kundinnen
            erhalten ein einfaches Nutzungsrecht für die vereinbarte Laufzeit.
          </p>

          <h2>7. Laufzeit & Beendigung</h2>
          <p>
            Vertragslaufzeiten werden individuell vereinbart. Nach Ablauf verlängert
            sich der Vertrag, sofern nicht fristgerecht gekündigt wird. Gesetzliche
            Kündigungsrechte bleiben unberührt.
          </p>

          <h2>8. Schlussbestimmungen</h2>
          <p>
            Es gilt deutsches Recht. Gerichtsstand ist Köln, sofern gesetzlich zulässig.
            Sollten einzelne Bestimmungen unwirksam sein, berührt dies nicht die
            Wirksamkeit der übrigen Regelungen.
          </p>
        </div>
      </section>
    </>
  );
}

export default Terms;