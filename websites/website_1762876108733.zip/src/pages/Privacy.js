import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Legal.module.css";

function Privacy() {
  return (
    <>
      <Helmet>
        <title>Klyvratica Datenschutzinformation</title>
        <meta
          name="description"
          content="Datenschutzinformationen der Klyvratica Smart-Store-Plattform nach DSGVO."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Datenschutzinformation</h1>
          <p>Stand: Januar 2024</p>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.content}`}>
        <div className="container">
          <h2>1. Verantwortlicher</h2>
          <p>
            Verantwortlich im Sinne der DSGVO ist Klyvratica GmbH, Schildergasse 72,
            50667 Köln, Deutschland. E-Mail: datenschutz@klyvratica.com
          </p>

          <h2>2. Verarbeitungszwecke</h2>
          <p>
            Wir verarbeiten personenbezogene Daten zur Bereitstellung und
            Weiterentwicklung unserer Plattform, zur Kommunikation mit Kundinnen
            sowie zur Einhaltung gesetzlicher Pflichten.
          </p>

          <h2>3. Rechtsgrundlagen</h2>
          <p>
            Die Verarbeitung erfolgt gemäß Art. 6 Abs. 1 lit. b DSGVO zur
            Vertragserfüllung, lit. c zur Erfüllung rechtlicher Verpflichtungen sowie
            lit. f zur Wahrung berechtigter Interessen.
          </p>

          <h2>4. Datenempfänger</h2>
          <p>
            Daten werden nur an Dienstleister übermittelt, die im Rahmen von
            Auftragsverarbeitungsverträgen eingebunden sind. Eine Übermittlung in
            Drittstaaten erfolgt nur bei geeigneten Garantien.
          </p>

          <h2>5. Speicherdauer</h2>
          <p>
            Daten werden so lange gespeichert, wie es für die genannten Zwecke
            erforderlich ist. Gesetzliche Aufbewahrungspflichten bleiben unberührt.
          </p>

          <h2>6. Betroffenenrechte</h2>
          <p>
            Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der
            Verarbeitung, Datenübertragbarkeit sowie Widerspruch. Wende dich hierfür
            an datenschutz@klyvratica.com.
          </p>

          <h2>7. Cookies & Tracking</h2>
          <p>
            Wir setzen Cookies ein, um essentielle Funktionen bereitzustellen und die
            Nutzung unserer Plattform zu analysieren. Details findest du in unserer
            Cookie-Richtlinie.
          </p>

          <h2>8. Sicherheit</h2>
          <p>
            Wir treffen technische und organisatorische Maßnahmen gemäß Art. 32 DSGVO,
            um Daten vor Verlust, Missbrauch und unbefugtem Zugriff zu schützen.
          </p>

          <h2>9. Beschwerderecht</h2>
          <p>
            Du hast das Recht, dich bei einer Datenschutzaufsichtsbehörde zu
            beschweren, z.&nbsp;B. bei der Landesbeauftragten für Datenschutz NRW.
          </p>
        </div>
      </section>
    </>
  );
}

export default Privacy;