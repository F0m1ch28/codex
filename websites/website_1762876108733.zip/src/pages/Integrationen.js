import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Integrationen.module.css";

const integrationCategories = [
  {
    title: "ERP & WaWi",
    description:
      "SAP, Microsoft Dynamics, plentymarkets, Pickware, JTL, Futura4Retail, Comarch.",
    highlight:
      "Synchronisiere Artikel, Bestände, Preise und Lieferanten mit deinem Kernsystem."
  },
  {
    title: "Zahlungssysteme",
    description:
      "Zertifizierte Payment-Service-Provider inklusive girocard, Kreditkarte, Mobile Payment.",
    highlight: "Konnektoren für Concardis, Payone, Nexi, Worldline und Stripe POS."
  },
  {
    title: "E-Commerce & Apps",
    description:
      "Shopify, Shopware, WooCommerce, Spryker, Eigenentwicklungen via API.",
    highlight:
      "Click & Collect, Reservierungen und Unified Loyalty in Echtzeit."
  },
  {
    title: "Preislabels & Digital Signage",
    description:
      "Pricer, SES-Imagotag, SoluM, xplace mit bidirektionalem Sync.",
    highlight:
      "Aktualisiere Preise und Kampagnen zeitgleich auf Etiketten und Screens."
  },
  {
    title: "Workforce & Tasking",
    description:
      "Staffomatic, Quinyx, When I Work, eigene Tools per Webhook.",
    highlight:
      "Verknüpfe Store-Aufgaben mit Sensor-Events und POS-Aktivitäten."
  }
];

function Integrationen() {
  return (
    <>
      <Helmet>
        <title>Klyvratica Integrationen & offene APIs</title>
        <meta
          name="description"
          content="Verbinde ERP, Zahlungsanbieter, E-Commerce, Preislabels und Workforce-Tools mit der Klyvratica Smart-Store-Plattform."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Integrationen</span>
            <h1>Offene APIs und zertifizierte Konnektoren</h1>
            <p>
              Klyvratica fügt sich in bestehende Systemlandschaften ein. Standardisierte
              Konnektoren und offene APIs ermöglichen schnelle Projekte ohne Medienbrüche.
            </p>
            <a href="/kontakt" className="btnPrimary">
              Integrationen prüfen
            </a>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.integrations}`}>
        <div className="container">
          <div className={styles.grid}>
            {integrationCategories.map((cat) => (
              <article key={cat.title} className={styles.card}>
                <h2>{cat.title}</h2>
                <p>{cat.description}</p>
                <span>{cat.highlight}</span>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Integrationen;