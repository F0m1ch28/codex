import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const modules = [
  {
    title: "POS & Kassieren",
    description:
      "Cloudbasiertes Kassieren mit mobilen und stationären Terminals, digitalen Quittungen und flexiblem Workflow-Designer.",
    details: [
      "Schnellzugriffe für Stammkunden und Gutscheine",
      "Elektronische Unterschriften und digitale Belege",
      "Offline-Modus mit automatischem Sync"
    ],
    image: "https://picsum.photos/800/600?random=71"
  },
  {
    title: "Bestandsmanagement",
    description:
      "Zentrale Bestandsübersicht für alle Filialen mit Schwellenwerten, Umlagerungen und automatischer Disposition.",
    details: [
      "Bestandswarnungen in Echtzeit",
      "Lieferantenmanagement & Umlagerungsplanung",
      "Inventur-App mit mobilen Scannern"
    ],
    image: "https://picsum.photos/800/600?random=72"
  },
  {
    title: "IoT-Sensorik",
    description:
      "Regalsensoren, Temperaturfühler, Beacon-Netzwerke und Kameralösungen werden in einer Plattform orchestriert.",
    details: [
      "Plug-and-Play für zertifizierte Sensorik",
      "Dashboards mit Ereignis- und Alarmhistorie",
      "Predictive Maintenance für Geräte"
    ],
    image: "https://picsum.photos/800/600?random=73"
  },
  {
    title: "Self-Checkout",
    description:
      "Self-Checkout-Zonen mit Tablet, Kassenautomat oder App, inklusive Wägesystem, Diebstahlprävention und Alterserkennung.",
    details: [
      "Integrierte Sprachführung in mehreren Sprachen",
      "Flexibles Layout für kleine Flächen",
      "Monitoring via Remote-Dashboard"
    ],
    image: "https://picsum.photos/800/600?random=74"
  },
  {
    title: "Kundenbindung",
    description:
      "Digitale Stempelkarten, personalisierte Angebote und Clubprogramme mit Gamification und In-Store-Benachrichtigungen.",
    details: [
      "In-App Kampagnenmanager",
      "Segmentierung nach Filiale, Warenkorb oder Verhalten",
      "Nahtlose Integration mit POS und E-Commerce"
    ],
    image: "https://picsum.photos/800/600?random=75"
  },
  {
    title: "Store-Analytics",
    description:
      "Echtzeit-KPIs, Heatmaps, Frequenzmessung sowie Benchmarks für Filialnetzwerke mit Drill-Down auf Produkt- und Team-Ebene.",
    details: [
      "Export nach BI-Tools und Data Warehouses",
      "Konfigurierbare Alerts via Mail oder App",
      "ROI-Tracking für Kampagnen und Layouts"
    ],
    image: "https://picsum.photos/800/600?random=76"
  },
  {
    title: "API & Integrationen",
    description:
      "Offene APIs und Webhooks sowie Konnektoren für ERP, Zahlungsanbieter, Preislabels, E-Commerce und Workforce-Tools.",
    details: [
      "GraphQL und REST Endpunkte",
      "Sandbox-Umgebung für Partner",
      "Versioniertes API-Lifecycle Management"
    ],
    image: "https://picsum.photos/800/600?random=77"
  }
];

function Services() {
  return (
    <>
      <Helmet>
        <title>Funktionen der Klyvratica Smart-Store-Plattform</title>
        <meta
          name="description"
          content="Entdecke Module wie POS, Bestandsmanagement, IoT-Sensorik, Self-Checkout, Kundenbindung, Store-Analytics und Integrationen."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <span className="tag">Funktionen</span>
              <h1>Module für jeden Store-Typ</h1>
              <p>
                Stelle dir deine Smart-Store-Plattform modular zusammen. Wähle
                aus POS, Sensorik, Loyalty und Analytics – flexibel kombinierbar
                für Lebensmittelmärkte, Boutiquen oder Kioske.
              </p>
              <a href="/kontakt" className="btnPrimary">
                Demo anfragen
              </a>
            </div>
            <img
              src="https://picsum.photos/800/600?random=78"
              alt="Übersicht der Smart-Store-Funktionen"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.modules}`}>
        <div className="container">
          <div className={styles.moduleGrid}>
            {modules.map((module) => (
              <article key={module.title} className={styles.moduleCard}>
                <img src={module.image} alt={module.title} loading="lazy" />
                <div className={styles.moduleContent}>
                  <h2>{module.title}</h2>
                  <p>{module.description}</p>
                  <ul>
                    {module.details.map((detail) => (
                      <li key={detail}>{detail}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Services;