import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Hardware.module.css";

const hardwareCategories = [
  {
    title: "Scanner",
    description:
      "Handscanner, Präsentationsscanner und Wearables für Dauerinventur sowie SB-Stationen.",
    models: ["Honeywell Xenon Performance", "Zebra DS9900", "Datalogic QuickScan"],
    image: "https://picsum.photos/800/600?random=91"
  },
  {
    title: "Drucker",
    description:
      "Bondrucker, Etikettendrucker und Mobile Printer mit automatischer Einrichtung.",
    models: ["Epson TM-m30II", "Star Micronics TSP100", "Zebra ZD621"],
    image: "https://picsum.photos/800/600?random=92"
  },
  {
    title: "Terminals",
    description:
      "Touch-Terminals für POS und Self-Checkout, robust für Dauerbetrieb.",
    models: ["Sunmi T3 Pro", "HP Engage One Pro", "Aures Yuno II"],
    image: "https://picsum.photos/800/600?random=93"
  },
  {
    title: "Waagen",
    description:
      "IoT-fähige Waagen mit Wägedaten in Echtzeit für Feinkost, Bäckerei und Self-Checkout.",
    models: ["Bizerba KH II", "Mettler Toledo FreshBase", "CAS CL5500"],
    image: "https://picsum.photos/800/600?random=94"
  },
  {
    title: "Beacons & Sensoren",
    description:
      "Bluetooth-Beacons, Temperatur- und Regalsensorik mit Multi-Pairing.",
    models: ["Kontakt IoT Shelf Sensor", "Estimote Beacon Fleet", "Monnit ALTA Sensors"],
    image: "https://picsum.photos/800/600?random=95"
  }
];

function Hardware() {
  return (
    <>
      <Helmet>
        <title>Klyvratica Hardware: Scanner, Terminals & Sensorik</title>
        <meta
          name="description"
          content="Entdecke zertifizierte Hardware für Scanner, Drucker, Terminals, Waagen sowie Beacons und Sensoren."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Hardware</span>
            <h1>Zertifizierte Geräte für deinen Store</h1>
            <p>
              Klyvratica unterstützt ausgewählte Scanner, Drucker, Terminals,
              Waagen und IoT-Sensoren. Alle Geräte werden getestet und mit
              vorkonfigurierten Treibern geliefert.
            </p>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.hardwareList}`}>
        <div className="container">
          <div className={styles.grid}>
            {hardwareCategories.map((item) => (
              <article key={item.title} className={styles.card}>
                <img src={item.image} alt={item.title} loading="lazy" />
                <div className={styles.cardContent}>
                  <h2>{item.title}</h2>
                  <p>{item.description}</p>
                  <h4>Unterstützte Modelle</h4>
                  <ul>
                    {item.models.map((model) => (
                      <li key={model}>{model}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Hardware;