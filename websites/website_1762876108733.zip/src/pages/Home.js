import React, { useEffect, useMemo, useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const statsData = [
  { label: "vernetzte Geräte", value: 320 },
  { label: "aktive Stores", value: 145 },
  { label: "IoT-Ereignisse täglich", value: 18000 },
  { label: "zufriedene Teams", value: 96 }
];

const featureList = [
  {
    title: "POS & Kassieren",
    description:
      "Schnelles Kassieren mit digitalen Quittungen, individuellen Workflows und Anbindung an bestehende Peripherie.",
    icon: "🧾"
  },
  {
    title: "Bestandsmanagement",
    description:
      "Echtzeit-Bestände über Filialen hinweg, automatische Warnungen und KI-gestützte Vorschläge für Nachbestellungen.",
    icon: "📦"
  },
  {
    title: "IoT-Sensorik",
    description:
      "Regalsensoren, Temperaturüberwachung und Beacon-Flotten liefern präzise Daten für Warenfluss und Qualität.",
    icon: "📡"
  },
  {
    title: "Self-Checkout",
    description:
      "Flexible Self-Checkout-Flächen mit App, Terminal oder Tablet und smartem Wägesystem gegen Shrinkage.",
    icon: "🛒"
  },
  {
    title: "Kundenbindung",
    description:
      "Personalisierte Clubprogramme, digitale Stempelkarten und Gutscheine direkt im Smartphone deiner Kundschaft.",
    icon: "🤝"
  },
  {
    title: "Store-Analytics",
    description:
      "Dashboards mit KPIs zu Frequenz, Abverkauf, Aufenthaltsdauer und Heatmaps für datengestützte Entscheidungen.",
    icon: "📊"
  }
];

const processSteps = [
  {
    title: "Anschließen",
    text: "Hardware anschließen und vorhandene Systeme verknüpfen. Klyvratica erkennt Sensoren, Terminals und Kassentische automatisch.",
    media: "https://picsum.photos/800/600?random=21"
  },
  {
    title: "Einrichten",
    text: "Workflows, Rollen und Rollenrechte in wenigen Minuten konfigurieren. Ein Onboarding-Assistent führt Schritt für Schritt durch alle Bereiche.",
    media: "https://picsum.photos/800/600?random=22"
  },
  {
    title: "Automatisieren",
    text: "Bestände, Temperaturalarme, Kampagnen und Reports laufen im Hintergrund und informieren dein Team proaktiv.",
    media: "https://picsum.photos/800/600?random=23"
  },
  {
    title: "Auswerten",
    text: "Realtime-Dashboards mit Drill-Downs zeigen, was in deinem Store passiert. Exportiere Insights direkt für deine Stakeholder.",
    media: "https://picsum.photos/800/600?random=24"
  }
];

const benefits = [
  {
    title: "Datensouveränität & DSGVO",
    text: "Alle Daten bleiben in der EU, werden Ende-zu-Ende verschlüsselt und nach strengen Richtlinien verarbeitet."
  },
  {
    title: "Offene Integrationen",
    text: "REST APIs, GraphQL und Standard-Konnektoren verbinden ERP, WaWi, Payment, Preislabels und E-Commerce mühelos."
  },
  {
    title: "Sichere Rollensteuerung",
    text: "Feingranulare Rechte, Audit-Trails und revisionssichere Protokolle schützen den Zugriff auf kritische Informationen."
  },
  {
    title: "Skalierbar in Stunden",
    text: "Neue Filiale? Einfach Geräte anbinden, Profil wählen und innerhalb eines Tages betriebsbereit sein."
  }
];

const testimonials = [
  {
    quote:
      "Nach drei Monaten mit Klyvratica verkürzten wir Wartezeiten an der Kasse um 38%. Unsere Teams lieben die transparente Sicht auf Lagerbewegungen.",
    name: "Mira Schneider",
    role: "Leitung Retail Operations, Feinkost Müller",
    kpi: "−38% Wartezeit"
  },
  {
    quote:
      "Die Kombination aus IoT-Sensoren und Bestandsdaten reduziert Abschriften deutlich. Besonders die proaktiven Warnungen sparen uns täglich Zeit.",
    name: "Yusuf Duran",
    role: "Geschäftsführer, CityKiosk Köln",
    kpi: "−27% Abschriften"
  },
  {
    quote:
      "Durch Self-Checkout und Loyalty-App erzielen wir eine deutlich höhere Wiederkaufrate. Die Plattform wächst mit unserem Boutique-Konzept.",
    name: "Anna Richter",
    role: "Inhaberin, Studio Lune Mode",
    kpi: "+22% Wiederkehr"
  }
];

const projects = [
  {
    id: 1,
    title: "Lebensmittel-Store mit Temperaturmonitoring",
    category: "Lebensmittel",
    description:
      "Vernetzte Kühltruhen, Echtzeit-Bestände und dynamische Preisetiketten in vier Filialen.",
    image: "https://picsum.photos/1200/800?random=31"
  },
  {
    id: 2,
    title: "Drogerie mit Self-Checkout-Zone",
    category: "Drogerie",
    description:
      "Kontaktlose Self-Checkout-Stationen mit RFID, Loyalty-App und Echtzeit-Regal-Alerts.",
    image: "https://picsum.photos/1200/800?random=32"
  },
  {
    id: 3,
    title: "Fashion-Boutique mit Clienteling-App",
    category: "Mode",
    description:
      "Mobile Kassen, personalisierte Styling-Vorschläge und Integration mit Webshop.",
    image: "https://picsum.photos/1200/800?random=33"
  },
  {
    id: 4,
    title: "Kiosk-Netzwerk mit zentralem Dashboard",
    category: "Kiosk",
    description:
      "Filialübergreifendes Monitoring, Altersverifikation am Terminal und dynamische Promotionen.",
    image: "https://picsum.photos/1200/800?random=34"
  },
  {
    id: 5,
    title: "Bäckerei mit IoT-Backplanung",
    category: "Bäckerei",
    description:
      "Sensorische Teigführung, Produktionsplanung und Verkaufsflächen in einer Ansicht.",
    image: "https://picsum.photos/1200/800?random=35"
  }
];

const faqs = [
  {
    question: "Wie lange dauert ein Go-Live mit Klyvratica?",
    answer:
      "Kleine Teams starten häufig innerhalb von zwei Wochen. Durch vorkonfigurierte Templates richten wir Workflows und Rollen sehr schnell ein. Hardware kann per Plug-and-Play angebunden werden."
  },
  {
    question: "Welche POS-Hardware unterstützt ihr?",
    answer:
      "Wir unterstützen gängige Scanner, Bondrucker, Touch-Terminals, Waagen und Payment-Geräte führender Hersteller. Eine aktuelle Liste findest du in der Hardware-Übersicht."
  },
  {
    question: "Wie funktioniert die Datenhaltung in der EU?",
    answer:
      "Alle Daten liegen redundant in zertifizierten Rechenzentren innerhalb der EU. Verschlüsselung im Transit und at-rest sowie Zugriffskontrollen stellen höchste Sicherheit sicher."
  },
  {
    question: "Kann ich bestehende Software weiter nutzen?",
    answer:
      "Ja. Über unsere APIs und Konnektoren verbinden wir ERP, WaWi, E-Commerce, Preislabel-Lösungen sowie Payment-Anbieter. Neue Integrationen lassen sich flexibel ergänzen."
  }
];

const blogPosts = [
  {
    title: "Connected Retail: Leitfaden für vernetzte Filialprozesse",
    excerpt:
      "Wie du mit vernetzten Sensoren, POS-Daten und Workforce-Tools effizientere Abläufe schaffst.",
    image: "https://picsum.photos/800/600?random=41",
    link: "/ressourcen"
  },
  {
    title: "Self-Checkout im Alltag: Best Practices aus Köln und Düsseldorf",
    excerpt:
      "Von Layout über Schulung bis Wartung – so gelingt eine reibungslose Einführung.",
    image: "https://picsum.photos/800/600?random=42",
    link: "/ressourcen"
  },
  {
    title: "KPIs für moderne Stores: Was wirklich zählt",
    excerpt:
      "Welche Kennzahlen liefern echten Mehrwert und wie du sie in Klyvratica visualisierst.",
    image: "https://picsum.photos/800/600?random=43",
    link: "/ressourcen"
  }
];

function Home() {
  const [counts, setCounts] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeFilter, setActiveFilter] = useState("Alle");
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    let animationFrame;

    const startTimestamp = performance.now();
    const duration = 1800;

    const animate = (timestamp) => {
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      setCounts(
        statsData.map((item) => Math.floor(progress * item.value))
      );
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      } else {
        setCounts(statsData.map((item) => item.value));
      }
    };

    animationFrame = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects =
    activeFilter === "Alle"
      ? projects
      : projects.filter((project) => project.category === activeFilter);

  const structuredData = useMemo(
    () => ({
      "@context": "https://schema.org",
      "@type": "Organization",
      name: "Klyvratica",
      description:
        "Klyvratica ist die Smart-Store-Plattform für den Handel mit POS, Bestandsmanagement, IoT-Sensorik und Self-Checkout.",
      url: "https://klyvratica.com",
      logo: "https://klyvratica.com/logo.svg",
      address: {
        "@type": "PostalAddress",
        streetAddress: "Schildergasse 72",
        addressLocality: "Köln",
        postalCode: "50667",
        addressCountry: "DE"
      },
      contactPoint: {
        "@type": "ContactPoint",
        telephone: "+49 221 29123456",
        contactType: "customer service",
        areaServed: "DE"
      }
    }),
    []
  );

  return (
    <>
      <Helmet>
        <title>Klyvratica Smart-Store-Plattform für Handel in Köln</title>
        <meta
          name="description"
          content="Mach deinen Laden smart – einfach und skalierbar. Klyvratica vernetzt POS, Bestand, IoT und Loyalty für ambitionierte Einzelhändler."
        />
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>
      </Helmet>

      <section className={styles.hero}>
        <div
          className={styles.heroBackground}
          style={{
            backgroundImage:
              "linear-gradient(rgba(15, 23, 42, 0.7), rgba(15, 23, 42, 0.7)), url('https://picsum.photos/1600/900?random=51')"
          }}
        >
          <div className={`container ${styles.heroContent}`}>
            <div className={styles.heroText}>
              <span className="tag">Smart Store Intelligence</span>
              <h1>Mach deinen Laden smart – einfach und skalierbar</h1>
              <p>
                Klyvratica verbindet Kassensysteme, Regalsensoren, Loyalty-Apps
                und Analytics in einer Plattform. Für Teams, die flexibel auf
                den Alltag im Handel reagieren möchten.
              </p>
              <div className={styles.heroActions}>
                <a className="btnPrimary ctaPulse" href="/kontakt">
                  Jetzt starten
                </a>
                <a className="btnSecondary" href="/funktionen">
                  Funktionen ansehen
                </a>
              </div>
            </div>
            <div className={styles.heroMedia}>
              <img
                src="https://picsum.photos/800/600?random=52"
                alt="Dashboard für Smart-Store-Management"
                loading="lazy"
              />
              <div className={styles.heroOverlay}>
                <p>
                  Realtime-Dashboard mit Bestand, Workforce-Status und IoT-Alerts.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.stats} sectionSpacing`}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {counts[index].toLocaleString("de-DE")}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.intro}`}>
        <div className="container">
          <div className={styles.introGrid}>
            <div>
              <h2>Smart-Store-Plattform aus Köln für ambitionierte Händler</h2>
              <p>
                Klyvratica entsteht im Herzen von Köln. Unser Team begleitet
                Filialisten, Franchisegeber und lokale Unternehmerinnen auf dem
                Weg zu vernetzten Stores. Wir denken Retail ganzheitlich: vom
                Kassentisch über Robotik in der Warenversorgung bis zum
                personalisierten Einkaufserlebnis.
              </p>
            </div>
            <div className={styles.introHighlight}>
              <h3>Retail Experience neu gedacht</h3>
              <ul>
                <li>Mobile-first Bedienoberflächen für Teams und Kundschaft</li>
                <li>Adaptiver Workflow-Designer für verschiedene Shop-Formate</li>
                <li>Starke Community aus Händlerinnen, Tech-Partnern und Integratoren</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.features}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Alle Funktionen für deinen vernetzten Store</h2>
            <p>
              Von der Kasse bis zum Sensor: Klyvratica liefert ein abgestimmtes
              Zusammenspiel von Software, Hardware und Datenanalyse.
            </p>
          </div>
          <div className={styles.featureGrid}>
            {featureList.map((feature) => (
              <article key={feature.title} className={styles.featureCard}>
                <span className={styles.featureIcon} aria-hidden="true">
                  {feature.icon}
                </span>
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
                <a href="/funktionen" className={styles.featureLink}>
                  Mehr erfahren
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.process}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>So funktioniert Klyvratica im Alltag</h2>
            <p>
              In vier Schritten vom ersten Sensor bis zum auswertbaren Dashboard.
              Transparent, geführt und für jedes Team geeignet.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <div key={step.title} className={styles.processStep}>
                <div className={styles.processMedia}>
                  <img
                    src={step.media}
                    alt={`Schritt ${index + 1}: ${step.title}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.processContent}>
                  <span className={styles.stepNumber}>{index + 1}</span>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.why}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Warum Händlerinnen Klyvratica wählen</h2>
            <p>
              Sicherheit, Integrationen und Skalierbarkeit sind die Basis einer
              modernen Smart-Store-Strategie.
            </p>
          </div>
          <div className={styles.whyGrid}>
            {benefits.map((benefit) => (
              <div key={benefit.title} className={styles.whyCard}>
                <h3>{benefit.title}</h3>
                <p>{benefit.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.testimonials}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Erfolgsgeschichten aus dem Handel</h2>
            <p>
              Messbare Ergebnisse in unterschiedlichen Branchen. Hör direkt von
              Teams, die jeden Tag smarter arbeiten.
            </p>
          </div>
          <div className={styles.carousel}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.active : ""
                }`}
                aria-hidden={index !== activeTestimonial}
              >
                <p className={styles.quote}>{testimonial.quote}</p>
                <div className={styles.person}>
                  <div>
                    <h3>{testimonial.name}</h3>
                    <span>{testimonial.role}</span>
                  </div>
                  <span className={styles.kpi}>{testimonial.kpi}</span>
                </div>
              </article>
            ))}
            <div className={styles.carouselControls}>
              <button
                type="button"
                onClick={() =>
                  setActiveTestimonial(
                    (activeTestimonial - 1 + testimonials.length) %
                      testimonials.length
                  )
                }
                aria-label="Vorheriges Testimonial"
              >
                ←
              </button>
              <button
                type="button"
                onClick={() =>
                  setActiveTestimonial((activeTestimonial + 1) % testimonials.length)
                }
                aria-label="Nächstes Testimonial"
              >
                →
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.projects}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Projekte &amp; Use Cases</h2>
            <p>
              Wähle deinen Store-Typ und entdecke, wie Klyvratica den Alltag
              erleichtert.
            </p>
          </div>
          <div className={styles.filterBar}>
            {["Alle", "Lebensmittel", "Drogerie", "Mode", "Kiosk", "Bäckerei"].map(
              (category) => (
                <button
                  type="button"
                  key={category}
                  className={`${styles.filterButton} ${
                    activeFilter === category ? styles.filterActive : ""
                  }`}
                  onClick={() => setActiveFilter(category)}
                >
                  {category}
                </button>
              )
            )}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img
                  src={project.image}
                  alt={`${project.title}`}
                  loading="lazy"
                />
                <div className={styles.projectContent}>
                  <span className="tag">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.faq}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>FAQ: Deine Fragen, unsere Antworten</h2>
            <p>
              Transparente Infos für eine fundierte Entscheidung. Weitere Details
              gerne persönlich.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqs.map((item, index) => (
              <div key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqQuestion}
                  onClick={() =>
                    setOpenFaq(openFaq === index ? null : index)
                  }
                  aria-expanded={openFaq === index}
                >
                  <span>{item.question}</span>
                  <span aria-hidden="true">
                    {openFaq === index ? "−" : "+"}
                  </span>
                </button>
                {openFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.blog}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Insights aus dem Klyvratica Lab</h2>
            <p>
              Trends, Tipps und Guides rund um Smart Stores, Retail IoT und
              Change-Management im Handel.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogContent}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <a href={post.link} className={styles.blogLink}>
                    Weiterlesen
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.cta}`}>
        <div className="container">
          <div className={styles.ctaContent}>
            <div>
              <h2>Bereit für deinen smarten Store?</h2>
              <p>
                Lass uns gemeinsam herausfinden, welche Module du zuerst brauchst
                und wie wir deine Story unterstützen können.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <a className="btnPrimary" href="/kontakt">
                Jetzt starten
              </a>
              <a className="btnSecondary" href="/integrationen">
                Integrationen prüfen
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Home;