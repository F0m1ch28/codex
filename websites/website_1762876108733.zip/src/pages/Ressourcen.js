import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Ressourcen.module.css";

const resources = [
  {
    type: "Blog",
    title: "Self-Checkout richtig einführen",
    description:
      "Checklist für Planung, Schulung und Evaluation deiner Self-Checkout-Zone.",
    link: "#"
  },
  {
    type: "Guide",
    title: "IoT-Sensoren im Store",
    description:
      "Vom Prototypen zur produktiven Skalierung – Best Practices aus Projekten.",
    link: "#"
  },
  {
    type: "Template",
    title: "Store Operating Model Canvas",
    description:
      "Arbeitsvorlage für Prozesse, Rollen und KPIs im stationären Handel.",
    link: "#"
  },
  {
    type: "Webinar",
    title: "Kundenerlebnis und Datenschutz vereinen",
    description:
      "Live-Session mit Praxisbeispielen und Q&A.",
    link: "#"
  }
];

function Ressourcen() {
  return (
    <>
      <Helmet>
        <title>Klyvratica Ressourcen: Guides, Webinare & Templates</title>
        <meta
          name="description"
          content="Lerne mit Blogartikeln, Guides, Templates und Webinaren, wie du Smart-Store-Projekte erfolgreich umsetzt."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Ressourcen</span>
            <h1>Wissen für moderne Stores</h1>
            <p>
              Nutze unsere Ressourcen für Planung, Umsetzung und Skalierung deines
              Smart-Store-Projekts. Von Templates bis Webinaren.
            </p>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.resourceList}`}>
        <div className="container">
          <div className={styles.grid}>
            {resources.map((resource) => (
              <article key={resource.title} className={styles.card}>
                <span className={styles.type}>{resource.type}</span>
                <h2>{resource.title}</h2>
                <p>{resource.description}</p>
                <a href={resource.link} className={styles.link}>
                  Mehr erfahren
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Ressourcen;