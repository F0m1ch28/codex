import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Sicherheit.module.css";

const pillars = [
  {
    title: "DSGVO & Compliance",
    text: "Datenschutz ist integraler Bestandteil der Plattform. Wir dokumentieren Verarbeitungsprozesse, bieten AV-Verträge und halten Rollenrechte transparent."
  },
  {
    title: "Datenresidenz in der EU",
    text: "Alle Daten liegen in zertifizierten Rechenzentren innerhalb der Europäischen Union. Redundante Speicherung und Notfallpläne sind geprüft."
  },
  {
    title: "Verschlüsselung",
    text: "TLS 1.3 im Transit, AES-256 at rest. Zugriffsschlüssel werden via Hardware Security Modules verwaltet."
  },
  {
    title: "Rollen & Rechte",
    text: "Feingranulare Rollenvergabe, SSO- und MFA-Unterstützung sowie revisionssichere Audit-Trails für jede Aktion."
  },
  {
    title: "Audits & Tests",
    text: "Regelmäßige Penetrationstests, Code-Reviews und Zertifizierungen nach ISO 27001 durch Partner."
  },
  {
    title: "Monitoring",
    text: "Security Operations Center und 24/7 Monitoring für kritische Systeme mit automatischem Incident-Response."
  }
];

function Sicherheit() {
  return (
    <>
      <Helmet>
        <title>Klyvratica Sicherheit & Datenschutz für Smart Stores</title>
        <meta
          name="description"
          content="Erfahre, wie Klyvratica DSGVO, EU-Datenresidenz, Verschlüsselung, Rollen, Audits und Monitoring realisiert."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Sicherheit</span>
            <h1>Vertrauen durch konsequente Sicherheit</h1>
            <p>
              Von der Architektur bis zum Support ist Klyvratica auf Schutz,
              Transparenz und Compliance ausgelegt. Händlerinnen behalten
              jederzeit die Hoheit über ihre Daten.
            </p>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.pillars}`}>
        <div className="container">
          <div className={styles.grid}>
            {pillars.map((pillar) => (
              <article key={pillar.title} className={styles.card}>
                <h2>{pillar.title}</h2>
                <p>{pillar.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Sicherheit;