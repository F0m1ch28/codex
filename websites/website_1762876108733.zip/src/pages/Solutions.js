import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Solutions.module.css";

const solutions = [
  {
    title: "Lebensmittel",
    description:
      "Temperaturmonitoring, Frische-Checks, dynamische Preisetiketten und Self-Checkout für stark frequentierte Märkte.",
    benefits: [
      "Temperaturalarm in Echtzeit",
      "Rückverfolgbarkeit für Frischeprodukte",
      "Kundenfrequenz-Analysen nach Tageszeit"
    ],
    image: "https://picsum.photos/800/600?random=81"
  },
  {
    title: "Drogerie",
    description:
      "Regalverfügbarkeiten, Batch-Verwaltung und Assisted Selling via App für Beratung auf der Fläche.",
    benefits: [
      "Mobile Produktinfos für Mitarbeitende",
      "Automatische Nachbestellung anhand Schwellen",
      "Self-Checkout mit Altersprüfung"
    ],
    image: "https://picsum.photos/800/600?random=82"
  },
  {
    title: "Boutique & Mode",
    description:
      "Clienteling-App, Omnichannel-Bestände und personalisierte Loyalty-Programme für individuelle Beratung.",
    benefits: [
      "Reservierungen aus dem Webshop in die Filiale",
      "Digitale Stilprofile der Kundschaft",
      "Live-Anzeige von Warenbewegungen"
    ],
    image: "https://picsum.photos/800/600?random=83"
  },
  {
    title: "Kiosk",
    description:
      "Schneller POS, verlässliche Altersverifikation, Remote-Monitoring und Warenkörbe für Stammkunden.",
    benefits: [
      "Central Dashboard für Filialverbünde",
      "Instant Alerts bei Bestandsengpässen",
      "Smarte Kampagnen für Pendler"
    ],
    image: "https://picsum.photos/800/600?random=84"
  },
  {
    title: "Bäckerei",
    description:
      "Backplanung, Produktionssteuerung und Verkauf mit integrierter Waage und Tagesabschluss in einer Anwendung.",
    benefits: [
      "IoT-Sensorik für Teigführung",
      "Intelligente Vorbestellungen",
      "Mehrschichtige Zugriffsrechte für Filialteams"
    ],
    image: "https://picsum.photos/800/600?random=85"
  }
];

function Solutions() {
  return (
    <>
      <Helmet>
        <title>Klyvratica Lösungen für Lebensmittel, Mode & mehr</title>
        <meta
          name="description"
          content="Branchenspezifische Smart-Store-Lösungen für Lebensmittel, Drogerie, Boutique, Kiosk und Bäckerei."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="tag">Lösungen</span>
            <h1>Branchenspezifische Use Cases</h1>
            <p>
              Ob Supermarkt, Drogerie oder Boutique: Klyvratica verbindet die
              richtigen Module für dein Geschäftsmodell und schafft messbaren
              Mehrwert auf der Fläche.
            </p>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.solutionList}`}>
        <div className="container">
          <div className={styles.grid}>
            {solutions.map((solution) => (
              <article key={solution.title} className={styles.card}>
                <img src={solution.image} alt={solution.title} loading="lazy" />
                <div className={styles.cardContent}>
                  <h2>{solution.title}</h2>
                  <p>{solution.description}</p>
                  <ul>
                    {solution.benefits.map((benefit) => (
                      <li key={benefit}>{benefit}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Solutions;