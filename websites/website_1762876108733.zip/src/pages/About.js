import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const milestones = [
  {
    year: "2019",
    title: "Gründung in Köln",
    text: "Ein Team aus Retail-Expertinnen und IoT-Spezialisten startet mit ersten Pilotprojekten."
  },
  {
    year: "2020",
    title: "Launch der Smart-Store-Plattform",
    text: "POS, Sensorik und Analytics wachsen in einer modularen Lösung zusammen."
  },
  {
    year: "2021",
    title: "Partnernetzwerk & Integrationen",
    text: "Erste zertifizierte Integrationen mit ERP- und Payment-Anbietern werden veröffentlicht."
  },
  {
    year: "2023",
    title: "Expansion DACH",
    text: "Klyvratica unterstützt Händlerinnen in Deutschland, Österreich und der Schweiz."
  }
];

const team = [
  {
    name: "Laura Feldmann",
    role: "CEO & Co-Founder",
    bio: "Strategin für Retail-Innovation, zuvor 8 Jahre Leitung Digital bei einer internationalen Warenhausgruppe.",
    image: "https://picsum.photos/400/400?random=61"
  },
  {
    name: "Tobias Merz",
    role: "CTO & Co-Founder",
    bio: "Verantwortet Plattform-Architektur, Security und skalierbare Integrationen.",
    image: "https://picsum.photos/400/400?random=62"
  },
  {
    name: "Elena Hofrichter",
    role: "Head of Customer Success",
    bio: "Begleitet Händlerinnen vom Konzept bis zum laufenden Betrieb. Enthusiastin für Change-Management.",
    image: "https://picsum.photos/400/400?random=63"
  },
  {
    name: "Jakub Nowak",
    role: "Lead Hardware Partnerships",
    bio: "Baut unser Ökosystem an zertifizierten Geräten und Sensorpartnern aus.",
    image: "https://picsum.photos/400/400?random=64"
  }
];

function About() {
  return (
    <>
      <Helmet>
        <title>Klyvratica Team & Mission für Smart Stores</title>
        <meta
          name="description"
          content="Lerne das Klyvratica Team kennen. Wir entwickeln Smart-Store-Lösungen für lokale Handelsunternehmen und Franchise-Netzwerke."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div>
              <span className="tag">Über Klyvratica</span>
              <h1>Wir machen stationären Handel digital resilient</h1>
              <p>
                Klyvratica entstand aus der Überzeugung, dass moderne Handelsflächen
                mehr als nur Verkaufspunkte sind. Sie sind Orte der Begegnung.
                Unser Ziel: Technologie, die Menschen befähigt, kreative Einkaufserlebnisse
                zu gestalten – ohne Kompromisse bei Sicherheit und Datenschutz.
              </p>
            </div>
            <img
              src="https://picsum.photos/800/600?random=65"
              alt="Teammeeting bei Klyvratica in Köln"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.mission}`}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div>
              <h2>Unsere Mission</h2>
              <p>
                Wir befähigen kleine und mittlere Handelsunternehmen, digitale
                Services genauso souverän einzusetzen wie große Player. Dazu
                entwickeln wir eine Plattform, die Prozesse automatisiert,
                Mitarbeitende entlastet und Kundschaft begeistert.
              </p>
            </div>
            <div>
              <h3>Werte, die uns leiten</h3>
              <ul>
                <li>Partnerschaftlich: Wir bauen langfristige Beziehungen auf Augenhöhe.</li>
                <li>Verantwortungsvoll: Datenschutz, Fairness und Stabilität stehen im Fokus.</li>
                <li>Neugierig: Wir lernen täglich in enger Zusammenarbeit mit Händlerinnen.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.team}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Menschen hinter Klyvratica</h2>
            <p>
              Interdisziplinäre Expertise aus Retail, Software, Hardware und Operations.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.imageWrapper}>
                  <img src={member.image} alt={member.name} loading="lazy" />
                  <div className={styles.overlay}>
                    <p>{member.bio}</p>
                  </div>
                </div>
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.timeline}`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Unsere Geschichte</h2>
            <p>Wichtige Schritte auf unserem Weg zur Smart-Store-Plattform.</p>
          </div>
          <div className={styles.timelineGrid}>
            {milestones.map((item) => (
              <div key={item.year} className={styles.milestone}>
                <span className={styles.year}>{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.cta}`}>
        <div className="container">
          <div className={styles.ctaContent}>
            <div>
              <h2>Du möchtest mitgestalten?</h2>
              <p>
                Wir suchen Menschen, die Retail, Technologie und Nachhaltigkeit
                verbinden wollen. Melde dich bei uns und lass uns austauschen.
              </p>
            </div>
            <a className="btnPrimary" href="/kontakt">
              Kontakt aufnehmen
            </a>
          </div>
        </div>
      </section>
    </>
  );
}

export default About;