import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Legal.module.css";

function CookiePolicy() {
  return (
    <>
      <Helmet>
        <title>Klyvratica Cookie-Richtlinie</title>
        <meta
          name="description"
          content="Informationen zur Verwendung von Cookies auf klyvratica.com."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Cookie-Richtlinie</h1>
          <p>Stand: Januar 2024</p>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.content}`}>
        <div className="container">
          <h2>1. Was sind Cookies?</h2>
          <p>
            Cookies sind kleine Textdateien, die auf deinem Gerät gespeichert werden,
            um Funktionen bereitzustellen oder Informationen über die Nutzung zu
            erfassen.
          </p>

          <h2>2. Arten von Cookies</h2>
          <ul>
            <li>
              <strong>Essentielle Cookies</strong> sind notwendig, damit unsere
              Plattform funktioniert (z.&nbsp;B. Login, Session-Management).
            </li>
            <li>
              <strong>Analyse-Cookies</strong> helfen uns zu verstehen, wie unsere
              Plattform genutzt wird, um sie zu verbessern.
            </li>
          </ul>

          <h2>3. Verwaltung von Cookies</h2>
          <p>
            Du kannst Cookies im Browser deaktivieren. Beachte, dass dadurch der
            Funktionsumfang eingeschränkt sein kann. Über unseren Cookie-Banner kannst
            du Analyse-Cookies ablehnen.
          </p>

          <h2>4. Dritte</h2>
          <p>
            Wir setzen ausgewählte Dienstleister für Analyse und Performance ein. Diese
            agieren als Auftragsverarbeiter und dürfen Daten nur im Rahmen unserer
            Vorgaben nutzen.
          </p>

          <h2>5. Änderungen</h2>
          <p>
            Wir können diese Richtlinie aktualisieren. Prüfe sie regelmäßig, um über
            Neuerungen informiert zu bleiben.
          </p>
        </div>
      </section>
    </>
  );
}

export default CookiePolicy;