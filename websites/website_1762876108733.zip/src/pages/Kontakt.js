import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Kontakt.module.css";

const initialState = {
  name: "",
  email: "",
  company: "",
  topic: "Demo",
  message: ""
};

function Kontakt() {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Bitte Namen eintragen.";
    if (!formData.email.trim() || !formData.email.includes("@")) {
      newErrors.email = "Bitte gültige E-Mail-Adresse eingeben.";
    }
    if (!formData.message.trim()) newErrors.message = "Bitte Anliegen beschreiben.";
    return newErrors;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setFormData(initialState);
    }
  };

  return (
    <>
      <Helmet>
        <title>Klyvratica Kontakt & Onboarding</title>
        <meta
          name="description"
          content="Kontaktiere Klyvratica für Smart-Store-Demos, Onboarding von Händlern oder Partneranfragen."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <span className="tag">Kontakt</span>
              <h1>Gemeinsam zum smarten Store</h1>
              <p>
                Erzähl uns von deinem Projekt. Wir melden uns mit passenden
                Vorschlägen für Demo, Pilot oder Rollout.
              </p>
              <div className={styles.contactInfo}>
                <p>Adresse: Schildergasse 72, 50667 Köln, Deutschland</p>
                <p>Telefon: <a href="tel:+4922129123456">+49 221 29123456</a></p>
                <p>Email: <a href="mailto:hallo@klyvratica.com">hallo@klyvratica.com</a></p>
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.formGroup}>
                <label htmlFor="name">Name *</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={errors.name ? "true" : "false"}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="email">E-Mail *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={errors.email ? "true" : "false"}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="company">Unternehmen</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={formData.company}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="topic">Anliegen *</label>
                <select
                  id="topic"
                  name="topic"
                  value={formData.topic}
                  onChange={handleChange}
                >
                  <option value="Demo">Demo</option>
                  <option value="Onboarding">Onboarding-Hilfe</option>
                  <option value="Partner">Partnerschaft</option>
                  <option value="Support">Support</option>
                </select>
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="message">Nachricht *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="4"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={errors.message ? "true" : "false"}
                />
                {errors.message && (
                  <span className={styles.error}>{errors.message}</span>
                )}
              </div>
              <button type="submit" className="btnPrimary">
                Nachricht senden
              </button>
              {submitted && (
                <p className={styles.success}>
                  Danke für deine Nachricht! Wir melden uns in Kürze.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>

      <section className={`sectionSpacing ${styles.finalCta}`}>
        <div className="container">
          <div className={styles.finalCtaContent}>
            <h2>Du hast Fragen zum Partnerprogramm?</h2>
            <p>
              Wir arbeiten mit Systemhäusern, Payment-Anbietern und Beratungsteams
              zusammen. Vereinbare jetzt einen Austausch.
            </p>
            <a className="btnSecondary" href="mailto:partner@klyvratica.com">
              Partnerkontakt aufnehmen
            </a>
          </div>
        </div>
      </section>
    </>
  );
}

export default Kontakt;