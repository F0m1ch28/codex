document.addEventListener("DOMContentLoaded", function () {
    const banner = document.getElementById("cookieBanner");
    const acceptLink = document.getElementById("cookieAccept");
    const declineLink = document.getElementById("cookieDecline");

    if (!banner || !acceptLink || !declineLink) {
        return;
    }

    const consentStatus = localStorage.getItem("louverazqi-cookie-consent");
    if (!consentStatus) {
        banner.classList.add("active");
    }

    acceptLink.addEventListener("click", function (event) {
        event.preventDefault();
        localStorage.setItem("louverazqi-cookie-consent", "accepted");
        banner.classList.remove("active");
    });

    declineLink.addEventListener("click", function (event) {
        event.preventDefault();
        localStorage.setItem("louverazqi-cookie-consent", "declined");
        banner.classList.remove("active");
        window.location.href = "cookies.html";
    });
});