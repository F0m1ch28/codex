import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const accepted = localStorage.getItem('cookieConsent');
    if (!accepted) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookieConsent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        Мы используем cookies, чтобы улучшить работу сайта и сделать взаимодействие с нами удобнее. Продолжая
        использование сайта, вы соглашаетесь с нашей <a href="/politika-cookies">политикой cookies</a>.
      </div>
      <button type="button" onClick={handleAccept} className={styles.button}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;