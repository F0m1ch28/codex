import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.colBrand}>
        <div className={styles.logoBlock}>
          <img
            src="https://picsum.photos/96/48?random=22"
            alt="Логотип компании"
            className={styles.logoImage}
            loading="lazy"
          />
          <span className={styles.logoText}>Компания</span>
        </div>
        <p className={styles.description}>
          Компания — это команда экспертов, которая помогает бизнесу увереннее смотреть в будущее, внедряя
          стратегические решения, цифровые инструменты и проверенные практики управления.
        </p>
      </div>

      <div className={styles.colLinks}>
        <h3 className={styles.colTitle}>Навигация</h3>
        <ul className={styles.list}>
          <li><Link to="/uslugi">Услуги</Link></li>
          <li><Link to="/o-kompanii">О компании</Link></li>
          <li><Link to="/kontakty">Контакты</Link></li>
          <li><Link to="/blog">Блог</Link></li>
        </ul>
      </div>

      <div className={styles.colLinks}>
        <h3 className={styles.colTitle}>Юридические документы</h3>
        <ul className={styles.list}>
          <li><Link to="/usloviya">Условия использования</Link></li>
          <li><Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link></li>
          <li><Link to="/politika-cookies">Политика использования cookies</Link></li>
        </ul>
      </div>

      <div className={styles.colContacts}>
        <h3 className={styles.colTitle}>Контакты</h3>
        <address className={styles.address}>
          <span>123100, Россия, г. Москва, Пресненская набережная, д. 12</span>
          <a href="tel:+74951234567">+7 (495) 123-45-67</a>
          <a href="mailto:info@kompania.ru">info@kompania.ru</a>
        </address>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© 2023 Компания. Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;