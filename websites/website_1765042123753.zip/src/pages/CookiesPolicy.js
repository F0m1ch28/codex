import React from 'react';
import Seo from '../components/Seo';
import styles from './Legal.module.css';

const CookiesPolicy = () => (
  <>
    <Seo
      title="Политика использования cookies — Компания"
      description="Информация о том, как Компания использует файлы cookies и аналогичные технологии на сайте."
      keywords="cookies, политика cookies, файлы cookies"
    />
    <section className={styles.section}>
      <div className={styles.container}>
        <h1>Политика использования cookies</h1>
        <p>
          Cookies помогают нам анализировать посещаемость сайта, адаптировать контент и улучшать пользовательский опыт.
          Используя наш сайт, вы даёте согласие на применение cookies в соответствии с данной политикой.
        </p>

        <h2>1. Что такое cookies</h2>
        <p>
          Cookies — это небольшие файлы, которые сохраняются на устройстве пользователя. Они позволяют нам запоминать
          ваши предпочтения и понимать, как вы взаимодействуете с сайтом.
        </p>

        <h2>2. Какие cookies мы используем</h2>
        <ul>
          <li>Функциональные cookies для запоминания настроек и предпочтений.</li>
          <li>Аналитические cookies для сбора обезличенной статистики использования сайта.</li>
          <li>Сессионные cookies, которые удаляются после закрытия браузера.</li>
        </ul>

        <h2>3. Управление cookies</h2>
        <p>
          Вы можете настроить использование cookies в параметрах браузера. Отказ от cookies может повлиять на корректную
          работу отдельных разделов сайта.
        </p>

        <h2>4. Контакты</h2>
        <p>
          Вопросы о политике cookies направляйте по адресу
          <a href="mailto:info@kompania.ru"> info@kompania.ru</a>.
        </p>
      </div>
    </section>
  </>
);

export default CookiesPolicy;