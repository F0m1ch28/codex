import React from 'react';
import Seo from '../components/Seo';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Как сформировать устойчивую стратегию роста',
    date: '5 сентября 2023',
    description:
      'Рассказываем, как сочетать долгосрочные цели, гибкость в управлении и вовлечение команды, чтобы стратегия работала в реальном бизнесе.',
    tags: ['Стратегия', 'Управление'],
    image: 'https://picsum.photos/900/600?random=91'
  },
  {
    title: 'Практическое руководство по внедрению BI',
    date: '24 августа 2023',
    description:
      'Определяем ключевые шаги BI-проекта, делимся чек-листом подготовки данных и советами по управлению изменениями.',
    tags: ['Аналитика', 'Технологии'],
    image: 'https://picsum.photos/900/600?random=92'
  },
  {
    title: 'Customer Journey: почему его важно пересматривать',
    date: '8 августа 2023',
    description:
      'Контур клиента меняется быстрее, чем процесс компании. Объясняем, как регулярно обновлять CJM и интегрировать его в процессы.',
    tags: ['Маркетинг', 'Опыт клиента'],
    image: 'https://picsum.photos/900/600?random=93'
  },
  {
    title: 'Оптимизация цепочки поставок: подход компании',
    date: '18 июля 2023',
    description:
      'Системный подход к управлению цепочкой поставок снижает операционные риски и повышает устойчивость бизнеса. Разбираем лучшие практики.',
    tags: ['Операции', 'Логистика'],
    image: 'https://picsum.photos/900/600?random=94'
  }
];

const Blog = () => (
  <>
    <Seo
      title="Блог — Компания"
      description="Свежие аналитические материалы и практические обзоры от команды Компания. Стратегия, трансформация, аналитика и операционные решения."
      keywords="блог, статьи, аналитика, стратегия, трансформация"
    />
    <section className={styles.hero}>
      <h1>Блог и аналитика</h1>
      <p>
        Делимся опытом и аналитикой, которые помогают принимать взвешенные решения и настраивать процессы под новые
        вызовы рынка.
      </p>
    </section>
    <section className={styles.posts}>
      <div className={styles.grid}>
        {posts.map((post) => (
          <article key={post.title} className={styles.card}>
            <img src={post.image} alt={post.title} loading="lazy" />
            <div className={styles.content}>
              <span className={styles.date}>{post.date}</span>
              <h2>{post.title}</h2>
              <p>{post.description}</p>
              <ul className={styles.tags}>
                {post.tags.map((tag) => (
                  <li key={tag}>{tag}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Blog;