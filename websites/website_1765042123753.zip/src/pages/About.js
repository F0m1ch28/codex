import React from 'react';
import Seo from '../components/Seo';
import styles from './About.module.css';

const milestones = [
  {
    year: '2011',
    title: 'Основание компании',
    description: 'Команда консультантов объединилась, чтобы поддерживать бизнес в период активных изменений рынка.'
  },
  {
    year: '2015',
    title: 'Запуск аналитического направления',
    description: 'Создали первый центр компетенций по работе с данными и внедрили BI в крупных сетевых компаниях.'
  },
  {
    year: '2019',
    title: 'Международные проекты',
    description: 'Начали реализацию проектов в Европе и СНГ, расширив географию сотрудничества.'
  },
  {
    year: '2022',
    title: 'Цифровая трансформация',
    description: 'Сформировали практику цифровой трансформации, запустили собственные методологии и образовательные программы.'
  }
];

const values = [
  {
    title: 'Ответственность',
    description: 'Мы готовы отвечать за рекомендации и решения, которые предлагаем клиентам.'
  },
  {
    title: 'Партнёрство',
    description: 'Работаем в одной команде, фокусируясь на устойчивом результате.'
  },
  {
    title: 'Экспертиза',
    description: 'Инвестируем в развитие специалистов и внедрение новых знаний.'
  },
  {
    title: 'Прозрачность',
    description: 'Говорим о сложных вопросах открыто и предлагаем реалистичные пути решения.'
  }
];

const About = () => (
  <>
    <Seo
      title="О компании — Компания"
      description="Узнайте о миссии, ценностях и истории компании. Мы создаём решения для устойчивого развития бизнеса и сопровождаем изменения."
      keywords="о компании, миссия, ценности, история компании"
    />
    <section className={styles.intro}>
      <div className={styles.container}>
        <div className={styles.textBlock}>
          <h1>О компании</h1>
          <p>
            Компания — консалтинговая и технологическая группа, которая помогает организациям достигать нового уровня
            эффективности. Мы соединяем стратегическое мышление, управление изменениями и современные технологии,
            чтобы бизнес клиентов становился гибким и устойчивым.
          </p>
          <p>
            Наши эксперты сопровождают команды на всех этапах — от диагностики и разработки стратегии до внедрения и
            поддержки. Мы верим в силу партнерства и прозрачного диалога, благодаря которым совместная работа приносит
            реальные результаты.
          </p>
        </div>
        <div className={styles.imageBlock}>
          <img
            src="https://picsum.photos/800/600?random=61"
            alt="Команда компании на стратегической сессии"
            loading="lazy"
          />
        </div>
      </div>
    </section>

    <section className={styles.mission}>
      <div className={styles.container}>
        <div className={styles.missionContent}>
          <h2>Миссия</h2>
          <p>
            Мы помогаем компаниям формировать устойчивые стратегии, которые делают их более конкурентоспособными и
            готовыми к будущему. Наша цель — поддерживать лидеров и развивающиеся бизнесы, чтобы они уверенно
            справлялись с вызовами и создавали ценность для клиентов и общества.
          </p>
        </div>
        <div className={styles.missionHighlights}>
          <div className={styles.highlight}>
            <span className={styles.highlightNumber}>48</span>
            <span>Экспертов в штате</span>
          </div>
          <div className={styles.highlight}>
            <span className={styles.highlightNumber}>12</span>
            <span>Лет непрерывного развития</span>
          </div>
          <div className={styles.highlight}>
            <span className={styles.highlightNumber}>9</span>
            <span>Отраслевых практик</span>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.values}>
      <div className={styles.container}>
        <h2>Наши ценности</h2>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.milestones}>
      <div className={styles.container}>
        <h2>История развития</h2>
        <div className={styles.timeline}>
          {milestones.map((item) => (
            <div key={item.year} className={styles.timelineItem}>
              <span className={styles.timelineYear}>{item.year}</span>
              <div className={styles.timelineContent}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.culture}>
      <div className={styles.container}>
        <h2>Культура и подход</h2>
        <div className={styles.cultureGrid}>
          <div className={styles.cultureCard}>
            <h3>Командная работа</h3>
            <p>
              Мы строим доверительные отношения, в которых каждый эксперт разделяет ответственность за результат.
              Важно, чтобы решения были не только реализованы, но и приняли корневую форму в организации клиента.
            </p>
          </div>
          <div className={styles.cultureCard}>
            <h3>Обучение и развитие</h3>
            <p>
              Ежегодно сотрудники проходят повышение квалификации, участвуют в международных конференциях и обмене
              опытом. Это позволяет нам внедрять лучшие практики и поддерживать высокий уровень экспертизы.
            </p>
          </div>
          <div className={styles.cultureCard}>
            <h3>Инновации</h3>
            <p>
              Мы используем технологические инструменты, создаём прототипы и пилоты, чтобы проверять гипотезы и
              внедрять рабочие решения с минимальными рисками для клиента.
            </p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default About;