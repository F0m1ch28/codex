import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Services.module.css';

const serviceBlocks = [
  {
    title: 'Стратегический консалтинг',
    description:
      'Формируем стратегии развития, определяем приоритеты и операционные модели, которые помогают достигать амбициозных целей.',
    bulletPoints: [
      'Диагностика бизнеса и конкурентной среды',
      'Разработка стратегических и операционных моделей',
      'Построение системы показателей и KPI',
      'Сопровождение реализации стратегии'
    ]
  },
  {
    title: 'Цифровая трансформация',
    description:
      'Помогаем выстроить цифровую экосистему, оптимизировать процессы и внедрить технологии, которые дают новый уровень эффективности.',
    bulletPoints: [
      'Цифровая стратегия и архитектура',
      'Внедрение ERP, CRM и специализированных решений',
      'Автоматизация процессов и роботизация',
      'Обучение и поддержка команд'
    ]
  },
  {
    title: 'Аналитика и управление данными',
    description:
      'Настраиваем полный цикл работы с данными: от сбора и качества до визуализации и применения в принятии решений.',
    bulletPoints: [
      'Разработка BI-платформ и дашбордов',
      'Построение хранилищ данных и интеграций',
      'Модели прогнозирования и ML-проекты',
      'Обеспечение качества и безопасности данных'
    ]
  },
  {
    title: 'Операционные улучшения',
    description:
      'Оптимизируем ключевые процессы, повышаем производительность и внедряем культуру постоянных улучшений.',
    bulletPoints: [
      'Lean и Agile трансформация',
      'Оптимизация цепочек поставок',
      'Системы управления качеством',
      'Управление изменениями и обучение'
    ]
  }
];

const faqs = [
  {
    question: 'Можно ли заказать диагностику перед большим проектом?',
    answer:
      'Да, мы рекомендуем начинать с короткой диагностики. Она помогает понять масштаб задач, сформировать дорожную карту и определить команду проекта.'
  },
  {
    question: 'Сколько длится проект по цифровой трансформации?',
    answer:
      'Длительность зависит от масштаба и готовности организации. Пилот можно реализовать за 3–6 месяцев, комплексная трансформация занимает от 12 месяцев.'
  },
  {
    question: 'Работаете ли вы с внутренними командами клиента?',
    answer:
      'Безусловно. Мы формируем смешанные проектные команды и передаём знания, чтобы решения были устойчивыми и автономными.'
  }
];

const Services = () => {
  const [expandedIndex, setExpandedIndex] = useState(null);

  const toggleFaq = (index) => {
    setExpandedIndex((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Seo
        title="Услуги — Компания"
        description="Стратегический консалтинг, цифровая трансформация, аналитика и операционные улучшения. Комплексные услуги для развития бизнеса."
        keywords="услуги, консалтинг, цифровая трансформация, аналитика"
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Комплексные решения для развития бизнеса</h1>
          <p>
            Мы создаём системные изменения, объединяя стратегический взгляд, технологическую экспертизу и гибкий
            подход к управлению проектами. Каждый проект адаптируется под задачи клиента.
          </p>
        </div>
        <div className={styles.heroImage}>
          <img
            src="https://picsum.photos/1000/700?random=71"
            alt="Рабочая сессия над проектом клиента"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.services}>
        {serviceBlocks.map((service) => (
          <article key={service.title} className={styles.serviceCard}>
            <div className={styles.cardContent}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <ul>
                {service.bulletPoints.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.faq}>
        <h2>Частые вопросы</h2>
        <div className={styles.faqList}>
          {faqs.map((faq, index) => (
            <div key={faq.question} className={styles.faqItem}>
              <button
                type="button"
                onClick={() => toggleFaq(index)}
                className={styles.faqQuestion}
                aria-expanded={expandedIndex === index}
              >
                {faq.question}
                <span>{expandedIndex === index ? '−' : '+'}</span>
              </button>
              {expandedIndex === index && <p className={styles.faqAnswer}>{faq.answer}</p>}
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default Services;