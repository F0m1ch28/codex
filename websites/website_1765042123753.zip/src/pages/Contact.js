import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', company: '', message: '' });
  const [status, setStatus] = useState({ success: false, error: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setStatus({ success: false, error: '' });
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setStatus({ success: false, error: 'Заполните обязательные поля: имя, email и сообщение.' });
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      setStatus({ success: false, error: 'Введите корректный email.' });
      return;
    }

    setTimeout(() => {
      setStatus({ success: true, error: '' });
      setFormData({ name: '', email: '', company: '', message: '' });
    }, 700);
  };

  return (
    <>
      <Seo
        title="Контакты — Компания"
        description="Свяжитесь с командой Компания: офис в Москве, телефон, email и форма обратной связи. Ответим на запрос в течение рабочего дня."
        keywords="контакты, офис, телефон, email"
      />
      <section className={styles.hero}>
        <div className={styles.text}>
          <h1>Свяжитесь с нами</h1>
          <p>
            Мы рады обсудить вашу задачу и предложить решение, основанное на реальном опыте и передовых практиках.
            Заполните форму или свяжитесь с нами удобным способом.
          </p>
          <ul className={styles.contactList}>
            <li>
              <span className={styles.label}>Адрес:</span>
              <span>123100, Россия, г. Москва, Пресненская набережная, д. 12</span>
            </li>
            <li>
              <span className={styles.label}>Телефон:</span>
              <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            </li>
            <li>
              <span className={styles.label}>Email:</span>
              <a href="mailto:info@kompania.ru">info@kompania.ru</a>
            </li>
          </ul>
        </div>
        <div className={styles.map}>
          <img
            src="https://picsum.photos/900/600?random=81"
            alt="Офис компании в Москве"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.formSection}>
        <h2>Напишите нам</h2>
        <p>Опишите задачу — и мы вернёмся с ответом уже в ближайший рабочий день.</p>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.row}>
            <div className={styles.field}>
              <label htmlFor="contactName">Имя *</label>
              <input
                id="contactName"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                placeholder="Ваше имя"
                required
              />
            </div>
            <div className={styles.field}>
              <label htmlFor="contactEmail">Email *</label>
              <input
                id="contactEmail"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="example@company.ru"
                required
              />
            </div>
          </div>
          <div className={styles.row}>
            <div className={styles.field}>
              <label htmlFor="contactCompany">Компания</label>
              <input
                id="contactCompany"
                name="company"
                type="text"
                value={formData.company}
                onChange={handleChange}
                placeholder="Название компании"
              />
            </div>
          </div>
          <div className={styles.field}>
            <label htmlFor="contactMessage">Сообщение *</label>
            <textarea
              id="contactMessage"
              name="message"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              placeholder="Расскажите о задаче или проекте"
              required
            />
          </div>
          {status.error && <p className={styles.error}>{status.error}</p>}
          {status.success && <p className={styles.success}>Сообщение отправлено! Мы свяжемся с вами.</p>}
          <button type="submit" className={styles.submitButton}>
            Отправить
          </button>
        </form>
      </section>
    </>
  );
};

export default Contact;