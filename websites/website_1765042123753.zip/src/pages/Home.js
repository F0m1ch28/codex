import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const statsData = [
  { label: 'Лет на рынке', value: 12 },
  { label: 'Реализованных проектов', value: 380 },
  { label: 'Постоянных клиентов', value: 95 },
  { label: 'Экспертов в команде', value: 48 }
];

const services = [
  {
    title: 'Стратегическое консультирование',
    description: 'Формируем долгосрочные стратегии развития и роста, учитывая особенности отрасли и цели компании.'
  },
  {
    title: 'Цифровая трансформация',
    description: 'Внедряем современные технологии и автоматизируем ключевые процессы, повышая эффективность бизнеса.'
  },
  {
    title: 'Аналитика и BI',
    description: 'Создаём экосистему данных, которая помогает руководителям принимать решения на основе фактов.'
  },
  {
    title: 'Операционное совершенство',
    description: 'Оптимизируем операционные процессы, выстраиваем систему контроля качества и управления изменениями.'
  }
];

const advantages = [
  'Профессионализм и опыт',
  'Индивидуальный подход',
  'Надежность и качество',
  'Современные технологии',
  'Прозрачная коммуникация',
  'Долгосрочное партнёрство'
];

const processSteps = [
  {
    title: 'Исследование и диагностика',
    description: 'Понимаем текущую ситуацию, анализируем процессы и определяем точки роста.'
  },
  {
    title: 'Совместное проектирование',
    description: 'Формируем решения вместе с командой клиента, учитывая стратегию и ресурсы.'
  },
  {
    title: 'Внедрение и поддержка',
    description: 'Сопровождаем внедрение, обучаем команды и помогаем адаптировать изменения.'
  },
  {
    title: 'Контроль результатов',
    description: 'Отслеживаем KPI, корректируем действия и закрепляем достигнутые улучшения.'
  }
];

const testimonials = [
  {
    quote:
      'Благодаря команде «Компания» мы смогли пересмотреть бизнес-процессы и навести порядок в данных. Рост эффективности заметили уже через три месяца.',
    name: 'Анастасия Волкова',
    role: 'Генеральный директор, «Сфера»'
  },
  {
    quote:
      'Отметили высокий уровень экспертизы и внимательное отношение к деталям. Проект по цифровой трансформации прошёл без сбоев и в срок.',
    name: 'Илья Корнилов',
    role: 'Операционный директор, «Техпром»'
  },
  {
    quote:
      'Команда не просто консультировала, а работала вместе с нами плечом к плечу. Рекомендую «Компания» за их практичность и гибкость.',
    name: 'Мария Штукина',
    role: 'Директор по развитию, «Городские решения»'
  }
];

const teamMembers = [
  {
    name: 'Елена Миронова',
    role: 'Управляющий партнёр',
    bio: '15 лет опыта в стратегическом менеджменте и трансформации крупнейших компаний.',
    img: 'https://picsum.photos/400/400?random=31'
  },
  {
    name: 'Дмитрий Белов',
    role: 'Директор по аналитике',
    bio: 'Эксперт по данным и BI, выстроил аналитические платформы для банков и ритейла.',
    img: 'https://picsum.photos/400/400?random=32'
  },
  {
    name: 'Оксана Коваль',
    role: 'Руководитель проектов',
    bio: 'Специалист по управлению изменениями, сертифицированный PMP и Agile Coach.',
    img: 'https://picsum.photos/400/400?random=33'
  },
  {
    name: 'Артур Сафаров',
    role: 'Технический архитектор',
    bio: 'Отвечает за технологическую архитектуру и безопасность решений.',
    img: 'https://picsum.photos/400/400?random=34'
  }
];

const projects = [
  {
    title: 'Цифровая экосистема для холдинга',
    category: 'Технологии',
    description: 'Единая платформа для управления активами и оперативной отчётности.',
    image: 'https://picsum.photos/1200/800?random=41'
  },
  {
    title: 'Стратегия роста розничной сети',
    category: 'Стратегия',
    description: 'Маршрут масштабирования и оптимизации процессов для сети магазинов.',
    image: 'https://picsum.photos/1200/800?random=42'
  },
  {
    title: 'Внедрение BI-решения',
    category: 'Аналитика',
    description: 'Создание хранилища данных и визуализация ключевых показателей бизнеса.',
    image: 'https://picsum.photos/1200/800?random=43'
  },
  {
    title: 'Оптимизация цепочки поставок',
    category: 'Операции',
    description: 'Новый подход к планированию поставок и управлению запасами.',
    image: 'https://picsum.photos/1200/800?random=44'
  }
];

const faqItems = [
  {
    question: 'С какими отраслями вы работаете?',
    answer:
      'Наш опыт охватывает финансовый сектор, промышленность, услуги, ритейл и технологические компании. Мы адаптируем подход под специфику отрасли.'
  },
  {
    question: 'Как начинается сотрудничество?',
    answer:
      'Мы проводим первичную диагностику, определяем цели, формируем команду проекта и согласовываем дорожную карту внедрения.'
  },
  {
    question: 'Насколько гибки ваши решения?',
    answer:
      'Каждый проект проектируется индивидуально. Мы учитываем существующие процессы и IT-ландшафт, чтобы интеграция была комфортной.'
  },
  {
    question: 'Предоставляете ли вы обучение для сотрудников?',
    answer:
      'Да, мы проводим очные и онлайн-сессии, готовим методические материалы и поддерживаем команду после запуска решения.'
  },
  {
    question: 'Работаете ли вы с региональными компаниями?',
    answer:
      'Мы реализуем проекты по всей России и в странах СНГ. Формат взаимодействия подбираем вместе с клиентом — онлайн, офлайн или гибридно.'
  }
];

const blogPreviews = [
  {
    title: 'Пять шагов к зрелой аналитике данных',
    excerpt: 'Как перевести данные из хаоса в надежный инструмент управления — практические рекомендации команды.',
    date: '15 сентября 2023',
    image: 'https://picsum.photos/800/600?random=51'
  },
  {
    title: 'Цифровая трансформация: ошибки, которых стоит избежать',
    excerpt: 'Мы собрали ключевые ошибки проектов трансформации и подсказали, как их обойти.',
    date: '2 сентября 2023',
    image: 'https://picsum.photos/800/600?random=52'
  },
  {
    title: 'Клиентоцентричность как основа стратегии',
    excerpt: 'Почему компании, ставящие клиента в центр, выигрывают и как выстроить такой подход на практике.',
    date: '20 августа 2023',
    image: 'https://picsum.photos/800/600?random=53'
  }
];

const categories = ['Все', 'Технологии', 'Стратегия', 'Аналитика', 'Операции'];

const ImageWithLoader = ({ src, alt }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={`${styles.imageWrapper} ${loaded ? styles.imageLoaded : ''}`}>
      <img src={src} alt={alt} onLoad={() => setLoaded(true)} loading="lazy" />
      {!loaded && <div className={styles.imageSkeleton} aria-hidden="true" />}
    </div>
  );
};

const Home = () => {
  const [heroImageLoaded, setHeroImageLoaded] = useState(false);
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [activeProjectCategory, setActiveProjectCategory] = useState('Все');
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [formStatus, setFormStatus] = useState({ submitted: false, error: '' });
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    let animationFrame;
    const start = performance.now();
    const duration = 1500;

    const animate = (time) => {
      const progress = Math.min((time - start) / duration, 1);
      setStats(
        statsData.map((stat) => Math.floor(stat.value * progress))
      );
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeProjectCategory === 'Все') {
      return projects;
    }
    return projects.filter((project) => project.category === activeProjectCategory);
  }, [activeProjectCategory]);

  const handleFormChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setFormStatus({ submitted: false, error: 'Пожалуйста, заполните все поля формы.' });
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      setFormStatus({ submitted: false, error: 'Укажите корректный адрес электронной почты.' });
      return;
    }

    setTimeout(() => {
      setFormStatus({ submitted: true, error: '' });
      setFormData({ name: '', email: '', message: '' });
    }, 600);
  };

  const nextTestimonial = () => {
    setTestimonialIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setTestimonialIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  const toggleFaq = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Seo
        title="Компания — качественные решения для вашего бизнеса"
        description="Компания предлагает стратегическое консультирование, цифровую трансформацию и поддержку развития бизнеса. Узнайте, почему нас выбирают лидеры рынка."
        keywords="консалтинг, цифровая трансформация, аналитика, операционная эффективность"
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroTagline}>Ваши цели — наша ответственность</p>
          <h1 className={styles.heroTitle}>Добро пожаловать в Компанию</h1>
          <p className={styles.heroSubtitle}>
            Мы предоставляем качественные решения для вашего бизнеса, соединяя стратегию, технологии и опыт
            реализации. Вместе мы создаем устойчивые изменения, которые заметны уже сегодня.
          </p>
          <div className={styles.heroActions}>
            <Link to="/o-kompanii" className={styles.primaryButton}>
              Узнать больше
            </Link>
            <Link to="/kontakty" className={styles.secondaryButton}>
              Запросить консультацию
            </Link>
          </div>
        </div>
        <div className={`${styles.heroMedia} ${heroImageLoaded ? styles.heroMediaLoaded : ''}`}>
          <img
            src="https://picsum.photos/1600/900?random=11"
            alt="Команда специалистов за обсуждением проекта"
            onLoad={() => setHeroImageLoaded(true)}
            loading="eager"
          />
          {!heroImageLoaded && <div className={styles.heroSkeleton} aria-hidden="true" />}
        </div>
      </section>

      <section className={styles.stats} aria-label="Ключевые показатели компании">
        <div className={styles.statsGrid}>
          {statsData.map((stat, index) => (
            <div className={styles.statCard} key={stat.label}>
              <span className={styles.statValue}>{stats[index]}+</span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.aboutPreview}>
        <div className={styles.sectionHeader}>
          <h2>О нашей компании</h2>
          <p>
            Компания — это надежный партнер в сфере управленческого консалтинга, цифровой трансформации и аналитики.
            Мы работаем с 2011 года, помогая клиентам достигать их целей и уверенно расти.
          </p>
        </div>
        <Link to="/o-kompanii" className={styles.linkArrow}>
          Подробнее об истории и команде
        </Link>
      </section>

      <section className={styles.services}>
        <div className={styles.sectionHeader}>
          <h2>Наши услуги</h2>
          <p>
            Мы объединяем стратегический подход, экспертные знания и современные технологии, чтобы предложить решения,
            которые помогают бизнесу развиваться быстрее.
          </p>
        </div>
        <div className={styles.serviceGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/uslugi" className={styles.serviceLink}>
                Подробнее
              </Link>
            </article>
          ))}
        </div>
        <div className={styles.sectionFooter}>
          <Link to="/uslugi" className={styles.primaryButton}>
            Все услуги
          </Link>
        </div>
      </section>

      <section className={styles.advantages} aria-label="Преимущества компании">
        <div className={styles.sectionHeader}>
          <h2>Почему выбирают нас</h2>
          <p>
            Наш подход строится на глубоком понимании бизнеса, прозрачной коммуникации и ориентации на конкретный
            результат.
          </p>
        </div>
        <ul className={styles.advantageList}>
          {advantages.map((advantage) => (
            <li key={advantage} className={styles.advantageItem}>
              {advantage}
            </li>
          ))}
        </ul>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <h2>Как мы работаем</h2>
          <p>
            Устойчивые изменения требуют системного подхода. Мы сопровождаем клиента на всех этапах, создавая
            пространство для развития команды и бизнеса.
          </p>
        </div>
        <div className={styles.processTimeline}>
          {processSteps.map((step, index) => (
            <div className={styles.processStep} key={step.title}>
              <span className={styles.processNumber}>
                {(index + 1).toString().padStart(2, '0')}
              </span>
              <div>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Отзывы клиентов">
        <div className={styles.sectionHeader}>
          <h2>Отзывы клиентов</h2>
          <p>Мы гордимся доверием лидеров рынка и тем, что сопровождаем их рост на протяжении многих лет.</p>
        </div>
        <div className={styles.testimonialSlider}>
          <button
            type="button"
            onClick={prevTestimonial}
            className={styles.sliderControl}
            aria-label="Предыдущий отзыв"
          >
            ‹
          </button>
          <article className={styles.testimonialCard}>
            <p className={styles.testimonialQuote}>
              “{testimonials[testimonialIndex].quote}”
            </p>
            <div className={styles.testimonialAuthor}>
              <span className={styles.testimonialName}>{testimonials[testimonialIndex].name}</span>
              <span className={styles.testimonialRole}>{testimonials[testimonialIndex].role}</span>
            </div>
          </article>
          <button
            type="button"
            onClick={nextTestimonial}
            className={styles.sliderControl}
            aria-label="Следующий отзыв"
          >
            ›
          </button>
        </div>
      </section>

      <section className={styles.team} aria-label="Команда компании">
        <div className={styles.sectionHeader}>
          <h2>Встречайте команду</h2>
          <p>
            Мы собрали специалистов с разнообразным опытом, чтобы создавать комплексные решения и сопровождать их
            реализацию от идеи до результата.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <ImageWithLoader src={member.img} alt={`${member.name}, ${member.role}`} />
              <div className={styles.teamContent}>
                <h3>{member.name}</h3>
                <p className={styles.teamRole}>{member.role}</p>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects} aria-label="Наши проекты">
        <div className={styles.sectionHeader}>
          <h2>Проекты и кейсы</h2>
          <p>
            Каждая история успеха — это результат коллективной ответственности, точного планирования и гибкой
            адаптации. Мы делимся ключевыми проектами, чтобы вдохновить на изменения.
          </p>
        </div>
        <div className={styles.filterBar} role="tablist" aria-label="Фильтр проектов">
          {categories.map((category) => (
            <button
              type="button"
              key={category}
              className={`${styles.filterButton} ${
                activeProjectCategory === category ? styles.filterButtonActive : ''
              }`}
              onClick={() => setActiveProjectCategory(category)}
              role="tab"
              aria-selected={activeProjectCategory === category}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <ImageWithLoader src={project.image} alt={project.title} />
              <div className={styles.projectContent}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq} aria-label="Часто задаваемые вопросы">
        <div className={styles.sectionHeader}>
          <h2>Вопросы и ответы</h2>
          <p>Если не нашли нужную информацию, напишите нам — мы с радостью поможем.</p>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <div key={item.question} className={styles.faqItem}>
              <button
                type="button"
                className={styles.faqQuestion}
                onClick={() => toggleFaq(index)}
                aria-expanded={openFaq === index}
              >
                <span>{item.question}</span>
                <span className={styles.faqIcon}>{openFaq === index ? '−' : '+'}</span>
              </button>
              {openFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className={styles.sectionHeader}>
          <h2>Полезные материалы</h2>
          <p>Мы делимся знаниями и опытом, чтобы рынок становился зрелее и прозрачнее.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPreviews.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <ImageWithLoader src={post.image} alt={post.title} />
              <div className={styles.blogContent}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/blog" className={styles.serviceLink}>
                  Читать в блоге
                </Link>
              </div>
            </article>
          ))}
        </div>
        <div className={styles.sectionFooter}>
          <Link to="/blog" className={styles.secondaryButton}>
            Все статьи
          </Link>
        </div>
      </section>

      <section className={styles.contactCta} id="contact">
        <div className={styles.sectionHeader}>
          <h2>Свяжитесь с нами</h2>
          <p>
            Расскажите нам о задаче, и мы предложим решение, основанное на лучших практиках и опыте реализации
            сложных проектов.
          </p>
        </div>
        <div className={styles.contactGrid}>
          <div className={styles.contactInfo}>
            <h3>Контактные данные</h3>
            <p>Мы на связи и готовы ответить на вопросы в удобном для вас формате.</p>
            <ul>
              <li>
                <span className={styles.contactLabel}>Адрес:</span>
                <span>123100, Россия, г. Москва, Пресненская набережная, д. 12</span>
              </li>
              <li>
                <span className={styles.contactLabel}>Телефон:</span>
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </li>
              <li>
                <span className={styles.contactLabel}>Email:</span>
                <a href="mailto:info@kompania.ru">info@kompania.ru</a>
              </li>
            </ul>
          </div>
          <form className={styles.contactForm} onSubmit={handleFormSubmit} noValidate>
            <div className={styles.formGroup}>
              <label htmlFor="homeName">Имя</label>
              <input
                id="homeName"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleFormChange}
                placeholder="Ваше имя"
                required
              />
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="homeEmail">Email</label>
              <input
                id="homeEmail"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleFormChange}
                placeholder="example@domain.ru"
                required
              />
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="homeMessage">Сообщение</label>
              <textarea
                id="homeMessage"
                name="message"
                rows="4"
                value={formData.message}
                onChange={handleFormChange}
                placeholder="Расскажите о задаче или вопросе"
                required
              />
            </div>
            {formStatus.error && <p className={styles.formError}>{formStatus.error}</p>}
            {formStatus.submitted && (
              <p className={styles.formSuccess}>Спасибо! Мы свяжемся с вами в ближайшее время.</p>
            )}
            <button type="submit" className={styles.primaryButton}>
              Отправить сообщение
            </button>
          </form>
        </div>
      </section>
    </>
  );
};

export default Home;