import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Blog from './pages/Blog';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiesPolicy from './pages/CookiesPolicy';

const App = () => (
  <BrowserRouter>
    <div className="appWrapper">
      <Header />
      <main className="mainContent" role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/o-kompanii" element={<About />} />
          <Route path="/uslugi" element={<Services />} />
          <Route path="/kontakty" element={<Contact />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/usloviya" element={<Terms />} />
          <Route path="/politika-konfidencialnosti" element={<Privacy />} />
          <Route path="/politika-cookies" element={<CookiesPolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  </BrowserRouter>
);

export default App;