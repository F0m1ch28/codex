document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector("[data-nav-toggle]");
  const navMenu = document.querySelector("[data-nav-menu]");
  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      const isOpen = navMenu.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
    navMenu.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (window.innerWidth < 900) {
          navMenu.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );
  document.querySelectorAll(".animate-on-scroll").forEach((el) => observer.observe(el));

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  const cookieAccept = document.querySelector("[data-cookie-accept]");
  const cookieDecline = document.querySelector("[data-cookie-decline]");
  const cookieLink = document.querySelector("[data-cookie-link]");
  const COOKIE_KEY = "urbanautofixCookieChoice";

  if (cookieBanner && cookieAccept && cookieDecline) {
    const storedChoice = localStorage.getItem(COOKIE_KEY);
    if (!storedChoice) {
      cookieBanner.classList.add("active");
    }

    const handleChoice = (choice) => {
      localStorage.setItem(COOKIE_KEY, choice);
      cookieBanner.classList.remove("active");
    };

    cookieAccept.addEventListener("click", () => handleChoice("accept"));
    cookieDecline.addEventListener("click", () => handleChoice("decline"));
    if (cookieLink) {
      cookieLink.addEventListener("click", () => {
        cookieBanner.classList.remove("active");
      });
    }
  }

  const toast = document.querySelector("[data-toast]");
  const showToast = (message) => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    setTimeout(() => {
      toast.classList.remove("is-visible");
    }, 1600);
  };

  const forms = document.querySelectorAll("form[data-enhanced]");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      showToast("Solicitarea a fost trimisă. Mulțumim!");
      const target = form.getAttribute("action") || "thank-you.html";
      setTimeout(() => {
        window.location.href = target;
      }, 1200);
    });
  });

  const yearHolders = document.querySelectorAll("[data-year]");
  const currentYear = new Date().getFullYear();
  yearHolders.forEach((el) => {
    el.textContent = String(currentYear);
  });
});