document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navLinks.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', navLinks.classList.contains('is-open'));
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const currentYearEl = document.getElementById('currentYear');
    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const storedDecision = localStorage.getItem('navalmifvd_cookie_consent');
        if (!storedDecision) {
            cookieBanner.classList.add('is-visible');
        }

        cookieBanner.addEventListener('click', event => {
            const target = event.target.closest('[data-choice]');
            if (target) {
                event.preventDefault();
                const decision = target.dataset.choice;
                localStorage.setItem('navalmifvd_cookie_consent', decision);
                cookieBanner.classList.remove('is-visible');
                if (target.hasAttribute('href')) {
                    const url = target.getAttribute('href');
                    if (url) {
                        window.location.href = url;
                    }
                }
            }
        });
    }

    const searchInput = document.querySelector('[data-search-input]');
    const filterButtons = document.querySelectorAll('[data-filter-button]');
    const articleCards = document.querySelectorAll('[data-article-card]');

    function applyFilters() {
        const query = (searchInput ? searchInput.value.trim().toLowerCase() : '');
        const activeFilter = document.querySelector('[data-filter-button].is-active');
        const category = activeFilter ? activeFilter.dataset.filterButton : 'all';

        articleCards.forEach(card => {
            const title = card.querySelector('.card-title')?.textContent.toLowerCase() || '';
            const summary = card.querySelector('.card-summary')?.textContent.toLowerCase() || '';
            const cardCategory = card.dataset.category || 'all';
            const matchesCategory = category === 'all' || category === cardCategory;
            const matchesSearch = !query || title.includes(query) || summary.includes(query);
            if (matchesCategory && matchesSearch) {
                card.style.display = '';
            } else {
                card.style.display = 'none';
            }
        });
    }

    if (searchInput) {
        searchInput.addEventListener('input', applyFilters);
    }

    if (filterButtons.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                filterButtons.forEach(btn => btn.classList.remove('is-active'));
                button.classList.add('is-active');
                applyFilters();
            });
        });
    }

    const forms = document.querySelectorAll('form[data-validate]');
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                form.reportValidity();
            }
        });
    });
});