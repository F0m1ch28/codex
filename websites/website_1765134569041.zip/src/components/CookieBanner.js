import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timeout = setTimeout(() => setVisible(true), 1000);
      return () => clearTimeout(timeout);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        Ми використовуємо файли cookie, щоб поліпшити роботу сайту та аналізувати відвідуваність. Деталі у{' '}
        <a href="/cookie-policy" className={styles.link}>
          політиці щодо файлів cookie
        </a>
        .
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Прийняти
      </button>
    </div>
  );
};

export default CookieBanner;