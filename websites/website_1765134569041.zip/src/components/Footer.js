import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={styles.inner}>
        <div className={styles.column}>
          <h2 id="footer-heading" className={styles.title}>
            Професійне дресирування собак
          </h2>
          <p>
            Гуманні методи, міжнародний досвід та глибоке розуміння німецьких
            вівчарок для стабільних результатів у Варшаві та Кракові.
          </p>
        </div>
        <div className={styles.column}>
          <h3>Контакти</h3>
          <ul className={styles.list}>
            <li>
              Варшава, вул. Тренерська, 10 <br />
              Краків, вул. Собача, 5А
            </li>
            <li>
              Телефон:{' '}
              <a href="tel:+48123456789" className={styles.link}>
                +48 123 456 789
              </a>
            </li>
            <li>
              Email:{' '}
              <a href="mailto:trainer@dog-whisperer.pl" className={styles.link}>
                trainer@dog-whisperer.pl
              </a>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3>Документи</h3>
          <ul className={styles.list}>
            <li>
              <Link to="/terms" className={styles.link}>
                Умови використання
              </Link>
            </li>
            <li>
              <Link to="/privacy" className={styles.link}>
                Політика конфіденційності
              </Link>
            </li>
            <li>
              <Link to="/cookie-policy" className={styles.link}>
                Політика щодо файлів cookie
              </Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3>Соціальні мережі</h3>
          <div className={styles.socials} aria-label="Соціальні мережі">
            <a href="#facebook" className={styles.socialLink} aria-label="Facebook">
              <span aria-hidden="true"></span>
            </a>
            <a href="#instagram" className={styles.socialLink} aria-label="Instagram">
              <span aria-hidden="true"></span>
            </a>
            <a href="#youtube" className={styles.socialLink} aria-label="YouTube">
              <span aria-hidden="true"></span>
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        © {new Date().getFullYear()} Професійне дресирування собак. Усі права захищено.
      </div>
    </footer>
  );
};

export default Footer;