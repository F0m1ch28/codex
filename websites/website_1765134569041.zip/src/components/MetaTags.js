import { useEffect } from 'react';

const ensureMetaTag = (name, content) => {
  let tag = document.querySelector(`meta[name="${name}"]`);
  if (!tag) {
    tag = document.createElement('meta');
    tag.setAttribute('name', name);
    document.head.appendChild(tag);
  }
  tag.setAttribute('content', content);
};

const MetaTags = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    if (description) {
      ensureMetaTag('description', description);
    }
    if (keywords) {
      ensureMetaTag('keywords', keywords);
    }
  }, [title, description, keywords]);

  return null;
};

export default MetaTags;