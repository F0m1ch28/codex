import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`}>
      <a href="#main-content" className={styles.skipLink}>
        Перейти до змісту
      </a>
      <div className={styles.logoArea}>
        <Link to="/" className={styles.logo} onClick={closeMenu}>
          Професійне дресирування собак
        </Link>
        <button
          className={styles.burger}
          onClick={toggleMenu}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Перемкнути навігацію"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
      <nav
        id="primary-navigation"
        className={`${styles.nav} ${menuOpen ? styles.open : ''}`}
        aria-label="Головна навігація"
      >
        <NavLink
          to="/"
          className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
          onClick={closeMenu}
        >
          Головна
        </NavLink>
        <NavLink
          to="/about"
          className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
          onClick={closeMenu}
        >
          Про нас
        </NavLink>
        <NavLink
          to="/services"
          className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
          onClick={closeMenu}
        >
          Послуги
        </NavLink>
        <NavLink
          to="/success-stories"
          className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
          onClick={closeMenu}
        >
          Наші успіхи
        </NavLink>
        <NavLink
          to="/contact"
          className={({ isActive }) => (isActive ? styles.activeLink : undefined)}
          onClick={closeMenu}
        >
          Контакти
        </NavLink>
      </nav>
    </header>
  );
};

export default Header;