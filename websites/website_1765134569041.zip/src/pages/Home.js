import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import MetaTags from '../components/MetaTags';
import styles from './Home.module.css';

const counters = [
  { label: 'Випускників програм', value: 480 },
  { label: 'Років досвіду', value: 12 },
  { label: 'Командних занять щороку', value: 160 },
  { label: 'Оцінок “відмінно” на виставках', value: 94 },
];

const faqItems = [
  {
    question: 'Скільки триває базова програма ОКД для німецької вівчарки?',
    answer:
      'У середньому 8-10 тижнів із двома очними заняттями на тиждень та домашніми завданнями. Графік коригується залежно від віку собаки та темпів засвоєння команд.',
  },
  {
    question: 'Чи працюєте ви з молодими та дорослими собаками?',
    answer:
      'Так, ми формуємо індивідуальні плани для цуценят від 4 місяців, підлітків та дорослих німецьких вівчарок, враховуючи темперамент та попередній досвід.',
  },
  {
    question: 'Які методи корекції поведінки ви застосовуєте?',
    answer:
      'Ми базуємося на позитивному підкріпленні, чітких правилах та системній роботі з власником. Важлива командна робота сім’ї, тому надаємо покрокові інструкції.',
  },
  {
    question: 'Чи можливі заняття на території клієнта?',
    answer:
      'Так, команда тренерів регулярно виїжджає по районах Варшави та Кракова, щоб працювати у знайомому для собаки середовищі.',
  },
];

const blogItems = [
  {
    id: 1,
    title: '5 вправ для розвитку концентрації у німецької вівчарки',
    date: '12 квітня 2024',
    excerpt:
      'Поєднуємо нюхові задачі та базові команди, аби збільшити здатність собаки тримати контакт із провідником у складних умовах.',
  },
  {
    id: 2,
    title: 'Як підготуватися до виставки IPO: нотатки тренера',
    date: '28 березня 2024',
    excerpt:
      'Звертаємо увагу на соціалізацію, роботу з фігурантом та стабільність хвату. Ділимося планом останніх двох тижнів перед стартом.',
  },
];

const processSteps = [
  {
    title: 'Стартова консультація',
    description:
      'Зустріч із власником та собакою, оцінка мотивації, рівня соціалізації та визначення цілей на найближчі 3 місяці.',
  },
  {
    title: 'Індивідуальна програма',
    description:
      'Складаємо графік занять, рекомендовані вправи та план домашньої роботи з урахуванням навантаження та відпочинку.',
  },
  {
    title: 'Практичні сесії',
    description:
      'Тренування у парках Варшави та Кракова, на майданчиках партнерів або вдома у клієнта. Працюємо над поведінкою у місті.',
  },
  {
    title: 'Підсумковий аналіз',
    description:
      'Фіксуємо прогрес, готуємо звіт з рекомендаціями та планом підтримки результатів. За потреби оновлюємо цілі.',
  },
];

const serviceHighlights = [
  {
    title: 'Базове послухняння (ОКД)',
    description:
      'Побудова чіткої взаємодії, відпрацювання базових команд, керування емоціями собаки у місті та на майданчику.',
  },
  {
    title: 'Корекція поведінки',
    description:
      'Допомагаємо працювати з реактивністю, страхами, гіперактивністю та охоронними проявами німецьких вівчарок.',
  },
  {
    title: 'Підготовка до виставок',
    description:
      'Супровід на етапі грумінгу, відпрацювання показу зубів, стійки та руху. Співпрацюємо з експертами FCI.',
  },
  {
    title: 'Індивідуальні заняття',
    description:
      'Гнучкий графік, робота з конкретними запитами сім’ї та адаптація тренувань до реальних ситуацій.',
  },
];

const successPreview = [
  {
    name: 'Олена та Макс',
    breed: 'нім. вівчарка',
    story:
      'За 3 місяці Макс навчився спокійно реагувати на інших собак у центрі Варшави, а також склав ОКД із високим балом.',
  },
  {
    name: 'Мартин і Лара',
    breed: 'нім. вівчарка',
    story:
      'Після курсу з корекції охоронної поведінки Лара комфортно приймає гостей у квартирі та демонструє стабільний контакт на прогулянках.',
  },
  {
    name: 'Наталія та Рекс',
    breed: 'нім. вівчарка',
    story:
      'Підготовка до виставки у Кракові завершилась відзнакою “відмінно” та рекомендацією від експертів клубу породи.',
  },
];

const projects = [
  {
    id: 1,
    title: 'Міська соціалізація у Варшаві',
    description: 'Серія тренувань у парках Лазєнки та на берегах Вісли для роботи з шумними середовищами.',
    image: 'https://picsum.photos/1200/800?random=41',
  },
  {
    id: 2,
    title: 'Спортивна підготовка IPO',
    description: 'Командна робота з фігуристами та кінологами для пар Луна/Іван та Аура/Каміла.',
    image: 'https://picsum.photos/1200/800?random=42',
  },
];

const teamMembers = [
  {
    name: 'Ірина Коваленко',
    role: 'Головна тренерка, кінолог IGP',
    bio: '12 років працює з робочими лініями німецьких вівчарок, стажування у клубах Німеччини.',
    image: 'https://picsum.photos/400/400?random=51',
  },
  {
    name: 'Пшемек Новак',
    role: 'Кінолог-поведінковець',
    bio: 'Спеціалізується на корекції реактивності та захисній роботі. Автор методичних посібників.',
    image: 'httpsum.photos/400/400?random=52'
  }
];

Oops mistake: the above `image` for second team member mis- spelled `httpsum`. Need correct.

Let's rewrite teamMembers.

Also need stats counters effect using useState maybe.

Let's build component.

**Important**: For counter animation we can use `useEffect` to animate. Example useState for array of values.

Add event to start when component loads maybe as home mount (makes simple). We'll set using `useEffect` to animate up. For each counter set state to 0 and increments until target. We'll use `requestAnimationFrame`. For simpler, use `setInterval`.

We'll implement `useEffect(() => { const intervals = counters.map...})` but counters constant. we need state `counterValues`, with `useState` initial array of zeros.

Pseudo:

```
const [counts, setCounts] = useState(counters.map(() => 0));

useEffect(() => {
 const timers = counters.map((counter, index) => {
   const duration = 1500;
   const stepTime = Math.max(Math.floor(duration / counter.value), 20);
   let current = 0;
   const timer = setInterval(() => {
      current += Math.ceil(counter.value / (duration / stepTime));
 ...
```

But this may exceed. Instead we can use `requestAnimationFrame`. Since we just need simple, we can use `setInterval`. We'll ensure we don't overshoot.

Simplify: for each counter:

```
const timers = counters.map((counter, idx) => {
 let start = 0;
 const increment = Math.ceil(counter.value / 60);
 return setInterval(() => { start += increment; setCounts(prev => { const newCounts = [...prev]; newCounts[idx] = Math.min(counter.value, start); return newCounts;}); if (start >= counter.value) clearInterval(...);}, 50);
});
return () => timers.forEach(clearInterval);
```

But we must ensure `setCounts` uses functional update.

Also we need teamMembers array with 3? we can add 3.

Let's define teamMembers properly.

Also we need to ensure we import `styles`.

We also need to manage `activeFAQ` state for accordion.

Let's craft final home component carefully. We'll include hooking for counters, FAQ toggle.

Also need to manage `Team` section with interactive (maybe on hover). We'll ensure alt text.

`Projects` filterable? maybe we can implement simple filter toggles "Всі" etc? advanced instructions mention "Filterable portfolio gallery". Need to create simple filter buttons. Provide categories? We can assign categories to projects and allow filter state. We'll create `projectFilters = ['Всі', 'Варшава', 'Краків'];` assign each project location property. On filter, show relevant.

Also instructions mention `Testimonials` as carousel. We'll create simple manual slider with `activeIndex` state and buttons. Provide accessible.

Let's craft.

Also contact block in home will include mini form. We'll manage state and simple validation message.

Also `Hero` button with animation.

Remember to use remote images per instructions with unique random numbers.

Need to ensure there is `Stats` (we have `counters`), `Process` steps, `Team` etc.

Let's craft Home component.

We also need to ensure there isn't leftover bug.

Let's rewrite entire `Home.js`.

Redo.

Need to ensure we import `useState` `useEffect`.

Let's craft carefully.

Also we must ensure we have `teamMembers` with correct image urls.

Ok rewriting:

```
import React, { useEffect, useState } from 'react';
...
const teamMembers = [
 { ..., image: 'https://picsum.photos/400/400?random=51' },
 { ..., image: 'https://picsum.photos/400/400?random=52' },
 { ..., image: 'https://picsum.photos/400/400?random=53' },
];
```

Projects with categories:

```
const projects = [
 { id:1, title:..., description:..., image:'https...random=61', category:'Варшава' },
 etc.
```

The hero background use `style` referencing `https://picsum.photos/1600/900?random=11`.

In contact form we must avoid actual submission; use `onSubmit` to prevent default.

Need to ensure we use `aria` attributes for accordion.

Now create `Home.module.css` to style.

Large set.

Let's craft component first.

They also want "CTA Section" near end maybe `Залишилися питання?` etc.

Also `Services overview` 3-4 blocks with link to services page.

`Geography` section with stylized map (maybe a simple card listing two cities with icon). We'll use `div` with background pattern.

Let's craft.

### Compose `Home.js`:

Pseudo:

```
const HomePage = () => {
 const [counts, setCounts] = useState(counters.map(() => 0));
 const [activeFAQ, setActiveFAQ] = useState(null);
 const [projectFilter, setProjectFilter] = useState('Всі');
 const [testimonialIndex, setTestimonialIndex] = useState(0);
 const [formData, setFormData] = useState(...); 
 const [formErrors, setFormErrors] = useState({});
 const [formStatus, setFormStatus] = useState('');

 useEffect(() => { animate counters }, []);

 const filteredProjects = ...;

 const handleFAQToggle = index => setActiveFAQ(prev => prev === index ? null : index);

 const handleChange = e => { setFormData(...); };

 const handleSubmit = e => { e.preventDefault(); // validate }.

 return (
   <>
    <MetaTags title=... description=... keywords=... />
    <section className=styles.hero>...
```

Testimonial slider:

```
const handleNextTestimonial = () => setTestimonialIndex((prev) => (prev +1)%successPreview.length)
```

But successPreview used for hero? same as testimonials. We'll rename to `testimonials`. Provide preview to success page.

Need to ensure no naming conflict.

Add `Link` to success page.

Also `CTA` section near bottom with button.

Add `Process` section.

Add `Blog` section.

Add `Team` preview.

Add `Stats` integrated maybe.

Ok.

Let's craft code.

Need to ensure CSS class names exist.

Now produce `Home.js`.

Need to reference CSS classes; we must design `Home.module.css`.

Let's craft component carefully.

Also ensure data arrays.

Let's craft.

 (Take time to ensure there are no syntax errors.)

Pseudo code snippet:

```
const testimonials = [
 { name:'Олена та Макс', ... }
...
];

const teamMembers = [...] // 3.

const projects = [
 { id:1, title:'...', description:'...', image:'https://picsum.photos/1200/800?random=61', category:'Варшава' },
 { id:2, ... category:'Краків' },
 { id:3 } maybe? we can add third to have glimpsed.

```

Also contact form: validation for name, email simple regex, message length.

Set `formStatus` to success message.

Add `button type=submit`.

Add `aria-live` region for success.

Add `faq` list.

Now we must create CSS module to style.

Important to ensure `header` sticky? Already in header.

Now we need to ensure `Home.module.css` includes classes:

- hero, heroContent, heroTitle, heroSubtitle, heroActions etc.

Shots.

Let's craft final CSS carefully.

Also we must ensure class names used matches.

Let's plan sections:

1. `hero` with background image. Provide `::after` overlay.

2. `heroContent` set to align center.

3. `stats` to show counters.

But we already have `counters` for "Чому ми".

Maybe we do `section` for `trusted` etc.

Let's design: maybe structure:

```
<section className={styles.hero}>...</section>
<section className={styles.philosophy}>...</section>
<section className={styles.services}>...</section>
<section className={styles.statsSection}>...</section> // "Чому ми?" with counters.
<section className={styles.processSection}>...</section>
<section className={styles.geography}>...</section>
<section className={styles.testimonials}>...</section>
<section className={styles.team}>...</section>
<section className={styles.projects}>...</section>
<section className={styles.blog}>...</section>
<section className={styles.contactSection}>...</section>
<section className={styles.faqSection}>...</section>
<section className={styles.ctaSection}>...</section>
```

Need to ensure the instructions first 8 blocks exist: we have hero, philosophy, services, "Чому ми?" (stats), geography, testimonials, contact, FAQ. Additional sections (process, team, projects, blog, CTA) inserted but maintain interplay. That's acceptable.

Also we must ensure `Hero` button uses `Link` to contact.

Add `aria` to process list etc.

Now we must craft CSS.

`Home.module.css` will be large. We'll include CSS variables usage. We'll ensure mobile first.

Also this is big.

But we must ensure we don't forget to import `styles`.

While building, ensure we didn't forget to add hooking.

Let's craft final `Home.js`.

**Important**: For teamMembers we earlier had incorrect image url. fix.

Let's craft final code:

```
const teamMembers = [
 { name: 'Ірина...', role: '...', bio: '...', image: 'https://picsum.photos/400/400?random=51' },
 { name: 'Пшемек...', image: 'https://picsum.photos/400/400?random=52' },
 { name: 'Анастасія...', image: 'https://picsum.photos/400/400?random=53' },
];
```

Projects 3 maybe.

`const projects = [ {category:'Варшава'}, {category:'Краків'}, {category:'Варшава'} ]`.

`projectFilters` for categories.

Testimonials array.

Remember to set alt text.

Now contact form: use states.

Let's craft.

Will also need to show `Link` to `services` page etc.

Now we need to create CSS modules for other pages: `About.module.css`, `Services.module.css`, `SuccessStories.module.css`, `Contact.module.css`, `Terms.module.css`, `Privacy.module.css`, `CookiePolicy.module.css`.

Should ensure each page uses `MetaTags`.

`About`: include sections, timeline, mission etc.

`Services`: create interactive cards maybe toggled? We can create `selectedService` state for details. We'll use `useState`. Provide `Button`.

`SuccessStories`: list of case studies with details. Provide "Варшава" etc.

`Contact`: include full contact info, map embed? We can include static image? We can include `iframe`? For compliance low. Provide contact form with validation? Already home has form but we can replicate more detail.

`Terms`, `Privacy`, `CookiePolicy` simple text.

Need to ensure all pages in Ukrainian.

Also we must ensure we import `Link` from `react-router-dom` as needed.

Now we also need to import `MetaTags` into each page.

### global.css

Need to set root variables, base styles for body, main etc.

Define:

```
:root {
 --primary-color: #2E8B57 etc.
}
```

Set `body` font.

Set `img` display.

Set `.main-content` maybe.

Set `section` margin.

Set default.

Also add general transitions, etc.

### Other CSS modules.

Need to ensure we highlight consistent design.

**Important**: Many classes to create. We'll craft them carefully.

Let's begin customizing.

#### global.css

Define CSS variables, base.

Also set `* { box-sizing: border-box; }`.

Set `body`.

Set `.app-container`.

Set `main`.

Set `a`.

Set `button`.

Set `.sectionTitle` maybe? We can define general classes used across modules to keep consistent but we need to ensure we use them. If we define common class names we not import? In CSS modules we can't share. So we can create global classes for repeated. In CSS modules we can still use global class names by referencing via `className="section-title"` but we prefer to keep dividing. maybe we can define global classes such as `.container`. But we can also define inside modules.

Focus.

Now produce actual files.

Let's craft code pieces systematically.

----

### Compose `Home.js` final.

Let's write new.

Need to ensure there is no syntax error, e.g., restful. I must type carefully.

Start writing final code.

Note: In `teamMembers` we use `'` in text? We'll use `'` but might include `'` in string; but we should use `'` for quoting but internal `'` maybe need to escape.

Let's craft.

We also need to ensure dataset for testimonials (makes sense). Already yes.

Let's produce final.

(Remember to import `classNames`? not allowed. We'll just use template strings.

Also `useEffect` for counters obtains values.

Let's craft.

### Additional utility for contact form: simple regex.

`const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;`

Set `formErrors` object.

`setFormErrors(errors); if (Object.keys(errors).length ===0) { setFormStatus('...'); setFormDataReset; } else setFormStatus('');`

Ok.

Also define `projectFilters` constant.

Ok.

Also mania for `Link` to other pages.

Now lighten.

Let's craft.

(While writing we must ensure we imported CSS module `styles`. For class names that need to combine we use `styles.className`.

For some global anchor we can use `'${styles.button} ${styles.primaryButton}'` etc.

Need to define these classes in CSS.

Better to plan names:

Hero section classes:

- hero
- heroContent
- heroTag
- heroTitle
- heroSubtitle
- heroCTA
- primaryButton (for CTA).
- secondaryButton.

Philosophy:

- section
- container etc.

Maybe we can define general `.section` class but not interplay.

Better to create unique.

Maybe create `styles.sectionHeading`, `styles.sectionSubheading`.

Ok.

Now lighten.

Let's craft code.

(This is big but necessary.)

Write final `Home.js`.

Need to ensure no typos.

Let's type.

(chars)...

Note: Use `styles.section` etc.

Let's craft.

(We'll produce final code now).