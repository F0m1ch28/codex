/* global ReactHelmet */
import { useEffect } from 'react';

const Meta = ({ title, description }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }

    if (description) {
      let metaDescription = document.querySelector('meta[name="description"]');
      if (!metaDescription) {
        metaDescription = document.createElement('meta');
        metaDescription.setAttribute('name', 'description');
        document.head.appendChild(metaDescription);
      }
      metaDescription.setAttribute('content', description);
    }
  }, [title, description]);

  if (
    typeof window !== 'undefined' &&
    window.ReactHelmet &&
    window.ReactHelmet.Helmet
  ) {
    const Helmet = window.ReactHelmet.Helmet;
    return (
      <Helmet>
        {title && <title>{title}</title>}
        {description && (
          <meta name="description" content={description || ''} />
        )}
      </Helmet>
    );
  }

  return null;
};

export default Meta;