import Meta from '../components/Meta';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Ірина Ковалюк',
    role: 'Головний кінолог, засновниця',
    experience: '15 років із службовими породами, сертифікація FCI, IPO.',
    quote:
      'Немає універсальних схем. Ми вивчаємо собаку, її сім’ю та середовище, а потім створюємо маршрут, який працює в реальному житті.',
    image: 'https://picsum.photos/400/400?random=3',
  },
  {
    name: 'Артем Лісницький',
    role: 'Спеціаліст з ОКД та службової підготовки',
    experience:
      'Підготував понад 40 вівчарок для охорони об’єктів та пошукових задач.',
    quote:
      'Починаємо з дисципліни та мотивації, щоб далі собака була готова до будь-яких сценаріїв — від охорони до пошуку.',
    image: 'https://picsum.photos/400/400?random=13',
  },
  {
    name: 'Марта Дзюба',
    role: 'Експерт з поведінкової корекції',
    experience: 'Працює з реактивними та травмованими собаками понад 8 років.',
    quote:
      'Кожна зміна поведінки — це результат стабільної комунікації та довіри між собакою й людиною.',
    image: 'https://picsum.photos/400/400?random=23',
  },
];

const milestones = [
  {
    year: '2013',
    title: 'Запуск авторської програми',
    description:
      'Створили перший курс для молодих вівчарок, що комбінував ОКД та основи захисту.',
  },
  {
    year: '2016',
    title: 'Партнерство з бізнес-центрами Варшави',
    description:
      'Розробили протоколи охоронної підготовки K9, провели атестації для приватних команд.',
  },
  {
    year: '2019',
    title: 'Розширення у Кракові',
    description:
      'Запустили виїзні програми та консультації у старому місті й нових житлових комплексах.',
  },
  {
    year: '2023',
    title: 'Повна екосистема навчання',
    description:
      'Запровадили супровід після курсу: менторинг, повторні тестування, план підтримки.',
  },
];

const pillars = [
  {
    title: 'Робота з емоціями',
    description:
      'Розуміємо сигнали напруги та збудження, допомагаємо собаці навчатися у контрольованому стані.',
  },
  {
    title: 'Системність',
    description:
      'Кожне заняття має чітку мету, а власник отримує конкретні домашні завдання та відео-розбір.',
  },
  {
    title: 'Командна робота',
    description:
      'Ви не залишаєтеся сам-на-сам: кінолог супроводжує, відповідає на запитання та коригує план.',
  },
];

const AboutPage = () => {
  return (
    <>
      <Meta
        title="Про нас | Професійне дресерування собак"
        description="Команда сертифікованих кінологів із Варшави та Кракова. Понад десятирічний досвід роботи з німецькими вівчарками: ОКД, службова підготовка, корекція."
      />

      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <h1>Команда, що живе роботою з вівчарками</h1>
            <p>
              Ми об’єднали фахівців з ОКД, службової підготовки, ресоціалізації
              та ветеринарної поведінки. З нами ви маєте стратегічний план
              розвитку собаки та підтримку на кожному етапі.
            </p>
          </div>
          <div className={styles.heroImage}>
            <img
              src="https://picsum.photos/1200/800?random=5"
              alt="Команда кінологів під час занять з собакою"
            />
          </div>
        </div>
      </section>

      <section className={styles.pillars}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Принципи, які визначають наш стиль</h2>
            <p>
              Ми не обмежуємося командою «сидіти». Важливо створити глибокий
              контакт між собакою та власником, щоб кожне наступне завдання
              виконувалося з довірою та енергією.
            </p>
          </header>
          <div className={styles.pillarsGrid}>
            {pillars.map((pillar) => (
              <article key={pillar.title} className={styles.pillarCard}>
                <h3>{pillar.title}</h3>
                <p>{pillar.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.timelineSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Наш шлях</h2>
            <p>
              Від невеликої ініціативи у Варшаві до повноцінної програми, що
              охоплює обидва міста.
            </p>
          </header>
          <div className={styles.timeline}>
            {milestones.map((milestone) => (
              <article key={milestone.year} className={styles.timelineItem}>
                <span className={styles.timelineYear}>{milestone.year}</span>
                <h3>{milestone.title}</h3>
                <p>{milestone.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Команда кінологів</h2>
            <p>
              Кожен тренер спеціалізується на конкретному напрямі, але ми
              працюємо як єдине ціле, ділячись знаннями та рішеннями.
            </p>
          </header>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImage}>
                  <img src={member.image} alt={member.name} />
                  <div className={styles.teamOverlay}>
                    <p>{member.quote}</p>
                  </div>
                </div>
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.experience}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.supportSection}>
        <div className={`container ${styles.supportInner}`}>
          <div className={styles.supportContent}>
            <h2>Партнерство з ветеринарними та кінологічними центрами</h2>
            <p>
              Співпрацюємо з ветеринарними клініками, поведінковими спеціалістами
              та майданчиками для тренувань. Це дозволяє оперативно вирішувати
              медичні питання та підбирати оптимальні локації для занять.
            </p>
            <ul className={styles.supportList}>
              <li>Вет-контроль та консультації по здоров’ю</li>
              <li>Оренда закритих майданчиків у Варшаві та Кракові</li>
              <li>Партнерські кінологічні центри для іспитів та атестацій</li>
            </ul>
          </div>
          <div className={styles.supportImage}>
            <img
              src="https://picsum.photos/1200/800?random=15"
              alt="Тренування собаки на спеціальному майданчику"
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;