import Meta from '../components/Meta';
import styles from './Legal.module.css';

const PrivacyPage = () => (
  <>
    <Meta
      title="Політика конфіденційності | Професійне дресерування собак"
      description="Дізнайтеся, як ми обробляємо та захищаємо персональні дані клієнтів."
    />
    <section className={styles.legalSection}>
      <div className="container">
        <h1>Політика конфіденційності</h1>
        <p className={styles.lead}>
          Ми поважаємо вашу приватність і дотримуємось вимог законодавства
          Польщі та ЄС щодо захисту персональних даних.
        </p>

        <article className={styles.legalCard}>
          <h2>1. Які дані ми збираємо</h2>
          <ul>
            <li>Ім’я, прізвище, контактний телефон та email;</li>
            <li>інформацію про собаку для формування пропозиції;</li>
            <li>
              технічні дані (IP-адреса, cookies) для аналітики відвідувань
              сайту.
            </li>
          </ul>
        </article>

        <article className={styles.legalCard}>
          <h2>2. Як ми використовуємо дані</h2>
          <ul>
            <li>для відповіді на ваш запит та організації тренувань;</li>
            <li>для надсилання важливих організаційних повідомлень;</li>
            <li>для поліпшення роботи сайту (анонімна аналітика).</li>
          </ul>
        </article>

        <article className={styles.legalCard}>
          <h2>3. Зберігання та захист</h2>
          <p>
            Дані зберігаються на захищених серверах. Доступ мають лише
            уповноважені співробітники, які відповідають за роботу з клієнтами.
          </p>
        </article>

        <article className={styles.legalCard}>
          <h2>4. Ваші права</h2>
          <p>
            Ви маєте право на доступ до своїх даних, їх виправлення або
            видалення. Запит надсилайте на електронну адресу
            trainer@dog-training.pl.
          </p>
        </article>
      </div>
    </section>
  </>
);

export default PrivacyPage;