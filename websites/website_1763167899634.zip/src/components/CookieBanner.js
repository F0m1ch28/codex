import React from 'react';
import styles from './CookieBanner.module.css';

const defaultPreferences = {
  necessary: true,
  analytics: false,
  functional: false,
};

const COOKIE_STORAGE_KEY = 'techsolutions-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);
  const [preferences, setPreferences] = React.useState(defaultPreferences);
  const [showSettings, setShowSettings] = React.useState(false);

  React.useEffect(() => {
    if (typeof window === 'undefined') return;

    const stored = window.localStorage.getItem(COOKIE_STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setPreferences({ ...defaultPreferences, ...parsed.preferences });
        if (parsed.consentGiven) {
          setVisible(false);
          return;
        }
      } catch (error) {
        console.error('Failed to parse cookie preferences', error);
      }
    }
    setVisible(true);
  }, []);

  const savePreferences = (prefs, consentGiven = true) => {
    if (typeof window === 'undefined') return;

    const data = {
      preferences: prefs,
      consentGiven,
      timestamp: new Date().toISOString(),
    };
    window.localStorage.setItem(COOKIE_STORAGE_KEY, JSON.stringify(data));
    setPreferences(prefs);
  };

  const handleAcceptAll = () => {
    const updated = { ...preferences, analytics: true, functional: true };
    savePreferences(updated);
    setVisible(false);
  };

  const handleSave = () => {
    savePreferences(preferences);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.overlay} role="dialog" aria-label="Cookie consent banner">
      <div className={styles.banner}>
        <div className={styles.content}>
          <h3>Cookies on TechSolutions.com</h3>
          <p>
            We use cookies to improve your browsing experience, analyze site traffic, and support security. You may accept all cookies or manage your choices.
          </p>
        </div>

        {showSettings && (
          <div className={styles.preferences}>
            <div className={styles.preferenceItem}>
              <div>
                <span>Necessary Cookies</span>
                <p>Required for secure basic functionality. Always active.</p>
              </div>
              <label className={styles.switch}>
                <input type="checkbox" checked readOnly disabled />
                <span />
              </label>
            </div>
            <div className={styles.preferenceItem}>
              <div>
                <span>Analytics Cookies</span>
                <p>Help us understand site usage to enhance services.</p>
              </div>
              <label className={styles.switch}>
                <input
                  type="checkbox"
                  checked={preferences.analytics}
                  onChange={(e) =>
                    setPreferences((prev) => ({ ...prev, analytics: e.target.checked }))
                  }
                />
                <span />
              </label>
            </div>
            <div className={styles.preferenceItem}>
              <div>
                <span>Functional Cookies</span>
                <p>Enable enhanced features and personalized content.</p>
              </div>
              <label className={styles.switch}>
                <input
                  type="checkbox"
                  checked={preferences.functional}
                  onChange={(e) =>
                    setPreferences((prev) => ({ ...prev, functional: e.target.checked }))
                  }
                />
                <span />
              </label>
            </div>
          </div>
        )}

        <div className={styles.actions}>
          <button className="btn btn-primary" onClick={handleAcceptAll}>
            Accept all cookies
          </button>
          <button
            className="btn btn-outline"
            onClick={() => {
              if (showSettings) {
                handleSave();
              } else {
                setShowSettings(true);
              }
            }}
          >
            {showSettings ? 'Save preferences' : 'Manage preferences'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;