import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.grid}>
          <div>
            <div className={styles.brand}>
              <span className={styles.brandMark}>TS</span>
              <div>
                <h3>TechSolutions</h3>
                <p>Cloud expertise & digital transformation leadership.</p>
              </div>
            </div>
            <ul className={styles.contactList}>
              <li>
                <strong>Address:</strong> 123 Tech Avenue, Innovation District, San Francisco, CA 94105
              </li>
              <li>
                <strong>Phone:</strong> <a href="tel:+15551234567">+1 (555) 123-4567</a>
              </li>
              <li>
                <strong>Email:</strong> <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
              </li>
            </ul>
          </div>

          <div className={styles.linkSections}>
            <div>
              <h4>Explore</h4>
              <ul>
                <li>
                  <NavLink to="/services">Services</NavLink>
                </li>
                <li>
                  <NavLink to="/about">About</NavLink>
                </li>
                <li>
                  <NavLink to="/contact">Contact</NavLink>
                </li>
              </ul>
            </div>
            <div>
              <h4>Compliance</h4>
              <ul>
                <li>
                  <NavLink to="/privacy">Privacy Notice</NavLink>
                </li>
                <li>
                  <NavLink to="/cookie-policy">Cookie Policy</NavLink>
                </li>
                <li>
                  <NavLink to="/terms">Terms of Use</NavLink>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className={styles.bottomBar}>
          <span>© {year} TechSolutions. All rights reserved.</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;