import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const values = [
  {
    title: 'Client-first partnership',
    description:
      'We anchor every engagement in transparent collaboration, aligning delivery roadmaps with strategic business objectives.',
  },
  {
    title: 'Operational excellence',
    description:
      'Disciplined execution, measurable outcomes, and governance enablement ensure transformations deliver sustained value.',
  },
  {
    title: 'Continuous innovation',
    description:
      'Curated accelerators, reference architectures, and leading practices keep teams ahead of evolving technology landscapes.',
  },
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>About TechSolutions</title>
        <meta
          name="description"
          content="Learn about TechSolutions—an IT consulting firm specializing in cloud solutions and digital transformation."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <h1>Empowering enterprises through purposeful technology change.</h1>
              <p>
                TechSolutions was founded to help leaders establish cloud foundations, modernize
                operations, and foster adaptive digital cultures. We combine strategy, architecture,
                and delivery excellence to create value that endures.
              </p>
            </div>
            <div className={styles.heroStats}>
              <div>
                <span>70+</span>
                <p>cloud & transformation specialists.</p>
              </div>
              <div>
                <span>15</span>
                <p>average years of senior leadership experience.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-header">
            <div className="tag">Core values</div>
            <h2>The principles guiding every engagement</h2>
          </div>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <div key={value.title} className={`${styles.valueCard} card`}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.story} section`}>
        <div className="container">
          <div className={styles.storyGrid}>
            <img
              src="https://picsum.photos/seed/techsolutions-team/840/540"
              alt="TechSolutions consultants collaborating in a modern workspace"
              loading="lazy"
            />
            <div>
              <div className="tag">Our story</div>
              <h2>From cloud pioneers to trusted advisors.</h2>
              <p>
                Our leadership team has steered large-scale modernization programs across global
                enterprises. We bring practitioner experience in architecture, engineering,
                operations, and change management to every client partnership.
              </p>
              <p>
                With headquarters in San Francisco’s Innovation District, we cultivate a culture of
                curiosity, professionalism, and accountability. Clients appreciate our ability to
                translate complex technology decisions into actionable strategies supported by
                disciplined delivery.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;