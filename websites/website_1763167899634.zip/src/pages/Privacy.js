import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Notice | TechSolutions</title>
        <meta
          name="description"
          content="Review how TechSolutions collects, uses, and safeguards personal information in accordance with privacy regulations."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Privacy Notice</h1>
          <p>Effective date: January 1, 2024</p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <article className={styles.article}>
            <h2>1. Introduction</h2>
            <p>
              TechSolutions, LLC (“TechSolutions,” “we,” “us,” or “our”) respects your privacy. This
              Privacy Notice explains how we collect, use, disclose, and safeguard personal
              information obtained through our website and related services.
            </p>

            <h2>2. Information We Collect</h2>
            <p>
              We may collect personal information that you voluntarily provide, such as name, email
              address, company details, role, and message content when you complete contact forms or
              request information. We may also collect usage data, including anonymized analytics,
              browser types, and device identifiers to improve site performance.
            </p>

            <h2>3. How We Use Information</h2>
            <p>We use personal information for the following purposes:</p>
            <ul className={styles.list}>
              <li>Responding to inquiries and providing requested information or services.</li>
              <li>Managing business development, client relationships, and service delivery.</li>
              <li>Improving Site functionality, user experience, and analytics insights.</li>
              <li>Complying with legal obligations, policies, and contractual commitments.</li>
            </ul>

            <h2>4. Sharing of Information</h2>
            <p>
              We may share personal information with trusted service providers who support our
              operations, subject to confidentiality requirements. We may disclose information to
              comply with legal obligations, enforce agreements, or protect the rights and safety of
              TechSolutions, our clients, or others. We do not sell personal information.
            </p>

            <h2>5. Data Security</h2>
            <p>
              We implement technical and organizational safeguards to protect personal information
              against unauthorized access, disclosure, alteration, or destruction. Although we strive
              to protect information, no transmission or storage system is fully secure.
            </p>

            <h2>6. International Transfers</h2>
            <p>
              TechSolutions is headquartered in the United States. If you access the Site from
              outside the United States, you acknowledge that your information may be transferred to
              and processed in the United States where privacy laws may differ from those in your
              jurisdiction.
            </p>

            <h2>7. Data Retention</h2>
            <p>
              We retain personal information for as long as necessary to fulfill the purposes
              described in this Notice or as required by law. When information is no longer needed,
              we will securely delete or de-identify it.
            </p>

            <h2>8. Your Rights</h2>
            <p>
              Depending on applicable laws, you may have rights to access, correct, or delete
              personal information, object to processing, or request data portability. To exercise
              these rights, contact us at{' '}
              <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>. We may require
              verification of identity before responding.
            </p>

            <h2>9. Cookies and Tracking Technologies</h2>
            <p>
              We use cookies and similar technologies to remember preferences, analyze site traffic,
              and enhance usability. You may adjust cookie preferences through the cookie banner or
              your browser settings. Refer to our Cookie Policy for details.
            </p>

            <h2>10. Children’s Privacy</h2>
            <p>
              The Site is not directed to children under 16, and we do not knowingly collect personal
              information from children. If we become aware that a child has provided personal
              information, we will delete it.
            </p>

            <h2>11. Updates to this Notice</h2>
            <p>
              We may update this Privacy Notice periodically. The “Effective date” indicates the
              latest revision. Material changes will be communicated through the Site.
            </p>

            <h2>12. Contact Us</h2>
            <p>
              For privacy-related questions, contact TechSolutions at 123 Tech Avenue, Innovation
              District, San Francisco, CA 94105 or via{' '}
              <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Privacy;