import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const pillars = [
  {
    title: 'Cloud Strategy & Governance',
    summary:
      'Define long-term vision, operating models, and governance frameworks aligned to regulatory requirements and risk appetite.',
    bullets: [
      'Cloud readiness assessments and total cost of ownership analysis.',
      'Target operating model definition with stakeholder alignment.',
      'Governance guardrails covering security, compliance, and lifecycle management.',
    ],
  },
  {
    title: 'Migration & Modernization',
    summary:
      'Execute multi-wave migration programs and modernization patterns supported by automation and DevSecOps practices.',
    bullets: [
      'Portfolio prioritization, business case validation, and roadmap development.',
      'Landing zone design, automation pipelines, and migration execution.',
      'Application refactoring, containerization, and microservices enablement.',
    ],
  },
  {
    title: 'Data & Intelligent Platforms',
    summary:
      'Unlock data-driven decision making through cloud-native data architectures, analytics platforms, and AI enablement.',
    bullets: [
      'Enterprise data strategy and platform architecture.',
      'Data governance, quality assurance, and catalog initiatives.',
      'Operational analytics, BI modernization, and applied AI services.',
    ],
  },
  {
    title: 'Digital Transformation Advisory',
    summary:
      'Translate modernization into organizational change, digital process reengineering, and experience innovation.',
    bullets: [
      'Business process optimization and workflow digitization.',
      'Experience design across customer and employee journeys.',
      'Change management, capability uplift, and operating metrics.',
    ],
  },
];

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Services | TechSolutions</title>
        <meta
          name="description"
          content="Explore TechSolutions services spanning cloud strategy, migration, modernization, data platforms, and digital transformation advisory."
        />
      </Helmet>

      <header className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Services engineered for confident transformation.</h1>
            <p>
              TechSolutions orchestrates the intersection of cloud technology, process evolution,
              and organizational enablement to deliver measurable outcomes and operating resilience.
            </p>
          </div>
        </div>
      </header>

      <section className="section">
        <div className="container">
          <div className={styles.grid}>
            {pillars.map((pillar) => (
              <article key={pillar.title} className={`${styles.card} card`}>
                <h2>{pillar.title}</h2>
                <p>{pillar.summary}</p>
                <ul className="list">
                  {pillar.bullets.map((bullet) => (
                    <li key={bullet}>{bullet}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.engage} section`}>
        <div className="container">
          <div className={styles.engageCard}>
            <div>
              <h2>Engagement options aligned to your journey.</h2>
              <p>
                Whether launching a strategic assessment, operationalizing migration waves, or
                optimizing cloud-native teams, we tailor engagement models to your roadmap and
                delivery cadence.
              </p>
            </div>
            <ul className="list">
              <li>Executive advisory sprints and strategy workshops.</li>
              <li>Embedded transformation offices and cloud program management.</li>
              <li>Outcome-based delivery with measurable performance indicators.</li>
            </ul>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;