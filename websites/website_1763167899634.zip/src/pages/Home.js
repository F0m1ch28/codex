import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const services = [
  {
    title: 'Cloud Strategy & Architecture',
    description:
      'Tailored cloud blueprints that align technology capabilities with business objectives, ensuring scalable and secure platforms.',
    icon: 'cloud',
  },
  {
    title: 'Migration & Modernization',
    description:
      'End-to-end migration programs with governance, automation, and change enablement to unlock resilient digital operations.',
    icon: 'migration',
  },
  {
    title: 'Digital Transformation Advisory',
    description:
      'Cross-functional advisory services that streamline processes, elevate customer experience, and drive data-informed decisions.',
    icon: 'transformation',
  },
];

const differentiators = [
  'Certified multi-cloud architects with enterprise delivery expertise.',
  'Proven methodologies covering discovery, roadmap, implementation, and optimization.',
  'Embedded governance ensuring compliance, security, and performance across every workstream.',
];

const Home = () => {
  return (
    <>
      <Helmet>
        <title>TechSolutions | Cloud Solutions & Digital Transformation</title>
        <meta
          name="description"
          content="TechSolutions delivers strategic cloud consulting, digital transformation, and IT advisory services for organizations modernizing their operations."
        />
        <meta
          name="keywords"
          content="cloud solutions, digital transformation, IT consulting, business optimization, cloud migration"
        />
      </Helmet>

      <section className={`${styles.hero}`}>
        <div className="container">
          <div className={styles.heroContent}>
            <div className={styles.heroText}>
              <div className="tag">Cloud strategy. Confident transformation.</div>
              <h1>Accelerate transformation with resilient cloud foundations.</h1>
              <p>
                TechSolutions partners with executives and engineering leaders to design, migrate,
                and optimize cloud ecosystems that underpin high-performing digital businesses.
              </p>
              <div className={styles.ctaGroup}>
                <Link to="/contact" className="btn btn-primary">
                  Start a conversation
                </Link>
                <Link to="/services" className="btn btn-outline">
                  View our services
                </Link>
              </div>
            </div>
            <div className={styles.heroVisual}>
              <img
                src="https://picsum.photos/seed/techsolutions-cloud/720/520"
                alt="Modern cloud infrastructure visualization"
                loading="lazy"
              />
              <div className={styles.metricCard}>
                <span>98%</span>
                <p>client satisfaction across transformation programs.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-header">
            <div className="tag">Service pillars</div>
            <h2>Cloud-first capabilities engineered for business impact</h2>
            <p>
              Strategic consulting, technical execution, and enablement programs tailored to your
              modernization roadmap.
            </p>
          </div>
          <div className={`${styles.serviceGrid}`}>
            {services.map((service) => (
              <div key={service.title} className={`${styles.serviceCard} card`}>
                <span className={`${styles.icon} ${styles[service.icon]}`} aria-hidden="true" />
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className={styles.link}>
                  Discover more
                  <svg
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    aria-hidden="true"
                  >
                    <path
                      d="M8 5l8 7-8 7"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.aboutSection} section`}>
        <div className="container">
          <div className={styles.aboutGrid}>
            <div className={styles.aboutImage}>
              <img
                src="https://picsum.photos/seed/digital-transformation/780/520"
                alt="Team collaborating on digital strategy roadmap"
                loading="lazy"
              />
              <div className={styles.badge}>
                <span>25+</span>
                <p>industry domains supported with cloud initiatives.</p>
              </div>
            </div>
            <div className={styles.aboutContent}>
              <div className="tag">Trusted advisory</div>
              <h2>From strategy to steady-state optimization.</h2>
              <p>
                We equip organizations with the frameworks, engineering accelerators, and change
                adoption needed to realize the value of cloud-native operating models. Our
                specialists align technology modernization with measurable business outcomes.
              </p>
              <ul className="list">
                {differentiators.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <Link to="/about" className="btn btn-outline">
                Learn about TechSolutions
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.processSection} section`}>
        <div className="container">
          <div className="section-header">
            <div className="tag">Engagement rhythm</div>
            <h2>A structured journey toward operational excellence</h2>
          </div>
          <div className={styles.processGrid}>
            <div className={styles.processCard}>
              <div className={styles.step}>1</div>
              <h3>Vision & Assessment</h3>
              <p>
                Align key stakeholders on objectives, operating constraints, and current-state
                capabilities through collaborative workshops.
              </p>
            </div>
            <div className={styles.processCard}>
              <div className={styles.step}>2</div>
              <h3>Roadmap & Design</h3>
              <p>
                Develop actionable roadmaps, reference architectures, and governance frameworks
                tailored to your regulatory and performance requirements.
              </p>
            </div>
            <div className={styles.processCard}>
              <div className={styles.step}>3</div>
              <h3>Implementation & Enablement</h3>
              <p>
                Execute migrations, platform modernization, and team enablement with continuous
                improvement and transparent delivery metrics.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.ctaSection}`}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Shape a resilient digital future.</h2>
              <p>
                Engage TechSolutions to define your cloud strategy, modernize applications, and
                institutionalize continuous innovation across the enterprise.
              </p>
            </div>
            <Link to="/contact" className="btn btn-primary">
              Schedule a consultation
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;