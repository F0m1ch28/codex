import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | TechSolutions</title>
        <meta
          name="description"
          content="Understand how TechSolutions uses cookies and similar technologies to support website functionality and analytics."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Cookie Policy</h1>
          <p>Effective date: January 1, 2024</p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <article className={styles.article}>
            <h2>1. Overview</h2>
            <p>
              This Cookie Policy explains how TechSolutions, LLC (“TechSolutions,” “we,” “us,” or
              “our”) uses cookies and similar tracking technologies when you visit our website
              (collectively, “cookies”). It complements our Privacy Notice.
            </p>

            <h2>2. What Are Cookies?</h2>
            <p>
              Cookies are small data files placed on your device when you visit a website. They are
              widely used to enable site functionality, remember user preferences, and gather
              analytics insights.
            </p>

            <h2>3. Types of Cookies We Use</h2>
            <ul className={styles.list}>
              <li>
                <strong>Strictly Necessary Cookies:</strong> Required for the Site to function
                correctly, including security and accessibility features. These cookies cannot be
                disabled.
              </li>
              <li>
                <strong>Analytics Cookies:</strong> Help us understand how visitors interact with the
                Site so we can improve performance and content relevance.
              </li>
              <li>
                <strong>Functional Cookies:</strong> Enhance user experience by remembering
                preferences and enabling personalized features.
              </li>
            </ul>

            <h2>4. Managing Cookie Preferences</h2>
            <p>
              When you first visit the Site, a cookie banner allows you to accept or manage
              non-essential cookies. You can modify your preferences at any time by adjusting your
              browser settings or clearing cookies. Disabling certain cookies may affect Site
              functionality.
            </p>

            <h2>5. Third-Party Cookies</h2>
            <p>
              Some cookies may be set by trusted third parties to provide analytics or functionality
              services. We review these providers to ensure they adhere to appropriate privacy and
              security standards.
            </p>

            <h2>6. Updates to this Policy</h2>
            <p>
              We may update this Cookie Policy to reflect changes in technology, legal
              requirements, or our practices. Updates will be posted on this page with a new
              effective date.
            </p>

            <h2>7. Contact</h2>
            <p>
              If you have any questions regarding this Cookie Policy, contact TechSolutions at 123
              Tech Avenue, Innovation District, San Francisco, CA 94105 or via{' '}
              <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;