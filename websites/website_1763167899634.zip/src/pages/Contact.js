import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  company: '',
  message: '',
};

const Contact = () => {
  const [formData, setFormData] = React.useState(initialFormState);
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Please enter your full name.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please provide a valid email address.';
    }
    if (!formData.company.trim()) {
      newErrors.company = 'Please specify your organization.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Please include a brief summary of your objectives.';
    }
    return newErrors;
  };

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setErrors((prev) => ({ ...prev, [e.target.name]: '' }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmitted(false);
      return;
    }

    setSubmitted(true);
    setFormData(initialFormState);
  };

  return (
    <>
      <Helmet>
        <title>Contact TechSolutions</title>
        <meta
          name="description"
          content="Contact TechSolutions for cloud consulting, digital transformation support, and IT advisory services."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Contact TechSolutions</h1>
          <p>
            Share your objectives and our consultants will coordinate a focused conversation to
            explore how we can advance your cloud and digital transformation agenda.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.formWrapper}>
              <h2>Send us a message</h2>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <div className={styles.field}>
                  <label htmlFor="name">Full name</label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'name-error' : undefined}
                  />
                  {errors.name && <span id="name-error">{errors.name}</span>}
                </div>

                <div className={styles.field}>
                  <label htmlFor="email">Email</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'email-error' : undefined}
                  />
                  {errors.email && <span id="email-error">{errors.email}</span>}
                </div>

                <div className={styles.field}>
                  <label htmlFor="company">Company</label>
                  <input
                    type="text"
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.company)}
                    aria-describedby={errors.company ? 'company-error' : undefined}
                  />
                  {errors.company && <span id="company-error">{errors.company}</span>}
                </div>

                <div className={styles.field}>
                  <label htmlFor="message">How can we help?</label>
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    value={formData.message}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'message-error' : undefined}
                  />
                  {errors.message && <span id="message-error">{errors.message}</span>}
                </div>

                <button type="submit" className="btn btn-primary">
                  Submit inquiry
                </button>

                {submitted && (
                  <div className={styles.success}>
                    Thank you for reaching out. Our team will connect with you shortly.
                  </div>
                )}
              </form>
            </div>

            <aside className={styles.contactInfo}>
              <div className="tag">Contact details</div>
              <h2>We are here to support your next step.</h2>
              <ul className={styles.infoList}>
                <li>
                  <strong>Address</strong>
                  <span>123 Tech Avenue, Innovation District, San Francisco, CA 94105</span>
                </li>
                <li>
                  <strong>Phone</strong>
                  <a href="tel:+15551234567">+1 (555) 123-4567</a>
                </li>
                <li>
                  <strong>Email</strong>
                  <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
                </li>
              </ul>
              <div className={styles.map}>
                <img
                  src="https://picsum.photos/seed/sanfrancisco/680/420"
                  alt="San Francisco cityscape representing TechSolutions location"
                  loading="lazy"
                />
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;