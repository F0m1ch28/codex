import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Use | TechSolutions</title>
        <meta
          name="description"
          content="Review the Terms of Use governing access to and use of TechSolutions digital properties and services."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Terms of Use</h1>
          <p>Effective date: January 1, 2024</p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <article className={styles.article}>
            <h2>1. Agreement to Terms</h2>
            <p>
              These Terms of Use (“Terms”) constitute a legally binding agreement between you and
              TechSolutions, LLC (“TechSolutions,” “we,” “us,” or “our”) governing your access to
              and use of this website and any related content, functionality, and services (the
              “Site”). By accessing the Site, you acknowledge that you have read, understood, and
              agreed to be bound by these Terms. If you do not agree, you must discontinue use of
              the Site immediately.
            </p>

            <h2>2. Changes to Terms</h2>
            <p>
              We may update these Terms from time to time to reflect changes in our practices,
              technologies, legal requirements, or for other reasons. When updates occur, the
              revised Terms will be posted on this page with an updated effective date. Your
              continued use of the Site following the posting of revised Terms constitutes acceptance
              of the changes.
            </p>

            <h2>3. Use of the Site</h2>
            <p>
              You agree to use the Site only for lawful purposes and in accordance with these Terms.
              You must not use the Site in a manner that could disable, overburden, or impair the
              Site, interfere with others’ use, or introduce malicious code. Unauthorized attempts
              to access secure areas of the Site or TechSolutions systems are prohibited.
            </p>

            <h2>4. Intellectual Property</h2>
            <p>
              The Site and its entire contents, including text, graphics, logos, and software, are
              owned by TechSolutions or its licensors and are protected by intellectual property
              laws. You may not reproduce, distribute, modify, or create derivative works without
              prior written consent from TechSolutions. Limited copies may be downloaded for personal
              informational use provided that all proprietary notices are retained.
            </p>

            <h2>5. Third-Party Links</h2>
            <p>
              The Site may include links to third-party websites or resources for convenience. These
              links do not signify endorsement, and TechSolutions is not responsible for the content,
              policies, or practices of those third parties. Accessing third-party resources is at
              your own risk.
            </p>

            <h2>6. Disclaimers</h2>
            <p>
              The Site and its content are provided on an “as-is” and “as-available” basis without
              warranties of any kind, whether express or implied, including implied warranties of
              merchantability, fitness for a particular purpose, or non-infringement. TechSolutions
              does not guarantee that the Site will be uninterrupted, secure, or error-free, or that
              defects will be corrected.
            </p>

            <h2>7. Limitation of Liability</h2>
            <p>
              To the fullest extent permitted by law, TechSolutions shall not be liable for any
              indirect, incidental, consequential, special, or punitive damages arising out of or in
              connection with your use of the Site, even if advised of the possibility of such
              damages. Our total liability for any claim shall not exceed one hundred U.S. dollars
              (USD 100).
            </p>

            <h2>8. Indemnification</h2>
            <p>
              You agree to defend, indemnify, and hold harmless TechSolutions, its affiliates, and
              their respective officers, directors, employees, and agents from any claims, losses, or
              expenses resulting from your violation of these Terms or use of the Site.
            </p>

            <h2>9. Governing Law</h2>
            <p>
              These Terms are governed by the laws of the State of California, without regard to
              conflict-of-law principles. Any legal proceedings arising from these Terms shall be
              brought exclusively in the state or federal courts located in San Francisco County,
              California.
            </p>

            <h2>10. Contact</h2>
            <p>
              For questions about these Terms, contact TechSolutions at 123 Tech Avenue, Innovation
              District, San Francisco, CA 94105, or via email at{' '}
              <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Terms;