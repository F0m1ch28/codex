document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");
    const scrollBtn = document.querySelector(".scroll-to-top");
    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptCookiesBtn = document.getElementById("acceptCookies");
    const form = document.getElementById("contactForm");
    const feedback = document.querySelector(".form-feedback");
    const currentYearEl = document.getElementById("currentYear");

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    // Mobile navigation toggle
    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            navMenu.classList.toggle("open");
        });

        navMenu.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navMenu.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    // Scroll to top button
    const toggleScrollButton = () => {
        if (window.scrollY > 240) {
            scrollBtn.classList.add("show");
        } else {
            scrollBtn.classList.remove("show");
        }
    };

    if (scrollBtn) {
        scrollBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
        toggleScrollButton();
        window.addEventListener("scroll", toggleScrollButton);
    }

    // Cookie banner
    const cookieConsentKey = "cdiCookiesAccepted";
    if (cookieBanner) {
        const accepted = localStorage.getItem(cookieConsentKey);
        if (!accepted) {
            cookieBanner.style.display = "block";
        }

        if (acceptCookiesBtn) {
            acceptCookiesBtn.addEventListener("click", () => {
                localStorage.setItem(cookieConsentKey, "true");
                cookieBanner.style.display = "none";
            });
        }
    }

    // Contact form handling
    if (form && feedback) {
        form.addEventListener("submit", event => {
            event.preventDefault();

            if (!form.checkValidity()) {
                feedback.textContent = "Please complete all required fields.";
                feedback.style.color = "#c43b3b";
                return;
            }

            feedback.textContent = "Thank you. Our engagement team will contact you shortly.";
            feedback.style.color = "#1c7f4d";
            form.reset();
        });
    }
});