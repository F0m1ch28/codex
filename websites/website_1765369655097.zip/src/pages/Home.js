import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import useDocumentMeta from '../hooks/useDocumentMeta';
import styles from './Home.module.css';

const statsData = [
  { id: 1, label: 'Реализованных стратегий', value: 128 },
  { id: 2, label: 'Цифровых внедрений', value: 76 },
  { id: 3, label: 'Партнёров в экосистеме', value: 54 }
];

const keyAreas = [
  {
    title: 'Стратегическая аналитика',
    description: 'Глубокая аналитика данных и сценарное моделирование для уверенных управленческих решений.',
    icon: 'https://img.icons8.com/color/96/business-report.png',
    alt: 'Иконка аналитического отчёта'
  },
  {
    title: 'Технологический консалтинг',
    description: 'Подбираем технологии, которые поддерживают рост, а не усложняют процессы.',
    icon: 'https://img.icons8.com/color/96/artificial-intelligence.png',
    alt: 'Иконка искусственного интеллекта'
  },
  {
    title: 'Производственная цифровизация',
    description: 'Оцифровываем основные процессы, формируем единый контур управления операциями.',
    icon: 'https://img.icons8.com/color/96/automation.png',
    alt: 'Иконка автоматизации'
  },
  {
    title: 'Экосистемы и партнёрства',
    description: 'Создаём устойчивые союзы между бизнесом, технологиями и людьми.',
    icon: 'https://img.icons8.com/color/96/collaboration.png',
    alt: 'Иконка сотрудничества'
  }
];

const advantages = [
  'Авторские методики работы с неопределённостью и сложными данными.',
  'Команда практиков с опытом внедрения трансформации в разных отраслях.',
  'Прозрачные коммуникации и совместная работа с командами клиентов.',
  'Технологическая независимость и ориентация на бизнес-результат.',
  'Поддержка и развитие решений после завершения проекта.'
];

const processSteps = [
  {
    title: 'Диагностика и гипотезы',
    description: 'Совместная оценка текущей ситуации, ключевых ограничений и зон роста.'
  },
  {
    title: 'Визуализация будущего',
    description: 'Проработка целевой модели процессов, архитектуры данных и ключевых инициатив.'
  },
  {
    title: 'Создание прототипа',
    description: 'Быстрая проверка гипотез, подготовка дорожной карты и управленческих KPI.'
  },
  {
    title: 'Внедрение и сопровождение',
    description: 'Экспертная поддержка, обучение команд и непрерывная оптимизация решений.'
  }
];

const testimonials = [
  {
    name: 'Алина Королёва',
    role: 'Директор по развитию, НордЭнерго',
    quote:
      'Команда Лабмьсдсост ось б помогла сформировать стратегию цифровой модернизации. Получили не только отчёт, но и реальные изменения в производстве.',
    avatar: 'https://picsum.photos/200/200?random=11'
  },
  {
    name: 'Максим Власов',
    role: 'CEO, Finbasis',
    quote:
      'Эти специалисты умеют объяснять сложное простым языком и доводить проекты до результата. Поддержка продолжается даже после запуска.',
    avatar: 'https://picsum.photos/200/200?random=12'
  },
  {
    name: 'София Лебедева',
    role: 'Head of Operations, AgroLine',
    quote:
      'Мы увидели эффект уже на пилотном проекте: прозрачность данных выросла, а цикл принятия решений сократился вдвое.',
    avatar: 'https://picsum.photos/200/200?random=13'
  }
];

const teamMembers = [
  {
    name: 'Игорь Мальцев',
    role: 'Партнёр по стратегиям',
    description: '15 лет в стратегическом консалтинге, специализация — промышленность и энергетика.',
    photo: 'https://picsum.photos/400/400?random=21'
  },
  {
    name: 'Кира Смирнова',
    role: 'Директор по продуктам',
    description: 'Выстраивает продуктовое мышление и customer journey на всех этапах трансформации.',
    photo: 'https://picsum.photos/400/400?random=22'
  },
  {
    name: 'Павел Котов',
    role: 'Руководитель Data Office',
    description: 'Эксперт в архитектуре данных и машинном обучении, автор курсов по data culture.',
    photo: 'https://picsum.photos/400/400?random=23'
  },
  {
    name: 'Марина Белова',
    role: 'Партнёр по изменениям',
    description: 'Помогает командам адаптироваться к новым процессам, выстраивает управление изменениями.',
    photo: 'https://picsum.photos/400/400?random=24'
  }
];

const faqItems = [
  {
    question: 'С чего начинается сотрудничество?',
    answer:
      'Мы проводим экспресс-диагностику и определяем зоны эффекта. После согласования гипотез формируем дорожную карту и рабочую группу.'
  },
  {
    question: 'Работаете ли вы с существующими ИТ-подрядчиками клиента?',
    answer:
      'Да. Мы подключаемся как надёжный партнёр, синхронизируем работу поставщиков и помогаем донести ценность изменений до внутренних команд.'
  },
  {
    question: 'Можно ли запустить пилот перед масштабированием?',
    answer:
      'Всегда рекомендуем тестировать гипотезы на пилоте. Это помогает быстро получить обратную связь и уточнить экономику проекта.'
  },
  {
    question: 'Предоставляете ли вы обучение и поддержку?',
    answer:
      'Мы сопровождаем команду клиента на всех этапах, делимся материалами и проводим практические сессии для устойчивого результата.'
  }
];

const blogPosts = [
  {
    title: 'Как выстроить архитектуру данных без «технического долга»',
    date: '12 марта 2024',
    summary:
      'Рассматриваем подход к проектированию архитектуры данных, который позволяет быстро масштабировать решения и не терять управляемость.',
    image: 'https://picsum.photos/800/600?random=31',
    link: '/o-kompanii'
  },
  {
    title: 'Четыре шага к операционной устойчивости',
    date: '26 февраля 2024',
    summary:
      'Делимся опытом, как интегрировать аналитику, процессы и команду в единую систему управления для промышленного холдинга.',
    image: 'https://picsum.photos/800/600?random=32',
    link: '/uslugi'
  },
  {
    title: 'Какие компетенции нужны для трансформации?',
    date: '5 февраля 2024',
    summary:
      'Обсуждаем роль лидеров изменений, data-евангелистов и продуктовых команд в успешной цифровизации.',
    image: 'https://picsum.photos/800/600?random=33',
    link: '/o-kompanii'
  }
];

const projectGallery = [
  {
    title: 'Переосмысление операционной модели',
    category: 'Стратегия',
    description: 'Создание целевой операционной модели и системы мониторинга KPI для промышленной группы.',
    image: 'https://picsum.photos/1200/800?random=41'
  },
  {
    title: 'Единая аналитическая платформа',
    category: 'Data & Analytics',
    description: 'Внедрение платформы управления данными и самообслуживания отчётности.',
    image: 'https://picsum.photos/1200/800?random=42'
  },
  {
    title: 'Цифровизация производственных участков',
    category: 'Разработка',
    description: 'Разработка и внедрение MES-решения с адаптацией под специфику предприятия.',
    image: 'https://picsum.photos/1200/800?random=43'
  },
  {
    title: 'Управление экосистемой партнёров',
    category: 'Стратегия',
    description: 'Организация цифрового взаимодействия с партнёрами и контроль экосистемных KPI.',
    image: 'https://picsum.photos/1200/800?random=44'
  }
];

const servicesHighlights = [
  {
    title: 'Дизайн цифровой стратегии',
    description:
      'Формируем стратегию трансформации, где технологии связаны с целями бизнеса, а KPI — с ценностью для клиента.',
    image: 'https://picsum.photos/600/400?random=51'
  },
  {
    title: 'Интеллектуальная аналитика',
    description:
      'Используем машинное обучение, data governance и визуализацию, чтобы управленческие решения были своевременными и точными.',
    image: 'https://picsum.photos/600/400?random=52'
  },
  {
    title: 'Инжиниринг и разработка',
    description:
      'Разрабатываем цифровые продукты с упором на устойчивость, интеграцию и человеческий опыт при работе с системами.',
    image: 'https://picsum.photos/600/400?random=53'
  }
];

const Home = () => {
  useDocumentMeta({
    title: 'Лабмьсдсост ось б | Инновационный консалтинг и технологии',
    description:
      'Лабмьсдсост ось б помогает компаниям создавать цифровые стратегии, внедрять технологии и управлять изменениями. Аналитика, архитектура данных, продуктовый подход и сопровождение.'
  });

  const [stats, setStats] = useState(statsData.map(() => 0));
  const [activeProjectFilter, setActiveProjectFilter] = useState('Все');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  useEffect(() => {
    const timers = statsData.map((item, index) => {
      const increment = Math.ceil(item.value / 60);
      return setInterval(() => {
        setStats((prev) => {
          const next = [...prev];
          next[index] = Math.min(item.value, next[index] + increment);
          return next;
        });
      }, 30);
    });

    return () => timers.forEach((timer) => clearInterval(timer));
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);

    return () => clearInterval(timer);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeProjectFilter === 'Все') return projectGallery;
    return projectGallery.filter((project) => project.category === activeProjectFilter);
  }, [activeProjectFilter]);

  return (
    <div className={styles.page}>
      <section className={styles.heroSection}>
        <div className={styles.heroBackground} role="presentation" />
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <span className={styles.heroBadge}>Цифровая трансформация без суеты</span>
            <h1>
              Лабмьсдсост ось б — проводник в сложных технологических изменениях
            </h1>
            <p>
              Мы помогаем бизнесу системно расти, анализируя данные, создавая продукты и выстраивая культуру изменений. Каждая инициатива связана с реальной ценностью и измеримым результатом.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className={styles.primaryButton}>
                Связаться с нами
              </Link>
              <Link to="/o-kompanii" className={styles.secondaryButton}>
                Узнать о подходе
              </Link>
            </div>
          </div>
          <div className={styles.heroVisual}>
            <img
              src="https://picsum.photos/800/600?random=101"
              alt="Команда консультантов обсуждает стратегию цифровой трансформации"
            />
            <div className={styles.heroCard}>
              <h3>Результат как система</h3>
              <p>Стратегия, технологии и люди работают синхронно, чтобы каждая инициатива приносила эффект.</p>
            </div>
          </div>
        </div>
        <div className={`container ${styles.statsWrapper}`}>
          {statsData.map((item, index) => (
            <div key={item.id} className={styles.statCard}>
              <span className={styles.statValue}>{stats[index]}+</span>
              <span className={styles.statLabel}>{item.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.aboutPreviewSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Миссия и ориентиры</h2>
            <p className="section-subtitle">
              Мы объединяем аналитическое мышление, технологическую смелость и устойчивые изменения, чтобы компании могли быстрее адаптироваться к рынку и ожиданиям клиентов.
            </p>
          </div>
          <div className={styles.aboutGrid}>
            <div className={styles.aboutText}>
              <p>
                Лабмьсдсост ось б создаёт экосистему консультантов, архитекторов и инженеров, которые вместе с командами клиента строят понятный путь трансформации. Мы внимательно слушаем, объясняем без сложных терминов и поддерживаем внедрение до стабильного результата.
              </p>
              <Link to="/o-kompanii" className={styles.linkArrow}>
                Читать подробнее об истории компании
              </Link>
            </div>
            <div className={styles.aboutImageWrapper}>
              <img
                src="https://picsum.photos/800/600?random=102"
                alt="Совместная работа команды над цифровой картой изменений"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.keyAreasSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Ключевые направления</h2>
            <p className="section-subtitle">
              В основе нашей работы — глубокое понимание отраслевой специфики и управление изменениями. Мы создаём пути, по которым можно идти без остановок.
            </p>
          </div>
          <div className={styles.keyAreasGrid}>
            {keyAreas.map((area) => (
              <article key={area.title} className={styles.keyAreaCard}>
                <div className={styles.keyAreaIcon}>
                  <img src={area.icon} alt={area.alt} />
                </div>
                <h3>{area.title}</h3>
                <p>{area.description}</p>
                <Link to="/uslugi" className={styles.linkArrow}>
                  Подробнее об экспертизе
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Что мы делаем иначе</h2>
            <p className="section-subtitle">
              Мы работаем как единая команда с клиентом: совместно формируем гипотезы, тестируем идеи и создаём решения, которые устойчиво работают в реальной среде.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesHighlights.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceImage}>
                  <img src={service.image} alt={service.title} />
                </div>
                <div className={styles.serviceContent}>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <Link to="/uslugi" className={styles.linkArrow}>
                    Все услуги
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.advantagesSection}>
        <div className={`container ${styles.advantagesWrapper}`}>
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Почему нам доверяют сложные задачи</h2>
          </div>
          <ul className={styles.advantagesList}>
            {advantages.map((advantage) => (
              <li key={advantage}>
                <span className={styles.checkmark}>✔</span>
                <p>{advantage}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Как мы работаем</h2>
            <p className="section-subtitle">
              Прозрачный процесс позволяет видеть прогресс и вовремя адаптировать маршрут. Мы создаём условия, в которых изменения приживаются.
            </p>
          </div>
          <div className={styles.processTimeline}>
            {processSteps.map((step, index) => (
              <div key={step.title} className={styles.processStep}>
                <div className={styles.stepNumber}>{index + 1}</div>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Проекты и результаты</h2>
            <p className="section-subtitle">
              Мы берёмся за задачи, которые требуют нестандартного подхода и сочетания стратегии, технологий и изменений.
            </p>
          </div>
          <div className={styles.projectFilters}>
            {['Все', 'Стратегия', 'Data & Analytics', 'Разработка'].map((filter) => (
              <button
                key={filter}
                type="button"
                className={`${styles.filterButton} ${activeProjectFilter === filter ? styles.filterButtonActive : ''}`}
                onClick={() => setActiveProjectFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img src={project.image} alt={project.title} />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Голоса клиентов</h2>
            <p className="section-subtitle">
              Совместная работа для нас — это доверие и партнёрство. Мы ценим, когда результат вдохновляет команды клиентов двигаться дальше.
            </p>
          </div>
          <div className={styles.testimonialSlider}>
            <button
              type="button"
              className={styles.sliderControl}
              aria-label="Предыдущий отзыв"
              onClick={() =>
                setCurrentTestimonial((prev) =>
                  prev === 0 ? testimonials.length - 1 : prev - 1
                )
              }
            >
              ←
            </button>
            <div className={styles.testimonialCard}>
              <img
                src={testimonials[currentTestimonial].avatar}
                alt={`Фото клиента ${testimonials[currentTestimonial].name}`}
              />
              <blockquote>
                <p>“{testimonials[currentTestimonial].quote}”</p>
              </blockquote>
              <div className={styles.testimonialAuthor}>
                <strong>{testimonials[currentTestimonial].name}</strong>
                <span>{testimonials[currentTestimonial].role}</span>
              </div>
            </div>
            <button
              type="button"
              className={styles.sliderControl}
              aria-label="Следующий отзыв"
              onClick={() =>
                setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
              }
            >
              →
            </button>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Команда, влюблённая в изменения</h2>
            <p className="section-subtitle">
              Каждый партнёр Лабмьсдсост ось б — это практик, который в курсе реальных вызовов бизнеса и умеет внедрять устойчивые решения.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamPhoto}>
                  <img src={member.photo} alt={member.name} />
                </div>
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Частые вопросы</h2>
            <p className="section-subtitle">
              Мы открыто обсуждаем все детали и делимся опытом, чтобы совместное путешествие было предсказуемым и безопасным.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Практические заметки</h2>
            <p className="section-subtitle">
              Мы делимся наблюдениями, кейсами и инструментами, которые помогают ускорять решения и развивать культуру изменений.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImage}>
                  <img src={post.image} alt={post.title} />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.summary}</p>
                  <Link to={post.link} className={styles.linkArrow}>
                    Читать далее
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={`container ${styles.ctaContainer}`}>
          <div className={styles.ctaContent}>
            <h2>Готовы обсудить роль технологий в вашей стратегии?</h2>
            <p>
              Расскажите нам о текущих вызовах. Мы предложим шаги, которые помогут безопасно внедрить изменения и поддерживать их эффект.
            </p>
          </div>
          <Link to="/kontakty" className={styles.primaryButton}>
            Запланировать встречу
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;