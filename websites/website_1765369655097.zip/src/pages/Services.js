import React from 'react';
import useDocumentMeta from '../hooks/useDocumentMeta';
import styles from './Services.module.css';

const serviceBlocks = [
  {
    title: 'Цифровая стратегия и дорожные карты',
    description:
      'Проводим диагностику, формируем стратегию, рассчитываем экономический эффект и создаём понятную дорожную карту внедрений.',
    benefits: [
      'Диагностика зрелости процессов и данных',
      'Формирование целевой модели управления',
      'Портфель инициатив и приоритизация',
      'KPI и инструменты мониторинга'
    ],
    image: 'https://picsum.photos/800/600?random=71'
  },
  {
    title: 'Архитектура данных и аналитика',
    description:
      'Выстраиваем устойчивую архитектуру данных, внедряем BI-инструменты и культуру принятия решений на основе фактов.',
    benefits: [
      'Data governance и качество данных',
      'Единые витрины и самообслуживание',
      'Модели прогнозирования и сценарии',
      'Обучение аналитических команд'
    ],
    image: 'https://picsum.photos/800/600?random=72'
  },
  {
    title: 'Продуктовая разработка и интеграция',
    description:
      'Создаём цифровые продукты, сервисы и платформы. Уделяем внимание архитектуре, безопасности и опыту пользователей.',
    benefits: [
      'Разработка MVP и масштабирование',
      'Интеграция с legacy-системами',
      'UX/UI дизайн и исследование клиентов',
      'Эксплуатация и поддержка после запуска'
    ],
    image: 'https://picsum.photos/800/600?random=73'
  }
];

const accelerator = [
  {
    title: 'Работа с инновациями',
    description: 'Запускаем корпоративные акселераторы, пилоты и программы открытых инноваций.'
  },
  {
    title: 'Управление изменениями',
    description: 'Помогаем командам осваивать новые роли, выстраиваем коммуникации и систему вовлечения.'
  },
  {
    title: 'Киберустойчивость',
    description: 'Создаём культуру безопасной разработки и контролируем риски на всех этапах жизненного цикла продукта.'
  }
];

const Services = () => {
  useDocumentMeta({
    title: 'Услуги | Лабмьсдсост ось б',
    description:
      'Технологический консалтинг, цифровая стратегия, архитектура данных, продуктовая разработка и управление изменениями от команды Лабмьсдсост ось б.'
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Комплексные услуги для трансформации и роста</h1>
          <p>
            Мы закрываем весь цикл — от диагностики и разработки стратегии до внедрения и поддержки. Подбираем формат сотрудничества под контекст, интегрируемся в команду клиента и фокусируемся на практическом результате.
          </p>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <div className={styles.servicesGrid}>
            {serviceBlocks.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceInfo}>
                  <h2>{service.title}</h2>
                  <p>{service.description}</p>
                  <ul>
                    {service.benefits.map((benefit) => (
                      <li key={benefit}>{benefit}</li>
                    ))}
                  </ul>
                </div>
                <div className={styles.serviceImage}>
                  <img src={service.image} alt={service.title} />
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.additionalSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Дополнительная экспертиза</h2>
            <p className="section-subtitle">
              Мы подключаемся к задачам, которые требуют гибкости и точечной экспертизы. Для каждого направления — отдельная команда практиков.
            </p>
          </div>
          <div className={styles.acceleratorGrid}>
            {accelerator.map((item) => (
              <article key={item.title} className={styles.acceleratorCard}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.formatSection}>
        <div className="container">
          <div className={styles.formatGrid}>
            <div className={styles.formatCard}>
              <h2>Форматы сотрудничества</h2>
              <ul>
                <li>Консалтинговые проекты под ключ с выделенной командой.</li>
                <li>Продуктовые спринты для быстрых пилотов и проверки гипотез.</li>
                <li>Экспертное сопровождение и наставничество внутренних команд.</li>
                <li>Аудит текущих процессов, архитектуры и проектного портфеля.</li>
              </ul>
            </div>
            <div className={styles.formatImage}>
              <img
                src="https://picsum.photos/900/600?random=74"
                alt="Совместная работа консультантов и команды клиента"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;