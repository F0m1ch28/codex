import React, { useState } from 'react';
import useDocumentMeta from '../hooks/useDocumentMeta';
import styles from './Contact.module.css';

const Contact = () => {
  useDocumentMeta({
    title: 'Контакты | Лабмьсдсост ось б',
    description:
      'Свяжитесь с командой Лабмьсдсост ось б: консультации по цифровой трансформации, стратегиям, данным и продуктовой разработке.'
  });

  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Введите имя';
    if (!formData.email.trim()) newErrors.email = 'Укажите электронную почту';
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Некорректный формат email';
    if (!formData.message.trim()) newErrors.message = 'Расскажите о задаче';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormData({ name: '', company: '', email: '', message: '' });
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Давайте обсудим ваш проект</h1>
          <p>
            Мы внимательно изучаем контекст и подбираем формат взаимодействия. Оставьте заявку — ответим в течение одного рабочего дня.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.card}>
              <h2>Контактные данные</h2>
              <ul className={styles.contactList}>
                <li>
                  <span>Адрес</span>
                  <p>г. Москва, ул. Примерная, д. 1</p>
                </li>
                <li>
                  <span>Телефон</span>
                  <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </li>
                <li>
                  <span>Email</span>
                  <a href="mailto:info@labmsdsost-os-b.ru">info@labmsdsost-os-b.ru</a>
                </li>
              </ul>
              <div className={styles.mapWrapper}>
                <img
                  src="https://picsum.photos/800/500?random=81"
                  alt="Схематичная карта расположения офиса в Москве"
                />
              </div>
            </div>

            <div className={styles.formCard}>
              <h2>Оставьте сообщение</h2>
              <p>Опишите задачу — подготовим идеи и предложим сценарии взаимодействия.</p>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label>
                  Имя*
                  <input
                    type="text"
                    name="name"
                    placeholder="Как к вам обращаться"
                    value={formData.name}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.name)}
                  />
                  {errors.name && <span className={styles.error}>{errors.name}</span>}
                </label>
                <label>
                  Компания
                  <input
                    type="text"
                    name="company"
                    placeholder="Название компании"
                    value={formData.company}
                    onChange={handleChange}
                  />
                </label>
                <label>
                  Email*
                  <input
                    type="email"
                    name="email"
                    placeholder="example@company.ru"
                    value={formData.email}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.email)}
                  />
                  {errors.email && <span className={styles.error}>{errors.email}</span>}
                </label>
                <label>
                  Сообщение*
                  <textarea
                    name="message"
                    rows="5"
                    placeholder="Опишите задачу, контекст или ожидаемый результат"
                    value={formData.message}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.message)}
                  />
                  {errors.message && <span className={styles.error}>{errors.message}</span>}
                </label>
                <button type="submit" className={styles.submitButton}>
                  Отправить запрос
                </button>
                {submitted && (
                  <div className={styles.success}>
                    Спасибо! Мы получили запрос и свяжемся с вами в ближайшее время.
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;