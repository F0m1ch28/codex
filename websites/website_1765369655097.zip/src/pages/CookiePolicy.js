import React from 'react';
import useDocumentMeta from '../hooks/useDocumentMeta';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  useDocumentMeta({
    title: 'Политика использования cookie | Лабмьсдсост ось б',
    description:
      'Политика использования файлов cookie компании Лабмьсдсост ось б. Узнайте, какие cookie применяются на сайте и как ими управлять.'
  });

  return (
    <div className={styles.page}>
      <section className="container">
        <h1>Политика использования файлов cookie</h1>
        <p className={styles.updated}>Последнее обновление: 1 марта 2024 года</p>

        <div className={styles.block}>
          <h2>1. Что такое cookie</h2>
          <p>
            Cookie — это небольшие текстовые файлы, которые сохраняются в браузере пользователя. Они помогают нам улучшить работу сайта и сделать взаимодействие более удобным.
          </p>
        </div>

        <div className={styles.block}>
          <h2>2. Какие файлы мы используем</h2>
          <ul>
            <li>Технические cookie — обеспечивают корректную работу сайта.</li>
            <li>Аналитические cookie — помогают понять, как пользователи взаимодействуют с контентом, чтобы улучшать сервис.</li>
          </ul>
        </div>

        <div className={styles.block}>
          <h2>3. Управление cookie</h2>
          <p>
            Вы можете отключить использование cookie в настройках браузера. Однако это может повлиять на корректность отображения отдельных элементов сайта.
          </p>
        </div>

        <div className={styles.block}>
          <h2>4. Контакты</h2>
          <p>
            По вопросам использования cookie напишите нам: info@labmsdsost-os-b.ru.
          </p>
        </div>
      </section>
    </div>
  );
};

export default CookiePolicy;