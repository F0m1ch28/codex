import React from 'react';
import useDocumentMeta from '../hooks/useDocumentMeta';
import styles from './About.module.css';

const milestones = [
  {
    year: '2016',
    title: 'Старт как исследовательская группа',
    description:
      'Собрали команду аналитиков и технологов вокруг идеи честного консалтинга, который говорит с бизнесом на одном языке.'
  },
  {
    year: '2018',
    title: 'Первые крупные трансформации',
    description:
      'Запустили проекты по цифровизации производственных предприятий, наладили систему аналитики и управления данными.'
  },
  {
    year: '2021',
    title: 'Экосистема партнёров',
    description:
      'Расширили экспертизу продуктовой разработкой и организационным дизайном, выстроили сеть отраслевых партнёров.'
  },
  {
    year: '2023',
    title: 'Международные инициативы',
    description:
      'Начали сотрудничество с компаниями из СНГ и Европы, помогая выстраивать устойчивые цепочки поставок и центры данных.'
  }
];

const values = [
  {
    title: 'Ответственность',
    description: 'Берёмся за задачи, в которых можем принести пользу, и сопровождаем внедрение до стабильной работы.'
  },
  {
    title: 'Простота',
    description: 'Делаем сложное понятным: визуализируем данные, рассказываем о технологии в контексте бизнеса, учим команды.'
  },
  {
    title: 'Сотрудничество',
    description: 'Работаем вместе с клиентом. Совместные команды, прозрачные каналы общения, открытые обсуждения решений.'
  },
  {
    title: 'Устойчивость',
    description: 'Строим системы, которые переживают изменения рынка, и помогают бизнесу развиваться без отката назад.'
  }
];

const culture = [
  'Еженедельные открытые сессии, где делимся успехами и ошибками.',
  'Обучающие программы по аналитике, продуктам и управлению изменениями.',
  'Практика менторства: каждый сотрудник поддерживает рост коллег из других направлений.',
  'Ротация внутри проектов, чтобы команда видела картину целиком.'
];

const About = () => {
  useDocumentMeta({
    title: 'О компании | Лабмьсдсост ось б',
    description:
      'Лабмьсдсост ось б — команда стратегов, архитекторов данных и инженеров, которые строят устойчивые цифровые решения и поддерживают изменения в компаниях.'
  });

  return (
    <div className={styles.page}>
      <section className={styles.introSection}>
        <div className="container">
          <div className={styles.introContent}>
            <div>
              <h1>Мы помогаем сделать трансформацию человеческой</h1>
              <p>
                Лабмьсдсост ось б — консалтингово-технологическая компания. Мы сопровождаем стратегические изменения и внедряем решения, которые работают для людей. Нас ценят за честность, глубину анализа и способность адаптироваться к контексту клиента.
              </p>
            </div>
            <div className={styles.introImage}>
              <img
                src="https://picsum.photos/900/600?random=61"
                alt="Команда Лабмьсдсост ось б обсуждает дорожную карту изменений"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.missionSection}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div>
              <h2 className="section-title">Наш фокус</h2>
              <p>
                Мы верим, что технологии и данные должны помогать людям, а не наоборот. Поэтому каждое решение проходит три проверки: бизнес-смысл, технологическая устойчивость и принятие командой. Мы остаёмся рядом и после запуска, чтобы поддержать культуру изменений.
              </p>
            </div>
            <div className={styles.card}>
              <h3>Обещание партнёрам</h3>
              <p>
                Мы не оставляем клиента на этапе "пилота". Наша команда сопровождает внедрение и отвечает за то, чтобы решения приносили ценность на всей дистанции.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.milestonesSection}>
        <div className="container">
          <h2 className="section-title">Путь развития</h2>
          <div className={styles.timeline}>
            {milestones.map((milestone) => (
              <article key={milestone.year} className={styles.timelineItem}>
                <span className={styles.timelineYear}>{milestone.year}</span>
                <div>
                  <h3>{milestone.title}</h3>
                  <p>{milestone.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.valuesSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="section-title">Ценности, формирующие решения</h2>
            <p className="section-subtitle">
              Мы создаём проекты, которыми гордимся. Поэтому держим планку качества, инвестируем в развитие команды и заботимся о том, чтобы клиенты чувствовали поддержку.
            </p>
          </div>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cultureSection}>
        <div className="container">
          <div className={styles.cultureLayout}>
            <div className={styles.cultureText}>
              <h2 className="section-title">Культура совместной работы</h2>
              <p>
                Наша культура роста держится на доверии и открытости. Мы строим безопасное пространство для экспериментов, обсуждаем идеи, которые выходят за рамки привычного, и поддерживаем людей, которые берут ответственность.
              </p>
              <ul className={styles.cultureList}>
                {culture.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
            <div className={styles.cultureImage}>
              <img
                src="https://picsum.photos/900/650?random=62"
                alt="Внутреннее обучение и обсуждение в компании"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.globalSection}>
        <div className="container">
          <div className={styles.globalCard}>
            <div>
              <h2 className="section-title">География проектов</h2>
              <p>
                Мы работаем в Москве, Санкт-Петербурге, Екатеринбурге и Новосибирске, подключаясь к клиентам из финансового сектора, промышленности, логистики и девелопмента. С 2023 года сопровождаем проекты в СНГ и Европе, собирая экспертные команды под задачу.
              </p>
            </div>
            <img
              src="https://picsum.photos/800/500?random=63"
              alt="Карта распределения проектов компании"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;