import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import { ScrollToTopHandler } from './components/ScrollToTop';

function App() {
  return (
    <BrowserRouter>
      <ScrollToTopHandler />
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/o-kompanii" element={<About />} />
          <Route path="/uslugi" element={<Services />} />
          <Route path="/kontakty" element={<Contact />} />
          <Route path="/polzovatelskoe-soglashenie" element={<Terms />} />
          <Route path="/politika-konfidencialnosti" element={<Privacy />} />
          <Route path="/politika-cookie" element={<CookiePolicy />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}

export default App;