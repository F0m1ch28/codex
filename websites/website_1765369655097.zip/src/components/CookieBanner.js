import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'labmsdsost-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Мы используем cookie, чтобы улучшить работу сайта и сделать взаимодействие с сервисами более удобным. Подробнее в{' '}
          <Link to="/politika-cookie">политике использования cookie</Link>.
        </p>
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;