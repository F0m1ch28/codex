import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.container}`}>
        <div className={styles.column}>
          <div className={styles.logo}>
            <span className={styles.logoAccent}>Лабмьсдсост</span>
            <span className={styles.logoText}>ось б</span>
          </div>
          <p className={styles.description}>
            Мы объединяем экспертизу, технологии и человеческое участие, чтобы помочь компаниям смелее смотреть в будущее и реализовывать стратегические цели без лишних рисков.
          </p>
        </div>

        <div className={styles.column}>
          <h4 className={styles.heading}>Навигация</h4>
          <ul className={styles.list}>
            <li><Link to="/">Главная</Link></li>
            <li><Link to="/uslugi">Услуги</Link></li>
            <li><Link to="/o-kompanii">О компании</Link></li>
            <li><Link to="/kontakty">Контакты</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4 className={styles.heading}>Документы</h4>
          <ul className={styles.list}>
            <li><Link to="/polzovatelskoe-soglashenie">Пользовательское соглашение</Link></li>
            <li><Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link></li>
            <li><Link to="/politika-cookie">Политика использования cookie</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4 className={styles.heading}>Контакты</h4>
          <ul className={styles.contacts}>
            <li>г. Москва, ул. Примерная, д. 1</li>
            <li><a href="tel:+74951234567">+7 (495) 123-45-67</a></li>
            <li><a href="mailto:info@labmsdsost-os-b.ru">info@labmsdsost-os-b.ru</a></li>
          </ul>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <div className="container">
          <p>© {new Date().getFullYear()} Лабмьсдсост ось б. Все права защищены.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;