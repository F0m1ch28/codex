import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { path: '/', label: 'Главная' },
  { path: '/uslugi', label: 'Услуги' },
  { path: '/o-kompanii', label: 'О компании' },
  { path: '/kontakty', label: 'Контакты' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={`container ${styles.container}`}>
        <div className={styles.brand} aria-label="Лабмьсдсост ось б">
          <span className={styles.brandAccent}>Лабмьсдсост</span>
          <span className={styles.brandText}>ось б</span>
        </div>

        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Главная навигация">
          {navLinks.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ''}`
              }
              onClick={closeMenu}
              end={link.path === '/'}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        <button
          type="button"
          className={`${styles.burger} ${menuOpen ? styles.burgerOpen : ''}`}
          aria-label={menuOpen ? 'Закрыть меню' : 'Открыть меню'}
          aria-expanded={menuOpen}
          onClick={toggleMenu}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;