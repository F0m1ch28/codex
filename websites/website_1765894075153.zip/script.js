document.addEventListener("DOMContentLoaded", function () {
  const banner = document.querySelector(".cookie-banner");
  const acceptButton = document.querySelector(".cookie-button.accept");
  const declineButton = document.querySelector(".cookie-button.decline");

  if (!banner || !acceptButton || !declineButton) {
    return;
  }

  const storageKey = "dot-cookies-choice";
  const storedChoice = localStorage.getItem(storageKey);

  if (storedChoice) {
    banner.classList.add("cookie-banner--hidden");
  }

  acceptButton.addEventListener("click", function () {
    localStorage.setItem(storageKey, "accepted");
    banner.classList.add("cookie-banner--hidden");
  });

  declineButton.addEventListener("click", function () {
    localStorage.setItem(storageKey, "declined");
    banner.classList.add("cookie-banner--hidden");
  });
});