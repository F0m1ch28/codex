```javascript
document.addEventListener("DOMContentLoaded", () => {
  // Navigation toggle
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = primaryNav.classList.toggle("is-open");
      navToggle.classList.toggle("is-active", isOpen);
      navToggle.setAttribute("aria-expanded", isOpen);
    });

    primaryNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        primaryNav.classList.remove("is-open");
        navToggle.classList.remove("is-active");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  // Cookie banner
  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".js-cookie-accept");
  const declineBtn = document.querySelector(".js-cookie-decline");
  const storageKey = "qnm_cookie_preference";

  const showCookieBanner = () => {
    if (!cookieBanner) return;
    cookieBanner.classList.add("is-visible");
  };

  const hideCookieBanner = () => {
    if (!cookieBanner) return;
    cookieBanner.classList.remove("is-visible");
  };

  const currentPreference = localStorage.getItem(storageKey);
  if (!currentPreference) {
    window.setTimeout(showCookieBanner, 600);
  }

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      localStorage.setItem(storageKey, "accepted");
      hideCookieBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      localStorage.setItem(storageKey, "declined");
      hideCookieBanner();
    });
  }

  // FAQ Accordion
  const faqItems = document.querySelectorAll(".faq-item");
  faqItems.forEach((item) => {
    const trigger = item.querySelector("button");
    if (!trigger) return;
    trigger.addEventListener("click", () => {
      const isExpanded = item.getAttribute("aria-expanded") === "true";
      faqItems.forEach((other) => other.setAttribute("aria-expanded", "false"));
      item.setAttribute("aria-expanded", String(!isExpanded));
    });
  });

  // Contact form handler
  const contactForm = document.querySelector("#contact-form");
  if (contactForm) {
    const statusBox = document.querySelector(".form-status");
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!statusBox) return;

      const formData = new FormData(contactForm);
      const hasEmpty = Array.from(formData.values()).some((value) => !String(value).trim());
      if (hasEmpty) {
        statusBox.textContent = "Өтінеміз, барлық өрістерді толтырыңыз.";
        statusBox.className = "form-status error is-visible";
        return;
      }

      statusBox.textContent = "Хат сәтті жіберілді! Біз 24 сағат ішінде жауап береміз.";
      statusBox.className = "form-status success is-visible";
      contactForm.reset();
    });
  }
});
```