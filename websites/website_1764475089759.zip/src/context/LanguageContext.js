import React, { createContext, useContext, useMemo, useState } from 'react';

const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
  const browserLang = typeof window !== 'undefined' ? navigator.language : 'en';
  const initialLang = browserLang.startsWith('es') ? 'es' : 'en';
  const [language, setLanguage] = useState(initialLang);

  const value = useMemo(() => ({ language, setLanguage }), [language]);
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

export const useLanguage = () => useContext(LanguageContext);
```

```javascript