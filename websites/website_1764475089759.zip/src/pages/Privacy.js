import React from 'react';
import { Helmet } from 'react-helmet-async';

const Privacy = () => (
  <main className="section page">
    <Helmet>
      <title>Privacy Policy | Tu Progreso Hoy</title>
    </Helmet>
    <div className="container legal">
      <h1>Privacy Policy</h1>
      <p>Effective date: 2024</p>
      <h2>1. Overview</h2>
      <p>
        Tu Progreso Hoy is an educational platform. We collect minimal personal information to deliver course access,
        newsletters, and support. Your privacy is essential to maintaining trust.
      </p>

      <h2>2. Data collected</h2>
      <ul>
        <li>Contact details: name, email, phone (optional)</li>
        <li>Course interaction records and progress metrics</li>
        <li>Analytics (with consent) for improving learning materials</li>
      </ul>

      <h2>3. Data usage</h2>
      <p>
        Information is used to deliver educational content, maintain double opt-in communications, and comply with
        applicable Argentine regulations. We never sell your data.
      </p>

      <h2>4. Rights</h2>
      <p>
        You may request access, rectification, or deletion of your data by contacting hola@tuprogresohoy.com. We respond
        within 30 days.
      </p>

      <h2>5. International transfers</h2>
      <p>
        Some processing tools may store data outside Argentina. We ensure adequate protections aligned with GDPR-style
        safeguards.
      </p>

      <h2>6. Updates</h2>
      <p>
        Changes to this policy will be published on this page. Continued use of the platform indicates acceptance of the
        updated policy.
      </p>
    </div>
  </main>
);

export default Privacy;
```

```javascript