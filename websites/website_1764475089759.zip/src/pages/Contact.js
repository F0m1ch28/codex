import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import clsx from 'clsx';
import { useNavigate } from 'react-router-dom';

const steps = [
  {
    title: 'About you',
    fields: [
      { name: 'name', label: 'Full name', type: 'text', required: true },
      { name: 'email', label: 'Email', type: 'email', required: true }
    ]
  },
  {
    title: 'Message focus',
    fields: [
      {
        name: 'topic',
        label: 'Topic',
        type: 'select',
        options: ['Partnerships', 'Media', 'Learner support', 'Data inquiry'],
        required: true
      },
      { name: 'message', label: 'Message', type: 'textarea', required: true }
    ]
  }
];

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', topic: '', message: '' });
  const [currentStep, setCurrentStep] = useState(0);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleNext = (e) => {
    e.preventDefault();
    if (currentStep < steps.length - 1) setCurrentStep((prev) => prev + 1);
    else {
      navigate('/thank-you', { state: { name: formData.name } });
    }
  };

  const stepDef = steps[currentStep];

  return (
    <main className="section page">
      <Helmet>
        <title>Contact | Tu Progreso Hoy</title>
      </Helmet>
      <div className="container">
        <header className="page-header">
          <h1>Contact Tu Progreso Hoy</h1>
          <p>
            Estamos en Av. 9 de Julio 1000, C1043 Buenos Aires. Reach us for collaborations, learner support, or media
            insights. Información confiable que respalda elecciones responsables sobre tu dinero.
          </p>
        </header>

        <section className="contact-grid">
          <div className="contact-card">
            <h2>Multi-channel support</h2>
            <ul>
              <li>
                Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
              </li>
              <li>Phone: +54 11 5555-1234</li>
              <li>Live chat: Available weekdays 9:00-18:00 (ART)</li>
              <li>Social: LinkedIn, Instagram, Twitter</li>
            </ul>
          </div>
          <div className="contact-form-card">
            <div className="contact-progress">
              {steps.map((step, index) => (
                <span key={step.title} className={clsx({ active: index <= currentStep })}>
                  {step.title}
                </span>
              ))}
            </div>
            <form onSubmit={handleNext}>
              {stepDef.fields.map((field) => {
                if (field.type === 'select') {
                  return (
                    <label key={field.name}>
                      {field.label}
                      <select
                        name={field.name}
                        value={formData[field.name]}
                        onChange={handleChange}
                        required={field.required}
                      >
                        <option value="">Select</option>
                        {field.options.map((option) => (
                          <option value={option} key={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                    </label>
                  );
                }
                if (field.type === 'textarea') {
                  return (
                    <label key={field.name}>
                      {field.label}
                      <textarea
                        name={field.name}
                        value={formData[field.name]}
                        onChange={handleChange}
                        required={field.required}
                        rows={4}
                      />
                    </label>
                  );
                }
                return (
                  <label key={field.name}>
                    {field.label}
                    <input
                      name={field.name}
                      type={field.type}
                      value={formData[field.name]}
                      onChange={handleChange}
                      required={field.required}
                    />
                  </label>
                );
              })}
              <button type="submit" className="btn-primary">
                {currentStep === steps.length - 1 ? 'Send message' : 'Continue'}
              </button>
            </form>
          </div>
        </section>

        <section className="map-section">
          <h2>Buenos Aires hub</h2>
          <div className="map-container">
            <iframe
              title="Tu Progreso Hoy Buenos Aires Map"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3283.593793395915!2d-58.38238812366971!3d-34.614201358147195!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccada4c13c4b7%3A0x62bfcacbd7b3755c!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA!5e0!3m2!1sen!2sar!4v1700000000000!5m2!1sen!2sar"
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </section>
      </div>
    </main>
  );
};

export default Contact;
```

```javascript