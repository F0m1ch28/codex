import React from 'react';
import { Helmet } from 'react-helmet-async';

const Cookies = () => (
  <main className="section page">
    <Helmet>
      <title>Cookie Policy | Tu Progreso Hoy</title>
    </Helmet>
    <div className="container legal">
      <h1>Cookie Policy</h1>
      <p>
        Tu Progreso Hoy uses cookies to ensure essential functionality and enhance learning experiences. You may adjust
        optional analytics cookies via the cookie banner at any time.
      </p>

      <h2>Types of cookies</h2>
      <ul>
        <li>
          Functional cookies: Required for authentication, course progression, and preference storage. Cannot be
          disabled.
        </li>
        <li>
          Analytics cookies: Optional. Provide aggregated usage metrics to improve course materials. Deactivated by
          default until you opt in.
        </li>
      </ul>

      <h2>Managing preferences</h2>
      <p>
        Use the cookie banner controls or adjust your browser settings. Declining optional cookies does not limit access
        to educational content.
      </p>
    </div>
  </main>
);

export default Cookies;
```

```javascript