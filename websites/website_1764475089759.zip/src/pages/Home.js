import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { useCursorParallax } from '../hooks/useCursorParallax';
import { useParallaxScroll } from '../hooks/useParallaxScroll';
import ARSTracker from '../components/ARSTracker';
import DoubleOptInForm from '../components/forms/DoubleOptInForm';
import { insights, promises, timelineAchievements, testimonials } from '../data/companyData';
import { fadeIn, fadeInUp, scaleIn, staggerChildren } from '../utils/animations';

const AchievementBadge = ({ title, description, badge }) => (
  <motion.div variants={fadeInUp} className="promise-card">
    <span className="promise-badge">{badge}</span>
    <h4>{title}</h4>
    <p>{description}</p>
  </motion.div>
);

const Timeline = () => (
  <section className="section timeline">
    <div className="container">
      <h2>Our shared journey across volatile seasons</h2>
      <p>
        Conocimiento financiero impulsado por tendencias. Cada hito se celebró con nuestra comunidad, cuidando de tus
        emociones y tus decisiones.
      </p>
      <div className="timeline-grid">
        {timelineAchievements.map((milestone) => (
          <div key={milestone.year} className="timeline-card">
            <span className="timeline-year">{milestone.year}</span>
            <h4>{milestone.title}</h4>
            <p>{milestone.description}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const Testimonials = () => (
  <section className="section testimonials">
    <div className="container">
      <div className="section-header">
        <h2>Voices from our learners</h2>
        <p>Análisis transparentes y datos de mercado para decidir con seguridad.</p>
      </div>
      <div className="testimonial-grid">
        {testimonials.map((item) => (
          <motion.blockquote key={item.name} variants={fadeInUp} className="testimonial-card">
            <p>{item.quote}</p>
            <footer>
              <span className="name">{item.name}</span>
              <span className="title">{item.title}</span>
            </footer>
          </motion.blockquote>
        ))}
      </div>
    </div>
  </section>
);

const InsightLayer = () => (
  <section className="section insights">
    <div className="container">
      <div className="section-header">
        <h2>Insight layers to steady your path</h2>
        <p>Pasos acertados hoy, mejor futuro mañana.</p>
      </div>
      <div className="insight-grid">
        {insights.map((item) => (
          <motion.div key={item.title} variants={scaleIn} className="insight-card">
            <div className="insight-metric">
              <span>{item.metric}</span>
              <small>{item.label}</small>
            </div>
            <div className="insight-copy">
              <h4>{item.title}</h4>
              <p>{item.text}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const GamifiedProgress = () => (
  <section className="section gamified">
    <div className="container">
      <div className="gamified-inner">
        <div>
          <h2>Progress that celebrates your resilience</h2>
          <p>
            Track your achievements with mindful milestones. Each badge unlocks new reflections, audio cues, and peer
            stories to keep you motivated.
          </p>
          <ul className="progress-list">
            <li>
              <span className="badge">Badge 01</span>
              <div>
                <h4>Inflation Decoder</h4>
                <p>You learned to interpret CPI releases for your household. Achievement unlocked.</p>
              </div>
            </li>
            <li>
              <span className="badge">Badge 02</span>
              <div>
                <h4>FX Navigator</h4>
                <p>You designed a response plan for ARS→USD volatility using our live tracker and scenarios.</p>
              </div>
            </li>
            <li>
              <span className="badge">Badge 03</span>
              <div>
                <h4>Budget Steward</h4>
                <p>You crafted a budget that breathes with your life seasons, aligning values and numbers.</p>
              </div>
            </li>
          </ul>
        </div>
        <div className="progress-visual">
          <div className="progress-ring">
            <svg viewBox="0 0 120 120" aria-hidden="true">
              <circle cx="60" cy="60" r="54" className="ring-bg" />
              <circle cx="60" cy="60" r="54" className="ring-progress" />
            </svg>
            <span>76%</span>
            <small>Course completion</small>
          </div>
          <div className="progress-cards">
            <article>
              <h5>Reflective journaling</h5>
              <p>Record how inflation news makes you feel. Build a resilient mindset with weekly prompts.</p>
            </article>
            <article>
              <h5>Peer milestones</h5>
              <p>Celebrate community achievements in our learning lounge without comparing, only inspiring.</p>
            </article>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const StorytellingSection = () => (
  <section className="section storytelling">
    <div className="container storytelling-grid">
      <div>
        <h2>Datos verificados para planificar tu presupuesto.</h2>
        <p>
          Decisiones responsables, objetivos nítidos. Nuestra misión es acompañarte con empatía, información confiable
          y una estética emocional que abrace tu contexto argentino.
        </p>
        <p>
          Cada visualización es diseñada para generar calma. Conocimiento financiero impulsado por tendencias, narrado
          con respeto por las historias detrás de cada número.
        </p>
      </div>
      <div className="story-cards">
        <article>
          <h4>Behind the dashboards</h4>
          <p>We combine official INDEC data with private indices, cross-checked by our data integrity taskforce.</p>
          <p className="story-note">Información confiable que respalda elecciones responsables sobre tu dinero.</p>
        </article>
        <article>
          <h4>Customer journey</h4>
          <ol>
            <li>Begin with an emotional grounding exercise and a CPI pulse overview.</li>
            <li>Explore interactive simulations for ARS→USD shifts affecting groceries, utilities, and education.</li>
            <li>Create your financial route map with supportive community circles.</li>
          </ol>
          <p>Plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
        </article>
      </div>
    </div>
  </section>
);

const Hero = () => {
  const heroRef = useRef(null);
  const parallaxRef = useRef(null);
  useCursorParallax(heroRef);
  useParallaxScroll(parallaxRef, 0.15);

  return (
    <section className="hero" ref={heroRef}>
      <div className="hero-bg" ref={parallaxRef} />
      <div className="hero-overlay" />
      <div className="hero-content container">
        <motion.div initial="hidden" animate="visible" variants={staggerChildren(0.3)}>
          <motion.h1 variants={fadeInUp}>
            Tu Progreso Hoy — Emotional data guidance for Argentina&apos;s everyday choices.
          </motion.h1>
          <motion.p variants={fadeIn}>
            Análisis transparentes y datos de mercado para decidir con seguridad. Pasos acertados hoy, mejor futuro
            mañana.
          </motion.p>
          <motion.div variants={fadeInUp} className="hero-cta">
            <a href="#course-overview" className="btn-primary">
              Explore the course
            </a>
            <a href="#insights" className="btn-secondary">
              View insights
            </a>
          </motion.div>
        </motion.div>
        <motion.div className="hero-panel" initial="hidden" animate="visible" variants={fadeIn}>
          <ARSTracker />
          <div className="hero-checklist">
            <span>✔️ Datos verificados para planificar tu presupuesto.</span>
            <span>✔️ Decisiones responsables, objetivos nítidos.</span>
            <span>✔️ Conocimiento financiero impulsado por tendencias.</span>
          </div>
        </motion.div>
      </div>
      <div className="hero-flag" aria-hidden="true" />
    </section>
  );
};

const Home = () => {
  const sectionRef = useRef(null);
  useScrollAnimation(sectionRef);

  return (
    <main>
      <Hero />
      <section className="section promises" ref={sectionRef}>
        <div className="container">
          <motion.div className="section-header" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeInUp}>
              Emotional intelligence + responsible economics for Argentina’s everyday people
            </motion.h2>
            <motion.p variants={fadeIn}>
              We invite you to feel confident in your financial journey while honoring your lived experience.
            </motion.p>
          </motion.div>
          <motion.div
            className="promise-grid"
            initial="hidden"
            whileInView="visible"
            variants={staggerChildren()}
            viewport={{ once: true }}
          >
            {promises.map((promise) => (
              <AchievementBadge key={promise.title} {...promise} />
            ))}
          </motion.div>
        </div>
      </section>
      <StorytellingSection />
      <InsightLayer />
      <section id="course-overview" className="section overview">
        <div className="container">
          <div className="section-header">
            <h2>Course overview — step into clarity, stay grounded</h2>
            <p>
              Datos verificados para planificar tu presupuesto. Each module combines data walkthroughs, exercises, and
              community reflections.
            </p>
          </div>
          <div className="overview-grid">
            <article>
              <h3>Weekly live explorations</h3>
              <p>
                Follow the rhythm of Argentina’s inflation calendar with weekly deep dives, bilingual glossaries, and
                asynchronous reflections.
              </p>
            </article>
            <article>
              <h3>Interactive scenario studio</h3>
              <p>
                Model ARS→USD fluctuations, evaluate real cost-of-living shifts, and apply insights to your unique
                household.
              </p>
            </article>
            <article>
              <h3>Community learning lounge</h3>
              <p>
                Share progress, celebrate milestones, and exchange resilient strategies with fellow learners across
                Argentina.
              </p>
            </article>
          </div>
        </div>
      </section>
      <GamifiedProgress />
      <Testimonials />
      <Timeline />
      <section id="insights" className="section cta">
        <div className="container">
          <DoubleOptInForm />
        </div>
      </section>
    </main>
  );
};

export default Home;
```

```javascript