import React from 'react';
import { Helmet } from 'react-helmet-async';

const Terms = () => (
  <main className="section page">
    <Helmet>
      <title>Terms of Use | Tu Progreso Hoy</title>
    </Helmet>
    <div className="container legal">
      <h1>Terms of Use</h1>
      <p>Welcome to Tu Progreso Hoy. By accessing our website and courses, you agree to the following terms:</p>

      <h2>Educational purpose only</h2>
      <p>
        Content is provided for educational purposes. Plataforma educativa con datos esenciales, sin asesoría financiera
        directa.
      </p>

      <h2>Eligibility</h2>
      <p>
        You must be at least 18 years old or have parental consent. Users are responsible for maintaining the
        confidentiality of their login credentials.
      </p>

      <h2>Intellectual property</h2>
      <p>
        Materials, graphics, and audio elements are owned by Tu Progreso Hoy. You may not copy or distribute content
        without permission.
      </p>

      <h2>Limitation of liability</h2>
      <p>
        We strive for accuracy but cannot guarantee error-free data. Decisions remain the user’s responsibility. We do
        not provide financial services.
      </p>

      <h2>Governing law</h2>
      <p>These terms are governed by the laws of Argentina. Disputes will be resolved in Buenos Aires courts.</p>
    </div>
  </main>
);

export default Terms;
```

```javascript