import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import clsx from 'clsx';
import { resourceArticles } from '../data/companyData';

const categories = ['All', ...new Set(resourceArticles.map((a) => a.category))];

const Resources = () => {
  const [selected, setSelected] = useState('All');

  const filtered = useMemo(() => {
    if (selected === 'All') return resourceArticles;
    return resourceArticles.filter((article) => article.category === selected);
  }, [selected]);

  return (
    <main className="section page">
      <Helmet>
        <title>Articles & Glossaries | Tu Progreso Hoy</title>
      </Helmet>
      <div className="container">
        <header className="page-header">
          <h1>Resource library</h1>
          <p>
            Stories, glossaries, and analytical guides — English primary with Spanish companions. Sigue las tendencias,
            identifica oportunidades y diseña tu ruta financiera.
          </p>
        </header>

        <div className="resource-filters" role="tablist">
          {categories.map((category) => (
            <button
              key={category}
              className={clsx('resource-filter', { active: selected === category })}
              role="tab"
              aria-selected={selected === category}
              onClick={() => setSelected(category)}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="resource-grid">
          {filtered.map((article) => (
            <article key={article.id} className="resource-card">
              <header>
                <span className="resource-category">{article.category}</span>
                <h3>{article.title}</h3>
              </header>
              <p>{article.summary}</p>
              <p className="resource-summary-es">{article.langSummary}</p>
              <footer>
                <span>{article.readingTime} read</span>
                <div className="resource-topics">
                  {article.topics.map((topic) => (
                    <span key={topic}>{topic}</span>
                  ))}
                </div>
                <a href="/" className="btn-tertiary">
                  Read (EN / ES)
                </a>
              </footer>
            </article>
          ))}
        </div>

        <section className="newsletter-section">
          <h2>Newsletter & glossary drops</h2>
          <p>
            De la información al aprendizaje: fortalece tu criterio financiero paso a paso. Every edition includes
            ARS→USD updates, CPI context, and mindful prompts.
          </p>
          <form className="newsletter-form">
            <label htmlFor="newsletter-email" className="sr-only">
              Email
            </label>
            <input type="email" id="newsletter-email" required placeholder="Email address" />
            <button type="submit" className="btn-primary">
              Subscribe
            </button>
          </form>
        </section>
      </div>
    </main>
  );
};

export default Resources;
```

```javascript