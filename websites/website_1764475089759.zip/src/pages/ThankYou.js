import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useLocation, Link } from 'react-router-dom';

const ThankYou = () => {
  const location = useLocation();
  const name = location.state?.name || 'Friend';

  return (
    <main className="section thank-you">
      <Helmet>
        <title>Thank you | Tu Progreso Hoy</title>
      </Helmet>
      <div className="container">
        <h1>Gracias, {name}!</h1>
        <p>
          Tu solicitud fue recibida. Revisa tu correo para finalizar la doble confirmación. Datos verificados para
          planificar tu presupuesto.
        </p>
        <div className="thank-you-actions">
          <Link to="/resources" className="btn-primary">
            Explore resources
          </Link>
          <Link to="/" className="btn-secondary">
            Return home
          </Link>
        </div>
      </div>
    </main>
  );
};

export default ThankYou;
```

```javascript