import React from 'react';
import { Helmet } from 'react-helmet-async';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, ReferenceLine } from 'recharts';
import { faqItems } from '../data/companyData';

const cpiData = [
  { month: 'Jan', official: 6.5, private: 6.8 },
  { month: 'Feb', official: 6.2, private: 6.4 },
  { month: 'Mar', official: 7.7, private: 7.9 },
  { month: 'Apr', official: 8.4, private: 8.1 },
  { month: 'May', official: 7.8, private: 7.5 },
  { month: 'Jun', official: 6.8, private: 6.6 }
];

const fxData = [
  { month: 'Jan', official: 185, blended: 320 },
  { month: 'Feb', official: 194, blended: 340 },
  { month: 'Mar', official: 210, blended: 355 },
  { month: 'Apr', official: 220, blended: 370 },
  { month: 'May', official: 235, blended: 395 },
  { month: 'Jun', official: 265, blended: 418 }
];

const Inflation = () => (
  <main className="section page">
    <Helmet>
      <title>Inflation & FX Methodology | Tu Progreso Hoy</title>
      <link rel="alternate" href="https://www.tuprogresohoy.com/inflation" hreflang="en" />
      <link rel="alternate" href="https://www.tuprogresohoy.com/inflation?lang=es" hreflang="es-AR" />
    </Helmet>
    <div className="container">
      <header className="page-header">
        <h1>Inflation & ARS→USD Methodology</h1>
        <p>
          Datos verificados para planificar tu presupuesto. This page explains how we gather CPI and FX data, normalize
          it, and annotate shifts so you can trust the context behind each chart.
        </p>
      </header>

      <section className="methodology-section">
        <h2>Data philosophy</h2>
        <p>
          Our methodology is anchored in transparency. We combine official INDEC CPI releases with carefully vetted
          private estimates to capture nuances in Argentina’s inflation landscape. Each dataset is timestamped, traced to
          its origin, and labeled with bilingual commentary.
        </p>
        <ul className="method-list">
          <li>
            <strong>Official CPI (INDEC):</strong> Used as baseline. Adjusted for basket changes with historical
            documentation.
          </li>
          <li>
            <strong>Private measurements:</strong> Selected for regional coverage, frequency, and methodological rigor.
          </li>
          <li>
            <strong>FX references:</strong> Official, blended, and alternative rates captured to illustrate household
            exposure.
          </li>
          <li>
            <strong>Household anchors:</strong> Groceries, utilities, education, and transport price trackers.
          </li>
        </ul>
      </section>

      <section className="chart-section">
        <h2>Monthly CPI evolution</h2>
        <p>
          We plot official and private CPI monthly figures to visualize the gap and convergence. Tooltip notes explain
          historical events, policy shifts, and seasonal patterns.
        </p>
        <div className="chart-wrapper" role="img" aria-label="Monthly CPI chart with official and private data">
          <ResponsiveContainer width="100%" height={360}>
            <AreaChart data={cpiData}>
              <defs>
                <linearGradient id="official" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563EB" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="private" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1F3A6F" stopOpacity={0.7} />
                  <stop offset="95%" stopColor="#1F3A6F" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" stroke="#94A3B8" />
              <YAxis stroke="#94A3B8" />
              <Tooltip contentStyle={{ background: '#0F172A', borderRadius: '0.75rem', border: '1px solid #2563EB' }} />
              <Area type="monotone" dataKey="official" stroke="#2563EB" fill="url(#official)" name="Official CPI" />
              <Area type="monotone" dataKey="private" stroke="#1F3A6F" fill="url(#private)" name="Private CPI" />
              <ReferenceLine y={5} stroke="#38BDF8" strokeDasharray="3 3" label="Threshold" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="chart-section">
        <h2>ARS→USD context</h2>
        <p>
          Currency scenarios highlight the gap between official and blended references. We narrate how these movements
          ripple across household budgets so you can anticipate adjustments calmly.
        </p>
        <div className="chart-wrapper" role="img" aria-label="ARS to USD exchange rate comparison">
          <ResponsiveContainer width="100%" height={360}>
            <AreaChart data={fxData}>
              <defs>
                <linearGradient id="officialFX" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#93C5FD" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#93C5FD" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="blendedFX" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1D4ED8" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#1D4ED8" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" stroke="#94A3B8" />
              <YAxis stroke="#94A3B8" />
              <Tooltip contentStyle={{ background: '#0F172A', borderRadius: '0.75rem', border: '1px solid #2563EB' }} />
              <Area type="monotone" dataKey="official" stroke="#93C5FD" fill="url(#officialFX)" name="Official rate" />
              <Area type="monotone" dataKey="blended" stroke="#1D4ED8" fill="url(#blendedFX)" name="Blended / Alternative" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="faq-section">
        <h2>Frequently asked questions</h2>
        <div className="faq-grid">
          {faqItems.map((item) => (
            <details key={item.q}>
              <summary>{item.q}</summary>
              <p>{item.a}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="cta-banner">
        <div>
          <h3>Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.</h3>
          <p>Join the immersive course to transform data into daily clarity.</p>
        </div>
        <a className="btn-primary" href="/course">
          Explore syllabus
        </a>
      </section>
    </div>
  </main>
);

export default Inflation;
```

```javascript