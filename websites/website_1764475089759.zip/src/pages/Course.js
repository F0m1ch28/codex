import React from 'react';
import { Helmet } from 'react-helmet-async';
import { courseModules } from '../data/companyData';
import DoubleOptInForm from '../components/forms/DoubleOptInForm';

const Course = () => (
  <main className="section page">
    <Helmet>
      <title>Financial Course Syllabus | Tu Progreso Hoy</title>
    </Helmet>
    <div className="container">
      <header className="page-header">
        <h1>Course syllabus</h1>
        <p>
          Tu Progreso Hoy transforms inflation anxiety into mindful understanding. Each module blends data analysis,
          storytelling, and reflective exercises.
        </p>
      </header>

      <section className="target-audience">
        <h2>Who is this for?</h2>
        <div className="audience-grid">
          <article>
            <h3>Households facing price volatility</h3>
            <p>
              Build adaptive budgets that honor your family’s priorities while responding to CPI swings in Argentina.
            </p>
          </article>
          <article>
            <h3>Professionals and freelancers</h3>
            <p>
              Understand how ARS→USD movements influence project pricing, savings strategies, and long-term planning.
            </p>
          </article>
          <article>
            <h3>Community advocates & educators</h3>
            <p>
              Translate economic signals into accessible language for peers, students, and local audiences.
            </p>
          </article>
        </div>
      </section>

      <section className="module-section">
        <h2>Module breakdown</h2>
        <div className="module-grid">
          {courseModules.map((module) => (
            <article key={module.id}>
              <div className="module-header">
                <span>{module.duration}</span>
                <h3>{module.title}</h3>
              </div>
              <p>{module.description}</p>
              <ul>
                {module.outcomes.map((outcome) => (
                  <li key={outcome}>{outcome}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className="course-features">
        <h2>Learning experience features</h2>
        <div className="feature-grid">
          <div>
            <h4>Interactive timelines</h4>
            <p>
              Swipe through Argentina’s economic milestones and see how policy shifts translate into today’s prices.
            </p>
          </div>
          <div>
            <h4>Audio-guided reflections</h4>
            <p>Sound design soothes the learning journey. Each milestone is accompanied by gentle audio cues.</p>
          </div>
          <div>
            <h4>Gesture-ready dashboards</h4>
            <p>Swipe and drag to adjust inflation scenarios on mobile. Explore ARS→USD paths with tactile control.</p>
          </div>
        </div>
      </section>

      <section className="cta-banner" id="cta">
        <div>
          <h3>Ready to deepen your understanding?</h3>
          <p>
            Información confiable que respalda elecciones responsables sobre tu dinero. Pasos acertados hoy, mejor futuro
            mañana.
          </p>
        </div>
        <a className="btn-primary" href="#double-opt-form">
          Join the next cohort
        </a>
      </section>

      <section id="double-opt-form">
        <DoubleOptInForm variant="secondary" />
      </section>
    </div>
  </main>
);

export default Course;
```

```javascript