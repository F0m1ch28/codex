import React, { Suspense, lazy, useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { LanguageProvider } from './context/LanguageContext';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import CursorGlow from './components/CursorGlow';
import DisclaimerModal from './components/DisclaimerModal';

const Home = lazy(() => import('./pages/Home'));
const Inflation = lazy(() => import('./pages/Inflation'));
const Course = lazy(() => import('./pages/Course'));
const Resources = lazy(() => import('./pages/Resources'));
const Contact = lazy(() => import('./pages/Contact'));
const ThankYou = lazy(() => import('./pages/ThankYou'));
const Privacy = lazy(() => import('./pages/Privacy'));
const Cookies = lazy(() => import('./pages/Cookies'));
const Terms = lazy(() => import('./pages/Terms'));

const App = () => {
  const [disclaimerOpen, setDisclaimerOpen] = useState(true);

  return (
    <BrowserRouter>
      <LanguageProvider>
        <CursorGlow />
        <ScrollToTop />
        <Header />
        <Suspense
          fallback={
            <main className="loading-state">
              <div className="spinner" aria-label="Loading" />
              <p>Loading premium experience…</p>
            </main>
          }
        >
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/inflation" element={<Inflation />} />
            <Route path="/course" element={<Course />} />
            <Route path="/resources" element={<Resources />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/thank-you" element={<ThankYou />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookies" element={<Cookies />} />
            <Route path="/terms" element={<Terms />} />
          </Routes>
        </Suspense>
        <Footer />
        <CookieBanner />
        <DisclaimerModal open={disclaimerOpen} onClose={() => setDisclaimerOpen(false)} />
      </LanguageProvider>
    </BrowserRouter>
  );
};

export default App;
```

```css