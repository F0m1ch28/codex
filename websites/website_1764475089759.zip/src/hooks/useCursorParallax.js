import { useEffect } from 'react';

export const useCursorParallax = (ref, intensity = 20) => {
  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const handleMove = (event) => {
      const rect = node.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width - 0.5) * intensity;
      const y = ((event.clientY - rect.top) / rect.height - 0.5) * intensity;
      node.style.setProperty('--parallax-x', `${x}px`);
      node.style.setProperty('--parallax-y', `${y}px`);
    };

    window.addEventListener('mousemove', handleMove);
    return () => window.removeEventListener('mousemove', handleMove);
  }, [ref, intensity]);
};
```

```javascript