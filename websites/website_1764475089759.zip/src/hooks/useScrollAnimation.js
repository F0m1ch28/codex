import { useEffect } from 'react';

const defaultOptions = {
  threshold: 0.2,
  rootMargin: '0px 0px -10% 0px'
};

export const useScrollAnimation = (ref, className = 'is-visible', options = defaultOptions) => {
  useEffect(() => {
    if (!ref.current) return;
    const node = ref.current;

    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        node.classList.add(className);
      } else {
        node.classList.remove(className);
      }
    }, options);

    observer.observe(node);
    return () => observer.disconnect();
  }, [ref, className, options]);
};
```

```javascript