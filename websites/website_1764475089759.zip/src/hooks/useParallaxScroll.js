import { useEffect } from 'react';

export const useParallaxScroll = (ref, ratio = 0.3) => {
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const handleScroll = () => {
      const offset = window.scrollY * ratio;
      node.style.setProperty('--parallax-scroll', `${offset}px`);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [ref, ratio]);
};
```

```javascript