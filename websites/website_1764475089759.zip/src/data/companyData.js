export const promises = [
  {
    title: 'Inflation lenses with empathy',
    description:
      'Argentina’s economic cycles translated into digestible narratives that respect your goals and your context.',
    badge: 'Human + Data'
  },
  {
    title: 'Daily ARS→USD pulse',
    description:
      'Stay aware of currency shifts with trusted feeds and contextual alerts tied to local purchasing power.',
    badge: 'Live tracker'
  },
  {
    title: 'Responsible pathways',
    description:
      'Scenario planning guides focused on budgeting, household priorities, and resilient decision-making.',
    badge: 'Plan ahead'
  }
];

export const timelineAchievements = [
  {
    year: '2019',
    title: 'Listening to Argentina',
    description: 'Community workshops in Buenos Aires uncovered the need for transparent economic storytelling.'
  },
  {
    year: '2020',
    title: 'Beta cohort launch',
    description: 'First 200 learners tested our methodology during a volatile CPI season, co-creating key modules.'
  },
  {
    year: '2022',
    title: 'Data-partner integrations',
    description: 'Signed research collaborations with reputable data providers to enhance CPI and FX accuracy.'
  },
  {
    year: '2024',
    title: 'Emotion-aware dashboards',
    description: 'Launched adaptive journeys matching your learning pace with supportive narratives and audio cues.'
  }
];

export const courseModules = [
  {
    id: 1,
    title: 'Economic Reality Decoder',
    duration: 'Week 1',
    description:
      'Break down Argentina’s CPI releases, base effects, and basket methodologies to understand official and private indicators.',
    outcomes: [
      'Identify main CPI sources and differences',
      'Interpret headline vs. core inflation trends',
      'Understand how inflation impacts essential categories'
    ]
  },
  {
    id: 2,
    title: 'Currency Context Studio',
    duration: 'Week 2',
    description:
      'Navigate ARS→USD dynamics, parallel market references, and historical shifts to contextualize present-day choices.',
    outcomes: [
      'Read ARS exchange variants with confidence',
      'Assess the impact of FX moves on savings and expenses',
      'Simulate household budgets under multiple exchange scenarios'
    ]
  },
  {
    id: 3,
    title: 'Budgeting with Purpose',
    duration: 'Week 3',
    description:
      'Construct flexible budgets aligned with personal priorities, building cushions amid volatility.',
    outcomes: [
      'Prioritize essential vs. discretionary spending',
      'Create adaptive monthly budgets tied to inflation checkpoints',
      'Design contingency plans while staying value-driven'
    ]
  },
  {
    id: 4,
    title: 'Future Signals Lab',
    duration: 'Week 4',
    description:
      'Develop your own observation routines. Blend qualitative cues with data to maintain agile financial habits.',
    outcomes: [
      'Build a personalized economic dashboard',
      'Evaluate news, policy shifts, and data releases critically',
      'Maintain resilience via reflective financial journaling'
    ]
  }
];

export const testimonials = [
  {
    name: 'Lucía Fernández',
    title: 'Buenos Aires, Emprendedora',
    quote:
      '“Conocimiento financiero impulsado por tendencias. Aprendí a leer mis gastos con calma y a planear mis decisiones.”'
  },
  {
    name: 'Marcos Quiroga',
    title: 'Córdoba, Analista',
    quote:
      '“Datos verificados para planificar tu presupuesto. Cada módulo agregó claridad sin abrumar.”'
  },
  {
    name: 'Emily Torres',
    title: 'Rosario, Diseñadora',
    quote:
      '“Información confiable que respalda elecciones responsables sobre tu dinero. La experiencia es cálida y rigurosa.”'
  }
];

export const insights = [
  {
    title: 'Inflation pulses contextualized',
    text: 'Weekly CPI briefings tie macro signals to the grocery aisles, transport fares, and education fees you see.',
    metric: '15K+',
    label: 'Briefing subscribers'
  },
  {
    title: 'Household resilience trackers',
    text: 'Track your budget adaptability with AI-assisted reflections, celebrating each milestone you reach.',
    metric: '82%',
    label: 'Learners completing budgets'
  },
  {
    title: 'Community learning circles',
    text: 'Live cohorts foster support and accountability during each inflation checkpoint.',
    metric: '4.8/5',
    label: 'Learner satisfaction'
  }
];

export const faqItems = [
  {
    q: 'How frequently is the ARS→USD tracker updated?',
    a: 'We monitor multiple data feeds and update snapshots several times a day. Latency may occur during market closures or exceptional events.'
  },
  {
    q: 'Does Tu Progreso Hoy offer individual financial advice?',
    a: 'No. Plataforma educativa con datos esenciales, sin asesoría financiera directa. We empower you with knowledge to make personally responsible decisions.'
  },
  {
    q: 'Can I access materials in both English and Spanish?',
    a: 'Yes. Primary narratives are in English with Spanish companions. Each section highlights bilingual cues for clarity.'
  },
  {
    q: 'What is the data methodology behind inflation visuals?',
    a: 'We combine official INDEC data, reputable private indices, and international FX references with transparent normalization steps described on this page.'
  }
];

export const resourceArticles = [
  {
    id: 'ars-overview',
    category: 'Economic Trends',
    title: 'Reading the ARS→USD Curve with Compassion',
    summary:
      'Discover how currency shifts impact everyday experiences from school supplies to healthcare planning.',
    readingTime: '7 min',
    langSummary: 'Descubre cómo los movimientos cambiarios afectan la vida cotidiana.',
    topics: ['ARS→USD', 'Household Impact', 'Scenario Planning']
  },
  {
    id: 'budgeting-argentina',
    category: 'Budgeting',
    title: 'Designing a Buenos Aires Budget that Breathes',
    summary:
      'Blend data-driven estimations with personal rituals to keep your spending aligned with what matters.',
    readingTime: '9 min',
    langSummary: 'Integra estimaciones de datos con hábitos personales para cuidar tu presupuesto.',
    topics: ['Budget Flexibility', 'Inflation check-ins', 'Mindful spending']
  },
  {
    id: 'glossary',
    category: 'Glossary',
    title: 'Argentina Inflation & FX Glossary (EN/ES)',
    summary:
      'Key terminology in English and Spanish to navigate headlines, policy announcements, and neighborhood chatter.',
    readingTime: '12 min',
    langSummary: 'Terminología clave en inglés y español para comprender la coyuntura.',
    topics: ['Glossary', 'Bilingual', 'CPI']
  }
];

export const teamMembers = [
  {
    name: 'Ana Martínez',
    role: 'Lead Economist & Storyteller',
    story:
      'Ana helps translate volatile data into calming narratives. She facilitates the learner circles that guide your reflection moments.',
    skills: { 'Macro Research': 95, Facilitation: 92, Empathy: 97 }
  },
  {
    name: 'Santiago Rivas',
    role: 'Data Infrastructure Architect',
    story:
      'Santiago ensures that every CPI and FX feed is traceable, clean, and explained with transparency in both English and Spanish.',
    skills: { 'Data Pipelines': 94, Visualization: 90, Governance: 93 }
  },
  {
    name: 'Amelia Chen',
    role: 'Experience Designer',
    story:
      'Amelia curates emotional design arcs, layering visuals, audio cues, and progress trackers to celebrate each learner milestone.',
    skills: { 'UX Research': 91, Design Systems: 95, Sound Design: 88 }
  }
];
```

```javascript