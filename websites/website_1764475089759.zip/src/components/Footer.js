import React from 'react';
import { NavLink } from 'react-router-dom';
import clsx from 'clsx';
import { useSoundFeedback } from '../hooks/useSoundFeedback';

const Footer = () => {
  const { playClick } = useSoundFeedback();
  return (
    <footer className="site-footer">
      <div className="footer-grid">
        <div>
          <h3>Tu Progreso Hoy</h3>
          <p>
            Datos verificados para planificar tu presupuesto. Decisiones responsables, objetivos nítidos. Pasos
            acertados hoy, mejor futuro mañana.
          </p>
          <address>
            Av. 9 de Julio 1000<br />
            C1043 Buenos Aires, Argentina
          </address>
          <a href="tel:+541155551234" className="footer-link">
            +54 11 5555-1234
          </a>
        </div>
        <div>
          <h4>Company</h4>
          <ul>
            <li>
              <NavLink to="/privacy" onClick={playClick}>
                Privacy Policy
              </NavLink>
            </li>
            <li>
              <NavLink to="/cookies" onClick={playClick}>
                Cookie Policy
              </NavLink>
            </li>
            <li>
              <NavLink to="/terms" onClick={playClick}>
                Terms of Use
              </NavLink>
            </li>
          </ul>
        </div>
        <div>
          <h4>Resources</h4>
          <ul>
            <li>
              <NavLink to="/inflation" onClick={playClick}>
                Inflation & FX Methodology
              </NavLink>
            </li>
            <li>
              <NavLink to="/course" onClick={playClick}>
                Course Syllabus
              </NavLink>
            </li>
            <li>
              <NavLink to="/resources" onClick={playClick}>
                Articles & Glossaries
              </NavLink>
            </li>
          </ul>
        </div>
        <div>
          <h4>Stay connected</h4>
          <p>Sign up for our double opt-in newsletter.</p>
          <form className="footer-form">
            <label htmlFor="footer-email" className="sr-only">
              Email
            </label>
            <input type="email" id="footer-email" placeholder="Email address" required />
            <button type="button" className={clsx('btn-primary', 'btn-small')} onClick={playClick}>
              Subscribe
            </button>
            <p className="footer-footnote">You’ll receive a confirmation email to activate updates.</p>
          </form>
        </div>
      </div>
      <div className="footer-bottom">
        <p>Análisis transparentes y datos de mercado para decidir con seguridad.</p>
        <p>© {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
```

```javascript