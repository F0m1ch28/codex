import React, { useEffect, useState } from 'react';
import clsx from 'clsx';

const COOKIE_KEY = 'tph-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const [preferences, setPreferences] = useState({ analytics: false, functional: true });

  useEffect(() => {
    const stored = localStorage.getItem(COOKIE_KEY);
    if (!stored) {
      setVisible(true);
    } else {
      setPreferences(JSON.parse(stored));
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem(COOKIE_KEY, JSON.stringify(preferences));
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-label="Cookie consent">
      <div>
        <h2>Cookie preferences</h2>
        <p>
          We use cookies to enhance your learning experience. Functional cookies are essential. Analytics cookies
          are optional and help us improve materials responsibly.
        </p>
        <div className="cookie-options">
          <label>
            <input type="checkbox" checked disabled /> Functional (required)
          </label>
          <label>
            <input
              type="checkbox"
              checked={preferences.analytics}
              onChange={(e) => setPreferences((prev) => ({ ...prev, analytics: e.target.checked }))}
            />
            Analytics insights
          </label>
        </div>
      </div>
      <div className="cookie-actions">
        <button className="btn-secondary" onClick={() => setVisible(false)}>
          Decline optional
        </button>
        <button className={clsx('btn-primary')} onClick={handleSave}>
          Save preferences
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;
```

```javascript