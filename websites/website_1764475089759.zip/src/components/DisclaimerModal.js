import React from 'react';
import clsx from 'clsx';

const DisclaimerModal = ({ open, onClose }) => {
  if (!open) return null;
  return (
    <div className="modal-backdrop" role="dialog" aria-labelledby="disclaimer-title">
      <div className="modal-card">
        <h2 id="disclaimer-title">Disclaimer</h2>
        <p className="modal-text">Мы не предоставляем финансовые услуги.</p>
        <p className="modal-text">We do not provide financial services.</p>
        <p className="modal-text">No brindamos servicios financieros.</p>
        <p className="modal-footnote">
          Plataforma educativa con datos esenciales, sin asesoría financiera directa.
        </p>
        <button className={clsx('btn-primary')} onClick={onClose}>
          Understood
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;
```

```javascript