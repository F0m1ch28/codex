import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import clsx from 'clsx';
import { useLanguage } from '../context/LanguageContext';
import { useSoundFeedback } from '../hooks/useSoundFeedback';

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/inflation', label: 'Inflation Insights' },
  { to: '/course', label: 'Course' },
  { to: '/resources', label: 'Resources' },
  { to: '/contact', label: 'Contact' }
];

const Header = () => {
  const { language, setLanguage } = useLanguage();
  const [searchOpen, setSearchOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { pathname } = useLocation();
  const { playClick } = useSoundFeedback();

  const handleLanguageToggle = () => {
    playClick();
    setLanguage((prev) => (prev === 'en' ? 'es' : 'en'));
  };

  return (
    <header className={clsx('main-header', { 'header-alt': pathname !== '/' })}>
      <div className="header-inner">
        <NavLink to="/" className="brand" onClick={playClick}>
          <span className="brand__primary">Tu</span>
          <span className="brand__secondary">Progreso Hoy</span>
        </NavLink>
        <nav className={clsx('nav-links', { 'nav-open': menuOpen })}>
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              onClick={() => {
                setMenuOpen(false);
                playClick();
              }}
              className={({ isActive }) => clsx('nav-link', { active: isActive })}
            >
              {link.label}
            </NavLink>
          ))}
          <button className="language-toggle" onClick={handleLanguageToggle}>
            {language === 'en' ? 'ES' : 'EN'}
          </button>
        </nav>
        <div className="header-actions">
          <button
            className="header-search"
            aria-label="Toggle search"
            onClick={() => {
              setSearchOpen((prev) => !prev);
              playClick();
            }}
          >
            🔍
          </button>
          <button
            className={clsx('burger', { open: menuOpen })}
            onClick={() => {
              setMenuOpen((prev) => !prev);
              playClick();
            }}
            aria-label="Toggle menu"
          >
            <span />
            <span />
          </button>
        </div>
      </div>
      {searchOpen && (
        <div className="header-search-panel">
          <label htmlFor="site-search" className="sr-only">
            Search site
          </label>
          <input id="site-search" type="search" placeholder="Search insights, modules, stories…" />
          <p role="status">Try “budgeting argentina” or “economic trends”.</p>
        </div>
      )}
    </header>
  );
};

export default Header;
```

```javascript