import React, { useEffect, useState } from 'react';
import clsx from 'clsx';

const ENDPOINT = 'https://api.exchangerate.host/latest?base=ARS&symbols=USD';

const ARSTracker = () => {
  const [rate, setRate] = useState(null);
  const [timestamp, setTimestamp] = useState(null);
  const [status, setStatus] = useState('loading');

  useEffect(() => {
    let cancelled = false;
    const fetchRate = async () => {
      try {
        setStatus('loading');
        const response = await fetch(ENDPOINT);
        if (!response.ok) throw new Error('Network error');
        const data = await response.json();
        if (!cancelled && data?.rates?.USD) {
          setRate(data.rates.USD);
          setTimestamp(new Date().toLocaleString('es-AR', { timeZone: 'America/Argentina/Buenos_Aires' }));
          setStatus('ready');
        }
      } catch (error) {
        if (!cancelled) {
          setStatus('error');
        }
      }
    };
    fetchRate();
    const interval = setInterval(fetchRate, 1000 * 60 * 10);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  return (
    <div className={clsx('ars-tracker', status)}>
      <div className="ars-tracker__header">
        <span>ARS → USD Tracker</span>
        <span className="ars-tracker__status" data-status={status}>
          {status === 'loading' && 'Fetching'}
          {status === 'error' && 'Feed delayed'}
          {status === 'ready' && 'Live'}
        </span>
      </div>
      <div className="ars-tracker__body">
        <h4>{rate ? `1 ARS = ${rate.toFixed(4)} USD` : '--'}</h4>
        <p>
          Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. Última actualización:{' '}
          {timestamp || '—'}
        </p>
      </div>
    </div>
  );
};

export default ARSTracker;
```

```javascript