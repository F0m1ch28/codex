import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import clsx from 'clsx';
import { useSoundFeedback } from '../../hooks/useSoundFeedback';

const DoubleOptInForm = ({ variant = 'primary' }) => {
  const [step, setStep] = useState(1);
  const [formValues, setFormValues] = useState({ name: '', email: '', goal: '' });
  const [confirmationCode, setConfirmationCode] = useState('');
  const navigate = useNavigate();
  const { playClick } = useSoundFeedback();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleStepOne = (e) => {
    e.preventDefault();
    if (!formValues.name || !formValues.email) return;
    playClick();
    setStep(2);
  };

  const handleStepTwo = (e) => {
    e.preventDefault();
    if (!confirmationCode.trim()) return;
    playClick();
    navigate('/thank-you', { state: { name: formValues.name } });
  };

  return (
    <div className={clsx('double-optin-form', `double-optin-form--${variant}`)}>
      <h3>Получить бесплатный пробный урок</h3>
      <p>De la información al aprendizaje: fortalece tu criterio financiero paso a paso.</p>
      {step === 1 && (
        <form onSubmit={handleStepOne}>
          <label>
            Name
            <input name="name" value={formValues.name} onChange={handleChange} required />
          </label>
          <label>
            Email
            <input name="email" type="email" value={formValues.email} onChange={handleChange} required />
          </label>
          <label>
            Financial focus
            <select name="goal" value={formValues.goal} onChange={handleChange} required>
              <option value="">Select focus</option>
              <option value="household">Household budgeting</option>
              <option value="savings">Savings resilience</option>
              <option value="planning">Inflation planning</option>
              <option value="entrepreneur">Entrepreneurship</option>
            </select>
          </label>
          <button type="submit" className="btn-primary">
            Request confirmation email
          </button>
          <p className="form-footnote">
            This is step 1 of 2. You will receive an email to confirm subscription.
          </p>
        </form>
      )}
      {step === 2 && (
        <form onSubmit={handleStepTwo}>
          <p>
            We sent a confirmation email to <strong>{formValues.email}</strong>. Enter the code or tap the link in
            your inbox to continue.
          </p>
          <label>
            Confirmation code
            <input value={confirmationCode} onChange={(e) => setConfirmationCode(e.target.value)} required />
          </label>
          <button type="submit" className="btn-primary">
            Confirm subscription
          </button>
          <button type="button" className="btn-secondary" onClick={() => setStep(1)}>
            Start again
          </button>
        </form>
      )}
      <p className="form-disclaimer">
        Información confiable que respalda elecciones responsables sobre tu dinero. Plataforma educativa con datos
        esenciales, sin asesoría financiera directa.
      </p>
    </div>
  );
};

export default DoubleOptInForm;
```

```javascript