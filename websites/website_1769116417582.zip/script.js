document.addEventListener('DOMContentLoaded', () => {
  const header = document.querySelector('.site-header');
  const toggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelectorAll('.nav-link');
  const focusableSelectors = 'a[href], button:not([disabled]), [tabindex="0"]';

  if (toggle && header) {
    toggle.addEventListener('click', () => {
      header.classList.toggle('is-open');
      const expanded = header.classList.contains('is-open');
      toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
      if (expanded) {
        toggle.focus();
      }
    });
  }

  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      if (header.classList.contains('is-open')) {
        header.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  });

  document.addEventListener('click', event => {
    if (!header.contains(event.target) && header.classList.contains('is-open')) {
      header.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
    }
  });

  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && header.classList.contains('is-open')) {
      header.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.focus();
    }
  });

  const focusableElements = Array.from(document.querySelectorAll(focusableSelectors));
  focusableElements.forEach(el => {
    el.addEventListener('focus', () => {
      el.classList.add('is-focused');
    });
    el.addEventListener('blur', () => {
      el.classList.remove('is-focused');
    });
  });
});