document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('primary-nav');

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      nav.classList.toggle('is-open');
    });
  }

  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );

  document.querySelectorAll('.animate-on-scroll').forEach(element => {
    observer.observe(element);
  });

  const cookieBanner = document.getElementById('cookie-banner');
  const cookieChoice = localStorage.getItem('urbanautofixCookieChoice');

  if (cookieBanner && !cookieChoice) {
    cookieBanner.classList.add('is-visible');
  }

  document.querySelectorAll('[data-cookie-choice]').forEach(button => {
    button.addEventListener('click', () => {
      const choice = button.getAttribute('data-cookie-choice');
      localStorage.setItem('urbanautofixCookieChoice', choice);
      if (cookieBanner) {
        cookieBanner.classList.remove('is-visible');
      }
    });
  });

  const toastElement = document.getElementById('global-toast');

  function showToast(message) {
    if (!toastElement) return;
    toastElement.textContent = message;
    toastElement.classList.add('is-visible');
    setTimeout(() => {
      toastElement.classList.remove('is-visible');
    }, 1600);
  }

  const forms = document.querySelectorAll('form[data-form]');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const successMessage = form.getAttribute('data-success') || 'Solicitarea a fost trimisă.';
      showToast(successMessage);
      setTimeout(() => {
        window.location.href = form.getAttribute('action');
      }, 1400);
    });
  });

  const currentYear = new Date().getFullYear();
  document.querySelectorAll('.current-year').forEach(element => {
    element.textContent = String(currentYear);
  });
});