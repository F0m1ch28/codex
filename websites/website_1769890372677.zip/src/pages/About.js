import React, { useEffect } from 'react';

const About = () => {
  useEffect(() => {
    document.title = 'О проекте — КиберКотики';
    const description = document.querySelector('meta[name="description"]');
    if (description) {
      description.setAttribute(
        'content',
        'История команды КиберКотиков: как мы обучаем цифровой безопасности и вдохновляем через милых котов.'
      );
    }
  }, []);

  return (
    <section className="page-section about-page">
      <div className="page-container">
        <h1>О проекте «КиберКотики»</h1>
        <p>
          Всё началось с того, что наша команда поссорилась из-за ссылки на
          «скидку для своих». Пока мы обсуждали, кто виноват, домашний кот
          спокойно сидел на клавиатуре и не давал нажать ничего лишнего. Так мы
          поняли: нужен проект, который будет напоминать, что безопасность —
          это не скучные регламенты, а ежедневные привычки.
        </p>
        <p>
          «КиберКотики» — это эксперты по кибербезопасности, дизайнеры,
          психологи и, конечно, настоящие коты. Мы создаём образовательные
          программы и тренажёры, которые запоминаются. Даже когда разговор о
          двухфакторной аутентификации, у нас он сопровождается мурчанием.
        </p>

        <div className="team-grid">
          <article className="team-card">
            <img
              src="https://images.unsplash.com/photo-1591494575835-1110eed7c6b6?auto=format&fit=crop&w=600&q=80"
              alt="Команда на хакатоне"
              loading="lazy"
            />
            <h3>Команда</h3>
            <p>
              Специалисты с сертификациями CISSP, CEH и стажем работы в крупных
              ИБ-компаниях. Мы объединяем серьёзную экспертизу и яркую подачу.
            </p>
          </article>
          <article className="team-card">
            <img
              src="https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&q=80"
              alt="Основательница проекта"
              loading="lazy"
            />
            <h3>Наша миссия</h3>
            <p>
              Снизить количество цифровых инцидентов в компаниях и семьях,
              используя язык, понятный всем — язык котиков, юмора и наглядных
              историй.
            </p>
          </article>
          <article className="team-card">
            <img
              src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=600&q=80"
              alt="Кот-талисман команды"
              loading="lazy"
            />
            <h3>Кот-талисман Чип</h3>
            <p>
              Чип — наш главный инспектор. Если ему скучно на презентации, мы
              переписываем материал. Если ему интересно, клиент точно поймёт
              угрозу и не совершит опасных действий.
            </p>
          </article>
        </div>
      </div>
    </section>
  );
};

export default About;