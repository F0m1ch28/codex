import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

const ThankYou = () => {
  useEffect(() => {
    document.title = 'Спасибо! — КиберКотики';
    const description = document.querySelector('meta[name="description"]');
    if (description) {
      description.setAttribute(
        'content',
        'Спасибо за обращение! КиберКотики уже мурлычат ответ.'
      );
    }
  }, []);

  return (
    <section className="page-section thankyou-page">
      <div className="page-container thankyou-container">
        <h1>Спасибо за сообщение!</h1>
        <p>
          Наши котики уже прочитали ваш запрос, выпили кофе и приступили к составлению
          ответа. Мы свяжемся с вами очень скоро.
        </p>
        <Link to="/" className="primary-button">
          Вернуться на главную
        </Link>
      </div>
    </section>
  );
};

export default ThankYou;