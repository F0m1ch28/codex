import React, { useEffect, useState } from 'react';

const usePageMeta = (title, description) => {
  useEffect(() => {
    document.title = title;
    const descriptionTag = document.querySelector('meta[name="description"]');
    if (descriptionTag) {
      descriptionTag.setAttribute('content', description);
    } else {
      const meta = document.createElement('meta');
      meta.name = 'description';
      meta.content = description;
      document.head.appendChild(meta);
    }
  }, [title, description]);
};

const fallbackCats = [
  'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1453227588063-bb302b62f50b?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1508674861872-6d24f983f3c7?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1504208434309-cb69f4fe52b0?auto=format&fit=crop&w=800&q=80'
];

const Home = () => {
  usePageMeta(
    'КиберКотики — милота, предупреждающая о цифровых угрозах',
    'Узнай правила цифровой безопасности вместе с КиберКотиками: галерея милых котов, советы, тест и яркие предупреждения.'
  );

  const [catImages, setCatImages] = useState([]);
  const [loadingCats, setLoadingCats] = useState(true);
  const [errorCats, setErrorCats] = useState('');

  useEffect(() => {
    let isMounted = true;
    const controller = new AbortController();

    const fetchCats = async () => {
      try {
        const response = await fetch(
          'https://api.thecatapi.com/v1/images/search?limit=6&mime_types=jpg,png',
          { signal: controller.signal }
        );
        if (!response.ok) {
          throw new Error('Не удалось загрузить котиков');
        }
        const data = await response.json();
        if (isMounted) {
          setCatImages(data);
          setLoadingCats(false);
        }
      } catch (error) {
        if (isMounted) {
          setCatImages(
            fallbackCats.map((url, index) => ({ id: "fallback-${index}", url }))
          );
          setErrorCats('Не удалось загрузить котиков из API, показываем резервы.');
          setLoadingCats(false);
        }
      }
    };

    fetchCats();

    return () => {
      isMounted = false;
      controller.abort();
    };
  }, []);

  const handleCtaClick = () => {
    window.alert('Тест пройден! Вы молодец!');
  };

  return (
    <div className="home">
      <section className="hero" id="main">
        <div className="hero-overlay">
          <p className="hero-tagline">
            Ты что усвоил правила безопасности в цифровой среде?
          </p>
          <h1 className="hero-title">КИБЕРКОТИКИ НА СТРАЖЕ ТВОИХ ДАННЫХ</h1>
          <p className="hero-subtitle">
            Милые мордочки, острые коготки: мы мурлыкаем о сложном, чтобы ты
            не попался на уловки злоумышленников.
          </p>
          <div className="hero-actions">
            <a href="#warning" className="primary-button">
              Покажи предупреждение
            </a>
            <a href="#gallery" className="secondary-button">
              Хочу больше котиков
            </a>
          </div>
        </div>
      </section>

      <section className="gallery-section" id="gallery">
        <div className="section-header">
          <h2>Галерея киберкотов</h2>
          <p>
            Они милы, но их взгляд говорит: &laquo;Не кликай туда без проверок,
            человек!&raquo;
          </p>
        </div>
        {loadingCats && <p className="status-text">Загружаем пушистых экспертов...</p>}
        {!loadingCats && errorCats && (
          <p className="status-text warning-text">{errorCats}</p>
        )}
        <div className="cat-grid">
          {catImages.map((cat, index) => (
            <figure className="cat-card" key={cat.id || index}>
              <div className="cat-image-wrapper">
                <img src={cat.url} alt={"Котик эксперт №${index + 1}"} loading="lazy" />
              </div>
              <figcaption>Киберкот #{index + 1}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className="warning-section" id="warning">
        <h2>ПЕРЕХОДИТЬ ПО НЕПРОВЕРЕННЫМ ССЫЛКАМ НЕБЕЗОПАСНО</h2>
        <p>
          Даже если там обещают бесконечную ленту котов. Особенно если там
          обещают бесконечную ленту котов.
        </p>
      </section>

      <section className="info-section">
        <div className="section-header">
          <h2>Простые привычки цифровой безопасности</h2>
          <p>Коты бдят, и тебе советуют:</p>
        </div>
        <div className="info-cards">
          <article className="info-card">
            <div className="info-icon">🐾</div>
            <h3>Не переходи по подозрительным ссылкам</h3>
            <p>
              Получил письмо &laquo;от банка&raquo;? Проверь адрес отправителя и
              домен, а лучше зайди в банк из закладки.
            </p>
          </article>
          <article className="info-card">
            <div className="info-icon">😼</div>
            <h3>Проверяй URL внимательно</h3>
            <p>
              Один лишний символ может превратить сайт в ловушку. Коты замечают,
              а ты можешь пропустить.
            </p>
          </article>
          <article className="info-card">
            <div className="info-icon">🛡️</div>
            <h3>Не скачивай незнакомые файлы</h3>
            <p>
              Бесплатные обои с котятами? Возможно, вместе с ними ты установишь
              вредоносный хвостик.
            </p>
          </article>
          <article className="info-card">
            <div className="info-icon">🔑</div>
            <h3>Используй сложные пароли</h3>
            <p>
              Пароль &laquo;qwerty&raquo; взломают быстрее, чем котик успеет
              моргнуть. Генерируй и храни в менеджере паролей.
            </p>
          </article>
        </div>
      </section>

      <section className="services-highlight">
        <div className="section-header">
          <h2>Что делают наши киберкоты</h2>
          <p>
            Мы обучаем команды цифровой гигиене и защищаем данные так
            самоотверженно, как кот охраняет свою миску.
          </p>
        </div>
        <div className="service-cards">
          <article className="service-card">
            <h3>Экспресс-аудит</h3>
            <p>
              Быстрая проверка вашего цифрового дома: выявляем слабые места и
              подсказываем, где поставить дополнительную защиту.
            </p>
            <a href="/services">Подробнее</a>
          </article>
          <article className="service-card">
            <h3>Обучение для сотрудников</h3>
            <p>
              Интерактивные тренинги, где котики и реальные кейсы показывают,
              как легко попасться на фишинг.
            </p>
            <a href="/services">Подробнее</a>
          </article>
          <article className="service-card">
            <h3>24/7 киберконсьерж</h3>
            <p>
              Поддержка и мониторинг инцидентов. Если что-то подозрительное —
              котики уже спрыгнули с подоконника и мчатся.
            </p>
            <a href="/services">Подробнее</a>
          </article>
        </div>
      </section>

      <section className="testimonials-section">
        <div className="section-header">
          <h2>Отзывы тех, кто доверил данные котикам</h2>
          <p>Клиенты мурлычут от удовольствия.</p>
        </div>
        <div className="testimonials-grid">
          <figure className="testimonial-card">
            <img
              src="https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=200&q=80"
              alt="Фото клиента Анна"
            />
            <blockquote>
              «Наш отдел сразу перестал кликать на странные вложения. Даже
              директор теперь сверяется с чек-листом от КиберКотиков!»
            </blockquote>
            <figcaption>Анна, HR-директор</figcaption>
          </figure>
          <figure className="testimonial-card">
            <img
              src="https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80"
              alt="Фото клиента Максим"
            />
            <blockquote>
              «Фишинговая рассылка? Наши ребята только улыбнулись и переслали
              её котикам. Злоумышленники остались без обеда.»
            </blockquote>
            <figcaption>Максим, ИТ-руководитель</figcaption>
          </figure>
          <figure className="testimonial-card">
            <img
              src="https://images.unsplash.com/photo-1544723795-432537f11d5f?auto=format&fit=crop&w=200&q=80"
              alt="Фото клиента Ирина"
            />
            <blockquote>
              «Обучение играми с котиками — это шедевр. Сотрудники смеются и
              запоминают, что такое VPN и почему важны обновления.»
            </blockquote>
            <figcaption>Ирина, основатель стартапа</figcaption>
          </figure>
        </div>
      </section>

      <section className="cta-section" id="test">
        <p className="cta-text">ну тогда надо пройти тест снова</p>
        <button type="button" className="primary-button" onClick={handleCtaClick}>
          Начать тест заново
        </button>
      </section>
    </div>
  );
};

export default Home;