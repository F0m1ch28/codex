import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const initialFormState = {
  name: '',
  email: '',
  message: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    document.title = 'Связаться с КиберКотиками';
    const description = document.querySelector('meta[name="description"]');
    if (description) {
      description.setAttribute(
        'content',
        'Свяжитесь с командой КиберКотиков: задайте вопрос, закажите аудит или обучение по цифровой безопасности.'
      );
    }
  }, []);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, представьтесь.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Введите электронную почту.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Введите корректный адрес электронной почты.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Напишите, с чем мы можем помочь.';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Добавьте немного деталей, пожалуйста.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setFormData(initialFormState);
      navigate('/thank-you');
    }
  };

  return (
    <section className="page-section contact-page">
      <div className="page-container contact-container">
        <div className="contact-info">
          <h1>Связаться с нами</h1>
          <p>
            Расскажите, чего боятся ваши пользователи, и мы покажем, как превратить
            страх в здоровую осторожность.
          </p>
          <div className="contact-details">
            <div>
              <h4>Телефон</h4>
              <p>+7 (999) 123-45-67</p>
            </div>
            <div>
              <h4>Email</h4>
              <p>hello@cybercats.ru</p>
            </div>
            <div>
              <h4>Адрес</h4>
              <p>Москва, виртуальный офис №13</p>
            </div>
          </div>
          <p className="contact-note">
            Мы отвечаем в течение одного рабочего дня. Безопасность не терпит
            промедления — коты следят.
          </p>
        </div>

        <form className="contact-form" onSubmit={handleSubmit} noValidate>
          <label htmlFor="name">
            Имя
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={errors.name ? 'true' : 'false'}
              placeholder="Как к вам обращаться?"
            />
            {errors.name && <span className="input-error">{errors.name}</span>}
          </label>

          <label htmlFor="email">
            Электронная почта
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={errors.email ? 'true' : 'false'}
              placeholder="example@domain.ru"
            />
            {errors.email && <span className="input-error">{errors.email}</span>}
          </label>

          <label htmlFor="message">
            Сообщение
            <textarea
              id="message"
              name="message"
              rows="6"
              value={formData.message}
              onChange={handleChange}
              aria-required="true"
              aria-invalid={errors.message ? 'true' : 'false'}
              placeholder="Опишите задачу, тревогу или запрос"
            />
            {errors.message && (
              <span className="input-error">{errors.message}</span>
            )}
          </label>

          <button type="submit" className="primary-button">
            Отправить и получить мурчащий ответ
          </button>
        </form>
      </div>
    </section>
  );
};

export default Contact;