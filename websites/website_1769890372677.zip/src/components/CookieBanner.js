import React, { useEffect, useState } from 'react';

const storageKey = 'cybercats-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      const storedConsent = localStorage.getItem(storageKey);
      if (!storedConsent) {
        setVisible(true);
      }
    } catch (error) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    try {
      localStorage.setItem(storageKey, 'accepted');
    } catch (error) {
      // ignore storage errors
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <p>
        Мы используем файлы cookie, чтобы котики подмигивали вовремя, а ваши
        данные оставались в безопасности. Продолжая, вы соглашаетесь с нашей{' '}
        <a href="/cookie-policy">политикой использования cookie</a>.
      </p>
      <button type="button" onClick={acceptCookies}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;