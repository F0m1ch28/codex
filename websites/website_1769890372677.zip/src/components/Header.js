import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

const Header = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const closeMenu = () => setMobileOpen(false);

  const handleAnchorClick = (event, targetId) => {
    event.preventDefault();
    const scrollToTarget = () => {
      const target = document.getElementById(targetId);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    };

    if (location.pathname !== '/') {
      navigate('/');
      setTimeout(() => {
        scrollToTarget();
      }, 150);
    } else {
      scrollToTarget();
    }
    closeMenu();
  };

  return (
    <header className="header">
      <div className="header-inner">
        <Link to="/" className="logo" onClick={closeMenu}>
          Кибер<span>Котики</span>
        </Link>
        <button
          type="button"
          className="burger-button"
          aria-label="Меню"
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={"nav ${mobileOpen ? 'nav-open' : ''}"}>
          <a
            href="#main"
            onClick={(event) => handleAnchorClick(event, 'main')}
            className="nav-link"
          >
            Главная
          </a>
          <a
            href="#warning"
            onClick={(event) => handleAnchorClick(event, 'warning')}
            className="nav-link"
          >
            Предупреждение
          </a>
          <a
            href="#test"
            onClick={(event) => handleAnchorClick(event, 'test')}
            className="nav-link"
          >
            Тест
          </a>
          <Link to="/about" className="nav-link" onClick={closeMenu}>
            О проекте
          </Link>
          <Link to="/services" className="nav-link" onClick={closeMenu}>
            Услуги
          </Link>
          <Link to="/contact" className="nav-link nav-cta" onClick={closeMenu}>
            Связаться
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;