import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="footer">
    <div className="footer-inner">
      <div className="footer-column">
        <h3>КиберКотики</h3>
        <p>
          Милые мордочки, но очень серьезное отношение к вашей цифровой
          безопасности.
        </p>
        <div className="footer-socials">
          <a
            href="https://www.instagram.com"
            target="_blank"
            rel="noopener noreferrer"
          >
            🐾 Instagram
          </a>
          <a
            href="https://www.youtube.com"
            target="_blank"
            rel="noopener noreferrer"
          >
            🎬 YouTube
          </a>
          <a
            href="https://t.me"
            target="_blank"
            rel="noopener noreferrer"
          >
            ✉️ Telegram
          </a>
        </div>
      </div>
      <div className="footer-column">
        <h4>Навигация</h4>
        <Link to="/">Главная</Link>
        <Link to="/about">О проекте</Link>
        <Link to="/services">Услуги</Link>
        <Link to="/contact">Контакты</Link>
      </div>
      <div className="footer-column">
        <h4>Юридическое</h4>
        <Link to="/terms">Условия использования</Link>
        <Link to="/privacy">Политика конфиденциальности</Link>
        <Link to="/cookie-policy">Политика Cookie</Link>
      </div>
      <div className="footer-column">
        <h4>Контакты</h4>
        <Link to="/contact" className="footer-contact-link">
          +7 (999) 123-45-67
        </Link>
        <Link to="/contact" className="footer-contact-link">
          hello@cybercats.ru
        </Link>
        <p>Москва, виртуальный офис №13</p>
      </div>
    </div>
    <div className="footer-bottom">
      <p>© {new Date().getFullYear()} КиберКотики. Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;