document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const mainNav = document.querySelector(".main-nav");
    if (navToggle && mainNav) {
        navToggle.addEventListener("click", () => {
            mainNav.classList.toggle("open");
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptCookies = document.getElementById("accept-cookies");
    const declineCookies = document.getElementById("decline-cookies");
    const cookieKey = "gcw_cookie_choice_v1";
    if (cookieBanner) {
        const storedChoice = localStorage.getItem(cookieKey);
        if (!storedChoice) {
            cookieBanner.classList.add("active");
        }
        const closeBanner = (choice) => {
            localStorage.setItem(cookieKey, choice);
            cookieBanner.classList.remove("active");
        };
        if (acceptCookies) {
            acceptCookies.addEventListener("click", () => closeBanner("accept"));
        }
        if (declineCookies) {
            declineCookies.addEventListener("click", () => closeBanner("decline"));
        }
    }

    const ticker = document.querySelector(".ticker-track");
    if (ticker) {
        ticker.addEventListener("mouseenter", () => {
            ticker.style.animationPlayState = "paused";
        });
        ticker.addEventListener("mouseleave", () => {
            ticker.style.animationPlayState = "running";
        });
    }

    const decadeFilter = document.getElementById("timeline-filter");
    const timelineEntries = document.querySelectorAll(".timeline-entry");
    if (decadeFilter && timelineEntries.length > 0) {
        decadeFilter.addEventListener("change", (event) => {
            const value = event.target.value;
            timelineEntries.forEach((entry) => {
                const decade = entry.getAttribute("data-decade");
                if (!value || value === "all" || decade === value) {
                    entry.style.display = "";
                } else {
                    entry.style.display = "none";
                }
            });
        });
    }

    const modalTriggers = document.querySelectorAll("[data-modal-target]");
    const modalCloseButtons = document.querySelectorAll(".modal-close");
    modalTriggers.forEach((button) => {
        button.addEventListener("click", () => {
            const targetId = button.getAttribute("data-modal-target");
            const modal = document.getElementById(targetId);
            if (modal) {
                modal.classList.add("active");
                document.body.style.overflow = "hidden";
            }
        });
    });
    modalCloseButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const modal = button.closest(".modal");
            if (modal) {
                modal.classList.remove("active");
                document.body.style.overflow = "";
            }
        });
    });
    document.addEventListener("click", (event) => {
        if (event.target.classList.contains("modal")) {
            event.target.classList.remove("active");
            document.body.style.overflow = "";
        }
    });

    const lightboxOverlay = document.querySelector(".lightbox-overlay");
    const lightboxImage = document.getElementById("lightbox-image");
    const lightboxCaption = document.getElementById("lightbox-caption");
    const galleryItems = document.querySelectorAll("[data-lightbox]");
    if (lightboxOverlay && lightboxImage && lightboxCaption) {
        galleryItems.forEach((item) => {
            item.addEventListener("click", (event) => {
                event.preventDefault();
                const imageSrc = item.getAttribute("href");
                const caption = item.getAttribute("data-caption") || "";
                lightboxImage.setAttribute("src", imageSrc);
                lightboxCaption.textContent = caption;
                lightboxOverlay.classList.add("active");
                document.body.style.overflow = "hidden";
            });
        });
        const closeLightbox = () => {
            lightboxOverlay.classList.remove("active");
            lightboxImage.setAttribute("src", "");
            document.body.style.overflow = "";
        };
        lightboxOverlay.addEventListener("click", (event) => {
            if (event.target.classList.contains("lightbox-overlay") || event.target.classList.contains("lightbox-close")) {
                closeLightbox();
            }
        });
    }

    const filterControls = document.querySelectorAll("[data-filter-group]");
    filterControls.forEach((control) => {
        const buttons = control.querySelectorAll("[data-filter]");
        const targetSelector = control.getAttribute("data-target");
        const items = document.querySelectorAll(targetSelector);
        buttons.forEach((btn) => {
            btn.addEventListener("click", () => {
                const filterValue = btn.getAttribute("data-filter");
                buttons.forEach((b) => b.classList.remove("active"));
                btn.classList.add("active");
                items.forEach((item) => {
                    if (filterValue === "all" || item.getAttribute("data-category") === filterValue) {
                        item.style.display = "";
                    } else {
                        item.style.display = "none";
                    }
                });
            });
        });
    });

    const accordionHeaders = document.querySelectorAll(".accordion-header");
    accordionHeaders.forEach((header) => {
        header.addEventListener("click", () => {
            const item = header.parentElement;
            item.classList.toggle("active");
        });
    });

    const currentPath = window.location.pathname.split("/").pop() || "index.html";
    const navLinks = document.querySelectorAll(".main-nav a");
    navLinks.forEach((link) => {
        if (link.getAttribute("href") === currentPath) {
            link.classList.add("active");
        }
    });
});