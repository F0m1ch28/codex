import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Projects from './pages/Projects';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

function App() {
  return (
    <>
      <a href="#hauptinhalt" className="skip-link">
        Direkt zum Inhalt springen
      </a>
      <Header />
      <ScrollToTop />
      <CookieBanner />
      <main id="hauptinhalt" className="main-content" role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ueber-uns" element={<About />} />
          <Route path="/leistungen" element={<Services />} />
          <Route path="/projekte" element={<Projects />} />
          <Route path="/kontakt" element={<Contact />} />
          <Route path="/nutzungsbedingungen" element={<Terms />} />
          <Route path="/datenschutz" element={<Privacy />} />
          <Route path="/cookie-richtlinie" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
    </>
  );
}

export default App;