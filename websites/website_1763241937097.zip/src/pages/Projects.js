import React, { useMemo, useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './Projects.module.css';

const projectData = [
  {
    id: 1,
    title: 'Logistikzentrum Nürnberg',
    category: 'Gewerbe',
    description:
      '1,2 MWp Aufdachanlage inklusive 120 kWh Speicher und intelligenter Laststeuerung. Einsparung von 62 % der Stromkosten.',
    metrics: ['1,2 MWp', '8.500 m² Dachfläche', 'CO₂-Einsparung 980 t/Jahr'],
    image: 'https://picsum.photos/1200/800?random=401'
  },
  {
    id: 2,
    title: 'Wohnquartier „IsarWohnen“',
    category: 'Wohnbau',
    description:
      'Mieterstrommodell mit 85 kWp PV, Speicher und Wallboxen. Intuitive Abrechnungslösung und 30 % günstigere Stromtarife.',
    metrics: ['85 kWp', '32 Wohneinheiten', 'Smart Metering'],
    image: 'https://picsum.photos/1200/800?random=402'
  },
  {
    id: 3,
    title: 'Biohof Seebauer',
    category: 'Landwirtschaft',
    description:
      'Hybridlösung aus Dach- und Freiflächenanlage mit 45 kWh Speicher für Stall und Direktvermarktung.',
    metrics: ['210 kWp', 'Autarkiegrad 78 %', 'Speicher 45 kWh'],
    image: 'https://picsum.photos/1200/800?random=403'
  },
  {
    id: 4,
    title: 'Stadtwerke Dachau',
    category: 'Kommunal',
    description:
      'Bündelprojekt von sieben kommunalen Gebäuden mit insgesamt 420 kWp PV und Ladeinfrastruktur.',
    metrics: ['420 kWp', '70 Ladepunkte', '100 % Ökostrom'],
    image: 'httpsum.photos/1200/800?random=404'
  },
  {
    id: 5,
    title: 'Hotel Alpenlicht',
    category: 'Tourismus',
    description:
      'PV-Fassade in Kombination mit Dachanlage für Hotelbetrieb. Integration in das Gebäudedesign und Energiekonzept.',
    metrics: ['95 kWp', 'Fassade & Dach', 'Energieeinsparung 58 %'],
    image: 'https://picsum.photos/1200/800?random=405'
  },
  {
    id: 6,
    title: 'Rechenzentrum Ingolstadt',
    category: 'Gewerbe',
    description:
      'Hochverfügbare PV-Anlage mit Redundanzkonzept und dynamischer Netzeinspeisung für ein mittelständisches Rechenzentrum.',
    metrics: ['650 kWp', '3,2 GWh Jahresproduktion', 'Monitoring 24/7'],
    image: 'https://picsum.photos/1200/800?random=406'
  }
];

const categories = ['Alle', 'Wohnbau', 'Gewerbe', 'Landwirtschaft', 'Kommunal', 'Tourismus'];

const Projects = () => {
  const [activeCategory, setActiveCategory] = useState('Alle');
  const [selectedProject, setSelectedProject] = useState(null);

  useEffect(() => {
    if (!selectedProject) return undefined;
    const handleKeyDown = (event) => {
      if (event.key === 'Escape') {
        setSelectedProject(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedProject]);

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'Alle') {
      return projectData;
    }
    return projectData.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  return (
    <>
      <Helmet>
        <title>Projekte & Referenzen | GreenTech Solutions</title>
        <meta
          name="description"
          content="Entdecken Sie ausgewählte Referenzprojekte von GreenTech Solutions: Wohnbau, Gewerbe, Landwirtschaft und kommunale PV-Anlagen."
        />
        <link rel="canonical" href="https://www.greentech-solutions.de/projekte" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.heroBadge}>Referenzen</span>
            <h1>Solarprojekte, die Maßstäbe setzen</h1>
            <p>
              Mehr als 800 Anlagen haben wir in Bayern realisiert. Hier finden Sie eine Auswahl unserer Lieblingsprojekte
              – vom Mehrfamilienhaus bis zur gewerblichen Großanlage.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <div className={styles.filterBar} role="toolbar" aria-label="Projektkategorien filtern">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.activeFilter : ''
                }`}
                onClick={() => setActiveCategory(category)}
                aria-pressed={activeCategory === category}
              >
                {category}
              </button>
            ))}
          </div>

          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <button
                key={project.id}
                type="button"
                className={styles.projectCard}
                onClick={() => setSelectedProject(project)}
                aria-label={`Projekt ${project.title} ansehen`}
              >
                <div
                  className={styles.projectImage}
                  style={{ backgroundImage: `url(${project.image})` }}
                  aria-hidden="true"
                />
                <div className={styles.projectBody}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <ul>
                    {project.metrics.map((metric) => (
                      <li key={metric}>{metric}</li>
                    ))}
                  </ul>
                  <span className={styles.projectMore}>Details ansehen</span>
                </div>
              </button>
            ))}
          </div>

          <div className={styles.cta}>
            <h2>Ihr Projekt verdient einen erfahrenen Partner</h2>
            <p>
              Wir begleiten Sie von der ersten Idee bis zum laufenden Betrieb Ihrer Photovoltaikanlage. Lassen Sie uns über
              Ihre Anforderungen sprechen.
            </p>
            <Link className="btn btn-primary" to="/kontakt">
              Projekt anfragen
            </Link>
          </div>
        </div>
      </section>

      {selectedProject && (
        <div className={styles.modal} role="dialog" aria-modal="true">
          <div className={styles.modalContent}>
            <button
              type="button"
              className={styles.modalClose}
              onClick={() => setSelectedProject(null)}
              aria-label="Projektansicht schließen"
            >
              ×
            </button>
            <div
              className={styles.modalImage}
              style={{ backgroundImage: `url(${selectedProject.image})` }}
              aria-hidden="true"
            />
            <div className={styles.modalBody}>
              <span className={styles.projectCategory}>{selectedProject.category}</span>
              <h3>{selectedProject.title}</h3>
              <p>{selectedProject.description}</p>
              <ul>
                {selectedProject.metrics.map((metric) => (
                  <li key={metric}>{metric}</li>
                ))}
              </ul>
              <p className={styles.modalHint}>
                Interessiert an einem ähnlichen Projekt? Wir stellen Ihnen gerne detaillierte Case Studies zur Verfügung.
              </p>
              <Link className="btn btn-secondary" to="/kontakt" onClick={() => setSelectedProject(null)}>
                Gespräch vereinbaren
              </Link>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Projects;