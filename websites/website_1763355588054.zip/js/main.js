document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelector(".nav-links");
  const navAnchors = document.querySelectorAll('.nav-links a[href^="#"], a[href^="index.html#"]');
  const sections = document.querySelectorAll("section[id]");
  const cookieBanner = document.querySelector(".cookie-banner");
  const cookieDismiss = document.getElementById("cookie-dismiss");
  const floatingButtons = document.querySelectorAll(".floating-btn");
  const forms = document.querySelectorAll(".signup-form, .contact-form");
  const currentYear = document.getElementById("current-year");
  const storageKey = "swiftlaunch-cookie-consent";

  if (currentYear) {
    currentYear.textContent = new Date().getFullYear();
  }

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
      navToggle.setAttribute("aria-expanded", !expanded);
      navLinks.classList.toggle("open");
    });
  }

  navAnchors.forEach(anchor => {
    anchor.addEventListener("click", event => {
      const href = anchor.getAttribute("href");
      if (href.startsWith("#")) {
        event.preventDefault();
        const target = document.querySelector(href);
        if (target) {
          target.scrollIntoView({ behavior: "smooth" });
        }
        if (navLinks.classList.contains("open")) {
          navLinks.classList.remove("open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      } else if (href.includes("index.html#")) {
        const targetId = href.split("#")[1];
        if (window.location.pathname.endsWith("index.html") || window.location.pathname === "/" || window.location.pathname === "/index.html") {
          event.preventDefault();
          const target = document.getElementById(targetId);
          if (target) {
            target.scrollIntoView({ behavior: "smooth" });
          }
          navLinks.classList.remove("open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      }
    });
  });

  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        const id = entry.target.getAttribute("id");
        const navLink = document.querySelector(`.nav-links a[href="#${id}"]`);
        if (navLink) {
          if (entry.isIntersecting) {
            navAnchors.forEach(link => link.classList.remove("active"));
            navLink.classList.add("active");
          }
        }
      });
    }, {
      threshold: 0.5
    });

    sections.forEach(section => observer.observe(section));
  }

  if (localStorage.getItem(storageKey) === "acknowledged") {
    cookieBanner?.classList.add("hidden");
  }

  cookieDismiss?.addEventListener("click", () => {
    cookieBanner?.classList.add("hidden");
    localStorage.setItem(storageKey, "acknowledged");
  });

  floatingButtons.forEach(button => {
    button.addEventListener("focus", () => button.classList.add("focused"));
    button.addEventListener("blur", () => button.classList.remove("focused"));
  });

  forms.forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      const requiredFields = form.querySelectorAll("[required]");
      let valid = true;

      requiredFields.forEach(field => {
        if (!field.value.trim()) {
          valid = false;
          field.classList.add("input-error");
        } else {
          field.classList.remove("input-error");
        }

        if (field.type === "email" && !/^\S+@\S+\.\S+$/.test(field.value.trim())) {
          valid = false;
          field.classList.add("input-error");
        }
      });

      if (valid) {
        const successMessage = document.createElement("p");
        successMessage.className = "form-hint";
        successMessage.textContent = "Thanks! We’ll be in touch shortly.";
        form.replaceWith(successMessage);
      }
    });
  });
});