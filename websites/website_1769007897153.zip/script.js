document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-active');
            siteNav.classList.toggle('is-open');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('[data-cookie-action]');
    const cookieKey = 'cge_cookie_preference';

    if (cookieBanner) {
        const stored = localStorage.getItem(cookieKey);
        if (!stored) {
            cookieBanner.classList.add('is-visible');
        }
        cookieButtons.forEach(button => {
            button.addEventListener('click', () => {
                const action = button.dataset.cookieAction;
                localStorage.setItem(cookieKey, action);
                cookieBanner.classList.remove('is-visible');
            });
        });
    }

    const mapButtons = document.querySelectorAll('.map-marker');
    const mapInfo = document.getElementById('mapInfo');
    const regionData = {
        andalucia: {
            title: 'Andalucía: oficios y huertas',
            text: 'Andalucía combina cultivos de olivar, hortalizas tempranas y artes de pesca artesanal. Las ferias de agroalimentación de Córdoba y Sevilla documentan recetas con azahar, almendras y especias. En la Sierra de Cádiz se conservan procesos de quesería y en Huelva se registran curaciones de jamones con microclimas únicos.'
        },
        aragon: {
            title: 'Aragón: sotos del Ebro',
            text: 'La geografía de Aragón aporta trufas del Moncayo, ternasco con indicación geográfica y hortalizas de las huertas de Zaragoza. Los archivos de cofradías reflejan cómo se preservan recetas de migas y guisos de caza.'
        },
        asturias: {
            title: 'Asturias: litoral y montaña',
            text: 'Los registros de la sidra natural, quesos afinados en cuevas y fabada se entrelazan con rutas de pastores. Los concejos mantienen recetarios celebrados en espichas y festivales marinos.'
        },
        baleares: {
            title: 'Illes Balears: tradición insular',
            text: 'El recetario insular conserva ensaimadas, sobrasada, cocas vegetales y platos marineros. Los conventos de Palma archivan manuscritos sobre repostería y las cofradías pescadoras documentan técnicas de salazón.'
        },
        canarias: {
            title: 'Canarias: volcanes nutritivos',
            text: 'El gofio, los mojos y los quesos de cabra se combinan con cultivos subtropicales. Las actas de cabildos registran la importancia del agua en terrazas y el rescate de variedades autóctonas de papa.'
        },
        cantabria: {
            title: 'Cantabria: verde infinito',
            text: 'La cocina cántabra reúne sobaos, quesadas y guisos marineros. Los valles pasiegos conservan cuadernos de mantequeras y el litoral documenta artes de cerco y marisqueo sostenible.'
        },
        castillaleon: {
            title: 'Castilla y León: meseta cerealista',
            text: 'Las rutas del pan, el lechazo y las legumbres estructuran la gastronomía castellana. Los archivos catedralicios guardan registros de ferias agrícolas y celebraciones patronales vinculadas a la cosecha.'
        },
        castillamancha: {
            title: 'Castilla-La Mancha: campos de azafrán',
            text: 'Los molinos de viento, las tinajas y el azafrán caracterizan la identidad manchega. Los Consejos Reguladores preservan información sobre quesos, mieles y caza menor.'
        },
        cataluna: {
            title: 'Cataluña: cuina del país',
            text: 'La cuina catalana combina mar y montaña. Los cuadernos de pescadores de la Costa Brava y las tradiciones de calçots en Valls forman parte del patrimonio documentado.'
        },
        comunidadvalenciana: {
            title: 'Comunidad Valenciana: huerta y mar',
            text: 'Arroz, cítricos y pescados azules protagonizan la mesa valenciana. Las cofradías marinas registran técnicas de almadraba y los agricultores documentan riegos históricos en la huerta.'
        },
        extremadura: {
            title: 'Extremadura: dehesas y charcas',
            text: 'La dehesa produce embutidos curados, quesos de leche cruda y caldos tradicionales. Los archivos agrarios conservan la historia de cooperativas olivareras y rutas trashumantes.'
        },
        galicia: {
            title: 'Galicia: mar de fogones',
            text: 'Las rías gallegas aportan marisco, pescado y salazones. La cocina interior incorpora castañas, lacón con grelos y empanadas. Los museos etnográficos recogen testimonios sobre hornos comunales.'
        },
        larioja: {
            title: 'La Rioja: huerta y sarmientos',
            text: 'Verduras asadas, patatas a la riojana y embutidos definen la gastronomía. Las cofradías mantienen recetarios manuscritos y los archivos agrícolas documentan técnicas de riego por acequias.'
        },
        madrid: {
            title: 'Comunidad de Madrid: cruce de sabores',
            text: 'La cocina madrileña integra cocidos, bocadillos emblemáticos y repostería conventual. Los archivos municipales guardan reglamentos de restaurantes centenarios y ferias de San Isidro.'
        },
        murcia: {
            title: 'Región de Murcia: huertas fértiles',
            text: 'Las verduras de la huerta, los caldos con pescados del Mar Menor y los pasteles de carne marcan la identidad. Las cooperativas hortícolas poseen registros sobre variedades y técnicas de conservación.'
        },
        navarra: {
            title: 'Comunidad Foral de Navarra: diversidad climática',
            text: 'Desde espárragos hasta pacharán artesanal, Navarra combina productos de montaña y ribera. Las sociedades gastronómicas documentan menús tradicionales en sus libros de actas.'
        },
        paisvasco: {
            title: 'Euskadi: sociedades gastronómicas',
            text: 'La cocina vasca resalta pintxos, bacalao y txakoli. Las sociedades gastronómicas conservan actas de concursos y recetarios transmitidos entre generaciones.'
        }
    };

    if (mapButtons.length && mapInfo) {
        mapButtons.forEach(button => {
            button.addEventListener('click', () => {
                mapButtons.forEach(b => b.classList.remove('is-active'));
                button.classList.add('is-active');
                const data = regionData[button.dataset.region];
                if (data) {
                    mapInfo.innerHTML = `<h4>${data.title}</h4><p>${data.text}</p>`;
                }
            });
        });
    }

    const filterButtons = document.querySelectorAll('.filter-button');
    const ingredientCards = document.querySelectorAll('.ingredient-card');

    if (filterButtons.length && ingredientCards.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const filter = button.dataset.filter;
                filterButtons.forEach(b => b.setAttribute('aria-pressed', 'false'));
                button.setAttribute('aria-pressed', 'true');
                ingredientCards.forEach(card => {
                    if (filter === 'todos' || card.dataset.category === filter) {
                        card.style.display = 'grid';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }

    const galleryImages = document.querySelectorAll('.gallery-image');
    const lightbox = document.getElementById('lightbox');
    const lightboxImage = document.getElementById('lightboxImage');
    const lightboxCaption = document.getElementById('lightboxCaption');
    const lightboxClose = document.getElementById('lightboxClose');

    if (galleryImages.length && lightbox && lightboxImage && lightboxCaption && lightboxClose) {
        galleryImages.forEach(image => {
            image.addEventListener('click', () => {
                lightboxImage.src = image.src;
                lightboxImage.alt = image.alt;
                lightboxCaption.textContent = image.dataset.caption || image.alt;
                lightbox.classList.add('is-visible');
            });
        });
        lightboxClose.addEventListener('click', () => {
            lightbox.classList.remove('is-visible');
        });
        lightbox.addEventListener('click', (event) => {
            if (event.target === lightbox) {
                lightbox.classList.remove('is-visible');
            }
        });
    }

    const modalOverlay = document.getElementById('modalOverlay');
    const modalContentArea = modalOverlay ? modalOverlay.querySelector('.modal-content-area') : null;
    const modalClose = modalOverlay ? modalOverlay.querySelector('.modal-close') : null;
    const modalTriggers = document.querySelectorAll('.modal-trigger');

    if (modalOverlay && modalContentArea && modalClose && modalTriggers.length) {
        modalTriggers.forEach(trigger => {
            trigger.addEventListener('click', () => {
                const targetId = trigger.dataset.modal;
                const template = document.getElementById(targetId);
                if (template) {
                    modalContentArea.innerHTML = template.innerHTML;
                    modalOverlay.classList.add('is-visible');
                }
            });
        });
        modalClose.addEventListener('click', () => {
            modalOverlay.classList.remove('is-visible');
        });
        modalOverlay.addEventListener('click', (event) => {
            if (event.target === modalOverlay) {
                modalOverlay.classList.remove('is-visible');
            }
        });
    }

    const accordionItems = document.querySelectorAll('.accordion-item');
    if (accordionItems.length) {
        accordionItems.forEach(item => {
            const trigger = item.querySelector('.accordion-trigger');
            const content = item.querySelector('.accordion-content');
            if (trigger && content) {
                trigger.addEventListener('click', () => {
                    const isOpen = item.classList.contains('is-open');
                    accordionItems.forEach(i => {
                        i.classList.remove('is-open');
                        const innerContent = i.querySelector('.accordion-content');
                        if (innerContent) {
                            innerContent.style.maxHeight = null;
                        }
                    });
                    if (!isOpen) {
                        item.classList.add('is-open');
                        content.style.maxHeight = `${content.scrollHeight}px`;
                    }
                });
            }
        });
    }

    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', (event) => {
            const consent = form.querySelector('input[type="checkbox"][name="consentimiento"]');
            if (consent && !consent.checked) {
                event.preventDefault();
                alert('Por favor, confirma el consentimiento para continuar.');
            }
        });
    });
});