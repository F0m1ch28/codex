document.addEventListener('DOMContentLoaded', function () {
    var banner = document.getElementById('cookieBanner');
    if (!banner) {
        return;
    }

    var storedChoice = localStorage.getItem('gcqgCookieChoice');
    if (storedChoice) {
        banner.classList.add('hidden');
        return;
    }

    var buttons = banner.querySelectorAll('.cookie-btn');
    buttons.forEach(function (button) {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            var choice = button.dataset.choice || 'undecided';
            localStorage.setItem('gcqgCookieChoice', choice);
            banner.classList.add('hidden');
            var destination = button.getAttribute('href');
            if (destination) {
                setTimeout(function () {
                    window.location.href = destination;
                }, 100);
            }
        });
    });
});