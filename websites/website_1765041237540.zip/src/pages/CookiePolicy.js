import React, { useEffect } from 'react';

const CookiePolicyPage = () => {
  useEffect(() => {
    const pageTitle = 'Політика cookies Dog Training Expert';
    const pageDescription =
      'Політика використання cookies на сайті Dog Training Expert: типи файлів cookies, мета їх використання та налаштування користувачем.';
    const pageKeywords =
      'політика cookies, налаштування cookies, аналітика сайту, Dog Training Expert, технології сайту';
    document.title = pageTitle;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', pageDescription);
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', pageKeywords);
  }, []);

  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Політика cookies</h1>
        </div>
      </section>
      <section className="legal-section">
        <div className="container legal-content">
          <h2>1. Що таке cookies</h2>
          <p>
            Cookies — невеликі текстові файли, що зберігаються на вашому пристрої для покращення взаємодії з сайтом та аналізу
            роботи ресурсу.
          </p>

          <h2>2. Типи cookies</h2>
          <ul className="checklist">
            <li><strong>Необхідні:</strong> забезпечують коректне відображення сторінок.</li>
            <li><strong>Аналітичні:</strong> допомагають зрозуміти, як користувачі взаємодіють із сайтом.</li>
            <li><strong>Функціональні:</strong> зберігають ваші налаштування, наприклад вибір мови.</li>
          </ul>

          <h2>3. Керування cookies</h2>
          <p>
            Ви можете дозволити або заборонити використання cookies через банер на сайті або змінити налаштування браузера.
            Відключення деяких cookies може вплинути на роботу окремих функцій.
          </p>
        </div>
      </section>
    </div>
  );
};

export default CookiePolicyPage;