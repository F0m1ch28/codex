import React, { useEffect, useState } from 'react';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    city: 'Варшава',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [statusMessage, setStatusMessage] = useState('');

  useEffect(() => {
    const pageTitle = 'Контакти Dog Training Expert — Варшава та Краків';
    const pageDescription =
      'Зв’яжіться з Dog Training Expert: адреси у Варшаві та Кракові, телефон +48 123 456 789, email info@dogtrainingexpert.pl. Запишіться на консультацію з дресирування.';
    const pageKeywords =
      'контакти Dog Training Expert, дресирування собак Варшава, дресирування собак Краків, консультація кінолога, запис на тренування';
    document.title = pageTitle;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', pageDescription);
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', pageKeywords);
  }, []);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
    setStatusMessage('');
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Вкажіть ваше ім’я.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Вкажіть електронну пошту.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Вкажіть дійсну електронну пошту.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Опишіть запит або питання.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setStatusMessage('Дякуємо! Ми зв’яжемося з вами найближчим часом, щоб узгодити консультацію.');
    setFormData({
      name: '',
      email: '',
      phone: '',
      city: 'Варшава',
      message: ''
    });
  };

  return (
    <div className="page contact-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Контакти Dog Training Expert</h1>
          <p>Ми працюємо у Варшаві та Кракові, проводимо виїзні уроки і онлайн-консультації для власників.</p>
        </div>
      </section>

      <section className="contact-details-section">
        <div className="container contact-grid">
          <div className="contact-card">
            <h2>Зверніться до нас</h2>
            <ul className="contact-list">
              <li><strong>Телефон:</strong> <a href="tel:+48123456789">+48 123 456 789</a></li>
              <li><strong>Email:</strong> <a href="mailto:info@dogtrainingexpert.pl">info@dogtrainingexpert.pl</a></li>
            </ul>
            <div className="contact-locations">
              <div>
                <h3>Варшава</h3>
                <p>ул. Собакова 15, 00-001</p>
              </div>
              <div>
                <h3>Краків</h3>
                <p>ул. Паська 8, 30-001</p>
              </div>
            </div>
            <p>
              Рекомендуємо записатися на попередню консультацію, щоб узгодити очікування, визначити програму та графік тренувань.
            </p>
          </div>
          <div className="contact-card">
            <h2>Запис на консультацію</h2>
            <form onSubmit={handleSubmit} noValidate>
              <label htmlFor="name">Ваше ім’я</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className="form-error">{errors.name}</span>}

              <label htmlFor="email">Електронна пошта</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className="form-error">{errors.email}</span>}

              <label htmlFor="phone">Телефон (за бажанням)</label>
              <input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
              />

              <label htmlFor="city">Місто</label>
              <select id="city" name="city" value={formData.city} onChange={handleChange}>
                <option value="Варшава">Варшава</option>
                <option value="Краків">Краків</option>
              </select>

              <label htmlFor="message">Опишіть ваш запит</label>
              <textarea
                id="message"
                name="message"
                rows="4"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span className="form-error">{errors.message}</span>}

              <button type="submit" className="btn-primary">Надіслати</button>
              {statusMessage && <p className="form-success">{statusMessage}</p>}
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;