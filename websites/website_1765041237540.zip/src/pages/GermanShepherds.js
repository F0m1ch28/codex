import React, { useEffect } from 'react';

const GermanShepherdsPage = () => {
  useEffect(() => {
    const pageTitle = 'Німецькі вівчарки — спеціалізація Dog Training Expert';
    const pageDescription =
      'Dog Training Expert спеціалізується на німецьких вівчарках: розкриваємо робочі якості, коригуємо поведінку, готуємо до спорту, служби та сімейного життя.';
    const pageKeywords =
      'німецкі вівчарки дресирування, тренування вівчарок, робочі якості вівчарок, соціалізація вівчарок, Dog Training Expert';
    document.title = pageTitle;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', pageDescription);
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', pageKeywords);
  }, []);

  return (
    <div className="page german-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Німецькі вівчарки — наша спеціалізація</h1>
          <p>
            Ми працюємо саме з цією породою, бо знаємо, як поєднати її харизму, інтелект та робочий темперамент. Наша мета —
            сформувати керовану, соціальну й гармонійну собаку, яка реалізує свої природні здібності.
          </p>
        </div>
      </section>

      <section className="breed-details">
        <div className="container breed-detail-grid">
          <div>
            <h2>Що потрібно німецькій вівчарці</h2>
            <p>
              Собаці цієї породи важливо регулярно працювати з ментальним навантаженням, мати чіткі правила і отримувати емоційний
              контакт із власником. Без цього вони можуть шукати вихід енергії у небажаній поведінці.
            </p>
            <ul className="checklist">
              <li>Розумні щоденні завдання та вправи</li>
              <li>Послідовний підхід до правил удома і на прогулянці</li>
              <li>Розвиток нюху, фізичної витривалості та самоконтролю</li>
            </ul>
          </div>
          <div className="breed-focus">
            <h3>Наш фокус</h3>
            <p>
              Ми готуємо вівчарок до різних ролей: сімейний компаньйон, охоронець, спортивний партнер чи службова собака. У кожному
              разі важливі спільні елементи: стабільна психіка, готовність до співпраці, повага до власника.
            </p>
          </div>
        </div>
      </section>

      <section className="breed-programs">
        <div className="container">
          <h2>Програми спеціально для вівчарок</h2>
          <div className="program-grid">
            <article>
              <h3>Старт для цуценят</h3>
              <p>Побудова контакту, соціалізація, формування базових команд і щоденних ритуалів для малюків від 3 місяців.</p>
            </article>
            <article>
              <h3>Підлітковий вік</h3>
              <p>Допомога у період зміни характеру, керування енергією, фокус на витримці та дисципліні.</p>
            </article>
            <article>
              <h3>Дорослі собаки</h3>
              <p>
                Підвищений рівень складності, підтримка охоронних функцій, спортивні та службові задачі з контролем поведінки.
              </p>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
};

export default GermanShepherdsPage;