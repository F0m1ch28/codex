import React, { useEffect } from 'react';

const PrivacyPage = () => {
  useEffect(() => {
    const pageTitle = 'Політика конфіденційності Dog Training Expert';
    const pageDescription =
      'Політика конфіденційності Dog Training Expert: які дані ми збираємо, як їх використовуємо та як захищаємо.';
    const pageKeywords =
      'політика конфіденційності, захист даних, персональні дані, Dog Training Expert, дресирування собак конфіденційність';
    document.title = pageTitle;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', pageDescription);
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', pageKeywords);
  }, []);

  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Політика конфіденційності</h1>
        </div>
      </section>
      <section className="legal-section">
        <div className="container legal-content">
          <h2>1. Збір даних</h2>
          <p>
            Dog Training Expert збирає ім’я, електронну адресу, номер телефону та інформацію, яку ви добровільно залишаєте у формі
            звʼязку. Дані використовуються лише для відповіді на запит і планування тренувань.
          </p>

          <h2>2. Зберігання та захист</h2>
          <p>
            Дані зберігаються у захищених системах з обмеженим доступом. Ми застосовуємо технічні та організаційні заходи для
            запобігання несанкціонованому доступу.
          </p>

          <h2>3. Передача третім сторонам</h2>
          <p>
            Ми не передаємо ваші дані третім особам без вашої згоди, крім випадків, коли цього вимагає законодавство Польщі або
            міжнародні норми.
          </p>

          <h2>4. Cookies</h2>
          <p>
            Сайт використовує cookies для аналітики та покращення роботи ресурсу. Ви можете відмовитися від використання cookies у
            банері або налаштуваннях браузера.
          </p>

          <h2>5. Ваші права</h2>
          <p>
            Ви маєте право на доступ до своїх даних, їх виправлення або видалення. Для реалізації прав зверніться за адресою
            info@dogtrainingexpert.pl.
          </p>
        </div>
      </section>
    </div>
  );
};

export default PrivacyPage;