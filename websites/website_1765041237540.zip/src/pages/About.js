import React, { useEffect } from 'react';

const AboutPage = () => {
  useEffect(() => {
    const pageTitle = 'Про Dog Training Expert — команда та філософія';
    const pageDescription =
      'Дізнайтеся більше про команду Dog Training Expert, досвід тренерів і підхід до дресирування німецьких вівчарок у Варшаві та Кракові.';
    const pageKeywords =
      'команда Dog Training Expert, тренери німецькі вівчарки, кінолог Варшава, кінолог Краків, філософія дресури';
    document.title = pageTitle;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', pageDescription);
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', pageKeywords);
  }, []);

  return (
    <div className="page about-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Dog Training Expert — команда, яка живе дресируванням</h1>
          <p>
            Ми створили Dog Training Expert, щоб підтримати власників німецьких вівчарок на шляху до гармонійних стосунків.
            Сьогодні нас знають у Варшаві та Кракові як центр, де поєднані професіоналізм, турбота і сучасні методики.
          </p>
        </div>
      </section>

      <section className="mission-section">
        <div className="container mission-grid">
          <div>
            <h2>Наша місія</h2>
            <p>
              Ми допомагаємо кожній собаці розкрити потенціал, не втрачаючи природної харизми. Кожне заняття спрямоване на побудову
              взаєморозуміння між вівчаркою та власником, а також на підтримку емоційного балансу.
            </p>
            <p>
              Наші програми розробляються на перетині науки та практики: аналізуємо поведінку, спираємося на результативні методи і
              постійно вдосконалюємося через навчання та семінари в Європі.
            </p>
          </div>
          <div>
            <h3>Що нас вирізняє</h3>
            <ul className="checklist">
              <li>Вузька спеціалізація на німецьких вівчарках</li>
              <li>Команда, сертифікована міжнародними кінологічними школами</li>
              <li>Партнерські відносини з ветеринарами та поведінкарями</li>
              <li>Регулярні звіти, фото та відео з тренувань для власників</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="values-section">
        <div className="container">
          <h2>Наші цінності</h2>
          <div className="values-grid">
            <article>
              <h3>Повага</h3>
              <p>Слухаємо собаку і власника. Вчимо працювати без тиску, зважати на емоційний стан і комунікувати чітко.</p>
            </article>
            <article>
              <h3>Професіоналізм</h3>
              <p>Ми скрупульозно пропрацьовуємо кожен етап тренування і беремо відповідальність за результат.</p>
            </article>
            <article>
              <h3>Прозорість</h3>
              <p>Ви завжди знаєте, що відбувається під час занять, і отримуєте чіткі рекомендації для домашньої практики.</p>
            </article>
          </div>
        </div>
      </section>

      <section className="timeline-section">
        <div className="container">
          <h2>Ключові віхи розвитку</h2>
          <div className="timeline">
            <div className="timeline-item">
              <span className="timeline-year">2012</span>
              <p>Відкрили перший центр дресирування у Варшаві та сформували базову команду з трьох тренерів.</p>
            </div>
            <div className="timeline-item">
              <span className="timeline-year">2016</span>
              <p>Запустили програму підготовки до IPO та службових дисциплін, отримали міжнародні сертифікати.</p>
            </div>
            <div className="timeline-item">
              <span className="timeline-year">2019</span>
              <p>Відкрили філію у Кракові з просторою тренувальною базою та зоною соціалізації.</p>
            </div>
            <div className="timeline-item">
              <span className="timeline-year">2023</span>
              <p>Створили освітній центр для власників: вебінари, живі майстер-класи, онлайн-підтримка.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="expertise-section">
        <div className="container expertise-grid">
          <div>
            <h2>Глибока експертиза</h2>
            <p>
              Ми консультуємо кінологічні клуби, проводимо семінари для службових підрозділів та готуємо собак до змагань. Кожен
              тренер має досвід роботи з реальними викликами: від рятувальних операцій до спортивних стартів міжнародного рівня.
            </p>
          </div>
          <div>
            <h3>Напрями діяльності</h3>
            <ul className="checklist">
              <li>Спортивне дресирування (IPO, IGP, obedience)</li>
              <li>Робота із сімейними та виставковими собаками</li>
              <li>Підготовка до служби охорони та пошуку</li>
              <li>Індивідуальний супровід молодих кінологів</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;