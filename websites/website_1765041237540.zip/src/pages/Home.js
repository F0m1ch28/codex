import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const [stats, setStats] = useState({
    trainedDogs: 0,
    years: 0,
    workshops: 0,
    satisfaction: 0
  });
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('усі');

  useEffect(() => {
    const pageTitle = 'Dog Training Expert — Дресирування німецьких вівчарок';
    const pageDescription =
      'Професійна дресирування німецьких вівчарок у Варшаві та Кракові. Авторські методики, сертифіковані тренери та індивідуальні програми.';
    const pageKeywords =
      'дресирування німецьких вівчарок, тренування собак Варшава, тренування собак Краків, Dog Training Expert, корекція поведінки собак';
    document.title = pageTitle;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', pageDescription);
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', pageKeywords);
  }, []);

  useEffect(() => {
    const targets = {
      trainedDogs: 860,
      years: 12,
      workshops: 145,
      satisfaction: 98
    };
    const increments = {};
    Object.keys(targets).forEach((key) => {
      increments[key] = Math.max(1, Math.floor(targets[key] / 60));
    });

    const interval = setInterval(() => {
      setStats((prev) => {
        const next = { ...prev };
        let completed = true;
        Object.keys(targets).forEach((key) => {
          if (prev[key] < targets[key]) {
            next[key] = Math.min(prev[key] + increments[key], targets[key]);
            if (next[key] !== targets[key]) {
              completed = false;
            }
          }
        });
        if (completed) {
          clearInterval(interval);
        }
        return next;
      });
    }, 30);

    return () => clearInterval(interval);
  }, []);

  const testimonials = [
    'Успішно скоригували охоронну поведінку собаки, зменшили рівень стресу та навчили самоконтролю навіть у людних місцях.',
    'Команда Dog Training Expert допомогла побудувати глибоку довіру між нами та собакою, посилила послух і впевненість у різних середовищах.',
    'Після курсу відчутно покращилась комунікація з собакою, вона стала спокійнішою на тренуваннях і під час прогулянок у місті.'
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const projects = [
    {
      title: 'Спортивний курс IPO для вівчарки з Кракова',
      category: 'спортивна підготовка',
      image: 'https://picsum.photos/1200/800?random=4',
      description:
        'Посилена підготовка до іспитів IPO з акцентом на контактність, швидкість і точність виконання команд.'
    },
    {
      title: 'Корекція поведінки у Варшаві',
      category: 'корекція поведінки',
      image: 'https://picsum.photos/1200/800?random=5',
      description:
        'Індивідуальна програма для собаки з надмірною реактивністю, робота з тригерами у міському середовищі.'
    },
    {
      title: 'Інтенсивний курс послуху для юного пса',
      category: 'послух',
      image: 'https://picsum.photos/1200/800?random=6',
      description:
        'Закладено фундамент слухняності, сформовано стабільний контакт та чітку реакцію на сигнали господаря.'
    },
    {
      title: 'Підготовка собаки до служби охорони',
      category: 'спеціалізація',
      image: 'https://picsum.photos/1200/800?random=7',
      description:
        'Формування навичок охорони об’єктів, патрулювання та роботи у парі з провідником без втрати контролю.'
    }
  ];

  const filteredProjects =
    projectFilter === 'усі'
      ? projects
      : projects.filter((project) => project.category === projectFilter);

  const faqItems = [
    {
      question: 'З якого віку можна розпочинати дресирування німецької вівчарки?',
      answer:
        'Ми рекомендуємо стартувати з базової соціалізації вже з 3-4 місяців. Повноцінні тренінги послуху починаємо з 6 місяців, адаптуючи інтенсивність до темпераменту та стану собаки.'
    },
    {
      question: 'Чи працюєте ви з собаками, що демонструють агресію?',
      answer:
        'Так, наші тренери мають досвід корекції складної поведінки. Ми проводимо обовʼязкову оцінку характеру та тригерів, після чого формуємо безпечну та поетапну програму.'
    },
    {
      question: 'Який формат тренувань можливий: індивідуально чи в групах?',
      answer:
        'Пропонуємо індивідуальні заняття, міні-групи до 4 собак та комбіновані формати. Вибір залежить від потреб вашої вівчарки та цілей тренування.'
    },
    {
      question: 'Скільки часу триває курс базової слухняності?',
      answer:
        'Стандартна програма триває 8-10 тижнів із регулярними домашніми завданнями. Ми оцінюємо прогрес щотижнево та за потреби коригуємо план.'
    }
  ];

  return (
    <div className="home-page">
      <section className="hero-section">
        <div className="container hero-content">
          <div className="hero-text">
            <span className="eyebrow">Dog Training Expert</span>
            <h1>Професійна дресирування німецьких вівчарок у Варшаві та Кракові</h1>
            <p>
              Працюємо з породою, яку знаємо досконало. Створюємо персональні програми, що розкривають потенціал вашої
              німецької вівчарки та формують міцний зв’язок із власником.
            </p>
            <div className="hero-actions">
              <Link to="/kontakty" className="btn-primary">
                Запишіться на консультацію
              </Link>
              <Link to="/posluhan" className="btn-outline">
                Дізнатися про послуги
              </Link>
            </div>
          </div>
          <div className="hero-visual">
            <div className="hero-image" role="img" aria-label="Дресирування німецької вівчарки">
              <img src="https://picsum.photos/1600/900?random=1" alt="Тренування німецької вівчарки на майданчику" loading="lazy" />
            </div>
          </div>
        </div>
      </section>

      <section className="about-section" id="about">
        <div className="container about-grid">
          <div className="about-image">
            <img src="https://picsum.photos/800/600?random=2" alt="Тренер Dog Training Expert працює з собакою" loading="lazy" />
          </div>
          <div className="about-text">
            <h2>Хто ми</h2>
            <p>
              Dog Training Expert — команда сертифікованих кінологів, що спеціалізується виключно на роботі з німецькими
              вівчарками. Ми поєднуємо досвід службової підготовки, спортивних дисциплін та сімейної дресури, щоб ви отримали
              врівноваженого, слухняного та впевненого у собі партнера.
            </p>
            <ul className="about-highlights">
              <li>Індивідуальні тренувальні програми під характер вашого собаки</li>
              <li>Сучасні методики без насильства, побудовані на мотивації та контакті</li>
              <li>Регулярні звіти про прогрес та рекомендації для щоденної практики</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="stats-section">
        <div className="container stats-grid">
          <article className="stat-card">
            <span className="stat-number">{stats.trainedDogs}+</span>
            <p className="stat-label">натренованих німецьких вівчарок</p>
          </article>
          <article className="stat-card">
            <span className="stat-number">{stats.years}</span>
            <p className="stat-label">років досвіду у породних програмах</p>
          </article>
          <article className="stat-card">
            <span className="stat-number">{stats.workshops}</span>
            <p className="stat-label">проведених семінарів для власників</p>
          </article>
          <article className="stat-card">
            <span className="stat-number">{stats.satisfaction}%</span>
            <p className="stat-label">задоволених клієнтів</p>
          </article>
        </div>
      </section>

      <section className="services-section">
        <div className="container">
          <div className="section-heading">
            <h2>Наші послуги</h2>
            <p>Комплексні програми дресирування, побудовані спеціально для німецьких вівчарок різного віку та рівня підготовки.</p>
          </div>
          <div className="services-grid">
            <article className="service-card">
              <h3>Послух і базова дисципліна</h3>
              <p>
                Формуємо чітке виконання команд, закріплюємо контроль у різних середовищах та вчимо власників правильній комунікації.
              </p>
              <ul>
                <li>Команди «сидіти», «лежати», «до мене» у міському темпі</li>
                <li>Робота з витримкою та контактом</li>
                <li>Моделювання повсякденних ситуацій</li>
              </ul>
              <Link to="/posluhan" className="service-link">Детальніше</Link>
            </article>
            <article className="service-card">
              <h3>Корекція поведінки</h3>
              <p>
                Працюємо з реактивністю, небажаною охоронною поведінкою та стресом. Вибудовуємо безпечні патерни реагування.
              </p>
              <ul>
                <li>Діагностика тригерів та консультація ветеринарного поведінкаря</li>
                <li>Поетапна адаптація до подразників</li>
                <li>Підтримка власника на кожному етапі</li>
              </ul>
              <Link to="/posluhan" className="service-link">Детальніше</Link>
            </article>
            <article className="service-card">
              <h3>Соціалізація та спеціалізація</h3>
              <p>
                Готуємо вівчарок до сімейної, спортивної чи службової ролі. Опрацьовуємо соціальні навички та спеціальні задачі.
              </p>
              <ul>
                <li>Соціалізація у міському трафіку та зі звуками</li>
                <li>Підготовка до виставок, IPO, IGP</li>
                <li>Підтримка службових якостей без втрати послуху</li>
              </ul>
              <Link to="/posluhan" className="service-link">Детальніше</Link>
            </article>
          </div>
        </div>
      </section>

      <section className="process-section">
        <div className="container">
          <div className="section-heading">
            <h2>Як відбувається тренувальний процес</h2>
            <p>Прозора структура роботи дозволяє прогнозувати результат і впевнено рухатися до мети.</p>
          </div>
          <div className="process-steps">
            <div className="process-step">
              <span className="step-number">01</span>
              <h3>Оцінка та знайомство</h3>
              <p>Зустріч з тренером, аналіз темпераменту собаки, постановка цілей та очікувань власника.</p>
            </div>
            <div className="process-step">
              <span className="step-number">02</span>
              <h3>Планування програми</h3>
              <p>Формуємо індивідуальний план занять, графік та рекомендації щодо домашньої практики.</p>
            </div>
            <div className="process-step">
              <span className="step-number">03</span>
              <h3>Інтенсивні сесії</h3>
              <p>Проведення тренувань із фокусом на контакті, мотивації та постійному зворотному зв’язку.</p>
            </div>
            <div className="process-step">
              <span className="step-number">04</span>
              <h3>Аналіз результатів</h3>
              <p>Проміжні тести, адаптація програми та підсумкова демонстрація навичок собакою.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="breed-section">
        <div className="container breed-grid">
          <div>
            <h2>Чому саме німецькі вівчарки</h2>
            <p>
              Це універсальна порода з високим інтелектом, готовністю вчитися та величезною відданістю власнику. Водночас
              енергійність і охоронний інстинкт потребують спрямування. Ми знаємо, як знайти баланс між дисципліною та
              природними здібностями.
            </p>
            <ul className="breed-list">
              <li>Глибоке розуміння породних особливостей та стандартів</li>
              <li>Методики для контролю енергії та зміцнення нервової системи</li>
              <li>Підтримка у формуванні сімейної або службової ролі</li>
            </ul>
            <Link to="/nimetski-vivcharki" className="btn-text">
              Детально про підхід до вівчарок →
            </Link>
          </div>
          <div className="breed-highlight">
            <div className="highlight-card">
              <h3>Відданість і послух</h3>
              <p>Правильний тренер знає, як перетворити природну відданість на бездоганну співпрацю.</p>
            </div>
            <div className="highlight-card">
              <h3>Сильний характер</h3>
              <p>Поступовий розвиток впевненості без агресії та імпульсивності.</p>
            </div>
            <div className="highlight-card">
              <h3>Готовність працювати</h3>
              <p>Використовуємо енергію собаки для навчання складних завдань із натхненням.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="geography-section">
        <div className="container geography-grid">
          <div className="geo-text">
            <h2>Працюємо у Варшаві та Кракові</h2>
            <p>
              Два сучасні майданчики, зручні графіки занять та можливість виїзних сесій. Ми підтримуємо власників і між
              тренуваннями, щоб закріпити результат у реальному житті.
            </p>
            <div className="geo-locations">
              <div>
                <h3>Варшава</h3>
                <p>ул. Собакова 15, 00-001</p>
              </div>
              <div>
                <h3>Краков</h3>
                <p>ул. Паська 8, 30-001</p>
              </div>
            </div>
          </div>
          <div className="geo-map">
            <iframe
              title="Карта Dog Training Expert"
              src="https://www.google.com/maps/d/embed?mid=1W-m6XhLLqF1JxB3lXYIKILw5678&hl=uk"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>

      <section className="projects-section">
        <div className="container">
          <div className="section-heading">
            <h2>Проєкти та кейси</h2>
            <p>Підбираємо стратегії під конкретні задачі — від сімейного виховання до службової підготовки.</p>
          </div>
          <div className="project-filters" role="tablist" aria-label="Фільтр проєктів">
            {['усі', 'послух', 'корекція поведінки', 'спортивна підготовка', 'спеціалізація'].map((filter) => (
              <button
                key={filter}
                type="button"
                className={`filter-button ${projectFilter === filter ? 'active' : ''}`}
                onClick={() => setProjectFilter(filter)}
                role="tab"
                aria-selected={projectFilter === filter}
              >
                {filter.charAt(0).toUpperCase() + filter.slice(1)}
              </button>
            ))}
          </div>
          <div className="projects-grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.title}>
                <div className="project-image">
                  <img src={project.image} alt={project.title} loading="lazy" />
                </div>
                <div className="project-content">
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials-section">
        <div className="container">
          <div className="section-heading">
            <h2>Відгуки клієнтів</h2>
            <p>Результати, що надихають нас щодня працювати ще краще.</p>
          </div>
          <div className="testimonial-card">
            <p>“{testimonials[currentTestimonial]}”</p>
            <div className="testimonial-controls">
              <button
                type="button"
                aria-label="Попередній відгук"
                onClick={() =>
                  setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)
                }
              >
                ←
              </button>
              <span>
                {currentTestimonial + 1} / {testimonials.length}
              </span>
              <button
                type="button"
                aria-label="Наступний відгук"
                onClick={() => setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)}
              >
                →
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="team-section">
        <div className="container">
          <div className="section-heading">
            <h2>Наша команда</h2>
            <p>Знайомтесь із людьми, які щодня створюють історії успіху ваших собак.</p>
          </div>
          <div className="team-grid">
            <article className="team-card">
              <img src="https://picsum.photos/400/400?random=3" alt="Катерина Олійник, головний тренер" loading="lazy" />
              <h3>Катерина Олійник</h3>
              <p>Головний тренер, спеціаліст з IPO та службової підготовки.</p>
            </article>
            <article className="team-card">
              <img src="https://picsum.photos/400/400?random=8" alt="Михайло Боровик, кінолог" loading="lazy" />
              <h3>Михайло Боровик</h3>
              <p>Кінолог-поведінкар, експерт з корекції складних випадків.</p>
            </article>
            <article className="team-card">
              <img src="https://picsum.photos/400/400?random=9" alt="Олена Коваленко, координатор програм" loading="lazy" />
              <h3>Олена Коваленко</h3>
              <p>Координатор індивідуальних програм і наставництва власників.</p>
            </article>
          </div>
        </div>
      </section>

      <section className="faq-section">
        <div className="container">
          <div className="section-heading">
            <h2>Питання та відповіді</h2>
            <p>Зібрали найпоширеніші питання власників німецьких вівчарок.</p>
          </div>
          <div className="faq-list">
            {faqItems.map((item, index) => (
              <details key={item.question} className="faq-item">
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="blog-preview-section">
        <div className="container">
          <div className="section-heading">
            <h2>Останні статті блогу</h2>
            <p>Практичні поради і натхнення для роботи з вашою німецькою вівчаркою.</p>
          </div>
          <div className="blog-preview-grid">
            <article className="blog-card">
              <span className="blog-date">Січень 2024</span>
              <h3>5 помилок, яких варто уникати під час соціалізації вівчарки</h3>
              <p>Як вибудувати перші знайомства з оточенням без стресу для собаки і власника.</p>
              <Link to="/blog" className="blog-link">Читати більше</Link>
            </article>
            <article className="blog-card">
              <span className="blog-date">Листопад 2023</span>
              <h3>Мотиваційні ігри для розвитку послуху</h3>
              <p>Пояснюємо, як поєднати гру, інстинкти й команды, щоб отримати стабільний результат.</p>
              <Link to="/blog" className="blog-link">Читати більше</Link>
            </article>
            <article className="blog-card">
              <span className="blog-date">Вересень 2023</span>
              <h3>Що робити з охоронною поведінкою вдома</h3>
              <p>Стратегії управління охоронним інстинктом без втрати довіри та безпеки.</p>
              <Link to="/blog" className="blog-link">Читати більше</Link>
            </article>
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-content">
          <h2>Готові розпочати шлях до слухняної та щасливої вівчарки?</h2>
          <p>
            Заплануйте першу зустріч із тренером Dog Training Expert. Ми ретельно проаналізуємо потреби вашого собаки, підберемо
            оптимальний підхід і супроводжуватимемо вас на кожному етапі.
          </p>
          <Link to="/kontakty" className="btn-primary">
            Записатися зараз
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;