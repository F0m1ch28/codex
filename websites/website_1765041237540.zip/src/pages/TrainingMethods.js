import React, { useEffect } from 'react';

const TrainingMethodsPage = () => {
  useEffect(() => {
    const pageTitle = 'Методи дресирування Dog Training Expert';
    const pageDescription =
      'Dog Training Expert використовує поетапні методи навчання німецьких вівчарок: позитивне підкріплення, баланс мотивації та контроль охоронної поведінки.';
    const pageKeywords =
      'методи дресирування собак, позитивне підкріплення, тренування німецьких вівчарок, контроль охоронної поведінки, поетапне навчання';
    document.title = pageTitle;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', pageDescription);
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', pageKeywords);
  }, []);

  return (
    <div className="page methods-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Методи дресирування Dog Training Expert</h1>
          <p>
            Ми поєднуємо науковий підхід, практику міжнародних кінологічних шкіл та власні напрацювання, що довели свою ефективність
            при роботі з німецькими вівчарками.
          </p>
        </div>
      </section>

      <section className="method-section">
        <div className="container">
          <article className="method-card">
            <h2>Позитивне підкріплення та мотивація</h2>
            <p>
              Ми використовуємо мотивацію як основний інструмент навчання. Собаки вчаться із задоволенням, адже кожна команда
              асоціюється з позитивним результатом. Важливо не лише заохочення, а й правильно підібрана форма похвали.
            </p>
            <ul className="checklist">
              <li>Використання їжі, іграшки, голосової похвали</li>
              <li>Побудова коротких і змістовних сесій з відпочинком</li>
              <li>Поступове ускладнення, коли собака готова</li>
            </ul>
          </article>

          <article className="method-card">
            <h2>Контроль охоронної поведінки</h2>
            <p>
              Німецькі вівчарки мають потужний охоронний інстинкт. Наше завдання — спрямувати його так, щоб собака залишалася
              керованою та прогнозованою, не втрачаючи впевненості.
            </p>
            <ul className="checklist">
              <li>Розпізнаємо тригери, що запускають небажану реакцію</li>
              <li>Відпрацьовуємо зв’язок «помітив — звернувся до власника»</li>
              <li>Вчимо собаку перемикатися на команду власника</li>
            </ul>
          </article>

          <article className="method-card">
            <h2>Поетапне освоєння навичок</h2>
            <p>
              Кожна навичка вивчається за чітким алгоритмом: від знайомства до автоматизму. Ми фіксуємо прогрес у тренувальній
              картці, щоб ви бачили, як росте ваша вівчарка.
            </p>
            <ul className="checklist">
              <li>Етап 1: пояснення та формування правильної дії</li>
              <li>Етап 2: закріплення в контрольованих умовах</li>
              <li>Етап 3: тренування серед реальних подразників</li>
              <li>Етап 4: підтримка результату в житті власника</li>
            </ul>
          </article>
        </div>
      </section>
    </div>
  );
};

export default TrainingMethodsPage;