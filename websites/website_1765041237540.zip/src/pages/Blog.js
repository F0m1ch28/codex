import React, { useEffect } from 'react';

const BlogPage = () => {
  useEffect(() => {
    const pageTitle = 'Блог Dog Training Expert — поради з дресирування';
    const pageDescription =
      'Читайте блог Dog Training Expert про дресирування німецьких вівчарок, корекцію поведінки, соціалізацію та мотиваційні ігри.';
    const pageKeywords =
      'блог дресирування собак, поради кінолога, німецькі вівчарки блог, тренування собак Варшава, тренування собак Краків';
    document.title = pageTitle;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', pageDescription);
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', pageKeywords);
  }, []);

  const posts = [
    {
      title: 'Як розвинути самоконтроль у молодої вівчарки',
      date: '15.01.2024',
      excerpt:
        'Самоконтроль — ключ до безпечної поведінки. Ділимося вправами, які розвивають витримку та концентрацію, не пригнічуючи енергію собаки.'
    },
    {
      title: 'Підготовка до першої виставки: чек-ліст власника',
      date: '02.12.2023',
      excerpt:
        'Збираємо кроки, що допоможуть підготувати вівчарку до рингу: робота з експертом, поведінка серед собак, необхідні документи.'
    },
    {
      title: 'Як працювати з охоронним інстинктом удома',
      date: '18.10.2023',
      excerpt:
        'Пояснюємо, як спрямувати природний охоронний інстинкт у конструктивне русло і не допустити неконтрольованої поведінки.'
    }
  ];

  return (
    <div className="page blog-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Блог Dog Training Expert</h1>
          <p>Досвід, поради та реальні кейси для власників німецьких вівчарок.</p>
        </div>
      </section>

      <section className="blog-list-section">
        <div className="container blog-list">
          {posts.map((post) => (
            <article className="blog-entry" key={post.title}>
              <span className="blog-entry-date">{post.date}</span>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <a className="btn-text" href="#!" aria-label={`Читати статтю ${post.title}`}>
                Читати статтю →
              </a>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default BlogPage;