import React, { useEffect } from 'react';

const ServicesPage = () => {
  useEffect(() => {
    const pageTitle = 'Послуги Dog Training Expert — програми дресирування';
    const pageDescription =
      'Dog Training Expert пропонує програми дресирування німецьких вівчарок: послух, корекція поведінки, соціалізація, спеціалізовані тренування у Варшаві та Кракові.';
    const pageKeywords =
      'послуги дресирування, курс послуху, корекція поведінки собак, соціалізація німецьких вівчарок, програма тренувань';
    document.title = pageTitle;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', pageDescription);
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', pageKeywords);
  }, []);

  return (
    <div className="page services-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Послуги Dog Training Expert</h1>
          <p>
            Ми створюємо програми дресирування, які відповідають природі німецьких вівчарок: інтелект, енергія, охоронний
            інстинкт. Усі заняття супроводжуються чітким планом, звітністю та підтримкою власника.
          </p>
        </div>
      </section>

      <section className="service-details">
        <div className="container">
          <article className="service-detail-card">
            <h2>Курс базового послуху</h2>
            <p>
              Формуємо фундаментальні навички слухняності та контролю у побуті. Курс підходить молодим собакам, а також дорослим,
              яким потрібно закріпити дисципліну.
            </p>
            <div className="service-columns">
              <div>
                <h3>Що включено</h3>
                <ul className="checklist">
                  <li>Команди «до мене», «поруч», «сидіти», «лежати», «чекати»</li>
                  <li>Відпрацювання витримки серед відволікаючих факторів</li>
                  <li>Соціалізація в парках, біля транспорту, у торгових центрах</li>
                </ul>
              </div>
              <div>
                <h3>Формат</h3>
                <ul className="checklist">
                  <li>Індивідуальні заняття 1-2 рази на тиждень</li>
                  <li>Групові практики з іншими вівчарками</li>
                  <li>Домашні завдання та зворотний зв’язок від тренера</li>
                </ul>
              </div>
            </div>
          </article>

          <article className="service-detail-card">
            <h2>Корекція поведінки</h2>
            <p>
              Працюємо зі складними ситуаціями: агресія, надмірний контроль території, страхи та фобії. Кожна програма починається з
              глибокої діагностики причин поведінки.
            </p>
            <div className="service-columns">
              <div>
                <h3>Етапи роботи</h3>
                <ul className="checklist">
                  <li>Поведінковий аудит та відеоаналіз</li>
                  <li>Створення плану дій для родини</li>
                  <li>Відпрацювання нових сценаріїв поведінки</li>
                </ul>
              </div>
              <div>
                <h3>Результат</h3>
                <ul className="checklist">
                  <li>Зменшення реактивності, контроль над імпульсами</li>
                  <li>Покращення стресостійкості собаки</li>
                  <li>Власник отримує інструменти для підтримки прогресу</li>
                </ul>
              </div>
            </div>
          </article>

          <article className="service-detail-card">
            <h2>Соціалізація та спеціалізована підготовка</h2>
            <p>
              Готуємо собак до сімейного життя, виставок, спортивних або службових завдань. Опрацьовуємо специфічні навички та
              підтримуємо природні таланти вівчарок.
            </p>
            <div className="service-columns">
              <div>
                <h3>Напрями</h3>
                <ul className="checklist">
                  <li>Підготовка до виставок та тестів характеру</li>
                  <li>IPO, obedience, nosework, трюкова робота</li>
                  <li>Службові дисципліни: охорона, пошук, патрулювання</li>
                </ul>
              </div>
              <div>
                <h3>Додатково</h3>
                <ul className="checklist">
                  <li>Консультації з харчування та фізичного розвитку</li>
                  <li>Рекомендації щодо інвентарю та амуніції</li>
                  <li>Участь у тренуваннях на спеціалізованих локаціях</li>
                </ul>
              </div>
            </div>
          </article>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;