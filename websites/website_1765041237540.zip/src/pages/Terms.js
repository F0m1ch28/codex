import React, { useEffect } from 'react';

const TermsPage = () => {
  useEffect(() => {
    const pageTitle = 'Умови використання Dog Training Expert';
    const pageDescription =
      'Ознайомтеся з умовами використання сайту Dog Training Expert: права та обов’язки користувачів, правила взаємодії та контактні дані.';
    const pageKeywords =
      'умови використання, Dog Training Expert, правила сайту, юридична інформація, дресирування собак умови';
    document.title = pageTitle;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', pageDescription);
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', pageKeywords);
  }, []);

  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Умови використання</h1>
        </div>
      </section>
      <section className="legal-section">
        <div className="container legal-content">
          <h2>1. Загальні положення</h2>
          <p>
            Сайт Dog Training Expert надає інформацію про діяльність компанії, програми дресирування стаціонарно у Варшаві та
            Кракові, а також контактні дані для взаємодії. Користуючись сайтом, ви погоджуєтеся з викладеними умовами.
          </p>

          <h2>2. Використання контенту</h2>
          <p>
            Матеріали сайту призначені для ознайомлення з послугами та не можуть бути використані без письмової згоди Dog Training
            Expert. Забороняється копіювання та публікація матеріалів без посилання на джерело.
          </p>

          <h2>3. Зворотній зв’язок</h2>
          <p>
            Надсилаючи запити через форму, ви надаєте згоду на обробку персональних даних з метою відповіді на звернення. Ми не
            передаємо дані третім особам, окрім випадків, передбачених законом.
          </p>

          <h2>4. Відповідальність</h2>
          <p>
            Компанія прагне надавати точну і актуальну інформацію, проте не несе відповідальності за будь-які помилки або
            неточності, що можуть виникнути. Користувач несе відповідальність за використання інформації.
          </p>

          <h2>5. Контактна інформація</h2>
          <ul className="checklist">
            <li>Телефон: +48 123 456 789</li>
            <li>Email: info@dogtrainingexpert.pl</li>
            <li>Адреси: Варшава, ул. Собакова 15, 00-001; Краков, ул. Паська 8, 30-001</li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default TermsPage;