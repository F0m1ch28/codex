import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';

import HomePage from './pages/Home';
import ServicesPage from './pages/Services';
import AboutPage from './pages/About';
import TrainingMethodsPage from './pages/TrainingMethods';
import GermanShepherdsPage from './pages/GermanShepherds';
import ContactPage from './pages/Contact';
import BlogPage from './pages/Blog';
import TermsPage from './pages/Terms';
import PrivacyPage from './pages/Privacy';
import CookiePolicyPage from './pages/CookiePolicy';

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

function App() {
  return (
    <div className="app-shell">
      <ScrollToTopOnRouteChange />
      <Header />
      <main id="main-content" className="main-content" tabIndex="-1">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/posluhan" element={<ServicesPage />} />
          <Route path="/pro-nas" element={<AboutPage />} />
          <Route path="/metody-dresury" element={<TrainingMethodsPage />} />
          <Route path="/nimetski-vivcharki" element={<GermanShepherdsPage />} />
          <Route path="/kontakty" element={<ContactPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/umovy-vykorystannia" element={<TermsPage />} />
          <Route path="/polityka-konfidentsiinosti" element={<PrivacyPage />} />
          <Route path="/polityka-cookies" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;