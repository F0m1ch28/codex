import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSticky, setIsSticky] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  return (
    <header className={`site-header ${isSticky ? 'sticky' : ''}`}>
      <div className="container header-container">
        <Link to="/" className="logo" aria-label="Перейти на головну Dog Training Expert">
          <span className="logo-mark">Dog</span>
          <span className="logo-text">Training Expert</span>
        </Link>
        <nav className={`main-nav ${isMenuOpen ? 'open' : ''}`} aria-label="Головна навігація">
          <NavLink to="/" className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')} end>
            Головна
          </NavLink>
          <NavLink to="/posluhan" className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}>
            Послуги
          </NavLink>
          <NavLink to="/pro-nas" className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}>
            Про нас
          </NavLink>
          <NavLink to="/metody-dresury" className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}>
            Методи
          </NavLink>
          <NavLink to="/nimetski-vivcharki" className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}>
            Німецькі вівчарки
          </NavLink>
          <NavLink to="/blog" className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}>
            Блог
          </NavLink>
          <NavLink to="/kontakty" className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}>
            Контакти
          </NavLink>
        </nav>
        <button
          className={`menu-toggle ${isMenuOpen ? 'open' : ''}`}
          onClick={toggleMenu}
          aria-label="Перемикання навігації"
          aria-expanded={isMenuOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;