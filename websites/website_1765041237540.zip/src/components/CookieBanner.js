import React, { useState, useEffect } from 'react';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const consent = window.localStorage.getItem('cookieConsent');
      if (!consent) {
        setIsVisible(true);
      }
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('cookieConsent', 'accepted');
    }
    setIsVisible(false);
  };

  const handleDecline = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('cookieConsent', 'declined');
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <p>
          Ми використовуємо cookies для підвищення зручності користування сайтом Dog Training Expert. Детальніше у
          <a href="/polityka-cookies"> Політиці cookies</a>.
        </p>
        <div className="cookie-actions">
          <button type="button" className="btn-primary" onClick={handleAccept}>
            Погоджуюсь
          </button>
          <button type="button" className="btn-outline" onClick={handleDecline}>
            Відхиляю
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;