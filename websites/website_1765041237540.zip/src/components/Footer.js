import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-column">
          <h3 className="footer-title">Dog Training Expert</h3>
          <p className="footer-text">
            Спеціалізована школа дресирування німецьких вівчарок у Варшаві та Кракові. Ми поєднуємо сучасні методики,
            науковий підхід та безумовну любов до собак.
          </p>
        </div>
        <div className="footer-column">
          <h4 className="footer-heading">Навігація</h4>
          <ul className="footer-links">
            <li><Link to="/">Головна</Link></li>
            <li><Link to="/posluhan">Послуги</Link></li>
            <li><Link to="/pro-nas">Про нас</Link></li>
            <li><Link to="/metody-dresury">Методи</Link></li>
            <li><Link to="/nimetski-vivcharki">Німецькі вівчарки</Link></li>
            <li><Link to="/blog">Блог</Link></li>
            <li><Link to="/kontakty">Контакти</Link></li>
          </ul>
        </div>
        <div className="footer-column">
          <h4 className="footer-heading">Контакти</h4>
          <ul className="footer-contact">
            <li><strong>Варшава:</strong> ул. Собакова 15, 00-001</li>
            <li><strong>Краков:</strong> ул. Паська 8, 30-001</li>
            <li><a href="tel:+48123456789">+48 123 456 789</a></li>
            <li><a href="mailto:info@dogtrainingexpert.pl">info@dogtrainingexpert.pl</a></li>
          </ul>
        </div>
        <div className="footer-column">
          <h4 className="footer-heading">Документи</h4>
          <ul className="footer-links">
            <li><Link to="/umovy-vykorystannia">Умови використання</Link></li>
            <li><Link to="/polityka-konfidentsiinosti">Політика конфіденційності</Link></li>
            <li><Link to="/polityka-cookies">Політика cookies</Link></li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© {currentYear} Dog Training Expert. Усі права захищені.</span>
      </div>
    </footer>
  );
};

export default Footer;