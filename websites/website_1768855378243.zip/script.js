(function () {
  const navToggle = document.querySelector("[data-nav-toggle]");
  const navList = document.querySelector("[data-nav-list]");
  if (navToggle && navList) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      navList.classList.toggle("is-open");
    });
  }

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  if (cookieBanner) {
    const preference = localStorage.getItem("tttCookiePreference");
    if (preference) {
      cookieBanner.classList.add("is-hidden");
    }
    const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
    const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
    const hideBanner = (value) => {
      localStorage.setItem("tttCookiePreference", value);
      cookieBanner.classList.add("is-hidden");
    };
    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => hideBanner("accepted"));
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => hideBanner("declined"));
    }
  }
})();