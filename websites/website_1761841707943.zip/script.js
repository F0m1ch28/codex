document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  const scrollTopBtn = document.getElementById('scrollTop');
  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptCookiesBtn = document.getElementById('acceptCookies');
  const yearEl = document.getElementById('year');
  const impactNumbers = document.querySelectorAll('.impact-number');

  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  // Mobile Navigation
  if (navToggle) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', !expanded);
      nav.classList.toggle('open');
      document.body.classList.toggle('nav-open');
    });

    document.querySelectorAll('.site-nav a').forEach(link => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', false);
        nav.classList.remove('open');
        document.body.classList.remove('nav-open');
      });
    });
  }

  // Scroll to top button
  window.addEventListener('scroll', () => {
    if (window.scrollY > 400) {
      scrollTopBtn.classList.add('show');
    } else {
      scrollTopBtn.classList.remove('show');
    }
  });

  scrollTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // Cookie Banner
  const cookieConsent = localStorage.getItem('enervailCookieConsent');
  if (!cookieConsent) {
    setTimeout(() => cookieBanner.classList.add('active'), 1000);
  } else {
    cookieBanner.remove();
  }

  if (acceptCookiesBtn) {
    acceptCookiesBtn.addEventListener('click', () => {
      localStorage.setItem('enervailCookieConsent', 'accepted');
      cookieBanner.classList.remove('active');
      setTimeout(() => cookieBanner.remove(), 500);
    });
  }

  // Animated Impact Numbers
  if (impactNumbers.length) {
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const el = entry.target;
          const target = parseInt(el.getAttribute('data-count'), 10);
          let current = 0;
          const increment = target / 120;

          const updateNumber = () => {
            current += increment;
            if (current >= target) {
              el.textContent = target.toLocaleString();
            } else {
              el.textContent = Math.round(current).toLocaleString();
              requestAnimationFrame(updateNumber);
            }
          };

          requestAnimationFrame(updateNumber);
          obs.unobserve(el);
        }
      });
    }, { threshold: 0.6 });

    impactNumbers.forEach(num => observer.observe(num));
  }
});