document.addEventListener('DOMContentLoaded', function () {
  var cookieBanner = document.getElementById('cookie-banner');
  if (!cookieBanner) return;

  var storageKey = 'greenleafCookieConsent';
  var savedPreference = localStorage.getItem(storageKey);

  function hideBanner() {
    cookieBanner.classList.remove('visible');
  }

  function showBanner() {
    cookieBanner.classList.add('visible');
  }

  if (savedPreference === 'accepted' || savedPreference === 'declined') {
    hideBanner();
  } else {
    showBanner();
  }

  cookieBanner.addEventListener('click', function (event) {
    var target = event.target;
    if (!target.dataset.cookieAction) return;

    var action = target.dataset.cookieAction;
    localStorage.setItem(storageKey, action === 'accept' ? 'accepted' : 'declined');
    hideBanner();
  });
});