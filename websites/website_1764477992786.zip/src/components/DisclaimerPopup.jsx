```javascript
import { useEffect, useState } from 'react';

const DisclaimerPopup = () => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setOpen(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  if (!open) return null;

  return (
    <div className="disclaimer-backdrop" role="dialog" aria-modal="true">
      <div className="disclaimer-content">
        <h3>Disclaimer</h3>
        <p>Мы не предоставляем финансовые услуги / We do not provide financial services.</p>
        <button
          type="button"
          className="btn small"
          onClick={() => setOpen(false)}
        >
          Close
        </button>
      </div>
    </div>
  );
};

export default DisclaimerPopup;
```