```javascript
import { NavLink, Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const Header = ({ onLanguageChange }) => {
  const { language, t } = useLanguage();

  return (
    <header className="site-header" role="banner">
      <div className="container header-inner">
        <Link to="/" className="brand" aria-label="Tu Progreso Hoy home">
          <span className="brand-mark">TPH</span>
          <span className="brand-text">Tu Progreso Hoy</span>
        </Link>
        <nav aria-label="Primary navigation" className="primary-nav">
          <NavLink to="/" end>
            {t('nav.home')}
          </NavLink>
          <NavLink to="/inflation">{t('nav.inflation')}</NavLink>
          <NavLink to="/course">{t('nav.course')}</NavLink>
          <NavLink to="/resources">{t('nav.resources')}</NavLink>
          <NavLink to="/contact">{t('nav.contact')}</NavLink>
        </nav>
        <div className="header-actions">
          <span className="header-tagline">{t('header.tagline')}</span>
          <div className="language-toggle" role="group" aria-label="Language">
            <button
              type="button"
              className={language === 'en' ? 'active' : ''}
              onClick={() => onLanguageChange('en')}
            >
              EN
            </button>
            <button
              type="button"
              className={language === 'es' ? 'active' : ''}
              onClick={() => onLanguageChange('es')}
            >
              ES
            </button>
          </div>
          <Link to="/contact" className="btn small">
            {t('header.contactCta')}
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;
```