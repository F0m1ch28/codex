```javascript
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const Footer = () => {
  const { t } = useLanguage();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div>
          <h3>Tu Progreso Hoy</h3>
          <p>{t('footer.description')}</p>
          <p className="footer-tagline">{t('footer.tagline')}</p>
        </div>
        <div>
          <h4>{t('footer.linksTitle')}</h4>
          <ul>
            <li>
              <Link to="/">{t('nav.home')}</Link>
            </li>
            <li>
              <Link to="/inflation">{t('nav.inflation')}</Link>
            </li>
            <li>
              <Link to="/course">{t('nav.course')}</Link>
            </li>
            <li>
              <Link to="/resources">{t('nav.resources')}</Link>
            </li>
            <li>
              <Link to="/contact">{t('nav.contact')}</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4>{t('footer.legalTitle')}</h4>
          <ul>
            <li>
              <Link to="/privacy">Privacy</Link>
            </li>
            <li>
              <Link to="/cookies">Cookies</Link>
            </li>
            <li>
              <Link to="/terms">Terms</Link>
            </li>
            <li>
              <Link to="/imprint">Imprint</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4>{t('footer.newsletterTitle')}</h4>
          <p>{t('home.bottomCta.note')}</p>
          <p className="footer-sustain">{t('footer.sustain')}</p>
        </div>
      </div>
      <div className="footer-bottom">
        <small>
          © {currentYear} Tu Progreso Hoy. All rights reserved.
        </small>
      </div>
    </footer>
  );
};

export default Footer;
```