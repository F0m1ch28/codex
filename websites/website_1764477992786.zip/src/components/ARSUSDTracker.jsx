```javascript
import { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

const ARSUSDTracker = () => {
  const { t } = useLanguage();
  const [rate, setRate] = useState(null);
  const [inverse, setInverse] = useState(null);
  const [status, setStatus] = useState('idle');
  const [lastUpdated, setLastUpdated] = useState(null);

  useEffect(() => {
    let active = true;

    const fetchRate = async () => {
      try {
        setStatus('loading');
        const response = await fetch(
          'https://api.exchangerate.host/latest?base=ARS&symbols=USD'
        );
        const data = await response.json();
        if (!active) return;
        const usdRate = data?.rates?.USD;
        if (usdRate) {
          setRate(usdRate);
          setInverse(1 / usdRate);
          setLastUpdated(data?.date);
          setStatus('success');
        } else {
          throw new Error('No rate');
        }
      } catch (error) {
        if (!active) return;
        const fallback = 0.0012;
        setRate(fallback);
        setInverse(1 / fallback);
        setLastUpdated(new Date().toISOString().slice(0, 10));
        setStatus('error');
      }
    };

    fetchRate();
    const interval = setInterval(fetchRate, 60000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, []);

  return (
    <section className="tracker-section" aria-labelledby="tracker-heading">
      <div className="container tracker-wrapper">
        <div>
          <h2 id="tracker-heading">{t('tracker.title')}</h2>
          <p>{t('tracker.subtitle')}</p>
        </div>
        <div className="tracker-card">
          {status === 'loading' && (
            <p aria-live="polite">{t('tracker.loading')}</p>
          )}
          {status !== 'loading' && (
            <>
              <div className="tracker-values">
                <div>
                  <span className="tracker-label">1 ARS → USD</span>
                  <span className="tracker-value">
                    {rate ? rate.toFixed(5) : '—'}
                  </span>
                </div>
                <div>
                  <span className="tracker-label">1 USD → ARS</span>
                  <span className="tracker-value">
                    {inverse ? inverse.toFixed(2) : '—'}
                  </span>
                </div>
              </div>
              <p className="tracker-updated">
                {t('tracker.lastUpdated')}: {lastUpdated || '—'}
              </p>
              {status === 'error' && (
                <p role="status" className="tracker-error">
                  {t('tracker.error')}
                </p>
              )}
            </>
          )}
        </div>
        <p className="tracker-disclaimer">{t('tracker.disclaimer')}</p>
      </div>
    </section>
  );
};

export default ARSUSDTracker;
```