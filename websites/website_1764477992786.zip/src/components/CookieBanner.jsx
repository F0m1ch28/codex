```javascript
import { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

const STORAGE_KEY = 'tph-cookie-consent';

const CookieBanner = () => {
  const { t } = useLanguage();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem(STORAGE_KEY, choice);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <p>{t('cookieBanner.message')}</p>
      <div className="cookie-actions">
        <button className="btn small" onClick={() => handleChoice('accepted')}>
          {t('cookieBanner.accept')}
        </button>
        <button
          className="btn ghost small"
          onClick={() => handleChoice('declined')}
        >
          {t('cookieBanner.decline')}
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;
```