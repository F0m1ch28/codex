```javascript
import { useEffect } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Header from './Header';
import Footer from './Footer';
import CookieBanner from './CookieBanner';
import DisclaimerPopup from './DisclaimerPopup';
import { useLanguage } from '../context/LanguageContext';

const Layout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { language, setLanguage, t } = useLanguage();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const langParam = params.get('lang');
    if (langParam === 'es' && language !== 'es') {
      setLanguage('es');
    } else if (!langParam && language !== 'en') {
      setLanguage('en');
    }
  }, [location.search, language, setLanguage]);

  useEffect(() => {
    document.documentElement.lang = language === 'es' ? 'es' : 'en';
  }, [language]);

  const handleLanguageChange = (lang) => {
    const params = new URLSearchParams(location.search);
    if (lang === 'es') {
      params.set('lang', 'es');
    } else {
      params.delete('lang');
    }
    const search = params.toString();
    navigate(
      {
        pathname: location.pathname,
        search: search ? `?${search}` : ''
      },
      { replace: true }
    );
    setLanguage(lang);
  };

  const baseUrl = 'https://www.tuprogresohoy.com';
  const path = location.pathname === '/' ? '' : location.pathname;
  const canonicalUrl =
    language === 'es'
      ? `${baseUrl}${path}${path ? '?' : '?'}lang=es`.replace('??', '?')
      : `${baseUrl}${path}`;

  return (
    <>
      <Helmet>
        <title>Tu Progreso Hoy | Inflation Insights & Course</title>
        <meta name="description" content={t('meta.description')} />
        <link rel="canonical" href={canonicalUrl} />
        <link rel="alternate" hrefLang="en" href={`${baseUrl}${path}`} />
        <link
          rel="alternate"
          hrefLang="es-AR"
          href={`${baseUrl}${path}${path ? '?' : '?'}lang=es`.replace(
            '??',
            '?'
          )}
        />
      </Helmet>
      <div className="app-shell">
        <Header onLanguageChange={handleLanguageChange} />
        <CookieBanner />
        <DisclaimerPopup />
        <main id="main-content">
          <Outlet />
        </main>
        <Footer />
      </div>
    </>
  );
};

export default Layout;
```