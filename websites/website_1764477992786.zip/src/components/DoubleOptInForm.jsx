```javascript
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const DoubleOptInForm = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: ''
  });
  const [code, setCode] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleChange = ({ target: { name, value } }) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFirstSubmit = (event) => {
    event.preventDefault();
    if (!formData.name.trim() || !formData.email.trim()) {
      setError(t('contact.error'));
      return;
    }
    setError('');
    setStep(2);
    setMessage(t('doubleOpt.verificationInfo'));
  };

  const handleSecondSubmit = (event) => {
    event.preventDefault();
    if (code.trim().toUpperCase() === 'CONFIRM') {
      setError('');
      setMessage(t('doubleOpt.successMessage'));
      setTimeout(() => navigate('/thank-you'), 1200);
    } else {
      setError(t('doubleOpt.errorMessage'));
    }
  };

  return (
    <section
      className="double-opt-section"
      id="signupForm"
      aria-labelledby="double-opt-title"
    >
      <div className="container double-opt-container">
        <div>
          <h2 id="double-opt-title">{t('doubleOpt.title')}</h2>
          <p>{t('doubleOpt.description')}</p>
          <p className="privacy-note">{t('doubleOpt.privacyNote')}</p>
        </div>
        <div className="double-opt-card">
          {step === 1 && (
            <form onSubmit={handleFirstSubmit} className="double-opt-form">
              <h3>{t('doubleOpt.step1Title')}</h3>
              <label htmlFor="name">{t('doubleOpt.nameLabel')}</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                required
              />
              <label htmlFor="email">{t('doubleOpt.emailLabel')}</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
              <label htmlFor="company">{t('doubleOpt.companyLabel')}</label>
              <input
                id="company"
                name="company"
                type="text"
                value={formData.company}
                onChange={handleChange}
              />
              {error && (
                <p className="form-error" role="alert">
                  {error}
                </p>
              )}
              <button type="submit" className="btn primary">
                {t('doubleOpt.submitLabel')}
              </button>
            </form>
          )}
          {step === 2 && (
            <form onSubmit={handleSecondSubmit} className="double-opt-form">
              <h3>{t('doubleOpt.step2Title')}</h3>
              <p aria-live="polite">{message}</p>
              <label htmlFor="code">{t('doubleOpt.codeLabel')}</label>
              <input
                id="code"
                name="code"
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                required
              />
              {error && (
                <p className="form-error" role="alert">
                  {error}
                </p>
              )}
              <button type="submit" className="btn primary">
                {t('doubleOpt.confirmLabel')}
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};

export default DoubleOptInForm;
```