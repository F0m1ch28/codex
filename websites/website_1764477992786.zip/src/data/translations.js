```javascript
const translations = {
  en: {
    meta: {
      description:
        'Tu Progreso Hoy delivers Argentina-focused inflation insights, ARS→USD tracking, and a responsible personal finance starter course.'
    },
    nav: {
      home: 'Home',
      inflation: 'Inflation',
      course: 'Course',
      resources: 'Resources',
      contact: 'Contact'
    },
    header: {
      tagline: 'Argentina insights for responsible action',
      contactCta: 'Contact us'
    },
    hero: {
      badge: 'Argentina • Educational SaaS',
      title: 'Plan your Argentina finances with trusted intelligence',
      subtitle:
        'Tu Progreso Hoy unites real-time inflation indicators, ARS→USD monitoring, and a guided starter course so you can make informed personal finance decisions.',
      bullets: [
        'Datos verificados para planificar tu presupuesto.',
        'Decisiones responsables, objetivos nítidos.',
        'Conocimiento financiero impulsado por tendencias.'
      ],
      supportingLine: 'Pasos acertados hoy, mejor futuro mañana.',
      primaryCta: 'Start the course',
      secondaryCta: 'See inflation methodology',
      stats: [
        { label: 'Learners onboarded', value: '1,500+' },
        { label: 'Data refresh cadence', value: 'Daily' },
        { label: 'Coverage', value: 'Argentina (AR)' }
      ]
    },
    home: {
      keyPromises: {
        title: 'Key promises',
        description:
          'We synthesize macroeconomic data into human-centered learning journeys while sustaining responsible expectations.',
        items: [
          {
            title: 'Transparent analytics',
            description:
              'Análisis transparentes y datos de mercado para decidir con seguridad.'
          },
          {
            title: 'Responsible choices',
            description:
              'Información confiable que respalda elecciones responsables sobre tu dinero.'
          },
          {
            title: 'Trend-driven mindset',
            description:
              'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.'
          },
          {
            title: 'Educational-first ethos',
            description:
              'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
          },
          {
            title: 'Learning compounding',
            description:
              'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
          }
        ]
      },
      insights: {
        title: 'Real-time insights',
        description:
          'Stay oriented with curated Argentina CPI, FX, and wage signals presented in plain language.',
        cards: [
          {
            title: 'Headline CPI tracker',
            metric: '254.2% YoY',
            change: '+3.1 pts vs last month',
            narrative:
              'Inflation pressures continue as food and transport lead the basket.'
          },
          {
            title: 'ARS resilience index',
            metric: 'ARS 860.45 per USD',
            change: 'Spot variation -1.2%',
            narrative:
              'Central bank interventions stabilize the official rate amid parallel market divergence.'
          },
          {
            title: 'Household basket',
            metric: 'ARS 495,700',
            change: '+6.4% MoM',
            narrative: 'Datos verificados para planificar tu presupuesto.'
          }
        ]
      },
      courseOverview: {
        title: 'Course overview',
        description:
          'A guided pathway from macro basics to personal budgeting under inflation stress.',
        modules: [
          {
            title: 'Module 1 · Inflation foundations',
            items: [
              'Argentina CPI structure',
              'FX dynamics and capital controls',
              'Scenario planning workbook'
            ]
          },
          {
            title: 'Module 2 · Income & expenses',
            items: [
              'Indexing salaries responsibly',
              'ARS vs USD budgeting templates',
              'Savings buffers under volatility'
            ]
          },
          {
            title: 'Module 3 · Trend interpretation',
            items: [
              'Conocimiento financiero impulsado por tendencias.',
              'Data visualization fundamentals',
              'Storytelling with inflation dashboards'
            ]
          },
          {
            title: 'Module 4 · Action playbooks',
            items: [
              'Emergency protocols',
              'Community case studies',
              'Decisiones responsables, objetivos nítidos.'
            ]
          }
        ],
        cta: 'Review full syllabus',
        anchorText: 'Jump to enrollment form'
      },
      testimonials: {
        title: 'Community voices',
        items: [
          {
            quote:
              '“The methodology demystified CPI releases and helped our team set realistic quarterly targets.”',
            name: 'María López',
            role: 'FP&A Analyst, Córdoba'
          },
          {
            quote:
              '“Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. I finally see how macro and personal budgets connect.”',
            name: 'Julián Pérez',
            role: 'Entrepreneur, Rosario'
          },
          {
            quote:
              '“Pasos acertados hoy, mejor futuro mañana. The course keeps me grounded without overpromising returns.”',
            name: 'Ana Fernández',
            role: 'Marketing Specialist, Buenos Aires'
          }
        ]
      },
      bottomCta: {
        title: 'Act with clarity',
        description:
          'Consolidate the insights into weekly practice sessions and receive structured updates.',
        note:
          'Double opt-in protects your inbox and ensures explicit consent at each step.'
      }
    },
    tracker: {
      title: 'ARS→USD tracker',
      subtitle: 'Indicative live rate sourced from exchangerate.host',
      loading: 'Loading live rate…',
      error: 'Unable to load live rate. Showing indicative trend snapshot.',
      lastUpdated: 'Last updated',
      disclaimer:
        'Rates are informational. Consult official institutions before transacting.'
    },
    doubleOpt: {
      title: 'Secure your preview seat',
      description:
        'Complete the Double Opt-In to receive the “Tu Progreso Hoy” starter kit and a complimentary micro-lesson.',
      step1Title: 'Step 1 · Subscription request',
      step2Title: 'Step 2 · Confirm your email',
      nameLabel: 'Full name',
      emailLabel: 'Email address',
      companyLabel: 'Organization (optional)',
      privacyNote: 'We respect your privacy. Opt-out anytime.',
      verificationInfo:
        'We sent a verification code to your inbox. Enter “CONFIRM” below to complete your Double Opt-In.',
      codeLabel: 'Verification code',
      submitLabel: 'Получить бесплатный пробный урок',
      confirmLabel: 'Confirm subscription',
      successMessage: 'Verification accepted. Redirecting…',
      errorMessage: 'Please enter the code exactly as provided: CONFIRM.'
    },
    contact: {
      addressLabel: 'Office',
      addressValue: 'Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina',
      phoneLabel: 'Phone',
      phoneValue: '+54 11 5555-1234',
      emailLabel: 'Email',
      emailValue: 'hola@tuprogresohoy.com',
      hoursLabel: 'Office hours',
      hoursValue: 'Mon–Fri 9:00–18:00 (ART)',
      socialLabel: 'Connect',
      formTitle: 'Send us a message',
      nameLabel: 'Your name',
      emailFieldLabel: 'Email',
      subjectLabel: 'Subject',
      messageLabel: 'Message',
      submitLabel: 'Send message',
      success: 'Message sent! We will follow up soon.',
      error: 'Please complete all required fields.'
    },
    resourcesPage: {
      title: 'Resources',
      subtitle: 'Articles and glossaries available in English and Español.',
      articlesTitle: 'Latest articles',
      glossaryTitle: 'Key glossary terms',
      articles: [
        {
          id: 1,
          title: 'Understanding Argentina CPI Components',
          lang: 'EN',
          description:
            'Explore the weighted categories driving monthly CPI moves and learn how to interpret INDEC releases.',
          linkLabel: 'Read article'
        },
        {
          id: 2,
          title: 'Cómo equilibrar tu presupuesto frente a la inflación',
          lang: 'ES',
          description:
            'Una guía paso a paso para reorganizar gastos esenciales y mantener objetivos financieros realistas.',
          linkLabel: 'Leer artículo'
        },
        {
          id: 3,
          title: 'FX Scenarios: Official vs. MEP vs. Blue',
          lang: 'EN/ES',
          description:
            'Case-based comparison of exchange rate paths and what they mean for household planning.',
          linkLabel: 'Open briefing'
        }
      ],
      glossary: [
        {
          term: 'CPI',
          definition:
            'Consumer Price Index published by INDEC on a monthly cadence.'
        },
        {
          term: 'FX Spread',
          definition: 'Difference between official and parallel ARS exchange rates.'
        },
        {
          term: 'Unidad de Valor Adquisitivo (UVA)',
          definition:
            'Argentinian inflation-adjusted unit used for mortgages and savings.'
        }
      ]
    },
    inflationPage: {
      title: 'Inflation methodology',
      subtitle:
        'We translate complex CPI and FX signals into digestible learning blocks.',
      methodology: [
        'Collect granular CPI data sets from INDEC and trusted provincial observatories.',
        'Normalize the data with seasonal adjustments and track rolling three-month trends.',
        'Overlay FX corridors including official, blue-chip swap, and futures to illustrate scenario bands.',
        'Annotate each update with qualitative insights from economists and public policy experts.'
      ],
      chartsTitle: 'Visual dashboards',
      charts: [
        {
          title: 'CPI vs. Target Corridor',
          description:
            'Monthly CPI compared with analyst target bands. Values above corridor highlight risk of further devaluation.'
        },
        {
          title: 'ARS Devaluation Monitor',
          description:
            'Daily ARS→USD movements with stress thresholds to contextualize volatility.'
        },
        {
          title: 'Household Basket Pulse',
          description:
            'Quarterly cost-of-living adjustments across Buenos Aires, Córdoba, and Mendoza.'
        }
      ],
      contextTitle: 'CPI & FX context',
      contextParagraphs: [
        'Análisis transparentes y datos de mercado para decidir con seguridad. Each release is paired with a plain-language explainer and workbook prompts.',
        'Información confiable que respalda elecciones responsables sobre tu dinero. We emphasize responsible budgeting actions instead of speculative moves.',
        'Datos verificados para planificar tu presupuesto. Sources are cited and cross-checked before publishing.'
      ],
      faqTitle: 'FAQ',
      faqs: [
        {
          question: 'Do you provide financial advice or investment services?',
          answer:
            'No. Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
        },
        {
          question: 'How often is the data updated?',
          answer:
            'CPI visuals refresh monthly while FX trackers update daily with intraday notes when volatility spikes.'
        },
        {
          question: 'Can I download the datasets?',
          answer:
            'Yes. Subscribers receive CSV exports and Google Sheet dashboards after completing the Double Opt-In.'
        }
      ]
    },
    coursePage: {
      title: 'Course syllabus',
      subtitle:
        'Structure your learning with focused modules that tie macro trends to personal finance fundamentals.',
      syllabusTitle: 'Syllabus snapshot',
      modules: [
        {
          title: 'Orientation',
          description:
            'Welcome session, platform walkthrough, and baseline knowledge assessment.'
        },
        {
          title: 'Macro fundamentals',
          description:
            'Argentina inflation history, policy levers, and FX mechanics.'
        },
        {
          title: 'Budget resilience',
          description:
            'Tools to stress-test income and expenses under multiple inflation scenarios.'
        },
        {
          title: 'Decision frameworks',
          description:
            'Decisiones responsables, objetivos nítidos. Convert data into practical, aligned choices.'
        }
      ],
      forWhomTitle: 'Who is it for?',
      forWhomList: [
        'Young professionals navigating salary negotiations in Argentina.',
        'Households balancing ARS income with USD-linked expenses.',
        'Community leaders guiding financial literacy workshops.'
      ],
      outcomesTitle: 'Learning outcomes',
      outcomesList: [
        'Interpret core inflation datasets without jargon.',
        'Build adaptable budgets anchored in verified information.',
        'Design contingency plans aligned with personal goals.'
      ],
      ctaLabel: 'Go to enrollment form'
    },
    contactPage: {
      title: 'Contact Tu Progreso Hoy',
      subtitle:
        'We welcome questions from learners, community organizations, and the media.',
      mapTitle: 'Visit us in Buenos Aires'
    },
    thankYouPage: {
      title: 'Thank you!',
      subtitle:
        'Your Double Opt-In is confirmed. Expect the welcome email with your complimentary lesson shortly.',
      nextSteps: [
        'Add hola@tuprogresohoy.com to your trusted senders list.',
        'Complete the onboarding checklist included in the email.',
        'Join the next live cohort Q&A every Wednesday at 19:00 ART.'
      ],
      backHome: 'Return to homepage'
    },
    privacyPage: {
      title: 'Privacy Policy',
      intro:
        'We are committed to protecting your personal information and maintaining transparency about how data is collected, used, and stored.',
      sections: [
        {
          heading: 'Data collection',
          body:
            'We collect contact details and learning preferences strictly for delivering educational content and updates. Forms require explicit consent via our Double Opt-In flow.'
        },
        {
          heading: 'Use of information',
          body:
            'Personal data is used to send course materials, inflation briefings, and relevant updates. We do not sell or share your information with third parties.'
        },
        {
          heading: 'Data retention',
          body:
            'Data is retained while you maintain an active subscription or until you request deletion. Requests are processed within 30 days.'
        },
        {
          heading: 'Your rights',
          body:
            'You can access, rectify, or delete your information at any time by contacting hola@tuprogresohoy.com.'
        }
      ],
      updated: 'Last updated: March 2024'
    },
    cookiesPage: {
      title: 'Cookie Policy',
      intro:
        'This policy describes how Tu Progreso Hoy uses cookies and similar technologies on our website.',
      sections: [
        {
          heading: 'What are cookies?',
          body:
            'Cookies are small text files stored on your device to help us remember your preferences and improve your experience.'
        },
        {
          heading: 'Types of cookies we use',
          body:
            'We use essential cookies for site functionality and analytics cookies to understand how our platform is used. Analytics cookies are optional and require your consent.'
        },
        {
          heading: 'Managing cookies',
          body:
            'You can adjust your preferences through our cookie banner at any time or configure your browser settings to manage cookies.'
        }
      ],
      updated: 'Last updated: March 2024'
    },
    termsPage: {
      title: 'Terms & Conditions',
      intro:
        'These terms govern your use of the Tu Progreso Hoy platform and services.',
      sections: [
        {
          heading: 'Acceptance of terms',
          body:
            'By accessing our website or enrolling in the course, you agree to these terms and all applicable laws and regulations.'
        },
        {
          heading: 'Educational purpose',
          body:
            'Our content is provided for educational purposes only. We do not guarantee financial outcomes or provide investment services.'
        },
        {
          heading: 'User responsibilities',
          body:
            'You agree not to misuse the platform, share unauthorized access, or infringe on intellectual property.'
        },
        {
          heading: 'Limitation of liability',
          body:
            'Tu Progreso Hoy is not liable for any decisions made based on the information provided. Always consider consulting a licensed professional for financial advice.'
        }
      ],
      updated: 'Last updated: March 2024'
    },
    imprintPage: {
      title: 'Imprint',
      intro: 'Tu Progreso Hoy · Educational SaaS Platform',
      details: [
        'Legal entity: Tu Progreso Hoy SRL',
        'Registration: C.A.B.A. — CUIT 30-12345678-9',
        'Registered address: Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina',
        'Phone: +54 11 5555-1234',
        'Email: hola@tuprogresohoy.com',
        'Managing directors: Laura González & Martín Rivas'
      ]
    },
    footer: {
      description:
        'An Argentina-first educational platform delivering inflation insights and personal finance learning journeys.',
      linksTitle: 'Quick links',
      legalTitle: 'Legal',
      newsletterTitle: 'Updates',
      tagline:
        'Plataforma educativa con datos esenciales, sin asesoría financiera directa.',
      sustain:
        'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
    },
    cookieBanner: {
      message:
        'We use cookies to personalize content and analyze our traffic. You can opt in or decline non-essential cookies.',
      accept: 'Accept all',
      decline: 'Decline'
    }
  },
  es: {
    meta: {
      description:
        'Tu Progreso Hoy ofrece insights de inflación argentina, seguimiento ARS→USD y un curso inicial de finanzas personales responsables.'
    },
    nav: {
      home: 'Inicio',
      inflation: 'Inflación',
      course: 'Curso',
      resources: 'Recursos',
      contact: 'Contacto'
    },
    header: {
      tagline: 'Analítica educativa para la Argentina',
      contactCta: 'Escríbenos'
    },
    hero: {
      badge: 'Argentina • Plataforma educativa',
      title: 'Planificá tus finanzas con inteligencia confiable',
      subtitle:
        'Tu Progreso Hoy integra indicadores de inflación en tiempo real, monitoreo ARS→USD y un curso guiado para decisiones responsables.',
      bullets: [
        'Datos verificados para planificar tu presupuesto.',
        'Decisiones responsables, objetivos nítidos.',
        'Conocimiento financiero impulsado por tendencias.'
      ],
      supportingLine: 'Pasos acertados hoy, mejor futuro mañana.',
      primaryCta: 'Comenzar el curso',
      secondaryCta: 'Metodología de inflación',
      stats: [
        { label: 'Personas formadas', value: '1.500+' },
        { label: 'Frecuencia de actualización', value: 'Diaria' },
        { label: 'Cobertura', value: 'Argentina (AR)' }
      ]
    },
    home: {
      keyPromises: {
        title: 'Compromisos clave',
        description:
          'Convertimos datos macroeconómicos en experiencias de aprendizaje centradas en las personas, con expectativas responsables.',
        items: [
          {
            title: 'Analítica transparente',
            description:
              'Análisis transparentes y datos de mercado para decidir con seguridad.'
          },
          {
            title: 'Elecciones responsables',
            description:
              'Información confiable que respalda elecciones responsables sobre tu dinero.'
          },
          {
            title: 'Mentalidad orientada a tendencias',
            description:
              'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.'
          },
          {
            title: 'Ética educativa',
            description:
              'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
          },
          {
            title: 'Aprendizaje que se potencia',
            description:
              'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
          }
        ]
      },
      insights: {
        title: 'Insights en tiempo real',
        description:
          'Mantente orientado con señales curadas de CPI, FX y salarios en Argentina explicadas sin tecnicismos.',
        cards: [
          {
            title: 'Seguimiento del IPC general',
            metric: '254,2% interanual',
            change: '+3,1 pts vs mes anterior',
            narrative:
              'Las presiones inflacionarias continúan con alimentos y transporte liderando la canasta.'
          },
          {
            title: 'Índice de resiliencia del ARS',
            metric: 'ARS 860,45 por USD',
            change: 'Variación spot -1,2%',
            narrative:
              'Las intervenciones del BCRA estabilizan la cotización oficial frente a la brecha con mercados paralelos.'
          },
          {
            title: 'Canasta de hogar',
            metric: 'ARS 495.700',
            change: '+6,4% mensual',
            narrative: 'Datos verificados para planificar tu presupuesto.'
          }
        ]
      },
      courseOverview: {
        title: 'Resumen del curso',
        description:
          'Un recorrido guiado desde los fundamentos macro hasta el presupuesto personal bajo presión inflacionaria.',
        modules: [
          {
            title: 'Módulo 1 · Fundamentos de inflación',
            items: [
              'Estructura del IPC argentino',
              'Dinámicas cambiarias y cepo',
              'Cuaderno de planificación de escenarios'
            ]
          },
          {
            title: 'Módulo 2 · Ingresos y gastos',
            items: [
              'Indexar salarios de manera responsable',
              'Plantillas de presupuesto ARS vs USD',
              'Fondos de emergencia en contextos volátiles'
            ]
          },
          {
            title: 'Módulo 3 · Interpretación de tendencias',
            items: [
              'Conocimiento financiero impulsado por tendencias.',
              'Fundamentos de visualización de datos',
              'Narrativas con tableros de inflación'
            ]
          },
          {
            title: 'Módulo 4 · Playbooks de acción',
            items: [
              'Protocolos de emergencia',
              'Casos comunitarios',
              'Decisiones responsables, objetivos nítidos.'
            ]
          }
        ],
        cta: 'Revisar el programa completo',
        anchorText: 'Ir al formulario de inscripción'
      },
      testimonials: {
        title: 'Voces de la comunidad',
        items: [
          {
            quote:
              '“La metodología desmitificó los comunicados del IPC y nos ayudó a fijar objetivos trimestrales realistas.”',
            name: 'María López',
            role: 'Analista FP&A, Córdoba'
          },
          {
            quote:
              '“Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. Ahora conecto macro y presupuesto personal.”',
            name: 'Julián Pérez',
            role: 'Emprendedor, Rosario'
          },
          {
            quote:
              '“Pasos acertados hoy, mejor futuro mañana. El curso me mantiene enfocada sin promesas exageradas.”',
            name: 'Ana Fernández',
            role: 'Especialista en marketing, Buenos Aires'
          }
        ]
      },
      bottomCta: {
        title: 'Actuá con claridad',
        description:
          'Integrá los insights en sesiones prácticas semanales y recibí actualizaciones estructuradas.',
        note:
          'El doble opt-in protege tu bandeja y asegura consentimiento explícito en cada paso.'
      }
    },
    tracker: {
      title: 'ARS→USD tracker',
      subtitle: 'Cotización indicativa provista por exchangerate.host',
      loading: 'Cargando cotización…',
      error:
        'No pudimos obtener la cotización en vivo. Mostramos una referencia indicativa.',
      lastUpdated: 'Última actualización',
      disclaimer:
        'Las tasas son informativas. Consultá a las instituciones oficiales antes de operar.'
    },
    doubleOpt: {
      title: 'Asegurá tu clase de prueba',
      description:
        'Completá el Double Opt-In para recibir el kit inicial de “Tu Progreso Hoy” y una micro-lección gratuita.',
      step1Title: 'Paso 1 · Solicitud de suscripción',
      step2Title: 'Paso 2 · Confirmá tu correo',
      nameLabel: 'Nombre completo',
      emailLabel: 'Correo electrónico',
      companyLabel: 'Organización (opcional)',
      privacyNote: 'Respetamos tu privacidad. Podés darte de baja cuando quieras.',
      verificationInfo:
        'Enviamos un código de verificación a tu bandeja. Ingresá “CONFIRM” para completar el Double Opt-In.',
      codeLabel: 'Código de verificación',
      submitLabel: 'Получить бесплатный пробный урок',
      confirmLabel: 'Confirmar suscripción',
      successMessage: 'Verificación aceptada. Redirigiendo…',
      errorMessage: 'Ingresá el código exactamente como fue provisto: CONFIRM.'
    },
    contact: {
      addressLabel: 'Oficina',
      addressValue: 'Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina',
      phoneLabel: 'Teléfono',
      phoneValue: '+54 11 5555-1234',
      emailLabel: 'Correo',
      emailValue: 'hola@tuprogresohoy.com',
      hoursLabel: 'Horario de atención',
      hoursValue: 'Lunes a viernes de 9:00 a 18:00 (ART)',
      socialLabel: 'Conectá',
      formTitle: 'Escribinos',
      nameLabel: 'Tu nombre',
      emailFieldLabel: 'Correo electrónico',
      subjectLabel: 'Asunto',
      messageLabel: 'Mensaje',
      submitLabel: 'Enviar mensaje',
      success: '¡Mensaje enviado! Nos pondremos en contacto pronto.',
      error: 'Completá todos los campos requeridos.'
    },
    resourcesPage: {
      title: 'Recursos',
      subtitle: 'Artículos y glosarios disponibles en English y Español.',
      articlesTitle: 'Últimos artículos',
      glossaryTitle: 'Glosario clave',
      articles: [
        {
          id: 1,
          title: 'Understanding Argentina CPI Components',
          lang: 'EN',
          description:
            'Explore the weighted categories driving monthly CPI moves and learn how to interpret INDEC releases.',
          linkLabel: 'Read article'
        },
        {
          id: 2,
          title: 'Cómo equilibrar tu presupuesto frente a la inflación',
          lang: 'ES',
          description:
            'Una guía paso a paso para reorganizar gastos esenciales y mantener objetivos financieros realistas.',
          linkLabel: 'Leer artículo'
        },
        {
          id: 3,
          title: 'FX Scenarios: Official vs. MEP vs. Blue',
          lang: 'EN/ES',
          description:
            'Comparativa basada en casos sobre los distintos caminos cambiarios y su impacto en la planificación del hogar.',
          linkLabel: 'Ver briefing'
        }
      ],
      glossary: [
        {
          term: 'IPC',
          definition:
            'Índice de Precios al Consumidor publicado por INDEC mensualmente.'
        },
        {
          term: 'Brecha cambiaria',
          definition:
            'Diferencia entre el tipo de cambio oficial y las cotizaciones paralelas del ARS.'
        },
        {
          term: 'Unidad de Valor Adquisitivo (UVA)',
          definition:
            'Unidad ajustable por inflación usada en hipotecas y ahorros argentinos.'
        }
      ]
    },
    inflationPage: {
      title: 'Metodología de inflación',
      subtitle:
        'Traducimos señales complejas de IPC y FX en bloques de aprendizaje comprensibles.',
      methodology: [
        'Recolectamos datasets desagregados del IPC de INDEC y observatorios provinciales confiables.',
        'Normalizamos los datos con ajustes estacionales y seguimos tendencias móviles trimestrales.',
        'Superponemos corredores cambiarios oficiales, CCL y futuros para ilustrar escenarios.',
        'Anotamos cada actualización con insights cualitativos de economistas y especialistas en políticas públicas.'
      ],
      chartsTitle: 'Tableros visuales',
      charts: [
        {
          title: 'IPC vs. corredor objetivo',
          description:
            'Comparación mensual del IPC con bandas de analistas. Valores por encima del corredor indican riesgo de mayor devaluación.'
        },
        {
          title: 'Monitor de devaluación del ARS',
          description:
            'Movimientos diarios ARS→USD con umbrales de estrés para contextualizar la volatilidad.'
        },
        {
          title: 'Pulso de la canasta del hogar',
          description:
            'Actualizaciones trimestrales del costo de vida en Buenos Aires, Córdoba y Mendoza.'
        }
      ],
      contextTitle: 'Contexto IPC & FX',
      contextParagraphs: [
        'Análisis transparentes y datos de mercado para decidir con seguridad. Cada informe se acompaña de explicaciones claras y ejercicios guiados.',
        'Información confiable que respalda elecciones responsables sobre tu dinero. Priorizamos acciones presupuestarias responsables en lugar de movimientos especulativos.',
        'Datos verificados para planificar tu presupuesto. Todas las fuentes se citan y verifican antes de su publicación.'
      ],
      faqTitle: 'Preguntas frecuentes',
      faqs: [
        {
          question: '¿Brindan asesoramiento financiero o servicios de inversión?',
          answer:
            'No. Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
        },
        {
          question: '¿Con qué frecuencia se actualizan los datos?',
          answer:
            'Los visuales del IPC se actualizan mensualmente y los trackers de FX diariamente, con alertas intradía cuando la volatilidad se acelera.'
        },
        {
          question: '¿Puedo descargar los datasets?',
          answer:
            'Sí. Los suscriptores reciben archivos CSV y tableros en Google Sheets tras completar el Double Opt-In.'
        }
      ]
    },
    coursePage: {
      title: 'Programa del curso',
      subtitle:
        'Estructurá tu aprendizaje con módulos enfocados que conectan las tendencias macro con los fundamentos de finanzas personales.',
      syllabusTitle: 'Panorama del programa',
      modules: [
        {
          title: 'Orientación',
          description:
            'Sesión de bienvenida, recorrido por la plataforma y evaluación de base.'
        },
        {
          title: 'Fundamentos macro',
          description:
            'Historia de la inflación en Argentina, herramientas de política y mecánicas cambiarias.'
        },
        {
          title: 'Resiliencia del presupuesto',
          description:
            'Herramientas para testear ingresos y gastos frente a múltiples escenarios inflacionarios.'
        },
        {
          title: 'Marcos de decisión',
          description:
            'Decisiones responsables, objetivos nítidos. Convertí datos en acciones alineadas.'
        }
      ],
      forWhomTitle: '¿Para quién es?',
      forWhomList: [
        'Jóvenes profesionales negociando salarios en Argentina.',
        'Hogares que equilibran ingresos en ARS con gastos vinculados al USD.',
        'Referentes comunitarios que impulsan talleres de educación financiera.'
      ],
      outcomesTitle: 'Resultados de aprendizaje',
      outcomesList: [
        'Interpretar datasets de inflación sin jerga.',
        'Construir presupuestos adaptables basados en información verificada.',
        'Diseñar planes de contingencia alineados a tus metas personales.'
      ],
      ctaLabel: 'Ir al formulario de inscripción'
    },
    contactPage: {
      title: 'Contacto Tu Progreso Hoy',
      subtitle:
        'Recibimos consultas de estudiantes, organizaciones comunitarias y medios.',
      mapTitle: 'Visitá nuestra oficina en Buenos Aires'
    },
    thankYouPage: {
      title: '¡Gracias!',
      subtitle:
        'Tu Double Opt-In está confirmado. Pronto recibirás el correo de bienvenida con tu clase de cortesía.',
      nextSteps: [
        'Agregá hola@tuprogresohoy.com a tu lista de remitentes confiables.',
        'Completá el checklist de onboarding incluido en el correo.',
        'Sumate al próximo Q&A en vivo cada miércoles a las 19:00 ART.'
      ],
      backHome: 'Volver al inicio'
    },
    privacyPage: {
      title: 'Política de privacidad',
      intro:
        'Nos comprometemos a proteger tu información personal y a mantener transparencia sobre cómo se recopila, utiliza y almacena.',
      sections: [
        {
          heading: 'Recopilación de datos',
          body:
            'Recopilamos datos de contacto y preferencias de aprendizaje exclusivamente para brindar contenido educativo y actualizaciones. Los formularios requieren consentimiento explícito mediante nuestro Double Opt-In.'
        },
        {
          heading: 'Uso de la información',
          body:
            'Los datos personales se utilizan para enviar materiales del curso, reportes de inflación y novedades relevantes. No vendemos ni compartimos tu información con terceros.'
        },
        {
          heading: 'Retención de datos',
          body:
            'Conservamos la información mientras mantengas una suscripción activa o hasta que solicites la eliminación. Las solicitudes se procesan en un máximo de 30 días.'
        },
        {
          heading: 'Tus derechos',
          body:
            'Podés acceder, rectificar o eliminar tus datos en cualquier momento escribiendo a hola@tuprogresohoy.com.'
        }
      ],
      updated: 'Última actualización: marzo 2024'
    },
    cookiesPage: {
      title: 'Política de cookies',
      intro:
        'Esta política describe cómo Tu Progreso Hoy utiliza cookies y tecnologías similares en nuestro sitio web.',
      sections: [
        {
          heading: '¿Qué son las cookies?',
          body:
            'Las cookies son pequeños archivos de texto almacenados en tu dispositivo que nos ayudan a recordar tus preferencias y mejorar tu experiencia.'
        },
        {
          heading: 'Tipos de cookies que usamos',
          body:
            'Utilizamos cookies esenciales para el funcionamiento del sitio y cookies analíticas para comprender el uso de la plataforma. Las cookies analíticas son opcionales y requieren tu consentimiento.'
        },
        {
          heading: 'Gestión de cookies',
          body:
            'Podés ajustar tus preferencias desde nuestro banner de cookies en cualquier momento o configurar tu navegador para administrarlas.'
        }
      ],
      updated: 'Última actualización: marzo 2024'
    },
    termsPage: {
      title: 'Términos y condiciones',
      intro:
        'Estos términos regulan el uso de la plataforma y servicios de Tu Progreso Hoy.',
      sections: [
        {
          heading: 'Aceptación de términos',
          body:
            'Al acceder a nuestro sitio o inscribirte en el curso, aceptás estos términos y toda la normativa aplicable.'
        },
        {
          heading: 'Propósito educativo',
          body:
            'El contenido se brinda con fines educativos. No garantizamos resultados financieros ni prestamos servicios de inversión.'
        },
        {
          heading: 'Responsabilidades del usuario',
          body:
            'Te comprometés a no hacer un uso indebido de la plataforma, compartir accesos no autorizados ni infringir la propiedad intelectual.'
        },
        {
          heading: 'Limitación de responsabilidad',
          body:
            'Tu Progreso Hoy no se responsabiliza por decisiones basadas en la información provista. Considerá consultar a un profesional matriculado para asesoramiento financiero.'
        }
      ],
      updated: 'Última actualización: marzo 2024'
    },
    imprintPage: {
      title: 'Aviso legal',
      intro: 'Tu Progreso Hoy · Plataforma educativa SaaS',
      details: [
        'Entidad legal: Tu Progreso Hoy SRL',
        'Inscripción: C.A.B.A. — CUIT 30-12345678-9',
        'Domicilio legal: Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina',
        'Teléfono: +54 11 5555-1234',
        'Correo: hola@tuprogresohoy.com',
        'Directores: Laura González & Martín Rivas'
      ]
    },
    footer: {
      description:
        'Plataforma educativa centrada en Argentina que ofrece insights de inflación e itinerarios de aprendizaje financiero.',
      linksTitle: 'Accesos rápidos',
      legalTitle: 'Legal',
      newsletterTitle: 'Actualizaciones',
      tagline:
        'Plataforma educativa con datos esenciales, sin asesoría financiera directa.',
      sustain:
        'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
    },
    cookieBanner: {
      message:
        'Utilizamos cookies para personalizar el contenido y analizar el tráfico. Podés aceptar o rechazar las cookies no esenciales.',
      accept: 'Aceptar todo',
      decline: 'Rechazar'
    }
  }
};

export default translations;
```