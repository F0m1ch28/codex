```javascript
import { Link } from 'react-router-dom';
import ARSUSDTracker from '../components/ARSUSDTracker';
import DoubleOptInForm from '../components/DoubleOptInForm';
import { useLanguage } from '../context/LanguageContext';

const Home = () => {
  const { t } = useLanguage();
  const hero = t('hero');
  const home = t('home');

  return (
    <>
      <section className="hero-section" aria-labelledby="hero-title">
        <div className="hero-overlay" />
        <div className="container hero-content">
          <span className="hero-badge">{hero.badge}</span>
          <h1 id="hero-title">{hero.title}</h1>
          <p className="hero-subtitle">{hero.subtitle}</p>
          <ul className="hero-list">
            {hero.bullets.map((bullet, index) => (
              <li key={index}>{bullet}</li>
            ))}
          </ul>
          <p className="hero-supporting">{hero.supportingLine}</p>
          <div className="hero-ctas">
            <Link to="/course" className="btn primary">
              {hero.primaryCta}
            </Link>
            <Link to="/inflation" className="btn ghost">
              {hero.secondaryCta}
            </Link>
          </div>
          <div className="hero-stats" role="list">
            {hero.stats.map((item) => (
              <div key={item.label} role="listitem">
                <span className="stat-value">{item.value}</span>
                <span className="stat-label">{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="promises-title">
        <div className="container">
          <div className="section-header">
            <h2 id="promises-title">{home.keyPromises.title}</h2>
            <p>{home.keyPromises.description}</p>
          </div>
          <div className="card-grid">
            {home.keyPromises.items.map((item) => (
              <article key={item.title} className="card">
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <ARSUSDTracker />

      <section className="section" aria-labelledby="insights-title">
        <div className="container">
          <div className="section-header">
            <h2 id="insights-title">{home.insights.title}</h2>
            <p>{home.insights.description}</p>
          </div>
          <div className="card-grid insights-grid">
            {home.insights.cards.map((card) => (
              <article key={card.title} className="insight-card">
                <h3>{card.title}</h3>
                <div className="insight-metric">{card.metric}</div>
                <div className="insight-change">{card.change}</div>
                <p>{card.narrative}</p>
                <div className="insight-bar" aria-hidden="true">
                  <span />
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section course-overview" aria-labelledby="course-title">
        <div className="container">
          <div className="section-header">
            <h2 id="course-title">{home.courseOverview.title}</h2>
            <p>{home.courseOverview.description}</p>
            <div className="course-anchors">
              <Link to="/course" className="btn ghost">
                {home.courseOverview.cta}
              </Link>
              <a href="#signupForm" className="anchor-link">
                {home.courseOverview.anchorText}
              </a>
            </div>
          </div>
          <div className="module-grid">
            {home.courseOverview.modules.map((module) => (
              <article key={module.title} className="module-card">
                <h3>{module.title}</h3>
                <ul>
                  {module.items.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section testimonials" aria-labelledby="testimonials-title">
        <div className="container">
          <div className="section-header">
            <h2 id="testimonials-title">{home.testimonials.title}</h2>
          </div>
          <div className="testimonial-grid">
            {home.testimonials.items.map((item) => (
              <blockquote key={item.name} className="testimonial-card">
                <p>{item.quote}</p>
                <footer>
                  <span className="name">{item.name}</span>
                  <span className="role">{item.role}</span>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className="section bottom-cta" aria-labelledby="bottom-cta-title">
        <div className="container bottom-cta-container">
          <div>
            <h2 id="bottom-cta-title">{home.bottomCta.title}</h2>
            <p>{home.bottomCta.description}</p>
            <p className="note">{home.bottomCta.note}</p>
          </div>
        </div>
      </section>

      <DoubleOptInForm />
    </>
  );
};

export default Home;
```