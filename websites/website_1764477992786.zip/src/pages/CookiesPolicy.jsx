```javascript
import { useLanguage } from '../context/LanguageContext';

const CookiesPolicy = () => {
  const { t } = useLanguage();
  const content = t('cookiesPage');

  return (
    <div className="page legal">
      <section className="page-hero">
        <div className="container">
          <h1>{content.title}</h1>
          <p>{content.intro}</p>
          <p className="legal-updated">{content.updated}</p>
        </div>
      </section>
      <section className="section">
        <div className="container legal-content">
          {content.sections.map((section) => (
            <article key={section.heading}>
              <h2>{section.heading}</h2>
              <p>{section.body}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default CookiesPolicy;
```