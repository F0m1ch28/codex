```javascript
import { useLanguage } from '../context/LanguageContext';

const Imprint = () => {
  const { t } = useLanguage();
  const content = t('imprintPage');

  return (
    <div className="page legal">
      <section className="page-hero">
        <div className="container">
          <h1>{content.title}</h1>
          <p>{content.intro}</p>
        </div>
      </section>
      <section className="section">
        <div className="container legal-content">
          <ul className="imprint-list">
            {content.details.map((detail) => (
              <li key={detail}>{detail}</li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
};

export default Imprint;
```