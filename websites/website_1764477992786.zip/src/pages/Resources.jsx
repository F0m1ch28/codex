```javascript
import { useLanguage } from '../context/LanguageContext';

const Resources = () => {
  const { t } = useLanguage();
  const content = t('resourcesPage');

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>{content.title}</h1>
          <p>{content.subtitle}</p>
        </div>
      </section>

      <section className="section" aria-labelledby="articles-heading">
        <div className="container">
          <h2 id="articles-heading">{content.articlesTitle}</h2>
          <div className="card-grid">
            {content.articles.map((article) => (
              <article key={article.id} className="card resource-card">
                <div className="resource-lang">{article.lang}</div>
                <h3>{article.title}</h3>
                <p>{article.description}</p>
                <a
                  className="resource-link"
                  href={`https://www.tuprogresohoy.com/resources/article-${article.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {article.linkLabel}
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="glossary-heading">
        <div className="container">
          <h2 id="glossary-heading">{content.glossaryTitle}</h2>
          <dl className="glossary">
            {content.glossary.map((item) => (
              <div key={item.term}>
                <dt>{item.term}</dt>
                <dd>{item.definition}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>
    </div>
  );
};

export default Resources;
```