```javascript
import { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

const Contact = () => {
  const { t } = useLanguage();
  const contact = t('contact');
  const page = t('contactPage');
  const [status, setStatus] = useState(null);

  const handleSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const valid =
      form.name.value.trim() &&
      form.email.value.trim() &&
      form.subject.value.trim() &&
      form.message.value.trim();
    if (!valid) {
      setStatus({ type: 'error', message: contact.error });
      return;
    }
    setStatus({ type: 'success', message: contact.success });
    form.reset();
  };

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>{page.title}</h1>
          <p>{page.subtitle}</p>
        </div>
      </section>

      <section className="section" aria-labelledby="contact-info-heading">
        <div className="container contact-grid">
          <div>
            <h2 id="contact-info-heading">{contact.formTitle}</h2>
            <form className="contact-form" onSubmit={handleSubmit}>
              <label htmlFor="name">{contact.nameLabel}</label>
              <input id="name" name="name" type="text" required />
              <label htmlFor="email">{contact.emailFieldLabel}</label>
              <input id="email" name="email" type="email" required />
              <label htmlFor="subject">{contact.subjectLabel}</label>
              <input id="subject" name="subject" type="text" required />
              <label htmlFor="message">{contact.messageLabel}</label>
              <textarea id="message" name="message" rows="4" required />
              {status && (
                <p
                  className={`form-${status.type}`}
                  role={status.type === 'error' ? 'alert' : 'status'}
                >
                  {status.message}
                </p>
              )}
              <button type="submit" className="btn primary">
                {contact.submitLabel}
              </button>
            </form>
          </div>
          <aside className="contact-details">
            <h3>{page.mapTitle}</h3>
            <iframe
              title="Tu Progreso Hoy office map"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.1335247748584!2d-58.385312524561016!3d-34.60056535852638!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccacbcbf9f9d1%3A0x3c7fe5adb56c7cc5!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA!5e0!3m2!1ses-419!2sar!4v1700000000000!5m2!1ses-419!2sar"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
            <ul className="contact-info">
              <li>
                <strong>{contact.addressLabel}:</strong> {contact.addressValue}
              </li>
              <li>
                <strong>{contact.phoneLabel}:</strong> {contact.phoneValue}
              </li>
              <li>
                <strong>{contact.emailLabel}:</strong>{' '}
                <a href="mailto:hola@tuprogresohoy.com">
                  {contact.emailValue}
                </a>
              </li>
              <li>
                <strong>{contact.hoursLabel}:</strong> {contact.hoursValue}
              </li>
              <li>
                <strong>{contact.socialLabel}:</strong>{' '}
                <a
                  href="https://www.linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  LinkedIn
                </a>{' '}
                ·{' '}
                <a
                  href="https://www.instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Instagram
                </a>
              </li>
            </ul>
          </aside>
        </div>
      </section>
    </div>
  );
};

export default Contact;
```