```javascript
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const Course = () => {
  const { t } = useLanguage();
  const content = t('coursePage');

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>{content.title}</h1>
          <p>{content.subtitle}</p>
          <a href="#signupForm" className="btn primary">
            {content.ctaLabel}
          </a>
        </div>
      </section>

      <section className="section" aria-labelledby="syllabus-heading">
        <div className="container">
          <h2 id="syllabus-heading">{content.syllabusTitle}</h2>
          <div className="card-grid">
            {content.modules.map((module) => (
              <article key={module.title} className="card">
                <h3>{module.title}</h3>
                <p>{module.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="for-whom-heading">
        <div className="container">
          <h2 id="for-whom-heading">{content.forWhomTitle}</h2>
          <ul className="checklist">
            {content.forWhomList.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </div>
      </section>

      <section className="section" aria-labelledby="outcomes-heading">
        <div className="container">
          <h2 id="outcomes-heading">{content.outcomesTitle}</h2>
          <ul className="checklist">
            {content.outcomesList.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <Link to="/" className="btn ghost">
            {t('nav.home')}
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Course;
```