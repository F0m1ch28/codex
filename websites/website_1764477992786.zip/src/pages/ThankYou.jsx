```javascript
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const ThankYou = () => {
  const { t } = useLanguage();
  const content = t('thankYouPage');

  return (
    <div className="page">
      <section className="page-hero thank-you">
        <div className="container">
          <h1>{content.title}</h1>
          <p>{content.subtitle}</p>
          <ul className="checklist">
            {content.nextSteps.map((step, index) => (
              <li key={index}>{step}</li>
            ))}
          </ul>
          <Link to="/" className="btn primary">
            {content.backHome}
          </Link>
        </div>
      </section>
    </div>
  );
};

export default ThankYou;
```