```javascript
import { useLanguage } from '../context/LanguageContext';

const Inflation = () => {
  const { t } = useLanguage();
  const content = t('inflationPage');

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>{content.title}</h1>
          <p>{content.subtitle}</p>
        </div>
      </section>

      <section className="section" aria-labelledby="methodology-heading">
        <div className="container">
          <h2 id="methodology-heading">Methodology</h2>
          <ol className="methodology-list">
            {content.methodology.map((step, index) => (
              <li key={index}>{step}</li>
            ))}
          </ol>
        </div>
      </section>

      <section className="section" aria-labelledby="charts-heading">
        <div className="container">
          <h2 id="charts-heading">{content.chartsTitle}</h2>
          <div className="card-grid">
            {content.charts.map((chart) => (
              <article key={chart.title} className="card chart-card">
                <h3>{chart.title}</h3>
                <p>{chart.description}</p>
                <div className="chart-placeholder" role="img" aria-label={chart.title}>
                  <span />
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="context-heading">
        <div className="container">
          <h2 id="context-heading">{content.contextTitle}</h2>
          {content.contextParagraphs.map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
        </div>
      </section>

      <section className="section" aria-labelledby="faq-heading">
        <div className="container">
          <h2 id="faq-heading">{content.faqTitle}</h2>
          <div className="faq-list">
            {content.faqs.map((faq, index) => (
              <details key={index}>
                <summary>{faq.question}</summary>
                <p>{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Inflation;
```