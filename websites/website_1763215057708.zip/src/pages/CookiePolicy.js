```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PolicyPage.module.css';

const CookiePolicy = () => {
  return (
    <div className={styles.policy}>
      <Helmet>
        <title>Cookie Policy | TechSolutions</title>
        <meta
          name="description"
          content="Understand how TechSolutions uses cookies and similar technologies to improve your browsing experience."
        />
      </Helmet>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p className={styles.lastUpdated}>Last updated: January 3, 2024</p>

        <section>
          <h2>1. What are cookies?</h2>
          <p>
            Cookies are small text files placed on your device when you visit a
            website. They help websites remember your preferences and provide
            insight into how the site is used.
          </p>
        </section>

        <section>
          <h2>2. How we use cookies</h2>
          <p>
            TechSolutions uses cookies and similar technologies for the
            following purposes:
          </p>
          <ul>
            <li>
              <strong>Essential cookies</strong> that enable core functionality
              such as security, accessibility, and page navigation.
            </li>
            <li>
              <strong>Performance cookies</strong> that help us understand how
              visitors engage with the site so we can improve content and
              usability.
            </li>
            <li>
              <strong>Preference cookies</strong> that remember your settings,
              such as language or cookie consent choices.
            </li>
          </ul>
        </section>

        <section>
          <h2>3. Third-party cookies</h2>
          <p>
            We may partner with third-party service providers who place cookies
            on our site to support analytics or embedded content. These parties
            may collect information about your online activities over time and
            across different websites.
          </p>
        </section>

        <section>
          <h2>4. Managing cookies</h2>
          <p>
            You can manage or delete cookies through your browser settings.
            Doing so may affect how certain features of the site function. You
            can also revisit our cookie banner to update your preferences.
          </p>
        </section>

        <section>
          <h2>5. Updates to this policy</h2>
          <p>
            We may revise this Cookie Policy to reflect changes in technology or
            legal requirements. Any updates will be posted on this page with a
            new effective date.
          </p>
        </section>

        <section>
          <h2>6. Contact us</h2>
          <p>
            If you have questions about our use of cookies, please contact us at:
          </p>
          <address>
            TechSolutions
            <br />
            123 Tech Avenue, Innovation District
            <br />
            San Francisco, CA 94105
            <br />
            Phone: +1 (555) 123-4567
            <br />
            Email: <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
          </address>
        </section>
      </div>
    </div>
  );
};

export default CookiePolicy;
```