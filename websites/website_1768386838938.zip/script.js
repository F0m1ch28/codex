document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.mobile-nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            primaryNav.dataset.visible = String(!isExpanded);
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('[data-cookie="accept"]');
    const declineBtn = document.querySelector('[data-cookie="decline"]');

    const showCookieBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.add('active');
        }
    };

    const hideCookieBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.remove('active');
        }
    };

    const storedConsent = localStorage.getItem('cpc-cookie-consent');
    if (!storedConsent) {
        setTimeout(showCookieBanner, 600);
    }

    if (acceptBtn) {
        acceptBtn.addEventListener('click', () => {
            localStorage.setItem('cpc-cookie-consent', 'accepted');
            hideCookieBanner();
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener('click', () => {
            localStorage.setItem('cpc-cookie-consent', 'declined');
            hideCookieBanner();
        });
    }

    if (document.body.classList.contains('posts-page')) {
        const searchInput = document.querySelector('#searchPosts');
        const filterButtons = document.querySelectorAll('.filter-tags button');
        const postCards = document.querySelectorAll('[data-category]');
        const resultsCount = document.querySelector('#resultsCount');
        const noResultsMessage = document.querySelector('#noResultsMessage');
        let activeCategory = 'toate';

        const updateFilters = () => {
            const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
            let visibleCount = 0;

            postCards.forEach(card => {
                const categories = card.dataset.category.split(' ');
                const title = card.querySelector('.card-title') ? card.querySelector('.card-title').textContent.toLowerCase() : '';
                const excerpt = card.querySelector('.card-excerpt') ? card.querySelector('.card-excerpt').textContent.toLowerCase() : '';
                const matchesCategory = activeCategory === 'toate' || categories.includes(activeCategory);
                const matchesSearch = !query || title.includes(query) || excerpt.includes(query);

                if (matchesCategory && matchesSearch) {
                    card.classList.remove('is-hidden');
                    visibleCount += 1;
                } else {
                    card.classList.add('is-hidden');
                }
            });

            if (resultsCount) {
                resultsCount.textContent = visibleCount;
            }

            if (noResultsMessage) {
                noResultsMessage.classList.toggle('is-hidden', visibleCount !== 0);
            }
        };

        if (searchInput) {
            searchInput.addEventListener('input', updateFilters);
        }

        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                filterButtons.forEach(btn => btn.setAttribute('aria-pressed', 'false'));
                button.setAttribute('aria-pressed', 'true');
                activeCategory = button.dataset.filter;
                updateFilters();
            });
        });

        updateFilters();
    }
});