import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={styles.header} role="banner">
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="VerdantFlow Hydro Solutions Inicio">
          <span className={styles.logoIcon}>VF</span>
          <div>
            <span className={styles.logoText}>VerdantFlow</span>
            <span className={styles.logoSub}>Hydro Solutions</span>
          </div>
        </Link>
        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Navegación principal">
          <NavLink to="/" end className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}>Inicio</NavLink>
          <NavLink to="/servicios" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}>Servicios</NavLink>
          <NavLink to="/tecnologias" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}>Tecnologías</NavLink>
          <NavLink to="/proyectos" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}>Proyectos</NavLink>
          <NavLink to="/investigacion" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}>Investigación</NavLink>
          <NavLink to="/nosotros" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}>Sobre VerdantFlow</NavLink>
          <NavLink to="/contacto" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}>Contacto</NavLink>
        </nav>
        <button
          className={styles.menuButton}
          type="button"
          aria-label="Abrir menú de navegación"
          aria-expanded={isMenuOpen}
          onClick={() => setMenuOpen(!isMenuOpen)}
        >
          <span className={styles.menuBar}></span>
          <span className={styles.menuBar}></span>
          <span className={styles.menuBar}></span>
        </button>
      </div>
    </header>
  );
};

export default Header;