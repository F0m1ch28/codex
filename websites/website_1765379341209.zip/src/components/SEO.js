import { useEffect } from 'react';

const SEO = ({ title, description, keywords }) => {
  useEffect(() => {
    const defaultTitle = 'VerdantFlow Hydro Solutions';
    const fullTitle = title ? `${title} | VerdantFlow Hydro Solutions` : defaultTitle;
    document.title = fullTitle;

    const updateMeta = (name, content) => {
      if (!content) {
        return;
      }
      let element = document.querySelector(`meta[name="${name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('name', name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    updateMeta('description', description || 'Plataforma de ingeniería hidroeléctrica con enfoque en sistemas minihidráulicos, optimización fluvial e integración agua-energía.');
    updateMeta('keywords', keywords || 'energía hidroeléctrica, microcentrales, turbinas hidráulicas, flujo fluvial, minihydro, gestión hídrica, energía renovable España, turbinas Kaplan, sistemas run-of-river, ingeniería fluvial');
  }, [title, description, keywords]);

  return null;
};

export default SEO;