import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.inner}>
        <div className={styles.brandColumn}>
          <div className={styles.logoGroup}>
            <div className={styles.logoIcon}>VF</div>
            <div>
              <p className={styles.brandTitle}>VerdantFlow Hydro Solutions</p>
              <p className={styles.brandSubtitle}>Energía fluvial, sostenibilidad integrada</p>
            </div>
          </div>
          <p className={styles.brandDescription}>
            Plataforma española especializada en soluciones hidroeléctricas de pequeña escala, optimización de cauces fluviales y gestión integrada del recurso hídrico-energético.
          </p>
        </div>
        <div className={styles.columnsWrapper}>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Navegación</h3>
            <ul className={styles.linkList}>
              <li><Link to="/" className={styles.link}>Inicio</Link></li>
              <li><Link to="/servicios" className={styles.link}>Servicios</Link></li>
              <li><Link to="/tecnologias" className={styles.link}>Tecnologías</Link></li>
              <li><Link to="/proyectos" className={styles.link}>Proyectos</Link></li>
              <li><Link to="/investigacion" className={styles.link}>Investigación</Link></li>
              <li><Link to="/nosotros" className={styles.link}>Sobre VerdantFlow</Link></li>
              <li><Link to="/contacto" className={styles.link}>Contacto</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Documentos</h3>
            <ul className={styles.linkList}>
              <li><Link to="/terminos" className={styles.link}>Términos de Servicio</Link></li>
              <li><Link to="/privacidad" className={styles.link}>Política de Privacidad</Link></li>
              <li><Link to="/cookies" className={styles.link}>Política de Cookies</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Contacto</h3>
            <address className={styles.address}>
              Avenida Diagonal 640<br />
              08017 Barcelona, Spain
            </address>
            <a className={styles.contactLink} href="tel:+34932285167">Tel: +34 932 28 51 67</a>
            <a className={styles.contactLink} href="mailto:info@verdantflow.com">Email: info@verdantflow.com</a>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p className={styles.bottomText}>© {currentYear} VerdantFlow Hydro Solutions. Todos los derechos reservados.</p>
      </div>
    </footer>
  );
};

export default Footer;