import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem('verdantflow-cookie-consent');
    if (storedConsent !== 'accepted') {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('verdantflow-cookie-consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="assertive">
      <div className={styles.text}>
        Utilizamos cookies analíticas para mejorar la experiencia y comprender el rendimiento de nuestras soluciones hidroeléctricas. Al continuar, acepta su uso.
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Aceptar
      </button>
    </div>
  );
};

export default CookieBanner;