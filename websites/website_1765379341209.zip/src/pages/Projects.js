import React, { useState } from 'react';
import SEO from '../components/SEO';
import styles from './Projects.module.css';

const projectData = [
  {
    title: 'Microcentral escalonada en el río Noguera Pallaresa',
    description: 'Tres módulos run-of-river con turbinas Kaplan de baja carga y derivaciones laterales para proteger la ictiofauna.',
    location: 'Lleida',
    category: 'Minihidráulica',
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1000&q=80'
  },
  {
    title: 'Optimización de caudal ecológico en el río Guadalhorce',
    description: 'Modelación 2D, compuertas inteligentes y sensórica en continuo para asegurar conectividad longitudinal.',
    location: 'Málaga',
    category: 'Gestión fluvial',
    image: 'https://images.unsplash.com/photo-1527874529935-0b997cb297ec?auto=format&fit=crop&w=1000&q=80'
  },
  {
    title: 'Modernización de central histórica en el río Arga',
    description: 'Retrofit de generadores, incorporación de control digital y sistema híbrido hidro-solar con baterías.',
    location: 'Navarra',
    category: 'Modernización',
    image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1000&q=80'
  },
  {
    title: 'Laboratorio vivo de sedimentos en el Segura',
    description: 'Simulación de transporte sólido, trampas de sedimentos y restitución morfológica en colaboración con universidades.',
    location: 'Murcia',
    category: 'Investigación',
    image: 'https://images.unsplash.com/photo-1500043204469-092763a5e13f?auto=format&fit=crop&w=1000&q=80'
  },
  {
    title: 'Microgrid hidroeléctrica en Val d’Aran',
    description: 'Integración de microturbinas con almacenamiento y control predictivo para redes aisladas en entornos alpinos.',
    location: 'Lleida',
    category: 'Minihidráulica',
    image: 'https://images.unsplash.com/photo-1465146633011-14f67587ff45?auto=format&fit=crop&w=1000&q=80'
  },
  {
    title: 'Restauración fluvial en el Júcar',
    description: 'Soluciones basadas en la naturaleza que combinan energías renovables, reforestación ribereña y mejora de hábitats.',
    location: 'Valencia',
    category: 'Gestión fluvial',
    image: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&w=1000&q=80'
  }
];

const categories = ['Todos', 'Minihidráulica', 'Gestión fluvial', 'Modernización', 'Investigación'];

const Projects = () => {
  const [activeCategory, setActiveCategory] = useState('Todos');

  const filteredProjects = activeCategory === 'Todos'
    ? projectData
    : projectData.filter(project => project.category === activeCategory);

  return (
    <>
      <SEO
        title="Proyectos"
        description="Casos de VerdantFlow Hydro Solutions: microcentrales run-of-river, modernización de turbinas, laboratorios vivos y gestión de sedimentos en ríos españoles."
      />
      <section className="section">
        <div className="container">
          <header className={styles.header}>
            <h1 className="section-title">Proyectos destacados</h1>
            <p className="section-subtitle">Cada proyecto refleja nuestra capacidad para integrar energía, hidráulica y criterios ambientales con precisión en España.</p>
          </header>

          <div className={styles.filters}>
            {categories.map(category => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${activeCategory === category ? styles.filterActive : ''}`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>

          <div className={styles.grid}>
            {filteredProjects.map(project => (
              <article key={project.title} className={styles.card}>
                <img src={project.image} alt={project.title} />
                <div className={styles.cardBody}>
                  <div className={styles.cardMeta}>
                    <span className={styles.badge}>{project.category}</span>
                    <span className={styles.location}>{project.location}</span>
                  </div>
                  <h2>{project.title}</h2>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Projects;