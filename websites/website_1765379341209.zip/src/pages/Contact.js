import React, { useState } from 'react';
import SEO from '../components/SEO';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({ nombre: '', email: '', organizacion: '', mensaje: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ submitted: false, success: false });

  const handleChange = event => {
    const { name, value } = event.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.nombre.trim()) newErrors.nombre = 'Introduzca su nombre.';
    if (!formData.email.trim()) {
      newErrors.email = 'Introduzca un correo electrónico.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(formData.email)) {
      newErrors.email = 'Correo electrónico no válido.';
    }
    if (!formData.mensaje.trim()) newErrors.mensaje = 'Cuéntenos su proyecto o consulta.';
    return newErrors;
  };

  const handleSubmit = event => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setStatus({ submitted: true, success: false });
    setTimeout(() => {
      setStatus({ submitted: true, success: true });
      setFormData({ nombre: '', email: '', organizacion: '', mensaje: '' });
    }, 1200);
  };

  return (
    <>
      <SEO
        title="Contacto"
        description="Contacte con VerdantFlow Hydro Solutions en Barcelona para proyectos hidroeléctricos, optimización fluvial y soluciones de integración agua-energía."
      />
      <section className="section">
        <div className="container">
          <div className={styles.header}>
            <div>
              <h1 className="section-title">Contacto</h1>
              <p className="section-subtitle">Comparta los retos de su cauce. Nuestro equipo técnico responderá con propuestas basadas en datos.</p>
              <div className={styles.contactDetails}>
                <div>
                  <h3>Dirección</h3>
                  <p>Avenida Diagonal 640<br />08017 Barcelona, Spain</p>
                </div>
                <div>
                  <h3>Teléfono</h3>
                  <a href="tel:+34932285167">+34 932 28 51 67</a>
                </div>
                <div>
                  <h3>Email</h3>
                  <a href="mailto:info@verdantflow.com">info@verdantflow.com</a>
                </div>
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="nombre">Nombre completo *</label>
                <input
                  id="nombre"
                  name="nombre"
                  type="text"
                  value={formData.nombre}
                  onChange={handleChange}
                  aria-invalid={!!errors.nombre}
                />
                {errors.nombre && <span className={styles.error}>{errors.nombre}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Correo electrónico *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={!!errors.email}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="organizacion">Organización</label>
                <input
                  id="organizacion"
                  name="organizacion"
                  type="text"
                  value={formData.organizacion}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="mensaje">Descripción del proyecto o consulta *</label>
                <textarea
                  id="mensaje"
                  name="mensaje"
                  rows="5"
                  value={formData.mensaje}
                  onChange={handleChange}
                  aria-invalid={!!errors.mensaje}
                ></textarea>
                {errors.mensaje && <span className={styles.error}>{errors.mensaje}</span>}
              </div>
              <button type="submit" className={styles.submitButton} disabled={status.submitted && !status.success}>
                {status.submitted && !status.success ? 'Enviando...' : 'Enviar mensaje'}
              </button>
              {status.success && <p className={styles.success}>Gracias. Hemos recibido su mensaje y le contactaremos en breve.</p>}
            </form>
          </div>
        </div>
      </section>
      <section className={styles.mapSection}>
        <iframe
          title="Ubicación VerdantFlow Hydro Solutions"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2995.930931783301!2d2.12446157688183!3d41.3926370712988!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a4a2ee9c3f7f1d%3A0x939d9b4eef6c2455!2sAvinguda%20Diagonal%2C%20640%2C%2008017%20Barcelona!5e0!3m2!1ses!2ses!4v1712858400000!5m2!1ses!2ses"
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </section>
    </>
  );
};

export default Contact;