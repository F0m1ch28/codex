import React from 'react';
import SEO from '../components/SEO';
import styles from './Technologies.module.css';

const technologyFamilies = [
  {
    title: 'Turbinas y generadores',
    points: [
      'Turbinas Kaplan S con álabes móviles optimizados para caudales medios-bajos',
      'Turbinas Pelton y Turgo para saltos de alta energía con inyección múltiple',
      'Turbinas de flujo cruzado con diseño modular para ríos de montaña',
      'Generadores síncronos y asíncronos con sistemas de excitación digitales'
    ],
    image: 'https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Automatización y sensórica',
    points: [
      'Plataformas SCADA con redundancia y protocolos IEC 60870-5-104',
      'Redes de sensores IoT para niveles, vibraciones y temperatura',
      'Sistemas LiDAR y radar para medición de crema y nieve',
      'Control predictivo basado en modelos híbridos físicos-datos'
    ],
    image: 'https://images.unsplash.com/photo-1580894897200-6ff3c3af83c7?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Gestión ambiental',
    points: [
      'Software para balance sedimentario y modelación morfológica',
      'Monitorización acústica de fauna y control de velocidad de paso',
      'Compuertas inteligentes con regulación de caudal ecológico',
      'Simulaciones de calidad de agua acopladas a dinámicas fluviales'
    ],
    image: 'https://images.unsplash.com/photo-1500322963343-3e25aa543172?auto=format&fit=crop&w=900&q=80'
  }
];

const integrationStack = [
  {
    title: 'Gemelo digital VerdantFlow',
    description: 'Unifica datos de estaciones hidrométricas, sensores instalados, satélite y meteorología. Genera escenarios en tiempo real y recomendaciones de operación.',
    tags: ['IoT', 'Modelación CFD', 'Análisis predictivo']
  },
  {
    title: 'Centro de control Barcelona',
    description: 'Infraestructura de teleoperación con ciberseguridad industrial, respaldos redundantes y soporte permanente de ingenieras especialistas.',
    tags: ['SCADA', 'IEC 61850', 'Monitorización remota']
  },
  {
    title: 'Suite ambiental fluvial',
    description: 'Herramientas para seguimiento de caudales ecológicos, conectividad longitudinal y evaluación de indicadores de biodiversidad.',
    tags: ['Caudal ecológico', 'Sedimentos', 'Biodiversidad']
  }
];

const Technologies = () => (
  <>
    <SEO
      title="Tecnologías"
      description="Tecnologías de VerdantFlow Hydro Solutions: turbinas Kaplan y Pelton, automatización SCADA, sensórica IoT, gemelos digitales y herramientas ambientales para sistemas hidroeléctricos."
    />
    <section className="section">
      <div className="container">
        <header className={styles.header}>
          <h1 className="section-title">Tecnologías de referencia</h1>
          <p className="section-subtitle">Conectamos equipos hidráulicos, automatización y herramientas ambientales para crear ecosistemas hidroeléctricos inteligentes.</p>
        </header>

        <div className={styles.techGrid}>
          {technologyFamilies.map(family => (
            <article key={family.title} className={styles.techCard}>
              <img src={family.image} alt={family.title} />
              <div className={styles.techBody}>
                <h2>{family.title}</h2>
                <ul>
                  {family.points.map(point => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section bg-light">
      <div className="container">
        <h2 className="section-title">Arquitectura de integración</h2>
        <p className="section-subtitle">Capas interconectadas que posibilitan un control preciso, resiliente y trazable de la cadena hidroeléctrica.</p>
        <div className={styles.integrationGrid}>
          {integrationStack.map(stack => (
            <article key={stack.title} className={styles.integrationCard}>
              <h3>{stack.title}</h3>
              <p>{stack.description}</p>
              <div className={styles.tagGroup}>
                {stack.tags.map(tag => (
                  <span key={tag} className={styles.tag}>{tag}</span>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <div className={styles.labSection}>
          <div>
            <h2 className="section-title">Laboratorio de innovación fluvial</h2>
            <p className="section-subtitle">
              Barcelona alberga nuestro centro de experimentación con bancos de turbinas, canales de ensayo de 18 metros y un laboratorio hidroinformático con estaciones de cálculo de alto rendimiento. Validamos prototipos, analizamos perfiles hidráulicos y formamos a equipos de operación en entornos simulados.
            </p>
          </div>
          <div className={styles.labCard}>
            <h3>Infraestructura destacada</h3>
            <ul>
              <li>Canal inclinable con control de velocidad y simulación de crecidas</li>
              <li>Banco de pruebas de turbinas Kaplan de 45 kW</li>
              <li>Cluster HPC para modelación CFD y optimización multiobjetivo</li>
              <li>Plataforma de realidad virtual para entrenamiento de operadores</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Technologies;