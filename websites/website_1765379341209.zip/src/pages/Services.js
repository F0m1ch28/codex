import React from 'react';
import SEO from '../components/SEO';
import styles from './Services.module.css';

const serviceGroups = [
  {
    title: 'Planificación hidroeléctrica',
    items: [
      'Inventarios hidrológicos y batimetría de alta resolución',
      'Evaluación ambiental estratégica con indicadores de biodiversidad',
      'Análisis multiobjetivo de viabilidad en micro y minihidráulica',
      'Diseño conceptual de plantas run-of-river y derivación'
    ]
  },
  {
    title: 'Ingeniería y construcción',
    items: [
      'Modelación CFD, cálculo estructural y selección de turbomáquinas',
      'Diseño de obras civiles, canales de derivación y disipación de energía',
      'Integración eléctrica: generadores síncronos, excitadores y microrredes',
      'Supervisión de obra y comisionamiento con protocolos de puesta en marcha'
    ]
  },
  {
    title: 'Operación y modernización',
    items: [
      'Retrofit de turbinas Kaplan, Francis y Pelton de baja carga',
      'Digitalización de centrales con SCADA, IoT y control predictivo',
      'Programas de mantenimiento basado en condición y gemelos digitales',
      'Optimización de caudal ecológico con algoritmos adaptativos'
    ]
  },
  {
    title: 'Servicios ambientales',
    items: [
      'Gestión sedimentaria y diseño de pasos de fauna',
      'Restauración fluvial y soluciones basadas en la naturaleza',
      'Modelos de calidad de agua y gestión de nutrientes',
      'Seguimiento de indicadores ambientales y reportes de cuenca'
    ]
  }
];

const differentiators = [
  {
    title: 'Gemelos digitales fluviales',
    description: 'Plataformas que integran modelos hidrodinámicos 2D/3D, sensórica IoT y datos meteorológicos para anticipar comportamientos de caudal.',
    image: 'https://images.unsplash.com/photo-1516912481808-3406841bd33c?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Sala de control 24/7',
    description: 'Monitorización continua desde Barcelona con analítica de vibraciones, rendimiento energético y cumplimiento de caudales ecológicos.',
    image: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Integración interdisciplinar',
    description: 'Equipos de hidráulica, geología, automática y datos coordinados bajo metodologías ágiles aplicadas a la ingeniería.',
    image: 'https://images.unsplash.com/photo-1536305030015-6e4d4e8e89b3?auto=format&fit=crop&w=800&q=80'
  }
];

const Services = () => (
  <>
    <SEO
      title="Servicios"
      description="Servicios de VerdantFlow Hydro Solutions: planificación hidroeléctrica, ingeniería de detalle, operación digital y gestión ambiental para proyectos fluviales en España."
    />
    <section className="section">
      <div className="container">
        <div className={styles.header}>
          <h1 className="section-title">Servicios especializados</h1>
          <p className="section-subtitle">Un portafolio integral para desarrollar, modernizar y operar activos hidroeléctricos de pequeña y mediana escala con precisión hidráulica.</p>
        </div>
        <div className={styles.grid}>
          {serviceGroups.map(group => (
            <article key={group.title} className={styles.card}>
              <h2>{group.title}</h2>
              <ul>
                {group.items.map(item => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section bg-dark">
      <div className="container">
        <h2 className="section-title light">Diferenciales VerdantFlow</h2>
        <p className="section-subtitle light">Capacidades que nos permiten acompañar todo el ciclo hidroeléctrico con rigor técnico.</p>
        <div className={styles.differentiatorGrid}>
          {differentiators.map(item => (
            <article key={item.title} className={styles.differentiatorCard}>
              <img src={item.image} alt={item.title} />
              <div className={styles.differentiatorContent}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <div className={styles.serviceValue}>
          <div>
            <h2 className="section-title">Coordinación integral con agentes de cuenca</h2>
            <p className="section-subtitle">
              Facilitamos el diálogo técnico con confederaciones hidrográficas, administraciones autonómicas y comunidades locales. Nuestras plataformas comparten series temporales, escenarios climáticos y reportes automatizados para acelerar permisos y seguimiento.
            </p>
          </div>
          <div className={styles.valueCard}>
            <h3>Servicios complementarios</h3>
            <ul>
              <li>Programas de formación para operadores de centrales</li>
              <li>Auditorías de cumplimiento con normativa europea (Directiva Marco del Agua)</li>
              <li>Evaluaciones de resiliencia frente a sequías y avenidas</li>
              <li>Laboratorios de innovación colaborativa con universidades</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Services;