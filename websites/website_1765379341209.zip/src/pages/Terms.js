import React from 'react';
import SEO from '../components/SEO';
import styles from './Legal.module.css';

const Terms = () => (
  <>
    <SEO
      title="Términos de Servicio"
      description="Términos de Servicio de VerdantFlow Hydro Solutions para el uso de la plataforma y los servicios de ingeniería hidroeléctrica."
    />
    <section className="section">
      <div className="container">
        <div className={styles.legalWrapper}>
          <h1 className="section-title">Términos de Servicio</h1>
          <p className={styles.updated}>Última actualización: 10 de abril de 2024</p>

          <h2>1. Objeto</h2>
          <p>Los presentes términos regulan el acceso y uso del sitio web verdantflow.com y de los servicios ofertados por VerdantFlow Hydro Solutions (en adelante "VerdantFlow").</p>

          <h2>2. Uso permitido</h2>
          <p>El usuario se compromete a utilizar los contenidos para finalidades lícitas y conforme a la normativa vigente en España. VerdantFlow puede suspender el acceso ante usos contrarios a estos términos.</p>

          <h2>3. Propiedad intelectual</h2>
          <p>Los contenidos técnicos, informes, diseños y desarrollos mostrados en el sitio son titularidad de VerdantFlow o disponen de licencias adecuadas. No se autoriza su reproducción sin autorización expresa.</p>

          <h2>4. Responsabilidad</h2>
          <p>VerdantFlow procura que la información publicada sea precisa, si bien pueden existir actualizaciones pendientes. El uso que se haga de la información publicada es responsabilidad exclusiva del usuario.</p>

          <h2>5. Enlaces</h2>
          <p>El sitio puede incluir enlaces a recursos de terceros. VerdantFlow no controla dichos contenidos y no asume responsabilidad sobre ellos.</p>

          <h2>6. Legislación aplicable</h2>
          <p>Las presentes condiciones se rigen por la legislación española. Para cualquier controversia, las partes se someten a los juzgados y tribunales de Barcelona, España.</p>

          <p>Si tiene consultas sobre estos términos, puede escribirnos a info@verdantflow.com.</p>
        </div>
      </div>
    </section>
  </>
);

export default Terms;