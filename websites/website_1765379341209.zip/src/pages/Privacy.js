import React from 'react';
import SEO from '../components/SEO';
import styles from './Legal.module.css';

const Privacy = () => (
  <>
    <SEO
      title="Política de Privacidad"
      description="Política de Privacidad de VerdantFlow Hydro Solutions sobre el tratamiento de datos personales."
    />
    <section className="section">
      <div className="container">
        <div className={styles.legalWrapper}>
          <h1 className="section-title">Política de Privacidad</h1>
          <p className={styles.updated}>Última actualización: 10 de abril de 2024</p>

          <h2>1. Responsable</h2>
          <p>VerdantFlow Hydro Solutions, con sede en Avenida Diagonal 640, 08017 Barcelona, Spain. Correo de contacto: info@verdantflow.com.</p>

          <h2>2. Datos tratados</h2>
          <p>Podemos tratar datos identificativos y de contacto facilitados en formularios, así como información técnica derivada de la navegación (dirección IP, páginas visitadas, etc.).</p>

          <h2>3. Finalidades</h2>
          <ul>
            <li>Atender solicitudes de información o propuestas.</li>
            <li>Gestionar la relación comercial y técnica con clientes y colaboradores.</li>
            <li>Remitir comunicaciones sobre actividades o novedades relacionadas con servicios hidroeléctricos, siempre que exista base legitimadora.</li>
          </ul>

          <h2>4. Legitimación</h2>
          <p>El tratamiento se basa en el consentimiento del interesado, la ejecución de un contrato o el interés legítimo de VerdantFlow en mantener la seguridad del sitio web.</p>

          <h2>5. Destinatarios</h2>
          <p>No se cederán datos a terceros, salvo obligación legal o necesidad operativa justificada con encargados de tratamiento.</p>

          <h2>6. Derechos</h2>
          <p>Puede ejercer los derechos de acceso, rectificación, supresión, oposición, limitación y portabilidad enviando un correo a info@verdantflow.com. También puede presentar reclamación ante la Agencia Española de Protección de Datos.</p>

          <h2>7. Conservación</h2>
          <p>Los datos se conservarán durante el tiempo necesario para atender la finalidad para la que fueron recabados y mientras existan responsabilidades derivadas.</p>

          <h2>8. Seguridad</h2>
          <p>VerdantFlow aplica medidas técnicas y organizativas para proteger los datos frente a accesos no autorizados, pérdida o alteración.</p>
        </div>
      </div>
    </section>
  </>
);

export default Privacy;