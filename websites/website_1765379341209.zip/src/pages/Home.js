import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import styles from './Home.module.css';

const statsData = [
  { label: 'Rendimiento hídrico monitorizado', value: 240, suffix: ' GWh/año' },
  { label: 'Kilómetros de cauces optimizados', value: 165, suffix: ' km' },
  { label: 'Microturbinas integradas', value: 58, suffix: ' unidades' },
  { label: 'Años de experiencia combinada', value: 35, suffix: ' años' }
];

const focusAreas = [
  {
    title: 'Sistemas de Minihidráulica',
    description: 'Diseñamos microcentrales con turbinas Kaplan, Pelton y soluciones de flujo cruzado adaptadas a caudales irregulares.',
    icon: '🌊'
  },
  {
    title: 'Optimización de Cauces Fluviales',
    description: 'Modelamos dinámicas sedimentarias y perfiles hidráulicos mediante gemelos digitales calibrados con datos LIDAR.',
    icon: '🛰️'
  },
  {
    title: 'Integración Agua-Energía',
    description: 'Conectamos activos hidroeléctricos a microrredes inteligentes y sistemas de almacenamiento híbrido.',
    icon: '🔋'
  },
  {
    title: 'Investigación Aplicada',
    description: 'Laboratorios vivos con universidades para validar hidráulica ambiental y estrategias de caudal ecológico.',
    icon: '🧪'
  }
];

const processSteps = [
  { title: 'Análisis hidrológico avanzado', description: 'Inventario de recursos, batimetría y series temporales con machine learning para definir escenarios operativos.' },
  { title: 'Modelación hidroinformática', description: 'Simulación CFD 3D, análisis de turbulencia y validación con sensórica IoT para garantizar estabilidad.' },
  { title: 'Ingeniería de detalle', description: 'Cálculo estructural, selección de turbomáquinas y sistemas SCADA con ciberseguridad integrada.' },
  { title: 'Comisionamiento y monitoreo', description: 'Puesta en marcha, seguimiento remoto 24/7 y recalibración continua basada en datos en tiempo real.' }
];

const technologiesPreview = [
  { title: 'Turbinas Kaplan de baja carga', description: 'Con perfiles optimizados para ríos de llanura y variaciones suaves de caudal.' },
  { title: 'Run-of-river sin embalse', description: 'Módulos compactos que reducen el impacto morfológico y preservan el caudal ecológico.' },
  { title: 'Sistemas híbridos hidro-solar', description: 'Integración de generación solar flotante para complementar la curva hidroeléctrica.' }
];

const testimonials = [
  {
    quote: 'VerdantFlow nos permitió renovar la central de Mequinenza con un control avanzado de sedimentación y mejora del rendimiento del 12% sin aumentar la ocupación fluvial.',
    name: 'Carla Martínez',
    role: 'Directora de Energía, Ebro Renovables',
    image: 'https://images.unsplash.com/photo-1600022353946-9e66f0c9b26b?auto=format&fit=crop&w=200&q=80'
  },
  {
    quote: 'El gemelo digital del cauce del Miño redujo los tiempos de modelado un 40% y facilitó una gestión integrada con los organismos de cuenca.',
    name: 'Sergio López',
    role: 'Coordinador de Ingeniería Fluvial, Xunta de Galicia',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80'
  },
  {
    quote: 'La plataforma IoT desarrollada por VerdantFlow nos da visibilidad en tiempo real del rendimiento minihidráulico y del caudal ecológico comprometido.',
    name: 'Nerea Del Olmo',
    role: 'Responsable de Innovación, Cantábrica Energía',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=200&q=80'
  }
];

const faqItems = [
  {
    question: '¿Cómo aborda VerdantFlow la protección de la biodiversidad fluvial?',
    answer: 'Integramos pasos de fauna, rejillas de baja velocidad y monitorización de especies indicadoras mediante visión artificial y sensores acústicos.'
  },
  {
    question: '¿Qué escalas de potencia cubren vuestras soluciones?',
    answer: 'Trabajamos desde microinstalaciones de 50 kW hasta configuraciones modulares de 5 MW, adaptando turbinas y generadores al régimen hidráulico.'
  },
  {
    question: '¿Qué herramientas de simulación utilizáis?',
    answer: 'Combinamos ANSYS CFX, HEC-RAS 2D, Delft3D y una suite propia de optimización multiobjetivo para equilibrar energía y criterios ambientales.'
  },
  {
    question: '¿Colaboráis con administraciones de cuenca en España?',
    answer: 'Sí. Desarrollamos proyectos con la CHE, CHG, ACA y otros organismos para garantizar una gobernanza transparente y datos interoperables.'
  }
];

const blogPosts = [
  {
    title: 'Mapeo integral de microcuencas pirenaicas para generación distribuida',
    date: '12 abril 2024',
    description: 'Cómo combinamos radar de apertura sintética y análisis de series históricas para desarrollar portfolios minihidráulicos.',
    image: 'https://images.unsplash.com/photo-1502301197179-65228ab57f78?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Run-of-river y restauración fluvial: convivencia basada en datos',
    date: '28 marzo 2024',
    description: 'Metodología VerdantFlow para simular sedimentos, transporte de nutrientes y escenarios climáticos en ríos mediterráneos.',
    image: 'https://images.unsplash.com/photo-1469533778471-92a68acc3631?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Control predictivo en microcentrales con gemelos digitales',
    date: '6 marzo 2024',
    description: 'Aplicación de modelos predictivos y mantenimiento prescriptivo en turbinas de baja carga instaladas en Navarra.',
    image: 'https://images.unsplash.com/photo-1521207418485-99c705420785?auto=format&fit=crop&w=800&q=80'
  }
];

const teamPreview = [
  {
    name: 'Inés Vidal',
    role: 'Directora Técnica',
    focus: 'Dinámica de fluidos computacional y control de turbomáquinas.',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Marc Ferrer',
    role: 'Líder de Ingeniería Fluvial',
    focus: 'Geomorfología, modelación 2D/3D y soluciones basadas en la naturaleza.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Ainhoa Crespo',
    role: 'Responsable de Datos',
    focus: 'Sensórica IoT, machine learning y plataformas de gemelo digital.',
    image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&w=400&q=80'
  }
];

const Home = () => {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [openQuestion, setOpenQuestion] = useState(0);

  useEffect(() => {
    const intervals = statsData.map((stat, index) => {
      const target = stat.value;
      const increment = Math.max(1, Math.round(target / 100));
      return setInterval(() => {
        setCounters(prevCounts => {
          const updated = [...prevCounts];
          if (updated[index] < target) {
            updated[index] = Math.min(target, updated[index] + increment);
          }
          return updated;
        });
      }, 20);
    });

    return () => {
      intervals.forEach(interval => clearInterval(interval));
    };
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial(prev => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(timer);
  }, []);

  return (
    <>
      <SEO
        title="Inicio"
        description="VerdantFlow Hydro Solutions impulsa la ingeniería hidroeléctrica en España con sistemas de minihidráulica, optimización fluvial y gestión integrada agua-energía."
      />
      <div className={styles.hero} role="region" aria-label="Sección hero VerdantFlow" style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1600&q=80)' }}>
        <div className={styles.heroOverlay}></div>
        <div className={`${styles.heroContent} container`}>
          <p className={styles.heroEyebrow}>Plataforma española de ingeniería hidroeléctrica</p>
          <h1 className={styles.heroTitle}>VerdantFlow Hydro Solutions</h1>
          <p className={styles.heroSubtitle}>Energía fluvial, sostenibilidad integrada. Diseñamos sistemas hidroeléctricos de pequeña escala, gestionamos sedimentos y conectamos el agua con la red eléctrica de forma inteligente.</p>
          <div className={styles.heroActions}>
            <Link to="/contacto" className={styles.primaryButton}>Conozca nuestras soluciones</Link>
            <Link to="/tecnologias" className={styles.secondaryButton}>Explorar tecnologías</Link>
          </div>
          <div className={styles.heroStats}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.heroStatCard}>
                <span className={styles.heroStatValue}>{counters[index]}{stat.suffix}</span>
                <span className={styles.heroStatLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <section className="section">
        <div className="container">
          <div className={styles.introGrid}>
            <div>
              <h2 className="section-title">Ingeniería hidroeléctrica precisa para cada cauce</h2>
              <p className="section-subtitle">
                En VerdantFlow combinamos modelación avanzada, sistemas de monitoreo y diseño de turbomáquinas para desplegar microcentrales y soluciones run-of-river adaptadas a los ríos ibéricos. Nuestras plataformas tecnológicas conectan datos en tiempo real con decisiones energéticas responsables.
              </p>
            </div>
            <div className={styles.introCard}>
              <h3>Impacto en España</h3>
              <ul className={styles.introList}>
                <li><strong>Barcelona</strong>: centro de ingeniería y laboratorio hidráulico.</li>
                <li><strong>Galicia</strong>: pilotos run-of-river con organismos de cuenca.</li>
                <li><strong>Aragón</strong>: microrredes hidroeléctricas distribuidas.</li>
                <li><strong>Navarra</strong>: gemelos digitales y control predictivo.</li>
              </ul>
              <Link to="/nosotros" className={styles.introLink}>Conozca al equipo</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="section bg-light">
        <div className="container">
          <h2 className="section-title">Nuestros focos técnicos</h2>
          <p className="section-subtitle">Abordamos la energía hidroeléctrica de forma integral, desde la geomorfología del cauce hasta la integración en microrredes resilientes.</p>
          <div className={styles.focusGrid}>
            {focusAreas.map(area => (
              <article key={area.title} className={styles.focusCard}>
                <div className={styles.focusIcon} aria-hidden="true">{area.icon}</div>
                <h3>{area.title}</h3>
                <p>{area.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="section-title">Metodología VerdantFlow</h2>
          <p className="section-subtitle">Una hoja de ruta iterativa que combina análisis hidroambiental y automatización industrial.</p>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <div key={step.title} className={styles.processCard}>
                <span className={styles.processIndex}>0{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-dark">
        <div className="container">
          <h2 className="section-title light">Tecnologías en despliegue</h2>
          <p className="section-subtitle light">Innovaciones que maximizan la energía disponible y respetan la dinámica fluvial.</p>
          <div className={styles.techHighlightGrid}>
            {technologiesPreview.map(tech => (
              <div key={tech.title} className={styles.techCard}>
                <h3>{tech.title}</h3>
                <p>{tech.description}</p>
              </div>
            ))}
          </div>
          <div className={styles.techCta}>
            <Link to="/tecnologias" className="primary-button">Ver catálogo tecnológico</Link>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.projectsHeader}>
            <div>
              <h2 className="section-title">Proyectos en territorio español</h2>
              <p className="section-subtitle">Transformamos datos hidrométricos en soluciones ejecutables. Desde el Pirineo hasta el Guadalquivir, acompañamos a clientes públicos y privados.</p>
            </div>
            <Link to="/proyectos" className="ghost-button">Explorar todos los proyectos</Link>
          </div>
          <div className={styles.projectShowcase}>
            <article className={styles.projectCard}>
              <img src="https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&w=900&q=80" alt="Central minihidráulica en cauce pirenaico" />
              <div className={styles.projectContent}>
                <h3>Run-of-river modulable en el Alto Aragón</h3>
                <p>Diseño modular de 1,8 MW con turbinas Kaplan S, control de compuertas automatizado y sistemas de telemetría de caudal ecológico.</p>
              </div>
            </article>
            <article className={styles.projectCard}>
              <img src="https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?auto=format&fit=crop&w=900&q=80" alt="Obra fluvial con instrumentos de medición" />
              <div className={styles.projectContent}>
                <h3>Laboratorio vivo del río Miño</h3>
                <p>Modelo hidrogeomorfológico 3D, evaluación de transporte de sedimentos y pilotos de turbinas de flujo cruzado con monitoreo IoT.</p>
              </div>
            </article>
            <article className={styles.projectCard}>
              <img src="https://images.unsplash.com/photo-1465145782865-09532f760e0b?auto=format&fit=crop&w=900&q=80" alt="Infraestructura hidroeléctrica integrada con vegetación" />
              <div className={styles.projectContent}>
                <h3>Microcentral híbrida en Navarra</h3>
                <p>Integración hidro-solar con almacenamiento de baterías y sistema de predicción de caudales basado en aprendizaje automático.</p>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className="section bg-light">
        <div className="container">
          <h2 className="section-title">Historias desde el cauce</h2>
          <p className="section-subtitle">Organizaciones que confían en VerdantFlow para dinamizar su generación hidroeléctrica.</p>
          <div className={styles.testimonialWrapper}>
            <div className={styles.testimonialSlider} style={{ transform: `translateX(-${activeTestimonial * 100}%)` }}>
              {testimonials.map(testimonial => (
                <article key={testimonial.name} className={styles.testimonialCard}>
                  <div className={styles.testimonialQuote}>{testimonial.quote}</div>
                  <div className={styles.testimonialProfile}>
                    <img src={testimonial.image} alt={`Retrato de ${testimonial.name}`} />
                    <div>
                      <p className={styles.testimonialName}>{testimonial.name}</p>
                      <p className={styles.testimonialRole}>{testimonial.role}</p>
                    </div>
                  </div>
                </article>
              ))}
            </div>
            <div className={styles.testimonialDots}>
              {testimonials.map((_, index) => (
                <button
                  key={`dot-${index}`}
                  type="button"
                  className={`${styles.dot} ${activeTestimonial === index ? styles.dotActive : ''}`}
                  aria-label={`Ver testimonio ${index + 1}`}
                  onClick={() => setActiveTestimonial(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="section-title">Equipo en primera línea</h2>
          <p className="section-subtitle">Ingenieras e ingenieros que transforman datos fluviales en decisiones energéticas precisas.</p>
          <div className={styles.teamGrid}>
            {teamPreview.map(member => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img src={member.image} alt={`Equipo VerdantFlow - ${member.name}`} />
                </div>
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p className={styles.teamFocus}>{member.focus}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-light">
        <div className="container">
          <h2 className="section-title">Preguntas frecuentes</h2>
          <p className="section-subtitle">Lo esencial sobre nuestras capacidades hidroeléctricas y de investigación.</p>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <div key={item.question} className={`${styles.faqItem} ${openQuestion === index ? styles.faqOpen : ''}`}>
                <button
                  className={styles.faqButton}
                  onClick={() => setOpenQuestion(openQuestion === index ? null : index)}
                  aria-expanded={openQuestion === index}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqToggle}>{openQuestion === index ? '−' : '+'}</span>
                </button>
                <div className={styles.faqAnswer}>
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="section-title">Insights desde nuestros laboratorios</h2>
          <p className="section-subtitle">Últimas publicaciones del centro de investigación fluvial VerdantFlow.</p>
          <div className={styles.blogGrid}>
            {blogPosts.map(post => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} />
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.description}</p>
                  <Link to="/investigacion" className={styles.blogLink}>Leer más en I+D</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.ctaSection}`}>
        <div className={`${styles.ctaContainer} container`}>
          <div>
            <h2>Conecte su cauce con el futuro energético</h2>
            <p>Agendemos una sesión técnica para estudiar potencial hidroeléctrico, condiciones ambientales y esquemas de control digital.</p>
          </div>
          <div className={styles.ctaButtons}>
            <Link to="/contacto" className="primary-button">Solicitar diagnóstico</Link>
            <Link to="/servicios" className="secondary-button">Ver servicios</Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;