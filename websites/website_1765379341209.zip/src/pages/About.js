import React from 'react';
import SEO from '../components/SEO';
import styles from './About.module.css';

const milestones = [
  {
    year: '2015',
    title: 'Nacimiento de VerdantFlow',
    description: 'Un grupo de ingenieras hidráulicas de Barcelona funda VerdantFlow con el objetivo de modernizar microcentrales en ríos pirenaicos.'
  },
  {
    year: '2018',
    title: 'Primer laboratorio vivo',
    description: 'Se lanza el laboratorio fluvial del río Segre con sensores distribuidos y pilotos de turbinas de flujo cruzado.'
  },
  {
    year: '2021',
    title: 'Centro de control integrado',
    description: 'Inauguramos la sala de control 24/7, conectando más de 20 microcentrales con monitoreo y operación remota.'
  },
  {
    year: '2023',
    title: 'Programa RiverData',
    description: 'Presentamos una plataforma abierta con datos hidrométricos y ambientales para operadores y administraciones españolas.'
  }
];

const leadership = [
  {
    name: 'Núria Soler',
    role: 'Directora General',
    expertise: 'Gestión estratégica, alianzas con organismos de cuenca y coordinación de proyectos de energía distribuida.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Daniel Ortega',
    role: 'Director de Operaciones',
    expertise: 'Automatización de centrales, ciberseguridad industrial y operación remota con equipos multidisciplinares.',
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Laia Morales',
    role: 'Directora de I+D',
    expertise: 'Modelación hidrodinámica, investigación ambiental y coordinación con universidades y centros tecnológicos.',
    image: 'https://images.unsplash.com/photo-1525182008055-f88b95ff7980?auto=format&fit=crop&w=400&q=80'
  }
];

const About = () => (
  <>
    <SEO
      title="Sobre VerdantFlow"
      description="VerdantFlow Hydro Solutions: origen, visión, liderazgo y compromiso con la integración agua-energía en España."
    />
    <section className="section">
      <div className="container">
        <div className={styles.hero}>
          <div className={styles.textBlock}>
            <h1 className="section-title">Sobre VerdantFlow</h1>
            <p className="section-subtitle">
              VerdantFlow Hydro Solutions nació en Barcelona con la misión de transformar la energía fluvial en un vector flexible y respetuoso con los ecosistemas. Combinamos ingeniería hidráulica, digitalización y enfoque ambiental para acompañar a operadores públicos y privados.
            </p>
          </div>
          <div className={styles.valuesCard}>
            <h2>Principios esenciales</h2>
            <ul>
              <li><strong>Integridad hidrológica:</strong> proteger la dinámica natural del cauce en cada intervención.</li>
              <li><strong>Precisión técnica:</strong> modelar, probar y validar cada decisión con datos confiables.</li>
              <li><strong>Colaboración abierta:</strong> compartir conocimiento con investigadores, comunidades y organismos gestores.</li>
            </ul>
          </div>
        </div>

        <div className={styles.milestones}>
          {milestones.map(milestone => (
            <article key={milestone.year} className={styles.milestone}>
              <span className={styles.year}>{milestone.year}</span>
              <div>
                <h3>{milestone.title}</h3>
                <p>{milestone.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section bg-light">
      <div className="container">
        <h2 className="section-title">Dirección ejecutiva</h2>
        <p className="section-subtitle">Un liderazgo que combina experiencia en ingeniería, operaciones y cooperación institucional.</p>
        <div className={styles.leadershipGrid}>
          {leadership.map(member => (
            <article key={member.name} className={styles.leadershipCard}>
              <img src={member.image} alt={member.name} />
              <div className={styles.leadershipContent}>
                <h3>{member.name}</h3>
                <p className={styles.role}>{member.role}</p>
                <p className={styles.expertise}>{member.expertise}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <div className={styles.commitment}>
          <div>
            <h2 className="section-title">Compromiso con España</h2>
            <p className="section-subtitle">Trabajamos estrechamente con confederaciones hidrográficas, agencias autonómicas y comunidades locales para avanzar en soluciones hidroenergéticas responsables.</p>
          </div>
          <div className={styles.commitmentCard}>
            <h3>Ámbitos de colaboración</h3>
            <ul>
              <li>Planes de gestión de cuencas y apoyo a la Directiva Marco del Agua</li>
              <li>Programas de resiliencia hídrica y adaptación al cambio climático</li>
              <li>Capacitación técnica para operadores de centrales públicas y privadas</li>
              <li>Proyectos sociales y educativos sobre energía y ecosistemas fluviales</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default About;