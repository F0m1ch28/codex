import React from 'react';
import SEO from '../components/SEO';
import styles from './Investigation.module.css';

const researchLines = [
  {
    title: 'Hidrodinámica y sedimentos',
    description: 'Desarrollamos modelos acoplados flujo-sedimento que predicen deposición y erosión bajo escenarios de cambio climático para ríos ibéricos.',
    partners: ['Universitat Politècnica de Catalunya', 'Centro de Estudios Hidrográficos CEDEX']
  },
  {
    title: 'Hidroenergía digital',
    description: 'Implementamos algoritmos predictivos para ajustar la operación de microcentrales, identificando patrones de rendimiento con gemelos digitales.',
    partners: ['Universidad de Zaragoza', 'Tecnalia']
  },
  {
    title: 'Restauración ecohidráulica',
    description: 'Diseñamos soluciones basadas en la naturaleza que armonizan uso energético y biodiversidad, con monitoreo de fauna acuática.',
    partners: ['Fundación Nueva Cultura del Agua', 'Parques Nacionales']
  }
];

const knowledgeTransfer = [
  {
    title: 'Programa RiverData',
    body: 'Repositorio interoperable con datos hidrométricos, morfología, calidad de agua y parámetros energéticos en España. Abarca más de 400 estaciones y 25 proyectos piloto.',
    image: 'https://images.unsplash.com/photo-1446329360991-84c60293f021?auto=format&fit=crop&w=1000&q=80'
  },
  {
    title: 'Living Labs fluviales',
    body: 'Espacios colaborativos en Navarra, Galicia y Cataluña para testear soluciones run-of-river, pasos de fauna y plataformas digitales con operadores locales.',
    image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1000&q=80'
  }
];

const Investigation = () => (
  <>
    <SEO
      title="Investigación & Desarrollo"
      description="Centro de Investigación VerdantFlow: hidrodinámica, hidroenergía digital y restauración ecohidráulica con universidades y organismos españoles."
    />
    <section className="section">
      <div className="container">
        <div className={styles.hero}>
          <div>
            <h1 className="section-title">Investigación & Desarrollo</h1>
            <p className="section-subtitle">
              Desde nuestro centro en Barcelona lideramos proyectos de I+D que conectan dinámica fluvial, ingeniería energética y transformación digital. Colaboramos con universidades y organismos públicos para convertir conocimiento científico en soluciones aplicadas.
            </p>
          </div>
          <div className={styles.heroCard}>
            <h2>+18 proyectos de investigación activos</h2>
            <p>Programas financiados por Horizonte Europa, CDTI y consorcios autonómicos con foco en hidrodinámica, digitalización y restauración fluvial.</p>
          </div>
        </div>

        <div className={styles.researchGrid}>
          {researchLines.map(line => (
            <article key={line.title} className={styles.researchCard}>
              <h3>{line.title}</h3>
              <p>{line.description}</p>
              <div className={styles.partnerBlock}>
                <span>Colaboradores:</span>
                <ul>
                  {line.partners.map(partner => (
                    <li key={partner}>{partner}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section bg-light">
      <div className="container">
        <h2 className="section-title">Transferencia de conocimiento</h2>
        <p className="section-subtitle">Creamos espacios y plataformas para compartir datos, metodologías y resultados con la comunidad hidroeléctrica.</p>
        <div className={styles.transferGrid}>
          {knowledgeTransfer.map(item => (
            <article key={item.title} className={styles.transferCard}>
              <img src={item.image} alt={item.title} />
              <div className={styles.transferContent}>
                <h3>{item.title}</h3>
                <p>{item.body}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <div className={styles.callout}>
          <div>
            <h2 className="section-title">Publicaciones y divulgación</h2>
            <p className="section-subtitle">
              Participamos en foros internacionales como Hydro2024, RiverTech y conferencias de la Asociación Española de Ingeniería del Agua. Publicamos artículos en revistas como Water Research y Renewable Energy, y generamos informes técnicos abiertos.
            </p>
          </div>
          <div className={styles.calloutCard}>
            <h3>Áreas emergentes</h3>
            <ul>
              <li>Aplicación de inteligencia artificial a pronósticos de caudal</li>
              <li>Evaluación de turbinas de corriente libre en estuarios</li>
              <li>Sistemas híbridos hidro-hidrógeno verde</li>
              <li>Monitoreo acústico de peces migratorios</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Investigation;