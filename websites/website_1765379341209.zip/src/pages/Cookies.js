import React from 'react';
import SEO from '../components/SEO';
import styles from './Legal.module.css';

const CookiesPolicy = () => (
  <>
    <SEO
      title="Política de Cookies"
      description="Política de Cookies de VerdantFlow Hydro Solutions sobre el uso de tecnologías de seguimiento en verdantflow.com."
    />
    <section className="section">
      <div className="container">
        <div className={styles.legalWrapper}>
          <h1 className="section-title">Política de Cookies</h1>
          <p className={styles.updated}>Última actualización: 10 de abril de 2024</p>

          <h2>1. ¿Qué son las cookies?</h2>
          <p>Las cookies son archivos que se descargan en su dispositivo cuando accede a determinadas páginas web. Permiten almacenar y recuperar información sobre la navegación.</p>

          <h2>2. Tipos de cookies utilizadas</h2>
          <ul>
            <li><strong>Cookies técnicas:</strong> imprescindibles para el funcionamiento del sitio.</li>
            <li><strong>Cookies analíticas:</strong> nos ayudan a conocer el rendimiento del sitio y a mejorar la experiencia.</li>
          </ul>

          <h2>3. Gestión de cookies</h2>
          <p>Puede configurar su navegador para aceptar, rechazar o eliminar cookies. Si las bloquea, algunas funcionalidades pueden verse limitadas.</p>

          <h2>4. Cookies de terceros</h2>
          <p>Podemos utilizar servicios analíticos que instalen cookies propias. Consulte la política de cada proveedor para más información.</p>

          <h2>5. Actualizaciones</h2>
          <p>Podemos actualizar esta política para reflejar cambios normativos o funcionales. Recomendamos revisarla periódicamente.</p>

          <p>Para cualquier duda, escriba a info@verdantflow.com.</p>
        </div>
      </div>
    </section>
  </>
);

export default CookiesPolicy;