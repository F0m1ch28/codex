document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.site-navigation');
    const navLinks = document.querySelectorAll('.nav-links a');

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const isOpen = navigation.classList.toggle('is-open');
            navToggle.classList.toggle('is-active', isOpen);
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (navigation.classList.contains('is-open')) {
                    navigation.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const cookieButtons = document.querySelectorAll('[data-cookie-action]');
    const cookieChoice = localStorage.getItem('scrb_cookie_choice');

    function hideCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.add('hidden');
            setTimeout(() => {
                cookieBanner.style.display = 'none';
            }, 300);
        }
    }

    if (cookieChoice) {
        hideCookieBanner();
    }

    cookieButtons.forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            const action = this.getAttribute('data-cookie-action');
            if (action) {
                localStorage.setItem('scrb_cookie_choice', action);
            }
            hideCookieBanner();
            const target = this.getAttribute('href');
            if (target) {
                window.location.href = target;
            }
        });
    });
});