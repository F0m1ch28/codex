import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggleMenu = () => {
    setMenuOpen((prev) => !prev);
  };

  const handleCloseMenu = () => {
    setMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <a href="#mainContent" className={styles.skipLink}>
        Перейти к содержанию
      </a>
      <div className={"container ${styles.inner}"}>
        <div className={styles.branding}>
          <Link to="/" className={styles.logo} onClick={handleCloseMenu}>
            Мир Кошек
          </Link>
          <p className={styles.tagline}>Энциклопедия кошачьей жизни</p>
        </div>
        <button
          type="button"
          className={styles.menuToggle}
          aria-label="Меню"
          aria-controls="primary-navigation"
          aria-expanded={menuOpen}
          onClick={handleToggleMenu}
        >
          <span className={styles.burger} />
        </button>
        <nav
          id="primary-navigation"
          className={"${styles.nav} ${menuOpen ? styles.navOpen : ''}"}
          aria-label="Основная навигация"
        >
          <ul className={styles.navList}>
            <li className={styles.navItem}>
              <NavLink
                to="/porody-koshek"
                className={({ isActive }) =>
                  isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
                }
                onClick={handleCloseMenu}
              >
                Породы
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/uhod-i-zdorove"
                className={({ isActive }) =>
                  isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
                }
                onClick={handleCloseMenu}
              >
                Уход и здоровье
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/povedenie"
                className={({ isActive }) =>
                  isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
                }
                onClick={handleCloseMenu}
              >
                Поведение
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/nasha-missiya"
                className={({ isActive }) =>
                  isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
                }
                onClick={handleCloseMenu}
              >
                Наша миссия
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/kontakty"
                className={({ isActive }) =>
                  isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
                }
                onClick={handleCloseMenu}
              >
                Контакты
              </NavLink>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;