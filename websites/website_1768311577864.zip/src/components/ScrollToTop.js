import React, { useEffect, useState } from 'react';
import styles from './ScrollToTop.module.css';

const ScrollToTopButton = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      setIsVisible(window.pageYOffset > 320);
    };

    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const handleScrollTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <button
      type="button"
      className={"${styles.button} ${isVisible ? styles.visible : ''}"}
      onClick={handleScrollTop}
      aria-label="Прокрутить наверх"
    >
      ↑
    </button>
  );
};

export default ScrollToTopButton;