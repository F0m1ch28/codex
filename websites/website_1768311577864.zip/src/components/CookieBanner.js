import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'mirKoshekCookieChoice';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedChoice = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null;
    if (!storedChoice) {
      setIsVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem(STORAGE_KEY, choice);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <p>
          Мы используем cookies, чтобы сделать работу сайта удобнее. Продолжая пользоваться сайтом,
          вы соглашаетесь с условиями <Link to="/politika-cookie">политики Cookie</Link>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.accept} onClick={() => handleChoice('accepted')}>
          Принять
        </button>
        <button type="button" className={styles.decline} onClick={() => handleChoice('declined')}>
          Отклонить
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;