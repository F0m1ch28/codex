import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={"container ${styles.content}"}>
      <div className={styles.about}>
        <h2 className={styles.logo}>Мир Кошек</h2>
        <p className={styles.description}>
          Мы объединяем любителей кошек по всей России, чтобы делиться знаниями,
          вдохновлять и помогать заботиться о мурчащих друзьях.
        </p>
        <div className={styles.socials}>
          <a
            href="https://vk.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Мы во ВКонтакте"
          >
            VK
          </a>
          <a
            href="https://t.me"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Мы в Telegram"
          >
            TG
          </a>
          <a
            href="https://ok.ru"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Мы в Одноклассниках"
          >
            OK
          </a>
        </div>
      </div>
      <div className={styles.links}>
        <h3>Навигация</h3>
        <ul>
          <li>
            <Link to="/" className={styles.link}>
              Главная
            </Link>
          </li>
          <li>
            <Link to="/porody-koshek" className={styles.link}>
              Породы кошек
            </Link>
          </li>
          <li>
            <Link to="/uhod-i-zdorove" className={styles.link}>
              Уход и здоровье
            </Link>
          </li>
          <li>
            <Link to="/povedenie" className={styles.link}>
              Поведение
            </Link>
          </li>
        </ul>
      </div>
      <div className={styles.links}>
        <h3>Правовая информация</h3>
        <ul>
          <li>
            <Link to="/usloviya-ispolzovaniya" className={styles.link}>
              Условия использования
            </Link>
          </li>
          <li>
            <Link to="/politika-konfidencialnosti" className={styles.link}>
              Политика конфиденциальности
            </Link>
          </li>
          <li>
            <Link to="/politika-cookie" className={styles.link}>
              Политика Cookie
            </Link>
          </li>
        </ul>
      </div>
      <div className={styles.contact}>
        <h3>Контакты</h3>
        <ul className={styles.contactList}>
          <li>Адрес: г. Москва, ул. Кошачья, д. 15, офис 7</li>
          <li>
            <Link to="/kontakty" className={styles.contactLink}>
              Телефон: +7 (495) 123-45-67
            </Link>
          </li>
          <li>
            <Link to="/kontakty" className={styles.contactLink}>
              Email: info@mir-koshek.ru
            </Link>
          </li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Мир Кошек. Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;