import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import BreedsPage from './pages/Breeds';
import CareHealthPage from './pages/Services';
import BehaviorPage from './pages/Behavior';
import AboutPage from './pages/About';
import ContactsPage from './pages/Contact';
import ThankYouPage from './pages/ThankYou';
import TermsPage from './pages/TermsOfService';
import PrivacyPage from './pages/PrivacyPolicy';
import CookiePolicyPage from './pages/CookiePolicy';
import styles from './App.module.css';

const App = () => {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location]);

  return (
    <div className={styles.app}>
      <Header />
      <main id="mainContent" className={styles.main}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/porody-koshek" element={<BreedsPage />} />
          <Route path="/uhod-i-zdorove" element={<CareHealthPage />} />
          <Route path="/povedenie" element={<BehaviorPage />} />
          <Route path="/nasha-missiya" element={<AboutPage />} />
          <Route path="/kontakty" element={<ContactsPage />} />
          <Route path="/spasibo" element={<ThankYouPage />} />
          <Route path="/usloviya-ispolzovaniya" element={<TermsPage />} />
          <Route path="/politika-konfidencialnosti" element={<PrivacyPage />} />
          <Route path="/politika-cookie" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;