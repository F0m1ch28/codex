import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Behavior.module.css';

const BehaviorPage = () => {
  const behaviorBlocks = [
    {
      title: 'Язык хвоста',
      text: 'Высоко поднятый хвост говорит о дружелюбии. Поджатый означает стресс или страх, а резкое подёргивание — раздражение.',
    },
    {
      title: 'Мяуканье',
      text: 'Кошки используют голос в основном для общения с человеком. Частое тихое мяуканье может сигнализировать о просьбе или беспокойстве.',
    },
    {
      title: 'Трение о человека',
      text: 'Так кошка оставляет свой запах и признаёт вас частью своей территории. Это знак доверия и привязанности.',
    },
  ];

  const behaviourTips = [
    'Создайте пространство, где кошка может уединиться и восстановить силы.',
    'Используйте интерактивные игрушки, чтобы направить энергию в игру и предотвратить скуку.',
    'Поощряйте желательное поведение похвалой и лакомствами, избегайте наказаний.',
  ];

  return (
    <>
      <Helmet>
        <title>Поведение кошек — Мир Кошек</title>
        <meta
          name="description"
          content="Разбор поведения кошек: язык тела, причины стресса и советы по гармоничному общению."
        />
        <meta
          name="keywords"
          content="поведение кошек, язык тела кошек, привычки кошек"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Понимание поведения кошек</h1>
          <p>
            Раскройте язык тела кошки, научитесь распознавать стресс и сделайте взаимодействие с питомцем ещё
            более гармоничным.
          </p>
        </div>
      </section>

      <section className={styles.blocksSection}>
        <div className="container">
          <div className={styles.blockGrid}>
            {behaviorBlocks.map((block) => (
              <article key={block.title} className={styles.blockCard}>
                <h2>{block.title}</h2>
                <p>{block.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.bodyLanguage}>
        <div className="container">
          <div className={styles.bodyCard}>
            <h2>Сигналы тела</h2>
            <table>
              <thead>
                <tr>
                  <th>Сигнал</th>
                  <th>Что означает</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Прижатые уши</td>
                  <td>Страх или готовность к обороне. Предоставьте кошке больше пространства.</td>
                </tr>
                <tr>
                  <td>Расширенные зрачки</td>
                  <td>Сильное возбуждение, страх или желание играть — оцените контекст ситуации.</td>
                </tr>
                <tr>
                  <td>Медленное моргание</td>
                  <td>Знак доверия и спокойствия. Попробуйте моргнуть в ответ.</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className={styles.tipsSection}>
        <div className="container">
          <div className={styles.tipCard}>
            <h2>Как поддерживать баланс</h2>
            <ul>
              {behaviourTips.map((tip) => (
                <li key={tip}>{tip}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </>
  );
};

export default BehaviorPage;