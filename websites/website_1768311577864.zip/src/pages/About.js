import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const AboutPage = () => (
  <>
    <Helmet>
      <title>Наша миссия — Мир Кошек</title>
      <meta
        name="description"
        content="Команда Мир Кошек посвящает себя просвещению владельцев и защите благополучия кошек по всей России."
      />
      <meta
        name="keywords"
        content="миссия Мир Кошек, команда, ценности, помощь кошкам"
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <div className={styles.heroContent}>
          <h1>Наша миссия — сделать жизнь кошек лучше</h1>
          <p>
            Мы делимся знаниями, которые помогают людям понять потребности кошек, поддержать их здоровье и подарить
            заботу каждому хвостику. Мир Кошек — это сообщество, где ценят ответственность и сострадание.
          </p>
        </div>
      </div>
    </section>

    <section className={styles.valuesSection}>
      <div className="container">
        <header className={styles.sectionHeader}>
          <h2>Наши ценности</h2>
          <p>Каждое решение, статья и проект проходят через призму важных ориентиров.</p>
        </header>
        <div className={styles.valueGrid}>
          <article className={styles.valueCard}>
            <h3>Знания без границ</h3>
            <p>
              Мы публикуем достоверную, проверенную информацию, основанную на исследованиях и практике
              специалистов по фелинологии и этологии.
            </p>
          </article>
          <article className={styles.valueCard}>
            <h3>Ответственное отношение</h3>
            <p>
              Продвигаем этичное обращение с животными, поддерживаем приюты и образовательные инициативы по всей России.
            </p>
          </article>
          <article className={styles.valueCard}>
            <h3>Сообщество</h3>
            <p>
              Объединяем владельцев и волонтёров, вдохновляем на взаимную поддержку и обмен опытом о кошках.
            </p>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.storySection}>
      <div className="container">
        <div className={styles.storyContent}>
          <h2>История проекта</h2>
          <p>
            «Мир Кошек» появился в 2012 году как блог энтузиастов фелинологии. Со временем мы превратились в
            масштабный портал, публикующий аналитические материалы, интервью с экспертами, подборки полезных
            сервисов и вдохновляющие истории. Сегодня мы сотрудничаем с приютами, проводим лекции и организуем
            онлайн-события для всей страны.
          </p>
          <div className={styles.timeline}>
            <div>
              <strong>2012</strong>
              <span>Запуск блога</span>
            </div>
            <div>
              <strong>2016</strong>
              <span>Статус энциклопедии</span>
            </div>
            <div>
              <strong>2020</strong>
              <span>Сообщество волонтёров</span>
            </div>
            <div>
              <strong>2023</strong>
              <span>Цифровая библиотека</span>
            </div>
          </div>
        </div>
        <aside className={styles.aside}>
          <div className={styles.asideCard}>
            <h3>Мы рядом, когда это важно</h3>
            <p>
              Бесплатно распространяем образовательные материалы для новых владельцев и приютов, а также помогаем
              находить проверенные ресурсы по адаптации и социализации кошек.
            </p>
          </div>
          <div className={styles.asideCard}>
            <h3>Сотрудничество</h3>
            <p>
              Открыты к партнёрству с образовательными проектами, экоинициативами и ответственными брендами,
              разделяющими нашу любовь к кошкам.
            </p>
          </div>
        </aside>
      </div>
    </section>

    <section className={styles.ctaSection}>
      <div className="container">
        <div className={styles.ctaCard}>
          <h2>Присоединяйтесь к миссии</h2>
          <p>Поделитесь своей историей, предложите тему для исследования или помогите приюту вместе с нами.</p>
          <a className={styles.ctaButton} href="mailto:info@mir-koshek.ru">
            Написать редакции
          </a>
        </div>
      </div>
    </section>
  </>
);

export default AboutPage;