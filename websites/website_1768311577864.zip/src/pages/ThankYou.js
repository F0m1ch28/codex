import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './ThankYou.module.css';

const ThankYouPage = () => (
  <>
    <Helmet>
      <title>Спасибо за обращение — Мир Кошек</title>
      <meta
        name="description"
        content="Спасибо за обращение в Мир Кошек. Мы свяжемся с вами в ближайшее время."
      />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <div className={styles.card}>
          <h1>Спасибо!</h1>
          <p>
            Мы получили ваше сообщение и свяжемся с вами в ближайшее время. Благодарим за доверие к «Мир Кошек».
          </p>
          <div className={styles.actions}>
            <Link to="/" className={styles.primary}>
              На главную
            </Link>
            <Link to="/porody-koshek" className={styles.secondary}>
              Изучить породы
            </Link>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default ThankYouPage;