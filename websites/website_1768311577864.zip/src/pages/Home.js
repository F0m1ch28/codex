import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const HomePage = () => {
  const popularBreeds = [
    {
      title: 'Британская короткошёрстная',
      description: 'Урбанистичная классика: уравновешенный характер, плюшевый мех и выразительные глаза.',
      image: 'https://placekitten.com/400/260',
    },
    {
      title: 'Сибирская',
      description: 'Отлично чувствует себя в холодном климате, ласкова и предана семье.',
      image: 'https://placekitten.com/401/260',
    },
    {
      title: 'Мейн-кун',
      description: 'Добрый гигант с львиным хвостом, дружелюбен к детям и любит активные игры.',
      image: 'https://placekitten.com/402/260',
    },
  ];

  const careTips = [
    { icon: '🧴', title: 'Груминг', text: 'Регулярно расчёсывайте шерсть и выбирайте мягкие шампуни.' },
    { icon: '🥗', title: 'Питание', text: 'Сбалансируйте рацион по возрасту и активности кошки.' },
    { icon: '🧠', title: 'Обучение', text: 'Стимулируйте интеллект играми и игрушками-пазлами.' },
    { icon: '🩺', title: 'Профилактика', text: 'Планируйте осмотры у ветеринара и вакцинацию.' },
  ];

  const facts = [
    {
      question: 'Почему кошки мурлычат?',
      answer:
        'Мурлыканье помогает кошке выражать спокойствие, но также обладает успокаивающим эффектом при стрессе и даже способствует регенерации тканей.',
    },
    {
      question: 'Сколько спит взрослая кошка?',
      answer:
        'В среднем 12–16 часов в сутки. Сон разбит на короткие циклы, поэтому кошка всегда готова мгновенно проснуться.',
    },
    {
      question: 'Как кошки общаются с людьми?',
      answer:
        'Они используют голос, положение ушей, хвост и взгляд. Каждое движение — особое сообщение о настроении и намерениях.',
    },
  ];

  const testimonials = [
    {
      quote:
        'Благодаря рекомендациям “Мир Кошек” моя кошка преодолела страх поездок и стала спокойнее к переездам.',
      author: 'Анна Смирнова',
      role: 'Хозяйка Феликса',
      avatar: 'https://placekitten.com/120/120',
    },
    {
      quote:
        'Нашёл здесь подробное описание пород и понял, какая подходит семье с детьми. Теперь у нас мейн-кун Луна!',
      author: 'Игорь Петров',
      role: 'Папа и котолюб',
      avatar: 'https://placekitten.com/121/120',
    },
    {
      quote:
        'Статьи о поведении помогли разобраться в языке тела кошек и устранить нежелательные привычки.',
      author: 'Мария Котова',
      role: 'Волонтёр приюта',
      avatar: 'https://placekitten.com/122/120',
    },
  ];

  const team = [
    {
      name: 'Елена Романова',
      position: 'Главный редактор',
      photo: 'https://placekitten.com/300/300',
    },
    {
      name: 'Алексей Бобров',
      position: 'Специалист по поведению',
      photo: 'https://placekitten.com/301/300',
    },
    {
      name: 'Ольга Орлова',
      position: 'Эксперт по уходу',
      photo: 'https://placekitten.com/302/300',
    },
  ];

  const galleryImages = [
    'https://placekitten.com/400/300',
    'https://placekitten.com/401/301',
    'https://placekitten.com/402/302',
    'https://placekitten.com/403/303',
    'https://placekitten.com/404/304',
    'https://placekitten.com/405/305',
  ];

  const [activeFact, setActiveFact] = useState(0);
  const [loadedImages, setLoadedImages] = useState(
    () => new Array(galleryImages.length).fill(false)
  );

  const toggleFact = (index) => {
    setActiveFact((prev) => (prev === index ? -1 : index));
  };

  const handleImageLoad = (index) => {
    setLoadedImages((prev) => {
      const next = [...prev];
      next[index] = true;
      return next;
    });
  };

  return (
    <>
      <Helmet>
        <title>Мир Кошек — Главная</title>
        <meta
          name="description"
          content="Мир Кошек — вдохновляющий портал о породах, уходе, здоровье и поведении кошек."
        />
        <meta
          name="keywords"
          content="кошки, породы, уход, здоровье, поведение, котята"
        />
      </Helmet>
      <div className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.badge}>Доверие более 150 000 читателей</span>
            <h1>Погрузитесь в тёплый и заботливый мир кошек</h1>
            <p>
              Мы собрали проверенные знания о породах, здоровье и характере кошек, чтобы вы чувствовали
              уверенность в каждом мурлыкающем моменте.
            </p>
            <div className={styles.heroActions}>
              <Link to="/porody-koshek" className={styles.primaryButton}>
                Изучить породы
              </Link>
              <Link to="/kontakty" className={styles.secondaryButton}>
                Связаться с нами
              </Link>
            </div>
          </div>
          <div className={styles.heroIllustration} aria-hidden="true">
            <div className={styles.heroCard}>
              <img src="https://placekitten.com/420/360" alt="Очаровательный котёнок" />
              <div className={styles.heroCardInfo}>
                <h3>Наставник котолюбов</h3>
                <p>Доставим вам вдохновение и знания о кошках ежедневно.</p>
              </div>
            </div>
            <div className={styles.sparkle} />
          </div>
        </div>
      </div>

      <section className={styles.breedsSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Популярные породы</h2>
            <p>
              Узнайте особенности характера, требования по уходу и советы по адаптации для самых любимых пород.
            </p>
          </header>
          <div className={styles.breedGrid}>
            {popularBreeds.map((breed) => (
              <article key={breed.title} className={styles.breedCard}>
                <div className={styles.breedImageWrapper}>
                  <img src={breed.image} alt={breed.title} loading="lazy" />
                </div>
                <div className={styles.breedContent}>
                  <h3>{breed.title}</h3>
                  <p>{breed.description}</p>
                  <Link to="/porody-koshek" className={styles.linkButton}>
                    Подробнее
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.careSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Советы по уходу</h2>
            <div className={styles.headerActions}>
              <p>Сделайте повседневную заботу о кошке лёгкой и радостной.</p>
              <Link to="/uhod-i-zdorove" className={styles.textLink}>
                Читать гайд →
              </Link>
            </div>
          </header>
          <div className={styles.tipGrid}>
            {careTips.map((tip) => (
              <article key={tip.title} className={styles.tipCard}>
                <span className={styles.tipIcon} aria-hidden="true">
                  {tip.icon}
                </span>
                <h3>{tip.title}</h3>
                <p>{tip.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.factsSection}>
        <div className="container">
          <div className={styles.factsLayout}>
            <header className={styles.sectionHeader}>
              <h2>Интересные факты о кошках</h2>
              <p>Раскройте природу вашего питомца через научно подтверждённые наблюдения.</p>
            </header>
            <div className={styles.accordion}>
              {facts.map((fact, index) => (
                <div key={fact.question} className={styles.accordionItem}>
                  <button
                    type="button"
                    className={"${styles.accordionButton} ${
                      activeFact === index ? styles.accordionActive : ''
                    }"}
                    onClick={() => toggleFact(index)}
                    aria-expanded={activeFact === index}
                  >
                    {fact.question}
                    <span aria-hidden="true">{activeFact === index ? '−' : '+'}</span>
                  </button>
                  {activeFact === index && (
                    <div className={styles.accordionPanel}>
                      <p>{fact.answer}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.behaviorCallout}>
        <div className="container">
          <div className={styles.behaviorContent}>
            <h2>Понимание поведения</h2>
            <p>
              Станьте «переводчиком» языка тела кошки. Мы подскажем, как отличать приглашение к игре от
              просьбы о личном пространстве и предотвратить стресс у питомца.
            </p>
            <Link to="/povedenie" className={styles.primaryButton}>
              Исследовать поведение
            </Link>
          </div>
          <div className={styles.behaviorCard} aria-hidden="true">
            <img src="https://placekitten.com/410/320" alt="Игривый кот" />
          </div>
        </div>
      </section>

      <section className={styles.missionSection}>
        <div className="container">
          <div className={styles.missionContent}>
            <h2>Наша миссия</h2>
            <p>
              Мы верим, что каждая кошка заслуживает внимательного и любящего дома. Наша редакция создаёт
              материалы, которые помогают людям по всей России лучше понимать своих четвероногих друзей.
            </p>
            <Link to="/nasha-missiya" className={styles.textLink}>
              Узнать о команде →
            </Link>
          </div>
          <div className={styles.missionHighlights}>
            <div>
              <strong>500+</strong>
              <span>статей и гайдов</span>
            </div>
            <div>
              <strong>120</strong>
              <span>поддержанных приютов</span>
            </div>
            <div>
              <strong>24/7</strong>
              <span>доступ к знаниям</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.gallerySection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Галерея вдохновения</h2>
            <p>Истории наших читателей и их любимцев в тёплых фотографиях.</p>
          </header>
        </div>
        <div className={"container ${styles.galleryGrid}"}>
          {galleryImages.map((image, index) => (
            <figure key={image} className={styles.galleryItem}>
              {!loadedImages[index] && <div className={styles.imageSkeleton} />}
              <img
                src={image}
                alt={"Очаровательная кошка номер ${index + 1}"}
                onLoad={() => handleImageLoad(index)}
                className={loadedImages[index] ? styles.imageLoaded : styles.imageHidden}
                loading="lazy"
              />
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Что говорят наши читатели</h2>
            <p>Истории успеха и заботы, которыми гордится сообщество «Мир Кошек».</p>
          </header>
          <div className={styles.testimonialGrid}>
            {testimonials.map((testimonial) => (
              <article key={testimonial.author} className={styles.testimonialCard}>
                <div className={styles.testimonialHeader}>
                  <img src={testimonial.avatar} alt={testimonial.author} loading="lazy" />
                  <div>
                    <h3>{testimonial.author}</h3>
                    <p>{testimonial.role}</p>
                  </div>
                </div>
                <p className={styles.testimonialQuote}>{testimonial.quote}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Команда экспертов</h2>
            <p>
              За кулисами портала — команда редакторов, фотографов и кураторов проектов, объединённая любовью к кошкам.
            </p>
          </header>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.photo} alt={member.name} loading="lazy" />
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <p>{member.position}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.contactContent}>
            <h2>Свяжитесь с нами</h2>
            <p>
              Есть идея, вопрос или хотите поделиться историей своего питомца? Напишите нам — мы всегда на связи.
            </p>
            <ul className={styles.contactList}>
              <li>Адрес: г. Москва, ул. Кошачья, д. 15, офис 7</li>
              <li>Телефон: +7 (495) 123-45-67</li>
              <li>Email: info@mir-koshek.ru</li>
            </ul>
            <Link to="/kontakty" className={styles.primaryButton}>
              Перейти к контактам
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;