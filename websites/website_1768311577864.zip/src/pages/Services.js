import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const CareHealthPage = () => {
  const routineChecklist = [
    'Регулярно расчесывайте шерсть с учётом длины и подшерстка.',
    'Следите за чистотой глаз и ушей, используйте специализированные лосьоны.',
    'Предлагайте чистую воду и миску с источником влаги (влажный корм).',
    'Планируйте профилактический осмотр у ветеринара не реже раза в год.',
    'Соблюдайте режим игры и активности для профилактики ожирения.',
  ];

  const nutritionPrinciples = [
    { title: 'Баланс белков', text: 'Высокое содержание животного белка поддерживает мышечную массу и активность.' },
    { title: 'Полезные жиры', text: 'Омега-3 и Омега-6 укрепляют иммунитет, поддерживают кожу и шерсть.' },
    { title: 'Контроль порций', text: 'Дозируйте корм согласно возрасту, весу и образу жизни питомца.' },
    { title: 'Свежесть', text: 'Соблюдайте сроки хранения, не смешивайте корма сомнительного качества.' },
  ];

  return (
    <>
      <Helmet>
        <title>Уход и здоровье — Мир Кошек</title>
        <meta
          name="description"
          content="Полный гид по уходу за кошками: питание, гигиена, профилактика заболеваний и эмоциональное благополучие."
        />
        <meta
          name="keywords"
          content="уход за кошками, здоровье кошек, питание, гигиена кошек"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Уход и здоровье кошек</h1>
            <p>
              Наша команда собрала практичные рекомендации по гигиене, профилактике и эмоциональному благополучию,
              чтобы ваш питомец оставался здоровым и счастливым.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.nutritionSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Питание как фундамент здоровья</h2>
            <p>Выбирая рацион, ориентируйтесь на естественные потребности кошки, учитывая возраст и активность.</p>
          </header>
          <div className={styles.nutritionGrid}>
            {nutritionPrinciples.map((item) => (
              <article key={item.title} className={styles.nutritionCard}>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.routineSection}>
        <div className="container">
          <div className={styles.routineCard}>
            <h2>Чек-лист регулярного ухода</h2>
            <p>Простые шаги, которые помогут держать здоровье питомца под контролем.</p>
            <ul>
              {routineChecklist.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.environmentSection}>
        <div className="container">
          <div className={styles.environmentGrid}>
            <article>
              <h2>Эмоциональное благополучие</h2>
              <p>
                Кошкам важно иметь безопасные укрытия, вертикальные поверхности и возможность наблюдать за окружающим
                миром. Выделите тихий уголок, разместите когтеточки и чередуйте игрушки, чтобы сохранить интерес.
              </p>
            </article>
            <article>
              <h2>Гигиена и безопасность дома</h2>
              <p>
                Следите за чистотой лотка, подстилок и мисок. Используйте безопасные моющие средства без агрессивных
                ароматов, уберите токсичные растения и мелкие предметы, которые кошка может проглотить.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.preventionSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Профилактика заболеваний</h2>
            <p>Своевременная профилактика позволит предупредить большинство заболеваний, не прибегая к лечению.</p>
          </header>
          <div className={styles.timeline}>
            <div className={styles.timelineItem}>
              <span>1</span>
              <div>
                <h3>Вакцинация</h3>
                <p>
                  Соблюдайте график прививок, рекомендованный ветеринаром, и обновляйте их вовремя, особенно если
                  кошка выезжает за пределы дома.
                </p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <span>2</span>
              <div>
                <h3>Паразитический контроль</h3>
                <p>
                  Обрабатывайте кошку от блох, клещей и глистов. Для животных, выходящих на улицу, создайте график
                  обработки каждые 4–6 недель.
                </p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <span>3</span>
              <div>
                <h3>Дентальная гигиена</h3>
                <p>
                  Привыкайте чистить зубы с раннего возраста или используйте специализированные лакомства, снижающие
                  образование зубного налёта.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default CareHealthPage;