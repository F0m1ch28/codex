import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Breeds.module.css';

const BreedsPage = () => {
  const sizes = ['Все', 'Крупные', 'Средние', 'Миниатюрные'];
  const breeds = [
    {
      name: 'Мейн-кун',
      size: 'Крупные',
      coat: 'Полудлинная',
      temperament: 'Дружелюбный, контактный',
      origin: 'США',
      image: 'https://placekitten.com/420/280',
    },
    {
      name: 'Саванна',
      size: 'Крупные',
      coat: 'Короткая',
      temperament: 'Энергичная, голосистая',
      origin: 'США',
      image: 'https://placekitten.com/421/280',
    },
    {
      name: 'Британская короткошёрстная',
      size: 'Средние',
      coat: 'Короткая',
      temperament: 'Спокойная, уравновешенная',
      origin: 'Великобритания',
      image: 'https://placekitten.com/422/280',
    },
    {
      name: 'Сибирская',
      size: 'Средние',
      coat: 'Полудлинная',
      temperament: 'Ласковая, выносливая',
      origin: 'Россия',
      image: 'https://placekitten.com/423/280',
    },
    {
      name: 'Сфинкс',
      size: 'Миниатюрные',
      coat: 'Бесшёрстная',
      temperament: 'Общительная, игривая',
      origin: 'Канада',
      image: 'https://placekitten.com/424/280',
    },
    {
      name: 'Скоттиш-фолд',
      size: 'Средние',
      coat: 'Короткая/полудлинная',
      temperament: 'Нежная, спокойная',
      origin: 'Шотландия',
      image: 'https://placekitten.com/425/280',
    },
  ];

  const [selectedSize, setSelectedSize] = useState('Все');

  const filteredBreeds =
    selectedSize === 'Все' ? breeds : breeds.filter((breed) => breed.size === selectedSize);

  return (
    <>
      <Helmet>
        <title>Породы кошек — Мир Кошек</title>
        <meta
          name="description"
          content="Подробные описания пород кошек: характер, происхождение и особенности ухода."
        />
        <meta
          name="keywords"
          content="породы кошек, характеристики пород, выбор кошки"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Породы кошек</h1>
          <p>
            Изучите особенности популярных пород, сравните характер, тип шерсти и происхождение, чтобы найти
            питомца, подходящего вашему образу жизни.
          </p>
          <div className={styles.filter}>
            {sizes.map((size) => (
              <button
                key={size}
                type="button"
                className={"${styles.filterButton} ${
                  selectedSize === size ? styles.filterActive : ''
                }"}
                onClick={() => setSelectedSize(size)}
              >
                {size}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.gridSection}>
        <div className="container">
          <div className={styles.grid}>
            {filteredBreeds.map((breed) => (
              <article key={breed.name} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img src={breed.image} alt={breed.name} loading="lazy" />
                </div>
                <div className={styles.cardContent}>
                  <h2>{breed.name}</h2>
                  <dl>
                    <div>
                      <dt>Размер</dt>
                      <dd>{breed.size}</dd>
                    </div>
                    <div>
                      <dt>Шерсть</dt>
                      <dd>{breed.coat}</dd>
                    </div>
                    <div>
                      <dt>Темперамент</dt>
                      <dd>{breed.temperament}</dd>
                    </div>
                    <div>
                      <dt>Происхождение</dt>
                      <dd>{breed.origin}</dd>
                    </div>
                  </dl>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.tipsSection}>
        <div className="container">
          <div className={styles.tipCard}>
            <h2>Как выбрать породу</h2>
            <ul>
              <li>Оцените уровень активности и потребность в общении у породы.</li>
              <li>Учитывайте наличие аллергий в семье и особенности ухода за шерстью.</li>
              <li>Помните, что характер каждого котёнка индивидуален, а воспитание играет ключевую роль.</li>
            </ul>
          </div>
        </div>
      </section>
    </>
  );
};

export default BreedsPage;