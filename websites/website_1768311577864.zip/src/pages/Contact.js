import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  message: '',
};

const ContactsPage = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const nextErrors = {};
    const trimmedName = formData.name.trim();
    const trimmedEmail = formData.email.trim();
    const trimmedMessage = formData.message.trim();

    if (!trimmedName) {
      nextErrors.name = 'Пожалуйста, укажите имя.';
    }
    if (!trimmedEmail) {
      nextErrors.email = 'Укажите электронную почту.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/u.test(trimmedEmail)) {
      nextErrors.email = 'Введите корректный адрес электронной почты.';
    }
    if (!trimmedMessage) {
      nextErrors.message = 'Расскажите, как мы можем помочь.';
    } else if (trimmedMessage.length < 10) {
      nextErrors.message = 'Сообщение должно содержать не менее 10 символов.';
    }
    return nextErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setFormData(initialFormState);
      navigate('/spasibo');
    }
  };

  return (
    <>
      <Helmet>
        <title>Контакты — Мир Кошек</title>
        <meta
          name="description"
          content="Свяжитесь с командой Мир Кошек: адрес, телефон, email и форма обратной связи."
        />
        <meta
          name="keywords"
          content="контакты Мир Кошек, связь, адрес, телефон, email"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Контакты</h1>
          <p>
            Мы находимся в Москве и с удовольствием отвечаем на ваши письма. Поделитесь своим вопросом —
            и мы обязательно свяжемся.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.info}>
            <h2>Офис и связь</h2>
            <ul>
              <li>
                <strong>Адрес:</strong> г. Москва, ул. Кошачья, д. 15, офис 7
              </li>
              <li>
                <strong>Телефон:</strong> +7 (495) 123-45-67
              </li>
              <li>
                <strong>Email:</strong> info@mir-koshek.ru
              </li>
              <li>
                <strong>График:</strong> Пн-Пт: 10:00–19:00
              </li>
            </ul>
          </div>
          <div className={styles.formWrapper}>
            <h2>Написать нам</h2>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.formGroup}>
                <label htmlFor="name">Имя</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                />
                {errors.name && (
                  <span id="name-error" className={styles.error} role="alert">
                    {errors.name}
                  </span>
                )}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="email">Электронная почта</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                />
                {errors.email && (
                  <span id="email-error" className={styles.error} role="alert">
                    {errors.email}
                  </span>
                )}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="message">Сообщение</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                />
                {errors.message && (
                  <span id="message-error" className={styles.error} role="alert">
                    {errors.message}
                  </span>
                )}
              </div>
              <button type="submit" className={styles.submitButton}>
                Отправить
              </button>
            </form>
          </div>
        </div>
      </section>

      <section className={styles.mapSection}>
        <div className="container">
          <div className={styles.mapCard}>
            <h2>Как нас найти</h2>
            <p>Наш офис расположен в тихом районе недалеко от набережной. Гостей встречаем по предварительной договорённости.</p>
            <img
              src="https://picsum.photos/800/320?grayscale"
              alt="Схематичное изображение района офиса"
              loading="lazy"
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactsPage;