const interviewsData = [
  {
    id: 'claire-desmoulins',
    name: 'Claire Desmoulins',
    role: 'Directrice programmes ADAS, Valeo',
    theme: 'Pilotage des systèmes d’assistance et architectures logicielles',
    date: '2024-02-07',
    summary:
      "Claire Desmoulins expose la feuille de route des systèmes d’assistance au conducteur développés en France, leurs exigences de validation et les coopérations avec les pouvoirs publics pour l’automatisation graduelle.",
    topics: ['ADAS', 'Capteurs', 'Logiciel embarqué'],
  },
  {
    id: 'marc-ledu',
    name: 'Marc Ledû',
    role: 'Responsable moteurs électriques, Renault Group',
    theme: 'Industrialisation des moteurs à rotor bobiné',
    date: '2024-01-18',
    summary:
      "Marc Ledû décrit l’industrialisation des moteurs à rotor bobiné dans les usines françaises, l’optimisation énergétique visée et les partenariats européens autour des chaînes d’approvisionnement en cuivre et en acier magnétique.",
    topics: ['Motorisations', 'Production', 'Filières'],
  },
  {
    id: 'sophie-caradec',
    name: 'Sophie Caradec',
    role: 'Coordinatrice recherche batterie solide, CEA-Liten',
    theme: 'Laboratoires français et nouvelles chimies lithium',
    date: '2023-12-05',
    summary:
      "Sophie Caradec détaille la structuration des programmes français sur les électrolytes solides, les protocoles de caractérisation et les liens avec les démonstrateurs industriels prévus dans la décennie.",
    topics: ['Batteries', 'Recherche', 'Innovation'],
  },
  {
    id: 'lucas-baudry',
    name: 'Lucas Baudry',
    role: 'Directeur stratégie logistique, Forvia',
    theme: 'Logistique multi-énergies et résilience européenne',
    date: '2023-11-16',
    summary:
      "Lucas Baudry analyse la réorganisation des flux fournisseurs pour accompagner l’arrivée simultanée de composants thermiques, hybrides et électriques, ainsi que la place des hubs européens dans cette stratégie.",
    topics: ['Logistique', 'Supply Chain', 'Europe'],
  },
  {
    id: 'helene-jourdan',
    name: 'Hélène Jourdan',
    role: 'Responsable conception intérieure, Stellantis',
    theme: 'Design automobile et transition matérielle',
    date: '2023-10-24',
    summary:
      "Hélène Jourdan revient sur les évolutions du design intérieur dans les véhicules français, l’usage de matériaux recyclés et la collaboration entre designers, acousticiens et ergonomes.",
    topics: ['Design', 'Matériaux', 'Ergonomie'],
  },
];

export default interviewsData;