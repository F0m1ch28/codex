import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  organisation: '',
  email: '',
  message: '',
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Ce champ doit être renseigné.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Ce champ doit être renseigné.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = "Adresse électronique non valide.";
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Ce champ doit être renseigné.';
    } else if (formData.message.trim().length < 20) {
      newErrors.message = 'Le message doit comporter au moins vingt mots.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    if (submitted) {
      setSubmitted(false);
    }
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData(initialFormState);
    }
  };

  return (
    <div className={styles.page}>
      <Seo
        title="Contact – French Automotive Sector Analysis"
        description="Formulaire de contact destiné aux chercheurs, experts et médias souhaitant proposer des informations ou des angles d’analyse sur l’industrie automobile française."
      />
      <section className={`container ${styles.header}`}>
        <h1>Contact</h1>
        <p>
          Le formulaire permet aux chercheurs, experts, responsables institutionnels ou journalistes de transmettre des informations documentées. French Automotive Sector Analysis est une plateforme éditoriale non commerciale ; aucune sollicitation marchande n’est traitée.
        </p>
        <div className={styles.details}>
          <div>
            <h2>Adresse électronique</h2>
            <p className={styles.detailItem}>contact@french-auto-analysis.fr</p>
          </div>
          <div>
            <h2>Nature des échanges</h2>
            <p className={styles.detailItem}>
              Contributions éditoriales, précisions factuelles, retours d’expérience, propositions d’entretien.
            </p>
          </div>
          <div>
            <h2>Protection des données</h2>
            <p className={styles.detailItem}>
              Les informations soumises servent uniquement au suivi rédactionnel, conformément à la politique de confidentialité.
            </p>
          </div>
        </div>
      </section>
      <section className={styles.formSection}>
        <div className="container">
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="name">Nom et prénom</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && (
                <span id="name-error" className={styles.error}>
                  {errors.name}
                </span>
              )}
            </div>
            <div className={styles.field}>
              <label htmlFor="organisation">Organisation (optionnel)</label>
              <input
                id="organisation"
                name="organisation"
                type="text"
                value={formData.organisation}
                onChange={handleChange}
              />
            </div>
            <div className={styles.field}>
              <label htmlFor="email">Adresse électronique</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && (
                <span id="email-error" className={styles.error}>
                  {errors.email}
                </span>
              )}
            </div>
            <div className={`${styles.field} ${styles.full}`}>
              <label htmlFor="message">Message détaillé</label>
              <textarea
                id="message"
                name="message"
                rows="7"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && (
                <span id="message-error" className={styles.error}>
                  {errors.message}
                </span>
              )}
            </div>
            <div className={styles.actions}>
              <button type="submit">Transmettre la demande</button>
              {submitted && <span className={styles.success}>La demande a été enregistrée. La rédaction analysera les informations transmises.</span>}
            </div>
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;