import React from 'react';
import Seo from '../components/Seo';
import styles from './APropos.module.css';

const APropos = () => (
  <div className={styles.page}>
    <Seo
      title="À propos – French Automotive Sector Analysis"
      description="Présentation de la mission, des méthodes et des engagements éditoriaux de French Automotive Sector Analysis, publication indépendante dédiée à l’industrie automobile française."
    />
    <section className={`container ${styles.header}`}>
      <h1>À propos</h1>
      <p>
        French Automotive Sector Analysis constitue une publication analytique indépendante dédiée à l’étude des transformations de l’industrie automobile française. Les contenus sont rédigés à la troisième personne et reposent sur des méthodes de vérification systématiques.
      </p>
    </section>
    <section className={`container ${styles.blocks}`}>
      <article className={styles.block}>
        <h2>Mission</h2>
        <p>
          La mission principale consiste à documenter les évolutions industrielles, technologiques et réglementaires de la filière automobile française. La rédaction observe les constructeurs historiques, les équipementiers, les réseaux de sous-traitance et les nouveaux entrants spécialisés dans l’électrification.
        </p>
        <p>
          Chaque analyse replace les événements dans leur contexte historique, relie les décisions industrielles aux orientations européennes et met en lumière les coopérations territoriales. Les lecteurs obtiennent ainsi une vision synthétique mais contextualisée des mutations à l’œuvre.
        </p>
      </article>
      <article className={styles.block}>
        <h2>Approche éditoriale</h2>
        <p>
          Les publications s’appuient sur des sources primaires : rapports d’activité, documents réglementaires, données statistiques officielles, entretiens semi-directifs et visites de terrain. Les informations sont rapprochées afin de limiter les biais et d’identifier les zones d’incertitude.
        </p>
        <p>
          Les articles se structurent en segments clairs : introduction, développements thématiques et conclusion neutre. Cette organisation permet de suivre les raisonnements, d’isoler les constats majeurs et de retracer les liens causaux entre décisions industrielles et impacts opérationnels.
        </p>
      </article>
      <article className={styles.block}>
        <h2>Équipe éditoriale</h2>
        <p>
          La rédaction s’appuie sur des journalistes spécialisés, des analystes sectoriels et des correspondants régionaux. Les contributions d’ingénieurs, d’économistes et de sociologues sont sollicitées pour enrichir la compréhension des sujets complexes.
        </p>
        <p>
          Les entretiens avec des acteurs industriels s’effectuent dans le respect des règles de confidentialité convenues et sont restitués sans commentaire prescriptif. Les propos cités sont relus par les personnes interrogées pour en garantir l’exactitude factuelle.
        </p>
      </article>
      <article className={styles.block}>
        <h2>Indépendance</h2>
        <p>
          Le projet fonctionne sans objectifs commerciaux directs. Aucune publication ne fait l’objet de promotions ou de messages incitatifs. Les liens éventuels avec des programmes institutionnels sont mentionnés de manière transparente.
        </p>
        <p>
          Les choix éditoriaux sont guidés par la pertinence sectorielle, l’intérêt public et la disponibilité des données vérifiables. Les corrections et mises à jour sont publiées dès qu’une information évolue de manière substantielle.
        </p>
      </article>
    </section>
  </div>
);

export default APropos;