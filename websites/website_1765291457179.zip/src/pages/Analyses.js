import React, { useMemo, useState } from 'react';
import analysesData from '../data/analyses';
import Seo from '../components/Seo';
import ArticleCard from '../components/ArticleCard';
import styles from './Analyses.module.css';

const Analyses = () => {
  const [selectedTag, setSelectedTag] = useState('Toutes');

  const sortedArticles = useMemo(
    () => [...analysesData].sort((a, b) => new Date(b.date) - new Date(a.date)),
    []
  );

  const tags = useMemo(() => {
    const tagSet = new Set();
    analysesData.forEach((article) => {
      article.tags.forEach((tag) => tagSet.add(tag));
    });
    return ['Toutes', ...Array.from(tagSet)];
  }, []);

  const filteredArticles =
    selectedTag === 'Toutes'
      ? sortedArticles
      : sortedArticles.filter((article) => article.tags.includes(selectedTag));

  return (
    <div className={styles.page}>
      <Seo
        title="Analyses – French Automotive Sector Analysis"
        description="Panorama des analyses consacrées à la filière automobile française : électrification, robotisation, batteries, ingénierie des motorisations et infrastructures de recharge."
      />
      <section className={`container ${styles.header}`}>
        <h1>Analyses</h1>
        <p>
          Cette section rassemble les dossiers approfondis publiés par la rédaction. Chaque analyse s’appuie sur des données vérifiées, des entretiens avec des spécialistes et une mise en perspective historique ou réglementaire.
        </p>
        <div className={styles.filters} role="group" aria-label="Filtrer les analyses par thématique">
          {tags.map((tag) => (
            <button
              key={tag}
              type="button"
              className={`${styles.filterButton} ${selectedTag === tag ? styles.filterActive : ''}`}
              onClick={() => setSelectedTag(tag)}
              aria-pressed={selectedTag === tag}
            >
              {tag}
            </button>
          ))}
        </div>
      </section>
      <section className={styles.list}>
        <div className={`container ${styles.grid}`}>
          {filteredArticles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default Analyses;