import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import ArticleCard from '../components/ArticleCard';
import analysesData from '../data/analyses';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const keyTopics = [
  'Électrification et infrastructures de recharge',
  'Motorisations thermiques, hybrides et électriques',
  'Chaînes d’approvisionnement et logistique industrielle',
  'Batteries, matériaux critiques et recyclage',
  'Robotisation, automatisation et transition numérique',
  'Normes environnementales et directives européennes',
  'Design, ergonomie et expérience utilisateur',
  'Exportations françaises et compétitivité internationale',
  'Recherche partenariale et laboratoires publics',
  'Marché intérieur et comportements d’achat',
  'Infrastructure de recharge et réseaux énergétiques',
  'Systèmes d’assistance au conducteur et conduite automatisée',
  'Transition énergétique des constructeurs français',
  'Sous-traitance, équipementiers et tissu PME',
  'Histoire industrielle et archives automobiles',
];

const Home = () => {
  const latestAnalyses = useMemo(
    () =>
      [...analysesData]
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .slice(0, 3),
    []
  );

  return (
    <div className={styles.home}>
      <Seo
        title="French Automotive Sector Analysis – Observatoire de l’industrie automobile française"
        description="French Automotive Sector Analysis propose une veille analytique neutre sur la filière automobile française, en couvrant les innovations technologiques, les dynamiques industrielles et les cadres réglementaires."
      />
      <section className={styles.hero}>
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <p className={styles.heroLabel}>Veille sectorielle indépendante</p>
            <h1>Observatoire des dynamiques automobiles françaises</h1>
            <p className={styles.heroLead}>
              French Automotive Sector Analysis diffuse des synthèses documentées sur les acteurs industriels français, leurs choix technologiques, leurs chaînes d’approvisionnement et l’application des normes européennes. Les publications traitent chaque thématique avec un regard journalistique, factuel et contextualisé.
            </p>
            <div className={styles.heroStats}>
              <div>
                <span className={styles.statValue}>15</span>
                <span className={styles.statLabel}>Thématiques suivies en continu</span>
              </div>
              <div>
                <span className={styles.statValue}>120+</span>
                <span className={styles.statLabel}>Sources croisées par dossier</span>
              </div>
              <div>
                <span className={styles.statValue}>5</span>
                <span className={styles.statLabel}>Entretiens récents avec des experts</span>
              </div>
            </div>
            <div className={styles.heroLinks}>
              <Link to="/analyses" className={styles.heroLink}>
                Analyses récentes
              </Link>
              <Link to="/interviews" className={styles.heroLinkSecondary}>
                Entretiens d’experts
              </Link>
            </div>
          </div>
          <div className={styles.heroVisual} aria-hidden="true">
            <div className={styles.heroImage} />
          </div>
        </div>
      </section>

      <section className={styles.latest}>
        <div className="container">
          <h2 className="sectionTitle">Derniers dossiers analytiques</h2>
          <p className="sectionLead">
            Sélection de travaux récents consacrés aux chaînes d’approvisionnement, à l’ingénierie hybride, aux batteries, à la robotisation ou encore aux infrastructures de recharge.
          </p>
          <div className={styles.grid}>
            {latestAnalyses.map((article) => (
              <ArticleCard key={article.id} article={article} />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.themes}>
        <div className="container">
          <div className={styles.themesHeader}>
            <h2 className="sectionTitle">Axes de recherche suivis</h2>
            <p className="sectionLead">
              Les investigations couvrent l’ensemble de la chaîne de valeur, des sites industriels aux laboratoires de recherche en passant par les réseaux de distribution et les organismes publics.
            </p>
          </div>
          <div className={styles.themeGrid}>
            {keyTopics.map((topic) => (
              <div key={topic} className={styles.themeCard}>
                <span>{topic}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.methodology}>
        <div className="container shadowSurface">
          <div className={styles.methodologyContent}>
            <h2>Approche méthodologique</h2>
            <div className={styles.methodologyGrid}>
              <div>
                <h3>Sources croisées</h3>
                <p>
                  Chaque dossier agrège des données issues de rapports publics, d’indicateurs industriels, de bases statistiques françaises et européennes ainsi que d’observations de terrain.
                </p>
              </div>
              <div>
                <h3>Lecture pluridisciplinaire</h3>
                <p>
                  Les angles retenus combinent perspectives industrielles, technologiques, sociétales et réglementaires afin de restituer la complexité de la filière automobile française.
                </p>
              </div>
              <div>
                <h3>Temporalité suivie</h3>
                <p>
                  Les analyses intègrent les trajectoires historiques des groupes, les jalons de transition énergétique et les projections de capacités publiées jusqu’en 2030.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.editorial}>
        <div className="container">
          <h2 className="sectionTitle">Principes éditoriaux</h2>
          <div className={styles.editorialGrid}>
            <div className={styles.editorialCard}>
              <h3>Neutralité</h3>
              <p>
                Les contenus sont rédigés à la troisième personne et s’attachent à restituer les faits sans promotion. Les citations sont contextualisées et vérifiées avant publication.
              </p>
            </div>
            <div className={styles.editorialCard}>
              <h3>Vérification</h3>
              <p>
                Chaque information est confrontée à plusieurs sources indépendantes. Les données chiffrées sont rapprochées des publications officielles et des métriques reconnues par la profession.
              </p>
            </div>
            <div className={styles.editorialCard}>
              <h3>Transparence</h3>
              <p>
                Les hypothèses méthodologiques, les limites des jeux de données et les zones restant à documenter sont systématiquement mentionnées, afin de faciliter la réutilisation des analyses.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;