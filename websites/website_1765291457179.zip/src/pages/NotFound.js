import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './NotFound.module.css';

const NotFound = () => (
  <div className={styles.page}>
    <Seo title="Page introuvable – French Automotive Sector Analysis" description="La page demandée n’a pas été trouvée ou n’existe plus." />
    <div className="container">
      <div className={styles.card}>
        <h1>Page introuvable</h1>
        <p>Le chemin demandé ne correspond à aucune ressource publiée. Il est recommandé d’utiliser la navigation principale pour poursuivre la consultation.</p>
        <Link to="/" className={styles.link}>
          Retour à l’accueil
        </Link>
      </div>
    </div>
  </div>
);

export default NotFound;