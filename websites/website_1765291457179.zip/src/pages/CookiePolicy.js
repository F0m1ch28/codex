import React from 'react';
import Seo from '../components/Seo';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <div className={styles.legal}>
    <Seo
      title="Politique d'utilisation des cookies – French Automotive Sector Analysis"
      description="Informations sur les cookies utilisés par French Automotive Sector Analysis et modalités de gestion du consentement."
    />
    <div className={`container ${styles.wrapper}`}>
      <h1>Politique d'utilisation des cookies</h1>
      <p>
        La présente politique précise l’usage des cookies et technologies similaires sur le site French Automotive Sector Analysis. Les cookies sont de petits fichiers déposés sur le terminal de l’utilisateur lors de la consultation.
      </p>
      <h2>Cookies techniques indispensables</h2>
      <p>
        Ces cookies garantissent le fonctionnement du site : gestion de session, distribution de charge serveur, sécurisation des formulaires. Ils ne peuvent pas être désactivés car ils conditionnent l’accès aux pages.
      </p>
      <h2>Cookies de mesure anonymisée</h2>
      <p>
        Des statistiques anonymisées peuvent être collectées pour évaluer la fréquentation et améliorer l’ergonomie. Les données recueillies ne permettent pas d’identifier les visiteurs.
      </p>
      <h2>Gestion du consentement</h2>
      <p>
        Lors de la première visite, une bannière informe l’utilisateur de la présence de cookies techniques. Poursuivre la navigation vaut consentement pour ces cookies indispensables, qui ne stockent pas d’informations personnelles sensibles.
      </p>
      <h2>Paramétrage du navigateur</h2>
      <p>
        L’utilisateur peut configurer son navigateur afin de bloquer certains cookies ou de recevoir une notification avant leur dépôt. Cette configuration peut altérer le confort de navigation ou bloquer l’accès à certaines fonctionnalités.
      </p>
      <h2>Contact</h2>
      <p>
        Toute question relative à la politique cookies peut être adressée à contact@french-auto-analysis.fr. La rédaction répond dans un délai raisonnable et met à jour cette page en fonction de l’évolution des pratiques.
      </p>
    </div>
  </div>
);

export default CookiePolicy;