import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import analysesData from '../data/analyses';
import interviewsData from '../data/interviews';
import formatDate from '../utils/date';
import Seo from '../components/Seo';
import styles from './Archives.module.css';

const Archives = () => {
  const archiveItems = useMemo(() => {
    const analyses = analysesData.map((article) => ({
      id: article.id,
      title: article.title,
      subtitle: article.subtitle,
      summary: article.summary,
      date: article.date,
      type: 'Analyse',
      link: `/analyses/${article.slug}`,
    }));

    const interviews = interviewsData.map((interview) => ({
      id: interview.id,
      title: interview.name,
      subtitle: interview.theme,
      summary: interview.summary,
      date: interview.date,
      type: 'Interview',
      link: '/interviews',
    }));

    return [...analyses, ...interviews].sort((a, b) => new Date(b.date) - new Date(a.date));
  }, []);

  const years = useMemo(() => {
    const set = new Set(archiveItems.map((item) => new Date(item.date).getFullYear().toString()));
    return ['Toutes', ...Array.from(set).sort((a, b) => Number(b) - Number(a))];
  }, [archiveItems]);

  const [selectedYear, setSelectedYear] = useState('Toutes');

  const filteredItems =
    selectedYear === 'Toutes'
      ? archiveItems
      : archiveItems.filter((item) => new Date(item.date).getFullYear().toString() === selectedYear);

  return (
    <div className={styles.page}>
      <Seo
        title="Archives – French Automotive Sector Analysis"
        description="Accès chronologique aux analyses et interviews publiées par French Automotive Sector Analysis, avec filtrage par année."
      />
      <section className={`container ${styles.header}`}>
        <h1>Archives</h1>
        <p>
          L’archive rassemble l’ensemble des contenus publiés, classés par ordre chronologique inverse. Les filtres annuels facilitent l’accès aux dossiers correspondant à chaque période.
        </p>
        <div className={styles.filters} role="group" aria-label="Filtrer les archives par année">
          {years.map((year) => (
            <button
              key={year}
              type='button'
              className={`${styles.filterButton} ${selectedYear === year ? styles.activeFilter : ''}`}
              onClick={() => setSelectedYear(year)}
              aria-pressed={selectedYear === year}
            >
              {year}
            </button>
          ))}
        </div>
      </section>
      <section className={styles.timeline}>
        <div className="container">
          <ul className={styles.list}>
            {filteredItems.map((item) => (
              <li key={`${item.type}-${item.id}`} className={styles.item}>
                <div className={styles.marker} aria-hidden="true" />
                <div className={styles.content}>
                  <span className={styles.type}>{item.type}</span>
                  <span className={styles.date}>{formatDate(item.date)}</span>
                  <h3>{item.title}</h3>
                  <p className={styles.subtitle}>{item.subtitle}</p>
                  <p className={styles.summary}>{item.summary}</p>
                  <Link to={item.link} className={styles.link}>
                    Consulter la ressource
                  </Link>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
};

export default Archives;