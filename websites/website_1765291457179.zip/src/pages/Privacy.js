import React from 'react';
import Seo from '../components/Seo';
import styles from './Legal.module.css';

const Privacy = () => (
  <div className={styles.legal}>
    <Seo
      title="Politique de confidentialité – French Automotive Sector Analysis"
      description="Informations relatives à la collecte, à l’utilisation et à la conservation des données personnelles par French Automotive Sector Analysis."
    />
    <div className={`container ${styles.wrapper}`}>
      <h1>Politique de confidentialité</h1>
      <p>
        Cette politique décrit les modalités de traitement des données personnelles collectées via le site French Automotive Sector Analysis. Les pratiques respectent le règlement européen sur la protection des données (RGPD).
      </p>
      <h2>Données collectées</h2>
      <ul>
        <li>Données d’identification et coordonnées transmises via le formulaire de contact.</li>
        <li>Données techniques nécessaires à l’exploitation du site : adresse IP anonymisée, type d’appareil, horodatage des requêtes.</li>
        <li>Aucune donnée sensible n’est sollicitée.</li>
      </ul>
      <h2>Finalités</h2>
      <ul>
        <li>Répondre aux sollicitations éditoriales ou aux demandes d’information.</li>
        <li>Assurer la sécurité du site et prévenir les usages frauduleux.</li>
        <li>Élaborer des statistiques d’audience agrégées de manière anonyme.</li>
      </ul>
      <h2>Durée de conservation</h2>
      <p>
        Les échanges reçus via le formulaire sont conservés pendant une durée maximale de deux ans, le temps d’assurer le suivi des sujets traités. Les journaux techniques sont conservés six mois.
      </p>
      <h2>Destinataires</h2>
      <p>
        Les données sont accessibles uniquement aux membres habilités de la rédaction. Aucun transfert commercial à des tiers n’est réalisé. Les prestataires techniques intervenant pour la maintenance sont soumis à une obligation de confidentialité.
      </p>
      <h2>Vos droits</h2>
      <p>
        Toute personne dispose d’un droit d’accès, de rectification, de limitation ou de suppression des données la concernant. Les demandes peuvent être adressées à contact@french-auto-analysis.fr avec une justification d’identité.
      </p>
      <h2>Mesures de sécurité</h2>
      <p>
        Le site applique un protocole HTTPS, des outils de surveillance des connexions et des sauvegardes régulières. Les messages transmis via le formulaire sont stockés sur des serveurs situés dans l’Union européenne.
      </p>
    </div>
  </div>
);

export default Privacy;