import React from 'react';
import Seo from '../components/Seo';
import styles from './Legal.module.css';

const Terms = () => (
  <div className={styles.legal}>
    <Seo
      title="Conditions d'utilisation – French Automotive Sector Analysis"
      description="Cadre d’utilisation du site French Automotive Sector Analysis, responsabilités respectives et modalités de disponibilité des contenus."
    />
    <div className={`container ${styles.wrapper}`}>
      <h1>Conditions d'utilisation</h1>
      <p className={styles.notice}>
        Les présentes conditions précisent le cadre d’utilisation du site French Automotive Sector Analysis. Toute consultation implique l’acceptation des dispositions suivantes.
      </p>
      <h2>Objet</h2>
      <p>
        Le site diffuse des contenus analytiques sur la filière automobile française. Les informations publiées n’ont pas vocation à remplacer un avis d’expert personnalisé. Les utilisateurs sont invités à croiser les sources avant toute décision.
      </p>
      <h2>Accès et disponibilité</h2>
      <ul>
        <li>Le site est accessible gratuitement depuis tout terminal connecté à Internet.</li>
        <li>Les interruptions temporaires peuvent résulter de maintenances techniques ou de mises à jour éditoriales.</li>
        <li>La rédaction se réserve la possibilité de modifier ou de supprimer des contenus sans préavis.</li>
      </ul>
      <h2>Responsabilités</h2>
      <ul>
        <li>French Automotive Sector Analysis veille à la fiabilité des sources utilisées et signale tout correctif si nécessaire.</li>
        <li>L’utilisateur demeure responsable de l’usage qu’il fait des informations consultées.</li>
        <li>Les liens externes sont fournis pour contextualiser les sujets ; la rédaction ne contrôle pas les contenus des sites tiers.</li>
      </ul>
      <h2>Propriété intellectuelle</h2>
      <p>
        Les textes, visuels et éléments graphiques sont protégés par le droit d’auteur. Toute reproduction partielle ou intégrale nécessite l’accord écrit de la rédaction, à l’exception des courtes citations accompagnées d’une mention claire de la source.
      </p>
      <h2>Évolution des conditions</h2>
      <p>
        La présente version est applicable depuis le 1er janvier 2024. Les conditions peuvent être adaptées pour tenir compte de l’évolution du cadre légal ou des fonctionnalités du site. Les utilisateurs sont invités à consulter régulièrement cette page.
      </p>
    </div>
  </div>
);

export default Terms;