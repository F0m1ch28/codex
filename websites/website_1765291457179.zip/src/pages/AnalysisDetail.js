import React, { useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import analysesData from '../data/analyses';
import formatDate from '../utils/date';
import Seo from '../components/Seo';
import styles from './AnalysisDetail.module.css';

const AnalysisDetail = () => {
  const { slug } = useParams();
  const article = useMemo(() => analysesData.find((item) => item.slug === slug), [slug]);

  if (!article) {
    return (
      <div className={`container ${styles.notFound}`}>
        <Seo title="Analyse introuvable – French Automotive Sector Analysis" description="La ressource demandée n’a pas été trouvée." />
        <h1>Analyse introuvable</h1>
        <p>Le dossier recherché n’est plus disponible ou l’adresse renseignée est incorrecte.</p>
        <Link to="/analyses" className={styles.backLink}>
          Retourner vers les analyses
        </Link>
      </div>
    );
  }

  return (
    <article className={`container ${styles.detail}`}>
      <Seo title={`${article.title} – French Automotive Sector Analysis`} description={article.summary} />
      <header className={styles.header}>
        <span className={styles.date}>{formatDate(article.date)}</span>
        <h1>{article.title}</h1>
        {article.subtitle && <h2>{article.subtitle}</h2>}
        <div className={styles.tags}>
          {article.tags.map((tag) => (
            <span key={tag}>{tag}</span>
          ))}
        </div>
      </header>
      <div className={styles.content}>
        {article.content.map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
      </div>
      <footer className={styles.footer}>
        <Link to="/analyses" className={styles.backLink}>
          Retour à la liste des analyses
        </Link>
      </footer>
    </article>
  );
};

export default AnalysisDetail;