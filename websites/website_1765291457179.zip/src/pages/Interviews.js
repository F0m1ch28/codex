import React, { useMemo } from 'react';
import interviewsData from '../data/interviews';
import formatDate from '../utils/date';
import Seo from '../components/Seo';
import styles from './Interviews.module.css';

const Interviews = () => {
  const interviews = useMemo(
    () => [...interviewsData].sort((a, b) => new Date(b.date) - new Date(a.date)),
    []
  );

  return (
    <div className={styles.page}>
      <Seo
        title="Interviews – French Automotive Sector Analysis"
        description="Entretiens menés avec des ingénieurs, designers et spécialistes de la filière automobile française afin de documenter les orientations techniques et industrielles."
      />
      <section className={`container ${styles.header}`}>
        <h1>Interviews</h1>
        <p>
          Les entretiens donnent la parole aux responsables techniques, chercheurs et décideurs impliqués dans les transformations de l’automobile française. Chaque échange est retranscrit dans un format synthétique, sans commentaire promotionnel.
        </p>
      </section>
      <section className={styles.list}>
        <div className="container">
          <ul className={styles.cards}>
            {interviews.map((interview) => (
              <li key={interview.id} className={styles.card}>
                <div className={styles.meta}>
                  <span>{formatDate(interview.date)}</span>
                  <span>{interview.role}</span>
                </div>
                <h3>{interview.name}</h3>
                <p className={styles.theme}>{interview.theme}</p>
                <p className={styles.summary}>{interview.summary}</p>
                <ul className={styles.topicList} aria-label="Focus de l'interview">
                  {interview.topics.map((topic) => (
                    <li key={topic}>{topic}</li>
                  ))}
                </ul>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
};

export default Interviews;