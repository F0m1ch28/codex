import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Analyses from './pages/Analyses';
import AnalysisDetail from './pages/AnalysisDetail';
import Interviews from './pages/Interviews';
import Archives from './pages/Archives';
import APropos from './pages/APropos';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import NotFound from './pages/NotFound';

const App = () => (
  <BrowserRouter>
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/analyses" element={<Analyses />} />
        <Route path="/analyses/:slug" element={<AnalysisDetail />} />
        <Route path="/interviews" element={<Interviews />} />
        <Route path="/archives" element={<Archives />} />
        <Route path="/a-propos" element={<APropos />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/cookie-policy" element={<CookiePolicy />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Layout>
  </BrowserRouter>
);

export default App;