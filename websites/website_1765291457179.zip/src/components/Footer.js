import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.inner}`}>
      <div className={styles.brand}>
        <span className={styles.logo}>French Automotive Sector Analysis</span>
        <p className={styles.description}>
          Publication indépendante dédiée aux transformations industrielles, technologiques et réglementaires du secteur automobile français.
        </p>
        <p className={styles.disclaimer}>
          Ressource éditoriale non marchande produisant des analyses fondées sur des données vérifiées et des entretiens spécialisés.
        </p>
      </div>
      <div className={styles.columns}>
        <div className={styles.column}>
          <h3>Navigation</h3>
          <ul className="listClean">
            <li>
              <Link to="/analyses">Analyses</Link>
            </li>
            <li>
              <Link to="/interviews">Interviews</Link>
            </li>
            <li>
              <Link to="/archives">Archives</Link>
            </li>
            <li>
              <Link to="/a-propos">À propos</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3>Cadre légal</h3>
          <ul className="listClean">
            <li>
              <Link to="/terms">Conditions d'utilisation</Link>
            </li>
            <li>
              <Link to="/privacy">Politique de confidentialité</Link>
            </li>
            <li>
              <Link to="/cookie-policy">Politique cookies</Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3>Contact éditorial</h3>
          <ul className="listClean">
            <li>contact@french-auto-analysis.fr</li>
            <li>Projet éditorial basé en France</li>
            <li>Support dédié aux chercheurs, experts et médias</li>
          </ul>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <div className="container">
        <p>© {new Date().getFullYear()} French Automotive Sector Analysis. Tous droits réservés.</p>
      </div>
    </div>
  </footer>
);

export default Footer;