import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [open, setOpen] = useState(false);

  const toggleMenu = () => {
    setOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          French Automotive Sector Analysis
        </NavLink>
        <button
          type="button"
          className={styles.menuButton}
          onClick={toggleMenu}
          aria-expanded={open}
          aria-controls="navigation-principale"
          aria-label="Ouvrir la navigation principale"
        >
          <span className={styles.menuBar} />
          <span className={styles.menuBar} />
          <span className={styles.menuBar} />
        </button>
        <nav
          id="navigation-principale"
          className={`${styles.nav} ${open ? styles.navOpen : ''}`}
          aria-label="Navigation principale"
        >
          <NavLink
            to="/"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Accueil
          </NavLink>
          <NavLink
            to="/analyses"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Analyses
          </NavLink>
          <NavLink
            to="/interviews"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Interviews
          </NavLink>
          <NavLink
            to="/archives"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Archives
          </NavLink>
          <NavLink
            to="/a-propos"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            À propos
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;