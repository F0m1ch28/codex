import React from 'react';
import PropTypes from 'prop-types';
import Header from './Header';
import Footer from './Footer';
import CookieBanner from './CookieBanner';
import ScrollToTop from './ScrollToTop';
import styles from './Layout.module.css';

const Layout = ({ children }) => (
  <div className={styles.layout}>
    <a className={styles.skipLink} href="#contenu-principal">
      Aller directement au contenu
    </a>
    <Header />
    <main id="contenu-principal" className={styles.main}>
      {children}
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTop />
  </div>
);

Layout.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Layout;