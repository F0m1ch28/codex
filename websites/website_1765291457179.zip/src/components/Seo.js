import { useEffect } from 'react';
import PropTypes from 'prop-types';

const updateMetaTag = (selector, attribute, value) => {
  if (typeof document === 'undefined') return;
  let element = document.querySelector(selector);
  if (!element) {
    element = document.createElement('meta');
    if (attribute === 'name') {
      element.setAttribute('name', selector.replace('meta[name="', '').replace('"]', ''));
    } else if (attribute === 'property') {
      element.setAttribute('property', selector.replace('meta[property="', '').replace('"]', ''));
    }
    document.head.appendChild(element);
  }
  element.setAttribute(attribute, value);
};

const Seo = ({ title, description }) => {
  useEffect(() => {
    if (title && typeof document !== 'undefined') {
      document.title = title;
      updateMetaTag('meta[property="og:title"]', 'property', 'og:title');
      updateMetaTag('meta[property="og:title"]', 'content', title);
      updateMetaTag('meta[name="twitter:title"]', 'name', 'twitter:title');
      updateMetaTag('meta[name="twitter:title"]', 'content', title);
    }
    if (description) {
      if (typeof document !== 'undefined') {
        let descriptionTag = document.querySelector('meta[name="description"]');
        if (!descriptionTag) {
          descriptionTag = document.createElement('meta');
          descriptionTag.setAttribute('name', 'description');
          document.head.appendChild(descriptionTag);
        }
        descriptionTag.setAttribute('content', description);
      }
      updateMetaTag('meta[property="og:description"]', 'property', 'og:description');
      updateMetaTag('meta[property="og:description"]', 'content', description);
      updateMetaTag('meta[name="twitter:description"]', 'name', 'twitter:description');
      updateMetaTag('meta[name="twitter:description"]', 'content', description);
    }
  }, [title, description]);

  return null;
};

Seo.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
};

Seo.defaultProps = {
  title: 'French Automotive Sector Analysis',
  description: '',
};

export default Seo;