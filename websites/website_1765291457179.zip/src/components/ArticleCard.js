import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import formatDate from '../utils/date';
import styles from './ArticleCard.module.css';

const ArticleCard = ({ article }) => (
  <article className={styles.card}>
    <header className={styles.header}>
      <span className={styles.date}>{formatDate(article.date)}</span>
    </header>
    <h3 className={styles.title}>
      <Link to={`/analyses/${article.slug}`} className={styles.titleLink}>
        {article.title}
      </Link>
    </h3>
    {article.subtitle && <p className={styles.subtitle}>{article.subtitle}</p>}
    <p className={styles.summary}>{article.summary}</p>
    <div className={styles.tags} aria-label="Étiquettes thématiques">
      {article.tags.map((tag) => (
        <span key={tag} className={styles.tag}>
          {tag}
        </span>
      ))}
    </div>
    <Link to={`/analyses/${article.slug}`} className={styles.link} aria-label={`Accéder à l'analyse ${article.title}`}>
      Dossier complet
    </Link>
  </article>
);

ArticleCard.propTypes = {
  article: PropTypes.shape({
    slug: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    subtitle: PropTypes.string,
    summary: PropTypes.string.isRequired,
    date: PropTypes.string.isRequired,
    tags: PropTypes.arrayOf(PropTypes.string).isRequired,
  }).isRequired,
};

export default ArticleCard;