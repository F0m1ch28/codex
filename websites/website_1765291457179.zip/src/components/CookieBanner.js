import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const consent = window.localStorage.getItem('cookieConsent');
      if (!consent) {
        setVisible(true);
      }
    }
  }, []);

  const acceptCookies = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('cookieConsent', 'accepted');
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="region" aria-label="Gestion des cookies">
      <p>
        Ce site utilise des cookies techniques nécessaires au bon fonctionnement de la plateforme. Les détails figurent dans la{' '}
        <Link to="/cookie-policy">politique d'utilisation des cookies</Link>.
      </p>
      <button type="button" onClick={acceptCookies} className={styles.button}>
        Compris
      </button>
    </div>
  );
};

export default CookieBanner;