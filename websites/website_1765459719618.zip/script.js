document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navList = document.querySelector('.nav-list');

  if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      navList.classList.toggle('is-open');
    });

    navList.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        navList.classList.remove('is-open');
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');
    const consent = localStorage.getItem('pkts-cookie-consent');

    if (!consent) {
      cookieBanner.classList.add('is-visible');
    }

    const handleChoice = (value) => {
      localStorage.setItem('pkts-cookie-consent', value);
      cookieBanner.classList.remove('is-visible');
    };

    acceptBtn?.addEventListener('click', () => handleChoice('accepted'));
    declineBtn?.addEventListener('click', () => handleChoice('declined'));
  }

  const filterButtons = document.querySelectorAll('[data-filter]');
  const filterCards = document.querySelectorAll('[data-category]');
  if (filterButtons.length && filterCards.length) {
    filterButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const target = button.getAttribute('data-filter');

        filterButtons.forEach((btn) => {
          btn.classList.toggle('is-active', btn === button);
          btn.setAttribute('aria-pressed', String(btn === button));
        });

        filterCards.forEach((card) => {
          const categories = card.getAttribute('data-category')?.split(' ') || [];
          if (target === 'all' || categories.includes(target)) {
            card.classList.remove('is-hidden');
          } else {
            card.classList.add('is-hidden');
          }
        });
      });
    });
  }

  const contactForm = document.querySelector('[data-form="contact"]');
  if (contactForm) {
    const feedbackArea = contactForm.querySelector('[data-feedback]');

    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      let hasError = false;
      const messages = [];

      const name = formData.get('name')?.toString().trim();
      const email = formData.get('email')?.toString().trim();
      const message = formData.get('message')?.toString().trim();

      if (!name) {
        hasError = true;
        messages.push('Please add your name.');
      }

      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        hasError = true;
        messages.push('Please provide a valid email address.');
      }

      if (!message || message.length < 20) {
        hasError = true;
        messages.push('Tell us more about your request (minimum 20 characters).');
      }

      if (hasError) {
        feedbackArea.textContent = messages.join(' ');
        feedbackArea.style.color = '#FF6B8B';
      } else {
        feedbackArea.textContent = 'Thank you! Our toy specialists will reach out within one business day.';
        feedbackArea.style.color = '#4ECDC4';
        contactForm.reset();
      }
    });
  }
});