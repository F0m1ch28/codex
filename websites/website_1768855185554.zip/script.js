document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const navigation = document.getElementById('primary-navigation');
  const body = document.body;

  if (navToggle && navigation) {
    navToggle.addEventListener('click', function () {
      const isOpen = navigation.classList.toggle('open');
      navToggle.classList.toggle('open', isOpen);
      if (isOpen) {
        navigation.setAttribute('aria-hidden', 'false');
        navToggle.setAttribute('aria-expanded', 'true');
        body.style.overflow = 'hidden';
      } else {
        navigation.setAttribute('aria-hidden', 'true');
        navToggle.setAttribute('aria-expanded', 'false');
        body.style.overflow = '';
      }
    });

    navigation.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        navigation.classList.remove('open');
        navToggle.classList.remove('open');
        navigation.setAttribute('aria-hidden', 'true');
        navToggle.setAttribute('aria-expanded', 'false');
        body.style.overflow = '';
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptCookieBtn = document.querySelector('[data-cookie-accept]');
  const declineCookieBtn = document.querySelector('[data-cookie-decline]');
  const storageKey = 'pmia_cookie_consent';

  if (cookieBanner && acceptCookieBtn && declineCookieBtn) {
    const storedConsent = localStorage.getItem(storageKey);
    if (!storedConsent) {
      cookieBanner.classList.add('active');
    }

    acceptCookieBtn.addEventListener('click', function () {
      localStorage.setItem(storageKey, 'accepted');
      cookieBanner.classList.remove('active');
    });

    declineCookieBtn.addEventListener('click', function () {
      localStorage.setItem(storageKey, 'declined');
      cookieBanner.classList.remove('active');
    });
  }
});