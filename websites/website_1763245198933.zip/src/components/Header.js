import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Startseite' },
  { path: '/ueber-uns', label: 'Über Uns' },
  { path: '/leistungen', label: 'Leistungen' },
  { path: '/projekte', label: 'Projekte' },
  { path: '/kontakt', label: 'Kontakt' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setMenuOpen(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} role="banner">
      <div className={`container ${styles.inner}`}>
        <NavLink to="/" className={styles.logo} aria-label="GreenTech Solutions Startseite">
          <span className={styles.logoIcon} aria-hidden="true">
            ☀️
          </span>
          <span className={styles.logoText}>GreenTech Solutions</span>
        </NavLink>
        <button
          type="button"
          className={`${styles.menuButton} ${menuOpen ? styles.menuOpen : ''}`}
          aria-label={menuOpen ? 'Navigation schließen' : 'Navigation öffnen'}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Hauptnavigation">
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.path} className={styles.navItem}>
                <NavLink
                  end={item.path === '/'}
                  to={item.path}
                  className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}
                  onClick={() => setMenuOpen(false)}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
            <li className={`${styles.navItem} ${styles.navCta}`}>
              <NavLink
                to="/kontakt"
                className={({ isActive }) =>
                  isActive ? `${styles.contactButton} ${styles.contactButtonActive}` : styles.contactButton
                }
                onClick={() => setMenuOpen(false)}
              >
                Beratung anfragen
              </NavLink>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;