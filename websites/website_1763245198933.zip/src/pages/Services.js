import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './Services.module.css';

const services = [
  {
    title: 'Photovoltaik für Privatkunden',
    tagline: 'Individuelle Dachlösungen für Ein- und Mehrfamilienhäuser.',
    description:
      'Wir analysieren Ihr Dach, Ihren Stromverbrauch und entwickeln ein passgenaues Konzept inklusive Speicher und Wallbox.',
    bullets: [
      'Ertrags- und Verschattungsanalyse mit Drohnenvermessung',
      'Auswahl hochwertiger Module (z. B. Meyer Burger, QCells)',
      'Optionale Speicherlösungen für maximale Autarkie',
      'Smart-Home-Integration und Energiemonitoring per App'
    ],
    benefits: [
      'Bis zu 70 % geringere Stromkosten',
      'Wertsteigerung Ihrer Immobilie',
      'Attraktive Förderungen und Steuererleichterungen',
      'Komfortable Rundum-Betreuung – auch nach der Inbetriebnahme'
    ],
    image: 'https://picsum.photos/900/650?random=301'
  },
  {
    title: 'Gewerbliche Photovoltaik',
    tagline: 'Skalierbare Lösungen für Industrie, Handel und Logistik.',
    description:
      'Wir verbinden Energieeffizienz mit wirtschaftlichem Mehrwert: ideale Lösungen für große Dachflächen, Parkplätze oder Freiflächenanlagen.',
    bullets: [
      'Ganzheitliche Lastprofilanalyse und Eigenverbrauchsoptimierung',
      'Integration von Ladeinfrastruktur und Wärmepumpen',
      'Unterstützung bei PPA-Modellen und Mieterstrom',
      'Koordination mit Netzbetreibern und Behörden'
    ],
    benefits: [
      'Planbare Energiekosten und ESG-konforme Berichterstattung',
      'Reduzierung von CO₂-Emissionen und Imagegewinn',
      'Steuerliche Vorteile durch Sonderabschreibungen',
      'Schnelle Realisierung dank erfahrener Projektteams'
    ],
    image: 'https://picsum.photos/900/650?random=302'
  },
  {
    title: 'Wartung & Monitoring',
    tagline: 'Zuverlässige Betriebsführung für maximale Anlagenverfügbarkeit.',
    description:
      'Unsere Servicetechniker sorgen dafür, dass Ihre Anlage dauerhaft Höchstleistungen erzielt – proaktiv und transparent.',
    bullets: [
      '24/7-Fernüberwachung durch unser Monitoring-Center',
      'Regelmäßige technische Inspektionen und Reinigung',
      'Thermografie-Checks zur Früherkennung von Fehlern',
      'Erweiterte Garantie- und Versicherungspakete'
    ],
    benefits: [
      'Frühzeitige Fehlererkennung und kein Ertragsverlust',
      'Ein Ansprechpartner für Wartung, Reparatur und Versicherung',
      'Individuelle Service-Level-Agreements',
      'Detaillierte Berichte für Banken und Investoren'
    ],
    image: 'https://picsum.photos/900/650?random=303'
  },
  {
    title: 'Beratung & Projektsteuerung',
    tagline: 'Von der ersten Idee bis zur finale Abnahme zuverlässig begleitet.',
    description:
      'Wir übernehmen Machbarkeitsstudien, Fördermittelmanagement und koordinieren alle Gewerke – auf Wunsch schlüsselfertig.',
    bullets: [
      'Projektentwicklung inklusive Wirtschaftlichkeitsrechnung',
      'Fördermittel- und Finanzierungsberatung (KfW, BAFA, EEG)',
      'Genehmigungsmanagement und Netzanschlusskoordination',
      'Bauleitung durch zertifizierte Projektmanager:innen'
    ],
    benefits: [
      'Klare Projektstruktur und transparente Kommunikation',
      'Minimierte Risiken durch erfahrene Projektsteuerung',
      'Optimale Nutzung von Fördermitteln und Zuschüssen',
      'Termintreue Umsetzung und Kostenkontrolle'
    ],
    image: 'https://picsum.photos/900/650?random=304'
  }
];

const Services = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const activeService = services[activeIndex];

  return (
    <>
      <Helmet>
        <title>Leistungen | GreenTech Solutions Photovoltaik</title>
        <meta
          name="description"
          content="Entdecken Sie die Photovoltaik-Leistungen von GreenTech Solutions: Planung, Installation, Wartung und Beratung für Bayern."
        />
        <link rel="canonical" href="https://www.greentech-solutions.de/leistungen" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Unsere Leistungen für Ihren Solarerfolg</h1>
            <p>
              Wir bieten durchgängige Services – von der Potenzialanalyse über die technische Umsetzung bis zum
              langfristigen Monitoring. Jede Lösung ist individuell auf Ihren Energiebedarf abgestimmt.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <div className={styles.layout}>
            <div className={styles.tabList} role="tablist" aria-label="Leistungskategorien">
              {services.map((service, index) => (
                <button
                  key={service.title}
                  type="button"
                  role="tab"
                  aria-selected={activeIndex === index}
                  className={`${styles.tabButton} ${activeIndex === index ? styles.activeButton : ''}`}
                  onClick={() => setActiveIndex(index)}
                >
                  {service.title}
                </button>
              ))}
            </div>

            <article className={styles.serviceDetail} role="tabpanel">
              <div
                className={styles.serviceImage}
                style={{ backgroundImage: `url(${activeService.image})` }}
                aria-hidden="true"
              />
              <div className={styles.serviceContent}>
                <span className={styles.serviceTagline}>{activeService.tagline}</span>
                <h2>{activeService.title}</h2>
                <p>{activeService.description}</p>

                <div className={styles.detailGrid}>
                  <div>
                    <h3>Unser Leistungsumfang</h3>
                    <ul>
                      {activeService.bullets.map((bullet) => (
                        <li key={bullet}>{bullet}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3>Ihre Vorteile</h3>
                    <ul>
                      {activeService.benefits.map((benefit) => (
                        <li key={benefit}>{benefit}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <Link className="btn btn-primary" to="/kontakt">
                  Beratungsgespräch buchen
                </Link>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaBox}>
            <h2>Wir entwickeln Ihr Solarprojekt mit Präzision und Leidenschaft</h2>
            <p>
              Profitieren Sie von regionaler Expertise, klaren Prozessen und einem Team, das jedes Projekt als
              Gemeinschaftsaufgabe versteht. Wir freuen uns, Sie kennenzulernen.
            </p>
            <Link className="btn btn-secondary" to="/projekte">
              Referenzprojekte ansehen
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;