document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  const body = document.body;

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = nav.classList.toggle("open");
      navToggle.classList.toggle("active", expanded);
      if (expanded) {
        body.classList.add("no-scroll");
        navToggle.setAttribute("aria-expanded", "true");
      } else {
        body.classList.remove("no-scroll");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        nav.classList.remove("open");
        navToggle.classList.remove("active");
        body.classList.remove("no-scroll");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const yearSpan = document.getElementById("current-year");
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  const cookieBanner = document.getElementById("cookie-banner");
  const cookieKey = "ashicafezn_cookie_consent";
  if (cookieBanner) {
    const storedChoice = localStorage.getItem(cookieKey);
    if (!storedChoice) {
      cookieBanner.classList.add("active");
    }

    cookieBanner.querySelectorAll("button[data-cookie-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        const choice = button.getAttribute("data-cookie-choice");
        localStorage.setItem(cookieKey, choice);
        cookieBanner.classList.remove("active");
      });
    });
  }

  const toast = document.getElementById("global-toast");
  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("visible");
    setTimeout(() => {
      toast.classList.remove("visible");
    }, 2200);
  }

  const forms = document.querySelectorAll("form.form-redirect");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const submitButton = form.querySelector("button[type='submit']");
      if (submitButton) {
        submitButton.disabled = true;
      }
      showToast("Thank you. Redirecting...");
      setTimeout(() => {
        window.location.href = form.getAttribute("action") || "thank-you.html";
      }, 1500);
    });
  });
});