document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav-list');

    if (navToggle && navList) {
        navToggle.addEventListener('click', () => {
            navList.classList.toggle('nav-open');
            navToggle.classList.toggle('active');
        });

        navList.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navList.classList.remove('nav-open');
                navToggle.classList.remove('active');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');
    const customizeBtn = document.getElementById('cookieCustomize');

    if (cookieBanner) {
        const consentState = localStorage.getItem('genus_cookie_preference');
        if (!consentState) {
            cookieBanner.classList.add('show');
        }

        const hideBanner = (status) => {
            localStorage.setItem('genus_cookie_preference', status);
            cookieBanner.classList.remove('show');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => hideBanner('accepted'));
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => hideBanner('declined'));
        }

        if (customizeBtn) {
            customizeBtn.addEventListener('click', () => {
                window.location.href = 'cookies.html';
            });
        }
    }
});