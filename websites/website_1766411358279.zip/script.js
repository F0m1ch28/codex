document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', function () {
      navToggle.classList.toggle('is-active');
      mainNav.classList.toggle('is-open');
    });

    mainNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        navToggle.classList.remove('is-active');
        mainNav.classList.remove('is-open');
      });
    });
  }

  const ratingControls = document.querySelectorAll('.rating-control');
  ratingControls.forEach(function (control) {
    const stars = control.querySelectorAll('.star');
    stars.forEach(function (star) {
      star.addEventListener('mouseenter', function () {
        const value = Number(star.dataset.value);
        stars.forEach(function (s) {
          s.style.color = Number(s.dataset.value) <= value ? '#f5a623' : '#ccc';
        });
      });

      star.addEventListener('mouseleave', function () {
        stars.forEach(function (s) {
          s.style.color = '';
        });
      });

      star.addEventListener('click', function () {
        const selected = Number(star.dataset.value);
        control.dataset.userRating = selected;
        stars.forEach(function (s) {
          s.classList.toggle('is-selected', Number(s.dataset.value) <= selected);
        });
      });
    });
  });

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptButton = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineButton = cookieBanner.querySelector('[data-cookie="decline"]');
    const consent = localStorage.getItem('aav_cookie_consent');

    if (!consent) {
      cookieBanner.classList.add('is-visible');
    }

    if (acceptButton) {
      acceptButton.addEventListener('click', function () {
        localStorage.setItem('aav_cookie_consent', 'accepted');
        cookieBanner.classList.remove('is-visible');
      });
    }

    if (declineButton) {
      declineButton.addEventListener('click', function () {
        localStorage.setItem('aav_cookie_consent', 'declined');
        cookieBanner.classList.remove('is-visible');
      });
    }
  }
});