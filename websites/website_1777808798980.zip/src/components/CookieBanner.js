import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'gamblingreview_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }

    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleConsent = (value) => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(STORAGE_KEY, value);
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p className={styles.text}>
          Мы используем cookie для улучшения работы сайта. Продолжая, вы соглашаетесь с{' '}
          <a href="/cookie">политикой cookie</a>.
        </p>
        <div className={styles.actions}>
          <button type="button" className={styles.accept} onClick={() => handleConsent('accepted')}>
            Принять
          </button>
          <button type="button" className={styles.decline} onClick={() => handleConsent('declined')}>
            Отклонить
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;