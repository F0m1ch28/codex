import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.inner}`}>
      <div className={styles.column}>
        <Link to="/" className={styles.logo}>
          <span className={styles.logoAccent}>Gambling</span>Review
        </Link>
        <p className={styles.description}>
          Международный аналитический проект, который помогает сравнить онлайн-казино по лицензиям,
          бонусам и условиям выплат. Делимся фактами, чтобы вы принимали осознанные решения.
        </p>
        <p className={styles.disclaimer}>
          GamblingReview не продвигает азартные игры. Информация предназначена для лиц старше 18 лет.
          Всегда оценивайте риски и используйте инструменты ответственной игры.
        </p>
      </div>

      <div className={styles.column}>
        <h4 className={styles.heading}>Навигация</h4>
        <ul className={styles.list}>
          <li><Link to="/">Главная</Link></li>
          <li><Link to="/casino">Казино</Link></li>
          <li><Link to="/compare">Сравнение</Link></li>
          <li><Link to="/about">О нас</Link></li>
          <li><Link to="/contacts">Контакты</Link></li>
        </ul>
      </div>

      <div className={styles.column}>
        <h4 className={styles.heading}>Документы</h4>
        <ul className={styles.list}>
          <li><Link to="/terms">Условия</Link></li>
          <li><Link to="/privacy">Конфиденциальность</Link></li>
          <li><Link to="/cookie">Cookie политика</Link></li>
        </ul>
        <div className={styles.socials}>
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn GamblingReview">
            <i className="fab fa-linkedin-in" />
          </a>
          <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter GamblingReview">
            <i className="fab fa-twitter" />
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube GamblingReview">
            <i className="fab fa-youtube" />
          </a>
        </div>
      </div>

      <div className={styles.column}>
        <h4 className={styles.heading}>Контакты</h4>
        <ul className={styles.list}>
          <li>
            <i className="fas fa-map-marker-alt" aria-hidden="true" />
            123 Gambling St, Las Vegas, NV 89101, USA
          </li>
          <li>
            <i className="fas fa-phone" aria-hidden="true" />
            <a href="tel:+17025550123">+1 (702) 555-0123</a>
          </li>
          <li>
            <i className="fas fa-envelope" aria-hidden="true" />
            <a href="mailto:info@gamblingreview.com">info@gamblingreview.com</a>
          </li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <div className="container">
        <p className={styles.copyright}>
          © {new Date().getFullYear()} GamblingReview. Все права защищены.
        </p>
      </div>
    </div>
  </footer>
);

export default Footer;