import React, { useEffect, useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { label: 'Главная', path: '/' },
  { label: 'Казино', path: '/casino' },
  { label: 'Сравнение', path: '/compare' },
  { label: 'О нас', path: '/about' },
  { label: 'Контакты', path: '/contacts' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={styles.header} role="banner">
      <div className={`container ${styles.inner}`}>
        <div className={styles.logoArea}>
          <NavLink to="/" className={styles.logo} aria-label="GamblingReview — перейти на главную">
            <span className={styles.logoAccent}>Gambling</span>Review
          </NavLink>
          <p className={styles.tagline}>Обзор и сравнение гэмблинг продуктов</p>
        </div>

        <nav className={styles.nav} aria-label="Основная навигация">
          <button
            className={styles.burger}
            aria-label={menuOpen ? 'Закрыть меню' : 'Открыть меню'}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((prev) => !prev)}
          >
            <span className="visuallyHidden">{menuOpen ? 'Закрыть меню' : 'Открыть меню'}</span>
            <i className={`fas ${menuOpen ? 'fa-times' : 'fa-bars'}`} />
          </button>

          <ul className={`${styles.navList} ${menuOpen ? styles.open : ''}`}>
            {navLinks.map((item) => (
              <li key={item.path} className={styles.navItem}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <NavLink to="/contacts" className={styles.contactBtn}>
          Связаться
        </NavLink>
      </div>
    </header>
  );
};

export default Header;