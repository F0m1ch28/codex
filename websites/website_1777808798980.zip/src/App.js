import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import CasinoList from './pages/CasinoList';
import CasinoReview from './pages/CasinoReview';
import Compare from './pages/Compare';
import About from './pages/About';
import Contacts from './pages/Contacts';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

const RouteChangeHandler = () => {
  const location = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  return null;
};

const AppLayout = () => (
  <>
    <RouteChangeHandler />
    <Header />
    <main className="mainContent">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/casino" element={<CasinoList />} />
        <Route path="/review/:id" element={<CasinoReview />} />
        <Route path="/compare" element={<Compare />} />
        <Route path="/about" element={<About />} />
        <Route path="/contacts" element={<Contacts />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/cookie" element={<CookiePolicy />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTopButton />
  </>
);

const App = () => (
  <Router>
    <AppLayout />
  </Router>
);

export default App;