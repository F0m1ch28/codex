import { useEffect, useRef, useState } from 'react';

const useReveal = (options = {}) => {
  const elementRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const currentElement = elementRef.current;
    if (!currentElement) {
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      {
        threshold: 0.2,
        ...options
      }
    );

    observer.observe(currentElement);

    return () => {
      observer.disconnect();
    };
  }, [options]);

  return [elementRef, isVisible];
};

export default useReveal;