import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import useReveal from '../hooks/useReveal';
import { advantages, casinos, faqs, testimonials } from '../data';
import styles from './Home.module.css';

const Home = () => {
  const topCasinos = React.useMemo(
    () => [...casinos].sort((a, b) => b.rating - a.rating).slice(0, 3),
    []
  );
  const popularOffers = React.useMemo(
    () => casinos.filter((casino) => casino.rating >= 4.5).slice(0, 4),
    []
  );

  const [heroRef, heroVisible] = useReveal();
  const [aboutRef, aboutVisible] = useReveal();
  const [topRef, topVisible] = useReveal();
  const [compareRef, compareVisible] = useReveal();
  const [rateRef, rateVisible] = useReveal();
  const [offersRef, offersVisible] = useReveal();
  const [testimonialsRef, testimonialsVisible] = useReveal();
  const [advantagesRef, advantagesVisible] = useReveal();

  return (
    <div className={styles.home}>
      <Helmet>
        <title>GamblingReview | Экспертные обзоры и сравнение казино</title>
        <meta
          name="description"
          content="GamblingReview — независимые обзоры казино, сравнение бонусов, лицензий и условий выплат. Помогаем сделать взвешенный выбор."
        />
        <meta
          name="keywords"
          content="гэмблинг, казино, обзор казино, сравнение казино, бонусы казино, условия казино"
        />
      </Helmet>

      <section
        ref={heroRef}
        className={`${styles.section} ${styles.hero} ${heroVisible ? styles.visible : ''}`}
      >
        <div className={`container ${styles.heroGrid}`}>
          <div className={styles.heroContent}>
            <span className="badge">Международные обзоры</span>
            <h1>Лучшие гэмблинг продукты: сравнивайте условия и выбирайте лучшее для себя</h1>
            <p>
              Наши эксперты проанализировали десятки казино, чтобы вы могли сделать осознанный выбор.
              Мы проверяем лицензии, скорость выводов, прозрачность бонусов и инструменты
              ответственной игры.
            </p>
            <div className={styles.heroActions}>
              <Link to="/compare" className={styles.primaryBtn}>
                Сравнить условия
              </Link>
              <Link to="/casino" className={styles.secondaryBtn}>
                Смотреть обзоры
              </Link>
            </div>
            <div className={styles.heroStats} role="list">
              <div className={styles.statCard} role="listitem">
                <span className={styles.statNumber}>45+</span>
                <span className={styles.statLabel}>проверенных казино</span>
              </div>
              <div className={styles.statCard} role="listitem">
                <span className={styles.statNumber}>120+</span>
                <span className={styles.statLabel}>обновлений бонусов в месяц</span>
              </div>
              <div className={styles.statCard} role="listitem">
                <span className={styles.statNumber}>12</span>
                <span className={styles.statLabel}>аналитиков и редакторов</span>
              </div>
            </div>
          </div>
          <div className={styles.heroMedia}>
            <img
              src="https://picsum.photos/900/600?random=32"
              alt="Аналитики GamblingReview сравнивают показатели онлайн-казино"
              loading="lazy"
            />
            <div className={styles.mediaAnnotation}>
              Еженедельно обновляем таблицы условий, чтобы данные оставались актуальными.
            </div>
          </div>
        </div>
      </section>

      <section
        ref={aboutRef}
        className={`${styles.section} ${styles.about} ${aboutVisible ? styles.visible : ''}`}
      >
        <div className="container">
          <h2 className="sectionTitle">GamblingReview — ваш гид в мире онлайн-казино</h2>
          <p className="sectionSubtitle">
            GamblingReview — ваш надежный гид в мире онлайн-казино. Мы предоставляем исчерпывающую
            информацию о каждом оффере, его условиях и бонусах. Наша цель — помочь вам найти
            платформу, отвечающую вашим ожиданиям и требованиям безопасности.
          </p>
          <div className={styles.aboutGrid}>
            <div className={styles.aboutCard}>
              <h3>Подход к аналитике</h3>
              <p>
                Собираем данные о лицензиях, провайдерах и методах оплаты. Проверяем честность
                бонусов и соблюдение принципов ответственной игры.
              </p>
            </div>
            <div className={styles.aboutCard}>
              <h3>Экспертная команда</h3>
              <p>
                Аналитики, специалисты по комплаенсу и редакторы из Европы, Северной Америки и
                Латинской Америки. Работаем на трех языках.
              </p>
            </div>
            <div className={styles.aboutCard}>
              <h3>Прозрачные методики</h3>
              <p>
                Каждый рейтинг сопровождаем раскрытием критериев. Пользователь всегда понимает, как
                сформирована итоговая оценка.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section
        ref={topRef}
        className={`${styles.section} ${styles.topCasinos} ${topVisible ? styles.visible : ''}`}
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Наши топ-3 казино по рейтингу пользователей</h2>
            <p className="sectionSubtitle">
              Список постоянно обновляется: учитываем отзывы, скорость выплат и работу службы
              поддержки. Никаких рекламных приоритетов.
            </p>
          </div>
          <div className={styles.cardGrid}>
            {topCasinos.map((casino) => (
              <article key={casino.id} className={styles.casinoCard}>
                <div className={styles.cardImage}>
                  <img src={casino.image} alt={`Казино ${casino.name}`} loading="lazy" />
                  <span className={styles.ratingBadge}>
                    <i className="fas fa-star" aria-hidden="true" /> {casino.rating.toFixed(1)}
                  </span>
                </div>
                <div className={styles.cardBody}>
                  <h3>{casino.name}</h3>
                  <p>{casino.description}</p>
                  <ul className={styles.cardList}>
                    <li><i className="fas fa-gift" aria-hidden="true" /> {casino.bonus}</li>
                    <li><i className="fas fa-shield-alt" aria-hidden="true" /> Лицензия: {casino.license}</li>
                    <li><i className="fas fa-wallet" aria-hidden="true" /> Мин. депозит: {casino.minDeposit}</li>
                  </ul>
                  <div className={styles.cardActions}>
                    <Link to={`/review/${casino.slug}`} className={styles.linkBtn}>
                      Перейти к обзору
                    </Link>
                    <Link to="/compare" className={styles.outlineBtn}>
                      В таблицу сравнения
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        ref={compareRef}
        className={`${styles.section} ${styles.comparison} ${compareVisible ? styles.visible : ''}`}
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Сравнивайте условия по депозитам, бонусам и играм</h2>
            <p className="sectionSubtitle">
              Наша таблица анализа позволяет быстро оценить ключевые параметры: от минимальных
              депозитов до среднего времени вывода средств.
            </p>
          </div>
          <div className={styles.tableWrapper}>
            <table className={styles.previewTable}>
              <thead>
                <tr>
                  <th scope="col">Казино</th>
                  <th scope="col">Мин. депозит</th>
                  <th scope="col">Бонус</th>
                  <th scope="col">Срок вывода</th>
                  <th scope="col">Основные игры</th>
                </tr>
              </thead>
              <tbody>
                {topCasinos.map((casino) => (
                  <tr key={casino.id}>
                    <td>{casino.name}</td>
                    <td>{casino.minDeposit}</td>
                    <td>{casino.bonus}</td>
                    <td>{casino.withdrawalTime}</td>
                    <td>{casino.games.slice(0, 3).join(', ')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Link to="/compare" className={styles.primaryBtn}>
            Открыть всю таблицу
          </Link>
        </div>
      </section>

      <section
        ref={rateRef}
        className={`${styles.section} ${styles.howWeRate} ${rateVisible ? styles.visible : ''}`}
      >
        <div className="container">
          <h2 className="sectionTitle">Как мы оцениваем онлайн-казино</h2>
          <p className="sectionSubtitle">
            Критерии оценки: безопасность, скорость выплат, ассортимент игр и поддержка пользователей.
            Дополнительно учитываем инклюзивность интерфейса и политику ответственной игры.
          </p>
          <div className={styles.stepsGrid}>
            <div className={styles.stepCard}>
              <span className={styles.stepNumber}>01</span>
              <h3>Безопасность и лицензия</h3>
              <p>
                Проверяем регулятора, условия сертификации и прозрачность пользовательского
                соглашения. Анализируем историю санкций и PRNG отчёты.
              </p>
            </div>
            <div className={styles.stepCard}>
              <span className={styles.stepNumber}>02</span>
              <h3>Финансовые операции</h3>
              <p>
                Оцениваем лимиты, комиссии, скорость вывода и наличие альтернативных методов оплаты.
                Тестируем процесс верификации.
              </p>
            </div>
            <div className={styles.stepCard}>
              <span className={styles.stepNumber}>03</span>
              <h3>Игровое портфолио</h3>
              <p>
                Изучаем провайдеров, наличие живых дилеров, мобильную оптимизацию и честность
                указанных RTP.
              </p>
            </div>
            <div className={styles.stepCard}>
              <span className={styles.stepNumber}>04</span>
              <h3>Служба поддержки</h3>
              <p>
                Проверяем доступность, скорость реакции и компетентность операторов. Обращаем
                внимание на наличие локальных языков.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section
        ref={offersRef}
        className={`${styles.section} ${styles.popular} ${offersVisible ? styles.visible : ''}`}
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Самые популярные офферы этого месяца</h2>
            <p className="sectionSubtitle">
              Подборка основана на активности пользователей и обновлении бонусных программ. Мы не
              публикуем гарантии выигрыша и призываем относиться к азарту ответственно.
            </p>
          </div>
          <div className={styles.offerGrid}>
            {popularOffers.map((casino) => (
              <article key={casino.id} className={styles.offerCard}>
                <header>
                  <div>
                    <h3>{casino.name}</h3>
                    <span className={styles.offerBadge}>{casino.bonusType}</span>
                  </div>
                  <span className={styles.offerRating}>
                    <i className="fas fa-star" aria-hidden="true" /> {casino.rating.toFixed(1)}
                  </span>
                </header>
                <p>{casino.description}</p>
                <div className={styles.offerDetails}>
                  <span><i className="fas fa-gift" aria-hidden="true" /> {casino.bonus}</span>
                  <span><i className="fas fa-wallet" aria-hidden="true" /> Мин. депозит: {casino.minDeposit}</span>
                </div>
                <Link to={`/review/${casino.slug}`} className={styles.linkBtn}>
                  Узнать условия
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        ref={testimonialsRef}
        className={`${styles.section} ${styles.testimonials} ${testimonialsVisible ? styles.visible : ''}`}
      >
        <div className="container">
          <h2 className="sectionTitle">Отзывы реальных пользователей</h2>
          <p className="sectionSubtitle">
            Пользователи делятся своим опытом использования нашей аналитики. Мы модерируем отзывы и
            удаляем рекламные сообщения.
          </p>
          <div className={styles.testimonialGrid}>
            {testimonials.map((item) => (
              <figure key={item.name} className={styles.testimonialCard}>
                <figcaption>
                  <img src={item.avatar} alt={`Пользователь ${item.name}`} loading="lazy" />
                  <div>
                    <strong>{item.name}</strong>
                    <span>{item.country}</span>
                  </div>
                  <span className={styles.testimonialRating}>
                    <i className="fas fa-star" aria-hidden="true" /> {item.rating.toFixed(1)}
                  </span>
                </figcaption>
                <blockquote>“{item.text}”</blockquote>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section
        ref={advantagesRef}
        className={`${styles.section} ${styles.advantages} ${advantagesVisible ? styles.visible : ''}`}
      >
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Преимущества использования платформы</h2>
            <p className="sectionSubtitle">
              Почему выбирают нас: честные обзоры, актуальная информация, бесплатный доступ и акцент
              на безопасный опыт.
            </p>
          </div>
          <div className={styles.advantageGrid}>
            {advantages.map((item) => (
              <article key={item.title} className={styles.advantageCard}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
          <div className={styles.ctaBox}>
            <div>
              <h3>Присоединяйтесь к сообществу ответственных игроков</h3>
              <p>
                Подпишитесь на ежемесячную рассылку с аналитикой и обновлениями. Никаких призывов к
                игре — только проверенные факты и советы по самоконтролю.
              </p>
            </div>
            <Link to="/contacts" className={styles.primaryBtn}>
              Связаться с командой
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.faq}`}>
        <div className="container">
          <h2 className="sectionTitle">Часто задаваемые вопросы</h2>
          <div className={styles.faqList}>
            {faqs.map((item) => (
              <details key={item.question}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;