import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Политика конфиденциальности | GamblingReview</title>
      <meta
        name="description"
        content="Политика конфиденциальности GamblingReview описывает, как мы обрабатываем персональные данные и защищаем вашу приватность."
      />
    </Helmet>

    <div className="container">
      <h1>Политика конфиденциальности</h1>
      <p className={styles.updated}>Последнее обновление: 12 марта 2024 года</p>

      <section>
        <h2>1. Сбор данных</h2>
        <p>
          Мы можем собирать минимальный набор данных, который вы предоставляете добровольно через форму
          обратной связи: имя, email и текст сообщения. Эта информация используется исключительно для
          ответа на ваш запрос.
        </p>
      </section>

      <section>
        <h2>2. Cookie</h2>
        <p>
          Сайт применяет cookie-файлы для анализа трафика и улучшения навигации. Вы можете принять или
          отклонить cookie через всплывающее окно. Подробности описаны в <a href="/cookie">политике cookie</a>.
        </p>
      </section>

      <section>
        <h2>3. Хранение и защита</h2>
        <p>
          Мы используем защищенные каналы связи (HTTPS). Доступ к данным ограничен сотрудниками,
          которым он необходим для обработки запросов. Данные не передаются третьим лицам без
          дополнительного согласия.
        </p>
      </section>

      <section>
        <h2>4. Ваши права</h2>
        <ul>
          <li>Запросить копию предоставленных данных.</li>
          <li>Исправить или удалить данные, отправив запрос на <a href="mailto:info@gamblingreview.com">info@gamblingreview.com</a>.</li>
          <li>Отозвать согласие на обработку персональных данных.</li>
        </ul>
      </section>
    </div>
  </div>
);

export default Privacy;