import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contacts.module.css';

const initialFormState = {
  name: '',
  email: '',
  message: ''
};

const Contacts = () => {
  const [form, setForm] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) {
      newErrors.name = 'Укажите ваше имя';
    }
    if (!form.email.trim()) {
      newErrors.email = 'Укажите email';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/u.test(form.email.trim())) {
      newErrors.email = 'Введите корректный email';
    }
    if (!form.message.trim()) {
      newErrors.message = 'Опишите ваш вопрос';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const onSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      return;
    }
    setStatus('success');
    setForm(initialFormState);
  };

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Контакты GamblingReview</title>
        <meta
          name="description"
          content="Свяжитесь с командой GamblingReview: вопросы по обзорам казино, актуализация данных и сотрудничество."
        />
        <meta
          name="keywords"
          content="контакты GamblingReview, обратная связь казино, сотрудничество обзоры казино"
        />
      </Helmet>

      <div className="container">
        <header className={styles.header}>
          <h1>Свяжитесь с нами</h1>
          <p>
            Мы открыты для вопросов об обзорах, предложений по сотрудничеству и обратной связи.
            Пожалуйста, не отправляйте данные аккаунтов или конфиденциальную информацию.
          </p>
        </header>

        <div className={styles.grid}>
          <section className={styles.contacts}>
            <h2>Контактные данные</h2>
            <ul>
              <li>
                <i className="fas fa-map-marker-alt" aria-hidden="true" />
                123 Gambling St, Las Vegas, NV 89101, USA
              </li>
              <li>
                <i className="fas fa-phone" aria-hidden="true" />
                <a href="tel:+17025550123">+1 (702) 555-0123</a>
              </li>
              <li>
                <i className="fas fa-envelope" aria-hidden="true" />
                <a href="mailto:info@gamblingreview.com">info@gamblingreview.com</a>
              </li>
            </ul>
            <div className={styles.notice}>
              <h3>Работаем по международному графику</h3>
              <p>
                Команда распределена по нескольким часовым поясам. Мы стараемся отвечать в течение
                24 часов. Если ваш вопрос срочный, укажите это в теме письма.
              </p>
            </div>
          </section>

          <form className={styles.form} onSubmit={onSubmit} noValidate>
            <h2>Написать нам</h2>

            <label htmlFor="name">
              Имя
              <input
                id="name"
                name="name"
                type="text"
                value={form.name}
                onChange={(event) => setForm({ ...form, name: event.target.value })}
                aria-invalid={errors.name ? 'true' : 'false'}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </label>

            <label htmlFor="email">
              Email
              <input
                id="email"
                name="email"
                type="email"
                value={form.email}
                onChange={(event) => setForm({ ...form, email: event.target.value })}
                aria-invalid={errors.email ? 'true' : 'false'}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </label>

            <label htmlFor="message">
              Сообщение
              <textarea
                id="message"
                name="message"
                rows="6"
                value={form.message}
                onChange={(event) => setForm({ ...form, message: event.target.value })}
                aria-invalid={errors.message ? 'true' : 'false'}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </label>

            <button type="submit">Отправить</button>

            {status === 'success' && (
              <div className={styles.success}>
                Спасибо! Ваше сообщение отправлено. Мы свяжемся с вами в ближайшее время.
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contacts;