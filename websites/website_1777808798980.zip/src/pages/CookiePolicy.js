import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>Политика использования cookie | GamblingReview</title>
      <meta
        name="description"
        content="Узнайте, какие cookie-файлы использует GamblingReview, зачем они нужны и как управлять настройками."
      />
    </Helmet>

    <div className="container">
      <h1>Политика использования cookie</h1>
      <p className={styles.updated}>Последнее обновление: 12 марта 2024 года</p>

      <section>
        <h2>1. Что такое cookie?</h2>
        <p>
          Cookie — это небольшие текстовые файлы, которые сохраняются в вашем браузере для обеспечения
          корректной работы сайта и анализа трафика.
        </p>
      </section>

      <section>
        <h2>2. Какие cookie мы используем</h2>
        <ul>
          <li><strong>Функциональные</strong> — помогают запоминать ваш выбор (например, согласие с cookie).</li>
          <li><strong>Аналитические</strong> — используются для оценки того, как посетители взаимодействуют с сайтом. Данные обезличены.</li>
        </ul>
      </section>

      <section>
        <h2>3. Как управлять cookie</h2>
        <p>
          Вы можете изменить настройки в браузере или воспользоваться нашим баннером согласия. Отклонение cookie
          не влияет на доступ к основному контенту сайта.
        </p>
      </section>
    </div>
  </div>
);

export default CookiePolicy;