import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { casinos } from '../data';
import styles from './CasinoList.module.css';

const ratingOptions = [
  { label: 'Все рейтинги', value: 'all' },
  { label: '4.5 и выше', value: '4.5' },
  { label: '4.0 и выше', value: '4.0' }
];

const bonusOptions = [
  { label: 'Все бонусы', value: 'all' },
  { label: 'Фриспины', value: 'фриспины' },
  { label: 'Кэшбэк', value: 'кэшбэк' },
  { label: 'Без вейджера', value: 'без вейджера' },
  { label: 'Турниры', value: 'турниры' },
  { label: 'Обучение', value: 'обучение' }
];

const CasinoList = () => {
  const [ratingFilter, setRatingFilter] = useState('all');
  const [bonusFilter, setBonusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCasinos = useMemo(() => {
    return casinos.filter((casino) => {
      const matchRating =
        ratingFilter === 'all' || casino.rating >= parseFloat(ratingFilter);
      const matchBonus = bonusFilter === 'all' || casino.bonusType === bonusFilter;
      const matchSearch =
        searchTerm.trim().length === 0 ||
        casino.name.toLowerCase().includes(searchTerm.trim().toLowerCase());
      return matchRating && matchBonus && matchSearch;
    });
  }, [ratingFilter, bonusFilter, searchTerm]);

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Обзоры казино | GamblingReview</title>
        <meta
          name="description"
          content="Полный каталог онлайн-казино с независимыми обзорами. Фильтруйте по бонусам, рейтингу и условиям выплат."
        />
        <meta
          name="keywords"
          content="список казино, обзоры казино, рейтинг казино, бонусы казино, условия вывода"
        />
      </Helmet>

      <div className="container">
        <header className={styles.header}>
          <h1>Каталог казино</h1>
          <p>
            Ниже представлен полный список офферов с кратким описанием и ключевыми условиями. Мы не
            даем гарантий выигрыша и рекомендуем использовать инструменты самоконтроля.
          </p>
        </header>

        <div className={styles.filters} role="region" aria-label="Фильтры списка казино">
          <div className={styles.filterGroup}>
            <label htmlFor="rating">Рейтинг</label>
            <select
              id="rating"
              value={ratingFilter}
              onChange={(event) => setRatingFilter(event.target.value)}
            >
              {ratingOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div className={styles.filterGroup}>
            <label htmlFor="bonus">Тип бонуса</label>
            <select
              id="bonus"
              value={bonusFilter}
              onChange={(event) => setBonusFilter(event.target.value)}
            >
              {bonusOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div className={styles.filterGroup}>
            <label htmlFor="search">Поиск</label>
            <input
              id="search"
              type="text"
              placeholder="Например, Quantum Spin"
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
            />
          </div>
        </div>

        <div className={styles.grid}>
          {filteredCasinos.map((casino) => (
            <article key={casino.id} className={styles.card}>
              <div className={styles.cardTop}>
                <img src={casino.image} alt={`Казино ${casino.name}`} loading="lazy" />
                <span className={styles.ratingBadge}>
                  <i className="fas fa-star" aria-hidden="true" /> {casino.rating.toFixed(1)}
                </span>
                <span className={styles.bonusType}>{casino.bonusType}</span>
              </div>
              <div className={styles.cardBody}>
                <h2>{casino.name}</h2>
                <p>{casino.description}</p>
                <ul className={styles.meta}>
                  <li><i className="fas fa-gift" aria-hidden="true" /> {casino.bonus}</li>
                  <li><i className="fas fa-wallet" aria-hidden="true" /> Мин. депозит: {casino.minDeposit}</li>
                  <li><i className="fas fa-bolt" aria-hidden="true" /> Вывод: {casino.withdrawalTime}</li>
                  <li><i className="fas fa-certificate" aria-hidden="true" /> Лицензия: {casino.license}</li>
                </ul>
                <div className={styles.games}>
                  {casino.games.map((game) => (
                    <span key={game}>{game}</span>
                  ))}
                </div>
              </div>
              <div className={styles.cardFooter}>
                <Link to={`/review/${casino.slug}`} className={styles.linkBtn}>
                  Читать обзор
                </Link>
                <Link to="/compare" className={styles.outlineBtn}>
                  Сравнить условия
                </Link>
              </div>
            </article>
          ))}
        </div>

        {filteredCasinos.length === 0 && (
          <div className={styles.emptyState}>
            <h3>По вашему запросу ничего не найдено</h3>
            <p>Попробуйте изменить фильтры или сбросить поиск.</p>
            <button type="button" onClick={() => setSearchTerm('')}>
              Сбросить поиск
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CasinoList;