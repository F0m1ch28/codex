import React from 'react';
import { Helmet } from 'react-helmet';
import { casinos } from '../data';
import styles from './Compare.module.css';

const Compare = () => {
  const selectedCasinos = React.useMemo(
    () => [...casinos].sort((a, b) => b.rating - a.rating).slice(0, 5),
    []
  );

  return (
    <div className={styles.wrapper}>
      <Helmet>
        <title>Сравнение условий казино | GamblingReview</title>
        <meta
          name="description"
          content="Сравнительная таблица условий казино: депозиты, бонусы, сроки вывода и список игр. Выбирайте платформу осознанно."
        />
        <meta
          name="keywords"
          content="сравнение казино, депозит казино, бонусы казино, вывод средств казино, игры казино"
        />
      </Helmet>

      <div className="container">
        <header className={styles.header}>
          <h1>Сравнение условий казино</h1>
          <p>
            Используйте таблицу, чтобы быстро сопоставить ключевые параметры. Данные актуализируются
            каждую неделю. Мы не публикуем агрессивных призывов играть — решение всегда за вами.
          </p>
        </header>

        <div className={styles.tableWrapper}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th scope="col">Казино</th>
                <th scope="col">Рейтинг</th>
                <th scope="col">Мин. депозит</th>
                <th scope="col">Приветственный бонус</th>
                <th scope="col">Вейджер</th>
                <th scope="col">Срок вывода</th>
                <th scope="col">Лицензия</th>
                <th scope="col">Игры</th>
              </tr>
            </thead>
            <tbody>
              {selectedCasinos.map((casino) => (
                <tr key={casino.id}>
                  <td>
                    <div className={styles.casinoCell}>
                      <img src={casino.image} alt={casino.name} loading="lazy" />
                      <div>
                        <strong>{casino.name}</strong>
                        <span>{casino.bonusType}</span>
                      </div>
                    </div>
                  </td>
                  <td>{casino.rating.toFixed(1)}</td>
                  <td>{casino.minDeposit}</td>
                  <td>{casino.bonus}</td>
                  <td>{casino.details.wagering}</td>
                  <td>{casino.withdrawalTime}</td>
                  <td>{casino.license}</td>
                  <td>{casino.games.slice(0, 4).join(', ')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <section className={styles.notes}>
          <h2>Как читать таблицу</h2>
          <ul>
            <li>
              <strong>Рейтинг</strong> основывается на проверке лицензии, скорости выплат и обратной
              связи от пользователей.
            </li>
            <li>
              <strong>Вейджер</strong> показывает, сколько раз нужно проставить сумму бонуса, чтобы
              вывести выигрыш. Мы выделяем предложения с прозрачными требованиями.
            </li>
            <li>
              <strong>Ответственная игра</strong> — ключевой критерий. Обращайте внимание на наличие
              лимитов, самоисключения и образовательных материалов.
            </li>
          </ul>
        </section>
      </div>
    </div>
  );
};

export default Compare;