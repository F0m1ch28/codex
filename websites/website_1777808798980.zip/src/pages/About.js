import React from 'react';
import { Helmet } from 'react-helmet';
import { advantages, milestones, teamMembers } from '../data';
import styles from './About.module.css';

const About = () => (
  <div className={styles.wrapper}>
    <Helmet>
      <title>О проекте GamblingReview</title>
      <meta
        name="description"
        content="Узнайте, как работает команда GamblingReview: методология оценки казино, история проекта и эксперты, стоящие за аналитикой."
      />
      <meta
        name="keywords"
        content="GamblingReview, о нас, команда аналитиков казино, методология обзора казино"
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <span className="badge">О проекте</span>
        <h1>Независимая аналитика казино с 2018 года</h1>
        <p>
          GamblingReview появился, когда мы заметили, что игрокам не хватает прозрачных обзоров без
          маркетинговых обещаний. Мы объединили специалистов по лицензированию, комплаенсу и data
          science, чтобы создавать рейтинги, которым можно доверять.
        </p>
      </div>
    </section>

    <section className={styles.values}>
      <div className="container">
        <div className={styles.valuesGrid}>
          {advantages.map((item) => (
            <article key={item.title}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <div className="container">
        <h2 className="sectionTitle">Команда GamblingReview</h2>
        <p className="sectionSubtitle">
          Мы работаем полностью удаленно и объединяем экспертизу из разных стран. Команда регулярно
          посещает профильные конференции iGaming, чтобы быть в курсе трендов регулирования.
        </p>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={member.name} loading="lazy" />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span className={styles.role}>{member.role}</span>
                <span className={styles.experience}>{member.experience}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.milestones}>
      <div className="container">
        <h2 className="sectionTitle">Ключевые этапы развития</h2>
        <div className={styles.timeline}>
          {milestones.map((item) => (
            <div key={item.year} className={styles.timelineItem}>
              <span className={styles.year}>{item.year}</span>
              <div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.mission}>
      <div className="container">
        <div className={styles.missionContent}>
          <h2>Наша миссия</h2>
          <p>
            Развивать культуру ответственного гэмблинга, где пользователь принимает осознанные
            решения. Мы не пропускаем через редакцию промо-материалы без фактической проверки и
            открыто сообщаем о рисках. Самое главное — дать читателю инструменты для самостоятельной
            оценки платформы.
          </p>
          <p>
            Если у вас есть вопросы по обзорам или вы хотите поделиться опытом использования казино,
            напишите нам. Мы всегда открыты к обратной связи и исправляем материалы, если условия
            оператора меняются.
          </p>
          <a href="mailto:info@gamblingreview.com" className={styles.contactLink}>
            Написать редакции
          </a>
        </div>
        <div className={styles.missionImage}>
          <img
            src="https://picsum.photos/800/600?random=45"
            alt="Команда GamblingReview за аналитической работой"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  </div>
);

export default About;