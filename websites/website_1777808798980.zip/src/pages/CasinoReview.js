import React from 'react';
import { Helmet } from 'react-helmet';
import { Link, useParams } from 'react-router-dom';
import { casinos } from '../data';
import styles from './CasinoReview.module.css';

const CasinoReview = () => {
  const { id } = useParams();
  const casino = casinos.find((item) => item.slug === id);

  if (!casino) {
    return (
      <div className={styles.notFound}>
        <div className="container">
          <h1>Обзор не найден</h1>
          <p>Возможно, казино было удалено или перемещено. Попробуйте вернуться к списку.</p>
          <Link to="/casino" className={styles.backBtn}>
            Вернуться к каталогу
          </Link>
        </div>
      </div>
    );
  }

  return (
    <article className={styles.review}>
      <Helmet>
        <title>{casino.name} — подробный обзор | GamblingReview</title>
        <meta
          name="description"
          content={`Подробный обзор ${casino.name}: бонусы ${casino.bonus}, лицензия ${casino.license}, скорость выплат ${casino.withdrawalTime}.`}
        />
        <meta
          name="keywords"
          content={`обзор ${casino.name}, лицензия ${casino.license}, бонусы ${casino.name}, ${casino.games.join(', ')}`}
        />
      </Helmet>

      <div className="container">
        <header className={styles.header}>
          <div className={styles.headerInfo}>
            <span className="badge">Исследуем условия</span>
            <h1>{casino.name}</h1>
            <p>{casino.details.summary}</p>
            <div className={styles.meta}>
              <span>
                <i className="fas fa-star" aria-hidden="true" /> Рейтинг: {casino.rating.toFixed(1)}
              </span>
              <span>
                <i className="fas fa-certificate" aria-hidden="true" /> Лицензия: {casino.license}
              </span>
              <span>
                <i className="fas fa-clock" aria-hidden="true" /> Вывод: {casino.withdrawalTime}
              </span>
            </div>
            <div className={styles.actions}>
              <Link to="/compare" className={styles.primaryBtn}>
                Сравнить с другими
              </Link>
              <Link to="/casino" className={styles.secondaryBtn}>
                Вернуться к списку
              </Link>
            </div>
          </div>
          <div className={styles.heroImage}>
            <img src={casino.image} alt={`Интерфейс казино ${casino.name}`} loading="lazy" />
            <div className={styles.bonusBox}>
              <h3>Приветственный бонус</h3>
              <p>{casino.bonus}</p>
              <span>Вейджер: {casino.details.wagering}</span>
            </div>
          </div>
        </header>

        <section className={styles.grid}>
          <div className={styles.block}>
            <h2>Преимущества</h2>
            <ul>
              {casino.details.pros.map((item) => (
                <li key={item}>
                  <i className="fas fa-check" aria-hidden="true" /> {item}
                </li>
              ))}
            </ul>
          </div>

          <div className={styles.block}>
            <h2>Особенности бонусов</h2>
            <p>{casino.details.bonusTerms}</p>
          </div>

          <div className={styles.block}>
            <h2>Ограничения</h2>
            <ul>
              {casino.details.cons.map((item) => (
                <li key={item}>
                  <i className="fas fa-exclamation-triangle" aria-hidden="true" /> {item}
                </li>
              ))}
            </ul>
          </div>

          <div className={styles.block}>
            <h2>Игровое портфолио</h2>
            <div className={styles.tagList}>
              {casino.games.map((game) => (
                <span key={game}>{game}</span>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.details}>
          <div>
            <h2>Платежные методы</h2>
            <ul className={styles.inlineList}>
              {casino.details.paymentMethods.map((method) => (
                <li key={method}>{method}</li>
              ))}
            </ul>
          </div>
          <div>
            <h2>Служба поддержки</h2>
            <p>{casino.details.support}</p>
          </div>
          <div>
            <h2>Ответственная игра</h2>
            <ul className={styles.inlineList}>
              {casino.details.responsibleGaming.map((tool) => (
                <li key={tool}>{tool}</li>
              ))}
            </ul>
          </div>
        </section>

        <section className={styles.notice}>
          <h2>Важно</h2>
          <p>
            GamblingReview не гарантирует выигрыш и не побуждает к игре. Наш обзор предназначен для
            того, чтобы вы оценили риски, изучили условия оператора и при необходимости воспользовались
            инструментами самоконтроля. Если вы ощущаете потерю контроля, обратитесь к профессиональным
            консультантам в вашей стране.
          </p>
        </section>
      </div>
    </article>
  );
};

export default CasinoReview;