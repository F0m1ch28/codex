document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelector(".nav-links");
  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    navLinks.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (navLinks.classList.contains("is-open")) {
          navLinks.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }
  const navAnchors = document.querySelectorAll(".nav-links a");
  const currentPath = window.location.pathname.split("/").pop() || "index.html";
  navAnchors.forEach((anchor) => {
    const href = anchor.getAttribute("href");
    if (href === currentPath) {
      anchor.classList.add("is-active");
    }
  });
  const cookieBanner = document.getElementById("cookieBanner");
  const cookieStorageKey = "registrationPortalCookieConsent";
  if (cookieBanner) {
    const storedConsent = localStorage.getItem(cookieStorageKey);
    if (storedConsent === "accepted" || storedConsent === "declined") {
      cookieBanner.classList.add("is-hidden");
      document.body.classList.add(`cookies-${storedConsent}`);
    }
    cookieBanner.addEventListener("click", (event) => {
      const action = event.target.dataset.cookieAction;
      if (!action) {
        return;
      }
      if (action === "accept") {
        localStorage.setItem(cookieStorageKey, "accepted");
        document.body.classList.add("cookies-accepted");
      }
      if (action === "decline") {
        localStorage.setItem(cookieStorageKey, "declined");
        document.body.classList.add("cookies-declined");
      }
      cookieBanner.classList.add("is-hidden");
    });
  }
  const registerForm = document.getElementById("registerForm");
  if (registerForm) {
    const status = document.getElementById("registerStatus");
    registerForm.addEventListener("submit", (event) => {
      event.preventDefault();
      status.classList.remove("visible", "error", "success");
      const formData = new FormData(registerForm);
      const password = formData.get("password") || "";
      const confirmPassword = formData.get("confirmPassword") || "";
      if (!registerForm.checkValidity()) {
        status.textContent = "Please complete all required fields correctly.";
        status.classList.add("visible", "error");
        registerForm.reportValidity();
        return;
      }
      if (password !== confirmPassword) {
        status.textContent = "Passwords do not match.";
        status.classList.add("visible", "error");
        return;
      }
      if (password.length < 8) {
        status.textContent = "Password must be at least 8 characters long.";
        status.classList.add("visible", "error");
        return;
      }
      status.textContent = "Registration successful! Redirecting to your dashboard...";
      status.classList.add("visible", "success");
      setTimeout(() => {
        window.location.href = "dashboard.html";
      }, 1400);
    });
  }
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    const status = document.getElementById("loginStatus");
    loginForm.addEventListener("submit", (event) => {
      event.preventDefault();
      status.classList.remove("visible", "error", "success");
      if (!loginForm.checkValidity()) {
        status.textContent = "Enter your email and password to continue.";
        status.classList.add("visible", "error");
        loginForm.reportValidity();
        return;
      }
      status.textContent = "Welcome back! Redirecting to your dashboard...";
      status.classList.add("visible", "success");
      setTimeout(() => {
        window.location.href = "dashboard.html";
      }, 1000);
    });
  }
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    const status = document.getElementById("contactStatus");
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      status.classList.remove("visible", "error", "success");
      if (!contactForm.checkValidity()) {
        status.textContent = "Please fill out required contact details.";
        status.classList.add("visible", "error");
        contactForm.reportValidity();
        return;
      }
      status.textContent = "Thank you! Our support team will respond shortly.";
      status.classList.add("visible", "success");
      contactForm.reset();
    });
  }
  document.querySelectorAll("[data-progress]").forEach((progressEl) => {
    const value = parseInt(progressEl.dataset.progress, 10);
    const bounded = Math.min(Math.max(isNaN(value) ? 0 : value, 0), 100);
    requestAnimationFrame(() => {
      progressEl.style.width = `${bounded}%`;
    });
  });
});