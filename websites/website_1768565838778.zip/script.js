const navToggle = document.querySelector('[data-nav-toggle]');
const navMenu = document.querySelector('[data-nav-menu]');
const body = document.body;

if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
        const expanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', String(!expanded));
        navMenu.classList.toggle('is-open');
        body.classList.toggle('menu-open');
    });

    navMenu.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            navToggle.setAttribute('aria-expanded', 'false');
            navMenu.classList.remove('is-open');
            body.classList.remove('menu-open');
        });
    });
}

const COOKIE_KEY = 'politiyfdb_cookie_consent';
const cookieBanner = document.querySelector('[data-cookie-banner]');
const acceptBtn = cookieBanner ? cookieBanner.querySelector('[data-cookie-accept]') : null;
const declineBtn = cookieBanner ? cookieBanner.querySelector('[data-cookie-decline]') : null;

function hideBanner() {
    if (cookieBanner) {
        cookieBanner.classList.remove('is-visible');
    }
}

function showBanner() {
    if (cookieBanner) {
        cookieBanner.classList.add('is-visible');
    }
}

if (cookieBanner) {
    const storedConsent = localStorage.getItem(COOKIE_KEY);
    if (!storedConsent) {
        showBanner();
    }

    if (acceptBtn) {
        acceptBtn.addEventListener('click', () => {
            localStorage.setItem(COOKIE_KEY, 'accepted');
            hideBanner();
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener('click', () => {
            localStorage.setItem(COOKIE_KEY, 'declined');
            hideBanner();
        });
    }
}