document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  const body = document.body;

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = navToggle.classList.toggle("open");
      siteNav.classList.toggle("open", isOpen);
      body.classList.toggle("nav-open", isOpen);
    });

    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.classList.remove("open");
        siteNav.classList.remove("open");
        body.classList.remove("nav-open");
      });
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  const acceptButton = document.getElementById("cookie-accept");
  const declineButton = document.getElementById("cookie-decline");
  const consentKey = "glacier_cookie_consent";

  if (cookieBanner && acceptButton && declineButton) {
    const userConsent = localStorage.getItem(consentKey);

    if (!userConsent) {
      setTimeout(() => {
        cookieBanner.classList.add("visible");
      }, 800);
    }

    acceptButton.addEventListener("click", () => {
      localStorage.setItem(consentKey, "accepted");
      cookieBanner.classList.remove("visible");
    });

    declineButton.addEventListener("click", () => {
      localStorage.setItem(consentKey, "declined");
      cookieBanner.classList.remove("visible");
    });
  }
});