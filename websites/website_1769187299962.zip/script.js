const DEFAULT_LANG = 'fr';
const LANGUAGE_STORAGE_KEY = 'site_lang';
const COOKIE_STORAGE_KEY = 'cookie_consent';

const I18N = {
  fr: {
    brand: {
      name: 'danswholesaleplants'
    },
    language: {
      fr: 'FR',
      en: 'EN'
    },
    aria: {
      navToggle: 'Basculer la navigation principale',
      languageSwitcher: 'Changer de langue',
      toastDismiss: 'Fermer la notification',
      cookieBanner: 'Paramètres cookies'
    },
    nav: {
      home: 'Accueil',
      services: 'Expertises',
      about: 'À propos',
      blog: 'Analyses',
      faq: 'Questions clés',
      contact: 'Contact'
    },
    title: {
      home: 'danswholesaleplants — Orientation spatiale et signalétique numérique',
      services: 'Expertises — danswholesaleplants',
      about: 'À propos — danswholesaleplants',
      blog: 'Blog d’analyses — danswholesaleplants',
      contact: 'Contact — danswholesaleplants',
      faq: 'FAQ — danswholesaleplants',
      terms: 'Conditions d’utilisation — danswholesaleplants',
      privacy: 'Politique de confidentialité — danswholesaleplants',
      cookies: 'Politique de cookies — danswholesaleplants',
      refund: 'Politique de révision — danswholesaleplants',
      disclaimer: 'Clause de non-responsabilité — danswholesaleplants',
      thankyou: 'Merci — danswholesaleplants',
      post1: 'Cartographies logistiques des hôpitaux universitaires',
      post2: 'Signalétique numérique dans les hubs intermodaux',
      post3: 'Expérience piétonne des centres de services municipaux',
      post4: 'Guidages tactiles et visuels combinés',
      post5: 'Pipelines spatiaux temps réel pour le guidage'
    },
    meta: {
      home: 'Plateforme belge dédiée à l’orientation spatiale, à la signalétique numérique et à la lisibilité des environnements complexes. Études, méthodologies et analyses pour les bâtiments publics et les espaces urbains.',
      services: 'Panorama des domaines d’expertise de danswholesaleplants : analyse d’orientation, cartographie interactive, modélisation des flux piétons et recherche en accessibilité.',
      about: 'Découvrir l’approche méthodologique de danswholesaleplants : design informationnel, recherche UX spatiale, partenariats publics et veille internationale.',
      blog: 'Analyses approfondies sur la navigation intérieure, la cartographie des espaces, les plans interactifs et les parcours utilisateurs dans les environnements bâtis.',
      contact: 'Coordonnées de danswholesaleplants à Bruxelles, formulaire sécurisé et carte interactive pour discuter d’orientation spatiale et de signalétique numérique.',
      faq: 'Réponses aux questions fréquentes sur la démarche méthodologique, la collecte de données, la modélisation des flux et la diffusion des livrables.',
      terms: 'Conditions d’utilisation encadrant la consultation de danswholesaleplants, la propriété intellectuelle et la responsabilité sur les contenus proposés.',
      privacy: 'Politique de confidentialité détaillant les pratiques de collecte, d’utilisation et de conservation des données personnelles sur danswholesaleplants.',
      cookies: 'Politique de cookies expliquant les catégories d’outils utilisés, les objectifs de mesure qualitative et les options de consentement.',
      refund: 'Politique de révision décrivant la gestion des corrections, des ajustements et du suivi post-projet chez danswholesaleplants.',
      disclaimer: 'Clause de non-responsabilité précisant l’absence de garantie, les limites d’usage et la nature informative des publications.',
      thankyou: 'Confirmation de réception de votre message par danswholesaleplants et indications sur la suite du traitement.',
      post1: 'Analyse de la cartographie logistique des hôpitaux universitaires et optimisation des parcours pour les usagers et équipes.',
      post2: 'Étude des dispositifs de signalétique numérique dans les hubs intermodaux pour fluidifier la navigation des voyageurs.',
      post3: 'Exploration de l’expérience piétonne dans les centres de services municipaux à forte densité d’interactions.',
      post4: 'Intégration concertée des guidages tactiles et visuels dans les structures publiques pluriels.',
      post5: 'Organisation de pipelines spatiaux temps réel pour un guidage adaptatif des espaces partagés.'
    },
    footer: {
      tagline: 'Observatoire des parcours utilisateurs, des infrastructures publiques et des flux d’orientation en environnements complexes.',
      contactTitle: 'Coordonnées',
      legalTitle: 'Références juridiques',
      phone: 'Téléphone : +32 2 586 11 90',
      email: 'Courriel : info@danswholesaleplants.com',
      address: 'Avenue Louise 251, 1050 Bruxelles, Belgique',
      terms: 'Conditions d’utilisation',
      privacy: 'Confidentialité',
      cookies: 'Cookies',
      refund: 'Politique de révision',
      disclaimer: 'Clause de non-responsabilité',
      rights: '© {year} danswholesaleplants. Ressources analytiques sur la navigation spatiale et la lisibilité des infrastructures.'
    },
    cookieBanner: {
      title: 'Gestion des cookies',
      description: 'Nous utilisons des cookies pour assurer le fonctionnement du site, affiner les préférences d’affichage et évaluer l’ergonomie des contenus. Vous pouvez modifier vos choix à tout moment.',
      link: 'Voir la politique de cookies',
      buttons: {
        accept: 'Tout accepter',
        decline: 'Tout refuser',
        save: 'Enregistrer les préférences'
      },
      categories: {
        necessary: {
          title: 'Cookies essentiels',
          description: 'Indispensables au fonctionnement sécurisé du site. Désactivation impossible.'
        },
        preferences: {
          title: 'Préférences',
          description: 'Mémorisation des langues et options d’interface pour améliorer le confort de navigation.'
        },
        analytics: {
          title: 'Analyses',
          description: 'Mesure qualitative anonymisée pour comprendre le parcours et ajuster les contenus.'
        },
        marketing: {
          title: 'Visibilité',
          description: 'Indicateurs non personnels sur la diffusion de nos publications sur les espaces institutionnels.'
        }
      }
    },
    form: {
      validation: 'Merci de renseigner les champs requis avant envoi.',
      success: 'Votre message est pris en compte. Redirection en cours…',
      error: 'Une anomalie est survenue. Veuillez réessayer dans un instant.',
      toastDismiss: 'Fermer'
    },
    home: {
      hero: {
        badge: 'Orientation spatiale',
        title: 'Cartographier, éclairer et guider les parcours dans les environnements publics complexes',
        lead: 'Nous élaborons des cadres analytiques pour rendre lisibles les bâtiments pluriels, connecter la signalétique numérique aux usages réels et orchestrer des parcours fluides pour chaque type de public.',
        points: {
          first: 'Cartographie en profondeur des réseaux piétons et des points de friction.',
          second: 'Interfaçage entre signalétique numérique, tactile et analogique.',
          third: 'Pilotage data-driven des parcours utilisateurs et des plans interactifs.'
        },
        primaryAction: 'Découvrir les expertises',
        secondaryAction: 'Comprendre notre approche',
        imageAlt: 'Vue aérienne d’un atrium public avec circulation et signalétique'
      },
      featured: {
        kicker: 'Diagnostics avancés',
        title: 'Des grilles de lecture pour anticiper chaque transition spatiale',
        subtitle: 'Nos outils relient l’architecture à la cognition des visiteurs afin d’ajuster en continu la signalétique, les interfaces et les flux piétons.',
        cards: {
          one: {
            title: 'Analyse morphologique des bâtiments',
            body: 'Nous observons les volumes, la densité des intersections et la hiérarchie des axes pour cerner les zones où un guidage renforcé est nécessaire.',
            pointA: 'Cartes de chaleur des ralentissements piétons.',
            pointB: 'Couplage avec les données d’occupation temporelle.',
            pointC: 'Scénarios de réaffectation des séquences de circulation.'
          },
          two: {
            title: 'Signalétique numérique contextualisée',
            body: 'Chaque écran, totem ou interface mobile est évalué selon la logique d’usage réelle et le niveau d’attention disponible.',
            pointA: 'Scripts de contenu modulaires par période.',
            pointB: 'Matrices d’accessibilité multilingues.',
            pointC: 'Systèmes d’alertes pour flux exceptionnels.'
          },
          three: {
            title: 'Modélisation des parcours utilisateurs',
            body: 'En combinant observations, enquêtes et simulations, nous construisons des trajectoires types et des chemins alternatifs robustes.',
            pointA: 'Profils piétons par mission et temporalité.',
            pointB: 'Itinéraires prioritaires et redondances.',
            pointC: 'Critères de lisibilité et repérage sensoriel.'
          }
        }
      },
      insights: {
        title: 'Un référentiel pluridisciplinaire au service des espaces publics',
        body: 'Notre travail hybride la data de terrain, la sémiotique, l’ergonomie et la scénographie urbaine. Il en résulte des référentiels qui outillent les responsables d’infrastructure pour décider rapidement.',
        list: {
          one: 'Benchmarks sur plus de 120 sites européens et nord-américains.',
          two: 'Matrices de visibilité intégrant l’éclairage, la distance et l’angle d’approche.',
          three: 'Capteurs qualitatifs : observations in situ, entretiens, micro-sondages.'
        },
        panel: {
          title: 'Attention portée aux zones de friction',
          body: 'Hall d’accueil, sas de sécurité, croisements multimodaux : nous cartographions les micro-décisions qui orientent la suite du parcours et identifions les leviers de simplification.',
          imageAlt: 'Couloir signalétique avec fléchage lumineux'
        }
      },
      timeline: {
        kicker: 'Méthodologie',
        title: 'Une séquence collaborative en quatre respirations',
        lead: 'Chaque mission déploie un cycle qui associe immersion terrain, datavisualisation et accompagnement des équipes gestionnaires.',
        steps: {
          step1: {
            title: 'Immersion & collecte',
            body: 'Observation structurée, captation photo et relevés des supports existants pour stabiliser une base factuelle.'
          },
          step2: {
            title: 'Cartographie & modélisation',
            body: 'Production de plans dynamiques, scénarios d’usage et matrices de correspondance entre flux et services.'
          },
          step3: {
            title: 'Co-design & arbitrages',
            body: 'Ateliers avec les parties prenantes pour hiérarchiser la signalétique et répartir les interventions.'
          },
          step4: {
            title: 'Prototype & suivi',
            body: 'Pilotes sur site, indicateurs de lisibilité et plan d’amélioration continue des supports.'
          }
        },
        caption: 'La boucle de suivi s’adapte aux calendriers institutionnels et intègre des points de contrôle d’accessibilité.'
      },
      recommendations: {
        kicker: 'Recommandations',
        title: 'Lignes directrices pour des espaces intelligibles',
        subtitle: 'Extraits de nos guides pratiques appliqués aux campus, gares, hôpitaux et équipements métropolitains.',
        items: {
          one: {
            title: 'Articuler macro et micro signalétique',
            body: 'Associer plans d’ensemble clairs et indications micro-locales pour soutenir chaque transition et réduire le stress cognitif.'
          },
          two: {
            title: 'Synchroniser les canaux physiques et numériques',
            body: 'Aligner l’information délivrée par les écrans, kiosques, applications et supports analogiques afin d’éviter les divergences.'
          },
          three: {
            title: 'Consolider les parcours de repli',
            body: 'Prévoir des itinéraires alternatifs dès la conception pour absorber les aléas de circulation ou les fermetures ponctuelles.'
          },
          four: {
            title: 'Intégrer l’accessibilité sensorielle',
            body: 'Croiser repérages visuels, tactiles et sonores pour garantir une orientation inclusive et fluide.'
          }
        }
      },
      testimonials: {
        kicker: 'Retours de terrain',
        title: 'Ce que disent nos partenaires',
        subtitle: 'Institutions publiques, opérateurs de transport et gestionnaires de sites commentent les effets observés.',
        items: {
          one: {
            quote: 'Le diagnostic de danswholesaleplants nous a permis de clarifier un réseau hospitalier tentaculaire. La lisibilité est redevenue cohérente pour les équipes et les visiteurs.',
            author: 'Clara De Wilde',
            role: 'Coordination innovation, hôpital universitaire bruxellois'
          },
          two: {
            quote: 'L’analyse détaillée des parcours et l’alignement entre écrans et panneaux physiques ont fluidifié les correspondances en gare multimodale.',
            author: 'Joeri Van Parys',
            role: 'Direction mobilité, opérateur de transport régional'
          },
          three: {
            quote: 'Les recommandations sur la superposition des supports tactiles et visuels nous servent aujourd’hui de guide méthodologique pour chaque extension de campus.',
            author: 'Sophie Dumont',
            role: 'Responsable grands projets, université publique'
          }
        }
      },
      knowledge: {
        title: 'Explorer notre bibliothèque d’études spatiales',
        body: 'Chaque article du blog documente une problématique précise : parcours visiteurs, data de flux, scénarios d’urgence, dispositifs tactiles.',
        link: 'Consulter les analyses récentes'
      }
    },
    services: {
      hero: {
        badge: 'Expertises',
        title: 'Des missions calibrées pour décrypter et transformer la navigation intérieure',
        lead: 'Nous combinons données de terrain, design informationnel et planification opérationnelle pour sécuriser les environnements bâtis complexes.',
        highlights: {
          first: 'Approche neutre et documentée sur les orientateurs physiques et numériques.',
          second: 'Livrables structurés en matrices décisionnelles pour les équipes de gestion.',
          third: 'Suivi de terrain et formation aux outils produits.',
          imageAlt: 'Strates de circulation dans un bâtiment institutionnel'
        }
      },
      overview: {
        kicker: 'Domaines d’intervention',
        title: 'Cinq axes complémentaires pour structurer l’orientation spatiale',
        subtitle: 'Chaque module peut être activé indépendamment ou combiné selon les besoins du site.'
      },
      items: {
        one: {
          title: 'Audit d’orientation',
          body: 'Cartographie détaillée des points de bascule, des ruptures de continuité et des alignements entre architecture et signalétique.',
          pointA: 'Inventaires photographiques normés.',
          pointB: 'Diagnostic accessibilité et contrastes.',
          pointC: 'Analyse des flux multi-temporels.'
        },
        two: {
          title: 'Design de signalétique numérique',
          body: 'Définition des scénarios de diffusion, des gabarits graphiques et des règles éditoriales pour chaque support interactif.',
          pointA: 'Scripts de contenu adaptatifs.',
          pointB: 'Protocoles de mise à jour centralisée.',
          pointC: 'Tests utilisateurs rapides sur site.'
        },
        three: {
          title: 'Cartographie interactive',
          body: 'Plans dynamiques, layers thématiques et interfaces de consultation pour visualiser en temps réel l’occupation des espaces.',
          pointA: 'Bases de données spatiales structurées.',
          pointB: 'API pour applications internes.',
          pointC: 'Guidage par segments et états contextuels.'
        },
        four: {
          title: 'Modélisation des flux',
          body: 'Simulation des comportements piétons selon les horaires, la saisonnalité et les événements exceptionnels.',
          pointA: 'Scénarios de densité et évacuation.',
          pointB: 'Indicateurs de confort et temps de parcours.',
          pointC: 'Alignement avec les plans de mobilité douce.'
        },
        five: {
          title: 'Veille accessibilité',
          body: 'Études comparatives et recommandations sur les standards internationaux de lisibilité et d’inclusion.',
          pointA: 'Matrices de conformité multi-normes.',
          pointB: 'Dispositifs multi-sensoriels coordonnés.',
          pointC: 'Suivi législatif transfrontalier.'
        }
      },
      approach: {
        title: 'Une approche systémique',
        body: 'Nous partons des usages réels et des contraintes opérationnelles pour éviter les dispositifs hors-sol et créer un référentiel durable.',
        pointA: 'Écoute des équipes en première ligne.',
        pointB: 'Immersion terrain et parcours guidés.',
        pointC: 'Partage des arbitrages en phases successives.'
      },
      deliverables: {
        title: 'Livrables structurés',
        body: 'Chaque mission se conclut par des plans opérationnels activables par les équipes internes, sans dépendance logicielle lourde.',
        pointA: 'Dossiers de recommandations hiérarchisées.',
        pointB: 'Fichiers sources prêts pour la production.',
        pointC: 'Tableaux de bord pour le suivi longitudinal.'
      },
      closure: {
        title: 'Aller plus loin',
        body: 'Nous documentons chaque étape afin de transmettre des outils reproductibles et évolutifs à vos équipes.',
        link: 'Échanger sur vos besoins d’orientation'
      }
    },
    about: {
      hero: {
        badge: 'À propos',
        title: 'Une équipe dédiée à la lisibilité des environnements complexes',
        lead: 'Nous analysons les lieux publics à la croisée de l’urbanisme, du design d’information et des sciences comportementales afin de proposer des solutions ancrées dans le réel.',
        points: {
          first: 'Réseau de spécialistes en architecture, design et data spatiale.',
          second: 'Immersions longues au cœur des infrastructures étudiées.',
          third: 'Veille internationale pour anticiper les standards émergents.',
          imageAlt: 'Salle de contrôle dédiée au pilotage de signalétique'
        }
      },
      mission: {
        title: 'Notre mission',
        body: 'Créer des environnements où chaque personne peut comprendre l’espace, trouver sa destination et évoluer sans friction, quels que soient ses besoins.',
        pointA: 'Compréhension fine des comportements piétons.',
        pointB: 'Dialogue constant avec les gestionnaires de sites.',
        pointC: 'Neutralité dans les arbitrages recommandés.'
      },
      research: {
        title: 'Recherche continue',
        body: 'Nous publions des synthèses, conduisons des expérimentations et participons à des programmes européens sur la mobilité piétonne.',
        pointA: 'Études comparatives entre typologies d’équipements.',
        pointB: 'Laboratoires vivant dans des sites pilotes.',
        pointC: 'Collaboration avec des universités belges et françaises.'
      },
      framework: {
        kicker: 'Cadre méthodologique',
        title: 'Des repères structurants pour chaque intervention',
        subtitle: 'Nous suivons un processus documenté qui garantit la qualité et la cohérence des recommandations.',
        step1: {
          title: 'Observation situative',
          body: 'Repérage des séquences de parcours, cartographie des supports existants et relevé des données disponibles.'
        },
        step2: {
          title: 'Analyse et synthèse',
          body: 'Construction de grilles de lecture, modélisation des flux et identification des parcours critiques.'
        },
        step3: {
          title: 'Co-construction',
          body: 'Ateliers avec les parties prenantes pour prioriser les interventions et aligner les contraintes techniques.'
        },
        step4: {
          title: 'Transfert & suivi',
          body: 'Livraison de supports opérationnels, formations ciblées et accompagnement post-projet pour mesurer les effets.'
        }
      },
      partnerships: {
        title: 'Partenariats',
        body: 'Nos collaborations réunissent institutions publiques, bureaux d’architecture, opérateurs de mobilité et associations d’usagers.',
        pointA: 'Groupes de travail interservices pour partager les données.',
        pointB: 'Comités d’usagers intégrant des profils variés.',
        pointC: 'Accords-cadres pour suivre les transformations sur plusieurs années.'
      },
      culture: {
        title: 'Culture projet',
        body: 'Nous favorisons une gouvernance ouverte, la transparence des données et la documentation systématique des décisions.',
        pointA: 'Tableaux de bord partagés en temps réel.',
        pointB: 'Supports de restitution accessibles et bilingues.',
        pointC: 'Capitalisation pour les futures extensions.'
      },
      closure: {
        title: 'Une veille active et collaborative',
        body: 'Nous alimentons un observatoire où chaque projet contribue à améliorer les politiques de signalétique et de mobilité douce.',
        link: 'Voir nos domaines d’expertise'
      }
    },
    blog: {
      hero: {
        badge: 'Analyses',
        title: 'Observer et mesurer la lisibilité des espaces complexes',
        lead: 'Nos publications rassemblent méthodes, retours d’expérience et grilles d’évaluation pour les lieux publics à grande échelle.',
        readMore: 'Lire l’étude complète'
      },
      posts: {
        post1: {
          imageAlt: 'Plan directeur d’un hôpital avec zones de circulation'
        },
        post2: {
          imageAlt: 'Hall intermodal avec signalétique numérique et flux'
        },
        post3: {
          imageAlt: 'Espace municipal avec guichets et parcours piéton'
        },
        post4: {
          imageAlt: 'Couloir avec balisage tactile et visuel'
        },
        post5: {
          imageAlt: 'Centre de supervision temps réel d’un bâtiment public'
        }
      }
    },
    contact: {
      hero: {
        badge: 'Contact',
        title: 'Coordonner vos enjeux de signalétique et de navigation',
        lead: 'Un point focal unique à Bruxelles pour organiser ateliers, visites et revues de projet sur les thématiques d’orientation spatiale.',
        points: {
          first: 'Accompagnement sur mesure pour les sites publics belges et transfrontaliers.',
          second: 'Réunions hybrides et immersions sur site selon vos besoins.',
          third: 'Documentation bilingue de toutes les phases d’étude.',
          imageAlt: 'Réunion de travail autour d’un plan signalétique'
        }
      },
      details: {
        title: 'Coordonnées principales',
        description: 'Vous pouvez nous joindre pour planifier un diagnostic, partager des données de flux ou initier un projet pilote.',
        addressLabel: 'Adresse : Avenue Louise 251, 1050 Bruxelles, Belgique',
        phone: 'Téléphone : +32 2 586 11 90',
        email: 'Courriel : info@danswholesaleplants.com',
        hours: 'Créneaux : lundi – vendredi, 9h00 à 18h00 (CET)',
        note: 'Nous répondons sous deux jours ouvrés avec une feuille de route temporaire.'
      },
      form: {
        title: 'Formulaire de contact',
        intro: 'Décrivez vos enjeux et le contexte du lieu concerné. Nous reviendrons avec des pistes méthodologiques.',
        fields: {
          name: {
            label: 'Nom complet',
            placeholder: 'Votre nom'
          },
          organisation: {
            label: 'Organisation',
            placeholder: 'Collectivité, institution, opérateur…'
          },
          email: {
            label: 'Adresse électronique',
            placeholder: 'nom@organisation.be'
          },
          phone: {
            label: 'Téléphone',
            placeholder: '+32 …'
          },
          message: {
            label: 'Message',
            placeholder: 'Décrire brièvement le site, les enjeux et les échéances.'
          }
        },
        notice: 'En envoyant ce formulaire, vous acceptez que les informations fournies soient utilisées pour répondre à votre demande.',
        submit: 'Envoyer'
      },
      map: {
        title: 'Localisation',
        lead: 'Nos bureaux sont situés entre l’avenue Louise et les jardins du Roi, facilement accessibles par tram et vélo.',
        frameTitle: 'Carte interactive de danswholesaleplants à Bruxelles',
        caption: 'Point d’accueil principal — entrée depuis l’avenue Louise (halte tram Stéphanie).'
      }
    },
    faq: {
      hero: {
        badge: 'FAQ',
        title: 'Questions fréquentes sur notre approche',
        lead: 'Une sélection de réponses construites à partir des demandes récurrentes des porteurs de projets.'
      },
      items: {
        q1: {
          question: 'Quelle est la durée moyenne d’un diagnostic complet ?',
          answer: 'Selon la taille du site, compter entre quatre et huit semaines : immersion initiale, collecte de données, modélisation, ateliers puis restitution.'
        },
        q2: {
          question: 'Travaillez-vous uniquement en Belgique ?',
          answer: 'Le cœur de nos interventions se situe en Belgique mais nous opérons également pour des sites transfrontaliers avec coordination bilingue.'
        },
        q3: {
          question: 'Comment gérez-vous les données sensibles ?',
          answer: 'Les jeux de données transmis sont protégés, chiffrés et restitués sur des espaces sécurisés avec journalisation des accès.'
        },
        q4: {
          question: 'Intégrez-vous les consignes d’accessibilité ?',
          answer: 'Oui, nous comparons les normes européennes et locales et croisons la signalétique visuelle avec les dispositifs tactiles et sonores.'
        },
        q5: {
          question: 'Proposez-vous un accompagnement post-étude ?',
          answer: 'Nous assurons un suivi trimestriel pour mesurer l’efficacité des ajustements et mettre à jour les référentiels produits.'
        },
        q6: {
          question: 'Pouvez-vous collaborer avec notre agence d’architecture ?',
          answer: 'Nous coopérons fréquemment avec des équipes architecturales pour intégrer les résultats au processus de conception ou de rénovation.'
        },
        q7: {
          question: 'Quels livrables remettez-vous ?',
          answer: 'Des dossiers stratégiques, des plans annotés, des scripts de contenu, des fichiers sources prêts à être déployés et un plan de suivi.'
        },
        q8: {
          question: 'Comment se déroule la collecte de données ?',
          answer: 'Nous combinons observations, comptages, micro-entretiens et analyse documentaire pour couvrir l’ensemble des situations d’usage.'
        }
      },
      cta: {
        title: 'Besoin d’une réponse personnalisée ?',
        body: 'Contactez-nous pour élaborer un programme d’étude adapté à votre équipement.',
        link: 'Écrire à l’équipe'
      }
    },
    terms: {
      title: 'Conditions d’utilisation',
      intro: 'Les présentes conditions encadrent l’usage du site danswholesaleplants.com et précisent les obligations réciproques.',
      sections: {
        section01: {
          title: '1. Objet',
          body: 'Les conditions définissent le cadre juridique de l’accès aux contenus, outils et publications proposés par danswholesaleplants.'
        },
        section02: {
          title: '2. Acceptation',
          body: 'La consultation du site implique l’adhésion sans réserve aux conditions en vigueur au moment de l’accès.'
        },
        section03: {
          title: '3. Définitions',
          body: 'Utilisateur désigne toute personne consultant le site. Contenus englobe textes, images, études et ressources téléchargeables.'
        },
        section04: {
          title: '4. Propriété intellectuelle',
          body: 'Les contenus demeurent la propriété de danswholesaleplants ou de ses partenaires. Toute reproduction nécessite autorisation écrite.'
        },
        section05: {
          title: '5. Accès au site',
          body: 'Le site est accessible 24h/24 sous réserve d’interruptions pour maintenance ou raisons techniques indépendantes de notre volonté.'
        },
        section06: {
          title: '6. Usage autorisé',
          body: 'Les contenus sont fournis à des fins d’information et d’analyse. Toute utilisation commerciale ou détournée est interdite.'
        },
        section07: {
          title: '7. Contributions externes',
          body: 'Toute contribution d’un utilisateur doit respecter l’intégrité des personnes et des données. Nous nous réservons un droit de modération.'
        },
        section08: {
          title: '8. Liens sortants',
          body: 'Le site peut contenir des liens vers des ressources tierces. Nous ne contrôlons pas leur contenu et déclinons toute responsabilité y afférant.'
        },
        section09: {
          title: '9. Données personnelles',
          body: 'La collecte d’informations se fait conformément à la politique de confidentialité. L’utilisateur dispose de droits d’accès et de rectification.'
        },
        section10: {
          title: '10. Cookies',
          body: 'Le détail des cookies utilisés et des options de consentement est décrit dans la politique dédiée.'
        },
        section11: {
          title: '11. Responsabilité',
          body: 'Nous veillons à l’exactitude des contenus mais ne garantissons pas l’absence d’erreurs ou d’omissions.'
        },
        section12: {
          title: '12. Force majeure',
          body: 'Notre responsabilité ne saurait être engagée en cas de force majeure rendant l’accès partiellement ou totalement impossible.'
        },
        section13: {
          title: '13. Modifications',
          body: 'Nous pouvons adapter ces conditions à tout moment. Les mises à jour entrent en vigueur dès publication en ligne.'
        },
        section14: {
          title: '14. Loi applicable',
          body: 'Les présentes conditions sont régies par le droit belge. Tout litige relève des juridictions du ressort de Bruxelles.'
        }
      },
      closure: {
        title: 'Contact',
        body: 'Pour toute question relative aux conditions d’utilisation, contactez info@danswholesaleplants.com.'
      }
    },
    privacy: {
      title: 'Politique de confidentialité',
      intro: 'Nous détaillons ici notre approche de collecte et de traitement des données personnelles.',
      sections: {
        section01: {
          title: '1. Responsable du traitement',
          body: 'Le responsable est danswholesaleplants, Avenue Louise 251, 1050 Bruxelles.'
        },
        section02: {
          title: '2. Données collectées',
          body: 'Formulaires, statistiques de navigation anonymisées et correspondances électroniques constituent les principales sources.'
        },
        section03: {
          title: '3. Finalités',
          body: 'Les données servent à répondre aux demandes, améliorer nos contenus et assurer un suivi qualitatif des interactions.'
        },
        section04: {
          title: '4. Base légale',
          body: 'Le consentement ou l’intérêt légitime justifie chaque traitement selon sa nature. Aucune prospection automatisée n’est effectuée.'
        },
        section05: {
          title: '5. Conservation',
          body: 'Les informations sont conservées pour une durée proportionnée : trois ans maximum pour les données de contact.'
        },
        section06: {
          title: '6. Partage',
          body: 'Nous ne transmettons pas de données à des tiers sans nécessité technique ou obligation légale clairement identifiée.'
        },
        section07: {
          title: '7. Droits des personnes',
          body: 'Vous disposez de droits d’accès, rectification, effacement et opposition. Une réponse est apportée sous trente jours.'
        },
        section08: {
          title: '8. Sécurité',
          body: 'Nous utilisons chiffrement, contrôle des accès et sauvegardes régulières pour protéger les données.'
        },
        section09: {
          title: '9. Cookies',
          body: 'Le détail des cookies et le paramétrage sont décrits dans la politique correspondante. Les préférences peuvent être modifiées via la bannière.'
        },
        section10: {
          title: '10. Sous-traitance',
          body: 'Les prestataires techniques respectent des niveaux de garantie équivalents et sont soumis à des clauses de confidentialité strictes.'
        },
        section11: {
          title: '11. Transferts internationaux',
          body: 'Aucun transfert hors Union européenne n’est effectué sans garanties adéquates et information préalable.'
        },
        section12: {
          title: '12. Contact',
          body: 'Pour exercer vos droits ou poser une question, écrivez à privacy@danswholesaleplants.com.'
        }
      },
      closure: {
        title: 'Mise à jour',
        body: 'Cette politique pourra évoluer. La date de révision figure en en-tête du document.'
      }
    },
    cookiesPage: {
      title: 'Politique de cookies',
      intro: 'Cette politique décrit les technologies utilisées pour mesurer l’usage du site et vous permettre de contrôler vos préférences.',
      sections: {
        section01: {
          title: '1. Principes généraux',
          body: 'Nous limitons l’usage de cookies aux besoins techniques, à la personnalisation linguistique et aux mesures qualitatives anonymisées.'
        },
        section02: {
          title: '2. Consentement',
          body: 'Lors de votre première visite, une bannière vous permet d’accepter, refuser ou personnaliser vos choix.'
        },
        section03: {
          title: '3. Gestion des préférences',
          body: 'Vous pouvez à tout moment modifier vos options via la bannière ou en supprimant les cookies depuis votre navigateur.'
        },
        section04: {
          title: '4. Cookies nécessaires',
          body: 'Assurent la continuité de session, la sécurité et la mémorisation temporaire de la langue sélectionnée.'
        },
        section05: {
          title: '5. Cookies optionnels',
          body: 'Les cookies de préférences, d’analyses et de visibilité ne sont déposés qu’avec votre accord explicite.'
        },
        section06: {
          title: '6. Informations complémentaires',
          body: 'Pour toute question sur cette politique, contactez privacy@danswholesaleplants.com.'
        }
      },
      table: {
        title: 'Détails des cookies utilisés',
        headings: {
          name: 'Nom',
          provider: 'Fournisseur',
          type: 'Type',
          purpose: 'Finalité',
          duration: 'Durée'
        },
        rows: {
          row1: {
            name: 'site_lang',
            provider: 'danswholesaleplants',
            type: 'Essentiel',
            purpose: 'Conserver la langue choisie pour l’ensemble du site.',
            duration: '12 mois'
          },
          row2: {
            name: 'cookie_consent',
            provider: 'danswholesaleplants',
            type: 'Essentiel',
            purpose: 'Enregistrer vos préférences de consentement.',
            duration: '12 mois'
          },
          row3: {
            name: 'pref_view',
            provider: 'danswholesaleplants',
            type: 'Préférences',
            purpose: 'Précharger les composants visuels selon vos options.',
            duration: '6 mois'
          },
          row4: {
            name: 'ux_metrics',
            provider: 'danswholesaleplants',
            type: 'Analytique',
            purpose: 'Collecte anonymisée de métriques de navigation pour ajuster les contenus.',
            duration: '1 mois'
          }
        },
        note: 'Les cookies optionnels ne sont actifs qu’après votre accord explicite. Vous pouvez les retirer à tout moment.'
      }
    },
    refund: {
      title: 'Politique de révision',
      intro: 'Bien que nous ne réalisions pas de transactions commerciales via ce site, nous précisons notre cadre d’accompagnement et de correction.',
      sections: {
        section01: {
          title: '1. Portée',
          body: 'La politique s’applique aux missions d’étude et aux livrables produits par danswholesaleplants.'
        },
        section02: {
          title: '2. Absence de vente',
          body: 'Aucun paiement n’est traité en ligne. Les ajustements sont encadrés par des conventions signées avec les partenaires.'
        },
        section03: {
          title: '3. Demandes de correction',
          body: 'Les partenaires peuvent solliciter des corrections dans un délai de trente jours après remise des livrables.'
        },
        section04: {
          title: '4. Délai de traitement',
          body: 'Chaque demande est analysée sous cinq jours ouvrés pour déterminer les actions à mener.'
        },
        section05: {
          title: '5. Limites',
          body: 'Les corrections concernent exclusivement les éléments prévus dans le périmètre initial de la mission.'
        },
        section06: {
          title: '6. Nouvelles demandes',
          body: 'Tout besoin supplémentaire fera l’objet d’une proposition méthodologique distincte.'
        },
        section07: {
          title: '7. Documentation',
          body: 'Les ajustements validés sont consignés et partagés via un journal de modifications.'
        },
        section08: {
          title: '8. Collaboration',
          body: 'Nous sollicitons les retours détaillés des équipes partenaires pour prioriser les interventions.'
        },
        section09: {
          title: '9. Rétroplanning',
          body: 'Un planning révisé est communiqué dès validation des ajustements pour garantir la traçabilité.'
        },
        section10: {
          title: '10. Contact',
          body: 'Pour toute question relative à cette politique, écrivez à info@danswholesaleplants.com.'
        },
        section11: {
          title: '11. Mise à jour',
          body: 'Ce document peut être actualisé afin d’intégrer les retours d’expérience.'
        },
        section12: {
          title: '12. Date d’effet',
          body: 'Version mise à jour le 12 janvier 2025.'
        }
      },
      closure: {
        title: 'Transparence',
        body: 'Nous privilégions un dialogue continu pour garantir la qualité des livrables et la lisibilité des environnements étudiés.'
      }
    },
    disclaimer: {
      title: 'Clause de non-responsabilité',
      intro: 'Les contenus publiés sur danswholesaleplants ont vocation informative et ne sauraient se substituer à des décisions opérationnelles sans vérification.',
      sections: {
        section01: {
          title: '1. Nature des informations',
          body: 'Les analyses partagées reflètent un état de connaissances à la date de publication. Elles peuvent évoluer sans préavis.'
        },
        section02: {
          title: '2. Absence de garantie',
          body: 'Nous ne garantissons ni l’exhaustivité ni la permanence des informations fournies sur le site.'
        },
        section03: {
          title: '3. Responsabilité',
          body: 'Nous déclinons toute responsabilité pour les décisions prises sur la base des contenus sans vérification complémentaire.'
        },
        section04: {
          title: '4. Liens externes',
          body: 'Les ressources externes citées sont fournies à titre indicatif. Nous ne contrôlons pas leur exactitude ni leur disponibilité.'
        },
        section05: {
          title: '5. Compatibilité technique',
          body: 'L’accès au site peut dépendre de la configuration de votre équipement. Nous ne pouvons garantir la compatibilité universelle.'
        },
        section06: {
          title: '6. Témoignages',
          body: 'Les retours d’expérience publiés illustrent des contextes spécifiques et ne constituent pas une promesse de résultat.'
        },
        section07: {
          title: '7. Modifications',
          body: 'Nous pouvons mettre à jour la présente clause à tout moment afin de refléter l’évolution de nos pratiques.'
        },
        section08: {
          title: '8. Contact',
          body: 'Pour toute précision complémentaire, contactez info@danswholesaleplants.com.'
        }
      },
      closure: {
        title: 'Prudence recommandée',
        body: 'Nous invitons chaque lecteur à confronter nos analyses au contexte propre de son organisation avant décision.'
      }
    },
    thankyou: {
      hero: {
        badge: 'Message envoyé',
        title: 'Merci pour votre prise de contact',
        body: 'Nous analysons vos informations et revenons rapidement avec une proposition de cadrage ou des questions complémentaires.',
        primaryAction: 'Retour à l’accueil',
        secondaryAction: 'Parcourir les analyses'
      }
    },
    blogPosts: {
      post1: {
        title: 'Cartographies logistiques des hôpitaux universitaires',
        excerpt: 'Comment modéliser la circulation interne des hôpitaux universitaires pour fluidifier l’orientation des usagers, du triage d’urgence aux plateaux techniques ?',
        intro: 'Les hôpitaux universitaires constituent des labyrinthes stratifiés où se superposent médecine de pointe, logistique et accueil du public. Comprendre ces strates est indispensable pour réduire les ruptures de parcours.',
        content: `<h2>Comprendre la stratification de l'hôpital universitaire</h2>
<p>Les hôpitaux universitaires sont des structures qui accumulent dans un même volume des fonctions diverses : urgences, hospitalisations, laboratoires de recherche, enseignement. La juxtaposition de ces programmes crée une densité exceptionnelle de flux et de transitions spatiales. Pour élaborer une cartographie pertinente, il faut d'abord identifier les familles de parcours. Les patients ambulatoires, les visiteurs, le personnel médical et les approvisionnements suivent des logiques très différentes. Chaque famille possède des points de départ et des zones de destination spécifiques, mais leurs trajectoires se croisent dans des nœuds qui deviennent rapidement saturés. L'analyse débute donc par la constitution d'un inventaire précis de ces nœuds de convergence. On y observe la largeur réelle des couloirs, la hauteur des plans de signalétique, la visibilité des issues de secours et la présence d'informations redondantes ou obsolètes.</p>
<p>Une fois les nœuds identifiés, nous examinons la hiérarchie verticale de l'hôpital. Les ascenseurs et escaliers sont les véritables artères de l'édifice. Dans de nombreux bâtiments, les ascenseurs publics et professionnels sont mal différenciés, ce qui allonge les temps d'attente et impacte la ponctualité des rendez-vous médicaux. Nous recommandons de dissocier clairement les flux en travaillant des marqueurs visuels forts : couleurs contrastées, pictogrammes bilingues, balises lumineuses pour indiquer la disponibilité. L'introduction d'un guidage sonore discret peut compléter ce dispositif, notamment pour les patients qui appréhendent le déplacement dans un environnement complexe.</p>
<h3>Cartographier les flux médicaux et les flux logistiques</h3>
<p>Les flux médicaux et logistiques partagent parfois des corridors. Pourtant, leurs contraintes diffèrent radicalement. Les brancards et chariots ont besoin de surfaces lisses, dégagées, tandis que les flux logistiques imposent un passage fréquent de conteneurs roulants. Pour éviter que ces flux ne perturbent l'expérience des visiteurs, nous proposons de créer des couloirs techniques parallèles ou au moins des créneaux horaires dédiés. La cartographie doit intégrer ces temporalités. Des plans dynamiques affichés sur les écrans de coordination peuvent indiquer en direct la densité d'utilisation de certains couloirs et proposer des itinéraires alternatifs.</p>
<p>Il est également essentiel d'intégrer les services cliniques et les unités de recherche dans la cartographie. Les chercheurs circulent souvent avec du matériel sensible. La signalétique doit indiquer clairement les zones à accès restreint pour éviter les intrusions involontaires des visiteurs. Nous préconisons des codes visuels cohérents sur tout l'hôpital : un même symbole ne doit jamais porter deux messages différents. Cette cohérence renforce la compréhension immédiate des consignes, même pour un public non francophone ou peu habitué aux codes hospitaliers.</p>
<h2>Segmenter les parcours selon les temps du soin</h2>
<p>Le patient qui se rend à une consultation planifiée n'a pas les mêmes attentes que celui qui arrive aux urgences. Le premier cherche un parcours simple, rassurant, avec des repères réguliers. Le second doit accéder à un service prioritaire sans se perdre. Une cartographie efficace distingue ces situations. Pour les consultations, nous recommandons des itinéraires préalables envoyés par courrier ou par e-mail avec une cartographie numérique interactive. Sur place, des balises directionnelles reprennent la même logique graphique, assurant une continuité mentale. Pour les urgences, la signalétique doit être visible depuis l'extérieur, avec des codes couleurs universels et des indications directionnelles multipliées à chaque croisement.</p>
<p>Les temps du soin incluent aussi le retour à domicile. Trop souvent, la sortie est peu signalée, ce qui oblige les visiteurs à retracer leurs pas dans des couloirs parfois labyrinthiques. Nous préconisons d'installer des lignes de fuite visuelles vers les sorties principales, associées à des pictogrammes clairs et à des indications sur les transports publics à proximité. Les patients hospitalisés, quant à eux, ont besoin d'informations répétées et rassurantes sur la localisation des services de support : cafétéria, pharmacie, chapelle, espaces de soutien psychologique. Une cartographie murale dans chaque unité, accompagnée d'un plan portable simplifié, permet de réduire le stress et de favoriser l'autonomie.</p>
<h3>Modéliser les scénarios d'affluence et d'urgence</h3>
<p>La cartographie ne peut être figée. Les hôpitaux gèrent des pics d'affluence, des opérations de maintenance, des situations d'urgence. Une bonne pratique consiste à élaborer des scénarios type avec des plans de repli. Lors d'une fermeture d'aile, on sait immédiatement quel parcours de substitution activer et quelle signalétique temporaire déployer. Les outils numériques aident à simuler ces scénarios : on peut calculer le temps supplémentaire induit pour un patient et vérifier que les messages délivrés restent cohérents. Les exercices de simulation doivent inclure le personnel, car ce sont eux qui accompagneront les visiteurs en cas de perturbation.</p>
<p>Les situations d'urgence exigent une articulation parfaite entre les systèmes d'alerte, la signalétique lumineuse et l'accompagnement humain. Les plans d'évacuation doivent être lisibles et positionnés à hauteur de regard. Nous recommandons de les décliner en plusieurs formats, y compris tactile ou en braille, et de prévoir une explication simplifiée dans les langues les plus fréquentes de la patientèle. Les couloirs critiques peuvent être dotés d'un éclairage dynamique indiquant la direction à suivre. Chaque élément doit être testé en conditions réelles pour garantir son efficacité.</p>
<h2>Impliquer les usagers pour affiner la cartographie</h2>
<p>La participation des usagers est un levier précieux. Organiser des marches exploratoires avec des patients, des proches et des professionnels non familiers du site apporte des informations que les plans ne révèlent pas. On découvre des points de confusion, des zones jugées anxiogènes, des signalétiques cachées par des portes ouvertes. Les observations issues de ces marches sont intégrées dans la cartographie afin de produire des plans qui parlent réellement à ceux qui les utilisent. Les retours peuvent être collectés via des dispositifs simples : QR codes associés à un formulaire, boîtes à suggestions multilingues ou ateliers ponctuels.</p>
<p>Impliquer les usagers, c’est également penser aux personnels de nuit et aux équipes de week-end. Ils évoluent dans des environnements plus calmes mais parfois moins accompagnés. Une cartographie spécifique, en version lumineuse ou accessible sur terminaux mobiles, leur permet de repérer rapidement les zones techniques et les ressources disponibles. Les agents de sécurité, eux, ont besoin d'une vision globale à jour. Un tableau de bord synoptique relié aux plans interactifs est un atout considérable pour coordonner leurs interventions.</p>
<h3>Mesurer l'efficacité de la nouvelle cartographie</h3>
<p>Après déploiement, la cartographie doit être évaluée. Nous recommandons de définir des indicateurs clairs : temps moyen pour atteindre une destination critique, taux de questions posées à l’accueil, incidents de désorientation signalés. Ces métriques sont suivies sur plusieurs mois pour confirmer les gains obtenus et identifier les ajustements nécessaires. L'analyse croisée des données qualitatives et quantitatives renforce la pertinence des décisions prises.</p>
<p>Les retours du terrain nourrissent les itérations futures. Une cartographie hospitalière est un système vivant, qui doit intégrer les évolutions architecturales, technologiques et organisationnelles. La meilleure garantie de sa pérennité réside dans une gouvernance partagée et une documentation accessible à toutes les parties prenantes.</p>`,
        content_word_count: 0
      },
      post2: {
        title: 'Signalétique numérique dans les hubs intermodaux',
        excerpt: 'Comparer et synchroniser les dispositifs numériques des gares et stations pour réduire l’incertitude des voyageurs multi-modaux.',
        intro: 'Les hubs intermodaux orchestrent plusieurs réseaux simultanément. Les voyageurs y reçoivent une avalanche d’informations qu’il faut hiérarchiser avec précision.',
        content: `<h2>Cartographier l'écosystème d'information</h2>
<p>Un hub intermodal concentre trains, métros, tramways, bus et parfois vélos partagés. Chaque opérateur diffuse ses propres informations, souvent via des dispositifs numériques spécifiques. Le premier enjeu consiste à cartographier cet écosystème d'information : écrans de départ, bornes d'achat, panneaux contextuels, applications mobiles, annonces audio. Cette cartographie doit rendre visibles les doublons, les contradictions et les zones silencieuses. Elle permet d'orchestrer les diffusions, de définir des priorités et d'identifier les moments où les voyageurs sont le plus réceptifs.</p>
<p>Les écrans numériques constituent des points d'ancrage majeurs. Leur efficacité dépend de trois paramètres : la lisibilité, la hiérarchie des contenus et la localisation. Un écran mal positionné, orienté à contre-jour ou situé après un point de décision crucial perd son utilité. Nous préconisons de croiser l'étude des flux avec une analyse photométrique : mesurer la luminosité, la perception des contrastes, la distance de lecture. Les contenus doivent être structurés en couches : informations critiques (retards, quai), informations contextuelles (correspondances, services) et informations de confort (temps météo, orientations vers les sorties). Cette hiérarchie doit rester stable, même en cas de perturbation.</p>
<h3>Coordonner les opérateurs et les interfaces</h3>
<p>Les hubs intermodaux impliquent plusieurs opérateurs. Chacun possède ses propres codes visuels, ses outils de publication et ses contraintes réglementaires. Pour éviter la cacophonie, il est nécessaire d'établir un protocole commun. Ce protocole définit des règles d'affichage partagées : typographies, couleurs d'alerte, formats de messages. Il précise également la gouvernance, c'est-à-dire qui décide de publier quoi et à quel moment. L'objectif est d'éviter que deux informations contradictoires apparaissent simultanément, générant confusion et perte de confiance.</p>
<p>Les interfaces mobiles complètent ce dispositif. Les voyageurs consultent leur smartphone pour vérifier un quai, calculer un itinéraire ou acheter un ticket. Les données affichées doivent correspondre à celles visibles sur les écrans physiques. Nous recommandons l'utilisation d'API partagées alimentant tous les canaux. Lorsqu'une perturbation survient, un message unique est répercuté partout : écrans, notifications mobiles, annonces vocales. Cette cohérence réduit le stress et les comportements erratiques, particulièrement dans les situations où les voyageurs doivent prendre une décision rapide.</p>
<h2>Fluidifier les transitions entre modes</h2>
<p>Dans un hub intermodal, le voyageur passe souvent d'un mode à l'autre en quelques minutes. Les points de décision se situent dans des zones de transition : intersections, escaliers, entrées de quai, sorties vers la voirie. Ces zones doivent faire l'objet d'une attention spécifique. La signalétique numérique peut y jouer un rôle déterminant en affichant des informations contextuelles telles que le temps restant avant un départ ou le niveau de fréquentation d'une rame. Nous recommandons de positionner des écrans de rappel juste avant les choix critiques, avec un contenu épuré, focalisé sur la prochaine action à réaliser.</p>
<p>Les transitions doivent aussi prendre en compte les besoins des personnes à mobilité réduite. Les écrans interactifs peuvent proposer des itinéraires accessibles en évitant les escaliers ou les couloirs étroits. Des pictogrammes dynamiques, synchronisés avec le système de montée/descente des ascenseurs, indiquent la disponibilité des équipements. La coordination entre signalétique numérique et balisage tactile est essentielle : un utilisateur qui suit une bande podotactile doit retrouver les mêmes informations sur l'écran qu'il consulte pour vérifier son parcours.</p>
<h3>Gérer les situations perturbées</h3>
<p>Les hubs intermodaux sont particulièrement sensibles aux perturbations. Une grève, un incident technique ou des conditions météorologiques extrêmes peuvent désorganiser l'ensemble du système. Les dispositifs numériques doivent être capables de passer en mode "crise" en un clic. Ce mode simplifie l'affichage, donne la priorité aux messages décisifs et peut rediriger les flux vers des itinéraires alternatifs. Les équipes de contrôle doivent disposer d'une interface de pilotage intuitive leur permettant de déclencher ces scénarios préconfigurés.</p>
<p>La communication doit rester cohérente et répétée. Un message affiché sur les écrans doit être relayé par les annonces sonores et les notifications mobiles. Les pictogrammes d'alerte doivent être identiques sur tous les supports. Lorsqu'un itinéraire alternatif est proposé, il doit être accompagné de repères visuels clairs dans l'espace physique : flèches temporaires, éclairage de guidage, orientation du personnel. Les retours d'expérience prouvent que les voyageurs acceptent mieux les situations perturbées lorsqu'ils perçoivent une narration cohérente et des indications répétées.</p>
<h2>Mesurer l'expérience voyageur</h2>
<p>Une fois les dispositifs déployés, il est indispensable de mesurer leur efficacité. Nous recommandons d'installer des capteurs de flux anonymisés pour visualiser les parcours empruntés. Ces données sont croisées avec les retours des voyageurs collectés via des questionnaires courts ou des interviews sur site. Les indicateurs suivent l'évolution du temps moyen de correspondance, du nombre de demandes au guichet et du ressenti de confiance. Les écrans numériques peuvent intégrer des QR codes ou des interfaces tactiles permettant de recueillir un feedback en temps réel.</p>
<p>Les résultats alimentent un tableau de bord partagé entre les opérateurs. Ce tableau affiche les indicateurs clés de performance, les incidents récents et les actions correctives engagées. Il devient un outil de gouvernance qui favorise la coopération entre les différents acteurs. Lorsque l'on constate qu'un écran est peu consulté ou que les voyageurs continuent à se perdre dans une zone précise, on peut programmer une intervention ciblée : repositionnement, modification du contenu, ajout d'un renfort analogique.</p>
<h3>Anticiper les évolutions futures</h3>
<p>Les hubs intermodaux évoluent en permanence : nouvelles lignes, extensions, modifications des usages. La signalétique numérique doit être conçue comme un système évolutif. Nous préconisons l'utilisation de gabarits modulaires qui peuvent être adaptés rapidement sans repenser l'ensemble du dispositif. Les scripts de diffusion doivent être documentés, les données structurées pour permettre l'intégration de nouvelles sources (par exemple l'information vélo ou covoiturage). Les écrans peuvent être utilisés pour tester de nouveaux services à condition de conserver la hiérarchie définie.</p>
<p>Enfin, il est utile d'organiser des revues régulières avec les voyageurs, les opérateurs et les associations de quartier. Ces rencontres permettent de partager les projets à venir, de recueillir des attentes et de prévenir les incompréhensions. La signalétique numérique est un langage commun qui doit rester lisible et crédible. Sa réussite tient autant à la qualité des supports qu'à la gouvernance collective qui l'accompagne.</p>`
      },
      post3: {
        title: 'Expérience piétonne des centres de services municipaux',
        excerpt: 'Repenser la circulation dans les centres administratifs multi-usages pour réduire les files et clarifier les parcours citoyens.',
        intro: 'Les centres de services municipaux concentrent des démarches variées. Ils accueillent quotidiennement des publics hétérogènes avec des niveaux d’urgence différents.',
        content: `<h2>Cartographier les parcours citoyens</h2>
<p>Le centre de services municipal agrége de nombreuses démarches : état civil, logement, urbanisme, commerce, médiation sociale. Chaque démarche possède son propre circuit administratif, ses documents et ses interlocuteurs. Les visiteurs arrivent avec des attentes différentes et un capital de temps variable. La première étape consiste à cartographier ces parcours en identifiant les étapes successives : accueil général, réception d’un ticket, orientation vers un guichet spécialisé, éventuel passage dans une salle d’attente, échange avec un agent, dépôt de documents. Observer les flux à différentes heures permet de comprendre les pics de fréquentation et les moments de tension.</p>
<p>La signalétique doit refléter cette diversité sans surcharger les visiteurs. Les messages doivent être hiérarchisés. Nous recommandons trois niveaux : des repères macro (étages, ailes, secteurs), des indications intermédiaires (guichets, files spécifiques, salles) et des messages contextuels (documents à présenter, temps estimé). Les supports doivent être conçus pour être mis à jour rapidement. Les centres municipaux évoluent souvent : ouverture de nouvelles permanences, changement de localisation des bureaux, dispositifs temporaires. Une signalétique flexible, avec inserts modulables ou écrans légers, facilite ces ajustements.</p>
<h3>Fluidifier les files et les zones d'attente</h3>
<p>Les files d’attente sont un point sensible. Elles concentrent l’impatience et peuvent générer des comportements désordonnés. La mise en place d’un système de tickets à la fois physique et numérique permet de distribuer les flux. Les écrans listant les numéros appelés doivent être lisibles depuis toutes les zones d’attente. Nous recommandons un code couleur associant chaque filière à une teinte spécifique. Cette logique est déclinée sur les tickets, les écrans, les panneaux et les rappels sonores. L’utilisateur comprend immédiatement où il en est et quel guichet surveiller.</p>
<p>Les zones d'attente peuvent être segmentées en micro-espaces adaptés aux différents publics : familles avec enfants, personnes âgées, usagers nécessitant un accompagnement spécifique. Une signalétique douce, associée à des mobiliers adaptés, incite à la répartition naturelle et évite les regroupements massifs. Des écrans peuvent afficher des informations de préparation : documents requis, étapes à venir, rappel des mesures d’accessibilité. Ces contenus réduisent le temps d’échange au guichet car les usagers arrivent mieux préparés.</p>
<h2>Garantir l'accessibilité et l'inclusion</h2>
<p>Un centre municipal doit être accessible à tous. La signalétique visuelle est complétée par des dispositifs tactiles et sonores. Des bandes de guidage au sol orientent vers les guichets clés, des cartographies tactiles à l’entrée présentent la disposition générale, des annonces sonores rappellent les numéros appelés. Les écrans doivent proposer un contraste élevé et un texte suffisamment grand. Des traductions dans les langues les plus représentées au sein de la communauté peuvent être intégrées aux écrans ou aux brochures d’accueil.</p>
<p>La communication doit également anticiper les situations de vulnérabilité : personnes en difficulté de lecture, visiteurs en situation de stress. Les pictogrammes universels sont précieux. Ils doivent être testés auprès d’un panel d’usagers pour vérifier leur compréhension. L’accès aux ascenseurs, toilettes, espaces de confidentialité doit être signalé clairement. Les parcours doivent éviter les ruptures de niveau non signalées et les couloirs trop étroits. Lorsque des travaux sont en cours, une signalétique temporaire doit être déployée immédiatement avec des informations précises sur les déviations et les nouvelles entrées.</p>
<h3>Accompagner les agents dans le dispositif</h3>
<p>Les agents d’accueil et les conseillers jouent un rôle clé. Ils doivent disposer d’outils pour orienter rapidement les visiteurs. Un tableau de bord interne listant les files en temps réel, le statut des guichets et les messages diffusés sur les écrans les aide à donner des indications cohérentes. La signalétique numérique doit être facilement modifiable par les équipes habilitées : un changement de salle de conférence, l’ajout d’une permanence exceptionnelle doivent pouvoir être annoncés instantanément.</p>
<p>Former les agents à l’utilisation de la signalétique est tout aussi important que de déployer les supports. Ils doivent comprendre la logique de codification, savoir déclencher les messages d’alerte (par exemple en cas d’évacuation) et remonter les dysfonctionnements. Le retour terrain des agents est la meilleure source pour affiner la cartographie : ils savent quels panneaux sont ignorés, quelles questions reviennent en boucle et quelles zones restent confuses.</p>
<h2>Mesurer et ajuster en continu</h2>
<p>Après déploiement, l’observation continue permet d’améliorer le dispositif. Nous recommandons de mesurer le temps moyen passé dans chaque étape, le nombre de questions posées, le taux d’erreur dans les formulaires. Les retours peuvent être collectés via des bornes de satisfaction, des enquêtes en ligne ou des focus groups périodiques. Les ajustements sont consignés dans un registre partagé pour garder la mémoire des décisions.</p>
<p>Les centres municipaux évoluent au rythme de la vie locale. La signalétique doit donc être revue au moins une fois par an pour rester pertinente. Des ateliers avec les associations de quartier, les conseils citoyens et les équipes municipales permettent d’anticiper les nouvelles demandes (démarches numériques, nouveaux services sociaux). La flexibilité et la clarté restent les maîtres mots.</p>
<h3>Créer une expérience apaisée</h3>
<p>Au-delà de la fonctionnalité, la signalétique contribue à l’ambiance générale. Des supports soignés, des messages clairs et respectueux, un parcours lisible donnent aux citoyens le sentiment d’être considérés. C’est un élément majeur de la qualité de service. En réduisant la confusion et les files inutiles, la municipalité libère du temps pour accompagner les situations complexes et renforce la confiance dans l’administration.</p>`
      },
      post4: {
        title: 'Guidages tactiles et visuels combinés',
        excerpt: 'Associer les dispositifs tactiles, visuels et sonores pour garantir une orientation inclusive dans les équipements publics.',
        intro: 'L’orientation inclusive repose sur la coordination de plusieurs sens. Les guidages tactiles complètent les supports visuels et numériques.',
        content: `<h2>Diagnostiquer la chaîne sensorielle existante</h2>
<p>De nombreux équipements publics misent sur la signalétique visuelle sans s’assurer que les repères tactiles et sonores suivent la même logique. Le diagnostic initial consiste à parcourir le site avec différents profils d’usagers : personnes malvoyantes, personnes distraites, visiteurs étrangers. On vérifie la présence de bandes de guidage, leur continuité, la lisibilité des contrastes au sol, la cohérence des pictogrammes. Les informations tactiles doivent débuter dès l’espace public pour guider vers l’entrée principale, se prolonger dans les halls et se connecter aux ascenseurs, guichets et issues de secours.</p>
<p>La cartographie sensorielle met en regard chaque type de repère. On trace les bandes podotactiles, les plaques en braille, les signaux sonores, les écrans, les panneaux. L’objectif est de repérer les ruptures : une bande qui s’interrompt avant un obstacle, un pictogramme tactile qui renvoie à une zone non signalée visuellement, un message sonore qui n’est pas synchronisé avec le visuel. Ces incohérences sont sources de confusion et peuvent générer des situations dangereuses.</p>
<h3>Concevoir une grammaire commune</h3>
<p>Une fois le diagnostic posé, il s’agit de créer une grammaire commune. Chaque repère tactile doit correspondre à un repère visuel et, si nécessaire, à un message sonore. On définit un code couleur, un relief, une texture et un pictogramme cohérents. Par exemple, les espaces d’accueil utilisent une texture en points, les escaliers une texture striée, les ascenseurs une texture linéaire. Cette logique est documentée et partagée avec les équipes de maintenance pour éviter les modifications non coordonnées.</p>
<p>La grammaire intègre également les dispositifs numériques. Les plans interactifs doivent proposer une option haute visibilité et des indications vocales. Les applications mobiles peuvent détecter les balises Bluetooth ou NFC installées dans le bâtiment pour guider les visiteurs via un retour haptique ou audio. Cette synchronisation est particulièrement utile dans les grandes infrastructures comme les musées, les campus universitaires ou les gares.</p>
<h2>Mettre en place des parcours de test</h2>
<p>Avant déploiement global, nous recommandons de créer des parcours de test. Ils permettent de vérifier la compréhension des repères par différents publics. Les tests se déroulent en conditions réelles, avec des scénarios variés : trouver un guichet, rejoindre une salle de conférence, évacuer le bâtiment. Les participants donnent un retour précis sur chaque étape. Les observations sont consignées dans une matrice qui relie le type de repère (tactile, visuel, sonore) à son efficacité perçue.</p>
<p>Les parcours de test révèlent souvent des détails qui échappent aux concepteurs : une bande podotactile légèrement décalée, un pictogramme trop haut, un message sonore difficile à entendre à cause du bruit ambiant. Les corrections sont apportées immédiatement. Les équipes techniques sont impliquées pour garantir la faisabilité des ajustements et planifier la maintenance.</p>
<h3>Articuler les dispositifs en situation d'urgence</h3>
<p>La coordination tactile-visuelle est cruciale en cas d’urgence. Les bandes de guidage doivent mener vers les sorties de secours et les points de rassemblement. Les portes coupe-feu doivent être signalées par des poignées facilement repérables et des pictogrammes en relief. Les messages sonores d’évacuation doivent être clairs, multilingues et accompagnés de signaux lumineux. La documentation prévoit des scénarios où certaines voies sont impraticables. Dans ce cas, des balises lumineuses portatives ou des panneaux temporaires tactiles peuvent être déployés.</p>
<p>Les exercices d’évacuation incluent des participants en situation de handicap visuel ou auditif. On vérifie que les instructions sont comprises, que les repères sont accessibles et que les équipes d’intervention connaissent la grammaire sensorielle. Le retour d’expérience de ces exercices nourrit un plan d’amélioration continue.</p>
<h2>Former et sensibiliser les équipes</h2>
<p>La meilleure signalétique perd en efficacité si les équipes ne la maîtrisent pas. Une session de formation présente la grammaire sensorielle, explique comment entretenir les bandes de guidage, comment positionner les panneaux temporaires et comment accompagner les visiteurs. Les agents apprennent à décrire verbalement l’espace, à proposer un bras guide si nécessaire, à orienter vers les ressources complémentaires (plans tactiles, audioguides, assistance téléphonique).</p>
<p>La sensibilisation concerne également les prestataires externes : entreprises de nettoyage, équipes de maintenance, organisateurs d’événements. Ils doivent savoir qu’une bande podotactile ne peut pas être recouverte par un tapis ou une structure temporaire. Les organisateurs sont encouragés à intégrer la grammaire dans leur signalétique événementielle pour assurer une continuité.</p>
<h3>Pérenniser le dispositif</h3>
<p>Un dispositif tactile-visuel nécessite un suivi régulier. Les bandes de guidage s’usent, les pictogrammes peuvent être abîmés, les messages sonores doivent être testés. Nous recommandons un audit annuel qui vérifie l’état de chaque repère, met à jour la documentation et planifie les remplacements. Les retours des usagers sont recueillis grâce à des canaux dédiés : formulaire en braille, numéro de téléphone accessible, courriel spécifique.</p>
<p>La pérennité passe par la traçabilité. Chaque intervention est consignée dans un registre. Les équipes savent quel élément a été modifié, avec quel matériau et quelle référence. Ce suivi garantit la cohérence du dispositif sur le long terme et facilite les interventions ultérieures.</p>`
      },
      post5: {
        title: 'Pipelines spatiaux temps réel pour le guidage',
        excerpt: 'Structurer des pipelines de données pour actualiser en temps réel les plans interactifs et optimiser la mobilité piétonne.',
        intro: 'Le guidage contemporain s’appuie sur des flux de données dynamiques. Construire un pipeline fiable est essentiel pour fournir une information pertinente.',
        content: `<h2>Définir les sources et la gouvernance des données</h2>
<p>Un pipeline spatial efficace commence par l’identification des sources. Dans un bâtiment complexe, on peut capter des données via des capteurs de comptage, des systèmes d’accès, des applications mobiles, des retours agents, des caméras anonymisées. Chaque source a sa fréquence de mise à jour, son niveau de précision et ses contraintes juridiques. La gouvernance des données définit qui collecte quoi, qui vérifie la qualité, qui décide de l’intégration. Une charte précise les finalités : améliorer l’orientation, anticiper les saturations, informer les visiteurs.</p>
<p>La question de la confidentialité est centrale. Les pipelines doivent respecter le cadre légal et éviter toute identification personnelle. On privilégie les données agrégées ou anonymisées. Les flux entrants sont filtrés, nettoyés et stockés dans un environnement sécurisé. Une base de données spatiale centralise les informations en tenant compte de la structure du bâtiment : niveaux, zones, itinéraires, points d’intérêt. Ce socle permet de croiser les données en temps réel avec la cartographie et de générer des vues pertinentes.</p>
<h3>Concevoir l’architecture technique</h3>
<p>Le pipeline spatial comporte plusieurs couches : ingestion, traitement, stockage, diffusion. L’ingestion connecte les capteurs et les systèmes existants. Des API ou des connecteurs sécurisés assurent la collecte. Le traitement applique des règles métiers : calculer la densité d’une zone, détecter un flux inhabituel, identifier une fermeture temporaire. Le stockage consolide les données dans une base géospatiale. Enfin, la diffusion expose des services qui alimentent les plans interactifs, les écrans numériques, les applications mobiles ou les tableaux de bord internes.</p>
<p>Nous recommandons une architecture modulable qui peut intégrer de nouvelles sources sans tout reconstruire. Les messages sont formatés autour d’un modèle commun : chaque élément contient un identifiant, une géolocalisation, un niveau de confiance, une durée de validité. Cette structure facilite la diffusion simultanée vers plusieurs supports. En cas d’incident, il suffit d’envoyer une mise à jour centralisée pour que tous les supports s’alignent.</p>
<h2>Synchroniser les plans interactifs et les écrans</h2>
<p>Les plans interactifs sont les vitrines du pipeline. Ils doivent refléter la réalité du terrain : travaux, fermetures, zones saturées, événements spéciaux. Le pipeline alimente ces plans en temps réel. Lorsqu’un ascenseur est indisponible, l’information apparaît immédiatement sur l’écran du hall, sur le plan tactile et sur l’application mobile. Le système propose automatiquement un itinéraire alternatif accessible. Les interfaces affichent des messages contextualisés, adaptés à la position de l’utilisateur.</p>
<p>Les écrans répartis dans le bâtiment reçoivent des flux adaptés à leur zone. Un écran situé dans une galerie commerciale peut afficher la densité des flux, les temps de parcours estimés et recommander des chemins de délestage. Un écran au sein d’un campus universitaire met en avant les salles disponibles ou les événements en cours. La clé est de maintenir une cohérence entre les différents supports pour éviter la confusion.</p>
<h3>Mettre en place des tableaux de bord pour les équipes</h3>
<p>Les équipes de gestion ont besoin d’une vision globale. Les tableaux de bord agrègent les données du pipeline pour montrer l’état du bâtiment : zones actives, incidents, flux entrants. Ces tableaux permettent d’anticiper les saturations, de déclencher des renforts, de préparer des messages ciblés. Ils conservent l’historique pour analyser les tendances : évolution des flux selon la saison, impact d’une rénovation, résultat d’un nouveau dispositif d’orientation.</p>
<p>Un tableau de bord bien conçu offre des vues spécifiques : maintenance, sécurité, accueil, mobilité. Chaque équipe retrouve les informations pertinentes sans être noyée sous les données. Des alertes paramétrables préviennent en cas d’anomalie : densité excessive, capteur inactif, incohérence entre deux sources.</p>
<h2>Tester, calibrer et documenter</h2>
<p>Le déploiement d’un pipeline spatial nécessite des phases de test. On simule des scénarios : fermeture d’un couloir, événement exceptionnel, stimulation des flux. On vérifie que les messages diffusés sont justes, que les itinéraires alternatifs sont proposés, que les délais de mise à jour sont acceptables. Les tests impliquent des utilisateurs finaux pour mesurer la compréhension et la réactivité.</p>
<p>Le pipeline évolue au gré des retours. Les paramètres sont ajustés : seuils de densité, priorités d’affichage, formats de notification. Chaque évolution est documentée pour assurer la continuité en cas de changement d’équipe. Des fiches détaillent les sources, les traitements, les responsabilités. Une formation est proposée aux opérateurs pour comprendre le fonctionnement, intervenir en cas d’incident et enrichir le système.</p>
<h3>Assurer la résilience et la maintenance</h3>
<p>Un pipeline en temps réel doit rester fiable. Des mécanismes de redondance sont prévus : serveurs de secours, stockage distribué, sauvegardes régulières. On surveille la santé des capteurs et on planifie leur maintenance. Les incidents sont enregistrés, analysés et utilisés pour améliorer la résilience.</p>
<p>Enfin, il est crucial d’évaluer l’impact sur les usagers. Des enquêtes qualitatives mesurent la perception de la signalétique et la confiance accordée aux messages en temps réel. Les résultats guident les évolutions futures et démontrent la valeur du pipeline spatial dans la transformation des espaces publics.</p>`
      }
    }
  },
  en: {
    brand: {
      name: 'danswholesaleplants'
    },
    language: {
      fr: 'FR',
      en: 'EN'
    },
    aria: {
      navToggle: 'Toggle main navigation',
      languageSwitcher: 'Switch language',
      toastDismiss: 'Close notification',
      cookieBanner: 'Cookie settings'
    },
    nav: {
      home: 'Home',
      services: 'Expertise',
      about: 'About',
      blog: 'Insights',
      faq: 'Key questions',
      contact: 'Contact'
    },
    title: {
      home: 'danswholesaleplants — Spatial orientation & digital wayfinding',
      services: 'Expertise — danswholesaleplants',
      about: 'About — danswholesaleplants',
      blog: 'Insight blog — danswholesaleplants',
      contact: 'Contact — danswholesaleplants',
      faq: 'FAQ — danswholesaleplants',
      terms: 'Terms of use — danswholesaleplants',
      privacy: 'Privacy policy — danswholesaleplants',
      cookies: 'Cookie policy — danswholesaleplants',
      refund: 'Revision policy — danswholesaleplants',
      disclaimer: 'Disclaimer — danswholesaleplants',
      thankyou: 'Thank you — danswholesaleplants',
      post1: 'Logistic mapping for university hospitals',
      post2: 'Digital signage inside intermodal hubs',
      post3: 'Pedestrian experience in municipal service centers',
      post4: 'Combining tactile and visual guidance',
      post5: 'Real-time spatial pipelines for guidance'
    },
    meta: {
      home: 'Belgian platform focused on spatial orientation, digital signage and readability in complex public environments. Studies, methods and analytics for public buildings and urban infrastructures.',
      services: 'Overview of danswholesaleplants expertise: orientation audits, interactive mapping, pedestrian flow modelling and accessibility research.',
      about: 'Discover the methodological approach of danswholesaleplants: information design, spatial UX research, public partnerships and international monitoring.',
      blog: 'In-depth analyses on interior navigation, spatial mapping, interactive plans and user journeys across built environments.',
      contact: 'Contact details in Brussels, secure form and interactive map to discuss spatial orientation and digital signage topics.',
      faq: 'Answers to frequent questions about data collection, flow modelling, deliverables and methodology.',
      terms: 'Terms regulating use of danswholesaleplants, intellectual property and responsibility over published content.',
      privacy: 'Privacy policy detailing collection, usage and storage of personal data on danswholesaleplants.',
      cookies: 'Cookie policy describing categories, measurement objectives and consent options.',
      refund: 'Revision policy explaining how adjustments and follow-up are managed at danswholesaleplants.',
      disclaimer: 'Disclaimer outlining absence of guarantee, usage limitations and informative nature of publications.',
      thankyou: 'Confirmation of your message reception and information on next steps.',
      post1: 'Analysis of logistic mapping within university hospitals to optimise journeys for visitors and staff.',
      post2: 'Study of digital signage within intermodal hubs to streamline passenger navigation.',
      post3: 'Exploration of pedestrian experience inside high-density municipal service centres.',
      post4: 'Integrating tactile and visual guidance systems across public facilities.',
      post5: 'Organising real-time spatial pipelines for adaptive guidance in shared spaces.'
    },
    footer: {
      tagline: 'Observatory of user journeys, public infrastructure and orientation flows in complex built environments.',
      contactTitle: 'Contact details',
      legalTitle: 'Legal references',
      phone: 'Phone: +32 2 586 11 90',
      email: 'Email: info@danswholesaleplants.com',
      address: '251 Avenue Louise, 1050 Brussels, Belgium',
      terms: 'Terms of use',
      privacy: 'Privacy',
      cookies: 'Cookies',
      refund: 'Revision policy',
      disclaimer: 'Disclaimer',
      rights: '© {year} danswholesaleplants. Analytical resources on spatial navigation and infrastructure readability.'
    },
    cookieBanner: {
      title: 'Cookie management',
      description: 'We use cookies to keep the site running securely, tailor interface preferences and evaluate ergonomics. You can update your choices at any time.',
      link: 'Read the cookie policy',
      buttons: {
        accept: 'Accept all',
        decline: 'Decline all',
        save: 'Save preferences'
      },
      categories: {
        necessary: {
          title: 'Essential cookies',
          description: 'Required for secure operation of the site. They cannot be disabled.'
        },
        preferences: {
          title: 'Preferences',
          description: 'Remember language selection and interface options to improve comfort.'
        },
        analytics: {
          title: 'Analytics',
          description: 'Anonymous qualitative metrics to understand journeys and adjust content.'
        },
        marketing: {
          title: 'Visibility',
          description: 'Non-personal indicators about how our publications circulate across institutional channels.'
        }
      }
    },
    form: {
      validation: 'Please complete the required fields before submitting.',
      success: 'Your message has been received. Redirecting shortly…',
      error: 'Something went wrong. Please try again in a moment.',
      toastDismiss: 'Close'
    },
    home: {
      hero: {
        badge: 'Spatial orientation',
        title: 'Map, illuminate and guide journeys through complex public environments',
        lead: 'We build analytical frameworks that make layered buildings readable, connect digital signage to real usage and orchestrate fluid journeys for every audience.',
        points: {
          first: 'Deep mapping of pedestrian networks and friction points.',
          second: 'Interface between digital, tactile and analogue signage.',
          third: 'Data-driven journey management with interactive plans.'
        },
        primaryAction: 'Explore the expertise',
        secondaryAction: 'Learn about our approach',
        imageAlt: 'Atrium of a public facility with circulation paths and signage'
      },
      featured: {
        kicker: 'Advanced diagnostics',
        title: 'Frameworks to anticipate each spatial transition',
        subtitle: 'Our tools tie architecture to visitor cognition, enabling managers to fine-tune signage, interfaces and pedestrian flows.',
        cards: {
          one: {
            title: 'Morphological building analysis',
            body: 'We observe volumes, density of intersections and hierarchy of axes to pinpoint areas where reinforced guidance is necessary.',
            pointA: 'Heatmaps showing pedestrian slowdowns.',
            pointB: 'Coupling with temporal occupancy data.',
            pointC: 'Scenarios for reallocating circulation sequences.'
          },
          two: {
            title: 'Context-aware digital signage',
            body: 'Every screen, totem or mobile interface is evaluated through the lens of real-world usage and available attention.',
            pointA: 'Modular content scripts adapted over the day.',
            pointB: 'Multilingual accessibility matrices.',
            pointC: 'Alert systems for exceptional flows.'
          },
          three: {
            title: 'User journey modelling',
            body: 'By combining observation, surveys and simulation we design robust trajectories and resilient alternative routes.',
            pointA: 'Pedestrian profiles by mission and timeframe.',
            pointB: 'Priority itineraries and redundancies.',
            pointC: 'Readability criteria and sensory cues.'
          }
        }
      },
      insights: {
        title: 'A multidisciplinary reference for public spaces',
        body: 'We blend field data, semiotics, ergonomics and urban scenography to produce reference frameworks that empower infrastructure teams.',
        list: {
          one: 'Benchmarks across more than 120 European and North American sites.',
          two: 'Visibility matrices integrating lighting, distance and approach angle.',
          three: 'Qualitative inputs: field observation, interviews, micro-surveys.'
        },
        panel: {
          title: 'Attention on friction zones',
          body: 'Entrance halls, security gates and multimodal junctions are mapped to highlight micro-decisions and pinpoint simplification levers.',
          imageAlt: 'Corridor with luminous wayfinding signage'
        }
      },
      timeline: {
        kicker: 'Method',
        title: 'A four-stage collaborative sequence',
        lead: 'Each assignment follows a cycle mixing field immersion, data visualisation and support for operating teams.',
        steps: {
          step1: {
            title: 'Immersion & collection',
            body: 'Structured observation, photographic capture and inventory of supports to stabilise a factual baseline.'
          },
          step2: {
            title: 'Mapping & modelling',
            body: 'Production of dynamic plans, usage scenarios and matrices linking flows to services.'
          },
          step3: {
            title: 'Co-design & arbitration',
            body: 'Workshops with stakeholders to prioritise signage and allocate interventions.'
          },
          step4: {
            title: 'Prototype & follow-up',
            body: 'On-site pilots, readability indicators and continuous improvement roadmap.'
          }
        },
        caption: 'The monitoring loop adapts to institutional calendars and includes accessibility checkpoints.'
      },
      recommendations: {
        kicker: 'Recommendations',
        title: 'Guidelines for intelligible spaces',
        subtitle: 'Extracts from our playbooks applied to campuses, stations, hospitals and metropolitan facilities.',
        items: {
          one: {
            title: 'Bridge macro and micro signage',
            body: 'Combine clear master plans with micro-local cues to support each transition and reduce cognitive load.'
          },
          two: {
            title: 'Synchronise physical and digital channels',
            body: 'Align information across screens, kiosks, apps and analogue supports to prevent contradictions.'
          },
          three: {
            title: 'Strengthen fallback journeys',
            body: 'Plan alternative itineraries from the outset to absorb flow disruptions or temporary closures.'
          },
          four: {
            title: 'Embed sensory accessibility',
            body: 'Cross-reference visual, tactile and auditory cues for inclusive and seamless orientation.'
          }
        }
      },
      testimonials: {
        kicker: 'Field feedback',
        title: 'Voices from our partners',
        subtitle: 'Public institutions, transport operators and site managers describe observed impacts.',
        items: {
          one: {
            quote: 'The danswholesaleplants audit clarified a sprawling hospital network. Readability is coherent again for teams and visitors.',
            author: 'Clara De Wilde',
            role: 'Innovation lead, Brussels university hospital'
          },
          two: {
            quote: 'Detailed journey analysis and alignment between screens and physical panels made multimodal transfers smoother.',
            author: 'Joeri Van Parys',
            role: 'Mobility director, regional transport operator'
          },
          three: {
            quote: 'Recommendations on layering tactile and visual guidance now underpin every campus extension we deliver.',
            author: 'Sophie Dumont',
            role: 'Major projects manager, public university'
          }
        }
      },
      knowledge: {
        title: 'Browse our spatial studies library',
        body: 'Each article documents a specific challenge: visitor journeys, flow data, contingency scenarios, tactile devices.',
        link: 'Read the latest insights'
      }
    },
    services: {
      hero: {
        badge: 'Expertise',
        title: 'Assignments tailored to decode and transform interior navigation',
        lead: 'We combine field data, information design and operational planning to make complex buildings understandable.',
        highlights: {
          first: 'Neutral, documented view on digital and physical orienting media.',
          second: 'Structured deliverables translated into decision matrices for management teams.',
          third: 'On-site follow-up and handover of produced tools.',
          imageAlt: 'Layered circulation within an institutional building'
        }
      },
      overview: {
        kicker: 'Intervention scope',
        title: 'Five complementary pillars for spatial orientation',
        subtitle: 'Activate each module independently or combine them to match your site’s needs.'
      },
      items: {
        one: {
          title: 'Orientation audit',
          body: 'Detailed mapping of tipping points, continuity gaps and alignment between architecture and signage.',
          pointA: 'Standardised photographic inventories.',
          pointB: 'Accessibility and contrast diagnostics.',
          pointC: 'Multi-temporal flow analysis.'
        },
        two: {
          title: 'Digital signage design',
          body: 'Definition of broadcast scenarios, graphic templates and editorial rules for each interactive support.',
          pointA: 'Adaptive content scripts.',
          pointB: 'Centralised update protocols.',
          pointC: 'Rapid on-site user testing.'
        },
        three: {
          title: 'Interactive mapping',
          body: 'Dynamic plans, thematic layers and consultation interfaces showing real-time space usage.',
          pointA: 'Structured spatial databases.',
          pointB: 'APIs for internal applications.',
          pointC: 'Segment-based guidance with contextual states.'
        },
        four: {
          title: 'Flow modelling',
          body: 'Simulation of pedestrian behaviour across schedules, seasons and special events.',
          pointA: 'Density and evacuation scenarios.',
          pointB: 'Comfort indicators and travel times.',
          pointC: 'Alignment with soft-mobility plans.'
        },
        five: {
          title: 'Accessibility intelligence',
          body: 'Comparative studies and recommendations on international readability and inclusion standards.',
          pointA: 'Multi-standard compliance matrices.',
          pointB: 'Coordinated multisensory devices.',
          pointC: 'Cross-border regulatory monitoring.'
        }
      },
      approach: {
        title: 'A systemic approach',
        body: 'We start from real usage and operational constraints to avoid off-the-shelf devices and create a lasting reference.',
        pointA: 'Listening to frontline teams.',
        pointB: 'On-site immersion and guided walks.',
        pointC: 'Staged sharing of design decisions.'
      },
      deliverables: {
        title: 'Structured deliverables',
        body: 'Each mission ends with actionable plans that teams can operate without heavy software dependence.',
        pointA: 'Prioritised recommendation files.',
        pointB: 'Production-ready source files.',
        pointC: 'Dashboards supporting longitudinal monitoring.'
      },
      closure: {
        title: 'Move forward with clarity',
        body: 'We document every step to transmit reproducible, scalable tools to your teams.',
        link: 'Discuss your orientation needs'
      }
    },
    about: {
      hero: {
        badge: 'About',
        title: 'A team dedicated to readability in complex environments',
        lead: 'We analyse public venues at the crossroads of urbanism, information design and behavioural sciences to propose grounded solutions.',
        points: {
          first: 'Network of specialists in architecture, design and spatial data.',
          second: 'Extended immersions within each studied infrastructure.',
          third: 'International monitoring to anticipate emerging standards.',
          imageAlt: 'Control room orchestrating signage operations'
        }
      },
      mission: {
        title: 'Our mission',
        body: 'Create environments that anyone can understand, navigate and leave without friction, regardless of individual needs.',
        pointA: 'Fine-grained understanding of pedestrian behaviour.',
        pointB: 'Continuous dialogue with site managers.',
        pointC: 'Neutral advice for every recommended arbitration.'
      },
      research: {
        title: 'Ongoing research',
        body: 'We publish syntheses, run experiments and join European programmes on pedestrian mobility.',
        pointA: 'Comparative studies across facility typologies.',
        pointB: 'Living labs inside pilot sites.',
        pointC: 'Collaboration with Belgian and French universities.'
      },
      framework: {
        kicker: 'Methodological frame',
        title: 'Structured reference points for every project',
        subtitle: 'A documented process ensures the quality and coherence of each recommendation.',
        step1: {
          title: 'Situational observation',
          body: 'Record journey sequences, existing supports and available data.'
        },
        step2: {
          title: 'Analysis & synthesis',
          body: 'Build reading grids, model flows and identify critical paths.'
        },
        step3: {
          title: 'Co-construction',
          body: 'Workshops align interventions with technical and operational constraints.'
        },
        step4: {
          title: 'Transfer & follow-up',
          body: 'Deliver operational support, targeted training and aftercare to monitor impact.'
        }
      },
      partnerships: {
        title: 'Partnerships',
        body: 'We collaborate with public bodies, architectural studios, mobility operators and user associations.',
        pointA: 'Cross-departmental working groups sharing data.',
        pointB: 'User committees gathering diverse profiles.',
        pointC: 'Framework agreements to monitor long-term transformations.'
      },
      culture: {
        title: 'Project culture',
        body: 'We foster open governance, data transparency and systematic documentation of decisions.',
        pointA: 'Real-time shared dashboards.',
        pointB: 'Accessible bilingual reporting.',
        pointC: 'Capitalisation for future extensions.'
      },
      closure: {
        title: 'A living observatory',
        body: 'Each project enriches an observatory that improves signage policies and soft mobility strategies.',
        link: 'View our expertise areas'
      }
    },
    blog: {
      hero: {
        badge: 'Insights',
        title: 'Observing and measuring readability of complex spaces',
        lead: 'Our publications gather methods, field feedback and evaluation frameworks for large-scale public venues.',
        readMore: 'Read the full study'
      },
      posts: {
        post1: {
          imageAlt: 'Master plan of a hospital showing circulation zones'
        },
        post2: {
          imageAlt: 'Intermodal hall with digital signage and passenger flows'
        },
        post3: {
          imageAlt: 'Municipal service space with counters and pedestrian lanes'
        },
        post4: {
          imageAlt: 'Corridor featuring tactile and visual wayfinding cues'
        },
        post5: {
          imageAlt: 'Real-time supervision center of a public building'
        }
      }
    },
    contact: {
      hero: {
        badge: 'Contact',
        title: 'Coordinate your wayfinding and navigation challenges',
        lead: 'A Brussels-based focal point to organise workshops, site visits and review sessions on spatial orientation topics.',
        points: {
          first: 'Tailored support for Belgian and cross-border public sites.',
          second: 'Hybrid meetings and on-site immersions according to your needs.',
          third: 'Bilingual documentation across every study phase.',
          imageAlt: 'Workshop team analysing a signage plan'
        }
      },
      details: {
        title: 'Key contact information',
        description: 'Reach out to schedule a diagnostic, share flow data or launch a pilot project.',
        addressLabel: 'Address: 251 Avenue Louise, 1050 Brussels, Belgium',
        phone: 'Phone: +32 2 586 11 90',
        email: 'Email: info@danswholesaleplants.com',
        hours: 'Hours: Monday – Friday, 9:00 to 18:00 (CET)',
        note: 'We reply within two business days with a preliminary roadmap.'
      },
      form: {
        title: 'Contact form',
        intro: 'Describe your context and spatial challenges. We will respond with methodological options.',
        fields: {
          name: {
            label: 'Full name',
            placeholder: 'Your name'
          },
          organisation: {
            label: 'Organisation',
            placeholder: 'Municipality, operator, institution…'
          },
          email: {
            label: 'Email address',
            placeholder: 'name@organisation.be'
          },
          phone: {
            label: 'Phone',
            placeholder: '+32 …'
          },
          message: {
            label: 'Message',
            placeholder: 'Outline the site, issues and timing.'
          }
        },
        notice: 'By sending this form you authorise us to use the provided information to answer your request.',
        submit: 'Send'
      },
      map: {
        title: 'Location',
        lead: 'Our office sits between Avenue Louise and King’s Garden, reachable by tram and bike.',
        frameTitle: 'Interactive map for danswholesaleplants in Brussels',
        caption: 'Main reception — entrance via Avenue Louise (Stéphanie tram stop).'
      }
    },
    faq: {
      hero: {
        badge: 'FAQ',
        title: 'Frequently asked questions',
        lead: 'We gathered recurring topics raised by project owners and operating teams.'
      },
      items: {
        q1: {
          question: 'How long does a full diagnostic take?',
          answer: 'Depending on site scale, expect four to eight weeks: immersion, data collection, modelling, workshops and reporting.'
        },
        q2: {
          question: 'Do you work exclusively in Belgium?',
          answer: 'Belgium is our main base yet we support cross-border sites with bilingual coordination.'
        },
        q3: {
          question: 'How do you handle sensitive data?',
          answer: 'Shared datasets are protected, encrypted and delivered via secure platforms with access logs.'
        },
        q4: {
          question: 'Do you integrate accessibility guidelines?',
          answer: 'Yes, we benchmark European and local standards and align visual, tactile and audio guidance.'
        },
        q5: {
          question: 'Is there post-study support?',
          answer: 'We provide quarterly reviews to measure effectiveness and update produced references.'
        },
        q6: {
          question: 'Can you collaborate with our architecture firm?',
          answer: 'Absolutely. We partner with design teams to embed findings within conception or refurbishment workflows.'
        },
        q7: {
          question: 'What deliverables do you provide?',
          answer: 'Strategic dossiers, annotated plans, content scripts, production-ready files and a monitoring roadmap.'
        },
        q8: {
          question: 'How do you collect data?',
          answer: 'We mix observation, counts, micro-interviews and document analysis to cover every usage scenario.'
        }
      },
      cta: {
        title: 'Need an answer tailored to your site?',
        body: 'Contact us to build a study program suited to your facility.',
        link: 'Write to the team'
      }
    },
    terms: {
      title: 'Terms of use',
      intro: 'These terms govern the use of danswholesaleplants.com and set mutual obligations.',
      sections: {
        section01: {
          title: '1. Purpose',
          body: 'They define the legal framework for accessing the content, tools and publications offered by danswholesaleplants.'
        },
        section02: {
          title: '2. Acceptance',
          body: 'Visiting the site implies unreserved acceptance of the applicable terms at the time of access.'
        },
        section03: {
          title: '3. Definitions',
          body: 'User stands for anyone visiting the site. Content includes texts, images, studies and downloadable resources.'
        },
        section04: {
          title: '4. Intellectual property',
          body: 'Content remains the property of danswholesaleplants or its partners. Any reproduction requires written permission.'
        },
        section05: {
          title: '5. Site access',
          body: 'The site is available around the clock except for maintenance or events beyond our control.'
        },
        section06: {
          title: '6. Permitted use',
          body: 'Content is provided for information and analysis. Any commercial exploitation or misuse is forbidden.'
        },
        section07: {
          title: '7. External contributions',
          body: 'Users must respect people and data integrity. We reserve the right to moderate submissions.'
        },
        section08: {
          title: '8. External links',
          body: 'Outbound links point to third-party resources beyond our control. We decline responsibility for their content.'
        },
        section09: {
          title: '9. Personal data',
          body: 'Collection follows our privacy policy. Users may exercise access and rectification rights.'
        },
        section10: {
          title: '10. Cookies',
          body: 'See the dedicated policy for details on cookies and consent mechanisms.'
        },
        section11: {
          title: '11. Liability',
          body: 'We strive for accuracy but cannot guarantee the absence of mistakes or omissions.'
        },
        section12: {
          title: '12. Force majeure',
          body: 'We cannot be held liable for events constituting force majeure preventing access.'
        },
        section13: {
          title: '13. Changes',
          body: 'We may adapt these terms at any time. Updates take effect upon online publication.'
        },
        section14: {
          title: '14. Governing law',
          body: 'These terms are governed by Belgian law. Disputes fall under Brussels jurisdiction.'
        }
      },
      closure: {
        title: 'Contact',
        body: 'Questions about the terms may be sent to info@danswholesaleplants.com.'
      }
    },
    privacy: {
      title: 'Privacy policy',
      intro: 'This policy explains how we collect and process personal data.',
      sections: {
        section01: {
          title: '1. Data controller',
          body: 'danswholesaleplants, 251 Avenue Louise, 1050 Brussels, acts as controller.'
        },
        section02: {
          title: '2. Data collected',
          body: 'Contact forms, anonymised navigation metrics and email exchanges represent our main sources.'
        },
        section03: {
          title: '3. Purposes',
          body: 'Data supports request handling, content improvement and quality monitoring of interactions.'
        },
        section04: {
          title: '4. Legal basis',
          body: 'Consent or legitimate interest applies depending on use. No automated canvassing is conducted.'
        },
        section05: {
          title: '5. Retention',
          body: 'Data is stored for a proportionate duration: up to three years for contact information.'
        },
        section06: {
          title: '6. Sharing',
          body: 'We do not share personal data with third parties unless legally required or technically necessary.'
        },
        section07: {
          title: '7. Data subject rights',
          body: 'You may access, rectify, erase or object. Responses are provided within thirty days.'
        },
        section08: {
          title: '8. Security',
          body: 'We apply encryption, access control and regular backups to protect information.'
        },
        section09: {
          title: '9. Cookies',
          body: 'Cookie details and settings appear in the cookie policy. Preferences can be updated via the banner.'
        },
        section10: {
          title: '10. Processors',
          body: 'Technical partners operate under strict confidentiality clauses and provide equivalent safeguards.'
        },
        section11: {
          title: '11. International transfers',
          body: 'No transfer outside the European Union occurs without adequate safeguards and prior notice.'
        },
        section12: {
          title: '12. Contact',
          body: 'To exercise your rights or ask questions, email privacy@danswholesaleplants.com.'
        }
      },
      closure: {
        title: 'Updates',
        body: 'This policy may evolve. Revisions are dated at the top of the document.'
      }
    },
    cookiesPage: {
      title: 'Cookie policy',
      intro: 'This policy explains the technologies used to measure site usage and control your preferences.',
      sections: {
        section01: {
          title: '1. Core principles',
          body: 'Cookies are limited to technical needs, linguistic preferences and anonymous qualitative measurement.'
        },
        section02: {
          title: '2. Consent',
          body: 'A banner on first visit allows you to accept, decline or customise choices.'
        },
        section03: {
          title: '3. Managing preferences',
          body: 'You may adjust options through the banner at any time or by clearing cookies in your browser.'
        },
        section04: {
          title: '4. Necessary cookies',
          body: 'They preserve sessions, security and the selected language.'
        },
        section05: {
          title: '5. Optional cookies',
          body: 'Preference, analytics and visibility cookies are enabled only with explicit consent.'
        },
        section06: {
          title: '6. Additional information',
          body: 'Questions about this policy can be sent to privacy@danswholesaleplants.com.'
        }
      },
      table: {
        title: 'Cookie inventory',
        headings: {
          name: 'Name',
          provider: 'Provider',
          type: 'Type',
          purpose: 'Purpose',
          duration: 'Duration'
        },
        rows: {
          row1: {
            name: 'site_lang',
            provider: 'danswholesaleplants',
            type: 'Essential',
            purpose: 'Retain the selected language across the site.',
            duration: '12 months'
          },
          row2: {
            name: 'cookie_consent',
            provider: 'danswholesaleplants',
            type: 'Essential',
            purpose: 'Store your consent preferences.',
            duration: '12 months'
          },
          row3: {
            name: 'pref_view',
            provider: 'danswholesaleplants',
            type: 'Preferences',
            purpose: 'Preload visual components based on your options.',
            duration: '6 months'
          },
          row4: {
            name: 'ux_metrics',
            provider: 'danswholesaleplants',
            type: 'Analytics',
            purpose: 'Anonymous navigation metrics to adjust content.',
            duration: '1 month'
          }
        },
        note: 'Optional cookies become active only after explicit agreement and can be withdrawn at any time.'
      }
    },
    refund: {
      title: 'Revision policy',
      intro: 'No commercial transactions occur on this site, yet we describe our support and correction framework.',
      sections: {
        section01: {
          title: '1. Scope',
          body: 'The policy applies to studies and deliverables produced by danswholesaleplants.'
        },
        section02: {
          title: '2. No online sales',
          body: 'No payment is processed online. Adjustments are framed by agreements signed with partners.'
        },
        section03: {
          title: '3. Correction requests',
          body: 'Partners may request corrections within thirty days after handover of deliverables.'
        },
        section04: {
          title: '4. Processing time',
          body: 'Requests are analysed within five business days to define required actions.'
        },
        section05: {
          title: '5. Limits',
          body: 'Corrections cover items defined in the initial scope of work.'
        },
        section06: {
          title: '6. New needs',
          body: 'Additional needs trigger a separate methodological proposal.'
        },
        section07: {
          title: '7. Documentation',
          body: 'Approved adjustments are recorded and shared via a change log.'
        },
        section08: {
          title: '8. Collaboration',
          body: 'We rely on detailed partner feedback to prioritise interventions.'
        },
        section09: {
          title: '9. Revised planning',
          body: 'An updated schedule is issued once adjustments are validated.'
        },
        section10: {
          title: '10. Contact',
          body: 'Questions about this policy can be sent to info@danswholesaleplants.com.'
        },
        section11: {
          title: '11. Updates',
          body: 'The document may be revised to reflect experience.'
        },
        section12: {
          title: '12. Effective date',
          body: 'Version updated on 12 January 2025.'
        }
      },
      closure: {
        title: 'Transparency',
        body: 'We value continuous dialogue to secure deliverable quality and environment readability.'
      }
    },
    disclaimer: {
      title: 'Disclaimer',
      intro: 'Content published on danswholesaleplants is informative. Final decisions require additional verification.',
      sections: {
        section01: {
          title: '1. Nature of information',
          body: 'Analyses reflect knowledge at publication date and may change without notice.'
        },
        section02: {
          title: '2. No warranty',
          body: 'We do not guarantee completeness or permanence of site information.'
        },
        section03: {
          title: '3. Liability',
          body: 'We decline responsibility for decisions taken solely on the basis of our content.'
        },
        section04: {
          title: '4. External links',
          body: 'Referenced resources are provided for context. We do not control their accuracy or availability.'
        },
        section05: {
          title: '5. Technical compatibility',
          body: 'Site access depends on your equipment configuration. Universal compatibility cannot be ensured.'
        },
        section06: {
          title: '6. Testimonials',
          body: 'Published feedback illustrates specific contexts and does not constitute a promise of outcome.'
        },
        section07: {
          title: '7. Changes',
          body: 'We may update this disclaimer to reflect evolving practices.'
        },
        section08: {
          title: '8. Contact',
          body: 'For clarifications, contact info@danswholesaleplants.com.'
        }
      },
      closure: {
        title: 'Recommendation',
        body: 'We encourage readers to compare our analyses with their own organisational context before acting.'
      }
    },
    thankyou: {
      hero: {
        badge: 'Message sent',
        title: 'Thank you for reaching out',
        body: 'We are reviewing your information and will revert quickly with a framing note or follow-up questions.',
        primaryAction: 'Return home',
        secondaryAction: 'Explore insights'
      }
    },
    blogPosts: {
      post1: {
        title: 'Logistic mapping for university hospitals',
        excerpt: 'How to model internal circulation in university hospitals to ease navigation from emergency triage to technical platforms?',
        intro: 'University hospitals layer state-of-the-art medicine, logistics and public reception. Understanding these strata is key to reducing pathway disruptions.',
        content: `<h2>Understanding the layered nature of university hospitals</h2>
<p>University hospitals concentrate emergency care, scheduled medicine, laboratories, teaching and logistics within the same footprint. Their density generates an exceptional variety of flows. Building an effective map begins with identifying families of journeys. Walk-in patients, visitors, medical staff and supply chains follow very different logics. Each family has specific start points and destinations yet they converge at the same nodes, quickly leading to congestion. The first step is to inventory these convergence nodes. Field observation evaluates corridor widths, signage height, visibility of escape routes and presence of redundant or outdated information.</p>
<p>Once nodes are captured, we analyse the vertical hierarchy. Elevators and staircases are the arteries of the hospital. In many facilities, public and professional elevators are poorly differentiated, lengthening waiting times and affecting punctuality. Clear separation with strong visual markers—contrasting colours, bilingual pictograms, luminous beacons—restores efficiency. Adding discreet audio cues supports patients who feel uneasy in complex environments.</p>
<h3>Mapping medical and logistic flows</h3>
<p>Medical and logistic flows sometimes share corridors yet their constraints differ radically. Stretchers and trolleys need unobstructed surfaces while logistic carts require large turning radiuses. To keep visitors comfortable, we recommend creating parallel technical corridors or at least dedicated time windows. The map must integrate temporal data. Dynamic plans displayed on coordination screens can show live corridor density and propose alternate routes.</p>
<p>Research units also deserve special attention. Researchers travel with sensitive material, requiring restricted zones. Signage must clearly indicate these limits to avoid accidental intrusions. Consistency is essential: a given symbol should never convey two different messages. Cohesive symbolism strengthens immediate comprehension even for non-native speakers or visitors unfamiliar with hospital codes.</p>
<h2>Segmenting journeys by care timeline</h2>
<p>A patient arriving for a scheduled consultation behaves differently from someone reaching emergency care. The former expects a calm, reassuring path with regular cues; the latter must reach a priority service without delay. Effective mapping differentiates these situations. For consultations we recommend sharing pre-visit itineraries via email with interactive maps. On site, directional beacons reuse the same graphic logic to provide continuity. For emergency care, signage must be visible from outside with universal colour codes and repeated direction arrows at every junction.</p>
<p>Care timelines also include discharge. Exit routes are often poorly signposted, forcing visitors to backtrack through confusing corridors. We suggest installing strong sight lines towards exits, combining clear pictograms and information on nearby public transport. Inpatient units need repeated reminders about support services: cafeteria, pharmacy, chapel, counselling areas. Wall-mounted maps coupled with pocket-sized simplified plans reduce stress and promote autonomy.</p>
<h3>Modelling crowding and emergency scenarios</h3>
<p>Maps cannot remain static. Hospitals handle peaks, maintenance, emergencies. Best practice is to craft scenario playbooks with fallback routes. When a wing closes, teams instantly know which replacement path to activate and which temporary signage to deploy. Digital tools simulate these scenarios to estimate additional travel time and check message consistency. Simulation drills should embed staff, since they assist visitors during disruptions.</p>
<p>Emergency situations demand seamless coordination between alert systems, luminous signage and human support. Evacuation plans must be legible at eye level. We advise offering multiple formats, including tactile or braille, plus simplified explanations in the main patient languages. Critical corridors can feature dynamic lighting pointing to safe exits. Each element requires real-world testing to guarantee effectiveness.</p>
<h2>Engaging users to refine mapping</h2>
<p>User participation is invaluable. Organising exploratory walks with patients, relatives and staff unfamiliar with the site reveals hidden issues: confusing intersections, stressful zones, signs blocked by open doors. Observations feed the mapping process to produce plans that speak to actual users. Feedback can be collected via QR codes, multilingual suggestion boxes or periodic workshops.</p>
<p>Night teams and weekend staff must also be considered. They operate in quieter yet often less supported environments. Tailored mapping—luminescent versions or mobile access—helps them locate technical rooms and resources quickly. Security officers need an updated overview: a dashboard tied to interactive plans is a powerful coordination asset.</p>
<h3>Measuring the impact of refreshed mapping</h3>
<p>After deployment, measurement is essential. We recommend monitoring time to reach critical destinations, number of questions at reception and reported disorientation incidents. Metrics are tracked over several months to confirm gains and pinpoint adjustments. Cross-analysis between qualitative and quantitative data strengthens decisions.</p>
<p>Field feedback fuels future iterations. A hospital map is a living system integrating architectural, technological and organisational changes. Sustained governance and accessible documentation ensure longevity.</p>`
      },
      post2: {
        title: 'Digital signage inside intermodal hubs',
        excerpt: 'Compare and synchronise digital devices in multimodal stations to reduce passenger uncertainty.',
        intro: 'Intermodal hubs orchestrate multiple networks simultaneously. Travellers are bombarded with information that must be precisely prioritised.',
        content: `<h2>Mapping the information ecosystem</h2>
<p>An intermodal hub brings together trains, metro, tram, buses and often bike sharing. Each operator broadcasts its own information through dedicated devices. The first challenge is to map this ecosystem: departure boards, ticket kiosks, contextual panels, mobile apps, audio announcements. The map highlights duplicates, contradictions and silent zones. It helps orchestrate broadcasts, define priorities and identify moments when travellers are most receptive.</p>
<p>Digital screens act as anchors. Their effectiveness depends on readability, content hierarchy and placement. A screen positioned after a critical decision point loses value. We recommend combining flow analysis with photometric assessment: measure brightness, contrast perception, reading distance. Content should be stacked in tiers: critical data (delays, platform), contextual data (connections, services) and comfort data (weather, direction to exits). Hierarchy must remain consistent even during disruptions.</p>
<h3>Coordinating operators and interfaces</h3>
<p>Multiple operators mean multiple visual codes and publication tools. To avoid cacophony, a shared protocol is required. It defines display rules—typefaces, alert colours, message formats—and governance, i.e. who publishes what and when. The objective is to prevent conflicting information appearing simultaneously, which destroys trust.</p>
<p>Mobile interfaces complement the system. Travellers check smartphones for platforms, itineraries or ticketing. Data shown there must match physical screens. Shared APIs should feed all channels. Once a disruption occurs, a single message spreads everywhere: screens, mobile notifications, audio. Cohesion lowers stress and erratic behaviour, especially when travellers must decide quickly.</p>
<h2>Smoothing transitions between modes</h2>
<p>Passengers often switch modes within minutes. Decisions happen at transition zones: intersections, stairways, platform entrances, street exits. These areas deserve dedicated attention. Digital signage can display contextual cues such as remaining time before departure or carriage load levels. We recommend placing reminder screens right before critical choices, featuring clean content focused on the next step.</p>
<p>Transitions must also address accessibility. Interactive screens can propose accessible routes avoiding stairs or narrow corridors. Dynamic pictograms synchronised with elevators indicate equipment availability. Coordination between digital signage and tactile guidance is essential: a user following a tactile strip should find matching information on screens.</p>
<h3>Managing disrupted conditions</h3>
<p>Intermodal hubs are sensitive to disruptions. Strikes, technical incidents or severe weather can ripple through the system. Digital devices must switch to “crisis” mode instantly. This mode simplifies displays, prioritises decisive messages and redirects flows to alternate itineraries. Control teams need intuitive consoles to trigger predefined scenarios.</p>
<p>Communication must remain coherent and repeated. Messages on screens should be echoed by audio announcements and mobile alerts. Alert pictograms must match across supports. When an alternative route is suggested, physical cues—temporary arrows, light guidance, staff orientation—must confirm it. Field experience shows travellers accept disruptions better when they perceive a consistent narrative and repeated guidance.</p>
<h2>Measuring passenger experience</h2>
<p>Deployment requires measurement. We advise installing anonymised flow sensors to visualise pathways. Data is cross-referenced with traveller feedback gathered through short surveys or on-site interviews. Indicators track connection time, service desk requests and confidence levels. Screens can display QR codes or tactile interfaces to capture real-time reactions.</p>
<p>Results feed a shared dashboard across operators. It shows key performance indicators, recent incidents and corrective actions. The dashboard fosters cooperation. If a screen is barely used or travellers keep getting lost in a specific zone, teams can plan targeted interventions: repositioning, content adjustments, extra analogue reinforcement.</p>
<h3>Anticipating future evolution</h3>
<p>Hubs constantly evolve: new lines, extensions, shifting habits. Digital signage must be a living system. Modular templates allow quick adaptation without rebuilding everything. Distribution scripts also need documentation and structured data to integrate new sources (bike or car-sharing info). Screens can pilot new services provided the established hierarchy remains.</p>
<p>Regular reviews with travellers, operators and neighbourhood associations keep everyone aligned. Meetings share upcoming projects, collect expectations and avoid misunderstandings. Digital signage is a shared language: clarity and credibility depend as much on device quality as on collective governance.</p>`
      },
      post3: {
        title: 'Pedestrian experience in municipal service centers',
        excerpt: 'Rethink circulation inside multi-purpose civic centers to cut queues and clarify citizen journeys.',
        intro: 'Municipal service centers host diverse requests. They welcome heterogeneous audiences with varying urgency daily.',
        content: `<h2>Mapping citizen journeys</h2>
<p>Municipal centers gather civil registry, housing, urban planning, commerce and social mediation. Each procedure has its workflow, documents and staff. Visitors arrive with different expectations and time budgets. The first step is to map these journeys: general reception, ticket issuance, orientation to a specialised counter, potential waiting area, interaction with an agent, document submission. Observing flows at different times reveals peak hours and pressure points.</p>
<p>Signage must reflect diversity without overwhelming visitors. Messages require hierarchy. We suggest three levels: macro markers (floors, wings, sectors), intermediate cues (counters, dedicated lines, rooms) and contextual messages (documents required, estimated timing). Supports must be easily updated. Municipal setups change frequently; flexible signage—modular inserts or lightweight screens—helps adjustment.</p>
<h3>Smoothing queues and waiting zones</h3>
<p>Queues concentrate impatience. A dual ticketing system (physical and digital) distributes flows. Screens listing ticket numbers must be legible from all waiting areas. We recommend colour coding linking each pathway to a distinct hue. The code appears on tickets, screens, panels and audio cues, so users immediately know which counter to watch.</p>
<p>Waiting areas can be segmented into micro-spaces suited to different audiences: families, seniors, citizens needing specific assistance. Gentle signage combined with adequate furniture encourages natural distribution and avoids crowding. Screens can display preparation tips: required papers, next steps, accessibility reminders. These short messages reduce counter time because visitors arrive prepared.</p>
<h2>Ensuring accessibility and inclusion</h2>
<p>A municipal center must be accessible to everyone. Visual signage is augmented with tactile and audio cues. Guidance strips lead to key desks, tactile maps at entrances present the layout, audio announcements repeat ticket numbers. Screens need high contrast and large text. Translations into the most common community languages can appear on screens or welcome leaflets.</p>
<p>Communication should anticipate vulnerable situations: limited literacy, visitors under stress. Universal pictograms are valuable. Test them with user panels to confirm understanding. Access to elevators, restrooms and privacy rooms must be signposted clearly. Avoid unannounced level changes and narrow corridors. During renovations, deploy temporary signage with precise detours and new entrances as soon as works begin.</p>
<h3>Supporting staff within the system</h3>
<p>Receptionists and advisors are frontline anchors. They require tools to orient visitors quickly. An internal dashboard showing queues, counter status and screen messages helps deliver consistent guidance. Digital signage should be easy to edit: moving a conference room or adding an exceptional service must be published instantly.</p>
<p>Training staff is as important as deploying supports. They need to grasp coding logic, trigger alert messages (evacuation for instance) and report issues. Their field feedback is invaluable: it reveals ignored panels, recurring questions and persistent blind spots.</p>
<h2>Monitoring and iterative improvement</h2>
<p>Continuous observation unlocks improvement. Track time spent at each stage, recurring questions and form errors. Collect feedback through satisfaction kiosks, online surveys or regular focus groups. Log adjustments in a shared register to preserve institutional memory.</p>
<p>Municipal centers evolve with community life. Review signage at least annually. Workshops with local associations, citizen councils and municipal teams help anticipate new demands (digital services, social programmes). Flexibility and clarity remain guiding principles.</p>
<h3>Delivering a calm experience</h3>
<p>Beyond functionality, signage shapes atmosphere. Considerate graphic design, clear messaging and readable paths show citizens that their time matters. By cutting confusion and needless queues, the municipality frees resources for complex cases and strengthens trust in public services.</p>`
      },
      post4: {
        title: 'Combining tactile and visual guidance',
        excerpt: 'Integrate tactile, visual and audio media to deliver inclusive wayfinding in public facilities.',
        intro: 'Inclusive orientation relies on coordinating multiple senses. Tactile guidance complements visual and digital supports.',
        content: `<h2>Diagnosing the existing sensory chain</h2>
<p>Many public venues rely on visual signage without ensuring that tactile and audio cues follow the same logic. Diagnosis involves walking the site with different user profiles: partially sighted visitors, distracted travellers, newcomers. Check for guidance strips, their continuity, floor contrast, pictogram coherency. Tactile information should start outside, lead to main entrances, extend through lobbies and connect with elevators, desks and exits.</p>
<p>Sensory mapping overlays each cue type. Draw tactile strips, braille plates, audio beacons, screens, panels. Look for breaks: a strip stopping before an obstacle, a tactile pictogram pointing to a poorly signposted area, an audio message unsynchronised with visuals. Such inconsistencies create confusion and risk.</p>
<h3>Designing a unified grammar</h3>
<p>After diagnosis, craft a shared grammar. Each tactile cue should match a visual cue and, if relevant, an audio cue. Define a colour, relief, texture and pictogram family. For example, reception uses dotted texture, stairs use ridged texture, lifts use linear texture. Document the grammar and share it with maintenance teams to avoid uncoordinated changes.</p>
<p>The grammar must extend to digital devices. Interactive plans require high-contrast options and voice output. Mobile apps can detect Bluetooth or NFC beacons to deliver haptic or audio guidance. Synchronisation is especially valuable in large venues such as museums, university campuses or transit stations.</p>
<h2>Running pilot pathways</h2>
<p>Before full rollout, organise pilot pathways. They test comprehension across audiences. Scenarios include finding a service desk, reaching a conference room, evacuating the building. Participants supply precise feedback. Observations feed a matrix linking cue type (tactile, visual, audio) to perceived effectiveness.</p>
<p>Pilots often reveal overlooked details: a misaligned tactile strip, a pictogram set too high, an audio cue drowned by ambient noise. Adjustments are implemented immediately. Technical teams confirm feasibility and plan maintenance.</p>
<h3>Articulating systems during emergencies</h3>
<p>Tactile-visual coordination is vital in emergencies. Guidance strips must lead to exits and assembly points. Fire doors need easily identifiable handles and relief pictograms. Audio evacuation messages should be clear, multilingual and paired with visual beacons. Documentation anticipates blocked pathways. In such cases portable lighting or temporary tactile panels can be deployed.</p>
<p>Drills must include users with visual or hearing impairments. Check whether instructions are understood, cues accessible and response teams familiar with the sensory grammar. Feedback enriches a continuous improvement plan.</p>
<h2>Training and awareness</h2>
<p>Even the best signage fails if teams do not understand it. Training sessions present the sensory grammar, explain how to maintain guidance strips, position temporary panels and support visitors. Staff learn to describe spaces verbally, offer guiding arms when requested and point to complementary resources (tactile maps, audio guides, hotline).</p>
<p>Raise awareness among external providers: cleaning companies, maintenance teams, event organisers. They must know that a guidance strip cannot be covered by carpet or temporary structures. Event organisers are encouraged to integrate the grammar into their own signage to ensure continuity.</p>
<h3>Ensuring longevity</h3>
<p>A tactile-visual system needs regular monitoring. Guidance strips wear out, pictograms get damaged, audio cues require testing. We advise annual audits to check every element, update documentation and schedule replacements. User feedback is collected through dedicated channels: braille forms, accessible phone number, dedicated email.</p>
<p>Longevity depends on traceability. Record every intervention in a log. Teams can track what changed, which materials were used and any references. This oversight keeps the system coherent over time and simplifies future work.</p>`
      },
      post5: {
        title: 'Real-time spatial pipelines for guidance',
        excerpt: 'Build data pipelines to update interactive plans in real time and optimise pedestrian mobility.',
        intro: 'Contemporary guidance relies on dynamic data streams. Reliable pipelines are essential to deliver relevant information.',
        content: `<h2>Defining data sources and governance</h2>
<p>An efficient spatial pipeline starts by identifying sources: counting sensors, access systems, mobile apps, staff inputs, anonymised cameras. Each source has its refresh rate, accuracy level and legal constraints. Governance defines who collects, validates and integrates data. A charter sets goals: improve orientation, anticipate saturation, inform visitors.</p>
<p>Confidentiality is paramount. Pipelines must comply with legal frameworks and avoid personal identification. Use aggregated or anonymised data. Incoming streams are filtered, cleaned and stored securely. A spatial database consolidates the building structure: levels, zones, routes, points of interest. It enables cross-referencing real-time data with maps to generate meaningful views.</p>
<h3>Designing the technical architecture</h3>
<p>The pipeline includes ingestion, processing, storage and distribution layers. Ingestion connects sensors and existing systems through APIs or secure connectors. Processing applies business rules: calculate zone density, detect unusual flux, identify temporary closures. Storage consolidates data in a geospatial repository. Distribution exposes services feeding interactive plans, screens, mobile apps and internal dashboards.</p>
<p>We advocate a modular architecture capable of integrating new sources without reconstruction. Messages follow a shared model: identifier, geolocation, confidence level, validity window. This structure supports simultaneous distribution across supports. During an incident, a single update keeps all devices aligned.</p>
<h2>Synchronising interactive plans and screens</h2>
<p>Interactive plans display the pipeline’s output. They must match ground reality: works, closures, crowded zones, special events. When an elevator shuts down, the information instantly appears on lobby screens, tactile plans and mobile apps. The system automatically suggests accessible alternative routes. Interfaces display contextual messages tailored to user location.</p>
<p>Screens around the building receive zone-specific feeds. In a retail arcade, screens can show density, travel times and recommended relief paths. On a university campus, they highlight available rooms or ongoing events. Consistency across devices is essential to prevent confusion.</p>
<h3>Providing dashboards for teams</h3>
<p>Management teams need an overview. Dashboards aggregate pipeline data to display building status: active zones, incidents, flow counts. They help anticipate bottlenecks, dispatch staff and prepare targeted messages. Historical data tracks trends: seasonal flow shifts, refurbishment impact, new orientation device performance.</p>
<p>Well-designed dashboards offer tailored views: maintenance, security, reception, mobility. Each team sees relevant indicators. Configurable alerts warn about anomalies: high density, inactive sensor, conflicting data.</p>
<h2>Testing, calibrating and documenting</h2>
<p>Pipelines require thorough testing. Simulate scenarios: corridor closure, special event, sudden influx. Verify message accuracy, alternative route proposals and acceptable refresh times. Include end-users to assess comprehension and response.</p>
<p>Pipelines evolve with feedback. Adjust thresholds, display priorities and notification formats. Document every change to ensure continuity. Detailed sheets describe sources, processing and responsibilities. Train operators to understand the system, handle incidents and enrich the dataset.</p>
<h3>Ensuring resilience and maintenance</h3>
<p>Real-time pipelines must remain reliable. Provide redundancy: backup servers, distributed storage, regular backups. Monitor sensor health and schedule maintenance. Log incidents, analyse them and use lessons learned to improve resilience.</p>
<p>Finally, assess the effect on users. Qualitative surveys evaluate signage perception and trust in real-time messages. Findings guide future upgrades and demonstrate the pipeline’s value in transforming public spaces.</p>`
      }
    }
  }
};

function getTranslation(lang, key) {
  const segments = key.split('.');
  let value = I18N[lang];
  for (const segment of segments) {
    if (value && Object.prototype.hasOwnProperty.call(value, segment)) {
      value = value[segment];
    } else {
      value = null;
      break;
    }
  }
  return value;
}

function applyTranslations(lang) {
  const replaceTokens = (str) => {
    if (typeof str !== 'string') return str;
    return str.replace('{year}', new Date().getFullYear().toString());
  };

  document.documentElement.lang = lang;

  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    const value = replaceTokens(getTranslation(lang, key));
    if (value !== null && value !== undefined) {
      el.textContent = value;
    }
  });

  document.querySelectorAll('[data-i18n-html]').forEach((el) => {
    const key = el.getAttribute('data-i18n-html');
    const value = getTranslation(lang, key);
    if (value !== null && value !== undefined) {
      el.innerHTML = value;
    }
  });

  document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
    const key = el.getAttribute('data-i18n-placeholder');
    const value = getTranslation(lang, key);
    if (value !== null && value !== undefined) {
      el.setAttribute('placeholder', value);
    }
  });

  document.querySelectorAll('[data-i18n-alt]').forEach((el) => {
    const key = el.getAttribute('data-i18n-alt');
    const value = getTranslation(lang, key);
    if (value !== null && value !== undefined) {
      el.setAttribute('alt', value);
    }
  });

  document.querySelectorAll('[data-i18n-aria-label]').forEach((el) => {
    const key = el.getAttribute('data-i18n-aria-label');
    const value = getTranslation(lang, key);
    if (value !== null && value !== undefined) {
      el.setAttribute('aria-label', value);
    }
  });

  document.querySelectorAll('[data-i18n-title]').forEach((el) => {
    const key = el.getAttribute('data-i18n-title');
    const value = getTranslation(lang, key);
    if (value !== null && value !== undefined) {
      el.setAttribute('title', value);
    }
  });

  document.querySelectorAll('meta[data-i18n-meta]').forEach((meta) => {
    const key = meta.getAttribute('data-i18n-meta');
    const value = getTranslation(lang, key);
    if (value !== null && value !== undefined) {
      meta.setAttribute('content', value);
    }
  });

  document.querySelectorAll('title[data-i18n]').forEach((titleEl) => {
    const key = titleEl.getAttribute('data-i18n');
    const value = getTranslation(lang, key);
    if (value !== null && value !== undefined) {
      titleEl.textContent = value;
    }
  });

  document.querySelectorAll('.lang-button').forEach((btn) => {
    const isActive = btn.dataset.lang === lang;
    btn.classList.toggle('active', isActive);
    btn.setAttribute('aria-pressed', isActive.toString());
  });
}

function initLanguage() {
  const stored = localStorage.getItem(LANGUAGE_STORAGE_KEY);
  const initial = stored && I18N[stored] ? stored : DEFAULT_LANG;
  applyTranslations(initial);

  document.querySelectorAll('.lang-button').forEach((btn) => {
    btn.addEventListener('click', () => {
      const lang = btn.dataset.lang;
      if (lang && I18N[lang]) {
        localStorage.setItem(LANGUAGE_STORAGE_KEY, lang);
        applyTranslations(lang);
      }
    });
  });
}

function initNavToggle() {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  if (!toggle || !nav) return;

  toggle.addEventListener('click', () => {
    const expanded = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', (!expanded).toString());
    nav.classList.toggle('open', !expanded);
  });

  document.querySelectorAll('.nav-menu a').forEach((link) => {
    link.addEventListener('click', () => {
      toggle.setAttribute('aria-expanded', 'false');
      nav.classList.remove('open');
    });
  });
}

function initRevealAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  document.querySelectorAll('.reveal').forEach((element) => {
    observer.observe(element);
  });
}

function createToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const text = document.createElement('span');
  text.textContent = message;
  const close = document.createElement('button');
  close.textContent = getTranslation(localStorage.getItem(LANGUAGE_STORAGE_KEY) || DEFAULT_LANG, 'form.toastDismiss') || 'Close';
  close.addEventListener('click', () => {
    container.removeChild(toast);
  });
  toast.appendChild(text);
  toast.appendChild(close);
  container.appendChild(toast);
  setTimeout(() => {
    if (container.contains(toast)) {
      container.removeChild(toast);
    }
  }, 5000);
}

function initContactForm() {
  const form = document.querySelector('.contact-form-element');
  if (!form) return;

  form.addEventListener('submit', (event) => {
    const lang = localStorage.getItem(LANGUAGE_STORAGE_KEY) || DEFAULT_LANG;
    const requiredFields = ['name', 'email', 'message'];
    const missing = requiredFields.some((name) => {
      const field = form.querySelector(`[name="${name}"]`);
      return field && !field.value.trim();
    });
    if (missing) {
      event.preventDefault();
      const message = getTranslation(lang, 'form.validation');
      createToast(message || 'Please fill required fields.', 'error');
      return;
    }
    const message = getTranslation(lang, 'form.success');
    createToast(message || 'Message received.', 'success');
  });
}

function readCookieConsent() {
  const stored = localStorage.getItem(COOKIE_STORAGE_KEY);
  if (!stored) return null;
  try {
    return JSON.parse(stored);
  } catch (error) {
    return null;
  }
}

function saveCookieConsent(state) {
  localStorage.setItem(
    COOKIE_STORAGE_KEY,
    JSON.stringify({ ...state, decidedAt: new Date().toISOString() })
  );
}

function initCookieBanner() {
  const banner = document.getElementById('cookieBanner');
  if (!banner) return;
  const toggles = banner.querySelectorAll('.cookie-toggle');

  function applyState(state) {
    toggles.forEach((toggle) => {
      const category = toggle.dataset.category;
      toggle.checked = Boolean(state && state[category]);
    });
  }

  function hideBanner() {
    banner.classList.remove('visible');
    banner.setAttribute('aria-hidden', 'true');
  }

  function showBanner() {
    banner.classList.add('visible');
    banner.removeAttribute('aria-hidden');
  }

  const stored = readCookieConsent();
  if (stored) {
    applyState(stored);
  } else {
    showBanner();
  }

  banner.querySelector('[data-cookie-action="accept"]').addEventListener('click', () => {
    const consent = {
      necessary: true,
      preferences: true,
      analytics: true,
      marketing: true
    };
    saveCookieConsent(consent);
    applyState(consent);
    hideBanner();
  });

  banner.querySelector('[data-cookie-action="decline"]').addEventListener('click', () => {
    const consent = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false
    };
    saveCookieConsent(consent);
    applyState(consent);
    hideBanner();
  });

  banner.querySelector('[data-cookie-action="save"]').addEventListener('click', () => {
    const consent = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false
    };
    toggles.forEach((toggle) => {
      consent[toggle.dataset.category] = toggle.checked;
    });
    saveCookieConsent(consent);
    hideBanner();
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initLanguage();
  initNavToggle();
  initRevealAnimations();
  initContactForm();
  initCookieBanner();

  const lang = localStorage.getItem(LANGUAGE_STORAGE_KEY) || DEFAULT_LANG;
  applyTranslations(lang);
});