document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const mainNav = document.querySelector(".main-nav");
    const scrollTopBtn = document.querySelector(".scroll-top");
    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieAcceptBtn = document.querySelector(".cookie-accept");
    const body = document.body;

    if (navToggle && mainNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            mainNav.classList.toggle("open");
            body.classList.toggle("nav-open");
        });

        mainNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navToggle.setAttribute("aria-expanded", "false");
                mainNav.classList.remove("open");
                body.classList.remove("nav-open");
                window.scrollTo({ top: 0, behavior: "smooth" });
            });
        });
    }

    const toggleScrollBtn = () => {
        if (!scrollTopBtn) return;
        if (window.scrollY > 300) {
            scrollTopBtn.style.display = "flex";
        } else {
            scrollTopBtn.style.display = "none";
        }
    };

    window.addEventListener("scroll", toggleScrollBtn);

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    const currentYearEl = document.getElementById("current-year");
    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    const COOKIE_KEY = "nomadCreativeCookieConsent";
    if (cookieBanner && cookieAcceptBtn) {
        const consent = localStorage.getItem(COOKIE_KEY);
        if (consent === "accepted") {
            cookieBanner.classList.add("hidden");
        } else {
            cookieBanner.classList.remove("hidden");
        }

        cookieAcceptBtn.addEventListener("click", () => {
            localStorage.setItem(COOKIE_KEY, "accepted");
            cookieBanner.classList.add("hidden");
        });
    }
});