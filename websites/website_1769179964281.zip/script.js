document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const navigation = document.querySelector(".main-navigation");
  if (navToggle && navigation) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      navigation.classList.toggle("is-active");
    });
    navigation.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.setAttribute("aria-expanded", "false");
        navigation.classList.remove("is-active");
      });
    });
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.25 }
  );

  document.querySelectorAll(".fade-in").forEach((el) => observer.observe(el));

  const cookieBanner = document.getElementById("cookie-banner");
  const cookieChoice = localStorage.getItem("impactvolunteers_cookie_choice");
  if (cookieBanner && !cookieChoice) {
    cookieBanner.classList.add("is-visible");
  }
  cookieBanner?.querySelectorAll("button[data-cookie-choice]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const choice = btn.getAttribute("data-cookie-choice");
      localStorage.setItem("impactvolunteers_cookie_choice", choice);
      cookieBanner.classList.remove("is-visible");
    });
  });

  const toast = document.getElementById("global-toast");
  const form = document.querySelector("form[data-redirect]");
  if (form && toast) {
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      toast.textContent = "Mesajul a fost trimis. Vei fi redirecționat în scurt timp.";
      toast.classList.add("is-active");
      setTimeout(() => {
        toast.classList.remove("is-active");
        window.location.href = form.getAttribute("data-redirect");
      }, 2000);
    });
  }

  const yearElements = document.querySelectorAll("#current-year-index");
  yearElements.forEach((el) => {
    el.textContent = String(new Date().getFullYear());
  });
});