document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');
  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      siteNav.dataset.visible = String(!isExpanded);
    });
    siteNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          navToggle.setAttribute('aria-expanded', 'false');
          siteNav.dataset.visible = 'false';
        }
      });
    });
  }
  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const storedConsent = localStorage.getItem('financialwise-cookie-consent');
    if (!storedConsent) {
      cookieBanner.classList.add('active');
    }
    cookieBanner.querySelectorAll('[data-cookie-consent]').forEach((button) => {
      button.addEventListener('click', () => {
        const value = button.dataset.cookieConsent;
        localStorage.setItem('financialwise-cookie-consent', value);
        cookieBanner.classList.remove('active');
      });
    });
  }
});