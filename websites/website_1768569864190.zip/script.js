document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    const navLinkItems = document.querySelectorAll('.nav-links a');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            const isOpen = navLinks.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });

        navLinkItems.forEach(link => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('open')) {
                    navLinks.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
        const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');
        const customizeBtn = cookieBanner.querySelector('[data-cookie="customize"]');
        const choice = localStorage.getItem('yoruCookieChoice');

        if (!choice) {
            setTimeout(() => {
                cookieBanner.classList.add('show');
            }, 600);
        }

        const hideBanner = () => cookieBanner.classList.remove('show');

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => {
                localStorage.setItem('yoruCookieChoice', 'accepted');
                hideBanner();
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => {
                localStorage.setItem('yoruCookieChoice', 'declined');
                hideBanner();
            });
        }

        if (customizeBtn) {
            customizeBtn.addEventListener('click', () => {
                window.location.href = 'cookies.html';
            });
        }
    }
});