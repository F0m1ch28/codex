import React from 'react';
import SEO from '../components/SEO';
import styles from './Terminos.module.css';

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'AeroViento Ibérica',
  'url': 'https://aeroviento.com'
};

function Terminos() {
  return (
    <>
      <SEO
        title="Condiciones de uso | AeroViento Ibérica"
        description="Consulta las condiciones de uso del sitio web de AeroViento Ibérica, plataforma española de investigación e ingeniería eólica offshore."
        canonical="https://aeroviento.com/terminos"
        jsonLd={organizationJsonLd}
      />

      <section className={styles.section}>
        <div className="container">
          <h1>Condiciones de uso</h1>
          <p>Última actualización: 15 de marzo de 2024</p>

          <h2>1. Objeto</h2>
          <p>
            El presente documento regula el acceso y utilización del sitio aeroviento.com. Al navegar
            aceptas estas condiciones. Si no estás de acuerdo, debes abstenerte de utilizar la
            plataforma.
          </p>

          <h2>2. Propiedad intelectual</h2>
          <p>
            Todos los contenidos, incluyendo textos, imágenes, diseños y código fuente, pertenecen a
            AeroViento Ibérica o a terceros con licencia. No se permite la reproducción, distribución
            o transformación sin autorización previa expresa.
          </p>

          <h2>3. Uso permitido</h2>
          <p>
            Te comprometes a utilizar el sitio conforme a la legislación vigente, la buena fe y el
            orden público. Queda prohibido cualquier uso que pueda dañar sistemas, introducir virus o
            interferir con la operativa normal.
          </p>

          <h2>4. Responsabilidad</h2>
          <p>
            Nos esforzamos por mantener la información actualizada, sin embargo, no podemos asegurar
            la ausencia de errores. El contenido tiene carácter informativo. AeroViento Ibérica no se
            responsabiliza de decisiones basadas en la información publicada.
          </p>

          <h2>5. Enlaces externos</h2>
          <p>
            Este sitio puede incluir enlaces a páginas de terceros. AeroViento Ibérica no se
            responsabiliza del contenido ni de las políticas de dichos sitios.
          </p>

          <h2>6. Modificaciones</h2>
          <p>
            Nos reservamos el derecho a actualizar estas condiciones cuando sea necesario. Las
            modificaciones se considerarán vigentes desde su publicación.
          </p>

          <h2>7. Legislación aplicable y jurisdicción</h2>
          <p>
            Estas condiciones se rigen por la legislación española. Cualquier controversia se someterá
            a los juzgados y tribunales de Madrid capital.
          </p>
        </div>
      </section>
    </>
  );
}

export default Terminos;