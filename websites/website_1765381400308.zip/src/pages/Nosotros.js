import React from 'react';
import SEO from '../components/SEO';
import styles from './Nosotros.module.css';

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'AeroViento Ibérica',
  'url': 'https://aeroviento.com',
  'logo': 'https://images.unsplash.com/photo-1451188502541-13943edb6acb?auto=format&fit=crop&w=256&q=60',
  'address': {
    '@type': 'PostalAddress',
    'streetAddress': 'Paseo de la Castellana 259C, Torre de Cristal',
    'addressLocality': 'Madrid',
    'postalCode': '28046',
    'addressCountry': 'ES'
  },
  'sameAs': ['https://www.linkedin.com']
};

const teamMembers = [
  {
    name: 'Aitana Caballero',
    role: 'Directora de Dinámica Offshore',
    bio: 'Especialista en interacción ola-viento y fondeos para turbinas flotantes.',
    image: 'https://picsum.photos/400/400?random=31'
  },
  {
    name: 'Oriol Benítez',
    role: 'Responsable de Modelado CFD',
    bio: 'Diseña mallas multiescala e integra IA para predicciones de turbulencia.',
    image: 'https://picsum.photos/400/400?random=32'
  },
  {
    name: 'Teresa Álvarez',
    role: 'Arquitecta de Datos Atmosféricos',
    bio: 'Coordina la ingestión de datos Lidar, SAR y radares meteorológicos costeros.',
    image: 'https://picsum.photos/400/400?random=33'
  },
  {
    name: 'Germán Orozco',
    role: 'Ingeniero de Integración Eléctrica',
    bio: 'Define estrategias de acoplamiento a red y microrredes híbridas viento-sol.',
    image: 'https://picsum.photos/400/400?random=34'
  }
];

const milestones = [
  {
    year: '2016',
    title: 'Creación del laboratorio aero-marinizado',
    description:
      'AeroViento Ibérica nace en Madrid para unir ingeniería estructural, meteorología costera y robótica marina.'
  },
  {
    year: '2018',
    title: 'Primer gemelo digital offshore',
    description:
      'Se despliega el gemelo híbrido del proyecto Borealis con fidelidad de cargas del 94 %.'
  },
  {
    year: '2021',
    title: 'Red académica ibérica',
    description:
      'Firmamos convenios con universidades de Bilbao, Cádiz y Barcelona para reforzar la investigación conjunta.'
  },
  {
    year: '2023',
    title: 'Oficina técnica en Torre de Cristal',
    description:
      'Nos ubicamos en el corazón financiero de Madrid para coordinar consorcios nacionales y europeos.'
  }
];

const collaborators = [
  'Universitat Politècnica de Catalunya',
  'Universidad del País Vasco',
  'Oceanic Data Iberia',
  'Centro para el Desarrollo Tecnológico Industrial',
  'Instituto Domínguez de Marina y Energía'
];

const principles = [
  {
    title: 'Respeto ecosistémico',
    description:
      'Evaluamos corrientes y hábitats marinos para integrar turbinas con corredores biológicos y migratorios.'
  },
  {
    title: 'Circularidad de materiales',
    description:
      'Materiales compuestos susceptibles de reutilización y cadenas logísticas con bajas emisiones.'
  },
  {
    title: 'Trazabilidad digital',
    description:
      'Cada elemento de la plataforma se monitoriza con sensores para asegurar integridad estructural y mantenimiento preciso.'
  }
];

function Nosotros() {
  return (
    <>
      <SEO
        title="Nuestra Visión | AeroViento Ibérica"
        description="Descubre la historia, el equipo y los principios de AeroViento Ibérica. Conectamos investigación académica y operación industrial para impulsar la energía eólica offshore desde España."
        canonical="https://aeroviento.com/nosotros"
        image="https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=1200&q=80"
        jsonLd={organizationJsonLd}
      />

      <section className={styles.hero}>
        <div className="container">
          <span className="badge">Nuestra Visión</span>
          <h1>Ingeniería, mar y datos al servicio del viento offshore</h1>
          <p>
            Somos una plataforma que combina ciencia atmosférica, arquitectura naval y analítica de
            sistemas para acelerar la transición energética azul desde la península ibérica.
          </p>
        </div>
      </section>

      <section className={styles.storySection}>
        <div className="container">
          <div className={styles.storyGrid}>
            <div className={styles.storyText}>
              <h2>Nuestra historia</h2>
              <p>
                AeroViento Ibérica surge de la necesidad de crear un ecosistema que alinee la
                investigación universitaria con la realidad del Atlántico y el Mediterráneo. Durante
                más de siete años hemos impulsado proyectos que combinan prototipado, análisis de
                datos y colaboración industrial.
              </p>
              <p>
                Las costas españolas reúnen condiciones únicas: vientos constantes, puertos
                preparados y talento científico. Transformamos ese contexto en metodologías
                replicables y escalables para parques eólicos marinos de nueva generación.
              </p>
            </div>
            <div className={styles.storyCard}>
              <img
                src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80"
                alt="Equipo de ingeniería revisando datos oceánicos"
              />
              <div className={styles.storyOverlay}>
                <p>Base Madrid · Torre de Cristal</p>
                <strong>Coordinación multiclúster</strong>
              </div>
            </div>
          </div>

          <div className={styles.timeline}>
            {milestones.map((item) => (
              <article key={item.year}>
                <span>{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.methodSection}>
        <div className="container">
          <div className={styles.methodGrid}>
            <div>
              <h2>Metodología de investigación en viento offshore</h2>
              <p>
                Trabajamos con ciclos iterativos que conectan experimentación física, modelado
                digital y pruebas en campo. Cada proyecto incorpora:
              </p>
              <ul>
                <li>Captura de datos marina y atmosférica en alta frecuencia.</li>
                <li>Modelos CFD validados con campañas de túnel de viento.</li>
                <li>Simulación de cargas extremas y diseño de fondeos resilientes.</li>
                <li>Integración de control inteligente y supervisión remota.</li>
              </ul>
            </div>
            <div className={styles.methodCard}>
              <h3>Red académica y alianzas</h3>
              <p>
                Conectamos conocimiento universitario y necesidades industriales para generar
                soluciones escalables.
              </p>
              <ul>
                {collaborators.map((partner) => (
                  <li key={partner}>{partner}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className={styles.teamHeader}>
            <h2>Equipo técnico</h2>
            <p>
              Especialistas en aerodinámica, datos y oceánica que coordinan proyectos con impacto en
              toda la península ibérica.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className="shadow-card">
                <img src={member.image} alt={member.name} />
                <div>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.principlesSection}>
        <div className="container">
          <div className={styles.principlesHeader}>
            <h2>Principios de sostenibilidad marina</h2>
            <p>
              Cada decisión técnica sigue criterios ecológicos, sociales y económicos que protegen
              el entorno marítimo y a las comunidades costeras.
            </p>
          </div>
          <div className={styles.principlesGrid}>
            {principles.map((item) => (
              <article key={item.title}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Nosotros;