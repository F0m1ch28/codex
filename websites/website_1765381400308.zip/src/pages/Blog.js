import React from 'react';
import SEO from '../components/SEO';
import styles from './Blog.module.css';

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'AeroViento Ibérica',
  'url': 'https://aeroviento.com'
};

const posts = [
  {
    title: 'Pioneros en plataformas flotantes modulares',
    excerpt:
      'Analizamos cómo los diseños modulares reducen las cargas y facilitan el mantenimiento de aerogeneradores en aguas profundas.',
    category: 'Tecnología offshore',
    date: '12 febrero 2024',
    image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
    author: 'Equipo AeroViento',
    readTime: '7 min'
  },
  {
    title: 'IA predictiva para anticipar ráfagas en el Cantábrico',
    excerpt:
      'Modelos de aprendizaje automático que combinan radar, lidar y boyas para mejorar la respuesta de control.',
    category: 'Ingeniería de turbinas',
    date: '28 enero 2024',
    image: 'https://images.unsplash.com/photo-1603022208243-874c3ccc1cdf?auto=format&fit=crop&w=1200&q=80',
    author: 'Teresa Álvarez',
    readTime: '5 min'
  },
  {
    title: 'Hibridación viento-sol en fondeos mediterráneos',
    excerpt:
      'Exploramos configuraciones flotantes que integran turbinas y fotovoltaica para garantizar entrega estable.',
    category: 'Política energética',
    date: '10 enero 2024',
    image: 'https://images.unsplash.com/photo-1497449493050-aad2f6522687?auto=format&fit=crop&w=1200&q=80',
    author: 'Germán Orozco',
    readTime: '6 min'
  }
];

const articleJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Article',
  'headline': posts[0].title,
  'description': posts[0].excerpt,
  'image': posts[0].image,
  'datePublished': '2024-02-12',
  'author': {
    '@type': 'Organization',
    'name': 'AeroViento Ibérica'
  },
  'publisher': {
    '@type': 'Organization',
    'name': 'AeroViento Ibérica',
    'logo': {
      '@type': 'ImageObject',
      'url': 'https://images.unsplash.com/photo-1451188502541-13943edb6acb?auto=format&fit=crop&w=256&q=60'
    }
  }
};

function Blog() {
  return (
    <>
      <SEO
        title="Perspectivas Eólicas | Blog de AeroViento Ibérica"
        description="Artículos sobre tecnología eólica offshore, ingeniería de turbinas y política energética desde la experiencia de AeroViento Ibérica."
        canonical="https://aeroviento.com/blog"
        image="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80"
        type="website"
        jsonLd={[organizationJsonLd, articleJsonLd]}
      />

      <section className={styles.hero}>
        <div className="container">
          <span className="badge">Perspectivas Eólicas</span>
          <h1>Ideas y análisis sobre energía eólica marina</h1>
          <p>
            Compartimos experiencias, datos y tendencias que surgen de nuestra plataforma
            tecnológica y de la colaboración con organismos públicos y privados.
          </p>
        </div>
      </section>

      <section className={styles.categoriesSection}>
        <div className="container">
          <div className={styles.categories}>
            <div>
              <h3>Tecnología offshore</h3>
              <p>Innovaciones en plataformas, fondeos y estructuras marinas.</p>
            </div>
            <div>
              <h3>Ingeniería de turbinas</h3>
              <p>Control avanzado, aerodinámica y mantenimiento inteligente.</p>
            </div>
            <div>
              <h3>Política energética</h3>
              <p>Visión regulatoria, integración con la red y oportunidades de cooperación.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.postsSection}>
        <div className="container">
          <div className={styles.postsGrid}>
            {posts.map((post) => (
              <article key={post.title} className="shadow-card">
                <img src={post.image} alt={post.title} />
                <div className={styles.postContent}>
                  <span className={styles.postCategory}>{post.category}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <div className={styles.postMeta}>
                    <span>{post.date}</span>
                    <span>•</span>
                    <span>{post.readTime}</span>
                  </div>
                  <span className={styles.postAuthor}>Por {post.author}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Blog;