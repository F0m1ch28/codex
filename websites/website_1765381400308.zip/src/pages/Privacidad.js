import React from 'react';
import SEO from '../components/SEO';
import styles from './Privacidad.module.css';

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'AeroViento Ibérica',
  'url': 'https://aeroviento.com'
};

function Privacidad() {
  return (
    <>
      <SEO
        title="Política de privacidad | AeroViento Ibérica"
        description="Conoce cómo AeroViento Ibérica trata los datos personales de acuerdo con el Reglamento General de Protección de Datos."
        canonical="https://aeroviento.com/privacidad"
        jsonLd={organizationJsonLd}
      />

      <section className={styles.section}>
        <div className="container">
          <h1>Política de privacidad</h1>
          <p>Última actualización: 15 de marzo de 2024</p>

          <h2>Responsable del tratamiento</h2>
          <p>
            AeroViento Ibérica, con sede en Paseo de la Castellana 259C, Torre de Cristal, 28046
            Madrid, Spain. Contacto: info@aeroviento.com.
          </p>

          <h2>Datos tratados</h2>
          <p>
            Tratamos los datos proporcionados de forma voluntaria a través de formularios de contacto
            o suscripción: nombre, email, empresa, temática de interés y mensajes asociados.
          </p>

          <h2>Finalidad</h2>
          <p>
            Atender solicitudes de información, coordinar colaboraciones técnicas y enviar boletines
            relacionados con energía eólica offshore.
          </p>

          <h2>Legitimación</h2>
          <p>
            El tratamiento se basa en el consentimiento otorgado al remitir los formularios. Puedes
            retirarlo en cualquier momento escribiendo a info@aeroviento.com.
          </p>

          <h2>Conservación</h2>
          <p>
            Los datos se conservarán mientras exista relación activa, se mantenga interés en recibir
            comunicaciones o hasta que solicites su supresión.
          </p>

          <h2>Destinatarios</h2>
          <p>
            No se ceden datos a terceros salvo obligación legal o colaboración técnica previamente
            autorizada por la persona interesada.
          </p>

          <h2>Derechos</h2>
          <p>
            Puedes ejercer los derechos de acceso, rectificación, supresión, limitación, oposición y
            portabilidad enviando un correo a info@aeroviento.com. También tienes derecho a presentar
            reclamación ante la Agencia Española de Protección de Datos.
          </p>

          <h2>Medidas de seguridad</h2>
          <p>
            Aplicamos medidas organizativas y técnicas para preservar la confidencialidad, integridad
            y disponibilidad de los datos personales.
          </p>
        </div>
      </section>
    </>
  );
}

export default Privacidad;