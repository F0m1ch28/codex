import React from 'react';
import SEO from '../components/SEO';
import styles from './Investigacion.module.css';

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'AeroViento Ibérica',
  'url': 'https://aeroviento.com',
  'logo': 'https://images.unsplash.com/photo-1451188502541-13943edb6acb?auto=format&fit=crop&w=256&q=60'
};

const researchLines = [
  {
    title: 'Aeronáutica aplicada al viento marítimo',
    description:
      'Caracterizamos las estelas aerodinámicas y calibramos modelos de turbulencia específicos para plataformas flotantes.'
  },
  {
    title: 'Interacción estructural marina',
    description:
      'Analizamos cargas dinámicas, fatiga multiaxial y respuesta de fondeos bajo tormentas extremas.'
  },
  {
    title: 'Planificación energética integrada',
    description:
      'Simulamos escenarios que combinan viento, solar y almacenamiento para garantizar perfiles constantes de entrega.'
  }
];

const cfdSimulations = [
  {
    name: 'CFD multiescala',
    description: 'Mallas adaptativas y LES para simular estelas en parques de alta densidad.',
    image: 'https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=1200&q=80'
  },
  {
    name: 'Acoplamiento aero-hidrodinámico',
    description: 'Modelado conjunto viento-ola en plataformas semisumergibles con cargas no lineales.',
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=1200&q=80'
  }
];

const collaborations = [
  {
    entity: 'Universidad del País Vasco',
    focus: 'Estudios de fatiga y comportamiento estructural en acero marino.'
  },
  {
    entity: 'Instituto Hidrográfico de la Marina',
    focus: 'Cartografía batimétrica y corrientes profundas para fondeos seguros.'
  },
  {
    entity: 'Centro Europeo de Energía Marina',
    focus: 'Validación de prototipos en entornos controlados y mar abierto.'
  }
];

const publications = [
  {
    title: 'Modelos de turbulencia acoplados para parques eólicos flotantes',
    year: '2023',
    source: 'Revista de Energía Marina',
    link: '#'
  },
  {
    title: 'Gemelos digitales para monitorizar vibraciones en nacelles',
    year: '2022',
    source: 'Journal of Wind Engineering',
    link: '#'
  },
  {
    title: 'Metodologías de fondeo resiliente ante oleaje extremo',
    year: '2021',
    source: 'Cuadernos de Ingeniería Oceánica',
    link: '#'
  }
];

const visualArchive = [
  {
    title: 'Mapa vectorial de ráfagas en el Cantábrico',
    image: 'https://images.unsplash.com/photo-1521207418485-99c705420785?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Simulación LES de estelas múltiples',
    image: 'https://images.unsplash.com/photo-1605721911519-3dfeb3be25e7?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Análisis estructural de torre offshore',
    image: 'https://images.unsplash.com/photo-1509395009531-51d3b419d7d8?auto=format&fit=crop&w=1200&q=80'
  }
];

function Investigacion() {
  return (
    <>
      <SEO
        title="Investigación Aplicada | AeroViento Ibérica"
        description="Conoce las líneas de investigación, simulaciones CFD y colaboraciones científicas de AeroViento Ibérica para avanzar la energía eólica offshore."
        canonical="https://aeroviento.com/investigacion"
        image="https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=1200&q=80"
        jsonLd={organizationJsonLd}
      />

      <section className={styles.hero}>
        <div className="container">
          <span className="badge">Investigación aplicada</span>
          <h1>Laboratorio de ideas para la energía eólica marina</h1>
          <p>
            Convertimos datos atmosféricos en decisiones de diseño, sumando experimentos físicos,
            simulaciones CFD y alianzas científicas.
          </p>
        </div>
      </section>

      <section className={styles.researchSection}>
        <div className="container">
          <div className={styles.researchGrid}>
            {researchLines.map((line) => (
              <article key={line.title} className="shadow-card">
                <h2>{line.title}</h2>
                <p>{line.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cfdSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Simulaciones CFD y modelado digital</h2>
            <p>
              Utilizamos recursos de cómputo de alto rendimiento para anticipar comportamientos del
              viento, la ola y las estructuras offshore.
            </p>
          </div>
          <div className={styles.cfdGrid}>
            {cfdSimulations.map((simulation) => (
              <article key={simulation.name}>
                <img src={simulation.image} alt={simulation.name} />
                <div>
                  <h3>{simulation.name}</h3>
                  <p>{simulation.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.collaborationSection}>
        <div className="container">
          <div className={styles.collaborationHeader}>
            <h2>Colaboraciones científicas</h2>
            <p>
              Trabajamos con instituciones que aportan conocimiento oceánico, atmosférico y
              estructural para consolidar soluciones confiables.
            </p>
          </div>
          <div className={styles.collaborationGrid}>
            {collaborations.map((item) => (
              <article key={item.entity}>
                <h3>{item.entity}</h3>
                <p>{item.focus}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.librarySection}>
        <div className="container">
          <div className={styles.libraryHeader}>
            <h2>Biblioteca técnica</h2>
            <p>
              Publicaciones y papers que sintetizan resultados obtenidos en proyectos piloto y
              experimentos en mar abierto.
            </p>
          </div>
          <div className={styles.libraryList}>
            {publications.map((publication) => (
              <article key={publication.title}>
                <div>
                  <h3>{publication.title}</h3>
                  <p>{publication.source}</p>
                </div>
                <span>{publication.year}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.visualSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Archivo visual</h2>
            <p>
              Mapas de viento, resultados de simulaciones y análisis estructurales que resumen el
              trabajo de campo e investigación digital.
            </p>
          </div>
          <div className={styles.visualGrid}>
            {visualArchive.map((visual) => (
              <figure key={visual.title}>
                <img src={visual.image} alt={visual.title} />
                <figcaption>{visual.title}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Investigacion;