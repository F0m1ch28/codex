import React from 'react';
import SEO from '../components/SEO';
import styles from './PoliticaCookies.module.css';

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'AeroViento Ibérica',
  'url': 'https://aeroviento.com'
};

function PoliticaCookies() {
  return (
    <>
      <SEO
        title="Política de cookies | AeroViento Ibérica"
        description="Información sobre el uso de cookies técnicas y analíticas en el sitio web de AeroViento Ibérica."
        canonical="https://aeroviento.com/politica-de-cookies"
        jsonLd={organizationJsonLd}
      />

      <section className={styles.section}>
        <div className="container">
          <h1>Política de cookies</h1>
          <p>Última actualización: 15 de marzo de 2024</p>

          <h2>¿Qué son las cookies?</h2>
          <p>
            Las cookies son pequeños archivos que se almacenan en tu dispositivo cuando navegas por
            Internet. Permiten recordar ciertas informaciones para mejorar la experiencia de uso.
          </p>

          <h2>Tipo de cookies utilizadas</h2>
          <ul>
            <li>
              <strong>Cookies técnicas:</strong> Necesarias para el funcionamiento básico del sitio.
            </li>
            <li>
              <strong>Cookies analíticas:</strong> Nos ayudan a comprender el rendimiento del sitio y
              qué contenidos resultan más útiles.
            </li>
          </ul>

          <h2>Cookies de terceros</h2>
          <p>
            Podemos utilizar servicios de analítica (por ejemplo, Google Analytics) que instalan sus
            propias cookies. Consulta sus políticas para obtener información adicional.
          </p>

          <h2>Gestión y desactivación</h2>
          <p>
            Puedes configurar tu navegador para bloquear o eliminar cookies. Sin embargo, algunas
            funcionalidades podrían verse limitadas. Consulta la ayuda de tu navegador para conocer el
            procedimiento.
          </p>

          <h2>Actualizaciones</h2>
          <p>
            Podemos actualizar esta política para reflejar cambios en las cookies utilizadas o por
            motivos legales. Recomendamos revisarla periódicamente.
          </p>

          <h2>Contacto</h2>
          <p>
            Si tienes dudas sobre el uso de cookies, escribe a{' '}
            <a href="mailto:info@aeroviento.com">info@aeroviento.com</a>.
          </p>
        </div>
      </section>
    </>
  );
}

export default PoliticaCookies;