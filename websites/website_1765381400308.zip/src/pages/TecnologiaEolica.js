import React from 'react';
import SEO from '../components/SEO';
import styles from './TecnologiaEolica.module.css';

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'AeroViento Ibérica',
  'url': 'https://aeroviento.com',
  'logo': 'https://images.unsplash.com/photo-1451188502541-13943edb6acb?auto=format&fit=crop&w=256&q=60'
};

const turbineFeatures = [
  {
    title: 'Palas biomiméticas',
    description:
      'Geometrías inspiradas en aletas marinas, optimizadas con control de borde de fuga activo.'
  },
  {
    title: 'Generadores direct drive',
    description:
      'Rendimiento elevado en bajas revoluciones con refrigeración líquida integrada y sensores térmicos.'
  },
  {
    title: 'Sistemas de pitch adaptativo',
    description:
      'Microajustes en 35 ms gracias a algoritmos predictivos alimentados por datos lidar.'
  }
];

const floatingTech = [
  {
    name: 'Plataformas semisumergibles',
    detail:
      'Configuración de líneas de amarre catenarias con amortiguación variable para oleaje atlántico.'
  },
  {
    name: 'Estructuras spar compactas',
    detail:
      'Centro de gravedad profundo que reduce balanceos, ideal para ubicaciones mediterráneas.'
  },
  {
    name: 'Tensegridad híbrida',
    detail:
      'Red de cables activos y pasivos que distribuyen cargas y permiten mantenimiento remoto.'
  }
];

const controlSystems = [
  {
    title: 'Control autónomo',
    info: 'Capas de IA para anticipar rachas y minimizar cargas en nacelle y pala.'
  },
  {
    title: 'Digital twin operativo',
    info: 'Modelos sincronizados con datos en vivo para ensayar escenarios extremos.'
  },
  {
    title: 'Ciberseguridad marítima',
    info: 'Protocolos zero-trust e intercambio cifrado entre nodos SCADA.'
  }
];

const roboticMaintenance = [
  {
    title: 'Drones marinos',
    text: 'Inspección de bases y líneas de amarre con visión estereoscópica.'
  },
  {
    title: 'Robots trepadores',
    text: 'Revisión de palas sin detener el aerogenerador gracias a anclajes magnéticos.'
  },
  {
    title: 'Sensórica integrada',
    text: 'Fibra óptica distribuida para detectar microfisuras y cargas anómalas.'
  }
];

const dataPanel = [
  {
    metric: 'Velocidad media anual',
    value: '11.6 m/s',
    detail: 'Ventanas de 10 minutos · Boias profundas'
  },
  {
    metric: 'Factor de capacidad',
    value: '54 %',
    detail: 'Escenarios híbridos con almacenamiento térmico'
  },
  {
    metric: 'Nivel de vibración',
    value: '0.23 g',
    detail: 'Promedio en nacelle · Análisis 24h'
  },
  {
    metric: 'Integración a red',
    value: '4.8 GW',
    detail: 'Proyectos en desarrollo 2025-2028'
  }
];

function TecnologiaEolica() {
  return (
    <>
      <SEO
        title="Tecnología Eólica Offshore | AeroViento Ibérica"
        description="Explora las turbinas de nueva generación, plataformas flotantes y sistemas inteligentes desarrollados por AeroViento Ibérica para la energía eólica marina."
        canonical="https://aeroviento.com/tecnologia-eolica"
        image="https://images.unsplash.com/photo-1603984174778-0a6169d46f2d?auto=format&fit=crop&w=1200&q=80"
        jsonLd={organizationJsonLd}
      />

      <section className={styles.hero}>
        <div className="container">
          <span className="badge">Sistemas & Innovación</span>
          <h1>Tecnologías que redefinen la energía eólica offshore</h1>
          <p>
            Desde turbinas adaptativas hasta plataformas flotantes y control autónomo: cada módulo se
            diseña para responder a las condiciones exigentes del Atlántico y el Mediterráneo.
          </p>
        </div>
      </section>

      <section className={styles.turbinesSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Turbinas de nueva generación</h2>
            <p>
              Arquitectura modular con sistemas inteligentes que garantizan estabilidad, potencia y
              mantenimiento predictivo en mar abierto.
            </p>
          </div>
          <div className={styles.turbineGrid}>
            {turbineFeatures.map((feature) => (
              <article key={feature.title} className="shadow-card">
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.floatingSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Tecnologías de flotación y fondeo</h2>
            <p>
              Soluciones desarrolladas con modelos de oleaje y análisis de cargas cíclicas para
              asegurar el desempeño de los aerogeneradores flotantes.
            </p>
          </div>
          <div className={styles.floatingGrid}>
            {floatingTech.map((tech) => (
              <article key={tech.name}>
                <h3>{tech.name}</h3>
                <p>{tech.detail}</p>
              </article>
            ))}
          </div>
          <div className={styles.floatImage}>
            <img
              src="https://images.unsplash.com/photo-1503792070985-b414709577cc?auto=format&fit=crop&w=1400&q=80"
              alt="Plataformas flotantes en operación"
            />
          </div>
        </div>
      </section>

      <section className={styles.controlSection}>
        <div className="container">
          <div className={styles.controlGrid}>
            <div>
              <h2>Sistemas inteligentes de control</h2>
              <p>
                Capas de software que conectan sensores, algoritmos y gemelos digitales para tomar
                decisiones en tiempo real.
              </p>
              <img
                src="https://images.unsplash.com/photo-1618005198919-d3d4b5a92eee?auto=format&fit=crop&w=1200&q=80"
                alt="Panel de control inteligente para turbinas"
              />
            </div>
            <div className={styles.controlCards}>
              {controlSystems.map((control) => (
                <article key={control.title}>
                  <h3>{control.title}</h3>
                  <p>{control.info}</p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.roboticsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Robótica de mantenimiento</h2>
            <p>
              Sistemas automatizados que reducen tiempos de parada y permiten inspecciones seguras en
              condiciones marinas exigentes.
            </p>
          </div>
          <div className={styles.roboticsGrid}>
            {roboticMaintenance.map((robot) => (
              <article key={robot.title}>
                <h3>{robot.title}</h3>
                <p>{robot.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.integrationSection}>
        <div className="container">
          <div className={styles.integrationGrid}>
            <div>
              <h2>Integración en la red energética</h2>
              <p>
                Proyectamos escenarios de despacho coordinado y almacenamiento híbrido que facilitan
                la estabilidad del sistema eléctrico español.
              </p>
              <ul>
                <li>Sincronización dinámica con la red de transporte.</li>
                <li>Acoplamiento con plantas solares costeras para perfiles planos.</li>
                <li>Modelos de almacenamiento térmico y baterías marinas.</li>
              </ul>
            </div>
            <div className={styles.integrationImage}>
              <img
                src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80"
                alt="Subestación eléctrica conectada a parques offshore"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.hybridSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Proyectos híbridos viento + sol</h2>
            <p>
              Desarrollamos sinergias que combinan generación marina con fotovoltaica flotante, para
              entregar perfiles constantes y predecibles.
            </p>
          </div>
          <div className={styles.hybridCard}>
            <div>
              <h3>Plataformas híbridas Atlantic Sun</h3>
              <p>
                Flotadores multifunción capaces de alojar turbinas eólicas y paneles fotovoltaicos
                bifaciales, con almacenamiento térmico integrado.
              </p>
              <ul>
                <li>Optimización del factor de capacidad.</li>
                <li>Gestión térmica de excedentes energéticos.</li>
                <li>Supervisión remota y mantenimiento coordinado.</li>
              </ul>
            </div>
            <img
              src="https://images.unsplash.com/photo-1497449493050-aad2f6522687?auto=format&fit=crop&w=1200&q=80"
              alt="Render de plataforma híbrida con turbinas y paneles solares"
            />
          </div>
        </div>
      </section>

      <section className={styles.dataPanelSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Panel técnico de datos en operación</h2>
            <p>
              Indicadores clave de los proyectos piloto monitorizados por nuestro sistema digital.
            </p>
          </div>
          <div className={styles.dataPanelGrid}>
            {dataPanel.map((item) => (
              <article key={item.metric}>
                <header>
                  <h3>{item.metric}</h3>
                  <span>{item.value}</span>
                </header>
                <p>{item.detail}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default TecnologiaEolica;