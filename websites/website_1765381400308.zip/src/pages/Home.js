import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import styles from './Home.module.css';

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'AeroViento Ibérica',
  'url': 'https://aeroviento.com',
  'logo': 'https://images.unsplash.com/photo-1451188502541-13943edb6acb?auto=format&fit=crop&w=256&q=60',
  'contactPoint': {
    '@type': 'ContactPoint',
    'telephone': '+34 910 52 78 43',
    'contactType': 'Research Coordination',
    'areaServed': 'ES',
    'availableLanguage': ['es', 'en']
  },
  'address': {
    '@type': 'PostalAddress',
    'streetAddress': 'Paseo de la Castellana 259C, Torre de Cristal',
    'addressLocality': 'Madrid',
    'postalCode': '28046',
    'addressCountry': 'ES'
  }
};

const stats = [
  { value: '12', label: 'modelos atmosféricos validados' },
  { value: '28', label: 'campañas oceanográficas activas' },
  { value: '640 km', label: 'de costa monitorizada por sensores' },
  { value: '96 %', label: 'disponibilidad de datos en tiempo real' }
];

const markers = [
  { name: 'Golfo de Cádiz', left: '18%', top: '62%', status: 'fase piloto' },
  { name: 'Estrecho de Gibraltar', left: '22%', top: '68%', status: 'modelado CFD' },
  { name: 'Costa da Morte', left: '31%', top: '28%', status: 'prototipo flotante' },
  { name: 'Cantábrico Oriental', left: '57%', top: '24%', status: 'análisis estructural' },
  { name: 'Delta del Ebro', left: '72%', top: '55%', status: 'sensores lidar' }
];

const projectMonitor = [
  {
    title: 'Proyecto Borealis',
    progress: 78,
    status: 'Integración de red',
    description:
      'Sistema híbrido viento-sol con gestión flexible para la cornisa cantábrica.'
  },
  {
    title: 'Azimut Atlántico',
    progress: 64,
    status: 'Simulación CFD',
    description:
      'Validación de aerogeneradores flotantes con control activo anti-fatiga.'
  },
  {
    title: 'Cymba Mediterránea',
    progress: 52,
    status: 'Diseño de fondeo',
    description:
      'Plataforma semisumergible optimizada para olas largas en el arco mediterráneo.'
  }
];

const galleryItems = [
  {
    title: 'Plataformas semisumergibles',
    image:
      'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Análisis de vórtices en pala',
    image:
      'https://images.unsplash.com/photo-1521207418485-99c705420785?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Monitorización lidar offshore',
    image:
      'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1200&q=60'
  },
  {
    title: 'CFD de estelas múltiples',
    image:
      'https://images.unsplash.com/photo-1603984174778-0a6169d46f2d?auto=format&fit=crop&w=1200&q=80'
  }
];

const innovations = [
  {
    title: 'Perfiles adaptativos en tiempo real',
    description:
      'Ajuste dinámico de pitch mediante gemelos digitales que anticipan turbulencias marinas.'
  },
  {
    title: 'Control sensorial multi-nodo',
    description:
      'Arquitectura IoT con fusión de datos lidar, radar y satélite para decisiones de operación.'
  },
  {
    title: 'Flotas autónomas de inspección',
    description:
      'Robótica marina y aérea coordinada para mantenimiento predictivo en parques flotantes.'
  }
];

const windInsights = [
  {
    label: 'Índice de cizalladura atlántica',
    value: 68,
    change: '+4,2 pp',
    description: 'Incremento moderado gracias a patrones térmicos primaverales.'
  },
  {
    label: 'Disponibilidad anual simulada',
    value: 92,
    change: '+1,7 pp',
    description: 'Escenarios out-of-the-box comparados con datos históricos de la AEMET.'
  },
  {
    label: 'Reducción de fatiga en pala',
    value: 37,
    change: '-3,1 pp',
    description: 'Control activo de flaps en turbinas flotantes de nueva generación.'
  }
];

const processSteps = [
  {
    title: '1. Captación atmosférica',
    text: 'Red de radares y boyas inteligentes que capturan régimen de vientos y oleaje.'
  },
  {
    title: '2. Modelado digital',
    text: 'CFD multiescala con validación en túneles de viento y datos satelitales.'
  },
  {
    title: '3. Integración operativa',
    text: 'Sistemas SCADA y análisis predictivo para entrega constante al sistema eléctrico.'
  }
];

const testimonials = [
  {
    quote:
      'Los modelos de AeroViento Ibérica nos permitieron ajustar la orientación de las plataformas flotantes con precisión centimétrica.',
    name: 'María Lobera',
    role: 'Coordinadora Offshore, Red de Energía Cantábrica'
  },
  {
    quote:
      'La colaboración ha acelerado la evaluación de cargas cíclicas y extendido la vida útil de nuestras turbinas en mar abierto.',
    name: 'Jordi Matas',
    role: 'Director Técnico, Consorcio Eólico Mediterráneo'
  }
];

const faqItems = [
  {
    question: '¿Cómo se valida la fiabilidad de los modelos atmosféricos?',
    answer:
      'Combina datos in situ, observaciones satelitales y campañas de túnel de viento. Cada modelo se recalibra mensualmente con métricas de precisión y backtesting regional.'
  },
  {
    question: '¿Qué diferencia a la plataforma frente a un SCADA convencional?',
    answer:
      'Integra analítica de dominio marino y aerodinámico en un único entorno que enlaza CFD, gemelos digitales y supervisión marina autónoma.'
  },
  {
    question: '¿Cómo se gestiona la integración con la red eléctrica española?',
    answer:
      'Se trabajan escenarios de despacho coordinado con Red Eléctrica, incluyendo perfiles híbridos viento-sol y almacenamiento térmico asociado.'
  }
];

function Home() {
  const [email, setEmail] = useState('');
  const [feedback, setFeedback] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!email || !email.includes('@')) {
      setFeedback('Introduce un correo profesional válido.');
      return;
    }
    setFeedback('Gracias. Te contactaremos con los próximos briefs técnicos.');
    setEmail('');
  };

  return (
    <>
      <SEO
        title="AeroViento Ibérica | Ingeniería del Viento Offshore"
        description="Investigación avanzada en energía eólica offshore desde España. Simulaciones CFD, plataformas flotantes y analítica atmosférica para el futuro de la energía azul."
        canonical="https://aeroviento.com/"
        image="https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1200&q=80"
        jsonLd={organizationJsonLd}
      />

      <section className={styles.hero}>
        <div className={`${styles.heroInner} container`}>
          <div className={styles.heroText}>
            <div className="badge">Plataforma WindTech Research</div>
            <h1>
              Ingeniería del viento para el <span>nuevo horizonte offshore</span>
            </h1>
            <p>
              Desde Madrid impulsamos conocimiento situacional, prototipos flotantes y control
              inteligente de parques marinos. Analizamos cada corriente atmosférica y cada nudo de
              oleaje para maximizar el rendimiento de los aerogeneradores en aguas profundas.
            </p>
            <div className={styles.heroActions}>
              <Link className={styles.primaryButton} to="/tecnologia-eolica">
                Explorar innovación técnica
              </Link>
              <Link className={styles.secondaryButton} to="/investigacion">
                Ver investigación aplicada
              </Link>
            </div>
            <div className={styles.heroMetrics}>
              <div>
                <span>+4.8 PB</span>
                <p>de datos atmosféricos procesados</p>
              </div>
              <div>
                <span>27</span>
                <p>patentes colaborativas con la red europea</p>
              </div>
            </div>
          </div>
          <div className={styles.heroMedia}>
            <div className="gradient-border">
              <img
                src="https://images.unsplash.com/photo-1603988363607-e1e4a66962c8?auto=format&fit=crop&w=1100&q=80"
                alt="Turbinas eólicas offshore en el Atlántico"
              />
              <div className={styles.heroOverlay}>
                <p>Febrero · Cantábrico</p>
                <strong>Ráfagas controladas a 14 m/s</strong>
                <span>Equipo Lidar 360° · 4 nodos sincronizados</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className="container">
          <h2>Indicadores clave de nuestra plataforma marina</h2>
          <div className={styles.statsGrid}>
            {stats.map((item) => (
              <article key={item.label} className={styles.statCard}>
                <h3>{item.value}</h3>
                <p>{item.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.mapSection}>
        <div className="container">
          <div className={styles.mapHeader}>
            <h2>Cartografía de parques offshore monitorizados</h2>
            <p>
              Visualiza la distribución de proyectos en la península. Cada punto integra datos de
              viento, oleaje y grid management para acelerar las decisiones de ingeniería.
            </p>
          </div>
          <div className={styles.mapWrapper}>
            <img
              src="https://images.unsplash.com/photo-1522898467493-49726bf287ec?auto=format&fit=crop&w=1400&q=80"
              alt="Mapa conceptual de costas españolas con parques eólicos"
            />
            {markers.map((marker) => (
              <button
                type="button"
                key={marker.name}
                className={styles.mapMarker}
                style={{ left: marker.left, top: marker.top }}
              >
                <span>{marker.name}</span>
                <small>{marker.status}</small>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.monitorSection}>
        <div className="container">
          <div className={styles.monitorHeader}>
            <span className="badge">Monitor offshore</span>
            <h2>Seguimiento en tiempo real de proyectos estratégicos</h2>
            <p>
              Cada programa combina sensores, simulaciones y análisis estructural para anticipar
              escenarios operativos en mar abierto.
            </p>
          </div>
          <div className={styles.monitorGrid}>
            {projectMonitor.map((project) => (
              <article key={project.title} className="shadow-card">
                <header>
                  <h3>{project.title}</h3>
                  <p>{project.status}</p>
                </header>
                <p>{project.description}</p>
                <div className={styles.progressBar}>
                  <div style={{ width: `${project.progress}%` }} />
                </div>
                <span className={styles.progressValue}>{project.progress}% modelado</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.gallerySection}>
        <div className="container">
          <div className={styles.galleryHeader}>
            <h2>Galería técnica de proyectos en curso</h2>
            <p>
              Desde fondeos semisumergibles hasta drones marinos, mostramos las fases que definen los
              avances en ingeniería eólica offshore.
            </p>
          </div>
          <div className={styles.galleryGrid}>
            {galleryItems.map((item) => (
              <figure key={item.title}>
                <img src={item.image} alt={item.title} />
                <figcaption>{item.title}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.innovationSection}>
        <div className="container">
          <div className={styles.innovationHeader}>
            <span className="badge">Innovación aerodinámica</span>
            <h2>Soluciones que reconfiguran la ingeniería marina</h2>
            <p>
              Diseñamos y validamos módulos inteligentes que reducen vibraciones, mejoran el control
              y optimizan la captura energética.
            </p>
          </div>
          <div className={styles.innovationGrid}>
            {innovations.map((item) => (
              <article key={item.title}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.dataSection}>
        <div className="container">
          <div className={styles.dataHeader}>
            <h2>Visualización de datos de viento y operación</h2>
            <p>
              Monitoreamos indicadores clave para elevar la estabilidad energética y mitigar cargas
              en estructuras offshore.
            </p>
          </div>
          <div className={styles.dataGrid}>
            {windInsights.map((insight) => (
              <article key={insight.label}>
                <div className={styles.dataValue}>
                  <span>{insight.value}</span>
                  <small>{insight.change}</small>
                </div>
                <h3>{insight.label}</h3>
                <div className={styles.dataBar}>
                  <div style={{ width: `${insight.value}%` }} />
                </div>
                <p>{insight.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.processHeader}>
            <h2>Nuestro flujo de ingeniería marina</h2>
            <p>
              Desde la captura atmosférica hasta la entrega en red, cada fase de trabajo se sustenta
              en datos de alta resolución.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.title}>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialSection}>
        <div className="container">
          <div className={styles.testimonialHeader}>
            <span className="badge">Testimonios</span>
            <h2>Colaboraciones que impulsan la energía azul</h2>
          </div>
          <div className={styles.testimonialGrid}>
            {testimonials.map((item) => (
              <blockquote key={item.name}>
                <p>{item.quote}</p>
                <footer>
                  <strong>{item.name}</strong>
                  <span>{item.role}</span>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.faqHeader}>
            <h2>Preguntas frecuentes sobre la plataforma</h2>
            <p>
              Resolvemos las cuestiones más habituales de los equipos de ingeniería y operación en
              parques offshore.
            </p>
          </div>
          <div className={styles.faqGrid}>
            {faqItems.map((item) => (
              <details key={item.question}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.newsletterSection}>
        <div className="container">
          <div className="gradient-border">
            <div className={styles.newsletterCard}>
              <div>
                <h2>Suscríbete al briefing mensual de AeroViento</h2>
                <p>
                  Actualizaciones sobre viento offshore, dinámica estructural, robótica marina y
                  coordinación energética.
                </p>
              </div>
              <form onSubmit={handleSubmit}>
                <label className="sr-only" htmlFor="newsletter-email">
                  Correo electrónico
                </label>
                <input
                  id="newsletter-email"
                  type="email"
                  placeholder="tuemail@empresa.com"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                />
                <button type="submit">Unirme al briefing</button>
                {feedback && <span>{feedback}</span>}
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Home;