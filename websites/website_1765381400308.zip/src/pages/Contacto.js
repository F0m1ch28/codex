import React, { useState } from 'react';
import SEO from '../components/SEO';
import styles from './Contacto.module.css';

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  'name': 'AeroViento Ibérica',
  'url': 'https://aeroviento.com',
  'contactPoint': {
    '@type': 'ContactPoint',
    'telephone': '+34 910 52 78 43',
    'contactType': 'Soporte técnico'
  },
  'address': {
    '@type': 'PostalAddress',
    'streetAddress': 'Paseo de la Castellana 259C, Torre de Cristal',
    'addressLocality': 'Madrid',
    'postalCode': '28046',
    'addressCountry': 'ES'
  }
};

function Contacto() {
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    tema: '',
    mensaje: ''
  });
  const [status, setStatus] = useState('');

  const handleChange = (event) => {
    setFormData((prevData) => ({
      ...prevData,
      [event.target.name]: event.target.value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.nombre || !formData.email || !formData.tema || !formData.mensaje) {
      setStatus('Por favor completa todos los campos.');
      return;
    }
    if (!formData.email.includes('@')) {
      setStatus('Introduce un correo válido.');
      return;
    }
    setStatus('Recibido. El equipo de AeroViento se pondrá en contacto contigo.');
    setFormData({
      nombre: '',
      email: '',
      tema: '',
      mensaje: ''
    });
  };

  return (
    <>
      <SEO
        title="Conecta con AeroViento | Contacto"
        description="Contacta con AeroViento Ibérica para coordinación de proyectos eólicos offshore, investigación y colaboraciones técnicas."
        canonical="https://aeroviento.com/contacto"
        image="https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=1200&q=80"
        jsonLd={organizationJsonLd}
      />

      <section className={styles.hero}>
        <div className="container">
          <span className="badge">Contacto</span>
          <h1>Conecta con el equipo de AeroViento</h1>
          <p>
            Coordinamos proyectos de investigación, pruebas offshore y despliegues industriales.
            Cuéntanos tu iniciativa y encontremos sinergias.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.contactGrid}>
            <div className={styles.infoCard}>
              <h2>Información de contacto</h2>
              <p>Paseo de la Castellana 259C, Torre de Cristal, 28046 Madrid, Spain</p>
              <p>
                Teléfono:{' '}
                <a href="tel:+34910527843" className={styles.link}>
                  +34 910 52 78 43
                </a>
              </p>
              <p>
                Email:{' '}
                <a href="mailto:info@aeroviento.com" className={styles.link}>
                  info@aeroviento.com
                </a>
              </p>
              <div className={styles.mapWrapper}>
                <img
                  src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80"
                  alt="Mapa estático de Madrid señalando Torre de Cristal"
                />
                <span>Coordenadas · Torre de Cristal</span>
              </div>
            </div>
            <form className={styles.formCard} onSubmit={handleSubmit}>
              <h2>Escríbenos</h2>
              <label htmlFor="nombre">Nombre</label>
              <input
                id="nombre"
                name="nombre"
                type="text"
                value={formData.nombre}
                onChange={handleChange}
                placeholder="Nombre y apellidos"
              />

              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="correo@empresa.com"
              />

              <label htmlFor="tema">Tema</label>
              <input
                id="tema"
                name="tema"
                type="text"
                value={formData.tema}
                onChange={handleChange}
                placeholder="Interés o proyecto"
              />

              <label htmlFor="mensaje">Mensaje</label>
              <textarea
                id="mensaje"
                name="mensaje"
                rows="6"
                value={formData.mensaje}
                onChange={handleChange}
                placeholder="Describe tus objetivos y el contexto del proyecto."
              />

              <button type="submit">Enviar mensaje</button>
              {status && <p className={styles.status}>{status}</p>}
            </form>
          </div>
        </div>
      </section>
    </>
  );
}

export default Contacto;