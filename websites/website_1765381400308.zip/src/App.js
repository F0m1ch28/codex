import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import styles from './App.module.css';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import Home from './pages/Home';
import Nosotros from './pages/Nosotros';
import TecnologiaEolica from './pages/TecnologiaEolica';
import Investigacion from './pages/Investigacion';
import Blog from './pages/Blog';
import Contacto from './pages/Contacto';
import Terminos from './pages/Terminos';
import Privacidad from './pages/Privacidad';
import PoliticaCookies from './pages/PoliticaCookies';

function App() {
  return (
    <Router>
      <div className={styles.app}>
        <Header />
        <main className={styles.main}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/nosotros" element={<Nosotros />} />
            <Route path="/tecnologia-eolica" element={<TecnologiaEolica />} />
            <Route path="/investigacion" element={<Investigacion />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/contacto" element={<Contacto />} />
            <Route path="/terminos" element={<Terminos />} />
            <Route path="/privacidad" element={<Privacidad />} />
            <Route path="/politica-de-cookies" element={<PoliticaCookies />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <ScrollToTop />
      </div>
    </Router>
  );
}

export default App;