import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const quickLinks = [
  { path: '/', label: 'Ingeniería del Viento' },
  { path: '/nosotros', label: 'Nuestra Visión' },
  { path: '/tecnologia-eolica', label: 'Sistemas & Innovación' },
  { path: '/investigacion', label: 'Investigación Aplicada' },
  { path: '/blog', label: 'Perspectivas Eólicas' }
];

const resources = [
  { label: 'Términos legales', path: '/terminos' },
  { label: 'Privacidad', path: '/privacidad' },
  { label: 'Política de cookies', path: '/politica-de-cookies' }
];

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={`${styles.inner} container`}>
        <div className={styles.brandBlock}>
          <div className={styles.logo}>
            <span className={styles.logoMark}>A</span>
            <div>
              <p className={styles.logoName}>AeroViento Ibérica</p>
              <p className={styles.logoTagline}>
                Plataforma española de investigación e ingeniería eólica marina.
              </p>
            </div>
          </div>
          <div className={styles.contact}>
            <p>Paseo de la Castellana 259C, Torre de Cristal, 28046 Madrid, Spain</p>
            <a href="tel:+34910527843">+34 910 52 78 43</a>
            <a href="mailto:info@aeroviento.com">info@aeroviento.com</a>
          </div>
        </div>

        <div className={styles.columns}>
          <div>
            <h4>Explora</h4>
            <nav>
              {quickLinks.map((item) => (
                <Link key={item.path} to={item.path}>
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
          <div>
            <h4>Documentos</h4>
            <nav>
              {resources.map((item) => (
                <Link key={item.path} to={item.path}>
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
          <div>
            <h4>Actualizaciones</h4>
            <p>
              Recibe boletines sobre modelado atmosférico, ingeniería marina y
              analítica de turbinas.
            </p>
            <Link className={styles.subscribe} to="/contacto">
              Solicitar contacto
            </Link>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <div className="container">
          <p>© {new Date().getFullYear()} AeroViento Ibérica. Energía eólica offshore desde España.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;