import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Ingeniería del Viento' },
  { path: '/nosotros', label: 'Nuestra Visión' },
  { path: '/tecnologia-eolica', label: 'Sistemas & Innovación' },
  { path: '/investigacion', label: 'Investigación' },
  { path: '/blog', label: 'Perspectivas' },
  { path: '/contacto', label: 'Contacto' }
];

function Header() {
  const [open, setOpen] = useState(false);

  const handleToggle = () => setOpen((prev) => !prev);
  const handleClose = () => setOpen(false);

  return (
    <header className={styles.header}>
      <div className={`${styles.inner} container`}>
        <NavLink to="/" className={styles.logo} onClick={handleClose}>
          <span className={styles.logoMark}>A</span>
          <span className={styles.logoText}>AeroViento Ibérica</span>
        </NavLink>
        <nav className={`${styles.nav} ${open ? styles.open : ''}`}>
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={handleClose}
              className={({ isActive }) =>
                isActive ? `${styles.link} ${styles.active}` : styles.link
              }
            >
              {item.label}
            </NavLink>
          ))}
          <NavLink
            to="/tecnologia-eolica"
            className={`${styles.link} ${styles.highlight}`}
            onClick={handleClose}
          >
            Plataforma Técnica
          </NavLink>
        </nav>
        <button
          className={styles.burger}
          type="button"
          onClick={handleToggle}
          aria-label="Abrir menú"
          aria-expanded={open}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
}

export default Header;