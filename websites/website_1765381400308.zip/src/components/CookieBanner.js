import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem('av-cookies');
    if (stored !== 'accepted') {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('av-cookies', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="region" aria-label="Aviso de cookies">
      <div className={styles.content}>
        <p>
          Utilizamos cookies técnicas y analíticas para mejorar la experiencia de investigación.
          Al continuar, aceptas el uso responsable de estos datos.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={handleAccept}>
            Aceptar
          </button>
          <Link to="/politica-de-cookies">Más información</Link>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;