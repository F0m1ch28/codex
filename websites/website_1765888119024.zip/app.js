```javascript
document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const isOpen = navMenu.getAttribute('data-open') === 'true';
      navMenu.setAttribute('data-open', String(!isOpen));
      navToggle.setAttribute('aria-expanded', String(!isOpen));
    });

    navMenu.addEventListener('click', (event) => {
      if (event.target.tagName === 'A' && navMenu.getAttribute('data-open') === 'true') {
        navMenu.setAttribute('data-open', 'false');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
    const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
    const storageKey = 'auroraCookieConsent';

    try {
      const existing = localStorage.getItem(storageKey);
      if (!existing) {
        cookieBanner.setAttribute('data-visible', 'true');
      }

      const closeBanner = (choice) => {
        localStorage.setItem(storageKey, choice);
        cookieBanner.setAttribute('data-visible', 'false');
      };

      if (acceptBtn) {
        acceptBtn.addEventListener('click', () => closeBanner('accepted'));
      }

      if (declineBtn) {
        declineBtn.addEventListener('click', () => closeBanner('declined'));
      }
    } catch (err) {
      cookieBanner.setAttribute('data-visible', 'true');
    }
  }
});
```