```php
<?php
function sanitize($key) {
    return htmlspecialchars(trim($_POST[$key] ?? ''), ENT_QUOTES, 'UTF-8');
}

$name = sanitize('name');
$email = sanitize('email');
$company = sanitize('company');
$phone = sanitize('phone');
$message = sanitize('message');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You | Aurora Solar Canada</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="canonical" href="https://www.aurorasolarcanada.com/thanks.php">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='16' fill='%233498DB'/%3E%3Cpath d='M20 44L32 16l12 28' stroke='%23F39C12' stroke-width='6' stroke-linecap='round' stroke-linejoin='round' fill='none'/%3E%3Ccircle cx='32' cy='44' r='6' fill='%23F39C12'/%3E%3C/svg%3E">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to main content</a>
  <header class="site-header">
    <div class="header-inner">
      <a class="brand" href="index.html">
        <span class="brand-icon">AS</span>
        Aurora Solar Canada
      </a>
      <button class="nav-toggle" aria-expanded="false" aria-controls="primary-navigation" aria-label="Toggle navigation">☰</button>
      <nav id="primary-navigation" class="nav-menu" data-open="false">
        <a href="index.html">Home</a>
        <a href="solutions.html">Solutions</a>
        <a href="technology.html">Technology</a>
        <a href="case-studies.html">Case Studies</a>
        <a href="consulting.html">Consulting</a>
        <a href="faq.html">FAQ</a>
        <a href="contact.html" aria-current="page">Contact</a>
        <a href="terms.html">Terms</a>
        <a href="privacy.html">Privacy</a>
      </nav>
    </div>
  </header>

  <main id="main-content">
    <section class="section" style="padding-top:6rem;">
      <div class="container">
        <div class="card">
          <h1 class="section-title" style="font-size:2.2rem;">Thank You, <?php echo $name ? $name : 'Colleague'; ?>!</h1>
          <p>We have received your message<?php echo $company ? " from $company" : ''; ?>. A member of the Aurora Solar Canada team will reach out to <?php echo $email ? $email : 'the provided contact'; ?> soon.</p>
          <?php if ($message): ?>
            <div style="margin-top:1.5rem;">
              <h2 style="font-size:1.3rem;">Summary of Your Message</h2>
              <p><?php echo nl2br($message); ?></p>
            </div>
          <?php endif; ?>
          <div class="hero-actions" style="margin-top:2rem;">
            <a class="btn btn-primary" href="index.html">Return to Home</a>
            <a class="btn btn-secondary" href="solutions.html">Explore Solutions</a>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="page-footer">
    <div class="footer-inner">
      <div class="footer-top">
        <div>
          <div class="brand">
            <span class="brand-icon">AS</span>
            Aurora Solar Canada
          </div>
          <p style="max-width:320px;">Intelligent control systems engineered for Canadian solar farms, uniting monitoring, diagnostics, and optimization.</p>
        </div>
        <div>
          <h4>Navigation</h4>
          <div class="footer-nav">
            <a href="index.html">Home</a>
            <a href="solutions.html">Solutions</a>
            <a href="technology.html">Technology</a>
            <a href="case-studies.html">Case Studies</a>
            <a href="consulting.html">Consulting</a>
            <a href="faq.html">FAQ</a>
          </div>
        </div>
        <div>
          <h4>Contact</h4>
          <div class="footer-nav">
            <span>Brookfield Place, 181 Bay Street, Suite 2500<br>Toronto, ON M5J 2T3, Canada</span>
            <span>Phone: <a href="tel:+16475550199">+1 647 555 0199</a></span>
            <a href="contact.html">Contact Form</a>
            <a href="privacy.html">Privacy</a>
            <a href="terms.html">Terms</a>
          </div>
        </div>
      </div>
      <div class="footer-meta">
        <span>© <span id="current-year">2024</span> Aurora Solar Canada. All rights reserved.</span>
        <span>Designed for accessibility and WCAG AA alignment.</span>
      </div>
    </div>
  </footer>

  <div class="cookie-banner" role="dialog" aria-modal="false" aria-live="polite">
    <p>We use essential analytics to refine solar monitoring experiences. You can accept or decline optional analytics storage.</p>
    <div class="cookie-actions">
      <button type="button" class="cookie-decline" data-cookie-decline>Decline</button>
      <button type="button" class="cookie-accept" data-cookie-accept>Accept</button>
    </div>
  </div>

  <script src="app.js"></script>
  <script>document.getElementById('current-year').textContent = new Date().getFullYear();</script>
</body>
</html>
```