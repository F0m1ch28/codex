(function () {
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.querySelector(".primary-nav");

    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const isOpen = navToggle.classList.toggle("is-open");
            primaryNav.classList.toggle("is-open", isOpen);
            navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
        });

        primaryNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navToggle.classList.remove("is-open");
                primaryNav.classList.remove("is-open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieAccept = document.querySelector(".cookie-actions a.accept");
    const cookieDecline = document.querySelector(".cookie-actions a.decline");
    const cookieKey = "icp_cookie_consent";

    const hideCookieBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.add("is-hidden");
        }
    };

    const setCookieConsent = (value) => {
        try {
            localStorage.setItem(cookieKey, value);
        } catch (error) {
            console.warn("Cookie consent storage unavailable", error);
        }
    };

    const getCookieConsent = () => {
        try {
            return localStorage.getItem(cookieKey);
        } catch (error) {
            console.warn("Cookie consent retrieval failed", error);
            return null;
        }
    };

    if (cookieBanner && getCookieConsent()) {
        hideCookieBanner();
    }

    const consentHandler = (event, value) => {
        event.preventDefault();
        setCookieConsent(value);
        hideCookieBanner();
        window.location.href = event.currentTarget.getAttribute("href");
    };

    if (cookieAccept) {
        cookieAccept.addEventListener("click", (event) => consentHandler(event, "accepted"));
    }

    if (cookieDecline) {
        cookieDecline.addEventListener("click", (event) => consentHandler(event, "declined"));
    }

    const contactForm = document.querySelector("#contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            contactForm.classList.add("is-submitting");
            setTimeout(() => {
                window.location.href = "thanks.html";
            }, 500);
        });
    }

    const searchInput = document.querySelector("#post-search");
    const filterButtons = document.querySelectorAll(".filter-btn");
    const postCards = document.querySelectorAll("[data-category]");
    let activeCategory = "all";

    const applyFilters = () => {
        const query = searchInput ? searchInput.value.trim().toLowerCase() : "";
        postCards.forEach(card => {
            const matchesCategory = activeCategory === "all" || card.dataset.category === activeCategory;
            const textContent = card.textContent.toLowerCase();
            const matchesSearch = !query || textContent.includes(query);
            card.style.display = matchesCategory && matchesSearch ? "" : "none";
        });
    };

    if (searchInput) {
        searchInput.addEventListener("input", applyFilters);
    }

    filterButtons.forEach(button => {
        button.addEventListener("click", () => {
            activeCategory = button.dataset.filter;
            filterButtons.forEach(btn => btn.classList.toggle("is-active", btn === button));
            applyFilters();
        });
    });
})();