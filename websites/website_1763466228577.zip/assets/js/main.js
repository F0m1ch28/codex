document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const mainNav = document.querySelector('.main-nav');
    const scrollBtn = document.querySelector('.scroll-to-top');
    const consentBanner = document.querySelector('.cookie-banner');
    const consentButton = document.getElementById('acceptCookies');
    const currentYear = document.getElementById('current-year');
    const navLinks = document.querySelectorAll('.main-nav a, .footer-links a, .logo, .footer-logo');
    const contactForm = document.getElementById('contactForm');

    // Current year in footer
    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }

    // Mobile navigation toggle
    if (navToggle && mainNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            mainNav.classList.toggle('open');
        });
    }

    // Close mobile nav on link click and scroll top
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (mainNav.classList.contains('open')) {
                mainNav.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    // Scroll to top button
    window.addEventListener('scroll', () => {
        if (window.scrollY > 400) {
            scrollBtn.classList.add('show');
        } else {
            scrollBtn.classList.remove('show');
        }
    });

    if (scrollBtn) {
        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Cookie consent
    if (consentBanner && consentButton) {
        const consentKey = 'nlaCookieConsent';
        const consent = localStorage.getItem(consentKey);

        if (!consent) {
            consentBanner.classList.add('show');
        }

        consentButton.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'accepted');
            consentBanner.classList.remove('show');
        });
    }

    // Contact form validation
    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();

            const name = contactForm.querySelector('#name');
            const email = contactForm.querySelector('#email');
            const message = contactForm.querySelector('#message');
            const response = contactForm.querySelector('#formResponse');

            let valid = true;

            if (name.value.trim() === '') {
                document.getElementById('nameError').textContent = 'Please enter your name.';
                valid = false;
            } else {
                document.getElementById('nameError').textContent = '';
            }

            if (email.value.trim() === '') {
                document.getElementById('emailError').textContent = 'Please enter your email.';
                valid = false;
            } else if (!/^\S+@\S+\.\S+$/.test(email.value.trim())) {
                document.getElementById('emailError').textContent = 'Please provide a valid email address.';
                valid = false;
            } else {
                document.getElementById('emailError').textContent = '';
            }

            if (message.value.trim() === '') {
                document.getElementById('messageError').textContent = 'Please include a brief message.';
                valid = false;
            } else {
                document.getElementById('messageError').textContent = '';
            }

            if (valid) {
                response.textContent = 'Thank you for reaching out. We will respond shortly.';
                contactForm.reset();
                setTimeout(() => {
                    response.textContent = '';
                }, 6000);
            }
        });
    }
});