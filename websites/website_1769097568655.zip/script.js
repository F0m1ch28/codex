document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navigation = document.querySelector('.main-navigation');

  if (navToggle && navigation) {
    navToggle.addEventListener('click', () => {
      navToggle.classList.toggle('is-open');
      navigation.classList.toggle('is-open');
    });

    navigation.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        navToggle.classList.remove('is-open');
        navigation.classList.remove('is-open');
      });
    });
  }

  const animateItems = document.querySelectorAll('[data-animate]');
  const intersectionObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          intersectionObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );

  animateItems.forEach((item) => intersectionObserver.observe(item));

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const getConsent = () => {
      try {
        return window.localStorage.getItem('cookieConsent');
      } catch (error) {
        return null;
      }
    };

    const setConsent = (value) => {
      try {
        window.localStorage.setItem('cookieConsent', value);
      } catch (error) {
        // storage might be unavailable
      }
    };

    const consent = getConsent();
    if (consent) {
      cookieBanner.classList.add('banner-hidden');
    } else {
      cookieBanner.classList.add('banner-visible');
    }

    const acceptButton = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineButton = cookieBanner.querySelector('[data-cookie="decline"]');

    const hideBanner = (value) => {
      setConsent(value);
      cookieBanner.classList.remove('banner-visible');
      cookieBanner.classList.add('banner-hidden');
    };

    if (acceptButton) {
      acceptButton.addEventListener('click', () => hideBanner('accepted'));
    }

    if (declineButton) {
      declineButton.addEventListener('click', () => hideBanner('declined'));
    }
  }

  const toast = document.querySelector('.global-toast');
  let toastTimeout;

  const showToast = (message) => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('is-visible');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
      toast.classList.remove('is-visible');
    }, 2200);
  };

  const forms = document.querySelectorAll('form[data-form="contact"]');
  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      showToast('Message noted. Redirecting to confirmation...');
      const target = form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        window.location.href = target;
      }, 1600);
    });
  });

  const yearElement = document.getElementById('currentYear');
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }
});