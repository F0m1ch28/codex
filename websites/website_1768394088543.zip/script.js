document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieButtons = document.querySelectorAll('.cookie-button');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            const isOpen = navLinks.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('is-open')) {
                    navLinks.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth > 1024) {
                navLinks.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    if (cookieBanner) {
        const cookiePreference = localStorage.getItem('popkdzqCookieConsent');
        if (!cookiePreference) {
            cookieBanner.classList.add('is-active');
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', () => {
                const action = button.getAttribute('data-action');
                if (action === 'accept') {
                    localStorage.setItem('popkdzqCookieConsent', 'accepted');
                    cookieBanner.classList.remove('is-active');
                } else if (action === 'decline') {
                    localStorage.setItem('popkdzqCookieConsent', 'declined');
                    cookieBanner.classList.remove('is-active');
                } else if (action === 'preferences') {
                    window.location.href = 'cookies.html';
                }
            });
        });
    }
});