document.addEventListener("DOMContentLoaded", () => {
  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.getElementById("site-menu");
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen);
      navToggle.classList.toggle("is-open", isOpen);
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
    const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
    const storageKey = "rbluser-cookie-preference";
    const preference = localStorage.getItem(storageKey);

    const hideBanner = () => {
      cookieBanner.classList.remove("is-visible");
      setTimeout(() => {
        cookieBanner.hidden = true;
      }, 300);
    };

    if (!preference) {
      cookieBanner.hidden = false;
      requestAnimationFrame(() => cookieBanner.classList.add("is-visible"));
    }

    acceptBtn?.addEventListener("click", () => {
      localStorage.setItem(storageKey, "accepted");
      hideBanner();
    });

    declineBtn?.addEventListener("click", () => {
      localStorage.setItem(storageKey, "declined");
      hideBanner();
    });
  }

  const form = document.querySelector("[data-validate]");
  if (form) {
    const feedback = form.querySelector(".form-feedback");
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const name = form.name.value.trim();
      const email = form.email.value.trim();
      const message = form.message.value.trim();
      const consent = form.querySelector("#consent").checked;

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!name || !email || !message || !consent) {
        feedback.textContent = "Please complete all fields and consent to continue.";
        feedback.style.color = "#f97316";
        return;
      }
      if (!emailPattern.test(email)) {
        feedback.textContent = "Please enter a valid email address.";
        feedback.style.color = "#f97316";
        return;
      }
      feedback.textContent = "Thank you! Our team will be in touch shortly.";
      feedback.style.color = "#22c55e";
      form.reset();
    });
  }
});