const DEFAULT_LANG = "fr";
const LANG_STORAGE_KEY = "site_lang";
const COOKIE_STORAGE_KEY = "cookie_consent";
const CURRENT_YEAR = new Date().getFullYear();

const translationsEn = {
  meta: {
    index: {
      title: "danswholesaleplants | Spatial orientation intelligence",
      description: "Bilingual research collective documenting digital wayfinding, signage ecologies, and spatial orientation across Belgium's public environments."
    },
    services: {
      title: "Service lines for spatial orientation research | danswholesaleplants",
      description: "Overview of six analytical service lines covering diagnostics, digital mapping, and accessibility reviews for complex buildings across Belgium."
    },
    about: {
      title: "About danswholesaleplants | Spatial orientation research collective",
      description: "History, mission, and values of danswholesaleplants, a Brussels collective studying spatial orientation systems."
    },
    blog: {
      title: "Blog | danswholesaleplants spatial orientation insights",
      description: "Long-form articles exploring wayfinding, pedestrian mobility, and spatial UX within public environments."
    },
    contact: {
      title: "Contact danswholesaleplants | Spatial orientation collective",
      description: "Connect with danswholesaleplants to discuss spatial orientation challenges, collaborations, and accessibility goals."
    },
    faq: {
      title: "FAQ | danswholesaleplants",
      description: "Frequently asked questions about our wayfinding research process, documentation formats, and collaboration cadence."
    },
    terms: {
      title: "Terms of use | danswholesaleplants",
      description: "Terms of use governing danswholesaleplants content, referencing research scope, intellectual property, and limitations."
    },
    privacy: {
      title: "Privacy notice | danswholesaleplants",
      description: "Privacy notice outlining how danswholesaleplants handles personal data, analytics preferences, storage, and user rights."
    },
    cookies: {
      title: "Cookie policy | danswholesaleplants",
      description: "Cookie policy describing functional, preference, and analytics cookies used by danswholesaleplants."
    },
    refund: {
      title: "Refund policy | danswholesaleplants",
      description: "Refund policy clarifying non-commercial status and responses to content correction requests."
    },
    disclaimer: {
      title: "Disclaimer | danswholesaleplants",
      description: "Disclaimer explaining the informational nature of publications, absence of guarantees, and user responsibilities."
    },
    thankYou: {
      title: "Thank you | danswholesaleplants",
      description: "Confirmation page acknowledging successful contact form submission."
    },
    post1: {
      title: "Temporal layering for cultural districts | danswholesaleplants",
      description: "Analysis of temporal wayfinding strategies supporting evening programmes in cultural districts."
    },
    post2: {
      title: "Tactile interfaces for multimodal hubs | danswholesaleplants",
      description: "Assessment of tactile orientation interfaces supporting travellers inside multimodal transport hubs."
    },
    post3: {
      title: "Evaluating interactive campus maps | danswholesaleplants",
      description: "Framework for evaluating digital campus maps across kiosks, mobile devices, and seasonal programming."
    },
    post4: {
      title: "Governance frameworks for signage in public buildings | danswholesaleplants",
      description: "Guidance on establishing governance models that keep public building signage coherent over time."
    },
    post5: {
      title: "Legibility metrics for urban promenades | danswholesaleplants",
      description: "Methodology for measuring promenade legibility through landmarks, behaviour, and sensory cues."
    }
  },
  global: {
    siteName: "danswholesaleplants",
    tagline: "Spatial orientation intelligence",
    address: "Rue de la Loi 155, 1040 Bruxelles, Belgium",
    phone: "+32 2 403 12 87",
    email: "info@danswholesaleplants.com"
  },
  header: {
    skipLink: "Skip to content",
    mobileMenuLabel: "Toggle navigation",
    languageToggleLabel: "Select language",
    lang: {
      fr: "Français",
      en: "English"
    },
    nav: {
      home: "Home",
      services: "Services",
      about: "About",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact"
    }
  },
  footer: {
    addressTitle: "Address",
    address: "Rue de la Loi 155, 1040 Bruxelles, Belgium",
    phone: "Phone: +32 2 403 12 87",
    email: "Email: info@danswholesaleplants.com",
    navigate: "Legal",
    terms: "Terms",
    privacy: "Privacy",
    cookies: "Cookies",
    refund: "Refund Policy",
    disclaimer: "Disclaimer",
    copy: "© {year} danswholesaleplants. Spatial orientation insight collective."
  },
  home: {
    heroEyebrow: "Field notes from complex environments",
    heroTitle: "Mapping clarity across complex spatial ecosystems",
    heroSubtitle: "danswholesaleplants documents the craft of digital wayfinding, aligning architectural narratives, data layers, and pedestrian expectations to ensure every journey remains legible.",
    heroCtaPrimary: "Discover our analytical scope",
    heroCtaSecondary: "Browse recent field notes",
    heroFigureCaption: "Digital interpretive layer mapped onto the Parc Léopold civic ensemble.",
    heroImageAlt: "Composite visualization of indoor and outdoor wayfinding overlays",
    featureSectionTitle: "Interlacing architecture and information",
    featureSectionIntro: "We explore how signage systems, digital directories, and cartographic platforms can be orchestrated to deliver cohesive guidance inside interconnected venues.",
    features: [
      {
        title: "Context-aware digital layers",
        body: "We assemble orientation layers that respond to volumetric conditions, daylight, and circulation bottlenecks, enabling people to read spaces through situational cues."
      },
      {
        title: "Pedestrian behaviour dashboards",
        body: "Real-time pedestrian traces, aggregated from sensors and observation, reveal sequence disruptions, queuing pressure, and thresholds where messaging must adapt."
      },
      {
        title: "Accessible narrative frameworks",
        body: "Inclusive typographies, multilingual phrasing, and icon systems are assessed to support diverse cognitive models without overloading attention."
      }
    ],
    orientationHeading: "Navigational ecosystems observed",
    orientationIntro: "Each site we document blends architectural constraints with behavioural expectations. The snapshots below illustrate domains currently under review.",
    orientation: {
      items: [
        {
          title: "Transit interchanges in flux",
          body: "Layered bus, tram, and rail operations require choreographed signage that anticipates arrival surges while preserving calm for wayfinding decisions."
        },
        {
          title: "Civic campuses in transition",
          body: "Expanding administrative clusters demand connective journeys between historic wings and contemporary annexes, supported by digital beacons."
        },
        {
          title: "Museum circuits after dusk",
          body: "Evening programming reshapes circulation priorities, prompting adaptive light levels and media walls to anchor visitor orientation."
        }
      ]
    },
    recommendations: {
      title: "Recommendations evolving from field analysis",
      intro: "Observational campaigns convert into actionable briefs. These highlights summarise ongoing guidance developed with public stewards.",
      items: [
        {
          title: "Structure hybrid signage families",
          body: "Integrate static placemaking elements with responsive displays to offer both certainty and adaptability for visitors."
        },
        {
          title: "Rehearse intuitive detours",
          body: "Model temporary reroutes and clearly narrate them through a unified voice, ensuring maintenance or security shifts remain legible."
        },
        {
          title: "Embed tactile anchors",
          body: "Install textured surfaces, handrail cues, and ground lighting to support multisensory navigation without visual overload."
        },
        {
          title: "Measure dwell time ethically",
          body: "Capture flow metrics through privacy-preserving tooling so that insights inform layout choices without isolating individuals."
        }
      ]
    },
    testimonials: {
      title: "Testimonials from collaborating teams",
      subtitle: "Voices from planners, curators, and mobility researchers reflect on shared learnings.",
      items: [
        {
          quote: "The orientation playbooks produced with danswholesaleplants helped our tram hub project bridge historic signage with new digital kiosks.",
          author: "Lucie Verstraeten",
          role: "Mobility programme lead, STIB Observatory"
        },
        {
          quote: "Their cartographic audits reshaped how we narrate collections between galleries and public plazas.",
          author: "Jasper De Wilde",
          role: "Spatial storytelling curator, Brussels Urban Museum"
        },
        {
          quote: "They interrogate data with empathy, translating flows into actionable design rituals.",
          author: "Amélie De Smet",
          role: "Pedestrian experience researcher, Greentrack"
        }
      ]
    },
    metrics: {
      title: "Metrics framing our documentation",
      intro: "Each indicator illustrates the breadth of spaces surveyed and the depth of iterative analysis.",
      items: [
        { value: "18", label: "Site audits documented since 2019" },
        { value: "42 km", label: "Indoor-outdoor path segments traced" },
        { value: "260+", label: "Stakeholder interviews synthesised" },
        { value: "12", label: "Multilingual signage toolkits benchmarked" }
      ]
    },
    caseStudies: {
      title: "In-depth studies currently circulating",
      intro: "We publish annotated dossiers to allow teams to compare scenarios.",
      items: [
        {
          title: "North Brussels multimodal concourse",
          body: "A layered scheme connecting tram residual spaces with metro corridors using responsive iconography."
        },
        {
          title: "Canal-side civic forum",
          body: "Spatial scripts choreographing movement between municipal counters, libraries, and open-air terraces."
        },
        {
          title: "Museum quarter night pathways",
          body: "Light, projection, and ground cues aligning late programming with safe, legible routes."
        }
      ]
    },
    closing: {
      title: "Continuously iterating with public stewards",
      body: "Our documentation remains open to critique. We invite teams to question findings, contribute new observations, and co-create the next wave of orientation experiments.",
      cta: "Learn about our research cadence",
      imageAlt: "Analytical sketch of an urban grid illuminated for night navigation"
    }
  },
  services: {
    heroTitle: "Service lines for spatial orientation research",
    heroIntro: "Our work orbits six complementary strands that reveal how people interpret complex environments and how guidance systems can adapt.",
    heroImageAlt: "Researcher reviewing digital wayfinding overlays on a tablet device",
    list: [
      {
        title: "Orientation challenge diagnostics",
        body: "We dissect building typologies, circulation nodes, and user stories to detect where orientation fails. Field sketches, video walkthroughs, and stakeholder interviews create a shared evidence base for improvement. Each insight is mapped to spatial coordinates so decision makers can see friction layered onto floorplans.",
        points: [
          "Friction heatmaps for arrival, transfer, and departure journeys.",
          "Narrative logs capturing emotions and cues perceived by visitors."
        ]
      },
      {
        title: "Wayfinding design principles",
        body: "We compile design playbooks aligning static signage, digital media, and architectural gestures. Principles balance clarity with character so interventions reinforce existing identities rather than overwrite them.",
        points: [
          "Hierarchy matrices covering typography, iconography, and language.",
          "Scenario scripts rehearsing detours, closures, and temporary events."
        ]
      },
      {
        title: "Interactive mapping development",
        body: "We prototype map experiences that translate site-specific knowledge into adaptive interfaces. Workshops define dataset governance, while usability labs validate clarity across screen types.",
        points: [
          "Wireframes and clickable prototypes for kiosks and mobile devices.",
          "Data dictionaries defining layers, update frequency, and moderation roles."
        ]
      },
      {
        title: "Pedestrian experience research",
        body: "Mobility diaries, GPS traces, and participatory walks expose how people improvise routes. Findings highlight where to reinforce or redirect flows without forcing compliance.",
        points: [
          "Behavioural indicators comparing planned versus improvised routes.",
          "Comfort and confidence indexes segmented by visitor profiles."
        ]
      },
      {
        title: "Accessibility standards consulting",
        body: "We audit compliance with European accessibility directives, focusing on clarity for diverse sensory and cognitive needs. Recommendations emphasise inclusive narratives rather than checklist compliance.",
        points: [
          "Multisensory cue inventories covering tactile, audio, and visual prompts.",
          "Design adjustments prioritising contrast, pace, and cognitive load."
        ]
      },
      {
        title: "Wayfinding infrastructure evaluations",
        body: "Existing signage families, fixtures, and digital nodes are evaluated for durability, tone, and alignment with current programmes. We stage future-state simulations to test resilience.",
        points: [
          "Asset condition reports with lifecycle projections.",
          "Gap analyses between physical fixtures and digital updates."
        ]
      }
    ],
    methodology: {
      title: "Methodology anchors",
      body: "Every assignment combines quantitative mapping with qualitative storytelling. Our process remains transparent so partners can replicate insights independently.",
      steps: [
        {
          title: "Immerse",
          body: "We embed with staff, observe routines, and document base conditions across multiple timeframes."
        },
        {
          title: "Model",
          body: "Data streams convert into layered diagrams visualising flows, sightlines, and acoustic envelopes."
        },
        {
          title: "Prototype",
          body: "We stage temporary interventions, from pop-up signage to interactive prompts, recording reactions."
        },
        {
          title: "Reflect",
          body: "Debriefs with stakeholders consolidate learnings into actionable roadmaps."
        }
      ]
    },
    collaboration: {
      title: "Collaboration cadence",
      body: "Working groups meet biweekly to review findings, ensuring adjustments remain co-authored and context-aware."
    },
    deliverables: {
      title: "Deliverables without transactions",
      body: "Our outputs—atlases, scripts, and audit logs—are shared openly with civic partners, encouraging reuse across public networks."
    },
    tools: {
      title: "Toolbox snapshot",
      body: "The following instruments appear frequently in our documentation.",
      items: [
        "Layered GIS basemaps integrating indoor circulation and public realm.",
        "Observation matrices linking behaviours to environmental triggers.",
        "Accessibility conformance scorecards cross-referencing EU directives.",
        "Narrative storyboards illustrating visitor emotions along journeys."
      ]
    },
    callout: {
      title: "Ripple effects",
      body: "When space stewards engage with these tools, they report calmer visitor flows, clearer staff coordination, and a renewed sense of shared stewardship."
    }
  },
  about: {
    heroTitle: "Tracing the evolution of danswholesaleplants",
    heroSubtitle: "A Brussels-based collective documenting spatial orientation systems across public infrastructures. Our lens merges architectural literacy with UX research.",
    heroImageAlt: "Team members mapping circulation lines over architectural plans",
    mission: {
      title: "Mission",
      body: "We maintain a living archive of wayfinding analysis so public institutions can understand, critique, and evolve their navigation systems."
    },
    vision: {
      title: "Vision",
      body: "We envision public environments where guidance feels intuitive, inclusive, and reflective of local narratives."
    },
    approach: {
      title: "Approach",
      body: "Every project pairs immersive fieldwork with analytical synthesis. We spend time in concourses, offices, and galleries, documenting how orientation tools respond to fluctuating programmes."
    },
    methods: {
      title: "Methods",
      body: "Our methods blend ethnographic interviews, sensor data interpretation, service blueprinting, and cartographic storytelling. This hybrid perspective avoids siloed conclusions."
    },
    values: {
      title: "Values",
      items: [
        {
          title: "Curiosity",
          body: "We ask how people truly experience a space before suggesting adjustments."
        },
        {
          title: "Transparency",
          body: "Findings, assumptions, and limitations are shared openly with collaborators."
        },
        {
          title: "Care",
          body: "We treat visitor narratives with respect, recognising accessibility as a collective responsibility."
        },
        {
          title: "Iteration",
          body: "We revisit sites to observe outcomes, documenting what worked and what needs revision."
        }
      ]
    },
    timeline: {
      title: "Milestones",
      items: [
        {
          year: "2015",
          description: "Initial documentation of Brussels metro signage sparked the archive."
        },
        {
          year: "2017",
          description: "Partnership with regional mobility labs expanded the research scope to tram and bus interchanges."
        },
        {
          year: "2020",
          description: "Launch of bilingual publication series covering urban cultural districts."
        },
        {
          year: "2023",
          description: "Integrated accessibility audits into every project, collaborating with advocacy groups."
        }
      ]
    },
    community: {
      title: "Community practice",
      body: "We convene monthly salons where planners, artists, and mobility advocates dissect orientation challenges and share tactics."
    },
    research: {
      title: "Research outputs",
      body: "Our publications range from field notebooks to immersive digital atlases, each designed to translate complex environments into readable journeys."
    },
    future: {
      title: "Forward view",
      body: "We are developing open datasets so municipalities can benchmark orientation quality without commissioning new studies from scratch."
    }
  },
  blog: {
    heroTitle: "Insights from ongoing navigation studies",
    heroSubtitle: "Long-form documentation exploring signage ecologies, pedestrian mobility, and digital orientation systems.",
    readMore: "Read article",
    posts: {
      post1: {
        title: "Temporal layering for cultural districts",
        excerpt: "Temporal state analysis reveals how cultural venues adapt signage, lighting, and messaging to keep late programs legible.",
        date: "Published 12 April 2024",
        alt: "Night projection guiding visitors through a cultural district"
      },
      post2: {
        title: "Tactile interfaces for multimodal hubs",
        excerpt: "Examines tactile cues that complement visual signage inside dense multimodal transport halls.",
        date: "Published 22 March 2024",
        alt: "Tactile paving guiding passengers inside a transit hub"
      },
      post3: {
        title: "Evaluating interactive campus maps",
        excerpt: "A framework for reviewing campus maps across kiosks, mobile devices, and seasonal programming.",
        date: "Published 27 February 2024",
        alt: "Student interacting with a large touchscreen campus map"
      },
      post4: {
        title: "Governance frameworks for signage in public buildings",
        excerpt: "Defines governance structures ensuring signage stays coherent as public buildings evolve.",
        date: "Published 5 February 2024",
        alt: "Meeting discussing signage plans inside a civic building"
      },
      post5: {
        title: "Legibility metrics for urban promenades",
        excerpt: "Measures how promenades communicate orientation through landmarks, behaviour, and sensory cues.",
        date: "Published 18 January 2024",
        alt: "Pedestrians walking along an illuminated urban promenade"
      }
    }
  },
  faq: {
    heroTitle: "Frequently asked questions",
    heroIntro: "Learn how we study spatial orientation, structure collaborations, and share findings.",
    items: [
      {
        question: "How do you document spatial orientation challenges?",
        answer: "We combine site observation, participatory walks, and data analysis to understand how people interpret environments. Notes, sketches, and recordings converge into layered reports."
      },
      {
        question: "Do you produce commercial signage designs?",
        answer: "No. We focus on research and documentation, providing insights that public teams can adapt within their own procurement frameworks."
      },
      {
        question: "Which environments do you study?",
        answer: "Our portfolio spans transport hubs, civic campuses, cultural districts, and large event venues across Belgium."
      },
      {
        question: "How do you handle multilingual content?",
        answer: "We audit existing language policies, test comprehension with diverse audiences, and recommend phrasing hierarchies that respect local context."
      },
      {
        question: "Can we request a bespoke workshop?",
        answer: "Yes. Workshops emphasise shared analysis rather than commercial training, enabling teams to interpret their own findings."
      },
      {
        question: "What is your stance on accessibility standards?",
        answer: "Accessibility frameworks guide every project. We evaluate tactile cues, audio prompts, contrast ratios, and cognitive load."
      },
      {
        question: "How do you evaluate digital tools?",
        answer: "We run usability sessions on kiosks, mobile apps, and desktops, measuring task success and feelings of confidence."
      },
      {
        question: "How often do you update publications?",
        answer: "Major publications refresh twice per year, while field notes and micro-updates appear after each site visit."
      }
    ],
    contactPrompt: "Need a deeper perspective?",
    contactCta: "Write to us"
  },
  contact: {
    heroTitle: "Connect with the research collective",
    heroIntro: "Share context about your space so we can align documentation and insights.",
    heroImageAlt: "City map with layered wayfinding notes",
    availabilityTitle: "Availability",
    availabilityBody: "We dedicate time each quarter to new field partnerships across Belgium. Remote briefings are scheduled on Tuesday and Thursday afternoons.",
    detailsTitle: "Contact details",
    phoneTitle: "Phone",
    phoneValue: "Call +32 2 403 12 87",
    emailTitle: "Email",
    emailValue: "Write to info@danswholesaleplants.com",
    hoursTitle: "Collaboration hours",
    hoursBody: "Responses usually arrive within three working days.",
    formTitle: "Share your spatial context",
    formIntro: "Complete the form with a brief description of your site. We use this information solely to coordinate conversation.",
    form: {
      nameLabel: "Full name",
      namePlaceholder: "Your name",
      emailLabel: "Email address",
      emailPlaceholder: "name@example.com",
      organisationLabel: "Organisation or initiative",
      organisationPlaceholder: "Institution, venue, or group",
      messageLabel: "Spatial context and questions",
      messagePlaceholder: "Describe the environment, challenges, or objectives",
      consentText: "By submitting this form you agree to be contacted regarding spatial orientation research.",
      submit: "Send message"
    },
    mapTitle: "Brussels workbase",
    mapCaption: "Map centred on Rue de la Loi 155, 1040 Bruxelles."
  },
  terms: {
    heroTitle: "Terms of use",
    heroIntro: "Review these terms to understand how to engage with the danswholesaleplants website and publications.",
    sections: [
      {
        title: "Scope and purpose",
        body: "These terms govern access to the danswholesaleplants website, publications, and related materials. By using the site, you acknowledge the informational nature of the content."
      },
      {
        title: "Definitions",
        body: "“Content” refers to articles, visuals, data sets, and downloads. “We” denotes danswholesaleplants. “User” refers to anyone accessing the site."
      },
      {
        title: "Use of information",
        body: "You may reference our material for educational and institutional purposes provided attribution is maintained. Commercial reuse requires prior written permission."
      },
      {
        title: "Research integrity",
        body: "We endeavour to present accurate observations based on fieldwork and analysis. Nonetheless, all interpretations remain subject to revision as environments evolve."
      },
      {
        title: "Intellectual property",
        body: "Unless otherwise stated, all content is owned by danswholesaleplants. Third-party materials retain their respective rights and are used with acknowledgement."
      },
      {
        title: "Contributions from readers",
        body: "If you share feedback or materials with us, you grant permission to reference or publish them within our work while crediting your contribution."
      },
      {
        title: "External references",
        body: "Our site may link to external resources for context. We do not control those sources and are not responsible for their content or availability."
      },
      {
        title: "Data accuracy",
        body: "We strive to keep information current but cannot guarantee completeness. Users should verify critical details with relevant authorities."
      },
      {
        title: "Accessibility commitment",
        body: "We aim to maintain accessible formats, including bilingual content, semantic markup, and alternative text. Feedback on accessibility improvements is welcome."
      },
      {
        title: "Changes to the site",
        body: "We may modify, suspend, or discontinue parts of the site without notice. Updates to content or structure do not create obligations toward users."
      },
      {
        title: "Limitation of liability",
        body: "danswholesaleplants is not liable for any direct or indirect damages arising from use of the site, reliance on content, or temporary unavailability."
      },
      {
        title: "Governing law",
        body: "These terms are governed by Belgian law. Any disputes will be addressed in the competent courts of Brussels."
      },
      {
        title: "Contact information",
        body: "Questions about these terms can be directed to info@danswholesaleplants.com."
      },
      {
        title: "Effective date",
        body: "These terms were last updated on 1 May 2024."
      }
    ]
  },
  privacy: {
    heroTitle: "Privacy notice",
    heroIntro: "This notice explains how danswholesaleplants collects, uses, and protects personal data.",
    sections: [
      {
        title: "Data controller",
        body: "danswholesaleplants, Rue de la Loi 155, 1040 Bruxelles, Belgium, is responsible for processing personal data collected through this site."
      },
      {
        title: "Data collected",
        body: "We may collect names, email addresses, organisational details, language preferences, and cookie consent choices when you interact with the site."
      },
      {
        title: "Collection methods",
        body: "Data is obtained through contact forms, voluntary email correspondence, and local storage mechanisms that remember language and cookie selections."
      },
      {
        title: "Purposes of processing",
        body: "We process data to respond to enquiries, maintain bilingual functionality, record consent choices, and generate anonymised analytics if permission is granted."
      },
      {
        title: "Legal basis",
        body: "Processing relies on your consent for communications and cookies, and on legitimate interest to ensure site security and necessary functionality."
      },
      {
        title: "Retention period",
        body: "Contact records are retained for up to 12 months after the last interaction. Cookie-related data is stored according to the durations listed in the cookie policy."
      },
      {
        title: "Data sharing",
        body: "We do not sell personal data. Information may be shared with trusted hosting and infrastructure providers under confidentiality agreements."
      },
      {
        title: "International transfers",
        body: "Data is stored within the European Union. If service providers operate outside the EU, equivalent protections and contractual safeguards will apply."
      },
      {
        title: "Security measures",
        body: "We employ technical and organisational measures such as encrypted connections, access controls, and regular audits to protect personal data."
      },
      {
        title: "User rights",
        body: "You may request access, rectification, deletion, restriction of processing, or data portability. You can also withdraw consent at any time."
      },
      {
        title: "Requests and responses",
        body: "To exercise your rights, contact info@danswholesaleplants.com. We aim to respond within 30 days of receiving a complete request."
      },
      {
        title: "Updates to this notice",
        body: "We may update this notice to reflect operational changes. The effective date will be revised accordingly."
      }
    ]
  },
  cookiesPage: {
    heroTitle: "Cookie policy",
    heroIntro: "This policy details how cookies and similar technologies support the danswholesaleplants website.",
    sectionTitle: "How we use cookies",
    sectionBody: "Cookies help remember language preferences, store consent decisions, and enable optional analytics that improve navigation insights.",
    preferencesTitle: "Preference groups",
    preferencesIntro: "The categories below mirror the options available in our cookie banner.",
    groups: {
      necessary: {
        title: "Necessary cookies",
        body: "These cookies maintain core functionality such as security and remembering consent. They are always active."
      },
      preferences: {
        title: "Preference cookies",
        body: "Preference cookies store language choices and interface configurations so the site reflects your selected experience."
      },
      analytics: {
        title: "Analytics cookies",
        body: "Analytics cookies, enabled only with consent, help us understand aggregated page usage and detect navigation issues."
      },
      marketing: {
        title: "Marketing cookies",
        body: "We currently do not run marketing trackers. This category remains available to communicate any future updates transparently."
      }
    },
    tableIntro: "Cookies currently in use are summarised below.",
    table: {
      headers: {
        name: "Name",
        provider: "Provider",
        type: "Type",
        purpose: "Purpose",
        duration: "Duration"
      },
      rows: [
        {
          name: "cookie_consent",
          provider: "danswholesaleplants",
          type: "Necessary",
          purpose: "Stores the status of your cookie preferences.",
          duration: "12 months"
        },
        {
          name: "site_lang",
          provider: "danswholesaleplants",
          type: "Preference",
          purpose: "Remembers the language you selected for the site.",
          duration: "12 months"
        },
        {
          name: "session_orientation",
          provider: "danswholesaleplants",
          type: "Analytics (optional)",
          purpose: "Aggregates page navigation metrics to improve wayfinding content when enabled.",
          duration: "30 minutes"
        }
      ]
    },
    consentTitle: "Managing consent",
    consentBody: "You can adjust cookie choices at any time via the banner or by clearing saved preferences in your browser. Changes take effect immediately."
  },
  refund: {
    heroTitle: "Refund policy",
    heroIntro: "Although we do not conduct commercial transactions, this policy clarifies how we address correction and withdrawal requests.",
    sections: [
      {
        title: "Purpose",
        body: "This policy outlines procedures for reviewing requests to amend or retract content associated with danswholesaleplants."
      },
      {
        title: "Non-commercial scope",
        body: "We do not sell products or services. Therefore, financial refunds do not apply. Our focus is on informational accuracy."
      },
      {
        title: "Eligibility for review",
        body: "Individuals or organisations referenced in our publications may request clarifications or updates when information is incomplete or outdated."
      },
      {
        title: "Submission channel",
        body: "Requests should be submitted via info@danswholesaleplants.com with sufficient detail to identify the relevant content."
      },
      {
        title: "Evaluation criteria",
        body: "We assess requests based on evidence provided, alignment with our research notes, and the potential impact on public understanding."
      },
      {
        title: "Response timeline",
        body: "We aim to acknowledge requests within seven working days and provide a considered response within thirty days."
      },
      {
        title: "Corrective actions",
        body: "When necessary, we will update articles, append clarifications, or remove sensitive details while preserving contextual integrity."
      },
      {
        title: "Record keeping",
        body: "All requests and outcomes are logged to inform future editions and maintain accountability."
      },
      {
        title: "No financial compensation",
        body: "Because no commercial exchange occurs, compensation is limited to informational amendments."
      },
      {
        title: "Policy revisions",
        body: "We may revise this policy to reflect evolving editorial practices. Changes will be posted with a new effective date."
      },
      {
        title: "Contact and effective date",
        body: "For questions, email info@danswholesaleplants.com. This policy became effective on 1 May 2024."
      }
    ]
  },
  disclaimer: {
    heroTitle: "Disclaimer",
    heroIntro: "Understand the limits of our publications and the responsibilities of users.",
    sections: [
      {
        title: "Informational purpose",
        body: "All content on this site is provided for informational purposes. It should not be interpreted as professional, legal, or architectural advice."
      },
      {
        title: "No guarantees",
        body: "We do not guarantee that the information is exhaustive, current, or free from error. Readers should verify details before acting."
      },
      {
        title: "User responsibility",
        body: "Users are responsible for interpreting and applying insights appropriately within their own contexts."
      },
      {
        title: "Third-party references",
        body: "References or links to external resources are provided for context. We do not endorse or control third-party content."
      },
      {
        title: "Future changes",
        body: "We may update content without notice as research evolves. Continued use indicates acceptance of updated materials."
      },
      {
        title: "Contact",
        body: "For clarification regarding this disclaimer, contact info@danswholesaleplants.com. Effective date: 1 May 2024."
      }
    ]
  },
  thankYou: {
    heroTitle: "Thank you for your message",
    heroIntro: "We have received your note and will reply within three working days. Meanwhile, explore recent analyses.",
    cta: "Return to homepage"
  },
  posts: {
    backToBlog: "Back to blog",
    post1: {
      title: "Temporal layering for cultural districts",
      intro: "Cultural districts rarely operate on a single timetable. Evening performances, late gallery openings, and community workshops all compress into the same plazas and corridors. This article examines how temporal layering can shape responsive wayfinding strategies that remain legible to first-time visitors and returning neighbours.",
      heroImageAlt: "Evening crowds moving through a cultural district with illuminated signage",
      section1: {
        heading: "Interlacing occupancy data",
        subheading: "Reading sensor timelines alongside staff intuition",
        paragraph1: "Hourly occupancy traces from ticketing portals, Bluetooth sniffers, and manual door counts rarely align perfectly. Yet when plotted on the same axis, these streams outline where cultural venues breathe and stall. We start by identifying overlapping peaks across theatres, cafés, and workshop studios. From there, we overlay staff rosters and anecdotal reports to understand where guidance collapses under pressure. The combination reveals pinch points—open courtyards that turn into bottlenecks after curtain call, or staircases that seem clear on maps but become daunting when performances release simultaneously.",
        paragraph2: "Temporal anomalies surface the most actionable insights. For instance, a courtyard may work flawlessly on weekday afternoons yet disorient guests during night festivals because perimeter lighting shifts to highlight sculptures rather than exits. By comparing sensor logs with light programming schedules, we map out the minutes when signage legibility dips. These findings feed into a temporal segmentation model: we define baseline, surge, and overflow states for each zone, allowing the operations team to schedule ambassadors, adjust messaging hierarchy, and preload dynamic screens before confusion spreads."
      },
      section2: {
        heading: "Sequencing visual cues",
        subheading: "Aligning static landmarks with adaptive media",
        paragraph1: "Visitors rely on a blend of permanent landmarks and temporary prompts. We audit how banners, projection surfaces, and digital kiosks appear during each temporal state. Static identifiers should anchor orientation; digital panels can then highlight timely pathways. When static and adaptive layers compete—for example, when a projection overlays a directional mural—newcomers hesitate. We map zones where legacy signage must be repositioned or where digital walls need distinct backgrounds to preserve contrast and comprehension.",
        paragraph2: "Our design sprints test how quickly visitors recognise rerouted paths. Volunteers arrive with scripted narratives mirroring real events: simultaneous premieres, extended museum nights, or open-air screenings. We rotate the order of cues, pushing alternate messages to overhead displays, floor beacons, and handheld notifications. The most successful sequences pair a bold static frame with concise digital phrasing, repeated three times along the route. This rhythm allows guests to commit the detour to memory while still enjoying the atmosphere."
      },
      section3: {
        heading: "Synchronising digital channels",
        subheading: "Integrating signage, apps, and cultural calendars",
        paragraph1: "Digital signage excels when it reinforces, rather than replaces, other communication channels. We align the content management system with ticketing confirmations, website pop-ups, and printed programmes. When a visitor scans a QR code in the plaza, the mobile view mirrors the nearest kiosk layout, reducing cognitive shifts. Calendar integrations ensure that once a workshop ends early, the messaging cascade updates across all surfaces within minutes, preventing guests from following outdated directions.",
        paragraph2: "Reliable synchronization hinges on governance. Editors from the cultural district’s communications team, building operations, and neighbourhood council all access the same change log. Each update includes audience intent, estimated duration, and fallback instructions should equipment fail. By choreographing this workflow, we reduce conflicting updates and guarantee that on-site announcements match the tonal balance expected in the district—informative, calm, and welcoming even during peak hours."
      },
      section4: {
        heading: "Tracing outcomes and iterations",
        subheading: "Evaluating visitor confidence after adjustments",
        paragraph1: "After implementing temporal layering strategies, we evaluate impact through mixed methods. Heatmaps derived from anonymous device pings confirm whether new detours distribute foot traffic evenly. Meanwhile, intercept interviews capture whether visitors felt confident finding late-night transport or secondary venues. We especially probe for moments of hesitancy, asking guests to sketch their remembered route and highlight where they slowed down or looked for staff support.",
        paragraph2: "Iteration remains constant. Seasonal programming, construction, and neighbourhood policy all influence the choreography of guidance tools. We revisit the dataset each quarter, comparing confidence scores and dwell durations against earlier baselines. The continuous loop keeps the district agile without overwhelming teams. Temporal layering thus becomes a shared language, enabling curators, security staff, and mobility planners to shape evenings that feel intuitive while accommodating the district’s energetic rhythm."
      }
    },
    post2: {
      title: "Tactile interfaces for multimodal hubs",
      intro: "Multimodal mobility hubs depend on more than visual graphics. Travellers juggle luggage, time pressure, and sensory fatigue. This article examines tactile orientation tools that complement auditory and visual guidance within dense interchange halls.",
      heroImageAlt: "Tactile paving and handrails guiding passengers through a multimodal transport hall",
      section1: {
        heading: "Surveying sensory baselines",
        subheading: "Documenting existing textures and acoustic cues",
        paragraph1: "Before introducing new tactile signals, we catalogue the existing sensory landscape. Floor finishes, joint patterns, and edge treatments already convey subtle information about direction and safety. We walk the entire hub with station teams to note where granite slabs become smooth resin, where platform edges vibrate, and where mechanical rooms hum loudly. These cues may help or hinder orientation. Mapping them alongside decibel readings and lighting levels creates a baseline for future interventions.",
        paragraph2: "Passenger workshops deepen the inventory. We invite regular commuters, occasional visitors, and people relying on mobility aids to describe how they currently interpret the space. Their narratives often uncover overlooked anchors, such as the warmth of morning sun on a particular wall or the vibration of escalators. By translating these stories into spatial diagrams, we identify areas starved of tactile information and zones already saturated with competing stimuli."
      },
      section2: {
        heading: "Material grammars for touch",
        subheading: "Balancing guidance with comfort",
        paragraph1: "Tactile paving must communicate direction without becoming exhausting to cross. We test modular patterns that differentiate decision points, platform approaches, and safe waiting areas. Raised bars paired with smooth buffers indicate forward momentum, while studded clusters flag caution. Materials are selected for durability and thermal comfort so that travellers feel stable in winter boots or summer sandals.",
        paragraph2: "We also consider hand-level interfaces. Rails, balustrades, and wall reliefs receive subtle ridges that signal junctions or platform numbers. When paired with embossed iconography, these interventions allow travellers to confirm their location without needing to stop and read a full sign. Every new element undergoes tactile testing loops with participants who have varied grip strength and sensory sensitivity, ensuring that cues remain clear yet gentle."
      },
      section3: {
        heading: "Coordinating signage and sound",
        subheading: "Ensuring multi-sensory coherence",
        paragraph1: "Tactile additions only succeed when they reinforce other modes. We script how floor textures align with audible announcements and digital displays. For example, if a concourse splits toward tram and rail platforms, the tactile pathways branch at the same point where audio announcements differentiate services. Visual signage adopts matching iconography, so the same arrow family appears in every medium.",
        paragraph2: "Consistency extends to maintenance. Cleaning crews receive diagrams illustrating acceptable detergents and brushing techniques, preventing raised textures from being worn down. Audio engineers record new announcements to avoid clashes with reverberant materials introduced by tactile panels. The combined approach keeps multisensory cues aligned even as schedules change or seasonal events redirect flows."
      },
      section4: {
        heading: "Maintaining durability",
        subheading: "Embedding tactile strategies into operations",
        paragraph1: "A tactile strategy cannot remain a one-off project. We codify interventions into the hub’s asset management plan, including inspection routines and replacement cycles. Sensors log surface wear, alerting maintenance teams when tactile strips lose clarity. Procurement guidelines specify colour contrast and module dimensions so that future renovations respect the established grammar.",
        paragraph2: "Feedback loops sustain relevance. Quarterly walk-throughs with passenger panels gauge whether new patterns remain understandable. When new mobility services join the hub, we run micro-prototypes before making permanent changes, ensuring that tactile cues scale gracefully. Through ongoing stewardship, the tactile layer evolves alongside the hub, supporting every traveller as they recalibrate between modes."
      }
    },
    post3: {
      title: "Evaluating interactive campus maps",
      intro: "University campuses often rely on interactive maps to orient visitors, students, and staff. This article outlines a framework for evaluating these digital tools so they remain intuitive across the academic cycle.",
      heroImageAlt: "Interactive campus map displayed on a large kiosk screen",
      section1: {
        heading: "Benchmarking baseline tasks",
        subheading: "Testing routes, amenities, and temporal events",
        paragraph1: "We begin by scripting tasks that mirror real campus journeys: locating lecture halls, identifying accessible entrances, and navigating between buildings during weather disruptions. Participants attempt these tasks on kiosks, mobile web, and desktop versions of the interactive map. We observe search behaviours, time to first confident decision, and whether users cross-check with physical landmarks.",
        paragraph2: "Task results inform a complexity matrix. Routes with multiple accessibility considerations, such as elevators hidden within faculties, receive higher scores. Seasonal events like orientation weeks add additional layers. By cataloguing these scenarios, we understand which map functions must be front-loaded and which can sit deeper within the interface without frustrating users."
      },
      section2: {
        heading: "Assessing cartographic clarity",
        subheading: "Legibility, hierarchy, and contextual overlays",
        paragraph1: "Interactive maps often overload users with layers. We review symbol sets, colour palettes, and zoom behaviours to ensure hierarchy remains clear. Buildings that host multiple departments receive modular labels, while open spaces maintain generous padding for pop-up events. Legends adapt dynamically, showing only the overlays currently active.",
        paragraph2: "We also compare screen outputs with on-the-ground signage. When kiosk colours misalign with wayfinding plaques, visitors doubt both. Harmonising hex values and icon strokes across channels reinforces trust. If a map uses isometric renderings, we verify that perspective does not obscure entry points or vertical circulation nodes."
      },
      section3: {
        heading: "Calibrating data governance",
        subheading: "Keeping information current without noise",
        paragraph1: "Interactive maps fail when data lags. We work with campus operations to map existing data flows—maintenance tickets, room bookings, and emergency notifications. By establishing a central moderation queue, we prevent outdated notices from lingering while still enabling faculties to request updates.",
        paragraph2: "Governance also addresses language and tone. Multilingual campuses require evenly maintained translations. Content guidelines define how to describe temporary barriers, ensuring messages remain direct but reassuring. Update logs remain transparent so stakeholders can trace when and why a change occurred."
      },
      section4: {
        heading: "Measuring confidence after deployment",
        subheading: "Combining analytics with qualitative feedback",
        paragraph1: "After refinements, we collect analytics such as dwell time, search success rates, and zoom depth. These metrics reveal whether users find what they need quickly or wander through layers. Drop-off points hint at confusing terminology or missing cross-links.",
        paragraph2: "Quantitative results only tell part of the story. Therefore we run intercept interviews and digital surveys to capture perceptions. Respondents detail whether maps felt supportive during night walks, unfamiliar faculty visits, or campus events that reshape circulation. The blend of data guides further iterations, ensuring the map remains a living companion rather than a static diagram."
      }
    },
    post4: {
      title: "Governance frameworks for signage in public buildings",
      intro: "Public buildings host multiple agencies, shifting programmes, and diverse visitors. A governance framework ensures signage evolves coherently as these variables change.",
      heroImageAlt: "Team reviewing governance documents for public building signage",
      section1: {
        heading: "Mapping stakeholder roles",
        subheading: "Defining responsibilities across agencies",
        paragraph1: "We start by identifying every team that touches the visitor journey: facility management, communications, security, cultural programming, and accessibility coordinators. Workshops map where their responsibilities intersect and where gaps leave signage unattended. The exercise clarifies who approves language changes, who maintains digital directories, and who monitors temporary signage during events.",
        paragraph2: "With roles defined, we create a decision matrix. High-impact updates—such as renaming a service hall—require broader consensus, while routine maintenance can proceed through streamlined channels. The matrix prevents bottlenecks by giving each stakeholder confidence in their remit."
      },
      section2: {
        heading: "Establishing content standards",
        subheading: "Tone, hierarchy, and multilingual delivery",
        paragraph1: "Content standards set the voice of the building. We document how to refer to departments, how to format room numbers, and how to present multilingual content. Typography scales and colour contrasts are codified so contractors and internal teams deliver consistent outcomes. Icons follow a shared grid, ensuring new pictograms align with existing ones.",
        paragraph2: "We also prescribe review cycles. Every quarter, a small editorial group audits signage for outdated terminology or mismatched translations. During renovations, the group accelerates reviews to keep temporary signs aligned with permanent narratives."
      },
      section3: {
        heading: "Integrating digital and physical assets",
        subheading: "Synchronising directories, kiosks, and updates",
        paragraph1: "Digital kiosks and physical plaques must speak the same language. We connect content management systems so that when a new tenant moves in, updates propagate across wall directories, paper printouts, and room plates within a set timeframe. QR codes link to mobile views that mirror onsite messaging, offering contrast modes and audio descriptions.",
        paragraph2: "Maintenance logs track both hardware and content quality. When a screen fails or a panel shows wear, the issue enters the same system as textual updates. This integration avoids situations where hardware is fixed but outdated messages persist."
      },
      section4: {
        heading: "Monitoring performance",
        subheading: "Audits, feedback, and continuous improvement",
        paragraph1: "Governance thrives on evidence. We schedule biannual audits covering clarity, placement, and inclusivity. Auditors note where visitors hesitate, using floor annotations and photographs. Results feed into a dashboard shared with stakeholders, ensuring transparency.",
        paragraph2: "Feedback channels remain open year-round. QR codes invite visitors to comment on signage clarity, while service desks log recurring queries. The framework specifies response timelines so observations transform into action. Over time, the governance model becomes a living contract aligning building evolution with visitor comprehension."
      }
    },
    post5: {
      title: "Legibility metrics for urban promenades",
      intro: "Urban promenades connect civic, cultural, and residential zones. Measuring legibility helps planners understand how people interpret these open-air corridors.",
      heroImageAlt: "Night-time urban promenade with directional lighting and pedestrians",
      section1: {
        heading: "Defining observation segments",
        subheading: "Breaking the promenade into experiential zones",
        paragraph1: "We divide promenades into segments based on material changes, adjacent land uses, and sightline shifts. Each segment receives a profile documenting landmarks, seating, vegetation density, and lighting. Observers walk routes at different times of day to capture how shadows, traffic, and crowd levels alter perception.",
        paragraph2: "Segment profiles also record sensory attributes, such as noise gradients from nearby tram lines or aromas from food markets. These details influence wayfinding comfort and help prioritise which areas require additional cues."
      },
      section2: {
        heading: "Quantifying visual anchors",
        subheading: "Evaluating landmarks, lighting, and typography",
        paragraph1: "Landmarks anchor orientation, so we score their visibility and relevance. A sculptural fountain may serve as a strong reference during daylight but vanish at night without supportive lighting. We measure luminance levels, contrast ratios on signage, and the crispness of typographic installations.",
        paragraph2: "If typographic markers fade or lack tactile elements, we note accessibility risks. Recommendations may include repainting murals with reflective pigments, adjusting pole heights, or adding ground-level inlays that remain legible from wheelchairs and children’s eye levels."
      },
      section3: {
        heading: "Recording behavioural indicators",
        subheading: "Tracking pauses, detours, and social use",
        paragraph1: "Legibility metrics extend beyond visual audits. We observe how people pause, backtrack, or cluster. Long pauses near decision points suggest uncertainty, while frequent detours imply missing cues. We pair these observations with anonymised counts to understand flow intensity.",
        paragraph2: "Social behaviours provide additional insight. When benches face away from informational signage, people may miss cues while resting. Pop-up markets can either energise or clutter guidance. Documenting these dynamics helps adjust sign placement and support micro-events without eroding clarity."
      },
      section4: {
        heading: "Synthesising metrics into action",
        subheading: "Turning observations into design briefs",
        paragraph1: "Once data is collected, we compile legibility scores across segments, highlighting where interventions deliver the highest impact. High-performing zones reveal patterns worth replicating elsewhere, such as consistent lighting rhythms or integrated seating.",
        paragraph2: "The synthesis culminates in briefs that respect the promenade’s character. Instead of imposing generic signage, we recommend interventions that weave into existing materials—etched brass strips, layered planting, or gentle projections. Metrics thus guide nuanced enhancements, sustaining the promenade’s identity while strengthening navigation."
      }
    }
  },
  cookieBanner: {
    title: "Cookies on danswholesaleplants",
    description: "We use cookies to maintain essential features, remember preferences, and, with permission, understand how visitors navigate our site.",
    link: "Review the cookie policy",
    manageTitle: "Manage cookie preferences",
    toggles: {
      necessary: {
        title: "Necessary",
        description: "Required for security, consent storage, and core functionality.",
        aria: "Necessary cookies are always enabled"
      },
      preferences: {
        title: "Preferences",
        description: "Store language and interface selections so pages display as you expect.",
        aria: "Toggle preference cookies"
      },
      analytics: {
        title: "Analytics",
        description: "Help us observe aggregated navigation patterns to improve content.",
        aria: "Toggle analytics cookies"
      },
      marketing: {
        title: "Marketing",
        description: "Reserved for future communication tools. Currently inactive.",
        aria: "Toggle marketing cookies"
      }
    },
    state: {
      enabled: "Enabled",
      disabled: "Disabled"
    },
    buttons: {
      accept: "Accept all",
      decline: "Decline all",
      save: "Save preferences"
    },
    toasts: {
      accepted: "Cookie preferences accepted.",
      declined: "Optional cookies declined.",
      saved: "Cookie preferences updated."
    }
  },
  forms: {
    validationRequired: "Please complete the highlighted fields.",
    toastProcessing: "Sending your message...",
    toastSuccess: "Message sent. Thank you for reaching out.",
    toastError: "We could not submit your form. Please try again."
  }
};

const translationsFr = {
  meta: {
    index: {
      title: "danswholesaleplants | Intelligence en orientation spatiale",
      description: "Collectif de recherche bilingue documentant la signalétique numérique, les écosystèmes d'orientation et la lisibilité des espaces publics en Belgique."
    },
    services: {
      title: "Lignes de service pour la recherche en orientation spatiale | danswholesaleplants",
      description: "Panorama de six axes analytiques couvrant le diagnostic, la cartographie numérique et les revues d'accessibilité des bâtiments complexes en Belgique."
    },
    about: {
      title: "À propos de danswholesaleplants | Collectif de recherche spatiale",
      description: "Histoire, mission et valeurs de danswholesaleplants, collectif bruxellois dédié aux systèmes d'orientation spatiale."
    },
    blog: {
      title: "Blog | analyses spatiales de danswholesaleplants",
      description: "Articles approfondis explorant la signalétique, la mobilité piétonne et l'expérience spatiale dans les environnements publics."
    },
    contact: {
      title: "Contact danswholesaleplants | Collectif d'orientation spatiale",
      description: "Prenez contact avec danswholesaleplants pour partager vos défis d'orientation spatiale, collaborations et objectifs d'accessibilité."
    },
    faq: {
      title: "FAQ | danswholesaleplants",
      description: "Questions fréquentes sur notre démarche de recherche en orientation, nos formats de documentation et notre cadence de collaboration."
    },
    terms: {
      title: "Conditions d'utilisation | danswholesaleplants",
      description: "Conditions régissant les contenus de danswholesaleplants, leur portée de recherche, la propriété intellectuelle et les limites applicables."
    },
    privacy: {
      title: "Notice de confidentialité | danswholesaleplants",
      description: "Notice décrivant la gestion des données personnelles, des préférences d'analyse, du stockage et des droits des utilisateurs par danswholesaleplants."
    },
    cookies: {
      title: "Politique de cookies | danswholesaleplants",
      description: "Politique expliquant les cookies fonctionnels, de préférence et d'analyse utilisés par danswholesaleplants."
    },
    refund: {
      title: "Politique de rectification | danswholesaleplants",
      description: "Politique précisant le caractère non commercial et la manière de traiter les demandes de correction de contenu."
    },
    disclaimer: {
      title: "Avertissement | danswholesaleplants",
      description: "Avertissement rappelant la nature informative des publications, l'absence de garanties et les responsabilités des utilisateurs."
    },
    thankYou: {
      title: "Merci | danswholesaleplants",
      description: "Page de confirmation attestant la bonne réception du formulaire de contact."
    },
    post1: {
      title: "Stratification temporelle pour les districts culturels | danswholesaleplants",
      description: "Analyse des stratégies temporelles de signalétique soutenant les programmes du soir dans les districts culturels."
    },
    post2: {
      title: "Interfaces tactiles pour pôles multimodaux | danswholesaleplants",
      description: "Évaluation des dispositifs tactiles guidant les voyageurs dans les halles de transport multimodales."
    },
    post3: {
      title: "Évaluer les plans interactifs de campus | danswholesaleplants",
      description: "Cadre d'évaluation des plans numériques de campus sur bornes, mobiles et dispositifs saisonniers."
    },
    post4: {
      title: "Cadres de gouvernance pour la signalétique des bâtiments publics | danswholesaleplants",
      description: "Conseils pour établir des modèles de gouvernance garantissant la cohérence de la signalétique des bâtiments publics."
    },
    post5: {
      title: "Mesures de lisibilité pour promenades urbaines | danswholesaleplants",
      description: "Méthodologie de mesure de la lisibilité des promenades à travers repères, comportements et ressentis sensoriels."
    }
  },
  global: {
    siteName: "danswholesaleplants",
    tagline: "Intelligence en orientation spatiale",
    address: "Rue de la Loi 155, 1040 Bruxelles, Belgique",
    phone: "+32 2 403 12 87",
    email: "info@danswholesaleplants.com"
  },
  header: {
    skipLink: "Aller au contenu",
    mobileMenuLabel: "Basculer la navigation",
    languageToggleLabel: "Choisir la langue",
    lang: {
      fr: "Français",
      en: "Anglais"
    },
    nav: {
      home: "Accueil",
      services: "Services",
      about: "À propos",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact"
    }
  },
  footer: {
    addressTitle: "Adresse",
    address: "Rue de la Loi 155, 1040 Bruxelles, Belgique",
    phone: "Téléphone : +32 2 403 12 87",
    email: "Courriel : info@danswholesaleplants.com",
    navigate: "Mentions légales",
    terms: "Conditions d'utilisation",
    privacy: "Confidentialité",
    cookies: "Cookies",
    refund: "Politique de rectification",
    disclaimer: "Avertissement",
    copy: "© {year} danswholesaleplants. Collectif d'observation en orientation spatiale."
  },
  home: {
    heroEyebrow: "Carnets de terrain pour environnements complexes",
    heroTitle: "Cartographier la clarté des écosystèmes spatiaux complexes",
    heroSubtitle: "danswholesaleplants documente l'art de l'orientation numérique, alignant récits architecturaux, couches de données et attentes piétonnes afin que chaque parcours reste lisible.",
    heroCtaPrimary: "Découvrir notre portée analytique",
    heroCtaSecondary: "Consulter les notes de terrain",
    heroFigureCaption: "Couche interprétative numérique appliquée au complexe civique du Parc Léopold.",
    heroImageAlt: "Visualisation composite d'overlay d'orientation intérieure et extérieure",
    featureSectionTitle: "Entrelacer architecture et information",
    featureSectionIntro: "Nous explorons comment systèmes de signalétique, annuaires numériques et plateformes cartographiques peuvent être orchestrés pour offrir un guidage cohérent au sein de lieux interconnectés.",
    features: [
      {
        title: "Couches numériques contextuelles",
        body: "Nous assemblons des couches d'orientation réactives aux volumes, à la lumière naturelle et aux goulets de circulation, permettant aux usagers de lire les lieux selon les indices de situation."
      },
      {
        title: "Tableaux de bord des comportements piétons",
        body: "Les traces piétonnes en temps réel, agrégées à partir de capteurs et d'observations, révèlent les ruptures de séquence, la pression des files et les seuils où les messages doivent s'adapter."
      },
      {
        title: "Cadres narratifs accessibles",
        body: "Typographies inclusives, formulations multilingues et systèmes d'icônes sont évalués pour soutenir des modèles cognitifs variés sans surcharge de l'attention."
      }
    ],
    orientationHeading: "Écosystèmes d'orientation observés",
    orientationIntro: "Chaque site documenté conjugue contraintes architecturales et attentes comportementales. Les aperçus ci-dessous illustrent les domaines actuellement étudiés.",
    orientation: {
      items: [
        {
          title: "Pôles d'échanges en mutation",
          body: "L'empilement des services bus, tram et rail nécessite une signalétique chorégraphiée qui anticipe les arrivées massives tout en préservant un climat propice aux décisions d'orientation."
        },
        {
          title: "Campus civiques en transition",
          body: "Des ensembles administratifs en expansion exigent des parcours reliant ailes historiques et annexes contemporaines, soutenus par des balises numériques."
        },
        {
          title: "Parcours muséaux après la tombée du jour",
          body: "La programmation du soir recompose les priorités de circulation, appelant des niveaux lumineux adaptatifs et des murs média pour ancrer l'orientation des visiteurs."
        }
      ]
    },
    recommendations: {
      title: "Recommandations issues des analyses de terrain",
      intro: "Les campagnes d'observation se transforment en cahiers d'actions. Les axes suivants synthétisent les orientations élaborées avec des acteurs publics.",
      items: [
        {
          title: "Structurer des familles de signalétique hybrides",
          body: "Associez éléments placemaker statiques et dispositifs réactifs pour offrir à la fois confiance et souplesse aux visiteurs."
        },
        {
          title: "Répéter des détours intuitifs",
          body: "Modélisez les déviations temporaires et racontez-les clairement avec une voix unifiée afin que travaux ou consignes restent lisibles."
        },
        {
          title: "Ancrer des repères tactiles",
          body: "Installez textures, indices sur garde-corps et éclairages de sol pour soutenir la navigation multisensorielle sans surcharge visuelle."
        },
        {
          title: "Mesurer le temps de pause avec éthique",
          body: "Recueillez les métriques de flux via des outils respectueux de la vie privée afin d'informer les choix d'aménagement sans isoler les individus."
        }
      ]
    },
    testimonials: {
      title: "Témoignages des équipes partenaires",
      subtitle: "Des voix de planificateurs, curateurs et chercheurs en mobilité partagent les enseignements communs.",
      items: [
        {
          quote: "Les carnets d'orientation co-produits avec danswholesaleplants ont aidé notre hub tram à relier signalétique historique et nouvelles bornes numériques.",
          author: "Lucie Verstraeten",
          role: "Responsable programme mobilité, Observatoire STIB"
        },
        {
          quote: "Leurs audits cartographiques ont transformé la manière de raconter nos collections entre galeries et places publiques.",
          author: "Jasper De Wilde",
          role: "Curateur de narration spatiale, Brussels Urban Museum"
        },
        {
          quote: "Ils interrogent les données avec empathie, traduisant les flux en rituels de conception exploitables.",
          author: "Amélie De Smet",
          role: "Chercheuse en expérience piétonne, Greentrack"
        }
      ]
    },
    metrics: {
      title: "Indicateurs cadrant notre documentation",
      intro: "Chaque indicateur illustre l'étendue des espaces étudiés et la profondeur de l'analyse itérative.",
      items: [
        { value: "18", label: "Audits de site documentés depuis 2019" },
        { value: "42 km", label: "Segments de parcours intérieurs-extérieurs relevés" },
        { value: "260+", label: "Entretiens avec parties prenantes synthétisés" },
        { value: "12", label: "Jeux de signalétique multilingues comparés" }
      ]
    },
    caseStudies: {
      title: "Études approfondies actuellement diffusées",
      intro: "Nous publions des dossiers annotés pour permettre aux équipes de comparer les scénarios.",
      items: [
        {
          title: "Concourse multimodal du nord de Bruxelles",
          body: "Un dispositif stratifié reliant espaces résiduels du tram et corridors du métro via une iconographie réactive."
        },
        {
          title: "Forum civique au bord du canal",
          body: "Des scripts spatiaux orchestrant les déplacements entre guichets municipaux, bibliothèques et terrasses à ciel ouvert."
        },
        {
          title: "Chemins nocturnes du quartier des musées",
          body: "Lumière, projection et marquages au sol alignant la programmation tardive sur des itinéraires sûrs et lisibles."
        }
      ]
    },
    closing: {
      title: "Co-créer en continu avec les acteurs publics",
      body: "Notre documentation reste ouverte à la critique. Nous invitons les équipes à interroger les résultats, apporter de nouvelles observations et co-imaginer la prochaine vague d'expérimentations d'orientation.",
      cta: "Découvrir notre cadence de recherche",
      imageAlt: "Croquis analytique d'une grille urbaine éclairée pour la navigation nocturne"
    }
  },
  services: {
    heroTitle: "Lignes de service pour la recherche en orientation spatiale",
    heroIntro: "Nos travaux s'articulent autour de six axes complémentaires qui révèlent la manière dont les usagers interprètent les environnements complexes et comment les dispositifs de guidage peuvent évoluer.",
    heroImageAlt: "Chercheur examinant des superpositions d'orientation numérique sur une tablette",
    list: [
      {
        title: "Diagnostics des défis d'orientation",
        body: "Nous analysons typologies bâties, nœuds de circulation et récits d'usagers pour détecter les points de rupture. Croquis in situ, marches filmées et entretiens constituent une base de preuves partagée. Chaque enseignement est géolocalisé pour visualiser les frictions sur les plans.",
        points: [
          "Cartes thermiques des frictions à l'arrivée, en transfert et au départ.",
          "Journaux narratifs captant émotions et indices perçus par les visiteurs."
        ]
      },
      {
        title: "Principes de conception de la signalétique",
        body: "Nous élaborons des playbooks alignant signalétique statique, médias numériques et gestes architecturaux. Les principes équilibrent clarté et identité afin que les interventions renforcent les lieux existants.",
        points: [
          "Matrices de hiérarchie couvrant typographie, iconographie et langues.",
          "Scénarios répétant déviations, fermetures et événements temporaires."
        ]
      },
      {
        title: "Développement de cartographie interactive",
        body: "Nous prototypons des expériences cartographiques qui traduisent les connaissances situées en interfaces adaptatives. Ateliers et tests d'usage définissent gouvernance des données et lisibilité multi-écran.",
        points: [
          "Wireframes et prototypes cliquables pour bornes et supports mobiles.",
          "Dictionnaires de données définissant couches, fréquence de mise à jour et rôles de modération."
        ]
      },
      {
        title: "Recherche sur l'expérience piétonne",
        body: "Journaux de mobilité, traces GPS et marches participatives révèlent comment les personnes improvisent. Les résultats indiquent où renforcer ou rediriger les flux sans contrainte excessive.",
        points: [
          "Indicateurs comportementaux comparant parcours prévus et improvisés.",
          "Index de confort et de confiance segmentés par profils de visiteurs."
        ]
      },
      {
        title: "Conseil sur les standards d'accessibilité",
        body: "Nous auditons la conformité aux directives européennes en privilégiant la clarté pour des besoins sensoriels et cognitifs variés. Les recommandations valorisent des récits inclusifs plutôt qu'une simple conformité.",
        points: [
          "Inventaires d'indices multisensoriels couvrant tactile, audio et visuel.",
          "Ajustements de conception priorisant contraste, rythme et charge cognitive."
        ]
      },
      {
        title: "Évaluation des infrastructures de signalétique",
        body: "Nous évaluons familles de signalétique, supports physiques et dispositifs numériques selon leur durabilité, tonalité et adéquation aux programmes actuels. Des simulations anticipent la résilience future.",
        points: [
          "Rapports d'état des actifs avec projections de cycle de vie.",
          "Analyses d'écarts entre dispositifs physiques et mises à jour numériques."
        ]
      }
    ],
    methodology: {
      title: "Ancrages méthodologiques",
      body: "Chaque mission combine cartographie quantitative et récit qualitatif. Le processus reste transparent afin que les partenaires puissent répliquer les enseignements.",
      steps: [
        {
          title: "Immerger",
          body: "Nous passons du temps avec les équipes, observons les routines et documentons les conditions de base sur plusieurs temporalités."
        },
        {
          title: "Modéliser",
          body: "Les flux de données deviennent des diagrammes superposés visualisant circulations, lignes de vue et enveloppes acoustiques."
        },
        {
          title: "Prototyper",
          body: "Nous testons des interventions temporaires, de la signalétique éphémère aux prompts interactifs, et enregistrons les réactions."
        },
        {
          title: "Réfléchir",
          body: "Les bilans avec les parties prenantes consolident les apprentissages en feuilles de route concrètes."
        }
      ]
    },
    collaboration: {
      title: "Cadence de collaboration",
      body: "Des groupes de travail se réunissent toutes les deux semaines pour relire les résultats et garantir des ajustements co-construits et contextualisés."
    },
    deliverables: {
      title: "Livrables sans transaction",
      body: "Atlas, scripts et registres d'audit sont partagés ouvertement avec les partenaires publics afin d'encourager la réutilisation au sein des réseaux."
    },
    tools: {
      title: "Panorama d'outils",
      body: "Les instruments suivants reviennent fréquemment dans notre documentation.",
      items: [
        "Basemaps SIG superposant circulation intérieure et espace public.",
        "Matrices d'observation reliant comportements et déclencheurs environnementaux.",
        "Grilles de conformité accessibilité croisées avec les directives européennes.",
        "Storyboards narratifs illustrant les émotions ressenties le long des parcours."
      ]
    },
    callout: {
      title: "Effets de diffusion",
      body: "Lorsque les gestionnaires d'espace s'approprient ces outils, ils observent des flux plus apaisés, une coordination clarifiée et un sentiment renouvelé de stewardship partagée."
    }
  },
  about: {
    heroTitle: "Retracer l'évolution de danswholesaleplants",
    heroSubtitle: "Collectif bruxellois documentant les systèmes d'orientation au sein des infrastructures publiques. Notre regard croise culture architecturale et recherche UX.",
    heroImageAlt: "Membres de l'équipe cartographiant des lignes de circulation sur des plans",
    mission: {
      title: "Mission",
      body: "Nous entretenons un archivage vivant des analyses d'orientation afin que les institutions publiques puissent comprendre, questionner et faire évoluer leurs dispositifs."
    },
    vision: {
      title: "Vision",
      body: "Nous envisageons des environnements publics où le guidage est intuitif, inclusif et fidèle aux récits locaux."
    },
    approach: {
      title: "Approche",
      body: "Chaque projet associe immersion de terrain et synthèse analytique. Nous passons du temps dans concourses, bureaux et galeries pour documenter la réaction des outils d'orientation face aux programmes fluctuants."
    },
    methods: {
      title: "Méthodes",
      body: "Nos méthodes combinent entretiens ethnographiques, interprétation de données capteurs, blueprinting de services et récit cartographique. Cette hybridation évite les conclusions cloisonnées."
    },
    values: {
      title: "Valeurs",
      items: [
        {
          title: "Curiosité",
          body: "Nous questionnons l'expérience réelle des usagers avant toute recommandation."
        },
        {
          title: "Transparence",
          body: "Enseignements, hypothèses et limites sont partagés ouvertement avec les collaborateurs."
        },
        {
          title: "Soin",
          body: "Nous respectons les récits des visiteurs et considérons l'accessibilité comme une responsabilité collective."
        },
        {
          title: "Itération",
          body: "Nous revisitons les sites pour observer les effets, consignant réussites et ajustements nécessaires."
        }
      ]
    },
    timeline: {
      title: "Jalons",
      items: [
        {
          year: "2015",
          description: "Première documentation de la signalétique du métro bruxellois, point de départ de l'archive."
        },
        {
          year: "2017",
          description: "Partenariat avec des laboratoires de mobilité régionaux élargissant la recherche aux pôles tram et bus."
        },
        {
          year: "2020",
          description: "Lancement d'une série de publications bilingues consacrée aux districts culturels urbains."
        },
        {
          year: "2023",
          description: "Intégration d'audits d'accessibilité dans chaque projet, en collaboration avec des collectifs de plaidoyer."
        }
      ]
    },
    community: {
      title: "Pratique communautaire",
      body: "Nous organisons des salons mensuels où planificateurs, artistes et acteurs de la mobilité dissèquent les défis d'orientation et partagent leurs tactiques."
    },
    research: {
      title: "Productions de recherche",
      body: "Nos publications vont du carnet de terrain à l'atlas numérique immersif, chacun traduisant des environnements complexes en parcours lisibles."
    },
    future: {
      title: "Perspective",
      body: "Nous développons des jeux de données ouverts pour que les municipalités puissent évaluer la qualité de l'orientation sans relancer chaque étude."
    }
  },
  blog: {
    heroTitle: "Analyses issues de nos études de navigation",
    heroSubtitle: "Documentation longue explorant écosystèmes de signalétique, mobilité piétonne et dispositifs d'orientation numériques.",
    readMore: "Lire l'article",
    posts: {
      post1: {
        title: "Stratification temporelle pour les districts culturels",
        excerpt: "L'analyse des états temporels montre comment les lieux culturels adaptent signalétique, lumière et messages pour garder lisibles les programmes du soir.",
        date: "Publié le 12 avril 2024",
        alt: "Projection nocturne guidant les visiteurs dans un district culturel"
      },
      post2: {
        title: "Interfaces tactiles pour pôles multimodaux",
        excerpt: "Examen des repères tactiles complétant la signalétique visuelle au sein des halles multimodales denses.",
        date: "Publié le 22 mars 2024",
        alt: "Revêtement tactile guidant des passagers dans un hub de transport"
      },
      post3: {
        title: "Évaluer les plans interactifs de campus",
        excerpt: "Cadre de revue des plans de campus sur borne, mobile et dispositifs saisonniers.",
        date: "Publié le 27 février 2024",
        alt: "Étudiant utilisant une grande borne cartographique tactile"
      },
      post4: {
        title: "Cadres de gouvernance pour la signalétique des bâtiments publics",
        excerpt: "Définit des structures de gouvernance garantissant la cohérence de la signalétique à mesure que les bâtiments publics évoluent.",
        date: "Publié le 5 février 2024",
        alt: "Réunion autour de plans de signalétique dans un bâtiment civique"
      },
      post5: {
        title: "Mesures de lisibilité pour promenades urbaines",
        excerpt: "Mesure comment les promenades transmettent l'orientation via repères, comportements et indices sensoriels.",
        date: "Publié le 18 janvier 2024",
        alt: "Piétons marchant sur une promenade urbaine illuminée"
      }
    }
  },
  faq: {
    heroTitle: "Questions fréquentes",
    heroIntro: "Découvrez notre manière d'étudier l'orientation spatiale, de structurer les collaborations et de diffuser les résultats.",
    items: [
      {
        question: "Comment documentez-vous les défis d'orientation spatiale ?",
        answer: "Nous croisons observation in situ, marches participatives et analyses de données pour comprendre la perception des lieux. Notes, croquis et enregistrements convergent vers des rapports superposés."
      },
      {
        question: "Produisez-vous une signalétique commerciale ?",
        answer: "Non. Nous concentrons nos efforts sur la recherche et la documentation, laissant aux équipes publiques le soin d'adapter les enseignements dans leurs cadres d'achat."
      },
      {
        question: "Quels environnements étudiez-vous ?",
        answer: "Notre portefeuille couvre hubs de transport, campus civiques, districts culturels et grands sites événementiels en Belgique."
      },
      {
        question: "Comment gérez-vous les contenus multilingues ?",
        answer: "Nous auditons les politiques linguistiques, testons la compréhension avec des publics variés et recommandons des hiérarchies de formulations respectueuses du contexte local."
      },
      {
        question: "Est-il possible de demander un atelier sur mesure ?",
        answer: "Oui. Les ateliers privilégient l'analyse partagée plutôt qu'une formation commerciale, permettant aux équipes d'interpréter leurs propres résultats."
      },
      {
        question: "Quelle est votre approche des standards d'accessibilité ?",
        answer: "Les référentiels d'accessibilité guident chaque projet. Nous évaluons indices tactiles, prompts sonores, contrastes et charge cognitive."
      },
      {
        question: "Comment évaluez-vous les outils numériques ?",
        answer: "Nous organisons des sessions d'usage sur bornes, applications mobiles et postes fixes, en mesurant la réussite des tâches et le sentiment de confiance."
      },
      {
        question: "À quelle fréquence mettez-vous à jour vos publications ?",
        answer: "Les publications majeures sont actualisées deux fois par an, tandis que les notes de terrain et micro-mises à jour suivent chaque visite."
      }
    ],
    contactPrompt: "Besoin d'un éclairage supplémentaire ?",
    contactCta: "Écrivez-nous"
  },
  contact: {
    heroTitle: "Entrer en relation avec le collectif de recherche",
    heroIntro: "Partagez le contexte de votre espace afin d'aligner documentation et pistes d'analyse.",
    heroImageAlt: "Carte urbaine annotée de notes d'orientation",
    availabilityTitle: "Disponibilités",
    availabilityBody: "Nous consacrons chaque trimestre du temps à de nouveaux partenariats de terrain en Belgique. Les échanges à distance sont programmés les mardis et jeudis après-midi.",
    detailsTitle: "Coordonnées",
    phoneTitle: "Téléphone",
    phoneValue: "Appeler +32 2 403 12 87",
    emailTitle: "Courriel",
    emailValue: "Écrire à info@danswholesaleplants.com",
    hoursTitle: "Délai de réponse",
    hoursBody: "Les réponses sont généralement envoyées sous trois jours ouvrables.",
    formTitle: "Partager votre contexte spatial",
    formIntro: "Remplissez le formulaire avec une brève description de votre site. Ces informations servent uniquement à préparer l'échange.",
    form: {
      nameLabel: "Nom complet",
      namePlaceholder: "Votre nom",
      emailLabel: "Adresse courriel",
      emailPlaceholder: "nom@exemple.com",
      organisationLabel: "Organisation ou initiative",
      organisationPlaceholder: "Institution, lieu ou collectif",
      messageLabel: "Contexte spatial et questions",
      messagePlaceholder: "Décrivez l'environnement, les défis ou les objectifs",
      consentText: "En soumettant ce formulaire, vous acceptez d'être contacté à propos de la recherche en orientation spatiale.",
      submit: "Envoyer"
    },
    mapTitle: "Ancrage bruxellois",
    mapCaption: "Carte centrée sur la Rue de la Loi 155, 1040 Bruxelles."
  },
  terms: {
    heroTitle: "Conditions d'utilisation",
    heroIntro: "Veuillez lire ces conditions pour comprendre comment interagir avec le site et les publications de danswholesaleplants.",
    sections: [
      {
        title: "Champ d'application",
        body: "Ces conditions régissent l'accès au site, aux publications et aux supports associés de danswholesaleplants. L'utilisation du site vaut reconnaissance de leur nature informative."
      },
      {
        title: "Définitions",
        body: "'Contenu' désigne articles, visuels, jeux de données et téléchargements. 'Nous' renvoie à danswholesaleplants. 'Utilisateur' vise toute personne accédant au site."
      },
      {
        title: "Usage des informations",
        body: "Vous pouvez citer nos contenus à des fins pédagogiques ou institutionnelles en conservant l'attribution. Toute réutilisation à vocation commerciale nécessite une autorisation écrite préalable."
      },
      {
        title: "Intégrité de la recherche",
        body: "Nous nous efforçons de présenter des observations exactes issues du terrain et d'analyses. Les interprétations peuvent toutefois évoluer avec la transformation des lieux."
      },
      {
        title: "Propriété intellectuelle",
        body: "Sauf mention contraire, l'ensemble des contenus appartient à danswholesaleplants. Les matériaux tiers conservent leurs droits et sont crédités."
      },
      {
        title: "Contributions des lecteurs",
        body: "Si vous nous transmettez retours ou documents, vous nous autorisez à les citer ou publier dans nos travaux en mentionnant votre contribution."
      },
      {
        title: "Références externes",
        body: "Le site peut renvoyer à des ressources externes pour contexte. Nous n'en contrôlons pas le contenu ni la disponibilité."
      },
      {
        title: "Exactitude des données",
        body: "Nous cherchons à maintenir des informations à jour sans garantir l'exhaustivité. Les utilisateurs doivent vérifier les données critiques auprès des autorités compétentes."
      },
      {
        title: "Engagement accessibilité",
        body: "Nous visons des formats accessibles, incluant contenu bilingue, balisage sémantique et textes alternatifs. Les retours d'amélioration sont bienvenus."
      },
      {
        title: "Modifications du site",
        body: "Nous pouvons modifier, suspendre ou retirer des sections sans préavis. Les mises à jour n'impliquent pas d'obligation vis-à-vis des utilisateurs."
      },
      {
        title: "Limitation de responsabilité",
        body: "danswholesaleplants ne pourra être tenue responsable de dommages directs ou indirects liés à l'usage du site, à la confiance accordée aux contenus ou à une indisponibilité temporaire."
      },
      {
        title: "Droit applicable",
        body: "Les présentes conditions sont régies par le droit belge. Tout litige relève des tribunaux compétents de Bruxelles."
      },
      {
        title: "Contact",
        body: "Pour toute question relative aux conditions, écrivez à info@danswholesaleplants.com."
      },
      {
        title: "Date d'effet",
        body: "Ces conditions ont été mises à jour le 1er mai 2024."
      }
    ]
  },
  privacy: {
    heroTitle: "Notice de confidentialité",
    heroIntro: "Cette notice explique comment danswholesaleplants collecte, utilise et protège les données personnelles.",
    sections: [
      {
        title: "Responsable du traitement",
        body: "danswholesaleplants, Rue de la Loi 155, 1040 Bruxelles, Belgique, est responsable du traitement des données recueillies via ce site."
      },
      {
        title: "Données collectées",
        body: "Nous pouvons collecter noms, adresses courriel, informations organisationnelles, préférences linguistiques et choix de consentement aux cookies lors de vos interactions."
      },
      {
        title: "Méthodes de collecte",
        body: "Les données proviennent des formulaires de contact, des courriels volontaires et des mécanismes locaux qui mémorisent langue et préférences de cookies."
      },
      {
        title: "Finalités du traitement",
        body: "Nous traitons les données pour répondre aux demandes, maintenir le bilinguisme, enregistrer les choix de consentement et produire des analyses anonymisées lorsque l'autorisation est donnée."
      },
      {
        title: "Base juridique",
        body: "Le traitement repose sur votre consentement pour les communications et cookies, ainsi que sur l'intérêt légitime pour assurer sécurité et fonctionnalités essentielles."
      },
      {
        title: "Durée de conservation",
        body: "Les échanges de contact sont conservés jusqu'à douze mois après la dernière interaction. Les données liées aux cookies suivent les durées précisées dans la politique dédiée."
      },
      {
        title: "Partage des données",
        body: "Nous ne vendons aucune donnée personnelle. Les informations peuvent être partagées avec des prestataires d'hébergement et d'infrastructure soumis à confidentialité."
      },
      {
        title: "Transferts internationaux",
        body: "Les données sont stockées au sein de l'Union européenne. Si des prestataires opèrent hors UE, des garanties contractuelles équivalentes sont mises en place."
      },
      {
        title: "Mesures de sécurité",
        body: "Nous appliquons des mesures techniques et organisationnelles comme connexions chiffrées, contrôles d'accès et audits réguliers pour protéger les données."
      },
      {
        title: "Droits des personnes",
        body: "Vous pouvez demander accès, rectification, effacement, limitation du traitement ou portabilité. Vous pouvez retirer votre consentement à tout moment."
      },
      {
        title: "Demandes et réponses",
        body: "Pour exercer vos droits, contactez info@danswholesaleplants.com. Nous visons une réponse sous 30 jours à réception d'une demande complète."
      },
      {
        title: "Mises à jour de la notice",
        body: "Cette notice peut évoluer selon nos pratiques. La date d'effet sera ajustée en conséquence."
      }
    ]
  },
  cookiesPage: {
    heroTitle: "Politique de cookies",
    heroIntro: "Cette politique détaille l'usage des cookies et technologies similaires sur le site danswholesaleplants.",
    sectionTitle: "Notre utilisation des cookies",
    sectionBody: "Les cookies permettent de mémoriser la langue, d'enregistrer les décisions de consentement et d'activer, avec votre accord, des analyses destinées à améliorer la navigation.",
    preferencesTitle: "Catégories de préférence",
    preferencesIntro: "Les catégories ci-dessous correspondent aux options proposées dans notre bannière de cookies.",
    groups: {
      necessary: {
        title: "Cookies nécessaires",
        body: "Ces cookies assurent les fonctions essentielles comme la sécurité et la mémorisation du consentement. Ils sont toujours actifs."
      },
      preferences: {
        title: "Cookies de préférence",
        body: "Ils sauvegardent vos choix de langue et de présentation pour refléter l'expérience désirée."
      },
      analytics: {
        title: "Cookies d'analyse",
        body: "Activés uniquement avec votre accord, ils nous aident à comprendre les parcours agrégés et à détecter des difficultés d'orientation."
      },
      marketing: {
        title: "Cookies marketing",
        body: "Aucun traceur marketing n'est actuellement utilisé. Cette catégorie reste mentionnée pour informer de toute évolution future."
      }
    },
    tableIntro: "Les cookies utilisés sont récapitulés ci-dessous.",
    table: {
      headers: {
        name: "Nom",
        provider: "Fournisseur",
        type: "Type",
        purpose: "Finalité",
        duration: "Durée"
      },
      rows: [
        {
          name: "cookie_consent",
          provider: "danswholesaleplants",
          type: "Nécessaire",
          purpose: "Enregistre l'état de vos préférences de cookies.",
          duration: "12 mois"
        },
        {
          name: "site_lang",
          provider: "danswholesaleplants",
          type: "Préférence",
          purpose: "Mémorise la langue sélectionnée pour le site.",
          duration: "12 mois"
        },
        {
          name: "session_orientation",
          provider: "danswholesaleplants",
          type: "Analyse (optionnel)",
          purpose: "Agrège des métriques de navigation pour améliorer le contenu d'orientation lorsque l'option est activée.",
          duration: "30 minutes"
        }
      ]
    },
    consentTitle: "Gestion du consentement",
    consentBody: "Vous pouvez modifier vos choix à tout moment via la bannière ou en effaçant vos préférences dans le navigateur. Les changements sont appliqués immédiatement."
  },
  refund: {
    heroTitle: "Politique de rectification",
    heroIntro: "Bien que nous n'opérions aucune transaction commerciale, cette politique précise la manière de traiter les demandes de correction ou de retrait de contenu.",
    sections: [
      {
        title: "Objectif",
        body: "Cette politique décrit les procédures d'examen des demandes visant à modifier ou retirer un contenu associé à danswholesaleplants."
      },
      {
        title: "Portée non commerciale",
        body: "Nous ne vendons ni produits ni services. Les remboursements financiers ne s'appliquent donc pas ; notre priorité est l'exactitude informative."
      },
      {
        title: "Admissibilité à l'examen",
        body: "Les personnes ou organisations mentionnées dans nos publications peuvent solliciter des précisions ou mises à jour lorsque l'information est incomplète ou obsolète."
      },
      {
        title: "Canal de soumission",
        body: "Les demandes doivent être adressées à info@danswholesaleplants.com avec des éléments permettant d'identifier le contenu concerné."
      },
      {
        title: "Critères d'évaluation",
        body: "Nous analysons les requêtes selon les preuves fournies, leur cohérence avec nos notes de recherche et leur impact sur la compréhension publique."
      },
      {
        title: "Délais de réponse",
        body: "Nous accusons réception sous sept jours ouvrables et visons une réponse motivée dans les trente jours."
      },
      {
        title: "Actions correctives",
        body: "Si nécessaire, nous mettons à jour les articles, ajoutons des précisions ou retirons des éléments sensibles tout en conservant le contexte."
      },
      {
        title: "Traçabilité",
        body: "Toutes les demandes et leurs suites sont consignées afin d'alimenter les éditions futures et assurer la redevabilité."
      },
      {
        title: "Absence de compensation financière",
        body: "En l'absence d'échange commercial, les corrections portent uniquement sur le contenu informatif."
      },
      {
        title: "Révision de la politique",
        body: "La politique peut évoluer selon nos pratiques éditoriales. Les changements seront publiés avec une nouvelle date d'effet."
      },
      {
        title: "Contact et date d'effet",
        body: "Pour toute question, écrivez à info@danswholesaleplants.com. Cette politique est en vigueur depuis le 1er mai 2024."
      }
    ]
  },
  disclaimer: {
    heroTitle: "Avertissement",
    heroIntro: "Comprenez la portée de nos publications et les responsabilités des utilisateurs.",
    sections: [
      {
        title: "Portée informative",
        body: "Tous les contenus de ce site sont fournis à titre informatif. Ils ne constituent pas un conseil professionnel, juridique ou architectural."
      },
      {
        title: "Absence de garanties",
        body: "Nous ne garantissons pas que les informations soient exhaustives, actuelles ou exemptes d'erreurs. Les lecteurs doivent vérifier les détails avant d'agir."
      },
      {
        title: "Responsabilité des utilisateurs",
        body: "Chaque utilisateur demeure responsable de l'interprétation et de l'application des enseignements dans son propre contexte."
      },
      {
        title: "Références tierces",
        body: "Les références ou liens externes sont proposés pour situer le propos. Nous n'endossons ni ne contrôlons les contenus de tiers."
      },
      {
        title: "Évolutions futures",
        body: "Les contenus peuvent être actualisés sans préavis au fil des recherches. L'utilisation continue vaut acceptation des mises à jour."
      },
      {
        title: "Contact",
        body: "Pour toute précision au sujet de cet avertissement, contactez info@danswholesaleplants.com. Date d'effet : 1er mai 2024."
      }
    ]
  },
  thankYou: {
    heroTitle: "Merci pour votre message",
    heroIntro: "Nous avons bien reçu votre note et répondrons sous trois jours ouvrables. En attendant, explorez nos analyses récentes.",
    cta: "Retour à l'accueil"
  },
  posts: {
    backToBlog: "Retour au blog",
    post1: {
      title: "Stratification temporelle pour les districts culturels",
      intro: "Les districts culturels fonctionnent rarement sur un seul rythme. Soirées, nocturnes de galeries et ateliers communautaires se superposent dans les mêmes places et corridors. Cet article examine comment la stratification temporelle façonne des stratégies d'orientation réactives, lisibles pour les visiteurs novices comme pour les habitués du quartier.",
      heroImageAlt: "Foule nocturne circulant dans un district culturel éclairé par la signalétique",
      section1: {
        heading: "Entrelacer les données d'occupation",
        subheading: "Lire les chronologies des capteurs et l'intuition du personnel",
        paragraph1: "Les relevés horaires issus de billetteries, détecteurs Bluetooth et comptages manuels ne coïncident que rarement. Superposés sur un même axe, ils dessinent pourtant la respiration et les décrochages des lieux culturels. Nous repérons d'abord les pics convergents entre théâtres, cafés et ateliers, puis nous croisons plannings d'équipes et récits de terrain pour comprendre où le guidage fléchit sous la pression. Ce croisement révèle des points de friction : cours ouvertes devenant goulots après les saluts ou escaliers rassurants sur plan mais intimidants quand plusieurs spectacles libèrent leur public simultanément.",
        paragraph2: "Les anomalies temporelles livrent les enseignements les plus actionnables. Un patio peut fonctionner impeccablement l'après-midi mais désorienter lors d'un festival nocturne si l'éclairage met en avant les sculptures plutôt que les sorties. En comparant journaux de capteurs et programmation lumineuse, nous cartographions les minutes où la lisibilité chute. Ces résultats alimentent un modèle de segmentation temporelle : chaque zone reçoit des états basique, affluence et débordement, permettant aux équipes d'ajuster la présence humaine, la hiérarchie des messages et le préchargement des écrans dynamiques avant que la confusion ne s'installe."
      },
      section2: {
        heading: "Séquencer les repères visuels",
        subheading: "Aligner repères fixes et médias adaptatifs",
        paragraph1: "Les visiteurs s'appuient sur un mélange de repères permanents et de prompts temporaires. Nous auditons l'apparition des bannières, surfaces de projection et bornes numériques pour chaque état temporel. Les identifiants statiques doivent ancrer l'orientation ; les panneaux numériques soulignent ensuite les routes pertinentes. Lorsque ces couches entrent en compétition — par exemple une projection recouvrant une fresque directionnelle — les nouveaux arrivants hésitent. Nous cartographions les zones où la signalétique héritée doit être repositionnée ou où les murs numériques nécessitent un fond distinct pour préserver contraste et compréhension.",
        paragraph2: "Nos sprints de conception testent la vitesse de reconnaissance des détours. Des volontaires suivent des scénarios inspirés d'événements réels : premières simultanées, nocturnes prolongées, projections en plein air. Nous faisons varier l'ordre des indices, en envoyant des messages sur écrans suspendus, balises de sol et notifications portables. Les séquences les plus efficaces associent un cadre statique affirmé et une formulation numérique concise répétée trois fois le long du trajet. Ce rythme aide les visiteurs à mémoriser le détour tout en profitant de l'ambiance."
      },
      section3: {
        heading: "Synchroniser les canaux numériques",
        subheading: "Intégrer signalétique, applications et agendas culturels",
        paragraph1: "La signalétique numérique fonctionne mieux lorsqu'elle renforce les autres canaux. Nous alignons le système de gestion de contenu avec les confirmations de billets, les pop-up web et les programmes imprimés. Lorsqu'un visiteur scanne un QR code sur la place, l'affichage mobile reflète la mise en page de la borne la plus proche, limitant les changements cognitifs. Grâce aux connexions calendaires, un atelier terminé plus tôt déclenche la mise à jour simultanée de tous les supports, évitant les trajets dictés par des instructions périmées.",
        paragraph2: "La fiabilité de la synchronisation repose sur la gouvernance. Rédacteurs du district, exploitation du bâtiment et conseil de quartier partagent un journal unique de modifications. Chaque mise à jour précise l'intention, la durée estimée et des consignes de repli en cas de panne. Cette chorégraphie réduit les contradictions et garantit des annonces sur site calmes, informatives et accueillantes, même durant les périodes de pointe."
      },
      section4: {
        heading: