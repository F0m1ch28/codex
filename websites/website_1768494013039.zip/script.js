document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            navMenu.classList.toggle('is-active');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    navMenu.classList.remove('is-active');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('noblewtcrm-cookie-choice');
        if (storedChoice) {
            cookieBanner.classList.add('is-hidden');
        }

        const cookieButtons = cookieBanner.querySelectorAll('.cookie-btn');
        cookieButtons.forEach(button => {
            button.addEventListener('click', () => {
                const action = button.dataset.cookieAction || 'unspecified';
                localStorage.setItem('noblewtcrm-cookie-choice', action);
                cookieBanner.classList.add('is-hidden');
            });
        });
    }
});