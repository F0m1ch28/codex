import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Methods from './pages/Methods';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

const App = () => {
  return (
    <Router>
      <div className="app">
        <Header />
        <main className="mainContent">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/pro-nas-dresery" element={<About />} />
            <Route path="/posluhy-dresyruvannia" element={<Services />} />
            <Route path="/metodyky-dresyruvannia" element={<Methods />} />
            <Route path="/kontakty-varshava-krakiv" element={<Contact />} />
            <Route path="/umovy-vykorystannia" element={<Terms />} />
            <Route path="/polityka-konfidentsiinosti" element={<Privacy />} />
            <Route path="/polityka-cookie" element={<CookiePolicy />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <ScrollToTop />
      </div>
    </Router>
  );
};

export default App;