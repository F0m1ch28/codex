import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.brand}>
        <h3>Професійна дресирування німецьких вівчарок</h3>
        <p>
          Ми допомагаємо німецьким вівчаркам розкрити природний потенціал,
          зберігаючи баланс між дисципліною, довірою та захопленням від роботи
          поруч з людиною.
        </p>
      </div>
      <div className={styles.columns}>
        <div>
          <h4>Навігація</h4>
          <ul>
            <li>
              <Link to="/">Головна</Link>
            </li>
            <li>
              <Link to="/posluhy-dresyruvannia">Послуги</Link>
            </li>
            <li>
              <Link to="/pro-nas-dresery">Про нас</Link>
            </li>
            <li>
              <Link to="/metodyky-dresyruvannia">Методики</Link>
            </li>
            <li>
              <Link to="/kontakty-varshava-krakiv">Контакти</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4>Політика</h4>
          <ul>
            <li>
              <Link to="/umovy-vykorystannia">Умови використання</Link>
            </li>
            <li>
              <Link to="/polityka-konfidentsiinosti">Політика конфіденційності</Link>
            </li>
            <li>
              <Link to="/polityka-cookie">Політика cookie</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4>Контакти</h4>
          <ul className={styles.contactList}>
            <li>Варшава, вул. Собача, 15</li>
            <li>Краков, вул. Пастуша, 8</li>
            <li>
              <a href="tel:+48123456789">+48 123 456 789</a>
            </li>
            <li>
              <a href="mailto:info@dresyruvannia-ovcharok.pl">
                info@dresyruvannia-ovcharok.pl
              </a>
            </li>
          </ul>
          <div className={styles.socials}>
            <a href="https://www.facebook.com/" target="_blank" rel="noreferrer">
              Facebook
            </a>
            <a href="https://www.instagram.com/" target="_blank" rel="noreferrer">
              Instagram
            </a>
            <a href="https://www.youtube.com/" target="_blank" rel="noreferrer">
              YouTube
            </a>
          </div>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Професійна дресирування німецьких вівчарок. Усі права захищені.</p>
    </div>
  </footer>
);

export default Footer;