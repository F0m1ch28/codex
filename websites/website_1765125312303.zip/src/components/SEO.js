import { useEffect } from 'react';

const SEO = ({ title, description, keywords }) => {
  useEffect(() => {
    const baseTitle = 'Професійна дресирування німецьких вівчарок';
    document.title = title ? `${title} | ${baseTitle}` : baseTitle;

    const updateOrCreateMeta = (name, content) => {
      if (!content) return;
      let element = document.querySelector(`meta[name="${name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('name', name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    if (description) {
      updateOrCreateMeta('description', description);
    }
    if (keywords) {
      updateOrCreateMeta('keywords', keywords);
    }
  }, [title, description, keywords]);

  return null;
};

export default SEO;