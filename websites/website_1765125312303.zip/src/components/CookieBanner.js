import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'dogTrainingCookieConsent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(COOKIE_KEY);
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(COOKIE_KEY, 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem(COOKIE_KEY, 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        Ми використовуємо cookie, щоб персоналізувати враження та аналізувати
        статистику. Продовжуючи перегляд, ви погоджуєтесь з{' '}
        <a href="/polityka-cookie">Політикою cookie</a>.
      </p>
      <div className={styles.actions}>
        <button type="button" onClick={handleAccept}>
          Згоден
        </button>
        <button type="button" className={styles.secondary} onClick={handleDecline}>
          Відхилити
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;