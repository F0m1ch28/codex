import React, { useState } from 'react';
import styles from './ContactForm.module.css';

const initialState = {
  name: '',
  phone: '',
  email: '',
  dogAge: '',
  message: '',
};

const ContactForm = ({ compact = false }) => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [feedback, setFeedback] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Вкажіть ім’я';
    if (!formData.phone.trim()) newErrors.phone = 'Не забудьте телефон';
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Перевірте формат email';
    }
    if (!formData.message.trim()) newErrors.message = 'Опишіть запит';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value,
    }));
    setErrors((prev) => ({
      ...prev,
      [event.target.name]: '',
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setFeedback('');
    if (!validate()) return;

    const subject = encodeURIComponent('Запит на консультацію з дресирування');
    const body = encodeURIComponent(
      `Ім'я: ${formData.name}\nТелефон: ${formData.phone}\nEmail: ${formData.email}\nВік/стан собаки: ${formData.dogAge}\nЗапит: ${formData.message}`
    );

    window.location.href = `mailto:info@dresyruvannia-ovcharok.pl?subject=${subject}&body=${body}`;
    setFeedback('Дякуємо! Ми вже готуємо відповідь і скоро з вами зв’яжемося.');
    setFormData(initialState);
  };

  return (
    <form
      className={`${styles.form} ${compact ? styles.compact : ''}`}
      onSubmit={handleSubmit}
      noValidate
    >
      <div className={styles.fieldGroup}>
        <label htmlFor="name">Ім’я</label>
        <input
          id="name"
          name="name"
          type="text"
          placeholder="Як до вас звертатися?"
          value={formData.name}
          onChange={handleChange}
        />
        {errors.name && <span className={styles.error}>{errors.name}</span>}
      </div>
      <div className={styles.fieldGroup}>
        <label htmlFor="phone">Телефон</label>
        <input
          id="phone"
          name="phone"
          type="tel"
          placeholder="+48 ..."
          value={formData.phone}
          onChange={handleChange}
        />
        {errors.phone && <span className={styles.error}>{errors.phone}</span>}
      </div>
      <div className={styles.fieldGroup}>
        <label htmlFor="email">Email (за бажанням)</label>
        <input
          id="email"
          name="email"
          type="email"
          placeholder="приклад: doglover@gmail.com"
          value={formData.email}
          onChange={handleChange}
        />
        {errors.email && <span className={styles.error}>{errors.email}</span>}
      </div>
      <div className={styles.fieldGroup}>
        <label htmlFor="dogAge">Вік або рівень підготовки собаки</label>
        <input
          id="dogAge"
          name="dogAge"
          type="text"
          placeholder="Наприклад: 10 місяців, початковий рівень"
          value={formData.dogAge}
          onChange={handleChange}
        />
      </div>
      <div className={styles.fieldGroup}>
        <label htmlFor="message">Чим можемо допомогти?</label>
        <textarea
          id="message"
          name="message"
          rows="4"
          placeholder="Коротко опишіть очікування, виклики, цілі тренування..."
          value={formData.message}
          onChange={handleChange}
        />
        {errors.message && <span className={styles.error}>{errors.message}</span>}
      </div>
      <button type="submit" className={styles.submitButton}>
        Надіслати запит
      </button>
      {feedback && <p className={styles.feedback}>{feedback}</p>}
    </form>
  );
};

export default ContactForm;