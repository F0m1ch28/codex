import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import ContactForm from '../components/ContactForm';
import styles from './Home.module.css';

const statsTargets = [
  { label: 'Відпрацьованих годин з вівчарками', value: 3500, suffix: '+' },
  { label: 'Командирів та сімей, які довірилися нам', value: 240 },
  { label: 'Відзнак кінологічних асоціацій', value: 18 },
];

const testimonials = [
  {
    name: 'Оксана та Глек',
    location: 'Варшава',
    text: 'Наш дволітній самець мав шалений темперамент. Команда студії м’яко, але впевнено спрямувала енергію у спортивний послух. Тепер він зосереджений і слухняний навіть у міському шумі.',
  },
  {
    name: 'Марек і Айра',
    location: 'Краков',
    text: 'Ми готували Айру до служби в приватній охороні. Тренери поєднали роботу з інстинктами та психологічні вправи. На об’єкті собака працює стабільно, не реагує на провокації.',
  },
  {
    name: 'Анна з Дасті',
    location: 'Варшава',
    text: 'Дасті – молодий пес, боявся натовпу та метро. Завдяки спеціальним протоколам адаптації і ігор з довірою, він впевнено пересувається містом і насолоджується новими досвідами.',
  },
];

const projects = [
  {
    id: 1,
    title: 'Підготовка пари вівчарок до служби охорони',
    category: 'захист',
    description:
      'Комплексні тренування на злагодженість, перевірки на блок-постах, робота з фігурантом у міських умовах Кракова.',
    image: 'https://picsum.photos/1200/800?random=41',
  },
  {
    id: 2,
    title: 'Сімейний курс для молодої вівчарки',
    category: 'сімейний супровід',
    description:
      'Індивідуальна програма соціалізації: реакція на дітей, інші тварини, робота із сигналами заспокоєння.',
    image: 'https://picsum.photos/1200/800?random=42',
  },
  {
    id: 3,
    title: 'Пошуково-рятувальна підготовка',
    category: 'спецпризначення',
    description:
      'Створення сценаріїв з різними запаховими слідами, тренування у лісових масивах Малопольщі та промзонах.',
    image: 'https://picsum.photos/1200/800?random=43',
  },
];

const faqItems = [
  {
    question: 'З якого віку можна починати заняття з німецькою вівчаркою?',
    answer:
      'Ми приймаємо щенят від трьох місяців для м’якої соціалізації та формування контролюваної цікавості. Повноцінні тренування з дисципліни та захисту стартують після зубної зміни та консультації з ветеринаром.',
  },
  {
    question: 'Чи працюєте ви з проблемною поведінкою?',
    answer:
      'Так. Ми аналізуємо причини тривожності, надмірної охорони чи збудження. У план включаємо вправи на самоконтроль, мікро-рутини, роботу з емоційним станом власника та контроль оточення.',
  },
  {
    question: 'Скільки часу займає підготовка до випробувань IPO/IGP?',
    answer:
      'У середньому від 6 до 12 місяців залежно від попереднього досвіду пса та цілей власника. Проводимо тестування стартових навичок, після чого узгоджуємо план на блоки з проміжними перевірками.',
  },
  {
    question: 'Чи можливий виїзд тренера додому?',
    answer:
      'Так, ми покриваємо Варшаву та Краків, а також околиці. Виїзди плануємо за попереднім графіком, поєднуючи з заняттями на наших майданчиках для комплексного результату.',
  },
];

const blogPosts = [
  {
    id: 1,
    title: '5 сигналів, що німецькій вівчарці потрібна розумова робота',
    summary:
      'Розповідаємо, як відрізнити здорову активність від перенавантаження нервової системи і які вправи допомагають відновити баланс.',
    link: '/metodyky-dresyruvannia',
    image: 'https://picsum.photos/800/600?random=51',
  },
  {
    id: 2,
    title: 'Системний процес введення командного послуху',
    summary:
      'Покроковий алгоритм формування стабільної відповіді на команду з урахуванням моторики та темпераменту вівчарки.',
    link: '/posluhy-dresyruvannia',
    image: 'https://picsum.photos/800/600?random=52',
  },
  {
    id: 3,
    title: 'Як поєднати охоронні навички з сімейною поведінкою',
    summary:
      'Практичні поради для власників, які очікують від собаки одночасно пильності та дружелюбності в повсякденні.',
    link: '/pro-nas-dresery',
    image: 'https://picsum.photos/800/600?random=53',
  },
];

const Home = () => {
  const [stats, setStats] = useState(statsTargets.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [projectFilter, setProjectFilter] = useState('all');
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    const intervals = statsTargets.map((stat, index) => {
      let current = 0;
      const increment = Math.ceil(stat.value / 120);
      return setInterval(() => {
        current += increment;
        if (current >= stat.value) {
          current = stat.value;
          clearInterval(intervals[index]);
        }
        setStats((prev) => {
          const copy = [...prev];
          copy[index] = current;
          return copy;
        });
      }, 20);
    });
    return () => intervals.forEach((interval) => clearInterval(interval));
  }, []);

  useEffect(() => {
    const rotate = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(rotate);
  }, []);

  const filteredProjects =
    projectFilter === 'all'
      ? projects
      : projects.filter((project) => project.category === projectFilter);

  const toggleFaq = (idx) => {
    setOpenFaq((prev) => (prev === idx ? null : idx));
  };

  return (
    <>
      <SEO
        title="Головна"
        description="Дресирування німецьких вівчарок у Варшаві та Кракові. Індивідуальні програми, спорт, захист і сімейне виховання від сертифікованих тренерів."
        keywords="дресирування німецьких вівчарок, Варшава, Краков, корекція поведінки, захисна дресура, послух"
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.preTitle}>Варшава • Краков • Польща</p>
          <h1>
            Професійна дресирування німецьких вівчарок у Варшаві та Кракові
          </h1>
          <p className={styles.heroSubtitle}>
            Формуємо керованих, сміливих та стабільних партнерів. Авторські
            програми, адаптовані під темперамент, генетику та ваші запити – від
            першої соціалізації до підготовки до іспитів IPO та спеціалізацій.
          </p>
          <div className={styles.heroActions}>
            <Link to="/posluhy-dresyruvannia" className={styles.primaryButton}>
              Дізнатися про послуги
            </Link>
            <Link to="/kontakty-varshava-krakiv" className={styles.secondaryButton}>
              Отримати індивідуальний план
            </Link>
          </div>
        </div>
        <div className={styles.heroMedia}>
          <img
            src="https://picsum.photos/1600/900?random=21"
            alt="Німецька вівчарка на тренуванні з тренером у Варшаві"
          />
          <span className={styles.photoCredit}>Фото: picsum.photos</span>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsTargets.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {stats[index]}
                  {stat.suffix}
                </span>
                <p>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.specialization}>
        <div className="container">
          <div className={styles.specializationGrid}>
            <div>
              <h2>Чому ми концентруємося на німецьких вівчарках</h2>
              <p>
                Вівчарки – собаки з потужним робочим потенціалом, які потребують
                уважної, структурованої та різноманітної діяльності. Ми
                створили середовище, де можна розвивати їхні природні якості:
                від відданості та інтелекту до витривалості й інстинктів
                охорони.
              </p>
              <p>
                Кожна програма передбачає аудит темпераменту, генетичної лінії,
                попереднього досвіду і очікувань власника. Працюємо без
                примусу, поєднуючи мотиваційні методи, чіткі рамки та
                багатоступеневі протоколи безпеки.
              </p>
              <Link to="/metodyky-dresyruvannia" className={styles.linkButton}>
                Переглянути методики
              </Link>
            </div>
            <div className={styles.specializationMedia}>
              <img
                src="https://picsum.photos/800/600?random=22"
                alt="Тренування з фігурантом та німецькою вівчаркою"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.servicesPreview}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Наші ключові напрямки</h2>
            <p>
              Утримуємо баланс між спортивним драйвом і стабільністю у побуті,
              забезпечуючи безпечний прогрес для собаки та всієї родини.
            </p>
          </div>
          <div className={styles.serviceCards}>
            <div className={styles.serviceCard}>
              <h3>Виховання щенят</h3>
              <p>
                Стартові ритуали, соціалізація у місті, контроль імпульсів,
                формування слухняності і гри за правилами.
              </p>
            </div>
            <div className={styles.serviceCard}>
              <h3>Послух і керованість</h3>
              <p>
                Побудова чітких команд, витримка, робота поруч, закріплення
                навичок через симуляції щоденних ситуацій.
              </p>
            </div>
            <div className={styles.serviceCard}>
              <h3>Захисна та службова підготовка</h3>
              <p>
                Вправи з фігурантом, розвиток хвату, робота на стрес-стійкість,
                комплексні сценарії для охорони.
              </p>
            </div>
            <div className={styles.serviceCard}>
              <h3>Корекція поведінки</h3>
              <p>
                Робота з реактивністю, тривожністю, агресією, переналаштування
                рутин та підвищення впевненості собаки.
              </p>
            </div>
          </div>
          <Link to="/posluhy-dresyruvannia" className={styles.outlineButton}>
            Всі послуги та формати
          </Link>
        </div>
      </section>

      <section className={styles.geography}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Працюємо у двох містах без компромісів</h2>
            <p>
              Локації з безпечними майданчиками, закритими залами, зонами невідкладної
              допомоги та виїзними тренуваннями.
            </p>
          </div>
          <div className={styles.geoGrid}>
            <div className={styles.geoCard}>
              <h3>Варшава</h3>
              <p>вул. Собача, 15</p>
              <ul>
                <li>Майданчик з варіативними поверхнями</li>
                <li>Сучасний манеж для зимових занять</li>
                <li>Сесії соціалізації у міському просторі</li>
              </ul>
            </div>
            <div className={styles.geoCard}>
              <h3>Краков</h3>
              <p>вул. Пастуша, 8</p>
              <ul>
                <li>Спеціалізовані маршрути для розшуку</li>
                <li>Підготовка до роботи на охоронних об’єктах</li>
                <li>Групові заняття у вихідні дні</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.advantages}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Наші принципи і переваги</h2>
          </div>
          <div className={styles.advGrid}>
            <div className={styles.advCard}>
              <h3>Вузька спеціалізація</h3>
              <p>
                Працюємо виключно з німецькими вівчарками, знаємо особливості
                характеру робочих та шоу-ліній.
              </p>
            </div>
            <div className={styles.advCard}>
              <h3>Прозорий прогрес</h3>
              <p>
                Після кожного блоку отримуєте відеозвіт, чек-лист домашніх
                вправ та рекомендації з догляду.
              </p>
            </div>
            <div className={styles.advCard}>
              <h3>Безпечні методики</h3>
              <p>
                Використовуємо мотиваційні техніки, чіткі правила і поступове
                ускладнення без застосування жорстких методів.
              </p>
            </div>
            <div className={styles.advCard}>
              <h3>Командна робота</h3>
              <p>
                Тренери, кінологи, кінопсихологи, ветеринари працюють в одному
                інформаційному полі для стабільного результату.
              </p>
            </div>
            <div className={styles.advCard}>
              <h3>Індивідуальні сценарії</h3>
              <p>
                Кожна програма адаптується до вашого ритму життя, графіку
                роботи та конкретних викликів.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Як вибудовуємо процес тренувань</h2>
          </div>
          <div className={styles.timeline}>
            <div className={styles.timelineStep}>
              <span>01</span>
              <h4>Діагностика і консультація</h4>
              <p>
                Знайомимося з собакою, оцінюємо темперамент, базові навички,
                ваші цілі та умови життя.
              </p>
            </div>
            <div className={styles.timelineStep}>
              <span>02</span>
              <h4>Проектування програми</h4>
              <p>
                Формуємо тижневий цикл, список вправ, критерії прогресу і
                обираємо зручний формат занять.
              </p>
            </div>
            <div className={styles.timelineStep}>
              <span>03</span>
              <h4>Впровадження і супровід</h4>
              <p>
                Проводимо тренування, даємо домашні завдання, відстежуємо
                поведінкові показники, коригуємо план.
              </p>
            </div>
            <div className={styles.timelineStep}>
              <span>04</span>
              <h4>Результат і підтримка</h4>
              <p>
                Готуємо звіт, підказки з підтримки форми, пропонуємо
                наступні рівні або спеціалізації.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.testimonialCard}>
            <p className={styles.testimonialText}>
              “{testimonials[testimonialIndex].text}”
            </p>
            <div className={styles.testimonialMeta}>
              <strong>{testimonials[testimonialIndex].name}</strong>
              <span>{testimonials[testimonialIndex].location}</span>
            </div>
            <div className={styles.controls}>
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => setTestimonialIndex(index)}
                  className={
                    index === testimonialIndex ? styles.dotActive : styles.dot
                  }
                  aria-label={`Відгук ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Команда, яка працює з вашою вівчаркою</h2>
          </div>
          <div className={styles.teamGrid}>
            <div className={styles.teamCard}>
              <img
                src="https://picsum.photos/400/400?random=31"
                alt="Сертифікований кінолог Андрій"
              />
              <h3>Андрій Малиш</h3>
              <p>Головний тренер, спеціаліст IGP</p>
              <span>
                12 років досвіду, суддя клубних змагань, автор програм з
                керованої агресії.
              </span>
            </div>
            <div className={styles.teamCard}>
              <img
                src="https://picsum.photos/400/400?random=32"
                alt="Кінопсихолог Ірина"
              />
              <h3>Ірина Зєлінська</h3>
              <p>Кінопсихолог, спеціаліст з поведінки</p>
              <span>
                Працює з реактивністю, страхами та емоційним балансом, веде
                підтримку власників.
              </span>
            </div>
            <div className={styles.teamCard}>
              <img
                src="https://picsum.photos/400/400?random=33"
                alt="Фігурант тренувань Мирон"
              />
              <h3>Мирон Крук</h3>
              <p>Фігурант та інструктор із захисту</p>
              <span>
                Спеціалізується на побудові хвату, роботі з обладнанням і
                безпечних сценаріях для охорони.
              </span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Приклади реалізованих програм</h2>
            <div className={styles.filters}>
              <button
                type="button"
                onClick={() => setProjectFilter('all')}
                className={projectFilter === 'all' ? styles.filterActive : ''}
              >
                Усе
              </button>
              <button
                type="button"
                onClick={() => setProjectFilter('захист')}
                className={projectFilter === 'захист' ? styles.filterActive : ''}
              >
                Захист
              </button>
              <button
                type="button"
                onClick={() => setProjectFilter('сімейний супровід')}
                className={
                  projectFilter === 'сімейний супровід' ? styles.filterActive : ''
                }
              >
                Сім’я
              </button>
              <button
                type="button"
                onClick={() => setProjectFilter('спецпризначення')}
                className={
                  projectFilter === 'спецпризначення' ? styles.filterActive : ''
                }
              >
                Спецпризначення
              </button>
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <span className={styles.projectTag}>{project.category}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Питання, які нам ставлять найчастіше</h2>
          </div>
          <div className={styles.accordion}>
            {faqItems.map((item, idx) => (
              <div key={item.question} className={styles.accordionItem}>
                <button
                  type="button"
                  className={styles.accordionTrigger}
                  onClick={() => toggleFaq(idx)}
                  aria-expanded={openFaq === idx}
                >
                  <span>{item.question}</span>
                  <span>{openFaq === idx ? '−' : '+'}</span>
                </button>
                {openFaq === idx && (
                  <div className={styles.accordionContent}>
                    <p>{item.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Останні нотатки та рекомендації</h2>
            <p>
              Ділимося аналізом кейсів, методами, які працюють, та інсайтами з
              тренувальних майданчиків Варшави і Кракова.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div>
                  <h3>{post.title}</h3>
                  <p>{post.summary}</p>
                  <Link to={post.link} className={styles.linkButton}>
                    Читати далі
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div className={styles.ctaText}>
              <h2>Готові зробити перший крок?</h2>
              <p>
                Розкажіть про свого собаку, і ми підготуємо індивідуальний план
                дій. Залиште контакти – зателефонуємо, щоб узгодити зручний
                формат та графік тренувань.
              </p>
              <ul>
                <li>Індивідуальна програма під ваші задачі</li>
                <li>Виїзні та стаціонарні заняття</li>
                <li>Супровід від першого уроку до стабільного результату</li>
              </ul>
            </div>
            <ContactForm compact />
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;