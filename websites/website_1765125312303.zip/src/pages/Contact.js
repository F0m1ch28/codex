import React from 'react';
import SEO from '../components/SEO';
import ContactForm from '../components/ContactForm';
import styles from './Contact.module.css';

const Contact = () => (
  <>
    <SEO
      title="Контакти"
      description="Контакти тренувальних майданчиків у Варшаві та Кракові. Запишіться на консультацію з дресирування німецьких вівчарок."
      keywords="контакти дресирувальників, Варшава, Краков, телефон, email, дресирування німецьких вівчарок"
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>Контакти Варшава та Краков</h1>
        <p>
          Залишайте заявку або телефонуйте – узгодимо діагностичне заняття,
          формат тренувань та графік. Працюємо за попереднім записом.
        </p>
      </div>
    </section>

    <section className={styles.contactSection}>
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.info}>
            <h2>Зв’яжіться з нами</h2>
            <ul>
              <li>
                <strong>Телефон:</strong>{' '}
                <a href="tel:+48123456789">+48 123 456 789</a>
              </li>
              <li>
                <strong>Email:</strong>{' '}
                <a href="mailto:info@dresyruvannia-ovcharok.pl">
                  info@dresyruvannia-ovcharok.pl
                </a>
              </li>
              <li>
                <strong>Варшава:</strong> вул. Собача, 15
              </li>
              <li>
                <strong>Краков:</strong> вул. Пастуша, 8
              </li>
            </ul>
            <p>
              Приймаємо запити українською, польською та англійською мовами.
              Після консультації підготуємо індивідуальний план із часовими рамками
              та рекомендаціями щодо підготовки.
            </p>
          </div>
          <div className={styles.formWrap}>
            <ContactForm />
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Contact;