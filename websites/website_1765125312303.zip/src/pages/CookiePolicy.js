import React from 'react';
import SEO from '../components/SEO';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <SEO
      title="Політика cookie"
      description="Політика використання cookie-файлів на сайті «Професійна дресирування німецьких вівчарок»."
      keywords="політика cookie, використання cookie, файл cookie"
    />
    <section className={styles.section}>
      <div className="container">
        <h1>Політика cookie</h1>
        <p>Останнє оновлення: {new Date().toLocaleDateString('uk-UA')}</p>
        <h2>1. Що таке cookie</h2>
        <p>
          Cookie – це невеликі файли, які зберігаються у браузері користувача
          для полегшення навігації та аналізу використання сайту.
        </p>
        <h2>2. Які cookie ми використовуємо</h2>
        <p>
          Аналітичні cookie допомагають зрозуміти, як відвідувачі користуються
          сайтом, що дозволяє покращувати контент і структуру.
        </p>
        <h2>3. Як керувати cookie</h2>
        <p>
          Ви можете вимкнути cookie у налаштуваннях браузера або скористатися
          банером згоди на нашому сайті.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;