document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      primaryNav.classList.toggle("open");
    });

    primaryNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.setAttribute("aria-expanded", "false");
        primaryNav.classList.remove("open");
      });
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  const acceptCookies = document.getElementById("accept-cookies");
  const declineCookies = document.getElementById("decline-cookies");
  const storageKey = "caninfratech-cookie-consent";

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(storageKey);
    if (storedConsent) {
      cookieBanner.classList.add("hidden");
    } else {
      cookieBanner.classList.remove("hidden");
    }

    [acceptCookies, declineCookies].forEach((button) => {
      if (button) {
        button.addEventListener("click", () => {
          localStorage.setItem(storageKey, button.id === "accept-cookies" ? "accepted" : "declined");
          cookieBanner.classList.add("hidden");
        });
      }
    });
  }
});

(function clientRedirects() {
  const redirectMap = {
    "/history": "field-records.html",
    "/infrastructure": "methods.html",
    "/systems": "documentation.html",
    "/resilience": "lifecycle.html"
  };
  const path = window.location.pathname.replace(/\/+$/, "");
  if (redirectMap[path]) {
    window.location.replace(redirectMap[path]);
  }
})();