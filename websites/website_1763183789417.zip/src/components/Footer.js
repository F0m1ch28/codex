import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className="layout">
        <div className={styles.grid}>
          <div>
            <h3 className={styles.brand}>
              <span className={styles.brandAccent}>Tech</span>Solutions
            </h3>
            <p className={styles.text}>
              Guiding enterprises through cloud adoption, modernization, and digital transformation with tailored consulting expertise.
            </p>
          </div>
          <div>
            <h4 className={styles.heading}>Contact</h4>
            <ul className={styles.list}>
              <li>123 Innovation Street, Tech Park, San Francisco, CA 94105</li>
              <li><a href="tel:+15551234567">+1 (555) 123-4567</a></li>
              <li><a href="mailto:info@techsolutions.com">info@techsolutions.com</a></li>
            </ul>
          </div>
          <div>
            <h4 className={styles.heading}>Quick Links</h4>
            <ul className={styles.linkList}>
              <li><Link to="/services">Services</Link></li>
              <li><Link to="/about">About</Link></li>
              <li><Link to="/contact">Contact</Link></li>
            </ul>
          </div>
          <div>
            <h4 className={styles.heading}>Legal</h4>
            <ul className={styles.linkList}>
              <li><Link to="/privacy">Privacy Policy</Link></li>
              <li><Link to="/terms">Terms of Use</Link></li>
              <li><Link to="/cookie-policy">Cookie Policy</Link></li>
            </ul>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>© {new Date().getFullYear()} TechSolutions. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;