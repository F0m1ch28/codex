document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      siteNav.classList.toggle("open");
    });
  }

  document.querySelectorAll(".site-nav a").forEach(link => {
    link.addEventListener("click", () => {
      if (siteNav.classList.contains("open")) {
        siteNav.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  });

  const sections = document.querySelectorAll(".fade-section");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    sections.forEach(section => observer.observe(section));
  } else {
    sections.forEach(section => section.classList.add("visible"));
  }

  const yearTarget = document.querySelectorAll("[data-year]");
  const currentYear = new Date().getFullYear();
  yearTarget.forEach(span => {
    span.textContent = currentYear;
  });

  const cookieBanner = document.getElementById("cookieBanner");
  const acceptBtn = cookieBanner ? cookieBanner.querySelector("[data-cookie-accept]") : null;
  const declineBtn = cookieBanner ? cookieBanner.querySelector("[data-cookie-decline]") : null;
  const cookieKey = "davebondiart_cookie_pref";

  const hideBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
  };

  if (cookieBanner) {
    const storedChoice = localStorage.getItem(cookieKey);
    if (!storedChoice) {
      setTimeout(() => cookieBanner.classList.add("active"), 600);
    }
    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => {
        localStorage.setItem(cookieKey, "accepted");
        hideBanner();
        createToast("Cookies accepted. Thank you for helping us improve the experience.");
      });
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => {
        localStorage.setItem(cookieKey, "declined");
        hideBanner();
        createToast("Cookies declined. Essential features remain active.");
      });
    }
  }

  const forms = document.querySelectorAll("form[data-enhanced='true']");
  forms.forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      createToast("Message received. Redirecting...");
      const redirect = form.getAttribute("action") || "thank-you.html";
      setTimeout(() => {
        window.location.href = redirect;
      }, 1200);
    });
  });
});

function createToast(message) {
  const existing = document.querySelector(".toast");
  if (existing) {
    existing.remove();
  }
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.setAttribute("role", "status");
  toast.setAttribute("aria-live", "polite");
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translate(-50%, 20px)";
  }, 2600);
  setTimeout(() => {
    toast.remove();
  }, 3000);
}