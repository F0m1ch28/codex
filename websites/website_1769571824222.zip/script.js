const DEFAULT_LANG = "fr";
const LANG_KEY = "site_lang";
const COOKIE_KEY = "cookie_consent";
const TOAST_DURATION = 4200;
let currentLang = DEFAULT_LANG;

const I18N = {
  fr: {
    meta: {
      title: {
        home: "danswholesaleplants — Orientation spatiale et signalétique numérique",
        services: "Méthodologies d’orientation — danswholesaleplants",
        about: "Profil institutionnel — danswholesaleplants",
        blog: "Chroniques de navigation intérieure — danswholesaleplants",
        contact: "Coordonnées et interactions — danswholesaleplants",
        faq: "FAQ sur la navigation spatiale — danswholesaleplants",
        terms: "Conditions d’utilisation — danswholesaleplants",
        privacy: "Politique de confidentialité — danswholesaleplants",
        cookies: "Politique relative aux cookies — danswholesaleplants",
        refund: "Politique de réexamen — danswholesaleplants",
        disclaimer: "Avertissement — danswholesaleplants",
        thankyou: "Merci pour votre message — danswholesaleplants",
        post1: "Hiérarchies d’orientation dans les centres culturels pluriels",
        post2: "Cartographie narrative pour environnements universitaires complexes",
        post3: "Guidage visuel au sein des hubs de transport multimodaux",
        post4: "Interfaces tactiles et accessibilité dans les bâtiments publics",
        post5: "Flux piétons et lisibilité des espaces urbains stratifiés"
      },
      description: {
        home: "Plateforme d’analyse sur l’orientation spatiale, la signalétique numérique et les cartographies interactives appliquées aux environnements bâtis en Belgique.",
        services: "Panorama des approches analytiques et scénarios méthodologiques pour optimiser la navigation intérieure et extérieure.",
        about: "Présentation de la démarche éditoriale centrée sur la recherche en guidage visuel et UX spatiale au sein d’infrastructures publiques.",
        blog: "Sélection d’articles approfondis sur les parcours utilisateurs, la lisibilité des espaces et le design informationnel.",
        contact: "Coordonnées, carte et formulaire pour dialoguer autour des enjeux de signalétique et d’accessibilité.",
        faq: "Questions récurrentes concernant les méthodes d’analyse de mobilité piétonne et la cartographie des espaces complexes.",
        terms: "Conditions d’utilisation décrivant les responsabilités, droits et limites du site danswholesaleplants.",
        privacy: "Politique de confidentialité précisant la collecte, l’usage et la conservation des données liées à danswholesaleplants.",
        cookies: "Informations détaillées sur les cookies employés et les options de paramétrage disponibles.",
        refund: "Politique de réexamen expliquant les démarches d’actualisation de contenus et de corrections éditoriales.",
        disclaimer: "Avertissement indiquant les limites de responsabilité et l’absence d’engagement contractuel.",
        thankyou: "Confirmation de réception pour les messages envoyés via le formulaire de contact.",
        post1: "Étude approfondie des hiérarchies d’orientation dans les centres culturels multi-niveaux en Belgique.",
        post2: "Analyse des cartographies narratives pour campus universitaires à forte densité fonctionnelle.",
        post3: "Examens des dispositifs de guidage visuel des hubs de transport multimodaux européens.",
        post4: "Évaluation des interfaces tactiles et de l’accessibilité dans les bâtiments publics interconnectés.",
        post5: "Observation des flux piétons et de la lisibilité des espaces urbains stratifiés."
      }
    },
    header: {
      brand: "danswholesaleplants",
      menuLabel: "Basculer la navigation",
      menuOpen: "Ouvrir le menu",
      menuClose: "Fermer le menu"
    },
    nav: {
      home: "Accueil",
      services: "Approches",
      about: "Profil",
      blog: "Analyses",
      faq: "FAQ",
      contact: "Contact"
    },
    language: {
      label: "Choisir la langue",
      fr: "FR",
      en: "EN"
    },
    buttons: {
      readMore: "En savoir plus",
      discover: "Explorer",
      viewDetails: "Consulter",
      download: "Visualiser",
      manage: "Gérer"
    },
    home: {
      hero: {
        heading: "Cartographier l’expérience spatiale dans les environnements publics complexes",
        subheading: "danswholesaleplants rassemble analyses, retours d’expérience et cadres méthodologiques pour comprendre comment la signalétique numérique et les repères physiques orientent les usagers dans les architectures flexibles de Belgique.",
        bullet1: "Observation des parcours piétons et corrélation avec les usages hybrides des bâtiments",
        bullet2: "Construction de matrices de décision pour la lisibilité des plans interactifs",
        bullet3: "Évaluation de la perception sensorielle des repères et de leur synchronisation visuelle",
        cta: "Explorer les axes d’étude",
        imageAlt: "Personne examinant une carte numérique dans un atrium lumineux"
      },
      featured: {
        badge: "Axes structurants",
        title: "Analyser, synthétiser et scénariser la navigation intérieure",
        description: "Chaque étude consolide des données qualitatives et quantitatives afin de traduire des environnements denses en expériences compréhensibles, du premier point de contact aux décisions de micro-orientation.",
        card1: {
          title: "Matrices de lisibilité",
          text: "Décomposition des flux et articulation des repères textuels, iconiques et dynamiques pour conserver un degré de lisibilité constant malgré l’hétérogénéité programmatique."
        },
        card2: {
          title: "Scénarios utilisateurs",
          text: "Projection de situations contrastées — mobilité réduite, besoins linguistiques, temporalités nocturnes — pour mesurer l’adaptabilité des parcours proposés."
        },
        card3: {
          title: "Écologie des supports",
          text: "Coordination entre signalétique physique, cartographie interactive et notifications situées afin d’éviter la saturation ou les fractures narratives."
        }
      },
      narrative: {
        badge: "Synthèses",
        title: "Comprendre comment chaque signal guide l’attention",
        description: "Les synthèses associent croquis d’orientation, observations in situ et modélisations comportementales pour produire des trames narratives exploitables par les équipes pluridisciplinaires.",
        item1: {
          title: "Cartes de chaleur piétonnes",
          text: "Superposition des trajectoires observées avec les intentions de design pour déceler les zones de friction ou d’ambiguïté décisionnelle."
        },
        item2: {
          title: "Protocoles d’accessibilité",
          text: "Analyse des contrastes visuels, opportunités tactiles, dispositifs sonores et qualité des transitions d’éclairage dans les séquences de guidage."
        },
        item3: {
          title: "Systèmes multicouches",
          text: "Organisation hiérarchisée des informations selon les distances, la densité des intersections et le degré de familiarité des publics ciblés."
        }
      },
      recommendations: {
        title: "Recommandations éditoriales",
        description: "Ces recommandations s’appuient sur des rapports d’audit menés avec des collectivités et gestionnaires d’infrastructures désireux de renforcer la cohérence de leur réseau d’orientation.",
        card1: {
          title: "Documenter les seuils",
          text: "Cartographier chaque seuil d’entrée comme moment clé de synchronisation des repères physiques et numériques afin de sécuriser la continuité du parcours."
        },
        card2: {
          title: "Clarifier les croisements",
          text: "Positionner des balises narratives sur les intersections critiques et hiérarchiser les choix secondaires pour limiter les hésitations cumulatives."
        },
        card3: {
          title: "Temporaliser les informations",
          text: "Introduire des couches d’information temporelle pour anticiper les variations d’usage quotidiennes, hebdomadaires ou saisonnières."
        },
        card4: {
          title: "Outiller la maintenance",
          text: "Mettre en place une gouvernance partagée des contenus, facilitant la mise à jour coordonnée des supports physiques et digitaux."
        }
      },
      testimonials: {
        title: "Retours d’expérience",
        description: "Des responsables de sites publics partagent les effets mesurés après la refonte de leur dispositif d’orientation.",
        quote1: {
          text: "La cartographie scénarisée nous a permis d’aligner les parcours officiels sur les usages réels. Les visiteurs accèdent plus rapidement aux espaces clés et les équipes d’accueil gagnent en sérénité.",
          author: "Maïa Delcroix",
          role: "Coordination culturelle, centre polyvalent bruxellois"
        },
        quote2: {
          text: "La comparaison systématique entre flux observés et flux attendus a été décisive. Nous pouvons désormais hiérarchiser les investissements de mise à jour de nos supports d’orientation.",
          author: "Jonas Lievens",
          role: "Gestion des mobilités, consortium universitaire flamand"
        },
        quote3: {
          text: "Les tableaux de bord fournis facilitent les arbitrages entre signalétique statique et interfaces tactiles. L’équipe maintenance dispose d’un plan de suivi clair.",
          author: "Elena Vanneste",
          role: "Responsable infrastructure, réseau muséal wallon"
        }
      },
      observatory: {
        title: "Observatoire des environnements complexes",
        description: "Sélection de notes d’études dédiées aux grands équipements culturels, aux campus tertiaires densifiés et aux pôles d’échanges intermodaux.",
        item1: {
          title: "Atriums polyfonctionnels",
          text: "Analyse de l’influence des volumes verticaux et des vues superposées sur l’orientation spontanée."
        },
        item2: {
          title: "Passerelles numériques",
          text: "Étude des interactions entre murs LED informatifs et balisages directionnels."
        },
        item3: {
          title: "Quartiers connectés",
          text: "Évaluation des repères tactiles dans les séquences piétonnes prolongées."
        }
      }
    },
    services: {
      hero: {
        title: "Approches d’analyse pour l’orientation spatiale",
        lead: "Chaque approche repose sur des protocoles observables, des maquettes narratives et des mesures de performance dédiées à la circulation piétonne dans les environnements publics."
      },
      sections: {
        item1: {
          title: "Diagnostic des repères structurants",
          text: "Inventaire des éléments graphiques, lumineux et sonores présents dans les espaces, suivi d’une hiérarchisation basée sur leur capacité à orienter des profils hétérogènes."
        },
        item2: {
          title: "Modélisation des parcours utilisateurs",
          text: "Construction de cartes de parcours multi-scénarios prenant en compte la durée des trajets, les bifurcations et les points d’attention nécessaires à la prise de décision."
        },
        item3: {
          title: "Architecture de l’information spatiale",
          text: "Organisation des contenus textuels, iconographiques et cartographiques, en veillant à la cohérence sémantique entre dispositifs physiques et interfaces numériques."
        },
        item4: {
          title: "Expérience tactile et interactive",
          text: "Analyse des écrans, kiosques et plans tactiles, avec une attention particulière portée aux transitions entre supports et aux options d’accessibilité."
        },
        item5: {
          title: "Cadres d’accessibilité inclusive",
          text: "Évaluation des contrastes, de la signalétique en relief, des dispositifs sonores et des chemins de circulation compatibles avec divers usages et mobilités."
        }
      },
      methodology: {
        title: "Structure méthodologique",
        text: "Les travaux combinent observation de terrain, entretiens, captations vidéos anonymisées et benchmarks européens. Chaque livrable inclut une cartographie des dépendances, une analyse de risque et des recommandations de gouvernance."
      },
      outcomes: {
        title: "Livrables types",
        list: {
          a: "Cartes narratives haute résolution intégrant les gradients de densité piétonne.",
          b: "Fiches critères pour évaluer la lisibilité des intersections et des axes secondaires.",
          c: "Tableaux de bord quantitatifs pour suivre l’évolution des indicateurs de compréhension spatiale."
        }
      }
    },
    about: {
      hero: {
        title: "Contextualiser la recherche sur le guidage visuel",
        lead: "danswholesaleplants articule des ressources internationales et des études in situ menées sur le territoire belge pour éclairer la complexité des infrastructures publiques."
      },
      mission: {
        title: "Une mission centrée sur la compréhension spatiale",
        text: "La démarche croise urbanisme, design informationnel et sciences comportementales. Les analyses privilégient les retours d’usage, l’anticipation des flux et la traduction des contraintes techniques en expériences lisibles."
      },
      pillars: {
        title: "Piliers éditoriaux",
        item1: {
          title: "Observation situées",
          text: "Captations discrètes et cartographies d’usage dans des bâtiments à forte densité fonctionnelle."
        },
        item2: {
          title: "Transparence méthodologique",
          text: "Publication des variables observées, des biais potentiels et des limites de chaque protocole."
        },
        item3: {
          title: "Diffusion ouverte",
          text: "Mise à disposition de grilles de lecture pour les acteurs publics et associatifs."
        }
      },
      team: {
        title: "Coopérations expertes",
        text: "Le projet collabore avec des collectivités, chercheurs en UX spatiale, architectes, designers graphiques et spécialistes de la data pour consolider les analyses et préparer des recommandations transversales."
      }
    },
    blog: {
      hero: {
        title: "Chroniques dédiées à la navigation intérieure",
        lead: "Chaque article explore une configuration spatiale singulière, en confrontant l’intention architecturale aux comportements observés."
      },
      listing: {
        intro: "Sélection récente",
        post1: {
          title: "Hiérarchies d’orientation dans les centres culturels pluriels",
          excerpt: "Comment articuler signalétique lumineuse, repères tactiles et plans numériques dans les atriums culturels superposés."
        },
        post2: {
          title: "Cartographie narrative pour campus universitaires complexes",
          excerpt: "Construire des récits d’orientation multi-usagers en intégrant temporalités académiques et flux événementiels."
        },
        post3: {
          title: "Guidage visuel dans les hubs de transport multimodaux",
          excerpt: "Synchroniser l’information temps réel avec les trajectoires piétonnes pour fluidifier les correspondances."
        },
        post4: {
          title: "Interfaces tactiles et accessibilité dans les bâtiments publics",
          excerpt: "Mesurer la compréhension des écrans interactifs et garantir des transitions inclusives."
        },
        post5: {
          title: "Flux piétons et lisibilité des espaces urbains stratifiés",
          excerpt: "Analyser les superpositions d’usages dans les quartiers connectés et l’effet des repères visuels."
        }
      }
    },
    contact: {
      hero: {
        title: "Dialoguer autour des dispositifs d’orientation",
        lead: "Le formulaire permet de partager des retours terrain, poser des questions méthodologiques ou proposer des coopérations de recherche."
      },
      details: {
        title: "Coordonnées",
        address: "Rue de la Loi 155, 1040 Bruxelles, Belgique",
        phoneLabel: "Téléphone",
        emailLabel: "Courriel",
        availability: "Disponibilité : du lundi au vendredi, 09:00 – 17:30 (CET)."
      },
      mapLabel: "Localisation — Rue de la Loi 155 à Bruxelles",
      form: {
        title: "Formulaire d’échange",
        description: "Précisez le contexte de votre question ou partagez les premiers enseignements d’un site à analyser."
      }
    },
    faq: {
      hero: {
        title: "Questions fréquentes",
        lead: "Réponses aux points récurrents sur la collecte de données, la synthèse cartographique et la diffusion des analyses."
      },
      items: {
        q1: {
          question: "Comment sont collectées les données de parcours ?",
          answer: "Les données reposent sur des observations anonymisées, des schémas de circulation et des entretiens volontaires. Aucun dispositif intrusif n’est employé."
        },
        q2: {
          question: "Quels types de bâtiments sont étudiés ?",
          answer: "Les analyses couvrent les bâtiments publics, les infrastructures culturelles, les campus tertiaires, les pôles multimodaux et certains espaces urbains stratifiés."
        },
        q3: {
          question: "Comment sont traitées les questions d’accessibilité ?",
          answer: "Chaque étude inclut un volet dédié : contrastes visuels, repères tactiles, signalétique en relief, accompagnement sonore et cohésion des supports."
        },
        q4: {
          question: "Quelles sources alimentent les comparaisons internationales ?",
          answer: "Des bibliothèques spécialisées, des normes européennes, des retours d’expérience partagés entre collectivités et des réseaux de recherche en design informationnel."
        },
        q5: {
          question: "Les études sont-elles ouvertes à la collaboration ?",
          answer: "Oui, les institutions et experts peuvent proposer des terrains d’observation et partager leurs données sous réserve d’anonymisation."
        },
        q6: {
          question: "Comment sont gérés les retours d’usagers ?",
          answer: "Les retours sont synthétisés dans des fiches anonymes et intégrés aux recommandations lorsqu’ils apportent un éclairage complémentaire."
        }
      }
    },
    terms: {
      intro: "Les présentes conditions d’utilisation encadrent l’accès et la consultation de danswholesaleplants. En parcourant le site, vous acceptez ces dispositions.",
      sections: {
        s1: {
          title: "1. Objet",
          text: "Le site diffuse des analyses, articles et ressources documentaires relatifs à l’orientation spatiale et à la signalétique numérique."
        },
        s2: {
          title: "2. Acceptation",
          text: "L’accès au site implique l’acceptation sans réserve des présentes conditions. En cas de désaccord, il est recommandé de quitter le site."
        },
        s3: {
          title: "3. Accès au site",
          text: "Le site est accessible sans inscription. Sa disponibilité peut être ponctuellement interrompue pour maintenance ou mise à jour."
        },
        s4: {
          title: "4. Contenus",
          text: "Les contenus sont fournis à titre informatif. Ils peuvent évoluer ou être retirés sans préavis pour garantir leur actualisation."
        },
        s5: {
          title: "5. Propriété intellectuelle",
          text: "Les textes, visuels et maquettes publiés restent la propriété de danswholesaleplants ou de leurs auteurs respectifs."
        },
        s6: {
          title: "6. Utilisation autorisée",
          text: "Toute utilisation doit respecter les droits d’auteur. Les citations sont possibles avec mention explicite de la source."
        },
        s7: {
          title: "7. Responsabilité",
          text: "Le site ne garantit pas l’exhaustivité des informations et décline toute responsabilité liée à une utilisation contradictoire."
        },
        s8: {
          title: "8. Liens externes",
          text: "Les liens vers des sites tiers sont fournis pour référence. danswholesaleplants n’a aucun contrôle sur leur contenu."
        },
        s9: {
          title: "9. Données personnelles",
          text: "Les informations collectées via le formulaire de contact sont utilisées exclusivement pour répondre aux messages reçus."
        },
        s10: {
          title: "10. Cookies",
          text: "Le fonctionnement des cookies est précisé dans la politique dédiée. Les préférences peuvent être modifiées à tout moment."
        },
        s11: {
          title: "11. Modifications des conditions",
          text: "Les présentes conditions peuvent évoluer. La date de dernière mise à jour est indiquée au bas de la page."
        },
        s12: {
          title: "12. Droit applicable",
          text: "Le site est régi par le droit belge. Tout litige relève de la compétence des tribunaux de Bruxelles."
        },
        s13: {
          title: "13. Contact",
          text: "Pour toute question relative aux conditions, utilisez le formulaire de contact disponible sur le site."
        },
        s14: {
          title: "14. Entrée en vigueur",
          text: "Ces conditions sont effectives à compter du 15 février 2024 et restent valides jusqu’à leur prochaine révision."
        }
      }
    },
    privacy: {
      intro: "Cette politique décrit la manière dont danswholesaleplants traite les données personnelles collectées via ses formulaires et outils.",
      sections: {
        s1: {
          title: "1. Responsable du traitement",
          text: "Le responsable éditorial situé Rue de la Loi 155, 1040 Bruxelles, assure la conformité des traitements."
        },
        s2: {
          title: "2. Données collectées",
          text: "Le formulaire recueille le nom, l’adresse électronique, l’organisation et le contenu du message. Aucune donnée sensible n’est sollicitée."
        },
        s3: {
          title: "3. Finalités",
          text: "Les informations servent exclusivement à répondre aux demandes reçues et à assurer un suivi documentaire."
        },
        s4: {
          title: "4. Base légale",
          text: "Le traitement repose sur l’intérêt légitime de répondre aux messages adressés au site."
        },
        s5: {
          title: "5. Conservation",
          text: "Les messages sont conservés pendant douze mois avant suppression, sauf obligation légale contraire."
        },
        s6: {
          title: "6. Partage",
          text: "Les données ne sont pas cédées à des tiers. Elles peuvent être consultées par des collaborateurs assurant le suivi éditorial."
        },
        s7: {
          title: "7. Droits des personnes",
          text: "Vous disposez d’un droit d’accès, de rectification, d’effacement et de limitation, exercable via la page contact."
        },
        s8: {
          title: "8. Cookies",
          text: "Les cookies optionnels nécessitent votre consentement et peuvent être configurés dans le module dédié."
        },
        s9: {
          title: "9. Sécurité",
          text: "Les échanges sont sécurisés et les accès aux messages sont restreints aux personnes habilitées."
        },
        s10: {
          title: "10. Mise à jour",
          text: "La présente politique est révisée régulièrement pour refléter l’évolution des pratiques de traitement."
        }
      }
    },
    cookies: {
      intro: "Ce document détaille les cookies utilisés et les moyens de les gérer.",
      table: {
        title: "Cookies utilisés",
        head: {
          name: "Nom",
          provider: "Fournisseur",
          type: "Type",
          purpose: "Finalité",
          duration: "Durée"
        },
        rows: {
          r1: {
            name: "site_session",
            provider: "Interne",
            type: "Nécessaire",
            purpose: "Maintien des préférences essentielles de navigation.",
            duration: "Session"
          },
          r2: {
            name: "cookie_consent",
            provider: "Interne",
            type: "Préférences",
            purpose: "Mémorisation des choix exprimés dans le bandeau cookies.",
            duration: "12 mois"
          },
          r3: {
            name: "insights_metrics",
            provider: "Interne",
            type: "Analytique",
            purpose: "Agrégation statistique anonyme sur l’usage des pages.",
            duration: "6 mois"
          },
          r4: {
            name: "content_alignment",
            provider: "Interne",
            type: "Marketing",
            purpose: "Analyse des interactions avec les contenus éditoriaux pour ajuster leur hiérarchie.",
            duration: "3 mois"
          }
        }
      },
      management: {
        title: "Gestion des préférences",
        text: "Le bandeau dédié permet d’accepter, refuser ou ajuster chaque catégorie de cookie. Les préférences peuvent être modifiées à tout moment."
      },
      banner: {
        heading: "Gestion des cookies",
        description: "Nous utilisons des cookies pour améliorer l’expérience de navigation et mesurer l’audience. Vous pouvez ajuster vos choix par catégorie.",
        link: "En savoir plus sur la politique cookies",
        acceptAll: "Tout accepter",
        declineAll: "Tout refuser",
        save: "Enregistrer les préférences",
        manage: "Gérer les catégories",
        close: "Fermer le panneau"
      },
      toggles: {
        necessary: {
          title: "Nécessaires",
          description: "Indispensables au fonctionnement du site. Toujours actifs."
        },
        preferences: {
          title: "Préférences",
          description: "Mémorisent vos choix d’affichage et de langue."
        },
        analytics: {
          title: "Analytique",
          description: "Mesurent de manière agrégée la consultation des pages."
        },
        marketing: {
          title: "Contextuelles",
          description: "Aident à adapter la hiérarchie éditoriale selon l’intérêt manifesté."
        }
      }
    },
    refund: {
      intro: "La présente politique de réexamen décrit les modalités de correction, clarification ou mise à jour des contenus publiés.",
      sections: {
        s1: {
          title: "1. Champs d’application",
          text: "S’applique aux articles, synthèses, fiches méthodologiques et ressources cartographiques diffusés sur le site."
        },
        s2: {
          title: "2. Demandes de correction",
          text: "Toute demande argumentée peut être transmise via le formulaire de contact avec des références précises."
        },
        s3: {
          title: "3. Analyse des requêtes",
          text: "Les requêtes sont examinées sous quinze jours ouvrés afin de déterminer leur recevabilité et le type de correction à prévoir."
        },
        s4: {
          title: "4. Catégories de corrections",
          text: "Rectification factuelle, ajout de précision, mise à jour méthodologique ou retrait d’un passage obsolète."
        },
        s5: {
          title: "5. Communication",
          text: "Les corrections substantielles sont signalées en bas de page avec la date de modification."
        },
        s6: {
          title: "6. Versions archivées",
          text: "Les versions antérieures sont conservées à titre interne pour traçabilité pendant une durée de douze mois."
        },
        s7: {
          title: "7. Limites",
          text: "Le site ne garantit pas l’acceptation de toutes les demandes. Les refus motivés sont communiqués au demandeur."
        },
        s8: {
          title: "8. Délais",
          text: "Les corrections validées sont intégrées dans un délai maximum de trente jours ouvrés."
        },
        s9: {
          title: "9. Notifications",
          text: "Lorsque la demande provient d’une institution, une notification de mise à jour peut être adressée par courrier électronique."
        },
        s10: {
          title: "10. Contact",
          text: "Pour toute question relative à cette politique, veuillez utiliser les coordonnées indiquées sur la page contact."
        }
      }
    },
    disclaimer: {
      intro: "Cet avertissement précise les limites liées aux contenus et aux liens présents sur danswholesaleplants.",
      sections: {
        s1: {
          title: "Analyse informative",
          text: "Les informations publiées ont pour objectif de partager des analyses et ne constituent ni un engagement contractuel ni une recommandation opérationnelle."
        },
        s2: {
          title: "Absence de garantie",
          text: "Aucune garantie d’exhaustivité ou de validité permanente n’est offerte. Les contenus sont susceptibles d’évoluer."
        },
        s3: {
          title: "Liens externes",
          text: "Les liens sortants sont fournis pour faciliter la consultation de ressources. Le site n’endosse pas le contenu tiers."
        },
        s4: {
          title: "Responsabilité",
          text: "danswholesaleplants décline toute responsabilité en cas d’interprétation erronée des analyses diffusées."
        },
        s5: {
          title: "Mises à jour",
          text: "Les informations peuvent être modifiées sans préavis afin de refléter de nouveaux travaux ou observations."
        },
        s6: {
          title: "Contact",
          text: "Pour signaler une incohérence ou demander une clarification, veuillez nous écrire via le formulaire de contact."
        }
      }
    },
    thankyou: {
      title: "Merci pour votre envoi",
      message: "Votre message a été reçu. Une réponse sera apportée après analyse des informations transmises.",
      followup: "Vous pouvez revenir aux analyses ou poursuivre votre lecture des articles du blog."
    },
    footer: {
      mission: "Observatoire belge dédié à l’orientation spatiale, aux interfaces d’information et à la lisibilité des infrastructures publiques.",
      address: "Rue de la Loi 155, 1040 Bruxelles, Belgique",
      phone: "Téléphone : +32 2 123 45 67",
      email: "Courriel : info@danswholesaleplants.com",
      rights: "© {year} danswholesaleplants. Tous droits réservés."
    },
    toasts: {
      formSuccess: "Message transmis. Merci pour votre contribution.",
      formError: "Veuillez vérifier les informations du formulaire.",
      formSubmitting: "Envoi en cours…"
    },
    form: {
      nameLabel: "Nom",
      namePlaceholder: "Votre nom complet",
      emailLabel: "Adresse électronique",
      emailPlaceholder: "exemple@organisation.be",
      orgLabel: "Organisation",
      orgPlaceholder: "Nom de l’institution",
      messageLabel: "Message",
      messagePlaceholder: "Décrivez votre question ou votre retour d’expérience",
      consentLabel: "J’accepte que mes informations soient utilisées pour répondre à ma demande.",
      submit: "Envoyer le message"
    },
    posts: {
      post1: {
        intro: "Les centres culturels contemporains multiplient les niveaux, les fonctions et les temporalités d’usage. Ces caractéristiques complexifient la lecture spatiale et imposent une hiérarchisation fine des repères.",
        section1: {
          heading: "Cartographier les niveaux superposés",
          paragraph1: "Dans un centre culturel bruxellois rassemblant médiathèque, salles de spectacle et ateliers, la circulation verticale constituait la principale source d’incompréhension. Les usagers privilégiaient l’ascenseur central, créant une saturation ponctuelle alors que des escaliers latéraux demeuraient sous-utilisés. L’analyse des trajectoires a révélé que les plans muraux insistaient sur les activités mais négligeaient les connexions verticales. En replaçant les noyaux de circulation au cœur des diagrammes et en ajoutant des géométries colorimétriques identiques sur les garde-corps, les déplacements se sont équilibrés et la densité globale a diminué de 18 % lors des pics d’affluence.",
          paragraph2: "La mise en cohérence des repères nécessite une lecture séquentielle : chaque seuil informe sur la relation entre niveaux, fonctions et durées de séjour. Des jalons lumineux ont été intégrés aux paliers pour rappeler la destination principale et proposer des parcours alternatifs vers les espaces secondaires. L’approche a reposé sur des sessions d’observation réparties sur trois semaines, incluant des soirées thématiques et des ateliers matinaux. Les données recoupées ont servi à alimenter une matrice d’influence mesurant la contribution de chaque repère à la distribution des flux."
        },
        section1b: {
          heading: "Hiérarchie et perception sensorielle",
          paragraph1: "La cohérence sensorielle constitue un facteur déterminant. Les couleurs vives attirent l’attention mais peuvent brouiller la hiérarchie si elles ne sont pas coordonnées avec le niveau de granularité de l’information. Le centre culturel a privilégié une palette restreinte de bleus et de jaunes, doublée d’une typographie unique. Les pictogrammes tactiles ont été ajoutés sur les mains courantes afin de renforcer l’orientation pour les publics malvoyants. Les tests utilisateurs ont montré que la combinaison entre signal tactile et rappel visuel réduisait les hésitations sur les bifurcations.",
          paragraph2: "Les repères sonores ont également été réévalués. À certaines heures, les annonces automatiques interféraient avec les spectacles en cours. L’équipe a mis en place une grille horaire synchronisée avec les transitions de public. Ce pilotage temporel a permis de conserver l’efficacité des repères auditifs sans perturber l’expérience artistique. L’ensemble du dispositif s’appuie désormais sur des scénarios modulables selon la programmation culturelle et les conférences professionnelles."
        },
        section2: {
          heading: "Rendre les plans numériques intelligibles",
          paragraph1: "Les plans numériques constituent un point d’entrée stratégique. Pourtant, les kiosques installés dans le hall ne proposaient qu’un affichage statique. L’équipe projet a intégré des couches d’information contextuelle : temps estimé pour atteindre chaque espace, disponibilités des ateliers et orientation suggérée en fonction de la saturation des zones. Les usagers peuvent filtrer par type d’activité tout en visualisant la position réelle des ascenseurs et escaliers. Cette granularité facilite la prise de décision pour les visiteurs pressés.",
          paragraph2: "Afin de garantir la cohérence avec la signalétique physique, chaque plan numérique reprend les codes couleur et la nomenclature des repères muraux. Une boucle de rétroaction a été instaurée : lorsque les usagers empruntent un itinéraire recommandé, des marqueurs lumineux au sol confirment qu’ils se trouvent sur le bon parcours. L’ensemble crée une continuité narrative depuis la carte jusqu’à la destination finale.",
          paragraph3: "La maintenance du système repose sur un calendrier partagé entre l’équipe culturelle et les services techniques. Les mises à jour de programmation, les fermetures temporaires et les travaux sont intégrés à un tableau de bord commun. En amont de chaque événement majeur, un scénario d’orientation est produit, testant l’impact sur les flux et ajustant les messages des plans numériques. Cette coordination permet de conserver une lisibilité stable malgré les fréquentes reconfigurations d’espaces."
        },
        section2b: {
          heading: "Indicateurs et retours qualitatifs",
          paragraph1: "Les indicateurs retenus combinent données quantitatives et retours qualitatifs. Le temps moyen de recherche des salles a été réduit de 2 minutes à 1 minute 15. Les questionnaires anonymes recueillis auprès des publics ont souligné l’efficacité des repères lumineux et des rappels tactiles. Les membres du personnel d’accueil ont également signalé une baisse des sollicitations pour des questions de localisation.",
          paragraph2: "Le dispositif continue d’évoluer. Un observatoire trimestriel intègre de nouveaux cas d’usage, notamment les événements internationaux qui attirent des visiteurs non francophones ou néerlandophones. Des versions multilingues des plans numériques sont actuellement testées, en conservant la même architecture visuelle pour éviter toute dissonance. Les retours servent à enrichir le référentiel général, partagé avec d’autres institutions culturelles belges.",
          paragraph3: "Cette étude confirme que la hiérarchisation des repères au sein d’environnements pluriels exige une gouvernance collective, des protocoles de test réguliers et une articulation fine entre dispositifs physiques et numériques. La synchronisation sensorielle demeure un levier majeur pour favoriser la circulation et préserver l’expérience culturelle."
        }
      },
      post2: {
        intro: "Les campus universitaires s’étendent désormais sur plusieurs hectares, combinent fonctions pédagogiques, laboratoires, services administratifs et espaces publics ouverts. La navigation doit composer avec une densité programmatique fluctuante et des temporalités très contrastées.",
        section1: {
          heading: "Composer avec les temporalités académiques",
          paragraph1: "L’étude menée sur un campus flamand s’est concentrée sur la période de rentrée et sur les sessions d’examens. Ces deux séquences concentrent une forte charge émotionnelle et une fréquentation maximale. Les parcours piétons se réorganisent brutalement : les étudiants privilégient les trajets directifs vers les auditoriums, tandis que les nouveaux arrivants recherchent les guichets d’information. Pour anticiper ces variations, l’équipe a élaboré des cartes narratives superposant trois couches temporelles : semaine ordinaire, période d’inscription, période d’examen. Chaque couche identifie les carrefours de décision et les points de densité.",
          paragraph2: "Les résultats ont mis en évidence un déficit de signalisation pour les parcours dits de transition, reliant parkings vélos, arrêts de bus et bibliothèques. Les plans existants étaient centrés sur les bâtiments, sans intégrer le réseau extérieur de circulation douce. La nouvelle cartographie narrative, diffusée sous forme d’affiche et de support numérique, propose une lecture progressive : repérage du quartier, identification des axes principaux, micro-parcours adaptés aux contraintes horaires. Les étudiants consultent le support selon leur degré de familiarité et leur objectif du moment."
        },
        section1b: {
          heading: "Adapter le récit aux profils d’usagers",
          paragraph1: "Les étudiants internationaux, le personnel administratif et les publics extérieurs n’ont pas les mêmes besoins d’orientation. Des ateliers participatifs ont permis d’identifier les repères jugés essentiels par chaque catégorie. Les étudiants privilégiaient la rapidité et la disponibilité des salles, tandis que les publics extérieurs valorisaient la compréhension des services et des services de mobilité. À partir de ces retours, des micro-récits d’orientation ont été rédigés, chacun structuré en trois étapes : point d’entrée, trajectoire clé, repère final.",
          paragraph2: "Ces récits nourrissent un guide numérique intégré au site du campus. Lorsqu’un utilisateur sélectionne son profil, il reçoit un itinéraire narratif accompagné de pictogrammes et d’estimations de temps. Chaque récit renvoie à une carte interactive reprenant les couleurs de la signalétique physique. L’objectif est de fournir une expérience cohérente, qu’elle soit consultée sur smartphone, borne d’information ou plan imprimé."
        },
        section2: {
          heading: "Gérer l’extension du campus",
          paragraph1: "Le campus s’agrandit régulièrement. Les nouveaux bâtiments sont parfois mis en service alors que la signalétique n’a pas encore été déployée. Pour éviter ces décalages, un protocole de pré-ouverture a été instauré. Il consiste à cartographier les flux provisoires, à identifier les zones en chantier et à élaborer des repères temporaires cohérents avec l’identité graphique existante.",
          paragraph2: "Les repères temporaires utilisent des matériaux distinctifs mais conservent la typographie et les codes couleur du campus. Ils intègrent un QR code permettant de vérifier l’itinéraire actualisé en temps réel. Cette solution hybride limite la confusion pendant les phases de transition et facilite la prise en main des nouveaux espaces par les usagers réguliers.",
          paragraph3: "Les données collectées durant les trois premiers mois d’exploitation sont capitalisées pour ajuster la carte principale. Les flux réels sont comparés aux intentions initiales afin de décider du maintien ou de la transformation des repères. Ce processus évite l’accumulation de panneaux obsolètes et maintient l’ensemble du campus dans une logique de récit cohérent."
        },
        section2b: {
          heading: "Indicateurs de réussite et perspectives",
          paragraph1: "Les enquêtes menées après la mise en place des cartes narratives indiquent une hausse de 27 % de la compréhension des déplacements transversaux. Les demandes d’information auprès des guichets ont diminué, tandis que la consultation du guide numérique a doublé. Les étudiants internationaux ont particulièrement apprécié la possibilité de sélectionner un parcours adapté à leur langue et à leur niveau de connaissance du site.",
          paragraph2: "Les prochaines étapes incluent l’intégration de données de fréquentation en temps réel pour afficher la saturation des espaces d’étude. L’objectif est de rendre les récits encore plus contextuels, tout en préservant le caractère non intrusif du dispositif. Cette approche conforte l’idée qu’un campus peut être appréhendé comme une narration spatiale évolutive, alignée sur les rythmes et les attentes de ses communautés."
        }
      },
      post3: {
        intro: "Les hubs de transport conditionnent l’expérience de milliers de personnes chaque jour. La synchronisation entre flux piétons, informations temps réel et contraintes de sécurité constitue un défi majeur.",
        section1: {
          heading: "Synchroniser information et mouvement",
          paragraph1: "Dans un hub bruxellois connectant trains, métros, trams et bus, l’analyse a révélé un décalage constant entre l’information affichée et le flux réel. Les passagers consultaient les écrans, identifiaient leur correspondance, mais se heurtaient à des goulots d’étranglement mal signalés. Une cartographie fine des flux a permis de réorganiser les repères à hauteur de regard, avec un double affichage : direction principale et alternatives en cas d’incident. Les écrans ont été reprogrammés pour afficher des séquences plus courtes et répétitives, limitant la surcharge cognitive.",
          paragraph2: "La communication temporelle a été revisitée. Plutôt que de lister tous les départs, les écrans prioritaires indiquent les correspondances immédiates, tandis que des totems latéraux présentent les départs suivants. Ce découpage séquentiel permet aux voyageurs de se concentrer sur l’action la plus urgente et de réduire les changements de trajectoire."
        },
        section1b: {
          heading: "Fluidifier les correspondances",
          paragraph1: "Les correspondances complexes sont souvent entravées par des changements de niveau. Le hub étudié comporte quatre paliers principaux. Chaque palier dispose désormais d’une couleur dominante et d’un motif graphique discret reproduit sur les rampes et les passerelles. Les usagers identifient facilement leur progression et savent si leur correspondance se situe au-dessus ou au-dessous du niveau actuel.",
          paragraph2: "Des repères lumineux dynamiques s’allument lors des correspondances critiques pour guider les flux vers les quais concernés. Lorsque plusieurs correspondances sont prioritaires, les séquences lumineuses se différencient, évitant la confusion. Les tests ont montré une diminution des retours en arrière et une meilleure répartition des voyageurs entre les escaliers et les ascenseurs."
        },
        section2: {
          heading: "Intégrer les contraintes de sécurité",
          paragraph1: "Les dispositifs d’orientation doivent se coordonner avec les protocoles de sécurité. L’équipe a travaillé avec les services concernés pour définir des scénarios d’évacuation compatibles avec la nouvelle signalétique. Les messages d’urgence utilisent les mêmes codes couleur que la communication quotidienne, mais avec une intensité renforcée. Les plans affichent les parcours prioritaires en cas de perturbation, réduisant la nécessité de messages verbaux répétitifs.",
          paragraph2: "Une attention particulière a été portée aux voyageurs à mobilité réduite. Les itinéraires accessibles sont indiqués dès l’entrée, avec des rappels réguliers le long du parcours. Les plateformes élévatrices et ascenseurs disposent d’une signalétique tactile et de contrastes élevés. Les détecteurs de flux surveillent la saturation des zones sensibles pour adapter en temps réel les messages diffusés.",
          paragraph3: "Les retours des opérateurs confirment que la compatibilité entre orientation quotidienne et scénarios exceptionnels est essentielle. En harmonisant les supports, les annonces deviennent plus claires et les voyageurs adoptent les itinéraires recommandés sans hésitation prolongée."
        },
        section2b: {
          heading: "Mesure d’impact et perspectives",
          paragraph1: "Après six mois, les temps de correspondance enregistrés sur les trajets critiques ont diminué de 14 %. Les questionnaires montrent une meilleure compréhension des cheminements alternatifs. Les usagers soulignent la cohérence entre les écrans et les balises physiques.",
          paragraph2: "Le hub envisage d’intégrer prochainement des indicateurs de densité, visibles sur les plans numériques, pour rediriger une partie du flux lors des pointes. L’objectif est de maintenir un haut niveau de lisibilité malgré l’augmentation continue du nombre de passagers."
        }
      },
      post4: {
        intro: "Les interfaces tactiles se sont multipliées dans les bâtiments publics. Leur efficacité dépend de leur ergonomie, de leur intégration spatiale et de la cohérence avec la signalétique environnante.",
        section1: {
          heading: "Analyser la posture et la lisibilité",
          paragraph1: "Dans un centre administratif wallon, les bornes tactiles avaient été installées sans étude approfondie des postures adoptées par les usagers. Résultat : certains écrans étaient inclinés de manière peu lisible pour les personnes de petite taille ou en fauteuil roulant. L’audit ergonomique a abouti au repositionnement des bornes, à l’ajout d’un mode à contraste renforcé et à l’intégration d’un lecteur audio descriptif. Les interactions ont été simplifiées : les informations sont désormais regroupées en trois catégories principales, chacune accessible en deux touches.",
          paragraph2: "Les tests ont mis en évidence l’importance de la cohérence typographique. Les écrans reprennent la même famille de caractères que la signalétique murale, avec un interlignage généreux. Un bouton de retour systématique est disponible en bas d’écran, limitant le risque d’impasse pour l’utilisateur."
        },
        section1b: {
          heading: "Créer une continuité entre support tactile et espace",
          paragraph1: "L’expérience tactile ne se limite pas à l’écran. Une fois la destination sélectionnée, le visiteur doit retrouver des repères dans l’espace physique. L’équipe a donc synchronisé l’interface avec des balises lumineuses au plafond, qui s’illuminent pour indiquer la direction initiale. Les plans au sol ont été mis à jour avec des pictogrammes équivalents à ceux de l’écran.",
          paragraph2: "Les bornes fournissent aussi un QR code permettant de poursuivre la navigation sur mobile. Cette continuité évite à l’usager de mémoriser l’intégralité de l’itinéraire et renforce le sentiment de contrôle."
        },
        section2: {
          heading: "Intégrer l’accessibilité inclusive",
          paragraph1: "Les bornes offrent une option de navigation audio. Les utilisateurs peuvent brancher leurs écouteurs ou activer le haut-parleur discret. Les instructions vocales décrivent la position des commandes, la distance approximative et les points de repère à surveiller. Ce service améliore la compréhension pour les personnes malvoyantes et celles qui découvrent le bâtiment.",
          paragraph2: "Des plages tactiles contrastées ont été ajoutées autour de l’écran. Elles guident les mains et signalent l’emplacement des boutons physiques. Les usagers ont salué cette approche, considérant qu’elle réduit le stress lié à la technologie.",
          paragraph3: "L’entretien des bornes est assuré via une console centrale. Les contenus sont mis à jour chaque semaine pour refléter les changements de services. Un suivi statistique permet d’identifier les écrans les plus consultés et d’ajuster la structure de navigation."
        },
        section2b: {
          heading: "Indicateurs de performance",
          paragraph1: "Les temps d’interaction ont été mesurés avant et après la refonte. Ils sont passés de 2 minutes 40 à 1 minute 30 en moyenne. Le taux de navigation réussie, vérifié par un sondage de sortie, a augmenté de 22 points. Les agents d’accueil signalent une meilleure compréhension des parcours complexes.",
          paragraph2: "Les prochaines étapes consistent à intégrer des informations sur l’occupation des guichets et à proposer des suggestions dynamiques en fonction de l’heure. Ces évolutions maintiendront la pertinence des bornes dans un bâtiment en constante adaptation."
        }
      },
      post5: {
        intro: "Les espaces urbains stratifiés combinent passerelles, galeries souterraines et parvis ouverts. Leur lisibilité dépend de la clarté des transitions verticales et de la cohérence matérielle des chemins.",
        section1: {
          heading: "Observer les flux en temps réel",
          paragraph1: "Dans un quartier d’affaires de Bruxelles, les piétons empruntent simultanément des passerelles surélevées, des tunnels et des places publiques. Les observations ont révélé que les personnes unfamiliarisées optaient majoritairement pour le niveau zéro, allongeant leurs trajets. Les cartes mentales partagées lors d’entretiens montrent que les passerelles étaient perçues comme des espaces privés alors qu’elles sont publiques. La signalétique existante ne clarifiait pas cette information.",
          paragraph2: "Pour y remédier, un système de rubans lumineux a été installé sur les accès aux passerelles, accompagné de messages confirmant leur libre accès. Les flux se sont progressivement rééquilibrés, réduisant la congestion au sol et dynamisant les commerces en hauteur."
        },
        section1b: {
          heading: "Relier les couches via des repères cohérents",
          paragraph1: "Les galeries souterraines connectent des parkings, des stations de métro et des centres commerciaux. Elles souffraient d’un déficit de lumière naturelle et d’un manque d’orientation verticale. Des puits lumineux ont été ajoutés dans les zones clés, tandis que des totems indiquent systématiquement la correspondance avec le niveau supérieur. Les couleurs utilisées dans les espaces souterrains reprennent les teintes observées sur les passerelles pour renforcer la continuité visuelle.",
          paragraph2: "Des cartes tactiles ont été disposées aux intersections majeures. Elles décrivent la topographie du quartier, les points d’accès accessibles et les services présents. Les retours des personnes à mobilité réduite confirment que ces supports facilitent la compréhension des trajets multi-niveaux."
        },
        section2: {
          heading: "Mesurer l’impact sur la lisibilité urbaine",
          paragraph1: "L’étude a associé mesures de fréquentation, questionnaires courts et analyse des itinéraires GPS anonymisés. Les résultats montrent une augmentation de 19 % de l’usage des passerelles et une réduction du temps moyen de parcours entre les stations de transport et les bureaux. Les usagers déclarent mieux comprendre les alternatives offertes par les différentes couches du quartier.",
          paragraph2: "La municipalité prévoit d’étendre ce dispositif à d’autres zones stratifiées. Des guides d’usage seront publiés pour aider les visiteurs à choisir l’itinéraire le plus adapté en fonction de la météo, de la foule ou du temps disponible.",
          paragraph3: "Cette démarche confirme que la lisibilité urbaine repose sur une narration continue entre niveaux, une signalisation inclusive et une coordination permanente entre acteurs publics et gestionnaires privés."
        }
      }
    }
  },
  en: {
    meta: {
      title: {
        home: "danswholesaleplants — Spatial orientation and digital wayfinding",
        services: "Orientation methodologies — danswholesaleplants",
        about: "Institutional profile — danswholesaleplants",
        blog: "Interior navigation chronicles — danswholesaleplants",
        contact: "Coordinates and exchanges — danswholesaleplants",
        faq: "Spatial navigation FAQ — danswholesaleplants",
        terms: "Terms of use — danswholesaleplants",
        privacy: "Privacy policy — danswholesaleplants",
        cookies: "Cookie policy — danswholesaleplants",
        refund: "Review policy — danswholesaleplants",
        disclaimer: "Disclaimer — danswholesaleplants",
        thankyou: "Thank you for your message — danswholesaleplants",
        post1: "Orientation hierarchies in multi-layer cultural centers",
        post2: "Narrative mapping for complex university environments",
        post3: "Visual guidance inside multimodal transport hubs",
        post4: "Touch interfaces and accessibility in public buildings",
        post5: "Pedestrian flows and legibility of stratified urban spaces"
      },
      description: {
        home: "Analytical platform focused on spatial orientation, digital signage and interactive mapping within Belgian built environments.",
        services: "Overview of analytical approaches and methodological scenarios to optimise indoor and outdoor navigation.",
        about: "Presentation of the editorial approach centred on visual guidance and spatial UX across public infrastructures.",
        blog: "Selection of in-depth articles about user journeys, spatial legibility and informational design.",
        contact: "Contact details, map and form to exchange about signage and accessibility matters.",
        faq: "Common questions about pedestrian mobility analysis and mapping of complex venues.",
        terms: "Terms of use describing responsibilities, rights and limitations of danswholesaleplants.",
        privacy: "Privacy policy detailing collection, use and storage of data handled by danswholesaleplants.",
        cookies: "Comprehensive information about cookies in use and the available preference settings.",
        refund: "Review policy explaining how editorial updates and corrections are processed.",
        disclaimer: "Disclaimer outlining limitations of liability and absence of contractual commitment.",
        thankyou: "Acknowledgement page for messages sent through the contact form.",
        post1: "In-depth study of orientation hierarchies inside Belgium’s multi-level cultural centres.",
        post2: "Analysis of narrative mapping for dense academic campuses.",
        post3: "Assessment of visual guidance systems within European multimodal hubs.",
        post4: "Evaluation of touch interfaces and accessibility within interconnected public buildings.",
        post5: "Observation of pedestrian flows and legibility across stratified urban districts."
      }
    },
    header: {
      brand: "danswholesaleplants",
      menuLabel: "Toggle navigation",
      menuOpen: "Open menu",
      menuClose: "Close menu"
    },
    nav: {
      home: "Home",
      services: "Approaches",
      about: "Profile",
      blog: "Insights",
      faq: "FAQ",
      contact: "Contact"
    },
    language: {
      label: "Select language",
      fr: "FR",
      en: "EN"
    },
    buttons: {
      readMore: "Read more",
      discover: "Discover",
      viewDetails: "View details",
      download: "Open",
      manage: "Manage"
    },
    home: {
      hero: {
        heading: "Mapping spatial experience within complex public environments",
        subheading: "danswholesaleplants curates analyses, field feedback and methodological frameworks to understand how digital signage and physical cues support navigation inside Belgium’s flexible architectures.",
        bullet1: "Observation of pedestrian journeys aligned with evolving building programmes",
        bullet2: "Decision matrices built for the legibility of interactive floor plans",
        bullet3: "Assessment of sensory cues and their visual synchronisation across touchpoints",
        cta: "Explore research paths",
        imageAlt: "Person reviewing a digital map within a luminous atrium"
      },
      featured: {
        badge: "Core themes",
        title: "Analysing, synthesising and narrating indoor navigation",
        description: "Each study blends qualitative and quantitative data to translate dense environments into understandable experiences, from the first arrival to micro wayfinding decisions.",
        card1: {
          title: "Legibility matrices",
          text: "Decomposition of flows and articulation of textual, iconic and dynamic cues to maintain clarity despite heterogeneous programmes."
        },
        card2: {
          title: "User scenarios",
          text: "Projection of contrasted situations—reduced mobility, language needs, night-time schedules—to verify the adaptability of suggested journeys."
        },
        card3: {
          title: "Support ecology",
          text: "Coordination between physical signage, interactive mapping and contextual prompts to avoid narrative gaps or overload."
        }
      },
      narrative: {
        badge: "Briefings",
        title: "Understanding how each signal steers attention",
        description: "Briefings combine orientation sketches, on-site observations and behavioural modelling to craft narratives shared across multidisciplinary teams.",
        item1: {
          title: "Pedestrian heat maps",
          text: "Layering observed trajectories with design intentions to reveal friction points or ambiguous decisions."
        },
        item2: {
          title: "Accessibility protocols",
          text: "Review of visual contrasts, tactile cues, audio guidance and lighting transitions within navigation sequences."
        },
        item3: {
          title: "Multilayered systems",
          text: "Hierarchical organisation of information according to distance, intersection density and user familiarity."
        }
      },
      recommendations: {
        title: "Editorial recommendations",
        description: "These recommendations stem from audits conducted with public bodies and facility operators seeking stronger wayfinding coherence.",
        card1: {
          title: "Document thresholds",
          text: "Map each entry threshold as a key moment synchronising physical and digital cues to secure journey continuity."
        },
        card2: {
          title: "Clarify intersections",
          text: "Place narrative beacons on critical crossroads and structure secondary choices to limit cumulative hesitation."
        },
        card3: {
          title: "Temporalise information",
          text: "Add time-based layers to anticipate daily, weekly or seasonal shifts in usage."
        },
        card4: {
          title: "Support maintenance",
          text: "Implement shared governance so physical and digital supports remain aligned during updates."
        }
      },
      testimonials: {
        title: "Field feedback",
        description: "Managers of public venues describe the measurable impact observed after reframing their orientation systems.",
        quote1: {
          text: "Narrative mapping aligned the official journeys with actual practices. Visitors reach key areas faster and front-desk teams feel more at ease.",
          author: "Maïa Delcroix",
          role: "Cultural coordination, Brussels multi-purpose centre"
        },
        quote2: {
          text: "Systematic comparison between expected and observed flows proved essential. We can now prioritise our signage updates with confidence.",
          author: "Jonas Lievens",
          role: "Mobility management, Flemish university consortium"
        },
        quote3: {
          text: "The dashboards clarify how to balance static signage and tactile interfaces. Maintenance teams follow a precise roadmap.",
          author: "Elena Vanneste",
          role: "Infrastructure lead, Walloon museum network"
        }
      },
      observatory: {
        title: "Observatory of complex environments",
        description: "Selection of briefing notes dedicated to major cultural venues, dense tertiary campuses and multimodal nodes.",
        item1: {
          title: "Polyfunctional atriums",
          text: "Study of how vertical voids and overlapping views influence spontaneous orientation."
        },
        item2: {
          title: "Digital causeways",
          text: "Assessment of interactions between informational LED walls and directional markings."
        },
        item3: {
          title: "Connected districts",
          text: "Evaluation of tactile markers throughout extended pedestrian sequences."
        }
      }
    },
    services: {
      hero: {
        title: "Analytical approaches for spatial orientation",
        lead: "Each approach relies on observable protocols, narrative mock-ups and performance indicators tailored to pedestrian circulation across public environments."
      },
      sections: {
        item1: {
          title: "Structural cue diagnostics",
          text: "Inventory graphic, luminous and audio cues before ranking them according to their ability to guide diverse profiles."
        },
        item2: {
          title: "User journey modelling",
          text: "Build multi-scenario paths factoring travel duration, decision points and attention triggers."
        },
        item3: {
          title: "Spatial information architecture",
          text: "Organise textual, pictorial and cartographic content, ensuring semantic continuity between physical supports and digital interfaces."
        },
        item4: {
          title: "Tactile experience review",
          text: "Audit screens, kiosks and touch maps with particular focus on transitions between supports and inclusive options."
        },
        item5: {
          title: "Inclusive accessibility frameworks",
          text: "Evaluate contrasts, relief signage, audio prompts and circulation compatible with various mobilities."
        }
      },
      methodology: {
        title: "Methodological structure",
        text: "Field observation, interviews, anonymised video captures and European benchmarks are combined. Each deliverable includes dependency mapping, risk analysis and governance advice."
      },
      outcomes: {
        title: "Typical deliverables",
        list: {
          a: "High-resolution narrative maps integrating pedestrian density gradients.",
          b: "Criteria sheets to assess intersection legibility and secondary axes.",
          c: "Quantitative dashboards to track spatial understanding indicators."
        }
      }
    },
    about: {
      hero: {
        title: "Contextualising visual guidance research",
        lead: "danswholesaleplants interlaces international resources and Belgian field studies to unveil the complexity of public infrastructures."
      },
      mission: {
        title: "A mission centred on spatial comprehension",
        text: "The editorial stance combines urban design, informational design and behavioural sciences. Analyses emphasise user feedback, flow anticipation and the translation of technical constraints into legible experiences."
      },
      pillars: {
        title: "Editorial pillars",
        item1: {
          title: "Situated observation",
          text: "Discrete captures and usage mapping inside buildings with dense programming."
        },
        item2: {
          title: "Method transparency",
          text: "Publication of observed variables, potential biases and protocol limits."
        },
        item3: {
          title: "Open diffusion",
          text: "Sharing reading grids with public and associative stakeholders."
        }
      },
      team: {
        title: "Expert collaborations",
        text: "The project engages public authorities, spatial UX researchers, architects, graphic designers and data specialists to consolidate analyses and craft transversal recommendations."
      }
    },
    blog: {
      hero: {
        title: "Interior navigation chronicles",
        lead: "Each article explores a singular spatial configuration, confronting architectural intentions with observed behaviour."
      },
      listing: {
        intro: "Recent selection",
        post1: {
          title: "Orientation hierarchies in multi-layer cultural centres",
          excerpt: "Combining luminous signage, tactile markers and digital plans inside superposed cultural atriums."
        },
        post2: {
          title: "Narrative mapping for complex university environments",
          excerpt: "Crafting multi-user orientation narratives blending academic timelines and event-driven flows."
        },
        post3: {
          title: "Visual guidance inside multimodal transport hubs",
          excerpt: "Aligning real-time information with pedestrian trajectories to ease transfers."
        },
        post4: {
          title: "Touch interfaces and accessibility in public buildings",
          excerpt: "Measuring comprehension of interactive screens and delivering inclusive transitions."
        },
        post5: {
          title: "Pedestrian flows and legibility of stratified urban spaces",
          excerpt: "Analysing overlapping uses in connected districts and the effect of visual cues."
        }
      }
    },
    contact: {
      hero: {
        title: "Exchange about orientation systems",
        lead: "Use the form to share field feedback, ask methodological questions or suggest research collaborations."
      },
      details: {
        title: "Contact details",
        address: "Rue de la Loi 155, 1040 Brussels, Belgium",
        phoneLabel: "Phone",
        emailLabel: "Email",
        availability: "Availability: Monday to Friday, 09:00 – 17:30 (CET)."
      },
      mapLabel: "Location — Rue de la Loi 155 in Brussels",
      form: {
        title: "Exchange form",
        description: "Outline your context or share preliminary insights from a site under review."
      }
    },
    faq: {
      hero: {
        title: "Frequently asked questions",
        lead: "Responses to recurring points about data collection, cartographic synthesis and distribution of analyses."
      },
      items: {
        q1: {
          question: "How are journey data collected?",
          answer: "Datasets rely on anonymised observations, circulation diagrams and voluntary interviews. No intrusive device is deployed."
        },
        q2: {
          question: "Which types of buildings are studied?",
          answer: "Analyses cover public buildings, cultural infrastructures, tertiary campuses, multimodal hubs and selected stratified urban areas."
        },
        q3: {
          question: "How is accessibility addressed?",
          answer: "Each study includes a dedicated chapter covering visual contrasts, tactile cues, relief signage, audio support and coherent media."
        },
        q4: {
          question: "Which sources feed international comparisons?",
          answer: "Specialised libraries, European standards, shared feedback between public bodies and networks focusing on informational design."
        },
        q5: {
          question: "Are collaborations possible?",
          answer: "Yes, institutions and experts can propose observation sites and share anonymised datasets."
        },
        q6: {
          question: "How are user comments handled?",
          answer: "Feedback is summarised into anonymous memos and integrated when it sheds complementary light on the analysis."
        }
      }
    },
    terms: {
      intro: "These terms of use govern access to and consultation of danswholesaleplants. By browsing the site, you agree to these provisions.",
      sections: {
        s1: {
          title: "1. Purpose",
          text: "The site disseminates analyses, articles and documentary resources related to spatial orientation and digital signage."
        },
        s2: {
          title: "2. Acceptance",
          text: "Accessing the site implies unreserved acceptance of these terms. If you disagree, please discontinue browsing."
        },
        s3: {
          title: "3. Site access",
          text: "The site is freely accessible. Availability may be temporarily interrupted for maintenance or updates."
        },
        s4: {
          title: "4. Content",
          text: "Content is provided for informational purposes. It may evolve or be removed without notice to ensure accuracy."
        },
        s5: {
          title: "5. Intellectual property",
          text: "Texts, visuals and layouts remain the property of danswholesaleplants or their respective authors."
        },
        s6: {
          title: "6. Permitted use",
          text: "Usage must respect copyright. Quotations are allowed with explicit mention of the source."
        },
        s7: {
          title: "7. Liability",
          text: "The site does not guarantee exhaustive information and declines responsibility for contradictory interpretations."
        },
        s8: {
          title: "8. External links",
          text: "Links to third-party sites are provided for reference. danswholesaleplants has no control over external content."
        },
        s9: {
          title: "9. Personal data",
          text: "Information collected via the contact form is used solely to answer incoming messages."
        },
        s10: {
          title: "10. Cookies",
          text: "Cookie usage is described in the dedicated policy. Preferences can be adjusted at any time."
        },
        s11: {
          title: "11. Terms update",
          text: "These terms may change. The date of the last update appears at the bottom of the page."
        },
        s12: {
          title: "12. Governing law",
          text: "Belgian law applies. Disputes fall under the jurisdiction of Brussels courts."
        },
        s13: {
          title: "13. Contact",
          text: "For questions about the terms, use the contact form available on the site."
        },
        s14: {
          title: "14. Effective date",
          text: "These terms take effect on 15 February 2024 and remain valid until the next revision."
        }
      }
    },
    privacy: {
      intro: "This policy describes how danswholesaleplants handles personal data collected through its forms and tools.",
      sections: {
        s1: {
          title: "1. Data controller",
          text: "The editorial manager located at Rue de la Loi 155, 1040 Brussels, oversees compliance."
        },
        s2: {
          title: "2. Data collected",
          text: "The form captures name, email address, organisation and message content. No sensitive data is requested."
        },
        s3: {
          title: "3. Purpose",
          text: "Information is solely used to answer messages and document related exchanges."
        },
        s4: {
          title: "4. Legal basis",
          text: "Processing relies on the legitimate interest of responding to incoming requests."
        },
        s5: {
          title: "5. Retention",
          text: "Messages are stored for twelve months before deletion, unless a legal obligation states otherwise."
        },
        s6: {
          title: "6. Sharing",
          text: "Data is not transferred to third parties. It may be viewed by collaborators in charge of editorial follow-up."
        },
        s7: {
          title: "7. Data subject rights",
          text: "You can request access, rectification, deletion or restriction via the contact page."
        },
        s8: {
          title: "8. Cookies",
          text: "Optional cookies require your consent and can be configured within the dedicated module."
        },
        s9: {
          title: "9. Security",
          text: "Exchanges are secured and message access is restricted to authorised persons."
        },
        s10: {
          title: "10. Updates",
          text: "This policy is reviewed regularly to reflect evolving processing practices."
        }
      }
    },
    cookies: {
      intro: "This document details the cookies in use and how you can manage them.",
      table: {
        title: "Cookies in use",
        head: {
          name: "Name",
          provider: "Provider",
          type: "Type",
          purpose: "Purpose",
          duration: "Duration"
        },
        rows: {
          r1: {
            name: "site_session",
            provider: "Internal",
            type: "Necessary",
            purpose: "Maintains essential browsing preferences.",
            duration: "Session"
          },
          r2: {
            name: "cookie_consent",
            provider: "Internal",
            type: "Preferences",
            purpose: "Stores the decisions expressed through the cookie banner.",
            duration: "12 months"
          },
          r3: {
            name: "insights_metrics",
            provider: "Internal",
            type: "Analytics",
            purpose: "Aggregated statistics about page usage.",
            duration: "6 months"
          },
          r4: {
            name: "content_alignment",
            provider: "Internal",
            type: "Marketing",
            purpose: "Analyses editorial interactions to adjust content hierarchy.",
            duration: "3 months"
          }
        }
      },
      management: {
        title: "Managing preferences",
        text: "Use the banner to accept, refuse or adjust each cookie category. You may update your choices at any time."
      },
      banner: {
        heading: "Cookie management",
        description: "We use cookies to improve browsing experience and measure audience. Adjust your preferences by category.",
        link: "Learn more about the cookie policy",
        acceptAll: "Accept all",
        declineAll: "Decline all",
        save: "Save preferences",
        manage: "Manage categories",
        close: "Close panel"
      },
      toggles: {
        necessary: {
          title: "Necessary",
          description: "Essential for the website to operate. Always active."
        },
        preferences: {
          title: "Preferences",
          description: "Remember your display and language choices."
        },
        analytics: {
          title: "Analytics",
          description: "Measure page consultation in an aggregated way."
        },
        marketing: {
          title: "Contextual",
          description: "Help adapt editorial hierarchy according to expressed interest."
        }
      }
    },
    refund: {
      intro: "This review policy explains how published content is corrected, clarified or updated.",
      sections: {
        s1: {
          title: "1. Scope",
          text: "Applies to articles, syntheses, methodological sheets and mapping resources published on the site."
        },
        s2: {
          title: "2. Correction requests",
          text: "Submit detailed requests via the contact form together with precise references."
        },
        s3: {
          title: "3. Request review",
          text: "Requests are assessed within fifteen working days to determine eligibility and relevant correction type."
        },
        s4: {
          title: "4. Correction categories",
          text: "Factual adjustments, added clarifications, methodological updates or removal of outdated sections."
        },
        s5: {
          title: "5. Communication",
          text: "Significant corrections are flagged at the bottom of the page with an update date."
        },
        s6: {
          title: "6. Archived versions",
          text: "Previous versions are stored internally for twelve months to ensure traceability."
        },
        s7: {
          title: "7. Limitations",
          text: "Not every request can be accepted. Reasoned refusals are communicated to the requester."
        },
        s8: {
          title: "8. Deadlines",
          text: "Approved corrections are published within a maximum of thirty working days."
        },
        s9: {
          title: "9. Notifications",
          text: "Institutional requests may receive an email confirmation when an update is completed."
        },
        s10: {
          title: "10. Contact",
          text: "Direct any question about this policy through the contact page."
        }
      }
    },
    disclaimer: {
      intro: "This disclaimer outlines the limitations attached to the content and links provided by danswholesaleplants.",
      sections: {
        s1: {
          title: "Informational analysis",
          text: "Published information shares analytical insights and does not constitute contractual or operational advice."
        },
        s2: {
          title: "No guarantee",
          text: "No guarantee of exhaustiveness or permanent validity is offered. Content may change."
        },
        s3: {
          title: "External links",
          text: "Outgoing links are provided for convenience. The site does not endorse third-party content."
        },
        s4: {
          title: "Liability",
          text: "danswholesaleplants declines responsibility for misinterpretation of shared analyses."
        },
        s5: {
          title: "Updates",
          text: "Information may be updated without notice to reflect new work or observations."
        },
        s6: {
          title: "Contact",
          text: "Report inconsistencies or request clarification via the contact form."
        }
      }
    },
    thankyou: {
      title: "Thank you for reaching out",
      message: "Your message has been received. A response will follow after reviewing the details provided.",
      followup: "Feel free to return to the analyses or continue exploring the blog."
    },
    footer: {
      mission: "Belgian observatory dedicated to spatial orientation, informational interfaces and public infrastructure legibility.",
      address: "Rue de la Loi 155, 1040 Brussels, Belgium",
      phone: "Phone: +32 2 123 45 67",
      email: "Email: info@danswholesaleplants.com",
      rights: "© {year} danswholesaleplants. All rights reserved."
    },
    toasts: {
      formSuccess: "Message sent. Thank you for your contribution.",
      formError: "Please check the form information.",
      formSubmitting: "Sending in progress…"
    },
    form: {
      nameLabel: "Name",
      namePlaceholder: "Your full name",
      emailLabel: "Email address",
      emailPlaceholder: "example@organisation.be",
      orgLabel: "Organisation",
      orgPlaceholder: "Institution name",
      messageLabel: "Message",
      messagePlaceholder: "Describe your question or field insight",
      consentLabel: "I agree that my information will be used to answer my request.",
      submit: "Send message"
    },
    posts: {
      post1: {
        intro: "Contemporary cultural centres combine multiple levels, programmes and timeframes. These features complicate spatial reading and require a finely tuned hierarchy of cues.",
        section1: {
          heading: "Mapping stacked levels",
          paragraph1: "A Brussels cultural centre regrouping a media library, performance halls and studios faced recurring confusion around vertical circulation. Visitors overused the central lift while lateral staircases remained empty. Flow analysis revealed that wall-mounted plans emphasised activities rather than vertical connections. By repositioning circulation cores at the heart of diagrams and applying colour geometries to balustrades, flows balanced out and peak-time density dropped by 18 percent.",
          paragraph2: "Coherent cues demand sequential reading: every threshold communicates the relation between levels, functions and expected stay. Luminous markers were added to landings to recall main destinations and suggest alternative paths. Observations ran for three weeks across night events and morning workshops. Results fed an influence matrix measuring how each cue redistributed flows."
        },
        section1b: {
          heading: "Hierarchy and sensory perception",
          paragraph1: "Sensory coherence is crucial. Bright colours attract attention yet may blur hierarchy if not aligned with informational granularity. The centre adopted a restrained palette of blues and yellows reinforced by a single typeface. Tactile pictograms were applied to handrails to support passengers with low vision. Combined tactile and visual cues reduced hesitation at decision points during user tests.",
          paragraph2: "Audio cues were reassessed. Automated announcements interfered with performances at certain hours. A revised schedule now synchronises announcements with audience transitions, maintaining effectiveness without disturbing artistic experiences. The system relies on modular scenarios tailored to cultural programming and professional conferences."
        },
        section2: {
          heading: "Making digital plans intelligible",
          paragraph1: "Digital plans act as strategic entry points. Existing kiosks delivered static layouts only. The team introduced contextual layers: estimated travel time to each space, studio availability and suggested routes based on zone occupancy. Users filter by activity type while viewing real positions of lifts and stairs, easing decisions for time-pressed visitors.",
          paragraph2: "To align with physical signage, digital plans mirror colour codes and nomenclature from wall cues. Feedback loops were designed: when visitors follow a recommended route, luminous floor markers reassure them they remain on track. This establishes narrative continuity from the plan to the destination.",
          paragraph3: "Maintenance relies on a shared calendar between cultural staff and technical teams. Programming updates, temporary closures and construction phases feed a unified dashboard. Prior to major events, a scenario tests flow impact and adjusts digital messaging. Coordination sustains legibility despite frequent spatial reconfigurations."
        },
        section2b: {
          heading: "Indicators and qualitative feedback",
          paragraph1: "Indicators blend quantitative data and qualitative feedback. Average time spent locating rooms shrank from two minutes to seventy-five seconds. Anonymous surveys highlighted the effectiveness of luminous cues and tactile reminders. Welcome staff reported fewer location questions.",
          paragraph2: "The system keeps evolving. A quarterly observatory integrates new use cases, including international events attracting non-French or Dutch speakers. Multilingual plan versions are under testing while preserving the same visual architecture to avoid dissonance. Insights feed the broader reference framework shared with other Belgian cultural institutions.",
          paragraph3: "The study confirms that top-down cue hierarchy within plural environments requires collective governance, regular testing and refined articulation between physical and digital media. Sensory synchronisation remains a key lever to foster circulation while protecting cultural experience."
        }
      },
      post2: {
        intro: "University campuses now span several hectares, mixing educational facilities, laboratories, administrative services and open public spaces. Navigation must cope with fluctuating programmes and highly contrasted timeframes.",
        section1: {
          heading: "Working with academic timelines",
          paragraph1: "A Flemish campus study focused on the start of term and examination sessions. Both concentrate emotional load and maximum attendance. Pedestrian paths reshape abruptly: students rush toward auditoria whereas newcomers seek information desks. To anticipate variations, the team crafted narrative maps layered across three temporalities: regular week, enrolment period and exam weeks. Each layer identifies decision crossroads and density hotspots.",
          paragraph2: "Findings revealed a lack of signage for transition paths linking bike parks, bus stops and libraries. Existing plans focused on buildings without showing soft mobility networks. The new narrative map, distributed as poster and digital asset, offers a progressive reading: neighbourhood overview, primary axes, micro-journeys adapted to time constraints. Users consult the support according to familiarity and current goal."
        },
        section1b: {
          heading: "Adapting narratives to user profiles",
          paragraph1: "International students, administrative staff and external visitors do not require the same cues. Participatory workshops highlighted what each profile considered essential. Students valued speed and room availability, while visitors prioritised service understanding and transport options. Based on feedback, micro orientation stories were drafted, each structured into three steps: entry point, key trajectory, final cue.",
          paragraph2: "These narratives power a digital guide integrated into the campus website. Selecting a profile generates a tailored route with pictograms and time estimates. Each narrative links to an interactive map mirroring physical signage colours. The goal is to provide a coherent experience on smartphone, kiosk or printed plan."
        },
        section2: {
          heading: "Managing campus expansion",
          paragraph1: "Continuous expansion means new buildings sometimes open before signage is installed. A pre-opening protocol now maps provisional flows, identifies construction areas and designs temporary cues consistent with existing identity.",
          paragraph2: "Temporary cues rely on distinctive materials yet retain campus typography and colours. They include QR codes offering real-time itineraries. This hybrid approach limits confusion during transition phases and helps regular users adopt new spaces.",
          paragraph3: "Data gathered during the first three months feeds updates to the main map. Actual flows are compared with initial intentions to decide whether cues should remain or evolve. The process prevents accumulation of outdated panels and sustains narrative coherence."
        },
        section2b: {
          heading: "Success indicators and outlook",
          paragraph1: "Post-implementation surveys show a 27 percent rise in understanding of transverse routes. Information desk requests decreased while guide consultation doubled. International students especially appreciated selecting routes matching their language and site knowledge.",
          paragraph2: "Next steps include integrating real-time occupancy data to display study room saturation. The aim is to add context without intrusiveness. The approach reinforces the idea of a campus as an evolving spatial narrative aligned with community rhythms and expectations."
        }
      },
      post3: {
        intro: "Transport hubs shape the daily experience of thousands of travellers. Synchronising pedestrian flows, real-time information and safety constraints is a major challenge.",
        section1: {
          heading: "Aligning information and movement",
          paragraph1: "Within a Brussels hub linking train, metro, tram and bus lines, analysis revealed a constant gap between displayed data and real flow. Passengers checked screens, found their transfer, yet encountered poorly signposted bottlenecks. Detailed flow mapping reorganised eye-level cues with dual messaging: primary direction and alternatives during incidents. Screens were reprogrammed to deliver shorter, repetitive sequences, reducing cognitive load.",
          paragraph2: "Temporal communication was reframed. Instead of listing every departure, priority screens show immediate transfers while side totems present subsequent ones. This sequential split helps travellers focus on the most urgent action and limits trajectory shifts."
        },
        section1b: {
          heading: "Easing transfers",
          paragraph1: "Complex transfers are hindered by level changes. The studied hub counts four main tiers. Each tier now features a dominant colour and subtle graphic pattern repeated on ramps and bridges. Travellers recognise their progress and instantly know if the next transfer is above or below.",
          paragraph2: "Dynamic light cues activate during critical transfers to guide flows toward relevant platforms. When multiple transfers are key, light sequences differ to avoid confusion. Tests showed fewer U-turns and better distribution between stairs and lifts."
        },
        section2: {
          heading: "Integrating safety constraints",
          paragraph1: "Orientation devices must align with safety protocols. The team worked with safety services to define evacuation scenarios compatible with new signage. Emergency messages reuse daily colour codes with higher intensity. Plans display priority routes during disruptions, reducing the need for repeated verbal instructions.",
          paragraph2: "Special attention went to travellers with reduced mobility. Accessible itineraries appear immediately at entrances with regular reminders along the path. Platform lifts and elevators offer tactile signage and high-contrast markings. Flow detectors monitor sensitive zones to adapt messaging in real time.",
          paragraph3: "Operator feedback confirms that matching daily and exceptional orientation is essential. Harmonised supports make announcements clearer and travellers follow recommended routes without prolonged hesitation."
        },
        section2b: {
          heading: "Impact measurement and outlook",
          paragraph1: "Six months later, transfer times on critical journeys dropped by 14 percent. Surveys show stronger understanding of alternate routes. Travellers note the coherence between screens and physical beacons.",
          paragraph2: "The hub plans to integrate density indicators on digital plans to redirect part of the flow during peaks, maintaining legibility as passenger numbers rise."
        }
      },
      post4: {
        intro: "Touch interfaces have spread across public buildings. Their effectiveness depends on ergonomics, spatial integration and coherence with surrounding signage.",
        section1: {
          heading: "Assessing posture and legibility",
          paragraph1: "In a Walloon administrative centre, kiosks were installed without studying user posture. Some screens were illegible for short visitors or wheelchair users. Ergonomic audit led to repositioning, adding a high-contrast mode and integrating audio description. Interactions were simplified: information is grouped into three main categories, each reachable within two taps.",
          paragraph2: "Tests highlighted the importance of typographic consistency. Screens adopt the same typeface as wall signage with generous line spacing. A permanent back button sits at the bottom to avoid dead ends."
        },
        section1b: {
          heading: "Ensuring continuity between screen and space",
          paragraph1: "Touch experience extends beyond the device. Once a destination is chosen, visitors must find cues in physical space. Interfaces synchronise with ceiling beacons lighting up to indicate initial direction. Floor plans were updated with pictograms matching the screen.",
          paragraph2: "Kiosks also provide a QR code to continue navigation on mobile. Continuity prevents users from memorising entire routes and strengthens control."
        },
        section2: {
          heading: "Embedding inclusive accessibility",
          paragraph1: "Kiosks offer an audio navigation option. Users may plug headphones or activate a discreet speaker. Voice instructions detail button positions, approximate distance and cues to observe, helping visitors with low vision or low familiarity.",
          paragraph2: "Contrasting tactile pads surround the screen, guiding hands and signalling physical buttons. Feedback shows reduced stress linked to technology.",
          paragraph3: "Maintenance relies on a central console. Content updates occur weekly to reflect service changes. Statistics reveal most consulted screens, informing navigation structure."
        },
        section2b: {
          heading: "Performance indicators",
          paragraph1: "Interaction time dropped from two minutes forty to one minute thirty on average. Successful navigation rate, measured via exit survey, rose by twenty-two points. Front-desk staff report better understanding of complex paths.",
          paragraph2: "Next steps include integrating queue information and offering time-based suggestions. These updates will keep kiosks relevant within a constantly adapting building."
        }
      },
      post5: {
        intro: "Stratified urban spaces blend elevated walkways, underground galleries and open plazas. Their legibility depends on clear vertical transitions and coherent material cues.",
        section1: {
          heading: "Observing real-time flows",
          paragraph1: "In a Brussels business district, pedestrians use elevated walkways, tunnels and public squares simultaneously. Observations revealed that unfamiliar users stayed at ground level, lengthening journeys. Shared mental maps showed that walkways were perceived as private despite being public. Existing signage failed to clarify this status.",
          paragraph2: "To address it, luminous ribbons were installed on walkway access points alongside messages confirming public access. Flows gradually rebalanced, easing ground-level congestion and boosting upper-level commerce."
        },
        section1b: {
          heading: "Linking layers with coherent cues",
          paragraph1: "Underground galleries connect car parks, metro stations and shopping centres. They lacked natural light and vertical orientation. Light wells were added at key spots, while totems indicate links to upper levels. Colours used in tunnels mirror walkway tones to strengthen visual continuity.",
          paragraph2: "Tactile maps were placed at major intersections. They describe district topography, accessible entrances and amenities. Feedback from people with reduced mobility confirms easier understanding of multi-level routes."
        },
        section2: {
          heading: "Measuring impact on urban legibility",
          paragraph1: "The study combined counting, short surveys and anonymised GPS itineraries. Results show a nineteen percent increase in walkway usage and shorter travel times between transport nodes and offices. Users report clearer grasp of alternatives offered by different layers.",
          paragraph2: "The municipality plans to extend this setup to other stratified areas. Usage guides will help visitors choose itineraries based on weather, crowd levels or available time.",
          paragraph3: "The initiative proves that urban legibility relies on continuous storytelling between layers, inclusive signage and ongoing coordination between public stakeholders and private managers."
        }
      }
    }
  }
};

function getTranslation(lang, key) {
  const segments = key.split(".");
  let value = I18N[lang];
  for (const segment of segments) {
    if (value && Object.prototype.hasOwnProperty.call(value, segment)) {
      value = value[segment];
    } else {
      value = null;
      break;
    }
  }
  return value;
}

function replacePlaceholders(text) {
  if (typeof text !== "string") return text;
  return text.replace("{year}", new Date().getFullYear());
}

function applyLanguage(lang) {
  currentLang = lang;
  document.documentElement.setAttribute("lang", lang);
  const textNodes = document.querySelectorAll("[data-i18n]");
  textNodes.forEach((element) => {
    const key = element.dataset.i18n;
    const translation = getTranslation(lang, key);
    if (translation !== null && translation !== undefined) {
      element.textContent = replacePlaceholders(translation);
    }
  });

  const placeholders = document.querySelectorAll("[data-i18n-placeholder]");
  placeholders.forEach((element) => {
    const key = element.dataset.i18nPlaceholder;
    const translation = getTranslation(lang, key);
    if (translation !== null && translation !== undefined) {
      element.setAttribute("placeholder", translation);
      if (element.tagName === "TEXTAREA") {
        element.textContent = "";
      }
    }
  });

  const metaElements = document.querySelectorAll("[data-i18n-meta]");
  metaElements.forEach((element) => {
    const key = element.dataset.i18nMeta;
    const translation = getTranslation(lang, key);
    if (translation !== null && translation !== undefined) {
      element.setAttribute("content", replacePlaceholders(translation));
    }
  });

  const titleElements = document.querySelectorAll("[data-i18n-title]");
  titleElements.forEach((element) => {
    const key = element.dataset.i18nTitle;
    const translation = getTranslation(lang, key);
    if (translation !== null && translation !== undefined) {
      if (element.tagName.toLowerCase() === "title") {
        element.textContent = replacePlaceholders(translation);
      } else {
        element.setAttribute("title", translation);
      }
    }
  });

  const altElements = document.querySelectorAll("[data-i18n-alt]");
  altElements.forEach((element) => {
    const key = element.dataset.i18nAlt;
    const translation = getTranslation(lang, key);
    if (translation !== null && translation !== undefined) {
      element.setAttribute("alt", translation);
    }
  });

  const ariaElements = document.querySelectorAll("[data-i18n-aria-label]");
  ariaElements.forEach((element) => {
    const key = element.dataset.i18nAriaLabel;
    const translation = getTranslation(lang, key);
    if (translation !== null && translation !== undefined) {
      element.setAttribute("aria-label", translation);
    }
  });

  const languageButtons = document.querySelectorAll("[data-lang]");
  languageButtons.forEach((button) => {
    if (button.dataset.lang === lang) {
      button.classList.add("active");
    } else {
      button.classList.remove("active");
    }
  });
}

function initLanguage() {
  const stored = localStorage.getItem(LANG_KEY);
  const lang = stored && I18N[stored] ? stored : DEFAULT_LANG;
  applyLanguage(lang);
}

function handleLanguageSwitch() {
  const languageButtons = document.querySelectorAll("[data-lang]");
  languageButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const lang = button.dataset.lang;
      if (lang && I18N[lang]) {
        localStorage.setItem(LANG_KEY, lang);
        applyLanguage(lang);
        updateCookieBannerText();
      }
    });
  });
}

function handleNavigation() {
  const menuToggle = document.querySelector(".menu-toggle");
  const navigation = document.querySelector(".primary-navigation");
  if (!menuToggle || !navigation) return;

  menuToggle.addEventListener("click", () => {
    const isOpen = navigation.classList.toggle("open");
    const labelKey = isOpen ? "header.menuClose" : "header.menuOpen";
    const translation = getTranslation(currentLang, labelKey);
    if (translation) {
      menuToggle.setAttribute("aria-label", translation);
    }
  });

  navigation.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      navigation.classList.remove("open");
      const translation = getTranslation(currentLang, "header.menuOpen");
      if (translation) {
        menuToggle.setAttribute("aria-label", translation);
      }
    });
  });
}

function initAnimations() {
  const animatedElements = document.querySelectorAll(".animate-on-scroll");
  if (!("IntersectionObserver" in window)) {
    animatedElements.forEach((el) => el.classList.add("is-visible"));
    return;
  }
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.2
    }
  );
  animatedElements.forEach((el) => observer.observe(el));
}

function createToast(message, type = "success") {
  const container = document.getElementById("toastContainer");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = "toast";
  if (type === "error") toast.classList.add("error");
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(20px)";
  }, TOAST_DURATION - 800);
  setTimeout(() => {
    toast.remove();
  }, TOAST_DURATION);
}

function showToast(key, type = "success") {
  const message = getTranslation(currentLang, `toasts.${key}`);
  if (message) {
    createToast(message, type);
  }
}

function handleForm() {
  const form = document.getElementById("contactForm");
  if (!form) return;
  let isSubmitting = false;
  form.addEventListener("submit", (event) => {
    if (isSubmitting) return;
    if (!form.checkValidity()) {
      event.preventDefault();
      showToast("formError", "error");
      return;
    }
    event.preventDefault();
    isSubmitting = true;
    showToast("formSubmitting", "success");
    localStorage.setItem("form_submission_notice", Date.now().toString());
    setTimeout(() => {
      form.submit();
    }, 900);
  });
}

function displayThankYouToast() {
  const marker = localStorage.getItem("form_submission_notice");
  if (!marker) return;
  const body = document.body;
  if (body && body.classList.contains("thank-you-page")) {
    showToast("formSuccess", "success");
    localStorage.removeItem("form_submission_notice");
  }
}

function getStoredConsent() {
  try {
    const consent = localStorage.getItem(COOKIE_KEY);
    if (!consent) return null;
    return JSON.parse(consent);
  } catch (error) {
    return null;
  }
}

function saveConsent(consent) {
  localStorage.setItem(COOKIE_KEY, JSON.stringify(consent));
}

function updateCookieToggles(consent) {
  const toggles = document.querySelectorAll("[data-cookie-toggle]");
  toggles.forEach((toggle) => {
    const key = toggle.dataset.cookieToggle;
    if (key === "necessary") {
      toggle.setAttribute("aria-checked", "true");
      toggle.setAttribute("disabled", "true");
      return;
    }
    const value = consent[key] || false;
    toggle.setAttribute("aria-checked", value ? "true" : "false");
  });
}

function toggleConsentState(consent, key) {
  const updated = { ...consent };
  updated[key] = !updated[key];
  return updated;
}

function applyConsent(consent, persist = false) {
  if (persist) {
    consent.decidedAt = new Date().toISOString();
    saveConsent(consent);
  }
  updateCookieToggles(consent);
  const banner = document.getElementById("cookieBanner");
  if (banner) {
    banner.classList.remove("is-visible");
  }
}

function initCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  if (!banner) return;

  const consent = getStoredConsent();
  if (consent) {
    updateCookieToggles(consent);
  } else {
    banner.classList.add("is-visible");
  }

  const toggles = banner.querySelectorAll("[data-cookie-toggle]");
  toggles.forEach((toggle) => {
    toggle.addEventListener("click", () => {
      if (toggle.disabled) return;
      const key = toggle.dataset.cookieToggle;
      const current = getStoredConsent() || {
        necessary: true,
        preferences: false,
        analytics: false,
        marketing: false,
        decidedAt: null
      };
      const updated = toggleConsentState(current, key);
      updateCookieToggles(updated);
      saveConsent(updated);
    });
  });

  const acceptAll = banner.querySelector("[data-cookie-action='accept']");
  const declineAll = banner.querySelector("[data-cookie-action='decline']");
  const saveButton = banner.querySelector("[data-cookie-action='save']");
  const manageButton = banner.querySelector("[data-cookie-manage]");
  const closeButton = banner.querySelector("[data-cookie-close]");

  if (acceptAll) {
    acceptAll.addEventListener("click", () => {
      const newConsent = {
        necessary: true,
        preferences: true,
        analytics: true,
        marketing: true,
        decidedAt: new Date().toISOString()
      };
      saveConsent(newConsent);
      applyConsent(newConsent);
    });
  }

  if (declineAll) {
    declineAll.addEventListener("click", () => {
      const newConsent = {
        necessary: true,
        preferences: false,
        analytics: false,
        marketing: false,
        decidedAt: new Date().toISOString()
      };
      saveConsent(newConsent);
      applyConsent(newConsent);
    });
  }

  if (saveButton) {
    saveButton.addEventListener("click", () => {
      const current = getStoredConsent() || {
        necessary: true,
        preferences: false,
        analytics: false,
        marketing: false,
        decidedAt: new Date().toISOString()
      };
      current.decidedAt = new Date().toISOString();
      saveConsent(current);
      applyConsent(current);
    });
  }

  if (manageButton) {
    manageButton.addEventListener("click", () => {
      banner.classList.toggle("expanded");
    });
  }

  if (closeButton) {
    closeButton.addEventListener("click", () => {
      banner.classList.remove("expanded");
      banner.classList.remove("is-visible");
    });
  }

  updateCookieBannerText();
}

function updateCookieBannerText() {
  const banner = document.getElementById("cookieBanner");
  if (!banner) return;
  const manageButton = banner.querySelector("[data-cookie-manage]");
  const label = getTranslation(currentLang, "cookies.banner.manage");
  if (manageButton && label) {
    manageButton.textContent = label;
  }
}

function updateDynamicYear() {
  const footer = document.querySelectorAll("[data-dynamic-year]");
  footer.forEach((element) => {
    element.textContent = new Date().getFullYear().toString();
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initLanguage();
  handleLanguageSwitch();
  handleNavigation();
  initAnimations();
  handleForm();
  initCookieBanner();
  displayThankYouToast();
  updateDynamicYear();
});