document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            navToggle.classList.toggle('open');
            navMenu.classList.toggle('open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('open');
                navMenu.classList.remove('open');
            });
        });
    }

    const banner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');
    const customizeBtn = document.getElementById('cookieCustomize');
    const preferenceKey = 'phonicqgulCookieConsent';

    if (banner) {
        const storedPreference = localStorage.getItem(preferenceKey);
        if (!storedPreference) {
            banner.classList.add('active');
        }

        const hideBanner = (value) => {
            localStorage.setItem(preferenceKey, value);
            banner.classList.remove('active');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => hideBanner('accepted'));
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => hideBanner('declined'));
        }

        if (customizeBtn) {
            customizeBtn.addEventListener('click', () => {
                hideBanner('customize');
                window.location.href = 'cookies.html';
            });
        }
    }
});