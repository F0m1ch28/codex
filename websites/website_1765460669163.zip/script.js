document.addEventListener("DOMContentLoaded", () => {
  const banner = document.querySelector(".cookie-banner");
  if (!banner) return;
  const acceptBtn = banner.querySelector(".cookie-accept");
  const declineBtn = banner.querySelector(".cookie-decline");
  const consent = localStorage.getItem("adm-cookie-consent");

  if (!consent) {
    banner.style.display = "flex";
  }

  const handleConsent = (value) => {
    localStorage.setItem("adm-cookie-consent", value);
    banner.style.display = "none";
  };

  acceptBtn.addEventListener("click", () => handleConsent("accepted"));
  declineBtn.addEventListener("click", () => handleConsent("declined"));
});