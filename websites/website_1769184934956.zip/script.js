document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      nav.classList.toggle("is-active");
    });
  }

  document.querySelectorAll(".current-year").forEach((el) => {
    el.textContent = new Date().getFullYear();
  });

  const cookieBanner = document.getElementById("cookie-banner");
  const cookieKey = "signaturebystremio_cookie_consent";

  if (cookieBanner) {
    const storedChoice = localStorage.getItem(cookieKey);
    if (storedChoice) {
      cookieBanner.classList.add("hidden");
    }

    const acceptBtn = cookieBanner.querySelector("[data-cookie='accept']");
    const declineBtn = cookieBanner.querySelector("[data-cookie='decline']");

    const handleChoice = (choice) => {
      localStorage.setItem(cookieKey, choice);
      cookieBanner.classList.add("hidden");
    };

    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => handleChoice("accepted"));
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => handleChoice("declined"));
    }
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.18 }
  );

  document.querySelectorAll(".scroll-reveal").forEach((section) => {
    observer.observe(section);
  });

  const toast = document.getElementById("global-toast");
  const showToast = (message) => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    setTimeout(() => {
      toast.classList.remove("is-visible");
    }, 1800);
  };

  document.querySelectorAll("form").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      showToast("Your message is being routed. Redirecting...");
      setTimeout(() => {
        const target = form.getAttribute("action") || "thank-you.html";
        window.location.href = target;
      }, 1600);
    });
  });
});