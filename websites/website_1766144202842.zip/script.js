document.addEventListener("DOMContentLoaded", function () {
    const banner = document.querySelector("[data-banner]");
    if (!banner) {
        return;
    }
    const acceptButton = banner.querySelector("[data-accept]");
    const declineButton = banner.querySelector("[data-decline]");
    const preference = localStorage.getItem("cookiePreference");
    if (preference === "accepted" || preference === "declined") {
        banner.classList.add("hidden");
        return;
    }
    requestAnimationFrame(() => {
        banner.classList.add("visible");
    });
    function handleChoice(choice) {
        localStorage.setItem("cookiePreference", choice);
        banner.classList.remove("visible");
        setTimeout(() => {
            banner.classList.add("hidden");
        }, 300);
    }
    if (acceptButton) {
        acceptButton.addEventListener("click", function () {
            handleChoice("accepted");
        });
    }
    if (declineButton) {
        declineButton.addEventListener("click", function () {
            handleChoice("declined");
        });
    }
});