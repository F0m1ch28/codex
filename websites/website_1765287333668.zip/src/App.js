import { Routes, Route, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Methodologie from "./pages/Methodologie";
import Archives from "./pages/Archives";
import Thematiques from "./pages/Thematiques";
import Ressources from "./pages/Ressources";
import Contact from "./pages/Contact";
import ConditionsGenerales from "./pages/ConditionsGenerales";
import PolitiqueConfidentialite from "./pages/PolitiqueConfidentialite";
import PolitiqueCookies from "./pages/PolitiqueCookies";

function ScrollToTopOnRouteChange() {
  const location = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
  }, [location.pathname]);
  return null;
}

function App() {
  return (
    <>
      <Header />
      <ScrollToTopOnRouteChange />
      <main id="contenu-principal">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/a-propos" element={<About />} />
          <Route path="/methodologie" element={<Methodologie />} />
          <Route path="/archives" element={<Archives />} />
          <Route path="/thematiques" element={<Thematiques />} />
          <Route path="/ressources" element={<Ressources />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/conditions-generales" element={<ConditionsGenerales />} />
          <Route
            path="/politique-de-confidentialite"
            element={<PolitiqueConfidentialite />}
          />
          <Route path="/politique-des-cookies" element={<PolitiqueCookies />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
      <CookieBanner />
    </>
  );
}

export default App;