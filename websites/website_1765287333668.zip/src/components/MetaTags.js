import { useEffect } from "react";

function mettreMeta(name, content) {
  if (!content) return;
  let element = document.querySelector(`meta[name="${name}"]`);
  if (!element) {
    element = document.createElement("meta");
    element.setAttribute("name", name);
    document.head.appendChild(element);
  }
  element.setAttribute("content", content);
}

function mettreMetaProperty(property, content) {
  if (!content) return;
  let element = document.querySelector(`meta[property="${property}"]`);
  if (!element) {
    element = document.createElement("meta");
    element.setAttribute("property", property);
    document.head.appendChild(element);
  }
  element.setAttribute("content", content);
}

function MetaTags({ title, description, url, image }) {
  useEffect(() => {
    const baseTitle = "Historic Streets of France Review";
    const fullTitle = title ? `${title} | ${baseTitle}` : baseTitle;
    document.title = fullTitle;

    mettreMeta("description", description || "Historic Streets of France Review analyse les rues historiques françaises avec une approche documentaire.");
    mettreMetaProperty("og:title", fullTitle);
    mettreMetaProperty("og:description", description || "Historic Streets of France Review analyse les rues historiques françaises avec une approche documentaire.");
    mettreMetaProperty("og:type", "website");
    mettreMetaProperty("og:url", url || "https://www.historicstreets-fr-review.org");
    mettreMetaProperty("og:image", image || "https://picsum.photos/1200/630?random=901");
    mettreMeta("twitter:card", "summary_large_image");
    mettreMeta("twitter:title", fullTitle);
    mettreMeta("twitter:description", description || "Historic Streets of France Review analyse les rues historiques françaises avec une approche documentaire.");
    mettreMeta("twitter:image", image || "https://picsum.photos/1200/630?random=901");
  }, [title, description, url, image]);

  return null;
}

export default MetaTags;