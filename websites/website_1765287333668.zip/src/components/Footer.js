import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.colonneLarge}>
          <div className={styles.logo}>Historic Streets of France Review</div>
          <p className={styles.texte}>
            Historic Streets of France Review présente une lecture méthodique des
            rues historiques françaises en valorisant la rigueur documentaire et la
            pluralité des sources urbaines.
          </p>
        </div>
        <div className={styles.colonne}>
          <h3 className={styles.titre}>Navigation</h3>
          <ul className={styles.liste}>
            <li>
              <Link to="/a-propos">À Propos</Link>
            </li>
            <li>
              <Link to="/methodologie">Méthodologie</Link>
            </li>
            <li>
              <Link to="/archives">Archives</Link>
            </li>
            <li>
              <Link to="/thematiques">Thématiques</Link>
            </li>
            <li>
              <Link to="/ressources">Ressources</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </div>
        <div className={styles.colonne}>
          <h3 className={styles.titre}>Documents</h3>
          <ul className={styles.liste}>
            <li>
              <Link to="/conditions-generales">Conditions Générales</Link>
            </li>
            <li>
              <Link to="/politique-de-confidentialite">
                Politique de Confidentialité
              </Link>
            </li>
            <li>
              <Link to="/politique-des-cookies">Politique des Cookies</Link>
            </li>
          </ul>
        </div>
        <div className={styles.colonne}>
          <h3 className={styles.titre}>Contact</h3>
          <p className={styles.texte}>
            Email&nbsp;:{" "}
            <a href="mailto:redaction@historicstreets-fr-review.org">
              redaction@historicstreets-fr-review.org
            </a>
          </p>
          <p className={styles.texte}>
            Adresse postale&nbsp;: Historic Streets of France Review, BP 123, 75006
            Paris, France
          </p>
        </div>
      </div>
      <div className={styles.bas}>
        © {new Date().getFullYear()} Historic Streets of France Review. Tous droits
        réservés.
      </div>
    </footer>
  );
}

export default Footer;