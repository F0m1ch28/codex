import { useState } from "react";
import { NavLink } from "react-router-dom";
import styles from "./Header.module.css";

function Header() {
  const [menuOuvert, setMenuOuvert] = useState(false);

  const toggleMenu = () => {
    setMenuOuvert((prev) => !prev);
  };

  const fermerMenu = () => {
    setMenuOuvert(false);
  };

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} onClick={fermerMenu}>
          Historic Streets of France Review
        </NavLink>
        <nav
          className={`${styles.nav} ${menuOuvert ? styles.navOuvert : ""}`}
          aria-label="Navigation principale"
        >
          <NavLink
            to="/"
            className={({ isActive }) =>
              isActive ? `${styles.lien} ${styles.actif}` : styles.lien
            }
            onClick={fermerMenu}
          >
            Accueil
          </NavLink>
          <NavLink
            to="/a-propos"
            className={({ isActive }) =>
              isActive ? `${styles.lien} ${styles.actif}` : styles.lien
            }
            onClick={fermerMenu}
          >
            À Propos
          </NavLink>
          <NavLink
            to="/methodologie"
            className={({ isActive }) =>
              isActive ? `${styles.lien} ${styles.actif}` : styles.lien
            }
            onClick={fermerMenu}
          >
            Méthodologie
          </NavLink>
          <NavLink
            to="/archives"
            className={({ isActive }) =>
              isActive ? `${styles.lien} ${styles.actif}` : styles.lien
            }
            onClick={fermerMenu}
          >
            Archives
          </NavLink>
          <NavLink
            to="/thematiques"
            className={({ isActive }) =>
              isActive ? `${styles.lien} ${styles.actif}` : styles.lien
            }
            onClick={fermerMenu}
          >
            Thématiques
          </NavLink>
          <NavLink
            to="/ressources"
            className={({ isActive }) =>
              isActive ? `${styles.lien} ${styles.actif}` : styles.lien
            }
            onClick={fermerMenu}
          >
            Ressources
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) =>
              isActive ? `${styles.lien} ${styles.actif}` : styles.lien
            }
            onClick={fermerMenu}
          >
            Contact
          </NavLink>
        </nav>
        <button
          className={styles.boutonLangue}
          type="button"
          aria-label="Changer de langue (fonction à venir)"
          title="Changer de langue (fonction à venir)"
        >
          FR
        </button>
        <button
          className={styles.menuBouton}
          type="button"
          aria-label="Ouvrir le menu"
          onClick={toggleMenu}
        >
          <span className={styles.menuIcone} />
        </button>
      </div>
    </header>
  );
}

export default Header;