import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import styles from "./CookieBanner.module.css";

const stockageCle = "hsfr-cookie-consent";

const consentementParDefaut = {
  necessary: true,
  analytics: false,
};

function CookieBanner() {
  const [afficher, setAfficher] = useState(false);
  const [preferences, setPreferences] = useState(consentementParDefaut);
  const [personnaliser, setPersonnaliser] = useState(false);

  useEffect(() => {
    const sauvegarde = localStorage.getItem(stockageCle);
    if (sauvegarde) {
      try {
        const parse = JSON.parse(sauvegarde);
        setPreferences({ ...consentementParDefaut, ...parse });
      } catch (e) {
        setPreferences(consentementParDefaut);
      }
    } else {
      setAfficher(true);
    }
  }, []);

  const enregistrer = (valeurs) => {
    localStorage.setItem(stockageCle, JSON.stringify(valeurs));
    setPreferences(valeurs);
    setAfficher(false);
  };

  const accepter = () => {
    enregistrer({ necessary: true, analytics: true });
  };

  const enregistrerPersonnalisation = () => {
    enregistrer(preferences);
    setPersonnaliser(false);
  };

  if (!afficher) {
    return null;
  }

  return (
    <div className={styles.banniere} role="dialog" aria-live="polite">
      <div className={styles.contenu}>
        <p>
          Historic Streets of France Review utilise des cookies nécessaires au
          fonctionnement du site ainsi que des mesures analytiques facultatives.
          Les détails figurent dans la{" "}
          <Link to="/politique-des-cookies">Politique des Cookies</Link>.
        </p>
        <div className={styles.actions}>
          <button type="button" className={styles.boutonSecondaire} onClick={() => setPersonnaliser(true)}>
            Personnaliser
          </button>
          <button type="button" className={styles.boutonPrincipal} onClick={accepter}>
            Accepter
          </button>
        </div>
      </div>
      {personnaliser && (
        <div className={styles.personnalisation}>
          <h4>Préférences de cookies</h4>
          <div className={styles.option}>
            <div>
              <strong>Essentiels</strong>
              <p>Assurent le fonctionnement de base du site. Toujours actifs.</p>
            </div>
            <input type="checkbox" checked readOnly aria-label="Cookies essentiels activés" />
          </div>
          <div className={styles.option}>
            <div>
              <strong>Analyse</strong>
              <p>Contribuent au suivi anonymisé de la fréquentation.</p>
            </div>
            <label className={styles.interrupteur}>
              <input
                type="checkbox"
                checked={preferences.analytics}
                onChange={(e) =>
                  setPreferences((prev) => ({ ...prev, analytics: e.target.checked }))
                }
              />
              <span className={styles.lever} />
            </label>
          </div>
          <div className={styles.actionsPersonnalisation}>
            <button
              type="button"
              className={styles.boutonSecondaire}
              onClick={() => setPersonnaliser(false)}
            >
              Fermer
            </button>
            <button
              type="button"
              className={styles.boutonPrincipal}
              onClick={enregistrerPersonnalisation}
            >
              Enregistrer
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default CookieBanner;