import { useState } from "react";
import MetaTags from "../components/MetaTags";
import layoutStyles from "../styles/PageLayout.module.css";

const etapes = [
  {
    titre: "Inventaire des sources",
    resume:
      "Collecte structurée des registres cadastraux, plans d'alignement, photographies historiques et témoignages écrits.",
  },
  {
    titre: "Analyse morphologique",
    resume:
      "Croisement des données topographiques avec les séries iconographiques pour comprendre la dynamique spatiale.",
  },
  {
    titre: "Contextualisation sociale",
    resume:
      "Intégration des archives commerciales, associatives et municipales afin de caractériser les usages des rues.",
  },
  {
    titre: "Restitution cartographique",
    resume:
      "Production de cartes thématiques, schémas chronologiques et frises commentées pour synthétiser les observations.",
  },
];

const faqItems = [
  {
    question: "Comment sont sélectionnées les rues étudiées ?",
    reponse:
      "Chaque rue est retenue selon son intérêt patrimonial, la disponibilité des sources et la pertinence pour la compréhension des dynamiques urbaines françaises.",
  },
  {
    question: "Quels outils numériques sont mobilisés ?",
    reponse:
      "Les analyses mobilisent des systèmes d'information géographique, des outils de textométrie et des bases de données archivistiques interopérables.",
  },
  {
    question: "Comment sont validées les informations recueillies ?",
    reponse:
      "Les informations sont systématiquement recoupées avec plusieurs sources et soumises à la relecture d'experts universitaires partenaires.",
  },
];

function Methodologie() {
  const [questionOuverte, setQuestionOuverte] = useState(null);

  const basculerFaq = (index) => {
    setQuestionOuverte((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <MetaTags
        title="Méthodologie"
        description="Présentation de la méthodologie éditoriale d'Historic Streets of France Review."
        url="https://www.historicstreets-fr-review.org/methodologie"
      />
      <article className={layoutStyles.page}>
        <header className={layoutStyles.entete}>
          <p className={layoutStyles.surtitre}>Cadre analytique</p>
          <h1>Méthodologie</h1>
          <p className={layoutStyles.intro}>
            La méthodologie adoptée assure une lecture rigoureuse des rues françaises en
            combinant enquêtes archivistiques, outils cartographiques et analyses
            socio-spatiales.
          </p>
        </header>

        <section className={layoutStyles.section}>
          <h2>Processus d'enquête</h2>
          <div className={layoutStyles.grilleProcessus}>
            {etapes.map((etape) => (
              <article key={etape.titre} className={layoutStyles.etape}>
                <h3>{etape.titre}</h3>
                <p>{etape.resume}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={layoutStyles.section}>
          <h2>Standards de documentation</h2>
          <p>
            Chaque étude est accompagnée d'une description précise des sources consultées,
            d'une bibliographie commentée et d'une fiche méthodologique détaillant les
            outils utilisés. Les critères de sélection et les limites des corpus sont
            systématiquement explicités.
          </p>
        </section>

        <section className={layoutStyles.section}>
          <h2>Questions fréquentes</h2>
          <div className={layoutStyles.accordeon}>
            {faqItems.map((item, index) => (
              <div key={item.question} className={layoutStyles.accordeonItem}>
                <button
                  type="button"
                  className={layoutStyles.accordeonBouton}
                  aria-expanded={questionOuverte === index}
                  onClick={() => basculerFaq(index)}
                >
                  {item.question}
                  <span aria-hidden="true">
                    {questionOuverte === index ? "−" : "+"}
                  </span>
                </button>
                {questionOuverte === index && (
                  <div className={layoutStyles.accordeonContenu}>
                    <p>{item.reponse}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      </article>
    </>
  );
}

export default Methodologie;