import MetaTags from "../components/MetaTags";
import layoutStyles from "../styles/PageLayout.module.css";

function PolitiqueCookies() {
  return (
    <>
      <MetaTags
        title="Politique des Cookies"
        description="Politique d'utilisation des cookies sur Historic Streets of France Review."
        url="https://www.historicstreets-fr-review.org/politique-des-cookies"
      />
      <article className={layoutStyles.page}>
        <header className={layoutStyles.entete}>
          <h1>Politique des cookies</h1>
        </header>

        <section className={layoutStyles.section}>
          <h2>Définition</h2>
          <p>
            Un cookie est un fichier texte déposé sur l'appareil de l'utilisateur afin de
            faciliter la navigation et de recueillir des mesures d'audience anonymisées.
          </p>
        </section>

        <section className={layoutStyles.section}>
          <h2>Cookies essentiels</h2>
          <p>
            Ces cookies garantissent le fonctionnement du site (gestion de session,
            affichage multi-support). Ils sont indispensables et ne nécessitent pas de
            consentement.
          </p>
        </section>

        <section className={layoutStyles.section}>
          <h2>Cookies analytiques</h2>
          <p>
            Les cookies analytiques permettent de comprendre la fréquentation globale.
            Ils sont activés uniquement si l'utilisateur donne son accord via la bannière
            dédiée.
          </p>
        </section>

        <section className={layoutStyles.section}>
          <h2>Paramétrage</h2>
          <p>
            Les préférences peuvent être ajustées à tout moment en cliquant sur le lien
            présent dans la bannière ou en effaçant les cookies depuis le navigateur.
          </p>
        </section>
      </article>
    </>
  );
}

export default PolitiqueCookies;