import MetaTags from "../components/MetaTags";
import layoutStyles from "../styles/PageLayout.module.css";

const archives = [
  {
    ville: "Paris",
    titre: "Les passages couverts du IXe arrondissement",
    periode: "1850-1930",
    resume:
      "Étude des transformations commerciales et de la lumière naturelle dans les passages Jouffroy et Verdeau.",
    image: "https://picsum.photos/560/400?random=301",
  },
  {
    ville: "Marseille",
    titre: "La Canebière et ses horizons maritimes",
    periode: "1890-1975",
    resume:
      "Analyse des correspondances portuaires et des chroniques locales sur le rôle des tramways et des cafés.",
    image: "https://picsum.photos/560/400?random=302",
  },
  {
    ville: "Rouen",
    titre: "Rue Eau-de-Robec, atelier ouvert",
    periode: "1910-1980",
    resume:
      "Inventaire des métiers artisanaux et suivi des politiques de restauration du cœur médiéval.",
    image: "https://picsum.photos/560/400?random=303",
  },
  {
    ville: "Bordeaux",
    titre: "Les Chartrons et l'économie du négoce",
    periode: "1885-1960",
    resume:
      "Lecture croisée des registres douaniers et des carnets de maisons de commerce de la Garonne.",
    image: "https://picsum.photos/560/400?random=304",
  },
  {
    ville: "Dijon",
    titre: "Rue de la Liberté et patrimoine quotidien",
    periode: "1930-2020",
    resume:
      "Observation de la continuité commerçante et des transitions piétonnières dans l'hypercentre dijonnais.",
    image: "https://picsum.photos/560/400?random=305",
  },
  {
    ville: "Nice",
    titre: "Promenade des Anglais, stratifications littorales",
    periode: "1860-2010",
    resume:
      "Étude des plans balnéaires, des archives photographiques et des témoignages de villégiature.",
    image: "https://picsum.photos/560/400?random=306",
  },
];

function Archives() {
  return (
    <>
      <MetaTags
        title="Archives"
        description="Archives des études publiées par Historic Streets of France Review."
        url="https://www.historicstreets-fr-review.org/archives"
      />
      <article className={layoutStyles.page}>
        <header className={layoutStyles.entete}>
          <p className={layoutStyles.surtitre}>Corpus documentaires</p>
          <h1>Archives des études</h1>
          <p className={layoutStyles.intro}>
            Ce répertoire rassemble les dossiers publiés par ville et par période,
            accompagnés d'une synthèse des sources consultées.
          </p>
        </header>
        <section className={layoutStyles.section}>
          <div className={layoutStyles.grilleArchives}>
            {archives.map((item) => (
              <article key={item.titre} className={layoutStyles.archiveCarte}>
                <img src={item.image} alt={`Vue de ${item.ville}`} loading="lazy" />
                <div className={layoutStyles.archiveTexte}>
                  <span className={layoutStyles.badge}>{item.ville}</span>
                  <h3>{item.titre}</h3>
                  <p className={layoutStyles.periode}>{item.periode}</p>
                  <p>{item.resume}</p>
                </div>
              </article>
            ))}
          </div>
        </section>
      </article>
    </>
  );
}

export default Archives;