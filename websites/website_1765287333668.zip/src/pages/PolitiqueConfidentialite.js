import MetaTags from "../components/MetaTags";
import layoutStyles from "../styles/PageLayout.module.css";

function PolitiqueConfidentialite() {
  return (
    <>
      <MetaTags
        title="Politique de Confidentialité"
        description="Politique de protection des données personnelles d'Historic Streets of France Review."
        url="https://www.historicstreets-fr-review.org/politique-de-confidentialite"
      />
      <article className={layoutStyles.page}>
        <header className={layoutStyles.entete}>
          <h1>Politique de confidentialité</h1>
        </header>

        <section className={layoutStyles.section}>
          <h2>Collecte des données</h2>
          <p>
            Les données personnelles collectées via le formulaire de contact et le
            bulletin de recherche sont limitées aux informations strictement nécessaires
            à la gestion des échanges éditoriaux.
          </p>
        </section>

        <section className={layoutStyles.section}>
          <h2>Utilisation</h2>
          <p>
            Les données servent exclusivement à répondre aux sollicitations et à informer
            les lecteurs des nouvelles publications. Aucune transmission à des tiers n'est
            effectuée sans consentement explicite.
          </p>
        </section>

        <section className={layoutStyles.section}>
          <h2>Conservation</h2>
          <p>
            Les informations sont conservées pendant une durée maximale de trois ans
            après le dernier contact, puis supprimées ou archivées conformément aux
            obligations légales.
          </p>
        </section>

        <section className={layoutStyles.section}>
          <h2>Droits des personnes</h2>
          <p>
            Toute personne dispose d'un droit d'accès, de rectification et de suppression
            des données la concernant. La demande peut être adressée à
            redaction@historicstreets-fr-review.org.
          </p>
        </section>
      </article>
    </>
  );
}

export default PolitiqueConfidentialite;