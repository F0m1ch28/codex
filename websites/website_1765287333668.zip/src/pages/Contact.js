import { useState } from "react";
import MetaTags from "../components/MetaTags";
import layoutStyles from "../styles/PageLayout.module.css";

function Contact() {
  const [formData, setFormData] = useState({
    nom: "",
    email: "",
    sujet: "",
    message: "",
  });
  const [erreurs, setErreurs] = useState({});
  const [confirmation, setConfirmation] = useState(false);

  const valider = () => {
    const nouvellesErreurs = {};
    if (!formData.nom.trim()) nouvellesErreurs.nom = "Merci de préciser un nom.";
    if (!formData.email.includes("@"))
      nouvellesErreurs.email = "Merci de fournir une adresse électronique valide.";
    if (!formData.sujet.trim())
      nouvellesErreurs.sujet = "Merci de définir l'objet du message.";
    if (formData.message.trim().length < 20)
      nouvellesErreurs.message = "Le message doit comporter au moins vingt caractères.";
    return nouvellesErreurs;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validation = valider();
    if (Object.keys(validation).length > 0) {
      setErreurs(validation);
      setConfirmation(false);
      return;
    }
    setErreurs({});
    setConfirmation(true);
    setFormData({ nom: "", email: "", sujet: "", message: "" });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <>
      <MetaTags
        title="Contact"
        description="Coordonnées éditoriales d'Historic Streets of France Review."
        url="https://www.historicstreets-fr-review.org/contact"
      />
      <article className={layoutStyles.page}>
        <header className={layoutStyles.entete}>
          <p className={layoutStyles.surtitre}>Coordonnées</p>
          <h1>Contact</h1>
          <p className={layoutStyles.intro}>
            Les interlocuteurs institutionnels et chercheurs peuvent adresser leurs
            messages via le formulaire suivant ou par courrier électronique.
          </p>
        </header>

        <section className={layoutStyles.section}>
          <div className={layoutStyles.contactInfos}>
            <div>
              <h2>Rédaction</h2>
              <p>
                Email&nbsp;:{" "}
                <a href="mailto:redaction@historicstreets-fr-review.org">
                  redaction@historicstreets-fr-review.org
                </a>
              </p>
              <p>
                Adresse postale&nbsp;: Historic Streets of France Review, BP 123, 75006
                Paris, France
              </p>
            </div>
            <div>
              <h2>Formulaire de contact</h2>
              <form className={layoutStyles.formulaireContact} onSubmit={handleSubmit}>
                <label htmlFor="nom">Nom et affiliation</label>
                <input
                  id="nom"
                  name="nom"
                  type="text"
                  value={formData.nom}
                  onChange={handleChange}
                  placeholder="Nom complet"
                  required
                />
                {erreurs.nom && <p className={layoutStyles.erreur}>{erreurs.nom}</p>}

                <label htmlFor="email">Adresse électronique</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="exemple@organisation.fr"
                  required
                />
                {erreurs.email && <p className={layoutStyles.erreur}>{erreurs.email}</p>}

                <label htmlFor="sujet">Objet</label>
                <input
                  id="sujet"
                  name="sujet"
                  type="text"
                  value={formData.sujet}
                  onChange={handleChange}
                  placeholder="Objet du message"
                  required
                />
                {erreurs.sujet && <p className={layoutStyles.erreur}>{erreurs.sujet}</p>}

                <label htmlFor="message">Message</label>
                <textarea
                  id="message"
                  name="message"
                  rows="6"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Message détaillé"
                  required
                />
                {erreurs.message && (
                  <p className={layoutStyles.erreur}>{erreurs.message}</p>
                )}

                <button type="submit">Soumettre</button>
                {confirmation && (
                  <p className={layoutStyles.confirmation}>
                    Le message a été enregistré. La rédaction répondra par voie
                    électronique dans les meilleurs délais éditoriaux.
                  </p>
                )}
              </form>
            </div>
          </div>
        </section>
      </article>
    </>
  );
}

export default Contact;