import { useState } from "react";
import { Link } from "react-router-dom";
import MetaTags from "../components/MetaTags";
import styles from "./Home.module.css";

const etudes = [
  {
    id: 1,
    titre: "Perspectives haussmanniennes sur la rive droite",
    categorie: "Morphologie urbaine",
    date: "12 mars 2024",
    extrait:
      "Une lecture croisée des plans cadastraux et des récits journalistiques pour comprendre la formation des perspectives parisiennes.",
    image: "https://picsum.photos/600/420?random=101",
  },
  {
    id: 2,
    titre: "Chroniques de la rue Saint-Rome à Toulouse",
    categorie: "Commerce et sociabilité",
    date: "4 mars 2024",
    extrait:
      "Étude des archives notariales pour suivre l'évolution des métiers et des pratiques sociales dans l'artère médiévale toulousaine.",
    image: "https://picsum.photos/600/420?random=102",
  },
  {
    id: 3,
    titre: "Les quais de Saône et leur mémoire fluviale",
    categorie: "Paysage et mobilité",
    date: "26 février 2024",
    extrait:
      "Analyse des transformations des quais lyonnais à travers les registres portuaires et la photographie documentaire.",
    image: "https://picsum.photos/600/420?random=103",
  },
  {
    id: 4,
    titre: "Rues-jardins de Strasbourg : héritages et usages",
    categorie: "Écologie urbaine",
    date: "19 février 2024",
    extrait:
      "Comparaison des dispositifs végétalisés expérimentés dans les quartiers strasbourgeois depuis l'entre-deux-guerres.",
    image: "https://picsum.photos/600/420?random=104",
  },
];

const principes = [
  {
    titre: "Neutralité analytique",
    description:
      "Chaque dossier s'appuie sur une lecture critique des sources pour restituer les dynamiques urbaines sans parti pris.",
    icone: "📊",
  },
  {
    titre: "Rigueur documentaire",
    description:
      "Les archives municipales, cartes anciennes et relevés iconographiques sont systématiquement contextualisés et cités.",
    icone: "🗂️",
  },
  {
    titre: "Perspective culturelle",
    description:
      "Les interprétations associent histoire, géographie et anthropologie afin de restituer la dimension sensible des rues.",
    icone: "🧭",
  },
];

const indicateurs = [
  { chiffre: "124", label: "Études documentées" },
  { chiffre: "37", label: "Villes parcourues" },
  { chiffre: "1860-2024", label: "Chronologie couverte" },
];

function Home() {
  const [email, setEmail] = useState("");
  const [confirme, setConfirme] = useState(false);
  const [erreur, setErreur] = useState("");

  const gestionSoumission = (e) => {
    e.preventDefault();
    if (!email.trim() || !email.includes("@")) {
      setErreur("Veuillez indiquer une adresse électronique valide.");
      setConfirme(false);
      return;
    }
    setErreur("");
    setConfirme(true);
    setEmail("");
  };

  return (
    <>
      <MetaTags
        title="Accueil"
        description="Historic Streets of France Review explore l'âme des villes françaises à travers l'étude de leurs rues et de leurs archives."
        url="https://www.historicstreets-fr-review.org/"
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.surtitre}>Revue digitale d'histoire urbaine</p>
          <h1>Historic Streets of France Review</h1>
          <p className={styles.accroche}>
            Explorer l'âme des villes à travers leurs rues.
          </p>
          <p className={styles.description}>
            La revue analyse les transformations urbaines françaises en combinant
            sources archivistiques, investigations de terrain et regards
            interdisciplinaires.
          </p>
          <div className={styles.indicateurs}>
            {indicateurs.map((item) => (
              <div key={item.label} className={styles.indicateur}>
                <span className={styles.chiffre}>{item.chiffre}</span>
                <span className={styles.libelle}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.etudesSection}>
        <div className={styles.sectionEntete}>
          <h2>Dernières études</h2>
          <p>
            La sélection suivante rassemble les analyses les plus récentes publiées
            par la rédaction, chacune accompagnée de sa bibliographie contextualisée.
          </p>
        </div>
        <div className={styles.etudesGrille}>
          {etudes.map((etude) => (
            <article key={etude.id} className={styles.etudeCarte}>
              <div className={styles.imageWrap}>
                <img src={etude.image} alt={`Illustration de ${etude.titre}`} loading="lazy" />
              </div>
              <div className={styles.etudeContenu}>
                <span className={styles.categorie}>{etude.categorie}</span>
                <h3>{etude.titre}</h3>
                <p className={styles.date}>{etude.date}</p>
                <p className={styles.extrait}>{etude.extrait}</p>
                <Link className={styles.lienEtude} to="/archives">
                  Lire l'étude
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.themeUne}>
        <div className={styles.themeTexte}>
          <h2>Thème à la une</h2>
          <h3>Les traces médiévales à Lyon</h3>
          <p>
            Le dossier consacré aux ruelles médiévales lyonnaises retrace les
            persistances de trames anciennes dans le tissu contemporain à partir des
            terriers capitulaires, des relevés laser et des parcours in situ. La
            confrontation des sources permet de relire la continuité des usages et
            des sociabilités dans le Vieux-Lyon.
          </p>
          <Link to="/thematiques" className={styles.lienTheme}>
            Consulter l'ensemble des thématiques
          </Link>
        </div>
        <div className={styles.themeImage}>
          <img
            src="https://picsum.photos/640/540?random=110"
            alt="Ruelle médiévale à Lyon"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.principes}>
        <h2>Nos principes</h2>
        <div className={styles.principesGrille}>
          {principes.map((principe) => (
            <article key={principe.titre} className={styles.principeCarte}>
              <span className={styles.principeIcone} aria-hidden="true">
                {principe.icone}
              </span>
              <h3>{principe.titre}</h3>
              <p>{principe.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.citationSection}>
        <div className={styles.citationBloc}>
          <h2>Parole d'expert</h2>
          <blockquote>
            « Les rues françaises fonctionnent comme des palimpsestes où se lisent
            simultanément infrastructures, pratiques sociales et imaginaires. Historic
            Streets of France Review restitue ces strates avec une précision
            historique remarquable. »
          </blockquote>
          <p className={styles.citationAuteur}>
            Dr Madeleine Vannier, historienne de la ville, Université Lumière Lyon 2
          </p>
        </div>
      </section>

      <section className={styles.bulletinSection} aria-labelledby="bulletin-titre">
        <div className={styles.bulletinBloc}>
          <h2 id="bulletin-titre">Bulletin de recherche</h2>
          <p>
            Les lecteurs peuvent renseigner leur adresse électronique pour être informés
            des nouvelles études et des mises à jour méthodologiques.
          </p>
          <form className={styles.formulaire} onSubmit={gestionSoumission}>
            <label htmlFor="email-bulletin" className={styles.label}>
              Adresse électronique
            </label>
            <input
              id="email-bulletin"
              type="email"
              name="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="exemple@domain.fr"
              required
            />
            <button type="submit">Valider</button>
            {erreur && <p className={styles.erreur}>{erreur}</p>}
            {confirme && (
              <p className={styles.confirmation}>
                La demande a été enregistrée. La rédaction communiquera les prochaines
                publications par voie électronique.
              </p>
            )}
          </form>
        </div>
      </section>
    </>
  );
}

export default Home;