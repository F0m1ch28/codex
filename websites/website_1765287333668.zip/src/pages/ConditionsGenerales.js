import MetaTags from "../components/MetaTags";
import layoutStyles from "../styles/PageLayout.module.css";

function ConditionsGenerales() {
  return (
    <>
      <MetaTags
        title="Conditions Générales"
        description="Conditions générales d'utilisation du site Historic Streets of France Review."
        url="https://www.historicstreets-fr-review.org/conditions-generales"
      />
      <article className={layoutStyles.page}>
        <header className={layoutStyles.entete}>
          <h1>Conditions générales d'utilisation</h1>
        </header>

        <section className={layoutStyles.section}>
          <h2>Objet</h2>
          <p>
            Les présentes conditions définissent les modalités d'utilisation du site
            Historic Streets of France Review et des contenus mis à disposition des
            lecteurs.
          </p>
        </section>

        <section className={layoutStyles.section}>
          <h2>Accès au site</h2>
          <p>
            L'accès au site est libre. L'utilisateur s'engage à respecter les règles
            légales en vigueur ainsi que les droits de propriété intellectuelle
            attachés aux contenus proposés.
          </p>
        </section>

        <section className={layoutStyles.section}>
          <h2>Propriété intellectuelle</h2>
          <p>
            Les textes, images et éléments graphiques publiés sont protégés par le droit
            d'auteur. Toute reproduction est soumise à autorisation écrite de la
            rédaction ou des ayants droit.
          </p>
        </section>

        <section className={layoutStyles.section}>
          <h2>Responsabilité</h2>
          <p>
            Historic Streets of France Review s'efforce de fournir des informations
            exactes et actualisées. Toutefois, la revue ne peut garantir l'absence totale
            d'erreurs matérielles et invite le lecteur à signaler toute correction
            utile.
          </p>
        </section>

        <section className={layoutStyles.section}>
          <h2>Droit applicable</h2>
          <p>
            Les présentes conditions sont régies par le droit français. Tout litige
            relève de la compétence des juridictions françaises.
          </p>
        </section>
      </article>
    </>
  );
}

export default ConditionsGenerales;