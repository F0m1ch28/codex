import MetaTags from "../components/MetaTags";
import layoutStyles from "../styles/PageLayout.module.css";

function Ressources() {
  return (
    <>
      <MetaTags
        title="Ressources"
        description="Ressources documentaires sélectionnées par Historic Streets of France Review."
        url="https://www.historicstreets-fr-review.org/ressources"
      />
      <article className={layoutStyles.page}>
        <header className={layoutStyles.entete}>
          <p className={layoutStyles.surtitre}>Références</p>
          <h1>Ressources</h1>
          <p className={layoutStyles.intro}>
            Cette sélection offre des ressources externes pour approfondir les recherches
            urbaines menées par la revue.
          </p>
        </header>

        <section className={layoutStyles.section}>
          <h2>Bibliothèques et archives</h2>
          <ul className={layoutStyles.listeLien}>
            <li>
              Bibliothèque historique de la Ville de Paris – fonds iconographiques et
              cartes anciennes.
            </li>
            <li>
              Archives nationales – séries relatives aux travaux publics et aux plans
              cadastraux.
            </li>
            <li>
              Archives départementales du Rhône – dossiers de voirie et procès-verbaux
              municipaux.
            </li>
          </ul>
        </section>

        <section className={layoutStyles.section}>
          <h2>Corpus numériques</h2>
          <ul className={layoutStyles.listeLien}>
            <li>
              Gallica, Bibliothèque nationale de France – base cartographique et presse
              locale numérisée.
            </li>
            <li>
              Plateforme GeoHistoricalData – visualisation comparative de plans anciens.
            </li>
            <li>
              Base POP, Ministère de la Culture – notices patrimoniales relatives aux
              rues et édifices.
            </li>
          </ul>
        </section>

        <section className={layoutStyles.section}>
          <h2>Guides méthodologiques</h2>
          <ul className={layoutStyles.listeLien}>
            <li>
              Méthodes d'analyse morphologique urbaine, Presses universitaires de Rennes.
            </li>
            <li>
              Manuel d'histoire des sensibilités urbaines, Éditions de l'EHESS.
            </li>
            <li>
              Atelier de cartographie sensible, guide pratique coordonné par le CRESSON.
            </li>
          </ul>
        </section>
      </article>
    </>
  );
}

export default Ressources;