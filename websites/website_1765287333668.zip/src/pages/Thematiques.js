import { useMemo, useState } from "react";
import MetaTags from "../components/MetaTags";
import layoutStyles from "../styles/PageLayout.module.css";

const thematiquesDonnees = [
  {
    titre: "Architecture haussmannienne",
    categorie: "Architecture",
    resume:
      "Dossiers consacrés aux percées parisiennes, aux façades alignées et aux transformations de l'espace public.",
    image: "https://picsum.photos/540/360?random=401",
  },
  {
    titre: "Mémoire ouvrière",
    categorie: "Société",
    resume:
      "Études sur les rues industrielles, les ateliers collectifs et les sociabilités professionnelles.",
    image: "https://picsum.photos/540/360?random=402",
  },
  {
    titre: "Espaces portuaires",
    categorie: "Mobilités",
    resume:
      "Analyses des quais, entrepôts et infrastructures maritimes structurant les villes côtières.",
    image: "https://picsum.photos/540/360?random=403",
  },
  {
    titre: "Villes-jardins",
    categorie: "Paysages",
    resume:
      "Recherches sur les expérimentations paysagères, les coulées vertes et les rues plantées.",
    image: "https://picsum.photos/540/360?random=404",
  },
  {
    titre: "Traces médiévales",
    categorie: "Patrimoine",
    resume:
      "Investigations sur la résilience des trames anciennes et leur articulation aux plans modernes.",
    image: "https://picsum.photos/540/360?random=405",
  },
  {
    titre: "Cartographie sensible",
    categorie: "Approches",
    resume:
      "Programmes dédiés à la représentation sensorielle des rues par le son, la lumière ou l'olfaction.",
    image: "https://picsum.photos/540/360?random=406",
  },
];

const categories = ["Toutes", "Architecture", "Société", "Mobilités", "Paysages", "Patrimoine", "Approches"];

function Thematiques() {
  const [categorieActive, setCategorieActive] = useState("Toutes");

  const thematiquesFiltrees = useMemo(() => {
    if (categorieActive === "Toutes") {
      return thematiquesDonnees;
    }
    return thematiquesDonnees.filter((theme) => theme.categorie === categorieActive);
  }, [categorieActive]);

  return (
    <>
      <MetaTags
        title="Thématiques"
        description="Panorama des thématiques abordées par Historic Streets of France Review."
        url="https://www.historicstreets-fr-review.org/thematiques"
      />
      <article className={layoutStyles.page}>
        <header className={layoutStyles.entete}>
          <p className={layoutStyles.surtitre}>Cartographie des sujets</p>
          <h1>Thématiques de recherche</h1>
          <p className={layoutStyles.intro}>
            Les thématiques présentées illustrent la diversité des approches
            mobilisées pour comprendre les rues françaises.
          </p>
        </header>

        <section className={layoutStyles.section}>
          <div className={layoutStyles.filtres}>
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                className={`${layoutStyles.filtreBouton} ${
                  categorieActive === cat ? layoutStyles.filtreActif : ""
                }`}
                onClick={() => setCategorieActive(cat)}
              >
                {cat}
              </button>
            ))}
          </div>
          <div className={layoutStyles.grilleThematiques}>
            {thematiquesFiltrees.map((theme) => (
              <article key={theme.titre} className={layoutStyles.thematiqueCarte}>
                <img src={theme.image} alt={theme.titre} loading="lazy" />
                <div>
                  <span className={layoutStyles.badge}>{theme.categorie}</span>
                  <h3>{theme.titre}</h3>
                  <p>{theme.resume}</p>
                </div>
              </article>
            ))}
          </div>
        </section>
      </article>
    </>
  );
}

export default Thematiques;