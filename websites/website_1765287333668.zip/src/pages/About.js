import MetaTags from "../components/MetaTags";
import layoutStyles from "../styles/PageLayout.module.css";

const equipe = [
  {
    nom: "Clémence Roche",
    role: "Historienne des villes",
    image: "https://picsum.photos/400/400?random=201",
    bio: "Spécialiste des recompositions urbaines parisiennes du XIXe siècle, elle coordonne l'analyse des corpus cartographiques.",
  },
  {
    nom: "Yassine Benati",
    role: "Géographe urbain",
    image: "https://picsum.photos/400/400?random=202",
    bio: "Il structure les enquêtes de terrain et les relevés morphologiques sur les métropoles du Sud-Ouest.",
  },
  {
    nom: "Aurélie Chassaing",
    role: "Archiviste-paléographe",
    image: "https://picsum.photos/400/400?random=203",
    bio: "Elle assure le dépouillement des fonds municipaux et la validation matérielle des sources primaires.",
  },
];

function About() {
  return (
    <>
      <MetaTags
        title="À Propos"
        description="Présentation éditoriale d'Historic Streets of France Review, revue dédiée à l'étude des rues françaises."
        url="https://www.historicstreets-fr-review.org/a-propos"
      />
      <article className={layoutStyles.page}>
        <header className={layoutStyles.entete}>
          <p className={layoutStyles.surtitre}>Présentation éditoriale</p>
          <h1>À propos de la revue</h1>
          <p className={layoutStyles.intro}>
            Historic Streets of France Review documente les histoires urbaines
            françaises grâce à une approche transdisciplinaire mobilisant archives,
            analyses spatiales et enquêtes sensibles.
          </p>
        </header>

        <section className={layoutStyles.section}>
          <h2>Mission éditoriale</h2>
          <p>
            La revue vise à rendre intelligible la mémoire des rues par des dossiers
            analytiques, des cartes commentées et des synthèses bibliographiques
            systématisées. Chaque publication met en scène les dynamiques sociales,
            économiques et culturelles issues des sources locales.
          </p>
        </section>

        <section className={layoutStyles.section}>
          <h2>Approche transdisciplinaire</h2>
          <ul className={layoutStyles.listePuces}>
            <li>
              Confronter la morphologie urbaine et les récits d'habitants pour révéler
              les usages quotidiens.
            </li>
            <li>
              Articuler archives visuelles, statistiques et littéraires à l'échelle de la
              rue.
            </li>
            <li>
              Documenter les transformations contemporaines en dialogue avec les
              héritages patrimoniaux.
            </li>
          </ul>
        </section>

        <section className={layoutStyles.section}>
          <h2>Équipe éditoriale</h2>
          <div className={layoutStyles.grilleEquipe}>
            {equipe.map((membre) => (
              <figure key={membre.nom} className={layoutStyles.carteEquipe}>
                <img src={membre.image} alt={`${membre.nom}, ${membre.role}`} loading="lazy" />
                <figcaption>
                  <h3>{membre.nom}</h3>
                  <p className={layoutStyles.role}>{membre.role}</p>
                  <p>{membre.bio}</p>
                </figcaption>
              </figure>
            ))}
          </div>
        </section>

        <section className={layoutStyles.section}>
          <h2>Chronologie du projet</h2>
          <div className={layoutStyles.timeline}>
            <div>
              <h3>2018</h3>
              <p>Lancement du programme de recherche sur les rues françaises.</p>
            </div>
            <div>
              <h3>2020</h3>
              <p>
                Constitution de la base documentaire partagée avec les partenaires
                archivistiques.
              </p>
            </div>
            <div>
              <h3>2022</h3>
              <p>Ouverture de la plateforme numérique et premières publications.</p>
            </div>
            <div>
              <h3>2024</h3>
              <p>
                Développement de dossiers thématiques et renforcement de la cartographie
                interactive.
              </p>
            </div>
          </div>
        </section>
      </article>
    </>
  );
}

export default About;