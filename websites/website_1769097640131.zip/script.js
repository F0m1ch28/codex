document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');
  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = siteNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });
    siteNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        siteNav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const storedChoice = localStorage.getItem('efg_cookie_choice');
    if (!storedChoice) {
      cookieBanner.classList.add('active');
    }
    cookieBanner.addEventListener('click', (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.dataset.cookieConsent === 'accept') {
        localStorage.setItem('efg_cookie_choice', 'accepted');
        hideCookieBanner();
      }
      if (target.dataset.cookieConsent === 'decline') {
        localStorage.setItem('efg_cookie_choice', 'declined');
        hideCookieBanner();
      }
    });
    function hideCookieBanner() {
      cookieBanner.classList.remove('active');
    }
  }

  const currentYearEl = document.getElementById('current-year');
  if (currentYearEl) {
    currentYearEl.textContent = String(new Date().getFullYear());
  }

  const toast = document.getElementById('toast');
  const forms = document.querySelectorAll('form');
  forms.forEach(form => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      showToast('Your message is on its way. Thank you.');
      const action = form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        window.location.href = action;
      }, 1200);
    });
  });

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('visible');
    setTimeout(() => {
      toast.classList.remove('visible');
    }, 3000);
  }
});