document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.main-nav');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-btn');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            navMenu.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', navMenu.classList.contains('open'));
        });

        document.addEventListener('click', function (event) {
            if (!navMenu.contains(event.target) && !navToggle.contains(event.target)) {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    if (cookieBanner) {
        const existingConsent = localStorage.getItem('accultlraiConsent');
        if (!existingConsent) {
            cookieBanner.classList.add('active');
        }

        cookieButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                const decision = button.getAttribute('data-consent');
                const link = button.getAttribute('data-link');
                localStorage.setItem('accultlraiConsent', decision);
                cookieBanner.classList.remove('active');
                if (link) {
                    window.open(link, '_blank', 'noopener');
                }
            });
        });
    }
});