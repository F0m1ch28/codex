document.addEventListener('DOMContentLoaded', () => {
    if ('scrollRestoration' in history) {
        history.scrollRestoration = 'manual';
    }

    const navToggle = document.querySelector('.mobile-nav-toggle');
    const nav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.site-nav .nav-link');
    const scrollLinks = document.querySelectorAll('[data-scroll="true"]');
    const headerCTA = document.querySelector('.header-cta');

    if (navToggle && nav) {
        const toggleNav = () => {
            const isOpen = nav.classList.toggle('nav-open');
            navToggle.classList.toggle('nav-open', isOpen);
            navToggle.setAttribute('aria-expanded', String(isOpen));
        };
        navToggle.addEventListener('click', toggleNav);
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                nav.classList.remove('nav-open');
                navToggle.classList.remove('nav-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    scrollLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            const targetId = link.getAttribute('href')?.replace('#', '');
            const targetSection = targetId ? document.getElementById(targetId) : null;
            if (targetSection) {
                event.preventDefault();
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    if (headerCTA) {
        headerCTA.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const scrollTopButton = document.getElementById('scrollTop');
    if (scrollTopButton) {
        const toggleScrollButton = () => {
            if (window.scrollY > 260) {
                scrollTopButton.classList.add('visible');
            } else {
                scrollTopButton.classList.remove('visible');
            }
        };
        window.addEventListener('scroll', toggleScrollButton);
        toggleScrollButton();

        scrollTopButton.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookiesButton = document.getElementById('acceptCookies');
    if (cookieBanner && acceptCookiesButton) {
        const COOKIE_KEY = 'digitalstepCookiesAccepted';
        if (!localStorage.getItem(COOKIE_KEY)) {
            cookieBanner.classList.add('show');
        }
        acceptCookiesButton.addEventListener('click', () => {
            localStorage.setItem(COOKIE_KEY, 'true');
            cookieBanner.classList.remove('show');
        });
    }

    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        const responseEl = contactForm.querySelector('.form-response');
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const hasEmptyRequired = Array.from(formData.entries()).some(([name, value]) => {
                const field = contactForm.querySelector(`[name="${name}"]`);
                return field && field.hasAttribute('required') && !value.trim();
            });
            if (hasEmptyRequired) {
                if (responseEl) {
                    responseEl.textContent = 'Өтінішті толығырақ жазып көріңіз.';
                    responseEl.style.color = '#d64545';
                }
                return;
            }
            contactForm.reset();
            if (responseEl) {
                responseEl.textContent = 'Рақмет! Сіздің өтінішіңіз қабылданды, біз жақын арада хабарласамыз.';
                responseEl.style.color = '#00A896';
            }
        });
    }
});