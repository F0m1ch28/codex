```javascript
(function () {
  const COOKIE_KEY = 'npm_cookie_pref';

  const banner = document.querySelector('[data-cookie-banner]');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');

  const showBanner = () => {
    if (!banner) return;
    banner.classList.add('cookie-banner--visible');
  };

  const hideBanner = () => {
    if (!banner) return;
    banner.classList.remove('cookie-banner--visible');
  };

  if (banner && !localStorage.getItem(COOKIE_KEY)) {
    window.setTimeout(showBanner, 600);
  }

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => {
      localStorage.setItem(COOKIE_KEY, 'accepted');
      hideBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => {
      localStorage.setItem(COOKIE_KEY, 'declined');
      hideBanner();
    });
  }

  const form = document.querySelector('[data-contact-form]');
  const feedback = document.querySelector('[data-form-feedback]');
  if (form) {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const name = form.querySelector('input[name="name"]');
      const email = form.querySelector('input[name="email"]');
      const message = form.querySelector('textarea[name="message"]');

      let valid = true;
      [name, email, message].forEach((field) => {
        if (!field.value.trim()) {
          field.setAttribute('aria-invalid', 'true');
          valid = false;
        } else {
          field.removeAttribute('aria-invalid');
        }
      });

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (email.value && !emailPattern.test(email.value)) {
        email.setAttribute('aria-invalid', 'true');
        valid = false;
      }

      if (!valid) {
        if (feedback) {
          feedback.textContent = 'Please complete all fields with valid information before sending your message.';
          feedback.setAttribute('role', 'alert');
        }
        return;
      }

      if (feedback) {
        feedback.removeAttribute('role');
        feedback.textContent = '';
      }
      window.location.href = form.getAttribute('data-success-url');
    });
  }

  const searchInput = document.querySelector('[data-search]');
  const filterButtons = document.querySelectorAll('[data-filter]');
  const articles = document.querySelectorAll('[data-article]');

  const applyFilters = () => {
    if (!articles.length) return;
    const query = (searchInput ? searchInput.value : '').toLowerCase();
    const activeFilter = [...filterButtons].find((btn) => btn.getAttribute('aria-pressed') === 'true');
    const activeCategory = activeFilter ? activeFilter.dataset.filter : 'all';

    articles.forEach((article) => {
      const title = article.querySelector('[data-article-title]').textContent.toLowerCase();
      const description = (article.querySelector('[data-article-desc]') || { textContent: '' }).textContent.toLowerCase();
      const categories = article.dataset.categories ? article.dataset.categories.toLowerCase().split(',') : [];

      const matchesQuery = !query || title.includes(query) || description.includes(query);
      const matchesCategory = activeCategory === 'all' || categories.includes(activeCategory);

      if (matchesQuery && matchesCategory) {
        article.removeAttribute('hidden');
      } else {
        article.setAttribute('hidden', 'true');
      }
    });
  };

  if (searchInput) {
    searchInput.addEventListener('input', applyFilters);
  }

  if (filterButtons.length) {
    filterButtons.forEach((button) => {
      button.addEventListener('click', () => {
        filterButtons.forEach((btn) => btn.setAttribute('aria-pressed', 'false'));
        button.setAttribute('aria-pressed', 'true');
        applyFilters();
      });
    });
  }

  applyFilters();
})();
```