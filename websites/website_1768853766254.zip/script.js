document.addEventListener('DOMContentLoaded', function () {
  var navToggle = document.querySelector('.nav-toggle');
  var siteNav = document.querySelector('.site-nav');
  var cookieBanner = document.querySelector('.cookie-banner');
  var cookieButtons = document.querySelectorAll('[data-cookie-consent]');
  var yearElement = document.getElementById('current-year');
  var consentKey = 'marketInsightsPhCookieConsent';

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', function () {
      var isOpen = siteNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }

  function showCookieBanner() {
    if (cookieBanner && !localStorage.getItem(consentKey)) {
      cookieBanner.classList.add('visible');
    }
  }

  function handleConsent(value) {
    localStorage.setItem(consentKey, value);
    if (cookieBanner) {
      cookieBanner.classList.remove('visible');
    }
  }

  if (cookieButtons.length > 0) {
    cookieButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        var value = this.dataset.cookieConsent === 'accept' ? 'accepted' : 'declined';
        handleConsent(value);
      });
    });
  }

  showCookieBanner();
});