document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  const toggleNav = () => {
    if (!navToggle || !siteNav) return;
    const expanded = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', (!expanded).toString());
    navToggle.setAttribute('aria-label', expanded ? 'Открыть меню' : 'Закрыть меню');
    siteNav.classList.toggle('is-open');
    document.body.classList.toggle('nav-open');
  };

  navToggle?.addEventListener('click', toggleNav);

  siteNav?.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      if (siteNav.classList.contains('is-open')) {
        toggleNav();
      }
    });
  });

  const banner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');
  const storageKey = 'website-cookie-choice';

  const savedChoice = localStorage.getItem(storageKey);
  if (!savedChoice && banner) {
    requestAnimationFrame(() => banner.classList.add('show'));
  } else if (savedChoice && banner) {
    banner.remove();
  }

  const handleCookieChoice = value => {
    localStorage.setItem(storageKey, value);
    if (banner) {
      banner.classList.remove('show');
      setTimeout(() => banner.remove(), 320);
    }
  };

  acceptBtn?.addEventListener('click', () => handleCookieChoice('accepted'));
  declineBtn?.addEventListener('click', () => handleCookieChoice('declined'));

  const contactForm = document.querySelector('#contact-form');
  contactForm?.addEventListener('submit', event => {
    event.preventDefault();
    const form = event.target;
    const requiredFields = Array.from(form.querySelectorAll('[required]'));
    const errors = [];

    form.querySelectorAll('.field-error').forEach(el => el.remove());

    requiredFields.forEach(field => {
      const value = field.type === 'checkbox' ? field.checked : field.value.trim();
      let isValid = Boolean(value);

      if (isValid && field.type === 'email') {
        isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value);
      }

      if (!isValid) {
        const error = document.createElement('span');
        error.className = 'field-error';
        error.textContent = field.dataset.errorMessage || 'Заполните поле';
        field.parentElement.appendChild(error);
        errors.push(field);
      }
    });

    if (errors.length === 0) {
      const successMessage = form.querySelector('.form-success');
      if (successMessage) {
        successMessage.textContent = 'Спасибо! Мы свяжемся с вами в ближайшее время.';
        successMessage.classList.add('visible');
      }
      form.reset();
    }
  });
});