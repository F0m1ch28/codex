document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.primary-nav');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      nav.classList.toggle('is-open');
    });
  }
  const submenuItems = document.querySelectorAll('.nav-item.has-submenu');
  submenuItems.forEach(item => {
    const link = item.querySelector('a');
    if (!link) return;
    link.addEventListener('click', (event) => {
      if (window.innerWidth < 768) {
        event.preventDefault();
        const expanded = item.getAttribute('aria-expanded') === 'true';
        item.setAttribute('aria-expanded', String(!expanded));
      }
    });
  });

  const observerElements = document.querySelectorAll('.fade-in');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    observerElements.forEach(el => observer.observe(el));
  } else {
    observerElements.forEach(el => el.classList.add('is-visible'));
  }

  const counters = document.querySelectorAll('[data-counter]');
  if (counters.length) {
    counters.forEach(counter => {
      const target = Number(counter.dataset.counter || 0);
      let current = 0;
      const increment = target / 120;
      const update = () => {
        current += increment;
        if (current >= target) {
          counter.textContent = target.toLocaleString('es-ES');
        } else {
          counter.textContent = Math.round(current).toLocaleString('es-ES');
          requestAnimationFrame(update);
        }
      };
      update();
    });
  }

  const mapButtons = document.querySelectorAll('[data-region-btn]');
  const mapTitle = document.querySelector('[data-region-title]');
  const mapSummary = document.querySelector('[data-region-summary]');
  const regionDataset = {
    madrid: {
      title: 'Madrid',
      text: 'Madrid consolida laboratorios vivos de redes inteligentes con participación conjunta de hospitales y operadores eléctricos, integrando predicción de demanda clínica y almacenamiento distribuido.'
    },
    castillaleon: {
      title: 'Castilla y León',
      text: 'Castilla y León despliega telemedicina asistida por inteligencia artificial en entornos rurales, conectando centros de salud comarcales con nodos de análisis en Valladolid y Salamanca.'
    },
    aragon: {
      title: 'Aragón',
      text: 'Aragón coordina polígonos industriales con hospitales comarcales mediante contratos energéticos basados en datos que priorizan consumo crítico para terapias sensibles.'
    },
    murcia: {
      title: 'Murcia',
      text: 'Murcia avanza en diagnóstico avanzado con plataformas que combinan imágenes médicas y algoritmos energéticamente eficientes en la red sanitaria regional.'
    },
    cantabria: {
      title: 'Cantabria',
      text: 'Cantabria aplica principios de economía circular a sus instalaciones sanitarias, valorizando residuos energéticos y térmicos en colaboración con el sector marino.'
    }
  };
  if (mapButtons.length && mapTitle && mapSummary) {
    mapButtons.forEach(button => {
      button.addEventListener('click', () => {
        mapButtons.forEach(btn => btn.classList.remove('is-active'));
        button.classList.add('is-active');
        const key = button.dataset.regionBtn;
        const details = regionDataset[key];
        if (details) {
          mapTitle.textContent = details.title;
          mapSummary.textContent = details.text;
        }
      });
    });
    const first = mapButtons[0];
    if (first) first.click();
  }

  function renderBarChart(container, dataset) {
    if (!container) return;
    container.innerHTML = '';
    if (!Array.isArray(dataset) || !dataset.length) return;
    const maxValue = Math.max(...dataset.map(item => item.value));
    dataset.forEach(item => {
      const bar = document.createElement('div');
      bar.className = 'chart-bar';
      bar.style.height = `${Math.max(8, (item.value / maxValue) * 100)}%`;
      const label = document.createElement('span');
      label.textContent = `${item.label} · ${item.value}${item.unit || ''}`;
      bar.appendChild(label);
      container.appendChild(bar);
    });
  }

  function renderLineChart(container, dataset) {
    if (!container) return;
    if (!Array.isArray(dataset) || dataset.length < 2) return;
    const svgNS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('viewBox', '0 0 100 100');
    const maxValue = Math.max(...dataset.map(item => item.value));
    const points = dataset.map((item, index) => {
      const x = (index / (dataset.length - 1)) * 100;
      const y = 100 - (item.value / maxValue) * 100;
      return `${x},${y}`;
    }).join(' ');
    const path = document.createElementNS(svgNS, 'polyline');
    path.setAttribute('points', points);
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', 'rgba(255,255,255,0.8)');
    path.setAttribute('stroke-width', '3');
    path.setAttribute('stroke-linejoin', 'round');
    path.setAttribute('stroke-linecap', 'round');
    svg.appendChild(path);
    container.innerHTML = '';
    container.appendChild(svg);
  }

  const chartAreas = document.querySelectorAll('[data-visualization="bars"]');
  chartAreas.forEach(area => {
    const defaultData = area.dataset.default ? JSON.parse(area.dataset.default) : [];
    renderBarChart(area, defaultData);
  });

  const lineCharts = document.querySelectorAll('[data-visualization="line"]');
  lineCharts.forEach(area => {
    const defaultData = area.dataset.default ? JSON.parse(area.dataset.default) : [];
    renderLineChart(area, defaultData);
  });

  const chartButtons = document.querySelectorAll('[data-chart-target]');
  chartButtons.forEach(button => {
    button.addEventListener('click', () => {
      const targetId = button.dataset.chartTarget;
      const points = button.dataset.points ? JSON.parse(button.dataset.points) : [];
      if (targetId && points) {
        const chartType = button.dataset.chartType || 'bars';
        const container = document.getElementById(targetId);
        const siblings = button.parentElement ? button.parentElement.querySelectorAll('[data-chart-target]') : [];
        siblings.forEach(sib => sib.classList.remove('is-active'));
        button.classList.add('is-active');
        if (chartType === 'line') {
          renderLineChart(container, points);
        } else {
          renderBarChart(container, points);
        }
      }
    });
    if (button.classList.contains('chip-default')) {
      button.click();
    }
  });

  const toast = document.querySelector('[data-js="global-toast"]');
  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('is-visible');
    setTimeout(() => toast.classList.remove('is-visible'), 2600);
  }

  const forms = document.querySelectorAll('form[data-form="redirect"]');
  forms.forEach(form => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const message = form.dataset.toast || 'El observatorio ha registrado el formulario.';
      showToast(message);
      setTimeout(() => {
        const action = form.getAttribute('action') || 'exito.html';
        window.location.href = action;
      }, 1800);
    });
  });

  const cookieBanner = document.querySelector('[data-js="cookie-banner"]');
  if (cookieBanner) {
    const storedChoice = localStorage.getItem('odese-cookie-choice');
    if (!storedChoice) {
      cookieBanner.classList.add('is-visible');
    }
    const actions = cookieBanner.querySelectorAll('[data-cookie-choice]');
    actions.forEach(button => {
      button.addEventListener('click', () => {
        const value = button.dataset.cookieChoice;
        localStorage.setItem('odese-cookie-choice', value);
        cookieBanner.classList.remove('is-visible');
      });
    });
  }

  const timelineItems = document.querySelectorAll('[data-timeline] li');
  timelineItems.forEach((item, index) => {
    setTimeout(() => item.classList.add('is-visible'), index * 280);
  });

  const yearSpan = document.querySelector('[data-current-year]');
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }
});