document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.site-navigation');
    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navigation.classList.toggle('active');
            document.body.classList.toggle('no-scroll');
        });
        navigation.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('active');
                navigation.classList.remove('active');
                document.body.classList.remove('no-scroll');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptButton = document.querySelector('.cookie-accept');
    const declineButton = document.querySelector('.cookie-decline');
    if (cookieBanner && acceptButton && declineButton) {
        const consentStatus = localStorage.getItem('cookieConsent');
        if (!consentStatus) {
            cookieBanner.classList.add('active');
        }
        acceptButton.addEventListener('click', () => {
            localStorage.setItem('cookieConsent', 'accepted');
            cookieBanner.classList.remove('active');
        });
        declineButton.addEventListener('click', () => {
            localStorage.setItem('cookieConsent', 'declined');
            cookieBanner.classList.remove('active');
        });
    }

    document.querySelectorAll('.timeline button').forEach(button => {
        button.addEventListener('click', () => {
            const detailTarget = button.dataset.target;
            document.querySelectorAll('.timeline button').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.timeline-details article').forEach(article => article.classList.remove('active'));
            button.classList.add('active');
            const targetArticle = document.querySelector(`#${detailTarget}`);
            if (targetArticle) {
                targetArticle.classList.add('active');
            }
        });
    });

    const modalLinks = document.querySelectorAll('[data-modal]');
    const modalCloseButtons = document.querySelectorAll('.modal-close');
    modalLinks.forEach(link => {
        link.addEventListener('click', event => {
            event.preventDefault();
            const modalId = link.dataset.modal;
            const modal = document.querySelector(`#${modalId}`);
            if (modal) {
                modal.classList.add('active');
                document.body.classList.add('no-scroll');
            }
        });
    });
    modalCloseButtons.forEach(closeButton => {
        closeButton.addEventListener('click', () => {
            const modal = closeButton.closest('.modal');
            modal.classList.remove('active');
            document.body.classList.remove('no-scroll');
        });
    });
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', event => {
            if (event.target === modal) {
                modal.classList.remove('active');
                document.body.classList.remove('no-scroll');
            }
        });
    });
});