import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  const handleToggle = () => setIsOpen((prev) => !prev);
  const handleLinkClick = () => setIsOpen(false);

  return (
    <header className="header" role="banner">
      <div className="container header-inner">
        <Link to="/" className="logo" aria-label="Tu Progreso Hoy home">
          Tu Progreso Hoy
        </Link>
        <button
          className="menu-toggle"
          onClick={handleToggle}
          aria-controls="primary-navigation"
          aria-expanded={isOpen}
        >
          <span className="sr-only">Toggle navigation</span>
          <span className="menu-bar" />
          <span className="menu-bar" />
          <span className="menu-bar" />
        </button>
        <nav
          className={`nav ${isOpen ? "nav-open" : ""}`}
          id="primary-navigation"
          aria-label="Main Navigation"
        >
          <NavLink to="/" onClick={handleLinkClick}>
            Home
          </NavLink>
          <NavLink to="/inflation" onClick={handleLinkClick}>
            Inflation
          </NavLink>
          <NavLink to="/course" onClick={handleLinkClick}>
            Course
          </NavLink>
          <NavLink to="/resources" onClick={handleLinkClick}>
            Resources
          </NavLink>
          <NavLink to="/contact" onClick={handleLinkClick}>
            Contact
          </NavLink>
          <span className="language-tag" aria-label="Languages">
            EN · ES
          </span>
        </nav>
      </div>
    </header>
  );
};

export default Header;