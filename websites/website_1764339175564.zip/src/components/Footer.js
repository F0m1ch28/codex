import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="footer" role="contentinfo">
      <div className="container footer-grid">
        <div>
          <h3 className="footer-title">Tu Progreso Hoy</h3>
          <p>Datos verificados para planificar tu presupuesto.</p>
          <p>Pasos acertados hoy, mejor futuro mañana.</p>
        </div>
        <div>
          <h4>Contact</h4>
          <address>
            Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina<br />
            Phone: <a href="tel:+541155551234">+54 11 5555-1234</a><br />
            Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
          </address>
          <div className="social-links">
            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
              LinkedIn
            </a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
              X (Twitter)
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer">
              YouTube
            </a>
          </div>
        </div>
        <div>
          <h4>Legal</h4>
          <ul className="footer-links">
            <li>
              <Link to="/privacy">Privacy</Link>
            </li>
            <li>
              <Link to="/cookies">Cookies</Link>
            </li>
            <li>
              <Link to="/terms">Terms</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4>Navigation</h4>
          <ul className="footer-links">
            <li>
              <Link to="/inflation">Inflation</Link>
            </li>
            <li>
              <Link to="/course">Course</Link>
            </li>
            <li>
              <Link to="/resources">Resources</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </div>
      </div>
      <p className="footer-note">
        Plataforma educativa con datos esenciales, sin asesoría financiera directa.
      </p>
      <p className="footer-note">
        © {new Date().getFullYear()} Tu Progreso Hoy. Buenos Aires, Argentina.
      </p>
    </footer>
  );
};

export default Footer;