import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const consent = localStorage.getItem("tphCookieConsent");
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAction = (value) => {
    if (typeof window !== "undefined") {
      localStorage.setItem("tphCookieConsent", value);
    }
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <p>
          We use cookies to understand traffic and improve the plataforma educativa. Choose if you accept analytics cookies.
        </p>
        <div className="cookie-actions">
          <button type="button" className="btn-secondary" onClick={() => handleAction("declined")}>
            Decline
          </button>
          <button type="button" className="btn-primary" onClick={() => handleAction("accepted")}>
            Accept
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;