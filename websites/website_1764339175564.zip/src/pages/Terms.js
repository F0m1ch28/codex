import React from "react";

const Terms = () => {
  return (
    <div className="section-page">
      <section className="section hero-sm" aria-labelledby="terms-title">
        <div className="container narrow">
          <h1 id="terms-title">Terms & Conditions</h1>
          <p>
            These terms govern the use of Tu Progreso Hoy educational platform focused on argentina inflation insights and personal finance learning.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container narrow legal-text">
          <h2>Service nature</h2>
          <p>
            Tu Progreso Hoy provides educational content and data visualizations. Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>

          <h2>Accounts & access</h2>
          <p>
            Access to premium content may require registration. You must provide accurate information and maintain confidentiality of login credentials.
          </p>

          <h2>Acceptable use</h2>
          <ul>
            <li>Do not misuse data or portray insights as personal financial advice.</li>
            <li>Respect copyright on templates and course materials.</li>
            <li>Do not introduce malicious code or disrupt the platform.</li>
          </ul>

          <h2>Intellectual property</h2>
          <p>
            All content, graphics, and course materials are owned by Tu Progreso Hoy unless noted otherwise. You may use templates for personal or internal business use.
          </p>

          <h2>Limitation of liability</h2>
          <p>
            We provide information “as is” for educational purposes. Users remain responsible for financial decisions.
          </p>

          <h2>Changes to terms</h2>
          <p>
            Updates will be communicated on this page and, when material, by email to subscribed users.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Terms;