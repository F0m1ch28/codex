import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Contact = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    confirmEmail: "",
    message: "",
    consent: false
  });
  const [formError, setFormError] = useState("");

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name.trim()) {
      setFormError("Name is required.");
      return;
    }
    if (!formData.email.trim() || !formData.confirmEmail.trim()) {
      setFormError("Email fields are required.");
      return;
    }
    if (formData.email.trim().toLowerCase() !== formData.confirmEmail.trim().toLowerCase()) {
      setFormError("Emails must match.");
      return;
    }
    if (!formData.consent) {
      setFormError("Please accept the double opt-in notice.");
      return;
    }
    setFormError("");
    navigate("/thank-you", { state: { source: "contact" } });
  };

  return (
    <div className="section-page">
      <section className="section hero-sm" aria-labelledby="contact-title">
        <div className="container narrow">
          <h1 id="contact-title">Contact Tu Progreso Hoy</h1>
          <p>
            Buenos Aires-based educational SaaS. Reach out for argentina inflation insights and curso details.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container contact-grid">
          <div>
            <h2>Visit or call</h2>
            <address>
              Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina<br />
              Phone: <a href="tel:+541155551234">+54 11 5555-1234</a><br />
              Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
            </address>
            <div className="social-links">
              <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
                LinkedIn
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                X (Twitter)
              </a>
              <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer">
                YouTube
              </a>
            </div>
            <div className="map-wrapper" aria-label="Map of Buenos Aires office">
              <iframe
                title="Tu Progreso Hoy Buenos Aires"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3285.9470508570974!2d-58.38375932365438!3d-34.60373895950343!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccacf29f9098b%3A0xd4d51dfc6f0efa5f!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1699999999999!5m2!1sen!2sar"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
          <div>
            <h2>Send a message</h2>
            <form className="form" onSubmit={handleSubmit}>
              <div className="form-field">
                <label htmlFor="contact-name">Name</label>
                <input
                  id="contact-name"
                  name="name"
                  type="text"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Nombre / Name"
                />
              </div>
              <div className="form-field">
                <label htmlFor="contact-email">Email</label>
                <input
                  id="contact-email"
                  name="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="you@example.com"
                />
              </div>
              <div className="form-field">
                <label htmlFor="contact-confirm-email">Confirm email</label>
                <input
                  id="contact-confirm-email"
                  name="confirmEmail"
                  type="email"
                  required
                  value={formData.confirmEmail}
                  onChange={handleChange}
                  placeholder="Repeat email"
                />
              </div>
              <div className="form-field">
                <label htmlFor="contact-message">Message</label>
                <textarea
                  id="contact-message"
                  name="message"
                  rows="4"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="How can we help? ¿En qué podemos ayudarte?"
                />
              </div>
              <div className="form-checkbox">
                <input
                  id="contact-consent"
                  name="consent"
                  type="checkbox"
                  checked={formData.consent}
                  onChange={handleChange}
                  required
                />
                <label htmlFor="contact-consent">
                  I acknowledge Tu Progreso Hoy will email me for double opt-in confirmation.
                </label>
              </div>
              {formError && <p className="form-error" role="alert">{formError}</p>}
              <button type="submit" className="btn-primary">
                Submit & confirm
              </button>
            </form>
            <p className="form-note">
              De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;