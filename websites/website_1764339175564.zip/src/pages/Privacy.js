import React from "react";

const Privacy = () => {
  return (
    <div className="section-page">
      <section className="section hero-sm" aria-labelledby="privacy-title">
        <div className="container narrow">
          <h1 id="privacy-title">Privacy Policy</h1>
          <p>
            Effective date: 2024. Tu Progreso Hoy respects your privacy and complies with applicable Argentina data protection regulations.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container narrow legal-text">
          <h2>Data collected</h2>
          <p>
            We collect name, email, company (optional), and message content when you complete forms. We store consent preferences for double opt-in and cookie choices.
          </p>

          <h2>Purpose of processing</h2>
          <ul>
            <li>Send confirmation emails to complete double opt-in.</li>
            <li>Provide educational updates about argentina inflation and curso de finanzas.</li>
            <li>Respond to inquiries regarding our platform.</li>
          </ul>

          <h2>Legal basis</h2>
          <p>
            Consent provided via our forms. You may withdraw consent by emailing hola@tuprogresohoy.com.
          </p>

          <h2>Retention</h2>
          <p>
            Data is stored for 24 months after the last interaction or until consent withdrawal.
          </p>

          <h2>Data sharing</h2>
          <p>
            We do not sell personal data. Service providers (email service platform, analytics if accepted) process data under confidentiality agreements.
          </p>

          <h2>International transfers</h2>
          <p>
            When using cloud services, data may be stored outside Argentina. We ensure adequate safeguards through contractual clauses.
          </p>

          <h2>Your rights</h2>
          <p>
            You may request access, rectification, deletion, restriction, or objection by contacting hola@tuprogresohoy.com. We will respond within 10 business days.
          </p>

          <h2>Updates</h2>
          <p>
            Policy updates will be posted on this page with a new effective date.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;