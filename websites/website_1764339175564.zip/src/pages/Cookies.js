import React from "react";

const Cookies = () => {
  return (
    <div className="section-page">
      <section className="section hero-sm" aria-labelledby="cookies-title">
        <div className="container narrow">
          <h1 id="cookies-title">Cookie Policy</h1>
          <p>
            Tu Progreso Hoy uses cookies to operate the website and analyse usage only when you opt-in.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container narrow legal-text">
          <h2>Essential cookies</h2>
          <p>
            Required for security and session management. They cannot be disabled through our banner.
          </p>

          <h2>Analytics cookies</h2>
          <p>
            Optional cookies used to understand argentina inflation content engagement. Activated only after your consent via the cookie banner.
          </p>

          <h2>Managing cookies</h2>
          <p>
            You can clear or block cookies via browser settings. Revoking consent can be done by clearing local storage entries labelled <strong>tphCookieConsent</strong>.
          </p>

          <h2>Contact</h2>
          <p>
            For questions, email hola@tuprogresohoy.com.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Cookies;