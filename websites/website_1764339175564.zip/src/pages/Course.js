import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const modules = [
  {
    title: "Module 1 · Argentina macro essentials",
    points: [
      "Argentina inflation structure: core, regulated, seasonal.",
      "How BCRA policy influences household planning.",
      "Reading official datasets in English and Español."
    ]
  },
  {
    title: "Module 2 · Budgeting Argentina",
    points: [
      "Design ARS cash-flow dashboards.",
      "Integrate USD equivalent expenses responsibly.",
      "Benchmark grocery and transport baskets."
    ]
  },
  {
    title: "Module 3 · FX awareness",
    points: [
      "ARS→USD tracker workflows.",
      "Scenario planning with spread dashboards.",
      "Risk signals without offering financial products."
    ]
  },
  {
    title: "Module 4 · Personal finance habits",
    points: [
      "Build savings goals aligned with argentina inflation.",
      "Community accountability sessions.",
      "Templates for bilingual financial journaling."
    ]
  }
];

const Course = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    confirmEmail: "",
    consent: false
  });
  const [formError, setFormError] = useState("");

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name.trim()) {
      setFormError("Please add your name.");
      return;
    }
    if (!formData.email.trim() || !formData.confirmEmail.trim()) {
      setFormError("Complete both email fields.");
      return;
    }
    if (formData.email.trim().toLowerCase() !== formData.confirmEmail.trim().toLowerCase()) {
      setFormError("Emails must match for double opt-in.");
      return;
    }
    if (!formData.consent) {
      setFormError("Consent required to receive confirmation email.");
      return;
    }
    setFormError("");
    navigate("/thank-you", { state: { source: "course" } });
  };

  return (
    <div className="section-page">
      <section className="section hero-sm" aria-labelledby="course-hero-title">
        <div className="container narrow">
          <h1 id="course-hero-title">Curso de finanzas personales para Argentina</h1>
          <p>
            Información confiable que respalda elecciones responsables sobre tu dinero. 
            Learn budgeting Argentina fundamentals in English with Español support.
          </p>
        </div>
      </section>

      <section className="section" aria-labelledby="syllabus-title">
        <div className="container">
          <h2 id="syllabus-title">Syllabus</h2>
          <div className="modules-grid">
            {modules.map((module) => (
              <article key={module.title} className="card">
                <h3>{module.title}</h3>
                <ul className="feature-list">
                  {module.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section alt-section" aria-labelledby="audience-title">
        <div className="container course-two-col">
          <div>
            <h2 id="audience-title">Who is it for?</h2>
            <ul className="feature-list">
              <li>Young professionals managing multi-currency budgets.</li>
              <li>Families adjusting to argentina inflation changes.</li>
              <li>Entrepreneurs seeking datos confiables for planning.</li>
            </ul>
            <p>
              Sessions run live on AR time zone with recordings available for 30 days. 
              Material includes bilingual glossaries for key terms.
            </p>
          </div>
          <div>
            <h2>Benefits</h2>
            <ul className="feature-list">
              <li>Weekly accountability check-ins.</li>
              <li>Template library with ARS→USD scenarios.</li>
              <li>Community access moderated by Buenos Aires facilitators.</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="section" id="course-cta" aria-labelledby="cta-title">
        <div className="container narrow">
          <h2 id="cta-title">Enroll with Double Opt-In</h2>
          <p>
            Complete the form and confirm from your inbox to secure a place in the upcoming cohort.
          </p>
          <form className="form" onSubmit={handleSubmit}>
            <div className="form-field">
              <label htmlFor="course-name">Full name</label>
              <input
                id="course-name"
                name="name"
                type="text"
                required
                value={formData.name}
                onChange={handleChange}
                placeholder="Tu nombre / Your name"
              />
            </div>
            <div className="form-field">
              <label htmlFor="course-email">Email</label>
              <input
                id="course-email"
                name="email"
                type="email"
                required
                value={formData.email}
                onChange={handleChange}
                placeholder="you@example.com"
              />
            </div>
            <div className="form-field">
              <label htmlFor="course-confirm-email">Confirm email</label>
              <input
                id="course-confirm-email"
                name="confirmEmail"
                type="email"
                required
                value={formData.confirmEmail}
                onChange={handleChange}
                placeholder="Repeat email"
              />
            </div>
            <div className="form-checkbox">
              <input
                id="course-consent"
                name="consent"
                type="checkbox"
                checked={formData.consent}
                onChange={handleChange}
                required
              />
              <label htmlFor="course-consent">
                I agree to receive a confirmation email and understand enrolment completes after my approval (double opt-in).
              </label>
            </div>
            {formError && <p className="form-error" role="alert">{formError}</p>}
            <button type="submit" className="btn-primary">
              Request enrollment email
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};

export default Course;