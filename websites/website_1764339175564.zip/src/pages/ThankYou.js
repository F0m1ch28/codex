import React from "react";
import { Link, useLocation } from "react-router-dom";

const ThankYou = () => {
  const location = useLocation();
  const source = location.state?.source || "subscription";

  return (
    <div className="section-page">
      <section className="section hero-sm" aria-labelledby="thankyou-title">
        <div className="container narrow">
          <h1 id="thankyou-title">Thank you! ¡Gracias!</h1>
          <p>
            We received your request ({source}). Please check your inbox and confirm the email to complete the double opt-in process.
          </p>
          <p>
            Revisa tu correo y confirma para activar el acceso. Si no encuentras el mensaje, revisa tu carpeta de spam o comunícate con hola@tuprogresohoy.com.
          </p>
          <Link to="/" className="btn-primary">
            Return to home
          </Link>
        </div>
      </section>
    </div>
  );
};

export default ThankYou;