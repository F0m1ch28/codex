import React from "react";

const cpiSeries = [
  { label: "Jul 24", value: 84 },
  { label: "Aug 24", value: 91 },
  { label: "Sep 24", value: 96 },
  { label: "Oct 24", value: 93 }
];

const fxSeries = [
  { label: "Jul 24", value: 65 },
  { label: "Aug 24", value: 71 },
  { label: "Sep 24", value: 76 },
  { label: "Oct 24", value: 78 }
];

const faqs = [
  {
    question: "How do you source argentina inflation data?",
    answer:
      "Primary sources include INDEC CPI releases, provincial statistics, and energy tariff adjustments. We cross-check with BCRA high-frequency indicators and industry consortium datasets."
  },
  {
    question: "Do you offer forecasts?",
    answer:
      "We build scenarios, not deterministic forecasts. Scenario ranges combine CPI trailing averages, regulated price calendars, and forward FX implied by BCRA futures."
  },
  {
    question: "What is the ARS→USD methodology?",
    answer:
      "We consolidate official FX, blue-chip swap, and parallel rates to illustrate spreads. Rates are normalized to USD with weekly closing references."
  },
  {
    question: "Is this financial advice?",
    answer:
      "No. Plataforma educativa con datos esenciales, sin asesoría financiera directa."
  }
];

const Inflation = () => {
  return (
    <div className="section-page">
      <section className="section hero-sm" aria-labelledby="inflation-title">
        <div className="container narrow">
          <h1 id="inflation-title">Inflation methodology & Argentina macro context</h1>
          <p>
            Build transparent understanding of argentina inflation and ARS→USD dynamics with reproducible methodologies.
          </p>
        </div>
      </section>

      <section className="section" aria-labelledby="methodology-title">
        <div className="container narrow">
          <h2 id="methodology-title">Methodology / Metodología</h2>
          <p>
            We process CPI data in English and Español, harmonizing monthly releases with seasonally adjusted series. 
            Enfoque en canasta urbana, ponderaciones oficiales (INDEC) y monitoreo independiente del AMBA. 
            All calculations follow WCAG compliant visuals and reproducible notebooks.
          </p>
          <ul className="feature-list">
            <li>Data ingestion via INDEC CSV + BCRA APIs.</li>
            <li>Outlier detection using rolling median deviations.</li>
            <li>Scenario building: base, accelerated, regulated-price shock.</li>
          </ul>
        </div>
      </section>

      <section className="section alt-section" aria-labelledby="charts-title">
        <div className="container">
          <h2 id="charts-title">Charts: CPI vs ARS FX</h2>
          <div className="charts-grid">
            <div className="chart-card" role="img" aria-label="CPI Index chart">
              <h3>CPI index (base 100 = Jan 2024)</h3>
              <div className="chart-bars">
                {cpiSeries.map((point) => (
                  <div key={point.label} className="bar-wrapper">
                    <div className="bar" style={{ height: `${point.value}%` }} />
                    <span>{point.label}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="chart-card" role="img" aria-label="ARS FX chart">
              <h3>ARS→USD composite spread</h3>
              <div className="chart-bars">
                {fxSeries.map((point) => (
                  <div key={point.label} className="bar-wrapper">
                    <div className="bar bar-alt" style={{ height: `${point.value}%` }} />
                    <span>{point.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <p className="chart-description">
            Análisis transparentes y datos de mercado para decidir con seguridad. 
            Each bar reflects normalized index values to ease comparisons between CPI acceleration and FX adjustments.
          </p>
        </div>
      </section>

      <section className="section" aria-labelledby="context-title">
        <div className="container narrow">
          <h2 id="context-title">CPI & FX Context</h2>
          <p>
            Argentina inflation remains sensitive to regulated price adjustments and FX pass-through. 
            We analyse tarifario segments, fuel price dynamics, and wage agreements to monitor second-round effects.
          </p>
          <p>
            ARS→USD spreads are monitored through official, MEP, and CCL benchmarks. 
            Peso liquidity windows and BCRA interventions are logged to evaluate intraweek volatility.
          </p>
        </div>
      </section>

      <section className="section alt-section" aria-labelledby="faq-title">
        <div className="container narrow">
          <h2 id="faq-title">FAQ</h2>
          <div className="faq-list">
            {faqs.map((item) => (
              <details key={item.question}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Inflation;