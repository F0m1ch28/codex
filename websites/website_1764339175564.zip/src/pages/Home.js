import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const trackerData = [
  { date: "2024-10-01", rate: 0.00115, variation: "+0.9%" },
  { date: "2024-09-24", rate: 0.00114, variation: "+0.4%" },
  { date: "2024-09-17", rate: 0.00113, variation: "-0.6%" },
  { date: "2024-09-10", rate: 0.00114, variation: "+1.2%" },
  { date: "2024-09-03", rate: 0.00112, variation: "-0.3%" }
];

const insights = [
  {
    title: "Argentina inflation momentum",
    description:
      "Monthly CPI acceleration stabilized after subsidy adjustments. Energy and transport remain above the general index."
  },
  {
    title: "ARS → USD tracker insights",
    description:
      "ARS technical floor appears near 0.00110 USD with slow depreciation moderated by central bank interventions."
  },
  {
    title: "Budgeting Argentina",
    description:
      "Household baskets in AMBA show 2.4% monthly variation. Align short-term cash flow with payroll cycles."
  }
];

const testimonials = [
  {
    quote:
      "Tu Progreso Hoy helped our team monitor argentina inflation and align internal budgeting with credible benchmarks.",
    name: "Mariana P., FP&A Lead"
  },
  {
    quote:
      "Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera con guías claras y datos abiertos.",
    name: "Federico R., Emprendedor"
  }
];

const Home = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    confirmEmail: "",
    consent: false
  });
  const [formError, setFormError] = useState("");

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name.trim()) {
      setFormError("Please enter your name.");
      return;
    }
    if (!formData.email.trim() || !formData.confirmEmail.trim()) {
      setFormError("Please enter and confirm your email.");
      return;
    }
    if (formData.email.trim().toLowerCase() !== formData.confirmEmail.trim().toLowerCase()) {
      setFormError("Emails must match for double opt-in.");
      return;
    }
    if (!formData.consent) {
      setFormError("Double opt-in requires your consent acknowledgement.");
      return;
    }
    setFormError("");
    navigate("/thank-you", { state: { source: "free-trial" } });
  };

  return (
    <div>
      <section
        className="hero"
        aria-labelledby="hero-title"
        style={{
          backgroundImage:
            "linear-gradient(rgba(15, 23, 42, 0.78), rgba(15, 23, 42, 0.78)), url('https://upload.wikimedia.org/wikipedia/commons/1/1a/Flag_of_Argentina.svg')"
        }}
      >
        <div className="container hero-content">
          <p className="hero-kicker">argentina inflation · ars usd · finanzas personales</p>
          <h1 id="hero-title">Datos verificados para planificar tu presupuesto.</h1>
          <p className="hero-subtitle">
            Decisiones responsables, objetivos nítidos. Conocimiento financiero impulsado por tendencias. Pasos acertados hoy, mejor futuro mañana.
          </p>
          <div className="hero-actions">
            <Link to="/inflation" className="btn-primary">
              Explore inflation insights
            </Link>
            <a href="#free-trial" className="btn-secondary">
              Obtener prueba gratuita
            </a>
          </div>
          <p className="hero-note">
            Análisis transparentes y datos de mercado para decidir con seguridad.
          </p>
        </div>
      </section>

      <section className="section" id="promises" aria-labelledby="promises-title">
        <div className="container">
          <h2 id="promises-title">Key Promises / ключевые обещания</h2>
          <div className="promises-grid">
            <article>
              <h3>Market clarity</h3>
              <p>Información confiable que respalda elecciones responsables sobre tu dinero.</p>
            </article>
            <article>
              <h3>Trend-driven dashboards</h3>
              <p>Conocimiento financiero impulsado por tendencias con series históricas y actualización semanal.</p>
            </article>
            <article>
              <h3>Budget-first mindset</h3>
              <p>Argentina inflation contextualized for hogares y PyMEs, con escenarios en ARS y USD.</p>
            </article>
          </div>
        </div>
      </section>

      <section className="section alt-section" aria-labelledby="tracker-title">
        <div className="container">
          <div className="section-header">
            <h2 id="tracker-title">ARS → USD tracker</h2>
            <p>Monitor ARS spot value versus USD with weekly variations.</p>
          </div>
          <div className="tracker-table" role="table" aria-label="ARS to USD tracker">
            <div className="tracker-row tracker-head" role="row">
              <div role="columnheader">Date</div>
              <div role="columnheader">Rate</div>
              <div role="columnheader">Variation</div>
            </div>
            {trackerData.map((item) => (
              <div className="tracker-row" role="row" key={item.date}>
                <div role="cell">{item.date}</div>
                <div role="cell">{item.rate.toFixed(5)} USD</div>
                <div role="cell">{item.variation}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" id="insights" aria-labelledby="insights-title">
        <div className="container">
          <div className="section-header">
            <h2 id="insights-title">Insights / инсайты</h2>
            <p>Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.</p>
          </div>
          <div className="cards-grid">
            {insights.map((insight) => (
              <article className="card" key={insight.title}>
                <h3>{insight.title}</h3>
                <p>{insight.description}</p>
                <Link to="/inflation" className="text-link">
                  View methodology
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section alt-section" id="course" aria-labelledby="course-title">
        <div className="container course-overview">
          <div>
            <h2 id="course-title">Course overview</h2>
            <p>
              Curso introductorio de finanzas personales para Argentina con módulos de presupuesto, ahorro, FX y planificación.
              De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
            </p>
            <ul className="feature-list">
              <li>Weekly live session with data walk-throughs.</li>
              <li>Downloadable templates in English & Español.</li>
              <li>Community forum moderated in Buenos Aires (AR time).</li>
            </ul>
            <Link to="/course" className="btn-primary">
              View syllabus
            </Link>
          </div>
          <div className="course-highlight">
            <h3>Course modules</h3>
            <ol>
              <li>Argentina macro & Argentina inflation drivers.</li>
              <li>Budgeting Argentina: templates for ARS & USD.</li>
              <li>Managing FX exposure with responsible practices.</li>
              <li>Scenario planning with datos confiables.</li>
            </ol>
            <p>Disponible en EN / ES.</p>
          </div>
        </div>
      </section>

      <section className="section" id="testimonials" aria-labelledby="testimonials-title">
        <div className="container">
          <h2 id="testimonials-title">Testimonials</h2>
          <div className="testimonials-grid">
            {testimonials.map((testimonial, index) => (
              <blockquote key={index} className="testimonial">
                <p>“{testimonial.quote}”</p>
                <cite>{testimonial.name}</cite>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className="section alt-section" id="free-trial" aria-labelledby="trial-title">
        <div className="container">
          <div className="form-wrapper">
            <h2 id="trial-title">Получить бесплатный пробный урок</h2>
            <p>
              Double opt-in: complete the form, then confirm from your email inbox to activate the trial lesson.
            </p>
            <form className="form" onSubmit={handleSubmit}>
              <div className="form-field">
                <label htmlFor="name">Full name</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Your name"
                />
              </div>
              <div className="form-field">
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="you@example.com"
                />
              </div>
              <div className="form-field">
                <label htmlFor="confirmEmail">Confirm email</label>
                <input
                  id="confirmEmail"
                  name="confirmEmail"
                  type="email"
                  required
                  value={formData.confirmEmail}
                  onChange={handleChange}
                  placeholder="Retype email"
                />
              </div>
              <div className="form-checkbox">
                <input
                  id="consent"
                  name="consent"
                  type="checkbox"
                  checked={formData.consent}
                  onChange={handleChange}
                  required
                />
                <label htmlFor="consent">
                  I understand Tu Progreso Hoy will send a confirmation email and my trial starts after I approve it.
                </label>
              </div>
              {formError && <p className="form-error" role="alert">{formError}</p>}
              <button type="submit" className="btn-primary">
                Send & confirm email
              </button>
            </form>
            <p className="form-note">
              Plataforma educativa con datos esenciales, sin asesoría financiera directa.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;