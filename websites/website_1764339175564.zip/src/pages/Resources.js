import React from "react";

const resources = [
  {
    title: "Argentina inflation deep dive",
    lang: "EN",
    description: "Explains CPI categories, weighting, and how to compare yoy vs mom.",
    link: "/inflation"
  },
  {
    title: "Glosario de finanzas personales (ES)",
    lang: "ES",
    description: "Términos clave: presupuesto, colchón financiero, tasa efectiva.",
    link: "#"
  },
  {
    title: "Budgeting Argentina toolkit",
    lang: "EN/ES",
    description: "Downloadable spreadsheets with bilingual labels for ARS and USD planning.",
    link: "#"
  },
  {
    title: "Tendencias económicas semanales",
    lang: "ES",
    description: "Resumen de datos confiables para PyMEs y hogares en Argentina.",
    link: "#"
  }
];

const Resources = () => {
  return (
    <div className="section-page">
      <section className="section hero-sm" aria-labelledby="resources-title">
        <div className="container narrow">
          <h1 id="resources-title">Resources & Glossaries / Recursos</h1>
          <p>
            Curated reading list and templates in English and Español to strengthen argentina inflation understanding.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="cards-grid">
            {resources.map((resource) => (
              <article key={resource.title} className="card resource-card">
                <span className="resource-lang">{resource.lang}</span>
                <h3>{resource.title}</h3>
                <p>{resource.description}</p>
                {resource.link === "#" ? (
                  <span className="coming-soon">Available in member area</span>
                ) : (
                  <a className="text-link" href={resource.link}>
                    View resource
                  </a>
                )}
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Resources;