import React, { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import Inflation from "./pages/Inflation";
import Course from "./pages/Course";
import Resources from "./pages/Resources";
import Contact from "./pages/Contact";
import ThankYou from "./pages/ThankYou";
import Privacy from "./pages/Privacy";
import Cookies from "./pages/Cookies";
import Terms from "./pages/Terms";

const DisclaimerModal = ({ onClose }) => {
  return (
    <div className="disclaimer-overlay" role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
      <div className="disclaimer-card">
        <h2 id="disclaimer-title">Мы не предоставляем финансовые услуги</h2>
        <p>We do not provide financial services.</p>
        <button className="btn-primary" type="button" onClick={onClose}>
          Acknowledge
        </button>
      </div>
    </div>
  );
};

const App = () => {
  const [showDisclaimer, setShowDisclaimer] = useState(() => {
    if (typeof window === "undefined") return true;
    return !localStorage.getItem("tphDisclaimerAcknowledged");
  });

  useEffect(() => {
    if (!showDisclaimer && typeof window !== "undefined") {
      localStorage.setItem("tphDisclaimerAcknowledged", "true");
    }
  }, [showDisclaimer]);

  return (
    <div className="app">
      {showDisclaimer && <DisclaimerModal onClose={() => setShowDisclaimer(false)} />}
      <ScrollToTop />
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/inflation" element={<Inflation />} />
          <Route path="/course" element={<Course />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookies" element={<Cookies />} />
          <Route path="/terms" element={<Terms />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
};

export default App;