document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav-list');

    if (navToggle && navList) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            navList.classList.toggle('open');
        });

        navList.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    navList.classList.remove('open');
                }
            });
        });
    }

    const banner = document.getElementById('cookie-banner');
    const actionButtons = banner ? banner.querySelectorAll('[data-cookie-action]') : [];

    const hideBanner = () => {
        if (banner) {
            banner.classList.add('hide');
        }
    };

    if (localStorage.getItem('minepydc_cookie_pref')) {
        hideBanner();
    } else if (banner) {
        actionButtons.forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const action = button.getAttribute('data-cookie-action');
                localStorage.setItem('minepydc_cookie_pref', action);
                window.open('cookies.html', '_blank', 'noopener');
                hideBanner();
            });
        });
    }
});