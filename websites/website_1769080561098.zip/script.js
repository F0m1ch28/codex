document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = primaryNav.classList.toggle('nav-open');
            navToggle.classList.toggle('opened', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen.toString());
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (primaryNav.classList.contains('nav-open')) {
                    primaryNav.classList.remove('nav-open');
                    navToggle.classList.remove('opened');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    document.querySelectorAll('[data-current-year]').forEach(span => {
        span.textContent = new Date().getFullYear();
    });

    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAcceptBtn = document.getElementById('cookieAccept');
    const cookieDeclineBtn = document.getElementById('cookieDecline');
    const cookieKey = 'regeneracion-cookie-choice';

    if (cookieBanner && cookieAcceptBtn && cookieDeclineBtn) {
        const storedChoice = localStorage.getItem(cookieKey);
        if (!storedChoice) {
            requestAnimationFrame(() => cookieBanner.classList.add('visible'));
        }

        cookieAcceptBtn.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'accepted');
            cookieBanner.classList.remove('visible');
        });

        cookieDeclineBtn.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'declined');
            cookieBanner.classList.remove('visible');
        });
    }

    const toast = document.getElementById('formToast');
    const forms = document.querySelectorAll('form[data-form-type="contact"]');

    forms.forEach(form => {
        form.addEventListener('submit', event => {
            event.preventDefault();
            if (toast) {
                toast.textContent = 'Mensaje enviado. Redirigiendo a la confirmación.';
                toast.classList.add('visible');
                setTimeout(() => {
                    toast.classList.remove('visible');
                    window.location.href = form.getAttribute('action') || 'thank-you.html';
                }, 1600);
            } else {
                window.location.href = form.getAttribute('action') || 'thank-you.html';
            }
        });
    });

    const diagramCanvas = document.getElementById('circularDiagram');
    const diagramInfo = document.getElementById('circularInfo');
    if (diagramCanvas && diagramInfo) {
        const ctx = diagramCanvas.getContext('2d');
        const dpr = window.devicePixelRatio || 1;
        const baseSize = 360;
        diagramCanvas.width = baseSize * dpr;
        diagramCanvas.height = baseSize * dpr;
        diagramCanvas.style.width = baseSize + 'px';
        diagramCanvas.style.height = baseSize + 'px';
        ctx.scale(dpr, dpr);

        const flows = [
            { label: 'Cataluña', value: 28, color: '#6D4C41', energy: 'Waste-to-energy con redes de calor hospitalarias.', circularity: 74 },
            { label: 'Andalucía', value: 22, color: '#388E3C', energy: 'Clasificación inteligente y retornos materiales.', circularity: 68 },
            { label: 'Galicia', value: 18, color: '#FF6F00', energy: 'Biodigestión y retorno agroenergético.', circularity: 71 },
            { label: 'Murcia', value: 14, color: '#8BC34A', energy: 'Reutilización instrumental y logística inversa.', circularity: 63 },
            { label: 'Canarias', value: 18, color: '#4E342E', energy: 'Microplantas insulares y redes colaborativas.', circularity: 66 }
        ];

        const total = flows.reduce((acc, flow) => acc + flow.value, 0);
        const centerX = baseSize / 2;
        const centerY = baseSize / 2;
        const radius = baseSize / 2 - 20;

        const drawDiagram = () => {
            let startAngle = -Math.PI / 2;
            ctx.clearRect(0, 0, baseSize, baseSize);
            flows.forEach(flow => {
                const sliceAngle = (flow.value / total) * Math.PI * 2;
                ctx.beginPath();
                ctx.moveTo(centerX, centerY);
                ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
                ctx.closePath();
                ctx.fillStyle = flow.color;
                ctx.fill();
                ctx.strokeStyle = '#EFEBE9';
                ctx.lineWidth = 2;
                ctx.stroke();

                const midAngle = startAngle + sliceAngle / 2;
                const labelX = centerX + (radius * 0.65) * Math.cos(midAngle);
                const labelY = centerY + (radius * 0.65) * Math.sin(midAngle);
                ctx.fillStyle = '#FFFFFF';
                ctx.font = '600 14px Quicksand';
                ctx.fillText(flow.label, labelX - 30, labelY + 4);

                startAngle += sliceAngle;
            });
        };

        drawDiagram();

        const handleClick = event => {
            const rect = diagramCanvas.getBoundingClientRect();
            const x = event.clientX - rect.left - centerX;
            const y = event.clientY - rect.top - centerY;
            const angle = Math.atan2(y, x);
            let adjustedAngle = angle < -Math.PI / 2 ? angle + Math.PI * 2 : angle;
            adjustedAngle = adjustedAngle < -Math.PI / 2 ? adjustedAngle + Math.PI * 2 : adjustedAngle;
            adjustedAngle += Math.PI / 2;
            if (adjustedAngle < 0) adjustedAngle += Math.PI * 2;

            let startAngle = 0;
            for (const flow of flows) {
                const sliceAngle = (flow.value / total) * Math.PI * 2;
                if (adjustedAngle >= startAngle && adjustedAngle <= startAngle + sliceAngle) {
                    const capped = Math.min(flow.circularity, 99.9).toFixed(1);
                    diagramInfo.innerHTML = `
                        <h3>${flow.label}</h3>
                        <p>${flow.energy}</p>
                        <p>Grado de circularidad estimado: ${capped}%.</p>
                    `;
                    break;
                }
                startAngle += sliceAngle;
            }
        };

        diagramCanvas.addEventListener('click', handleClick);
    }

    const calcForm = document.getElementById('circularityForm');
    const calcResult = document.getElementById('calculatorResult');

    if (calcForm && calcResult) {
        calcForm.addEventListener('submit', event => {
            event.preventDefault();
            const total = parseFloat(document.getElementById('residuosTotales').value) || 0;
            const valorizados = parseFloat(document.getElementById('residuosValorizados').value) || 0;
            const energia = parseFloat(document.getElementById('energiaRecuperada').value) || 0;
            let ratio = 0;
            if (total > 0 && valorizados >= 0) {
                ratio = Math.min((valorizados / total) * 100, 99.9);
            }
            const recomendaciones = ratio > 70
                ? 'Consolida alianzas territoriales y publica métricas abiertas para fortalecer la replicabilidad.'
                : 'Refuerza la segregación en origen y conecta con operadores energéticos locales para aumentar el retorno.';
            calcResult.innerHTML = `
                <h3>Estimación de circularidad</h3>
                <p>Residuos totales: ${total.toFixed(2)} t/año.</p>
                <p>Residuos valorizados: ${valorizados.toFixed(2)} t/año.</p>
                <p>Energía recuperada estimada: ${energia.toFixed(2)} MWh/año.</p>
                <p>Grado de circularidad aproximado: ${ratio.toFixed(1)}%.</p>
                <p>${recomendaciones}</p>
            `;
        });
    }

    const impactRegion = document.getElementById('impactRegion');
    const impactYear = document.getElementById('impactYear');
    const impactOutput = document.getElementById('impactOutput');

    if (impactRegion && impactYear && impactOutput) {
        const dataset = {
            'Cataluña': { base: 62, increment: 3.1, energy: 45, community: 'Consorcios sanitarios y redes de calor urbano.' },
            'Andalucía': { base: 54, increment: 2.8, energy: 38, community: 'Robots colaborativos y rutas logísticas optimizadas.' },
            'Galicia': { base: 58, increment: 2.5, energy: 41, community: 'Biodigestores cooperativos y retornos agrarios.' },
            'Murcia': { base: 49, increment: 2.4, energy: 34, community: 'Inventarios de reutilización y talleres hospitalarios.' },
            'Canarias': { base: 51, increment: 2.6, energy: 36, community: 'Microplantas insulares y acuerdos interhospitalarios.' }
        };

        const updateImpact = () => {
            const region = impactRegion.value;
            const year = parseInt(impactYear.value, 10);
            const data = dataset[region];
            const yearsForward = Math.max(year - 2024, 0);
            const circularity = Math.min(data.base + data.increment * yearsForward, 99.9);
            const energyVector = data.energy + yearsForward * 1.8;
            impactOutput.innerHTML = `
                <h3>${region}: indicadores ${year}</h3>
                <div class="impact-output-grid">
                    <div>Grado de circularidad estimado: ${circularity.toFixed(1)}%.</div>
                    <div>Energía recuperada proyectada: ${energyVector.toFixed(1)} GWh/año.</div>
                    <div>Claves comunitarias: ${data.community}</div>
                </div>
            `;
        };

        impactRegion.addEventListener('change', updateImpact);
        impactYear.addEventListener('input', updateImpact);
        updateImpact();
    }
});