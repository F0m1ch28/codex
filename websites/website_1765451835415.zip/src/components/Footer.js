import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.footerInner}`}>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Language School Croatia</h3>
          <p className={styles.text}>
            Language School Croatia delivers professional language training tailored for
            learners in Zagreb and across Croatia. Discover how English lessons and Croatian
            language courses empower your goals.
          </p>
          <p className={styles.legal}>
            &copy; {new Date().getFullYear()} Language School Croatia. All rights reserved.
          </p>
        </div>
        <div className={styles.column}>
          <h4 className={styles.columnSubtitle}>Explore</h4>
          <ul className={styles.linkList}>
            <li><Link to="/courses">Courses</Link></li>
            <li><Link to="/about">About Us</Link></li>
            <li><Link to="/teachers">Teachers</Link></li>
            <li><Link to="/methodology">Methodology</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4 className={styles.columnSubtitle}>Contact</h4>
          <ul className={styles.contactList}>
            <li>
              Language Street 123<br />
              10000 Zagreb, Croatia
            </li>
            <li>
              <a href="tel:+38512345678">+385 1 2345 678</a>
            </li>
            <li>
              <a href="mailto:info@languageschoolcroatia.com">
                info@languageschoolcroatia.com
              </a>
            </li>
          </ul>
          <div className={styles.legalLinks}>
            <Link to="/terms">Terms of Service</Link>
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/cookie-policy">Cookie Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;