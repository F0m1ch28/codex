import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const consent = window.localStorage.getItem('cookieConsent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('cookieConsent', 'accepted');
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="region" aria-label="Cookie consent banner">
      <div className={styles.content}>
        <p className={styles.text}>
          We use cookies to enhance your experience, analyse site performance, and support
          essential functionality. By continuing, you agree to our cookie practices.
        </p>
        <button type="button" className={styles.button} onClick={handleAccept}>
          Accept cookies
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;