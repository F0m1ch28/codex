import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  return (
    <>
      <PageHelmet
        title="Cookie Policy | Language School Croatia"
        description="Cookie Policy for Language School Croatia explaining how cookies are used to support our language school website and services."
        canonical="https://www.languageschoolcroatia.com/cookie-policy"
      />
      <section className={styles.legal}>
        <div className="container">
          <h1>Cookie Policy</h1>
          <p className={styles.updated}>Last updated: January 2024</p>

          <div className={styles.section}>
            <h2>1. What are cookies?</h2>
            <p>
              Cookies are small text files stored on your device when visiting our website. They help us deliver a personalised
              experience and support essential functionality, such as remembering preferences or enabling secure logins.
            </p>
          </div>

          <div className={styles.section}>
            <h2>2. How we use cookies</h2>
            <ul>
              <li>Essential cookies that keep the website functional.</li>
              <li>Performance cookies to analyse anonymous usage and improve services.</li>
              <li>Preference cookies that remember your language or login status for our learning portals.</li>
            </ul>
          </div>

          <div className={styles.section}>
            <h2>3. Managing cookies</h2>
            <p>
              You can adjust cookie preferences through your browser settings. Most browsers allow you to block or delete cookies,
              though doing so may impact access to certain features of Language School Croatia&apos;s platforms.
            </p>
          </div>

          <div className={styles.section}>
            <h2>4. Third-party cookies</h2>
            <p>
              Some cookies may be set by trusted partners providing analytics or embedded learning tools. These partners
              operate under their own privacy and cookie policies.
            </p>
          </div>

          <div className={styles.section}>
            <h2>5. Contact</h2>
            <p>
              For questions regarding this Cookie Policy, contact{' '}
              <a href="mailto:info@languageschoolcroatia.com">info@languageschoolcroatia.com</a>.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;