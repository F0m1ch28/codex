import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Teachers.module.css';

const Teachers = () => {
  const teachers = [
    {
      name: 'Ana Petrović',
      title: 'Head of English Programmes',
      bio: 'CELTA-certified educator with 12 years of experience coaching professionals across finance, tourism, and tech sectors in Croatia.',
      image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Luka Horvat',
      title: 'Lead Croatian Language Mentor',
      bio: 'Specialises in Croatian for expats, delivering immersive cultural workshops that blend language and local customs.',
      image: 'https://images.unsplash.com/photo-1544723795-3fb73c55308c?auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Emily Carter',
      title: 'Business Communication Specialist',
      bio: 'Native English trainer focused on leadership communication, negotiation, and public speaking for executives in Zagreb.',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Marko Babić',
      title: 'Multilingual Programme Designer',
      bio: 'Coordinates German, Italian, and French programmes ensuring blended learning paths for Croatian companies.',
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Ivana Grgić',
      title: 'Academic Success Coach',
      bio: 'Supports learners with personalised study plans, exam strategies, and motivation tracking for long-term progress.',
      image: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Mateo Kovač',
      title: 'Digital Learning Specialist',
      bio: 'Integrates learning technology, analytics, and AI tools to keep online sessions interactive and effective.',
      image: 'https://images.unsplash.com/photo-1549078642-b2da9fda3fc0?auto=format&fit=crop&w=400&q=80',
    },
  ];

  return (
    <>
      <PageHelmet
        title="Teachers | Language School Croatia"
        description="Meet the expert teaching team at Language School Croatia. Our mentors deliver professional language training, English lessons, and Croatian language courses tailored to your goals."
        canonical="https://www.languageschoolcroatia.com/teachers"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Our teaching team</h1>
          <p>
            Language School Croatia brings together passionate teachers who blend international
            credentials with a deep understanding of Croatian culture. Meet the professionals guiding
            your language journey.
          </p>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.grid}>
            {teachers.map((teacher) => (
              <article key={teacher.name} className={styles.card}>
                <img src={teacher.image} alt={teacher.name} />
                <div className={styles.cardContent}>
                  <h3>{teacher.name}</h3>
                  <span className={styles.role}>{teacher.title}</span>
                  <p>{teacher.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.philosophy}>
        <div className="container">
          <div className={styles.philosophyCard}>
            <div>
              <h2>Teaching philosophy</h2>
              <p>
                Our educators believe that learners thrive when lessons are relevant, collaborative,
                and connected to real-life goals. We celebrate progress and adapt quickly when needs change.
              </p>
            </div>
            <div className={styles.philosophyHighlights}>
              <div>
                <h4>Continuous development</h4>
                <p>
                  Teachers participate in regular workshops, peer observations, and international conferences.
                </p>
              </div>
              <div>
                <h4>Inclusive classrooms</h4>
                <p>
                  We create safe, inclusive spaces where every learner feels heard and supported on their path to fluency.
                </p>
              </div>
              <div>
                <h4>Results-driven</h4>
                <p>
                  Structured feedback loops, progress dashboards, and milestone celebrations keep motivation high.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Teachers;