import React, { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  phone: '',
  language: '',
  message: '',
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Please enter your name.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email address.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Please provide a valid email address.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Please let us know about your language goals.';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setIsSubmitted(false);
      return;
    }
    setIsSubmitted(true);
    setFormData(initialFormState);
  };

  return (
    <>
      <PageHelmet
        title="Contact | Language School Croatia"
        description="Contact Language School Croatia for personalised language courses in Croatia. Reach our Zagreb team for English lessons, Croatian language courses, and professional language training."
        canonical="https://www.languageschoolcroatia.com/contact"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Contact our team</h1>
          <p>
            We are here to design the right language solution for you. Share your goals and our advisors
            will respond within one business day.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.infoCard}>
              <h2>Visit or reach us</h2>
              <p>Language School Croatia</p>
              <p>Language Street 123<br />10000 Zagreb, Croatia</p>
              <p>
                <a href="tel:+38512345678">+385 1 2345 678</a><br />
                <a href="mailto:info@languageschoolcroatia.com">info@languageschoolcroatia.com</a>
              </p>
              <div className={styles.infoBox}>
                <h3>Office hours</h3>
                <p>
                  Monday to Friday: 9:00 - 19:00<br />
                  Saturday: 9:00 - 13:00<br />
                  By appointment for corporate trainings
                </p>
              </div>
              <div className={styles.infoBox}>
                <h3>How we can help</h3>
                <ul>
                  <li>Arrange language courses Croatia-wide</li>
                  <li>Plan English lessons for teams or individuals</li>
                  <li>Design Croatian language courses for expats</li>
                  <li>Customise professional language training</li>
                </ul>
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Send us a message</h2>
              {isSubmitted && (
                <div className={styles.successMessage}>
                  Thank you! Our team will reach out shortly to discuss your language goals.
                </div>
              )}
              <div className={styles.fieldGroup}>
                <label htmlFor="name">Full name *</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={Boolean(errors.name)}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="email">Email address *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={Boolean(errors.email)}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="phone">Phone number</label>
                <input
                  id="phone"
                  name="phone"
                  type="text"
                  value={formData.phone}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="language">Preferred language focus</label>
                <select
                  id="language"
                  name="language"
                  value={formData.language}
                  onChange={handleChange}
                >
                  <option value="">Select an option</option>
                  <option value="English lessons">English lessons</option>
                  <option value="Croatian language courses">Croatian language courses</option>
                  <option value="Multilingual">Multilingual programme</option>
                  <option value="Corporate training">Corporate training</option>
                </select>
              </div>
              <div className={styles.fieldGroup}>
                <label htmlFor="message">Tell us about your goals *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={Boolean(errors.message)}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className={styles.submitButton}>
                Send message
              </button>
              <p className={styles.privacyNotice}>
                By submitting, you agree to our <a href="/privacy">Privacy Policy</a> and consent to
                contact regarding language training services.
              </p>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;