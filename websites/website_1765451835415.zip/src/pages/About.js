import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './About.module.css';

const About = () => {
  return (
    <>
      <PageHelmet
        title="About Us | Language School Croatia"
        description="Learn about Language School Croatia, a language school in Zagreb delivering personalised English lessons, Croatian language courses, and multilingual programmes for ambitious learners."
        canonical="https://www.languageschoolcroatia.com/about"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Building bridges through language</h1>
          <p>
            Language School Croatia is a community of educators, linguists, and cultural ambassadors
            committed to helping people learn languages with confidence. From our hub in Zagreb we support
            learners across Croatia and beyond.
          </p>
        </div>
      </section>

      <section className={styles.story}>
        <div className="container">
          <div className={styles.grid}>
            <div>
              <h2>Our story</h2>
              <p>
                Established by a team of Croatian language specialists and international trainers, Language
                School Croatia combines deep cultural knowledge with globally recognised teaching standards.
                We wanted a language school in Zagreb that connects Croatia&apos;s dynamic business environment
                with international opportunities.
              </p>
              <p>
                Today we deliver English lessons, Croatian language courses, and multilingual pathways to
                individuals, companies, and institutions that value results and authentic communication.
              </p>
            </div>
            <div className={styles.timeline}>
              <div className={styles.timelineItem}>
                <span className={styles.year}>2014</span>
                <p>Language School Croatia opens its first classrooms in the heart of Zagreb.</p>
              </div>
              <div className={styles.timelineItem}>
                <span className={styles.year}>2017</span>
                <p>Launch of corporate training programmes for leading Croatian companies.</p>
              </div>
              <div className={styles.timelineItem}>
                <span className={styles.year}>2020</span>
                <p>Hybrid learning model introduced with live online lessons and digital practice labs.</p>
              </div>
              <div className={styles.timelineItem}>
                <span className={styles.year}>2023</span>
                <p>Community outreach initiative supporting language integration for new residents.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2>Our values</h2>
          <div className={styles.valueGrid}>
            <div className={styles.valueCard}>
              <h3>Learner-first mindset</h3>
              <p>
                We tailor every interaction to your goals, ensuring that each lesson has purpose and creates momentum.
              </p>
            </div>
            <div className={styles.valueCard}>
              <h3>Cultural connection</h3>
              <p>
                Language is culture. We celebrate Croatian heritage while enabling learners to communicate globally.
              </p>
            </div>
            <div className={styles.valueCard}>
              <h3>Innovation</h3>
              <p>
                From AI-assisted feedback to interactive classrooms, we explore new tools that enhance learning outcomes.
              </p>
            </div>
            <div className={styles.valueCard}>
              <h3>Community impact</h3>
              <p>
                We partner with schools, NGOs, and businesses to create inclusive spaces where languages are shared.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.community}>
        <div className="container">
          <div className={styles.communityCard}>
            <div>
              <h2>Connected to Croatia</h2>
              <p>
                We take pride in supporting Croatia&apos;s growth by equipping professionals, students, and newcomers
                with language skills that open doors. Our classrooms host learners from Zagreb, Split, Rijeka, Varaždin,
                and international partners who see Croatia as their base.
              </p>
            </div>
            <img
              src="https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=900&q=80"
              alt="Zagreb city view"
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default About;