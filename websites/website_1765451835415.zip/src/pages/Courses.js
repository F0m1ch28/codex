import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Courses.module.css';

const Courses = () => {
  const courseCategories = [
    {
      name: 'Professional English lessons',
      description:
        'Dynamic English programmes for professionals based in Croatia. Build fluency for presentations, negotiation, and cross-cultural collaboration.',
      highlights: [
        'Business English intensives for corporate teams in Zagreb and Rijeka',
        'English for tourism tailored to hospitality and travel professionals',
        'Exam preparation for IELTS, TOEIC, and Cambridge certifications',
        'One-to-one executive coaching focusing on public speaking and leadership',
      ],
    },
    {
      name: 'Croatian language courses',
      description:
        'Practical Croatian language courses designed for expats, international students, and families relocating to Croatia.',
      highlights: [
        'Survival Croatian for everyday communication and essential phrases',
        'Intermediate courses with cultural workshops and city immersions',
        'Family packages supporting school-age learners and parents',
        'Preparation for the Hrvatski Jezik A2/B1 national exams',
      ],
    },
    {
      name: 'Multilingual pathways',
      description:
        'Broaden your horizons with German, Italian, French, or Spanish in programmes tailored to Croatian-based learners.',
      highlights: [
        'German for engineering and manufacturing professionals in northern Croatia',
        'Italian conversation clubs inspired by Adriatic tourism and cuisine',
        'French for EU affairs, diplomacy, and academic exchanges',
        'Spanish language courses for commerce and Latin American trade partners',
      ],
    },
    {
      name: 'Specialised corporate training',
      description:
        'Partner with Language School Croatia to empower your organisation through professional language training built around performance metrics.',
      highlights: [
        'Needs analysis workshops and language benchmarking across departments',
        'Custom-built e-learning libraries branded for your company',
        'On-site and hybrid delivery options for teams across Croatia',
        'Regular reporting on engagement, attendance, and skill growth',
      ],
    },
  ];

  return (
    <>
      <PageHelmet
        title="Courses | Language School Croatia"
        description="Discover English lessons, Croatian language courses, and multilingual programmes across Croatia. Language School Croatia designs professional language training for your goals."
        canonical="https://www.languageschoolcroatia.com/courses"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1 className={styles.title}>Courses crafted for your success</h1>
          <p className={styles.subtitle}>
            Language School Croatia delivers language courses Croatia learners trust.
            Explore flexible formats, personalised coaching, and practical outcomes that help you learn languages with confidence.
          </p>
        </div>
      </section>

      <section className={styles.courseSection}>
        <div className="container">
          <div className={styles.grid}>
            {courseCategories.map((category) => (
              <article key={category.name} className={styles.card}>
                <h2>{category.name}</h2>
                <p>{category.description}</p>
                <ul>
                  {category.highlights.map((highlight) => (
                    <li key={highlight}>{highlight}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.delivery}>
        <div className="container">
          <div className={styles.flex}>
            <div className={styles.flexContent}>
              <h2>Flexible delivery across Croatia</h2>
              <p>
                Combine in-person lessons in Zagreb with remote sessions and digital coaching.
                Whether you are based in Split, Osijek, or travelling internationally, our blended learning
                ensures continuity. Each programme includes milestone reviews to track progress.
              </p>
              <ul className={styles.deliveryList}>
                <li>Small-group classes with a maximum of eight participants</li>
                <li>Hybrid learning hub with live-streamed lessons and recordings</li>
                <li>Task-based projects reflecting your Croatian work or life scenarios</li>
                <li>Dedicated learner success manager for corporate partnerships</li>
              </ul>
            </div>
            <div className={styles.flexMedia}>
              <img
                src="https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=900&q=80"
                alt="Language course participants collaborating"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.callout}>
        <div className="container">
          <div className={styles.calloutCard}>
            <div>
              <h2>Not sure which course fits?</h2>
              <p>
                Schedule a diagnostic session with our academic team. We will recommend English lessons,
                Croatian language courses, or multilingual pathways aligned to your goals in Croatia.
              </p>
            </div>
            <a className={styles.calloutButton} href="mailto:info@languageschoolcroatia.com">
              Email our advisors
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Courses;