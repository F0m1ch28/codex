import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <>
      <PageHelmet
        title="Privacy Policy | Language School Croatia"
        description="Privacy Policy for Language School Croatia outlining how we collect, use, and protect personal data for our language school services in Croatia."
        canonical="https://www.languageschoolcroatia.com/privacy"
      />
      <section className={styles.legal}>
        <div className="container">
          <h1>Privacy Policy</h1>
          <p className={styles.updated}>Last updated: January 2024</p>

          <div className={styles.section}>
            <h2>1. Introduction</h2>
            <p>
              Language School Croatia is committed to protecting your privacy. This policy explains how we collect,
              use, and safeguard personal data in line with applicable Croatian and EU regulations.
            </p>
          </div>

          <div className={styles.section}>
            <h2>2. Data we collect</h2>
            <ul>
              <li>Contact details provided through enquiry forms, emails, or phone calls.</li>
              <li>Assessment results necessary to tailor English lessons or Croatian language courses.</li>
              <li>Attendance records and progress reports for professional language training programmes.</li>
            </ul>
          </div>

          <div className={styles.section}>
            <h2>3. How we use data</h2>
            <ul>
              <li>To deliver language courses Croatia learners enrol in and monitor progress.</li>
              <li>To communicate schedules, updates, and relevant information about our services.</li>
              <li>To improve our curriculum and ensure quality assurance for corporate partners.</li>
            </ul>
          </div>

          <div className={styles.section}>
            <h2>4. Data sharing</h2>
            <p>
              We do not sell personal data. Information may be shared with trusted service providers (e.g., digital
              learning platforms) strictly for service delivery. Any sharing complies with contractual obligations and data protection laws.
            </p>
          </div>

          <div className={styles.section}>
            <h2>5. Data retention</h2>
            <p>
              Personal data is retained for the duration of your learning agreement and for a reasonable period thereafter
              to meet legal obligations or provide course certificates. Upon request, data can be updated or deleted where legally permissible.
            </p>
          </div>

          <div className={styles.section}>
            <h2>6. Your rights</h2>
            <p>
              You may request access to your data, correct inaccuracies, withdraw consent, or request deletion.
              Contact <a href="mailto:info@languageschoolcroatia.com">info@languageschoolcroatia.com</a> to exercise these rights.
            </p>
          </div>

          <div className={styles.section}>
            <h2>7. Security</h2>
            <p>
              We implement technical and organisational measures to protect data against unauthorised access, loss, or misuse.
            </p>
          </div>

          <div className={styles.section}>
            <h2>8. Updates</h2>
            <p>
              This Privacy Policy may be updated periodically. The latest version will always be available on this page.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Privacy;