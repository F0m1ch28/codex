import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';
import styles from './Home.module.css';

const Home = () => {
  const stats = [
    { label: 'Learners empowered', value: '4,800+' },
    { label: 'Industry partners in Croatia', value: '60+' },
    { label: 'Languages coached', value: '8' },
    { label: 'Learner satisfaction', value: '98%' },
  ];

  const featuredCourses = [
    {
      title: 'English Lessons for Professionals',
      description:
        'Develop fluent communication for meetings, negotiations, and global teamwork. Ideal for companies in Zagreb.',
      image: 'https://images.unsplash.com/photo-1529070538774-1843cb3265df?auto=format&fit=crop&w=600&q=80',
      link: '/courses',
    },
    {
      title: 'Croatian Language Courses',
      description:
        'Learn Croatian for life in Croatia with practical conversation, vocabulary, and cultural insights.',
      image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=600&q=80',
      link: '/courses',
    },
    {
      title: 'Multilingual Rapid Learning',
      description:
        'Custom learning paths for German, Italian, and French with blended online and classroom experiences.',
      image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=600&q=80',
      link: '/courses',
    },
  ];

  const testimonials = [
    {
      quote:
        'The professional language training redefined how our team interacts with international clients. The customised English lessons were exactly what we needed.',
      name: 'Martina Kovač, HR Manager',
      image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=200&q=80',
    },
    {
      quote:
        'As an expat in Zagreb, the Croatian language courses made everyday life easier. Teachers are supportive and the methodology works.',
      name: 'Peter Smith, IT Specialist',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80',
    },
    {
      quote:
        'Our hospitality staff improved conversational skills dramatically. Language School Croatia understands tourism needs perfectly.',
      name: 'Ivana Marković, Hotel Director',
      image: 'https://images.unsplash.com/photo-1530023367847-a683933f4177?auto=format&fit=crop&w=200&q=80',
    },
  ];

  const successStories = [
    {
      id: 1,
      category: 'Business',
      title: 'Pharmaceutical team in Zagreb',
      description:
        'Delivered specialised English lessons that enabled confident regulatory presentations across Europe.',
      image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=800&q=80',
    },
    {
      id: 2,
      category: 'Academic',
      title: 'Medical students in Rijeka',
      description:
        'Accelerated English exam prep with blended sessions and speaking labs for international rotations.',
      image: 'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=800&q=80',
    },
    {
      id: 3,
      category: 'Expat',
      title: 'Family relocating to Zagreb',
      description:
        'Immersive Croatian language courses eased integration into Croatian schools and neighbourhood life.',
      image: 'https://images.unsplash.com/photo-1528712306091-ed0763094c98?auto=format&fit=crop&w=800&q=80',
    },
    {
      id: 4,
      category: 'Business',
      title: 'Tourism professionals in Split',
      description:
        'Seasonal English lessons focused on hospitality dialogues and cultural etiquette for visitors.',
      image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80',
    },
  ];

  const filters = ['All', 'Business', 'Academic', 'Expat'];
  const [activeFilter, setActiveFilter] = useState('All');

  const filteredStories =
    activeFilter === 'All'
      ? successStories
      : successStories.filter((story) => story.category === activeFilter);

  const faqItems = [
    {
      id: 'faq1',
      question: 'Which language courses in Croatia are best for my career goals?',
      answer:
        'Our academic team schedules a free consultation to map your goals and proficiency. We then recommend English lessons, Croatian language courses, or multilingual pathways that align with your industry in Croatia.',
    },
    {
      id: 'faq2',
      question: 'Do you offer blended learning options?',
      answer:
        'Yes. Learners combine live sessions in Zagreb with digital practice on our learning platform. Weekly coaching ensures you learn languages efficiently even with a demanding schedule.',
    },
    {
      id: 'faq3',
      question: 'Are courses suitable for absolute beginners?',
      answer:
        'Absolutely. We design foundations for beginners and advanced modules for professionals. Placement diagnostics ensures professional language training starts at the right level.',
    },
  ];

  const [openFaq, setOpenFaq] = useState(faqItems[0].id);

  const toggleFaq = (id) => {
    setOpenFaq((prev) => (prev === id ? null : id));
  };

  return (
    <>
      <PageHelmet
        title="Language School Croatia | Language Courses Croatia & English Lessons"
        description="Learn languages confidently with Language School Croatia. Explore English lessons, Croatian language courses, and professional language training designed for life and work in Croatia."
        canonical="https://www.languageschoolcroatia.com/"
      />
      <section
        className={styles.hero}
        style={{
          backgroundImage:
            'linear-gradient(120deg, rgba(15, 23, 42, 0.78), rgba(37, 99, 235, 0.55)), url("https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=1600&q=80")',
        }}
      >
        <div className="container">
          <div className={styles.heroContent}>
            <h1 className={styles.heroTitle}>
              Language courses in Croatia tailored for ambitious learners
            </h1>
            <p className={styles.heroSubtitle}>
              Language School Croatia partners with professionals, expats, and students to deliver
              English lessons, Croatian language courses, and multilingual programs that unlock real-world success.
            </p>
            <div className={styles.heroActions}>
              <Link to="/courses" className={styles.primaryButton}>
                Explore courses
              </Link>
              <Link to="/contact" className={styles.secondaryButton}>
                Book a consultation
              </Link>
            </div>
            <div className={styles.heroTags}>
              <span>Language courses Croatia</span>
              <span>Language school Zagreb</span>
              <span>Professional language training</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className="container">
          <div className={styles.statGrid}>
            {stats.map((stat) => (
              <div key={stat.label} className={styles.statCard}>
                <div className={styles.statValue}>{stat.value}</div>
                <div className={styles.statLabel}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.courses}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Featured learning journeys</h2>
            <p className={styles.sectionSubtitle}>
              Practical language training for business, study, and everyday life across Croatia.
            </p>
          </div>
          <div className={styles.courseGrid}>
            {featuredCourses.map((course) => (
              <article key={course.title} className={styles.courseCard}>
                <img src={course.image} alt={course.title} className={styles.courseImage} />
                <div className={styles.courseContent}>
                  <h3>{course.title}</h3>
                  <p>{course.description}</p>
                  <Link to={course.link} className={styles.link}>
                    View course details
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Why learn with us?</h2>
            <p className={styles.sectionSubtitle}>
              We connect Croatia’s cultural richness with global communication standards.
            </p>
          </div>
          <div className={styles.benefitGrid}>
            <div className={styles.benefitCard}>
              <h3>Tailored curriculum</h3>
              <p>
                Diagnostic assessments ensure every learner receives a personalised pathway. Whether
                you aim to pass professional certifications or integrate into Croatian life, we guide you.
              </p>
            </div>
            <div className={styles.benefitCard}>
              <h3>Expert mentors</h3>
              <p>
                Our teachers include CELTA-certified trainers, native Croatian linguists, and industry specialists
                with years of experience in Zagreb and the Adriatic region.
              </p>
            </div>
            <div className={styles.benefitCard}>
              <h3>Flexible scheduling</h3>
              <p>
                Choose from in-person sessions in Zagreb, hybrid lessons, or remote coaching that fits busy schedules.
                Evening and weekend options keep learning accessible.
              </p>
            </div>
            <div className={styles.benefitCard}>
              <h3>Measured progress</h3>
              <p>
                Track milestones through regular feedback, proficiency reports, and skill showcases so you can
                confidently learn languages and apply them immediately.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.methodologyHighlight}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Teaching methodology that delivers results</h2>
            <p className={styles.sectionSubtitle}>
              We combine communicative immersion, task-based learning, and digital support for measurable outcomes.
            </p>
          </div>
          <div className={styles.methodologyContent}>
            <div className={styles.methodologyPoints}>
              <div className={styles.methodologyPoint}>
                <span className={styles.pointNumber}>01</span>
                <div>
                  <h3>Immersive communication</h3>
                  <p>
                    Real-life scenarios, role plays, and simulations mirror situations learners face in Croatia and abroad.
                  </p>
                </div>
              </div>
              <div className={styles.methodologyPoint}>
                <span className={styles.pointNumber}>02</span>
                <div>
                  <h3>Data-informed coaching</h3>
                  <p>
                    Continuous assessment informs personalised assignments, ensuring rapid progress across all skills.
                  </p>
                </div>
              </div>
              <div className={styles.methodologyPoint}>
                <span className={styles.pointNumber}>03</span>
                <div>
                  <h3>Culture & confidence</h3>
                  <p>
                    Understand Croatian etiquette, business norms, and everyday expressions that make communication natural.
                  </p>
                </div>
              </div>
            </div>
            <div className={styles.methodologyMedia}>
              <img
                src="https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=700&q=80"
                alt="Language coaching session in Zagreb"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Your learning journey</h2>
            <p className={styles.sectionSubtitle}>
              A streamlined process built for busy professionals and motivated learners.
            </p>
          </div>
          <ol className={styles.processSteps}>
            <li className={styles.processStep}>
              <span className={styles.stepBadge}>Step 1</span>
              <h3>Consult & diagnose</h3>
              <p>Book a free consultation to map your goals, schedule, and target proficiency levels.</p>
            </li>
            <li className={styles.processStep}>
              <span className={styles.stepBadge}>Step 2</span>
              <h3>Custom programme</h3>
              <p>Receive a learning plan combining English lessons, Croatian language courses, or multilingual tracks.</p>
            </li>
            <li className={styles.processStep}>
              <span className={styles.stepBadge}>Step 3</span>
              <h3>Coached practice</h3>
              <p>Participate in live workshops, digital modules, and feedback checkpoints each week.</p>
            </li>
            <li className={styles.processStep}>
              <span className={styles.stepBadge}>Step 4</span>
              <h3>Showcase progress</h3>
              <p>Share presentations, pass internal exams, and celebrate milestones recognised by Croatian employers.</p>
            </li>
          </ol>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Voices from our learners</h2>
            <p className={styles.sectionSubtitle}>
              Discover how Language School Croatia turns ambitions into fluent communication.
            </p>
          </div>
          <div className={styles.testimonialGrid}>
            {testimonials.map((item) => (
              <article key={item.name} className={styles.testimonialCard}>
                <img src={item.image} alt={item.name} className={styles.testimonialImage} />
                <p className={styles.quote}>&ldquo;{item.quote}&rdquo;</p>
                <p className={styles.person}>{item.name}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.successStories}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Success stories across Croatia</h2>
            <p className={styles.sectionSubtitle}>
              Explore how learners use professional language training to thrive in business, academics, and community life.
            </p>
          </div>
          <div className={styles.filterBar}>
            {filters.map((filter) => (
              <button
                key={filter}
                type="button"
                className={`${styles.filterButton} ${
                  activeFilter === filter ? styles.filterActive : ''
                }`}
                aria-pressed={activeFilter === filter}
                onClick={() => setActiveFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.storyGrid}>
            {filteredStories.map((story) => (
              <article key={story.id} className={styles.storyCard}>
                <img src={story.image} alt={story.title} className={styles.storyImage} />
                <div className={styles.storyContent}>
                  <span className={styles.storyCategory}>{story.category}</span>
                  <h3>{story.title}</h3>
                  <p>{story.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Frequently asked questions</h2>
            <p className={styles.sectionSubtitle}>
              Everything you need to know about our language school in Zagreb.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item) => (
              <div key={item.id} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqQuestion}
                  onClick={() => toggleFaq(item.id)}
                  aria-expanded={openFaq === item.id}
                  aria-controls={`${item.id}-content`}
                >
                  {item.question}
                  <span className={styles.faqIcon}>{openFaq === item.id ? '−' : '+'}</span>
                </button>
                {openFaq === item.id && (
                  <div id={`${item.id}-content`} className={styles.faqAnswer}>
                    <p>{item.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Insights from our language experts</h2>
            <p className={styles.sectionSubtitle}>
              Stay informed with practical tips on how to learn languages efficiently in Croatia.
            </p>
          </div>
          <div className={styles.blogGrid}>
            <article className={styles.blogCard}>
              <img
                src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=800&q=80"
                alt="Learners collaborating in a classroom"
              />
              <div>
                <span className={styles.blogTag}>Professional insight</span>
                <h3>Designing business English lessons for Croatian companies</h3>
                <p>
                  Discover how strategic vocabulary, role-play scenarios, and feedback loops elevate corporate communication.
                </p>
                <Link to="/methodology" className={styles.link}>
                  Learn more
                </Link>
              </div>
            </article>
            <article className={styles.blogCard}>
              <img
                src="https://images.unsplash.com/photo-1529078155058-5d716f45d604?auto=format&fit=crop&w=800&q=80"
                alt="Student practicing language skills"
              />
              <div>
                <span className={styles.blogTag}>Learner journey</span>
                <h3>How expats master Croatian language courses in 12 weeks</h3>
                <p>
                  A step-by-step plan that balances grammar foundations with cultural immersion around Zagreb.
                </p>
                <Link to="/courses" className={styles.link}>
                  Explore courses
                </Link>
              </div>
            </article>
            <article className={styles.blogCard}>
              <img
                src="https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=800&q=80"
                alt="Teacher leading a methodology workshop"
              />
              <div>
                <span className={styles.blogTag}>Methodology</span>
                <h3>Integrating digital platforms into language school training</h3>
                <p>
                  See how hybrid sessions and analytics keep learners accountable while maintaining human connection.
                </p>
                <Link to="/methodology" className={styles.link}>
                  View methodology
                </Link>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Ready to learn languages with confidence?</h2>
              <p>
                Connect with Language School Croatia for a personalised consultation. Together we will design
                English lessons, Croatian language courses, or multilingual programmes that meet your goals.
              </p>
            </div>
            <Link to="/contact" className={styles.ctaButton}>
              Start your journey
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;