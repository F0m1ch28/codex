import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Methodology.module.css';

const Methodology = () => {
  return (
    <>
      <PageHelmet
        title="Methodology | Language School Croatia"
        description="Discover the teaching methodology behind Language School Croatia. We blend communicative practice, data-driven coaching, and cultural immersion to support language learning in Croatia."
        canonical="https://www.languageschoolcroatia.com/methodology"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Methodology designed for impact</h1>
          <p>
            Our teaching approach blends proven pedagogies with learner-centred innovation. We guide you to learn
            languages effectively while remaining confident in real-world situations across Croatia and beyond.
          </p>
        </div>
      </section>

      <section className={styles.principles}>
        <div className="container">
          <div className={styles.grid}>
            <article className={styles.card}>
              <h2>Communicative immersion</h2>
              <p>
                Lessons are rooted in authentic communication. Role-plays, debates, and simulations replicate meetings,
                travel encounters, and social interactions you experience in Croatia.
              </p>
            </article>
            <article className={styles.card}>
              <h2>Task-based learning</h2>
              <p>
                Each module concludes with a task—presentation, negotiation, or cultural interview—allowing you to apply
                new vocabulary and grammar with purpose.
              </p>
            </article>
            <article className={styles.card}>
              <h2>Adaptive feedback</h2>
              <p>
                Weekly coaching sessions, analytics dashboards, and reflective journals help you internalise progress
                and adjust goals.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.pipeline}>
        <div className="container">
          <div className={styles.pipelineHeader}>
            <h2>Our learning pipeline</h2>
            <p>
              Professional language training should be systematic. We align diagnostics, planning, delivery, and review
              so your learning path remains transparent and motivating.
            </p>
          </div>
          <div className={styles.pipelineSteps}>
            <div className={styles.step}>
              <span className={styles.stepNumber}>01</span>
              <h3>Diagnostics</h3>
              <p>
                Benchmark your skills through speaking interviews, grammar analysis, and comprehension tasks aligned
                with CEFR standards.
              </p>
            </div>
            <div className={styles.step}>
              <span className={styles.stepNumber}>02</span>
              <h3>Design</h3>
              <p>
                Collaborate with our academic team to create a curriculum emphasising industry vocabulary and
                sociolinguistic awareness of Croatia.
              </p>
            </div>
            <div className={styles.step}>
              <span className={styles.stepNumber}>03</span>
              <h3>Delivery</h3>
              <p>
                Alternate interactive classroom sessions with personalised coaching and digital practice labs.
              </p>
            </div>
            <div className={styles.step}>
              <span className={styles.stepNumber}>04</span>
              <h3>Review</h3>
              <p>
                Track progress with quarterly assessments, learner showcases, and stakeholder feedback for corporate programmes.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.support}>
        <div className="container">
          <div className={styles.supportCard}>
            <img
              src="https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=900&q=80"
              alt="Teacher guiding a student during a language lesson"
            />
            <div className={styles.supportContent}>
              <h2>Support ecosystem</h2>
              <p>
                Beyond the classroom, you gain access to conversation clubs, pronunciation clinics, and community
                events in Zagreb that help you maintain momentum. Mentors are available for office hours
                and our online platform offers curated practice extending your learning time.
              </p>
              <ul>
                <li>Weekly pronunciation and fluency labs</li>
                <li>Digital platform with AI-powered feedback</li>
                <li>Peer study groups and themed conversation evenings</li>
                <li>Progress reports mapped to CEFR levels and corporate KPIs</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Methodology;