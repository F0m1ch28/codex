import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Terms.module.css';

const Terms = () => {
  return (
    <>
      <PageHelmet
        title="Terms of Service | Language School Croatia"
        description="Read the Terms of Service for Language School Croatia covering course registration, responsibilities, and service use for language training in Croatia."
        canonical="https://www.languageschoolcroatia.com/terms"
      />
      <section className={styles.legal}>
        <div className="container">
          <h1>Terms of Service</h1>
          <p className={styles.updated}>Last updated: January 2024</p>

          <div className={styles.section}>
            <h2>1. Overview</h2>
            <p>
              These Terms of Service govern the use of language courses and related services provided by Language School Croatia.
              By enrolling in a course, accessing our digital platforms, or communicating with our team, you agree to these terms.
            </p>
          </div>

          <div className={styles.section}>
            <h2>2. Registration</h2>
            <ul>
              <li>Course registration is confirmed once we receive your enrolment form and written confirmation from our team.</li>
              <li>Language School Croatia reserves the right to request placement assessments before confirming a course level.</li>
              <li>For corporate programmes, a signed agreement outlining deliverables and schedules is required.</li>
            </ul>
          </div>

          <div className={styles.section}>
            <h2>3. Learner responsibilities</h2>
            <ul>
              <li>Attend scheduled lessons on time and inform us of any absences at least 24 hours in advance.</li>
              <li>Engage with assigned materials and complete tasks that support learning progress.</li>
              <li>Respect fellow learners, teachers, and Language School Croatia facilities at all times.</li>
            </ul>
          </div>

          <div className={styles.section}>
            <h2>4. Service changes</h2>
            <p>
              We may adjust lesson schedules, formats, or trainers if necessary to ensure the quality of professional language training.
              In the case of significant changes, learners will be notified promptly and alternative arrangements offered.
            </p>
          </div>

          <div className={styles.section}>
            <h2>5. Intellectual property</h2>
            <p>
              Course materials, lesson recordings, and digital resources are proprietary to Language School Croatia.
              Learners may use them for personal study only and must not redistribute without written permission.
            </p>
          </div>

          <div className={styles.section}>
            <h2>6. Liability</h2>
            <p>
              Language School Croatia is not liable for personal belongings or outcomes outside the scope of agreed training objectives.
              We strive to provide accurate information, yet make no guarantees regarding third-party services linked during training.
            </p>
          </div>

          <div className={styles.section}>
            <h2>7. Contact</h2>
            <p>
              Questions regarding these terms can be directed to{' '}
              <a href="mailto:info@languageschoolcroatia.com">info@languageschoolcroatia.com</a>.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Terms;