document.addEventListener('DOMContentLoaded', () => {
    if ('scrollRestoration' in history) {
        history.scrollRestoration = 'manual';
    }
    window.scrollTo(0, 0);

    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    navToggle?.addEventListener('click', () => {
        const expanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', String(!expanded));
        navLinks.classList.toggle('open');
    });

    navLinks?.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('open');
            navToggle?.setAttribute('aria-expanded', 'false');
        });
    });

    const scrollTopBtn = document.getElementById('scrollTopBtn');
    const toggleScrollButton = () => {
        if (window.scrollY > 220) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    };
    window.addEventListener('scroll', toggleScrollButton);
    scrollTopBtn?.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    const contactForm = document.querySelector('.contact-form');
    const newsletterForm = document.querySelector('.newsletter-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const messageBox = contactForm.querySelector('.form-message');
            messageBox.textContent = '¡Gracias! Hemos recibido tu mensaje y nos pondremos en contacto muy pronto.';
            contactForm.reset();
        });
    }
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const success = document.createElement('p');
            success.className = 'form-message';
            success.textContent = 'Suscripción confirmada. Revisa tu correo para comenzar a recibir inspiración.';
            newsletterForm.after(success);
            newsletterForm.reset();
        });
    }

    const footerYear = document.getElementById('year');
    if (footerYear) {
        footerYear.textContent = new Date().getFullYear();
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const cookieKey = 'vidaCookieConsent';
    if (cookieBanner && !localStorage.getItem(cookieKey)) {
        cookieBanner.classList.add('show');
    }
    acceptCookiesBtn?.addEventListener('click', () => {
        localStorage.setItem(cookieKey, 'accepted');
        cookieBanner.classList.remove('show');
    });
});