document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');
  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', function () {
      primaryNav.classList.toggle('nav-open');
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptCookies = document.getElementById('accept-cookies');
  const declineCookies = document.getElementById('decline-cookies');
  const storedPreference = localStorage.getItem('canoryxCookiePreference');

  if (cookieBanner) {
    if (!storedPreference) {
      cookieBanner.classList.add('active');
    }
    if (acceptCookies) {
      acceptCookies.addEventListener('click', function () {
        localStorage.setItem('canoryxCookiePreference', 'accepted');
        cookieBanner.classList.remove('active');
      });
    }
    if (declineCookies) {
      declineCookies.addEventListener('click', function () {
        localStorage.setItem('canoryxCookiePreference', 'declined');
        cookieBanner.classList.remove('active');
      });
    }
  }

  const redirectMap = {
    '/history': 'archives.html',
    '/history/': 'archives.html',
    '/infrastructure': 'exposure.html',
    '/infrastructure/': 'exposure.html',
    '/systems': 'frameworks.html',
    '/systems/': 'frameworks.html',
    '/resilience': 'contexts.html',
    '/resilience/': 'contexts.html'
  };

  const path = window.location.pathname.toLowerCase();
  if (redirectMap[path]) {
    window.location.replace(redirectMap[path]);
  }

  const yearTarget = document.querySelector('[data-current-year]');
  if (yearTarget) {
    yearTarget.textContent = new Date().getFullYear().toString();
  }
});