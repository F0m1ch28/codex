(function () {
  const COOKIE_KEY = 'aov_cookie_consent';

  function formatTime(seconds) {
    if (isNaN(seconds)) return '00:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }

  document.addEventListener('DOMContentLoaded', function () {
    const banners = document.querySelectorAll('[data-cookie-banner]');
    const storedConsent = localStorage.getItem(COOKIE_KEY);

    function showBanners() {
      banners.forEach(banner => banner.classList.add('is-visible'));
    }

    function hideBanners() {
      banners.forEach(banner => banner.classList.remove('is-visible'));
    }

    if (!storedConsent) {
      showBanners();
    }

    document.querySelectorAll('[data-cookie-accept]').forEach(button => {
      button.addEventListener('click', () => {
        localStorage.setItem(COOKIE_KEY, 'accepted');
        hideBanners();
      });
    });

    document.querySelectorAll('[data-cookie-decline]').forEach(button => {
      button.addEventListener('click', () => {
        localStorage.setItem(COOKIE_KEY, 'declined');
        hideBanners();
      });
    });

    document.querySelectorAll('[data-video-player]').forEach(player => {
      const video = player.querySelector('video');
      const playButton = player.querySelector('[data-action="toggle-play"]');
      const muteButton = player.querySelector('[data-action="toggle-mute"]');
      const volumeSlider = player.querySelector('.volume-slider');
      const progressBar = player.querySelector('.video-progress span');
      const currentTimeEl = player.querySelector('[data-time-current]');
      const durationEl = player.querySelector('[data-time-duration]');

      function updatePlayButton() {
        if (video.paused) {
          playButton.textContent = '▶ Assistir';
        } else {
          playButton.textContent = '⏸ Pausar';
        }
      }

      function updateMuteButton() {
        muteButton.textContent = video.muted ? '🔇 Mutado' : '🔈 Som';
      }

      function updateProgress() {
        if (!progressBar) return;
        const percent = (video.currentTime / video.duration) * 100;
        progressBar.style.width = `${percent || 0}%`;
        if (currentTimeEl) currentTimeEl.textContent = formatTime(video.currentTime);
      }

      video.addEventListener('loadedmetadata', () => {
        if (durationEl) durationEl.textContent = formatTime(video.duration);
      });

      playButton?.addEventListener('click', () => {
        if (video.paused) {
          video.play();
        } else {
          video.pause();
        }
      });

      video.addEventListener('play', updatePlayButton);
      video.addEventListener('pause', updatePlayButton);

      muteButton?.addEventListener('click', () => {
        video.muted = !video.muted;
        updateMuteButton();
      });

      volumeSlider?.addEventListener('input', event => {
        video.volume = parseFloat(event.target.value);
        if (video.volume === 0) {
          video.muted = true;
        } else {
          video.muted = false;
        }
        updateMuteButton();
      });

      video.addEventListener('timeupdate', updateProgress);
      video.addEventListener('volumechange', updateMuteButton);

      updatePlayButton();
      updateMuteButton();
      updateProgress();
    });

    document.querySelectorAll('[data-search-form]').forEach(form => {
      form.addEventListener('submit', event => {
        event.preventDefault();
        const input = form.querySelector('input[name="q"]');
        const query = input ? input.value.trim() : '';
        if (query.length) {
          alert(`Funcionalidade em desenvolvimento. Em breve você poderá buscar por: "${query}".`);
        } else {
          alert('Digite um termo para buscar vídeos. Em breve teremos recomendações personalizadas.');
        }
      });
    });

    const filterContainer = document.querySelector('[data-video-filter]');
    if (filterContainer) {
      const videoList = document.querySelector('[data-video-list]');
      const cards = videoList ? Array.from(videoList.querySelectorAll('[data-video-card]')) : [];
      const categorySelect = filterContainer.querySelector('select[name="categoria"]');
      const sortSelect = filterContainer.querySelector('select[name="ordenar"]');
      const searchInput = filterContainer.querySelector('input[type="search"]');

      function applyFilters() {
        const category = categorySelect?.value || 'all';
        const sort = sortSelect?.value || 'recentes';
        const search = (searchInput?.value || '').trim().toLowerCase();

        let filtered = cards.slice();

        filtered.forEach(card => {
          const matchesCategory = category === 'all' || card.dataset.category === category;
          const matchesSearch = !search || card.querySelector('.card-title').textContent.toLowerCase().includes(search);
          card.style.display = (matchesCategory && matchesSearch) ? '' : 'none';
        });

        const visibleCards = filtered.filter(card => card.style.display !== 'none');

        visibleCards.sort((a, b) => {
          const durationA = parseFloat(a.dataset.duration || '0');
          const durationB = parseFloat(b.dataset.duration || '0');
          const dateA = new Date(a.dataset.date || '1970-01-01');
          const dateB = new Date(b.dataset.date || '1970-01-01');

          switch (sort) {
            case 'antigos':
              return dateA - dateB;
            case 'curtos':
              return durationA - durationB;
            case 'longos':
              return durationB - durationA;
            case 'recentes':
            default:
              return dateB - dateA;
          }
        });

        if (videoList) {
          visibleCards.forEach(card => videoList.appendChild(card));
        }
      }

      categorySelect?.addEventListener('change', applyFilters);
      sortSelect?.addEventListener('change', applyFilters);
      searchInput?.addEventListener('input', () => {
        window.clearTimeout(searchInput._debounce);
        searchInput._debounce = window.setTimeout(applyFilters, 200);
      });

      applyFilters();
    }
  });
})();