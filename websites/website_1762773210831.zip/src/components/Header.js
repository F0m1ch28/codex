import React, { useEffect, useState } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';

const navigation = [
  { path: '/', label: 'Home' },
  { path: '/funktionen', label: 'Funktionen' },
  { path: '/tools', label: 'Tools' },
  { path: '/ratgeber', label: 'Ratgeber' },
  { path: '/blog', label: 'Blog' },
  { path: '/about', label: 'Über uns' },
  { path: '/contact', label: 'Kontakt' }
];

const Header = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        scrolled ? 'bg-white/95 backdrop-blur shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 md:px-6">
        <Link to="/" className="flex items-center gap-3 text-lg font-heading font-semibold text-primary">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10 text-accent">
            FB
          </span>
          <span className="leading-tight">
            FamilienBudget
            <span className="block text-sm font-body text-slate-500">
              Klarheit für Familienfinanzen
            </span>
          </span>
        </Link>
        <nav className="hidden items-center gap-6 lg:flex">
          {navigation.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `text-sm font-medium transition-colors duration-200 ${
                  isActive ? 'text-accent' : 'text-slate-600 hover:text-accent'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
          <Link
            to="/funktionen"
            className="btn-primary hidden rounded-full px-5 py-2 text-sm font-semibold text-white shadow-soft lg:inline-flex"
          >
            Jetzt Budget starten
          </Link>
        </nav>
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="inline-flex items-center justify-center rounded-full bg-white px-4 py-2 text-sm font-semibold text-accent shadow-soft lg:hidden"
          aria-label="Navigation umschalten"
        >
          <span className="font-heading">{mobileOpen ? 'Schließen' : 'Menü'}</span>
        </button>
      </div>

      <div
        className={`lg:hidden ${mobileOpen ? 'max-h-screen' : 'max-h-0'} overflow-hidden bg-white transition-all duration-300`}
      >
        <nav className="space-y-3 px-4 pb-6">
          {navigation.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `block rounded-lg px-4 py-3 text-sm font-semibold transition-colors ${
                  isActive
                    ? 'bg-accent/10 text-accent'
                    : 'text-slate-600 hover:bg-light hover:text-accent'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
          <Link
            to="/funktionen"
            className="block rounded-full bg-accent px-4 py-3 text-center text-sm font-semibold text-white"
          >
            Jetzt Budget starten
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;