import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('familienbudget_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('familienbudget_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="fixed inset-x-0 bottom-4 z-[90] px-4">
      <div className="mx-auto max-w-4xl rounded-2xl bg-white p-6 shadow-soft ring-1 ring-light">
        <div className="flex flex-col items-start gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h3 className="text-sm font-semibold text-primary">
              Wir verwenden Cookies
            </h3>
            <p className="mt-1 text-sm text-slate-600">
              Wir nutzen Cookies, um Funktionen zu ermöglichen und anonyme Statistiken zu erheben.
              Details findest du in unserer{' '}
              <Link to="/cookies" className="font-semibold text-accent underline">
                Cookie-Richtlinie
              </Link>
              .
            </p>
          </div>
          <div className="flex w-full items-center gap-3 md:w-auto">
            <Link
              to="/policy"
              className="w-full rounded-full border border-light px-5 py-2 text-center text-sm font-semibold text-primary md:w-auto"
            >
              Mehr erfahren
            </Link>
            <button
              onClick={handleAccept}
              className="w-full rounded-full bg-accent px-6 py-2 text-sm font-semibold text-white shadow-soft transition hover:bg-accent/90 md:w-auto"
            >
              Akzeptieren
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;