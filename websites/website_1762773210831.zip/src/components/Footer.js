import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-light bg-white">
      <div className="mx-auto max-w-7xl px-4 py-14 md:px-6">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link to="/" className="text-lg font-heading font-semibold text-primary">
              FamilienBudget
            </Link>
            <p className="mt-4 text-sm text-slate-600">
              Wir geben Familien in Deutschland Werkzeuge an die Hand, um Haushaltsbuch,
              Fixkosten, Rücklagen und Sparziele sicher zu steuern.
            </p>
            <div className="mt-4 flex items-center gap-3 text-sm text-slate-500">
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="hover:text-accent"
              >
                LinkedIn
              </a>
              <a
                href="https://www.instagram.com"
                target="_blank"
                rel="noreferrer"
                className="hover:text-accent"
              >
                Instagram
              </a>
              <a
                href="https://www.youtube.com"
                target="_blank"
                rel="noreferrer"
                className="hover:text-accent"
              >
                YouTube
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
              Plattform
            </h4>
            <ul className="mt-4 space-y-3 text-sm text-slate-600">
              <li>
                <Link to="/funktionen" className="hover:text-accent">
                  Funktionen & Haushaltsbuch
                </Link>
              </li>
              <li>
                <Link to="/tools" className="hover:text-accent">
                  Rechner & Vorlagen
                </Link>
              </li>
              <li>
                <Link to="/ratgeber" className="hover:text-accent">
                  Ratgeber & Leitfäden
                </Link>
              </li>
              <li>
                <Link to="/blog" className="hover:text-accent">
                  Blog & Insights
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
              Unternehmen
            </h4>
            <ul className="mt-4 space-y-3 text-sm text-slate-600">
              <li>
                <Link to="/about" className="hover:text-accent">
                  Über FamilienBudget
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-accent">
                  Kontakt & Beratung
                </Link>
              </li>
              <li>
                <Link to="/faq" className="hover:text-accent">
                  Häufige Fragen
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
              Rechtliches
            </h4>
            <ul className="mt-4 space-y-3 text-sm text-slate-600">
              <li>
                <Link to="/terms" className="hover:text-accent">
                  Nutzungsbedingungen
                </Link>
              </li>
              <li>
                <Link to="/policy" className="hover:text-accent">
                  Datenschutz
                </Link>
              </li>
              <li>
                <Link to="/cookies" className="hover:text-accent">
                  Cookie-Richtlinie
                </Link>
              </li>
              <li>
                <Link to="/impressum" className="hover:text-accent">
                  Impressum
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-light pt-6 text-xs text-slate-500 md:flex md:items-center md:justify-between">
          <p>© {year} FamilienBudget. Alle Rechte vorbehalten.</p>
          <p>Made for Familien, die ihre Finanzen lieben.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;