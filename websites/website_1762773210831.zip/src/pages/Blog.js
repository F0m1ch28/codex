import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import blogPosts from '../data/blogPosts';

const Blog = () => {
  return (
    <>
      <Helmet>
        <title>Blog – Budgetplanung, Notgroschen & Kontenmodelle</title>
        <meta
          name="description"
          content="FamilienBudget Blog: Praxisnahe Artikel zu Haushaltsbuch, Budgetplanung, Notgroschen, Kontenmodellen und Schuldenabbau in Deutschland."
        />
        <meta
          name="keywords"
          content="Blog Familienfinanzen, Haushaltsbuch, Budgetplanung, Notgroschen, Kontenmodell"
        />
        <meta property="og:title" content="FamilienBudget Blog" />
        <meta
          property="og:description"
          content="Aktuelle Beiträge über Familienfinanzen, Budgettipps, Schuldenabbau und Rücklagen."
        />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=901" />
        <link rel="canonical" href="https://familienbudget.de/blog" />
      </Helmet>

      <section className="relative bg-primary py-20 text-white">
        <img
          src="https://picsum.photos/1600/900?random=902"
          alt="Blogartikel zu Familienfinanzen"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
        />
        <div className="relative mx-auto max-w-4xl px-4 text-center">
          <h1 className="text-3xl font-heading font-semibold md:text-4xl">
            Insights für stabile Familienfinanzen
          </h1>
          <p className="mt-4 text-sm text-slate-200 md:text-base">
            Praxisnahe Artikel aus Budgetplanung, Rücklagen, Kontenmodellen und Spartipps. Jede Woche
            neu aus der Finanzpraxis für Familien in Deutschland.
          </p>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-6xl py-16">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {blogPosts.map((post) => (
            <article
              key={post.slug}
              className="card-hover overflow-hidden rounded-3xl border border-light bg-white shadow-soft"
            >
              <img
                src={post.heroImage}
                alt={post.title}
                className="h-48 w-full object-cover"
                loading="lazy"
              />
              <div className="p-6">
                <span className="tag-pill">{post.tags[0]}</span>
                <h2 className="mt-4 text-lg font-semibold text-primary">{post.title}</h2>
                <p className="mt-3 text-sm text-slate-600">{post.excerpt}</p>
                <div className="mt-4 flex items-center justify-between text-xs text-slate-500">
                  <span>{post.date}</span>
                  <span>{post.readTime}</span>
                </div>
                <Link
                  to={`/blog/${post.slug}`}
                  className="mt-4 inline-flex text-sm font-semibold text-accent"
                >
                  Weiterlesen →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Blog;