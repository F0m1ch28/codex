import React from 'react';
import { Helmet } from 'react-helmet';

const Terms = () => (
  <>
    <Helmet>
      <title>Nutzungsbedingungen – FamilienBudget</title>
      <meta
        name="description"
        content="Nutzungsbedingungen von FamilienBudget: Vertragsgegenstand, Leistungen, Haftung und Schlussbestimmungen."
      />
      <meta property="og:title" content="Nutzungsbedingungen FamilienBudget" />
      <meta property="og:image" content="https://picsum.photos/1200/630?random=1201" />
      <link rel="canonical" href="https://familienbudget.de/terms" />
    </Helmet>

    <section className="container-padding mx-auto max-w-4xl py-20">
      <h1 className="text-3xl font-heading font-semibold text-primary">Nutzungsbedingungen</h1>
      <p className="mt-4 text-sm text-slate-600">
        Diese Nutzungsbedingungen regeln die Verwendung der Plattform FamilienBudget. Mit der
        Registrierung akzeptierst du die folgenden Bestimmungen.
      </p>

      <div className="mt-10 space-y-6 text-sm text-slate-600">
        <section>
          <h2 className="font-semibold text-primary">1. Vertragsgegenstand</h2>
          <p>
            FamilienBudget stellt digitale Werkzeuge für Haushaltsbuch, Budgetplanung, Notgroschen,
            Finanzziele sowie Informationsangebote bereit. Die Nutzung erfolgt ausschließlich zu
            privaten Zwecken.
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">2. Registrierung & Zugang</h2>
          <p>
            Für Premium-Funktionen ist eine Registrierung erforderlich. Du bist verpflichtet,
            Zugangsdaten geheim zu halten und missbräuchliche Nutzung unverzüglich zu melden.
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">3. Leistungen</h2>
          <p>
            Die Plattform bietet Haushaltsbuchfunktionen, Rechner, Vorlagen und Beratung.
            Anpassungen und Erweiterungen sind möglich. Wir informieren dich über wesentliche Änderungen.
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">4. Haftung</h2>
          <p>
            FamilienBudget übernimmt keine Garantie für zukünftige finanzielle Entwicklungen.
            Entscheidungen triffst du eigenverantwortlich. Wir haften für Vorsatz und grobe Fahrlässigkeit,
            bei Verletzung wesentlicher Pflichten begrenzt auf vertragstypische Schäden.
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">5. Kündigung & Laufzeit</h2>
          <p>
            Kostenfreie Accounts können jederzeit gelöscht werden. Kostenpflichtige Abos sind mit Frist zum Monatsende kündbar,
            sofern nichts anderes vereinbart wurde.
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">6. Schlussbestimmungen</h2>
          <p>
            Es gilt deutsches Recht. Gerichtsstand ist Berlin. Sollten einzelne Klauseln unwirksam sein,
            bleibt der Vertrag im Übrigen wirksam.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default Terms;