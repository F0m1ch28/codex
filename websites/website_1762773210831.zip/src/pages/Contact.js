import React, { useState } from 'react';
import { Helmet } from 'react-helmet';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    familySize: '',
    topic: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Bitte Vor- und Nachname angeben.';
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim() || !emailRegex.test(formData.email))
      newErrors.email = 'Bitte eine gültige E-Mail-Adresse angeben.';
    if (!formData.topic.trim()) newErrors.topic = 'Bitte Anliegen auswählen.';
    if (formData.message.trim().length < 20)
      newErrors.message = 'Bitte beschreibe dein Anliegen mit mindestens 20 Zeichen.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      setStatus('');
    } else {
      setErrors({});
      setStatus('Danke! Wir melden uns innerhalb von zwei Werktagen bei dir.');
      setFormData({
        name: '',
        email: '',
        familySize: '',
        topic: '',
        message: ''
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt – Beratung & Support für FamilienBudget</title>
        <meta
          name="description"
          content="Nimm Kontakt zu FamilienBudget auf: individuelles Coaching, Workshops, Fragen zum Haushaltsbuch oder zu unseren Tools."
        />
        <meta name="keywords" content="Kontakt, Finanzberatung, Familienfinanzen, Haushaltsbuch" />
        <meta property="og:title" content="Kontakt FamilienBudget" />
        <meta
          property="og:description"
          content="Buche eine kostenfreie Erstberatung und erfahre, wie FamilienBudget dein Haushaltsbuch und Sparziele unterstützt."
        />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=1001" />
        <link rel="canonical" href="https://familienbudget.de/contact" />
      </Helmet>

      <section className="relative bg-primary py-20 text-white">
        <img
          src="https://picsum.photos/1600/900?random=1002"
          alt="Beratungsgespräch zu Familienfinanzen"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
        />
        <div className="relative mx-auto max-w-4xl px-4 text-center">
          <h1 className="text-3xl font-heading font-semibold md:text-4xl">
            Lass uns über eure Familienfinanzen sprechen
          </h1>
          <p className="mt-4 text-sm text-slate-200 md:text-base">
            Kostenfreie Erstberatung, individuelle Budgetbegleitung oder Fragen zu unseren Tools – wir sind für dich da.
          </p>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-5xl py-16">
        <div className="grid gap-10 lg:grid-cols-[1fr_320px]">
          <form
            onSubmit={handleSubmit}
            className="rounded-3xl bg-white p-8 shadow-soft"
            noValidate
          >
            <h2 className="text-2xl font-heading font-semibold text-primary">
              Kontaktformular
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Wir antworten in der Regel innerhalb von 48 Stunden und schlagen einen Termin für das Erstgespräch vor.
            </p>

            <div className="mt-6 space-y-4">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
                Name *
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="mt-2 w-full rounded-2xl border border-light px-4 py-3 text-sm focus:border-accent focus:outline-none"
                  placeholder="Vor- und Nachname"
                />
                {errors.name && <span className="mt-1 block text-xs text-accent">{errors.name}</span>}
              </label>

              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
                E-Mail *
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="mt-2 w-full rounded-2xl border border-light px-4 py-3 text-sm focus:border-accent focus:outline-none"
                  placeholder="E-Mail-Adresse"
                />
                {errors.email && <span className="mt-1 block text-xs text-accent">{errors.email}</span>}
              </label>

              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
                Familiengröße
                <input
                  type="number"
                  min="1"
                  value={formData.familySize}
                  onChange={(e) => setFormData({ ...formData, familySize: e.target.value })}
                  className="mt-2 w-full rounded-2xl border border-light px-4 py-3 text-sm focus:border-accent focus:outline-none"
                  placeholder="Anzahl Personen im Haushalt"
                />
              </label>

              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
                Anliegen *
                <select
                  value={formData.topic}
                  onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                  className="mt-2 w-full rounded-2xl border border-light px-4 py-3 text-sm focus:border-accent focus:outline-none"
                >
                  <option value="">Bitte auswählen</option>
                  <option value="beratung">Individuelle Budgetberatung</option>
                  <option value="tools">Fragen zu Tools & Vorlagen</option>
                  <option value="workshop">Workshop oder Teamtraining</option>
                  <option value="support">Technischer Support</option>
                </select>
                {errors.topic && <span className="mt-1 block text-xs text-accent">{errors.topic}</span>}
              </label>

              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
                Nachricht *
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="mt-2 h-32 w-full rounded-2xl border border-light px-4 py-3 text-sm focus:border-accent focus:outline-none"
                  placeholder="Wobei dürfen wir euch unterstützen?"
                />
                {errors.message && <span className="mt-1 block text-xs text-accent">{errors.message}</span>}
              </label>

              <button
                type="submit"
                className="w-full rounded-full bg-accent px-6 py-3 text-sm font-semibold text-white shadow-soft"
              >
                Anfrage senden
              </button>
              {status && <p className="text-sm font-semibold text-success">{status}</p>}
            </div>
          </form>

          <aside className="space-y-6">
            <div className="rounded-3xl bg-white p-6 shadow-soft">
              <h3 className="text-base font-semibold text-primary">Kontaktinformationen</h3>
              <p className="mt-3 text-sm text-slate-600">
                FamilienBudget GmbH
                <br />
                Oranienstraße 24
                <br />
                10999 Berlin
              </p>
              <p className="mt-3 text-sm text-slate-600">
                Telefon: +49 (0)30 123 456 70
                <br />
                E-Mail: hallo@familienbudget.de
              </p>
              <p className="mt-3 text-xs text-slate-500">
                Termine nach Vereinbarung – digital oder vor Ort in Berlin.
              </p>
            </div>

            <div className="rounded-3xl bg-white p-6 shadow-soft">
              <h3 className="text-base font-semibold text-primary">Sprechzeiten</h3>
              <ul className="mt-3 text-sm text-slate-600">
                <li>Montag – Donnerstag: 09:00 – 18:00 Uhr</li>
                <li>Freitag: 09:00 – 14:00 Uhr</li>
                <li>Familien-Workshops: Samstag nach Vereinbarung</li>
              </ul>
            </div>

            <img
              src="https://picsum.photos/600/400?random=1003"
              alt="FamilienBudget Büro Berlin"
              className="rounded-3xl object-cover shadow-soft"
            />
          </aside>
        </div>
      </section>
    </>
  );
};

export default Contact;