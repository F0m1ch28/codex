import React from 'react';
import { Helmet } from 'react-helmet';

const Privacy = () => (
  <>
    <Helmet>
      <title>Datenschutzerklärung – FamilienBudget</title>
      <meta
        name="description"
        content="Datenschutzinformationen von FamilienBudget: Verantwortliche Stelle, Datenarten, Zwecke, Rechtsgrundlagen und Rechte der Betroffenen."
      />
      <meta property="og:title" content="Datenschutz FamilienBudget" />
      <meta property="og:image" content="https://picsum.photos/1200/630?random=1301" />
      <link rel="canonical" href="https://familienbudget.de/policy" />
    </Helmet>

    <section className="container-padding mx-auto max-w-4xl py-20">
      <h1 className="text-3xl font-heading font-semibold text-primary">Datenschutzerklärung</h1>
      <p className="mt-4 text-sm text-slate-600">
        Wir nehmen Datenschutz ernst. Nachfolgend informieren wir dich über Art, Umfang und Zweck der
        Verarbeitung personenbezogener Daten innerhalb unserer Plattform.
      </p>

      <div className="mt-10 space-y-6 text-sm text-slate-600">
        <section>
          <h2 className="font-semibold text-primary">1. Verantwortlicher</h2>
          <p>
            FamilienBudget GmbH, Oranienstraße 24, 10999 Berlin, E-Mail: datenschutz@familienbudget.de
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">2. Datenverarbeitung</h2>
          <p>
            Wir verarbeiten Kontaktdaten, Vertragsdaten, Nutzungsdaten und Zahlungsinformationen zur
            Bereitstellung unserer Dienste. Bankverbindungen werden ausschließlich für die optionalen
            Kontosynchronisationen verarbeitet. Die Datenverarbeitung erfolgt gem. Art. 6 Abs. 1 lit. b
            und f DSGVO.
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">3. Cookies & Tracking</h2>
          <p>
            Wir verwenden notwendige Cookies für den Login und optionale Cookies für anonymisierte
            Statistiken. Du kannst deine Einwilligung jederzeit im Cookie-Banner widerrufen.
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">4. Auftragsverarbeitung</h2>
          <p>
            Wir arbeiten mit ausgewählten Dienstleistern (Hosting, Newsletter, Zahlungsabwicklung)
            auf Basis von Auftragsverarbeitungsverträgen gem. Art. 28 DSGVO. Serverstandort ist Deutschland.
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">5. Rechte der Betroffenen</h2>
          <p>
            Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung und Datenübertragbarkeit.
            Wende dich an datenschutz@familienbudget.de. Beschwerden kannst du an die zuständige
            Aufsichtsbehörde richten.
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">6. Speicherdauer</h2>
          <p>
            Wir speichern Daten so lange, wie es für die Vertragserfüllung notwendig ist. Nach
            Vertragsende löschen oder anonymisieren wir Daten, sofern keine gesetzlichen Aufbewahrungsfristen entgegenstehen.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default Privacy;