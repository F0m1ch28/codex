import React from 'react';
import { Helmet } from 'react-helmet';

const Cookies = () => (
  <>
    <Helmet>
      <title>Cookie-Richtlinie – FamilienBudget</title>
      <meta
        name="description"
        content="Cookie-Richtlinie von FamilienBudget: Einsatz, Kategorien, Widerrufsrechte und Einstellungen."
      />
      <meta property="og:title" content="Cookie-Richtlinie FamilienBudget" />
      <meta property="og:image" content="https://picsum.photos/1200/630?random=1401" />
      <link rel="canonical" href="https://familienbudget.de/cookies" />
    </Helmet>

    <section className="container-padding mx-auto max-w-4xl py-20">
      <h1 className="text-3xl font-heading font-semibold text-primary">Cookie-Richtlinie</h1>
      <p className="mt-4 text-sm text-slate-600">
        Diese Cookie-Richtlinie erklärt, wie FamilienBudget Cookies und ähnliche Technologien einsetzt.
      </p>

      <div className="mt-10 space-y-6 text-sm text-slate-600">
        <section>
          <h2 className="font-semibold text-primary">1. Notwendige Cookies</h2>
          <p>
            Diese Cookies sind für die Nutzung der Plattform erforderlich, z. B. für Login-Sessions oder
            Sicherheitsfunktionen. Rechtsgrundlage: Art. 6 Abs. 1 lit. f DSGVO.
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">2. Statistik & Analyse</h2>
          <p>
            Wir setzen optionale Cookies ein, um anonymisierte Nutzungsstatistiken zu erheben. Damit
            verbessern wir Funktionen und Inhalte. Du kannst diese Cookies über den Cookie-Banner deaktivieren.
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">3. Marketing</h2>
          <p>
            Wir verzichten auf personalisierte Werbung. Newsletter werden nur nach ausdrücklicher
            Einwilligung versendet.
          </p>
        </section>
        <section>
          <h2 className="font-semibold text-primary">4. Verwaltung</h2>
          <p>
            Du kannst Cookies jederzeit löschen oder blockieren. Bei Deaktivierung bestimmter Cookies
            können Funktionen eingeschränkt sein. Verwende die Einstellungen deines Browsers oder unseren Cookie-Banner.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default Cookies;