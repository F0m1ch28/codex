import React, { useState } from 'react';
import { Helmet } from 'react-helmet';

const features = [
  {
    id: 'haushaltsbuch',
    name: 'Haushaltsbuch',
    description:
      'Transparente Auswertungen, Kategorisierung nach Fixkosten, variablen Ausgaben und Spartöpfen. Automatische Regeln für Einkäufe, Abonnements und Kita-Gebühren.',
    benefits: [
      'Übersichtliche Dashboards und Monatsberichte',
      'Kategorisierung mit KI-Unterstützung',
      'Alerts bei Budgetüberschreitungen',
      'CSV-Export und PDF-Reports für Familienrat'
    ],
    image: 'https://picsum.photos/900/600?random=601'
  },
  {
    id: 'kategorien',
    name: 'Kategorien & Regeln',
    description:
      'Definiere individuelle Kategorien für Familienalltag, lege Regeln fest und ordne Ein- und Ausgaben automatisch zu. Ideal für Taschengeld, Bildung und Freizeit.',
    benefits: [
      'Paare und Kinder erhalten eigene Kategorien',
      'Unterkonten mit persönlichen Limits',
      'Karten- und Bargeldausgaben werden erfasst',
      'Monatliche Checklisten zum Review'
    ],
    image: 'https://picsum.photos/900/600?random=602'
  },
  {
    id: 'ziele',
    name: 'Ziele & Fortschrittsbalken',
    description:
      'Setze Sparziele, plane Rücklagen und visualisiere den Fortschritt mit ansprechenden Grafiken. Feiert gemeinsame Erfolge als Familie.',
    benefits: [
      'Jede Zieldefinition inklusive Sparplan',
      'Automatische Überweisungen auf Tagesgeld',
      'Zielkarten für Kinder zum Mitverfolgen',
      'Motivierende Erfolgs-Alerts'
    ],
    image: 'https://picsum.photos/900/600?random=603'
  },
  {
    id: 'alerts',
    name: 'Benachrichtigungen & Insights',
    description:
      'Individuelle Alerts bei Unregelmäßigkeiten, Zahlungsfälligkeiten oder neuen Spartipps. DSGVO-konform und jederzeit anpassbar.',
    benefits: [
      'Fixkosten-Alerts bei Vertragsänderungen',
      'Warnungen bei auslaufenden Strom- oder Gaskonditionen',
      'Hinweise zu Kinderzuschlag, Wohngeld, Steuerboni',
      'Integrierte Spartipps passend zum Haushalt'
    ],
    image: 'https://picsum.photos/900/600?random=604'
  }
];

const Services = () => {
  const [activeFeature, setActiveFeature] = useState(features[0]);

  return (
    <>
      <Helmet>
        <title>Funktionen – Haushaltsbuch, Regeln & Ziele für FamilienBudget</title>
        <meta
          name="description"
          content="Entdecke alle Funktionen von FamilienBudget: Haushaltsbuch, Kategorien, Regeln, Ziele und Alerts für transparente Familienfinanzen."
        />
        <meta
          name="keywords"
          content="Haushaltsbuch, Budgetplanung, Kategorien, Finanzziele, Alerts, Familienfinanzen"
        />
        <meta property="og:title" content="Funktionen von FamilienBudget" />
        <meta
          property="og:description"
          content="Haushaltsbuch, Kategorien, Finanzziele und Alerts – alles für dein Familienbudget."
        />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=605" />
        <link rel="canonical" href="https://familienbudget.de/funktionen" />
      </Helmet>

      <section className="relative bg-primary py-20 text-white">
        <img
          src="https://picsum.photos/1600/900?random=606"
          alt="Dashboard der FamilienBudget App"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
        />
        <div className="relative mx-auto max-w-4xl px-4 text-center">
          <h1 className="text-3xl font-heading font-semibold md:text-4xl">
            Funktionen, die dein Familienbudget stärken
          </h1>
          <p className="mt-4 text-sm text-slate-200 md:text-base">
            Kombiniere Haushaltsbuch, zielorientierte Kategorien, clevere Regeln und Echtzeit-Alerts.
            So bleibt jede Ausgabe im Blick und jedes Finanzziel erreichbar.
          </p>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-6xl py-16">
        <div className="rounded-3xl bg-white p-8 shadow-soft">
          <div className="grid gap-10 lg:grid-cols-[280px_1fr]">
            <div className="space-y-4">
              {features.map((feature) => (
                <button
                  key={feature.id}
                  onClick={() => setActiveFeature(feature)}
                  className={`w-full rounded-2xl px-4 py-4 text-left text-sm font-semibold transition ${
                    activeFeature.id === feature.id
                      ? 'bg-accent text-white shadow-soft'
                      : 'bg-background text-primary hover:bg-accent/10'
                  }`}
                >
                  {feature.name}
                </button>
              ))}
            </div>
            <div className="space-y-6">
              <img
                src={activeFeature.image}
                alt={activeFeature.name}
                className="w-full rounded-3xl object-cover"
              />
              <h2 className="text-2xl font-heading font-semibold text-primary">
                {activeFeature.name}
              </h2>
              <p className="text-sm text-slate-600">{activeFeature.description}</p>
              <ul className="mt-4 grid gap-4 text-sm text-slate-600 md:grid-cols-2">
                {activeFeature.benefits.map((benefit) => (
                  <li key={benefit} className="flex items-start gap-2">
                    <span className="mt-1 text-success">✔</span>
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
              <div className="rounded-2xl bg-background/60 p-6 text-sm text-slate-600">
                <p className="font-semibold text-primary">FamilienPraxis Tipp</p>
                <p className="mt-2">
                  Verknüpfe jedes Feature mit einer wöchentlichen Budgetroutine. So bleibt euer
                  Haushaltsbuch aktuell, und ihr reagiert rechtzeitig auf Fixkostenänderungen.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;