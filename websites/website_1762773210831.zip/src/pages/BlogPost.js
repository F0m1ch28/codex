import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import blogPosts from '../data/blogPosts';

const BlogPost = () => {
  const { slug } = useParams();
  const post = blogPosts.find((entry) => entry.slug === slug);

  if (!post) {
    return (
      <section className="container-padding mx-auto max-w-4xl py-20">
        <h1 className="text-3xl font-heading font-semibold text-primary">
          Beitrag nicht gefunden
        </h1>
        <p className="mt-4 text-sm text-slate-600">
          Der gesuchte Beitrag ist nicht verfügbar. Schau dir unsere aktuellen Artikel im{' '}
          <Link to="/blog" className="text-accent underline">
            Blog
          </Link>{' '}
          an.
        </p>
      </section>
    );
  }

  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'Blog',
        item: 'https://familienbudget.de/blog'
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: post.title,
        item: `https://familienbudget.de/blog/${post.slug}`
      }
    ]
  };

  return (
    <>
      <Helmet>
        <title>{post.title} – FamilienBudget Blog</title>
        <meta name="description" content={post.metaDescription} />
        <meta
          name="keywords"
          content="Haushaltsbuch, Budgetplanung, Familienfinanzen, Notgroschen, Kontenmodell, Spartipps, Finanzziele"
        />
        <meta property="og:title" content={post.title} />
        <meta property="og:description" content={post.metaDescription} />
        <meta property="og:image" content={post.heroImage} />
        <meta property="og:type" content="article" />
        <meta property="article:author" content={post.author} />
        <link rel="canonical" href={`https://familienbudget.de/blog/${post.slug}`} />
        <script type="application/ld+json">
          {JSON.stringify(breadcrumbSchema)}
        </script>
      </Helmet>

      <article className="bg-background">
        <header className="relative overflow-hidden">
          <img
            src={post.heroImage}
            alt={post.title}
            className="h-72 w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-primary/60 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 px-4 pb-8 md:px-6">
            <div className="mx-auto max-w-4xl text-white">
              <span className="tag-pill bg-white/20 text-white">{post.tags.join(', ')}</span>
              <h1 className="mt-4 text-3xl font-heading font-semibold md:text-4xl">
                {post.title}
              </h1>
              <div className="mt-4 flex flex-wrap gap-4 text-xs text-slate-200">
                <span>{post.author}</span>
                <span>{post.date}</span>
                <span>{post.readTime}</span>
              </div>
            </div>
          </div>
        </header>

        <div className="container-padding mx-auto max-w-4xl py-16">
          <div className="prose prose-slate max-w-none">
            {post.content.map((section) => (
              <section key={section.heading} className="mb-10">
                <h2 className="text-2xl font-heading font-semibold text-primary">
                  {section.heading}
                </h2>
                {section.paragraphs &&
                  section.paragraphs.map((paragraph) => (
                    <p key={paragraph} className="mt-4 text-sm text-slate-600">
                      {paragraph}
                    </p>
                  ))}
                {section.list && (
                  <div className="mt-4 rounded-2xl border border-light bg-white p-6">
                    {section.listTitle && (
                      <p className="text-sm font-semibold text-primary">{section.listTitle}</p>
                    )}
                    <ul className="mt-3 space-y-2 text-sm text-slate-600">
                      {section.list.map((item) => (
                        <li key={item} className="flex items-start gap-2">
                          <span className="mt-1 text-accent">•</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {section.highlight && (
                  <div className="mt-6 rounded-2xl bg-accent/10 p-6 text-sm text-accent">
                    {section.highlight}
                  </div>
                )}
              </section>
            ))}
          </div>

          <div className="mt-10 rounded-3xl bg-white p-8 shadow-soft">
            <h3 className="text-lg font-semibold text-primary">Weiterführende Ressourcen</h3>
            <ul className="mt-4 space-y-3 text-sm text-slate-600">
              <li>
                <Link to="/tools" className="text-accent underline">
                  Budgetrechner & Notgroschen-Rechner ausprobieren
                </Link>
              </li>
              <li>
                <Link to="/ratgeber" className="text-accent underline">
                  Ratgeber zu Sozialleistungen und Versicherungen lesen
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-accent underline">
                  Individuelle Budgetberatung anfragen
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </article>
    </>
  );
};

export default BlogPost;