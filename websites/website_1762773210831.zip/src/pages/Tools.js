import React, { useState } from 'react';
import { Helmet } from 'react-helmet';

const Tools = () => {
  const [income, setIncome] = useState('');
  const [budgetResult, setBudgetResult] = useState(null);
  const [expenses, setExpenses] = useState('');
  const [months, setMonths] = useState('6');
  const [notgroschenResult, setNotgroschenResult] = useState(null);
  const [debtSum, setDebtSum] = useState('');
  const [interestRate, setInterestRate] = useState('');
  const [snowballResult, setSnowballResult] = useState(null);

  const handleBudgetCalc = (event) => {
    event.preventDefault();
    const net = parseFloat(income);
    if (!net || net <= 0) {
      setBudgetResult({ error: 'Bitte gib ein gültiges monatliches Nettoeinkommen an.' });
      return;
    }
    setBudgetResult({
      needs: net * 0.5,
      wants: net * 0.3,
      savings: net * 0.2
    });
  };

  const handleNotgroschenCalc = (event) => {
    event.preventDefault();
    const monthly = parseFloat(expenses);
    const period = parseInt(months, 10);
    if (!monthly || monthly <= 0) {
      setNotgroschenResult({ error: 'Bitte gib deine monatlichen Fixkosten an.' });
      return;
    }
    setNotgroschenResult({
      amount: monthly * period,
      perMonth: (monthly * period) / period
    });
  };

  const handleSnowballCalc = (event) => {
    event.preventDefault();
    const total = parseFloat(debtSum);
    const rate = parseFloat(interestRate);
    if (!total || total <= 0) {
      setSnowballResult({ error: 'Bitte gib die Gesamtsumme deiner Schulden ein.' });
      return;
    }
    const monthlyRate = total / 12 + (total * (isNaN(rate) ? 0 : rate / 100)) / 12;
    setSnowballResult({
      monthlyRate,
      timeline: Math.ceil(total / (monthlyRate || 1))
    });
  };

  return (
    <>
      <Helmet>
        <title>Tools & Rechner – Budgetrechner, Notgroschen, Schuldenplan</title>
        <meta
          name="description"
          content="Nutze Budgetrechner, Notgroschen-Rechner, Schulden-Snowball und PDF-Vorlagen von FamilienBudget für klare Familienfinanzen."
        />
        <meta
          name="keywords"
          content="Budgetrechner, Notgroschen, Schuldenabbau, Haushaltsbuch, Familienfinanzen, PDF-Vorlagen"
        />
        <meta property="og:title" content="FamilienBudget Tools" />
        <meta
          property="og:description"
          content="Rechner und Vorlagen für Budgetplanung, Rücklagen und Schuldenmanagement."
        />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=701" />
        <link rel="canonical" href="https://familienbudget.de/tools" />
      </Helmet>

      <section className="relative bg-accent/90 py-20 text-white">
        <img
          src="https://picsum.photos/1600/900?random=702"
          alt="Familie arbeitet mit Budget-Tools"
          className="absolute inset-0 h-full w-full object-cover opacity-40"
        />
        <div className="relative mx-auto max-w-4xl px-4 text-center">
          <h1 className="text-3xl font-heading font-semibold md:text-4xl">
            Deine digitalen Helfer für Budgetplanung & Rücklagen
          </h1>
          <p className="mt-4 text-sm text-slate-100 md:text-base">
            Berechne deine 50/30/20-Verteilung, plane den Notgroschen und strukturiere Schuldenabbau.
            Lade PDF-Templates für Haushaltsbuch, Monatsreview und Spartipps herunter.
          </p>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-6xl py-16">
        <div className="grid gap-8 lg:grid-cols-3">
          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <h2 className="text-xl font-heading font-semibold text-primary">
              50/30/20 Budgetrechner
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Verteile dein monatliches Nettoeinkommen nach Fixkosten, Wünschen und Rücklagen. Ideal
              für Budgetplanung mit mehreren Konten.
            </p>
            <form onSubmit={handleBudgetCalc} className="mt-6 space-y-4">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
                Nettoeinkommen pro Monat (€)
                <input
                  type="number"
                  min="0"
                  step="50"
                  value={income}
                  onChange={(e) => setIncome(e.target.value)}
                  className="mt-2 w-full rounded-2xl border border-light px-4 py-3 text-sm focus:border-accent focus:outline-none"
                  required
                />
              </label>
              <button
                type="submit"
                className="w-full rounded-full bg-accent px-5 py-3 text-sm font-semibold text-white shadow-soft"
              >
                Budget berechnen
              </button>
            </form>
            {budgetResult && (
              <div className="mt-6 rounded-2xl bg-background/60 p-4 text-sm text-slate-600">
                {budgetResult.error ? (
                  <p className="text-accent">{budgetResult.error}</p>
                ) : (
                  <>
                    <p>
                      <strong>Fixkosten (50 %):</strong> {budgetResult.needs.toFixed(2)} €
                    </p>
                    <p>
                      <strong>Wünsche (30 %):</strong> {budgetResult.wants.toFixed(2)} €
                    </p>
                    <p>
                      <strong>Rücklagen (20 %):</strong> {budgetResult.savings.toFixed(2)} €
                    </p>
                  </>
                )}
              </div>
            )}
          </div>

          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <h2 className="text-xl font-heading font-semibold text-primary">
              Notgroschen-Rechner
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Ermittelt deine ideale Rücklage auf Tagesgeldbasis. Wähle deinen Sicherheitsfaktor und
              plane, wie viele Monate abgesichert sein sollen.
            </p>
            <form onSubmit={handleNotgroschenCalc} className="mt-6 space-y-4">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
                Monatliche Fixkosten (€)
                <input
                  type="number"
                  min="0"
                  step="10"
                  value={expenses}
                  onChange={(e) => setExpenses(e.target.value)}
                  className="mt-2 w-full rounded-2xl border border-light px-4 py-3 text-sm focus:border-accent focus:outline-none"
                  required
                />
              </label>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
                Sicherheitsfaktor (Monate)
                <select
                  value={months}
                  onChange={(e) => setMonths(e.target.value)}
                  className="mt-2 w-full rounded-2xl border border-light px-4 py-3 text-sm focus:border-accent focus:outline-none"
                >
                  <option value="3">3 Monate</option>
                  <option value="6">6 Monate</option>
                  <option value="9">9 Monate</option>
                  <option value="12">12 Monate</option>
                </select>
              </label>
              <button
                type="submit"
                className="w-full rounded-full bg-success px-5 py-3 text-sm font-semibold text-white shadow-soft"
              >
                Notgroschen berechnen
              </button>
            </form>
            {notgroschenResult && (
              <div className="mt-6 rounded-2xl bg-background/60 p-4 text-sm text-slate-600">
                {notgroschenResult.error ? (
                  <p className="text-accent">{notgroschenResult.error}</p>
                ) : (
                  <>
                    <p>
                      <strong>Ziel-Rücklage:</strong> {notgroschenResult.amount.toFixed(2)} €
                    </p>
                    <p>
                      <strong>Monatlicher Sparbetrag:</strong> {notgroschenResult.perMonth.toFixed(2)} €
                    </p>
                    <p className="mt-2 text-xs text-slate-500">
                      Tipp: Lege die Rücklage auf ein separates Tagesgeldkonto, um sie von Alltagseinkäufen zu trennen.
                    </p>
                  </>
                )}
              </div>
            )}
          </div>

          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <h2 className="text-xl font-heading font-semibold text-primary">
              Schulden-Snowball-Rechner
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Plane den Schuldenabbau mit monatlichen Raten, tilge zuerst kleine Beträge und halte
              deinen Fortschritt fest.
            </p>
            <form onSubmit={handleSnowballCalc} className="mt-6 space-y-4">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
                Gesamtsumme Schulden (€)
                <input
                  type="number"
                  min="0"
                  step="100"
                  value={debtSum}
                  onChange={(e) => setDebtSum(e.target.value)}
                  className="mt-2 w-full rounded-2xl border border-light px-4 py-3 text-sm focus:border-accent focus:outline-none"
                  required
                />
              </label>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
                Effektiver Jahreszins (%)
                <input
                  type="number"
                  min="0"
                  step="0.1"
                  value={interestRate}
                  onChange={(e) => setInterestRate(e.target.value)}
                  className="mt-2 w-full rounded-2xl border border-light px-4 py-3 text-sm focus:border-accent focus:outline-none"
                  placeholder="Optional"
                />
              </label>
              <button
                type="submit"
                className="w-full rounded-full bg-primary px-5 py-3 text-sm font-semibold text-white shadow-soft"
              >
                Plan berechnen
              </button>
            </form>
            {snowballResult && (
              <div className="mt-6 rounded-2xl bg-background/60 p-4 text-sm text-slate-600">
                {snowballResult.error ? (
                  <p className="text-accent">{snowballResult.error}</p>
                ) : (
                  <>
                    <p>
                      <strong>Empfohlene Monatsrate:</strong> {snowballResult.monthlyRate.toFixed(2)} €
                    </p>
                    <p>
                      <strong>Plausible Laufzeit:</strong> {snowballResult.timeline} Monate
                    </p>
                    <p className="mt-2 text-xs text-slate-500">
                      Kombiniere den Plan mit unserem Schulden-Dashboard, um jeden Kredit gezielt abzubauen.
                    </p>
                  </>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="mt-12 rounded-3xl bg-white p-8 shadow-soft">
          <h2 className="text-2xl font-heading font-semibold text-primary">PDF-Vorlagen & Checklisten</h2>
          <p className="mt-2 text-sm text-slate-600">
            Alle Vorlagen sind DSGVO-konform, leicht ausfüllbar und begleiten dich Schritt für Schritt.
          </p>
          <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[
              'Haushaltsbuch Monat für Monat',
              'Fixkosten- & Versicherungsübersicht',
              'Monatlicher Budget-Review',
              'Taschengeldvertrag & Lernziele',
              'Notgroschen-Tracker',
              'Schulden-Snowball-Planer'
            ].map((template) => (
              <div key={template} className="rounded-2xl border border-light p-5 text-sm text-slate-600">
                <p className="font-semibold text-primary">{template}</p>
                <p className="mt-2 text-xs text-slate-500">Download im Kundenbereich verfügbar</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Tools;