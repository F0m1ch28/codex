import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import blogPosts from '../data/blogPosts';

const Home = () => {
  const statsData = useMemo(
    () => [
      { label: 'Haushalte begleitet', value: 1250, suffix: '+' },
      { label: 'Automatisierte Budgets', value: 380000, suffix: ' €' },
      { label: 'Erreichte Sparziele', value: 970, suffix: '' },
      { label: 'Durchschnittliche Zufriedenheit', value: 94, suffix: ' %' }
    ],
    []
  );
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));

  useEffect(() => {
    let raf;
    const duration = 2000;
    const start = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - start) / duration, 1);
      setAnimatedStats(
        statsData.map((stat) => Math.round(stat.value * progress))
      );
      if (progress < 1) {
        raf = requestAnimationFrame(animate);
      }
    };

    raf = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(raf);
  }, [statsData]);

  const testimonials = [
    {
      name: 'Familie Köhler, Freiburg',
      quote:
        'Wir haben endlich volle Transparenz. Fixkosten, Rücklagen und Wunschlisten laufen automatisiert – das Haushaltsbuch ist kein Stress mehr.',
      role: '2 Kinder, Doppelverdiener',
      image: 'https://picsum.photos/120/120?random=301'
    },
    {
      name: 'Selina & Mark, Leipzig',
      quote:
        'Die Budget-Vorlagen und der Schulden-Snowball-Rechner haben uns geholfen, in 18 Monaten 12.000 € Kredit zu tilgen.',
      role: 'Angestellte & Selbstständiger',
      image: 'https://picsum.photos/120/120?random=302'
    },
    {
      name: 'Familie Nguyen, Hamburg',
      quote:
        'Unser Notgroschen ist aufgebaut, und die Kinder lernen dank Kategorien und Taschengeld-Konten, wie Budgetplanung funktioniert.',
      role: '3 Kinder, Patchwork-Familie',
      image: 'https://picsum.photos/120/120?random=303'
    }
  ];

  const [testimonialIndex, setTestimonialIndex] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const filters = ['Alle', 'Budget', 'Sparen', 'Schulden'];
  const [activeFilter, setActiveFilter] = useState('Alle');

  const projects = [
    {
      id: 1,
      title: 'Fixkosten-Reset für Familie Schröder',
      category: 'Budget',
      description:
        'Analyse von Versicherungen, Stromverträgen und Kitagebühren: 348 € monatlich eingespart.',
      image: 'https://picsum.photos/900/600?random=311'
    },
    {
      id: 2,
      title: 'Notgroschen in 6 Monaten',
      category: 'Sparen',
      description:
        'Tagesgeld-Strategie mit automatisierten Sparplänen, um 9.000 € Rücklagen aufzubauen.',
      image: 'https://picsum.photos/900/600?random=312'
    },
    {
      id: 3,
      title: 'Schulden-Snowball mit Plan',
      category: 'Schulden',
      description:
        'Schuldenabbau-Programm für Konsumentenkredite und Dispo in 14 Monaten abgeschlossen.',
      image: 'https://picsum.photos/900/600?random=313'
    },
    {
      id: 4,
      title: 'Digitales Haushaltsbuch & Taschengeld',
      category: 'Budget',
      description:
        'Kinderbudget mit Kategorien und pädagogischen Templates für Finanzbildung zuhause.',
      image: 'https://picsum.photos/900/600?random=314'
    }
  ];

  const filteredProjects =
    activeFilter === 'Alle'
      ? projects
      : projects.filter((project) => project.category === activeFilter);

  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterMessage, setNewsletterMessage] = useState('');

  const handleNewsletterSubmit = (e) => {
    e.preventDefault();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!newsletterEmail || !emailRegex.test(newsletterEmail)) {
      setNewsletterMessage('Bitte eine gültige E-Mail-Adresse eingeben.');
    } else {
      setNewsletterMessage('Danke! Bitte bestätige deine Anmeldung in deinem Postfach.');
      setNewsletterEmail('');
    }
  };

  const organizationSchema = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'FamilienBudget',
    url: 'https://familienbudget.de',
    logo: 'https://picsum.photos/160/160?random=399',
    sameAs: [
      'https://www.linkedin.com',
      'https://www.instagram.com',
      'https://www.youtube.com'
    ],
    description:
      'FamilienBudget bietet Tools für Haushaltsbuch, Budgetplanung und Rücklagenmanagement für Familien in Deutschland.'
  };

  return (
    <>
      <Helmet>
        <title>FamilienBudget – Haushaltsbuch & Budgetplanung für Familien</title>
        <meta
          name="description"
          content="Mit FamilienBudget behältst du deine Familienfinanzen im Griff: Haushaltsbuch, Budgetrechner, Notgroschen-Planer, Spartipps und Vorlagen speziell für deutsche Haushalte."
        />
        <meta
          name="keywords"
          content="Haushaltsbuch, Budgetplanung, Familienfinanzen, Notgroschen, Rücklagen, Tagesgeld, Girokonto, Fixkosten, Spartipps, Schuldenabbau, Finanzziele, Budget-Vorlagen"
        />
        <meta property="og:title" content="FamilienBudget – Haushaltsbuch & Budgetplanung" />
        <meta
          property="og:description"
          content="Budgetplanung, Notgroschen-Rechner und Finanzziele – alles in einer Plattform für Familienhaushalte."
        />
        <meta property="og:image" content="https://picsum.photos/1600/900?random=401" />
        <meta property="og:url" content="https://familienbudget.de/" />
        <meta name="twitter:title" content="FamilienBudget" />
        <meta name="twitter:card" content="summary_large_image" />
        <link rel="canonical" href="https://familienbudget.de/" />
        <script type="application/ld+json">
          {JSON.stringify(organizationSchema)}
        </script>
      </Helmet>

      <section className="relative flex min-h-[70vh] items-center justify-center overflow-hidden">
        <img
          src="https://picsum.photos/1600/900?random=402"
          alt="Familie bespricht Budget am Küchentisch"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-primary/80" />
        <div className="relative z-10 mx-auto max-w-4xl px-4 py-24 text-center text-white sm:px-6">
          <span className="tag-pill inline-block bg-white/15 text-sm text-white">
            Familienfinanzen smart steuern
          </span>
          <h1 className="mt-6 text-3xl font-heading font-semibold md:text-5xl">
            Behalte deine Familienfinanzen im Griff
          </h1>
          <p className="mt-4 text-base text-slate-200 md:text-lg">
            Haushaltsbuch, Budgetrechner, Notgroschen-Planer und Vorlagen – maßgeschneidert für
            Familien in Deutschland. Mit klaren Routinen vom ersten Budget bis zum langfristigen Ziel.
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              to="/funktionen"
              className="btn-primary animate-bounce-slow inline-flex items-center justify-center rounded-full px-8 py-3 text-sm font-semibold text-white shadow-soft"
            >
              Jetzt Budget starten
            </Link>
            <Link
              to="/tools"
              className="btn-outline inline-flex items-center justify-center rounded-full px-8 py-3 text-sm font-semibold text-primary"
            >
              Tools entdecken
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 md:px-6">
        <div className="grid gap-6 rounded-3xl bg-white p-8 shadow-soft sm:grid-cols-2 lg:grid-cols-4">
          {statsData.map((stat, index) => (
            <div key={stat.label} className="text-center">
              <p className="text-3xl font-heading font-semibold text-accent md:text-4xl">
                {animatedStats[index]}
                {stat.suffix}
              </p>
              <p className="mt-2 text-sm font-medium text-slate-600">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container-padding mx-auto max-w-6xl py-16">
        <div className="rounded-3xl bg-white p-8 shadow-soft lg:p-12">
          <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
            <div>
              <span className="tag-pill">Vorteile</span>
              <h2 className="section-title mt-4">
                Warum FamilienBudget dein Partner für Haushaltsbuch & Rücklagen ist
              </h2>
              <p className="section-subtitle">
                Wir kombinieren klare Budgetregeln mit smarten Tools, damit Fixkosten, Spartipps,
                Schuldenabbau und Finanzziele jederzeit transparent bleiben.
              </p>
              <dl className="mt-8 space-y-6">
                <div className="card-hover rounded-2xl border border-light p-6">
                  <dt className="flex items-center gap-3 text-base font-semibold text-primary">
                    <span className="flex h-10 w-10 items-center justify-center rounded-full bg-success/15 text-success">
                      ✓
                    </span>
                    Haushaltsbuch mit Automatisierung
                  </dt>
                  <dd className="mt-2 text-sm text-slate-600">
                    Synchronisiere Konten, kategorisiere Ausgaben und erhalte Alerts bei Ausreißern.
                  </dd>
                </div>
                <div className="card-hover rounded-2xl border border-light p-6">
                  <dt className="flex items-center gap-3 text-base font-semibold text-primary">
                    <span className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/15 text-accent">
                      ⏱
                    </span>
                    Budgetplanung in 15 Minuten pro Woche
                  </dt>
                  <dd className="mt-2 text-sm text-slate-600">
                    Mit Checklisten, Templates und klaren Routinen, die in jede Familienagenda passen.
                  </dd>
                </div>
                <div className="card-hover rounded-2xl border border-light p-6">
                  <dt className="flex items-center gap-3 text-base font-semibold text-primary">
                    <span className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/15 text-accent">
                      🎯
                    </span>
                    Finanzziele sichtbar machen
                  </dt>
                  <dd className="mt-2 text-sm text-slate-600">
                    Fortschrittsbalken, Monatsreviews und Familien-Meilensteine sorgen für Motivation.
                  </dd>
                </div>
              </dl>
            </div>
            <div className="relative">
              <img
                src="https://picsum.photos/800/600?random=403"
                alt="Digitales Haushaltsbuch Dashboard"
                className="rounded-3xl shadow-soft"
              />
              <div className="absolute -bottom-8 -left-8 hidden w-40 rounded-2xl bg-white p-4 text-sm font-semibold text-primary shadow-soft md:block">
                <p>+182 € Rücklagen</p>
                <p className="text-xs text-slate-500">im Monat April</p>
              </div>
              <div className="absolute -top-6 -right-6 hidden w-44 rounded-2xl bg-white p-4 text-xs text-slate-600 shadow-soft md:block">
                <p className="font-semibold text-primary">Alerts</p>
                <p>Stromabschlag +12 €</p>
                <p>Kindergarten-Gebühren bezahlt</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-6xl py-16">
        <div className="rounded-3xl bg-primary px-6 py-12 text-white lg:px-12">
          <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
            <div>
              <span className="tag-pill bg-white/15 text-white">Budgetmethode</span>
              <h2 className="mt-4 text-3xl font-heading font-semibold">50/30/20 leicht erklärt</h2>
              <p className="mt-4 text-sm text-slate-200">
                Fixkosten begrenzen, Wünsche planen, Rücklagen automatisieren: Die 50/30/20-Regel ist
                unser bewährtes Framework für nachhaltige Familienbudgets. Passe die Quoten an eure
                Situation an und tracke alles im Haushaltsbuch.
              </p>
            </div>
            <div className="space-y-4">
              {[
                { label: '50 % Pflicht & Fixkosten', description: 'Miete, Energie, Versicherungen, Kredite, Mobilität, Kinderbetreuung' },
                { label: '30 % Wünsche & Alltag', description: 'Lebensmittel, Freizeit, Taschengeld, Hobbys, Urlaub' },
                { label: '20 % Rücklagen & Ziele', description: 'Notgroschen, Tagesgeld, Reserven für Reparaturen, langfristige Finanzziele' }
              ].map((item) => (
                <div key={item.label} className="rounded-2xl bg-white/10 p-5 shadow-soft">
                  <p className="text-lg font-semibold">{item.label}</p>
                  <p className="mt-2 text-xs text-slate-200">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-6xl py-16">
        <div className="rounded-3xl bg-white p-8 shadow-soft lg:p-12">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <span className="tag-pill">Kontenmodelle</span>
              <h2 className="section-title mt-4">Welche Kontostruktur passt zu euch?</h2>
              <p className="section-subtitle">
                Klare Kontenmodelle verhindern Engpässe. Kombiniere Girokonto, Tagesgeld und
                Unterkonten smart für Fixkosten, Alltag und Rücklagen.
              </p>
            </div>
            <Link
              to="/blog/kontenmodell-familie"
              className="rounded-full bg-accent px-6 py-3 text-sm font-semibold text-white shadow-soft"
            >
              Leitfaden lesen
            </Link>
          </div>

          <div className="mt-10 overflow-x-auto">
            <table className="min-w-full text-sm text-slate-600">
              <thead>
                <tr className="bg-background text-xs uppercase tracking-wide text-slate-500">
                  <th className="px-4 py-3 text-left">Kontotyp</th>
                  <th className="px-4 py-3 text-left">Zweck</th>
                  <th className="px-4 py-3 text-left">Highlights</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-light">
                <tr>
                  <td className="px-4 py-4 font-semibold text-primary">Gemeinschafts-Girokonto</td>
                  <td className="px-4 py-4">Gehaltszufluss, Fixkosten, Versicherungen, Kita</td>
                  <td className="px-4 py-4">Automatische Regeln, Alerts bei Ausreißern, Monatsreport</td>
                </tr>
                <tr className="bg-background/60">
                  <td className="px-4 py-4 font-semibold text-primary">Einzelkonten</td>
                  <td className="px-4 py-4">Persönliche Ausgaben, Taschengeld, spontane Wünsche</td>
                  <td className="px-4 py-4">Fairness, Freiraum, Besseres Gefühl bei kleinen Käufen</td>
                </tr>
                <tr>
                  <td className="px-4 py-4 font-semibold text-primary">Tagesgeld & Unterkonten</td>
                  <td className="px-4 py-4">Notgroschen, Urlaubsbudget, Bildung, Reparaturen</td>
                  <td className="px-4 py-4">Zinsvorteile, getrennte Rücklagen, klare Zielvisualisierung</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-6xl py-16">
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <span className="tag-pill">Tools & Vorlagen</span>
            <h2 className="section-title mt-4">Alles für deine Budgetroutine</h2>
            <p className="section-subtitle">
              Rechner, Checklisten und PDF-Templates – sofort einsatzbereit für deinen Familienalltag.
            </p>
            <div className="mt-8 space-y-6">
              {[
                {
                  title: 'Budgetrechner',
                  description: 'Ermittelt deine 50/30/20-Verteilung, Fixkostenquote und Sparrate.'
                },
                {
                  title: 'Notgroschen-Rechner',
                  description: 'Berechne Rücklagen nach Monatsausgaben und Sicherheitsfaktor.'
                },
                {
                  title: 'Schulden-Snowball',
                  description: 'Priorisiere Kredite und plane den schnellen Schuldenabbau.'
                },
                {
                  title: 'PDF-Vorlagen',
                  description: 'Haushaltsbuch, Monatsreview, Taschengeld-Plan, Versicherungsübersicht.'
                }
              ].map((tool) => (
                <div key={tool.title} className="card-hover rounded-2xl border border-light p-6">
                  <h3 className="text-base font-semibold text-primary">{tool.title}</h3>
                  <p className="mt-2 text-sm text-slate-600">{tool.description}</p>
                </div>
              ))}
            </div>
            <Link
              to="/tools"
              className="mt-8 inline-block rounded-full bg-primary px-6 py-3 text-sm font-semibold text-white"
            >
              Tools ausprobieren
            </Link>
          </div>

          <div className="rounded-3xl bg-primary p-8 text-white shadow-soft lg:p-12">
            <span className="tag-pill bg-white/15 text-white">Prozess</span>
            <h2 className="mt-4 text-3xl font-heading font-semibold">
              In 4 Schritten zu stabilen Familienfinanzen
            </h2>
            <ul className="mt-8 space-y-6 text-sm">
              <li className="rounded-2xl bg-white/10 p-5">
                <p className="font-semibold">1. Haushaltsanalyse</p>
                <p className="mt-2 text-slate-200">
                  Fixkosten erfassen, Girokonten verbinden, Kategorien definieren.
                </p>
              </li>
              <li className="rounded-2xl bg-white/10 p-5">
                <p className="font-semibold">2. Budget festlegen</p>
                <p className="mt-2 text-slate-200">
                  Einnahmen verteilen, Ziele priorisieren, Regeln für Alerts und Limits aktivieren.
                </p>
              </li>
              <li className="rounded-2xl bg-white/10 p-5">
                <p className="font-semibold">3. Routinen etablieren</p>
                <p className="mt-2 text-slate-200">
                  Wöchentliche Kurz-Reviews, Monatsabschluss mit Checklisten und Familienrat.
                </p>
              </li>
              <li className="rounded-2xl bg-white/10 p-5">
                <p className="font-semibold">4. Ziele feiern</p>
                <p className="mt-2 text-slate-200">
                  Fortschritte teilen, Spartipps mit Kindern üben und nächste Etappen planen.
                </p>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-6xl py-16">
        <div className="rounded-3xl bg-white p-8 shadow-soft lg:p-12">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <span className="tag-pill">Erfolgsstories</span>
              <h2 className="section-title mt-4">Projekte & Ergebnisse</h2>
              <p className="section-subtitle">
                Filtere nach Budget, Sparen oder Schuldenabbau und lass dich inspirieren.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {filters.map((filter) => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`rounded-full px-4 py-2 text-xs font-semibold transition ${
                    activeFilter === filter
                      ? 'bg-accent text-white shadow-soft'
                      : 'bg-light text-primary hover:bg-accent/10'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {filteredProjects.map((project) => (
              <article key={project.id} className="card-hover overflow-hidden rounded-3xl border border-light bg-white">
                <img
                  src={project.image}
                  alt={project.title}
                  className="h-48 w-full object-cover"
                  loading="lazy"
                />
                <div className="p-6">
                  <span className="tag-pill">{project.category}</span>
                  <h3 className="mt-4 text-lg font-semibold text-primary">{project.title}</h3>
                  <p className="mt-3 text-sm text-slate-600">{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-primary py-16 text-white">
        <div className="container-padding mx-auto max-w-5xl">
          <div className="text-center">
            <span className="tag-pill bg-white/15 text-white">Stimmen aus der Community</span>
            <h2 className="mt-5 text-3xl font-heading font-semibold">Was Familien sagen</h2>
            <div className="relative mt-10">
              <div className="rounded-3xl bg-white/10 p-8 shadow-soft md:p-12">
                <div className="flex flex-col items-center gap-4 md:flex-row md:items-center md:text-left">
                  <img
                    src={testimonials[testimonialIndex].image}
                    alt={`Portrait von ${testimonials[testimonialIndex].name}`}
                    className="h-20 w-20 rounded-full border-4 border-white object-cover"
                  />
                  <div>
                    <p className="text-lg font-medium text-white">
                      „{testimonials[testimonialIndex].quote}“
                    </p>
                    <p className="mt-4 text-sm font-semibold">
                      {testimonials[testimonialIndex].name}
                    </p>
                    <p className="text-xs uppercase tracking-wider text-slate-200">
                      {testimonials[testimonialIndex].role}
                    </p>
                  </div>
                </div>
                <div className="mt-6 flex items-center justify-center gap-3">
                  {testimonials.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setTestimonialIndex(idx)}
                      className={`h-3 w-3 rounded-full transition ${
                        idx === testimonialIndex ? 'bg-white' : 'bg-white/40'
                      }`}
                      aria-label={`Testimonial ${idx + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-6xl py-16">
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <span className="tag-pill">Team</span>
            <h2 className="section-title mt-4">Expert:innen an deiner Seite</h2>
            <p className="section-subtitle">
              Finanzcoaches, Steuerexpertinnen und Pädagog:innen arbeiten zusammen, um Familienbudget alltagstauglich zu machen.
            </p>
            <div className="mt-8 grid gap-6 sm:grid-cols-2">
              {[
                {
                  name: 'Mara Fischer',
                  role: 'Finanzcoach & Haushaltsbuch-Profi',
                  image: 'https://picsum.photos/400/400?random=321'
                },
                {
                  name: 'Jonas Reuter',
                  role: 'Steuerspezialist & Familienrecht',
                  image: 'https://picsum.photos/400/400?random=322'
                },
                {
                  name: 'Lea Sommer',
                  role: 'Budgetpädagogin & Workshops',
                  image: 'https://picsum.photos/400/400?random=323'
                },
                {
                  name: 'Dr. Elisa Hahn',
                  role: 'Research & Sozialleistungen',
                  image: 'https://picsum.photos/400/400?random=324'
                }
              ].map((member) => (
                <div
                  key={member.name}
                  className="card-hover rounded-2xl border border-light p-4"
                >
                  <img
                    src={member.image}
                    alt={`Teammitglied ${member.name}`}
                    className="h-24 w-24 rounded-full object-cover"
                  />
                  <h3 className="mt-4 text-base font-semibold text-primary">{member.name}</h3>
                  <p className="text-sm text-slate-600">{member.role}</p>
                  <button className="mt-4 text-xs font-semibold text-accent">
                    Profil ansehen →
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <span className="tag-pill">FAQ</span>
            <h2 className="section-title mt-4">Die häufigsten Fragen</h2>
            <dl className="mt-6 space-y-5">
              {[
                {
                  question: 'Wie lange dauert der Einstieg?',
                  answer:
                    'In zwei Sessions à 45 Minuten strukturierst du deine Konten, Kategorien und Budgets. Danach reichen 15 Minuten pro Woche für das Review.'
                },
                {
                  question: 'Braucht jede Person ein eigenes Konto?',
                  answer:
                    'Wir empfehlen mindestens ein Gemeinschaftskonto für Fixkosten und pro Person ein frei verfügbares Konto. So bleibt Fairness und Transparenz gewährleistet.'
                },
                {
                  question: 'Welche Daten benötige ich?',
                  answer:
                    'Wir arbeiten DSGVO-konform. Du entscheidest, welche Bankverbindungen synchronisiert werden. Alternativ dokumentierst du manuell im Haushaltsbuch.'
                }
              ].map((item) => (
                <div key={item.question} className="rounded-2xl bg-background/60 p-5">
                  <dt className="text-sm font-semibold text-primary">{item.question}</dt>
                  <dd className="mt-2 text-sm text-slate-600">{item.answer}</dd>
                </div>
              ))}
            </dl>
            <Link
              to="/faq"
              className="mt-6 inline-flex items-center text-sm font-semibold text-accent"
            >
              Alle Fragen ansehen →
            </Link>
          </div>
        </div>
      </section>

      <section className="bg-background py-16">
        <div className="container-padding mx-auto max-w-6xl">
          <div className="rounded-3xl bg-white p-8 shadow-soft lg:p-12">
            <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <span className="tag-pill">Blog & Insights</span>
                <h2 className="section-title mt-4">Unsere aktuellen Beiträge</h2>
                <p className="section-subtitle">
                  Strategien zu Haushaltsbuch, Sozialleistungen, Versicherungen und Steuertipps.
                </p>
              </div>
              <Link
                to="/blog"
                className="rounded-full border border-light px-6 py-3 text-sm font-semibold text-primary hover:border-accent hover:text-accent"
              >
                Zum Blog
              </Link>
            </div>

            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {blogPosts.slice(0, 3).map((post) => (
                <article key={post.slug} className="card-hover rounded-3xl border border-light bg-white">
                  <img
                    src={post.heroImage}
                    alt={post.title}
                    className="h-40 w-full rounded-t-3xl object-cover"
                    loading="lazy"
                  />
                  <div className="p-6">
                    <span className="tag-pill">{post.tags[0]}</span>
                    <h3 className="mt-4 text-lg font-semibold text-primary">{post.title}</h3>
                    <p className="mt-3 text-sm text-slate-600">{post.excerpt}</p>
                    <Link
                      to={`/blog/${post.slug}`}
                      className="mt-4 inline-flex text-sm font-semibold text-accent"
                    >
                      Weiterlesen →
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-primary py-16 text-white">
        <div className="container-padding mx-auto max-w-5xl text-center">
          <h2 className="text-3xl font-heading font-semibold">
            Starte deine Budgetroutine mit FamilienBudget
          </h2>
          <p className="mt-4 text-sm text-slate-200">
            Spare dir Excel-Chaos, verhindere Stress vor Monatsende und finanziere Ziele vom Urlaub
            bis zur Renovierung.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              to="/contact"
              className="rounded-full bg-white px-8 py-3 text-sm font-semibold text-primary shadow-soft"
            >
              Kostenfreie Erstberatung
            </Link>
            <Link
              to="/funktionen"
              className="rounded-full border border-white/30 px-8 py-3 text-sm font-semibold text-white"
            >
              Funktionen ansehen
            </Link>
          </div>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-3xl py-16">
        <div className="rounded-3xl bg-white p-8 shadow-soft text-center sm:p-10">
          <span className="tag-pill">Newsletter</span>
          <h2 className="mt-4 text-2xl font-heading font-semibold">
            Finanzbrief für Familien – monatlich inspiriert bleiben
          </h2>
          <p className="mt-3 text-sm text-slate-600">
            Spartipps, Sozialleistungen, Steuertipps und neue Budget-Vorlagen direkt in dein Postfach.
          </p>
          <form onSubmit={handleNewsletterSubmit} className="mt-8 flex flex-col gap-4 sm:flex-row">
            <input
              type="email"
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              placeholder="E-Mail-Adresse"
              className="w-full rounded-full border border-light px-6 py-3 text-sm outline-none transition focus:border-accent"
              required
              aria-label="E-Mail-Adresse für Newsletter"
            />
            <button
              type="submit"
              className="rounded-full bg-accent px-8 py-3 text-sm font-semibold text-white shadow-soft"
            >
              Anmelden
            </button>
          </form>
          {newsletterMessage && (
            <p className="mt-4 text-sm font-semibold text-success">{newsletterMessage}</p>
          )}
        </div>
      </section>
    </>
  );
};

export default Home;