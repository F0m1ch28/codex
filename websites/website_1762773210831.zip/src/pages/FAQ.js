import React, { useState } from 'react';
import { Helmet } from 'react-helmet';

const questions = [
  {
    question: 'Wie funktioniert das Haushaltsbuch von FamilienBudget?',
    answer:
      'Du verbindest deine Konten oder trägst Transaktionen manuell ein. Haushaltsbuch-Kategorien für Fixkosten, Alltag, Kinder, Sparziele und Schulden lassen sich frei definieren. Automatische Regeln sortieren Einnahmen und Ausgaben. Mit Monatsreviews siehst du, wo Optimierungspotenzial liegt.'
  },
  {
    question: 'Ist FamilienBudget DSGVO-konform?',
    answer:
      'Ja. Unsere Server stehen in Deutschland und wir arbeiten mit zertifizierten Schnittstellenpartnern zusammen. Du kannst das Haushaltsbuch komplett offline nutzen oder Daten jederzeit löschen.'
  },
  {
    question: 'Welche Rolle spielt der Notgroschen?',
    answer:
      'Der Notgroschen ist dein Sicherheitspolster für ungeplante Ausgaben. Wir empfehlen drei bis sechs Monatsausgaben für Angestellte, sechs bis zwölf Monate für Selbstständige. Unser Notgroschen-Rechner hilft dir bei der Planung.'
  },
  {
    question: 'Bietet ihr persönliche Beratung an?',
    answer:
      'Ja. Neben Onlinekursen bieten wir individuelle Finanzcoachings, Workshops für Familien und Analysegespräche, zum Beispiel für Budgetplanung bei Elternzeit, Studium oder Schuldenabbau.'
  },
  {
    question: 'Was kostet FamilienBudget?',
    answer:
      'Wir arbeiten mit flexiblen Modellen: Kostenfreie Basisvorlagen, monatliche Abos für digitale Tools und maßgeschneiderte Coaching-Pakete. Eine Übersicht senden wir dir gern nach dem Erstgespräch.'
  }
];

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <>
      <Helmet>
        <title>FAQ – Häufige Fragen zu FamilienBudget</title>
        <meta
          name="description"
          content="Antworten zu Haushaltsbuch, Datenschutz, Notgroschen, Beratung und Kosten von FamilienBudget."
        />
        <meta
          name="keywords"
          content="FAQ, Haushaltsbuch, Datenschutz, Notgroschen, Finanzberatung, Familienbudget"
        />
        <meta property="og:title" content="FamilienBudget FAQ" />
        <meta
          property="og:description"
          content="Alle Antworten zu Funktionen, Datenschutz, Notgroschen und Coaching."
        />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=1101" />
        <link rel="canonical" href="https://familienbudget.de/faq" />
      </Helmet>

      <section className="bg-primary py-20 text-white">
        <div className="container-padding mx-auto max-w-4xl text-center">
          <h1 className="text-3xl font-heading font-semibold">Häufige Fragen</h1>
          <p className="mt-4 text-sm text-slate-200 md:text-base">
            Klarheit rund um Haushaltsbuch, Budgetplanung, Datenschutz und persönliche Beratung.
          </p>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-4xl py-16">
        <div className="rounded-3xl bg-white p-8 shadow-soft">
          {questions.map((item, index) => (
            <div key={item.question} className="border-b border-light py-4">
              <button
                onClick={() => setOpenIndex(index === openIndex ? -1 : index)}
                className="flex w-full items-center justify-between text-left"
              >
                <span className="text-sm font-semibold text-primary">
                  {item.question}
                </span>
                <span className="text-accent">{openIndex === index ? '−' : '+'}</span>
              </button>
              {openIndex === index && (
                <p className="mt-3 text-sm text-slate-600">{item.answer}</p>
              )}
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default FAQ;