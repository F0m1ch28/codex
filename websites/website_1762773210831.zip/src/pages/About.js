import React from 'react';
import { Helmet } from 'react-helmet';

const About = () => {
  const timeline = [
    {
      year: '2020',
      title: 'Gründung von FamilienBudget',
      description:
        'Nach eigenen Herausforderungen mit Elternzeit, Teilzeitjobs und Fixkosten gründeten wir FamilienBudget in Berlin.'
    },
    {
      year: '2021',
      title: 'Launch des digitalen Haushaltsbuchs',
      description:
        'Wir veröffentlichten unser erstes Haushaltsbuch mit Kategorien, Alerts und Budgetregeln speziell für Familien.'
    },
    {
      year: '2022',
      title: 'Beratung & Workshops',
      description:
        'Finanzcoaches, Steuerexpert:innen und Pädagog:innen erweiterten das Team für individuelle Beratung und Familienkurse.'
    },
    {
      year: '2023',
      title: 'Partnerschaften & Community',
      description:
        'Kooperationen mit Verbraucherzentralen, Familienzentren und Bildungsträgern – die FamilienBudget-Community wuchs auf 15.000 Mitglieder.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Über FamilienBudget – Unsere Mission für Familienfinanzen</title>
        <meta
          name="description"
          content="FamilienBudget unterstützt Familien in Deutschland mit Haushaltsbuch, Budgetplanung, Workshops und Finanzwissen. Lerne unser Team und unsere Werte kennen."
        />
        <meta
          name="keywords"
          content="Familienfinanzen, Haushaltsbuch, Budgetplanung, Finanzbildung, Workshops, Sozialleistungen"
        />
        <meta property="og:title" content="Über FamilienBudget" />
        <meta
          property="og:description"
          content="Unser Team aus Finanzcoaches, Steuerexpert:innen und Pädagog:innen begleitet Familien zu stabilen Budgets."
        />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=501" />
        <link rel="canonical" href="https://familienbudget.de/about" />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'AboutPage',
            name: 'Über FamilienBudget',
            url: 'https://familienbudget.de/about',
            description:
              'FamilienBudget begleitet Familien mit Haushaltsbuch, Budgetplanung und Workshops in Deutschland.'
          })}
        </script>
      </Helmet>

      <section className="relative flex items-center justify-center overflow-hidden bg-primary/90 py-24 text-white">
        <img
          src="https://picsum.photos/1600/900?random=502"
          alt="Teammeeting bei FamilienBudget"
          className="absolute inset-0 h-full w-full object-cover opacity-60"
        />
        <div className="relative mx-auto max-w-4xl px-4 text-center">
          <h1 className="text-3xl font-heading font-semibold md:text-4xl">
            Unsere Mission: Finanzklarheit für Familien in Deutschland
          </h1>
          <p className="mt-4 text-sm text-slate-200 md:text-base">
            Wir glauben, dass jede Familie ein entspanntes Verhältnis zu Geld verdient – frei von Stress vor Monatsende, mit realistischen Zielen und fairen Routinen.
          </p>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-5xl py-16">
        <div className="rounded-3xl bg-white p-8 shadow-soft">
          <h2 className="section-title">Wer wir sind</h2>
          <p className="section-subtitle">
            FamilienBudget ist ein interdisziplinäres Team aus Finanzplanung, Steuerrecht, Sozialberatung und Pädagogik.
          </p>
          <div className="mt-8 grid gap-6 md:grid-cols-2">
            <div className="rounded-2xl border border-light p-6">
              <h3 className="text-base font-semibold text-primary">
                Finanzkompetenz & Coaching
              </h3>
              <p className="mt-2 text-sm text-slate-600">
                Unsere Coaches analysieren Haushaltsbücher, optimieren Fixkosten, strukturieren Kontenmodelle
                und begleiten beim Schuldenabbau. Wir übersetzen komplexe Finanzthemen in verständliche Schritte.
              </p>
            </div>
            <div className="rounded-2xl border border-light p-6">
              <h3 className="text-base font-semibold text-primary">
                Sozialleistungen & Steuerwissen
              </h3>
              <p className="mt-2 text-sm text-slate-600">
                Wir bleiben über Wohngeld Plus, Kinderzuschlag, Steuerentlastungen und Förderprogramme auf dem Laufenden und integrieren sie in deine Budgetplanung.
              </p>
            </div>
            <div className="rounded-2xl border border-light p-6">
              <h3 className="text-base font-semibold text-primary">
                Finanzbildung für Kinder & Jugendliche
              </h3>
              <p className="mt-2 text-sm text-slate-600">
                Mit Taschengeld-Plänen, Workshops und Checklisten fördern wir Finanzbildung spielerisch und stärken Selbstwirksamkeit.
              </p>
            </div>
            <div className="rounded-2xl border border-light p-6">
              <h3 className="text-base font-semibold text-primary">
                Datenschutz & Vertrauen
              </h3>
              <p className="mt-2 text-sm text-slate-600">
                DSGVO-Konformität, Server in Deutschland und transparente Prozesse. Du entscheidest jederzeit, welche Daten geteilt werden.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-background py-16">
        <div className="container-padding mx-auto max-w-5xl">
          <div className="rounded-3xl bg-white p-8 shadow-soft">
            <h2 className="section-title">Unsere Werte</h2>
            <p className="section-subtitle">
              Wir nehmen Familienrealitäten ernst: Care-Arbeit, Schichtmodelle, Patchwork, Selbstständigkeit oder Studium – wir passen jede Budgetstrategie individuell an.
            </p>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {[
                {
                  title: 'Empathie & Partnerschaft',
                  text: 'Wir hören zu, bewerten nicht, sondern entwickeln Lösungen, die zu euch passen.'
                },
                {
                  title: 'Transparenz & Wissen',
                  text: 'Wir erklären jede Zahl, jedes Tool und jede Regel leicht verständlich.'
                },
                {
                  title: 'Nachhaltige Routinen',
                  text: 'Wir setzen auf langfristige Gewohnheiten statt kurzfristiger Sparzwänge.'
                }
              ].map((value) => (
                <div key={value.title} className="card-hover rounded-2xl border border-light p-6">
                  <h3 className="text-base font-semibold text-primary">{value.title}</h3>
                  <p className="mt-2 text-sm text-slate-600">{value.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-5xl py-16">
        <div className="rounded-3xl bg-white p-8 shadow-soft">
          <h2 className="section-title">Meilensteine</h2>
          <div className="mt-8 space-y-6">
            {timeline.map((item) => (
              <div
                key={item.year}
                className="flex flex-col gap-4 rounded-2xl border border-light p-6 md:flex-row md:items-start"
              >
                <div className="text-sm font-semibold text-accent md:w-24">{item.year}</div>
                <div>
                  <h3 className="text-base font-semibold text-primary">{item.title}</h3>
                  <p className="mt-2 text-sm text-slate-600">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default About;