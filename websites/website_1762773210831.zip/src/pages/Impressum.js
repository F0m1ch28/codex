import React from 'react';
import { Helmet } from 'react-helmet';

const Impressum = () => (
  <>
    <Helmet>
      <title>Impressum – FamilienBudget</title>
      <meta
        name="description"
        content="Impressum der FamilienBudget GmbH mit Angaben gemäß § 5 TMG."
      />
      <meta property="og:title" content="Impressum FamilienBudget" />
      <meta property="og:image" content="https://picsum.photos/1200/630?random=1501" />
      <link rel="canonical" href="https://familienbudget.de/impressum" />
    </Helmet>

    <section className="container-padding mx-auto max-w-4xl py-20">
      <h1 className="text-3xl font-heading font-semibold text-primary">Impressum</h1>
      <div className="mt-6 space-y-4 text-sm text-slate-600">
        <p>
          FamilienBudget GmbH
          <br />
          Oranienstraße 24
          <br />
          10999 Berlin
        </p>
        <p>
          Telefon: +49 (0)30 123 456 70
          <br />
          E-Mail: hallo@familienbudget.de
        </p>
        <p>
          Geschäftsführer: Mara Fischer, Jonas Reuter
          <br />
          Handelsregister: Amtsgericht Berlin-Charlottenburg, HRB 123456
          <br />
          USt-IdNr.: DE321654987
        </p>
        <p>
          Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV:
          <br />
          Mara Fischer, Oranienstraße 24, 10999 Berlin
        </p>
        <p>
          Plattform der EU-Kommission zur Online-Streitbeilegung:{' '}
          <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noreferrer" className="text-accent underline">
            https://ec.europa.eu/consumers/odr
          </a>
        </p>
      </div>
    </section>
  </>
);

export default Impressum;