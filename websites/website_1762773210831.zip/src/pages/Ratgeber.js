import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';

const guides = [
  {
    title: 'Basiswissen Familienfinanzen',
    description:
      'Haushaltsbuch starten, Fixkosten analysieren, Spartipps etablieren. Mit Checklisten für den ersten Monat.',
    image: 'https://picsum.photos/800/600?random=801',
    points: [
      'Haushaltsbuch-Aufbau in 5 Schritten',
      'Budgetplanung für Angestellte & Selbstständige',
      'Kontenmodelle für Familien und Paare'
    ]
  },
  {
    title: 'Sozialleistungen & Förderungen',
    description:
      'Überblick zu Kinderzuschlag, Wohngeld Plus, Bildungspaket und regionalen Familienleistungen mit Anspruchsprüfung.',
    image: 'https://picsum.photos/800/600?random=802',
    points: [
      'Checkliste Unterlagen & Fristen',
      'Links zu Anträgen und Beratungsstellen',
      'So kombinierst du Leistungen mit Budgetplanung'
    ]
  },
  {
    title: 'Versicherungen & Absicherung',
    description:
      'Welche Versicherungen sind Pflicht, welche nice-to-have? Von Haftpflicht über BU bis zu Krankentagegeld.',
    image: 'https://picsum.photos/800/600?random=803',
    points: [
      'Fixkostenquoten im Blick',
      'Vergleichskriterien für Familienversicherungen',
      'Übersicht zu Fristen und Kündigung'
    ]
  },
  {
    title: 'Steuertipps für Familien',
    description:
      'Steuerklassen, Freibeträge, Homeoffice-Pauschale und wie du Ausgaben im Haushaltsbuch steuerlich nutzt.',
    image: 'https://picsum.photos/800/600?random=804',
    points: [
      'Jährlicher Steuerfahrplan',
      'Belege smart sammeln',
      'Rücklagen für Nachzahlungen planen'
    ]
  }
];

const Ratgeber = () => {
  return (
    <>
      <Helmet>
        <title>Ratgeber – Basiswissen, Sozialleistungen, Versicherungen & Steuern</title>
        <meta
          name="description"
          content="Kompetente Ratgeber für Familienfinanzen: Haushaltsbuch, Sozialleistungen, Versicherungen und Steuertipps verständlich erklärt."
        />
        <meta
          name="keywords"
          content="Ratgeber Familienfinanzen, Sozialleistungen, Versicherungen, Steuertipps, Haushaltsbuch"
        />
        <meta property="og:title" content="FamilienBudget Ratgeber" />
        <meta
          property="og:description"
          content="Basiswissen zu Budgetplanung, Sozialleistungen, Versicherungen und Steuertipps für Familien."
        />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=805" />
        <link rel="canonical" href="https://familienbudget.de/ratgeber" />
      </Helmet>

      <section className="relative bg-primary py-20 text-white">
        <img
          src="https://picsum.photos/1600/900?random=806"
          alt="Familie liest Finanzratgeber"
          className="absolute inset-0 h-full w-full object-cover opacity-50"
        />
        <div className="relative mx-auto max-w-4xl px-4 text-center">
          <h1 className="text-3xl font-heading font-semibold md:text-4xl">
            Ratgeber für jede Familienphase
          </h1>
          <p className="mt-4 text-sm text-slate-200 md:text-base">
            Von Basiswissen über Sozialleistungen bis zu Versicherungen und Steuertipps – alle
            Inhalte sind auf Familien in Deutschland zugeschnitten.
          </p>
        </div>
      </section>

      <section className="container-padding mx-auto max-w-6xl py-16">
        <div className="grid gap-8 md:grid-cols-2">
          {guides.map((guide) => (
            <article
              key={guide.title}
              className="card-hover overflow-hidden rounded-3xl border border-light bg-white shadow-soft"
            >
              <img
                src={guide.image}
                alt={guide.title}
                className="h-48 w-full object-cover"
                loading="lazy"
              />
              <div className="p-6">
                <span className="tag-pill">Ratgeber</span>
                <h2 className="mt-4 text-lg font-semibold text-primary">{guide.title}</h2>
                <p className="mt-3 text-sm text-slate-600">{guide.description}</p>
                <ul className="mt-4 space-y-2 text-xs text-slate-500">
                  {guide.points.map((point) => (
                    <li key={point} className="flex items-start gap-2">
                      <span className="mt-1 text-success">●</span>
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  to="/contact"
                  className="mt-4 inline-flex text-sm font-semibold text-accent"
                >
                  Beratung anfragen →
                </Link>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-12 rounded-3xl bg-white p-8 shadow-soft">
          <h2 className="text-2xl font-heading font-semibold text-primary">
            Checklisten zum Download
          </h2>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            {[
              'Monatliche Budget-Routine',
              'Kindergeld & Kinderzuschlag',
              'Versicherungsscreening',
              'Steuer- & Fristenkalender',
              'Studium, Ausbildung & Übergänge',
              'Elternzeit & Teilzeitplanung'
            ].map((item) => (
              <div key={item} className="rounded-2xl border border-light p-5 text-sm text-slate-600">
                <p className="font-semibold text-primary">{item}</p>
                <p className="mt-2 text-xs text-slate-500">
                  PDF im Mitgliederbereich, inklusive Schritt-für-Schritt-Anleitung.
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Ratgeber;