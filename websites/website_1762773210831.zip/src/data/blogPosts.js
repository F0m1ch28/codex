const blogPosts = [
  {
    slug: 'budget-503020-de',
    title: '50/30/20 für deutsche Haushalte',
    excerpt:
      'Wie du mit der 50/30/20-Regel Fixkosten, Wünsche und Sparziele trennst und dein Haushaltsbuch strukturiert führst.',
    heroImage: 'https://picsum.photos/1200/650?random=201',
    date: '2023-08-01',
    readTime: '7 Min.',
    author: 'Mara Fischer',
    tags: ['Budgetplanung', 'Haushaltsbuch', 'Familienfinanzen'],
    metaDescription:
      'Die 50/30/20-Regel hilft deutschen Familien, Haushalt, Fixkosten, Wünsche und Rücklagen klar zu strukturieren. Mit Beispielrechnung und Tipps für Familienbudgets.',
    content: [
      {
        heading: 'Warum das 50/30/20-Regelwerk funktioniert',
        paragraphs: [
          'Das 50/30/20-Prinzip verteilt dein Einkommen auf Pflichtausgaben, persönliche Wünsche und Sparziele. Gerade für Familien ist die klare Aufteilung entscheidend, um Fixkosten wie Miete, Energie, Versicherung und Kitagebühren sicher abzudecken.',
          'In deutschen Haushalten bietet die Regel Struktur für Haushaltsbuch und Girokonto: 50 % für Fixkosten, 30 % für variable Wünsche, 20 % für Rücklagen, Notgroschen und langfristige Ziele wie Tagesgeld oder ETF-Sparplan.'
        ]
      },
      {
        heading: 'Konkrete Schritte für Familien',
        paragraphs: [
          'Starte mit einem Haushaltsbuch: Erfasse drei Monate lang Einnahmen und Ausgaben. Klassifiziere jede Position in Fixkosten, Wünsche oder Sparen.',
          'Nutze Kontenmodelle: Ein Girokonto für Fixkosten, ein Gemeinschaftskonto für Alltag, ein Tagesgeldkonto für Rücklagen. Automatisiere deine Überweisungen direkt nach Gehaltseingang.'
        ],
        listTitle: 'Checkliste zum Loslegen',
        list: [
          'Nettoeinkommen und Kindergeld erfassen',
          'Fixkostenquote berechnen und ggf. Versicherungen optimieren',
          '30 %-Topf für Freizeit und variable Ausgaben begrenzen',
          '20 %-Quote für Notgroschen und Ziele automatisieren'
        ]
      },
      {
        heading: 'Anpassungen für moderne Familienbudgets',
        paragraphs: [
          'Die Realität verlangt Flexibilität: Wenn eure Fixkosten über 50 % liegen, reduziere zuerst variable Ausgaben, bevor du Sparziele kürzt. Prüfe außerdem Ansprüche auf Sozialleistungen wie Wohngeld Plus oder Kinderzuschlag.',
          'Plane regelmäßige Budget-Reviews. Familienleben ändert sich durch Elternzeit, Schule, Umzug oder neue Ziele. Passe die 50/30/20-Verteilung dynamisch an und dokumentiere jeden Schritt im Haushaltsbuch.'
        ],
        highlight:
          'Expertentipp: Lege den Notgroschen für drei bis sechs Monatsausgaben auf ein Tagesgeldkonto. So bleibt der Betrag verfügbar und getrennt vom Girokonto.'
      }
    ]
  },
  {
    slug: 'notgroschen-berechnen',
    title: 'So groß sollte dein Notgroschen sein',
    excerpt:
      'Berechne in drei Schritten deinen Notgroschen und erfahre, welche Rücklagen deutsche Familien wirklich brauchen.',
    heroImage: 'https://picsum.photos/1200/650?random=202',
    date: '2023-09-12',
    readTime: '6 Min.',
    author: 'Jonas Reuter',
    tags: ['Notgroschen', 'Rücklagen', 'Sicherheit'],
    metaDescription:
      'Mit dem Notgroschen-Rechner von FamilienBudget bestimmst du die passende Rücklage für unerwartete Ausgaben. Leitfaden für drei bis zwölf Monatsausgaben.',
    content: [
      {
        heading: 'Warum ein Notgroschen unverzichtbar ist',
        paragraphs: [
          'Reparaturen, Jobwechsel oder krankheitsbedingte Ausfälle – ungeplante Kosten treffen Familien oft hart. Ein Notgroschen schafft Sicherheit, ohne Kredite oder Dispo nutzen zu müssen.',
          'Der Betrag hängt von euren Lebenshaltungskosten, Beschäftigungsform und Familiengröße ab. Selbstständige und Alleinverdiener:innen sollten höhere Rücklagen planen.'
        ]
      },
      {
        heading: 'So berechnest du deine Zielgröße',
        paragraphs: [
          'Addiere alle monatlichen Fixkosten (Miete, Energie, Versicherungen, Kredite, Kitagebühren) und essenziellen variablen Ausgaben wie Lebensmittel und Mobilität.',
          'Multipliziere den Betrag mit drei bis sechs Monaten. Bei unsicheren Einkommen sind neun bis zwölf Monate sinnvoll. Hinterlege diese Summe auf einem Tagesgeldkonto.'
        ],
        listTitle: 'Rechner-Eingaben, die du brauchst',
        list: [
          'Monatliche Fixkosten inkl. Versicherungen',
          'Regelmäßige variable Kosten (Lebensmittel, Mobilität)',
          'Bestehende Rücklagen und Bafög/KfW-Verpflichtungen',
          'Sicherheitsfaktor (3-12 Monate)'
        ]
      },
      {
        heading: 'Notgroschen im Haushaltsplan verankern',
        paragraphs: [
          'Baue den Notgroschen in deine Budgetplanung ein: Jede Gehaltszahlung legt automatisch einen Anteil auf das Rücklagenkonto. So wächst der Sicherheitsbaustein kontinuierlich.',
          'Nutze Zieltracker in FamilienBudget, um den Fortschritt sichtbar zu machen. Kleine Meilensteine motivieren und zeigen, wie viel Puffer bereits vorhanden ist.'
        ],
        highlight:
          'Richte ein separates Tagesgeldkonto ein, damit der Notgroschen unangetastet bleibt und dennoch täglich verfügbar ist.'
      }
    ]
  },
  {
    slug: 'kontenmodell-familie',
    title: 'Kontenmodell für Paare & Familien',
    excerpt:
      'Das 3-Konten-Modell sorgt für faire Verteilung, Transparenz und klare Verantwortlichkeiten im Familienbudget.',
    heroImage: 'https://picsum.photos/1200/650?random=203',
    date: '2023-07-18',
    readTime: '8 Min.',
    author: 'Lea Sommer',
    tags: ['Kontenmodell', 'Girokonto', 'Familienfinanzen'],
    metaDescription:
      'Vergleiche Kontenmodelle für Paare und Familien: Gemeinschaftskonto, Einzelkonten und Tagesgeld für Fixkosten, Freizeit und Rücklagen.',
    content: [
      {
        heading: 'Warum ein Kontenmodell Struktur schafft',
        paragraphs: [
          'Mit getrennten und gemeinsamen Konten lassen sich Fixkosten, variable Ausgaben und Sparziele transparent organisieren. Jede Person behält finanzielle Freiheit, während Familienausgaben gemeinsam gesteuert werden.',
          'Das Modell verhindert Stress über Kleinigkeiten und stärkt das Vertrauen in die gemeinsame Budgetplanung.'
        ]
      },
      {
        heading: 'Das 3-Konten-Modell im Überblick',
        paragraphs: [
          'Konto 1 (Gemeinschaft): Einnahmen, Fixkosten, langfristige Verpflichtungen wie Kita oder Versicherungen. Konto 2 (Person A) und Konto 3 (Person B): variable Ausgaben, Taschengeld, persönliche Rücklagen.',
          'Ergänze ein Tagesgeldkonto für Notgroschen und ein Unterkonto für kurzfristige Ziele wie Urlaub oder Renovierung. Automatisiere Überweisungen zum Monatsbeginn.'
        ],
        listTitle: 'Vorteile für Familien',
        list: [
          'Klare Nachvollziehbarkeit der Haushaltskosten',
          'Gerechte Verteilung nach Einkommen oder prozentualen Anteilen',
          'Gemeinsamer Fokus auf Sparziele und Schuldenabbau',
          'Schnelle Budget-Checks mit der FamilienBudget-App'
        ]
      },
      {
        heading: 'So startest du in 30 Minuten',
        paragraphs: [
          '1. Fixkostenliste erstellen und Summe definieren. 2. Daueraufträge einrichten: Gehalt auf Gemeinschaftskonto, Sparbeträge auf Tagesgeld, Taschengeld auf Einzelkonten.',
          '3. Haushaltsbuch anlegen und Kategorien definieren (Fixkosten, Alltag, Kinder, Freizeit, Rücklagen). 4. Monatlich analysieren und anpassen.'
        ],
        highlight:
          'Transparente Kommunikation ist entscheidend: Legt gemeinsame Regeln fest, wie mit Sonderausgaben, Prämien oder Geschenken umgegangen wird.'
      }
    ]
  }
];

export default blogPosts;