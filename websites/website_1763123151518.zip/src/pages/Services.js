import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'General Counsel Support',
    description: 'Embed CLP attorneys alongside executive teams for ongoing legal strategy, decision briefings, and board readiness.',
    details: ['Strategic advisory retainers', 'Policy drafting and governance updates', 'Executive briefing materials']
  },
  {
    title: 'Transactions Leadership',
    description: 'Drive diligence, negotiation, and closing activities for mergers, acquisitions, and investments.',
    details: ['Deal structuring and documentation', 'Regulatory filings and approvals', 'Integration planning']
  },
  {
    title: 'Litigation Command Centre',
    description: 'Coordinate complex disputes with disciplined project management, evidence workflows, and stakeholder communications.',
    details: ['Case strategy and risk assessment', 'Witness preparation and evidence management', 'Hearing and arbitration advocacy']
  },
  {
    title: 'Employment Transformation Hub',
    description: 'Guide organisations through workforce changes, social dialogue, and executive transitions.',
    details: ['Collective consultation roadmaps', 'Executive contract strategy', 'Post-restructuring compliance']
  },
  {
    title: 'Regulatory Horizon Scanning',
    description: 'Monitor EU directives and Belgian regulations with tailored impact assessments and implementation plans.',
    details: ['Regulatory watch briefs', 'Gap analyses and action plans', 'Engagement with EU institutions']
  }
];

const Services = () => (
  <>
    <Helmet>
      <title>Services | Consonragp Legal Partners</title>
      <meta
        name="description"
        content="Discover Consonragp Legal Partners’ service offerings including general counsel support, transactional leadership, litigation strategy, employment transformation, and regulatory monitoring."
      />
      <link rel="canonical" href="https://www.example.com/services" />
    </Helmet>
    <section className={styles.hero}>
      <div>
        <p className={styles.kicker}>Services</p>
        <h1>Integrated legal services for forward-looking organisations</h1>
        <p>We design service models around your operating rhythm, enabling legal teams and executives to address challenges proactively.</p>
      </div>
    </section>
    <section className={styles.grid}>
      {services.map((service) => (
        <article key={service.title} className={styles.card}>
          <h2>{service.title}</h2>
          <p>{service.description}</p>
          <ul>
            {service.details.map((detail) => (
              <li key={detail}>{detail}</li>
            ))}
          </ul>
        </article>
      ))}
    </section>
  </>
);

export default Services;