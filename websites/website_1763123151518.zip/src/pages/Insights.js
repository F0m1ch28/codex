import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Insights.module.css';

const insightsContent = [
  {
    title: 'EU Digital Services Act: Compliance Timelines for Belgian Platforms',
    date: 'February 9, 2024',
    category: 'Regulatory Update',
    summary:
      'Key steps for platforms and intermediaries operating in Belgium to meet the Digital Services Act obligations, including transparency reporting and risk assessments.',
    link: '#'
  },
  {
    title: 'Commercial Court of Brussels: Managing Cross-Border Evidence',
    date: 'January 21, 2024',
    category: 'Case Study',
    summary:
      'How we coordinated multilingual documentation, expert testimony, and digital evidence to secure a favourable ruling in a distribution dispute.',
    link: '#'
  },
  {
    title: 'Sustainable Finance Disclosure: What Boards Should Review in 2024',
    date: 'December 18, 2023',
    category: 'Insight',
    summary:
      'Practical actions for directors responding to new ESG reporting obligations, including governance adjustments and data verification protocols.',
    link: '#'
  },
  {
    title: 'Human Capital Strategy Post-Reorganisation',
    date: 'November 7, 2023',
    category: 'Employment Brief',
    summary:
      'A blueprint for employers to manage communications, employee wellbeing, and regulatory filings following workforce restructuring.',
    link: '#'
  }
];

const Insights = () => (
  <>
    <Helmet>
      <title>Insights & Updates | Consonragp Legal Partners</title>
      <meta
        name="description"
        content="Read legal insights, regulatory updates, and case studies from Consonragp Legal Partners’ attorneys in Brussels."
      />
      <link rel="canonical" href="https://www.example.com/insights" />
    </Helmet>
    <section className={styles.hero}>
      <div>
        <p className={styles.kicker}>Insights</p>
        <h1>Legal intelligence for resilient decision-making</h1>
        <p>
          Stay ahead of Belgian and EU legal developments with briefings authored by Consonragp Legal Partners’ attorneys.
        </p>
      </div>
    </section>
    <section className={styles.grid}>
      {insightsContent.map((item) => (
        <article key={item.title} className={styles.card}>
          <img src="https://picsum.photos/800/600?random=91" alt="Brussels legal conference" loading="lazy" />
          <div className={styles.info}>
            <span className={styles.category}>{item.category}</span>
            <h2>{item.title}</h2>
            <p className={styles.date}>{item.date}</p>
            <p>{item.summary}</p>
            <a href={item.link} className={styles.link} aria-label={`Read more about ${item.title}`}>
              Continue reading →
            </a>
          </div>
        </article>
      ))}
    </section>
  </>
);

export default Insights;