import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPages.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Service | Consonragp Legal Partners</title>
      <meta
        name="description"
        content="Review the terms governing the use of Consonragp Legal Partners’ website and services."
      />
      <link rel="canonical" href="https://www.example.com/terms" />
    </Helmet>
    <section className={styles.section}>
      <h1>Terms of Service</h1>
      <p>Last updated: January 2024</p>
      <h2>1. Introduction</h2>
      <p>
        These Terms of Service govern your access to the Consonragp Legal Partners website. By browsing or interacting with the site, you accept these terms. If you do not agree, please discontinue use.
      </p>
      <h2>2. Professional relationship</h2>
      <p>
        Accessing this website does not establish an attorney-client relationship. Such a relationship is formed only after we confirm engagement in writing and agree on the scope of services.
      </p>
      <h2>3. Information on the website</h2>
      <p>
        The materials provided are for general information only and should not be relied upon as legal advice. We make reasonable efforts to keep content accurate but do not guarantee completeness or timeliness.
      </p>
      <h2>4. Intellectual property</h2>
      <p>
        All texts, graphics, and design elements are owned by Consonragp Legal Partners unless otherwise stated. You may view and print content for personal use. Any other use requires prior written consent.
      </p>
      <h2>5. External links</h2>
      <p>
        The website may link to external resources. We are not responsible for the content or privacy policies of third-party sites.
      </p>
      <h2>6. Limitation of liability</h2>
      <p>
        To the fullest extent permitted by Belgian law, Consonragp Legal Partners is not liable for losses arising from the use of the website or reliance on its content.
      </p>
      <h2>7. Governing law and jurisdiction</h2>
      <p>
        These terms are governed by Belgian law. Any disputes shall be submitted to the exclusive jurisdiction of the courts of Brussels.
      </p>
    </section>
  </>
);

export default Terms;