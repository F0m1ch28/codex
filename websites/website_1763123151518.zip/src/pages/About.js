import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>About Us | Consonragp Legal Partners</title>
      <meta
        name="description"
        content="Learn about Consonragp Legal Partners’ history, leadership, and values. Discover how our Brussels-based law firm delivers strategic legal counsel."
      />
      <link rel="canonical" href="https://www.example.com/about" />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.content}>
        <p className={styles.kicker}>Our Story</p>
        <h1>Advocating with precision since 2006</h1>
        <p>
          Consonragp Legal Partners was founded by attorneys determined to combine meticulous legal craftsmanship with a collaborative client experience. Our practice has grown alongside Belgium’s dynamic business landscape, advising organisations as they scale, restructure, and resolve complex disputes across Europe.
        </p>
      </div>
      <img src="https://picsum.photos/1200/800?random=51" alt="Historic Brussels architecture representing legal heritage" loading="lazy" />
    </section>

    <section className={styles.history}>
      <div className={styles.timeline}>
        <div>
          <h2>Milestones in our evolution</h2>
          <p>From boutique corporate counsel to full-service litigation and regulatory advisors, our trajectory reflects clients’ trust and the complexity of mandates we handle.</p>
        </div>
        <ul>
          <li>
            <span>2006</span>
            <p>CLP opens its doors on Avenue Louise with a focus on corporate governance and cross-border transactions.</p>
          </li>
          <li>
            <span>2012</span>
            <p>Launch of our Commercial Disputes practice, representing multinational clients in arbitration and Belgian courts.</p>
          </li>
          <li>
            <span>2017</span>
            <p>Employment & Social Dialogue group formed to guide enterprises through collective bargaining and compliance reforms.</p>
          </li>
          <li>
            <span>2021</span>
            <p>Expanded Regulatory & EU Affairs desk to advise on digital services, sustainable finance, and competition law.</p>
          </li>
        </ul>
      </div>
    </section>

    <section className={styles.values}>
      <h2>Our guiding principles</h2>
      <div className={styles.grid}>
        <article>
          <h3>Client-first judgement</h3>
          <p>We consider every recommendation through the lens of your organisation’s strategy, risk tolerance, and stakeholder expectations.</p>
        </article>
        <article>
          <h3>Collaborative intelligence</h3>
          <p>Our attorneys share knowledge, coordinate across disciplines, and leverage collective experience to deliver integrated counsel.</p>
        </article>
        <article>
          <h3>Transparent communication</h3>
          <p>We provide concise updates, clear reporting, and risk assessments that enable executive teams to decide with confidence.</p>
        </article>
        <article>
          <h3>Ethical stewardship</h3>
          <p>Integrity sits at the core of our practice. We maintain the highest professional standards in every forum and engagement.</p>
        </article>
      </div>
    </section>

    <section className={styles.partners} aria-labelledby="partners-heading">
      <div className={styles.header}>
        <h2 id="partners-heading">Partners & senior counsel</h2>
        <p>Our leadership team draws on decades of collective experience across corporate law, litigation, employment strategy, and regulatory compliance.</p>
      </div>
      <div className={styles.cards}>
        {[
          {
            name: 'Claire Bouchard',
            role: 'Managing Partner',
            bio: 'Claire advises boards and executive teams on cross-border transactions, corporate restructurings, and ESG governance. She is valued for her ability to align legal strategy with business transformation.',
            image: 'https://picsum.photos/400/400?random=61'
          },
          {
            name: 'Lukas Meyer',
            role: 'Partner – Commercial Disputes',
            bio: 'Lukas leads complex litigation and arbitration matters across Benelux and EU jurisdictions, managing high-stakes disputes with disciplined advocacy and thorough evidentiary preparation.',
            image: 'https://picsum.photos/400/400?random=62'
          },
          {
            name: 'Amélie Dupont',
            role: 'Partner – Employment & Social Dialogue',
            bio: 'Amélie supports multinational employers with workforce transitions, social dialogue strategies, and executive employment matters, ensuring compliance and clear stakeholder communication.',
            image: 'https://picsum.photos/400/400?random=63'
          },
          {
            name: 'Jasper Claes',
            role: 'Senior Counsel – Regulatory & EU Affairs',
            bio: 'Jasper focuses on EU regulatory developments, especially in digital services, sustainable finance, and competition regulation, providing proactive compliance roadmaps for clients.',
            image: 'https://picsum.photos/400/400?random=64'
          }
        ].map((partner) => (
          <article key={partner.name} className={styles.card}>
            <img src={partner.image} alt={`${partner.name} portrait`} loading="lazy" />
            <div>
              <h3>{partner.name}</h3>
              <p className={styles.role}>{partner.role}</p>
              <p>{partner.bio}</p>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.valuesStatement}>
      <div className={styles.statementContent}>
        <h2>Our commitment to clients</h2>
        <p>
          We invest the time to understand your organisation’s priorities, tailoring legal frameworks that stand up to scrutiny and support sustainable growth. When the stakes are high, we act with urgency, discretion, and unwavering focus on achieving the right outcome.
        </p>
      </div>
      <img src="https://picsum.photos/1100/800?random=52" alt="Law library and meeting space in Brussels office" loading="lazy" />
    </section>
  </>
);

export default About;