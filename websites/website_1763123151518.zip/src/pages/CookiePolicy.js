import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPages.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Consonragp Legal Partners</title>
      <meta
        name="description"
        content="Learn how Consonragp Legal Partners uses cookies and similar technologies on this website."
      />
      <link rel="canonical" href="https://www.example.com/cookie-policy" />
    </Helmet>
    <section className={styles.section}>
      <h1>Cookie Policy</h1>
      <p>Last updated: January 2024</p>
      <h2>1. What are cookies?</h2>
      <p>
        Cookies are small data files that websites store on your device. They help improve performance, remember preferences, and analyse site usage.
      </p>
      <h2>2. Types of cookies we use</h2>
      <p>
        We use essential cookies for site functionality and analytics cookies to understand visitor interactions. Analytics cookies are activated only with your consent.
      </p>
      <h2>3. Managing cookies</h2>
      <p>
        You may update your cookie preferences at any time through your browser settings. Declining cookies may affect certain features.
      </p>
      <h2>4. Third-party cookies</h2>
      <p>
        Some cookies may be placed by trusted service providers offering analytics and performance tools. These providers process data on our behalf.
      </p>
      <h2>5. Contact</h2>
      <p>
        For questions about cookie usage, contact privacy@consonragplegal.com.
      </p>
    </section>
  </>
);

export default CookiePolicy;