import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Attorneys.module.css';

const attorneys = [
  {
    name: 'Claire Bouchard',
    title: 'Managing Partner – Corporate & Governance',
    education: 'LL.M., University of Cambridge | Master of Laws, Université catholique de Louvain',
    expertise: 'Corporate governance, cross-border mergers, ESG advisory, board strategy.',
    image: 'https://picsum.photos/500/500?random=81'
  },
  {
    name: 'Lukas Meyer',
    title: 'Partner – Commercial Disputes & Arbitration',
    education: 'LL.M., Columbia Law School | Law Degree, KU Leuven',
    expertise: 'International arbitration, commercial litigation, urgent relief proceedings.',
    image: 'https://picsum.photos/500/500?random=82'
  },
  {
    name: 'Amélie Dupont',
    title: 'Partner – Employment & Social Dialogue',
    education: 'LL.M., Université Libre de Bruxelles | Postgraduate, Sorbonne University',
    expertise: 'Collective bargaining, executive employment, workforce restructuring.',
    image: 'https://picsum.photos/500/500?random=83'
  },
  {
    name: 'Jasper Claes',
    title: 'Senior Counsel – Regulatory & EU Affairs',
    education: 'LL.M., College of Europe | Law Degree, Ghent University',
    expertise: 'EU regulatory compliance, digital services, competition law.',
    image: 'https://picsum.photos/500/500?random=84'
  },
  {
    name: 'Sophie van den Berg',
    title: 'Counsel – Transactions & Financing',
    education: 'LL.M., London School of Economics | Law Degree, University of Antwerp',
    expertise: 'Private equity, venture financing, joint ventures, corporate reorganisations.',
    image: 'https://picsum.photos/500/500?random=85'
  },
  {
    name: 'Oliver Schmidt',
    title: 'Counsel – Litigation & Investigations',
    education: 'LL.M., Humboldt University | Law Degree, University of Bonn',
    expertise: 'Internal investigations, compliance reviews, multi-jurisdictional disputes.',
    image: 'https://picsum.photos/500/500?random=86'
  }
];

const Attorneys = () => (
  <>
    <Helmet>
      <title>Our Attorneys | Consonragp Legal Partners</title>
      <meta
        name="description"
        content="Meet the attorneys of Consonragp Legal Partners. Explore their specialisations, experience, and educational backgrounds."
      />
      <link rel="canonical" href="https://www.example.com/attorneys" />
    </Helmet>
    <section className={styles.hero}>
      <div>
        <p className={styles.kicker}>Our Team</p>
        <h1>Dedicated attorneys with international perspective</h1>
        <p>
          Each attorney at Consonragp Legal Partners brings a blend of technical expertise, multilingual capability, and a commitment to collaborative problem solving.
        </p>
      </div>
    </section>
    <section className={styles.grid}>
      {attorneys.map((attorney) => (
        <article key={attorney.name} className={styles.card}>
          <img src={attorney.image} alt={`${attorney.name}`} loading="lazy" />
          <div className={styles.info}>
            <h2>{attorney.name}</h2>
            <p className={styles.title}>{attorney.title}</p>
            <p><strong>Education:</strong> {attorney.education}</p>
            <p><strong>Focus:</strong> {attorney.expertise}</p>
          </div>
        </article>
      ))}
    </section>
  </>
);

export default Attorneys;