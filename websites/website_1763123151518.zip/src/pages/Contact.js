import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [form, setForm] = React.useState({
    name: '',
    email: '',
    organisation: '',
    message: ''
  });

  const [submitted, setSubmitted] = React.useState(false);
  const [errors, setErrors] = React.useState({});

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Please provide your full name.';
    if (!form.email.trim()) {
      newErrors.email = 'Please provide a professional email address.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(form.email)) {
      newErrors.email = 'Enter a valid email address.';
    }
    if (!form.message.trim()) newErrors.message = 'Tell us more about your legal objectives.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setForm({
        name: '',
        email: '',
        organisation: '',
        message: ''
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact | Consonragp Legal Partners</title>
        <meta
          name="description"
          content="Contact Consonragp Legal Partners in Brussels to schedule a consultation. Located on Avenue Louise 250 with multilingual legal support."
        />
        <link rel="canonical" href="https://www.example.com/contact" />
      </Helmet>
      <section className={styles.hero}>
        <div>
          <p className={styles.kicker}>Contact</p>
          <h1>Connect with Consonragp Legal Partners</h1>
          <p>
            Share your objectives and our team will coordinate a consultation with the right attorneys. Meetings can be held in person in Brussels or virtually.
          </p>
        </div>
      </section>
      <section className={styles.contactSection}>
        <div className={styles.infoCard}>
          <h2>Brussels Office</h2>
          <p>Avenue Louise 250<br />1050 Brussels, Belgium</p>
          <p><strong>Phone:</strong> <a href="tel:+3221234567">+32 2 123 4567</a></p>
          <p><strong>Email:</strong> <a href="mailto:contact@consonragplegal.com">contact@consonragplegal.com</a></p>
          <p><strong>Languages:</strong> English, French, Dutch, German, Italian, Spanish</p>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.fieldGroup}>
            <label htmlFor="name">Full name *</label>
            <input type="text" id="name" name="name" value={form.name} onChange={handleChange} aria-required="true" aria-invalid={!!errors.name} />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.fieldGroup}>
            <label htmlFor="email">Email *</label>
            <input type="email" id="email" name="email" value={form.email} onChange={handleChange} aria-required="true" aria-invalid={!!errors.email} />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.fieldGroup}>
            <label htmlFor="organisation">Organisation</label>
            <input type="text" id="organisation" name="organisation" value={form.organisation} onChange={handleChange} />
          </div>
          <div className={styles.fieldGroup}>
            <label htmlFor="message">How can we assist? *</label>
            <textarea id="message" name="message" rows="5" value={form.message} onChange={handleChange} aria-required="true" aria-invalid={!!errors.message} />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </div>
          <button type="submit" className={styles.submitBtn}>Submit request</button>
          {submitted && <p className={styles.success}>Thank you. Our client services team will contact you shortly.</p>}
        </form>
      </section>
      <section className={styles.mapSection}>
        <iframe
          title="Consonragp Legal Partners office location"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2519.32415423618!2d4.35514917710508!3d50.82496816291358!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c3c4840f28ddc9%3A0x8d9fcb31d6b82620!2sAv.%20Louise%20250%2C%201050%20Ixelles%2C%20Belgium!5e0!3m2!1sen!2sbe!4v1707391354002!5m2!1sen!2sbe"
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </section>
    </>
  );
};

export default Contact;