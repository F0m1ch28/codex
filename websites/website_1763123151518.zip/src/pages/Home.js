import React from 'react';
import { Helmet } from 'react-helmet';
import { NavLink } from 'react-router-dom';
import styles from './Home.module.css';

const statsData = [
  { label: 'Years advising cross-border operations', value: 18 },
  { label: 'Successful commercial litigations', value: 240 },
  { label: 'Corporate reorganisations completed', value: 125 },
  { label: 'Languages spoken by our team', value: 6 }
];

const practiceAreas = [
  {
    title: 'Corporate Law',
    description: 'Strategic counsel on structuring, governance, mergers, and cross-border investments tailored to Belgium’s regulatory environment.'
  },
  {
    title: 'Commercial Disputes',
    description: 'Resolving complex disputes through litigation and arbitration with meticulous preparation and outcome-focused advocacy.'
  },
  {
    title: 'Employment Law',
    description: 'Guiding businesses through workforce strategy, executive agreements, collective bargaining, and restructuring obligations.'
  },
  {
    title: 'Contract Advisory',
    description: 'Drafting, negotiating, and auditing critical agreements to align risk, compliance frameworks, and operational objectives.'
  }
];

const testimonials = [
  {
    quote: 'Consonragp Legal Partners have an exceptional ability to decode complex regulatory scenarios and deliver actionable strategies on tight timelines.',
    name: 'Isabelle Lemaire',
    role: 'General Counsel, European MedTech Group'
  },
  {
    quote: 'Their litigation team is disciplined, insightful, and always prepared. They have been instrumental in safeguarding our business relationships.',
    name: 'Thomas Vermeer',
    role: 'Chief Operations Officer, Benelux Logistics'
  },
  {
    quote: 'We rely on CLP for high-level employment and corporate structuring advice. They collaborate closely with our leadership and deliver clear guidance.',
    name: 'Marta Ruiz',
    role: 'HR Director, Global Fintech Alliance'
  }
];

const processSteps = [
  {
    title: 'Diagnostic Insight',
    detail: 'We examine the strategic context, risk profile, and stakeholder priorities behind every matter to frame the right legal trajectory.'
  },
  {
    title: 'Structured Planning',
    detail: 'Our attorneys design a tailored roadmap with precise milestones, resource allocation, and anticipated legal touchpoints.'
  },
  {
    title: 'Focused Execution',
    detail: 'We drive negotiations, filings, hearings, and stakeholder communication with rigorous attention to detail and timing.'
  },
  {
    title: 'Continuous Stewardship',
    detail: 'Post-resolution, we evaluate impact, monitor emerging obligations, and brief clients on future-proof compliance measures.'
  }
];

const projectItems = [
  { id: 1, category: 'Corporate', title: 'EU Cross-Border Merger Roadmap', image: 'https://picsum.photos/1200/800?random=41' },
  { id: 2, category: 'Disputes', title: 'Commercial Arbitration Strategy', image: 'https://picsum.photos/1200/800?random=42' },
  { id: 3, category: 'Employment', title: 'Workforce Transformation Compliance', image: 'https://picsum.photos/1200/800?random=43' },
  { id: 4, category: 'Regulatory', title: 'Digital Services Act Readiness', image: 'https://picsum.photos/1200/800?random=44' },
  { id: 5, category: 'Corporate', title: 'Joint Venture Governance Framework', image: 'https://picsum.photos/1200/800?random=45' },
  { id: 6, category: 'Disputes', title: 'High-Value Distribution Litigation', image: 'https://picsum.photos/1200/800?random=46' }
];

const faqItems = [
  {
    question: 'How do you approach multi-jurisdictional matters involving EU institutions?',
    answer: 'We assemble interdisciplinary teams that monitor both EU-level legislation and Belgian transposition. We engage with regulators, coordinate across jurisdictions, and structure workstreams to align with timing and disclosure obligations.'
  },
  {
    question: 'Do you offer tailored counsel for scale-ups expanding into Belgium?',
    answer: 'Yes. We advise on corporate structuring, employment frameworks, IP protection, strategic contract negotiations, and sector-specific licensing to ensure scale-ups enter the market with confidence.'
  },
  {
    question: 'How can clients collaborate with your attorneys on an ongoing basis?',
    answer: 'We set up dedicated client success channels, provide periodic legal intelligence briefings, and use secure collaboration platforms for document exchange and real-time strategy alignment.'
  }
];

const blogPosts = [
  {
    title: 'Belgian Corporate Mobility Directive: Practical Implications for Boards',
    date: 'January 8, 2024',
    excerpt: 'A pragmatic breakdown of how the EU Corporate Sustainability Reporting Directive intersects with Belgian corporate mobility planning and governance obligations.',
    link: '/insights'
  },
  {
    title: 'Employment Law Reforms: Preparing for Belgium’s 2024 Social Dialogue Cycle',
    date: 'December 14, 2023',
    excerpt: 'Key compliance checkpoints, workforce communications, and documentation protocols to update ahead of upcoming social elections and reforms.',
    link: '/insights'
  },
  {
    title: 'Navigating Commercial Litigation in Brussels Commercial Court',
    date: 'November 27, 2023',
    excerpt: 'Process oversight, evidence preparation, and timing considerations to effectively manage a complex commercial dispute in Brussels.',
    link: '/insights'
  }
];

const Home = () => {
  const [testimonialIndex, setTestimonialIndex] = React.useState(0);
  const [activeCategory, setActiveCategory] = React.useState('All');
  const [animatedValues, setAnimatedValues] = React.useState(statsData.map(() => 0));

  React.useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  React.useEffect(() => {
    const animationDuration = 1600;
    const start = performance.now();

    const tick = (now) => {
      const progress = Math.min((now - start) / animationDuration, 1);
      setAnimatedValues(
        statsData.map((stat) => Math.floor(stat.value * progress))
      );
      if (progress < 1) {
        requestAnimationFrame(tick);
      }
    };

    requestAnimationFrame(tick);
  }, []);

  const filteredProjects =
    activeCategory === 'All'
      ? projectItems
      : projectItems.filter((item) => item.category === activeCategory);

  return (
    <>
      <Helmet>
        <title>Consonragp Legal Partners | Premier Brussels Law Firm</title>
        <meta
          name="description"
          content="Consonragp Legal Partners delivers strategic legal counsel in corporate law, commercial litigation, employment strategy, and EU regulatory compliance."
        />
        <meta name="keywords" content="Belgium law firm, Brussels attorneys, corporate law Belgium, commercial disputes, employment law, EU compliance" />
        <link rel="canonical" href="https://www.example.com/" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroOverlay} />
        <img
          className={styles.heroImage}
          src="https://picsum.photos/1600/900?random=11"
          alt="Professional legal team in Brussels office"
          loading="lazy"
        />
        <div className={styles.heroContent}>
          <p className={styles.heroKicker}>Trusted Counsel, Decisive Outcomes</p>
          <h1>Your Trusted Legal Partner in Belgium</h1>
          <p className={styles.heroText}>
            Consonragp Legal Partners guides organisations through pivotal corporate, regulatory, and dispute-driven moments with measured strategy and enduring precision.
          </p>
          <div className={styles.heroActions}>
            <NavLink to="/contact" className={styles.primaryCta}>
              Schedule Consultation
            </NavLink>
            <NavLink to="/practice-areas" className={styles.secondaryCta}>
              Explore Practice Areas
            </NavLink>
          </div>
        </div>
      </section>

      <section className={styles.introSection} aria-labelledby="intro-heading">
        <div className={styles.introContent}>
          <div>
            <p className={styles.sectionKicker}>Strategic Legal Guidance</p>
            <h2 id="intro-heading">A Brussels firm with European reach</h2>
            <p>
              Based on Avenue Louise, Consonragp Legal Partners assists Belgian and international companies navigating corporate development, sensitive disputes, and regulatory transitions. We work seamlessly across English, French, Dutch, German, Italian, and Spanish to anticipate the legal dimensions of expansion and change.
            </p>
          </div>
          <div className={styles.introHighlight}>
            <h3>What defines our practice</h3>
            <ul>
              <li>Board-level advisory and scenario planning</li>
              <li>Litigation strategies rooted in meticulous preparation</li>
              <li>Workforce transitions aligned with social dialogue requirements</li>
              <li>Regulatory intelligence designed for rapidly evolving EU directives</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Firm performance statistics">
        {statsData.map((stat, index) => (
          <article key={stat.label} className={styles.statCard}>
            <span className={styles.statValue}>
              {animatedValues[index]}
            </span>
            <p>{stat.label}</p>
          </article>
        ))}
      </section>

      <section className={styles.practiceAreas} id="practice-areas" aria-labelledby="practice-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Practice Areas</p>
          <h2 id="practice-heading">Powered by insight across disciplines</h2>
          <p>We assemble agile teams around each mandate, combining sector fluency with technical expertise to deliver outcomes that support long-term business objectives.</p>
        </div>
        <div className={styles.practicesGrid}>
          {practiceAreas.map((area) => (
            <article key={area.title} className={styles.practiceCard}>
              <h3>{area.title}</h3>
              <p>{area.description}</p>
              <NavLink to="/practice-areas" className={styles.cardLink} aria-label={`Learn more about ${area.title}`}>
                Learn more →
              </NavLink>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.processSection} aria-labelledby="process-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Our Approach</p>
          <h2 id="process-heading">Methodical execution, transparent collaboration</h2>
          <p>Every instruction is anchored by a rigorous methodology that keeps client leadership informed and prepared for each decision point.</p>
        </div>
        <div className={styles.processTimeline}>
          {processSteps.map((step, idx) => (
            <article key={step.title} className={styles.processCard}>
              <span className={styles.stepNumber}>{idx + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.detail}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.whyChoose} aria-labelledby="why-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Why Choose Us</p>
          <h2 id="why-heading">Precision that inspires trust</h2>
          <p>Clients select Consonragp Legal Partners for strategic clarity, disciplined advocacy, and the calm assurance that complex matters are under control.</p>
        </div>
        <div className={styles.whyGrid}>
          <article>
            <h3>Sector Intelligence</h3>
            <p>We partner with leading organisations in financial services, technology, life sciences, logistics, and advanced manufacturing, translating sector nuance into effective legal strategy.</p>
          </article>
          <article>
            <h3>Collaborative Culture</h3>
            <p>Our teams embed with client leadership, offering proactive updates, briefing notes, and regulatory snapshots that empower informed decision-making.</p>
          </article>
          <article>
            <h3>Evidence-Backed Advocacy</h3>
            <p>From corporate negotiations to commercial litigation, we ground every argument in exhaustive research, precise documentation, and compelling presentation.</p>
          </article>
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonial-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Client Reflections</p>
          <h2 id="testimonial-heading">Trusted by leaders shaping Belgium’s economy</h2>
        </div>
        <div className={styles.testimonialCarousel}>
          {testimonials.map((testimonial, idx) => (
            <article
              key={testimonial.name}
              className={`${styles.testimonialCard} ${idx === testimonialIndex ? styles.active : ''}`}
              aria-hidden={idx !== testimonialIndex}
            >
              <p className={styles.quoteMark}>“</p>
              <p className={styles.quote}>{testimonial.quote}</p>
              <p className={styles.clientName}>{testimonial.name}</p>
              <p className={styles.clientRole}>{testimonial.role}</p>
            </article>
          ))}
          <div className={styles.dots} role="tablist" aria-label="Testimonials">
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                type="button"
                className={`${styles.dot} ${idx === testimonialIndex ? styles.dotActive : ''}`}
                onClick={() => setTestimonialIndex(idx)}
                aria-label={`View testimonial ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.teamSection} aria-labelledby="team-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Leadership Insight</p>
          <h2 id="team-heading">Seasoned attorneys. Unified mindset.</h2>
          <p>Our partners combine courtroom experience, transactional acuity, and regulatory foresight to support clients navigating pivotal decisions.</p>
        </div>
        <div className={styles.teamGrid}>
          {[
            { name: 'Claire Bouchard', title: 'Managing Partner – Corporate & Governance', img: 'https://picsum.photos/400/400?random=21' },
            { name: 'Lukas Meyer', title: 'Partner – Commercial Disputes & Arbitration', img: 'https://picsum.photos/400/400?random=22' },
            { name: 'Amélie Dupont', title: 'Partner – Employment & Social Dialogue', img: 'https://picsum.photos/400/400?random=23' }
          ].map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.img} alt={`${member.name}, ${member.title}`} loading="lazy" />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <p>{member.title}</p>
                <NavLink to="/attorneys" className={styles.teamLink}>View profile →</NavLink>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projectsSection} aria-labelledby="projects-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Case Experience</p>
          <h2 id="projects-heading">Delivering clarity in mission-critical matters</h2>
        </div>
        <div className={styles.filterBar} role="group" aria-label="Filter projects">
          {['All', 'Corporate', 'Disputes', 'Employment', 'Regulatory'].map((category) => (
            <button
              key={category}
              type="button"
              className={`${styles.filterBtn} ${activeCategory === category ? styles.filterActive : ''}`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <img src={project.image} alt={`${project.title} - ${project.category} project`} loading="lazy" />
              <div className={styles.projectInfo}>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faqSection} aria-labelledby="faq-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Frequently Asked Questions</p>
          <h2 id="faq-heading">Insights before engagement</h2>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, idx) => (
            <details key={item.question} className={styles.faqItem}>
              <summary>
                <span>{item.question}</span>
                <span aria-hidden="true">+</span>
              </summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={styles.blogPreview} aria-labelledby="blog-heading">
        <div className={styles.sectionHeader}>
          <p className={styles.sectionKicker}>Insights</p>
          <h2 id="blog-heading">Legal intelligence for decision-makers</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <img src="https://picsum.photos/800/600?random=32" alt="Brussels legal district skyline" loading="lazy" />
              <div className={styles.blogInfo}>
                <p className={styles.blogDate}>{post.date}</p>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <NavLink to={post.link} className={styles.blogLink}>
                  Read more →
                </NavLink>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection} aria-labelledby="cta-heading">
        <div className={styles.ctaContent}>
          <h2 id="cta-heading">Bring clarity to your next strategic move</h2>
          <p>Share your objectives and we will coordinate with the right attorneys to outline a path forward. Meetings can be held in Brussels or via secure video conference.</p>
          <NavLink to="/contact" className={styles.ctaButton}>Schedule Consultation</NavLink>
        </div>
      </section>
    </>
  );
};

export default Home;