import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PracticeAreas.module.css';

const practiceAreasDetails = [
  {
    title: 'Corporate Law',
    description:
      'We advise on complex corporate structures, reorganisations, shareholder arrangements, and cross-border transactions. Our team supports boards through governance reviews, private equity investments, and ESG-driven initiatives.',
    points: [
      'Corporate governance and board advisory',
      'Local and cross-border M&A execution',
      'Joint ventures, alliances, and strategic partnerships',
      'ESG, sustainability reporting, and stakeholder engagement',
      'Shareholder agreements and dispute prevention'
    ]
  },
  {
    title: 'Commercial Disputes',
    description:
      'Our litigators handle high-value disputes before Belgian courts, Brussels Commercial Court, and international arbitration panels. We manage complex evidence, procedural strategy, and settlement negotiations with precision.',
    points: [
      'Commercial litigation and arbitration',
      'Distribution and agency disputes',
      'Post-acquisition and warranty claims',
      'Urgent relief and interim proceedings',
      'Mediation and settlement strategy'
    ]
  },
  {
    title: 'Employment & Social Dialogue',
    description:
      'We guide employers through restructuring, workforce planning, and labour relations. Our attorneys ensure compliance with collective bargaining requirements and evolving employment regulations.',
    points: [
      'Workforce restructuring and transfers of undertakings',
      'Collective bargaining and union consultation',
      'Executive employment agreements and incentives',
      'Employment litigation and disciplinary investigations',
      'Workplace policies, wellbeing, and compliance'
    ]
  },
  {
    title: 'Contract Advisory',
    description:
      'We draft, negotiate, and audit key commercial arrangements. Our counsel aligns risk allocation with operational objectives and the regulatory context in Belgium and the EU.',
    points: [
      'Commercial supply and distribution agreements',
      'Technology licensing and SaaS contracting',
      'Strategic procurement and outsourcing',
      'Data protection and confidentiality frameworks',
      'Contract lifecycle audits and optimisation'
    ]
  },
  {
    title: 'EU Regulatory Compliance',
    description:
      'Our EU affairs team interprets evolving directives and regulations impacting digital services, financial markets, consumer protection, and competition law.',
    points: [
      'Digital Services Act and Digital Markets Act compliance',
      'Sustainable finance and ESG reporting obligations',
      'Competition law assessments and merger control',
      'Product compliance and consumer protection',
      'Interaction with EU institutions and regulators'
    ]
  }
];

const PracticeAreas = () => (
  <>
    <Helmet>
      <title>Practice Areas | Consonragp Legal Partners</title>
      <meta
        name="description"
        content="Explore Consonragp Legal Partners’ practice areas including corporate law, commercial disputes, employment law, contract advisory, and EU regulatory compliance."
      />
      <link rel="canonical" href="https://www.example.com/practice-areas" />
    </Helmet>
    <section className={styles.hero}>
      <div>
        <p className={styles.kicker}>Practice Areas</p>
        <h1>Expertise aligned with complex business objectives</h1>
        <p>
          Across corporate mandates, high-stakes disputes, and regulatory challenges, Consonragp Legal Partners assembles integrated teams to deliver clarity and results.
        </p>
      </div>
      <img src="https://picsum.photos/1000/700?random=71" alt="Brussels business district skyline" loading="lazy" />
    </section>
    <section className={styles.areas}>
      {practiceAreasDetails.map((area) => (
        <article key={area.title} className={styles.card}>
          <div className={styles.cardContent}>
            <h2>{area.title}</h2>
            <p>{area.description}</p>
          </div>
          <ul>
            {area.points.map((point) => (
              <li key={point}>{point}</li>
            ))}
          </ul>
        </article>
      ))}
    </section>
  </>
);

export default PracticeAreas;