import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPages.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | Consonragp Legal Partners</title>
      <meta
        name="description"
        content="Review Consonragp Legal Partners’ GDPR-compliant privacy policy describing how we collect and protect personal data."
      />
      <link rel="canonical" href="https://www.example.com/privacy" />
    </Helmet>
    <section className={styles.section}>
      <h1>Privacy Policy</h1>
      <p>Last updated: January 2024</p>
      <h2>1. Data controller</h2>
      <p>Consonragp Legal Partners, Avenue Louise 250, 1050 Brussels, Belgium.</p>
      <h2>2. Personal data collected</h2>
      <p>
        We collect contact details, professional information, and other data submitted via our forms. We may also collect technical data through analytics cookies.
      </p>
      <h2>3. Purpose and legal basis</h2>
      <p>
        Personal data is processed to respond to enquiries, manage client relationships, and comply with legal obligations. Processing is based on consent, performance of a contract, or legitimate interest.
      </p>
      <h2>4. Data retention</h2>
      <p>
        We retain personal data only as long as necessary for the purposes described or in accordance with statutory retention periods.
      </p>
      <h2>5. Data protection rights</h2>
      <p>
        You have the right to access, rectify, erase, restrict processing, and object to processing of your personal data. Requests can be sent to privacy@consonragplegal.com.
      </p>
      <h2>6. Security measures</h2>
      <p>
        We implement administrative, technical, and organisational measures to safeguard personal data against loss, misuse, or unauthorised access.
      </p>
      <h2>7. International transfers</h2>
      <p>
        Where data is transferred outside the European Economic Area, we ensure appropriate safeguards, such as standard contractual clauses.
      </p>
      <h2>8. Contact</h2>
      <p>
        For any questions about this policy, please contact privacy@consonragplegal.com.
      </p>
    </section>
  </>
);

export default Privacy;