import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={styles.inner}>
      <div className={styles.brand}>
        <span className={styles.logo}>CLP</span>
        <p>
          Consonragp Legal Partners delivers pragmatic legal solutions to organisations operating across Belgium and the European Union.
        </p>
      </div>
      <div className={styles.column}>
        <h4>Explore</h4>
        <ul>
          <li><NavLink to="/about">About</NavLink></li>
          <li><NavLink to="/practice-areas">Practice Areas</NavLink></li>
          <li><NavLink to="/attorneys">Attorneys</NavLink></li>
          <li><NavLink to="/insights">Insights</NavLink></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4>Resources</h4>
        <ul>
          <li><NavLink to="/services">Services</NavLink></li>
          <li><NavLink to="/contact">Contact</NavLink></li>
          <li><NavLink to="/terms">Terms of Service</NavLink></li>
          <li><NavLink to="/privacy">Privacy Policy</NavLink></li>
          <li><NavLink to="/cookie-policy">Cookie Policy</NavLink></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4>Contact</h4>
        <ul>
          <li>Avenue Louise 250<br />1050 Brussels, Belgium</li>
          <li>Phone: <a href="tel:+3221234567">+32 2 123 4567</a></li>
          <li>Email: <a href="mailto:contact@consonragplegal.com">contact@consonragplegal.com</a></li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Consonragp Legal Partners. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;