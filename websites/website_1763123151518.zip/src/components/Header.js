import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Home' },
  { path: '/about', label: 'About' },
  { path: '/practice-areas', label: 'Practice Areas' },
  { path: '/attorneys', label: 'Attorneys' },
  { path: '/insights', label: 'Insights' },
  { path: '/services', label: 'Services' },
  { path: '/contact', label: 'Contact' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const toggleMenu = () => setMenuOpen((prev) => !prev);

  React.useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <header className={styles.header} role="banner">
      <div className={styles.inner}>
        <NavLink to="/" className={styles.brand} aria-label="Consonragp Legal Partners home">
          <span className={styles.logoMark}>CLP</span>
          <span className={styles.brandName}>Consonragp Legal Partners</span>
        </NavLink>
        <button
          className={`${styles.menuToggle} ${menuOpen ? styles.open : ''}`}
          onClick={toggleMenu}
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Main navigation">
          <ul>
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
                  onClick={() => setMenuOpen(false)}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <NavLink to="/contact" className={styles.consultationBtn} onClick={() => setMenuOpen(false)}>
            Schedule Consultation
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;