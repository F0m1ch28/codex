import React from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(() => {
    return localStorage.getItem('clp_cookie_consent') !== 'accepted';
  });

  const acceptCookies = () => {
    localStorage.setItem('clp_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <div className={styles.content}>
        <h4>Cookies & Privacy</h4>
        <p>
          We use essential and analytics cookies to optimise your experience. You may review our <a href="/cookie-policy">Cookie Policy</a> for details.
        </p>
      </div>
      <button className={styles.acceptBtn} onClick={acceptCookies} type="button">
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;