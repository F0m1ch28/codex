```md
Place PWA icons generated via https://realfavicongenerator.net here.
```