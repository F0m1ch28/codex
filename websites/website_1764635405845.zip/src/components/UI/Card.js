```jsx
import styled from "styled-components";
import { motion } from "framer-motion";

const Card = styled(motion.div)`
  background: white;
  border-radius: ${({ theme }) => theme.radii.lg};
  box-shadow: ${({ theme }) => theme.shadows.soft};
  padding: 1.8rem;
  border: 1px solid rgba(31, 58, 111, 0.08);
`;

Card.defaultProps = {
  whileHover: { y: -6, scale: 1.01 }
};

export default Card;
```