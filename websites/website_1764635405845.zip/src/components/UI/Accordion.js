```jsx
import styled from "styled-components";
import { motion, AnimatePresence } from "framer-motion";
import React from "react";

const Item = styled.div`
  border-radius: 18px;
  background: white;
  border: 1px solid rgba(31, 58, 111, 0.08);
  margin-bottom: 1rem;
  overflow: hidden;
  box-shadow: ${({ theme }) => theme.shadows.soft};
`;

const Header = styled.button`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  padding: 1.2rem 1.6rem;
  background: transparent;
  font-weight: 600;
  text-align: left;
  color: ${({ theme }) => theme.colors.primary};
`;

const Content = styled(motion.div)`
  padding: 0 1.6rem 1.4rem;
  color: ${({ theme }) => theme.colors.textDark};
`;

export const AccordionItem = ({ title, content, isOpen, onToggle }) => (
  <Item>
    <Header onClick={onToggle} aria-expanded={isOpen}>
      {title}
      <span>{isOpen ? "−" : "+"}</span>
    </Header>
    <AnimatePresence initial={false}>
      {isOpen && (
        <Content
          key="content"
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
        >
          <div style={{ paddingTop: "0.75rem" }}>{content}</div>
        </Content>
      )}
    </AnimatePresence>
  </Item>
);
```