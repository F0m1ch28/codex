```jsx
import React from "react";
import ReactDOM from "react-dom";
import styled from "styled-components";
import { motion, AnimatePresence } from "framer-motion";

const Overlay = styled(motion.div)`
  position: fixed;
  inset: 0;
  background: rgba(15, 23, 42, 0.55);
  backdrop-filter: blur(10px);
  display: grid;
  place-items: center;
  z-index: 1000;
`;

const Dialog = styled(motion.div)`
  background: white;
  border-radius: 26px;
  padding: 2rem;
  width: min(560px, 92vw);
  box-shadow: ${({ theme }) => theme.shadows.medium};
  position: relative;
`;

const Close = styled.button`
  position: absolute;
  top: 1.2rem;
  right: 1.2rem;
  width: 38px;
  height: 38px;
  border-radius: 12px;
  background: rgba(31, 58, 111, 0.08);
  font-size: 1.1rem;
`;

const Modal = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;

  return ReactDOM.createPortal(
    <AnimatePresence>
      <Overlay
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        role="presentation"
      >
        <Dialog
          initial={{ y: 60, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
            exit={{ y: -30, opacity: 0 }}
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-title"
          onClick={(e) => e.stopPropagation()}
        >
          <Close onClick={onClose} aria-label="Close">
            ✕
          </Close>
          {title && (
            <h3 id="modal-title" style={{ marginBottom: "1rem" }}>
              {title}
            </h3>
          )}
          {children}
        </Dialog>
      </Overlay>
    </AnimatePresence>,
    document.getElementById("modal-root")
  );
};

export default Modal;
```