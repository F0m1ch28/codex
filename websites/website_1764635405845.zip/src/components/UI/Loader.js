```jsx
import React from "react";
import styled, { keyframes } from "styled-components";

const spin = keyframes`
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
`;

const Wrapper = styled.div`
  display: grid;
  place-items: center;
  padding: ${({ fullscreen }) => (fullscreen ? "20vh 0" : "2rem")};
`;

const Spinner = styled.div`
  width: 58px;
  height: 58px;
  border-radius: 50%;
  border: 6px solid rgba(31, 58, 111, 0.18);
  border-top-color: ${({ theme }) => theme.colors.accent};
  animation: ${spin} 0.8s linear infinite;
`;

const Loader = ({ fullscreen }) => (
  <Wrapper fullscreen={fullscreen}>
    <Spinner role="status" aria-label="Loading" />
  </Wrapper>
);

export default Loader;
```