```jsx
import styled from "styled-components";
import { motion } from "framer-motion";

const sizes = {
  sm: "0.55rem 1.25rem",
  md: "0.75rem 1.8rem",
  lg: "1rem 2.4rem"
};

const Button = styled(motion.button)`
  border-radius: ${({ theme }) => theme.radii.full};
  background: ${({ variant, theme }) =>
    variant === "secondary"
      ? "rgba(37, 99, 235, 0.12)"
      : variant === "ghost"
      ? "transparent"
      : theme.gradients.primary};
  color: ${({ variant, theme }) =>
    variant === "secondary" ? theme.colors.accent : variant === "ghost" ? theme.colors.primary : "white"};
  padding: ${({ size }) => sizes[size] || sizes.md};
  font-weight: 600;
  font-size: 0.95rem;
  border: ${({ variant, theme }) =>
    variant === "ghost" ? `1px solid ${theme.colors.primary}` : "none"};
  box-shadow: ${({ variant, theme }) => (variant === "primary" ? theme.shadows.soft : "none")};
  display: inline-flex;
  align-items: center;
  gap: 0.6rem;
`;

Button.defaultProps = {
  variant: "primary",
  whileHover: { y: -2 },
  whileTap: { scale: 0.98 }
};

export default Button;
```