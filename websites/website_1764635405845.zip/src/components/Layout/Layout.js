```jsx
import React from "react";
import { Outlet } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
import CookieBanner from "../Shared/CookieBanner";
import BackToTop from "../Shared/BackToTop";
import DisclaimerModal from "../Shared/DisclaimerModal";
import Preloader from "../Shared/Preloader";

const Layout = () => (
  <>
    <Preloader />
    <Header />
    <main>
      <Outlet />
    </main>
    <Footer />
    <CookieBanner />
    <DisclaimerModal />
    <BackToTop />
  </>
);

export default Layout;
```