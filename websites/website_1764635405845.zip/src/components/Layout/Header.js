```jsx
import React, { useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import styled from "styled-components";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "../../providers/LanguageProvider";
import { useThemeMode } from "../../providers/ThemeModeProvider";
import LanguageSwitcher from "../Shared/LanguageSwitcher";
import { useMemo } from "react";

const HeaderWrapper = styled.header`
  position: sticky;
  top: 0;
  backdrop-filter: blur(14px);
  background: rgba(248, 250, 252, 0.92);
  border-bottom: 1px solid rgba(31, 58, 111, 0.08);
  z-index: 999;
`;

const Container = styled.div`
  max-width: 1280px;
  margin: 0 auto;
  padding: 0.75rem 1.5rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const Brand = styled(NavLink)`
  font-family: "DM Sans";
  font-weight: 700;
  font-size: 1.2rem;
  color: ${({ theme }) => theme.colors.primary};
  letter-spacing: 0.04em;
  display: flex;
  align-items: center;
  gap: 0.6rem;
`;

const Nav = styled.nav`
  display: flex;
  gap: 1.25rem;
  align-items: center;

  @media (max-width: 960px) {
    display: none;
  }
`;

const StyledLink = styled(NavLink)`
  font-weight: 500;
  font-size: 0.95rem;
  color: ${({ theme }) => theme.colors.textDark};
  padding: 0.4rem 0;
  position: relative;

  &.active::after {
    content: "";
    position: absolute;
    bottom: -8px;
    left: 0;
    width: 100%;
    height: 3px;
    border-radius: 999px;
    background: ${({ theme }) => theme.colors.accent};
  }

  &:hover {
    color: ${({ theme }) => theme.colors.accent};
  }
`;

const MenuButton = styled.button`
  display: none;
  position: relative;

  @media (max-width: 960px) {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 46px;
    height: 46px;
    border-radius: 14px;
    background: rgba(37, 99, 235, 0.1);
    color: ${({ theme }) => theme.colors.accent};
  }
`;

const MobileMenu = styled(motion.nav)`
  position: fixed;
  inset: 0;
  background: rgba(15, 23, 42, 0.85);
  backdrop-filter: blur(12px);
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 1.5rem;
  padding: 2rem;
`;

const MobileLink = styled(NavLink)`
  font-size: 1.4rem;
  color: white;
  text-transform: uppercase;
  font-weight: 600;
  letter-spacing: 0.08em;

  &.active {
    color: ${({ theme }) => theme.colors.accent};
  }
`;

const ThemeToggle = styled.button`
  border-radius: 999px;
  padding: 0.5rem 1.1rem;
  background: ${({ theme }) => theme.gradients.primary};
  color: white;
  font-weight: 600;
  font-size: 0.9rem;
  box-shadow: ${({ theme }) => theme.shadows.soft};
  transition: transform 0.25s ease;

  &:hover {
    transform: translateY(-2px);
  }
`;

const Header = () => {
  const { t } = useLanguage();
  const { mode, toggleMode } = useThemeMode();
  const location = useLocation();
  const [open, setOpen] = useState(false);

  const navItems = useMemo(
    () => [
      { path: "/", label: t("nav.home") },
      { path: "/about", label: t("nav.about") },
      { path: "/services", label: t("nav.services") },
      { path: "/course", label: t("nav.course") },
      { path: "/inflation", label: t("nav.inflation") },
      { path: "/resources", label: t("nav.resources") },
      { path: "/faq", label: t("nav.faq") },
      { path: "/contact", label: t("nav.contact") }
    ],
    [t]
  );

  const closeMenu = () => setOpen(false);

  return (
    <HeaderWrapper role="banner">
      <Container>
        <Brand to="/" aria-label="Tu Progreso Hoy home">
          <span>Tu Progreso Hoy</span>
        </Brand>

        <Nav aria-label="Primary navigation">
          {navItems.map(({ path, label }) => (
            <StyledLink key={path} to={path} className={({ isActive }) => (isActive ? "active" : "")}>
              {label}
            </StyledLink>
          ))}
          <LanguageSwitcher />
          <ThemeToggle onClick={toggleMode} aria-pressed={mode === "deep"}>
            {mode === "light" ? t("ui.contrast") : t("ui.restore")}
          </ThemeToggle>
        </Nav>

        <MenuButton
          aria-label={open ? t("ui.closeMenu") : t("ui.openMenu")}
          onClick={() => setOpen((prev) => !prev)}
        >
          <span aria-hidden="true">{open ? "✕" : "☰"}</span>
        </MenuButton>
      </Container>

      <AnimatePresence>
        {open && (
          <MobileMenu
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            role="dialog"
            aria-modal="true"
          >
            {navItems.map(({ path, label }) => (
              <MobileLink
                key={path}
                to={path}
                onClick={closeMenu}
                className={location.pathname === path ? "active" : ""}
              >
                {label}
              </MobileLink>
            ))}
            <LanguageSwitcher mobile />
            <ThemeToggle onClick={toggleMode}>
              {mode === "light" ? t("ui.contrast") : t("ui.restore")}
            </ThemeToggle>
          </MobileMenu>
        )}
      </AnimatePresence>
    </HeaderWrapper>
  );
};

export default Header;
```