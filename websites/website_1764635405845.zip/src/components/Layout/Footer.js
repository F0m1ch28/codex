```jsx
import React from "react";
import styled from "styled-components";
import { NavLink } from "react-router-dom";
import { useLanguage } from "../../providers/LanguageProvider";
import ShareButtons from "../Shared/ShareButtons";

const FooterWrapper = styled.footer`
  background: white;
  border-top: 1px solid rgba(31, 58, 111, 0.12);
  padding: 3rem 1.5rem 2rem;
`;

const Container = styled.div`
  max-width: 1280px;
  margin: 0 auto;
  display: grid;
  gap: 2rem;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
`;

const Column = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const Title = styled.h4`
  font-size: 1rem;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: ${({ theme }) => theme.colors.primary};
`;

const Link = styled(NavLink)`
  font-size: 0.95rem;
  color: ${({ theme }) => theme.colors.textDark};
  opacity: 0.8;

  &:hover {
    opacity: 1;
    color: ${({ theme }) => theme.colors.accent};
  }
`;

const BottomNote = styled.div`
  text-align: center;
  margin-top: 2rem;
  font-size: 0.85rem;
  color: rgba(15, 23, 42, 0.65);
`;

const Footer = () => {
  const { t } = useLanguage();
  return (
    <FooterWrapper>
      <Container>
        <Column>
          <Title>Tu Progreso Hoy</Title>
          <p>{t("footer.tagline")}</p>
          <ShareButtons />
        </Column>
        <Column>
          <Title>{t("footer.quickLinks")}</Title>
          <Link to="/course">{t("nav.course")}</Link>
          <Link to="/services">{t("nav.services")}</Link>
          <Link to="/resources">{t("nav.resources")}</Link>
          <Link to="/faq">{t("nav.faq")}</Link>
        </Column>
        <Column>
          <Title>{t("footer.legal")}</Title>
          <Link to="/privacy">{t("legal.privacy")}</Link>
          <Link to="/terms">{t("legal.terms")}</Link>
          <Link to="/cookies">{t("legal.cookies")}</Link>
        </Column>
        <Column>
          <Title>{t("footer.contact")}</Title>
          <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
          <a href="tel:+541145678900">+54 11 4567-8900</a>
          <p>Av. 9 de Julio 1000, CABA</p>
        </Column>
      </Container>
      <BottomNote>
        © {new Date().getFullYear()} Tu Progreso Hoy. {t("footer.rights")}
      </BottomNote>
    </FooterWrapper>
  );
};

export default Footer;
```