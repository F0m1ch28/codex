```jsx
import React from "react";
import Modal from "../UI/Modal";
import useLocalStorage from "../../hooks/useLocalStorage";
import { useLanguage } from "../../providers/LanguageProvider";
import { useState, useEffect } from "react";
import Button from "../UI/Button";

const DisclaimerModal = () => {
  const [hasAccepted, setHasAccepted] = useLocalStorage("tph-disclaimer", false);
  const [isOpen, setIsOpen] = useState(false);
  const { t, dual } = useLanguage();

  useEffect(() => {
    if (!hasAccepted) {
      setIsOpen(true);
    }
  }, [hasAccepted]);

  const handleAccept = () => {
    setHasAccepted(true);
    setIsOpen(false);
  };

  const copy = dual("disclaimer.text");

  return (
    <Modal isOpen={isOpen} onClose={handleAccept} title={t("disclaimer.title")}>
      <p lang="en">{copy.en}</p>
      <p lang="es-AR" style={{ marginTop: "0.8rem" }}>
        {copy.es}
      </p>
      <Button onClick={handleAccept} size="md" style={{ marginTop: "1.6rem" }}>
        {t("disclaimer.button")}
      </Button>
    </Modal>
  );
};

export default DisclaimerModal;
```