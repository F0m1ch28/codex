```jsx
import React, { useEffect, useState } from "react";
import styled from "styled-components";
import { motion } from "framer-motion";

const Button = styled(motion.button)`
  position: fixed;
  bottom: 24px;
  right: 24px;
  width: 54px;
  height: 54px;
  border-radius: 18px;
  background: ${({ theme }) => theme.gradients.primary};
  color: white;
  font-size: 1.4rem;
  box-shadow: ${({ theme }) => theme.shadows.medium};
  display: grid;
  place-items: center;
  z-index: 999;
`;

const BackToTop = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 400);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  if (!visible) return null;

  return (
    <Button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.05 }}
      aria-label="Back to top"
    >
      ↑
    </Button>
  );
};

export default BackToTop;
```