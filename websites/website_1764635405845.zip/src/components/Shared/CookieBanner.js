```jsx
import React, { useState } from "react";
import styled from "styled-components";
import { motion, AnimatePresence } from "framer-motion";
import useLocalStorage from "../../hooks/useLocalStorage";
import Button from "../UI/Button";
import { useLanguage } from "../../providers/LanguageProvider";

const Banner = styled(motion.div)`
  position: fixed;
  bottom: 18px;
  left: 50%;
  transform: translateX(-50%);
  background: white;
  width: min(620px, 92vw);
  border-radius: 28px;
  padding: 1.5rem;
  box-shadow: ${({ theme }) => theme.shadows.medium};
  z-index: 100;
  border: 1px solid rgba(31, 58, 111, 0.16);
`;

const Buttons = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-top: 1.2rem;
`;

const CookieBanner = () => {
  const { t } = useLanguage();
  const [consent, setConsent] = useLocalStorage("tph-cookie-consent", null);
  const [openPreferences, setOpenPreferences] = useState(false);

  const acceptNecessary = () => setConsent({ necessary: true, analytics: false });
  const acceptAll = () => setConsent({ necessary: true, analytics: true });

  return (
    <AnimatePresence>
      {!consent && (
        <Banner
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
        >
          <strong>{t("cookie.title")}</strong>
          <p>{t("cookie.description")}</p>
          {openPreferences && <p>{t("cookie.preferences")}</p>}
          <Buttons>
            <Button variant="primary" size="md" onClick={acceptAll}>
              {t("cookie.acceptAll")}
            </Button>
            <Button variant="secondary" size="md" onClick={acceptNecessary}>
              {t("cookie.acceptNecessary")}
            </Button>
            <Button
              variant="ghost"
              size="md"
              onClick={() => setOpenPreferences((prev) => !prev)}
            >
              {t("cookie.customize")}
            </Button>
          </Buttons>
        </Banner>
      )}
    </AnimatePresence>
  );
};

export default CookieBanner;
```