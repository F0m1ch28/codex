```jsx
import React from "react";
import styled from "styled-components";

const List = styled.div`
  display: flex;
  gap: 0.6rem;
`;

const Button = styled.a`
  width: 42px;
  height: 42px;
  border-radius: 14px;
  background: rgba(37, 99, 235, 0.12);
  display: grid;
  place-items: center;
  color: ${({ theme }) => theme.colors.accent};
  font-size: 1.1rem;

  &:hover {
    background: ${({ theme }) => theme.gradients.primary};
    color: white;
  }
`;

const ShareButtons = () => {
  const url = encodeURIComponent(window.location.href);
  const text = encodeURIComponent("Discover Tu Progreso Hoy - data-driven education for Argentina.");
  return (
    <List aria-label="Share links">
      <Button href={`https://twitter.com/intent/tweet?url=${url}&text=${text}`} target="_blank" rel="noopener noreferrer" aria-label="Share on X">
        X
      </Button>
      <Button href={`https://www.linkedin.com/sharing/share-offsite/?url=${url}`} target="_blank" rel="noopener noreferrer" aria-label="Share on LinkedIn">
        in
      </Button>
      <Button href={`https://wa.me/?text=${text}%20${url}`} target="_blank" rel="noopener noreferrer" aria-label="Share on WhatsApp">
        ☎
      </Button>
    </List>
  );
};

export default ShareButtons;
```