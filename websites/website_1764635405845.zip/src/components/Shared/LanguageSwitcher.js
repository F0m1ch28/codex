```jsx
import React from "react";
import styled from "styled-components";
import { useLanguage } from "../../providers/LanguageProvider";

const Wrapper = styled.div`
  display: flex;
  background: rgba(37, 99, 235, 0.1);
  border-radius: 999px;
  padding: 0.2rem;
  gap: 0.2rem;
  ${({ mobile }) => mobile && `margin-top: 1rem;`}
`;

const Option = styled.button`
  border-radius: 999px;
  padding: 0.35rem 0.85rem;
  font-weight: 600;
  background: ${({ active, theme }) => (active ? theme.gradients.primary : "transparent")};
  color: ${({ active }) => (active ? "white" : "rgba(37, 99, 235, 0.9)")};
`;

const LanguageSwitcher = ({ mobile }) => {
  const { language, setLanguage } = useLanguage();
  return (
    <Wrapper role="radiogroup" mobile={mobile}>
      <Option
        type="button"
        role="radio"
        aria-checked={language === "en"}
        active={language === "en"}
        onClick={() => setLanguage("en")}
      >
        EN
      </Option>
      <Option
        type="button"
        role="radio"
        aria-checked={language === "es-AR"}
        active={language === "es-AR"}
        onClick={() => setLanguage("es-AR")}
      >
        ES
      </Option>
    </Wrapper>
  );
};

export default LanguageSwitcher;
```