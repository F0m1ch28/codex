```jsx
import React from "react";
import styled from "styled-components";
import { NavLink } from "react-router-dom";
import { useLanguage } from "../../providers/LanguageProvider";

const Wrapper = styled.nav`
  width: 100%;
  margin: 1rem 0;
  font-size: 0.85rem;
  color: rgba(15, 23, 42, 0.6);
`;

const Crumb = styled(NavLink)`
  color: inherit;
  &:hover {
    color: ${({ theme }) => theme.colors.accent};
  }
`;

const Breadcrumbs = ({ trail }) => {
  const { t } = useLanguage();
  return (
    <Wrapper aria-label="Breadcrumb">
      <Crumb to="/">{t("nav.home")}</Crumb> /{" "}
      {trail.map((item, idx) => (
        <React.Fragment key={item.path}>
          {idx < trail.length - 1 ? (
            <>
              <Crumb to={item.path}>{item.label}</Crumb> /{" "}
            </>
          ) : (
            <span>{item.label}</span>
          )}
        </React.Fragment>
      ))}
    </Wrapper>
  );
};

export default Breadcrumbs;
```