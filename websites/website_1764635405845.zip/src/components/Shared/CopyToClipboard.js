```jsx
import React, { useState } from "react";
import styled from "styled-components";

const Button = styled.button`
  padding: 0.45rem 0.9rem;
  border-radius: 12px;
  background: rgba(37, 99, 235, 0.15);
  color: ${({ theme }) => theme.colors.accent};
  font-weight: 600;
`;

const CopyToClipboard = ({ text, label }) => {
  const [copied, setCopied] = useState(false);
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch (error) {
      console.warn("Clipboard error", error);
    }
  };

  return (
    <Button onClick={handleCopy} aria-live="polite">
      {copied ? "Copied!" : label}
    </Button>
  );
};

export default CopyToClipboard;
```