```jsx
import React, { useEffect, useState } from "react";
import styled, { keyframes } from "styled-components";

const pulse = keyframes`
  0% { transform: scale(1); opacity: 0.9; }
  50% { transform: scale(1.08); opacity: 1; }
  100% { transform: scale(1); opacity: 0.9; }
`;

const Wrapper = styled.div`
  position: fixed;
  inset: 0;
  background: ${({ theme }) => theme.colors.lightBg};
  display: grid;
  place-items: center;
  z-index: 1500;
`;

const Logo = styled.div`
  border-radius: 26px;
  padding: 1.6rem 2rem;
  background: ${({ theme }) => theme.gradients.primary};
  color: white;
  font-weight: 700;
  font-size: 1.4rem;
  animation: ${pulse} 1.6s ease-in-out infinite;
  box-shadow: ${({ theme }) => theme.shadows.medium};
`;

const Preloader = () => {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setReady(true), 1200);
    return () => clearTimeout(timer);
  }, []);
  if (ready) return null;
  return (
    <Wrapper>
      <Logo>Tu Progreso Hoy</Logo>
    </Wrapper>
  );
};

export default Preloader;
```