```jsx
import React, { useEffect, useState } from "react";
import styled from "styled-components";
import { useLocation } from "react-router-dom";

const Bar = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  height: 4px;
  width: ${({ width }) => width}%;
  background: ${({ theme }) => theme.gradients.primary};
  z-index: 1200;
  transition: width 0.3s ease;
`;

const ProgressBar = () => {
  const [progress, setProgress] = useState(0);
  const location = useLocation();

  useEffect(() => {
    setProgress(15);
    const timer = setTimeout(() => setProgress(100), 500);
    return () => {
      clearTimeout(timer);
      setProgress(0);
    };
  }, [location.pathname]);

  return <Bar width={progress} role="presentation" />;
};

export default ProgressBar;
```