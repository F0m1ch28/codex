```jsx
import { createGlobalStyle } from "styled-components";

const GlobalStyles = createGlobalStyle`
  :root {
    color-scheme: light;
    scroll-behavior: smooth;
  }

  *, *::before, *::after {
    box-sizing: border-box;
  }

  html, body {
    margin: 0;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: ${({ theme }) => theme.colors.lightBg};
    color: ${({ theme }) => theme.colors.textDark};
    min-height: 100%;
    text-rendering: optimizeLegibility;
  }

  h1, h2, h3, h4, h5, h6 {
    font-family: 'DM Sans', 'Inter', sans-serif;
    margin: 0;
    color: ${({ theme }) => theme.colors.textDark};
  }

  p {
    line-height: 1.6;
    margin: 0;
  }

  a {
    color: inherit;
    text-decoration: none;
  }

  img {
    max-width: 100%;
    display: block;
  }

  ul {
    margin: 0;
    padding: 0;
    list-style: none;
  }

  button {
    font-family: inherit;
    cursor: pointer;
    border: none;
    background: none;
  }

  ::selection {
    background: ${({ theme }) => theme.colors.accent};
    color: white;
  }

  [lang="es-AR"] {
    font-style: normal;
  }
`;
export default GlobalStyles;
```