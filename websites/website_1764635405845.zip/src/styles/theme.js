```jsx
const palette = {
  primary: "#1F3A6F",
  accent: "#2563EB",
  lightGray: "#E2E8F0",
  lightBg: "#F8FAFC",
  textDark: "#0F172A",
  success: "#16A34A",
  warning: "#F59E0B",
  danger: "#DC2626"
};

const theme = {
  colors: palette,
  gradients: {
    primary: `linear-gradient(135deg, ${palette.primary} 0%, ${palette.accent} 100%)`,
    glass: "rgba(255,255,255,0.75)"
  },
  shadows: {
    soft: "0 15px 35px rgba(31,58,111,0.12)",
    medium: "0 20px 45px rgba(31,58,111,0.18)"
  },
  radii: {
    md: "18px",
    lg: "28px",
    full: "999px"
  },
  breakpoints: {
    xs: "360px",
    sm: "600px",
    md: "900px",
    lg: "1200px",
    xl: "1600px"
  }
};

export default theme;
```