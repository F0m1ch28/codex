```jsx
import { useForm as useReactHookForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

const useForm = ({ schema, defaultValues = {}, mode = "onBlur" }) => {
  return useReactHookForm({
    defaultValues,
    mode,
    reValidateMode: "onChange",
    resolver: schema ? yupResolver(schema) : undefined
  });
};

export default useForm;
```