```jsx
import React, { Suspense, useEffect } from "react";
import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import Layout from "./components/Layout/Layout";
import Loader from "./components/UI/Loader";
import ProgressBar from "./components/Shared/ProgressBar";
import { AnimatePresence } from "framer-motion";

const Home = React.lazy(() => import("./pages/Home"));
const About = React.lazy(() => import("./pages/About"));
const Services = React.lazy(() => import("./pages/Services"));
const Course = React.lazy(() => import("./pages/Course"));
const Inflation = React.lazy(() => import("./pages/Inflation"));
const Resources = React.lazy(() => import("./pages/Resources"));
const FAQ = React.lazy(() => import("./pages/FAQ"));
const Contact = React.lazy(() => import("./pages/Contact"));
const Privacy = React.lazy(() => import("./pages/Legal/Privacy"));
const Terms = React.lazy(() => import("./pages/Legal/Terms"));
const Cookies = React.lazy(() => import("./pages/Legal/Cookies"));
const ThankYou = React.lazy(() => import("./pages/ThankYou"));
const NotFound = React.lazy(() => import("./pages/NotFound"));

const App = () => {
  const location = useLocation();

  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker
        .register("/service-worker.js")
        .catch((err) => console.error("SW registration failed", err));
    }
  }, []);

  return (
    <>
      <ProgressBar />
      <AnimatePresence mode="wait">
        <Suspense fallback={<Loader fullscreen />}>
          <Routes location={location} key={location.pathname}>
            <Route element={<Layout />}>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/services" element={<Services />} />
              <Route path="/course" element={<Course />} />
              <Route path="/inflation" element={<Inflation />} />
              <Route path="/resources" element={<Resources />} />
              <Route path="/faq" element={<FAQ />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/terms" element={<Terms />} />
              <Route path="/cookies" element={<Cookies />} />
              <Route path="/thank-you" element={<ThankYou />} />
              <Route path="/404" element={<NotFound />} />
              <Route path="*" element={<Navigate to="/404" replace />} />
            </Route>
          </Routes>
        </Suspense>
      </AnimatePresence>
    </>
  );
};

export default App;
```