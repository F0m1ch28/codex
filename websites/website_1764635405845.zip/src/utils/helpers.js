```jsx
export const formatCurrency = (value, currency = "USD", locale = "en-US") =>
  new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
    maximumFractionDigits: 2
  }).format(value);

export const formatPercentage = (value, locale = "en-US") =>
  new Intl.NumberFormat(locale, {
    style: "percent",
    maximumFractionDigits: 2
  }).format(value);

export const slugify = (text) =>
  text
    .toLowerCase()
    .replace(/[\s/]+/g, "-")
    .replace(/[^\w-]+/g, "");
```