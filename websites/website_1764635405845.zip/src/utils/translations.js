```jsx
const translations = {
  "nav.home": { en: "Home", "es-AR": "Inicio" },
  "nav.about": { en: "About", "es-AR": "Sobre nosotros" },
  "nav.services": { en: "Services", "es-AR": "Servicios" },
  "nav.course": { en: "Course", "es-AR": "Curso" },
  "nav.inflation": { en: "Inflation", "es-AR": "Inflación" },
  "nav.resources": { en: "Resources", "es-AR": "Recursos" },
  "nav.faq": { en: "FAQ", "es-AR": "Preguntas" },
  "nav.contact": { en: "Contact", "es-AR": "Contacto" },
  "footer.tagline": {
    en: "Empowering Argentina’s learners with real-time economic intelligence.",
    "es-AR": "Empoderamos a estudiantes argentinos con inteligencia económica en tiempo real."
  },
  "footer.quickLinks": { en: "Quick links", "es-AR": "Enlaces rápidos" },
  "footer.legal": { en: "Legal", "es-AR": "Legal" },
  "footer.contact": { en: "Contact", "es-AR": "Contacto" },
  "footer.rights": {
    en: "All rights reserved.",
    "es-AR": "Todos los derechos reservados."
  },
  "legal.privacy": { en: "Privacy Policy", "es-AR": "Política de privacidad" },
  "legal.terms": { en: "Terms of Service", "es-AR": "Términos del servicio" },
  "legal.cookies": { en: "Cookies", "es-AR": "Cookies" },
  "ui.contrast": { en: "Contrast mode", "es-AR": "Modo contraste" },
  "ui.restore": { en: "Standard mode", "es-AR": "Modo estándar" },
  "ui.openMenu": { en: "Open navigation", "es-AR": "Abrir navegación" },
  "ui.closeMenu": { en: "Close navigation", "es-AR": "Cerrar navegación" },
  "cookie.title": {
    en: "Your privacy matters",
    "es-AR": "Tu privacidad nos importa"
  },
  "cookie.description": {
    en: "We use cookies to analyse traffic and enhance experiences. Manage your preferences anytime.",
    "es-AR": "Usamos cookies para analizar el tráfico y mejorar tu experiencia. Administra tus preferencias cuando quieras."
  },
  "cookie.preferences": {
    en: "Necessary cookies ensure site performance. Analytics cookies help us understand how you learn.",
    "es-AR": "Las cookies necesarias garantizan el rendimiento del sitio. Las cookies analíticas nos ayudan a entender cómo aprendes."
  },
  "cookie.acceptAll": { en: "Accept all", "es-AR": "Aceptar todas" },
  "cookie.acceptNecessary": {
    en: "Accept necessary",
    "es-AR": "Aceptar necesarias"
  },
  "cookie.customize": { en: "Customize", "es-AR": "Personalizar" },
  "disclaimer.title": {
    en: "Important Notice",
    "es-AR": "Aviso importante"
  },
  "disclaimer.text": {
    en: "We do not provide financial services. Information is educational only.",
    "es-AR": "No brindamos servicios financieros. La información es únicamente educativa."
  },
  "disclaimer.button": { en: "Understood", "es-AR": "Entendido" },
  "home.hero.title": {
    en: "Guide Your Growth with Data-Led Learning",
    "es-AR": "Guía tu crecimiento con aprendizaje basado en datos"
  },
  "home.hero.subtitle": {
    en: "Tu Progreso Hoy combines real-time Argentine economic analytics with premium education modules.",
    "es-AR": "Tu Progreso Hoy combina analíticas económicas argentinas en tiempo real con módulos educativos premium."
  },
  "home.hero.ctaPrimary": {
    en: "Start Free Trial",
    "es-AR": "Comenzar prueba gratuita"
  },
  "home.hero.ctaSecondary": {
    en: "Explore Modules",
    "es-AR": "Explorar módulos"
  },
  "home.metrics.title": {
    en: "Essential Indicators at a Glance",
    "es-AR": "Indicadores esenciales de un vistazo"
  },
  "home.currency.title": {
    en: "ARS to USD Live Tracker",
    "es-AR": "ARS a USD en vivo"
  },
  "home.currency.caption": {
    en: "Simulated live conversion refreshed every 5 seconds.",
    "es-AR": "Conversión simulada con actualización cada 5 segundos."
  },
  "home.course.title": {
    en: "Course Preview",
    "es-AR": "Vista previa del curso"
  },
  "home.reviews.title": {
    en: "Learners thriving across Argentina",
    "es-AR": "Aprendices creciendo en toda Argentina"
  },
  "home.cta.title": {
    en: "Claim Your Complimentary Lesson",
    "es-AR": "Solicitá tu clase gratuita"
  },
  "home.cta.subtitle": {
    en: "Complete the form and receive a confirmation email to activate your trial.",
    "es-AR": "Completá el formulario y recibí un email de confirmación para activar tu prueba."
  },
  "form.name": { en: "Full name", "es-AR": "Nombre completo" },
  "form.email": { en: "Email", "es-AR": "Email" },
  "form.company": { en: "Organization", "es-AR": "Organización" },
  "form.submit": { en: "Request Trial", "es-AR": "Solicitar prueba" },
  "form.required": {
    en: "This field is required",
    "es-AR": "Este campo es obligatorio"
  },
  "form.emailInvalid": {
    en: "Enter a valid email",
    "es-AR": "Ingresá un email válido"
  },
  "form.success": {
    en: "Thanks! Please check your inbox.",
    "es-AR": "¡Gracias! Revisá tu casilla de correo."
  },
  "about.hero.title": {
    en: "Data-first, learner-centered",
    "es-AR": "Datos primero, aprendizaje centrado"
  },
  "services.hero.title": {
    en: "Premium services tailored to your mission",
    "es-AR": "Servicios premium adaptados a tu misión"
  },
  "inflation.hero.title": {
    en: "Inflation Intelligence Hub",
    "es-AR": "Centro de inteligencia de inflación"
  },
  "course.hero.title": {
    en: "Master the economic landscape",
    "es-AR": "Domina el panorama económico"
  },
  "resources.hero.title": {
    en: "Curated resources for smarter decisions",
    "es-AR": "Recursos curados para decisiones inteligentes"
  },
  "faq.hero.title": {
    en: "Answers for your data journey",
    "es-AR": "Respuestas para tu viaje de datos"
  },
  "contact.hero.title": {
    en: "Connect with our specialists",
    "es-AR": "Conectá con nuestros especialistas"
  },
  "thankyou.title": {
    en: "You're almost there!",
    "es-AR": "¡Estás a un paso!"
  },
  "thankyou.subtitle": {
    en: "Check your email to confirm your access. We sent a double opt-in message.",
    "es-AR": "Revisá tu correo para confirmar el acceso. Enviamos un mensaje de doble opt-in."
  },
  "thankyou.links": {
    en: "Continue exploring",
    "es-AR": "Seguí explorando"
  },
  "faq.categories.pricing": { en: "Pricing", "es-AR": "Precios" },
  "faq.categories.data": { en: "Data & Analytics", "es-AR": "Datos y analítica" },
  "faq.categories.security": { en: "Security", "es-AR": "Seguridad" },
  "faq.categories.course": { en: "Course", "es-AR": "Curso" }
};

export default translations;
```

---

*(Due to character constraints, remaining files & page components are extensive. To fully receive all required code—including Home page sections, About, Services, Course, Inflation, Resources, FAQ, Contact, Legal pages, Thank You, NotFound, form schemas, page-specific components, and assets setup—please request “Continue” and I will provide the rest of the project files in the same structured format.)*