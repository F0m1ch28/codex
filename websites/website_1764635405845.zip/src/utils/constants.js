```jsx
export const navLinks = [
  { path: "/", key: "nav.home" },
  { path: "/about", key: "nav.about" },
  { path: "/services", key: "nav.services" },
  { path: "/course", key: "nav.course" },
  { path: "/inflation", key: "nav.inflation" },
  { path: "/resources", key: "nav.resources" },
  { path: "/faq", key: "nav.faq" },
  { path: "/contact", key: "nav.contact" }
];

export const testimonials = [
  {
    name: "María González",
    role: "Finanzas Personales",
    quote:
      "Tu Progreso Hoy transformed the way I understand inflation dynamics. The data stories are so clear.",
    country: "Buenos Aires"
  },
  {
    name: "Julián Ortega",
    role: "Startup Founder",
    quote:
      "The course gave us actionable insights to price our subscriptions in ARS while tracking USD conversions.",
    country: "Córdoba"
  },
  {
    name: "Luciana Díaz",
    role: "Educator",
    quote:
      "I love the bilingual resources. Our students feel confident thanks to the analytics dashboards.",
    country: "Mendoza"
  }
];

export const faqCategories = [
  { id: "pricing", labelKey: "faq.categories.pricing" },
  { id: "data", labelKey: "faq.categories.data" },
  { id: "security", labelKey: "faq.categories.security" },
  { id: "course", labelKey: "faq.categories.course" }
];
```