```jsx
import React, { createContext, useContext, useMemo, useState } from "react";
import translations from "../utils/translations";
import useLocalStorage from "../hooks/useLocalStorage";

const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useLocalStorage("tph-lang", "en");

  const value = useMemo(
    () => ({
      language,
      setLanguage,
      t: (key) => translations[key]?.[language] || key,
      dual: (key) => ({
        en: translations[key]?.en || key,
        es: translations[key]?.["es-AR"] || key
      })
    }),
    [language, setLanguage]
  );

  return (
    <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within LanguageProvider");
  return ctx;
};
```