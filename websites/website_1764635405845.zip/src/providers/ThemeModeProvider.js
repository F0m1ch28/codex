```jsx
import React, { createContext, useContext, useMemo } from "react";
import useLocalStorage from "../hooks/useLocalStorage";

const ThemeModeContext = createContext();

export const ThemeModeProvider = ({ children }) => {
  const [mode, setMode] = useLocalStorage("tph-theme", "light");

  const value = useMemo(
    () => ({
      mode,
      toggleMode: () =>
        setMode((prev) => (prev === "light" ? "deep" : "light"))
    }),
    [mode, setMode]
  );

  return (
    <ThemeModeContext.Provider value={value}>
      <div data-theme={mode}>{children}</div>
    </ThemeModeContext.Provider>
  );
};

export const useThemeMode = () => {
  const ctx = useContext(ThemeModeContext);
  if (!ctx) throw new Error("useThemeMode must be used inside provider");
  return ctx;
};
```