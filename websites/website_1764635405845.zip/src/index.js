```jsx
import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import App from "./App";
import GlobalStyles from "./styles/GlobalStyles";
import { ThemeProvider } from "styled-components";
import theme from "./styles/theme";
import { LanguageProvider } from "./providers/LanguageProvider";
import { ThemeModeProvider } from "./providers/ThemeModeProvider";
import ScrollToTop from "./components/Shared/ScrollToTop";

const container = document.getElementById("root");
const root = createRoot(container);

root.render(
  <React.StrictMode>
    <HelmetProvider>
      <ThemeModeProvider>
        <LanguageProvider>
          <ThemeProvider theme={theme}>
            <BrowserRouter>
              <ScrollToTop />
              <GlobalStyles />
              <App />
            </BrowserRouter>
          </ThemeProvider>
        </LanguageProvider>
      </ThemeModeProvider>
    </HelmetProvider>
  </React.StrictMode>
);
```