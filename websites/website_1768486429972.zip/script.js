const navToggle = document.querySelector('.nav-toggle');
const navLinks = document.querySelector('.nav-links');
const cookieBanner = document.querySelector('.cookie-banner');
const cookieButtons = document.querySelectorAll('.cookie-button');

if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
        navLinks.classList.toggle('is-open');
        navToggle.setAttribute('aria-expanded', navLinks.classList.contains('is-open'));
    });
}

if (cookieBanner && cookieButtons.length) {
    cookieButtons.forEach(button => {
        button.addEventListener('click', event => {
            const href = button.getAttribute('href');
            if (href && href.includes('cookies.html')) {
                event.preventDefault();
                cookieBanner.classList.add('is-hidden');
                cookieBanner.setAttribute('hidden', 'hidden');
                window.location.href = href;
            } else {
                cookieBanner.classList.add('is-hidden');
                cookieBanner.setAttribute('hidden', 'hidden');
            }
        });
    });
}