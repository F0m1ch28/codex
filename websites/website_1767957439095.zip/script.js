document.addEventListener('DOMContentLoaded', function () {
    const yearSpan = document.getElementById('current-year');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const consent = localStorage.getItem('cookieConsent');
        if (consent) {
            cookieBanner.classList.add('hidden');
        } else {
            cookieBanner.classList.remove('hidden');
        }

        cookieBanner.querySelectorAll('.cookie-btn').forEach(function (btn) {
            btn.addEventListener('click', function (event) {
                event.preventDefault();
                const decision = btn.dataset.consent;
                if (decision) {
                    localStorage.setItem('cookieConsent', decision);
                }
                cookieBanner.classList.add('hidden');
            });
        });
    }
});