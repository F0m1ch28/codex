import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const usePageMetadata = (title, description) => {
  useEffect(() => {
    document.title = title;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', description);
  }, [title, description]);
};

const HomePage = () => {
  usePageMetadata(
    'Calorimbastella - Smart Budgeting | Planeación financiera inteligente',
    'Descubre soluciones de presupuestación para hogares mexicanos. Analiza tus hábitos y optimiza tus decisiones con Calorimbastella.'
  );

  return (
    <div className={styles.homePage}>
      <section className={styles.heroSection}>
        <div className={styles.heroContent}>
          <p className={styles.heroEyebrow}>Planeación a tu medida en México</p>
          <h1 className={styles.heroTitle}>
            Toma decisiones financieras inteligentes con datos claros y accionables
          </h1>
          <p className={styles.heroSubtitle}>
            Calorimbastella combina analítica, contexto local y acompañamiento para ayudarte a
            equilibrar tu presupuesto sin renunciar a tus prioridades.
          </p>
          <div className={styles.heroCtas}>
            <Link to="/herramientas" className={styles.primaryButton}>
              Explorar herramientas
            </Link>
            <Link to="/guia" className={styles.secondaryButton}>
              Leer la guía esencial
            </Link>
          </div>
        </div>
        <div className={styles.heroVisual} aria-hidden="true">
          <img
            src="https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&w=1200&q=80"
            alt=""
          />
        </div>
      </section>

      <section className={styles.overviewSection}>
        <div className={styles.overviewGrid}>
          <article className={styles.overviewCard}>
            <h2>Visión estratégica</h2>
            <p>
              Diseñamos rutas financieras personalizadas para hogares mexicanos considerando el costo
              de vida de cada región, metas familiares y hábitos culturales.
            </p>
          </article>
          <article className={styles.overviewCard}>
            <h2>Metodología calibrada</h2>
            <p>
              Aplicamos modelos estadísticos y escenarios de sensibilidad que anticipan gastos clave
              como vivienda, educación, salud y movilidad.
            </p>
          </article>
          <article className={styles.overviewCard}>
            <h2>Acompañamiento cercano</h2>
            <p>
              Nuestro equipo facilita sesiones educativas y tableros visuales para traducir datos en
              acciones concretas que puedas aplicar semana a semana.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.featuresSection}>
        <h2>Servicios centrales de Calorimbastella</h2>
        <div className={styles.featuresGrid}>
          <article className={styles.featureCard}>
            <span className={styles.featureIcon} aria-hidden="true">📊</span>
            <h3>Analítica de gastos</h3>
            <p>
              Identifica patrones de consumo, analiza tus categorías esenciales y recibe
              recomendaciones automáticas basadas en indicadores mexicanos.
            </p>
          </article>
          <article className={styles.featureCard}>
            <span className={styles.featureIcon} aria-hidden="true">🧭</span>
            <h3>Planeación de objetivos</h3>
            <p>
              Define metas claras, desde educación hasta viajes, y obtén escenarios trimestrales con
              metas de ahorro sostenibles.
            </p>
          </article>
          <article className={styles.featureCard}>
            <span className={styles.featureIcon} aria-hidden="true">⚙️</span>
            <h3>Automatización inteligente</h3>
            <p>
              Configura alertas, recordatorios y ajustes automáticos que se adaptan a cambios en tus
              ingresos, inflación y estilo de vida.
            </p>
          </article>
          <article className={styles.featureCard}>
            <span className={styles.featureIcon} aria-hidden="true">🤝</span>
            <h3>Mentoría especializada</h3>
            <p>
              Conecta con especialistas en finanzas personales que comprenden el contexto mexicano y
              acompañan cada decisión importante.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.metricsSection}>
        <div className={styles.metricsGrid}>
          <div className={styles.metricCard}>
            <p className={styles.metricValue}>92%</p>
            <p className={styles.metricLabel}>de usuarios ajustó su presupuesto en menos de 4 semanas</p>
          </div>
          <div className={styles.metricCard}>
            <p className={styles.metricValue}>160+</p>
            <p className={styles.metricLabel}>municipios con parámetros adaptados en nuestra plataforma</p>
          </div>
          <div className={styles.metricCard}>
            <p className={styles.metricValue}>48 hrs</p>
            <p className={styles.metricLabel}>para recibir tu tablero personalizado después del diagnóstico</p>
          </div>
        </div>
      </section>

      <section className={styles.howItWorksSection}>
        <h2>¿Cómo trabajamos contigo?</h2>
        <ol className={styles.stepsList}>
          <li className={styles.stepCard}>
            <span className={styles.stepNumber}>1</span>
            <h3>Diagnóstico integral</h3>
            <p>
              Capturamos tus ingresos, obligaciones y estilo de vida para entender el contexto real y
              definir prioridades.
            </p>
          </li>
          <li className={styles.stepCard}>
            <span className={styles.stepNumber}>2</span>
            <h3>Ruta estratégica</h3>
            <p>
              Con base en tus metas, trazamos un calendario realista con ajustes progresivos y acciones
              de alto impacto.
            </p>
          </li>
          <li className={styles.stepCard}>
            <span className={styles.stepNumber}>3</span>
            <h3>Seguimiento continuo</h3>
            <p>
              Monitoreamos tus avances con tableros intuitivos, asesorías puntuales y notificaciones
              oportunas.
            </p>
          </li>
        </ol>
      </section>

      <section className={styles.testimonialsSection}>
        <h2>Historias que inspiran</h2>
        <div className={styles.testimonialsGrid}>
          <figure className={styles.testimonialCard}>
            <img
              className={styles.testimonialAvatar}
              src="https://i.pravatar.cc/150?img=47"
              alt="Retrato de Mariana L."
            />
            <blockquote className={styles.testimonialMessage}>
              “Nuestro hogar en Puebla logró equilibrar los gastos escolares y de salud. Las alertas y
              simulaciones nos dieron tranquilidad y claridad.”
            </blockquote>
            <figcaption>Mariana L. · Puebla</figcaption>
          </figure>
          <figure className={styles.testimonialCard}>
            <img
              className={styles.testimonialAvatar}
              src="https://i.pravatar.cc/150?img=32"
              alt="Retrato de Jorge R."
            />
            <blockquote className={styles.testimonialMessage}>
              “Las herramientas nos ayudaron a medir el impacto de cada decisión. Ahora actualizamos
              nuestro presupuesto en minutos y con rumbo.”
            </blockquote>
            <figcaption>Jorge R. · Monterrey</figcaption>
          </figure>
          <figure className={styles.testimonialCard}>
            <img
              className={styles.testimonialAvatar}
              src="https://i.pravatar.cc/150?img=12"
              alt="Retrato de Andrea G."
            />
            <blockquote className={styles.testimonialMessage}>
              “El acompañamiento del equipo fue clave para priorizar experiencias familiares sin
              descuidar nuestras reservas.”
            </blockquote>
            <figcaption>Andrea G. · Mérida</figcaption>
          </figure>
        </div>
      </section>

      <section className={styles.finalCtaSection}>
        <div className={styles.finalCtaContent}>
          <h2>Da el siguiente paso con Calorimbastella</h2>
          <p>
            Activa tus herramientas personalizadas, recibe diagnósticos avanzados y transforma tus
            decisiones financieras con claridad.
          </p>
          <div className={styles.heroCtas}>
            <Link to="/contacto" className={styles.primaryButton}>
              Solicitar diagnóstico
            </Link>
            <Link to="/programas" className={styles.secondaryButton}>
              Revisar programas
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;