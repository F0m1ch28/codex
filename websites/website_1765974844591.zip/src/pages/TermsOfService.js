import React, { useEffect } from 'react';
import styles from './Legal.module.css';

const usePageMetadata = (title, description) => {
  useEffect(() => {
    document.title = title;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', description);
  }, [title, description]);
};

const LegalPage = () => {
  usePageMetadata(
    'Avisos legales | Calorimbastella - Smart Budgeting',
    'Consulta los términos de uso y la información legal de Calorimbastella - Smart Budgeting.'
  );

  return (
    <div className={styles.legalPage}>
      <h1>Avisos legales de Calorimbastella</h1>
      <section className={styles.section}>
        <h2>1. Uso del sitio</h2>
        <p>
          Calorimbastella - Smart Budgeting proporciona herramientas, contenidos y recursos educativos
          orientados a la planeación de presupuesto. Al utilizar este sitio aceptas hacerlo de manera
          responsable y exclusivamente para fines personales o familiares.
        </p>
      </section>

      <section className={styles.section}>
        <h2>2. Límites de responsabilidad</h2>
        <p>
          Trabajamos con información actualizada y contextualizada a México. Aun así, los resultados
          pueden variar según las circunstancias de cada usuario. Te recomendamos verificar cualquier
          decisión importante con un asesor especializado.
        </p>
      </section>

      <section className={styles.section}>
        <h2>3. Propiedad intelectual</h2>
        <p>
          Los contenidos, diseños, logotipos, gráficos y materiales disponibles en este sitio son
          propiedad de Calorimbastella o se utilizan con autorización. Queda prohibida su reproducción
          total o parcial sin consentimiento escrito previo.
        </p>
      </section>

      <section className={styles.section}>
        <h2>4. Actualizaciones</h2>
        <p>
          Estas condiciones pueden modificarse para mantener la precisión y el cumplimiento regulatorio.
          Te sugerimos revisarlas periódicamente.
        </p>
      </section>
    </div>
  );
};

export default LegalPage;