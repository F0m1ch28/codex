import React, { useEffect } from 'react';
import styles from './Privacy.module.css';

const usePageMetadata = (title, description) => {
  useEffect(() => {
    document.title = title;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', description);
  }, [title, description]);
};

const PrivacyPolicyPage = () => {
  usePageMetadata(
    'Política de privacidad | Calorimbastella',
    'Consulta cómo Calorimbastella protege tus datos personales al ofrecer soluciones de planeación financiera.'
  );

  return (
    <div className={styles.privacyPage}>
      <h1>Política de privacidad</h1>
      <section className={styles.section}>
        <h2>Datos que recopilamos</h2>
        <p>
          Solicitamos información como nombre, correo electrónico, zona de residencia y hábitos de gasto
          con el propósito de construir recomendaciones personalizadas. Esta información se resguarda en
          servidores seguros con acceso restringido.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Uso responsable</h2>
        <p>
          Empleamos tus datos para enviarte reportes, recordatorios y contenido educativo. Nunca
          compartimos información identificable con terceros sin tu consentimiento expreso.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Derechos ARCO</h2>
        <p>
          Puedes solicitar el acceso, rectificación, cancelación u oposición del tratamiento de tus datos
          escribiendo a contacto@calorimbastella.site. Atenderemos tu solicitud en un plazo máximo de 20
          días hábiles.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Vigencia</h2>
        <p>
          Esta política se actualiza periódicamente para garantizar su vigencia. Te notificaremos cualquier
          cambio sustancial a través de nuestros canales oficiales.
        </p>
      </section>
    </div>
  );
};

export const CookiePolicyPage = () => {
  usePageMetadata(
    'Política de cookies | Calorimbastella',
    'Aprende cómo Calorimbastella utiliza cookies para mejorar la experiencia de planeación financiera.'
  );

  return (
    <div className={styles.privacyPage}>
      <h1>Política de cookies</h1>
      <section className={styles.section}>
        <h2>¿Qué son las cookies?</h2>
        <p>
          Son archivos pequeños que se almacenan en tu navegador para recordar preferencias y entender
          cómo interactúas con nuestro sitio. Nos ayudan a ofrecerte recomendaciones más relevantes.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Tipos de cookies que utilizamos</h2>
        <ul className={styles.list}>
          <li>
            Esenciales: necesarias para acceder a las herramientas y garantizar la seguridad de las
            sesiones.
          </li>
          <li>
            Analíticas: nos permiten comprender qué secciones son más consultadas y mejorar la
            experiencia.
          </li>
          <li>
            Funcionales: guardan tus preferencias de idioma y vista para presentarte contenido adecuado.
          </li>
        </ul>
      </section>
      <section className={styles.section}>
        <h2>Gestión de preferencias</h2>
        <p>
          Puedes administrar las cookies desde la configuración de tu navegador o a través del banner
          que aparece al visitar el sitio. Si decides desactivarlas, algunas funciones podrían limitarse.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Contacto</h2>
        <p>
          Para resolver dudas sobre el uso de cookies, contáctanos en contacto@calorimbastella.site.
        </p>
      </section>
    </div>
  );
};

export default PrivacyPolicyPage;