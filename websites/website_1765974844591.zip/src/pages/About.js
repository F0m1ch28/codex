import React, { useEffect } from 'react';
import styles from './About.module.css';

const usePageMetadata = (title, description) => {
  useEffect(() => {
    document.title = title;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', description);
  }, [title, description]);
};

const AboutPage = () => {
  usePageMetadata(
    'Nosotros | Calorimbastella - Smart Budgeting',
    'Conoce la historia, misión y equipo multidisciplinario que impulsa Calorimbastella y acompaña a los hogares mexicanos.'
  );

  return (
    <div className={styles.aboutPage}>
      <section className={styles.aboutHero}>
        <div className={styles.heroContent}>
          <h1>Somos Calorimbastella</h1>
          <p>
            Nacimos en Ciudad de México con el objetivo de acercar metodologías financieras a
            personas y familias que buscan estabilidad, claridad y bienestar. Creemos en el poder de
            los datos traducidos en acciones simples y en la importancia de respetar las particularidades
            culturales del país.
          </p>
        </div>
        <div className={styles.heroImage} aria-hidden="true">
          <img
            src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1100&q=80"
            alt=""
          />
        </div>
      </section>

      <section className={styles.narrativeSection}>
        <h2>Nuestra misión</h2>
        <p>
          Acompañamos a la comunidad mexicana con herramientas accesibles, contenido educativo y
          asesoría especializada. Construimos estrategias que consideran la inflación local, los
          beneficios laborales nacionales, la informalidad y los hábitos de consumo de cada región.
        </p>
        <h3>Lo que nos distingue</h3>
        <ul className={styles.valuesList}>
          <li>Decisiones basadas en analítica y sensibilidad regional.</li>
          <li>Lenguaje claro y acompañamiento cercano sin tecnicismos innecesarios.</li>
          <li>Compromiso con la educación financiera como motor de bienestar social.</li>
        </ul>
      </section>

      <section className={styles.timelineSection}>
        <h2>Camino recorrido</h2>
        <div className={styles.timeline}>
          <article className={styles.timelineItem}>
            <h4>2018</h4>
            <p>Se conforma el equipo fundador con especialistas en finanzas, sociología y diseño.</p>
          </article>
          <article className={styles.timelineItem}>
            <h4>2020</h4>
            <p>Lanzamos el primer tablero dinámico con datos de 35 ciudades mexicanas.</p>
          </article>
          <article className={styles.timelineItem}>
            <h4>2022</h4>
            <p>Integramos asesoría remota y sesiones grupales enfocadas en educación financiera.</p>
          </article>
          <article className={styles.timelineItem}>
            <h4>2023</h4>
            <p>Incorporamos métricas de sostenibilidad y bienestar en nuestros diagnósticos.</p>
          </article>
        </div>
      </section>

      <section className={styles.teamSection}>
        <h2>Equipo multidisciplinario</h2>
        <div className={styles.teamGrid}>
          <article className={styles.teamCard}>
            <img
              src="https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80"
              alt="Retrato de Laura Méndez, directora de análisis"
            />
            <h3>Laura Méndez</h3>
            <p className={styles.teamRole}>Directora de análisis</p>
            <p>
              Economista especializada en modelos de costo de vida y políticas públicas. Lidera la
              integración de datos y escenarios.
            </p>
          </article>
          <article className={styles.teamCard}>
            <img
              src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80"
              alt="Retrato de Daniela López, consultora de hábitos financieros"
            />
            <h3>Daniela López</h3>
            <p className={styles.teamRole}>Consultora de hábitos financieros</p>
            <p>
              Diseña experiencias educativas y talleres para familias, con énfasis en bienestar y
              corresponsabilidad.
            </p>
          </article>
          <article className={styles.teamCard}>
            <img
              src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80"
              alt="Retrato de Miguel Andrade, líder de producto"
            />
            <h3>Miguel Andrade</h3>
            <p className={styles.teamRole}>Líder de producto digital</p>
            <p>
              Arquitecto de la plataforma tecnológica que permite visualizar escenarios, alertas y
              recomendaciones personalizadas.
            </p>
          </article>
          <article className={styles.teamCard}>
            <img
              src="https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=600&q=80"
              alt="Retrato de Sara Hernández, coordinadora de impacto"
            />
            <h3>Sara Hernández</h3>
            <p className={styles.teamRole}>Coordinadora de impacto</p>
            <p>
              Monitorea la satisfacción de los usuarios, recopila historias de éxito y garantiza la
              mejora continua de nuestros servicios.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;