import React, { useEffect, useState } from 'react';
import styles from './Contact.module.css';

const usePageMetadata = (title, description) => {
  useEffect(() => {
    document.title = title;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', description);
  }, [title, description]);
};

const ContactPage = () => {
  usePageMetadata(
    'Contacto | Calorimbastella - Smart Budgeting',
    'Ponte en contacto con el equipo de Calorimbastella para resolver dudas sobre nuestros programas y herramientas.'
  );

  const [formData, setFormData] = useState({ nombre: '', correo: '', mensaje: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ type: '', message: '' });

  const validate = () => {
    const newErrors = {};
    if (!formData.nombre.trim()) {
      newErrors.nombre = 'Por favor ingresa tu nombre.';
    }
    if (!formData.correo.trim()) {
      newErrors.correo = 'Incluye un correo electrónico.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.correo)) {
      newErrors.correo = 'El formato de correo no es válido.';
    }
    if (!formData.mensaje.trim() || formData.mensaje.trim().length < 10) {
      newErrors.mensaje = 'Comparte más detalles sobre tu consulta (mínimo 10 caracteres).';
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setStatus({
        type: 'success',
        message: 'Gracias por tu mensaje. Te responderemos en un plazo máximo de 24 horas hábiles.'
      });
      setFormData({ nombre: '', correo: '', mensaje: '' });
    } else {
      setStatus({ type: 'error', message: 'Revisa la información destacada e inténtalo nuevamente.' });
    }
  };

  return (
    <div className={styles.contactPage}>
      <section className={styles.contactIntro}>
        <h1>Conversemos sobre tus objetivos</h1>
        <p>
          ¿Deseas conocer más sobre nuestros programas, solicitar un diagnóstico o agendar una sesión?
          Completa el formulario y nuestro equipo te contactará.
        </p>
      </section>

      <section className={styles.formSection}>
        <div className={styles.formWrapper}>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.fieldGroup}>
              <label htmlFor="nombre">Nombre completo</label>
              <input
                id="nombre"
                name="nombre"
                type="text"
                value={formData.nombre}
                onChange={handleChange}
                aria-describedby={errors.nombre ? 'error-nombre' : undefined}
                required
              />
              {errors.nombre && (
                <span id="error-nombre" className={styles.error}>
                  {errors.nombre}
                </span>
              )}
            </div>

            <div className={styles.fieldGroup}>
              <label htmlFor="correo">Correo electrónico</label>
              <input
                id="correo"
                name="correo"
                type="email"
                value={formData.correo}
                onChange={handleChange}
                aria-describedby={errors.correo ? 'error-correo' : undefined}
                required
              />
              {errors.correo && (
                <span id="error-correo" className={styles.error}>
                  {errors.correo}
                </span>
              )}
            </div>

            <div className={styles.fieldGroup}>
              <label htmlFor="mensaje">¿Cómo podemos ayudarte?</label>
              <textarea
                id="mensaje"
                name="mensaje"
                rows="6"
                value={formData.mensaje}
                onChange={handleChange}
                aria-describedby={errors.mensaje ? 'error-mensaje' : undefined}
                required
              />
              {errors.mensaje && (
                <span id="error-mensaje" className={styles.error}>
                  {errors.mensaje}
                </span>
              )}
            </div>

            <button type="submit" className={styles.submitButton}>
              Enviar mensaje
            </button>

            {status.message && (
              <p
                className={`${styles.statusMessage} ${
                  status.type === 'success' ? styles.success : styles.statusMessage
                }`}
                aria-live="polite"
              >
                {status.message}
              </p>
            )}
          </form>
        </div>

        <aside className={styles.infoPanel}>
          <h2>Más formas de contacto</h2>
          <ul>
            <li>Teléfono: [+52 XX XXXX XXXX]</li>
            <li>Correo: contacto@calorimbastella.site</li>
            <li>Horario de atención: Lunes a viernes de 9:00 a 18:00 (GMT-6)</li>
          </ul>
          <p>
            También ofrecemos sesiones virtuales personalizadas. Indícanos tus horarios disponibles y
            coordinaremos la reunión inicial.
          </p>
        </aside>
      </section>
    </div>
  );
};

export default ContactPage;