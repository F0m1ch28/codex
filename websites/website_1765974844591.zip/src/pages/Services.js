import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './Services.module.css';

const usePageMetadata = (title, description) => {
  useEffect(() => {
    document.title = title;
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', description);
  }, [title, description]);
};

const ProgramsPage = () => {
  usePageMetadata(
    'Programas de Calorimbastella | Smart Budgeting',
    'Explora los programas de Calorimbastella para optimizar tu presupuesto, desde diagnósticos hasta mentoría continua.'
  );

  const programas = [
    {
      titulo: 'Diagnóstico Integral 360°',
      descripcion:
        'Evaluación detallada de ingresos, gastos y compromisos familiares para construir tu perfil financiero y detectar oportunidades inmediatas.',
      tag: 'Ideal para nuevos usuarios',
      beneficios: [
        'Reporte con análisis de 4 categorías clave',
        'Escenarios de contingencia regionales',
        'Sesión introductoria con especialista'
      ]
    },
    {
      titulo: 'Ruta Estratégica Semestral',
      descripcion:
        'Planificación de objetivos por trimestre con ajustes automáticos según inflación, hábitos y metas familiares en México.',
      tag: 'Seguimiento activo',
      beneficios: [
        'Tablero con metas mensuales',
        'Recordatorios personalizados',
        'Revisión bimestral con asesor'
      ]
    },
    {
      titulo: 'Mentoría para proyectos de vida',
      descripcion:
        'Acompañamiento para decisiones relevantes como educación, mudanza o emprendimiento familiar con escenarios comparativos.',
      tag: 'Consultoría especializada',
      beneficios: [
        'Sesiones a distancia y presenciales',
        'Modelos de priorización',
        'Recomendaciones de hábitos sostenibles'
      ]
    }
  ];

  return (
    <div className={styles.page}>
      <section className={styles.introSection}>
        <h1>Programas diseñados para sostener tus objetivos</h1>
        <p>
          Cada programa combina datos, asesoría y herramientas visuales para adaptarse a la dinámica
          mexicana. Puedes iniciar con un diagnóstico puntual o mantener un acompañamiento continuo.
        </p>
      </section>
      <section className={styles.cardsSection}>
        <div className={styles.cardGrid}>
          {programas.map((programa) => (
            <article key={programa.titulo} className={styles.card}>
              <span className={styles.tag}>{programa.tag}</span>
              <h2>{programa.titulo}</h2>
              <p>{programa.descripcion}</p>
              <ul className={styles.cardList}>
                {programa.beneficios.map((beneficio) => (
                  <li key={beneficio}>{beneficio}</li>
                ))}
              </ul>
              <Link to="/contacto" className={styles.cardLink}>
                Solicitar información
              </Link>
            </article>
          ))}
        </div>
      </section>
      <section className={styles.highlightSection}>
        <div>
          <h2>Lo que obtienes</h2>
          <p>
            Visualizaciones claras, alertas oportunas y estrategias adaptadas a tus prioridades.
            Integramos fuentes de datos como inflación, canasta básica e indicadores estatales para que
            tus decisiones tengan fundamento.
          </p>
        </div>
        <img
          src="https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=900&q=80"
          alt="Persona revisando gráficos de presupuesto en una tablet"
        />
      </section>
    </div>
  );
};

export const GuidePage = () => {
  usePageMetadata(
    'Guía de presupuesto | Calorimbastella',
    'Aprende técnicas de presupuesto y optimización de gastos con la guía detallada de Calorimbastella.'
  );

  return (
    <div className={styles.page}>
      <header className={styles.introSection}>
        <h1>Guía para presupuestar con inteligencia en México</h1>
        <p>
          Reunimos principios prácticos y herramientas para que diseñes tu propio plan financiero.
          Cada capítulo incluye ejemplos, formatos descargables y claves de implementación.
        </p>
      </header>
      <section className={styles.guideSection}>
        <article className={styles.guideArticle}>
          <h2>1. Diagnóstico consciente</h2>
          <p>
            Registra tus gastos fijos y variables durante cuatro semanas. Clasifícalos en categorías
            homogéneas (vivienda, transporte, alimentación, experiencias) y detecta patrones recurrentes.
          </p>
          <ul>
            <li>Define periodos de análisis (mensual o quincenal).</li>
            <li>Utiliza la técnica de sobres digitales para distribuir tu ingreso.</li>
            <li>Incluye gastos estacionales como uniformes, mantenimiento o viajes familiares.</li>
          </ul>
        </article>
        <article className={styles.guideArticle}>
          <h2>2. Prioridades con propósito</h2>
          <p>
            Asigna tus metas a horizontes temporales: cortas, medianas y largas. Evalúa qué actividades
            te acercan a ellas y cuáles las frenan. Calorimbastella te sugiere ajustes graduales para
            mantener el ritmo.
          </p>
          <p>
            Recuerda destinar un porcentaje a imprevistos, otro a disfrute consciente y otro a
            construcción de reservas futuras.
          </p>
        </article>
        <article className={styles.guideArticle}>
          <h2>3. Monitoreo constante</h2>
          <p>
            Programa revisiones semanales para validar avances. Ajusta montos y metas según cambios en
            tu contexto laboral o familiar.
          </p>
          <p>
            Integra tableros personalizados y, si tu ingreso es variable, utiliza promedios móviles para
            evitar altibajos bruscos.
          </p>
        </article>
      </section>
    </div>
  );
};

export const ToolsPage = () => {
  usePageMetadata(
    'Herramientas inteligentes | Calorimbastella',
    'Interactúa con herramientas y calculadoras de Calorimbastella para optimizar tu presupuesto con precisión.'
  );

  const [ingresoMensual, setIngresoMensual] = useState('');
  const [gastoEsencial, setGastoEsencial] = useState('');
  const [recomendacion, setRecomendacion] = useState(null);

  const [metaMonto, setMetaMonto] = useState('');
  const [metaMeses, setMetaMeses] = useState('');
  const [metaResultado, setMetaResultado] = useState(null);

  useEffect(() => {
    if (ingresoMensual && gastoEsencial) {
      const ingreso = Number(ingresoMensual);
      const esenciales = Number(gastoEsencial);
      if (!Number.isNaN(ingreso) && !Number.isNaN(esenciales) && ingreso > 0) {
        const bienestar = Math.max(0, ingreso * 0.2);
        const crecimiento = Math.max(0, ingreso - esenciales - bienestar);
        setRecomendacion({
          bienestar: bienestar.toFixed(2),
          crecimiento: crecimiento.toFixed(2),
          esenciales: esenciales.toFixed(2)
        });
      }
    }
  }, [ingresoMensual, gastoEsencial]);

  useEffect(() => {
    if (metaMonto && metaMeses) {
      const monto = Number(metaMonto);
      const meses = Number(metaMeses);
      if (!Number.isNaN(monto) && !Number.isNaN(meses) && meses > 0) {
        const sugerido = monto / meses;
        setMetaResultado(sugerido.toFixed(2));
      }
    }
  }, [metaMonto, metaMeses]);

  return (
    <div className={styles.page}>
      <section className={styles.introSection}>
        <h1>Herramientas para presupuestos vibrantes</h1>
        <p>
          Experimenta con nuestras calculadoras y visualiza rápidamente cómo organizar tu dinero,
          alcanzar metas y mantener equilibrio.
        </p>
      </section>

      <section className={styles.toolsLayout}>
        <article className={styles.toolCard}>
          <h2>Distribuidor 50-30-20 adaptado</h2>
          <p>
            Ingresa tu ingreso mensual y tu gasto esencial estimado para visualizar cuánto destinar a
            bienestar y crecimiento personal.
          </p>
          <form className={styles.calculatorForm}>
            <label htmlFor="ingreso">Ingreso mensual (MXN)</label>
            <input
              id="ingreso"
              type="number"
              min="0"
              value={ingresoMensual}
              onChange={(event) => setIngresoMensual(event.target.value)}
            />
            <label htmlFor="esencial">Gasto esencial (MXN)</label>
            <input
              id="esencial"
              type="number"
              min="0"
              value={gastoEsencial}
              onChange={(event) => setGastoEsencial(event.target.value)}
            />
          </form>
          {recomendacion && (
            <div className={styles.resultBox} aria-live="polite">
              <p>
                Esenciales recomendados: <strong>${recomendacion.esenciales}</strong>
              </p>
              <p>
                Bienestar consciente: <strong>${recomendacion.bienestar}</strong>
              </p>
              <p>
                Crecimiento y futuro: <strong>${recomendacion.crecimiento}</strong>
              </p>
            </div>
          )}
        </article>

        <article className={styles.toolCard}>
          <h2>Planificador de metas</h2>
          <p>
            Determina cuánto necesitas reservar cada mes para lograr tu objetivo en el tiempo deseado.
            Ideal para estudios, vivienda o experiencias familiares.
          </p>
          <form className={styles.calculatorForm}>
            <label htmlFor="metaMonto">Monto objetivo (MXN)</label>
            <input
              id="metaMonto"
              type="number"
              min="0"
              value={metaMonto}
              onChange={(event) => setMetaMonto(event.target.value)}
            />
            <label htmlFor="metaMeses">Meses previstos</label>
            <input
              id="metaMeses"
              type="number"
              min="1"
              value={metaMeses}
              onChange={(event) => setMetaMeses(event.target.value)}
            />
          </form>
          {metaResultado && (
            <div className={styles.resultBox} aria-live="polite">
              <p>
                Necesitas destinar <strong>${metaResultado} MXN</strong> por mes para alcanzar tu meta
                en el periodo elegido.
              </p>
            </div>
          )}
        </article>

        <article className={styles.toolCard}>
          <h2>Tablero de hábitos</h2>
          <p>
            Integra estas métricas en tu tablero de Calorimbastella y recibe recordatorios,
            visualizaciones y sugerencias puntuales cada semana.
          </p>
          <ul className={styles.toolList}>
            <li>Alertas cuando tus gastos variables superan el umbral definido.</li>
            <li>Consejos basados en tendencias de inflación y mercado local.</li>
            <li>Comparativos con tu histórico y usuarios de perfil similar.</li>
          </ul>
          <Link to="/programas" className={styles.cardLink}>
            Conocer el tablero completo
          </Link>
        </article>
      </section>
    </div>
  );
};

export const BlogPage = () => {
  usePageMetadata(
    'Blog Calorimbastella | Historias y estrategias',
    'Lee artículos y casos reales que ilustran cómo optimizar el presupuesto en México con Calorimbastella.'
  );

  const posts = [
    {
      titulo: 'Cómo una familia en Guadalajara reorganizó sus gastos escolares',
      fecha: '10 marzo 2024',
      resumen:
        'Comparamos tres escenarios de colegiaturas, actividades extracurriculares y transporte para mantener equilibrio financiero.'
    },
    {
      titulo: 'Saque el máximo provecho a las prestaciones mexicanas',
      fecha: '27 febrero 2024',
      resumen:
        'Analizamos cómo integrar aguinaldo, fondo de ahorro y vales en tu estrategia anual de presupuesto.'
    },
    {
      titulo: 'Vivienda compartida: dividir gastos sin conflictos',
      fecha: '14 febrero 2024',
      resumen:
        'Te mostramos formatos y acuerdos que ayudan a repartir servicios, despensa y mantenimiento en departamentos compartidos.'
    },
    {
      titulo: 'Microempresas familiares y flujo de efectivo',
      fecha: '29 enero 2024',
      resumen:
        'Recomendaciones para equilibrar ingresos variables mientras se protege el presupuesto del hogar.'
    }
  ];

  return (
    <div className={styles.page}>
      <header className={styles.introSection}>
        <h1>Blog Calorimbastella</h1>
        <p>
          Historias reales, recomendaciones prácticas y análisis coyunturales que te inspiran a tomar
          decisiones informadas día a día.
        </p>
      </header>
      <section className={styles.blogSection}>
        <div className={styles.blogList}>
          {posts.map((post) => (
            <article key={post.titulo} className={styles.blogCard}>
              <h2>{post.titulo}</h2>
              <p className={styles.blogMeta}>{post.fecha}</p>
              <p>{post.resumen}</p>
              <Link to="/contacto" className={styles.cardLink}>
                Comentar este tema
              </Link>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default ProgramsPage;