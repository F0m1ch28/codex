import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { to: '/', label: 'Inicio' },
  { to: '/guia', label: 'Guía' },
  { to: '/programas', label: 'Programas' },
  { to: '/herramientas', label: 'Herramientas' },
  { to: '/blog', label: 'Blog' },
  { to: '/nosotros', label: 'Nosotros' },
  { to: '/contacto', label: 'Contacto' }
];

const Header = () => {
  const [menuAbierto, setMenuAbierto] = useState(false);

  const toggleMenu = () => {
    setMenuAbierto((prev) => !prev);
  };

  const closeMenu = () => {
    setMenuAbierto(false);
  };

  return (
    <header className={styles.header} role="banner">
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="Inicio Calorimbastella">
          <span className={styles.brandName}>Calorimbastella</span>
          <span className={styles.brandTagline}>Smart Budgeting</span>
        </Link>
        <button
          type="button"
          className={styles.menuButton}
          onClick={toggleMenu}
          aria-expanded={menuAbierto}
          aria-controls="menu-principal"
        >
          <span className={styles.menuIcon} aria-hidden="true" />
          <span className="visually-hidden">Abrir menú</span>
        </button>
        <nav
          id="menu-principal"
          className={`${styles.nav} ${menuAbierto ? styles.navOpen : ''}`}
          aria-label="Menú principal"
        >
          <ul className={styles.navList}>
            {navLinks.map((link) => (
              <li key={link.to} className={styles.navItem}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                  onClick={closeMenu}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <Link to="/herramientas" className={styles.ctaLink} onClick={closeMenu}>
            Explorar soluciones
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;