import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'calorimbastella-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const savedConsent = localStorage.getItem(STORAGE_KEY);
    if (!savedConsent) {
      setVisible(true);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem(STORAGE_KEY, value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.message}>
        Utilizamos cookies para analizar el uso del sitio y reforzar la experiencia de planeación.
        Consulta nuestra <Link to="/politica-cookies">política de cookies</Link>.
      </p>
      <div className={styles.actions}>
        <button type="button" className={styles.secondary} onClick={() => handleConsent('declined')}>
          Rechazar
        </button>
        <button type="button" className={styles.primary} onClick={() => handleConsent('accepted')}>
          Aceptar
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;