import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} role="contentinfo">
    <div className={styles.columns}>
      <div className={styles.column}>
        <p className={styles.brand}>Calorimbastella</p>
        <p className={styles.description}>
          Inteligencia financiera aplicada a la vida diaria en México. Acompañamos a familias y
          profesionales a diseñar hábitos económicos duraderos.
        </p>
      </div>
      <div className={styles.column}>
        <h3 className={styles.columnTitle}>Explora</h3>
        <ul className={styles.linkList}>
          <li><Link to="/guia" className={styles.link}>Guía de presupuesto</Link></li>
          <li><Link to="/programas" className={styles.link}>Programas</Link></li>
          <li><Link to="/herramientas" className={styles.link}>Herramientas</Link></li>
          <li><Link to="/blog" className={styles.link}>Blog</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3 className={styles.columnTitle}>Compañía</h3>
        <ul className={styles.linkList}>
          <li><Link to="/nosotros" className={styles.link}>Nosotros</Link></li>
          <li><Link to="/legal" className={styles.link}>Avisos legales</Link></li>
          <li><Link to="/privacidad" className={styles.link}>Privacidad</Link></li>
          <li><Link to="/politica-cookies" className={styles.link}>Política de cookies</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3 className={styles.columnTitle}>Contacto</h3>
        <ul className={styles.contactInfo}>
          <li>Dirección: [Dirección en México]</li>
          <li>Teléfono: [+52 XX XXXX XXXX]</li>
          <li>Correo: <a href="mailto:contacto@calorimbastella.site" className={styles.link}>contacto@calorimbastella.site</a></li>
        </ul>
        <div className={styles.socialLinks} aria-label="Redes sociales">
          <a href="https://www.linkedin.com" className={styles.link} target="_blank" rel="noreferrer">LinkedIn</a>
          <a href="https://www.facebook.com" className={styles.link} target="_blank" rel="noreferrer">Facebook</a>
          <a href="https://www.instagram.com" className={styles.link} target="_blank" rel="noreferrer">Instagram</a>
        </div>
      </div>
    </div>
    <div className={styles.bottomBar}>
      <p>&copy; {new Date().getFullYear()} Calorimbastella - Smart Budgeting. Derechos reservados.</p>
    </div>
  </footer>
);

export default Footer;