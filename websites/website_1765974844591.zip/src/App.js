import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ProgramsPage, { GuidePage, ToolsPage, BlogPage } from './pages/Services';
import ContactPage from './pages/Contact';
import LegalPage from './pages/TermsOfService';
import PrivacyPolicyPage, { CookiePolicyPage } from './pages/PrivacyPolicy';
import styles from './App.module.css';

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

function App() {
  return (
    <div className={styles.appShell}>
      <Header />
      <ScrollToTopOnRouteChange />
      <main className={styles.mainContent} id="contenido-principal">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/guia" element={<GuidePage />} />
          <Route path="/programas" element={<ProgramsPage />} />
          <Route path="/herramientas" element={<ToolsPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/nosotros" element={<AboutPage />} />
          <Route path="/contacto" element={<ContactPage />} />
          <Route path="/legal" element={<LegalPage />} />
          <Route path="/privacidad" element={<PrivacyPolicyPage />} />
          <Route path="/politica-cookies" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;