document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.nav-toggle').forEach(toggle => {
        const navContainer = toggle.closest('.nav-container');
        const navLinks = navContainer.querySelector('.nav-links');

        toggle.addEventListener('click', () => {
            const expanded = toggle.getAttribute('aria-expanded') === 'true';
            toggle.setAttribute('aria-expanded', (!expanded).toString());
            navLinks.classList.toggle('open');
        });

        navLinks.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                toggle.setAttribute('aria-expanded', 'false');
                navLinks.classList.remove('open');
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth > 1024) {
                toggle.setAttribute('aria-expanded', 'false');
                navLinks.classList.remove('open');
            }
        });
    });

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('springieCookieConsent');
        if (!storedConsent) {
            requestAnimationFrame(() => {
                cookieBanner.classList.add('visible');
            });
        } else {
            cookieBanner.remove();
        }

        cookieBanner.querySelectorAll('.cookie-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const choice = btn.dataset.choice || 'undecided';
                localStorage.setItem('springieCookieConsent', choice);
                cookieBanner.classList.remove('visible');
                cookieBanner.classList.add('hide');

                const target = btn.dataset.target;
                if (target) {
                    window.open(target, '_blank', 'noopener');
                }

                setTimeout(() => {
                    if (cookieBanner && cookieBanner.parentElement) {
                        cookieBanner.parentElement.removeChild(cookieBanner);
                    }
                }, 400);
            });
        });
    }

    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.24,
        rootMargin: '0px 0px -10% 0px'
    });

    document.querySelectorAll('[data-animate]').forEach(el => observer.observe(el));
});