import React, { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

interface NavItem {
  label: string;
  path: string;
}

const navItems: NavItem[] = [
  { label: "Home", path: "/" },
  { label: "About", path: "/about" },
  { label: "Systems", path: "/systems" },
  { label: "Blog", path: "/blog" },
  { label: "Contact", path: "/contact" }
];

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [scrolled, setScrolled] = useState<boolean>(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 24);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-[#0F172A]/90 backdrop-blur shadow-lg" : "bg-[#E6E9ED]"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 md:h-20">
          <NavLink
            to="/"
            className="flex items-center space-x-2 text-[#2753D9] font-semibold tracking-wide uppercase"
            aria-label="Barrel Blueprint home"
          >
            <div className="w-10 h-10 flex items-center justify-center rounded-full bg-[#2753D9]/10 text-[#2753D9]">
              BB
            </div>
            <span className="font-satoshi text-lg md:text-xl text-[#0F172A]">
              Barrel Blueprint
            </span>
          </NavLink>
          <nav className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `relative font-inter tracking-tight text-sm uppercase transition-colors ${
                    isActive
                      ? "text-[#2753D9]"
                      : scrolled
                      ? "text-slate-200"
                      : "text-[#1E2535]"
                  } hover:text-[#2753D9]`
                }
              >
                {({ isActive }) => (
                  <>
                    {item.label}
                    {isActive && (
                      <motion.span
                        layoutId="activeNav"
                        className="absolute -bottom-2 left-0 right-0 h-0.5 bg-[#2753D9]"
                      />
                    )}
                  </>
                )}
              </NavLink>
            ))}
            <NavLink
              to="/systems"
              className="inline-flex items-center rounded-full border border-[#2753D9] px-4 py-2 text-sm font-medium uppercase text-[#2753D9] transition hover:bg-[#2753D9] hover:text-white"
            >
              Explore Systems
            </NavLink>
          </nav>
          <button
            type="button"
            onClick={() => setIsOpen((prev) => !prev)}
            className="lg:hidden inline-flex items-center justify-center rounded-md p-2 text-[#0F172A]"
            aria-label="Toggle navigation menu"
          >
            <span className="sr-only">Open main menu</span>
            <div className="space-y-1">
              <span
                className={`block h-0.5 w-6 bg-current transform transition ${
                  isOpen ? "translate-y-1.5 rotate-45" : ""
                }`}
              />
              <span
                className={`block h-0.5 w-6 bg-current transition ${
                  isOpen ? "opacity-0" : ""
                }`}
              />
              <span
                className={`block h-0.5 w-6 bg-current transform transition ${
                  isOpen ? "-translate-y-1.5 -rotate-45" : ""
                }`}
              />
            </div>
          </button>
        </div>
      </div>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            className="lg:hidden bg-[#0F172A] text-slate-100 shadow-lg"
          >
            <div className="px-4 pb-6 space-y-4">
              {navItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    `block rounded-md px-4 py-3 text-sm uppercase tracking-wide transition ${
                      isActive ? "bg-[#2753D9] text-white" : "hover:bg-[#1E2535]"
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              ))}
              <NavLink
                to="/systems"
                className="block rounded-md px-4 py-3 text-sm uppercase tracking-wide bg-[#2753D9] text-white text-center"
              >
                Explore Systems
              </NavLink>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;