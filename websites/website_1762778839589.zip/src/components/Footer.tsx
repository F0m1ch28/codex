import React from "react";
import { NavLink } from "react-router-dom";

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0F172A] text-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
        <div>
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-10 h-10 flex items-center justify-center rounded-full bg-[#2753D9]/30 text-[#2753D9]">
              BB
            </div>
            <span className="font-satoshi text-lg tracking-wide">
              Barrel Blueprint
            </span>
          </div>
          <p className="text-sm leading-relaxed text-slate-300">
            Barrel Blueprint observes Canadian industrial barrel systems with measured documentation and neutral commentary on pipelines, refinery nodes, and storage assemblies.
          </p>
        </div>
        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wide mb-4 text-[#E6E9ED]">
            Navigation
          </h3>
          <ul className="space-y-2 text-sm">
            <li>
              <NavLink to="/" className="hover:text-[#2753D9] transition-colors">
                Home
              </NavLink>
            </li>
            <li>
              <NavLink to="/about" className="hover:text-[#2753D9] transition-colors">
                About
              </NavLink>
            </li>
            <li>
              <NavLink to="/systems" className="hover:text-[#2753D9] transition-colors">
                Systems
              </NavLink>
            </li>
            <li>
              <NavLink to="/blog" className="hover:text-[#2753D9] transition-colors">
                Blog
              </NavLink>
            </li>
            <li>
              <NavLink to="/contact" className="hover:text-[#2753D9] transition-colors">
                Contact
              </NavLink>
            </li>
          </ul>
        </div>
        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wide mb-4 text-[#E6E9ED]">
            Contact
          </h3>
          <ul className="text-sm space-y-3 text-slate-300">
            <li>
              707 8 Ave SW<br />
              Calgary, AB T2P 1H3<br />
              Canada
            </li>
            <li>
              <a href="tel:+15875557314" className="hover:text-[#2753D9] transition-colors">
                +1 (587) 555-7314
              </a>
            </li>
            <li>
              <a
                href="mailto:info@barrelblueprint.com"
                className="hover:text-[#2753D9] transition-colors"
              >
                info@barrelblueprint.com
              </a>
            </li>
          </ul>
        </div>
        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wide mb-4 text-[#E6E9ED]">
            Legal
          </h3>
          <ul className="space-y-2 text-sm">
            <li>
              <NavLink to="/terms" className="hover:text-[#2753D9] transition-colors">
                Terms of Use
              </NavLink>
            </li>
            <li>
              <NavLink to="/privacy" className="hover:text-[#2753D9] transition-colors">
                Privacy Policy
              </NavLink>
            </li>
            <li>
              <NavLink to="/cookie-policy" className="hover:text-[#2753D9] transition-colors">
                Cookie Policy
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 text-sm text-center text-slate-400">
          © {new Date().getFullYear()} Barrel Blueprint. Built in Calgary with disciplined observation.
        </div>
      </div>
    </footer>
  );
};

export default Footer;