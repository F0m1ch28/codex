import React, { useEffect, useState } from "react";

const STORAGE_KEY = "bb-cookie-consent";

const CookieBanner: React.FC = () => {
  const [visible, setVisible] = useState<boolean>(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = window.setTimeout(() => setVisible(true), 800);
      return () => window.clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem(STORAGE_KEY, "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 lg:left-auto lg:right-8 lg:w-96 z-50">
      <div className="rounded-2xl bg-[#1E2535] text-slate-200 shadow-2xl p-6 space-y-4 border border-[#2753D9]/30">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-[#E6E9ED]">
          Cookie Notice
        </h2>
        <p className="text-sm leading-relaxed">
          Barrel Blueprint uses minimal cookies to monitor functional performance of this site. No advertising identifiers are stored. Review the full cookie policy for details.
        </p>
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            type="button"
            onClick={handleAccept}
            className="flex-1 rounded-full bg-[#2753D9] px-4 py-2 text-sm font-semibold uppercase tracking-wide text-white transition hover:bg-[#1f46b6]"
          >
            Accept
          </button>
          <button
            type="button"
            onClick={handleDecline}
            className="flex-1 rounded-full border border-slate-500 px-4 py-2 text-sm font-semibold uppercase tracking-wide text-slate-200 transition hover:border-slate-300"
          >
            Decline
          </button>
        </div>
        <a
          href="/cookie-policy"
          className="text-xs uppercase tracking-wide text-[#8aa2ff] hover:text-[#c6d1ff]"
        >
          View cookie policy
        </a>
      </div>
    </div>
  );
};

export default CookieBanner;