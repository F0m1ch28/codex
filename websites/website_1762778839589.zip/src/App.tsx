import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Systems from "./pages/Services";
import Blog from "./pages/Blog";
import PipelineRevisionShapes from "./pages/blog/PipelineRevisionShapes";
import RefineryNodeLogic from "./pages/blog/RefineryNodeLogic";
import StorageFieldLayout from "./pages/blog/StorageFieldLayout";
import Contact from "./pages/Contact";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import CookiePolicy from "./pages/CookiePolicy";

const App: React.FC = () => {
  return (
    <>
      <Helmet>
        <html lang="en-CA" />
        <link rel="canonical" href="https://www.barrelblueprint.com/" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Organization",
            name: "Barrel Blueprint",
            url: "https://www.barrelblueprint.com/",
            logo: "https://www.barrelblueprint.com/favicon-32.png",
            email: "info@barrelblueprint.com",
            telephone: "+1-587-555-7314",
            address: {
              "@type": "PostalAddress",
              streetAddress: "707 8 Ave SW",
              addressLocality: "Calgary",
              addressRegion: "AB",
              postalCode: "T2P 1H3",
              addressCountry: "CA"
            },
            sameAs: []
          })}
        </script>
      </Helmet>
      <ScrollToTop />
      <div className="min-h-screen flex flex-col bg-[#E6E9ED] text-[#1E2535]">
        <Header />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/systems" element={<Systems />} />
            <Route path="/services" element={<Services />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/pipeline-revision-shapes" element={<PipelineRevisionShapes />} />
            <Route path="/blog/refinery-node-logic" element={<RefineryNodeLogic />} />
            <Route path="/blog/storage-field-layout" element={<StorageFieldLayout />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookie-policy" element={<CookiePolicy />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
        <Footer />
      </div>
      <CookieBanner />
    </>
  );
};

export default App;