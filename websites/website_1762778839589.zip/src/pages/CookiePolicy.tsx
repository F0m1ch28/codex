import React from "react";
import { Helmet } from "react-helmet-async";

const CookiePolicy: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | Barrel Blueprint</title>
        <meta
          name="description"
          content="Understand how Barrel Blueprint uses cookies to maintain core functionality and gather basic analytics."
        />
        <link rel="canonical" href="https://www.barrelblueprint.com/cookie-policy" />
      </Helmet>
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20 space-y-10">
        <header>
          <h1 className="font-satoshi text-4xl text-[#0F172A]">Cookie Policy</h1>
          <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
            Effective date: March 1, 2024
          </p>
        </header>
        <article className="space-y-8 text-sm text-[#1E2535]/80 leading-relaxed">
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">1. Introduction</h2>
            <p>
              This Cookie Policy explains how Barrel Blueprint uses cookies and similar technologies when you visit our website.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">2. What Are Cookies?</h2>
            <p>
              Cookies are small text files stored on your device by your browser. They help websites remember user preferences, maintain sessions, and gather aggregate analytics.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">3. Types of Cookies We Use</h2>
            <p>
              Barrel Blueprint uses essential cookies to deliver website functionality, such as maintaining navigation states and storing cookie consent decisions. We also use basic analytics cookies to monitor traffic patterns in aggregate form without identifying individual visitors.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">4. Managing Cookies</h2>
            <p>
              You may control cookies through your browser settings, including blocking or deleting them. Doing so may affect certain features of the site. The cookie banner allows you to accept or decline non-essential cookies directly.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">5. Third-Party Cookies</h2>
            <p>
              We do not serve advertising or profiling cookies. However, embedded content from external platforms may set their own cookies. We encourage you to review the policies of any linked services.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">6. Updates</h2>
            <p>
              This Cookie Policy may be updated as our practices evolve. The effective date will indicate the latest version. Continued use of the site signifies acceptance of any updates.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">7. Contact</h2>
            <p>
              For questions about this Cookie Policy, contact info@barrelblueprint.com.
            </p>
          </section>
        </article>
      </section>
    </>
  );
};

export default CookiePolicy;