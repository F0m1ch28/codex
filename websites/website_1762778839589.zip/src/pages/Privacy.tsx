import React from "react";
import { Helmet } from "react-helmet-async";

const Privacy: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | Barrel Blueprint</title>
        <meta
          name="description"
          content="Review how Barrel Blueprint collects, uses, and safeguards personal information within its informational platform."
        />
        <link rel="canonical" href="https://www.barrelblueprint.com/privacy" />
      </Helmet>
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20 space-y-10">
        <header>
          <h1 className="font-satoshi text-4xl text-[#0F172A]">Privacy Policy</h1>
          <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
            Effective date: March 1, 2024
          </p>
        </header>
        <article className="space-y-8 text-sm text-[#1E2535]/80 leading-relaxed">
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">1. Scope</h2>
            <p>
              This Privacy Policy describes how Barrel Blueprint collects, uses, and protects personal information submitted through this website.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">2. Information We Collect</h2>
            <p>
              We collect information that you voluntarily provide, such as your name, email address, and message content when using contact forms or subscribing to updates. We also gather basic usage analytics through essential cookies to understand site performance.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">3. Use of Information</h2>
            <p>
              Information is used to respond to inquiries, manage mailing lists, improve content, and ensure site security. Personal data is not sold or shared with third parties except as required by law or to operate core site services.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">4. Cookies</h2>
            <p>
              We employ minimal cookies to maintain session functionality and assess aggregate site performance. The Cookie Policy provides additional detail on the categories and controls available to you.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">5. Data Security</h2>
            <p>
              Reasonable technical and organizational measures are in place to protect personal information. While no system is entirely secure, Barrel Blueprint monitors its infrastructure for unauthorized access or misuse.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">6. Data Retention</h2>
            <p>
              We retain personal information only as long as necessary to fulfill the purposes outlined in this policy. Contact requests may be archived for reference, while newsletter subscription data remains until you unsubscribe.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">7. Access and Correction</h2>
            <p>
              You may request access to your personal information, ask for corrections, or withdraw consent by contacting info@barrelblueprint.com. We will respond within a reasonable timeframe, subject to applicable laws.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">8. Third-Party Services</h2>
            <p>
              Certain third-party services, such as email distribution tools or analytics providers, may process limited data on our behalf. These partners are required to safeguard the information and use it only for agreed purposes.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">9. Children</h2>
            <p>
              Barrel Blueprint does not knowingly collect personal information from individuals under the age of eighteen. If such information is inadvertently gathered, it will be deleted upon discovery.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">10. Changes</h2>
            <p>
              We may update this Privacy Policy to reflect new practices or regulatory requirements. The effective date will indicate the latest version. Continued use of the site signifies acceptance of the updated policy.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">11. Contact</h2>
            <p>
              For privacy-related questions or requests, email info@barrelblueprint.com or write to Barrel Blueprint, 707 8 Ave SW, Calgary, AB T2P 1H3, Canada.
            </p>
          </section>
        </article>
      </section>
    </>
  );
};

export default Privacy;