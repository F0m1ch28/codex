import React, { useEffect, useMemo, useState } from "react";
import { NavLink } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

interface StatItem {
  label: string;
  value: number;
  suffix?: string;
}

interface SignalBlock {
  title: string;
  description: string;
}

interface ModuleHighlight {
  title: string;
  text: string;
}

interface NoteItem {
  title: string;
  detail: string;
}

interface ReadingItem {
  title: string;
  summary: string;
  link: string;
}

interface ProcessStep {
  title: string;
  detail: string;
}

interface Testimonial {
  quote: string;
  name: string;
  role: string;
}

interface TeamMember {
  name: string;
  role: string;
  focus: string;
  image: string;
}

interface ProjectItem {
  id: number;
  title: string;
  category: "Pipelines" | "Refineries" | "Storage";
  description: string;
  image: string;
}

interface FAQItem {
  question: string;
  answer: string;
}

const stats: StatItem[] = [
  { label: "Tracked pipeline alignments", value: 124 },
  { label: "Refinery node schematics mapped", value: 38 },
  { label: "Storage grid scenarios logged", value: 96 }
];

const signalBlocks: SignalBlock[] = [
  {
    title: "Flow Signal Integrity",
    description:
      "We document the telemetry cadence of transmission lines to show how pressure signals cascade through branching corridors."
  },
  {
    title: "Node Load Balancing",
    description:
      "Each refinery unit is observed for load relay behavior, heat integration timing, and the ripple effect across allied trains."
  },
  {
    title: "Containment Staging",
    description:
      "Storage fields are indexed by berm geometry, venting rhythm, and isolator sequences that govern safe staging."
  }
];

const modules: ModuleHighlight[] = [
  {
    title: "Grid-Ready Barrel Mapping",
    text:
      "Blueprint modules dissect barrel throughput grids, highlighting how diameter transitions align with anchor stations."
  },
  {
    title: "Valve Logic Views",
    text:
      "Interactive callouts translate control-room valve logic into simple diagrams for quick orientation across sections."
  },
  {
    title: "Interchange Checklists",
    text:
      "Ready-to-reference checklists clarify interchange points where refined products switch to terminal routing."
  },
  {
    title: "Containment Field Notes",
    text:
      "Visual field notes catalogue containment berm profiles, roof structures, and gauge access routes."
  }
];

const notes: NoteItem[] = [
  {
    title: "Refinery cadence",
    detail:
      "Aromatics and diesel trains maintain offset fuel gas headers with intervalled purging to balance residual heat."
  },
  {
    title: "Storage drift control",
    detail:
      "Tank clusters adopt concentric sample ladders that keep drift monitoring near shell midpoints during seasonal swings."
  },
  {
    title: "Blending corridors",
    detail:
      "Inline blending corridors track sample slipstreams that pass through small-bore loops before rejoining the main stream."
  }
];

const readings: ReadingItem[] = [
  {
    title: "Pipeline Revision Shapes",
    summary:
      "A close read of revision corridors and the geometry of displacement spreads along prairie alignments.",
    link: "/blog/pipeline-revision-shapes"
  },
  {
    title: "Refinery Node Logic",
    summary:
      "Inside the logic relays that guide refinery nodes when pressure bands close in on load thresholds.",
    link: "/blog/refinery-node-logic"
  },
  {
    title: "Storage Field Layout",
    summary:
      "Angular storage grids and the neutral spacing patterns that allow operations to stay accessible year-round.",
    link: "/blog/storage-field-layout"
  }
];

const processSteps: ProcessStep[] = [
  {
    title: "Scope assembly",
    detail:
      "We map existing industrial barrel infrastructure, collecting cross-sectional data, control schemes, and regulatory filings."
  },
  {
    title: "Structure translation",
    detail:
      "Complex schematics are translated into modular layers, identifying connections, instrumentation nodes, and safety chords."
  },
  {
    title: "Field validation",
    detail:
      "Observations are verified through public registries, satellite overlays, and community input, ensuring accurate context."
  },
  {
    title: "Ongoing monitoring",
    detail:
      "Changes are appended to living dossiers so readers can trace updates across pipelines, refining districts, and storage fields."
  }
];

const testimonials: Testimonial[] = [
  {
    quote:
      "Barrel Blueprint pieces make it simple to explain corridor transitions without overstatement or gaps in the supporting context.",
    name: "L. Raymond",
    role: "Pipeline Operations Analyst"
  },
  {
    quote:
      "The modular refinery diagrams condense hundreds of pages into a disciplined summary that my team references in planning sessions.",
    name: "S. Kulkarni",
    role: "Process Engineer"
  },
  {
    quote:
      "Storage layout briefings are factual, steady, and grounded in spatial awareness that helps coordinate multi-site teams.",
    name: "N. Tremblay",
    role: "Terminal Coordinator"
  }
];

const team: TeamMember[] = [
  {
    name: "Avery Clarke",
    role: "Editor-in-Chief",
    focus: "Long-form pipeline and corridor documentation.",
    image: "https://picsum.photos/400/400?random=31"
  },
  {
    name: "Mira Thompson",
    role: "Refinery Systems Analyst",
    focus: "Heat integration and control sequence reporting.",
    image: "https://picsum.photos/400/400?random=32"
  },
  {
    name: "Jonas Patel",
    role: "Storage Field Cartographer",
    focus: "Spatial mapping of containment fields and access routes.",
    image: "https://picsum.photos/400/400?random=33"
  },
  {
    name: "Louise Chen",
    role: "Data Visualization Lead",
    focus: "Diagramming stable, low-contrast schematics.",
    image: "https://picsum.photos/400/400?random=34"
  }
];

const projectItems: ProjectItem[] = [
  {
    id: 1,
    title: "Prairie Line Junction Atlas",
    category: "Pipelines",
    description:
      "A layered atlas tracing diameter shifts and valve clusters across western prairie junctions.",
    image: "https://picsum.photos/1200/800?random=51"
  },
  {
    id: 2,
    title: "Thermal Block Cross-Sections",
    category: "Refineries",
    description:
      "Cross-sectional views depicting process blocks, flares, and heat recovery loops in modular format.",
    image: "https://picsum.photos/1200/800?random=52"
  },
  {
    id: 3,
    title: "Containment Grid Registry",
    category: "Storage",
    description:
      "An indexed registry of storage grids cataloguing berm shapes, roof types, and access spines.",
    image: "https://picsum.photos/1200/800?random=53"
  },
  {
    id: 4,
    title: "Coastal Lift Corridor Study",
    category: "Pipelines",
    description:
      "Analysis of steep grade lift stations with emphasis on pump sequencing and pressure recovery.",
    image: "https://picsum.photos/1200/800?random=54"
  },
  {
    id: 5,
    title: "Northern Distillation Loop",
    category: "Refineries",
    description:
      "Documentation of distillation loop routing, maintenance clearances, and vapour recovery alignments.",
    image: "https://picsum.photos/1200/800?random=55"
  },
  {
    id: 6,
    title: "Prairie Storage Array Patterns",
    category: "Storage",
    description:
      "Diagrammatic study of tank spacing patterns paired with instrumentation access lanes in prairie climates.",
    image: "https://picsum.photos/1200/800?random=56"
  }
];

const faqItems: FAQItem[] = [
  {
    question: "How does Barrel Blueprint verify infrastructure data?",
    answer:
      "Our team references public regulatory filings, municipal planning documents, and field observations. Each diagram is cross-checked with satellite imagery and reputable industry reports to maintain stable, neutral accuracy."
  },
  {
    question: "What geographical areas does the platform cover?",
    answer:
      "We focus on Canadian infrastructure with close attention to prairie, coastal, and Arctic-adjacent systems. Cross-border connections are noted when relevant to flow balance or storage availability."
  },
  {
    question: "Can readers request additional schematics?",
    answer:
      "Requests can be submitted through the contact form. The editorial team considers alignment with existing dossiers, available public data, and the ability to maintain measured coverage."
  }
];

const Home: React.FC = () => {
  const [counters, setCounters] = useState<number[]>(stats.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState<number>(0);
  const [projectFilter, setProjectFilter] = useState<ProjectItem["category"] | "All">("All");
  const [email, setEmail] = useState<string>("");
  const [newsletterMessage, setNewsletterMessage] = useState<string>("");
  const [faqOpen, setFaqOpen] = useState<number | null>(0);

  const filteredProjects = useMemo(() => {
    if (projectFilter === "All") return projectItems;
    return projectItems.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  useEffect(() => {
    const intervals = stats.map((stat, index) => {
      const duration = 1600;
      const stepTime = Math.max(Math.floor(duration / stat.value), 20);
      return window.setInterval(() => {
        setCounters((prev) => {
          const next = [...prev];
          if (next[index] < stat.value) {
            next[index] += 1;
          }
          return next;
        });
      }, stepTime);
    });

    const timeout = window.setTimeout(() => {
      intervals.forEach((interval) => window.clearInterval(interval));
      setCounters(stats.map((stat) => stat.value));
    }, 2000);

    return () => {
      intervals.forEach((interval) => window.clearInterval(interval));
      window.clearTimeout(timeout);
    };
  }, []);

  useEffect(() => {
    const rotation = window.setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => window.clearInterval(rotation);
  }, []);

  const handleNewsletterSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setNewsletterMessage("Please enter a valid email address.");
      return;
    }
    setNewsletterMessage("Thank you. We will notify you about new dossiers.");
    setEmail("");
  };

  return (
    <>
      <Helmet>
        <title>Barrel Blueprint | Understanding Industrial Barrel Systems</title>
        <meta
          name="description"
          content="Measured coverage of Canadian pipelines, refinery nodes, and storage fields. Explore modular diagrams, field notes, and structured briefings."
        />
        <link rel="canonical" href="https://www.barrelblueprint.com/" />
      </Helmet>
      <section className="relative overflow-hidden bg-[#0F172A] text-slate-100">
        <div className="absolute inset-0">
          <img
            src="https://picsum.photos/1600/900?random=61"
            alt="Industrial pipeline silhouettes at dusk"
            className="h-full w-full object-cover opacity-30"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-[#0F172A]/90 via-[#0F172A]/85 to-[#2753D9]/30" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 grid gap-10 lg:grid-cols-2 items-center">
          <div>
            <motion.span
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center rounded-full bg-[#2753D9]/20 px-4 py-1 text-xs uppercase tracking-[0.3em] text-[#c7d6ff]"
            >
              Barrel Blueprint | Calgary, Canada
            </motion.span>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="mt-6 font-satoshi text-4xl sm:text-5xl lg:text-6xl font-semibold leading-tight text-slate-100"
            >
              Understanding Industrial Barrel Systems
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="mt-6 text-lg text-slate-200 leading-relaxed"
            >
              Barrel Blueprint examines how Canadian pipelines, refinery nodes, and storage fields align within the broader barrel flow. Each brief delivers steady reporting, modular diagrams, and accessible language.
            </motion.p>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="mt-4 text-lg text-slate-200 leading-relaxed"
            >
              Explore signal behavior, containment staging, and node control patterns through structured data sets and measured commentary designed for planners, analysts, and community observers.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="mt-8 flex flex-col sm:flex-row gap-4"
            >
              <NavLink
                to="/systems"
                className="inline-flex items-center justify-center rounded-full bg-[#2753D9] px-6 py-3 text-sm uppercase tracking-wide font-semibold text-white transition hover:bg-[#1f46b6]"
              >
                Explore system dossiers
              </NavLink>
              <a
                href="#newsletter"
                className="inline-flex items-center justify-center rounded-full border border-slate-400 px-6 py-3 text-sm uppercase tracking-wide font-semibold text-slate-100 transition hover:border-slate-200"
              >
                Join the briefing list
              </a>
            </motion.div>
          </div>
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.9, delay: 0.2 }}
            className="lg:justify-self-end w-full max-w-lg"
          >
            <div className="rounded-3xl bg-[#1E2535]/80 backdrop-blur p-6 sm:p-8 border border-[#2753D9]/40 shadow-2xl">
              <h2 className="font-satoshi text-2xl text-slate-100">
                Signal Blocks At A Glance
              </h2>
              <p className="mt-3 text-sm text-slate-300 leading-relaxed">
                Three signal structures underpin our latest reporting cycle.
              </p>
              <div className="mt-6 space-y-5">
                {signalBlocks.map((block) => (
                  <div key={block.title} className="rounded-2xl border border-[#2753D9]/30 bg-[#0F172A]/40 p-5">
                    <h3 className="text-lg font-semibold text-[#c7d6ff]">
                      {block.title}
                    </h3>
                    <p className="mt-2 text-sm text-slate-300 leading-relaxed">
                      {block.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
        <div className="grid gap-6 sm:grid-cols-3">
          {stats.map((stat, index) => (
            <div
              key={stat.label}
              className="rounded-3xl border border-[#0F172A]/10 bg-white p-6 shadow-sm hover:shadow-md transition"
            >
              <p className="text-sm uppercase tracking-wide text-[#2753D9]">
                {stat.label}
              </p>
              <p className="mt-4 font-satoshi text-4xl text-[#0F172A]">
                {counters[index]}
                {stat.suffix}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
          <div className="sm:flex sm:items-end sm:justify-between">
            <div>
              <h2 className="font-satoshi text-3xl md:text-4xl text-[#0F172A]">
                Modular Layout Highlights
              </h2>
              <p className="mt-4 text-base text-[#1E2535]/80 max-w-xl">
                Each module distills larger system diagrams into layered views, allowing readers to orient themselves quickly without oversimplifying critical structural information.
              </p>
            </div>
            <NavLink
              to="/systems"
              className="inline-flex items-center rounded-full border border-[#2753D9] px-5 py-2 text-sm uppercase font-semibold tracking-wide text-[#2753D9] mt-6 sm:mt-0 hover:bg-[#2753D9] hover:text-white transition"
            >
              View all clusters
            </NavLink>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-2">
            {modules.map((module) => (
              <div
                key={module.title}
                className="group relative rounded-3xl border border-[#0F172A]/10 bg-[#F7F9FB] p-8 transition hover:-translate-y-1 hover:border-[#2753D9]/50 hover:shadow-lg"
              >
                <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-[#2753D9]/0 via-[#2753D9]/5 to-[#2753D9]/0 opacity-0 group-hover:opacity-100 transition" />
                <div className="relative">
                  <h3 className="font-satoshi text-2xl text-[#0F172A]">
                    {module.title}
                  </h3>
                  <p className="mt-4 text-sm leading-relaxed text-[#1E2535]/80">
                    {module.text}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
        <div className="rounded-3xl border border-[#0F172A]/10 bg-white p-10 md:p-14 shadow-md">
          <h2 className="font-satoshi text-3xl text-[#0F172A]">
            Refinery and Storage Observations
          </h2>
          <p className="mt-4 text-base text-[#1E2535]/80 max-w-2xl">
            Notes collected from the current cycle of refinery and storage field monitoring provide localized insight into steady-state operations.
          </p>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {notes.map((note) => (
              <div key={note.title} className="rounded-2xl bg-[#E6E9ED] p-6">
                <h3 className="text-lg font-semibold text-[#2753D9]">
                  {note.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-[#1E2535]/80">
                  {note.detail}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[#0F172A] text-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
          <h2 className="font-satoshi text-3xl md:text-4xl text-slate-100">
            Reading Dossiers
          </h2>
          <p className="mt-4 text-base text-slate-300 max-w-2xl">
            These three recommendations provide a balanced overview of pipeline revisions, node logic sequencing, and storage field geometry. Each dossier is mapped with neutral, low-contrast diagrams.
          </p>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {readings.map((reading) => (
              <NavLink
                key={reading.title}
                to={reading.link}
                className="group rounded-3xl border border-slate-700 bg-[#1E2535] p-6 transition hover:border-[#2753D9]"
              >
                <h3 className="font-satoshi text-xl text-[#c7d6ff] group-hover:text-white">
                  {reading.title}
                </h3>
                <p className="mt-3 text-sm text-slate-300 leading-relaxed">
                  {reading.summary}
                </p>
                <span className="mt-4 inline-flex items-center text-sm uppercase tracking-wide text-[#8aa2ff] group-hover:text-[#c7d6ff]">
                  Continue reading →
                </span>
              </NavLink>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
        <div className="grid gap-12 lg:grid-cols-2">
          <div>
            <h2 className="font-satoshi text-3xl text-[#0F172A]">
              Process Overview
            </h2>
            <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
              A clear workflow maintains consistent reporting quality. Each phase is documented to preserve traceability and transparency for readers.
            </p>
            <div className="mt-8 space-y-6">
              {processSteps.map((step, index) => (
                <div key={step.title} className="relative pl-10">
                  <div className="absolute left-0 top-1 flex items-center justify-center rounded-full bg-[#2753D9] w-8 h-8 text-white text-sm font-semibold">
                    {index + 1}
                  </div>
                  <h3 className="font-semibold text-lg text-[#0F172A]">
                    {step.title}
                  </h3>
                  <p className="mt-2 text-sm text-[#1E2535]/80 leading-relaxed">
                    {step.detail}
                  </p>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-3xl border border-[#0F172A]/10 bg-white p-10 shadow-sm">
            <h2 className="font-satoshi text-3xl text-[#0F172A]">
              Testimonials
            </h2>
            <div className="mt-6">
              {testimonials.map((testimonial, index) => (
                <div
                  key={testimonial.name}
                  className={`transition-opacity ${
                    activeTestimonial === index ? "opacity-100" : "opacity-0"
                  }`}
                >
                  {activeTestimonial === index && (
                    <blockquote className="space-y-4">
                      <p className="text-lg text-[#1E2535]/90 leading-relaxed">
                        “{testimonial.quote}”
                      </p>
                      <footer className="text-sm uppercase tracking-wide text-[#2753D9]">
                        {testimonial.name} · {testimonial.role}
                      </footer>
                    </blockquote>
                  )}
                </div>
              ))}
            </div>
            <div className="mt-6 flex space-x-2">
              {testimonials.map((_testimonial, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => setActiveTestimonial(index)}
                  className={`h-2 w-8 rounded-full transition ${
                    activeTestimonial === index ? "bg-[#2753D9]" : "bg-[#D1D5DB]"
                  }`}
                  aria-label={`View testimonial ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
          <div className="sm:flex sm:items-end sm:justify-between">
            <div>
              <h2 className="font-satoshi text-3xl text-[#0F172A]">
                Team at Barrel Blueprint
              </h2>
              <p className="mt-4 text-base text-[#1E2535]/80 max-w-xl">
                A multidisciplinary team documents the barrel system lifecycle, combining field experience, cartography, and editorial oversight.
              </p>
            </div>
            <NavLink
              to="/about"
              className="inline-flex items-center rounded-full border border-[#2753D9] px-5 py-2 text-sm uppercase tracking-wide text-[#2753D9] mt-6 sm:mt-0 hover:bg-[#2753D9] hover:text-white transition"
            >
              Learn more about us
            </NavLink>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            {team.map((member) => (
              <div
                key={member.name}
                className="group relative overflow-hidden rounded-3xl border border-[#0F172A]/10 bg-[#F7F9FB] shadow-sm"
              >
                <img
                  src={member.image}
                  alt={`${member.name} portrait`}
                  className="h-64 w-full object-cover transition duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="p-6 space-y-2">
                  <h3 className="font-satoshi text-xl text-[#0F172A]">
                    {member.name}
                  </h3>
                  <p className="text-sm uppercase tracking-wide text-[#2753D9]">
                    {member.role}
                  </p>
                  <p className="text-sm text-[#1E2535]/80 leading-relaxed">
                    {member.focus}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
        <div className="sm:flex sm:items-center sm:justify-between">
          <div>
            <h2 className="font-satoshi text-3xl text-[#0F172A]">
              Project Dossiers
            </h2>
            <p className="mt-4 text-base text-[#1E2535]/80 max-w-2xl">
              Filtered project dossiers show how pipelines, refineries, and storage systems interlink across Canada. Each entry contains measured analysis without dramatization.
            </p>
          </div>
          <div className="mt-6 sm:mt-0 flex flex-wrap gap-2">
            {(["All", "Pipelines", "Refineries", "Storage"] as const).map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setProjectFilter(category)}
                className={`rounded-full border px-4 py-2 text-sm uppercase tracking-wide transition ${
                  projectFilter === category
                    ? "border-[#2753D9] bg-[#2753D9] text-white"
                    : "border-[#0F172A]/10 bg-white text-[#0F172A]"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="overflow-hidden rounded-3xl border border-[#0F172A]/10 bg-white shadow-sm hover:shadow-lg transition"
            >
              <img
                src={project.image}
                alt={`${project.title} visual`}
                className="h-64 w-full object-cover"
                loading="lazy"
              />
              <div className="p-6 space-y-3">
                <span className="inline-flex items-center rounded-full bg-[#2753D9]/10 px-3 py-1 text-xs uppercase tracking-wide text-[#2753D9]">
                  {project.category}
                </span>
                <h3 className="font-satoshi text-2xl text-[#0F172A]">
                  {project.title}
                </h3>
                <p className="text-sm text-[#1E2535]/80 leading-relaxed">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
          <h2 className="font-satoshi text-3xl text-[#0F172A]">
            Frequently Asked Questions
          </h2>
          <div className="mt-8 space-y-4">
            {faqItems.map((item, index) => (
              <div key={item.question} className="rounded-3xl border border-[#0F172A]/10 bg-[#F7F9FB]">
                <button
                  type="button"
                  className="w-full flex justify-between items-center px-6 py-5 text-left"
                  onClick={() => setFaqOpen((prev) => (prev === index ? null : index))}
                >
                  <span className="font-semibold text-lg text-[#0F172A]">
                    {item.question}
                  </span>
                  <span className="text-2xl text-[#2753D9]">
                    {faqOpen === index ? "−" : "+"}
                  </span>
                </button>
                {faqOpen === index && (
                  <div className="px-6 pb-6">
                    <p className="text-sm text-[#1E2535]/80 leading-relaxed">
                      {item.answer}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
        <div className="rounded-3xl border border-[#0F172A]/10 bg-white p-10 md:p-14 shadow-md">
          <div className="md:flex md:items-start md:justify-between">
            <div className="md:w-2/3">
              <h2 className="font-satoshi text-3xl text-[#0F172A]">
                Latest from the Blog
              </h2>
              <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
                Brief and structured entries summarizing recent observations. Dive deeper into our blog for the complete articles.
              </p>
            </div>
            <NavLink
              to="/blog"
              className="inline-flex items-center rounded-full border border-[#2753D9] px-5 py-2 text-sm uppercase tracking-wide text-[#2753D9] mt-6 md:mt-0 hover:bg-[#2753D9] hover:text-white transition"
            >
              View all posts
            </NavLink>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {readings.map((reading) => (
              <div key={reading.title} className="rounded-3xl border border-[#0F172A]/10 bg-[#F7F9FB] p-6">
                <h3 className="font-satoshi text-xl text-[#0F172A]">
                  {reading.title}
                </h3>
                <p className="mt-3 text-sm text-[#1E2535]/80 leading-relaxed">
                  {reading.summary}
                </p>
                <NavLink
                  to={reading.link}
                  className="mt-4 inline-flex items-center text-sm uppercase tracking-wide text-[#2753D9]"
                >
                  Read article →
                </NavLink>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section
        id="newsletter"
        className="relative overflow-hidden bg-[#0F172A] text-slate-100"
      >
        <div className="absolute inset-0">
          <img
            src="https://picsum.photos/1200/800?random=62"
            alt="Refinery structures silhouette"
            className="h-full w-full object-cover opacity-30"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0F172A]/95 via-[#0F172A]/80 to-[#2753D9]/40" />
        </div>
        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
          <div className="rounded-3xl border border-[#2753D9]/40 bg-[#0F172A]/70 p-10 md:p-14 backdrop-blur">
            <h2 className="font-satoshi text-3xl md:text-4xl text-slate-100">
              Join the Barrel Briefing
            </h2>
            <p className="mt-4 text-base text-slate-300 leading-relaxed max-w-2xl">
              Receive concise notifications when new dossiers are published. The briefing is low-volume and focused on structural updates across the industrial barrel network.
            </p>
            <form
              onSubmit={handleNewsletterSubmit}
              className="mt-8 flex flex-col sm:flex-row gap-4"
            >
              <label htmlFor="newsletter-email" className="sr-only">
                Email address
              </label>
              <input
                id="newsletter-email"
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                required
                placeholder="yourname@example.com"
                className="flex-1 rounded-full border border-slate-400/40 bg-white/90 px-6 py-3 text-sm text-[#0F172A] placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#2753D9]"
              />
              <button
                type="submit"
                className="inline-flex items-center justify-center rounded-full bg-[#2753D9] px-8 py-3 text-sm uppercase tracking-wide font-semibold text-white transition hover:bg-[#1f46b6]"
              >
                Subscribe
              </button>
            </form>
            {newsletterMessage && (
              <p className="mt-4 text-sm text-slate-200">{newsletterMessage}</p>
            )}
          </div>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="rounded-3xl border border-[#0F172A]/10 bg-white p-10 md:p-12 shadow-sm">
          <h2 className="font-satoshi text-2xl text-[#0F172A]">
            Information Disclaimer
          </h2>
          <p className="mt-4 text-sm text-[#1E2535]/80 leading-relaxed">
            Barrel Blueprint provides information for educational and contextual purposes. Content is drawn from public data, field observation, and verifiable sources. It should not be interpreted as operational, legal, or financial guidance. Users remain responsible for confirming requirements with relevant authorities and experts before acting on any information presented here.
          </p>
        </div>
      </section>
    </>
  );
};

export default Home;