import React, { useState } from "react";
import { Helmet } from "react-helmet-async";

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [status, setStatus] = useState<string>("");

  const handleChange = (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (
      !formData.name.trim() ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email) ||
      !formData.message.trim()
    ) {
      setStatus("Please complete all required fields with valid information.");
      return;
    }
    setStatus("Thank you. Your message has been noted. Our team will review it soon.");
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <>
      <Helmet>
        <title>Contact Barrel Blueprint | Calgary Headquarters</title>
        <meta
          name="description"
          content="Reach Barrel Blueprint in Calgary for inquiries about pipeline, refinery, and storage field dossiers. Contact via the secure form or direct contact details."
        />
        <link rel="canonical" href="https://www.barrelblueprint.com/contact" />
      </Helmet>
      <section className="relative overflow-hidden bg-[#0F172A] text-slate-100">
        <div className="absolute inset-0">
          <img
            src="https://picsum.photos/1600/900?random=97"
            alt="Control room overview with industrial monitors"
            className="h-full w-full object-cover opacity-25"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-[#0F172A]/95 via-[#0F172A]/85 to-[#2753D9]/25" />
        </div>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 text-center">
          <h1 className="font-satoshi text-4xl md:text-5xl text-slate-100">
            Contact Barrel Blueprint
          </h1>
          <p className="mt-6 text-lg text-slate-200 leading-relaxed">
            We welcome information requests, clarifications, and suggestions for future dossiers.
          </p>
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20 space-y-10">
        <div className="rounded-3xl border border-[#0F172A]/10 bg-white p-8 md:p-10 shadow-sm">
          <h2 className="font-satoshi text-2xl text-[#0F172A]">
            Headquarters
          </h2>
          <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
            Barrel Blueprint operates from downtown Calgary, Alberta, with analysts covering field visits across Canada.
          </p>
          <div className="mt-6 grid gap-6 sm:grid-cols-2">
            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wide text-[#2753D9]">
                Address
              </h3>
              <p className="mt-2 text-sm text-[#1E2535]/80 leading-relaxed">
                707 8 Ave SW<br />
                Calgary, AB T2P 1H3<br />
                Canada
              </p>
            </div>
            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wide text-[#2753D9]">
                Contact
              </h3>
              <p className="mt-2 text-sm text-[#1E2535]/80 leading-relaxed">
                <a href="tel:+15875557314" className="hover:text-[#2753D9]">
                  +1 (587) 555-7314
                </a>
                <br />
                <a href="mailto:info@barrelblueprint.com" className="hover:text-[#2753D9]">
                  info@barrelblueprint.com
                </a>
              </p>
            </div>
          </div>
        </div>

        <div className="rounded-3xl border border-[#0F172A]/10 bg-white p-8 md:p-10 shadow-sm">
          <h2 className="font-satoshi text-2xl text-[#0F172A]">
            Send a Message
          </h2>
          <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
            Provide your details and a brief overview of your inquiry. We respond to most messages within three business days, prioritizing clarity and transparency.
          </p>
          <form onSubmit={handleSubmit} className="mt-6 space-y-6">
            <div>
              <label htmlFor="name" className="text-sm font-medium text-[#0F172A]">
                Name
              </label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                required
                className="mt-2 block w-full rounded-xl border border-[#0F172A]/10 bg-[#F7F9FB] px-4 py-3 text-sm focus:border-[#2753D9] focus:ring-[#2753D9]"
              />
            </div>
            <div>
              <label htmlFor="email" className="text-sm font-medium text-[#0F172A]">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="mt-2 block w-full rounded-xl border border-[#0F172A]/10 bg-[#F7F9FB] px-4 py-3 text-sm focus:border-[#2753D9] focus:ring-[#2753D9]"
              />
            </div>
            <div>
              <label htmlFor="message" className="text-sm font-medium text-[#0F172A]">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                rows={5}
                value={formData.message}
                onChange={handleChange}
                required
                className="mt-2 block w-full rounded-xl border border-[#0F172A]/10 bg-[#F7F9FB] px-4 py-3 text-sm focus:border-[#2753D9] focus:ring-[#2753D9]"
              />
            </div>
            <button
              type="submit"
              className="inline-flex items-center rounded-full bg-[#2753D9] px-6 py-3 text-sm uppercase tracking-wide font-semibold text-white hover:bg-[#1f46b6] transition"
            >
              Submit message
            </button>
            {status && (
              <p className="text-sm text-[#1E2535]/80 leading-relaxed">{status}</p>
            )}
          </form>
        </div>
      </section>
    </>
  );
};

export default Contact;