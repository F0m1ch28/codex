import React from "react";
import { Helmet } from "react-helmet-async";
import { NavLink } from "react-router-dom";

interface BlogPost {
  title: string;
  excerpt: string;
  date: string;
  link: string;
  image: string;
}

const posts: BlogPost[] = [
  {
    title: "Pipeline Revision Shapes",
    excerpt:
      "A detailed examination of pipeline revision corridors, displacement spreads, and the relationships between pump spacing and ground conditions.",
    date: "April 12, 2024",
    link: "/blog/pipeline-revision-shapes",
    image: "https://picsum.photos/800/600?random=81"
  },
  {
    title: "Refinery Node Logic",
    excerpt:
      "Inside refinery node transitions, telemetry loops, and the logic sequences that govern load balancing during seasonal adjustments.",
    date: "March 27, 2024",
    link: "/blog/refinery-node-logic",
    image: "https://picsum.photos/800/600?random=82"
  },
  {
    title: "Storage Field Layout",
    excerpt:
      "Mapping storage field geometry, containment berm profiles, and monitoring access using modular diagrams and neutral commentary.",
    date: "March 10, 2024",
    link: "/blog/storage-field-layout",
    image: "https://picsum.photos/800/600?random=83"
  }
];

const Blog: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Barrel Blueprint Blog | Structured Insights</title>
        <meta
          name="description"
          content="Read Barrel Blueprint blog entries covering pipeline updates, refinery node logic, and storage field layouts across Canada."
        />
        <link rel="canonical" href="https://www.barrelblueprint.com/blog" />
      </Helmet>
      <section className="relative overflow-hidden bg-[#0F172A] text-slate-100">
        <div className="absolute inset-0">
          <img
            src="https://picsum.photos/1600/900?random=84"
            alt="Industrial facility with modular overlays"
            className="h-full w-full object-cover opacity-25"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-[#0F172A]/95 via-[#0F172A]/85 to-[#2753D9]/20" />
        </div>
        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 text-center">
          <h1 className="font-satoshi text-4xl md:text-5xl text-slate-100">
            Barrel Blueprint Blog
          </h1>
          <p className="mt-6 text-lg text-slate-200 leading-relaxed">
            Neutral updates on industrial barrel systems. Each article combines field observation with public data, supported by modular visuals.
          </p>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20 space-y-8">
        {posts.map((post) => (
          <article
            key={post.link}
            className="rounded-3xl border border-[#0F172A]/10 bg-white overflow-hidden shadow-sm hover:shadow-lg transition"
          >
            <div className="md:flex">
              <div className="md:w-5/12">
                <img
                  src={post.image}
                  alt={`${post.title} illustration`}
                  className="h-64 w-full object-cover"
                  loading="lazy"
                />
              </div>
              <div className="md:w-7/12 p-8 space-y-4">
                <span className="text-xs uppercase tracking-[0.3em] text-[#2753D9]">
                  {post.date}
                </span>
                <h2 className="font-satoshi text-3xl text-[#0F172A]">
                  {post.title}
                </h2>
                <p className="text-base text-[#1E2535]/80 leading-relaxed">
                  {post.excerpt}
                </p>
                <NavLink
                  to={post.link}
                  className="inline-flex items-center text-sm uppercase tracking-wide text-[#2753D9]"
                >
                  Read full article →
                </NavLink>
              </div>
            </div>
          </article>
        ))}
      </section>
    </>
  );
};

export default Blog;