import React from "react";
import { Helmet } from "react-helmet-async";

const About: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>About Barrel Blueprint | Origins and Team</title>
        <meta
          name="description"
          content="Learn about Barrel Blueprint’s origins in Calgary, our editorial position, source model, neutrality policy, and the specialists behind the platform."
        />
        <link rel="canonical" href="https://www.barrelblueprint.com/about" />
      </Helmet>
      <section className="relative overflow-hidden bg-[#0F172A] text-slate-100">
        <div className="absolute inset-0">
          <img
            src="https://picsum.photos/1600/900?random=70"
            alt="Aerial view of pipeline network"
            className="h-full w-full object-cover opacity-30"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-[#0F172A]/90 via-[#0F172A]/85 to-[#2753D9]/20" />
        </div>
        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 text-center">
          <h1 className="font-satoshi text-4xl md:text-5xl text-slate-100">
            Steady Observation of Barrel Infrastructure
          </h1>
          <p className="mt-6 text-lg text-slate-200 leading-relaxed">
            Barrel Blueprint was established in Calgary to interpret how pipelines, refinery nodes, and storage grids operate within the Canadian landscape.
          </p>
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20 space-y-12">
        <article>
          <h2 className="font-satoshi text-3xl text-[#0F172A]">Origins</h2>
          <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
            Barrel Blueprint began as a collaborative research project among engineers, planners, and data communicators based in Calgary. The team saw a need for measured resources that explain industrial barrel systems without sensational language. Each contributor brought field familiarity and a commitment to disciplined reporting. Over time, the project evolved into a platform that documents the interplay between pipelines, refinery modules, and storage grids.
          </p>
          <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
            Today, the collective continues to investigate infrastructure through field notes, public filings, and open data. The goal is to produce explanations that remain accessible to community stakeholders while retaining enough technical detail to assist operators and planners. The platform maintains a mobile-first approach to ensure that insights remain available on site visits and in field settings.
          </p>
        </article>

        <article>
          <h2 className="font-satoshi text-3xl text-[#0F172A]">Editorial Position</h2>
          <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
            The editorial stance emphasizes clarity, restraint, and evidence-based reporting. We avoid promotional claims and focus on structural facts that define barrel systems. Language choices are intentional, centring on signal flows, layout geometry, and sequence logic. When uncertainties arise, they are clearly marked, and readers are guided to supporting registries or regulatory documents.
          </p>
        </article>

        <article>
          <h2 className="font-satoshi text-3xl text-[#0F172A]">Source Model</h2>
          <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
            Sources include national energy data archives, provincial regulatory bulletins, municipal planning departments, satellite imagery providers, and professional associations. Each blueprint is cross-referenced with at least two independent sources before publication. When possible, we cite the exact dataset or public document to help readers trace the original context.
          </p>
        </article>

        <article>
          <h2 className="font-satoshi text-3xl text-[#0F172A]">Neutrality Policy</h2>
          <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
            Neutrality guides every publication. The team refrains from projecting outcomes or advocating for specific projects. Instead, we report on existing infrastructure, planned expansions noted in public filings, and observed operational changes. Feedback is reviewed to ensure we remain balanced and respectful of all affected communities.
          </p>
        </article>
      </section>

      <section className="bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
          <h2 className="font-satoshi text-3xl text-[#0F172A] text-center">
            Editorial Team
          </h2>
          <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed text-center max-w-2xl mx-auto">
            The team spans process engineering, cartography, and data visualization. Each biography highlights current focus areas and daily responsibilities within Barrel Blueprint.
          </p>
          <div className="mt-12 grid gap-8 md:grid-cols-2">
            <article className="rounded-3xl border border-[#0F172A]/10 bg-[#F7F9FB] p-8 shadow-sm">
              <h3 className="font-satoshi text-2xl text-[#0F172A]">Avery Clarke</h3>
              <p className="text-sm uppercase tracking-wide text-[#2753D9]">
                Editor-in-Chief
              </p>
              <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
                Avery coordinates cross-disciplinary research threads and ensures each dossier meets the platform’s neutrality standards. With a background in pipeline operations, Avery translates technical documents into structured narratives that remain accessible to non-specialists while preserving precision.
              </p>
            </article>
            <article className="rounded-3xl border border-[#0F172A]/10 bg-[#F7F9FB] p-8 shadow-sm">
              <h3 className="font-satoshi text-2xl text-[#0F172A]">Mira Thompson</h3>
              <p className="text-sm uppercase tracking-wide text-[#2753D9]">
                Refinery Systems Analyst
              </p>
              <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
                Mira documents refinery node sequences, focusing on heat integration, energy recovery, and control logic. Her reports compare theoretical operation with observed field behaviour, capturing incremental adjustments that impact throughput and safety thresholds.
              </p>
            </article>
            <article className="rounded-3xl border border-[#0F172A]/10 bg-[#F7F9FB] p-8 shadow-sm">
              <h3 className="font-satoshi text-2xl text-[#0F172A]">Jonas Patel</h3>
              <p className="text-sm uppercase tracking-wide text-[#2753D9]">
                Storage Field Cartographer
              </p>
              <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
                Jonas constructs spatial models of storage arrays, detailing containment berms, roof types, venting routines, and access corridors. His diagrams prioritize clarity while respecting safety considerations and operator privacy requirements.
              </p>
            </article>
            <article className="rounded-3xl border border-[#0F172A]/10 bg-[#F7F9FB] p-8 shadow-sm">
              <h3 className="font-satoshi text-2xl text-[#0F172A]">Louise Chen</h3>
              <p className="text-sm uppercase tracking-wide text-[#2753D9]">
                Data Visualization Lead
              </p>
              <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
                Louise transforms raw data sets into low-contrast diagrams that respect accessibility standards. She builds modular components so visuals can be repurposed across dossiers without losing structural consistency.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;