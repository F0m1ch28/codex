import React from "react";
import { Helmet } from "react-helmet-async";

const Terms: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Use | Barrel Blueprint</title>
        <meta
          name="description"
          content="Review the Terms of Use governing access to Barrel Blueprint’s informational platform."
        />
        <link rel="canonical" href="https://www.barrelblueprint.com/terms" />
      </Helmet>
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20 space-y-10">
        <header>
          <h1 className="font-satoshi text-4xl text-[#0F172A]">Terms of Use</h1>
          <p className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
            Effective date: March 1, 2024
          </p>
        </header>
        <article className="space-y-8 text-sm text-[#1E2535]/80 leading-relaxed">
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">1. Acceptance</h2>
            <p>
              By accessing Barrel Blueprint, you agree to comply with these Terms of Use. If you do not accept these terms, please discontinue use of the site.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">2. Informational Purpose</h2>
            <p>
              Content provided on Barrel Blueprint serves informational purposes and does not constitute operational, legal, technical, or other professional advice. Users should consult qualified professionals for decisions related to industrial infrastructure.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">3. Use of Content</h2>
            <p>
              You may access, view, and reference the content for personal or organizational knowledge. Redistribution or reproduction of substantial portions requires written permission. Attribution is requested when referencing our materials.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">4. Accuracy</h2>
            <p>
              We strive to maintain accurate and current information drawn from reliable sources. However, the site may contain inadvertent errors or omissions. Barrel Blueprint disclaims liability for inaccuracies or reliance on the provided information.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">5. Third-Party Links</h2>
            <p>
              External links are offered solely for reference. Barrel Blueprint does not control and is not responsible for the content or policies of linked sites. Following links is at your discretion.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">6. User Contributions</h2>
            <p>
              Submissions through forms or email must be accurate and respectful. You grant Barrel Blueprint a non-exclusive right to use submitted information for the purposes of responding to inquiries and improving site content.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">7. Privacy</h2>
            <p>
              Personal data collected through the site is handled in accordance with our Privacy Policy. Please review that document to understand how we manage collected information.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">8. Intellectual Property</h2>
            <p>
              All trademarks, logos, diagrams, and textual content belong to Barrel Blueprint unless otherwise noted. Unauthorized use is prohibited.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">9. Limitation of Liability</h2>
            <p>
              Barrel Blueprint, its contributors, and affiliates are not liable for direct or indirect damages arising from site use, including reliance on information, loss of data, or site unavailability.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">10. Changes</h2>
            <p>
              We may update these terms without prior notice. Continued use after changes constitutes acceptance of the revised terms. The effective date will reflect the latest update.
            </p>
          </section>
          <section>
            <h2 className="font-semibold text-lg text-[#0F172A]">11. Contact</h2>
            <p>
              Questions regarding these Terms of Use may be directed to info@barrelblueprint.com.
            </p>
          </section>
        </article>
      </section>
    </>
  );
};

export default Terms;