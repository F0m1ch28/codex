import React from "react";
import { Helmet } from "react-helmet-async";

interface ClusterLink {
  label: string;
  url: string;
}

interface ClusterContent {
  title: string;
  paragraphs: string[];
  links: ClusterLink[];
}

const clusters: ClusterContent[] = [
  {
    title: "Pipeline Clusters",
    paragraphs: [
      "Pipeline dossiers highlight flow corridors across prairie, foothill, and coastal routes. We trace diameter transitions, pump station sequences, and pressure relief installations to help readers understand how fluid volumes travel between basins and terminals.",
      "Each cluster includes route overlays, valve spacing notes, and regulatory references. Revisions to pipeline alignments are catalogued to show how new segments integrate into the existing network without overstating their impact."
    ],
    links: [
      { label: "Canada Energy Regulator pipeline profiles", url: "https://www.cer-rec.gc.ca/en/data/pipeline/" },
      { label: "National Energy Board archived filings", url: "https://apps.cer-rec.gc.ca/REGDOCS/" },
      { label: "Provincial pipeline maps", url: "https://geogratis.gc.ca/" }
    ]
  },
  {
    title: "Refinery Clusters",
    paragraphs: [
      "Refinery dossiers break down process blocks into modular units, documenting distillation columns, heat exchanger loops, and vapor recovery systems. The focus remains on how each node contributes to overall stability.",
      "We translate control logic into plain language while preserving the sequencing of alarms, interlocks, and energy integration. This approach supports maintenance planning and stakeholder awareness without disclosing proprietary details."
    ],
    links: [
      { label: "Alberta Energy Regulator facility registry", url: "https://www.aer.ca/" },
      { label: "Environment and Climate Change Canada emission reports", url: "https://www.canada.ca/en/environment-climate-change/services/pollutant-inventory.html" },
      { label: "Industry technical standards library", url: "https://www.csa.ca/" }
    ]
  },
  {
    title: "Storage Clusters",
    paragraphs: [
      "Storage field dossiers examine tank geometries, containment berms, manifold arrangements, and instrumentation loops. We note structural spacing, venting patterns, and emergency access routes.",
      "Weather resilience is documented through seasonal observations, highlighting how insulation, heating, and drainage strategies maintain stability in Canadian climates."
    ],
    links: [
      { label: "Municipal emergency response guidelines", url: "https://www.alberta.ca/emergency-management.aspx" },
      { label: "Transport Canada terminal regulations", url: "https://tc.canada.ca/en" },
      { label: "Satellite imagery for industrial sites", url: "https://earth.google.com/web/" }
    ]
  }
];

const Services: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Systems Dossiers | Pipelines, Refineries, Storage</title>
        <meta
          name="description"
          content="Explore Barrel Blueprint clusters: pipeline corridors, refinery nodes, and storage fields. Each cluster provides structured paragraphs and neutral public links."
        />
        <link rel="canonical" href="https://www.barrelblueprint.com/systems" />
      </Helmet>
      <section className="relative overflow-hidden bg-[#0F172A] text-slate-100">
        <div className="absolute inset-0">
          <img
            src="https://picsum.photos/1600/900?random=80"
            alt="Industrial network overlaid with modular diagrams"
            className="h-full w-full object-cover opacity-30"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0F172A]/90 to-[#2753D9]/25" />
        </div>
        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 text-center">
          <h1 className="font-satoshi text-4xl md:text-5xl text-slate-100">
            Systems Clusters
          </h1>
          <p className="mt-6 text-lg text-slate-200 leading-relaxed">
            Three clusters anchor Barrel Blueprint: pipelines, refineries, and storage fields. Each cluster is delivered with neutral language, spatial awareness, and links to public references.
          </p>
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20 space-y-12">
        {clusters.map((cluster) => (
          <article
            key={cluster.title}
            className="rounded-3xl border border-[#0F172A]/10 bg-white p-10 shadow-sm"
          >
            <h2 className="font-satoshi text-3xl text-[#0F172A]">
              {cluster.title}
            </h2>
            {cluster.paragraphs.map((paragraph, index) => (
              <p key={index} className="mt-4 text-base text-[#1E2535]/80 leading-relaxed">
                {paragraph}
              </p>
            ))}
            <div className="mt-6">
              <h3 className="text-sm font-semibold uppercase tracking-wide text-[#2753D9]">
                Neutral Public References
              </h3>
              <ul className="mt-3 list-disc list-inside space-y-2 text-sm text-[#1E2535]/80">
                {cluster.links.map((link) => (
                  <li key={link.url}>
                    <a
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#2753D9] hover:underline"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </section>
    </>
  );
};

export default Services;