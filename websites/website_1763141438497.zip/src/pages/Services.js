import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const services = [
  {
    title: "Бренд-стратегия и платформа",
    description:
      "Исследуем аудиторию и конкурентную среду, формируем позиционирование, тональность и визуальные ориентиры, которые определяют будущий язык бренда.",
    points: [
      "Исследования и аналитика",
      "Платформа бренда и архетипы",
      "Гайд по коммуникациям"
    ]
  },
  {
    title: "Визуальная айдентика",
    description:
      "Разрабатываем логотипы, цветовые палитры, графику и типографику, создаём дизайн-системы и брендбуки, обеспечивающие целостность коммуникаций.",
    points: [
      "Логотип и графические паттерны",
      "Брендбук и гайдлайны",
      "Печатные и цифровые носители"
    ]
  },
  {
    title: "UX/UI и цифровые продукты",
    description:
      "Проектируем интуитивные интерфейсы для сайтов и приложений с фокусом на бизнес-метрики и комфорт пользователей.",
    points: [
      "UX-исследования и CJM",
      "Интерактивные прототипы",
      "UI дизайн и дизайн-системы"
    ]
  },
  {
    title: "Контент и креативные кампании",
    description:
      "Разрабатываем визуальные концепции и контент для цифровых и офлайн-каналов, усиливая маркетинговые активности бренда.",
    points: [
      "Креативные концепции",
      "Контент-производство",
      "Motion и анимация"
    ]
  }
];

const Services = () => (
  <div className={styles.services}>
    <Helmet>
      <html lang="ru" />
      <title>Услуги | ArtVision Studio</title>
      <meta
        name="description"
        content="ArtVision Studio предлагает услуги по разработке брендов, айдентики, UX/UI дизайна и креативных кампаний."
      />
    </Helmet>

    <section className={styles.intro}>
      <h1>Экспертиза ArtVision Studio</h1>
      <p>
        Мы создаём дизайн-решения, которые помогают брендам выделяться, выстраивать доверие и
        достигать своих целей. Работая как единая команда с клиентом, мы сопровождаем проект на
        всех этапах — от стратегии до внедрения.
      </p>
    </section>

    <section className={styles.cards}>
      {services.map((service) => (
        <article key={service.title} className={styles.card}>
          <h2>{service.title}</h2>
          <p>{service.description}</p>
          <ul>
            {service.points.map((point) => (
              <li key={point}>{point}</li>
            ))}
          </ul>
        </article>
      ))}
    </section>

    <section className={styles.process}>
      <h2>Как мы работаем</h2>
      <div className={styles.steps}>
        <div className={styles.step}>
          <span>01</span>
          <h3>Погружение</h3>
          <p>
            Анализируем задачу, изучаем аудиторию и бизнес-процессы, формируем гипотезы и критерии успеха.
          </p>
        </div>
        <div className={styles.step}>
          <span>02</span>
          <h3>Создание концепции</h3>
          <p>
            Разрабатываем визуальные направления, тестируем решения и совместно с клиентом выбираем оптимальный путь.
          </p>
        </div>
        <div className={styles.step}>
          <span>03</span>
          <h3>Реализация</h3>
          <p>
            Детализируем дизайн-систему, подготавливаем материалы и сопровождаем внедрение на сторону клиента.
          </p>
        </div>
      </div>
    </section>
  </div>
);

export default Services;