import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

const Contact = () => {
  const [status, setStatus] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus("Спасибо! Ваше сообщение отправлено. Мы свяжемся с вами в ближайшее время.");
    event.target.reset();
  };

  return (
    <div className={styles.contact}>
      <Helmet>
        <html lang="ru" />
        <title>Контакты | ArtVision Studio</title>
        <meta
          name="description"
          content="Свяжитесь с ArtVision Studio: офис в Москве, телефон, email и форма обратной связи."
        />
      </Helmet>

      <section className={styles.intro}>
        <h1>Связаться с ArtVision Studio</h1>
        <p>
          Мы открыты к новым проектам и партнёрствам. Расскажите нам о задаче — вместе мы найдём визуальное решение.
        </p>
      </section>

      <div className={styles.grid}>
        <form className={styles.form} onSubmit={handleSubmit}>
          <label>
            Имя
            <input type="text" name="name" placeholder="Ваше имя" required />
          </label>
          <label>
            Email
            <input type="email" name="email" placeholder="name@example.com" required />
          </label>
          <label>
            Компания
            <input type="text" name="company" placeholder="Название компании" />
          </label>
          <label>
            Сообщение
            <textarea name="message" rows="5" placeholder="Опишите задачу или идею" required />
          </label>
          <button type="submit">Отправить сообщение</button>
          {status && <p className={styles.status}>{status}</p>}
        </form>

        <div className={styles.info}>
          <div className={styles.card}>
            <h3>Контакты</h3>
            <p>ул. Творческая, 15, Москва, Россия</p>
            <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            <a href="mailto:hello@artvision.ru">hello@artvision.ru</a>
          </div>
          <div className={styles.map}>
            <iframe
              title="Карта ArtVision Studio"
              src="https://maps.google.com/maps?q=Москва%20ул.%20Творческая%2015&t=&z=13&ie=UTF8&iwloc=&output=embed"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;