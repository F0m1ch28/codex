import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Portfolio.module.css";

const projects = [
  {
    id: 1,
    title: "Re:Form Health",
    category: "Брендинг",
    image: "https://picsum.photos/600/800?random=31"
  },
  {
    id: 2,
    title: "Glow Digital",
    category: "Цифровой дизайн",
    image: "https://picsum.photos/600/800?random=32"
  },
  {
    id: 3,
    title: "Urban Stories",
    category: "Креатив",
    image: "https://picsum.photos/600/800?random=33"
  },
  {
    id: 4,
    title: "Northwind Travel",
    category: "Брендинг",
    image: "https://picsum.photos/600/800?random=34"
  },
  {
    id: 5,
    title: "Futura Tech",
    category: "Цифровой дизайн",
    image: "https://picsum.photos/600/800?random=35"
  },
  {
    id: 6,
    title: "Muse Concept",
    category: "Креатив",
    image: "https://picsum.photos/600/800?random=36"
  }
];

const categories = ["Все", "Брендинг", "Цифровой дизайн", "Креатив"];

const Portfolio = () => {
  const [filter, setFilter] = useState("Все");

  const filteredProjects =
    filter === "Все"
      ? projects
      : projects.filter((project) => project.category === filter);

  return (
    <div className={styles.portfolio}>
      <Helmet>
        <html lang="ru" />
        <title>Портфолио | ArtVision Studio</title>
        <meta
          name="description"
          content="Избранные проекты ArtVision Studio по брендингу, цифровому дизайну и креативным кампаниям."
        />
      </Helmet>

      <section className={styles.intro}>
        <h1>Выбор проектов ArtVision Studio</h1>
        <p>
          От концепции до реализации — наши проекты отражают разнообразие задач и подходов.
          Наша цель — создавать визуальные истории, которые вдохновляют и работают.
        </p>
      </section>

      <div className={styles.filters}>
        {categories.map((category) => (
          <button
            key={category}
            className={`${styles.filterBtn} ${
              filter === category ? styles.active : ""
            }`}
            onClick={() => setFilter(category)}
          >
            {category}
          </button>
        ))}
      </div>

      <section className={styles.grid}>
        {filteredProjects.map((project) => (
          <article key={project.id} className={styles.card}>
            <img src={project.image} alt={`Проект ${project.title}`} />
            <div className={styles.cardContent}>
              <span>{project.category}</span>
              <h3>{project.title}</h3>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};

export default Portfolio;