import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Legal.module.css";

const CookiePolicy = () => (
  <div className={styles.legal}>
    <Helmet>
      <html lang="ru" />
      <title>Политика Cookies | ArtVision Studio</title>
      <meta
        name="description"
        content="Политика использования файлов cookies на сайте ArtVision Studio."
      />
    </Helmet>

    <h1>Политика использования файлов cookies</h1>
    <p>Последнее обновление: 12 мая 2024 года</p>

    <h2>1. Что такое cookies</h2>
    <p>
      Cookies — это небольшие текстовые файлы, которые сохраняются на вашем устройстве при посещении сайта. Они помогают улучшить работу сайта и сделать взаимодействие удобнее.
    </p>

    <h2>2. Какие cookies мы используем</h2>
    <p>
      Мы используем функциональные cookies для сохранения ваших предпочтений, аналитические cookies для понимания поведения пользователей и маркетинговые cookies для персонализации контента.
    </p>

    <h2>3. Как управлять cookies</h2>
    <p>
      Вы можете настроить параметры браузера и ограничить использование cookies или удалить их. Обратите внимание, что это может повлиять на функциональность сайта.
    </p>
  </div>
);

export default CookiePolicy;