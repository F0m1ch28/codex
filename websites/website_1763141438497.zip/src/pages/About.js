import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const team = [
  {
    name: "Анна Ковалёва",
    role: "Креативный директор",
    image: "https://picsum.photos/400/400?random=41"
  },
  {
    name: "Дмитрий Левин",
    role: "Арт-директор",
    image: "https://picsum.photos/400/400?random=42"
  },
  {
    name: "Мария Чернова",
    role: "UX/UI-лид",
    image: "https://picsum.photos/400/400?random=43"
  },
  {
    name: "Илья Петров",
    role: "Стратег бренда",
    image: "https://picsum.photos/400/400?random=44"
  }
];

const About = () => (
  <div className={styles.about}>
    <Helmet>
      <html lang="ru" />
      <title>О студии | ArtVision Studio</title>
      <meta
        name="description"
        content="ArtVision Studio — команда стратегов, дизайнеров и креаторов, объединённых стремлением создавать выразительные бренды."
      />
    </Helmet>

    <section className={styles.intro}>
      <h1>ArtVision Studio — история, созданная дизайном</h1>
      <p>
        Мы объединяем стратегическое мышление, дизайн и технологии, чтобы создавать эмоциональные бренды.
        Студия выросла из небольшого бюро, и сегодня мы работаем с компаниями из разных отраслей,
        помогая им формировать уникальный визуальный голос.
      </p>
    </section>

    <section className={styles.mission}>
      <div>
        <h2>Миссия и подход</h2>
        <p>
          В центре наших проектов — понимание людей. Мы изучаем, как аудитория взаимодействует с брендом,
          и создаём дизайн, который говорит на её языке. Для нас важно, чтобы визуальные решения
          были не только эстетичными, но и решали конкретные бизнес-задачи.
        </p>
        <p>
          Мы верим в силу коллаборации: клиент — часть команды, и вместе мы ищем смелые, но точные решения.
        </p>
      </div>
      <div className={styles.imageWrap}>
        <img
          src="https://picsum.photos/600/700?random=45"
          alt="Команда ArtVision Studio за работой"
        />
      </div>
    </section>

    <section className={styles.team}>
      <h2>Команда ArtVision Studio</h2>
      <div className={styles.teamGrid}>
        {team.map((person) => (
          <article key={person.name} className={styles.member}>
            <img src={person.image} alt={`${person.name} — ${person.role}`} />
            <h3>{person.name}</h3>
            <span>{person.role}</span>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.values}>
      <h2>Наши ценности</h2>
      <div className={styles.valuesGrid}>
        <div>
          <h3>Честность и открытость</h3>
          <p>Строим прозрачные процессы и честно говорим о результатах.</p>
        </div>
        <div>
          <h3>Любознательность</h3>
          <p>Изучаем новые инструменты, тренды и подходы, чтобы создавать актуальные решения.</p>
        </div>
        <div>
          <h3>Ответственность</h3>
          <p>Берём на себя обязательства и доводим проекты до результата, который вдохновляет.</p>
        </div>
      </div>
    </section>
  </div>
);

export default About;