import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const Home = () => {
  return (
    <div className={styles.home}>
      <Helmet>
        <html lang="ru" />
        <title>ArtVision Studio — креативное дизайн-агентство</title>
        <meta
          name="description"
          content="ArtVision Studio создаёт эмоциональные бренды, визуальные концепции и цифровые продукты, вдохновляющие аудиторию."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.kicker}>Креативное дизайн-агентство</span>
          <h1>
            Сильная визуальная идентификация для брендов, которые хотят быть услышанными.
          </h1>
          <p>
            Мы превращаем идеи в выразительные бренды, создаём цифровые продукты и коммуникации,
            которые выделяют и усиливают бизнес.
          </p>
          <div className={styles.heroActions}>
            <Link to="/services" className={styles.primaryBtn}>
              Услуги студии
            </Link>
            <Link to="/portfolio" className={styles.secondaryBtn}>
              Портфолио
            </Link>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://picsum.photos/600/700?random=21"
            alt="Творческая команда ArtVision Studio"
          />
        </div>
      </section>

      <section className={styles.servicesPreview}>
        <div className={styles.sectionHeader}>
          <span>Что мы делаем</span>
          <h2>Комплексный подход к визуальному развитию брендов</h2>
          <p>
            Команда ArtVision Studio объединяет стратегов, дизайнеров и технólogos, чтобы создавать
            продуманные и вдохновляющие решения в различных направлениях.
          </p>
        </div>
        <div className={styles.serviceGrid}>
          <article className={styles.serviceCard}>
            <div className={styles.icon}>🎨</div>
            <h3>Айдентика бренда</h3>
            <p>
              Создаём цельные визуальные системы, которые отражают характер бренда и помогают
              выстраивать диалог с аудиторией на всех точках контакта.
            </p>
          </article>
          <article className={styles.serviceCard}>
            <div className={styles.icon}>💡</div>
            <h3>Креативные концепции</h3>
            <p>
              Разрабатываем идеи и визуальные кампании, которые выделяют бренд и обеспечивают
              запоминающийся опыт.
            </p>
          </article>
          <article className={styles.serviceCard}>
            <div className={styles.icon}>🖥️</div>
            <h3>Цифровой дизайн</h3>
            <p>
              UX/UI для сайтов и приложений, где функциональность сочетается с эстетикой и поддерживает цели бизнеса.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.portfolioPreview}>
        <div className={styles.sectionHeader}>
          <span>Наши работы</span>
          <h2>Портфолио, которым мы гордимся</h2>
          <p>
            От стартапов до крупных брендов — мы влюбляемся в каждую задачу и доводим визуальные решения до совершенства.
          </p>
        </div>
        <div className={styles.gallery}>
          {[24, 25, 26, 27].map((id) => (
            <figure key={id} className={styles.galleryItem}>
              <img
                src={`https://picsum.photos/600/600?random=${id}`}
                alt="Пример работы ArtVision Studio"
              />
              <figcaption>Визуальный проект ArtVision Studio</figcaption>
            </figure>
          ))}
        </div>
        <Link to="/portfolio" className={styles.galleryLink}>
          Смотреть все проекты
        </Link>
      </section>

      <section className={styles.values}>
        <div className={styles.valuesContent}>
          <h2>Мы верим в силу сотрудничества</h2>
          <p>
            Наш подход строится на глубоком понимании контекста бизнеса и потребностей аудитории.
            Мы создаём решения, которые работают сегодня и остаются актуальными завтра.
          </p>
          <ul>
            <li>Погружаемся в задачу и ищем инсайты.</li>
            <li>Работаем прозрачно и вовлекаем клиентов на каждом этапе.</li>
            <li>Создаём дизайн, который объединяет эстетику и функциональность.</li>
          </ul>
        </div>
        <div className={styles.valuesImage}>
          <img
            src="https://picsum.photos/600/800?random=29"
            alt="Рабочий процесс дизайнеров"
          />
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaCard}>
          <h2>Готовы вывести ваш бренд на новый уровень?</h2>
          <p>
            Расскажите о задаче, и мы предложим креативный путь развития визуальной коммуникации.
          </p>
          <Link to="/contact" className={styles.primaryBtn}>
            Связаться с нами
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;