import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.brand}>
        <h3>ArtVision Studio</h3>
        <p>
          Мы создаём визуальные решения, которые помогают брендам звучать ярко и уверенно.
        </p>
      </div>
      <div className={styles.contacts}>
        <h4>Контакты</h4>
        <ul>
          <li>ул. Творческая, 15, Москва, Россия</li>
          <li>
            <a href="tel:+74951234567">+7 (495) 123-45-67</a>
          </li>
          <li>
            <a href="mailto:hello@artvision.ru">hello@artvision.ru</a>
          </li>
        </ul>
      </div>
      <div className={styles.links}>
        <h4>Информация</h4>
        <NavLink to="/privacy">Политика конфиденциальности</NavLink>
        <NavLink to="/terms">Условия использования</NavLink>
        <NavLink to="/cookie-policy">Политика Cookies</NavLink>
      </div>
    </div>
    <div className={styles.bottom}>
      <span>© {new Date().getFullYear()} ArtVision Studio. Все права защищены.</span>
    </div>
  </footer>
);

export default Footer;