import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("av-cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem("av-cookie-consent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner}>
      <p>
        Мы используем cookies для улучшения работы сайта. Подробнее в{" "}
        <Link to="/cookie-policy">Политике Cookies</Link>.
      </p>
      <button onClick={acceptCookies}>Принять</button>
    </div>
  );
};

export default CookieBanner;