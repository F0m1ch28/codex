document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.mobile-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            primaryNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', primaryNav.classList.contains('open'));
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const consentButtons = document.querySelectorAll('.cookie-actions a[data-consent]');
    const consentKey = 'ccoCookieConsent';

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (storedConsent) {
            cookieBanner.classList.add('hidden');
        }

        consentButtons.forEach(button => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const choice = button.getAttribute('data-consent');
                localStorage.setItem(consentKey, choice);
                cookieBanner.classList.add('hidden');
                window.location.href = 'cookies.html';
            });
        });
    }

    const searchInput = document.querySelector('[data-search-posts]');
    const categoryButtons = document.querySelectorAll('[data-category-button]');
    const postCards = document.querySelectorAll('[data-post-card]');

    if (searchInput) {
        searchInput.addEventListener('input', () => {
            filterPosts();
        });
    }

    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            filterPosts();
        });
    });

    function filterPosts() {
        const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
        const activeCategoryButton = document.querySelector('[data-category-button].active');
        const category = activeCategoryButton ? activeCategoryButton.getAttribute('data-category-button') : 'all';

        postCards.forEach(card => {
            const title = card.querySelector('h3').textContent.toLowerCase();
            const excerpt = card.querySelector('p').textContent.toLowerCase();
            const cardCategory = card.getAttribute('data-category');
            const matchesCategory = category === 'all' || cardCategory === category;
            const matchesQuery = title.includes(query) || excerpt.includes(query);

            if (matchesCategory && matchesQuery) {
                card.classList.remove('hidden');
            } else {
                card.classList.add('hidden');
            }
        });
    }

    const subscribeForms = document.querySelectorAll('form[data-validate="subscribe"]');
    subscribeForms.forEach(form => {
        form.addEventListener('submit', (event) => {
            const emailInput = form.querySelector('input[type="email"]');
            if (emailInput && !isValidEmail(emailInput.value)) {
                event.preventDefault();
                emailInput.focus();
                displayFormFeedback(form, 'Please enter a valid email address.');
            }
        });
    });

    const contactForm = document.querySelector('form[data-validate="contact"]');
    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            const requiredFields = contactForm.querySelectorAll('[required]');
            let valid = true;

            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    valid = false;
                    field.classList.add('field-error');
                } else {
                    field.classList.remove('field-error');
                }
            });

            const emailField = contactForm.querySelector('input[type="email"]');
            if (emailField && !isValidEmail(emailField.value)) {
                valid = false;
                emailField.classList.add('field-error');
                displayFormFeedback(contactForm, 'Please enter a valid email address.');
            } else if (emailField) {
                emailField.classList.remove('field-error');
            }

            if (!valid) {
                event.preventDefault();
                displayFormFeedback(contactForm, 'Please complete all required fields before submitting.');
            }
        });
    }

    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.toLowerCase());
    }

    function displayFormFeedback(form, message) {
        let feedback = form.querySelector('.form-feedback');
        if (!feedback) {
            feedback = document.createElement('div');
            feedback.className = 'form-feedback';
            form.appendChild(feedback);
        }
        feedback.textContent = message;
    }
});