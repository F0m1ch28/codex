import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className="container">
      <div className={styles.grid}>
        <div className={styles.brand}>
          <h2>Nuvrionex</h2>
          <p>
            Automatisierte Kundenservice-Erlebnisse mit menschlicher Qualität, KI-Präzision und DSGVO-konformer Infrastruktur.
          </p>
          <div className={styles.contactDetails}>
            <p>Friedrichstraße 123, 10117 Berlin, Deutschland</p>
            <p>Telefon: <a href="tel:+493012345678">+49 30 12345678</a></p>
            <p>E-Mail: <a href="mailto:info@nuvrionex.com">info@nuvrionex.com</a></p>
          </div>
        </div>
        <div className={styles.column}>
          <h3>Lösungen</h3>
          <ul>
            <li><NavLink to="/loesungen">Branchen</NavLink></li>
            <li><NavLink to="/funktionen">Funktionen</NavLink></li>
            <li><NavLink to="/integrationen">Integrationen</NavLink></li>
            <li><NavLink to="/sicherheit">Sicherheit</NavLink></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3>Ressourcen</h3>
          <ul>
            <li><NavLink to="/ressourcen">Blog & Leitfäden</NavLink></li>
            <li><NavLink to="/plaene">Pakete</NavLink></li>
            <li><NavLink to="/kontakt">Support & SLA</NavLink></li>
            <li><NavLink to="/ueber-uns">Über Nuvrionex</NavLink></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3>Rechtliches</h3>
          <ul>
            <li><NavLink to="/nutzungsbedingungen">Nutzungsbedingungen</NavLink></li>
            <li><NavLink to="/datenschutz">Datenschutz</NavLink></li>
            <li><NavLink to="/cookie-richtlinie">Cookie-Richtlinie</NavLink></li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Nuvrionex GmbH. Alle Rechte vorbehalten.</p>
        <div className={styles.bottomLinks}>
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">LinkedIn</a>
          <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">X</a>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;