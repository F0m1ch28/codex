import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [open, setOpen] = useState(false);

  const toggleMenu = () => setOpen((prev) => !prev);
  const closeMenu = () => setOpen(false);

  return (
    <header className={styles.header} role="banner">
      <div className="container">
        <div className={styles.inner}>
          <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Nuvrionex Startseite">
            Nuvrionex
          </NavLink>
          <nav className={`${styles.nav} ${open ? styles.navOpen : ''}`} aria-label="Hauptnavigation">
            <NavLink
              to="/funktionen"
              className={({ isActive }) =>
                isActive ? `${styles.link} ${styles.active}` : styles.link
              }
              onClick={closeMenu}
            >
              Funktionen
            </NavLink>
            <NavLink
              to="/loesungen"
              className={({ isActive }) =>
                isActive ? `${styles.link} ${styles.active}` : styles.link
              }
              onClick={closeMenu}
            >
              Lösungen
            </NavLink>
            <NavLink
              to="/integrationen"
              className={({ isActive }) =>
                isActive ? `${styles.link} ${styles.active}` : styles.link
              }
              onClick={closeMenu}
            >
              Integrationen
            </NavLink>
            <NavLink
              to="/ressourcen"
              className={({ isActive }) =>
                isActive ? `${styles.link} ${styles.active}` : styles.link
              }
              onClick={closeMenu}
            >
              Ressourcen
            </NavLink>
            <NavLink
              to="/sicherheit"
              className={({ isActive }) =>
                isActive ? `${styles.link} ${styles.active}` : styles.link
              }
              onClick={closeMenu}
            >
              Sicherheit
            </NavLink>
            <NavLink
              to="/plaene"
              className={({ isActive }) =>
                isActive ? `${styles.link} ${styles.active}` : styles.link
              }
              onClick={closeMenu}
            >
              Pakete
            </NavLink>
            <NavLink
              to="/kontakt"
              className={({ isActive }) =>
                isActive ? `${styles.link} ${styles.active}` : styles.link
              }
              onClick={closeMenu}
            >
              Kontakt
            </NavLink>
            <NavLink
              to="/ueber-uns"
              className={({ isActive }) =>
                isActive ? `${styles.link} ${styles.active}` : styles.link
              }
              onClick={closeMenu}
            >
              Über uns
            </NavLink>
            <NavLink
              to="/kontakt"
              className={({ isActive }) =>
                isActive ? `${styles.cta} ${styles.activeCta}` : styles.cta
              }
              onClick={closeMenu}
            >
              Demo anfordern
            </NavLink>
          </nav>
          <button
            type="button"
            className={styles.toggle}
            onClick={toggleMenu}
            aria-expanded={open}
            aria-controls="nav-menu"
            aria-label="Menü umschalten"
          >
            <span className={styles.bar} />
            <span className={styles.bar} />
            <span className={styles.bar} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;