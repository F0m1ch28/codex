import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('nuvrionex-cookie-consent');
    if (!consent) {
      const timeout = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timeout);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem('nuvrionex-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="assertive" aria-label="Cookie Hinweis">
      <p>
        Wir verwenden Cookies, um den Support-Workflow zu optimieren und anonyme Nutzungsdaten sicher zu analysieren. Details finden Sie in unserer{' '}
        <a href="/cookie-richtlinie">Cookie-Richtlinie</a>.
      </p>
      <button type="button" onClick={handleAccept} className="button buttonPrimary">
        Einverstanden
      </button>
    </div>
  );
};

export default CookieBanner;