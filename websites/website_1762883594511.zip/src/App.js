import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Funktionen from './pages/Funktionen';
import Loesungen from './pages/Loesungen';
import Integrationen from './pages/Integrationen';
import Ressourcen from './pages/Ressourcen';
import Sicherheit from './pages/Sicherheit';
import Plaene from './pages/Plaene';
import Kontakt from './pages/Kontakt';
import Nutzungsbedingungen from './pages/Nutzungsbedingungen';
import Datenschutz from './pages/Datenschutz';
import CookieRichtlinie from './pages/CookieRichtlinie';

function App() {
  return (
    <>
      <a href="#mainContent" className="skip-link">
        Zum Hauptinhalt springen
      </a>
      <Header />
      <main id="mainContent" tabIndex="-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ueber-uns" element={<About />} />
          <Route path="/funktionen" element={<Funktionen />} />
          <Route path="/loesungen" element={<Loesungen />} />
          <Route path="/integrationen" element={<Integrationen />} />
          <Route path="/ressourcen" element={<Ressourcen />} />
          <Route path="/sicherheit" element={<Sicherheit />} />
          <Route path="/plaene" element={<Plaene />} />
          <Route path="/kontakt" element={<Kontakt />} />
          <Route path="/nutzungsbedingungen" element={<Nutzungsbedingungen />} />
          <Route path="/datenschutz" element={<Datenschutz />} />
          <Route path="/cookie-richtlinie" element={<CookieRichtlinie />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </>
  );
}

export default App;