import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Ressourcen.module.css';

const resources = [
  {
    type: 'Leitfaden',
    title: 'Operational Excellence im Kundenservice',
    description: 'Ein 40-seitiger Guide mit Templates für Runbooks, Eskalationen und Feedback-Loops.',
    link: '#'
  },
  {
    type: 'Webinar',
    title: 'KI-Verantwortung im Support',
    description: 'Live-Diskussion mit Security- und Compliance-Expertinnen über Governance und Audits.',
    link: '#'
  },
  {
    type: 'Template',
    title: 'SLA-Dashboard Vorlage',
    description: 'Starten Sie mit einem vorgefertigten KPI-Framework für Team- und Management-Reports.',
    link: '#'
  },
  {
    type: 'Blog',
    title: 'Customer Journey Automation',
    description: 'Wie Sie Lifecycle-Kommunikation orchestrieren und Übergaben an Sales & Success strukturieren.',
    link: '#'
  }
];

const Ressourcen = () => (
  <>
    <Helmet>
      <title>Nuvrionex | Ressourcen & Dokumentation</title>
      <meta
        name="description"
        content="Ressourcen für Support-Teams: Leitfäden, Webinare, Templates und Dokumentation rund um Nuvrionex."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Ressourcen & Dokumentation</h1>
        <p>
          Wissen, Tools und Best Practices für Ihren Kundenservice. Nutzen Sie unsere Ressourcen, um Ihre Teams zu befähigen und Prozesse nachhaltig zu optimieren.
        </p>
      </div>
    </section>
    <section className={styles.list}>
      <div className="container">
        <div className={styles.grid}>
          {resources.map((resource) => (
            <article key={resource.title} className={styles.card}>
              <span>{resource.type}</span>
              <h2>{resource.title}</h2>
              <p>{resource.description}</p>
              <a href={resource.link} className={styles.link}>
                Weiterlesen →
              </a>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Ressourcen;