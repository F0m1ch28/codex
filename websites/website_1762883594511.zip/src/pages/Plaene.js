import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Plaene.module.css';

const plans = [
  {
    name: 'Essentials',
    description: 'Für Teams, die Automatisierung und Omnichannel-Fähigkeiten gezielt aufbauen möchten.',
    features: [
      'KI-Chatbot & Agent Assist',
      'Omnichannel-Inbox mit SLA-Tracking',
      'Wissensdatenbank & Self-Service Portal',
      'Standard-Integrationen & API'
    ]
  },
  {
    name: 'Growth',
    description: 'Ideal für wachsende Organisationen mit komplexeren Workflows und erweiterten Anforderungen.',
    features: [
      'Erweiterter Workflow-Builder',
      'Mehrsprachige Inhalte & Übersetzungen',
      'Quality Analytics & Sentiment Tracking',
      'Erweiterte Rollenmodelle'
    ],
    highlight: true
  },
  {
    name: 'Enterprise',
    description: 'Für Unternehmen mit globalen Teams, Governance-Anforderungen und dediziertem Supportbedarf.',
    features: [
      'Dedizierte Datenresidenz & Tenant-Isolation',
      'Custom Integrationen & SLA-Erweiterungen',
      'Security Reviews & Pentest-Zusammenfassungen',
      'Technical Account Management'
    ]
  }
];

const Plaene = () => (
  <>
    <Helmet>
      <title>Nuvrionex | Pakete & Leistungsumfang</title>
      <meta
        name="description"
        content="Pakete von Nuvrionex: Essentials, Growth und Enterprise. Wählen Sie den Leistungsumfang, der zu Ihrem Service-Team passt."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Pakete & Leistungsumfang</h1>
        <p>
          Wählen Sie das Setup, das am besten zu Ihrem Wachstum und Ihren Governance-Anforderungen passt. Unsere Expertinnen beraten Sie gern.
        </p>
      </div>
    </section>
    <section className={styles.plans}>
      <div className="container">
        <div className={styles.grid}>
          {plans.map((plan) => (
            <article
              key={plan.name}
              className={`${styles.card} ${plan.highlight ? styles.highlight : ''}`}
            >
              <h2>{plan.name}</h2>
              <p>{plan.description}</p>
              <ul>
                {plan.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
              <a href="/kontakt" className="button buttonPrimary">
                Demo anfordern
              </a>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Plaene;