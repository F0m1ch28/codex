import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Loesungen.module.css';

const solutions = [
  {
    title: 'E-Commerce',
    description:
      'Schnelle Antworten zu Bestellungen, Retouren und Lieferzeiten. Automatische Erkennung kritischer Fälle sowie personalisierte Empfehlungen.',
    outcomes: ['First-Contact-Resolution steigern', 'Warenkorb-Abbrüche reduzieren', 'Self-Service erweitern']
  },
  {
    title: 'SaaS',
    description:
      'Onboarding-Workflows, Renewal-Signale und Beta-Support in einer Plattform. Verbinden Sie Produktdaten für kontextbezogene Kommunikation.',
    outcomes: ['Trial-Konvertierung verbessern', 'Feature-Adoption messen', 'Community-Support stärken']
  },
  {
    title: 'FinTech',
    description:
      'Auditierbare Kommunikationsketten, sichere Identitätsprüfung und klare Eskalationspfade für regulatorische Vorgaben.',
    outcomes: ['Compliance-Anforderungen erfüllen', 'Suspicious Activity Alerts priorisieren', 'Incident-Kommunikation koordinieren']
  },
  {
    title: 'Logistik',
    description:
      'Steuern Sie ETA-Updates, Ausnahmemanagement und Partnerkommunikation zentral. Verbinden Sie IoT-Feeds für Echtzeit-Einsichten.',
    outcomes: ['Lieferzuverlässigkeit erhöhen', 'Eskalationen senken', 'Flotten-Transparenz ausbauen']
  }
];

const Loesungen = () => (
  <>
    <Helmet>
      <title>Nuvrionex | Lösungen für Branchen & Use Cases</title>
      <meta
        name="description"
        content="Nuvrionex unterstützt E-Commerce, SaaS, FinTech und Logistik mit maßgeschneiderten Use Cases. Entdecken Sie branchenspezifische Workflows."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Lösungen für Ihre Branche</h1>
        <p>
          Ob wachsender Onlineshop oder streng reguliertes Institut – Nuvrionex schafft Klarheit, Geschwindigkeit und Vertrauen in jeder Interaktion.
        </p>
      </div>
    </section>
    <section className={styles.solutions}>
      <div className="container">
        <div className={styles.grid}>
          {solutions.map((solution) => (
            <article key={solution.title} className={styles.card}>
              <h2>{solution.title}</h2>
              <p>{solution.description}</p>
              <ul>
                {solution.outcomes.map((outcome) => (
                  <li key={outcome}>{outcome}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Loesungen;