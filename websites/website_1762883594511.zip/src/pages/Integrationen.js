import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Integrationen.module.css';

const categories = [
  {
    title: 'CRM & Service',
    tools: ['Salesforce', 'HubSpot Service', 'Microsoft Dynamics', 'Zendesk', 'Pipedrive']
  },
  {
    title: 'Shops & Marktplätze',
    tools: ['Shopify', 'Magento', 'Spryker', 'Amazon Marketplace', 'WooCommerce']
  },
  {
    title: 'Zahlungsanbieter',
    tools: ['Adyen', 'Stripe', 'Mollie', 'Unzer', 'PayPal']
  },
  {
    title: 'Kommunikation',
    tools: ['WhatsApp Business', 'Twilio Voice', 'Microsoft Teams', 'Slack', 'Zoom Contact Center']
  },
  {
    title: 'Collaboration & Tickets',
    tools: ['Jira Service Management', 'Asana', 'Notion', 'Confluence', 'ServiceNow']
  },
  {
    title: 'Daten & BI',
    tools: ['Snowflake', 'BigQuery', 'Looker', 'Tableau', 'Power BI']
  }
];

const Integrationen = () => (
  <>
    <Helmet>
      <title>Nuvrionex | Integrationen & offene API</title>
      <meta
        name="description"
        content="Verbinden Sie Nuvrionex mit CRM, Shops, Zahlungs- und Collaboration-Tools. Nutzen Sie unsere offene API und Webhooks."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Integrationen & API</h1>
        <p>
          Verbinden Sie Ihre Systeme ohne Kompromisse. Über 40 Konnektoren und eine leistungsfähige API ermöglichen einen durchgängigen Datenfluss – sicher und skalierbar.
        </p>
      </div>
    </section>
    <section className={styles.categories}>
      <div className="container">
        <div className={styles.grid}>
          {categories.map((category) => (
            <article key={category.title} className={styles.card}>
              <h2>{category.title}</h2>
              <ul>
                {category.tools.map((tool) => (
                  <li key={tool}>{tool}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
        <div className={styles.apiCallout}>
          <h2>Offene API & Webhooks</h2>
          <p>
            Nutzen Sie REST- und GraphQL-Endpunkte sowie Event-basierte Webhooks, um individuelle Integrationen zu bauen. Detaillierte Dokumentation, SDKs und Sandbox-Umgebungen beschleunigen Ihr Projekt.
          </p>
          <a href="/ressourcen" className="button buttonSecondary">
            Dokumentation lesen
          </a>
        </div>
      </div>
    </section>
  </>
);

export default Integrationen;