import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Kontakt.module.css';

const Kontakt = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    topic: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Bitte geben Sie Ihren Namen ein.';
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte geben Sie Ihre E-Mail-Adresse ein.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.topic.trim()) newErrors.topic = 'Bitte wählen Sie ein Thema.';
    if (!formData.message.trim()) newErrors.message = 'Bitte beschreiben Sie Ihr Anliegen.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData({
        name: '',
        email: '',
        company: '',
        topic: '',
        message: ''
      });
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <>
      <Helmet>
        <title>Nuvrionex | Kontakt & Support</title>
        <meta
          name="description"
          content="Kontaktieren Sie Nuvrionex: Demo anfordern, technische Fragen stellen oder SLA-Informationen erhalten."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Kontakt</h1>
          <p>
            Wir freuen uns auf Ihre Nachricht – ob Projektanfrage, Demo-Wunsch oder Unterstützung für Ihr bestehendes Team.
          </p>
        </div>
      </section>
      <section className={styles.content}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.details}>
              <h2>Support & SLA</h2>
              <p>
                Unser Support-Team ist montags bis freitags von 8:00 bis 20:00 Uhr CET erreichbar. Enterprise-Kundinnen erhalten dedizierte Rufbereitschaft und vereinbarte Reaktionszeiten.
              </p>
              <div className={styles.contactInfo}>
                <p><strong>Adresse:</strong> Friedrichstraße 123, 10117 Berlin, Deutschland</p>
                <p><strong>Telefon:</strong> <a href="tel:+493012345678">+49 30 12345678</a></p>
                <p><strong>E-Mail:</strong> <a href="mailto:info@nuvrionex.com">info@nuvrionex.com</a></p>
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Name *</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={errors.name ? 'true' : 'false'}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">E-Mail *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={errors.email ? 'true' : 'false'}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="company">Unternehmen</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={formData.company}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="topic">Thema *</label>
                <select
                  id="topic"
                  name="topic"
                  value={formData.topic}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={errors.topic ? 'true' : 'false'}
                >
                  <option value="">Bitte auswählen</option>
                  <option value="Demo">Demo anfordern</option>
                  <option value="Technik">Technische Frage</option>
                  <option value="SLA">SLA & Support</option>
                  <option value="Partnerschaft">Partnerschaft</option>
                </select>
                {errors.topic && <span className={styles.error}>{errors.topic}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Nachricht *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={errors.message ? 'true' : 'false'}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className="button buttonPrimary">
                Nachricht senden
              </button>
              {submitted && (
                <p className={styles.success} role="status">
                  Vielen Dank! Wir melden uns in Kürze bei Ihnen.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Kontakt;