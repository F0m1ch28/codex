import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Svenja Mertens',
    role: 'Chief Executive Officer',
    focus: 'Strategie & Kundenerlebnis',
    image: 'https://picsum.photos/400/400?random=3'
  },
  {
    name: 'Rahul Banerjee',
    role: 'Chief Technology Officer',
    focus: 'Plattform & KI',
    image: 'https://picsum.photos/400/400?random=9'
  },
  {
    name: 'Elena Jäger',
    role: 'Head of Security',
    focus: 'Governance & Compliance',
    image: 'https://picsum.photos/400/400?random=10'
  },
  {
    name: 'Marcel Ortner',
    role: 'VP Customer Success',
    focus: 'Adoption & Enablement',
    image: 'https://picsum.photos/400/400?random=11'
  }
];

const About = () => (
  <>
    <Helmet>
      <title>Nuvrionex | Über uns und unsere Mission</title>
      <meta
        name="description"
        content="Lernen Sie die Geschichte, Mission und das Team von Nuvrionex kennen. Wir formen sicheren, automatisierten Kundenservice für digitale Vorreiter."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <div className={styles.heroInner}>
          <div>
            <span className={styles.tagline}>Über Nuvrionex</span>
            <h1>Wir gestalten Kundenservice, der Wirkung zeigt</h1>
            <p>
              Nuvrionex wurde in Berlin gegründet, um anspruchsvollen Service-Teams ein Fundament aus Automatisierung, Qualität und Sicherheit zu bieten. Unsere Plattform verbindet KI, Wissensmanagement und Omnichannel-Kommunikation in einer Steuerzentrale.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.story}>
      <div className="container">
        <div className={styles.storyGrid}>
          <div>
            <h2>Unsere Geschichte</h2>
            <p>
              Nach Jahren im Enterprise-Support, in der KI-Forschung und im Sicherheitsumfeld erkannten wir, dass bestehende Tools entweder zu unflexibel oder zu fragmentiert für moderne Teams sind. 2020 gründeten wir Nuvrionex, um die Lücke zwischen exzellentem Service und effizienter Automatisierung zu schließen.
            </p>
          </div>
          <div>
            <h2>Mission & Werte</h2>
            <ul>
              <li><strong>Empathie:</strong> Kundenkommunikation braucht Kontext und Timing – unsere Lösungen unterstützen Menschen, nicht ersetzen sie.</li>
              <li><strong>Sicherheit:</strong> Datenschutz ist ein Versprechen. Jede Zeile Code reflektiert unsere Sicherheitsphilosophie.</li>
              <li><strong>Transparenz:</strong> Entscheidungen müssen nachvollziehbar sein. Deshalb liefern wir klare Protokolle und Messgrößen.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.quality}>
      <div className="container">
        <div className={styles.qualityInner}>
          <div>
            <h2>Qualität & Sicherheit in jedem Schritt</h2>
            <p>
              Unser Entwicklungsprozess folgt Security-by-Design-Prinzipien. Jedes Feature durchläuft automatisierte Tests, Peer Reviews und Privacy Assessments. Wir arbeiten mit unabhängigen Auditorinnen, um Compliance-Anforderungen fortlaufend zu übertreffen.
            </p>
          </div>
          <div className={styles.qualityList}>
            <div>
              <h3>Security Operations</h3>
              <p>24/7 Monitoring, Incident Response Playbooks und regelmäßige Penetrationstests.</p>
            </div>
            <div>
              <h3>Reliability</h3>
              <p>Multi-Region-Architektur mit aktiver Redundanz und abgesicherten Deployments.</p>
            </div>
            <div>
              <h3>Enablement</h3>
              <p>Training, Erfolgsmessung und Feedback-Loops stellen sicher, dass Teams nachhaltig profitieren.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.teamSection}>
      <div className="container">
        <h2>Team</h2>
        <p className={styles.teamIntro}>
          Unser Kernteam vereint Expertise aus Customer Experience, Machine Learning, Security Engineering und Service Operations.
        </p>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
              <div className={styles.teamOverlay}>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
                <span>{member.focus}</span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default About;