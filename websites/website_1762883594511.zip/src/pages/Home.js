import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Kundenzufriedenheit', target: 99.2, suffix: '%', decimals: 1 },
  { label: 'Schnellere Falllösung', target: 65, suffix: '%', decimals: 0 },
  { label: 'Erfolgreiche Integrationen', target: 40, suffix: '+', decimals: 0 },
  { label: 'Automatisierte Antworten', target: 3.2, suffix: ' Mio.', decimals: 1 }
];

const testimonials = [
  {
    quote: 'Nuvrionex hat unsere Bearbeitungszeiten halbiert und liefert jederzeit auditierbare DSGVO-Protokolle.',
    name: 'Leonie Berger',
    role: 'Head of Support, AlpineCommerce'
  },
  {
    quote: 'Die Omnichannel-Inbox bringt Chat, E-Mail und WhatsApp in eine Ansicht. Unser Team arbeitet endlich synchron.',
    name: 'Dr. Tobias Krämer',
    role: 'Customer Experience Lead, FinSphere'
  },
  {
    quote: 'Durch die Automationen erkennen wir Prioritäten sofort und eskalieren kritische Anfragen ohne Verzögerung.',
    name: 'Mira Schilling',
    role: 'Operations Director, TransLogix'
  }
];

const projects = [
  {
    title: 'Self-Service Portal für E-Commerce',
    category: 'E-Commerce',
    description: 'Personalisierte KI-Antworten für Retouren, Verzollung und Bestellstatus mit Live-Tracking.',
    image: 'https://picsum.photos/1200/800?random=4',
    alt: 'E-Commerce Dashboard mit Support-Analysen'
  },
  {
    title: 'FinTech Monitoring Suite',
    category: 'FinTech',
    description: 'Regulatorische Workflows mit Vier-Augen-Prinzip, revisionssichere Chats und Rollenverwaltung.',
    image: 'https://picsum.photos/1200/800?random=5',
    alt: 'FinTech Analysekonsole'
  },
  {
    title: 'SaaS Onboarding Journeys',
    category: 'SaaS',
    description: 'Automatische Lifecycle-Kommunikation, Trial-Konvertierung und In-App-Proaktive Hinweise.',
    image: 'https://picsum.photos/1200/800?random=6',
    alt: 'SaaS Workflow Builder'
  },
  {
    title: 'Logistik Incident Response',
    category: 'Logistik',
    description: 'Eskalationspfade, IoT-Datenfeeds und ETA-Alerts in einer einheitlichen Support-Oberfläche.',
    image: 'https://picsum.photos/1200/800?random=7',
    alt: 'Logistik Steuerungsoberfläche'
  }
];

const faqItems = [
  {
    question: 'Wie integriert sich Nuvrionex in bestehende Systeme?',
    answer:
      'Über unsere API- und Webhook-Plattform verbinden wir CRM, ERP, Shopsysteme und Collaboration-Tools ohne Medienbrüche. Vorgefertigte Konnektoren beschleunigen die Implementierung.'
  },
  {
    question: 'Welche Datenresidenz bietet Nuvrionex?',
    answer:
      'Alle Daten werden in ISO 27001-zertifizierten Rechenzentren in Deutschland verarbeitet. Datenexporte erfolgen ausschließlich verschlüsselt.'
  },
  {
    question: 'Wie unterstützt Nuvrionex hybride Support-Teams?',
    answer:
      'Gemeinsame Arbeitsbereiche, kollaborative Kommentierungen und Live-Insights sorgen für Transparenz – unabhängig vom Standort.'
  },
  {
    question: 'Welche Metriken können gemessen werden?',
    answer:
      'Dashboards liefern Echtzeit-Analysen zu SLA-Erfüllung, Stimmungsentwicklung, Eskalationsgründen und Automationsgrad. Individuelle Metriken sind konfigurierbar.'
  }
];

const blogPosts = [
  {
    title: 'Service-Automatisierung verantwortungsvoll gestalten',
    excerpt:
      'Wie Sie Governance, Transparenz und Customer Experience ausbalancieren und Ihre Teams in den Wandel einbinden.',
    date: '12. März 2024',
    link: '/ressourcen'
  },
  {
    title: 'Omnichannel-Playbook für skalierbare Kommunikation',
    excerpt:
      'Fünf praxiserprobte Taktiken, um Nachrichtenfluten zu kontrollieren und Prioritäten automatisch zu erkennen.',
    date: '28. Februar 2024',
    link: '/ressourcen'
  },
  {
    title: 'Security-by-Design im Kundenservice',
    excerpt:
      'Vom Verschlüsselungs-Stack bis zum Berechtigungsmodell: So verhindern Sie Schattenprozesse und Datenlecks.',
    date: '5. Februar 2024',
    link: '/sicherheit'
  }
];

const Home = () => {
  const [activeProjectFilter, setActiveProjectFilter] = useState('Alle');
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [counters, setCounters] = useState(statsData.map(() => 0));

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const durations = statsData.map(() => 1600);
    const start = performance.now();

    const animate = (time) => {
      const updated = statsData.map((stat, index) => {
        const progress = Math.min((time - start) / durations[index], 1);
        const value = stat.target * progress;
        return Number(value.toFixed(stat.decimals));
      });
      setCounters(updated);
      if (time - start < Math.max(...durations)) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, []);

  const filteredProjects =
    activeProjectFilter === 'Alle'
      ? projects
      : projects.filter((project) => project.category === activeProjectFilter);

  return (
    <>
      <Helmet>
        <title>Nuvrionex | Automatisierter Kundenservice, der skaliert</title>
        <meta
          name="description"
          content="Nuvrionex bringt KI, Omnichannel-Inbox und DSGVO-Sicherheit in Ihren Kundenservice. Automatisieren Sie Workflows, messen Sie Ergebnisse und begeistern Sie Kunden."
        />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'SoftwareApplication',
            name: 'Nuvrionex',
            applicationCategory: 'Customer Support Automation',
            address: {
              '@type': 'PostalAddress',
              streetAddress: 'Friedrichstraße 123',
              postalCode: '10117',
              addressLocality: 'Berlin',
              addressCountry: 'DE'
            },
            offers: {
              '@type': 'Offer',
              availability: 'https://schema.org/InStock'
            },
            operatingSystem: 'Web',
            creator: {
              '@type': 'Organization',
              name: 'Nuvrionex GmbH',
              address: 'Friedrichstraße 123, 10117 Berlin, Deutschland',
              contactPoint: {
                '@type': 'ContactPoint',
                contactType: 'customer support',
                telephone: '+49 30 12345678',
                email: 'info@nuvrionex.com'
              }
            }
          })}
        </script>
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <div className={styles.heroText}>
              <p className={styles.tagline}>KI-gestützte Service-Automatisierung</p>
              <h1>Automatisierter Kundenservice, der skaliert</h1>
              <p className={styles.heroDescription}>
                Nuvrionex orchestriert Chat, E-Mail und Voice in einer DSGVO-konformen Plattform. Teams gewinnen Kontrolle, Kundinnen erhalten verlässliche Antworten und Führungskräfte sehen Wirkung in Echtzeit.
              </p>
              <div className={styles.heroActions}>
                <Link className="button buttonPrimary" to="/kontakt">
                  Jetzt starten
                </Link>
                <Link className="button buttonSecondary" to="/funktionen">
                  Funktionen ansehen
                </Link>
              </div>
              <div className={styles.heroHighlights}>
                <div>
                  <span>Starkes Zusammenspiel</span>
                  <p>KI-Chatbot & Agent Assist in einer Oberfläche</p>
                </div>
                <div>
                  <span>Auditierbar</span>
                  <p>Transparente Workflows mit Ende-zu-Ende-Verschlüsselung</p>
                </div>
              </div>
            </div>
            <div className={styles.heroVisual}>
              <img
                src="https://picsum.photos/1600/900?random=1"
                alt="Support-Team in einem modernen Dashboard"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className="container">
          <div className={styles.statsGrid} role="list">
            {statsData.map((stat, index) => (
              <div className={styles.statCard} key={stat.label} role="listitem">
                <span className={styles.statValue}>
                  {counters[index]}
                  {stat.suffix}
                </span>
                <p>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.about}>
        <div className="container">
          <div className={styles.aboutInner}>
            <div>
              <h2>Wir verbinden Exzellenz im Kundenservice mit konsequenter Automatisierung</h2>
              <p>
                Nuvrionex ist die Plattform für Unternehmen, die ihren Kundenservice verlässlich skalieren möchten, ohne Einbußen bei Qualität, Transparenz oder Sicherheit. Moderne Teams steuern Touchpoints, Workflows und Wissensdatenbanken in einer Steuerzentrale.
              </p>
              <Link to="/ueber-uns" className="button buttonSecondary">
                Mehr über uns
              </Link>
            </div>
            <div className={styles.aboutVisual}>
              <img
                src="https://picsum.photos/800/600?random=2"
                alt="Modernes Support-Team arbeitet an Dashboards"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.features}>
        <div className="container">
          <h2>Leistungsstarke Module für Ihren Kundenservice</h2>
          <p className={styles.sectionIntro}>
            Von KI-gestützten Antworten bis zu tiefen Integrationen – jede Funktion ist auf hohe Service-Ansprüche ausgelegt.
          </p>
          <div className={styles.featureGrid}>
            <article className={styles.featureCard}>
              <h3>KI-Chatbot & Agent Assist</h3>
              <p>Trainieren Sie unseren KI-Assistenten auf Ihrem Wissen, validieren Sie Antworten und übergeben Sie komplexe Fälle automatisch an Expertinnen.</p>
              <Link to="/funktionen" className={styles.cardLink}>
                Details erkunden →
              </Link>
            </article>
            <article className={styles.featureCard}>
              <h3>Omnichannel-Inbox</h3>
              <p>Bündeln Sie E-Mail, Chat, Social Messaging und Voice in einer Oberfläche – priorisiert, kategorisiert und SLA-konform.</p>
              <Link to="/integrationen" className={styles.cardLink}>
                Kanäle verbinden →
              </Link>
            </article>
            <article className={styles.featureCard}>
              <h3>Workflow-Orchestrierung</h3>
              <p>Automatisieren Sie Routineaufgaben mit unserem visuellen Builder: vom Routing über Eskalationen bis zu Rückfragen.</p>
              <Link to="/funktionen" className={styles.cardLink}>
                Workflows gestalten →
              </Link>
            </article>
            <article className={styles.featureCard}>
              <h3>Wissensdatenbank</h3>
              <p>Pflegen Sie konsistente Antworten mit granularen Freigaben, Loopings für Feedback und Analytics zum Wissensstand.</p>
              <Link to="/ressourcen" className={styles.cardLink}>
                Wissensstrategie →
              </Link>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <h2>So funktioniert Nuvrionex</h2>
          <div className={styles.processGrid}>
            {['Verbinden', 'Automatisieren', 'Ausliefern', 'Messen'].map((step, index) => (
              <div className={styles.processCard} key={step}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <h3>{step}</h3>
                <p>
                  {step === 'Verbinden' &&
                    'Systeme und Kanäle sicher verknüpfen – per API, Konnektor oder Webhook.'}
                  {step === 'Automatisieren' &&
                    'Workflows modellieren, KI-Modelle trainieren und Validierungsregeln festlegen.'}
                  {step === 'Ausliefern' &&
                    'Antworten orchestrieren, Routing steuern und Kollaboration im Team stärken.'}
                  {step === 'Messen' &&
                    'Analysen in Echtzeit erhalten, SLA-Erfüllung überwachen und Optimierungen ableiten.'}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.why}>
        <div className="container">
          <div className={styles.whyInner}>
            <div className={styles.whyText}>
              <h2>Warum Nuvrionex?</h2>
              <ul>
                <li>
                  <span>DSGVO by Design:</span> Verschlüsselung, Audit-Trails und Rollenmodelle sind standardmäßig aktiv.
                </li>
                <li>
                  <span>Sofortige Einblicke:</span> Echtzeit-Analytics, Sentiment-Tracking und SLA Dashboards für fundierte Entscheidungen.
                </li>
                <li>
                  <span>Flexibel erweiterbar:</span> Über 40 Integrationen in CRM, Shops, Zahlungs- und Kollaborationstools.
                </li>
                <li>
                  <span>Operations im Fokus:</span> Resiliente Workflows, Runbooks und Incident-Kommunikation ohne Medienbrüche.
                </li>
              </ul>
            </div>
            <div className={styles.whyVisual}>
              <img
                src="https://picsum.photos/800/600?random=8"
                alt="Analytisches Dashboard mit KPI-Visualisierungen"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.successStories}>
        <div className="container">
          <h2>Erfolgsgeschichten</h2>
          <div className={styles.successGrid}>
            <article>
              <h3>AlpineCommerce</h3>
              <p>Reduzierte Bearbeitungszeit um 58% und erzielte 4,7/5 Bewertung bei Kundenzufriedenheit nach drei Monaten.</p>
            </article>
            <article>
              <h3>FinSphere</h3>
              <p>Audit-konforme Dokumentation jeder Interaktion, 100% SLA-Einhaltung im Quartal Q4.</p>
            </article>
            <article>
              <h3>TransLogix</h3>
              <p>Automatisierte ETA-Updates senkten Eskalationen um 36% und erhöhten First-Contact-Resolution auf 92%.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.testimonialCard}>
            <p className={styles.quote} aria-live="polite">
              “{testimonials[activeTestimonial].quote}”
            </p>
            <p className={styles.person}>
              {testimonials[activeTestimonial].name} – {testimonials[activeTestimonial].role}
            </p>
            <div className={styles.dots} role="tablist" aria-label="Kundenstimmen">
              {testimonials.map((testimonial, index) => (
                <button
                  key={testimonial.name}
                  type="button"
                  className={`${styles.dot} ${activeTestimonial === index ? styles.dotActive : ''}`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Testimonial ${index + 1} von ${testimonial.name}`}
                  aria-selected={activeTestimonial === index}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.projectsHeader}>
            <h2>Referenz-Workspaces & Journeys</h2>
            <div className={styles.filterGroup} role="group" aria-label="Projektkategorien filtern">
              {['Alle', 'E-Commerce', 'SaaS', 'FinTech', 'Logistik'].map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setActiveProjectFilter(category)}
                  className={`${styles.filterButton} ${
                    activeProjectFilter === category ? styles.filterActive : ''
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article className={styles.projectCard} key={project.title}>
                <div className={styles.projectImage}>
                  <img src={project.image} alt={project.alt} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/loesungen" className={styles.cardLink}>
                    Use Case lesen →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <h2>FAQ</h2>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.blogHeader}>
            <h2>Aktuelle Einblicke</h2>
            <Link to="/ressourcen" className="button buttonSecondary">
              Dokumentation lesen
            </Link>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <span>{post.date}</span>
                <Link to={post.link} className={styles.cardLink}>
                  Weiterlesen →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Bereit für den nächsten Standard im Kundenservice?</h2>
              <p>Starten Sie mit einem maßgeschneiderten Workspace und erleben Sie, wie Automatisierung und Empathie zusammenwirken.</p>
            </div>
            <div className={styles.ctaButtons}>
              <Link to="/kontakt" className="button buttonPrimary">
                Jetzt starten
              </Link>
              <Link to="/funktionen" className="button buttonGhost">
                Funktionen ansehen
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;