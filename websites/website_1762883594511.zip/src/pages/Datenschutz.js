import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Datenschutz = () => (
  <>
    <Helmet>
      <title>Nuvrionex | Datenschutzrichtlinie</title>
      <meta
        name="description"
        content="Nuvrionex Datenschutzrichtlinie: Informationen zur Verarbeitung personenbezogener Daten nach DSGVO."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Datenschutz</h1>
      </div>
    </section>
    <section className={styles.content}>
      <div className="container">
        <h2>1. Verantwortliche Stelle</h2>
        <p>
          Verantwortlich für die Datenverarbeitung ist die Nuvrionex GmbH, Friedrichstraße 123, 10117 Berlin, Deutschland. Kontakt: info@nuvrionex.com.
        </p>

        <h2>2. Verarbeitungszwecke</h2>
        <p>
          Wir verarbeiten personenbezogene Daten zur Bereitstellung unserer Plattform, zur Kundenbetreuung, zur Verbesserung unserer Dienste sowie zur Erfüllung gesetzlicher Pflichten.
        </p>

        <h2>3. Rechtsgrundlagen</h2>
        <p>
          Rechtsgrundlagen sind Art. 6 Abs. 1 lit. b DSGVO (Vertragserfüllung), Art. 6 Abs. 1 lit. c DSGVO (rechtliche Verpflichtung) und Art. 6 Abs. 1 lit. f DSGVO (berechtigte Interessen).
        </p>

        <h2>4. Auftragsverarbeitung</h2>
        <p>
          Bei Nutzung der Plattform handeln wir als Auftragsverarbeiter gemäß Art. 28 DSGVO. Mit allen Kundinnen schließen wir entsprechende Vereinbarungen zur Auftragsverarbeitung.
        </p>

        <h2>5. Datenresidenz & Sicherheit</h2>
        <p>
          Sämtliche Daten werden in Rechenzentren in Deutschland gespeichert. Wir nutzen Verschlüsselung, rollenbasierte Zugriffe, Logging und Sicherheitsprüfungen zur Absicherung.
        </p>

        <h2>6. Speicherdauer</h2>
        <p>
          Daten werden nach Ende des Vertragsverhältnisses oder auf Anweisung der Kundin gelöscht, sofern keine gesetzlichen Aufbewahrungspflichten bestehen.
        </p>

        <h2>7. Betroffenenrechte</h2>
        <p>
          Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit sowie Widerspruch. Wenden Sie sich hierfür an info@nuvrionex.com.
        </p>

        <h2>8. Beschwerderecht</h2>
        <p>
          Sie haben das Recht, sich bei einer Datenschutzaufsichtsbehörde zu beschweren. Zuständig ist die Berliner Beauftragte für Datenschutz und Informationsfreiheit.
        </p>

        <h2>9. Änderungen</h2>
        <p>
          Wir aktualisieren diese Richtlinie bei Bedarf. Wesentliche Änderungen kommunizieren wir proaktiv innerhalb der Plattform.
        </p>
      </div>
    </section>
  </>
);

export default Datenschutz;