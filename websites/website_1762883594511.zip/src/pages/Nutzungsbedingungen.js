import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Nutzungsbedingungen = () => (
  <>
    <Helmet>
      <title>Nuvrionex | Nutzungsbedingungen</title>
      <meta
        name="description"
        content="Nuvrionex Nutzungsbedingungen: rechtliche Grundlagen für die Nutzung der SaaS-Plattform."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Nutzungsbedingungen</h1>
      </div>
    </section>
    <section className={styles.content}>
      <div className="container">
        <h2>1. Geltungsbereich</h2>
        <p>
          Diese Nutzungsbedingungen regeln die Verwendung der Plattform Nuvrionex durch Kundinnen und Nutzer. Abweichungen sind nur wirksam, wenn sie schriftlich vereinbart wurden.
        </p>

        <h2>2. Vertragsgegenstand</h2>
        <p>
          Nuvrionex stellt eine SaaS-Plattform bereit, die Funktionen zur Automatisierung und Verwaltung von Kundenservice-Prozessen bietet. Der konkrete Leistungsumfang ergibt sich aus der jeweils vereinbarten Leistungsbeschreibung.
        </p>

        <h2>3. Zugang & Accounts</h2>
        <p>
          Kundinnen sind verantwortlich für die Verwaltung ihrer Zugänge. Anmeldedaten dürfen nicht an unbefugte Dritte weitergegeben werden. Bei Verdacht auf Missbrauch ist Nuvrionex unverzüglich zu informieren.
        </p>

        <h2>4. Verfügbarkeit</h2>
        <p>
          Nuvrionex strebt eine hohe Verfügbarkeit an. Wartungsarbeiten werden, soweit möglich, außerhalb der üblichen Geschäftszeiten durchgeführt. Über planbare Wartungen informieren wir rechtzeitig.
        </p>

        <h2>5. Verantwortlichkeiten</h2>
        <p>
          Kundinnen sind für die Inhalte verantwortlich, die sie in die Plattform einstellen. Sie gewährleisten, dass Daten keine Rechte Dritter verletzen und im Einklang mit geltendem Recht verarbeitet werden.
        </p>

        <h2>6. Datenschutz</h2>
        <p>
          Nuvrionex verarbeitet personenbezogene Daten ausschließlich im Rahmen der Vereinbarungen zur Auftragsverarbeitung. Weitere Informationen finden Sie in unserer Datenschutzrichtlinie.
        </p>

        <h2>7. Sicherheit</h2>
        <p>
          Nuvrionex setzt technische und organisatorische Maßnahmen ein, um die Daten vor unbefugtem Zugriff zu schützen. Kundinnen sind verpflichtet, eigene Endgeräte entsprechend abzusichern.
        </p>

        <h2>8. Haftung</h2>
        <p>
          Nuvrionex haftet für Vorsatz und grobe Fahrlässigkeit. Bei leichter Fahrlässigkeit haften wir nur bei Verletzung wesentlicher Vertragspflichten und begrenzt auf den vertragstypischen, vorhersehbaren Schaden.
        </p>

        <h2>9. Kündigung</h2>
        <p>
          Verträge können mit der vereinbarten Frist gekündigt werden. Das Recht zur außerordentlichen Kündigung bleibt unberührt.
        </p>

        <h2>10. Schlussbestimmungen</h2>
        <p>
          Es gilt deutsches Recht. Gerichtsstand ist Berlin, sofern gesetzlich zulässig. Sollten einzelne Bestimmungen unwirksam sein, bleibt die Wirksamkeit der übrigen Regelungen unberührt.
        </p>
      </div>
    </section>
  </>
);

export default Nutzungsbedingungen;