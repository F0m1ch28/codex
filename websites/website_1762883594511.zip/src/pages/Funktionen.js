import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Funktionen.module.css';

const modules = [
  {
    title: 'KI-Chatbot & Agent Assist',
    description:
      'Trainieren Sie unser Sprachmodell auf Ihrem Wissensschatz, überwachen Sie Antwortvorschläge und definieren Sie Freigaberegeln. Der Agent Assist liefert in Echtzeit Kontext, ähnliche Fälle und empfohlene Aktionen.',
    bullets: [
      'Adaptive Intents und mehrsprachige Antworten',
      'Human-in-the-loop Freigaben',
      'Feedback-Loops zum Nachtrainieren'
    ]
  },
  {
    title: 'Omnichannel-Inbox',
    description:
      'Alle Anfragen fließen in eine zentrale Inbox – kategorisiert, priorisiert und mit einheitlicher Kundenhistorie. Individuelle Queues und Skill-Routing sorgen für Effizienz.',
    bullets: [
      'Unified Timeline mit Kundenprofilen',
      'Priorisierung nach SLAs und Stimmung',
      'Collaboration-Tools mit Mentions'
    ]
  },
  {
    title: 'Ticketing & SLAs',
    description:
      'Visualisieren Sie Service-Level in Echtzeit, definieren Sie Eskalationsregeln und behalten Sie Zielerreichung transparent im Blick – inklusive Audit-Protokoll.',
    bullets: [
      'Mehrstufige Eskalationen',
      'SLA-Templates und Zieltracking',
      'Auditierbare Zeitstempel'
    ]
  },
  {
    title: 'Wissensdatenbank',
    description:
      'Pflegen Sie strukturierte Inhalte mit granularen Berechtigungen, Versionierung und intelligente Suche. Veröffentlichen Sie Inhalte nahtlos im Self-Service.',
    bullets: [
      'Versionierung & Freigabeprozesse',
      'KI-basierte Suche und Relevanzranking',
      'Self-Service Portal mit Branding-Optionen'
    ]
  },
  {
    title: 'Automationen & Workflows',
    description:
      'Mit dem visuellen Builder modellieren Sie Ereignisse, Bedingungen und Aktionen. Nutzen Sie vorkonfigurierte Templates oder bauen Sie individuelle Journeys.',
    bullets: [
      'Drag-and-drop Workflow Builder',
      'Webhook- und API-Trigger',
      'Bedingte Logik & A/B-Testing'
    ]
  },
  {
    title: 'Analytics & Insights',
    description:
      'Dashboards liefern sofortige Einblicke in Performance, Erfahrung und Effizienz. Exportieren Sie Daten sicher in Ihr Data Warehouse.',
    bullets: [
      'Echtzeit-Dashboards mit Drill-down',
      'Sentiment- und Trendanalysen',
      'Sichere Exporte & API-Zugriff'
    ]
  }
];

const Funktionen = () => (
  <>
    <Helmet>
      <title>Nuvrionex | Funktionen für modernen Kundenservice</title>
      <meta
        name="description"
        content="Entdecken Sie die Funktionen von Nuvrionex: KI-Chatbot, Omnichannel-Inbox, Workflow-Automation, Ticketing, Wissensdatenbank und Analytics."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Funktionen, die Service-Teams verbinden</h1>
        <p>
          Jedes Modul von Nuvrionex wurde gemeinsam mit Support-Leadern entwickelt. Erleben Sie, wie Automatisierung, Transparenz und Sicherheit nahtlos ineinandergreifen.
        </p>
      </div>
    </section>

    <section className={styles.modules}>
      <div className="container">
        <div className={styles.grid}>
          {modules.map((module) => (
            <article key={module.title} className={styles.card}>
              <h2>{module.title}</h2>
              <p>{module.description}</p>
              <ul>
                {module.bullets.map((bullet) => (
                  <li key={bullet}>{bullet}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Funktionen;