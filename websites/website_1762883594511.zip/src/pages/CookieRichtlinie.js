import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookieRichtlinie = () => (
  <>
    <Helmet>
      <title>Nuvrionex | Cookie-Richtlinie</title>
      <meta
        name="description"
        content="Erfahren Sie, wie Nuvrionex Cookies einsetzt, welche Kategorien es gibt und wie Sie Einstellungen verwalten."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Cookie-Richtlinie</h1>
      </div>
    </section>
    <section className={styles.content}>
      <div className="container">
        <h2>1. Allgemeines</h2>
        <p>
          Diese Richtlinie erläutert, wie Nuvrionex Cookies und ähnliche Technologien einsetzt. Cookies sind kleine Textdateien, die auf Ihrem Gerät gespeichert werden.
        </p>

        <h2>2. Einsatzkategorien</h2>
        <ul>
          <li><strong>Essenzielle Cookies:</strong> Notwendig für Login, Sicherheit und Session-Verwaltung.</li>
          <li><strong>Funktions-Cookies:</strong> Speichern Einstellungen wie Sprache oder Dashboard-Ansichten.</li>
          <li><strong>Analyse-Cookies:</strong> Helfen uns zu verstehen, wie die Plattform genutzt wird. Analysen erfolgen anonymisiert.</li>
        </ul>

        <h2>3. Steuerung</h2>
        <p>
          Sie können Cookies über die Einstellungen Ihres Browsers steuern oder löschen. Das Ablehnen essenzieller Cookies kann zu Funktionseinschränkungen führen.
        </p>

        <h2>4. Dienste von Drittanbietern</h2>
        <p>
          Wir setzen ausgewählte Dienstleister ein, die Daten ausschließlich in unserem Auftrag verarbeiten. Verträge nach Art. 28 DSGVO stellen sicher, dass der Datenschutz gewahrt bleibt.
        </p>

        <h2>5. Änderungen</h2>
        <p>
          Wir aktualisieren diese Richtlinie regelmäßig. Wesentliche Änderungen teilen wir in der Plattform mit.
        </p>
      </div>
    </section>
  </>
);

export default CookieRichtlinie;