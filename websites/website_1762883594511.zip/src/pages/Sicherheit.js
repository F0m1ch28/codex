import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Sicherheit.module.css';

const Sicherheit = () => (
  <>
    <Helmet>
      <title>Nuvrionex | Sicherheit & Datenschutz</title>
      <meta
        name="description"
        content="Nuvrionex schützt Kundendaten mit DSGVO-konformer Datenresidenz, Verschlüsselung und rollenbasierten Berechtigungen."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Sicherheit & Datenschutz</h1>
        <p>
          Wir entwickeln nach strengen Security-by-Design-Prinzipien. Daten bleiben in Deutschland, werden verschlüsselt verarbeitet und durch fein granulare Rechte geschützt.
        </p>
      </div>
    </section>
    <section className={styles.content}>
      <div className="container">
        <div className={styles.grid}>
          <article className={styles.card}>
            <h2>DSGVO & Compliance</h2>
            <p>
              Nuvrionex erfüllt DSGVO, BDSG und branchenspezifische Richtlinien. Funktionen wie Datenaufbewahrungspläne, Löschkonzepte und Audit-Trails sind integraler Bestandteil.
            </p>
          </article>
          <article className={styles.card}>
            <h2>Datenresidenz</h2>
            <p>
              Speicherung und Verarbeitung erfolgen ausschließlich in ISO 27001-zertifizierten Rechenzentren in Frankfurt und Berlin. Optional bieten wir dedizierte Tenant-Setups.
            </p>
          </article>
          <article className={styles.card}>
            <h2>Verschlüsselung</h2>
            <p>
              Daten werden im Ruhezustand (AES-256) und während der Übertragung (TLS 1.3) verschlüsselt. Schlüssel werden in einem HSM abgesichert, inklusive Rotation.
            </p>
          </article>
          <article className={styles.card}>
            <h2>Rollen & Rechte</h2>
            <p>
              Rollenbasierte Zugriffe mit Attribut-Policies stellen sicher, dass nur autorisierte Personen sensible Daten einsehen oder exportieren können.
            </p>
          </article>
          <article className={styles.card}>
            <h2>Monitoring & Response</h2>
            <p>
              24/7 Security Monitoring, Schwachstellen-Scans und Playbooks für Incident Response. Alle Ereignisse werden protokolliert und können exportiert werden.
            </p>
          </article>
          <article className={styles.card}>
            <h2>Zertifizierungen</h2>
            <p>
              Wir arbeiten mit unabhängigen Auditorinnen zusammen und veröffentlichen Sicherheitsberichte im Kundenportal. Pentest-Zusammenfassungen sind auf Anfrage verfügbar.
            </p>
          </article>
        </div>
      </div>
    </section>
  </>
);

export default Sicherheit;