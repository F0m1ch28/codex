import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CONSENT_KEY = 'selvariCookieConsent';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(CONSENT_KEY);
    if (!consent) {
      const timeout = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timeout);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem(CONSENT_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner}>
      <div className={styles.message}>
        Utilizamos cookies esenciales para mejorar tu experiencia en Selvari&apos;s Insights. Al
        continuar, aceptas nuestra <a href="/cookies">Política de Cookies</a>.
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Aceptar
      </button>
    </div>
  );
}

export default CookieBanner;