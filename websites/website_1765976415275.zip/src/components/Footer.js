import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.brandBlock}>
          <div className={styles.logo}>Selvari&apos;s Insights</div>
          <p className={styles.tagline}>
            Sabiduría práctica para una vida larga, plena y consciente en México.
          </p>
        </div>

        <div className={styles.columns}>
          <div className={styles.column}>
            <h4>Navegación</h4>
            <ul>
              <li><Link to="/">Inicio</Link></li>
              <li><Link to="/guide">Guía</Link></li>
              <li><Link to="/programs">Programas</Link></li>
              <li><Link to="/tools">Herramientas</Link></li>
              <li><Link to="/blog">Blog</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4>Compañía</h4>
            <ul>
              <li><Link to="/about">Acerca de</Link></li>
              <li><Link to="/contact">Contacto</Link></li>
              <li><Link to="/terminos">Términos de Servicio</Link></li>
              <li><Link to="/privacidad">Política de Privacidad</Link></li>
              <li><Link to="/cookies">Política de Cookies</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4>Contacto</h4>
            <p>Correo: <a href="mailto:hola@selvaritonamira.site">hola@selvaritonamira.site</a></p>
            <p>Ciudad de México, MX</p>
            <div className={styles.socials}>
              <a href="https://www.instagram.com" aria-label="Instagram de Selvari">IG</a>
              <a href="https://www.linkedin.com" aria-label="LinkedIn de Selvari">IN</a>
              <a href="https://www.youtube.com" aria-label="YouTube de Selvari">YT</a>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} Selvari&apos;s Insights. Todos los derechos reservados.</span>
      </div>
    </footer>
  );
}

export default Footer;