import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Guide.module.css';

const guideSections = [
  {
    title: 'Amanecer con intención',
    description:
      'Pequeñas prácticas al despertar que regulan el cortisol y preparan tu mente para decisiones serenas.',
    steps: [
      'Hidratación templada con una pizca de sal de mar para activar electrolitos.',
      'Respiración 4-6-8 durante tres minutos para suavizar tu ritmo cardiaco.',
      'Preguntar: ¿qué necesita mi cuerpo hoy? Escribe una idea breve en tu bitácora.'
    ]
  },
  {
    title: 'Nutrición que acompaña el ritmo mexicano',
    description:
      'Estrategias culinarias realistas para quienes combinan cocina tradicional con jornadas modernas.',
    steps: [
      'Planifica desayunos sencillos con proteína vegetal y grasas calmantes (aguacate, semillas de calabaza).',
      'Diseña dos “platos base” que puedas replicar durante la semana variando vegetales locales.',
      'Incluye tisanas digestivas nocturnas con manzanilla, hinojo y toque de canela.'
    ]
  },
  {
    title: 'Movimiento restaurativo en jornada laboral',
    description:
      'Secuencias accesibles que puedes realizar entre videollamadas o tras desplazamientos largos.',
    steps: [
      'Micro-pausa cada 90 minutos: 6 ciclos de respiración con brazos que acompañan la inhalación.',
      'Circuito de movilidad suave en silla: columna, caderas y tobillos en 5 minutos.',
      'Caminata consciente post comida: 10 minutos al aire libre o en tu edificio para activar digestión.'
    ]
  },
  {
    title: 'Cierre del día y sueño reparador',
    description:
      'Rituales nocturnos para lograr descanso profundo aun con ruidos urbanos o agendas cambiantes.',
    steps: [
      'Apaga pantallas fuertes 45 minutos antes de dormir y cambia la iluminación por tonos cálidos.',
      'Escribe tres agradecimientos concretos que hayas percibido durante tu día.',
      'Escucha audio de respiración diafragmática mientras colocas bolsas de semillas tibias en cuello y manos.'
    ]
  }
];

function Guide() {
  return (
    <>
      <Helmet>
        <title>Guía de estilo de vida | Selvari&apos;s Insights</title>
        <meta
          name="description"
          content="Guía detallada de Selvari's Insights para cultivar longevidad desde hábitos cotidianos, nutrición, movimiento y descanso."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Guía esencial para una longevidad gentil</h1>
        <p>
          Diseñamos esta guía pensando en personas mexicanas con agendas vibrantes que desean
          sostener salud sin sacrificar calidez. Aquí encontrarás rituales realistas, basados en
          ciencia actualizada y la sabiduría de nuestras abuelas.
        </p>
      </section>

      <section className={styles.sections}>
        {guideSections.map((section) => (
          <article key={section.title} className={styles.card}>
            <header>
              <h2>{section.title}</h2>
              <p>{section.description}</p>
            </header>
            <ol>
              {section.steps.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
          </article>
        ))}
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h3>Integra la guía a tu propio ritmo</h3>
          <p>
            Descarga la versión imprimible, personaliza los horarios y comparte con quienes te
            acompañan en casa u oficina. Cada práctica es flexible para ajustarse a tu temporada.
          </p>
          <a href="#descarga" className={styles.ctaButton}>
            Descargar versión PDF
          </a>
        </div>
      </section>
    </>
  );
}

export default Guide;