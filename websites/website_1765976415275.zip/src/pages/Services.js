import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

const programs = [
  {
    title: 'Programa Vitalidad Cotidiana',
    subtitle: '90 días para redibujar tu energía',
    description:
      'Un acompañamiento paso a paso con sesiones grupales semanales, bitácoras guiadas y ajustes personalizados que se adaptan a tu agenda laboral.',
    highlights: [
      'Mapeo profundo de tus ritmos actuales.',
      'Protocolos de nutrición sensorial y pausas activas.',
      'Seguimiento de sueño con ajustes semanales.'
    ]
  },
  {
    title: 'Residencia Digital Selvari',
    subtitle: '4 semanas intensivas en línea',
    description:
      'Ideal para quienes quieren un reset completo. Incluye cápsulas audiovisuales, prácticas grabadas y círculos de integración cada domingo.',
    highlights: [
      'Acceso a biblioteca de respiraciones y audio guías.',
      'Plan de comidas armoniosas con ingredientes locales.',
      'Mentorías exprés uno a uno (2 por semana).'
    ]
  },
  {
    title: 'Círculo Corporativo Calm',
    subtitle: 'Bienestar para equipos creativos',
    description:
      'Diseñamos experiencias de bienestar híbridas para organizaciones que desean cuidar a su talento desde la empatía y la ciencia del descanso.',
    highlights: [
      'Diagnóstico sensible del ambiente laboral.',
      'Sesiones temáticas (nutrición, estrés, movimiento).',
      'Dashboard con métricas de energía y recomendaciones.'
    ]
  }
];

function Programs() {
  return (
    <>
      <Helmet>
        <title>Programas de bienestar | Selvari&apos;s Insights</title>
        <meta
          name="description"
          content="Explora los programas de Selvari's Insights: Vitalidad Cotidiana, Residencia Digital y Círculo Corporativo Calm para impulsar tu salud."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Programas para sostener bienestar con calma estratégica</h1>
        <p>
          Cada programa nace de la escucha activa a nuestra comunidad. Diseñamos experiencias que
          honran tu contexto, mezclan conocimiento científico y la calidez de rituales mexicanos.
        </p>
      </section>

      <section className={styles.programs}>
        {programs.map((program) => (
          <article key={program.title} className={styles.programCard}>
            <header>
              <h2>{program.title}</h2>
              <span>{program.subtitle}</span>
            </header>
            <p>{program.description}</p>
            <ul>
              {program.highlights.map((highlight) => (
                <li key={highlight}>{highlight}</li>
              ))}
            </ul>
            <button type="button" className={styles.programButton}>
              Solicitar agenda de sesiones
            </button>
          </article>
        ))}
      </section>

      <section className={styles.note}>
        <div className={styles.noteCard}>
          <h3>¿Necesitas algo totalmente a tu medida?</h3>
          <p>
            Con gusto creamos un plan personalizado combinando evaluación funcional, terapias
            respiratorias, mindfulness y acompañamiento culinario. Agenda una conversación inicial
            sin compromiso desde nuestra página de contacto.
          </p>
        </div>
      </section>
    </>
  );
}

export default Programs;