import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Tools.module.css';

const tools = [
  {
    title: 'Bitácora Selvari',
    description:
      'Formato imprimible con preguntas gatillo para monitorear energía, sueño y emociones durante 14 días.',
    benefit: 'Te ayuda a detectar patrones sutiles y tomar decisiones informadas.'
  },
  {
    title: 'Biblioteca de respiraciones',
    description:
      'Colección de audios guiados (3, 6 y 12 minutos) inspirados en técnicas de coherencia cardiaca.',
    benefit: 'Recupera calma en cualquier momento y regula tu sistema nervioso.'
  },
  {
    title: 'Mapa de sabores calmantes',
    description:
      'Infografía con ingredientes mexicanos que favorecen la digestión y la producción de serotonina.',
    benefit: 'Diseña menús semanales más nutritivos sin perder arraigo cultural.'
  },
  {
    title: 'Playlist Ritmos Circadianos',
    description:
      'Selección musical matutina y nocturna para acompañar tus rituales cotidianos y mejorar foco.',
    benefit: 'Utiliza el sonido como ancla para transitar entre tareas con suavidad.'
  }
];

function Tools() {
  return (
    <>
      <Helmet>
        <title>Herramientas y técnicas | Selvari&apos;s Insights</title>
        <meta
          name="description"
          content="Herramientas descargables, audios y recursos prácticos de Selvari's Insights para aplicar bienestar en tu día a día."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Herramientas para mantenerte en equilibrio</h1>
        <p>
          Seleccionamos instrumentos versátiles que puedes usar en casa, en oficina o viajando.
          Todo el contenido está protegido con contraseña para miembros; solicita acceso desde el
          formulario de contacto.
        </p>
      </section>

      <section className={styles.grid}>
        {tools.map((tool) => (
          <article key={tool.title} className={styles.card}>
            <h2>{tool.title}</h2>
            <p>{tool.description}</p>
            <span>{tool.benefit}</span>
            <button type="button">Solicitar acceso</button>
          </article>
        ))}
      </section>
    </>
  );
}

export default Tools;