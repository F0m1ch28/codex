import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  message: '',
  subscribe: false
};

function Contact() {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Por favor ingresa tu nombre completo.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Necesitamos un correo electrónico para responderte.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'El formato del correo no es válido.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Cuéntanos en qué podemos ayudarte.';
    }

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      setStatus('Gracias por escribir. Te responderemos en un máximo de 24 horas hábiles.');
      setFormData(initialState);
    } else {
      setStatus('');
    }
  };

  return (
    <>
      <Helmet>
        <title>Contacto | Selvari&apos;s Insights</title>
        <meta
          name="description"
          content="Ponte en contacto con Selvari's Insights. Agenda una conversación, solicita programas a la medida o haz preguntas."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Hablemos sobre tu bienestar</h1>
        <p>
          Comparte tus objetivos, dudas o ideas. Estamos listos para ayudarte a diseñar un camino
          de salud y longevidad que se sienta humano y sostenible.
        </p>
      </section>

      <section className={styles.contactSection}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Nombre completo</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Escribe tu nombre"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'error-name' : undefined}
              required
            />
            {errors.name && <span id="error-name">{errors.name}</span>}
          </div>

          <div className={styles.field}>
            <label htmlFor="email">Correo electrónico</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="tu@email.com"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'error-email' : undefined}
              required
            />
            {errors.email && <span id="error-email">{errors.email}</span>}
          </div>

          <div className={styles.field}>
            <label htmlFor="message">Mensaje</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Cuéntanos acerca de tus metas de bienestar..."
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'error-message' : undefined}
              required
            />
            {errors.message && <span id="error-message">{errors.message}</span>}
          </div>

          <label className={styles.checkbox}>
            <input
              type="checkbox"
              name="subscribe"
              checked={formData.subscribe}
              onChange={handleChange}
            />
            <span>Suscribirse a las actualizaciones</span>
          </label>

          <button type="submit" className={styles.submitButton}>
            Enviar mensaje
          </button>
          {status && (
            <p className={styles.status} role="status">
              {status}
            </p>
          )}
        </form>

        <aside className={styles.infoCard}>
          <h2>También estamos en:</h2>
          <ul>
            <li>
              <strong>Correo:</strong> <a href="mailto:hola@selvaritonamira.site">hola@selvaritonamira.site</a>
            </li>
            <li>
              <strong>WhatsApp:</strong> +52 (55) 0000 0000
            </li>
            <li>
              <strong>Ubicación:</strong> Consultorías presenciales en Ciudad de México
            </li>
          </ul>
          <p>
            Horario de respuesta: Lunes a viernes, 9:00 a 18:00. Si escribes en fin de semana,
            recibirás respuesta el lunes siguiente.
          </p>
        </aside>
      </section>
    </>
  );
}

export default Contact;