import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Respirar con el aroma a lluvia: mindfulness sensorial en CDMX',
    date: '5 marzo 2024',
    excerpt:
      'Una práctica para aprovechar el olor a tierra mojada durante las lluvias vespertinas y conectar con el presente.',
    image: 'https://images.unsplash.com/photo-1499696786230-29e4d976f51f?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Cómo organizar tu cocina para nutrirte con calma',
    date: '26 febrero 2024',
    excerpt:
      'Tips de mise en place emocional para que cocinar sea terapéutico aun en departamentos pequeños.',
    image: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'El arte de cerrar pantallas y abrir el descanso',
    date: '12 febrero 2024',
    excerpt:
      'Estrategias de higiene digital inspiradas en rituales de pueblos mágicos, adaptadas a la vida urbana.',
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=800&q=80'
  }
];

function Blog() {
  return (
    <>
      <Helmet>
        <title>Blog | Selvari&apos;s Insights</title>
        <meta
          name="description"
          content="Artículos y relatos personales sobre bienestar, longevidad y calma en el día a día creados por Selvari's Insights."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Blog: relatos, ciencia y rituales</h1>
        <p>
          Compartimos historias reales, aprendizajes desde la investigación y notas de campo donde
          exploramos bienestar en contextos mexicanos contemporáneos.
        </p>
      </section>

      <section className={styles.posts}>
        {posts.map((post) => (
          <article key={post.title} className={styles.postCard}>
            <div className={styles.imageWrapper}>
              <img src={post.image} alt={post.title} loading="lazy" />
            </div>
            <div className={styles.postContent}>
              <span>{post.date}</span>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <button type="button">Leer artículo completo</button>
            </div>
          </article>
        ))}
      </section>
    </>
  );
}

export default Blog;