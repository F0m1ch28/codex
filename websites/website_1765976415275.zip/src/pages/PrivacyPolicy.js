import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Policy.module.css';

function PrivacyPolicy() {
  return (
    <>
      <Helmet>
        <title>Política de Privacidad | Selvari&apos;s Insights</title>
        <meta
          name="description"
          content="Política de Privacidad de Selvari's Insights. Transparencia sobre cómo recopilamos y protegemos tu información personal."
        />
      </Helmet>
      <section className={styles.policy}>
        <h1>Política de Privacidad</h1>
        <p className={styles.updated}>Última actualización: 5 de marzo de 2024</p>

        <div className={styles.section}>
          <h2>Datos recopilados</h2>
          <p>
            Recopilamos información de contacto (nombre, correo electrónico) cuando te suscribes,
            solicitas un programa o nos envías un mensaje. También utilizamos cookies para mejorar
            tu experiencia.
          </p>
        </div>

        <div className={styles.section}>
          <h2>Uso de la información</h2>
          <ul>
            <li>Responder consultas y brindar soporte personalizado.</li>
            <li>Enviar comunicaciones sobre programas y novedades.</li>
            <li>Analizar métricas de uso y mejorar nuestros contenidos.</li>
          </ul>
        </div>

        <div className={styles.section}>
          <h2>Protección</h2>
          <p>
            Implementamos medidas de seguridad razonables para resguardar tus datos. El acceso está
            limitado al equipo de Selvari y aliados que requieren la información para operar los
            servicios.
          </p>
        </div>

        <div className={styles.section}>
          <h2>Tus derechos</h2>
          <p>
            Puedes solicitar acceso, corrección o eliminación de tus datos enviando un correo a{' '}
            <a href="mailto:hola@selvaritonamira.site">hola@selvaritonamira.site</a>. Responderemos
            dentro de un plazo máximo de 10 días hábiles.
          </p>
        </div>

        <div className={styles.section}>
          <h2>Cambios a esta política</h2>
          <p>
            Nos reservamos el derecho de actualizar esta política. Publicaremos la nueva versión en
            este sitio y te notificaremos por correo cuando sea relevante.
          </p>
        </div>
      </section>
    </>
  );
}

export default PrivacyPolicy;