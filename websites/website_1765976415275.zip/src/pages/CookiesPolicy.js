import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Policy.module.css';

function CookiesPolicy() {
  return (
    <>
      <Helmet>
        <title>Política de Cookies | Selvari&apos;s Insights</title>
        <meta
          name="description"
          content="Política de Cookies de Selvari's Insights. Conoce qué cookies utilizamos y cómo gestionarlas."
        />
      </Helmet>
      <section className={styles.policy}>
        <h1>Política de Cookies</h1>
        <p className={styles.updated}>Última actualización: 5 de marzo de 2024</p>

        <div className={styles.section}>
          <h2>¿Qué son las cookies?</h2>
          <p>
            Las cookies son pequeños archivos de texto que se almacenan en tu dispositivo cuando
            visitas nuestro sitio. Nos ayudan a recordar tus preferencias y mejorar tu experiencia.
          </p>
        </div>

        <div className={styles.section}>
          <h2>Tipos de cookies que usamos</h2>
          <ul>
            <li><strong>Esenciales:</strong> permiten el funcionamiento correcto del sitio.</li>
            <li><strong>Analíticas:</strong> analizan cómo navegas para optimizar contenidos.</li>
            <li><strong>Funcionales:</strong> recuerdan preferencias como idioma o formularios.</li>
          </ul>
        </div>

        <div className={styles.section}>
          <h2>Gestión de cookies</h2>
          <p>
            Puedes aceptar o rechazar cookies directamente en nuestro banner. También puedes
            configurarlas desde la sección de ajustes de tu navegador. Considera que desactivar
            cookies puede afectar ciertas funciones del sitio.
          </p>
        </div>

        <div className={styles.section}>
          <h2>Contacto</h2>
          <p>
            Si tienes preguntas sobre esta política escribe a{' '}
            <a href="mailto:hola@selvaritonamira.site">hola@selvaritonamira.site</a>.
          </p>
        </div>
      </section>
    </>
  );
}

export default CookiesPolicy;