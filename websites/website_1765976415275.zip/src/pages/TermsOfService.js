import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Policy.module.css';

function TermsOfService() {
  return (
    <>
      <Helmet>
        <title>Términos de Servicio | Selvari&apos;s Insights</title>
        <meta
          name="description"
          content="Términos de Servicio de Selvari's Insights. Conoce las condiciones de uso y participación en nuestros programas."
        />
      </Helmet>
      <section className={styles.policy}>
        <h1>Términos de Servicio</h1>
        <p className={styles.updated}>Última actualización: 5 de marzo de 2024</p>

        <div className={styles.section}>
          <h2>1. Aceptación</h2>
          <p>
            Al utilizar el sitio selvaritonamira.site y nuestros recursos asociados aceptas cumplir
            estos Términos. Si no estás de acuerdo con alguna parte, te solicitamos detener el uso
            de los servicios.
          </p>
        </div>

        <div className={styles.section}>
          <h2>2. Servicios</h2>
          <p>
            Selvari&apos;s Insights ofrece programas educativos, sesiones grupales y contenidos
            digitales orientados al bienestar integral. Toda la información es de apoyo y no
            reemplaza la opinión de profesionales médicos particulares.
          </p>
        </div>

        <div className={styles.section}>
          <h2>3. Uso responsable</h2>
          <ul>
            <li>No reproducir ni redistribuir materiales sin autorización.</li>
            <li>Respetar a la comunidad en foros y sesiones grupales.</li>
            <li>Informar cualquier cambio relevante de salud antes de iniciar un programa.</li>
          </ul>
        </div>

        <div className={styles.section}>
          <h2>4. Propiedad intelectual</h2>
          <p>
            Todo el contenido (textos, audios, diseños) pertenece a Selvari&apos;s Insights o a sus
            creadores aliados. La descarga no otorga licencia de uso comercial.
          </p>
        </div>

        <div className={styles.section}>
          <h2>5. Limitación de responsabilidad</h2>
          <p>
            Nos esforzamos por ofrecer información precisa; sin embargo, cada persona es
            responsable de adaptar las recomendaciones a su realidad y consultar a especialistas
            médicos cuando sea necesario.
          </p>
        </div>

        <div className={styles.section}>
          <h2>6. Contacto</h2>
          <p>
            Para dudas sobre estos Términos escribe a{' '}
            <a href="mailto:hola@selvaritonamira.site">hola@selvaritonamira.site</a>.
          </p>
        </div>
      </section>
    </>
  );
}

export default TermsOfService;