import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const featuredInsights = [
  {
    title: 'Ritmos internos y longevidad cotidiana',
    description:
      'Cómo sincronizar tus horarios de comida y descanso con el reloj biológico para mejorar energía y resiliencia.',
    category: 'Guía práctica',
    link: '/guide'
  },
  {
    title: 'Movimiento restaurativo para días intensos',
    description:
      'Secuencia corta de movilidad consciente inspirada en fisioterapia respiratoria mexicana.',
    category: 'Programa destacado',
    link: '/programs'
  },
  {
    title: 'Mindfulness sensorial con sabores locales',
    description:
      'Explora la presencia plena a través de ingredientes veracruzanos y rituales aromáticos sencillos.',
    category: 'Blog',
    link: '/blog'
  }
];

const pillars = [
  {
    name: 'Nutrición viva',
    description:
      'Aprovecha alimentos frescos, hidratación inteligente y ritmos de ayuno que respeten tu estilo de vida mexicano.',
    icon: '🥗'
  },
  {
    name: 'Movimiento consciente',
    description:
      'Combina caminatas urbanas, micro-pausas activas y respiraciones para desbloquear tensión.',
    icon: '🧘'
  },
  {
    name: 'Sueño profundo',
    description:
      'Diseña un ritual nocturno con luz cálida, reflexión escrita y aromas relajantes que faciliten el descanso.',
    icon: '🌙'
  },
  {
    name: 'Calma emocional',
    description:
      'Integra pausas de atención plena y prácticas de gratitud que fortalezcan tu sistema nervioso.',
    icon: '🫶'
  }
];

const testimonials = [
  {
    quote:
      'Las prácticas de Selvari transformaron mis mañanas. Me siento más clara y tranquila antes de iniciar consultorías.',
    name: 'Isabel Cortés',
    role: 'Consultora de impacto social',
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80'
  },
  {
    quote:
      'Me encantó la combinación entre ciencia y sensibilidad cultural. Los programas se sienten hechos para nosotras.',
    name: 'Marcela Durán',
    role: 'Diseñadora culinaria',
    avatar: 'https://images.unsplash.com/photo-1531891437562-4301cf35b7e4?auto=format&fit=crop&w=200&q=80'
  },
  {
    quote:
      'Dormir mejor cambió mi productividad. Los micro-protocolos de respiración son fáciles de seguir y efectivos.',
    name: 'Erik Ramírez',
    role: 'Emprendedor tech',
    avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80'
  }
];

function Home() {
  const [status, setStatus] = useState('');

  const handleNewsletter = (event) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const email = formData.get('email');
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setStatus('Por favor ingresa un correo electrónico válido.');
      return;
    }
    setStatus('¡Gracias por unirte! Pronto recibirás nuestra primera carta de bienestar.');
    event.currentTarget.reset();
  };

  return (
    <>
      <Helmet>
        <title>Selvari&apos;s Insights | Salud y longevidad para México</title>
        <meta
          name="description"
          content="Descubre prácticas de bienestar, longevidad y calma diseñadas para la comunidad mexicana. Guías, programas y herramientas de Selvari's Insights."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroKicker}>Salud guiada - México</p>
          <h1>
            Longevidad consciente para una vida plena, serena y verdaderamente tuya.
          </h1>
          <p className={styles.heroText}>
            Selvari&apos;s Insights acompaña tu camino con prácticas basadas en conocimiento,
            rituales cotidianos y una comunidad que honra la calma. Exploramos ciencia y tradición
            para que cada día se sienta ligero.
          </p>
          <div className={styles.heroActions}>
            <Link to="/guide" className={styles.primaryButton}>
              Explorar la guía esencial
            </Link>
            <Link to="/programs" className={styles.secondaryButton}>
              Ver programas
            </Link>
          </div>
        </div>
        <div className={styles.heroMedia} aria-hidden="true">
          <div className={styles.heroImage} />
        </div>
      </section>

      <section className={styles.featured}>
        <div className={styles.sectionHead}>
          <div>
            <p className={styles.sectionKicker}>Destacados</p>
            <h2>Insights seleccionados para comenzar hoy</h2>
          </div>
          <Link to="/blog" className={styles.linkMore}>
            Visitar el blog completo →
          </Link>
        </div>
        <div className={styles.featuredGrid}>
          {featuredInsights.map((item) => (
            <article key={item.title} className={styles.featuredCard}>
              <span className={styles.cardTag}>{item.category}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <Link to={item.link} className={styles.cardLink}>
                Leer más
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.pillars}>
        <div className={styles.sectionHead}>
          <div>
            <p className={styles.sectionKicker}>Pilares de la longevidad</p>
            <h2>Cuatro bases esenciales para sostener tu energía</h2>
          </div>
        </div>
        <div className={styles.pillarsGrid}>
          {pillars.map((pillar) => (
            <div key={pillar.name} className={styles.pillarCard}>
              <div className={styles.pillarIcon} aria-hidden="true">
                {pillar.icon}
              </div>
              <h3>{pillar.name}</h3>
              <p>{pillar.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHead}>
          <div>
            <p className={styles.sectionKicker}>Testimonios</p>
            <h2>Historias de serenidad y enfoque renovado</h2>
          </div>
        </div>
        <div className={styles.testimonialsGrid}>
          {testimonials.map((testimonial) => (
            <figure key={testimonial.name} className={styles.testimonialCard}>
              <blockquote>“{testimonial.quote}”</blockquote>
              <figcaption>
                <img src={testimonial.avatar} alt={`Retrato de ${testimonial.name}`} />
                <div>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.aboutPreview}>
        <div className={styles.sectionHead}>
          <div>
            <p className={styles.sectionKicker}>Vistazo a &quot;Acerca de&quot;</p>
            <h2>Selvari nació para acompañar tu longevidad con confianza</h2>
          </div>
        </div>
        <div className={styles.aboutContent}>
          <p>
            Nuestro enfoque integra biología, nutrición consciente y herramientas somáticas
            inspiradas en el ritmo de las ciudades mexicanas. Creemos en pequeñas victorias
            diarias que se mantienen en el tiempo.
          </p>
          <Link to="/about" className={styles.primaryLink}>
            Conoce la historia detrás de Selvari →
          </Link>
        </div>
      </section>

      <section className={styles.toolsPreview}>
        <div className={styles.sectionHead}>
          <div>
            <p className={styles.sectionKicker}>Herramientas y Técnicas</p>
            <h2>Instrumentos sencillos para integrar bienestar sin fricción</h2>
          </div>
          <Link to="/tools" className={styles.linkMore}>
            Ver más herramientas →
          </Link>
        </div>
        <div className={styles.toolsRow}>
          <div className={styles.toolCard}>
            <h3>Cuaderno de encuadre nocturno</h3>
            <p>
              Cinco preguntas que alivian la mente antes de dormir. Descárgalo y personalízalo.
            </p>
          </div>
          <div className={styles.toolCard}>
            <h3>Audio de respiración guiada</h3>
            <p>
              Práctica de 6 minutos para resetear tu sistema nervioso entre reuniones.
            </p>
          </div>
          <div className={styles.toolCard}>
            <h3>Mapa de alimentos calmantes</h3>
            <p>
              Ingredientes locales con efectos antiinflamatorios para tu despensa semanal.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.newsletter}>
        <div className={styles.newsletterCard}>
          <div>
            <p className={styles.sectionKicker}>Suscríbete</p>
            <h2>Recibe cartas mensuales con rituales, playlists y prácticas guiadas</h2>
            <p>
              Solo contenido curado por Selvari. Sin spam, sin ruido, solo calma aplicable.
            </p>
          </div>
          <form className={styles.newsletterForm} onSubmit={handleNewsletter}>
            <label htmlFor="email" className="sr-only">
              Correo electrónico
            </label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="tu@email.com"
              required
            />
            <button type="submit">Quiero unirme</button>
          </form>
          {status && <p className={styles.newsletterStatus}>{status}</p>}
        </div>
      </section>
    </>
  );
}

export default Home;