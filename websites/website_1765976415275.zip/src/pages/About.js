import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const milestones = [
  {
    year: '2018',
    title: 'Semillas de Selvari',
    description:
      'Después de años investigando longevidad en Europa, Tonamira regresa a México con el sueño de crear un espacio de educación calmada.'
  },
  {
    year: '2020',
    title: 'Red de especialistas aliados',
    description:
      'Sumamos médicos funcionales, nutriólogas, coaches somáticos y chefs creativos para diseñar experiencias integrales.'
  },
  {
    year: '2023',
    title: 'Nace la Residencia Digital',
    description:
      'Transformamos nuestro acompañamiento a un formato accesible que combina audios, video-sesiones y círculos comunitarios.'
  }
];

function About() {
  return (
    <>
      <Helmet>
        <title>Acerca de Selvari&apos;s Insights</title>
        <meta
          name="description"
          content="Conoce la misión, visión y el equipo humano que impulsa Selvari's Insights. Salud y longevidad con corazón mexicano."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Una casa de conocimiento vivo sobre bienestar y longevidad</h1>
          <p>
            Selvari&apos;s Insights nació como proyecto personal de Tonamira, investigadora de
            longevidad y amante de los rituales cotidianos. Hoy somos un equipo interdisciplinario
            comprometido con acompañarte a diseñar una vida larga, creativa y profundamente humana.
          </p>
        </div>
        <div className={styles.heroImage} aria-hidden="true">
          <img
            src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=80"
            alt="Fundadora de Selvari trabajando"
          />
        </div>
      </section>

      <section className={styles.mission}>
        <div className={styles.missionCard}>
          <h2>Nuestra misión</h2>
          <p>
            Crear experiencias de aprendizaje que inspiren bienestar sostenido, combinando ciencia,
            espiritualidad práctica y cultura mexicana. Buscamos que cada persona se sienta
            acompañada, nunca abrumada.
          </p>
        </div>
        <div className={styles.missionCard}>
          <h2>Nuestra visión</h2>
          <p>
            Ser la referencia en Latinoamérica para educación en longevidad consciente, fomentando
            comunidades resilientes, creativas y llenas de calma.
          </p>
        </div>
      </section>

      <section className={styles.milestones}>
        <h2>Hitos que marcan nuestra historia</h2>
        <div className={styles.timeline}>
          {milestones.map((milestone) => (
            <article key={milestone.year}>
              <span>{milestone.year}</span>
              <h3>{milestone.title}</h3>
              <p>{milestone.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.team}>
        <h2>Equipo corazón</h2>
        <div className={styles.teamGrid}>
          <figure>
            <img
              src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80"
              alt="Retrato de Tonamira Selvari"
            />
            <figcaption>
              <strong>Tonamira Selvari</strong>
              <span>Fundadora y guía en longevidad</span>
            </figcaption>
          </figure>
          <figure>
            <img
              src="https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=600&q=80"
              alt="Retrato de César"
            />
            <figcaption>
              <strong>César Neri</strong>
              <span>Especialista en nutrición intuitiva</span>
            </figcaption>
          </figure>
          <figure>
            <img
              src="https://images.unsplash.com/photo-1525134479668-1bee5c7c6845?auto=format&fit=crop&w=600&q=80"
              alt="Retrato de Andrea"
            />
            <figcaption>
              <strong>Andrea Vives</strong>
              <span>Psicoterapeuta somática</span>
            </figcaption>
          </figure>
        </div>
      </section>
    </>
  );
}

export default About;