document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = siteNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    siteNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        siteNav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const storedPreference = localStorage.getItem('cva-cookie-consent');
    if (!storedPreference) {
      cookieBanner.setAttribute('data-visible', 'true');
    }

    cookieBanner.querySelectorAll('[data-cookie-action]').forEach(button => {
      button.addEventListener('click', () => {
        const action = button.dataset.cookieAction;
        localStorage.setItem('cva-cookie-consent', action);
        cookieBanner.setAttribute('data-visible', 'false');
      });
    });
  }

  const form = document.querySelector('form[data-validate]');
  if (form) {
    const requiredFields = form.querySelectorAll('[data-required]');
    const errorNote = form.querySelector('.form-error-note');

    form.addEventListener('submit', event => {
      let isValid = true;

      requiredFields.forEach(field => {
        const value = field.value.trim();
        if (!value) {
          field.classList.add('has-error');
          field.setAttribute('aria-invalid', 'true');
          isValid = false;
        } else {
          field.classList.remove('has-error');
          field.removeAttribute('aria-invalid');
        }
      });

      const emailField = form.querySelector('input[type="email"]');
      if (emailField) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(emailField.value.trim())) {
          emailField.classList.add('has-error');
          emailField.setAttribute('aria-invalid', 'true');
          isValid = false;
        }
      }

      if (!isValid) {
        event.preventDefault();
        if (errorNote) {
          errorNote.hidden = false;
          errorNote.textContent = 'Please complete the highlighted fields before submitting.';
        }
      }
    });

    requiredFields.forEach(field => {
      field.addEventListener('input', () => {
        if (field.value.trim()) {
          field.classList.remove('has-error');
          field.removeAttribute('aria-invalid');
          if (errorNote) {
            const unresolved = Array.from(requiredFields).some(f => f.classList.contains('has-error'));
            if (!unresolved) {
              errorNote.hidden = true;
            }
          }
        }
      });
    });
  }
});