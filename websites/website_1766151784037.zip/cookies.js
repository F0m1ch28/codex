(function () {
  const selectors = {
    banner: '#cookie-banner',
    accept: '[data-cookie-action="accept"]',
    reject: '[data-cookie-action="reject"]',
    customize: '[data-cookie-action="customize"]',
    form: '#cookie-preferences-form'
  };

  const defaultPrefs = {
    necessary: true,
    analytics: false,
    marketing: false
  };

  const preferenceKey = 'auroraCookiePreferences';

  const getBanner = () => document.querySelector(selectors.banner);

  const parsePrefs = (value) => {
    try {
      return JSON.parse(value);
    } catch (error) {
      console.warn('Invalid cookie preferences found, resetting.', error);
      return null;
    }
  };

  const hideBanner = (banner) => {
    banner.classList.add('hidden');
  };

  const showBanner = (banner) => {
    banner.classList.remove('hidden');
  };

  const updateFormState = (form, prefs) => {
    if (!form) return;
    ['analytics', 'marketing'].forEach((key) => {
      const input = form.querySelector(`input[name="${key}"]`);
      if (input) {
        input.checked = !!prefs[key];
      }
    });
  };

  const persistPreferences = (prefs) => {
    localStorage.setItem(preferenceKey, JSON.stringify({
      ...prefs,
      timestamp: new Date().toISOString()
    }));
    fetch('/api/preferences', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(prefs)
    }).catch((error) => {
      console.warn('Failed to sync preferences', error);
    });
  };

  document.addEventListener('DOMContentLoaded', () => {
    const banner = getBanner();
    if (!banner) return;

    const acceptBtn = banner.querySelector(selectors.accept);
    const rejectBtn = banner.querySelector(selectors.reject);
    const customizeBtn = banner.querySelector(selectors.customize);
    const form = banner.querySelector(selectors.form);

    const savedPrefs = parsePrefs(localStorage.getItem(preferenceKey));

    if (savedPrefs && typeof savedPrefs === 'object') {
      hideBanner(banner);
      updateFormState(form, savedPrefs);
    } else {
      showBanner(banner);
    }

    acceptBtn?.addEventListener('click', () => {
      const preferences = { necessary: true, analytics: true, marketing: true };
      persistPreferences(preferences);
      hideBanner(banner);
    });

    rejectBtn?.addEventListener('click', () => {
      const preferences = { necessary: true, analytics: false, marketing: false };
      persistPreferences(preferences);
      hideBanner(banner);
    });

    customizeBtn?.addEventListener('click', () => {
      form?.classList.toggle('hidden');
      if (!form?.classList.contains('hidden')) {
        const currentPrefs = parsePrefs(localStorage.getItem(preferenceKey)) || defaultPrefs;
        updateFormState(form, currentPrefs);
      }
    });

    form?.addEventListener('submit', (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      const preferences = {
        necessary: true,
        analytics: formData.get('analytics') === 'on',
        marketing: formData.get('marketing') === 'on'
      };
      persistPreferences(preferences);
      hideBanner(banner);
    });
  });
})();