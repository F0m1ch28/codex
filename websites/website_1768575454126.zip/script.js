document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            document.body.classList.toggle('nav-open');
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                document.body.classList.remove('nav-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 1024) {
                document.body.classList.remove('nav-open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('virilernehCookieConsent');

        if (!storedConsent) {
            cookieBanner.classList.add('active');
        } else {
            cookieBanner.classList.add('hidden');
        }

        const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
        const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
        const customizeBtn = cookieBanner.querySelector('[data-cookie-customize]');

        const setConsent = (value) => {
            localStorage.setItem('virilernehCookieConsent', value);
            cookieBanner.classList.remove('active');
            cookieBanner.classList.add('hidden');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => {
                setConsent('accepted');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => {
                setConsent('declined');
            });
        }

        if (customizeBtn) {
            customizeBtn.addEventListener('click', () => {
                window.location.href = 'cookies.html';
            });
        }
    }
});