```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} id="footer">
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.branding}>
            <h3 className={styles.title}>TechSolutions</h3>
            <p className={styles.description}>
              Мы создаём цифровые решения, которые помогают бизнесу развиваться, масштабироваться и оставаться конкурентоспособным в стремительно меняющемся мире технологий.
            </p>
          </div>
          <div className={styles.column}>
            <h4 className={styles.heading}>Навигация</h4>
            <ul className={styles.list}>
              <li><Link to="/" className={styles.link}>Главная</Link></li>
              <li><Link to="/services" className={styles.link}>Услуги</Link></li>
              <li><Link to="/about" className={styles.link}>О компании</Link></li>
              <li><Link to="/contacts" className={styles.link}>Контакты</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4 className={styles.heading}>Юридическая информация</h4>
            <ul className={styles.list}>
              <li><Link to="/terms" className={styles.link}>Условия использования</Link></li>
              <li><Link to="/privacy" className={styles.link}>Политика конфиденциальности</Link></li>
              <li><Link to="/cookie-policy" className={styles.link}>Политика cookie</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4 className={styles.heading}>Контакты</h4>
            <ul className={styles.list}>
              <li>ул. Программистов, 15, офис 304</li>
              <li>Москва, Россия, 123456</li>
              <li><a className={styles.link} href="tel:+74951234567">+7 (495) 123-45-67</a></li>
              <li><a className={styles.link} href="mailto:info@techsolutions.ru">info@techsolutions.ru</a></li>
            </ul>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>© {new Date().getFullYear()} TechSolutions. Все права защищены.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
```