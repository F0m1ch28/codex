```javascript
import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('techsolutions_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('techsolutions_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('techsolutions_cookie_consent', 'declined');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Мы используем cookie-файлы для улучшения работы сайта и персонализации сервисов. Продолжая использование сайта, вы соглашаетесь с{' '}
          <a href="/cookie-policy" className={styles.link}>
            политикой cookie
          </a>.
        </p>
        <div className={styles.actions}>
          <button type="button" className="btn btn-light" onClick={handleDecline}>
            Отклонить
          </button>
          <button type="button" className="btn btn-primary" onClick={handleAccept}>
            Принять
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;
```