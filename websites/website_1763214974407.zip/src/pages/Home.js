```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  return (
    <>
      <Helmet>
        <title>TechSolutions — IT-консалтинг и разработка программного обеспечения</title>
        <meta
          name="description"
          content="TechSolutions — команда экспертов в IT-консалтинге, разработке веб- и мобильных приложений. Ускоряем цифровую трансформацию бизнеса любой сложности."
        />
        <meta
          name="keywords"
          content="IT-консалтинг, разработка программного обеспечения, цифровая трансформация, веб-приложения, мобильные приложения, TechSolutions"
        />
        <meta property="og:title" content="TechSolutions — IT-консалтинг и разработка ПО" />
        <meta
          property="og:description"
          content="Комплексные цифровые решения: аудит, консалтинг, дизайн и разработка веб и мобильных приложений."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.techsolutions.ru/" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=11" />
      </Helmet>

      <section className={`${styles.hero} section`}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div className={styles.heroContent}>
              <span className={styles.heroTag}>Цифровая трансформация</span>
              <h1 className={styles.heroTitle}>
                TechSolutions — Ваш надежный партнёр в мире технологий
              </h1>
              <p className={styles.heroSubtitle}>
                Мы объединяем стратегический IT-консалтинг, дизайн процессов и разработку высоконагруженных цифровых продуктов, чтобы помочь вашему бизнесу расти и опережать конкурентов.
              </p>
              <div className={styles.heroActions}>
                <Link to="/contacts" className="btn btn-primary">
                  Обсудить проект
                </Link>
                <Link to="/services" className="btn btn-outline">
                  Посмотреть услуги
                </Link>
              </div>
              <ul className={styles.heroHighlights}>
                <li>15+ лет отраслевого опыта</li>
                <li>120+ реализованных проектов</li>
                <li>Партнёрство с международными компаниями</li>
              </ul>
            </div>
            <div className={styles.heroVisual}>
              <img
                src="https://picsum.photos/640/520?random=21"
                alt="Команда TechSolutions за работой над цифровым продуктом"
                className={styles.heroImage}
              />
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Ключевые направления</h2>
            <p className="sectionSubtitle">
              Мы помогаем компаниям переосмыслить процессы, внедрить инновации и масштабировать цифровые решения.
            </p>
          </div>
          <div className={styles.cards}>
            <article className={styles.card}>
              <h3>IT-консалтинг</h3>
              <p>
                Глубокий аудит, цифровая стратегия, оптимизация IT-ландшафта и Roadmap развития технологий. Помогаем выстроить устойчивую архитектуру и управлять рисками.
              </p>
              <Link to="/services" className={styles.cardLink}>
                Узнать больше →
              </Link>
            </article>
            <article className={styles.card}>
              <h3>Разработка веб-приложений</h3>
              <p>
                Создаём высоконадежные веб-платформы, клиентские порталы и ERP-системы, которые выдерживают масштабирование и критические нагрузки.
              </p>
              <Link to="/services" className={styles.cardLink}>
                Узнать больше →
              </Link>
            </article>
            <article className={styles.card}>
              <h3>Мобильные решения</h3>
              <p>
                Проектируем и разрабатываем мобильные приложения с нативным опытом, интеграцией с backend-сервисами и аналитикой поведения пользователей.
              </p>
              <Link to="/services" className={styles.cardLink}>
                Узнать больше →
              </Link>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.highlightSection} section`}>
        <div className="container">
          <div className={styles.highlightGrid}>
            <div className={styles.highlightContent}>
              <h2 className="sectionTitle">Почему выбирают TechSolutions</h2>
              <p className="sectionSubtitle">
                Мы объединяем консалтинговую экспертизу и инженерное мастерство. Каждый проект — это прозрачность, гибкость и измеримый результат.
              </p>
              <div className={styles.stats}>
                <div>
                  <span className={styles.statValue}>98%</span>
                  <span className={styles.statLabel}>Удовлетворенность клиентов</span>
                </div>
                <div>
                  <span className={styles.statValue}>24/7</span>
                  <span className={styles.statLabel}>Техническая поддержка</span>
                </div>
                <div>
                  <span className={styles.statValue}>30%</span>
                  <span className={styles.statLabel}>Средний рост эффективности</span>
                </div>
              </div>
            </div>
            <div className={styles.highlightPanel}>
              <h3>Наш подход</h3>
              <ul>
                <li>
                  <strong>Понимание бизнеса.</strong> Выявляем ключевые цели, ограничения и ожидания стейкхолдеров.
                </li>
                <li>
                  <strong>Проектирование экосистемы.</strong> Создаём архитектуру решений с учётом масштабирования и безопасности.
                </li>
                <li>
                  <strong>Итеративная разработка.</strong> Agile-подход с чёткими спринтами и регулярными демонстрациями.
                </li>
                <li>
                  <strong>Поддержка и развитие.</strong> Обучаем команды, сопровождаем внедрение и предлагаем Proactive Support.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Нам доверяют</h2>
            <p className="sectionSubtitle">
              Крупные корпорации и динамичные стартапы — мы помогаем компаниям разных масштабов достигать амбициозных целей.
            </p>
          </div>
          <div className={styles.testimonials}>
            <figure className={styles.testimonial}>
              <blockquote>
                «TechSolutions сопровождал нас от фазы концепции до промышленной эксплуатации. Их экспертиза в масштабируемых архитектурах помогла нам ускорить time-to-market на 45%.»
              </blockquote>
              <figcaption>Анна Смирнова, директор по цифровой трансформации, GlobalRetail</figcaption>
            </figure>
            <figure className={styles.testimonial}>
              <blockquote>
                «Команда нашла баланс между бизнес-задачами и инженерной реализацией. Продукт стабильно работает при многократном росте пользователей.»
              </blockquote>
              <figcaption>Дмитрий Орлов, CEO, FinTech Dynamics</figcaption>
            </figure>
          </div>
        </div>
      </section>

      <section className={`${styles.ctaSection} section`}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Готовы к цифровому прорыву?</h2>
            <p>
              Давайте обсудим вашу стратегию и найдем оптимальный путь к трансформации. Мы предложим решения, которые обеспечат устойчивый рост.
            </p>
            <Link to="/contacts" className="btn btn-light">
              Связаться с командой
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
```