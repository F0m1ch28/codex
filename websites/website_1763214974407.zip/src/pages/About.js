```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  return (
    <>
      <Helmet>
        <title>О компании TechSolutions — История, миссия и команда</title>
        <meta
          name="description"
          content="Узнайте о миссии и ценностях TechSolutions. Более 15 лет создаем цифровые решения для бизнеса, объединяя стратегию, инженерию и человеческий подход."
        />
        <meta
          name="keywords"
          content="TechSolutions, о компании, команда, миссия, ценности, IT-консалтинг"
        />
        <meta property="og:title" content="О компании TechSolutions" />
        <meta
          property="og:description"
          content="TechSolutions — команда экспертов, объединенная миссией создавать устойчивые цифровые решения для бизнеса."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.techsolutions.ru/about" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=13" />
      </Helmet>

      <section className="section">
        <div className="container">
          <div className={styles.intro}>
            <h1 className="sectionTitle">TechSolutions — технологии, создающие возможности</h1>
            <p className="sectionSubtitle">
              Мы помогаем компаниям адаптироваться к цифровой реальности, внедрять инновации и создавать цифровые экосистемы, которые масштабируются вместе с бизнесом.
            </p>
          </div>
          <div className={styles.storyGrid}>
            <img
              src="https://picsum.photos/720/480?random=41"
              alt="Совместная работа команды TechSolutions над проектом"
              className={styles.storyImage}
            />
            <div className={styles.storyContent}>
              <h2>История и путь</h2>
              <p>
                TechSolutions появилась как объединение экспертов из консалтинга, продуктовой разработки и enterprise-инженерии. С самого начала мы сосредоточились на том, чтобы превращать технологические вызовы в возможности роста.
              </p>
              <p>
                За последние 15 лет мы прошли путь от небольшой команды до международной компании с проектами в России, Европе и на Ближнем Востоке. Наши решения работают в финансовом секторе, ритейле, телекоммуникациях и промышленности.
              </p>
              <p>
                Сегодня TechSolutions — это экосистема экспертов, которые одинаково ценят стратегию, технологическое мастерство и человеческие отношения.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.missionSection} section`}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div className={styles.missionCard}>
              <h3>Миссия</h3>
              <p>
                Мы создаём цифровые решения, которые помогают компаниям строить устойчивое будущее, опираясь на инновации, данные и ответственность.
              </p>
            </div>
            <div className={styles.missionCard}>
              <h3>Ценности</h3>
              <ul>
                <li><strong>Партнёрство.</strong> Мы строим долгосрочные отношения и разделяем ответственность за результат.</li>
                <li><strong>Инновации.</strong> Постоянно исследуем новые подходы и технологии, чтобы предлагать лучшее.</li>
                <li><strong>Прозрачность.</strong> Открыты в коммуникациях, прогнозах и оценке рисков.</li>
                <li><strong>Уважение.</strong> Ценим людей и создаём безопасную среду для развития команд.</li>
              </ul>
            </div>
            <div className={styles.missionCard}>
              <h3>Социальная ответственность</h3>
              <p>
                Мы поддерживаем образовательные инициативы, развиваем молодые таланты и внедряем экологичные подходы в инфраструктуру и процессы.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="sectionTitle">Ключевые этапы развития</h2>
          <div className={styles.timeline}>
            <div className={styles.timelineItem}>
              <span className={styles.timelineYear}>2009</span>
              <div>
                <h3>Основание компании</h3>
                <p>Команда инженеров и консультантов объединяется для реализации первых проектов в финансовой сфере.</p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.timelineYear}>2014</span>
              <div>
                <h3>Международные проекты</h3>
                <p>Выходим на зарубежные рынки, запускаем крупнейший проект по цифровизации ритейла в Восточной Европе.</p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.timelineYear}>2018</span>
              <div>
                <h3>Собственный R&D центр</h3>
                <p>Создаем лабораторию инноваций, фокусируемся на data science, IoT и автоматизации бизнес-процессов.</p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <span className={styles.timelineYear}>2023</span>
              <div>
                <h3>Расширение портфеля</h3>
                <p>Укрепляем практики кибербезопасности, сертифицируем DevOps-процессы, усиливаем команды поддержки 24/7.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.teamSection} section`}>
        <div className="container">
          <div className={styles.teamHeader}>
            <h2 className="sectionTitle">Наша команда</h2>
            <p className="sectionSubtitle">
              В TechSolutions работают эксперты с опытом в международных компаниях, стартапах и консалтинге. Мы ценим многогранность компетенций и энергию командной работы.
            </p>
          </div>
          <div className={styles.teamGrid}>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/360/360?random=51"
                alt="Елена Власова — операционный директор TechSolutions"
              />
              <h3>Елена Власова</h3>
              <span>Операционный директор</span>
              <p>
                Отвечает за создание устойчивых процессов и развитие партнерских отношений. Более 12 лет опыта в управлении крупными IT-проектами.
              </p>
            </article>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/360/360?random=52"
                alt="Игорь Колесников — директор по инженерии TechSolutions"
              />
              <h3>Игорь Колесников</h3>
              <span>Директор по инженерии</span>
              <p>
                Руководит архитектурой и технической стратегией, компетенции в cloud-native, микросервисах и построении DevOps-культур.
              </p>
            </article>
            <article className={styles.teamCard}>
              <img
                src="https://picsum.photos/360/360?random=53"
                alt="Алина Чернова — руководитель практики цифрового консалтинга TechSolutions"
              />
              <h3>Алина Чернова</h3>
              <span>Руководитель цифрового консалтинга</span>
              <p>
                Помогает клиентам трансформировать бизнес-модели и процессы. Ведет стратегические проекты в ритейле и телеком-секторе.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;
```