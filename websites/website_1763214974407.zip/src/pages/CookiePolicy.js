```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Политика cookie — TechSolutions</title>
      <meta
        name="description"
        content="Политика использования cookie-файлов на сайте TechSolutions. Узнайте, какие cookie мы применяем и как управлять настройками."
      />
      <meta
        name="keywords"
        content="cookie, политика cookie, TechSolutions, файлы cookie"
      />
      <meta property="og:title" content="Политика cookie TechSolutions" />
      <meta
        property="og:description"
        content="Информация о cookie-файлах, используется на сайте TechSolutions."
      />
      <meta property="og:type" content="website" />
      <meta property="og:url" content="https://www.techsolutions.ru/cookie-policy" />
      <meta property="og:image" content="https://picsum.photos/1200/630?random=17" />
    </Helmet>

    <section className="section">
      <div className="container">
        <div className={styles.legal}>
          <h1>Политика cookie</h1>
          <p className={styles.updated}>Последнее обновление: 10 января 2024 года</p>

          <p>
            Настоящая Политика cookie объясняет, какие cookie-файлы использует ООО «ТехСолюшнс» на Сайте, с какой целью и как ими управлять.
          </p>

          <h2>1. Что такое cookie</h2>
          <p>
            Cookie — это небольшие текстовые файлы, которые сохраняются на устройстве пользователя при посещении Сайта. Они помогают распознавать ваше устройство, запоминать настройки и улучшать взаимодействие.
          </p>

          <h2>2. Типы cookie, которые мы используем</h2>
          <ul>
            <li>
              <strong>Обязательные cookie.</strong> Необходимы для работы Сайта. Без них функциональность может быть ограничена.
            </li>
            <li>
              <strong>Функциональные cookie.</strong> Запоминают ваши предпочтения (язык, форма, заполненные поля), помогают повысить удобство.
            </li>
            <li>
              <strong>Аналитические cookie.</strong> Сбор обезличенной статистики о посещениях и поведении пользователей для улучшения Сайта.
            </li>
            <li>
              <strong>Маркетинговые cookie.</strong> Используются для отображения релевантной информации о наших услугах. Применяются только при наличии согласия.
            </li>
          </ul>

          <h2>3. Срок хранения cookie</h2>
          <p>
            Cookie могут храниться в течение сеанса (стираются после закрытия браузера) или сохраняться на устройстве до тех пор, пока не будут удалены вручную либо автоматически по истечении срока хранения.
          </p>

          <h2>4. Управление cookie</h2>
          <p>
            Вы можете изменить настройки cookie в браузере или воспользоваться баннером согласия на Сайте. Обратите внимание, что отключение некоторых cookie может повлиять на корректность работы отдельных функций.
          </p>

          <h2>5. Сторонние cookie</h2>
          <p>
            Мы можем использовать сервисы аналитики и маркетинга третьих лиц. Такие сервисы могут размещать собственные cookie. Рекомендуем ознакомиться с их политикой конфиденциальности.
          </p>

          <h2>6. Обновления политики</h2>
          <p>
            Мы время от времени пересматриваем Политику cookie, чтобы отразить изменения в технологиях и законодательстве. Актуальная версия доступна на Сайте.
          </p>

          <h2>7. Контакты</h2>
          <p>
            Если у вас есть вопросы по использованию cookie, свяжитесь с нами:<br />
            Email: info@techsolutions.ru<br />
            Телефон: +7 (495) 123-45-67
          </p>
        </div>
      </div>
    </section>
  </>
);

export default CookiePolicy;
```