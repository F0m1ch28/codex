```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Услуги TechSolutions — IT-консалтинг и разработка цифровых решений</title>
        <meta
          name="description"
          content="Комплексные услуги TechSolutions: стратегический IT-консалтинг, разработка веб- и мобильных приложений, интеграции и поддержка цифровых продуктов."
        />
        <meta
          name="keywords"
          content="услуги IT-консалтинга, разработка веб-приложений, мобильные приложения, интеграция систем, аудит IT, TechSolutions"
        />
        <meta property="og:title" content="Услуги TechSolutions" />
        <meta
          property="og:description"
          content="От стратегии до внедрения — TechSolutions помогает компаниям выстраивать современные цифровые решения."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.techsolutions.ru/services" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=12" />
      </Helmet>

      <section className="section">
        <div className="container">
          <div className={styles.header}>
            <h1 className="sectionTitle">Комплексные услуги TechSolutions</h1>
            <p className="sectionSubtitle">
              Мы сопровождаем цифровые инициативы на всех этапах: от идеи и стратегии до масштабирования и поддержки. Наши эксперты обеспечивают предсказуемый результат и высокое качество решений.
            </p>
          </div>

          <div className={styles.serviceGroup}>
            <div className={styles.serviceCard}>
              <div className={styles.serviceImageWrapper}>
                <img
                  src="https://picsum.photos/560/360?random=31"
                  alt="IT-консультанты анализируют стратегию цифровой трансформации"
                />
              </div>
              <div className={styles.serviceContent}>
                <h2>Стратегический IT-консалтинг</h2>
                <p>
                  Мы выстраиваем долгосрочную digital-стратегию, которая отвечает бизнес-целям и учитывает отраслевые тренды. Помогаем оптимизировать IT-ландшафт, оценить зрелость процессов и сформировать дорожную карту развития.
                </p>
                <ul>
                  <li>Аудит IT-инфраструктуры и бизнес-процессов</li>
                  <li>Разработка цифровой стратегии и Roadmap</li>
                  <li>Архитектурное проектирование и Enterprise Architecture</li>
                  <li>Управление изменениями и обучение команд</li>
                </ul>
              </div>
            </div>

            <div className={styles.serviceCard}>
              <div className={styles.serviceImageWrapper}>
                <img
                  src="https://picsum.photos/560/360?random=32"
                  alt="Разработка веб-приложений для корпоративного клиента"
                />
              </div>
              <div className={styles.serviceContent}>
                <h2>Разработка веб-приложений</h2>
                <p>
                  Создаём веб-платформы, рассчитанные на высокие нагрузки и интеграцию с корпоративными системами. Применяем микросервисную архитектуру, облачные технологии и DevOps-практики для устойчивости и масштабируемости.
                </p>
                <ul>
                  <li>Порталы для клиентов и партнеров, B2B-платформы</li>
                  <li>Корпоративные системы, аналитические панели, ERP</li>
                  <li>Интеграция с CRM, API, внутренними сервисами</li>
                  <li>Автоматизация CI/CD, непрерывное тестирование</li>
                </ul>
              </div>
            </div>

            <div className={styles.serviceCard}>
              <div className={styles.serviceImageWrapper}>
                <img
                  src="https://picsum.photos/560/360?random=33"
                  alt="Создание интерфейсов мобильного приложения командой разработчиков"
                />
              </div>
              <div className={styles.serviceContent}>
                <h2>Мобильные приложения</h2>
                <p>
                  Проектируем и разрабатываем мобильные приложения для iOS и Android с акцентом на UX, безопасность и надежность. Обеспечиваем полный цикл: от исследований и прототипирования до релиза и аналитики.
                </p>
                <ul>
                  <li>Нативные и кроссплатформенные решения</li>
                  <li>UX/UI дизайн, тестирование сценариев взаимодействия</li>
                  <li>Интеграция с backend, push-уведомления, аналитика</li>
                  <li>Поддержка, развитие, внедрение новых фич</li>
                </ul>
              </div>
            </div>

            <div className={styles.serviceCard}>
              <div className={styles.serviceImageWrapper}>
                <img
                  src="https://picsum.photos/560/360?random=34"
                  alt="Команда DevOps специалистов оптимизирует инфраструктуру"
                />
              </div>
              <div className={styles.serviceContent}>
                <h2>Интеграции и сопровождение</h2>
                <p>
                  Обеспечиваем стабильную работу продуктов после запуска: мониторинг, надежность, масштабирование и непрерывные улучшения. Настраиваем экосистему для гибкого развития.
                </p>
                <ul>
                  <li>Интеграция с облачными сервисами и внутренними системами</li>
                  <li>DevOps, автоматизация инфраструктуры, SRE-подход</li>
                  <li>Мониторинг, SLA, техподдержка 24/7</li>
                  <li>Проактивное развитие и выявление возможностей роста</li>
                </ul>
              </div>
            </div>
          </div>

          <section className={styles.processSection}>
            <h2>Как мы работаем</h2>
            <div className={styles.processGrid}>
              <div className={styles.processStep}>
                <span className={styles.stepNumber}>01</span>
                <h3>Диагностика и исследование</h3>
                <p>
                  Анализируем текущую ситуацию, определяем цели и KPI, проводим воркшопы с ключевыми стейкхолдерами, формируем гипотезы и план экспериментов.
                </p>
              </div>
              <div className={styles.processStep}>
                <span className={styles.stepNumber}>02</span>
                <h3>Дизайн решений</h3>
                <p>
                  Проектируем UX, архитектуру, технологический стек и модель данных. Создаём прототипы и тестируем сценарии, валидируем предположения с пользователями.
                </p>
              </div>
              <div className={styles.processStep}>
                <span className={styles.stepNumber}>03</span>
                <h3>Реализация и интеграция</h3>
                <p>
                  Agile-команды разработки запускают спринты, внедряют CI/CD, обеспечивают качество через автоматизированное тестирование и код-ревью.
                </p>
              </div>
              <div className={styles.processStep}>
                <span className={styles.stepNumber}>04</span>
                <h3>Запуск и развитие</h3>
                <p>
                  Поддерживаем запуск, проводим обучение и передачу знаний, настраиваем метрики, обеспечиваем сопровождение и масштабирование решений.
                </p>
              </div>
            </div>
          </section>
        </div>
      </section>
    </>
  );
};

export default Services;
```