```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  phone: '',
  message: ''
};

const Contact = () => {
  const [form, setForm] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Пожалуйста, укажите ваше имя.';
    if (!form.email.trim()) {
      newErrors.email = 'Укажите email для связи.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(form.email)) {
      newErrors.email = 'Введите корректный email.';
    }
    if (form.phone && !/^\+?[0-9()\s-]{7,20}$/i.test(form.phone)) {
      newErrors.phone = 'Введите корректный номер телефона.';
    }
    if (!form.message.trim()) newErrors.message = 'Расскажите подробнее о вашей задаче.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({
      ...prev,
      [name]: value
    }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      setSubmitted(true);
      setForm(initialFormState);
    }
  };

  return (
    <>
      <Helmet>
        <title>Контакты TechSolutions — Связаться с нами</title>
        <meta
          name="description"
          content="Свяжитесь с командой TechSolutions: офис в Москве, телефон, email. Оставьте заявку, чтобы обсудить ваш цифровой проект."
        />
        <meta
          name="keywords"
          content="контакты TechSolutions, IT-консалтинг, цифровые решения, обратная связь"
        />
        <meta property="og:title" content="Контакты TechSolutions" />
        <meta
          property="og:description"
          content="Оставьте заявку или посетите офис TechSolutions в Москве. Мы ответим в течение одного рабочего дня."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.techsolutions.ru/contacts" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=14" />
      </Helmet>

      <section className="section">
        <div className="container">
          <div className={styles.header}>
            <h1 className="sectionTitle">Свяжитесь с нами</h1>
            <p className="sectionSubtitle">
              Расскажите о своих задачах — мы предложим подход, технологию и команду. Отвечаем на запросы в течение одного рабочего дня.
            </p>
          </div>

          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Имя *</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  placeholder="Иван Иванов"
                  value={form.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                />
                {errors.name && (
                  <span className={styles.error} id="name-error">
                    {errors.name}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Email *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="name@company.ru"
                  value={form.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                />
                {errors.email && (
                  <span className={styles.error} id="email-error">
                    {errors.email}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="phone">Телефон</label>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  placeholder="+7 (495) 123-45-67"
                  value={form.phone}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.phone)}
                  aria-describedby={errors.phone ? 'phone-error' : undefined}
                />
                {errors.phone && (
                  <span className={styles.error} id="phone-error">
                    {errors.phone}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Сообщение *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  placeholder="Опишите ваш проект или вопрос"
                  value={form.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                ></textarea>
                {errors.message && (
                  <span className={styles.error} id="message-error">
                    {errors.message}
                  </span>
                )}
              </div>
              <p className={styles.policy}>
                Отправляя форму, вы соглашаетесь с{' '}
                <a href="/privacy">политикой конфиденциальности</a>.
              </p>
              <button type="submit" className="btn btn-primary">
                Отправить запрос
              </button>
              {submitted && (
                <div className={styles.success}>
                  Спасибо! Ваша заявка отправлена. Мы свяжемся с вами в ближайшее время.
                </div>
              )}
            </form>

            <div className={styles.info}>
              <div className={styles.contactCard}>
                <h2>Наш офис</h2>
                <p>
                  ул. Программистов, 15, офис 304<br />
                  Москва, Россия, 123456
                </p>
                <p>
                  <strong>Телефон:</strong>{' '}
                  <a href="tel:+74951234567">+7 (495) 123-45-67</a><br />
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@techsolutions.ru">info@techsolutions.ru</a>
                </p>
                <p>
                  <strong>Часы работы:</strong><br />
                  Пн–Пт: 9:00 — 19:00<br />
                  Сб–Вс: по предварительной записи
                </p>
              </div>
              <div className={styles.mapWrapper}>
                <iframe
                  title="TechSolutions на карте"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.7713180111594!2d37.6203930160986!3d55.75396098055201!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2z0JDQstGC0L7RgdC40YTQtdCy0L3Ri9C5INCY0LjQutGD0YDQvdCw!5e0!3m2!1sru!2sru!4v1700000000000!5m2!1sru!2sru"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  allowFullScreen
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;
```