document.addEventListener("DOMContentLoaded", () => {
  const cookieBanner = document.getElementById("cookie-banner");
  const acceptButton = document.getElementById("cookie-accept");
  const declineButton = document.getElementById("cookie-decline");
  const consentKey = "hscCookieConsent";

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      cookieBanner.classList.add("active");
    }

    const setConsent = (value) => {
      localStorage.setItem(consentKey, value);
      cookieBanner.classList.remove("active");
      cookieBanner.setAttribute("aria-hidden", "true");
    };

    if (acceptButton) {
      acceptButton.addEventListener("click", () => setConsent("accepted"));
    }

    if (declineButton) {
      declineButton.addEventListener("click", () => setConsent("declined"));
    }
  }

  const contactForm = document.getElementById("contact-form");
  if (contactForm) {
    const alertBox = document.getElementById("form-alert");

    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      if (alertBox) {
        alertBox.textContent = "";
      }

      const nameInput = contactForm.querySelector('input[name="name"]');
      const emailInput = contactForm.querySelector('input[name="email"]');
      const orgInput = contactForm.querySelector('input[name="organization"]');
      const topicInput = contactForm.querySelector('select[name="topic"]');
      const messageInput = contactForm.querySelector('textarea[name="message"]');

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
      const inputsValid =
        nameInput.value.trim().length > 1 &&
        orgInput.value.trim().length > 1 &&
        messageInput.value.trim().length > 5 &&
        topicInput.value.trim().length > 0 &&
        emailPattern.test(emailInput.value.trim());

      if (!inputsValid) {
        if (alertBox) {
          alertBox.textContent = "Please confirm every field before sending.";
        }
        return;
      }

      contactForm.reset();
      window.location.href = "thanks.html";
    });
  }
});