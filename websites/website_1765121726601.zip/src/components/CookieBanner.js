import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedConsent = typeof window !== 'undefined' ? localStorage.getItem('cookieConsent') : null;
    if (storedConsent === 'accepted') {
      setIsVisible(false);
    } else {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('cookieConsent', 'accepted');
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о cookies">
      <p className={styles.text}>
        Мы используем файлы cookie, чтобы сайт работал корректно и помогал вам быстрее находить нужную информацию. Продолжая работу с сайтом, вы соглашаетесь с нашей{' '}
        <Link to="/politika-cookie" className={styles.link}>
          политикой использования cookie
        </Link>
        .
      </p>
      <div className={styles.buttons}>
        <button type="button" className={styles.button} onClick={handleAccept}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;