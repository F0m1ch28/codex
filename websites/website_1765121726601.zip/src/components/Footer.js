import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.top}>
      <div className={styles.brand}>
        <span className={styles.brandName}>Альфа Тех Консалтинг</span>
        <p className={styles.brandDescription}>
          Мы помогаем компаниям из России и стран СНГ ускорять цифровую трансформацию, создавая устойчивые ИТ-решения и внедряя инновации, которые увеличивают эффективность и рост.
        </p>
      </div>
      <div>
        <p className={styles.columnTitle}>Навигация</p>
        <ul className={styles.linkList}>
          <li>
            <Link to="/" className={styles.link}>
              Главная
            </Link>
          </li>
          <li>
            <Link to="/uslugi" className={styles.link}>
              Услуги
            </Link>
          </li>
          <li>
            <Link to="/o-kompanii" className={styles.link}>
              О компании
            </Link>
          </li>
          <li>
            <Link to="/kontakty" className={styles.link}>
              Контакты
            </Link>
          </li>
        </ul>
      </div>
      <div>
        <p className={styles.columnTitle}>Контакты</p>
        <div className={styles.contactItem}>
          <span>Адрес:</span>
          <span>Россия, Москва, ул. Тверская, д. 15, офис 402</span>
        </div>
        <div className={styles.contactItem}>
          <span>Телефон:</span>
          <a className={styles.link} href="tel:+74951234567">
            +7 (495) 123-45-67
          </a>
        </div>
        <div className={styles.contactItem}>
          <span>Email:</span>
          <a className={styles.link} href="mailto:info@alfatech.ru">
            info@alfatech.ru
          </a>
        </div>
      </div>
      <div>
        <p className={styles.columnTitle}>Документы</p>
        <ul className={styles.linkList}>
          <li>
            <Link to="/politika-konfidencialnosti" className={styles.link}>
              Политика конфиденциальности
            </Link>
          </li>
          <li>
            <Link to="/usloviya-ispolzovaniya" className={styles.link}>
              Условия использования
            </Link>
          </li>
          <li>
            <Link to="/politika-cookie" className={styles.link}>
              Политика использования файлов cookie
            </Link>
          </li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <span>© {new Date().getFullYear()} Альфа Тех Консалтинг. Все права защищены.</span>
      <div className={styles.bottomLinks}>
        <span>Ключевые слова: IT консалтинг, цифровая трансформация, внедрение ERP, аудит IT инфраструктуры, ИТ стратегия</span>
      </div>
    </div>
  </footer>
);

export default Footer;