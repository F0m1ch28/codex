import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleToggle = () => {
    setIsMobileMenuOpen((prev) => !prev);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`} aria-label="Основная навигация">
      <div className={styles.inner}>
        <div className={styles.brand}>
          <NavLink to="/" className={styles.logo} onClick={closeMobileMenu}>
            Альфа Тех Консалтинг
          </NavLink>
          <span className={styles.tagline}>ИТ-консалтинг | Россия, Москва</span>
        </div>
        <nav className={styles.nav}>
          <ul className={styles.navList}>
            <li>
              <NavLink
                to="/"
                className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
                onClick={closeMobileMenu}
              >
                Главная
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/uslugi"
                className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
                onClick={closeMobileMenu}
              >
                Услуги
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/o-kompanii"
                className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
                onClick={closeMobileMenu}
              >
                О компании
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/kontakty"
                className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
                onClick={closeMobileMenu}
              >
                Контакты
              </NavLink>
            </li>
          </ul>
          <button
            type="button"
            className={`${styles.mobileToggle} ${isMobileMenuOpen ? styles.mobileToggleActive : ''}`}
            aria-label="Переключить навигацию"
            aria-expanded={isMobileMenuOpen}
            onClick={handleToggle}
          >
            <span className={styles.mobileToggleIcon} aria-hidden="true" />
          </button>
        </nav>
      </div>
      {isMobileMenuOpen && (
        <div className={styles.mobileMenu}>
          <NavLink
            to="/"
            className={({ isActive }) => `${styles.mobileLink} ${isActive ? styles.active : ''}`}
            onClick={closeMobileMenu}
          >
            Главная
          </NavLink>
          <NavLink
            to="/uslugi"
            className={({ isActive }) => `${styles.mobileLink} ${isActive ? styles.active : ''}`}
            onClick={closeMobileMenu}
          >
            Услуги
          </NavLink>
          <NavLink
            to="/o-kompanii"
            className={({ isActive }) => `${styles.mobileLink} ${isActive ? styles.active : ''}`}
            onClick={closeMobileMenu}
          >
            О компании
          </NavLink>
          <NavLink
            to="/kontakty"
            className={({ isActive }) => `${styles.mobileLink} ${isActive ? styles.active : ''}`}
            onClick={closeMobileMenu}
          >
            Контакты
          </NavLink>
        </div>
      )}
    </header>
  );
};

export default Header;