import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Home.module.css';

const statsTargetData = [
  { label: 'Реализованных проектов', value: 120, suffix: '+' },
  { label: 'Экспертов в команде', value: 45, suffix: '' },
  { label: 'Средний рост эффективности', value: 38, suffix: '%' },
  { label: 'Городов присутствия', value: 12, suffix: '' },
];

const servicesData = [
  {
    title: 'Стратегия цифровой трансформации',
    description: 'Формируем реалистичную дорожную карту развития ИТ-ландшафта, ориентируясь на цели бизнеса и отраслевые тренды.',
    icon: '🧭',
    link: '/uslugi#strategiya',
  },
  {
    title: 'Внедрение ERP и CRM',
    description: 'Выбираем и адаптируем платформы SAP, 1C, Microsoft Dynamics и отечественные решения под ваши процессы и команды.',
    icon: '⚙️',
    link: '/uslugi#erp',
  },
  {
    title: 'Аналитика и BI',
    description: 'Настраиваем сквозную аналитику, создаем BI-дашборды и обучаем сотрудников работать с данными ежедневно.',
    icon: '📊',
    link: '/uslugi#bi',
  },
  {
    title: 'Кибербезопасность и аудит',
    description: 'Оцениваем зрелость защиты, устраняем уязвимости и строим процессы кибербезопасности на основе лучших практик.',
    icon: '🛡️',
    link: '/uslugi#security',
  },
];

const advantagesData = [
  '15 лет опыта работы с промышленностью, логистикой и финансовым сектором.',
  'Комплексные проекты от стратегии до сопровождения и поддержки.',
  'Сильная команда аналитиков, архитекторов, разработчиков и управляющих проектами.',
  'Прозрачная коммуникация и контроль метрик эффективности на каждом этапе.',
  'Строгое соблюдение стандартов информационной безопасности и законодательства РФ.',
  'Экспертное знание рынка отечественного и импортонезависимого ПО.',
];

const processStepsData = [
  {
    title: 'Диагностика и интервью',
    description:
      'Изучаем текущие процессы, опрашиваем ключевых стейкхолдеров и фиксируем проблемы, которые мешают росту.',
  },
  {
    title: 'Проектирование и выбор решений',
    description:
      'Сравниваем альтернативы, рассчитываем экономический эффект и формируем архитектурную модель будущей системы.',
  },
  {
    title: 'Пилот и внедрение',
    description:
      'Настраиваем решения, переносим данные, обучаем пользователей и запускаем пилотные потоки, чтобы проверить гипотезы.',
  },
  {
    title: 'Интеграция и масштабирование',
    description:
      'Выстраиваем интеграции с существующими системами, автоматизируем контроллинг и адаптируем решения для всех подразделений.',
  },
  {
    title: 'Аналитика и оптимизация',
    description:
      'Измеряем эффект, улучшаем процессы и поддерживаем пользователей, чтобы изменения закрепились и давали результат.',
  },
];

const projectFiltersData = ['Все', 'ERP', 'Инфраструктура', 'Аналитика', 'Разработка'];

const projectGalleryData = [
  {
    id: 1,
    title: 'ERP-платформа для производителя электроники',
    category: 'ERP',
    description: 'Объединили снабжение, производство и продажи в единой системе, сократив цикл от заявки до отгрузки на 27%.',
    image: 'https://picsum.photos/800/600?random=201',
  },
  {
    id: 2,
    title: 'Дорожная карта цифровой трансформации холдинга',
    category: 'Аналитика',
    description: 'Определили 19 инициатив, посчитали ROI и организовали процесс управления цифровым портфелем.',
    image: 'https://picsum.photos/800/600?random=202',
  },
  {
    id: 3,
    title: 'Импортонезависимая инфраструктура для банка',
    category: 'Инфраструктура',
    description: 'Перевели 320 сервисов на отечественные решения, обеспечили непрерывность и соответствие требованиям регулятора.',
    image: 'https://picsum.photos/800/600?random=203',
  },
  {
    id: 4,
    title: 'Платформа аналитики продаж для ритейла',
    category: 'Аналитика',
    description: 'Настроили витрины данных и BI-дашборды, внедрив прогнозирование спроса и ценообразование в реальном времени.',
    image: 'https://picsum.photos/800/600?random=204',
  },
  {
    id: 5,
    title: 'Мобильное приложение для сервисной службы',
    category: 'Разработка',
    description: 'Создали приложение для инженеров, сократив время обработки заявок на 35% и обеспечив прозрачность SLA.',
    image: 'https://picsum.photos/800/600?random=205',
  },
  {
    id: 6,
    title: 'Центр мониторинга кибербезопасности',
    category: 'Инфраструктура',
    description: 'Развернули SOC на базе отечественных решений, организовали реагирование на инциденты 24/7.',
    image: 'https://picsum.photos/800/600?random=206',
  },
];

const testimonialsData = [
  {
    quote:
      'Коллеги из Альфа Тех Консалтинг провели полноценную трансформацию нашего ИТ-ландшафта. Благодаря совместной работе мы автоматизировали управление производством и снизили издержки на 18%.',
    author: 'Сергей Волков',
    role: 'Генеральный директор, «ТехПром»',
  },
  {
    quote:
      'Команда оперативно включилась в проект по импортозамещению и помогла безболезненно перейти на отечественные решения. Важнее всего, что они берут ответственность за результат.',
    author: 'Анна Романова',
    role: 'Директор по цифровому развитию, «Банк Северный»',
  },
  {
    quote:
      'Мы получили качественную стратегию и дорожную карту цифровизации. Эксперты глубоко погрузились в специфику логистики и предложили инициативы с понятным экономическим эффектом.',
    author: 'Игорь Кравцов',
    role: 'Операционный директор, «ЛогистикПро»',
  },
];

const teamPreviewData = [
  {
    name: 'Наталья Левина',
    role: 'Партнёр по стратегиям и инновациям',
    experience: '15 лет в IT-консалтинге, экс-руководитель цифровых решений в международной компании.',
    image: 'https://picsum.photos/400/400?random=301',
  },
  {
    name: 'Алексей Дорофеев',
    role: 'Директор по технологическим платформам',
    experience: 'Специалист по ERP и CRM, реализовал более 40 проектов внедрения в производстве и логистике.',
    image: 'https://picsum.photos/400/400?random=302',
  },
  {
    name: 'Мария Крылова',
    role: 'Руководитель практики аналитики данных',
    experience: 'Эксперт по BI и машинному обучению, сертифицированный аналитик Power BI и Qlik.',
    image: 'https://picsum.photos/400/400?random=303',
  },
  {
    name: 'Илья Сергеев',
    role: 'Руководитель направления кибербезопасности',
    experience: '12 лет в области ИБ, опыт построения SOC и внедрения DevSecOps практик.',
    image: 'https://picsum.photos/400/400?random=304',
  },
];

const faqsData = [
  {
    question: 'С чего начинается сотрудничество?',
    answer:
      'Мы начинаем с экспресс-диагностики и интервью с ключевыми руководителями, чтобы понять цели и ограничения. Затем формируем предложение с планом работ и ожидаемым эффектом.',
  },
  {
    question: 'Работаете ли вы с импортонезависимыми решениями?',
    answer:
      'Да, у нас накоплен опыт внедрения отечественных платформ и решений: «1С», «Галактика», «Naumen», «PostgreSQL», «Red OS» и других аналогов. Мы помогаем выбрать и адаптировать ПО под требования регуляторов.',
  },
  {
    question: 'Можно ли подключиться только на этап сопровождения?',
    answer:
      'Мы берем проекты на любом этапе. Если система уже внедрена, мы проведём аудит, сформируем рекомендации и настроим поддержку, чтобы повысить эффективность и стабильность работы.',
  },
  {
    question: 'Как вы оцениваете результативность проектов?',
    answer:
      'Для каждого проекта мы фиксируем KPI: снижение издержек, рост выручки, скорость обработки операций, SLA сервисов. Цифры мониторятся в BI-дашбордах, которые передаются клиенту.',
  },
  {
    question: 'Работаете ли вы в регионах?',
    answer:
      'Да, наша команда ведёт проекты по всей России и в странах СНГ. Используем гибридный формат: часть команды работает на площадке клиента, часть — централизованно из офиса в Москве.',
  },
];

const blogArticlesData = [
  {
    title: '7 шагов к устойчивой цифровой трансформации в 2024 году',
    summary:
      'Разбираем практические рекомендации, как сочетать бизнес-цели, технологии и управление изменениями, чтобы трансформация давала измеримый эффект.',
    date: '15 июня 2024',
    link: '/o-kompanii#blog-transformation',
    image: 'https://picsum.photos/800/600?random=401',
  },
  {
    title: 'Как построить импортонезависимую архитектуру и не потерять скорость',
    summary:
      'Делимся опытом перевода банков и промышленных компаний на отечественный софт, включая типичные риски и способы их минимизировать.',
    date: '28 мая 2024',
    link: '/o-kompanii#blog-architecture',
    image: 'https://picsum.photos/800/600?random=402',
  },
  {
    title: 'BI-платформа как единый источник правды: история ритейлера',
    summary:
      'Рассказываем, как построили витрины данных, объединили продажи и логистику и вывели управленческие решения на новый уровень.',
    date: '12 апреля 2024',
    link: '/o-komпании#blog-bi',
    image: 'https://picsum.photos/800/600?random=403',
  },
];

const Home = () => {
  usePageMetadata(
    'Альфа Тех Консалтинг | Цифровая трансформация и IT консалтинг',
    'Альфа Тех Консалтинг — российская команда экспертов по IT консалтингу и цифровой трансформации. Мы внедряем ERP, развиваем ИТ-стратегию и повышаем эффективность бизнеса.'
  );

  const [stats, setStats] = useState(statsTargetData.map(() => 0));

  useEffect(() => {
    const increments = statsTargetData.map((stat) => Math.max(1, Math.ceil(stat.value / 40)));
    const intervalId = setInterval(() => {
      setStats((prev) => {
        let allReached = true;
        const updated = prev.map((value, index) => {
          if (value < statsTargetData[index].value) {
            allReached = false;
            const nextValue = value + increments[index];
            return nextValue >= statsTargetData[index].value ? statsTargetData[index].value : nextValue;
          }
          return value;
        });
        if (allReached) {
          clearInterval(intervalId);
        }
        return updated;
      });
    }, 50);

    return () => clearInterval(intervalId);
  }, []);

  const [activeFilter, setActiveFilter] = useState('Все');

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'Все') {
      return projectGalleryData;
    }
    return projectGalleryData.filter((project) => project.category === activeFilter);
  }, [activeFilter]);

  const [testimonialIndex, setTestimonialIndex] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonialsData.length);
    }, 7000);

    return () => clearInterval(intervalId);
  }, []);

  const [openQuestion, setOpenQuestion] = useState(null);

  const toggleQuestion = (index) => {
    setOpenQuestion((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.home}>
      <section className={styles.hero}>
        <div className={`container ${styles.heroContainer}`}>
          <div className={styles.heroContent}>
            <span className={styles.heroBadge}>ИТ-консалтинг полного цикла</span>
            <h1 className={styles.heroTitle}>
              Цифровая трансформация, которая работает на рост вашего бизнеса
            </h1>
            <p className={styles.heroText}>
              Альфа Тех Консалтинг помогает компаниям из России и СНГ выстраивать устойчивые ИТ-решения: от стратегии и архитектуры до внедрения ERP, аналитики и кибербезопасности.
            </p>
            <div className={styles.heroActions}>
              <Link to="/контакты" className={styles.primaryButton}>
                Связаться с нами
              </Link>
              <Link to="/uslugi" className={styles.secondaryButton}>
                Посмотреть услуги
              </Link>
            </div>
            <ul className={styles.heroHighlights}>
              <li>Импортонезависимые решения без потери эффективности</li>
              <li>Сильная команда архитекторов, аналитиков и менеджеров</li>
              <li>Чёткие KPI и прозрачная отчетность по проектам</li>
            </ul>
          </div>
          <div className={styles.heroImageWrapper}>
            <img
              src="https://picsum.photos/800/600?random=101"
              alt="Команда Альфа Тех Консалтинг работает над цифровой стратегией"
              className={styles.heroImage}
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.stats} aria-label="Ключевые показатели">
        <div className="container">
          <div className={styles.statsGrid}>
            {statsTargetData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard}>
                <span className={styles.statNumber}>
                  {stats[index]}
                  {stat.suffix}
                </span>
                <p className={styles.statLabel}>{stat.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="services-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionBadge}>Наши ключевые компетенции</span>
            <h2 id="services-title" className={styles.sectionTitle}>
              Проекты «под ключ» — от идеи до поддержки
            </h2>
            <p className={styles.sectionDescription}>
              Мы сопровождаем цифровые инициативы по всей цепочке создания ценности: от аудита и стратегии до внедрения, интеграции и развития продуктов.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <Link key={service.title} to={service.link} className={styles.serviceCard}>
                <span className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </span>
                <h3 className={styles.serviceTitle}>{service.title}</h3>
                <p className={styles.serviceDescription}>{service.description}</p>
                <span className={styles.serviceLink}>Подробнее</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="advantages-title">
        <div className="container">
          <div className={styles.splitLayout}>
            <div className={styles.splitContent}>
              <span className={styles.sectionBadge}>Почему выбирают нас</span>
              <h2 id="advantages-title" className={styles.sectionTitle}>
                Наша экспертиза подтверждена практикой
              </h2>
              <p className={styles.sectionDescription}>
                Мы выстраиваем долгосрочные партнерства: 78% клиентов приходят по рекомендациям. Команда синхронизирует технологические решения с целями бизнеса и измеряет результат.
              </p>
            </div>
            <ul className={styles.advantageList}>
              {advantagesData.map((item) => (
                <li key={item} className={styles.advantageItem}>
                  <span className={styles.advantageBullet} aria-hidden="true">
                    ✓
                  </span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="process-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionBadge}>Как мы работаем</span>
            <h2 id="process-title" className={styles.sectionTitle}>
              Прозрачный процесс и контроль на каждом этапе
            </h2>
            <p className={styles.sectionDescription}>
              Строим доверие через четкие этапы, понятные deliverables и регулярную отчетность. Все материалы доступны клиенту в едином пространстве.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processStepsData.map((step, index) => (
              <article key={step.title} className={styles.processCard}>
                <span className={styles.processNumber}>{index + 1}</span>
                <h3 className={styles.processTitle}>{step.title}</h3>
                <p className={styles.processDescription}>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="projects-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionBadge}>Практика</span>
            <h2 id="projects-title" className={styles.sectionTitle}>
              Избранные проекты
            </h2>
            <p className={styles.sectionDescription}>
              Реализуем проекты в промышленности, финансовом секторе, логистике и ритейле. Выбирайте направление, чтобы посмотреть кейсы.
            </p>
          </div>
          <div className={styles.projectFilters} role="tablist" aria-label="Фильтр проектов">
            {projectFiltersData.map((filter) => (
              <button
                key={filter}
                type="button"
                className={`${styles.filterButton} ${activeFilter === filter ? styles.filterButtonActive : ''}`}
                onClick={() => setActiveFilter(filter)}
                aria-pressed={activeFilter === filter}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img
                    src={project.image}
                    alt={project.title}
                    className={styles.projectImage}
                    loading="lazy"
                  />
                  <span className={styles.projectCategory}>{project.category}</span>
                </div>
                <div className={styles.projectContent}>
                  <h3 className={styles.projectTitle}>{project.title}</h3>
                  <p className={styles.projectDescription}>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.testimonialsSection}`} aria-labelledby="testimonials-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionBadge}>Отзывы</span>
            <h2 id="testimonials-title" className={styles.sectionTitle}>
              Что говорят клиенты
            </h2>
            <p className={styles.sectionDescription}>
              Мы дорожим доверием партнеров и отвечаем за измеримый результат. Вот что отмечают руководители цифровых проектов.
            </p>
          </div>
          <div className={styles.testimonialWrapper}>
            <article className={styles.testimonialCard}>
              <p className={styles.testimonialQuote}>
                «{testimonialsData[testimonialIndex].quote}»
              </p>
              <p className={styles.testimonialAuthor}>{testimonialsData[testimonialIndex].author}</p>
              <span className={styles.testimonialRole}>{testimonialsData[testimonialIndex].role}</span>
            </article>
            <div className={styles.testimonialNav}>
              <button type="button" onClick={() => setTestimonialIndex((prev) => (prev - 1 + testimonialsData.length) % testimonialsData.length)} aria-label="Предыдущий отзыв">
                ‹
              </button>
              <div className={styles.testimonialDots} aria-live="polite">
                {testimonialsData.map((_, index) => (
                  <span
                    key={`dot-${index}`}
                    className={`${styles.testimonialDot} ${testimonialIndex === index ? styles.testimonialDotActive : ''}`}
                    aria-hidden={testimonialIndex !== index}
                  />
                ))}
              </div>
              <button type="button" onClick={() => setTestimonialIndex((prev) => (prev + 1) % testimonialsData.length)} aria-label="Следующий отзыв">
                ›
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="team-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionBadge}>Команда</span>
            <h2 id="team-title" className={styles.sectionTitle}>
              Люди, которые отвечают за ваш успех
            </h2>
            <p className={styles.sectionDescription}>
              В проекте участвуют только практики, прошедшие путь от аналитика до менеджера программы. Мы подбираем команду под конкретные задачи и масштаб бизнеса.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamPreviewData.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img
                  src={member.image}
                  alt={`${member.name} — ${member.role}`}
                  className={styles.teamImage}
                  loading="lazy"
                />
                <div className={styles.teamContent}>
                  <h3 className={styles.teamName}>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p className={styles.teamExperience}>{member.experience}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="faq-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionBadge}>Вопросы и ответы</span>
            <h2 id="faq-title" className={styles.sectionTitle}>
              Часто задаваемые вопросы
            </h2>
          </div>
          <div className={styles.faqList}>
            {faqsData.map((faq, index) => (
              <div key={faq.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqQuestion}
                  onClick={() => toggleQuestion(index)}
                  aria-expanded={openQuestion === index}
                >
                  <span>{faq.question}</span>
                  <span aria-hidden="true">{openQuestion === index ? '−' : '+'}</span>
                </button>
                {openQuestion === index && <p className={styles.faqAnswer}>{faq.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="blog-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.sectionBadge}>Блог</span>
            <h2 id="blog-title" className={styles.sectionTitle}>
              Последние материалы
            </h2>
            <p className={styles.sectionDescription}>
              Делимся аналитикой, актуальными кейсами и подходами к развитию ИТ-ландшафта без пустых слов.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogArticlesData.map((article) => (
              <article key={article.title} className={styles.blogCard}>
                <div className={styles.blogImageWrapper}>
                  <img
                    src={article.image}
                    alt={article.title}
                    className={styles.blogImage}
                    loading="lazy"
                  />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{article.date}</span>
                  <h3 className={styles.blogTitle}>{article.title}</h3>
                  <p className={styles.blogSummary}>{article.summary}</p>
                  <Link to={article.link} className={styles.blogLink}>
                    Читать далее
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection} aria-labelledby="cta-title">
        <div className={`container ${styles.ctaContainer}`}>
          <div>
            <h2 id="cta-title" className={styles.ctaTitle}>
              Готовы обсудить цифровые задачи вашего бизнеса?
            </h2>
            <p className={styles.ctaSubtitle}>
              Свяжитесь с нами, и мы подготовим бесплатную экспресс-оценку потенциала трансформации с конкретными цифрами и сроками.
            </p>
          </div>
          <div className={styles.ctaActions}>
            <a href="tel:+74951234567" className={styles.ctaPhone}>
              +7 (495) 123-45-67
            </a>
            <Link to="/контакты" className={styles.ctaButton}>
              Запланировать консультацию
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;