document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      navMenu.classList.toggle('activo');
      navToggle.classList.toggle('abierto');
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');

  const consent = localStorage.getItem('ml_cookieConsent');
  if (!consent && cookieBanner) {
    cookieBanner.classList.add('visible');
  }

  const hideBanner = value => {
    if (cookieBanner) {
      cookieBanner.classList.remove('visible');
      localStorage.setItem('ml_cookieConsent', value);
    }
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => hideBanner('accepted'));
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => hideBanner('declined'));
  }
});