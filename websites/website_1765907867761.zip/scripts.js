document.addEventListener('DOMContentLoaded', function () {
  const nav = document.querySelector('.site-nav');
  const menuToggle = document.querySelector('.menu-toggle');

  if (menuToggle && nav) {
    menuToggle.addEventListener('click', () => {
      nav.classList.toggle('open');
      menuToggle.setAttribute('aria-expanded', nav.classList.contains('open'));
    });

    document.addEventListener('click', (event) => {
      if (nav.classList.contains('open') && !nav.contains(event.target) && event.target !== menuToggle) {
        nav.classList.remove('open');
        menuToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptCookiesBtn = document.querySelector('#cookieAccept');
  const declineCookiesBtn = document.querySelector('#cookieDecline');
  const cookieChoice = localStorage.getItem('ecdCookieChoice');

  if (cookieBanner) {
    if (!cookieChoice) {
      cookieBanner.classList.add('active');
    }

    if (acceptCookiesBtn) {
      acceptCookiesBtn.addEventListener('click', () => {
        localStorage.setItem('ecdCookieChoice', 'accepted');
        cookieBanner.classList.remove('active');
      });
    }

    if (declineCookiesBtn) {
      declineCookiesBtn.addEventListener('click', () => {
        localStorage.setItem('ecdCookieChoice', 'declined');
        cookieBanner.classList.remove('active');
      });
    }
  }

  const contactForm = document.querySelector('#contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function (event) {
      event.preventDefault();
      const nameField = contactForm.querySelector('input[name="name"]');
      const emailField = contactForm.querySelector('input[name="email"]');
      const messageField = contactForm.querySelector('textarea[name="message"]');
      const errors = [];

      if (!nameField.value.trim()) {
        errors.push('Please enter your name.');
      }

      const emailValue = emailField.value.trim();
      if (!emailValue) {
        errors.push('Please provide an email address.');
      } else if (!/^[\w.-]+@[\w.-]+\.\w{2,}$/.test(emailValue)) {
        errors.push('Please enter a valid email address.');
      }

      if (!messageField.value.trim()) {
        errors.push('Please include your message.');
      }

      const errorContainer = contactForm.querySelector('.form-errors');
      if (errorContainer) {
        errorContainer.remove();
      }

      if (errors.length > 0) {
        const errorList = document.createElement('div');
        errorList.className = 'form-errors';
        errorList.style.marginBottom = '1rem';
        errorList.style.color = '#b81d24';
        errorList.innerHTML = `<strong>Action required:</strong><br>${errors.join('<br>')}`;
        contactForm.insertBefore(errorList, contactForm.firstChild);
        return;
      }

      window.location.href = 'thanks.html';
    });
  }

  const filterButtons = document.querySelectorAll('[data-filter]');
  const searchInput = document.querySelector('#searchInput');
  const articleCards = document.querySelectorAll('[data-category]');

  if (filterButtons.length > 0 && articleCards.length > 0) {
    filterButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const category = button.dataset.filter;
        filterButtons.forEach((btn) => btn.classList.remove('is-active'));
        button.classList.add('is-active');
        filterArticles(category, searchInput ? searchInput.value.trim().toLowerCase() : '');
      });
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', () => {
      const activeButton = document.querySelector('.filter-btn.is-active');
      const activeCategory = activeButton ? activeButton.dataset.filter : 'all';
      filterArticles(activeCategory, searchInput.value.trim().toLowerCase());
    });
  }

  function filterArticles(category, query) {
    articleCards.forEach((card) => {
      const matchesCategory = category === 'all' || card.dataset.category === category;
      const title = card.querySelector('h3') ? card.querySelector('h3').textContent.toLowerCase() : '';
      const excerpt = card.querySelector('p') ? card.querySelector('p').textContent.toLowerCase() : '';
      const matchesQuery = title.includes(query) || excerpt.includes(query);
      if (matchesCategory && matchesQuery) {
        card.classList.remove('hidden');
      } else {
        card.classList.add('hidden');
      }
    });
  }
});