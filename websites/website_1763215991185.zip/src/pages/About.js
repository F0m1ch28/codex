```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  return (
    <div className={styles.about}>
      <Helmet>
        <title>About TechSolutions | Cloud &amp; Digital Transformation Experts</title>
        <meta
          name="description"
          content="Learn about TechSolutions, our mission, and the consultants who guide organizations through cloud adoption and meaningful digital transformation."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Guiding technology change with purpose</h1>
          <p>
            TechSolutions was founded to deliver consulting that blends strategic
            insight with practical execution. We believe technology should serve
            people, and that progress happens when teams work together with
            clarity and respect.
          </p>
        </div>
      </section>

      <section className={`${styles.story} container`}>
        <div className={styles.storyContent}>
          <h2>Our story</h2>
          <p>
            The TechSolutions team brings deep experience across industries,
            cloud platforms, and digital products. After leading large-scale
            transformations for global enterprises, our founders saw a gap: too
            many initiatives started with enthusiasm but lacked the guidance to
            deliver sustainable change. We set out to close that gap.
          </p>
          <p>
            Today we partner with growth-minded organizations to build cloud
            strategies, modernize operations, and empower people with intuitive
            digital tools. Every engagement is rooted in listening, transparent
            communication, and a focus on measurable impact.
          </p>
        </div>
        <div className={styles.storyMedia}>
          <img
            src="https://picsum.photos/seed/teamwork/600/450"
            alt="TechSolutions consultants collaborating with business leaders"
          />
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2>The values that guide us</h2>
          <div className={styles.valueGrid}>
            <article>
              <h3>Integrity</h3>
              <p>
                We earn trust by being transparent, realistic, and accountable.
                Our recommendations align with your goals, not trends.
              </p>
            </article>
            <article>
              <h3>Empathy</h3>
              <p>
                Technology is ultimately about people. We listen carefully to
                every voice and design solutions that support the teams who rely
                on them.
              </p>
            </article>
            <article>
              <h3>Learning mindset</h3>
              <p>
                We stay curious, encourage experimentation, and share knowledge
                generously so your teams grow more confident with each milestone.
              </p>
            </article>
            <article>
              <h3>Clarity</h3>
              <p>
                Complex initiatives demand clear communication. We translate
                vision into actionable steps and keep everyone aligned.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.leadership}>
        <div className="container">
          <h2>Leadership team</h2>
          <div className={styles.leaders}>
            <article>
              <img
                src="https://picsum.photos/seed/leader1/320/320"
                alt="Portrait of Maya Chen, Chief Executive Officer"
              />
              <h3>Maya Chen</h3>
              <p>Chief Executive Officer</p>
              <span>
                Maya blends enterprise strategy expertise with a passion for
                building collaborative cultures that sustain change.
              </span>
            </article>
            <article>
              <img
                src="https://picsum.photos/seed/leader2/320/320"
                alt="Portrait of Jordan Patel, Head of Cloud Strategy"
              />
              <h3>Jordan Patel</h3>
              <p>Head of Cloud Strategy</p>
              <span>
                Jordan guides clients through cloud adoption with a structured,
                security-minded approach that keeps teams aligned.
              </span>
            </article>
            <article>
              <img
                src="https://picsum.photos/seed/leader3/320/320"
                alt="Portrait of Elena Ramirez, Director of Digital Experience"
              />
              <h3>Elena Ramirez</h3>
              <p>Director of Digital Experience</p>
              <span>
                Elena ensures every digital product balances human-centered
                design with dependable performance.
              </span>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
```