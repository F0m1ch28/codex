```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PolicyPage.module.css';

const Terms = () => {
  return (
    <div className={styles.policy}>
      <Helmet>
        <title>Terms of Use | TechSolutions</title>
        <meta
          name="description"
          content="Review the TechSolutions Terms of Use to understand conditions for accessing and using our website and services."
        />
      </Helmet>
      <div className="container">
        <h1>Terms of Use</h1>
        <p className={styles.lastUpdated}>Last updated: January 3, 2024</p>

        <section>
          <h2>1. Acceptance of terms</h2>
          <p>
            By accessing or using the TechSolutions website (“Site”), you agree
            to be bound by these Terms of Use. If you do not agree with these
            terms, please refrain from using the Site.
          </p>
        </section>

        <section>
          <h2>2. Use of the site</h2>
          <p>
            You may use the Site for lawful purposes and in accordance with
            these terms. You agree not to use the Site in ways that may damage,
            disable, or impair any part of the Site or interfere with others’
            use of the Site.
          </p>
        </section>

        <section>
          <h2>3. Intellectual property</h2>
          <p>
            All content, trademarks, logos, and materials on the Site are owned
            or licensed by TechSolutions and are protected by applicable laws.
            You may not reproduce, modify, distribute, or use any content
            without our prior written consent.
          </p>
        </section>

        <section>
          <h2>4. Informational content</h2>
          <p>
            The materials provided on this Site are for informational purposes
            only and do not constitute professional advice. Any reliance on the
            information provided is at your own risk.
          </p>
        </section>

        <section>
          <h2>5. Third-party links</h2>
          <p>
            The Site may contain links to third-party websites. TechSolutions is
            not responsible for the content or practices of those sites. Access
            them at your own discretion.
          </p>
        </section>

        <section>
          <h2>6. Disclaimer of warranties</h2>
          <p>
            The Site is provided “as is” without warranties of any kind. We do
            not guarantee that the Site will be uninterrupted, secure, or free
            of errors. Your use of the Site is at your own risk.
          </p>
        </section>

        <section>
          <h2>7. Limitation of liability</h2>
          <p>
            To the fullest extent permitted by law, TechSolutions shall not be
            liable for any direct, indirect, incidental, or consequential
            damages resulting from your use of or inability to use the Site.
          </p>
        </section>

        <section>
          <h2>8. Indemnification</h2>
          <p>
            You agree to indemnify and hold TechSolutions harmless from any
            claims, damages, or expenses arising from your use of the Site or
            violation of these Terms.
          </p>
        </section>

        <section>
          <h2>9. Governing law</h2>
          <p>
            These Terms of Use are governed by the laws of the State of
            California, without regard to its conflict of law provisions. Any
            disputes arising out of or relating to the Site shall be resolved in
            the state or federal courts located in San Francisco, California.
          </p>
        </section>

        <section>
          <h2>10. Changes to terms</h2>
          <p>
            We may update these Terms of Use from time to time. Changes are
            effective when posted on this page. Continued use of the Site after
            changes signifies your acceptance of the revised terms.
          </p>
        </section>

        <section>
          <h2>11. Contact us</h2>
          <p>
            If you have questions about these Terms of Use, please contact us at:
          </p>
          <address>
            TechSolutions
            <br />
            123 Tech Avenue, Innovation District
            <br />
            San Francisco, CA 94105
            <br />
            Phone: +1 (555) 123-4567
            <br />
            Email: <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
          </address>
        </section>
      </div>
    </div>
  );
};

export default Terms;
```