document.addEventListener('DOMContentLoaded', () => {
  const nav = document.querySelector('.site-nav');
  const toggle = document.querySelector('.hamburger');

  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      toggle.classList.toggle('active', isOpen);
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    nav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (nav.classList.contains('open')) {
          nav.classList.remove('open');
          toggle.classList.remove('active');
          toggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const banner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const rejectBtn = document.getElementById('cookie-reject');
  const consentKey = 'alkisoda_cookie_preference';

  if (banner) {
    try {
      const storedConsent = localStorage.getItem(consentKey);
      if (!storedConsent) {
        banner.classList.remove('hidden');
      }
    } catch (error) {
      banner.classList.remove('hidden');
    }

    const setConsent = (value) => {
      try {
        localStorage.setItem(consentKey, value);
      } catch (error) {
        // storage might be unavailable; ignore
      }
      banner.classList.add('hidden');
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => setConsent('acceptat'));
    }

    if (rejectBtn) {
      rejectBtn.addEventListener('click', () => setConsent('respins'));
    }
  }
});