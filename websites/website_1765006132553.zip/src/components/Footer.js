import React from 'react';
import { NavLink } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div>
          <div className="footer-brand">
            <div className="brand-icon brand-icon--footer">▲</div>
            <div>
              <p className="footer-title">ElevateX Solutions</p>
              <p className="footer-text">
                Transforming ambitious ideas into measurable business impact through strategic digital innovation.
              </p>
            </div>
          </div>
          <div className="footer-social">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
            <a href="https://www.twitter.com" target="_blank" rel="noreferrer">
              Twitter
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer">
              YouTube
            </a>
          </div>
        </div>

        <div>
          <p className="footer-heading">Company</p>
          <ul>
            <li>
              <NavLink to="/about">About</NavLink>
            </li>
            <li>
              <NavLink to="/services">Services</NavLink>
            </li>
            <li>
              <NavLink to="/contact">Contact</NavLink>
            </li>
            <li>
              <NavLink to="/privacy">Privacy Policy</NavLink>
            </li>
            <li>
              <NavLink to="/terms">Terms of Use</NavLink>
            </li>
          </ul>
        </div>

        <div>
          <p className="footer-heading">Services</p>
          <ul>
            <li>Digital Strategy</li>
            <li>Product Design</li>
            <li>Engineering</li>
            <li>Data &amp; AI</li>
            <li>Cloud Transformation</li>
          </ul>
        </div>

        <div>
          <p className="footer-heading">Newsletter</p>
          <p className="footer-text">
            Subscribe to receive actionable insights and industry-leading case studies every month.
          </p>
          <form
            className="footer-form"
            onSubmit={(e) => {
              e.preventDefault();
              const form = e.currentTarget;
              const messageEl = form.querySelector('.form-message');
              const email = form.email.value.trim();
              if (!/\S+@\S+\.\S+/.test(email)) {
                messageEl.textContent = 'Please enter a valid email address.';
                messageEl.className = 'form-message error';
                return;
              }
              messageEl.textContent = 'Thanks! You are now subscribed.';
              messageEl.className = 'form-message success';
              form.reset();
            }}
          >
            <label htmlFor="footer-email" className="sr-only">
              Email address
            </label>
            <input id="footer-email" type="email" name="email" placeholder="you@company.com" required />
            <button type="submit">Subscribe</button>
            <p className="form-message" aria-live="polite"></p>
          </form>
        </div>
      </div>
      <div className="container footer-bottom">
        <p>© {currentYear} ElevateX Solutions. All rights reserved.</p>
        <p>Designed for performance, built for scale.</p>
      </div>
    </footer>
  );
};

export default Footer;