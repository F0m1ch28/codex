import React, { useState, useEffect } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('elevatex-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('elevatex-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <p>
          We use cookies to personalize experiences and analyze performance. By clicking “Accept” you consent to our use
          of cookies.{' '}
          <a href="/privacy" className="cookie-link">
            Learn more
          </a>
        </p>
        <div className="cookie-actions">
          <button onClick={handleAccept} className="btn primary">
            Accept
          </button>
          <button onClick={() => setVisible(false)} className="btn ghost">
            Decline
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;