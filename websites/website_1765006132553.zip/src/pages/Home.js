import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';

const statsData = [
  { label: 'Projects Delivered', value: 240 },
  { label: 'Client Satisfaction', value: 98 },
  { label: 'Lead Time Reduction', value: 62 },
  { label: 'Countries Served', value: 18 },
];

const servicesData = [
  {
    title: 'Product Strategy',
    description: 'Define vision, roadmap, and measurable outcomes to accelerate digital transformation.',
    icon: '🧭',
  },
  {
    title: 'Experience Design',
    description: 'Craft high-converting journeys with human-centered UX and conversion-focused UI design.',
    icon: '🎨',
  },
  {
    title: 'Custom Engineering',
    description: 'Build resilient platforms leveraging modern Cloud-native architectures and DevOps standards.',
    icon: '⚙️',
  },
  {
    title: 'Data Intelligence',
    description: 'Unlock meaningful insights with predictive analytics, machine learning, and AI ops.',
    icon: '📊',
  },
];

const processSteps = [
  {
    step: '01',
    title: 'Discover & Diagnose',
    description: 'Collaborative workshops identify opportunities, audit existing systems, and align success metrics.',
  },
  {
    step: '02',
    title: 'Design & Prototype',
    description: 'Rapid prototyping validates experiences, while design systems ensure scalable execution.',
  },
  {
    step: '03',
    title: 'Build & Iterate',
    description: 'Engineering sprints deliver incremental value with automated testing and quality assurance.',
  },
  {
    step: '04',
    title: 'Launch & Optimize',
    description: 'Post-launch performance analytics drive ongoing optimization and actionable growth strategies.',
  },
];

const testimonials = [
  {
    quote:
      'ElevateX delivered a 126% uplift in qualified conversions within three months. Their team became a trusted extension of ours.',
    name: 'Sophia Turner',
    role: 'Chief Marketing Officer, NexusCore',
  },
  {
    quote:
      'They led our cloud modernization journey flawlessly. The new platform reduced downtime to virtually zero.',
    name: 'Carlos Medina',
    role: 'VP of Engineering, StratusWave',
  },
  {
    quote:
      'From concept to launch, ElevateX guided our marketplace expansion with empathy, clarity, and expert execution.',
    name: 'Amelia Watts',
    role: 'Founder, UrbanRise Collective',
  },
];

const teamMembers = [
  {
    name: 'Lauren Mitchell',
    role: 'Chief Executive Officer',
    bio: 'Seasoned strategist with two decades scaling high-growth technology ventures.',
    img: 'https://picsum.photos/400/400?random=31',
  },
  {
    name: 'Arjun Kapoor',
    role: 'Head of Product Innovation',
    bio: 'Leads cross-functional product squads focused on experimentation and customer value.',
    img: 'https://picsum.photos/400/400?random=32',
  },
  {
    name: 'Diana Kuo',
    role: 'Director of Engineering',
    bio: 'Architects secure, future-ready platforms with best-in-class DevOps practices.',
    img: 'https://picsum.photos/400/400?random=33',
  },
  {
    name: 'Marcus Lee',
    role: 'Principal Data Scientist',
    bio: 'Transforms complex datasets into predictive models and automated insights.',
    img: 'https://picsum.photos/400/400?random=34',
  },
];

const projectsData = [
  {
    category: 'Strategy',
    title: 'Global Logistics Intelligence Platform',
    image: 'https://picsum.photos/1200/800?random=41',
    description: 'Unified supply chain analytics delivering 40% faster decision-making cycles.',
  },
  {
    category: 'Product',
    title: 'Telehealth Patient Experience',
    image: 'https://picsum.photos/1200/800?random=42',
    description: 'Omnichannel care ecosystem with 4.9/5 patient satisfaction scores.',
  },
  {
    category: 'Engineering',
    title: 'Fintech Compliance Automation',
    image: 'https://picsum.photos/1200/800?random=43',
    description: 'Reduced manual review time by 73% via rule-based and AI-driven workflows.',
  },
  {
    category: 'Data & AI',
    title: 'Retail Demand Forecasting',
    image: 'https://picsum.photos/1200/800?random=44',
    description: 'Machine learning models predicting demand with 95% accuracy across 300 stores.',
  },
];

const faqData = [
  {
    question: 'How do you tailor solutions for different industries?',
    answer:
      'We begin each engagement with executive and stakeholder workshops to understand your business context, KPIs, and constraints. From there, we craft a bespoke roadmap that blends cross-industry best practices with unique requirements.',
  },
  {
    question: 'What is your approach to collaboration?',
    answer:
      'Embedded squads work alongside your teams, leveraging transparent communication, agile ceremonies, and shared OKRs. We operate with co-ownership to ensure alignment, speed, and accountability.',
  },
  {
    question: 'How quickly can you launch a new engagement?',
    answer:
      'Our rapid kick-off process enables us to align on goals, scope, and timeline within two weeks. We prioritize quick wins while building the foundation for long-term success.',
  },
  {
    question: 'Do you provide post-launch support?',
    answer:
      'Yes. Our optimization and growth retainers ensure your product evolves with changing customer expectations and market needs, backed by data-driven experimentation.',
  },
];

const blogPosts = [
  {
    title: 'Accelerating Digital Maturity with Adaptive Operating Models',
    excerpt: 'Discover the frameworks that leading enterprises use to iterate faster, enhance governance, and empower teams.',
    link: '#',
    date: 'February 12, 2024',
  },
  {
    title: 'Design Systems That Drive Brand and Conversion Consistency',
    excerpt: 'Learn how to scale design with reusable components that delight customers and improve ROI across channels.',
    link: '#',
    date: 'January 30, 2024',
  },
  {
    title: 'Data-Led Transformation: From Legacy Debt to AI Advantage',
    excerpt: 'A step-by-step guide to modernizing infrastructure and operationalizing analytics to inform critical decisions.',
    link: '#',
    date: 'January 11, 2024',
  },
];

const Home = () => {
  const statsRef = useRef(null);
  const [isStatsVisible, setIsStatsVisible] = useState(false);
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [testimonialsIndex, setTestimonialsIndex] = useState(0);
  const [projectFilter, setProjectFilter] = useState('All');
  const [expandedFaq, setExpandedFaq] = useState(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting) {
          setIsStatsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.4 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => {
      if (statsRef.current) {
        observer.unobserve(statsRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!isStatsVisible) return;

    const animationDuration = 1800;
    const frameRate = 60;
    const totalFrames = Math.round((animationDuration / 1000) * frameRate);

    let frame = 0;

    const interval = setInterval(() => {
      frame += 1;
      setCounters(
        statsData.map((stat) => Math.min(stat.value, Math.round((stat.value / totalFrames) * frame)))
      );
      if (frame === totalFrames) {
        clearInterval(interval);
      }
    }, 1000 / frameRate);

    return () => clearInterval(interval);
  }, [isStatsVisible]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialsIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    projectFilter === 'All'
      ? projectsData
      : projectsData.filter((project) => project.category === projectFilter);

  return (
    <div className="home-page">
      <section className="hero-section">
        <div className="hero-media">
          <img
            src="https://picsum.photos/1600/900?random=11"
            alt="Team collaborating in a modern digital workspace"
            loading="eager"
          />
        </div>
        <div className="container hero-content">
          <span className="eyebrow">Strategic Digital Innovation</span>
          <h1>
            Build bold digital products that unlock measurable business impact.
          </h1>
          <p>
            ElevateX partners with ambitious leaders to craft transformative experiences, launch resilient platforms, and
            operationalize data-driven decision making. We bridge strategy, design, and engineering to help you scale with conviction.
          </p>
          <div className="hero-actions">
            <Link to="/contact" className="btn primary large">
              Launch a Project
            </Link>
            <Link to="/services" className="btn ghost large">
              Explore Services
            </Link>
          </div>
          <div className="hero-stats">
            <div>
              <p className="hero-stats-number">+240</p>
              <p>Enterprise-grade engagements delivered globally.</p>
            </div>
            <div>
              <p className="hero-stats-number">4.9/5</p>
              <p>Average partnership rating across all industries.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="stats-section" ref={statsRef}>
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <div key={stat.label} className="stat-card">
              <p className="stat-value">
                {counters[index]}
                {stat.label === 'Client Satisfaction' ? '%' : ''}
              </p>
              <p className="stat-label">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="services-section" id="services">
        <div className="container section-header">
          <div>
            <span className="eyebrow">What we do</span>
            <h2>A cross-disciplinary team delivering end-to-end innovation.</h2>
          </div>
          <p>
            We blend strategic insight with executional excellence. From validating opportunities to scaling global platforms,
            ElevateX ensures every initiative is customer-centric, data-informed, and engineered for longevity.
          </p>
        </div>
        <div className="container services-grid">
          {servicesData.map((service) => (
            <article key={service.title} className="service-card">
              <span className="service-icon" aria-hidden="true">
                {service.icon}
              </span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/services" className="service-link">
                Discover more →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="process-section">
        <div className="container section-header">
          <div>
            <span className="eyebrow">How we partner</span>
            <h2>A proven framework for accelerating innovation.</h2>
          </div>
          <p>
            Transparency, velocity, and measurable outcomes define every phase. Our integrated squads align stakeholders, streamline
            delivery, and build with purpose.
          </p>
        </div>
        <div className="container process-grid">
          {processSteps.map((step) => (
            <div key={step.step} className="process-card">
              <div className="process-step">{step.step}</div>
              <div>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="testimonials-section">
        <div className="container testimonials-wrapper">
          <div className="testimonial-card">
            <div className="testimonial-quote">“{testimonials[testimonialsIndex].quote}”</div>
            <div className="testimonial-author">
              <p className="testimonial-name">{testimonials[testimonialsIndex].name}</p>
              <p className="testimonial-role">{testimonials[testimonialsIndex].role}</p>
            </div>
            <div className="testimonial-controls">
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  className={`dot ${idx === testimonialsIndex ? 'active' : ''}`}
                  onClick={() => setTestimonialsIndex(idx)}
                  aria-label={`View testimonial ${idx + 1}`}
                ></button>
              ))}
            </div>
          </div>
          <div className="testimonial-image">
            <img
              src="https://picsum.photos/800/600?random=21"
              alt="Professionals working together in a modern office"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="team-section">
        <div className="container section-header">
          <div>
            <span className="eyebrow">Leadership</span>
            <h2>Meet the experts guiding every partnership.</h2>
          </div>
          <p>
            Our leadership team brings deep expertise across strategy, product, engineering, and data. Together, we build resilient
            ecosystems that empower your teams and delight your customers.
          </p>
        </div>
        <div className="container team-grid">
          {teamMembers.map((member) => (
            <article key={member.name} className="team-card">
              <div className="team-image">
                <img src={member.img} alt={`${member.name}, ${member.role}`} loading="lazy" />
              </div>
              <div className="team-info">
                <h3>{member.name}</h3>
                <p className="team-role">{member.role}</p>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="projects-section">
        <div className="container section-header">
          <div>
            <span className="eyebrow">Case studies</span>
            <h2>High-impact engagements shaping tomorrow’s leaders.</h2>
          </div>
          <div className="project-filters" role="tablist" aria-label="Filter projects">
            {['All', 'Strategy', 'Product', 'Engineering', 'Data & AI'].map((filter) => (
              <button
                key={filter}
                className={`filter-btn ${projectFilter === filter ? 'active' : ''}`}
                onClick={() => setProjectFilter(filter)}
                role="tab"
                aria-selected={projectFilter === filter}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
        <div className="container projects-grid">
          {filteredProjects.map((project) => (
            <article key={project.title} className="project-card">
              <div className="project-image">
                <img src={project.image} alt={`${project.title} project showcase`} loading="lazy" />
              </div>
              <div className="project-content">
                <span className="project-category">{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <a href="#!" className="project-link">
                  View full case study →
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="faq-section">
        <div className="container section-header">
          <div>
            <span className="eyebrow">FAQ</span>
            <h2>Answers to frequent partnership questions.</h2>
          </div>
          <p>
            We prioritize clarity and collaboration from day one. If you have further questions, our team is available for a deep dive.
          </p>
        </div>
        <div className="container faq-list">
          {faqData.map((item, idx) => {
            const isOpen = expandedFaq === idx;
            return (
              <div key={item.question} className={`faq-item ${isOpen ? 'open' : ''}`}>
                <button
                  className="faq-trigger"
                  onClick={() => setExpandedFaq(isOpen ? null : idx)}
                  aria-expanded={isOpen}
                >
                  <span>{item.question}</span>
                  <span className="faq-icon">{isOpen ? '−' : '+'}</span>
                </button>
                <div className="faq-content">
                  <p>{item.answer}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="blog-section">
        <div className="container section-header">
          <div>
            <span className="eyebrow">Insights</span>
            <h2>Latest perspectives powering executive decisions.</h2>
          </div>
          <p>
            Explore practical frameworks, case studies, and thought leadership curated for forward-thinking leaders ready to transform.
          </p>
        </div>
        <div className="container blog-grid">
          {blogPosts.map((post) => (
            <article key={post.title} className="blog-card">
              <span className="blog-date">{post.date}</span>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <a href={post.link} className="blog-link">
                Continue reading →
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-card">
          <div>
            <h2>Ready to shape the next era of your business?</h2>
            <p>
              Partner with ElevateX to launch visionary products, modernize operations, and activate data-backed growth. Let’s architect
              the future—together.
            </p>
          </div>
          <Link to="/contact" className="btn primary large">
            Schedule a Strategy Session
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;