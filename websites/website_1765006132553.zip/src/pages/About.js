import React from 'react';

const About = () => {
  return (
    <div className="page about-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">About ElevateX</span>
          <h1>We combine strategy, design, and engineering to unlock opportunity at scale.</h1>
          <p>
            ElevateX is an integrated consultancy built for digital trailblazers. With studios in North America, Europe, and APAC, we
            collaborate with executive teams to deliver customer-centric experiences, robust platforms, and data-fueled growth.
          </p>
        </div>
      </section>

      <section className="mission-section">
        <div className="container mission-grid">
          <div>
            <h2>Mission</h2>
            <p>
              We empower visionary organizations to adapt, innovate, and lead. By embedding with your teams, we align technology decisions
              with strategic outcomes, ensuring ideas move from concept to measurable impact.
            </p>
          </div>
          <div>
            <h2>Values</h2>
            <ul className="values-list">
              <li>
                <strong>Empathy:</strong> We listen deeply to understand your customers and your teams.
              </li>
              <li>
                <strong>Clarity:</strong> We communicate transparently to de-risk complex initiatives.
              </li>
              <li>
                <strong>Craft:</strong> We obsess over details that deliver performant, beautiful experiences.
              </li>
              <li>
                <strong>Velocity:</strong> We accelerate execution with repeatable frameworks and automation.
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className="leadership-image">
        <div className="container">
          <img
            src="https://picsum.photos/1200/600?random=52"
            alt="ElevateX leadership discussing strategic roadmap"
            loading="lazy"
          />
        </div>
      </section>

      <section className="approach-section">
        <div className="container narrow">
          <h2>Our integrated approach</h2>
          <p>
            Every engagement is led by a multidisciplinary pod that includes strategy, design, engineering, and data experts. This model
            ensures we deliver holistic solutions that are technically sound, financially viable, and human-centered. Weekly steering
            ceremonies and transparent dashboards keep stakeholders aligned and accountable.
          </p>
        </div>
      </section>

      <section className="capabilities-section">
        <div className="container section-header">
          <div>
            <span className="eyebrow">Centers of Excellence</span>
            <h2>Global teams delivering local impact.</h2>
          </div>
          <p>
            Our distributed delivery centers provide follow-the-sun coverage, continuous delivery, and access to niche expertise.
          </p>
        </div>
        <div className="container capabilities-grid">
          <div>
            <h3>Strategy Lab</h3>
            <p>
              Market analysts, product strategists, and service designers collaborate to define transformation roadmaps, business models,
              and go-to-market playbooks.
            </p>
          </div>
          <div>
            <h3>Design Studio</h3>
            <p>
              Brand strategists, UX researchers, and UI designers craft cohesive experiences supported by adaptable design systems.
            </p>
          </div>
          <div>
            <h3>Engineering Guild</h3>
            <p>
              Cloud architects, platform engineers, and security experts engineer scalable infrastructures and reliable digital products.
            </p>
          </div>
          <div>
            <h3>Data Collective</h3>
            <p>
              Data scientists, ML engineers, and analytics consultants help organizations leverage predictive insights and automation.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;