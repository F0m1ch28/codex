import React, { useState } from 'react';

const Contact = () => {
  const [formState, setFormState] = useState({
    name: '',
    company: '',
    email: '',
    project: '',
    message: '',
  });
  const [formFeedback, setFormFeedback] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const { name, company, email, project, message } = formState;

    if (!name.trim() || !company.trim() || !message.trim()) {
      setFormFeedback('Please complete all required fields.');
      return;
    }

    if (!/\S+@\S+\.\S+/.test(email)) {
      setFormFeedback('Please enter a valid email address.');
      return;
    }

    if (!project) {
      setFormFeedback('Please select your project timeline.');
      return;
    }

    setFormFeedback('Success! We will reach out within one business day.');
    setFormState({
      name: '',
      company: '',
      email: '',
      project: '',
      message: '',
    });
  };

  return (
    <div className="page contact-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">Let’s talk</span>
          <h1>Tell us about your next big idea.</h1>
          <p>
            We partner with executive teams, founders, and product leaders. Share a few details and we’ll schedule a tailored strategy
            session to explore fit, roadmap, and expected ROI.
          </p>
        </div>
      </section>

      <section className="contact-section">
        <div className="container contact-grid">
          <div className="contact-info">
            <h2>What to expect</h2>
            <ul className="contact-highlights">
              <li>Discovery call with a senior strategist</li>
              <li>Opportunity assessment and timeline clarity</li>
              <li>Actionable recommendations within 10 days</li>
            </ul>
            <div className="contact-details">
              <p>
                <strong>Global HQ</strong>
                <br />
                415 Market Street, Suite 800
                <br />
                San Francisco, CA 94105
              </p>
              <p>
                <strong>Email</strong>
                <br />
                hello@elevatex.co
              </p>
              <p>
                <strong>Phone</strong>
                <br />
                +1 (415) 555-0147
              </p>
            </div>
          </div>
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-row">
              <label htmlFor="name">Full name*</label>
              <input
                id="name"
                type="text"
                name="name"
                value={formState.name}
                onChange={handleChange}
                placeholder="Jordan Reynolds"
                required
              />
            </div>
            <div className="form-row">
              <label htmlFor="company">Company*</label>
              <input
                id="company"
                type="text"
                name="company"
                value={formState.company}
                onChange={handleChange}
                placeholder="Acme Ventures"
                required
              />
            </div>
            <div className="form-row">
              <label htmlFor="email">Work email*</label>
              <input
                id="email"
                type="email"
                name="email"
                value={formState.email}
                onChange={handleChange}
                placeholder="you@company.com"
                required
              />
            </div>
            <div className="form-row">
              <label htmlFor="project">Timeline*</label>
              <select id="project" name="project" value={formState.project} onChange={handleChange} required>
                <option value="">Select timeline</option>
                <option value="Immediate (0-3 months)">Immediate (0-3 months)</option>
                <option value="Near-term (3-6 months)">Near-term (3-6 months)</option>
                <option value="Long-term (6+ months)">Long-term (6+ months)</option>
              </select>
            </div>
            <div className="form-row">
              <label htmlFor="message">Project details*</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formState.message}
                onChange={handleChange}
                placeholder="Share your goals, challenges, and timeline."
                required
              ></textarea>
            </div>
            <button type="submit" className="btn primary large">
              Submit Inquiry
            </button>
            <p className={`form-feedback ${formFeedback.includes('Success') ? 'success' : 'error'}`} aria-live="polite">
              {formFeedback}
            </p>
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;