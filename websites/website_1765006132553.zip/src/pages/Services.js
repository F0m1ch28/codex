import React, { useState } from 'react';

const servicePackages = [
  {
    title: 'Ignite Strategy',
    duration: '6-8 weeks',
    price: 'Starting at $45k',
    outcomes: [
      'Customer & market opportunity analysis',
      'North-star journey maps & value proposition',
      'Product vision, roadmap & investment model',
    ],
  },
  {
    title: 'Velocity Build',
    duration: '12-20 weeks',
    price: 'Starting at $180k',
    outcomes: [
      'Cross-functional product squad',
      'Experience design system & prototype',
      'MVP build, QA automation & launch readiness',
    ],
  },
  {
    title: 'Scale & Optimize',
    duration: 'Ongoing partnership',
    price: 'Starting at $25k / month',
    outcomes: [
      'A/B testing & conversion optimization',
      'Data engineering & advanced analytics',
      'Performance monitoring & feature iteration',
    ],
  },
];

const Services = () => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const selectedService = servicePackages[selectedIndex];

  return (
    <div className="page services-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">Services</span>
          <h1>Purpose-built services crafted for measurable growth.</h1>
          <p>
            Whether you’re validating a new venture, scaling a flagship product, or modernizing core systems, ElevateX mobilizes the
            right talent to deliver outcomes with speed and confidence.
          </p>
        </div>
      </section>

      <section className="service-offerings">
        <div className="container offerings-grid">
          <div className="offerings-menu" role="tablist" aria-label="Service packages">
            {servicePackages.map((packageItem, idx) => (
              <button
                key={packageItem.title}
                className={`offerings-tab ${selectedIndex === idx ? 'active' : ''}`}
                onClick={() => setSelectedIndex(idx)}
                role="tab"
                aria-selected={selectedIndex === idx}
              >
                <span>{packageItem.title}</span>
                <span className="tab-icon">→</span>
              </button>
            ))}
          </div>
          <div className="offerings-detail" role="tabpanel">
            <div className="offerings-header">
              <h2>{selectedService.title}</h2>
              <p>
                <strong>{selectedService.duration}</strong> · {selectedService.price}
              </p>
            }
            </div>
            <ul className="offerings-list">
              {selectedService.outcomes.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <p className="offerings-description">
              Every engagement includes strategic leadership, product management, and end-to-end delivery support. We integrate with your
              existing teams, systems, and stakeholders to ensure alignment and momentum from day one.
            </p>
          </div>
        </div>
      </section>

      <section className="service-image">
        <div className="container">
          <img
            src="https://picsum.photos/1200/700?random=62"
            alt="Design and engineering squads collaborating on product strategy"
            loading="lazy"
          />
        </div>
      </section>

      <section className="consultation-section">
        <div className="container cta-card">
          <div>
            <h2>Let’s unlock your next growth chapter.</h2>
            <p>
              Share your biggest challenge, and we’ll assemble the right experts to co-create the solution. Expect clarity, momentum, and
              visible impact within the first sprint.
            </p>
          </div>
          <a className="btn primary large" href="/contact">
            Book a Consultation
          </a>
        </div>
      </section>
    </div>
  );
};

export default Services;