import React from 'react';

const Privacy = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">Privacy Policy</span>
          <h1>Your privacy matters—here’s how we protect it.</h1>
          <p>
            ElevateX collects and processes personal data responsibly. This policy describes the information we collect, how we use it, and
            the rights available to you.
          </p>
        </div>
      </section>

      <section className="legal-section">
        <div className="container narrow legal-content">
          <h2>Information We Collect</h2>
          <p>
            We collect information you provide directly through contact forms, inquiries, or subscription requests. We also gather limited
            technical data through analytics tools to understand website usage patterns.
          </p>

          <h2>How We Use Information</h2>
          <p>
            Data is used to respond to inquiries, deliver services, personalize experiences, and improve our offerings. We may share
            information with trusted partners who assist with operations, subject to confidentiality obligations.
          </p>

          <h2>Cookies</h2>
          <p>
            Cookies help us analyze traffic and enhance functionality. You can manage cookie preferences through your browser settings. By
            continuing to browse our site, you consent to our use of cookies.
          </p>

          <h2>Your Rights</h2>
          <p>
            Depending on your location, you may have the right to access, correct, delete, or restrict processing of your personal data. To
            exercise these rights, contact privacy@elevatex.co.
          </p>

          <h2>Security</h2>
          <p>
            We implement technical and organizational measures to protect data against unauthorized access, alteration, disclosure, or
            destruction. While we strive for security, no system can be fully guaranteed.
          </p>

          <h2>Retention</h2>
          <p>
            We retain personal information only as long as necessary to fulfill the purposes described or comply with legal obligations.
          </p>

          <h2>Changes</h2>
          <p>
            We may update this policy periodically. We encourage you to review it regularly. Continued use of our services constitutes
            acceptance of the changes.
          </p>

          <p className="legal-updated">Last updated: February 15, 2024</p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;