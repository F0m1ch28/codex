import React from 'react';

const Terms = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">Terms of Use</span>
          <h1>Understand the guidelines governing your use of ElevateX services.</h1>
          <p>
            These terms outline the rights and responsibilities between ElevateX Solutions LLC (“ElevateX”, “we”, “us”) and you, our
            visitors and clients. By accessing our website or engaging our services, you agree to these terms.
          </p>
        </div>
      </section>

      <section className="legal-section">
        <div className="container narrow legal-content">
          <h2>1. Services</h2>
          <p>
            ElevateX provides strategic consulting, design, engineering, data, and related professional services. Specific deliverables,
            scope, and fees will be detailed in mutually executed statements of work or master service agreements.
          </p>

          <h2>2. Intellectual Property</h2>
          <p>
            Pre-existing materials, frameworks, and proprietary methodologies remain the property of ElevateX. Upon full payment, newly
            created deliverables will be assigned according to the terms of the applicable agreement.
          </p>

          <h2>3. Confidentiality</h2>
          <p>
            We treat all non-public information received from clients as confidential and use it solely for delivering services. Clients
            agree to maintain confidentiality of any proprietary information shared by ElevateX.
          </p>

          <h2>4. Limitation of Liability</h2>
          <p>
            To the maximum extent permitted by law, ElevateX is not liable for indirect, incidental, or consequential damages arising from
            your use of our services or website. Our total liability shall not exceed the fees paid for the applicable services.
          </p>

          <h2>5. Acceptable Use</h2>
          <p>
            You agree not to misuse our website, interfere with its operation, or attempt unauthorized access. We reserve the right to
            suspend or terminate access if misuse is detected.
          </p>

          <h2>6. Governing Law</h2>
          <p>
            These terms are governed by the laws of the State of California, excluding its conflict of law principles. Any disputes will be
            resolved in the state or federal courts located in San Francisco County, California.
          </p>

          <h2>7. Updates</h2>
          <p>
            We may update these terms periodically. The “Last updated” date below indicates the most recent revision. Continued use after
            changes constitutes acceptance of the updated terms.
          </p>

          <p className="legal-updated">Last updated: February 15, 2024</p>
        </div>
      </section>
    </div>
  );
};

export default Terms;