import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ProgramsPage from './pages/Services';
import ContactPage from './pages/Contact';
import GuidePage from './pages/Guide';
import ToolsPage from './pages/Tools';
import BlogPage from './pages/Blog';
import LegalPage from './pages/Legal';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy, { CookiePolicy } from './pages/PrivacyPolicy';

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

const App = () => {
  return (
    <div className="app-shell">
      <Header />
      <ScrollToTopOnRouteChange />
      <main className="main-content" role="main">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/guide" element={<GuidePage />} />
          <Route path="/programs" element={<ProgramsPage />} />
          <Route path="/tools" element={<ToolsPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/legal" element={<LegalPage />} />
          <Route path="/legal/terminos" element={<TermsOfService />} />
          <Route path="/legal/privacidad" element={<PrivacyPolicy />} />
          <Route path="/legal/cookies" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;