import React, { useEffect, useState } from 'react';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  subject: '',
  message: ''
};

const ContactPage = () => {
  const [form, setForm] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  useEffect(() => {
    document.title = 'Contacto | Valentora Micado';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute('content', 'Comunícate con el equipo de Valentora Micado para conocer más sobre nuestros programas y tecnología educativa.');
    }
  }, []);

  const validate = () => {
    const currentErrors = {};
    if (!form.name.trim()) currentErrors.name = 'Ingresa tu nombre completo.';
    if (!form.email.trim()) {
      currentErrors.email = 'El correo electrónico es necesario.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/u.test(form.email)) {
      currentErrors.email = 'Proporciona un correo válido.';
    }
    if (!form.subject.trim()) currentErrors.subject = 'Especifica el motivo del mensaje.';
    if (!form.message.trim()) currentErrors.message = 'Cuéntanos cómo podemos ayudarte.';
    return currentErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const currentErrors = validate();
    if (Object.keys(currentErrors).length > 0) {
      setErrors(currentErrors);
      setStatus(null);
      return;
    }
    setStatus('enviando');
    setTimeout(() => {
      setStatus('enviado');
      setForm(initialState);
    }, 900);
  };

  return (
    <div className={styles.contact}>
      <section className={styles.header}>
        <h1>Conversemos sobre tu siguiente paso</h1>
        <p>
          Completa el formulario o comunícate directamente con nuestro equipo. Respondemos en menos de 24 horas hábiles para ofrecerte
          orientación personalizada.
        </p>
      </section>

      <div className={styles.content}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="name">
            Nombre completo
            <input
              id="name"
              name="name"
              type="text"
              value={form.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'error-name' : undefined}
              required
            />
            {errors.name && (
              <span id="error-name" className={styles.error} role="alert">
                {errors.name}
              </span>
            )}
          </label>

          <label htmlFor="email">
            Correo electrónico
            <input
              id="email"
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'error-email' : undefined}
              required
            />
            {errors.email && (
              <span id="error-email" className={styles.error} role="alert">
                {errors.email}
              </span>
            )}
          </label>

          <label htmlFor="subject">
            Tema
            <input
              id="subject"
              name="subject"
              type="text"
              value={form.subject}
              onChange={handleChange}
              aria-invalid={Boolean(errors.subject)}
              aria-describedby={errors.subject ? 'error-subject' : undefined}
              required
            />
            {errors.subject && (
              <span id="error-subject" className={styles.error} role="alert">
                {errors.subject}
              </span>
            )}
          </label>

          <label htmlFor="message">
            Mensaje
            <textarea
              id="message"
              name="message"
              rows="5"
              value={form.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'error-message' : undefined}
              required
            />
            {errors.message && (
              <span id="error-message" className={styles.error} role="alert">
                {errors.message}
              </span>
            )}
          </label>

          <button type="submit" className={styles.submit}>
            Enviar
          </button>
          {status === 'enviando' && (
            <p className={styles.info} aria-live="polite">
              Procesando tu mensaje...
            </p>
          )}
          {status === 'enviado' && (
            <p className={styles.success} aria-live="polite">
              Gracias por escribirnos, pronto nos pondremos en contacto.
            </p>
          )}
        </form>

        <aside className={styles.details}>
          <div className={styles.card}>
            <h2>Datos de contacto</h2>
            <p><strong>Teléfono:</strong> <a href="tel:+525512345678">+52 55 1234 5678</a></p>
            <p><strong>Correo:</strong> <a href="mailto:contacto@valentoramicado.site">contacto@valentoramicado.site</a></p>
            <p><strong>Dirección:</strong> Av. Reforma 250, Piso 12, Ciudad de México</p>
          </div>
          <div className={styles.card}>
            <h2>Horario de atención</h2>
            <p>Lunes a viernes de 9:00 a 18:00 (GMT-6)</p>
            <p>Sesiones especiales con previa cita los sábados.</p>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default ContactPage;