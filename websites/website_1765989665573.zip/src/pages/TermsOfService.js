import React, { useEffect } from 'react';
import styles from './TermsOfService.module.css';

const TermsOfService = () => {
  useEffect(() => {
    document.title = 'Términos de uso | Valentora Micado';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute('content', 'Consulta los términos de uso de la plataforma Valentora Micado y conoce tus responsabilidades como usuario.');
    }
  }, []);

  return (
    <div className={styles.terms}>
      <h1>Términos de uso</h1>
      <p>Última actualización: 12 de marzo de 2024</p>

      <section>
        <h2>1. Objeto</h2>
        <p>
          Estos términos regulan el acceso y uso de la plataforma Valentora Micado disponible en valentoramicado.site. Al utilizar el
          sitio, aceptas cumplir con las condiciones aquí descritas.
        </p>
      </section>

      <section>
        <h2>2. Uso permitido</h2>
        <p>
          La plataforma está destinada al fortalecimiento de habilidades profesionales de personas adultas. Te comprometes a utilizarla
          de forma responsable, a respetar la privacidad de otros participantes y a abstenerte de distribuir material que infrinja
          derechos de terceros.
        </p>
      </section>

      <section>
        <h2>3. Propiedad intelectual</h2>
        <p>
          Los contenidos, marcas, metodologías y desarrollos tecnológicos de Valentora Micado están protegidos por leyes mexicanas e
          internacionales. El uso de la plataforma no otorga licencias sobre la propiedad intelectual.
        </p>
      </section>

      <section>
        <h2>4. Acceso y disponibilidad</h2>
        <p>
          Nos reservamos el derecho de modificar, suspender o interrumpir temporalmente el servicio para labores de mantenimiento o por
          causas de fuerza mayor. Procuramos notificar oportunamente cualquier afectación.
        </p>
      </section>

      <section>
        <h2>5. Limitación de responsabilidad</h2>
        <p>
          Valentora Micado proporciona orientaciones y herramientas educativas sin garantizar resultados específicos. Las decisiones
          que tomes a partir del contenido son de tu exclusiva responsabilidad.
        </p>
      </section>

      <section>
        <h2>6. Contacto</h2>
        <p>
          Si tienes preguntas sobre estos términos, escribe a <a href="mailto:legal@valentoramicado.site">legal@valentoramicado.site</a>.
        </p>
      </section>
    </div>
  );
};

export default TermsOfService;