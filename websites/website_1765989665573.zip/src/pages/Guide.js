import React, { useEffect, useState } from 'react';
import styles from './Guide.module.css';

const steps = [
  {
    title: 'Exploración inicial',
    description: 'Conversas con nuestro asistente para mapear expectativas, motivaciones y disponibilidad.'
  },
  {
    title: 'Diagnóstico inteligente',
    description: 'La IA analiza tus respuestas y propone rutas preliminares que un mentor revisa contigo.'
  },
  {
    title: 'Experiencia inmersiva',
    description: 'Avanzas en micro-retos, sesiones sincrónicas y contenido curado según tu estilo de aprendizaje.'
  },
  {
    title: 'Evidencia y seguimiento',
    description: 'Documentamos tus logros con historias de progreso y sugerencias para futuros proyectos.'
  }
];

const knowledgeBase = [
  {
    title: 'Manual de tutores',
    detail: 'Buenas prácticas para acompañar a personas adultas con ritmos flexibles.'
  },
  {
    title: 'Guía de IA conversacional',
    detail: 'Cómo formular preguntas para obtener respuestas contextualizadas.'
  },
  {
    title: 'Plantillas de reflexión',
    detail: 'Herramientas descargables para documentar aprendizajes clave.'
  },
  {
    title: 'Metodología Valentora',
    detail: 'Marco conceptual que conecta teoría con práctica profesional.'
  }
];

const GuidePage = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    document.title = 'Guía de uso | Valentora Micado';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute('content', 'Descubre cómo funciona Valentora Micado paso a paso y conoce nuestra base de conocimiento.');
    }
  }, []);

  return (
    <div className={styles.guide}>
      <section className={styles.intro}>
        <h1>Cómo funciona Valentora Micado</h1>
        <p>
          Esta guía te acompaña desde el primer ingreso hasta la construcción de informes de logro. Puedes explorar cada fase y acceder
          a recursos específicos para perfeccionar tu experiencia.
        </p>
      </section>

      <section className={styles.tutorial}>
        <h2>Tutorial interactivo</h2>
        <div className={styles.steps}>
          <div className={styles.stepList}>
            {steps.map((step, index) => (
              <button
                type="button"
                key={step.title}
                onClick={() => setActiveIndex(index)}
                className={"${styles.stepButton} ${activeIndex === index ? styles.active : ''}"}
                aria-pressed={activeIndex === index}
              >
                <span>{index + 1}</span>
                {step.title}
              </button>
            ))}
          </div>
          <div className={styles.stepDetail}>
            <h3>{steps[activeIndex].title}</h3>
            <p>{steps[activeIndex].description}</p>
            <div className={styles.tip}>
              <strong>Consejo:</strong>{' '}
              {activeIndex === 0 && 'Comparte ejemplos concretos para que la IA entienda tu contexto profesional.'}
              {activeIndex === 1 && 'Revisa las rutas sugeridas con tu mentor para ajustar carga y prioridades.'}
              {activeIndex === 2 && 'Combina los micro-retos con tus proyectos reales para acelerar la transferencia.'}
              {activeIndex === 3 && 'Utiliza las plantillas de reflexión para describir logros medibles antes de tu sesión final.'}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.knowledge}>
        <h2>Base de conocimiento</h2>
        <div className={styles.knowledgeGrid}>
          {knowledgeBase.map((item) => (
            <article key={item.title} className={styles.knowledgeCard}>
              <h3>{item.title}</h3>
              <p>{item.detail}</p>
              <span className={styles.badge}>Actualizado</span>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default GuidePage;