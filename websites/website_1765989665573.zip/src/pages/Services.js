import React, { useEffect } from 'react';
import styles from './Services.module.css';

const programs = [
  {
    name: 'Programa Horizonte',
    focus: 'Transición de liderazgo y gestión de cambio',
    description:
      'Ideal para personas que asumen nuevas responsabilidades directivas. Integra simuladores de decisiones y mentoría en comunicación estratégica.',
    format: 'Sesiones híbridas, cohortes de 10 personas',
    length: '12 semanas'
  },
  {
    name: 'Programa Prisma',
    focus: 'Competencias digitales aplicadas',
    description:
      'Explora automatización, analítica descriptiva y colaboración remota. La IA adapta proyectos prácticos para sectores como retail, servicios y manufactura.',
    format: 'Retos semanales acompañados de feedback asíncrono',
    length: '8 semanas'
  },
  {
    name: 'Programa Aurora',
    focus: 'Creatividad y pensamiento crítico',
    description:
      'Diseñado para consultores y managers que requieren pensamiento sistémico. Incluye laboratorios de ideas guiados por nuestro motor conversacional.',
    format: 'Laboratorios virtuales + sesiones de co-diseño',
    length: '10 semanas'
  },
  {
    name: 'Programa Brújula',
    focus: 'Planeación de carrera y propósito profesional',
    description:
      'Acompañamiento personalizado para redefinir objetivos, construir portafolio y fortalecer habilidades comunicativas.',
    format: 'Mentoría individual complementada con IA reflexiva',
    length: '6 semanas'
  }
];

const ProgramsPage = () => {
  useEffect(() => {
    document.title = 'Programas de aprendizaje | Valentora Micado';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute('content', 'Explora los programas de Valentora Micado diseñados para personas adultas con apoyo de inteligencia artificial.');
    }
  }, []);

  return (
    <div className={styles.programs}>
      <header className={styles.header}>
        <h1>Programas pensados para realidades adultas</h1>
        <p>
          Cada programa se co-diseña con especialistas del ecosistema mexicano y se actualiza continuamente según la retroalimentación
          de participantes y datos del motor cognitivo.
        </p>
      </header>

      <div className={styles.grid}>
        {programs.map((program) => (
          <article key={program.name} className={styles.card}>
            <div className={styles.cardHeader}>
              <h2>{program.name}</h2>
              <p className={styles.focus}>{program.focus}</p>
            </div>
            <p>{program.description}</p>
            <ul className={styles.meta}>
              <li><span>Formato:</span> {program.format}</li>
              <li><span>Duración:</span> {program.length}</li>
            </ul>
          </article>
        ))}
      </div>

      <section className={styles.outcomes}>
        <h2>Lo que obtienes al finalizar</h2>
        <ul>
          <li>Informe narrativo personalizado con métricas de progreso y recomendaciones inmediatas.</li>
          <li>Repositorio de recursos curados según tu perfil y metas futuras.</li>
          <li>Acceso a comunidad de práctica con conversaciones moderadas por mentores.</li>
        </ul>
      </section>
    </div>
  );
};

export default ProgramsPage;