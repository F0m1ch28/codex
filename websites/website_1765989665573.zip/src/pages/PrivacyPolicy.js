import React, { useEffect } from 'react';
import styles from './PrivacyPolicy.module.css';

const PrivacyPolicy = () => {
  useEffect(() => {
    document.title = 'Política de privacidad | Valentora Micado';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute('content', 'Revisa cómo Valentora Micado protege tus datos personales y en qué casos los utiliza.');
    }
  }, []);

  return (
    <div className={styles.privacy}>
      <h1>Política de privacidad</h1>
      <p>Última actualización: 12 de marzo de 2024</p>

      <section>
        <h2>1. Responsable del tratamiento</h2>
        <p>
          Valentora Micado S.A.P.I. de C.V., con domicilio en Av. Reforma 250, Piso 12, Ciudad de México, es responsable del tratamiento
          de los datos personales que nos proporcionas.
        </p>
      </section>

      <section>
        <h2>2. Datos tratados</h2>
        <p>
          Tratamos información de contacto, trayectoria profesional, preferencias de aprendizaje y datos de interacción con la
          plataforma. No solicitamos datos sensibles sin tu consentimiento explícito.
        </p>
      </section>

      <section>
        <h2>3. Finalidades</h2>
        <p>
          Utilizamos tus datos para crear experiencias educativas personalizadas, gestionar tu participación en programas, emitir
          reportes de avance y comunicarnos contigo. También analizamos datos anonimizados para mejorar nuestros servicios.
        </p>
      </section>

      <section>
        <h2>4. Derechos ARCO</h2>
        <p>
          Puedes ejercer tus derechos de acceso, rectificación, cancelación y oposición enviando un correo a{' '}
          <a href="mailto:privacidad@valentoramicado.site">privacidad@valentoramicado.site</a>. Responderemos en un plazo máximo de 20 días hábiles.
        </p>
      </section>

      <section>
        <h2>5. Transferencias</h2>
        <p>
          Compartimos datos únicamente con proveedores que respaldan la operación de la plataforma y garantizan estándares de protección.
          No comercializamos información personal.
        </p>
      </section>
    </div>
  );
};

export const CookiePolicy = () => {
  useEffect(() => {
    document.title = 'Política de cookies | Valentora Micado';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute('content', 'Conoce cómo Valentora Micado utiliza cookies para mejorar tu experiencia de aprendizaje.');
    }
  }, []);

  return (
    <div className={styles.cookies}>
      <h1>Política de cookies</h1>
      <p>Última actualización: 12 de marzo de 2024</p>

      <section>
        <h2>¿Qué son las cookies?</h2>
        <p>
          Son pequeños archivos de texto que se almacenan en tu dispositivo para recordar preferencias y mejorar la navegación.
        </p>
      </section>

      <section>
        <h2>Tipos de cookies que usamos</h2>
        <ul>
          <li><strong>Esenciales:</strong> permiten el funcionamiento básico de la plataforma.</li>
          <li><strong>De análisis:</strong> nos ayudan a comprender el uso del sitio de forma agregada.</li>
          <li><strong>De personalización:</strong> adaptan contenidos a tu estilo de aprendizaje.</li>
        </ul>
      </section>

      <section>
        <h2>Gestión</h2>
        <p>
          Puedes ajustar tus preferencias desde la configuración de tu navegador o contactarnos en{' '}
          <a href="mailto:privacidad@valentoramicado.site">privacidad@valentoramicado.site</a>.
        </p>
      </section>
    </div>
  );
};

export default PrivacyPolicy;