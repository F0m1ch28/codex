import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const HomePage = () => {
  useEffect(() => {
    document.title = 'Valentora Micado | Aprendizaje adulto guiado por IA';
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute(
        'content',
        'Valentora Micado ofrece itinerarios personalizados, mentoría y herramientas con inteligencia artificial para profesionales adultos en México.'
      );
    }
  }, []);

  const beneficios = [
    {
      title: 'Rutas personalizadas',
      description:
        'Detectamos tus habilidades actuales y preferencia de aprendizaje para diseñar un itinerario coherente con tus objetivos profesionales.'
    },
    {
      title: 'Mentoría humana',
      description:
        'Especialistas certificados acompañan cada avance con retroalimentación tranquila y accionable, reforzada por analítica de IA.'
    },
    {
      title: 'Aprendizaje aplicado',
      description:
        'Cada módulo se integra con escenarios reales del contexto mexicano para acelerar la transferencia al entorno laboral.'
    }
  ];

  const pasos = [
    {
      title: 'Diagnóstico integral',
      detail: 'Una conversación guiada por IA analiza intereses, ritmo y experiencia previa para crear un perfil holístico.'
    },
    {
      title: 'Ruta curada',
      detail: 'Seleccionamos micro-retos y materiales multimedia que responden a tu forma preferida de aprender.'
    },
    {
      title: 'Acompañamiento continuo',
      detail: 'Mentores especializados y bots cognitivos ofrecen seguimiento puntual y sugerencias de mejora.'
    },
    {
      title: 'Evidencia de logros',
      detail: 'Generamos informes narrativos que describen habilidades adquiridas y recomendaciones de evolución profesional.'
    }
  ];

  const testimonios = [
    {
      name: 'Ana Valdés',
      role: 'Directora de talento, Guadalajara',
      quote:
        'La combinación de análisis inteligente y coaching humano me permitió reorientar a mi equipo en menos de tres meses sin estrés.',
      image: 'https://picsum.photos/seed/ana-valdes/200'
    },
    {
      name: 'Mauricio Ortega',
      role: 'Consultor independiente, CDMX',
      quote:
        'Me sorprendió la claridad de los informes y la forma en que la IA interpreta mis hábitos. Logré integrar nuevas metodologías con confianza.',
      image: 'https://picsum.photos/seed/mauricio-ortega/200'
    },
    {
      name: 'Rebeca Flores',
      role: 'Especialista de operaciones, Monterrey',
      quote:
        'Las sesiones híbridas son flexibles y profundas. Pude documentar mis aprendizajes para mis evaluaciones internas con facilidad.',
      image: 'https://picsum.photos/seed/rebeca-flores/200'
    }
  ];

  const recursos = [
    {
      title: 'Guía práctica de microaprendizaje',
      description: 'Descubre cómo fragmentar metas complejas en hábitos semanales sostenibles.',
      link: '/blog'
    },
    {
      title: 'Checklist de competencias digitales',
      description: 'Evalúa la madurez digital de tu equipo y planifica próximas acciones.',
      link: '/guide'
    },
    {
      title: 'Mapa de conversación con IA',
      description: 'Aprende a dialogar con nuestro motor semántico para obtener las respuestas más útiles.',
      link: '/tools'
    }
  ];

  return (
    <div className={styles.home}>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.kicker}>Plataforma mexicana para aprendizaje adulto</p>
          <h1>Impulsa tu evolución con inteligencia artificial y humanidad experta</h1>
          <p className={styles.subtitle}>
            Valentora Micado integra analítica semántica, diseño instruccional y mentoría para acompañarte en cada etapa
            profesional con serenidad y enfoque estratégico.
          </p>
          <div className={styles.heroActions}>
            <Link to="/programs" className={styles.primaryButton}>
              Explorar programas
            </Link>
            <Link to="/guide" className={styles.secondaryButton}>
              Ver cómo funciona
            </Link>
          </div>
        </div>
        <div className={styles.heroVisual} role="presentation" aria-hidden="true">
          <img src="https://picsum.photos/seed/valentora-hero/520/520" alt="" loading="lazy" />
        </div>
      </section>

      <section className={styles.intro}>
        <div className={styles.introText}>
          <h2>Aprendizaje diseñado para la vida real</h2>
          <p>
            Nuestro enfoque se centra en la experiencia acumulada de cada persona adulta. A través de modelos de IA que interpretan
            contexto, emociones y objetivos, logramos itinerarios equilibrados, sin sobrecarga cognitiva y con resultados visibles.
          </p>
        </div>
        <div className={styles.introMetrics}>
          <article>
            <h3>92%</h3>
            <p>de participantes reportan mayor claridad estratégica en sus roles.</p>
          </article>
          <article>
            <h3>18 hrs</h3>
            <p>promedio de acompañamiento profundo durante los primeros dos meses.</p>
          </article>
          <article>
            <h3>4.8/5</h3>
            <p>valoración de la experiencia integral en sesiones síncronas e híbridas.</p>
          </article>
        </div>
      </section>

      <section className={styles.benefits}>
        <h2>Lo que hace diferente a Valentora Micado</h2>
        <div className={styles.benefitGrid}>
          {beneficios.map((beneficio) => (
            <article key={beneficio.title} className={styles.benefitCard}>
              <h3>{beneficio.title}</h3>
              <p>{beneficio.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.method}>
        <div className={styles.methodText}>
          <h2>Un proceso que se ajusta a tu ritmo</h2>
          <p>
            Nuestras recomendaciones evolucionan a medida que avanzas. Cada hito nutre al modelo cognitivo, que propone nuevas
            rutas y mantiene un equilibrio saludable entre teoría, experimentación y reflexión.
          </p>
        </div>
        <ol className={styles.methodList}>
          {pasos.map((paso) => (
            <li key={paso.title}>
              <h3>{paso.title}</h3>
              <p>{paso.detail}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className={styles.testimonials} aria-label="Testimonios de participantes">
        <h2>Historias de quien confió en nosotros</h2>
        <div className={styles.testimonialGrid}>
          {testimonios.map((testimonio) => (
            <article key={testimonio.name} className={styles.testimonialCard}>
              <img src={testimonio.image} alt={"Retrato de ${testimonio.name}"} loading="lazy" />
              <blockquote>
                <p>{testimonio.quote}</p>
              </blockquote>
              <div className={styles.testimonialMeta}>
                <span className={styles.name}>{testimonio.name}</span>
                <span className={styles.role}>{testimonio.role}</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.resources}>
        <h2>Recursos que puedes explorar hoy</h2>
        <div className={styles.resourceGrid}>
          {recursos.map((resource) => (
            <article key={resource.title} className={styles.resourceCard}>
              <h3>{resource.title}</h3>
              <p>{resource.description}</p>
              <Link to={resource.link} className={styles.link}>
                Ver detalles →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Conecta con una evolución basada en propósito</h2>
          <p>
            Reserva una sesión introductoria para comprender cómo la IA contextualizada puede respaldar tus proyectos y
            construir hábitos de aprendizaje sostenibles.
          </p>
          <Link to="/contact" className={styles.primaryButton}>
            Agendar conversación
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;