import React, { useEffect } from 'react';
import styles from './Tools.module.css';

const tools = [
  {
    name: 'Motor semántico Valentora',
    description:
      'Analiza tus interacciones y selecciona recursos alineados a tu estilo de aprendizaje y contexto profesional.',
    impact: 'Reduce el tiempo de búsqueda de recursos en 45%.'
  },
  {
    name: 'Panel de mentoría',
    description:
      'Los especialistas visualizan tu progreso, recomendaciones de IA y notas clave para ofrecer acompañamiento preciso.',
    impact: 'Favorece retroalimentación personalizada en cada sesión.'
  },
  {
    name: 'Cuaderno reflexivo inteligente',
    description:
      'Notas guiadas por IA que generan resúmenes y sugerencias automáticas para transformar aprendizajes en acciones.',
    impact: 'Facilita la documentación de logros y próximos pasos concretos.'
  }
];

const ToolsPage = () => {
  useEffect(() => {
    document.title = 'Tecnología y herramientas | Valentora Micado';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute('content', 'Conoce las herramientas impulsadas por inteligencia artificial que respaldan nuestros programas de aprendizaje.');
    }
  }, []);

  return (
    <div className={styles.tools}>
      <section className={styles.hero}>
        <h1>Tecnología que respalda el aprendizaje humano</h1>
        <p>
          Nuestra infraestructura combina modelos de lenguaje, analítica visual y dashboards intuitivos. Todo se integra con protocolos
          éticos y prácticas de protección de datos basadas en los estándares mexicanos.
        </p>
      </section>

      <section className={styles.toolGrid}>
        {tools.map((tool) => (
          <article key={tool.name} className={styles.card}>
            <h2>{tool.name}</h2>
            <p>{tool.description}</p>
            <div className={styles.impact}>
              <strong>Impacto:</strong> {tool.impact}
            </div>
          </article>
        ))}
      </section>

      <section className={styles.security}>
        <div className={styles.securityContent}>
          <h2>Seguridad y ética</h2>
          <p>
            Implementamos encriptación, controles de acceso por roles y procesos de auditoría periódica. Colaboramos con comités externos
            para monitorear sesgos y garantizar interpretabilidad en nuestras recomendaciones.
          </p>
        </div>
        <div className={styles.securityImage} role="presentation" aria-hidden="true">
          <img src="https://picsum.photos/seed/tools-valentora/520/360" alt="" loading="lazy" />
        </div>
      </section>
    </div>
  );
};

export default ToolsPage;