import React, { useEffect } from 'react';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Aprendizaje adulto sin sobrecarga',
    excerpt: 'Estrategias para dosificar información y favorecer la práctica deliberada en profesionales con agendas intensas.',
    date: '8 marzo 2024',
    author: 'Luciana Herrera',
    image: 'https://picsum.photos/seed/blog-aprendizaje/460/300'
  },
  {
    title: 'Mentoría y datos: duetos necesarios',
    excerpt: 'Cómo combinar insights algorítmicos y conversaciones humanas para generar planes de acción confiables.',
    date: '1 marzo 2024',
    author: 'Javier Molina',
    image: 'https://picsum.photos/seed/blog-mentoria/460/300'
  },
  {
    title: 'Comunidades que sostienen hábitos',
    excerpt: 'Buenas prácticas para construir espacios colaborativos que promuevan la reflexión continua.',
    date: '21 febrero 2024',
    author: 'Sofía Peralta',
    image: 'https://picsum.photos/seed/blog-comunidad/460/300'
  }
];

const BlogPage = () => {
  useEffect(() => {
    document.title = 'Blog y recursos | Valentora Micado';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute('content', 'Explora ideas, guías y tendencias sobre aprendizaje para personas adultas en el blog de Valentora Micado.');
    }
  }, []);

  return (
    <div className={styles.blog}>
      <header className={styles.header}>
        <h1>Ideas para nutrir el aprendizaje continuo</h1>
        <p>
          Reunimos reflexiones, guías descargables y entrevistas con especialistas para mantener viva la curiosidad y fortalecer tus
          habilidades profesionales.
        </p>
      </header>

      <div className={styles.grid}>
        {posts.map((post) => (
          <article key={post.title} className={styles.card}>
            <img src={post.image} alt={"Imagen del artículo ${post.title}"} loading="lazy" />
            <div className={styles.cardBody}>
              <span className={styles.meta}>{post.date} · {post.author}</span>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <button type="button" className={styles.readMore}>
                Seguir leyendo
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default BlogPage;