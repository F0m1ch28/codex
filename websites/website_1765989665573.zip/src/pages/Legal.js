import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './Legal.module.css';

const LegalPage = () => {
  useEffect(() => {
    document.title = 'Información legal | Valentora Micado';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute('content', 'Accede a los documentos legales y de cumplimiento de Valentora Micado.');
    }
  }, []);

  return (
    <div className={styles.legal}>
      <section className={styles.intro}>
        <h1>Información legal y cumplimiento</h1>
        <p>
          La transparencia es un pilar de Valentora Micado. Consulta nuestros documentos legales, políticas de privacidad y lineamientos
          de uso responsable.
        </p>
      </section>

      <div className={styles.grid}>
        <article>
          <h2>Términos de uso</h2>
          <p>Conoce las condiciones que aplican al utilizar nuestros servicios y plataformas.</p>
          <Link to="/legal/terminos">Revisar términos</Link>
        </article>
        <article>
          <h2>Política de privacidad</h2>
          <p>Descubre cómo protegemos y utilizamos tus datos personales en cada interacción.</p>
          <Link to="/legal/privacidad">Ver privacidad</Link>
        </article>
        <article>
          <h2>Política de cookies</h2>
          <p>Infórmate sobre las cookies utilizadas y cómo puedes administrar tus preferencias.</p>
          <Link to="/legal/cookies">Ver cookies</Link>
        </article>
      </div>
    </div>
  );
};

export default LegalPage;