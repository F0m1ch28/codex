import React, { useEffect } from 'react';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Luciana Herrera',
    role: 'Directora de estrategia educativa',
    bio: 'Diseña experiencias de aprendizaje basadas en evidencia y lidera la comunidad de mentores nacionales.',
    image: 'https://picsum.photos/seed/luciana-herrera/280'
  },
  {
    name: 'Javier Molina',
    role: 'Arquitecto de inteligencia artificial',
    bio: 'Coordina el motor semántico de Valentora Micado y vela por la ética algorítmica en cada interacción.',
    image: 'https://picsum.photos/seed/javier-molina/280'
  },
  {
    name: 'Sofía Peralta',
    role: 'Responsable de acompañamiento',
    bio: 'Conecta a participantes con especialistas y cultiva la cultura de bienestar y aprendizaje continuo.',
    image: 'https://picsum.photos/seed/sofia-peralta/280'
  }
];

const AboutPage = () => {
  useEffect(() => {
    document.title = 'Quiénes somos | Valentora Micado';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute('content', 'Conoce al equipo de Valentora Micado y nuestra visión sobre el aprendizaje adulto apoyado por inteligencia artificial.');
    }
  }, []);

  return (
    <div className={styles.about}>
      <section className={styles.story}>
        <h1>Nuestra historia</h1>
        <p>
          Valentora Micado nace en Ciudad de México con la convicción de que el aprendizaje adulto requiere respeto por la trayectoria
          y herramientas que se adapten a ritmos reales. Desde 2019 articulamos conocimiento científico, datos y humanidad para crear
          experiencias memorables que fortalecen la confianza profesional.
        </p>
        <p>
          Combinamos metodología basada en teorías de aprendizaje continuo con analítica responsable. Cada recomendación se fundamenta
          en datos claros y en conversaciones profundas con especialistas que acompañan la toma de decisiones.
        </p>
      </section>

      <section className={styles.values}>
        <h2>Nuestros principios</h2>
        <div className={styles.valueGrid}>
          <article>
            <h3>Respeto humano</h3>
            <p>Reconocemos la trayectoria y el ritmo de cada persona para construir aprendizajes personalizados.</p>
          </article>
          <article>
            <h3>IA ética</h3>
            <p>Garantizamos modelos transparentes, auditados y libres de sesgos discriminatorios.</p>
          </article>
          <article>
            <h3>Impacto sostenible</h3>
            <p>Fomentamos prácticas que produzcan cambios sostenibles en equipos y comunidades laborales.</p>
          </article>
        </div>
      </section>

      <section className={styles.team}>
        <h2>Equipo directivo</h2>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={"Retrato de ${member.name}"} loading="lazy" />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <p className={styles.role}>{member.role}</p>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.vision}>
        <h2>Visión a futuro</h2>
        <p>
          Aspiramos a que cada organización en México cuente con estrategias de aprendizaje que celebren la curiosidad adulta. Estamos
          expandiendo nuestro ecosistema de socios académicos y especialistas para dar soporte a diversas industrias que necesitan
          innovación constante.
        </p>
      </section>
    </div>
  );
};

export default AboutPage;