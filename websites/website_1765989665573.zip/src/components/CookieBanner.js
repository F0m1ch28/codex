import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'valentora-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  const handleReject = () => {
    localStorage.setItem(STORAGE_KEY, 'rejected');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Aviso de uso de cookies">
      <p>
        Utilizamos cookies para comprender mejor tus necesidades y mejorar la experiencia de aprendizaje. Consulta nuestra{' '}
        <Link to="/legal/cookies">Política de cookies</Link>.
      </p>
      <div className={styles.actions}>
        <button type="button" className={styles.accept} onClick={handleAccept}>
          Aceptar
        </button>
        <button type="button" className={styles.reject} onClick={handleReject}>
          Configurar / Rechazar
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;