import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.columns}>
        <div className={styles.column}>
          <h3 className={styles.title}>Valentora Micado</h3>
          <p>
            Plataforma mexicana que combina inteligencia artificial con acompañamiento humano para impulsar el aprendizaje
            significativo de personas adultas.
          </p>
        </div>
        <div className={styles.column}>
          <h4>Explora</h4>
          <ul className={styles.links}>
            <li><Link to="/guide">Cómo funciona</Link></li>
            <li><Link to="/programs">Programas</Link></li>
            <li><Link to="/tools">Tecnología</Link></li>
            <li><Link to="/blog">Blog</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4>Contacto</h4>
          <ul className={styles.contactList}>
            <li><a href="tel:+525512345678">+52 55 1234 5678</a></li>
            <li><a href="mailto:contacto@valentoramicado.site">contacto@valentoramicado.site</a></li>
            <li>Av. Reforma 250, Piso 12, Ciudad de México</li>
          </ul>
          <div className={styles.socials} aria-label="Enlaces a redes sociales">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn Valentora Micado">
              in
            </a>
            <a href="https://www.facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook Valentora Micado">
              f
            </a>
            <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram Valentora Micado">
              ig
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Valentora Micado. Todos los derechos reservados.</p>
        <div className={styles.bottomLinks}>
          <Link to="/legal">Información legal</Link>
          <Link to="/legal/terminos">Términos</Link>
          <Link to="/legal/privacidad">Privacidad</Link>
          <Link to="/legal/cookies">Cookies</Link>
        </div>
      </div>
    </footer>
  );
};

export default Footer;