import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} aria-label="Inicio Valentora Micado">
          Valentora <span>Micado</span>
        </NavLink>
        <button
          className={styles.menuToggle}
          aria-label="Abrir menú principal"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <span className={styles.menuIcon} />
        </button>
        <nav className={"${styles.nav} ${menuOpen ? styles.navOpen : ''}"} aria-label="Navegación principal">
          <NavLink to="/guide" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
            Guía
          </NavLink>
          <NavLink to="/programs" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
            Programas
          </NavLink>
          <NavLink to="/tools" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
            Herramientas
          </NavLink>
          <NavLink to="/blog" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
            Blog
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
            Sobre nosotros
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => (isActive ? "${styles.navLink} ${styles.active}" : styles.navLink)}>
            Contacto
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;