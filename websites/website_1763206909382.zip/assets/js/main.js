document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navList = document.querySelector(".nav-list");
    const scrollButton = document.querySelector(".scroll-to-top");
    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptCookiesButton = document.getElementById("accept-cookies");
    const currentYearSpan = document.getElementById("current-year");

    // Mobile navigation toggle
    if (navToggle && navList) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            navList.classList.toggle("open");
        });

        navList.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navToggle.setAttribute("aria-expanded", "false");
                navList.classList.remove("open");
                window.scrollTo({ top: 0, behavior: "smooth" });
            });
        });
    }

    // Scroll to top button
    window.addEventListener("scroll", () => {
        if (window.scrollY > 300) {
            scrollButton.style.display = "flex";
        } else {
            scrollButton.style.display = "none";
        }
    });

    if (scrollButton) {
        scrollButton.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    // Cookie banner
    if (cookieBanner && acceptCookiesButton) {
        const cookieConsent = localStorage.getItem("na-cookie-consent");
        if (!cookieConsent) {
            cookieBanner.style.display = "block";
        }

        acceptCookiesButton.addEventListener("click", () => {
            localStorage.setItem("na-cookie-consent", "accepted");
            cookieBanner.style.display = "none";
        });
    }

    // Footer year
    if (currentYearSpan) {
        currentYearSpan.textContent = new Date().getFullYear();
    }
});