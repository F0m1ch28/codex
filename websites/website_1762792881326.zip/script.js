document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    const scrollTopBtn = document.getElementById('scrollTop');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookiesBtn = document.getElementById('accept-cookies');
    const currentYear = document.getElementById('current-year');
    const navAnchors = document.querySelectorAll('.nav-links a');
    const contactForm = document.getElementById('contactForm');
    const formStatus = document.getElementById('form-status');

    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }

    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', () => {
            const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
            menuToggle.setAttribute('aria-expanded', !expanded);
            navLinks.classList.toggle('show');
        });
    }

    if (navAnchors) {
        navAnchors.forEach(anchor => {
            anchor.addEventListener('click', () => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
                if (navLinks && navLinks.classList.contains('show')) {
                    navLinks.classList.remove('show');
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const toggleScrollButton = () => {
        if (window.scrollY > 200) {
            scrollTopBtn.style.display = 'flex';
        } else {
            scrollTopBtn.style.display = 'none';
        }
    };

    if (scrollTopBtn) {
        window.addEventListener('scroll', toggleScrollButton);
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && acceptCookiesBtn) {
        const cookieConsent = localStorage.getItem('gne_cookie_consent');
        if (cookieConsent === 'accepted') {
            cookieBanner.style.display = 'none';
        }
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('gne_cookie_consent', 'accepted');
            cookieBanner.style.display = 'none';
        });
    }

    if (contactForm && formStatus) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            formStatus.textContent = 'Thank you. We will reach out within two business days.';
            contactForm.reset();
        });
    }
});