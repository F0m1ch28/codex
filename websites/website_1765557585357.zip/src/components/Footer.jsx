```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.about}>
          <div className={styles.logo}>🎨 Сколько вариантов сайта создать?</div>
          <p>
            Креативная команда из Москвы, объединяющая дизайнеров, разработчиков и стратегов.
            Проектируем digital-опыт, который помогает брендам говорить на одном языке с аудиторией.
          </p>
        </div>
        <div className={styles.columns}>
          <div>
            <h3 className={styles.columnTitle}>Навигация</h3>
            <ul className={styles.linkList}>
              <li><Link to="/">Главная</Link></li>
              <li><Link to="/uslugi">Услуги</Link></li>
              <li><Link to="/portfolio">Портфолио</Link></li>
              <li><Link to="/process">Процесс</Link></li>
              <li><Link to="/kontakty">Контакты</Link></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.columnTitle}>Контакты</h3>
            <ul className={styles.linkList}>
              <li>г. Москва, ул. Тверская, д. 10, офис 45</li>
              <li><a href="tel:+74951234567">+7 (495) 123-45-67</a></li>
              <li><a href="mailto:info@skolko-variantov.ru">info@skolko-variantov.ru</a></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.columnTitle}>Правовая информация</h3>
            <ul className={styles.linkList}>
              <li><Link to="/terms">Условия использования</Link></li>
              <li><Link to="/privacy">Политика конфиденциальности</Link></li>
              <li><Link to="/cookie-policy">Политика использования cookie</Link></li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        © {currentYear} 🎨 Сколько вариантов сайта создать? Все права защищены.
      </div>
    </footer>
  );
};

export default Footer;
```