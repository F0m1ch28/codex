```javascript
import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CONSENT_KEY = 'sv-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    try {
      const consent = localStorage.getItem(CONSENT_KEY);
      if (!consent) {
        setIsVisible(true);
      }
    } catch (error) {
      setIsVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    try {
      localStorage.setItem(CONSENT_KEY, choice);
    } catch (error) {
      // ignore write errors
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        Мы используем файлы cookie, чтобы улучшить работу сайта и анализировать взаимодействие пользователей.
        Подробности в нашей&nbsp;
        <a href="/cookie-policy">Политике cookie</a>.
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.accept} onClick={() => handleChoice('accepted')}>
          Принять
        </button>
        <button type="button" className={styles.decline} onClick={() => handleChoice('declined')}>
          Отклонить
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;
```