```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import layoutStyles from '../styles/Layout.module.css';
import styles from './LegalPages.module.css';

const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Политика использования cookies — 🎨 Сколько вариантов сайта создать?</title>
      <meta
        name="description"
        content="Политика использования cookies агентства «🎨 Сколько вариантов сайта создать?» объясняет, какие файлы cookie мы применяем и как управлять настройками."
      />
    </Helmet>

    <section className={layoutStyles.sectionPadding}>
      <div className={`${layoutStyles.container} ${styles.content}`}>
        <h1>Политика использования файлов cookie</h1>
        <p>Дата обновления: 5 января 2024 года.</p>

        <h2>1. Что такое cookie</h2>
        <p>
          Cookie — это небольшие текстовые файлы, размещаемые на устройстве пользователя при посещении сайта.
          Они помогают распознавать устройство и улучшать пользовательский опыт.
        </p>

        <h2>2. Какие cookie мы используем</h2>
        <ul>
          <li><strong>Обязательные</strong> — обеспечивают базовую работу сайта, например, запоминают состояние cookie-баннера.</li>
          <li><strong>Аналитические</strong> — собирают обезличенные данные о поведении пользователей для улучшения сервиса.</li>
          <li><strong>Функциональные</strong> — сохраняют предпочтения пользователя, чтобы персонализировать интерфейс.</li>
        </ul>

        <h2>3. Как управлять cookie</h2>
        <p>
          Вы можете принять или отклонить использование cookie через баннер на сайте. Кроме того, настройте работу cookie в настройках браузера. 
          Обратите внимание, что отключение некоторых cookie может повлиять на корректность работы отдельных разделов.
        </p>

        <h2>4. Обновления политики</h2>
        <p>
          В случае изменений мы обновим текст политики и дату последнего обновления. Продолжая использовать сайт после изменений, вы подтверждаете согласие с обновленной политикой.
        </p>

        <h2>5. Контакты</h2>
        <p>
          Вопросы о cookie направляйте на <a href="mailto:info@skolko-variantov.ru">info@skolko-variantov.ru</a> или звоните <a href="tel:+74951234567">+7 (495) 123-45-67</a>.
        </p>
      </div>
    </section>
  </div>
);

export default CookiePolicyPage;
```