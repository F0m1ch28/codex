```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import layoutStyles from '../styles/Layout.module.css';
import styles from './ServicesPage.module.css';

const services = [
  {
    title: 'Исследование и стратегия',
    description: 'Проводим интервью, анализируем конкурентов, формируем гипотезы и customer journey. Готовим дорожную карту проекта и критерии эффективности.',
    items: ['Сессии с командой', 'Аналитика и аудит', 'Постановка KPI', 'Контентная стратегия']
  },
  {
    title: 'UX-концепция и прототипирование',
    description: 'Разрабатываем структуру сайта, сценарии взаимодействия и прототипы, проверяем гипотезы на ранних этапах и собираем обратную связь.',
    items: ['UX-исследование', 'Информационная архитектура', 'Интерактивные прототипы', 'Юзабилити-тесты']
  },
  {
    title: 'UI-дизайн и дизайн-система',
    description: 'Создаем визуальный стиль, адаптируем бренд под digital, собираем дизайн-систему и гайдлайны для будущего развития.',
    items: ['Концепты и визуал', 'Дизайн-система', 'Анимации и микровзаимодействия', 'Гайдлайны']
  },
  {
    title: 'Фронтенд и интеграции',
    description: 'Верстаем responsive-интерфейсы, работаем с React, подключаем API и CMS, обеспечиваем высокую производительность и защиту.',
    items: ['Адаптивная верстка', 'React/Next.js', 'CMS и CRM', 'Тестирование и доступность']
  },
  {
    title: 'Контент и запуск',
    description: 'Помогаем подготовить контент, переносим материалы, проводим финальную проверку, сопровождаем при запуске и обучаем команду.',
    items: ['Контент-менеджмент', 'SEO-ready структура', 'Настройка аналитики', 'Онбординг команды']
  },
  {
    title: 'Поддержка и развитие',
    description: 'Следим за стабильностью, анализируем показатели, предлагаем улучшения и внедряем новые функции по мере роста проекта.',
    items: ['Мониторинг', 'Оптимизация', 'Новые фичи', 'Техническая поддержка']
  }
];

const ServicesPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Услуги — 🎨 Сколько вариантов сайта создать?</title>
      <meta
        name="description"
        content="Полный спектр услуг по дизайну и разработке сайтов: исследования, UX/UI, фронтенд, интеграции, контент и поддержка. Создаем digital-решения под цели бизнеса."
      />
      <meta
        name="keywords"
        content="услуги по разработке сайтов, UX исследования, UI дизайн, фронтенд, поддержка сайта"
      />
    </Helmet>

    <section className={`${layoutStyles.sectionPadding} ${styles.hero}`}>
      <div className={layoutStyles.container}>
        <h1 className={styles.title}>Что мы делаем для вашего проекта</h1>
        <p className={styles.subtitle}>
          Подбираем команду под задачу — от стратегов и продюсеров до дизайнеров и разработчиков.
          Формируем прозрачный процесс, где каждое решение опирается на данные и цели бизнеса.
        </p>
      </div>
    </section>

    <section className={layoutStyles.sectionPadding}>
      <div className={layoutStyles.container}>
        <div className={styles.grid}>
          {services.map((service) => (
            <article key={service.title} className={styles.card}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <ul>
                {service.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default ServicesPage;
```