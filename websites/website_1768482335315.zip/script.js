document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-open');
            navMenu.classList.toggle('is-open');
        });
        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('is-open');
                navMenu.classList.remove('is-open');
            });
        });
    }

    const banner = document.querySelector('[data-cookie-banner]');
    if (banner) {
        const acceptBtn = banner.querySelector('[data-accept-cookies]');
        const declineBtn = banner.querySelector('[data-decline-cookies]');
        const customizeBtn = banner.querySelector('[data-customize-cookies]');
        const consentState = localStorage.getItem('gcCookieConsent');

        if (!consentState) {
            banner.classList.add('is-visible');
        }

        acceptBtn?.addEventListener('click', () => {
            localStorage.setItem('gcCookieConsent', 'accepted');
            banner.classList.remove('is-visible');
        });

        declineBtn?.addEventListener('click', () => {
            localStorage.setItem('gcCookieConsent', 'declined');
            banner.classList.remove('is-visible');
        });

        customizeBtn?.addEventListener('click', () => {
            window.location.href = 'cookies.html';
        });
    }
});