document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      mainNav.classList.toggle('is-open');
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
    });

    mainNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        mainNav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.querySelector('[data-cookie-banner]');
  if (cookieBanner) {
    const cookieAccept = cookieBanner.querySelector('[data-cookie-accept]');
    const cookieDecline = cookieBanner.querySelector('[data-cookie-decline]');
    const cookieConsent = localStorage.getItem('cookieConsent');

    if (!cookieConsent) {
      cookieBanner.classList.add('is-visible');
    }

    if (cookieAccept) {
      cookieAccept.addEventListener('click', () => {
        localStorage.setItem('cookieConsent', 'accepted');
        cookieBanner.classList.remove('is-visible');
      });
    }

    if (cookieDecline) {
      cookieDecline.addEventListener('click', () => {
        localStorage.setItem('cookieConsent', 'declined');
        cookieBanner.classList.remove('is-visible');
      });
    }
  }

  const sliders = document.querySelectorAll('[data-slider]');
  sliders.forEach(slider => {
    const track = slider.querySelector('.slider-track');
    const slides = slider.querySelectorAll('.slide');
    const prevBtn = slider.querySelector('[data-slider-prev]');
    const nextBtn = slider.querySelector('[data-slider-next]');
    let index = 0;

    const updateSlider = () => {
      const offset = index * slider.clientWidth;
      track.style.transform = `translateX(-${offset}px)`;
    };

    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        index = (index - 1 + slides.length) % slides.length;
        updateSlider();
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        index = (index + 1) % slides.length;
        updateSlider();
      });
    }

    window.addEventListener('resize', updateSlider);
  });

  const tabGroups = document.querySelectorAll('[data-tabs]');
  tabGroups.forEach(group => {
    const buttons = group.querySelectorAll('.tabs-buttons button');
    const panels = group.querySelectorAll('.tab-panel');

    buttons.forEach(button => {
      button.addEventListener('click', () => {
        const targetId = button.getAttribute('data-tab');
        buttons.forEach(btn => btn.classList.remove('is-active'));
        panels.forEach(panel => panel.classList.remove('is-active'));

        button.classList.add('is-active');
        const targetPanel = group.querySelector(`#${targetId}`);
        if (targetPanel) {
          targetPanel.classList.add('is-active');
        }
      });
    });
  });

  const modals = document.querySelectorAll('[data-modal]');
  modals.forEach(modal => {
    const closeBtn = modal.querySelector('[data-modal-close]');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => closeModal(modal));
    }
    modal.addEventListener('click', event => {
      if (event.target === modal) {
        closeModal(modal);
      }
    });
  });

  const modalTriggers = document.querySelectorAll('[data-modal-target]');
  modalTriggers.forEach(trigger => {
    trigger.addEventListener('click', () => {
      const targetSelector = trigger.getAttribute('data-modal-target');
      const modal = document.querySelector(targetSelector);
      if (!modal) return;
      const videoFrame = modal.querySelector('[data-video-frame]');
      const modalImage = modal.querySelector('[data-modal-image]');

      if (videoFrame) {
        const videoSrc = trigger.getAttribute('data-video');
        videoFrame.src = videoSrc || videoFrame.src;
      }

      if (modalImage) {
        const imageSrc = trigger.getAttribute('data-image');
        if (imageSrc) {
          modalImage.src = imageSrc;
        }
      }

      openModal(modal);
    });
  });

  const galleryItems = document.querySelectorAll('[data-gallery-item]');
  galleryItems.forEach(item => {
    item.addEventListener('click', () => {
      const modal = document.querySelector('#gallery-modal') || document.querySelector('#track-modal');
      if (!modal) return;
      const modalImage = modal.querySelector('[data-modal-image]');
      if (modalImage) {
        modalImage.src = item.src;
        modalImage.alt = item.alt || 'Просмотр изображения';
      }
      openModal(modal);
    });
  });

  function openModal(modal) {
    modal.classList.add('is-visible');
    document.body.style.overflow = 'hidden';
  }

  function closeModal(modal) {
    const videoFrame = modal.querySelector('[data-video-frame]');
    if (videoFrame) {
      videoFrame.src = '';
    }
    modal.classList.remove('is-visible');
    document.body.style.overflow = '';
  }

  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      modals.forEach(modal => {
        if (modal.classList.contains('is-visible')) {
          closeModal(modal);
        }
      });
    }
  });
});