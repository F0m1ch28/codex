import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  return (
    <>
      <Helmet>
        <title>
          ArtVision Studio — креативное дизайн-агентство в Москве
        </title>
        <meta
          name="description"
          content="ArtVision Studio создает брендинг, дизайн и цифровые продукты, которые помогают компаниям выделяться и расти."
        />
      </Helmet>

      <section className={`${styles.hero} container`}>
        <div className={styles.heroContent}>
          <span className={styles.badge}>Креатив • Стратегия • Дизайн</span>
          <h1>
            ArtVision Studio — визуальные решения, которые усиливают ваш бренд
          </h1>
          <p>
            Мы объединяем стратегическое мышление, современный дизайн и
            технологичность, чтобы создавать яркие бренды, выразительные
            сайты и визуальные коммуникации, к которым хочется возвращаться.
          </p>
          <div className={styles.heroActions}>
            <Link className="primaryButton" to="/contact">
              Обсудить проект
            </Link>
            <Link className="ghostButton" to="/portfolio">
              Смотреть портфолио
            </Link>
          </div>
          <dl className={styles.stats}>
            <div className={styles.statItem}>
              <dt>120+</dt>
              <dd>реализованных проектов в России и за рубежом</dd>
            </div>
            <div className={styles.statItem}>
              <dt>12 лет</dt>
              <dd>создаем бренды, сайты и графические экосистемы</dd>
            </div>
            <div className={styles.statItem}>
              <dt>24/7</dt>
              <dd>поддержка и сопровождение ключевых клиентов</dd>
            </div>
          </dl>
        </div>
        <div className={styles.heroIllustration}>
          <img
            src="https://picsum.photos/seed/artvision-hero/680/520"
            alt="Абстрактная дизайн-композиция в фирменных цветах ArtVision"
          />
        </div>
      </section>

      <section className={`${styles.services} container`}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Экспертиза</span>
          <h2>Комплексный дизайн для брендов и цифровых продуктов</h2>
          <p>
            Мы погружаемся в бизнес-задачи, чтобы построить визуальную
            экосистему бренда и донести ценность продукта через дизайн.
          </p>
        </div>
        <div className={styles.servicesGrid}>
          <article className={styles.serviceCard}>
            <span className={styles.serviceIcon} aria-hidden="true">
              ✨
            </span>
            <h3>Брендинг и айдентика</h3>
            <p>
              Разрабатываем системы визуальной идентичности, руководства по
              стилю, фирменные визуалы и принципы коммуникации бренда.
            </p>
          </article>
          <article className={styles.serviceCard}>
            <span className={styles.serviceIcon} aria-hidden="true">
              💻
            </span>
            <h3>Цифровой дизайн</h3>
            <p>
              Создаем веб-сайты, интерфейсы и цифровые продукты с высокой
              вовлеченностью и безупречным пользовательским опытом.
            </p>
          </article>
          <article className={styles.serviceCard}>
            <span className={styles.serviceIcon} aria-hidden="true">
              🖼️
            </span>
            <h3>Графика и коммуникации</h3>
            <p>
              Разрабатываем презентации, иллюстрации, рекламные кампании и
              визуальные концепции для офлайн и онлайн-активностей.
            </p>
          </article>
        </div>
      </section>

      <section className={`${styles.process} container`}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Подход</span>
          <h2>Прозрачный процесс и вовлеченная команда</h2>
        </div>
        <ul className={styles.processList}>
          <li>
            <h3>Анализ и инсайты</h3>
            <p>
              Исследуем аудиторию, позиционирование, визуальные тренды и
              конкурентную среду. Формулируем стратегию и визуальную идею.
            </p>
          </li>
          <li>
            <h3>Креатив и концепт</h3>
            <p>
              Генерируем несколько направлений, формируем прототипы, создаем
              moodboard и сценарии использования дизайна.
            </p>
          </li>
          <li>
            <h3>Реализация</h3>
            <p>
              Доводим идеи до совершенства: визуальная система, гайдлайны,
              адаптация для разных каналов, подготовка к внедрению.
            </p>
          </li>
        </ul>
      </section>

      <section className={`${styles.portfolioPreview} container`}>
        <div className={styles.sectionHeader}>
          <span className={styles.sectionBadge}>Проекты</span>
          <h2>Выразительные истории успеха клиентов</h2>
        </div>
        <div className={styles.portfolioGrid}>
          <article>
            <img
              src="https://picsum.photos/seed/portfolio1/520/360"
              alt="Ребрендинг кофейни с современным фирменным стилем"
            />
            <div>
              <h3>Aurora Coffee — ребрендинг и коммуникации</h3>
              <p>
                Разработали новую айдентику, упаковку и мерч для кофейной
                сети, подчеркнув ремесленный подход и эмоциональность бренда.
              </p>
            </div>
          </article>
          <article>
            <img
              src="https://picsum.photos/seed/portfolio2/520/360"
              alt="Дизайн интерфейса и веб-сайта технологического стартапа"
            />
            <div>
              <h3>NeuroPulse — цифровая платформа</h3>
              <p>
                Спроектировали и запустили веб-платформу для стартапа в сфере
                искусственного интеллекта с интуитивным UX/UI.
              </p>
            </div>
          </article>
          <article>
            <img
              src="https://picsum.photos/seed/portfolio3/520/360"
              alt="Графическая иллюстрация для музыкального фестиваля"
            />
            <div>
              <h3>Soundwave Festival — визуальная коммуникация</h3>
              <p>
                Создали графическую систему для фестиваля: постеры,
                нейроморфные визуальные паттерны и динамический мерч.
              </p>
            </div>
          </article>
        </div>
        <Link className="ghostButton" to="/portfolio">
          Смотреть все проекты
        </Link>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <span className={styles.sectionBadge}>Сотрудничество</span>
              <h2>Готовы обсудить идею или задачу?</h2>
              <p>
                Напишите нам, и команда ArtVision Studio подготовит концепцию
                и подход, который подчеркнет характер вашего бренда.
              </p>
            </div>
            <Link className="primaryButton light" to="/contact">
              Связаться с нами
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;