import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  company: '',
  message: '',
};

const Contact = () => {
  const [formData, setFormData] = React.useState(initialFormState);
  const [submitted, setSubmitted] = React.useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
    setFormData(initialFormState);
  };

  return (
    <>
      <Helmet>
        <title>Контакты ArtVision Studio — обсудите проект</title>
        <meta
          name="description"
          content="Свяжитесь с ArtVision Studio: офис в Москве, email hello@artvision.ru, телефон +7 (495) 123-45-67. Давайте обсудим ваш проект."
        />
      </Helmet>

      <section className={`container ${styles.hero}`}>
        <div>
          <span className={styles.badge}>Контакты</span>
          <h1>Давайте преобразим ваш бренд вместе</h1>
          <p>
            Расскажите о проекте или задаче — мы подготовим персональное
            предложение и подберем команду специалистов.
          </p>
          <ul className={styles.contactList}>
            <li>
              <strong>Адрес:</strong> ул. Творческая, 15, Москва, Россия
            </li>
            <li>
              <strong>Телефон:</strong>{' '}
              <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            </li>
            <li>
              <strong>Email:</strong>{' '}
              <a href="mailto:hello@artvision.ru">hello@artvision.ru</a>
            </li>
          </ul>
        </div>
        <form className={styles.form} onSubmit={handleSubmit}>
          <h2>Форма обратной связи</h2>
          <div className={styles.formGroup}>
            <label htmlFor="name">Имя *</label>
            <input
              id="name"
              name="name"
              type="text"
              required
              value={formData.name}
              onChange={handleChange}
              placeholder="Как к вам обращаться?"
            />
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="email">Email *</label>
            <input
              id="email"
              name="email"
              type="email"
              required
              value={formData.email}
              onChange={handleChange}
              placeholder="example@domain.ru"
            />
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="company">Компания</label>
            <input
              id="company"
              name="company"
              type="text"
              value={formData.company}
              onChange={handleChange}
              placeholder="Название компании"
            />
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="message">Сообщение *</label>
            <textarea
              id="message"
              name="message"
              required
              rows="4"
              value={formData.message}
              onChange={handleChange}
              placeholder="Опишите задачу или идею"
            />
          </div>
          <button type="submit" className="primaryButton">
            Отправить сообщение
          </button>
          {submitted && (
            <p className={styles.successMessage}>
              Спасибо! Мы свяжемся с вами в ближайшее время.
            </p>
          )}
        </form>
      </section>

      <section className={styles.mapSection}>
        <div className="container">
          <div className={styles.mapWrapper}>
            <iframe
              title="Карта офиса ArtVision Studio"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.058144724935!2d37.61729937660073!3d55.75582698055333!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTXCsDQ1JzIxLjAiTiAzN8KwMzcnMDkuMiJF!5e0!3m2!1sru!2sru!4v1700000000000!5m2!1sru!2sru"
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;