import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Portfolio.module.css';

const categories = ['Все', 'Брендинг', 'Веб-дизайн', 'Графика', 'Иллюстрация'];

const projects = [
  {
    id: 1,
    title: 'Aurora Coffee',
    category: 'Брендинг',
    description:
      'Полный ребрендинг сети кофеен: фирменный стиль, упаковка, дизайн пространства и POS-материалы.',
    image: 'https://picsum.photos/seed/branding1/640/460',
  },
  {
    id: 2,
    title: 'NeuroPulse Platform',
    category: 'Веб-дизайн',
    description:
      'UX/UI и дизайн-система для платформы анализа данных искусственного интеллекта.',
    image: 'https://picsum.photos/seed/web1/640/460',
  },
  {
    id: 3,
    title: 'Soundwave Festival',
    category: 'Графика',
    description:
      'Айдентика музыкального фестиваля: плакаты, мерч, digital-реклама, сценография.',
    image: 'https://picsum.photos/seed/graphic1/640/460',
  },
  {
    id: 4,
    title: 'Lumen Architecture',
    category: 'Брендинг',
    description:
      'Визуальная идентичность архитектурного бюро с акцентом на свет и минимализм.',
    image: 'https://picsum.photos/seed/branding2/640/460',
  },
  {
    id: 5,
    title: 'FlowApp Dashboard',
    category: 'Веб-дизайн',
    description:
      'Продвинутая аналитическая панель для SaaS-продукта: проектирование и дизайн интерфейса.',
    image: 'https://picsum.photos/seed/web2/640/460',
  },
  {
    id: 6,
    title: 'Arton Illustrations',
    category: 'Иллюстрация',
    description:
      'Серия концептуальных иллюстраций для художественного каталога и social media.',
    image: 'https://picsum.photos/seed/illustration1/640/460',
  },
];

const Portfolio = () => {
  const [activeCategory, setActiveCategory] = React.useState('Все');

  const filteredProjects =
    activeCategory === 'Все'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  return (
    <>
      <Helmet>
        <title>Портфолио ArtVision Studio — реализованные дизайн-проекты</title>
        <meta
          name="description"
          content="Портфолио ArtVision Studio: брендинг, веб-дизайн, графика и иллюстрации. Вдохновляющие проекты для компаний из разных отраслей."
        />
      </Helmet>

      <section className={`container ${styles.hero}`}>
        <div>
          <span className={styles.badge}>Портфолио</span>
          <h1>Вдохновляющие проекты для брендов и продуктов</h1>
          <p>
            Мы создаем визуальные экосистемы, которые помогают компаниям
            строить эмоциональные связи, расширять аудиторию и достигать
            амбициозных целей.
          </p>
        </div>
      </section>

      <section className={`container ${styles.filters}`}>
        <div className={styles.filterButtons}>
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              className={
                category === activeCategory ? styles.active : undefined
              }
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
      </section>

      <section className={`container ${styles.grid}`}>
        {filteredProjects.map((project) => (
          <article key={project.id} className={styles.card}>
            <div className={styles.imageWrapper}>
              <img
                src={project.image}
                alt={`Проект ${project.title} — ${project.category}`}
              />
            </div>
            <div className={styles.cardContent}>
              <span className={styles.category}>{project.category}</span>
              <h3>{project.title}</h3>
              <p>{project.description}</p>
            </div>
          </article>
        ))}
      </section>
    </>
  );
};

export default Portfolio;