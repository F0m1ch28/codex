import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Бренд-стратегия и позиционирование',
    description:
      'Формируем бренд-платформу, архетип, tone of voice и визуальные ориентиры, чтобы бренд звучал ясно и узнаваемо.',
    icon: '🧭',
  },
  {
    title: 'Айдентика и фирменный стиль',
    description:
      'Разрабатываем логотип, шрифтовые решения, цветовую систему, графический язык и гайдлайн по использованию.',
    icon: '🎯',
  },
  {
    title: 'UX/UI дизайн и прототипирование',
    description:
      'Проводим аудит, строим пользовательские сценарии, создаем высокоточные прототипы и дизайн-системы.',
    icon: '🧩',
  },
  {
    title: 'Веб-дизайн и разработка',
    description:
      'Проектируем адаптивные сайты и промо-страницы, внедряем анимации и обеспечиваем безупречный фронтенд.',
    icon: '🌐',
  },
  {
    title: 'Графика и коммуникационные материалы',
    description:
      'Создаем презентации, иллюстрации, инфографику, кампании для социальных сетей и digital-рекламы.',
    icon: '📣',
  },
  {
    title: 'Дизайн сопровождение и контроль качества',
    description:
      'Долго сопровождаем бренды: обновляем материалы, контролируем визуал в каналах, поддерживаем команды.',
    icon: '🤝',
  },
];

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Услуги ArtVision Studio — брендинг, веб-дизайн, графика</title>
        <meta
          name="description"
          content="Услуги ArtVision Studio: разработка брендинга, UX/UI, веб-дизайна и графических коммуникаций. Комплексные решения для бизнеса."
        />
      </Helmet>
      <section className={`container ${styles.hero}`}>
        <div>
          <span className={styles.badge}>Услуги</span>
          <h1>Стратегический дизайн для бизнеса любого масштаба</h1>
          <p>
            Команда ArtVision Studio ведет проекты от аналитики и концепции до
            внедрения и поддержки. Мы ценим прозрачную коммуникацию,
            гибкость и креативность, позволяющие воплощать смелые идеи.
          </p>
        </div>
        <div className={styles.heroCard}>
          <h2>Как мы работаем</h2>
          <ul>
            <li>Погружаемся в контекст бизнеса и аудиторию</li>
            <li>Формируем концепции и визуальные направления</li>
            <li>Тестируем решения и собираем обратную связь</li>
            <li>Передаем гайдлайны и поддерживаем команду клиента</li>
          </ul>
        </div>
      </section>

      <section className={`container ${styles.servicesGrid}`}>
        {services.map((service) => (
          <article key={service.title} className={styles.card}>
            <span className={styles.icon} aria-hidden="true">
              {service.icon}
            </span>
            <h3>{service.title}</h3>
            <p>{service.description}</p>
          </article>
        ))}
      </section>

      <section className={styles.highlightSection}>
        <div className="container">
          <div className={styles.highlightCard}>
            <h2>Нужны консультация или дизайн-аудит?</h2>
            <p>
              Поделитесь задачей — мы подготовим индивидуальный план и
              предложим оптимальную команду специалистов под ваш проект.
            </p>
            <a className="primaryButton light" href="mailto:hello@artvision.ru">
              hello@artvision.ru
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;