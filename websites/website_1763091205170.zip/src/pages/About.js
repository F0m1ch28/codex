import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  return (
    <>
      <Helmet>
        <title>О студии — команда ArtVision Studio</title>
        <meta
          name="description"
          content="ArtVision Studio — команда дизайнеров, стратегов и иллюстраторов, создающих выразительные бренды и цифровой дизайн."
        />
      </Helmet>

      <section className={`container ${styles.hero}`}>
        <div>
          <span className={styles.badge}>О студии</span>
          <h1>ArtVision Studio — команда, которая мыслит визуально</h1>
          <p>
            Мы объединяем креативность, глубокую экспертизу и внимание к
            деталям, чтобы создавать дизайн, который работает на бизнес и
            вдохновляет людей. Наши проекты строятся на доверии, открытом
            диалоге и любви к визуальным экспериментам.
          </p>
        </div>
        <div className={styles.imageWrapper}>
          <img
            src="https://picsum.photos/seed/aboutteam/720/520"
            alt="Команда ArtVision Studio за обсуждением дизайн-концепции"
          />
        </div>
      </section>

      <section className={`container ${styles.values}`}>
        <div className={styles.sectionHeader}>
          <h2>Ценности студии</h2>
          <p>
            В работе мы опираемся на три основных принципа, которые помогают
            достижению высоких результатов.
          </p>
        </div>
        <div className={styles.valuesGrid}>
          <article>
            <h3>Искренность</h3>
            <p>
              Мы говорим прямо, внимательно слушаем и всегда стремимся к
              прозрачности в процессе — именно так рождаются сильные идеи.
            </p>
          </article>
          <article>
            <h3>Исследования</h3>
            <p>
              Наша креативность подкреплена аналитикой: мы глубоко изучаем
              аудитории, конкурентов и культурные тренды.
            </p>
          </article>
          <article>
            <h3>Непрерывность</h3>
            <p>
              Контролируем качество каждого носителя и сопровождаем клиентов
              после запуска, чтобы дизайн оставался актуальным.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.timelineSection}>
        <div className="container">
          <div className={styles.timelineHeader}>
            <h2>История ArtVision Studio</h2>
            <p>
              За двенадцать лет мы выросли из небольшой команды энтузиастов в
              студию полного цикла.
            </p>
          </div>
          <ul className={styles.timeline}>
            <li>
              <span>2012</span>
              <div>
                <h3>Основание студии</h3>
                <p>
                  Два дизайнера и один стратег объединились для создания
                  агентства, в котором дизайн служит бизнесу.
                </p>
              </div>
            </li>
            <li>
              <span>2016</span>
              <div>
                <h3>Рост команды</h3>
                <p>
                  Появились направления UX/UI, motion и иллюстрации — мы
                  начали работать с технологическими компаниями.
                </p>
              </div>
            </li>
            <li>
              <span>2019</span>
              <div>
                <h3>Международные проекты</h3>
                <p>
                  Вышли на глобальные рынки: сотрудничали с брендами из
                  Европы, США и Ближнего Востока.
                </p>
              </div>
            </li>
            <li>
              <span>2023</span>
              <div>
                <h3>Новые форматы</h3>
                <p>
                  Запустили лабораторию дизайн-исследований и расширили
                  сервисы по сопровождению брендов.
                </p>
              </div>
            </li>
          </ul>
        </div>
      </section>

      <section className={`container ${styles.teamQuote}`}>
        <blockquote>
          «Мы верим, что дизайн — это не просто эстетика, а инструмент
          изменений. Когда визуальная идея резонирует с людьми, она становится
          движущей силой роста бренда.»
        </blockquote>
        <cite>Команда ArtVision Studio</cite>
      </section>
    </>
  );
};

export default About;