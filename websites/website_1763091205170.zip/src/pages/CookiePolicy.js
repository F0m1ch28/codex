import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './StaticPage.module.css';

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Политика Cookie — ArtVision Studio</title>
        <meta
          name="description"
          content="Политика использования файлов cookie на сайте ArtVision Studio. Узнайте, как мы применяем cookie."
        />
      </Helmet>
      <section className={`container ${styles.wrapper}`}>
        <h1>Политика использования файлов Cookie</h1>
        <p className={styles.updated}>Последнее обновление: 15 января 2024 г.</p>
        <p>
          Cookie — это небольшие текстовые файлы, сохраняемые в вашем браузере
          при посещении сайта. Они помогают улучшить взаимодействие с сайтом и
          позволяют анализировать работу ресурсов.
        </p>
        <h2>1. Используемые типы cookie</h2>
        <ul className={styles.list}>
          <li>Технические — обеспечивают корректную работу сайта.</li>
          <li>
            Аналитические — помогают понять, как пользователи взаимодействуют с
            разделами сайта.
          </li>
          <li>
            Функциональные — запоминают ваши настройки и предпочтения.
          </li>
        </ul>
        <h2>2. Управление cookie</h2>
        <p>
          Вы можете ограничить или отключить cookie в настройках браузера. При
          этом некоторые функции сайта могут работать некорректно.
        </p>
        <h2>3. Обратная связь</h2>
        <p>
          По вопросам, связанным с использованием cookie, обратитесь по адресу{' '}
          <a href="mailto:hello@artvision.ru">hello@artvision.ru</a>.
        </p>
      </section>
    </>
  );
};

export default CookiePolicy;