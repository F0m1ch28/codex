import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'artvision_cookie_consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(COOKIE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="assertive">
      <div className={`container ${styles.bannerContent}`}>
        <p>
          Мы используем cookie, чтобы улучшить работу сайта и адаптировать
          контент. Продолжая пользоваться сайтом, вы соглашаетесь с{' '}
          <Link to="/cookie-policy">политикой использования cookie</Link>.
        </p>
        <button type="button" className={styles.button} onClick={handleAccept}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;