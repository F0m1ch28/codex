import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.footerInner}`}>
        <div className={styles.brandBlock}>
          <div className={styles.logo}>
            <span role="img" aria-label="палитра" className={styles.logoIcon}>
              🎨
            </span>
            <span>
              ArtVision <span className={styles.logoAccent}>Studio</span>
            </span>
          </div>
          <p className={styles.description}>
            Мы воплощаем стратегии брендов в сильные визуальные решения и
            создаем дизайн, который резонирует с людьми.
          </p>
        </div>

        <div className={styles.footerColumns}>
          <div>
            <h4 className={styles.columnTitle}>Навигация</h4>
            <ul className={styles.linkList}>
              <li>
                <Link to="/">Главная</Link>
              </li>
              <li>
                <Link to="/services">Услуги</Link>
              </li>
              <li>
                <Link to="/portfolio">Портфолио</Link>
              </li>
              <li>
                <Link to="/about">О нас</Link>
              </li>
              <li>
                <Link to="/contact">Контакты</Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className={styles.columnTitle}>Юридическая информация</h4>
            <ul className={styles.linkList}>
              <li>
                <Link to="/terms">Условия использования</Link>
              </li>
              <li>
                <Link to="/privacy">Политика конфиденциальности</Link>
              </li>
              <li>
                <Link to="/cookie-policy">Политика Cookie</Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className={styles.columnTitle}>Контакты</h4>
            <ul className={styles.contactList}>
              <li>ул. Творческая, 15, Москва, Россия</li>
              <li>
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </li>
              <li>
                <a href="mailto:hello@artvision.ru">hello@artvision.ru</a>
              </li>
            </ul>
            <div className={styles.socials}>
              <a
                href="https://www.behance.net/"
                target="_blank"
                rel="noreferrer"
                aria-label="Behance"
              >
                Behance
              </a>
              <a
                href="https://www.dribbble.com/"
                target="_blank"
                rel="noreferrer"
                aria-label="Dribbble"
              >
                Dribbble
              </a>
              <a
                href="https://www.instagram.com/"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
              >
                Instagram
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <div className="container">
          <p>© {currentYear} ArtVision Studio. Все права защищены.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;