document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.site-nav .nav-link');

    const closeNavigation = () => {
        if (siteNav && navToggle) {
            siteNav.classList.remove('is-visible');
            navToggle.classList.remove('is-active');
            navToggle.setAttribute('aria-expanded', 'false');
            document.body.classList.remove('nav-open');
        }
    };

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            siteNav.classList.toggle('is-visible');
            navToggle.classList.toggle('is-active');
            const isExpanded = navToggle.classList.contains('is-active');
            navToggle.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
            if (isExpanded) {
                document.body.classList.add('nav-open');
            } else {
                document.body.classList.remove('nav-open');
            }
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth < 1024) {
                closeNavigation();
            }
        });
    });

    document.addEventListener('keydown', event => {
        if (event.key === 'Escape') {
            closeNavigation();
        }
    });

    // Cookie Banner Logic
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-accept');
    const declineBtn = document.querySelector('.cookie-decline');
    const consentKey = 'inesseewfv-cookie-consent';

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (!storedConsent) {
            window.setTimeout(() => {
                cookieBanner.classList.add('is-visible');
            }, 1200);
        }

        const handleConsent = value => {
            localStorage.setItem(consentKey, value);
            cookieBanner.classList.remove('is-visible');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => handleConsent('accepted'));
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => handleConsent('declined'));
        }
    }
});