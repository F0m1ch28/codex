/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#1A1F2E",
        solar: "#FDB813",
        flare: "#F97316",
        cream: "#FEFCE8",
        "surface-dark": "#141829"
      },
      fontFamily: {
        sans: ["Manrope", "sans-serif"],
        alt: ["Inter", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"]
      },
      boxShadow: {
        solar: "0 20px 60px rgba(253, 184, 19, 0.25)"
      }
    }
  },
  plugins: []
};