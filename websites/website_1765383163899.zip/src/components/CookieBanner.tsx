import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const COOKIE_STORAGE_KEY = "heliosphera_cookie_consent";

const CookieBanner: React.FC = () => {
  const [visible, setVisible] = useState<boolean>(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(COOKIE_STORAGE_KEY);
      if (!stored) {
        setVisible(true);
      }
    } catch {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    try {
      localStorage.setItem(COOKIE_STORAGE_KEY, "accepted");
    } catch {
      /* noop */
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="fixed inset-x-0 bottom-0 z-[60] px-4 pb-4 sm:px-6 sm:pb-6">
      <div className="section-container">
        <div className="rounded-3xl border border-primary/10 bg-white/95 p-5 shadow-2xl backdrop-blur">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="font-semibold text-primary">Preferencias de cookies</p>
              <p className="mt-1 text-sm text-primary/80">
                Utilizamos cookies analíticas para mejorar nuestros modelos y ofrecerte indicadores precisos. Consulta la
                <Link to="/politica-cookies" className="ml-1 font-semibold text-flare underline">
                  política de cookies
                </Link>
                .
              </p>
            </div>
            <button type="button" className="btn-primary w-full md:w-auto" onClick={handleAccept}>
              Aceptar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;