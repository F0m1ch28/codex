import React, { useEffect, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

interface NavigationItem {
  name: string;
  path: string;
}

const navigation: NavigationItem[] = [
  { name: "Inicio", path: "/" },
  { name: "Misión", path: "/mision" },
  { name: "Tecnologías", path: "/tecnologias-fotovoltaicas" },
  { name: "Modelado", path: "/modelado-predictivo" },
  { name: "Instalaciones", path: "/instalaciones-referencia" },
  { name: "Laboratorio", path: "/laboratorio-virtual" },
  { name: "Blog", path: "/blog" },
  { name: "Conecta", path: "/conecta" }
];

const Header: React.FC = () => {
  const [menuOpen, setMenuOpen] = useState<boolean>(false);
  const [scrolled, setScrolled] = useState<boolean>(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 24);
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.header
      className={`sticky top-0 z-50 backdrop-blur-xl transition-all ${
        scrolled ? "bg-primary/95 shadow-xl" : "bg-primary/75"
      }`}
      initial={{ y: -72, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.45, ease: "easeOut" }}
    >
      <div className="section-container">
        <div className="flex items-center justify-between py-4">
          <NavLink to="/" className="flex items-center gap-3" aria-label="Ir al inicio">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-solar text-primary shadow-solar">
              <span className="font-mono text-lg font-semibold">HS</span>
            </div>
            <div className="flex flex-col leading-tight text-white">
              <span className="font-sans text-lg font-semibold tracking-tight">HelioSphera Ibérica</span>
              <span className="font-alt text-xs uppercase tracking-[0.3em] text-white/70">
                Innovación Fotovoltaica
              </span>
            </div>
          </NavLink>

          <nav className="hidden items-center gap-8 lg:flex" aria-label="Navegación principal">
            {navigation.map((item) => (
              <NavLink
                key={item.name}
                to={item.path}
                className={({ isActive }) =>
                  `relative text-sm font-medium uppercase tracking-[0.24em] transition ${
                    isActive ? "text-solar" : "text-white/80 hover:text-solar"
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    {item.name}
                    {isActive && (
                      <motion.span
                        layoutId="activeNav"
                        className="absolute inset-x-0 -bottom-2 h-0.5 rounded-full bg-solar"
                      />
                    )}
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          <button
            type="button"
            aria-label="Abrir menú"
            className="inline-flex items-center justify-center rounded-full border border-white/20 bg-white/5 p-2 text-white transition hover:border-solar hover:text-solar focus:outline-none focus:ring-2 focus:ring-solar focus:ring-offset-2 lg:hidden"
            onClick={() => setMenuOpen((prev) => !prev)}
          >
            <span className="sr-only">Abrir menú de navegación</span>
            <svg
              className="h-6 w-6"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.6"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d={
                  menuOpen
                    ? "M6 18L18 6M6 6l12 12"
                    : "M4 6h16M4 12h16M4 18h16"
                }
              />
            </svg>
          </button>
        </div>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.nav
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.26, ease: "easeInOut" }}
            className="lg:hidden"
            aria-label="Navegación móvil"
          >
            <div className="section-container pb-6">
              <ul className="space-y-3 rounded-2xl border border-white/10 bg-primary/95 p-6 shadow-xl">
                {navigation.map((item) => (
                  <li key={item.name}>
                    <NavLink
                      to={item.path}
                      className={({ isActive }) =>
                        `block rounded-xl px-4 py-3 text-sm font-semibold uppercase tracking-[0.24em] transition ${
                          isActive ? "bg-solar text-primary" : "text-white/80 hover:bg-white/10 hover:text-solar"
                        }`
                      }
                    >
                      {item.name}
                    </NavLink>
                  </li>
                ))}
              </ul>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </motion.header>
  );
};

export default Header;