import React from "react";
import { Link } from "react-router-dom";

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-white">
      <div className="section-container py-16">
        <div className="grid gap-12 lg:grid-cols-4">
          <div>
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-solar text-primary shadow-solar">
                <span className="font-mono text-base font-semibold">HS</span>
              </div>
              <div className="leading-tight">
                <span className="block text-lg font-semibold">HelioSphera Ibérica</span>
                <span className="text-xs uppercase tracking-[0.3em] text-white/70">
                  Energía solar en clave técnica
                </span>
              </div>
            </div>
            <p className="max-w-xs text-sm text-white/80">
              Plataforma de innovación y análisis solar que acompaña a promotores, ingenierías y operadores a optimizar cada
              instalación fotovoltaica en España.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.35em] text-solar">Secciones</h3>
            <ul className="mt-4 space-y-3 text-sm text-white/80">
              <li>
                <Link className="transition hover:text-solar" to="/mision">
                  Misión y enfoque
                </Link>
              </li>
              <li>
                <Link className="transition hover:text-solar" to="/tecnologias-fotovoltaicas">
                  Tecnologías fotovoltaicas
                </Link>
              </li>
              <li>
                <Link className="transition hover:text-solar" to="/modelado-predictivo">
                  Modelado predictivo
                </Link>
              </li>
              <li>
                <Link className="transition hover:text-solar" to="/instalaciones-referencia">
                  Instalaciones de referencia
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.35em] text-solar">Recursos</h3>
            <ul className="mt-4 space-y-3 text-sm text-white/80">
              <li>
                <Link className="transition hover:text-solar" to="/laboratorio-virtual">
                  Laboratorio virtual
                </Link>
              </li>
              <li>
                <Link className="transition hover:text-solar" to="/blog">
                  Blog &amp; actualidad
                </Link>
              </li>
              <li>
                <Link className="transition hover:text-solar" to="/conecta">
                  Solicita una sesión técnica
                </Link>
              </li>
              <li>
                <a
                  className="transition hover:text-solar"
                  href="https://www.linkedin.com"
                  target="_blank"
                  rel="noreferrer"
                >
                  LinkedIn corporativo
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.35em] text-solar">Contacto</h3>
            <ul className="mt-4 space-y-3 text-sm text-white/80">
              <li>
                Paseo de la Castellana 259D,
                <br />
                28046 Madrid
              </li>
              <li>
                Teléfono:{" "}
                <a href="tel:+34912456789" className="font-medium text-solar">
                  +34 912 45 67 89
                </a>
              </li>
              <li>
                Email:{" "}
                <a href="mailto:info@heliosphera.com" className="font-medium text-solar">
                  info@heliosphera.com
                </a>
              </li>
            </ul>
            <div className="mt-6 flex flex-wrap gap-4 text-xs uppercase tracking-[0.28em] text-white/60">
              <Link to="/condiciones" className="hover:text-solar">
                Condiciones
              </Link>
              <Link to="/privacidad" className="hover:text-solar">
                Privacidad
              </Link>
              <Link to="/politica-cookies" className="hover:text-solar">
                Cookies
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-12 border-t border-white/10 pt-6 text-xs uppercase tracking-[0.35em] text-white/50">
          © {currentYear} HelioSphera Ibérica. Ingeniería solar orientada a resultados verificables.
        </div>
      </div>
    </footer>
  );
};

export default Footer;