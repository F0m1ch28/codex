import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import HomePage from "./pages/HomePage";
import MisionPage from "./pages/MisionPage";
import TecnologiasPage from "./pages/TecnologiasPage";
import ModeladoPage from "./pages/ModeladoPage";
import InstalacionesPage from "./pages/InstalacionesPage";
import LaboratorioPage from "./pages/LaboratorioPage";
import BlogPage from "./pages/BlogPage";
import ConectaPage from "./pages/ConectaPage";
import CondicionesPage from "./pages/CondicionesPage";
import PrivacidadPage from "./pages/PrivacidadPage";
import CookiePolicyPage from "./pages/CookiePolicyPage";
import NotFoundPage from "./pages/NotFoundPage";

const App: React.FC = () => {
  const location = useLocation();

  return (
    <div className="flex min-h-screen flex-col bg-cream text-primary">
      <Header />
      <CookieBanner />
      <ScrollToTop />

      <AnimatePresence mode="wait">
        <motion.main
          key={location.pathname}
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -32 }}
          transition={{ duration: 0.35, ease: "easeOut" }}
          className="flex-1"
        >
          <Routes location={location}>
            <Route path="/" element={<HomePage />} />
            <Route path="/mision" element={<MisionPage />} />
            <Route path="/tecnologias-fotovoltaicas" element={<TecnologiasPage />} />
            <Route path="/modelado-predictivo" element={<ModeladoPage />} />
            <Route path="/instalaciones-referencia" element={<InstalacionesPage />} />
            <Route path="/laboratorio-virtual" element={<LaboratorioPage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/conecta" element={<ConectaPage />} />
            <Route path="/condiciones" element={<CondicionesPage />} />
            <Route path="/privacidad" element={<PrivacidadPage />} />
            <Route path="/politica-cookies" element={<CookiePolicyPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </motion.main>
      </AnimatePresence>

      <Footer />
    </div>
  );
};

export default App;