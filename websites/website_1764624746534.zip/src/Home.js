import React, { useContext } from 'react';
import { Helmet } from 'react-helmet-async';
import Section from './Section';
import Card from './Card';
import Button from './Button';
import ARSUSDTracker from './ARSUSDTracker';
import DoubleOptInForm from './DoubleOptInForm';
import { LanguageContext } from './LanguageContext';
import { homeContent, fixedSpanishMessages } from './translations';

const Home = () => {
  const { language } = useContext(LanguageContext);
  const content = homeContent[language];

  const testimonialImages = [
    'https://picsum.photos/100/100?random=21',
    'https://picsum.photos/100/100?random=22',
    'https://picsum.photos/100/100?random=23'
  ];

  return (
    <>
      <Helmet>
        <title>{language === 'es' ? 'Tu Progreso Hoy | Inicio' : 'Tu Progreso Hoy | Home'}</title>
        <meta
          name="description"
          content={
            language === 'es'
              ? 'Educación financiera bilingüe con tableros de inflación y cursos accionables para Argentina.'
              : 'Bilingual financial education with inflation dashboards and actionable courses for Argentina.'
          }
        />
      </Helmet>

      <section className="hero">
        <div className="hero-content">
          <div className="hero-text">
            <span className="hero-kicker">{content.hero.kicker}</span>
            <h1 className="hero-title">{content.hero.title}</h1>
            <p>{content.hero.subtitle}</p>
            <div className="hero-actions">
              <Button to="/inflation" variant="primary">
                {content.hero.primaryCta}
              </Button>
              <Button to="/course" variant="secondary">
                {content.hero.secondaryCta}
              </Button>
            </div>
            <p className="hero-tagline">{content.hero.tagline}</p>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <img
              src="https://picsum.photos/1200/600?grayscale&blur=2"
              alt="Argentina skyline with analytical overlay"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <Section title={content.promises.title} subtitle={content.promises.subtitle} eyebrow="Key promises">
        <div className="cards-grid">
          {content.promises.items.map((item) => (
            <Card key={item.title} title={item.title}>
              <p>{item.description}</p>
            </Card>
          ))}
        </div>
      </Section>

      <Section title={content.tracker.title} subtitle={content.tracker.subtitle}>
        <ARSUSDTracker />
      </Section>

      <Section title={content.insights.title} subtitle={content.insights.subtitle}>
        <div className="cards-grid">
          {content.insights.items.map((item) => (
            <Card key={item.title} title={item.title}>
              <p>{item.description}</p>
            </Card>
          ))}
        </div>
      </Section>

      <Section title="Our guiding principles" subtitle="Fixed messages that guide every lesson.">
        <div className="cards-grid">
          {fixedSpanishMessages.map((message) => (
            <Card key={message} variant="highlight">
              <p style={{ margin: 0, fontWeight: 600 }}>{message}</p>
            </Card>
          ))}
        </div>
      </Section>

      <Section
        title={content.courseOverview.title}
        subtitle={content.courseOverview.subtitle}
        eyebrow={language === 'es' ? 'Curso' : 'Course'}
      >
        <div className="cards-grid">
          {content.courseOverview.modules.map((module) => (
            <Card key={module.title} title={module.title}>
              <p><strong>{module.duration}</strong></p>
              <p>{module.description}</p>
            </Card>
          ))}
        </div>
        <div style={{ marginTop: '2rem', display: 'grid', gap: '1rem' }}>
          <ul style={{ margin: 0, paddingLeft: '1.2rem', color: 'rgba(15, 23, 42, 0.78)' }}>
            {content.courseOverview.highlights.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <Button href={content.courseOverview.ctaLink} variant="primary">
            {content.courseOverview.ctaLabel}
          </Button>
        </div>
      </Section>

      <Section title={content.testimonials.title} subtitle={content.testimonials.subtitle} background="muted">
        <div className="cards-grid">
          {content.testimonials.items.map((item, index) => (
            <Card key={item.name} variant="highlight" className="testimonial-card">
              <p>{item.quote}</p>
              <div className="testimonial-footer">
                <img
                  src={testimonialImages[index]}
                  alt={item.name}
                  className="testimonial-avatar"
                  loading="lazy"
                />
                <div>
                  <strong>{item.name}</strong>
                  <p style={{ margin: 0 }}>{item.role}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </Section>

      <Section
        title={content.form.title}
        subtitle={content.form.subtitle}
        eyebrow={language === 'es' ? 'Clase de prueba' : 'Free trial'}
      >
        <DoubleOptInForm formId="home-trial-form" copy={content.form} redirect="/thank-you" />
      </Section>
    </>
  );
};

export default Home;