import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { LanguageContext } from './LanguageContext';
import { footerContent } from './translations';

const Footer = () => {
  const { language } = useContext(LanguageContext);
  const content = footerContent[language];
  const year = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="footer-inner">
        <div className="footer-col">
          <h3>Tu Progreso Hoy</h3>
          <p>{content.description}</p>
          <p><strong>{content.mission}</strong></p>
          <p>{content.compliance}</p>
        </div>
        <div className="footer-col">
          <h4>{content.officeTitle}</h4>
          <p>Av. 9 de Julio 1000<br />C1043 Buenos Aires, Argentina</p>
          <p>
            {content.phoneLabel}: <a href="tel:+541155551234">+54 11 5555-1234</a><br />
            {content.emailLabel}: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
          </p>
        </div>
        <div className="footer-col">
          <h4>{content.contactTitle}</h4>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'grid', gap: '0.6rem' }}>
            {content.quickLinks.map((link) => (
              <li key={link.path}>
                <Link to={link.path}>{link.label}</Link>
              </li>
            ))}
          </ul>
        </div>
        <div className="footer-col">
          <h4>{content.socialTitle}</h4>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'grid', gap: '0.6rem' }}>
            {content.socials.map((social) => (
              <li key={social.label}>
                <a href={social.url} target="_blank" rel="noopener noreferrer">
                  {social.label} · {social.handle}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <span>{content.rights.replace('{year}', year.toString())}</span>
        <span>VAT-ready receipts available on request.</span>
      </div>
    </footer>
  );
};

export default Footer;