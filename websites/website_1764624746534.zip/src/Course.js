import React, { useContext } from 'react';
import { Helmet } from 'react-helmet-async';
import Section from './Section';
import Card from './Card';
import Button from './Button';
import DoubleOptInForm from './DoubleOptInForm';
import { LanguageContext } from './LanguageContext';
import { courseContent } from './translations';

const Course = () => {
  const { language } = useContext(LanguageContext);
  const content = courseContent[language];

  return (
    <>
      <Helmet>
        <title>{language === 'es' ? 'Tu Progreso Hoy | Curso' : 'Tu Progreso Hoy | Course'}</title>
        <meta
          name="description"
          content={
            language === 'es'
              ? 'Conocé el programa de Tu Progreso Hoy con módulos sobre inflación, dinámica cambiaria y planificación.'
              : 'Discover Tu Progreso Hoy syllabus covering inflation, FX dynamics, and planning studios.'
          }
        />
      </Helmet>

      <Section title={content.heroTitle} subtitle={content.intro} eyebrow={language === 'es' ? 'Programa' : 'Syllabus'}>
        <div className="cards-grid">
          {content.audienceItems.map((item) => (
            <Card key={item}>
              <p style={{ margin: 0 }}>{item}</p>
            </Card>
          ))}
        </div>
      </Section>

      <Section title={content.modulesTitle} background="muted">
        <div className="cards-grid">
          {content.modules.map((module) => (
            <Card key={module.name} title={module.name}>
              <ul style={{ paddingLeft: '1.2rem' }}>
                {module.outcomes.map((outcome) => (
                  <li key={outcome}>{outcome}</li>
                ))}
              </ul>
              <p><strong>{module.resources}</strong></p>
            </Card>
          ))}
        </div>
      </Section>

      <Section title={content.formatTitle} subtitle={content.ctaText}>
        <div className="cards-grid">
          {content.formatItems.map((item) => (
            <Card key={item}>
              <p style={{ margin: 0 }}>{item}</p>
            </Card>
          ))}
        </div>
        <div style={{ marginTop: '2rem' }}>
          <Button href={content.formReference.anchor} variant="primary">
            {content.formReference.label}
          </Button>
        </div>
      </Section>

      <Section title={content.form.title} subtitle={content.form.subtitle}>
        <DoubleOptInForm formId="course-trial-form" copy={content.form} redirect="/thank-you" />
      </Section>
    </>
  );
};

export default Course;