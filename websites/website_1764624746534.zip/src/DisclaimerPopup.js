import React, { useEffect, useState } from 'react';
import Button from './Button';

const DisclaimerPopup = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const stored = typeof window !== 'undefined' ? window.localStorage.getItem('tph_disclaimer_ack') : null;
    if (!stored) {
      setTimeout(() => setShow(true), 800);
    }
  }, []);

  const handleClose = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('tph_disclaimer_ack', 'true');
    }
    setShow(false);
  };

  if (!show) return null;

  return (
    <div className="disclaimer-popup" role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
      <div className="disclaimer-card">
        <h3 id="disclaimer-title">We do not provide financial services</h3>
        <ul>
          <li>We do not provide financial services.</li>
          <li>Мы не оказываем финансовые услуги.</li>
          <li>No brindamos servicios financieros.</li>
        </ul>
        <div style={{ marginTop: '1.5rem', display: 'flex', justifyContent: 'flex-end' }}>
          <Button variant="primary" onClick={handleClose}>
            Acknowledge
          </Button>
        </div>
      </div>
    </div>
  );
};

export default DisclaimerPopup;