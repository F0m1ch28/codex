import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from './Button';

const defaultStateFromFields = (fields) =>
  fields.reduce(
    (acc, field) => ({
      ...acc,
      [field.name]: ''
    }),
    {}
  );

const DoubleOptInForm = ({ formId, copy, redirect = '/thank-you' }) => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [values, setValues] = useState(defaultStateFromFields(copy.fields || []));
  const [errors, setErrors] = useState({});
  const [checkboxConfirmed, setCheckboxConfirmed] = useState(false);

  const validate = () => {
    const newErrors = {};
    (copy.fields || []).forEach((field) => {
      if (field.required && !values[field.name]) {
        newErrors[field.name] = field.type === 'textarea' ? 'This field is required.' : 'Required field.';
      }
      if (field.type === 'email' && values[field.name]) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(values[field.name])) {
          newErrors[field.name] = 'Please enter a valid email address.';
        }
      }
    });
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setValues((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setStep(2);
    }
  };

  const handleConfirm = (event) => {
    event.preventDefault();
    if (checkboxConfirmed) {
      navigate(redirect);
    }
  };

  return (
    <div className="form-card" id={formId}>
      <h3>{copy.title}</h3>
      <p>{copy.subtitle}</p>
      {step === 1 && (
        <form onSubmit={handleSubmit} className="form-grid" noValidate>
          {(copy.fields || []).map((field) => (
            <div key={field.name}>
              <label htmlFor={`${formId}-${field.name}`}>{field.label}</label>
              {field.type === 'textarea' ? (
                <textarea
                  id={`${formId}-${field.name}`}
                  name={field.name}
                  placeholder={field.placeholder}
                  value={values[field.name]}
                  onChange={handleChange}
                  required={field.required}
                />
              ) : (
                <input
                  id={`${formId}-${field.name}`}
                  name={field.name}
                  type={field.type}
                  placeholder={field.placeholder}
                  value={values[field.name]}
                  onChange={handleChange}
                  required={field.required}
                />
              )}
              {errors[field.name] && <div className="form-error">{errors[field.name]}</div>}
            </div>
          ))}
          <Button type="submit" variant="primary">
            {copy.submitLabel}
          </Button>
          <p style={{ fontSize: '0.85rem', color: 'rgba(15, 23, 42, 0.7)' }}>{copy.privacyNote}</p>
        </form>
      )}
      {step === 2 && (
        <form onSubmit={handleConfirm} aria-live="polite">
          <div className="confirmation-pane">
            <h4>{copy.confirmationTitle}</h4>
            <p>{copy.confirmationBody}</p>
            <div className="checkbox-row">
              <input
                type="checkbox"
                id={`${formId}-confirmed`}
                checked={checkboxConfirmed}
                onChange={(event) => setCheckboxConfirmed(event.target.checked)}
                required
              />
              <label htmlFor={`${formId}-confirmed`}>{copy.confirmationCheckbox}</label>
            </div>
          </div>
          <Button type="submit" variant="primary" style={{ marginTop: '1.25rem' }}>
            {copy.confirmButton}
          </Button>
        </form>
      )}
    </div>
  );
};

export default DoubleOptInForm;