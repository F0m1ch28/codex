export const navigationContent = {
  en: [
    { label: 'Home', path: '/' },
    { label: 'Inflation Lab', path: '/inflation' },
    { label: 'Course', path: '/course' },
    { label: 'Resources', path: '/resources' },
    { label: 'Contact', path: '/contact' }
  ],
  es: [
    { label: 'Inicio', path: '/' },
    { label: 'Laboratorio de inflación', path: '/inflation' },
    { label: 'Curso', path: '/course' },
    { label: 'Recursos', path: '/resources' },
    { label: 'Contacto', path: '/contact' }
  ]
};

export const footerContent = {
  en: {
    description: 'Información confiable que respalda elecciones responsables sobre tu dinero.',
    mission: 'Pasos acertados hoy, mejor futuro mañana.',
    officeTitle: 'Headquarters',
    contactTitle: 'Connect',
    socialTitle: 'Community',
    compliance: 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.',
    emailLabel: 'Email',
    phoneLabel: 'Phone',
    rights: '© {year} Tu Progreso Hoy. All rights reserved.',
    quickLinksTitle: 'Policies',
    quickLinks: [
      { label: 'Privacy Policy', path: '/privacy' },
      { label: 'Cookies Policy', path: '/cookies' },
      { label: 'Terms of Service', path: '/terms' }
    ],
    socials: [
      { label: 'LinkedIn', url: 'https://www.linkedin.com', handle: '@TuProgresoHoy' },
      { label: 'YouTube', url: 'https://www.youtube.com', handle: 'Tu Progreso Hoy' },
      { label: 'X (Twitter)', url: 'https://twitter.com', handle: '@TuProgresoHoy' }
    ]
  },
  es: {
    description: 'Información confiable que respalda elecciones responsables sobre tu dinero.',
    mission: 'Pasos acertados hoy, mejor futuro mañana.',
    officeTitle: 'Oficinas',
    contactTitle: 'Contacto',
    socialTitle: 'Comunidad',
    compliance: 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.',
    emailLabel: 'Correo',
    phoneLabel: 'Teléfono',
    rights: '© {year} Tu Progreso Hoy. Todos los derechos reservados.',
    quickLinksTitle: 'Políticas',
    quickLinks: [
      { label: 'Política de Privacidad', path: '/privacy' },
      { label: 'Política de Cookies', path: '/cookies' },
      { label: 'Términos del servicio', path: '/terms' }
    ],
    socials: [
      { label: 'LinkedIn', url: 'https://www.linkedin.com', handle: '@TuProgresoHoy' },
      { label: 'YouTube', url: 'https://www.youtube.com', handle: 'Tu Progreso Hoy' },
      { label: 'X (Twitter)', url: 'https://twitter.com', handle: '@TuProgresoHoy' }
    ]
  }
};

export const homeContent = {
  en: {
    hero: {
      kicker: 'Datos verificados para planificar tu presupuesto.',
      title: "Build resilient financial habits for Argentina's next chapter",
      subtitle: 'Tu Progreso Hoy combines data-backed insights with guided lessons so every objective stays actionable.',
      primaryCta: 'Explore inflation insights',
      secondaryCta: 'Review the course',
      tagline: 'Conocimiento financiero impulsado por tendencias.'
    },
    promises: {
      title: 'Premium guidance rooted in transparency',
      subtitle: 'Decisiones responsables, objetivos nítidos.',
      items: [
        {
          title: 'Verified macro indicators',
          description: 'We curate official CPI, respected private projections, and currency references to give you one reliable knowledge hub.'
        },
        {
          title: 'Context explained clearly',
          description: 'Análisis transparentes y datos de mercado para decidir con seguridad.'
        },
        {
          title: 'Actionable lesson pathways',
          description: 'Move from nuance to practice with accountability templates that keep every milestone grounded in reality.'
        }
      ]
    },
    tracker: {
      title: 'ARS → USD live tracker',
      subtitle: 'Monitor FX moves alongside your study plan.'
    },
    insights: {
      title: 'Insight pulses you can act on',
      subtitle: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
      items: [
        {
          title: 'Weekly CPI digest',
          description: 'Review variance drivers, fuel and food adjustments, and demand-side narratives in one bilingual brief.'
        },
        {
          title: 'FX corridor spotlight',
          description: 'Contrast official and market-driven rates with concise explanations for spreads and policy signals.'
        },
        {
          title: 'Household budget labs',
          description: 'Scenario planning templates help you stress-test purchases and savings decisions with up-to-date ratios.'
        }
      ]
    },
    courseOverview: {
      title: 'Course overview at a glance',
      subtitle: 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.',
      modules: [
        {
          title: 'Module 1 · Inflation decoded',
          duration: '2 hrs guided + 1 hr practice',
          description: 'Understand CPI components, price normalization, and how to translate reports into household context.'
        },
        {
          title: 'Module 2 · Currency dynamics',
          duration: '3 hrs guided + 1 hr practice',
          description: 'Assess monetary policy notes, FX regulations, and hedging basics tailored for everyday decisions.'
        },
        {
          title: 'Module 3 · Planning studio',
          duration: '2 hrs guided + 2 hrs practice',
          description: 'Apply trackers, build adaptive budgets, and evaluate opportunity costs through real Argentine case studies.'
        }
      ],
      highlights: [
        'Live cohort sessions with bilingual mentors',
        'Practical labs built around actual data dashboards',
        'Downloadable checklists to stay accountable'
      ],
      ctaLabel: 'Jump to the enrollment form',
      ctaLink: '#course-trial-form'
    },
    testimonials: {
      title: 'Learners progressing with clarity',
      subtitle: 'Stories from professionals and students in Buenos Aires.',
      items: [
        {
          quote: '“The inflation methodology dashboard finally helped our family compare official updates with retail invoices in a single view.”',
          name: 'Lucía Fernández',
          role: 'Entrepreneur · Palermo'
        },
        {
          quote: '“Having lessons in both languages meant our team could align quickly on budgeting assumptions during quarterly reviews.”',
          name: 'Matías Gómez',
          role: 'Finance Lead · Caballito'
        },
        {
          quote: '“Course prompts insisted on realistic goals and kept us away from hype. Exactly the responsible guidance we needed.”',
          name: 'Sofía López',
          role: 'University Student · Recoleta'
        }
      ]
    },
    form: {
      title: 'Get your free trial lesson',
      subtitle: 'Receive the welcome module preview and double opt-in to confirm your participation.',
      fields: [
        { name: 'fullName', label: 'Full name', placeholder: 'Your name', type: 'text', required: true },
        { name: 'email', label: 'Email', placeholder: 'name@example.com', type: 'email', required: true }
      ],
      submitLabel: 'Continue to email confirmation',
      confirmationTitle: 'Confirm your subscription',
      confirmationBody: 'We have sent a confirmation email. Open it, click confirm, then acknowledge below to access your trial lesson.',
      confirmationCheckbox: 'I confirm that I approved the email from Tu Progreso Hoy.',
      confirmButton: 'I have confirmed my email',
      privacyNote: 'By continuing you agree to our Privacy Policy and Cookies Policy.'
    }
  },
  es: {
    hero: {
      kicker: 'Datos verificados para planificar tu presupuesto.',
      title: 'Construí hábitos financieros resilientes para el próximo capítulo de Argentina',
      subtitle: 'Tu Progreso Hoy combina insights con datos para que cada objetivo sea accionable.',
      primaryCta: 'Explorar metodología de inflación',
      secondaryCta: 'Ver el curso',
      tagline: 'Conocimiento financiero impulsado por tendencias.'
    },
    promises: {
      title: 'Guía premium basada en transparencia',
      subtitle: 'Decisiones responsables, objetivos nítidos.',
      items: [
        {
          title: 'Indicadores macro verificados',
          description: 'Integramos el IPC oficial, proyecciones privadas reconocidas y referencias cambiarias en un hub confiable.'
        },
        {
          title: 'Contexto explicado con claridad',
          description: 'Análisis transparentes y datos de mercado para decidir con seguridad.'
        },
        {
          title: 'Rutas formativas accionables',
          description: 'Pasá del análisis a la práctica con plantillas de seguimiento que mantienen cada meta en tierra firme.'
        }
      ]
    },
    tracker: {
      title: 'ARS → USD en tiempo real',
      subtitle: 'Controlá los movimientos cambiarios junto a tu plan de estudio.'
    },
    insights: {
      title: 'Pulso de insights para accionar',
      subtitle: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
      items: [
        {
          title: 'Digest de IPC semanal',
          description: 'Revisá los impulsores de variación, ajustes en combustibles y alimentos, y narrativas de demanda en un brief bilingüe.'
        },
        {
          title: 'Spotlight del corredor cambiario',
          description: 'Contrastá los tipos oficiales y de mercado con explicaciones concisas sobre brechas y señales de política.'
        },
        {
          title: 'Laboratorios de presupuesto',
          description: 'Los escenarios te ayudan a testear compras y ahorros con ratios actualizados.'
        }
      ]
    },
    courseOverview: {
      title: 'Resumen del curso a simple vista',
      subtitle: 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.',
      modules: [
        {
          title: 'Módulo 1 · Inflación decodificada',
          duration: '2 h guiadas + 1 h práctica',
          description: 'Comprendé los componentes del IPC, la normalización de precios y cómo llevar los reportes a tu hogar.'
        },
        {
          title: 'Módulo 2 · Dinámica cambiaria',
          duration: '3 h guiadas + 1 h práctica',
          description: 'Analizá política monetaria, regulaciones y nociones de cobertura adaptadas a decisiones cotidianas.'
        },
        {
          title: 'Módulo 3 · Estudio de planificación',
          duration: '2 h guiadas + 2 h práctica',
          description: 'Aplicá tableros, construí presupuestos adaptables y evaluá costos de oportunidad con casos argentinos.'
        }
      ],
      highlights: [
        'Sesiones en vivo con mentores bilingües',
        'Laboratorios prácticos con tableros reales',
        'Checklists descargables para sostener tus hábitos'
      ],
      ctaLabel: 'Ir al formulario de inscripción',
      ctaLink: '#course-trial-form'
    },
    testimonials: {
      title: 'Personas que avanzan con claridad',
      subtitle: 'Historias de profesionales y estudiantes en Buenos Aires.',
      items: [
        {
          quote: '“El tablero de metodología de inflación nos permitió comparar datos oficiales con tickets minoristas en una sola vista.”',
          name: 'Lucía Fernández',
          role: 'Emprendedora · Palermo'
        },
        {
          quote: '“Tener materiales en ambos idiomas ayudó a nuestro equipo a alinear supuestos de presupuesto en las reuniones trimestrales.”',
          name: 'Matías Gómez',
          role: 'Líder financiero · Caballito'
        },
        {
          quote: '“El curso exigió objetivos realistas y nos mantuvo lejos del hype. La guía responsable que necesitábamos.”',
          name: 'Sofía López',
          role: 'Estudiante universitaria · Recoleta'
        }
      ]
    },
    form: {
      title: 'Accedé a la clase de prueba',
      subtitle: 'Recibí el módulo de bienvenida y completá el doble opt-in para confirmar tu participación.',
      fields: [
        { name: 'fullName', label: 'Nombre completo', placeholder: 'Tu nombre', type: 'text', required: true },
        { name: 'email', label: 'Correo electrónico', placeholder: 'nombre@ejemplo.com', type: 'email', required: true }
      ],
      submitLabel: 'Continuar a la confirmación por correo',
      confirmationTitle: 'Confirmá tu suscripción',
      confirmationBody: 'Enviamos un correo de confirmación. Abrilo, hacé clic en confirmar y reconocelo debajo para acceder a la clase.',
      confirmationCheckbox: 'Confirmo que aprobé el correo de Tu Progreso Hoy.',
      confirmButton: 'Ya confirmé mi correo',
      privacyNote: 'Al continuar aceptás la Política de Privacidad y la Política de Cookies.'
    }
  }
};

export const inflationContent = {
  en: {
    heroTitle: 'Inflation methodology grounded in market reality',
    intro:
      'We triangulate public institutional reports, independent consultancies, and on-the-ground retail panels to build a balanced inflation perspective for Argentina.',
    methodologyTitle: 'How our methodology works',
    steps: [
      {
        title: 'Source curation',
        description:
          'Blend INDEC releases with credible private index providers and supermarket baskets updated daily.'
      },
      {
        title: 'Normalization & weighting',
        description:
          'Adjust categories for volatility, convert to comparable baselines, and weight by urban household relevance.'
      },
      {
        title: 'Cross-validation',
        description:
          'Compare rolling averages, evaluate deviations from official communications, and annotate drivers inside the dashboard.'
      },
      {
        title: 'Narrative summary',
        description:
          'Convert the data into lean bulletins that reinforce Información confiable que respalda elecciones responsables sobre tu dinero.'
      }
    ],
    chartSection: {
      title: 'CPI & FX stress test',
      subtitle: 'Consolidated monthly CPI vs ARS exchange references (last 12 months)',
      note:
        'Data compiled from INDEC, BCRA communications, and Tu Progreso Hoy internal research. Values represent percent change month-over-month.'
    },
    contextBlocks: [
      {
        title: 'CPI in focus',
        body:
          'Our CPI line blends official indices with mainstream consultancies to temper anomalies and highlight persistent price clusters.'
      },
      {
        title: 'FX corridor',
        body:
          'Overlay official and market-driven FX markers to identify spreads that may influence import-dependent categories.'
      },
      {
        title: 'Scenario planning',
        body:
          'Use the tracker alongside the course exercises to align family, freelance, or business planning horizons.'
      }
    ],
    faqTitle: 'Frequently asked questions',
    faqItems: [
      {
        question: 'How often is the ARS→USD tracker refreshed?',
        answer:
          'We update FX data throughout the day using exchangerate.host and annotate shifts that exceed 2% to guide your review cadence.'
      },
      {
        question: 'Do you issue direct investment calls?',
        answer:
          'No. Plataforma educativa con datos esenciales, sin asesoría financiera directa. We provide structured learning materials only.'
      },
      {
        question: 'Can I export the inflation datasets?',
        answer:
          'Yes. Subscribers receive CSV downloads and API access tiers aligned with their course enrollment.'
      },
      {
        question: 'Why compare CPI with FX pressure?',
        answer:
          'Monitoring both helps reveal pass-through effects and timing lags so you can prepare budgets with greater foresight.'
      }
    ]
  },
  es: {
    heroTitle: 'Metodología de inflación alineada con la realidad del mercado',
    intro:
      'Triangulamos informes institucionales, consultoras independientes y paneles minoristas para construir una perspectiva equilibrada de la inflación argentina.',
    methodologyTitle: 'Cómo funciona nuestra metodología',
    steps: [
      {
        title: 'Curación de fuentes',
        description:
          'Combinamos publicaciones del INDEC con índices privados creíbles y canastas de supermercados actualizadas a diario.'
      },
      {
        title: 'Normalización y ponderación',
        description:
          'Ajustamos categorías por volatilidad, llevamos a bases comparables y ponderamos según relevancia para hogares urbanos.'
      },
      {
        title: 'Validación cruzada',
        description:
          'Contrastamos promedios móviles, evaluamos desviaciones frente a comunicados oficiales y anotamos impulsores en el tablero.'
      },
      {
        title: 'Resumen narrativo',
        description:
          'Transformamos los datos en boletines concisos que refuerzan Información confiable que respalda elecciones responsables sobre tu dinero.'
      }
    ],
    chartSection: {
      title: 'Stress test de IPC y FX',
      subtitle: 'IPC consolidado vs referencias cambiarias ARS (últimos 12 meses)',
      note:
        'Datos compilados de INDEC, comunicaciones del BCRA e investigación interna de Tu Progreso Hoy. Valores expresan variación porcentual mensual.'
    },
    contextBlocks: [
      {
        title: 'IPC en foco',
        body:
          'La línea de IPC integra índices oficiales con consultoras para atenuar anomalías y resaltar clusters persistentes de precios.'
      },
      {
        title: 'Corredor cambiario',
        body:
          'Superponemos referencias oficiales y de mercado para detectar brechas que afectan categorías importadas.'
      },
      {
        title: 'Planificación de escenarios',
        body:
          'Usá el tablero junto a los ejercicios del curso para alinear horizontes de planificación familiar, freelance o empresarial.'
      }
    ],
    faqTitle: 'Preguntas frecuentes',
    faqItems: [
      {
        question: '¿Con qué frecuencia se actualiza el tracker ARS→USD?',
        answer:
          'Actualizamos los datos cambiarios durante el día con exchangerate.host y señalamos variaciones mayores al 2% para guiar tu seguimiento.'
      },
      {
        question: '¿Realizan recomendaciones de inversión directas?',
        answer:
          'No. Plataforma educativa con datos esenciales, sin asesoría financiera directa. Proveemos materiales formativos estructurados.'
      },
      {
        question: '¿Puedo exportar los datasets de inflación?',
        answer:
          'Sí. Los suscriptores acceden a descargas CSV y niveles API acordes a su inscripción.'
      },
      {
        question: '¿Por qué comparar IPC con presión cambiaria?',
        answer:
          'Observar ambos permite detectar efectos de traspaso y rezagos temporales para preparar presupuestos con mayor anticipación.'
      }
    ]
  }
};

export const courseContent = {
  en: {
    heroTitle: 'Course syllabus tailored for Argentine realities',
    intro:
      'Each module blends bilingual instruction with dashboards and labs to help you implement decisions responsibly.',
    audienceTitle: 'Designed for',
    audienceItems: [
      'Professionals recalibrating quarterly budgets',
      'Freelancers managing peso and dollar income',
      'Students developing analytical finance skills'
    ],
    modulesTitle: 'Modules',
    modules: [
      {
        name: 'Module 1 · Inflation decoded',
        outcomes: [
          'Interpret CPI releases and private indices with confidence.',
          'Translate variance into household and business budgets.'
        ],
        resources: 'Workbook + interactive quiz'
      },
      {
        name: 'Module 2 · Currency dynamics',
        outcomes: [
          'Compare official vs alternative FX paths and understand gap drivers.',
          'Sequence purchase decisions around regulations and liquidity.'
        ],
        resources: 'Live workshop + simulator'
      },
      {
        name: 'Module 3 · Planning studio',
        outcomes: [
          'Build adaptive cash-flow templates with real datasets.',
          'Communicate scenarios clearly to teams, families, or clients.'
        ],
        resources: 'Scenario labs + peer feedback'
      }
    ],
    formatTitle: 'Learning format',
    formatItems: [
      'Hybrid sessions (Buenos Aires classroom + live streaming)',
      'Bilingual materials with localized terminology',
      'Peer forum moderated by analysts'
    ],
    ctaText: 'Pasos acertados hoy, mejor futuro mañana.',
    ctaButton: 'Reserve my spot',
    formReference: {
      label: 'Go to enrollment form',
      anchor: '#course-trial-form'
    },
    form: {
      title: 'Secure your enrollment',
      subtitle: 'Complete the double opt-in to confirm your course reservation.',
      fields: [
        { name: 'fullName', label: 'Full name', placeholder: 'Your name', type: 'text', required: true },
        { name: 'email', label: 'Email', placeholder: 'name@example.com', type: 'email', required: true },
        { name: 'role', label: 'Role or focus area', placeholder: 'Student, analyst, entrepreneur…', type: 'text', required: true }
      ],
      submitLabel: 'Continue to confirmation email',
      confirmationTitle: 'Confirm your enrollment request',
      confirmationBody:
        'Check your inbox for a message from Tu Progreso Hoy. Approve the link and acknowledge below to finalize your seat.',
      confirmationCheckbox: 'I verified the confirmation email from Tu Progreso Hoy.',
      confirmButton: 'Finalize my enrollment request',
      privacyNote: 'Submitting confirms agreement with our Privacy and Cookies policies.'
    }
  },
  es: {
    heroTitle: 'Programa pensado para la realidad argentina',
    intro:
      'Cada módulo combina instrucción bilingüe con tableros y laboratorios para ayudarte a implementar decisiones responsables.',
    audienceTitle: 'Pensado para',
    audienceItems: [
      'Profesionales que recalibran presupuestos trimestrales',
      'Freelancers que gestionan ingresos en pesos y dólares',
      'Estudiantes que desarrollan habilidades financieras analíticas'
    ],
    modulesTitle: 'Módulos',
    modules: [
      {
        name: 'Módulo 1 · Inflación decodificada',
        outcomes: [
          'Interpretar informes del IPC y índices privados con seguridad.',
          'Trasladar variaciones a presupuestos familiares o empresariales.'
        ],
        resources: 'Cuaderno de trabajo + quiz interactivo'
      },
      {
        name: 'Módulo 2 · Dinámica cambiaria',
        outcomes: [
          'Comparar trayectorias oficiales y alternativas y entender las brechas.',
          'Ordenar decisiones de compra según regulaciones y liquidez.'
        ],
        resources: 'Workshop en vivo + simulador'
      },
      {
        name: 'Módulo 3 · Estudio de planificación',
        outcomes: [
          'Construir plantillas de flujo adaptables con datos reales.',
          'Comunicar escenarios a equipos, familias o clientes.'
        ],
        resources: 'Laboratorios de escenarios + feedback entre pares'
      }
    ],
    formatTitle: 'Formato de aprendizaje',
    formatItems: [
      'Sesiones híbridas (aula en Buenos Aires + streaming en vivo)',
      'Materiales bilingües con terminología local',
      'Foro de pares moderado por analistas'
    ],
    ctaText: 'Pasos acertados hoy, mejor futuro mañana.',
    ctaButton: 'Reservar mi lugar',
    formReference: {
      label: 'Ir al formulario de inscripción',
      anchor: '#course-trial-form'
    },
    form: {
      title: 'Garantizá tu inscripción',
      subtitle: 'Completá el doble opt-in para confirmar tu reserva.',
      fields: [
        { name: 'fullName', label: 'Nombre completo', placeholder: 'Tu nombre', type: 'text', required: true },
        { name: 'email', label: 'Correo electrónico', placeholder: 'nombre@ejemplo.com', type: 'email', required: true },
        { name: 'role', label: 'Rol o foco', placeholder: 'Estudiante, analista, emprendedor…', type: 'text', required: true }
      ],
      submitLabel: 'Continuar a la confirmación por correo',
      confirmationTitle: 'Confirmá tu solicitud',
      confirmationBody:
        'Revisá tu bandeja de entrada, abrí el correo de Tu Progreso Hoy y confirmá el enlace antes de continuar.',
      confirmationCheckbox: 'Verifiqué el correo de confirmación de Tu Progreso Hoy.',
      confirmButton: 'Finalizar solicitud de inscripción',
      privacyNote: 'Al enviar confirmás tu acuerdo con nuestras políticas de Privacidad y Cookies.'
    }
  }
};

export const resourcesContent = {
  en: {
    title: 'Resource library',
    subtitle: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
    intro:
      'Curated articles, explainers, and glossaries in English and Español to reinforce each lesson you complete.',
    articles: [
      {
        title: 'Argentina CPI essentials (EN/ES)',
        description:
          'Understand basket composition shifts, regional differentials, and how to present findings in bilingual teams.',
        language: 'English · Español',
        linkLabel: 'Open guide',
        href: '#cpi-essentials'
      },
      {
        title: 'FX gap explainer for everyday decisions',
        description:
          'A quick read on currency corridors, tax implications, and practical checklists for upcoming purchases.',
        language: 'English · Español',
        linkLabel: 'Read explainer',
        href: '#fx-gap'
      },
      {
        title: 'Household budgeting templates',
        description:
          'Downloadable sheets and Notion dashboards synced with our ARS trackers to plan responsibly.',
        language: 'English · Español',
        linkLabel: 'Download templates',
        href: '#budgeting'
      }
    ],
    glossaryTitle: 'Glossary snapshots',
    glossaryItems: [
      {
        term: 'Brecha cambiaria',
        definition:
          'Difference between official and alternative exchange rates. Key for pricing imports and future cash flows.'
      },
      {
        term: 'Rolling average',
        definition:
          'A moving average used to smooth volatility and highlight the underlying trend in CPI or FX data.'
      },
      {
        term: 'Pass-through',
        definition:
          'The speed and intensity with which exchange rate shifts influence consumer prices.'
      }
    ],
    note: 'Información confiable que respalda elecciones responsables sobre tu dinero.'
  },
  es: {
    title: 'Biblioteca de recursos',
    subtitle: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
    intro:
      'Artículos, explicadores y glosarios en Español e Inglés para reforzar cada lección completada.',
    articles: [
      {
        title: 'Esenciales del IPC argentino (EN/ES)',
        description:
          'Comprendé la composición de la canasta, diferenciales regionales y cómo presentar hallazgos en equipos bilingües.',
        language: 'Español · English',
        linkLabel: 'Abrir guía',
        href: '#cpi-essentials'
      },
      {
        title: 'Explicador de brecha cambiaria para decisiones cotidianas',
        description:
          'Lectura ágil sobre corredores cambiarios, implicancias tributarias y checklists para compras próximas.',
        language: 'Español · English',
        linkLabel: 'Leer explicador',
        href: '#fx-gap'
      },
      {
        title: 'Plantillas de presupuesto familiar',
        description:
          'Hojas descargables y tableros en Notion sincronizados con nuestros trackers ARS para planificar con responsabilidad.',
        language: 'Español · English',
        linkLabel: 'Descargar plantillas',
        href: '#budgeting'
      }
    ],
    glossaryTitle: 'Glosario express',
    glossaryItems: [
      {
        term: 'Brecha cambiaria',
        definition:
          'Diferencia entre el tipo oficial y las referencias alternativas. Clave para precios de importados y flujos futuros.'
      },
      {
        term: 'Promedio móvil',
        definition:
          'Promedio que suaviza la volatilidad y resalta la tendencia subyacente en IPC o FX.'
      },
      {
        term: 'Pass-through',
        definition:
          'Velocidad e intensidad con que los cambios cambiarios impactan en los precios al consumidor.'
      }
    ],
    note: 'Información confiable que respalda elecciones responsables sobre tu dinero.'
  }
};

export const contactContent = {
  en: {
    title: 'Connect with Tu Progreso Hoy',
    subtitle:
      'Our Buenos Aires team responds within one business day. Use the bilingual form to start the conversation.',
    mapTitle: 'Visit our learning studio',
    address: 'Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina',
    email: 'hola@tuprogresohoy.com',
    phone: '+54 11 5555-1234',
    socials: [
      { label: 'LinkedIn', url: 'https://www.linkedin.com', handle: '@TuProgresoHoy' },
      { label: 'Instagram', url: 'https://www.instagram.com', handle: '@TuProgresoHoy' }
    ],
    form: {
      title: 'Reach out',
      subtitle: 'Share a brief overview and confirm your email to receive our response.',
      fields: [
        { name: 'fullName', label: 'Full name', placeholder: 'Your name', type: 'text', required: true },
        { name: 'email', label: 'Email', placeholder: 'name@example.com', type: 'email', required: true },
        { name: 'topic', label: 'Topic or question', placeholder: 'Course enrollment, inflation data, partnerships…', type: 'text', required: true },
        { name: 'message', label: 'Message', placeholder: 'Tell us about your needs and timeline.', type: 'textarea', required: true }
      ],
      submitLabel: 'Continue to email confirmation',
      confirmationTitle: 'Check your inbox',
      confirmationBody:
        'We sent a confirmation email. Approve it to validate your inquiry, then acknowledge below so we can reply.',
      confirmationCheckbox: 'I confirmed the Tu Progreso Hoy email in my inbox.',
      confirmButton: 'I confirmed my email',
      privacyNote: 'Your information is stored securely and handled according to our policies.'
    }
  },
  es: {
    title: 'Conectá con Tu Progreso Hoy',
    subtitle:
      'Nuestro equipo en Buenos Aires responde dentro de un día hábil. Usá el formulario bilingüe para iniciar la conversación.',
    mapTitle: 'Visitá nuestro estudio de aprendizaje',
    address: 'Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina',
    email: 'hola@tuprogresohoy.com',
    phone: '+54 11 5555-1234',
    socials: [
      { label: 'LinkedIn', url: 'https://www.linkedin.com', handle: '@TuProgresoHoy' },
      { label: 'Instagram', url: 'https://www.instagram.com', handle: '@TuProgresoHoy' }
    ],
    form: {
      title: 'Escribinos',
      subtitle: 'Contanos brevemente y confirmá tu correo para recibir nuestra respuesta.',
      fields: [
        { name: 'fullName', label: 'Nombre completo', placeholder: 'Tu nombre', type: 'text', required: true },
        { name: 'email', label: 'Correo electrónico', placeholder: 'nombre@ejemplo.com', type: 'email', required: true },
        { name: 'topic', label: 'Tema o consulta', placeholder: 'Inscripción, datos de inflación, alianzas…', type: 'text', required: true },
        { name: 'message', label: 'Mensaje', placeholder: 'Contanos necesidades y plazos.', type: 'textarea', required: true }
      ],
      submitLabel: 'Continuar a la confirmación por correo',
      confirmationTitle: 'Revisá tu bandeja',
      confirmationBody:
        'Te enviamos un correo de confirmación. Aprobalo para validar la consulta y reconocelo debajo para avanzar.',
      confirmationCheckbox: 'Confirmé el correo de Tu Progreso Hoy en mi bandeja.',
      confirmButton: 'Confirmé mi correo',
      privacyNote: 'Guardamos tu información de forma segura y según nuestras políticas.'
    }
  }
};

export const thankYouContent = {
  en: {
    title: 'Thank you for confirming',
    message:
      'Your double opt-in is complete. Check your email for access to the requested materials and next steps.',
    cta: 'Return to home'
  },
  es: {
    title: 'Gracias por confirmar',
    message:
      'Completaste el doble opt-in. Revisá tu correo para acceder al material solicitado y próximos pasos.',
    cta: 'Volver al inicio'
  }
};

export const policyContent = {
  privacy: {
    en: {
      title: 'Privacy Policy',
      updated: 'Updated: April 2024',
      intro:
        'This Privacy Policy explains how Tu Progreso Hoy collects, uses, and protects your personal information when you interact with our bilingual education platform.',
      sections: [
        {
          heading: '1. Data collection',
          paragraphs: [
            'We collect the information you provide directly, such as name, email address, and course preferences, when you complete forms or participate in sessions.',
            'Analytics tools capture non-identifiable data including device type, browser, and interaction events to improve accessibility and performance.'
          ]
        },
        {
          heading: '2. How we use your information',
          paragraphs: [
            'To deliver course materials, send double opt-in confirmations, and keep you informed about updates that match your selected interests.',
            'To comply with legal obligations and maintain secure, responsible data practices aligned with Argentine regulations.'
          ]
        },
        {
          heading: '3. Your choices',
          paragraphs: [
            'You can request access, correction, or deletion of your personal data by emailing hola@tuprogresohoy.com.',
            'Marketing communications always include an opt-out option. Transactional messages related to double opt-in or course delivery remain essential.'
          ]
        }
      ]
    },
    es: {
      title: 'Política de Privacidad',
      updated: 'Actualizada: Abril 2024',
      intro:
        'Esta Política de Privacidad explica cómo Tu Progreso Hoy recopila, utiliza y protege tu información personal cuando interactuás con nuestra plataforma educativa bilingüe.',
      sections: [
        {
          heading: '1. Recolección de datos',
          paragraphs: [
            'Recopilamos la información que brindás directamente, como nombre, correo y preferencias de curso, al completar formularios o participar en sesiones.',
            'Las herramientas analíticas registran datos no identificables como dispositivo, navegador y eventos de interacción para mejorar accesibilidad y desempeño.'
          ]
        },
        {
          heading: '2. Uso de la información',
          paragraphs: [
            'Para entregar materiales del curso, enviar confirmaciones de doble opt-in y mantenerte informado sobre novedades acordes a tus intereses.',
            'Para cumplir obligaciones legales y conservar prácticas seguras y responsables alineadas con la normativa argentina.'
          ]
        },
        {
          heading: '3. Tus opciones',
          paragraphs: [
            'Podés solicitar acceso, corrección o eliminación de tus datos personales escribiendo a hola@tuprogresohoy.com.',
            'Las comunicaciones de marketing incluyen opción de baja. Los mensajes transaccionales vinculados al doble opt-in o entrega del curso son esenciales.'
          ]
        }
      ]
    }
  },
  cookies: {
    en: {
      title: 'Cookies Policy',
      updated: 'Updated: April 2024',
      intro:
        'This Cookies Policy describes how Tu Progreso Hoy uses cookies and similar technologies to provide a secure and personalized experience.',
      sections: [
        {
          heading: '1. What are cookies?',
          paragraphs: [
            'Cookies are small text files stored on your device to remember preferences, enable essential features, and measure website performance.',
            'We use strictly necessary cookies for language settings and analytics cookies to understand aggregated behavior.'
          ]
        },
        {
          heading: '2. Managing cookies',
          paragraphs: [
            'Our cookie banner allows you to accept or decline optional cookies. You can change your choice at any time by clearing your browser cache.',
            'Declining optional cookies will not affect access to core educational content.'
          ]
        },
        {
          heading: '3. Third-party services',
          paragraphs: [
            'We may integrate trusted analytics tools that comply with GDPR and Argentine data requirements.',
            'All third-party providers are evaluated to ensure responsible data practices.'
          ]
        }
      ]
    },
    es: {
      title: 'Política de Cookies',
      updated: 'Actualizada: Abril 2024',
      intro:
        'Esta Política de Cookies describe cómo Tu Progreso Hoy utiliza cookies y tecnologías similares para brindar una experiencia segura y personalizada.',
      sections: [
        {
          heading: '1. ¿Qué son las cookies?',
          paragraphs: [
            'Las cookies son archivos de texto que se guardan en tu dispositivo para recordar preferencias, habilitar funciones esenciales y medir el rendimiento del sitio.',
            'Usamos cookies estrictamente necesarias para la configuración de idioma y cookies analíticas para comprender comportamientos agregados.'
          ]
        },
        {
          heading: '2. Gestión de cookies',
          paragraphs: [
            'Nuestro banner te permite aceptar o rechazar cookies opcionales. Podés cambiar tu decisión eliminando la caché del navegador.',
            'Rechazar cookies opcionales no afecta el acceso al contenido educativo principal.'
          ]
        },
        {
          heading: '3. Servicios de terceros',
          paragraphs: [
            'Podemos integrar herramientas analíticas confiables que cumplen con GDPR y requisitos de datos en Argentina.',
            'Todos los proveedores externos se evalúan para asegurar prácticas responsables de datos.'
          ]
        }
      ]
    }
  },
  terms: {
    en: {
      title: 'Terms of Service',
      updated: 'Updated: April 2024',
      intro:
        'These Terms of Service govern your use of Tu Progreso Hoy. By accessing our site or enrolling in courses, you agree to these terms.',
      sections: [
        {
          heading: '1. Educational purpose',
          paragraphs: [
            'Tu Progreso Hoy offers educational content and data analysis tools. We do not provide financial services or individualized investment advice.',
            'All insights are for learning purposes. You remain responsible for financial decisions you undertake.'
          ]
        },
        {
          heading: '2. User responsibilities',
          paragraphs: [
            'Maintain accurate account information and respect bilingual community guidelines.',
            'Do not share course materials publicly without written permission from Tu Progreso Hoy.'
          ]
        },
        {
          heading: '3. Liability',
          paragraphs: [
            'We strive to deliver timely and accurate data. However, we do not accept liability for outcomes resulting from how information is used.',
            'In case of service interruptions, our obligation is limited to restoring access or extending enrollment periods.'
          ]
        }
      ]
    },
    es: {
      title: 'Términos del Servicio',
      updated: 'Actualizados: Abril 2024',
      intro:
        'Estos Términos del Servicio rigen el uso de Tu Progreso Hoy. Al acceder al sitio o inscribirte en cursos, aceptás estas condiciones.',
      sections: [
        {
          heading: '1. Propósito educativo',
          paragraphs: [
            'Tu Progreso Hoy brinda contenido educativo y herramientas de análisis de datos. No ofrecemos servicios financieros ni asesoramiento de inversión individual.',
            'Los insights son para aprendizaje. Las decisiones financieras que realices son de tu responsabilidad.'
          ]
        },
        {
          heading: '2. Responsabilidades del usuario',
          paragraphs: [
            'Mantené la información de tu cuenta actualizada y respetá las normas bilingües de la comunidad.',
            'No compartas públicamente materiales del curso sin autorización escrita de Tu Progreso Hoy.'
          ]
        },
        {
          heading: '3. Responsabilidad',
          paragraphs: [
            'Nos esforzamos por entregar datos oportunos y precisos. Sin embargo, no asumimos responsabilidad por los resultados del uso de la información.',
            'Ante interrupciones del servicio, nuestra obligación se limita a restablecer el acceso o extender períodos de cursada.'
          ]
        }
      ]
    }
  }
};

export const fixedSpanishMessages = [
  'Datos verificados para planificar tu presupuesto.',
  'Decisiones responsables, objetivos nítidos.',
  'Conocimiento financiero impulsado por tendencias.',
  'Pasos acertados hoy, mejor futuro mañana.',
  'Análisis transparentes y datos de mercado para decidir con seguridad.',
  'Información confiable que respalda elecciones responsables sobre tu dinero.',
  'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
  'Plataforma educativa con datos esenciales, sin asesoría financiera directa.',
  'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
];