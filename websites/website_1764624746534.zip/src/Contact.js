import React, { useContext } from 'react';
import { Helmet } from 'react-helmet-async';
import Section from './Section';
import Card from './Card';
import DoubleOptInForm from './DoubleOptInForm';
import { LanguageContext } from './LanguageContext';
import { contactContent } from './translations';

const Contact = () => {
  const { language } = useContext(LanguageContext);
  const content = contactContent[language];

  return (
    <>
      <Helmet>
        <title>{language === 'es' ? 'Tu Progreso Hoy | Contacto' : 'Tu Progreso Hoy | Contact'}</title>
        <meta
          name="description"
          content={
            language === 'es'
              ? 'Contactá a Tu Progreso Hoy en Buenos Aires para cursos y datos de inflación.'
              : 'Contact Tu Progreso Hoy in Buenos Aires for courses and inflation data.'
          }
        />
      </Helmet>

      <Section title={content.title} subtitle={content.subtitle} eyebrow="Contact">
        <div className="cards-grid">
          <Card>
            <h4>{content.mapTitle}</h4>
            <iframe
              title={language === 'es' ? 'Mapa de Buenos Aires' : 'Buenos Aires map'}
              className="map-embed"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3285.340239984519!2d-58.38246552445625!3d-34.59362035627945!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzTCsDM1JzM2LjkiUyA1OMKwMjInNTYuOCJX!5e0!3m2!1sen!2sar!4v1712293200000"
              loading="lazy"
              allowFullScreen
            ></iframe>
          </Card>
          <Card>
            <div className="contact-details">
              <div>
                <strong>{content.address}</strong>
              </div>
              <div>
                <a href="mailto:hola@tuprogresohoy.com">{content.email}</a><br />
                <a href="tel:+541155551234">{content.phone}</a>
              </div>
              <div>
                {content.socials.map((social) => (
                  <p key={social.label}>
                    <a href={social.url} target="_blank" rel="noopener noreferrer">
                      {social.label} · {social.handle}
                    </a>
                  </p>
                ))}
              </div>
            </div>
          </Card>
        </div>
      </Section>

      <Section title={content.form.title} subtitle={content.form.subtitle}>
        <DoubleOptInForm formId="contact-form" copy={content.form} redirect="/thank-you" />
      </Section>
    </>
  );
};

export default Contact;