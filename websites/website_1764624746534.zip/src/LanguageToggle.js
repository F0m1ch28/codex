import React, { useContext } from 'react';
import { LanguageContext } from './LanguageContext';

const LanguageToggle = () => {
  const { language, setLanguage } = useContext(LanguageContext);

  return (
    <div className="language-toggle" role="group" aria-label="Language selection">
      <button
        type="button"
        className={language === 'en' ? 'active' : ''}
        onClick={() => setLanguage('en')}
      >
        EN
      </button>
      <button
        type="button"
        className={language === 'es' ? 'active' : ''}
        onClick={() => setLanguage('es')}
      >
        ES
      </button>
    </div>
  );
};

export default LanguageToggle;