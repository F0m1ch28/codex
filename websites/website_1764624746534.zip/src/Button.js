import React from 'react';
import { Link } from 'react-router-dom';

const Button = ({ to, href, children, variant = 'primary', type = 'button', onClick, ...props }) => {
  if (to) {
    return (
      <Link to={to} className={`btn btn-${variant}`} onClick={onClick} {...props}>
        {children}
      </Link>
    );
  }

  if (href) {
    return (
      <a href={href} className={`btn btn-${variant}`} {...props}>
        {children}
      </a>
    );
  }

  return (
    <button type={type} className={`btn btn-${variant}`} onClick={onClick} {...props}>
      {children}
    </button>
  );
};

export default Button;