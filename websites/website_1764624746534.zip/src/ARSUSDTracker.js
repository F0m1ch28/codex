import React, { useEffect, useMemo, useState } from 'react';
import { Line } from 'react-chartjs-2';
import Card from './Card';

const formatDate = (date) => date.toISOString().split('T')[0];

const ARSUSDTracker = () => {
  const [series, setSeries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  useEffect(() => {
    const fetchRates = async () => {
      try {
        const end = new Date();
        const start = new Date();
        start.setDate(end.getDate() - 7);
        const url = `https://api.exchangerate.host/timeseries?base=ARS&symbols=USD&start_date=${formatDate(
          start
        )}&end_date=${formatDate(end)}`;

        const response = await fetch(url);
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        if (data.rates) {
          const points = Object.entries(data.rates)
            .map(([date, values]) => ({
              date,
              rate: values.USD
            }))
            .sort((a, b) => new Date(a.date) - new Date(b.date));
          setSeries(points);
          setLastUpdated(new Date().toLocaleString());
        } else {
          throw new Error('Invalid data structure');
        }
      } catch (err) {
        setError('Live data unavailable, displaying reference trend.');
        const fallback = Array.from({ length: 7 }).map((_, index) => {
          const date = new Date();
          date.setDate(date.getDate() - (6 - index));
          return {
            date: formatDate(date),
            rate: 0.0012 + index * 0.00002
          };
        });
        setSeries(fallback);
      } finally {
        setLoading(false);
      }
    };

    fetchRates();
  }, []);

  const chartConfig = useMemo(() => {
    const labels = series.map((point) => point.date);
    const data = series.map((point) => (point.rate ? (point.rate * 1).toFixed(6) : null));

    return {
      data: {
        labels,
        datasets: [
          {
            label: 'USD per 1 ARS',
            data,
            borderColor: '#2563EB',
            backgroundColor: 'rgba(37, 99, 235, 0.2)',
            tension: 0.35,
            pointRadius: 4,
            pointBackgroundColor: '#1F3A6F',
            fill: true
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: true,
            position: 'bottom'
          },
          tooltip: {
            callbacks: {
              label: (context) => `USD ${Number(context.parsed.y).toFixed(6)}`
            }
          }
        },
        scales: {
          y: {
            ticks: {
              callback: (value) => value.toFixed(6)
            }
          }
        }
      }
    };
  }, [series]);

  const latest = series[series.length - 1];
  const previous = series.length > 1 ? series[series.length - 2] : null;
  const change =
    latest && previous ? (((latest.rate - previous.rate) / previous.rate) * 100).toFixed(2) : null;

  const thousandConversion = latest ? (1000 * latest.rate).toFixed(2) : null;

  return (
    <div className="arsusd-wrapper">
      <Card>
        <div className="rate-display">
          <span className="badge">Live FX Tracker</span>
          <h3 className="rate-value">
            {loading ? 'Loading…' : latest ? `1 ARS = USD ${latest.rate.toFixed(6)}` : 'N/A'}
          </h3>
          <div className="rate-meta">
            {thousandConversion && (
              <span>
                ARS 1,000 ≈ USD {thousandConversion}
              </span>
            )}
            {change && (
              <span>
                Daily change: {change}% vs previous data point
              </span>
            )}
            {lastUpdated && (
              <span aria-live="polite">Last updated: {lastUpdated}</span>
            )}
            {error && <span role="alert">{error}</span>}
            <small>
              Source: exchangerate.host · Values rounded to six decimals for clarity.
            </small>
          </div>
        </div>
      </Card>
      <Card>
        <div className="chart-box" role="img" aria-label="Line chart showing ARS to USD evolution">
          {series.length > 0 ? (
            <Line data={chartConfig.data} options={chartConfig.options} />
          ) : (
            <p>Data loading…</p>
          )}
        </div>
      </Card>
    </div>
  );
};

export default ARSUSDTracker;