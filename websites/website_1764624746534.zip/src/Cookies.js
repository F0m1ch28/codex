import React, { useContext } from 'react';
import { Helmet } from 'react-helmet-async';
import { LanguageContext } from './LanguageContext';
import { policyContent } from './translations';
import PolicyTemplate from './PolicyTemplate';

const Cookies = () => {
  const { language } = useContext(LanguageContext);
  const content = policyContent.cookies[language];

  return (
    <>
      <Helmet>
        <title>{language === 'es' ? 'Tu Progreso Hoy | Política de Cookies' : 'Tu Progreso Hoy | Cookies Policy'}</title>
      </Helmet>
      <PolicyTemplate content={content} />
    </>
  );
};

export default Cookies;