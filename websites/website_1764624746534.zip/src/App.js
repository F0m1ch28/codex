import React, { useContext } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet, HelmetProvider } from 'react-helmet-async';
import { LanguageContext, LanguageProvider } from './LanguageContext';
import Header from './Header';
import Footer from './Footer';
import CookieBanner from './CookieBanner';
import DisclaimerPopup from './DisclaimerPopup';
import ScrollToTop from './ScrollToTop';
import Home from './Home';
import Inflation from './Inflation';
import Course from './Course';
import Resources from './Resources';
import Contact from './Contact';
import ThankYou from './ThankYou';
import Privacy from './Privacy';
import Cookies from './Cookies';
import Terms from './Terms';
import './chartConfig';

const AppContent = () => {
  const { language } = useContext(LanguageContext);
  const htmlLang = language === 'es' ? 'es-AR' : 'en';

  return (
    <Router>
      <Helmet>
        <html lang={htmlLang} />
        <link rel="alternate" href="https://www.tuprogresohoy.com/" hrefLang="en" />
        <link rel="alternate" href="https://www.tuprogresohoy.com/es-ar/" hrefLang="es-AR" />
      </Helmet>
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>
      <div className="app-shell">
        <CookieBanner />
        <DisclaimerPopup />
        <Header />
        <main id="main-content" role="main">
          <ScrollToTop />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/inflation" element={<Inflation />} />
            <Route path="/course" element={<Course />} />
            <Route path="/resources" element={<Resources />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/thank-you" element={<ThankYou />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookies" element={<Cookies />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="*" element={<Home />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
};

const App = () => (
  <HelmetProvider>
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  </HelmetProvider>
);

export default App;