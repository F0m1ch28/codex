import React, { useEffect, useState } from 'react';
import Button from './Button';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = typeof window !== 'undefined' ? window.localStorage.getItem('tph_cookie_consent') : null;
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('tph_cookie_consent', choice);
    }
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <p>
        We use essential cookies to remember your language selection and optional analytics cookies to improve the platform.
      </p>
      <div className="cookie-actions">
        <Button variant="secondary" onClick={() => handleChoice('declined')}>
          Decline
        </Button>
        <Button variant="primary" onClick={() => handleChoice('accepted')}>
          Accept
        </Button>
      </div>
    </div>
  );
};

export default CookieBanner;