import React from 'react';

const Card = ({ title, children, variant = 'default', as = 'div' }) => {
  const Component = as;
  const className = variant === 'highlight' ? 'card highlight-card' : 'card';

  return (
    <Component className={className}>
      {title && <h3 className="card-title">{title}</h3>}
      {children}
    </Component>
  );
};

export default Card;