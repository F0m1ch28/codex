import React, { useState } from 'react';

const AccordionItem = ({ item, index }) => {
  const [expanded, setExpanded] = useState(false);
  const toggle = () => setExpanded((prev) => !prev);

  return (
    <div className="accordion-item">
      <button
        type="button"
        className="accordion-button"
        aria-expanded={expanded}
        aria-controls={`accordion-panel-${index}`}
        onClick={toggle}
      >
        <span>{item.question}</span>
        <span>{expanded ? '−' : '+'}</span>
      </button>
      {expanded && (
        <div id={`accordion-panel-${index}`} className="accordion-panel">
          <p>{item.answer}</p>
        </div>
      )}
    </div>
  );
};

const Accordion = ({ items }) => (
  <div className="accordion">
    {items.map((item, index) => (
      <AccordionItem item={item} index={index} key={item.question} />
    ))}
  </div>
);

export default Accordion;