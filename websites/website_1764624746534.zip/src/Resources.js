import React, { useContext } from 'react';
import { Helmet } from 'react-helmet-async';
import Section from './Section';
import Card from './Card';
import Button from './Button';
import { LanguageContext } from './LanguageContext';
import { resourcesContent } from './translations';

const Resources = () => {
  const { language } = useContext(LanguageContext);
  const content = resourcesContent[language];

  return (
    <>
      <Helmet>
        <title>{language === 'es' ? 'Tu Progreso Hoy | Recursos' : 'Tu Progreso Hoy | Resources'}</title>
        <meta
          name="description"
          content={
            language === 'es'
              ? 'Accedé a artículos, glosarios y plantillas bilingües de Tu Progreso Hoy.'
              : 'Access Tu Progreso Hoy bilingual articles, glossaries, and templates.'
          }
        />
      </Helmet>

      <Section title={content.title} subtitle={content.subtitle} eyebrow={language === 'es' ? 'Biblioteca' : 'Library'}>
        <p>{content.intro}</p>
      </Section>

      <Section title={language === 'es' ? 'Artículos destacados' : 'Featured articles'} background="muted">
        <div className="cards-grid">
          {content.articles.map((article) => (
            <Card key={article.title} title={article.title}>
              <p>{article.description}</p>
              <p><strong>{article.language}</strong></p>
              <Button href={article.href} variant="secondary">
                {article.linkLabel}
              </Button>
            </Card>
          ))}
        </div>
      </Section>

      <Section title={content.glossaryTitle}>
        <div className="cards-grid">
          {content.glossaryItems.map((item) => (
            <Card key={item.term} title={item.term}>
              <p>{item.definition}</p>
            </Card>
          ))}
        </div>
        <p style={{ marginTop: '2rem', fontWeight: 600 }}>{content.note}</p>
      </Section>
    </>
  );
};

export default Resources;