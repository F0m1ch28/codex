import React, { useContext } from 'react';
import { Helmet } from 'react-helmet-async';
import Section from './Section';
import Button from './Button';
import { LanguageContext } from './LanguageContext';
import { thankYouContent } from './translations';

const ThankYou = () => {
  const { language } = useContext(LanguageContext);
  const content = thankYouContent[language];

  return (
    <>
      <Helmet>
        <title>{language === 'es' ? 'Tu Progreso Hoy | Gracias' : 'Tu Progreso Hoy | Thank You'}</title>
      </Helmet>
      <Section title={content.title} subtitle={content.message}>
        <Button to="/" variant="primary">
          {content.cta}
        </Button>
      </Section>
    </>
  );
};

export default ThankYou;