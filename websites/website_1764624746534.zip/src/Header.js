import React, { useContext, useState } from 'react';
import { NavLink } from 'react-router-dom';
import LanguageToggle from './LanguageToggle';
import Button from './Button';
import { LanguageContext } from './LanguageContext';
import { navigationContent } from './translations';

const Header = () => {
  const { language } = useContext(LanguageContext);
  const navItems = navigationContent[language];
  const [open, setOpen] = useState(false);

  const closeMenu = () => setOpen(false);

  return (
    <header>
      <div className="header-inner" role="navigation" aria-label="Main navigation">
        <div className="logo">Tu Progreso Hoy</div>
        <button
          className="menu-toggle"
          aria-expanded={open}
          aria-controls="primary-navigation"
          onClick={() => setOpen((prev) => !prev)}
        >
          {open ? 'Close' : 'Menu'}
        </button>
        <nav id="primary-navigation">
          <div className={`nav-links ${open ? 'open' : ''}`}>
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
                end={item.path === '/'}
                onClick={closeMenu}
              >
                {item.label}
              </NavLink>
            ))}
            <LanguageToggle />
            <Button
              to="/course"
              variant="primary"
              onClick={closeMenu}
              aria-label={language === 'es' ? 'Ver curso' : 'View course'}
            >
              {language === 'es' ? 'Inscribite' : 'Enroll now'}
            </Button>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;