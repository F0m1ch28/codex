import React from 'react';

const Section = ({ id, title, subtitle, eyebrow, children, background = 'contrast' }) => {
  return (
    <section id={id} className={`section section--${background}`}>
      <div className="section-inner">
        {(title || subtitle || eyebrow) && (
          <header className="section-header">
            {eyebrow && <p className="section-eyebrow">{eyebrow}</p>}
            {title && <h2>{title}</h2>}
            {subtitle && <p className="section-subtitle">{subtitle}</p>}
          </header>
        )}
        {children}
      </div>
    </section>
  );
};

export default Section;