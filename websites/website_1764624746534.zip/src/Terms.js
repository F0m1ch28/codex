import React, { useContext } from 'react';
import { Helmet } from 'react-helmet-async';
import { LanguageContext } from './LanguageContext';
import { policyContent } from './translations';
import PolicyTemplate from './PolicyTemplate';

const Terms = () => {
  const { language } = useContext(LanguageContext);
  const content = policyContent.terms[language];

  return (
    <>
      <Helmet>
        <title>{language === 'es' ? 'Tu Progreso Hoy | Términos del Servicio' : 'Tu Progreso Hoy | Terms of Service'}</title>
      </Helmet>
      <PolicyTemplate content={content} />
    </>
  );
};

export default Terms;