import React from 'react';
import Section from './Section';

const PolicyTemplate = ({ content }) => {
  return (
    <div className="policy-page">
      <Section title={content.title} subtitle={content.updated}>
        <p>{content.intro}</p>
        {content.sections.map((section) => (
          <article className="policy-section" key={section.heading}>
            <h3>{section.heading}</h3>
            {section.paragraphs.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </article>
        ))}
      </Section>
    </div>
  );
};

export default PolicyTemplate;