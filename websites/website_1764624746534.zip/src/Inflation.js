import React, { useContext } from 'react';
import { Helmet } from 'react-helmet-async';
import { Line } from 'react-chartjs-2';
import Section from './Section';
import Card from './Card';
import Accordion from './Accordion';
import { LanguageContext } from './LanguageContext';
import { inflationContent } from './translations';

const months = [
  'Jun 2023',
  'Jul 2023',
  'Aug 2023',
  'Sep 2023',
  'Oct 2023',
  'Nov 2023',
  'Dec 2023',
  'Jan 2024',
  'Feb 2024',
  'Mar 2024',
  'Apr 2024',
  'May 2024'
];

const cpiSeries = [6.4, 7.3, 12.4, 12.7, 8.3, 12.5, 25.5, 20.6, 13.2, 11.3, 8.8, 7.9];
const officialFx = [1.4, 1.6, 1.9, 2.4, 2.1, 2.3, 4.8, 2.7, 2.2, 2.0, 1.7, 1.5];
const marketFx = [2.8, 3.1, 5.4, 6.2, 6.9, 8.5, 15.2, 12.7, 9.4, 8.6, 7.1, 6.5];

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom'
    },
    tooltip: {
      callbacks: {
        label: (context) => `${context.dataset.label}: ${context.parsed.y}%`
      }
    }
  },
  scales: {
    y: {
      title: {
        display: true,
        text: 'Monthly % change'
      },
      ticks: {
        callback: (value) => `${value}%`
      }
    }
  }
};

const Inflation = () => {
  const { language } = useContext(LanguageContext);
  const content = inflationContent[language];

  const chartData = {
    labels: months,
    datasets: [
      {
        label: language === 'es' ? 'IPC consolidado' : 'Consolidated CPI',
        data: cpiSeries,
        borderColor: '#2563EB',
        backgroundColor: 'rgba(37, 99, 235, 0.12)',
        borderWidth: 3,
        tension: 0.35,
        pointRadius: 4
      },
      {
        label: language === 'es' ? 'FX oficial' : 'Official FX',
        data: officialFx,
        borderColor: '#38BDF8',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        borderDash: [6, 4],
        borderWidth: 3,
        tension: 0.25,
        pointRadius: 3
      },
      {
        label: language === 'es' ? 'FX alternativo' : 'Market FX',
        data: marketFx,
        borderColor: '#0F172A',
        backgroundColor: 'rgba(15, 23, 42, 0.12)',
        borderWidth: 2,
        tension: 0.2,
        pointRadius: 3
      }
    ]
  };

  return (
    <>
      <Helmet>
        <title>{language === 'es' ? 'Tu Progreso Hoy | Metodología de inflación' : 'Tu Progreso Hoy | Inflation Methodology'}</title>
        <meta
          name="description"
          content={
            language === 'es'
              ? 'Explorá la metodología de Tu Progreso Hoy para combinar datos de inflación y FX en Argentina.'
              : 'Explore Tu Progreso Hoy methodology for combining inflation and FX data in Argentina.'
          }
        />
      </Helmet>

      <Section title={content.heroTitle} subtitle={content.intro} eyebrow={language === 'es' ? 'Metodología' : 'Methodology'}>
        <div className="cards-grid">
          {content.steps.map((step) => (
            <Card key={step.title} title={step.title}>
              <p>{step.description}</p>
            </Card>
          ))}
        </div>
      </Section>

      <Section title={content.chartSection.title} subtitle={content.chartSection.subtitle} background="muted">
        <div className="chart-box" style={{ minHeight: '360px' }}>
          <Line data={chartData} options={chartOptions} />
        </div>
        <p style={{ marginTop: '1rem', fontSize: '0.85rem', color: 'rgba(15, 23, 42, 0.75)' }}>
          {content.chartSection.note}
        </p>
      </Section>

      <Section title={language === 'es' ? 'Contexto y aplicación' : 'Context and application'}>
        <div className="cards-grid">
          {content.contextBlocks.map((block) => (
            <Card key={block.title} title={block.title}>
              <p>{block.body}</p>
            </Card>
          ))}
        </div>
      </Section>

      <Section title={content.faqTitle} background="contrast">
        <Accordion items={content.faqItems} />
      </Section>
    </>
  );
};

export default Inflation;