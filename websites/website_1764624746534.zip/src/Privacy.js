import React, { useContext } from 'react';
import { Helmet } from 'react-helmet-async';
import { LanguageContext } from './LanguageContext';
import { policyContent } from './translations';
import PolicyTemplate from './PolicyTemplate';

const Privacy = () => {
  const { language } = useContext(LanguageContext);
  const content = policyContent.privacy[language];

  return (
    <>
      <Helmet>
        <title>{language === 'es' ? 'Tu Progreso Hoy | Política de Privacidad' : 'Tu Progreso Hoy | Privacy Policy'}</title>
      </Helmet>
      <PolicyTemplate content={content} />
    </>
  );
};

export default Privacy;