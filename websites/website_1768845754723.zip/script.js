document.addEventListener('DOMContentLoaded', function () {
  var navToggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('primary-navigation');
  if (nav && navToggle) {
    navToggle.addEventListener('click', function () {
      var expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
      if (!expanded) {
        nav.classList.add('is-visible');
      } else {
        nav.classList.remove('is-visible');
      }
    });
  }

  var cookieBanner = document.querySelector('[data-cookie-banner]');
  if (cookieBanner) {
    var consent = localStorage.getItem('eliteTattooCookieConsent');
    if (!consent) {
      cookieBanner.classList.add('is-active');
    }
    var acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
    var declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
    var hideBanner = function (choice) {
      localStorage.setItem('eliteTattooCookieConsent', choice);
      cookieBanner.classList.remove('is-active');
      cookieBanner.classList.add('is-hidden');
    };
    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        hideBanner('accepted');
      });
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', function () {
        hideBanner('declined');
      });
    }
  }
});