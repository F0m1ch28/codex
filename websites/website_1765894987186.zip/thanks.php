<?php
function sanitize_field($key) {
    return htmlspecialchars(trim($_POST[$key] ?? ''), ENT_QUOTES, 'UTF-8');
}
$name = sanitize_field('contact-name');
$email = sanitize_field('contact-email');
$phone = sanitize_field('contact-phone');
$role = sanitize_field('contact-role');
$organization = sanitize_field('contact-organization');
$focus = sanitize_field('contact-focus');
$message = sanitize_field('contact-message');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You | Maple Hydro Control Canada</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Maple Hydro Control Canada has received your message. Our hydro specialists will respond promptly.">
  <meta property="og:title" content="Thank You for Contacting Maple Hydro Control Canada">
  <meta property="og:description" content="Our hydro specialists will respond to your request shortly.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.maplehydrocontrol.ca/thanks.php">
  <meta property="og:image" content="https://picsum.photos/seed/maplehydrothanks/1200/630">
  <link rel="canonical" href="https://www.maplehydrocontrol.ca/thanks.php">
  <link rel="icon" href="favicon.png" type="image/png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <a class="skip-link" href="#maincontent">Skip to content</a>
  <header class="site-header">
    <div class="header-inner">
      <a class="branding" href="index.html">
        <img src="https://picsum.photos/seed/maplehydrologo/96/96" alt="Maple Hydro Control Canada logo">
        <span>Maple Hydro Control Canada</span>
      </a>
      <button class="menu-toggle" aria-expanded="false" aria-controls="primary-navigation">Menu</button>
      <nav class="primary-nav" id="primary-navigation" aria-label="Primary navigation">
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="about.html">About</a></li>
          <li><a href="solutions.html">Solutions</a></li>
          <li><a href="technology.html">Technology</a></li>
          <li><a href="performance.html">Performance</a></li>
          <li><a href="projects.html">Projects</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </nav>
      <a class="header-cta" href="contact.php">Request Evaluation</a>
    </div>
  </header>
  <main id="maincontent">
    <section class="page-hero">
      <div class="container hero-content">
        <h1>Thank You for Reaching Out</h1>
        <p>Our hydro specialists have received your message and will respond shortly.</p>
      </div>
    </section>
    <section class="section light">
      <div class="container">
        <div class="callout">
          <h3>Summary of Your Request</h3>
          <p><strong>Name:</strong> <?php echo $name ?: 'Not provided'; ?></p>
          <p><strong>Email:</strong> <?php echo $email ?: 'Not provided'; ?></p>
          <p><strong>Phone:</strong> <?php echo $phone ?: 'Not provided'; ?></p>
          <p><strong>Role:</strong> <?php echo $role ?: 'Not provided'; ?></p>
          <p><strong>Organization:</strong> <?php echo $organization ?: 'Not provided'; ?></p>
          <p><strong>Operational Focus:</strong> <?php echo $focus ?: 'Not provided'; ?></p>
          <p><strong>Message:</strong> <?php echo $message ?: 'No additional details submitted.'; ?></p>
          <div class="button-group">
            <a class="btn btn-secondary" href="index.html">Return to Homepage</a>
            <a class="btn btn-primary" href="solutions.html">Explore Our Solutions</a>
          </div>
        </div>
      </div>
    </section>
  </main>
  <footer>
    <div class="footer-inner">
      <div class="footer-brand">
        <img src="https://picsum.photos/seed/maplehydrofooter/120/120" alt="Maple Hydro Control emblem">
        <p>Intelligent hydro control solutions engineered for Canada’s evolving energy systems.</p>
      </div>
      <nav class="footer-nav" aria-label="Footer navigation">
        <a href="index.html">Home</a>
        <a href="about.html">About</a>
        <a href="solutions.html">Solutions</a>
        <a href="technology.html">Technology</a>
        <a href="performance.html">Performance</a>
        <a href="projects.html">Projects</a>
        <a href="contact.php">Contact</a>
      </nav>
      <div class="footer-contact">
        <strong>Contact</strong>
        <span>Hydro Place, 500 Columbus Drive<br>St. John’s, NL A1B 0C9, Canada</span>
        <a href="tel:+17095553842">+1 709 555 3842</a>
        <a href="mailto:info@maplehydrocontrol.ca">info@maplehydrocontrol.ca</a>
      </div>
      <div class="footer-legal">
        <strong>Information</strong>
        <a href="privacy.html">Privacy Policy</a>
        <a href="cookies.html">Cookies</a>
        <a href="terms.html">Terms of Use</a>
        <a href="sitemap.xml">Sitemap</a>
      </div>
    </div>
    <div class="footer-bottom">
      © <span id="current-year">2024</span> Maple Hydro Control Canada. All rights reserved.
    </div>
  </footer>
  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie consent banner">
    <h2>Cookies and Performance Metrics</h2>
    <p>We use cookies to enhance hydro analytics and improve user experience. Review our <a href="cookies.html">cookie guidance</a> and choose your preference.</p>
    <div class="cookie-actions">
      <button class="btn-accept" type="button">Accept</button>
      <button class="btn-decline" type="button">Decline</button>
    </div>
  </div>
  <script src="script.js" defer></script>
  <script>
    document.getElementById("current-year").textContent = new Date().getFullYear();
  </script>
</body>
</html>