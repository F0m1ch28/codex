document.addEventListener("DOMContentLoaded", () => {
  const nav = document.querySelector(".primary-nav");
  const toggle = document.querySelector(".menu-toggle");
  const cookieBanner = document.querySelector(".cookie-banner");
  const consentKey = "maple-hydro-cookie-consent";

  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      nav.classList.toggle("active");
      toggle.setAttribute("aria-expanded", nav.classList.contains("active"));
    });
  }

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      cookieBanner.classList.add("active");
    }

    cookieBanner.addEventListener("click", (event) => {
      if (event.target.matches(".btn-accept")) {
        localStorage.setItem(consentKey, "accepted");
        cookieBanner.classList.remove("active");
      }

      if (event.target.matches(".btn-decline")) {
        localStorage.setItem(consentKey, "declined");
        cookieBanner.classList.remove("active");
      }
    });
  }
});