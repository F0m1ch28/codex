<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Maple Hydro Control Canada | Request Hydro Evaluation</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Contact Maple Hydro Control Canada for hydro monitoring consultations. Request hydro evaluation, connect with experts, and find our address, phone, and map.">
  <meta property="og:title" content="Contact Maple Hydro Control Canada">
  <meta property="og:description" content="Request hydro evaluation and connect with Maple Hydro Control Canada’s specialists.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.maplehydrocontrol.ca/contact.php">
  <meta property="og:image" content="https://picsum.photos/seed/maplehydrocontact/1200/630">
  <link rel="canonical" href="https://www.maplehydrocontrol.ca/contact.php">
  <link rel="icon" href="favicon.png" type="image/png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <a class="skip-link" href="#maincontent">Skip to content</a>
  <header class="site-header">
    <div class="header-inner">
      <a class="branding" href="index.html">
        <img src="https://picsum.photos/seed/maplehydrologo/96/96" alt="Maple Hydro Control Canada logo">
        <span>Maple Hydro Control Canada</span>
      </a>
      <button class="menu-toggle" aria-expanded="false" aria-controls="primary-navigation">Menu</button>
      <nav class="primary-nav" id="primary-navigation" aria-label="Primary navigation">
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="about.html">About</a></li>
          <li><a href="solutions.html">Solutions</a></li>
          <li><a href="technology.html">Technology</a></li>
          <li><a href="performance.html">Performance</a></li>
          <li><a href="projects.html">Projects</a></li>
          <li><a href="contact.php" aria-current="page">Contact</a></li>
        </ul>
      </nav>
      <a class="header-cta" href="contact.php">Request Evaluation</a>
    </div>
  </header>
  <main id="maincontent">
    <section class="page-hero">
      <div class="container hero-content">
        <h1>Contact Maple Hydro Control Canada</h1>
        <p>Plan a consultation with our hydro specialists. We’ll align monitoring, analytics, and remote supervision strategies with your operational objectives.</p>
      </div>
    </section>
    <section class="section light">
      <div class="container">
        <div class="split-layout">
          <div>
            <h2>Request Hydro Evaluation</h2>
            <form class="form-grid" action="thanks.php" method="post">
              <div class="form-grid-columns">
                <div class="form-field">
                  <label for="contact-name">Full name</label>
                  <input id="contact-name" name="contact-name" type="text" required autocomplete="name">
                </div>
                <div class="form-field">
                  <label for="contact-email">Email address</label>
                  <input id="contact-email" name="contact-email" type="email" required autocomplete="email">
                </div>
              </div>
              <div class="form-grid-columns">
                <div class="form-field">
                  <label for="contact-phone">Phone</label>
                  <input id="contact-phone" name="contact-phone" type="tel" autocomplete="tel">
                </div>
                <div class="form-field">
                  <label for="contact-role">Role</label>
                  <input id="contact-role" name="contact-role" type="text" placeholder="Operations Director">
                </div>
              </div>
              <div class="form-field">
                <label for="contact-organization">Organization</label>
                <input id="contact-organization" name="contact-organization" type="text" required>
              </div>
              <div class="form-field">
                <label for="contact-focus">Primary operational focus</label>
                <select id="contact-focus" name="contact-focus" required>
                  <option value="">Select focus</option>
                  <option value="Monitoring modernization">Monitoring modernization</option>
                  <option value="Predictive maintenance">Predictive maintenance</option>
                  <option value="Remote supervision">Remote supervision</option>
                  <option value="Climate resilience">Climate resilience</option>
                  <option value="Performance reporting">Performance reporting</option>
                </select>
              </div>
              <div class="form-field">
                <label for="contact-message">How can we support your hydro facilities?</label>
                <textarea id="contact-message" name="contact-message"></textarea>
              </div>
              <button class="btn btn-primary" type="submit">Submit Request</button>
            </form>
          </div>
          <div>
            <div class="contact-details">
              <strong>Direct Contact</strong>
              <span>Hydro Place, 500 Columbus Drive<br>St. John’s, NL A1B 0C9, Canada</span>
              <a href="tel:+17095553842">+1 709 555 3842</a>
              <a href="mailto:info@maplehydrocontrol.ca">info@maplehydrocontrol.ca</a>
              <p>Our technical coordination desk responds within one business day.</p>
            </div>
            <div class="map-embed" aria-label="Map showing Maple Hydro Control Canada location">
              <iframe title="Maple Hydro Control Canada location" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1324.373046269006!2d-52.7054823!3d47.5675282!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDfCsDM0JzAzLjEiTiA1MsKwNDInMTkuNyJX!5e0!3m2!1sen!2sca!4v1700000000000"></iframe>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <footer>
    <div class="footer-inner">
      <div class="footer-brand">
        <img src="https://picsum.photos/seed/maplehydrofooter/120/120" alt="Maple Hydro Control emblem">
        <p>Intelligent hydro control solutions engineered for Canada’s evolving energy systems.</p>
      </div>
      <nav class="footer-nav" aria-label="Footer navigation">
        <a href="index.html">Home</a>
        <a href="about.html">About</a>
        <a href="solutions.html">Solutions</a>
        <a href="technology.html">Technology</a>
        <a href="performance.html">Performance</a>
        <a href="projects.html">Projects</a>
        <a href="contact.php" aria-current="page">Contact</a>
      </nav>
      <div class="footer-contact">
        <strong>Contact</strong>
        <span>Hydro Place, 500 Columbus Drive<br>St. John’s, NL A1B 0C9, Canada</span>
        <a href="tel:+17095553842">+1 709 555 3842</a>
        <a href="mailto:info@maplehydrocontrol.ca">info@maplehydrocontrol.ca</a>
      </div>
      <div class="footer-legal">
        <strong>Information</strong>
        <a href="privacy.html">Privacy Policy</a>
        <a href="cookies.html">Cookies</a>
        <a href="terms.html">Terms of Use</a>
        <a href="sitemap.xml">Sitemap</a>
      </div>
    </div>
    <div class="footer-bottom">
      © <span id="current-year">2024</span> Maple Hydro Control Canada. All rights reserved.
    </div>
  </footer>
  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie consent banner">
    <h2>Cookies and Performance Metrics</h2>
    <p>We use cookies to enhance hydro analytics and improve user experience. Review our <a href="cookies.html">cookie guidance</a> and choose your preference.</p>
    <div class="cookie-actions">
      <button class="btn-accept" type="button">Accept</button>
      <button class="btn-decline" type="button">Decline</button>
    </div>
  </div>
  <script src="script.js" defer></script>
  <script>
    document.getElementById("current-year").textContent = new Date().getFullYear();
  </script>
</body>
</html>