document.addEventListener("DOMContentLoaded", () => {
    const header = document.querySelector(".site-header");
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");
    const storageKey = "wnzxs-cookie-consent";
    const cookieBanner = document.getElementById("cookie-banner");
    const acceptBtn = document.getElementById("cookie-accept");
    const declineBtn = document.getElementById("cookie-decline");

    function handleScroll() {
        if (!header) return;
        if (window.scrollY > 20) {
            header.classList.add("is-scrolled");
        } else {
            header.classList.remove("is-scrolled");
        }
    }

    window.addEventListener("scroll", handleScroll);
    handleScroll();

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            const isExpanded = navToggle.classList.toggle("is-open");
            navToggle.setAttribute("aria-expanded", String(isExpanded));
            navLinks.classList.toggle("is-open");
        });

        navLinks.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                navLinks.classList.remove("is-open");
                navToggle.classList.remove("is-open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    function hideCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.add("is-hidden");
            cookieBanner.setAttribute("aria-hidden", "true");
        }
    }

    const savedConsent = localStorage.getItem(storageKey);
    if (savedConsent) {
        hideCookieBanner();
    }

    if (acceptBtn && declineBtn && cookieBanner) {
        acceptBtn.addEventListener("click", () => {
            localStorage.setItem(storageKey, "accepted");
            hideCookieBanner();
        });

        declineBtn.addEventListener("click", () => {
            localStorage.setItem(storageKey, "declined");
            hideCookieBanner();
        });
    }
});