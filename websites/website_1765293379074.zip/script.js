document.addEventListener("DOMContentLoaded", () => {
  const banner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".cookie-accept");
  const declineBtn = document.querySelector(".cookie-decline");
  const storageKey = "pb.cookies.preference";

  const setPreference = (value) => {
    localStorage.setItem(storageKey, value);
    banner.setAttribute("aria-hidden", "true");
  };

  if (!localStorage.getItem(storageKey)) {
    banner.setAttribute("aria-hidden", "false");
  }

  acceptBtn.addEventListener("click", () => setPreference("accepted"));
  declineBtn.addEventListener("click", () => setPreference("declined"));
});