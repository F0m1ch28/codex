import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => (
  <div className={styles.home}>
    <Helmet>
      <title>TechSolutions Inc. | Cloud & Digital Transformation Experts</title>
      <meta
        name="description"
        content="TechSolutions Inc. delivers cloud solutions, DevOps consulting, cybersecurity, and data analytics that accelerate digital transformation and business optimization."
      />
      <meta
        name="keywords"
        content="cloud solutions, digital transformation, IT consulting, DevOps consulting, cybersecurity, data analytics, business optimization"
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <span className={styles.tagline}>Cloud-first IT Consulting</span>
        <h1>Strategic Cloud Solutions for Ambitious Enterprises</h1>
        <p>
          TechSolutions Inc. empowers organizations to modernize operations, unlock data intelligence,
          and accelerate innovation through full-spectrum digital transformation services.
        </p>
        <div className={styles.heroActions}>
          <Link to="/contact" className={styles.ctaPrimary}>Schedule a Consultation</Link>
          <Link to="/services" className={styles.ctaSecondary}>Explore Services</Link>
        </div>
      </div>
      <div className={styles.heroMedia}>
        <img
          src="https://picsum.photos/600/420?technology"
          alt="Digital transformation team collaboration"
          loading="lazy"
        />
      </div>
    </section>

    <section className={styles.metrics}>
      <article>
        <h3>250+</h3>
        <p>Successful cloud migrations completed without operational disruption.</p>
      </article>
      <article>
        <h3>98%</h3>
        <p>Client satisfaction rate driven by measurable business outcomes.</p>
      </article>
      <article>
        <h3>30%</h3>
        <p>Average increase in operational efficiency across transformation programs.</p>
      </article>
    </section>

    <section className={styles.services}>
      <header>
        <h2>Holistic Services Tailored to Your Transformation Journey</h2>
        <p>
          Align strategy, technology, and teams with our integrated consulting practice rooted in cloud excellence and secure delivery.
        </p>
      </header>
      <div className={styles.serviceGrid}>
        <article>
          <div className={styles.icon}>☁️</div>
          <h3>Cloud Architecture & Migration</h3>
          <p>
            Design resilient cloud architectures, orchestrate migrations, and optimize workloads for unmatched scalability.
          </p>
          <Link to="/services">Learn more</Link>
        </article>
        <article>
          <div className={styles.icon}>⚙️</div>
          <h3>DevOps Enablement</h3>
          <p>
            Accelerate release cycles with automated pipelines, observability, and culture change programs.
          </p>
          <Link to="/services">Learn more</Link>
        </article>
        <article>
          <div className={styles.icon}>🛡️</div>
          <h3>Cybersecurity Strategy</h3>
          <p>
            Safeguard assets with cloud-native security frameworks, zero-trust adoption, and managed detection.
          </p>
          <Link to="/services">Learn more</Link>
        </article>
        <article>
          <div className={styles.icon}>📊</div>
          <h3>Data & Analytics</h3>
          <p>
            Unlock insights with modern data platforms, AI-ready pipelines, and actionable dashboards.
          </p>
          <Link to="/services">Learn more</Link>
        </article>
      </div>
    </section>

    <section className={styles.about}>
      <div className={styles.aboutMedia}>
        <img
          src="https://picsum.photos/540/360?cloud"
          alt="TechSolutions Inc. consultants designing cloud strategy"
          loading="lazy"
        />
      </div>
      <div className={styles.aboutContent}>
        <h2>Experience that Champions Your Vision</h2>
        <p>
          For over a decade, TechSolutions Inc. has partnered with global enterprises to redefine operations through cloud-first strategies and sustainable innovation. Our cross-functional experts bring deep domain knowledge, proven frameworks, and a relentless focus on business outcomes.
        </p>
        <ul>
          <li>Certified architects across AWS, Azure, and Google Cloud</li>
          <li>Design thinking workshops to align stakeholders and roadmap value</li>
          <li>Continuous improvement programs that embed resilience and agility</li>
        </ul>
        <Link to="/about" className={styles.ctaLink}>Discover our story</Link>
      </div>
    </section>

    <section className={styles.testimonial}>
      <blockquote>
        “TechSolutions Inc. guided our global cloud adoption with precision. Their team delivered a secure, scalable platform that now powers our digital business at speed.”
      </blockquote>
      <cite>— Sophia Martinez, CIO, Global Retail Innovators</cite>
    </section>

    <section className={styles.ctaBanner}>
      <div>
        <h2>Let’s architect the next chapter of your digital business.</h2>
        <p>Connect with our consultants to design a transformation journey tailored to your goals.</p>
      </div>
      <Link to="/contact" className={styles.ctaPrimary}>Get in touch</Link>
    </section>
  </div>
);

export default Home;