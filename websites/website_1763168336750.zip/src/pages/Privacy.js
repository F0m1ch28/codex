import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Policy | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Read the TechSolutions Inc. Privacy Policy to understand how we collect, use, and protect your personal information."
      />
      <meta
        name="keywords"
        content="privacy policy, TechSolutions Inc privacy, data protection, personal information"
      />
    </Helmet>

    <h1>Privacy Policy</h1>
    <p>Effective date: January 1, 2024</p>

    <section>
      <h2>1. Overview</h2>
      <p>
        TechSolutions Inc. (“we”, “our”, “us”) is committed to protecting your privacy. This Privacy Policy describes how we collect, use, and safeguard personal information when you engage with our website, products, and services.
      </p>
    </section>

    <section>
      <h2>2. Information We Collect</h2>
      <ul>
        <li><strong>Contact Information:</strong> Name, email address, company details, and phone number provided via our contact forms.</li>
        <li><strong>Usage Data:</strong> Analytics regarding interactions with our website including pages viewed, time spent, and referring sources.</li>
        <li><strong>Technical Data:</strong> IP address, browser type, device identifiers, and operating system information collected through cookies and similar technologies.</li>
      </ul>
    </section>

    <section>
      <h2>3. How We Use Information</h2>
      <ul>
        <li>Responding to inquiries and providing requested information.</li>
        <li>Delivering, maintaining, and improving our services.</li>
        <li>Conducting analytics to enhance user experience and optimize content.</li>
        <li>Ensuring compliance with legal and regulatory obligations.</li>
      </ul>
    </section>

    <section>
      <h2>4. Sharing of Information</h2>
      <p>
        We may share personal information with trusted service providers who assist with operations such as analytics, hosting, and communications. These providers are contractually obligated to protect your data and use it only for the services we request. We may also disclose information when required by law or to protect our legal rights.
      </p>
    </section>

    <section>
      <h2>5. Cookies & Tracking Technologies</h2>
      <p>
        We use cookies, web beacons, and similar technologies to understand usage patterns, personalize content, and improve performance. You can manage cookie preferences through your browser settings or our Cookie Policy.
      </p>
    </section>

    <section>
      <h2>6. Data Retention</h2>
      <p>
        We retain personal information for as long as necessary to fulfill the purposes outlined in this policy, comply with legal obligations, resolve disputes, and enforce agreements.
      </p>
    </section>

    <section>
      <h2>7. Security</h2>
      <p>
        We implement administrative, technical, and physical safeguards designed to protect personal information against unauthorized access, disclosure, alteration, or destruction.
      </p>
    </section>

    <section>
      <h2>8. Your Rights</h2>
      <p>
        Depending on your jurisdiction, you may have rights to access, correct, or delete personal information, as well as the right to restrict or object to certain processing. To exercise these rights, contact us at <a href="mailto:info@techsolutions-inc.com">info@techsolutions-inc.com</a>.
      </p>
    </section>

    <section>
      <h2>9. International Transfers</h2>
      <p>
        If you access our services from outside the United States, you acknowledge that your information may be processed in the United States where data protection laws may differ.
      </p>
    </section>

    <section>
      <h2>10. Updates</h2>
      <p>
        We may update this Privacy Policy periodically. We will post the revised version on our website with the updated effective date.
      </p>
    </section>

    <section>
      <h2>11. Contact</h2>
      <p>
        For questions or concerns about this Privacy Policy, please contact us at:
      </p>
      <address>
        TechSolutions Inc.<br />
        123 Innovation Drive, Tech Park, San Francisco, CA 94105<br />
        Phone: +1 (555) 123-4567<br />
        Email: <a href="mailto:info@techsolutions-inc.com">info@techsolutions-inc.com</a>
      </address>
    </section>
  </div>
);

export default Privacy;