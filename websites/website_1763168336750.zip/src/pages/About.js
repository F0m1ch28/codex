import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <div className={styles.page}>
    <Helmet>
      <title>About TechSolutions Inc.</title>
      <meta
        name="description"
        content="Discover TechSolutions Inc.—our mission, leadership team, and the story behind our success in delivering cloud and digital transformation."
      />
      <meta
        name="keywords"
        content="TechSolutions Inc, mission, leadership team, IT consulting history, digital transformation expertise"
      />
    </Helmet>

    <section className={styles.hero}>
      <div>
        <h1>We build resilient digital futures together.</h1>
        <p>
          TechSolutions Inc. is an IT consulting firm focused on guiding enterprises through cloud adoption,
          operational modernization, and data-driven innovation. We believe that technology is only successful
          when people, processes, and platforms are aligned.
        </p>
      </div>
      <img
        src="https://picsum.photos/620/420?team"
        alt="TechSolutions Inc. team collaborating on strategy"
        loading="lazy"
      />
    </section>

    <section className={styles.values}>
      <h2>Mission & Core Values</h2>
      <div className={styles.valuesGrid}>
        <article>
          <h3>Mission</h3>
          <p>
            Our mission is to empower organizations to innovate with velocity, operate with intelligence, and compete with confidence through the power of cloud technology and digital transformation.
          </p>
        </article>
        <article>
          <h3>Vision</h3>
          <p>
            We envision a future in which enterprises thrive on agile platforms, collaborating seamlessly across ecosystems, and delivering exceptional experiences to customers everywhere.
          </p>
        </article>
        <article>
          <h3>Values</h3>
          <ul>
            <li>Client partnership over short-term engagements</li>
            <li>Integrity and transparency in every decision</li>
            <li>Inclusive innovation powered by diverse teams</li>
            <li>Continuous improvement and measurable impact</li>
          </ul>
        </article>
      </div>
    </section>

    <section className={styles.timeline}>
      <h2>Our Journey</h2>
      <div className={styles.milestones}>
        <div>
          <span>2012</span>
          <p>TechSolutions Inc. is founded in San Francisco with a focus on cloud-native strategy consulting.</p>
        </div>
        <div>
          <span>2015</span>
          <p>Launches DevOps enablement practice and partners with leading cloud providers for joint initiatives.</p>
        </div>
        <div>
          <span>2018</span>
          <p>Expands portfolio to include cybersecurity and managed detection services for global clients.</p>
        </div>
        <div>
          <span>2022</span>
          <p>Recognized as a top digital transformation partner delivering measurable ROI across industries.</p>
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <h2>Leadership</h2>
      <div className={styles.teamGrid}>
        <article>
          <img
            src="https://picsum.photos/320/320?person1"
            alt="CEO of TechSolutions Inc."
            loading="lazy"
          />
          <h3>Elena Ramirez</h3>
          <p className={styles.role}>Chief Executive Officer</p>
          <p>
            Elena champions strategic partnerships and continuous innovation, guiding clients through transformational change with empathy and clarity.
          </p>
        </article>
        <article>
          <img
            src="https://picsum.photos/320/320?person2"
            alt="CTO of TechSolutions Inc."
            loading="lazy"
          />
          <h3>Marcus Chen</h3>
          <p className={styles.role}>Chief Technology Officer</p>
          <p>
            Marcus leads our architecture and engineering teams, ensuring cloud platforms are designed for scale, security, and resilience.
          </p>
        </article>
        <article>
          <img
            src="https://picsum.photos/320/320?person3"
            alt="COO of TechSolutions Inc."
            loading="lazy"
          />
          <h3>Priya Patel</h3>
          <p className={styles.role}>Chief Operating Officer</p>
          <p>
            Priya drives operational excellence, delivering programs that elevate customer experience and empower high-performing teams.
          </p>
        </article>
      </div>
    </section>
  </div>
);

export default About;