import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookie Policy | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Learn how TechSolutions Inc. uses cookies and similar technologies to improve website performance and user experience."
      />
      <meta
        name="keywords"
        content="cookie policy, TechSolutions Inc cookies, tracking technologies"
      />
    </Helmet>

    <h1>Cookie Policy</h1>
    <p>Effective date: January 1, 2024</p>

    <section>
      <h2>1. What Are Cookies?</h2>
      <p>
        Cookies are small text files stored on your device when you visit a website. They help us remember your preferences, analyze site performance, and deliver relevant content.
      </p>
    </section>

    <section>
      <h2>2. Types of Cookies We Use</h2>
      <ul>
        <li><strong>Essential Cookies:</strong> Required for core functionality such as security and accessibility.</li>
        <li><strong>Performance Cookies:</strong> Collect data on how users interact with the site to help us improve usability.</li>
        <li><strong>Functional Cookies:</strong> Remember your preferences to provide a more personalized experience.</li>
        <li><strong>Analytics Cookies:</strong> Help us understand traffic sources and user behavior for continuous optimization.</li>
      </ul>
    </section>

    <section>
      <h2>3. Managing Cookies</h2>
      <p>
        You can manage or disable cookies through your browser settings. Note that disabling essential cookies may impact site functionality. You can also update your preferences using the cookie banner controls.
      </p>
    </section>

    <section>
      <h2>4. Third-Party Technologies</h2>
      <p>
        We may use third-party analytics providers that set their own cookies to help us understand usage trends. These providers are subject to their own privacy policies.
      </p>
    </section>

    <section>
      <h2>5. Updates</h2>
      <p>
        We may update this Cookie Policy to reflect changes in technology or regulations. Any updates will be posted on this page with a revised effective date.
      </p>
    </section>

    <section>
      <h2>6. Contact</h2>
      <p>
        For questions about this Cookie Policy, please contact:
      </p>
      <address>
        TechSolutions Inc.<br />
        123 Innovation Drive, Tech Park, San Francisco, CA 94105<br />
        Phone: +1 (555) 123-4567<br />
        Email: <a href="mailto:info@techsolutions-inc.com">info@techsolutions-inc.com</a>
      </address>
    </section>
  </div>
);

export default CookiePolicy;