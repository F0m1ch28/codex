import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms of Service | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Review the TechSolutions Inc. Terms of Service outlining the conditions for using our website and consulting services."
      />
      <meta
        name="keywords"
        content="terms of service, TechSolutions Inc terms, consulting agreement, service terms"
      />
    </Helmet>

    <h1>Terms of Service</h1>
    <p>Effective date: January 1, 2024</p>

    <section>
      <h2>1. Acceptance of Terms</h2>
      <p>
        By accessing or using the TechSolutions Inc. website, content, or services, you agree to be bound by these Terms of Service. If you do not agree, you must discontinue use immediately.
      </p>
    </section>

    <section>
      <h2>2. Services</h2>
      <p>
        TechSolutions Inc. provides IT consulting services focusing on cloud adoption, digital transformation, and related solutions. Specific terms of engagement will be outlined in separate agreements executed with clients.
      </p>
    </section>

    <section>
      <h2>3. Intellectual Property</h2>
      <p>
        All content, trademarks, and materials available on our website are the intellectual property of TechSolutions Inc. or its licensors. Unauthorized use, reproduction, or distribution is prohibited.
      </p>
    </section>

    <section>
      <h2>4. User Responsibilities</h2>
      <ul>
        <li>Provide accurate information when submitting inquiries or engaging with us.</li>
        <li>Use the website in compliance with applicable laws and regulations.</li>
        <li>Refrain from engaging in activities that disrupt or harm the website or associated systems.</li>
      </ul>
    </section>

    <section>
      <h2>5. Disclaimer</h2>
      <p>
        The website and its content are provided “as is” without warranties of any kind. TechSolutions Inc. disclaims all warranties, express or implied, including fitness for a particular purpose and non-infringement.
      </p>
    </section>

    <section>
      <h2>6. Limitation of Liability</h2>
      <p>
        To the maximum extent permitted by law, TechSolutions Inc. shall not be liable for any indirect, incidental, consequential, or punitive damages arising from the use of our website or services.
      </p>
    </section>

    <section>
      <h2>7. Indemnification</h2>
      <p>
        You agree to indemnify and hold TechSolutions Inc., its officers, employees, and partners harmless from any claims, damages, or expenses arising from your use of the website or violation of these Terms of Service.
      </p>
    </section>

    <section>
      <h2>8. Governing Law</h2>
      <p>
        These Terms of Service are governed by the laws of the State of California, without regard to conflict of law provisions. Any disputes shall be resolved in the state or federal courts located in San Francisco, California.
      </p>
    </section>

    <section>
      <h2>9. Changes to Terms</h2>
      <p>
        We may update these Terms of Service from time to time. Continued use of our website after changes take effect constitutes acceptance of the revised terms.
      </p>
    </section>

    <section>
      <h2>10. Contact</h2>
      <p>
        For questions about these Terms of Service, please contact us at:
      </p>
      <address>
        TechSolutions Inc.<br />
        123 Innovation Drive, Tech Park, San Francisco, CA 94105<br />
        Phone: +1 (555) 123-4567<br />
        Email: <a href="mailto:info@techsolutions-inc.com">info@techsolutions-inc.com</a>
      </address>
    </section>
  </div>
);

export default Terms;