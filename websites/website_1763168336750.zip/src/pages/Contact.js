import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });

  const [status, setStatus] = React.useState(null);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus('Thank you for reaching out. Our consultants will respond promptly.');
    setFormData({
      name: '',
      email: '',
      company: '',
      message: ''
    });
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact TechSolutions Inc.</title>
        <meta
          name="description"
          content="Contact TechSolutions Inc. for cloud consulting, digital transformation services, and IT strategy support."
        />
        <meta
          name="keywords"
          content="contact TechSolutions Inc, IT consulting contact, cloud consulting inquiry, digital transformation support"
        />
      </Helmet>

      <section className={styles.header}>
        <h1>Partner with TechSolutions Inc.</h1>
        <p>
          Share your objectives and our specialists will tailor a transformation plan that delivers measurable results.
        </p>
      </section>

      <section className={styles.content}>
        <form className={styles.form} onSubmit={handleSubmit}>
          <label>
            Full Name
            <input
              type="text"
              name="name"
              placeholder="Enter your full name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </label>
          <label>
            Business Email
            <input
              type="email"
              name="email"
              placeholder="name@company.com"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </label>
          <label>
            Company
            <input
              type="text"
              name="company"
              placeholder="Company name"
              value={formData.company}
              onChange={handleChange}
              required
            />
          </label>
          <label>
            How can we help?
            <textarea
              name="message"
              rows="5"
              placeholder="Describe your project or challenges"
              value={formData.message}
              onChange={handleChange}
              required
            />
          </label>
          <button type="submit">Submit</button>
          {status && <p className={styles.status}>{status}</p>}
        </form>

        <div className={styles.details}>
          <div className={styles.card}>
            <h2>Contact Information</h2>
            <ul>
              <li><strong>Address:</strong> 123 Innovation Drive, Tech Park, San Francisco, CA 94105</li>
              <li><strong>Phone:</strong> <a href="tel:+15551234567">+1 (555) 123-4567</a></li>
              <li><strong>Email:</strong> <a href="mailto:info@techsolutions-inc.com">info@techsolutions-inc.com</a></li>
            </ul>
          </div>
          <div className={styles.mapWrapper}>
            <iframe
              title="TechSolutions Inc. location"
              src="https://www.google.com/maps?q=123+Innovation+Drive,+San+Francisco,+CA+94105&output=embed"
              loading="lazy"
              allowFullScreen
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;