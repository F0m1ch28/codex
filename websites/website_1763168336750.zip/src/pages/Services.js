import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Services | TechSolutions Inc.</title>
      <meta
        name="description"
        content="Explore TechSolutions Inc. services including cloud migration, DevOps consulting, cybersecurity strategy, and data analytics solutions."
      />
      <meta
        name="keywords"
        content="cloud migration, DevOps consulting, cybersecurity services, data analytics, digital transformation consulting"
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Services that Accelerate Digital Transformation</h1>
      <p>
        From cloud foundations to intelligent analytics, we provide end-to-end consulting that aligns technology platforms with strategic business objectives.
      </p>
    </header>

    <section className={styles.section}>
      <article className={styles.card}>
        <div className={styles.badge}>Cloud Migration & Modernization</div>
        <p>
          Modernize infrastructure with tailored migration playbooks, automated workload assessments, and hybrid cloud strategies. We re-platform legacy systems, build cloud-native architectures, and create governance frameworks that unlock agility while maintaining compliance.
        </p>
        <ul>
          <li>Cloud readiness assessments and TCO modeling</li>
          <li>Landing zone design and workload prioritization</li>
          <li>FinOps and continuous optimization services</li>
        </ul>
      </article>

      <article className={styles.card}>
        <div className={styles.badge}>DevOps Consulting & Automation</div>
        <p>
          Transform delivery pipelines with DevOps coaching, toolchain integration, and continuous delivery frameworks. We orchestrate culture change, automate infrastructure, and establish observability practices that keep teams aligned to value delivery.
        </p>
        <ul>
          <li>CI/CD pipeline design and implementation</li>
          <li>Infrastructure as code using Terraform and CloudFormation</li>
          <li>Site reliability engineering and proactive monitoring</li>
        </ul>
      </article>

      <article className={styles.card}>
        <div className={styles.badge}>Cybersecurity & Compliance</div>
        <p>
          Protect critical assets with adaptive security architectures, zero-trust methodologies, and managed detection capabilities. Our experts embed security into every phase of the transformation lifecycle to safeguard trust and continuity.
        </p>
        <ul>
          <li>Security posture assessments and remediation roadmaps</li>
          <li>Identity, access, and zero-trust architecture</li>
          <li>Managed detection, response, and incident playbooks</li>
        </ul>
      </article>

      <article className={styles.card}>
        <div className={styles.badge}>Data Analytics & AI Enablement</div>
        <p>
          Build data platforms that deliver real-time insights and power AI innovation. We connect data sources, streamline governance, and develop analytics experiences that empower every decision maker.
        </p>
        <ul>
          <li>Modern data warehouse & lakehouse implementation</li>
          <li>Advanced analytics and machine learning activation</li>
          <li>Data governance, cataloging, and literacy programs</li>
        </ul>
      </article>
    </section>

    <section className={styles.process}>
      <div className={styles.processContent}>
        <h2>Our Collaborative Delivery Framework</h2>
        <p>
          Every engagement follows a structured yet adaptable methodology that prioritizes co-creation and measurable outcomes.
        </p>
        <div className={styles.steps}>
          <div>
            <h3>1. Vision & Alignment</h3>
            <p>
              Facilitate strategy workshops, define success metrics, and align stakeholders on a prioritized transformation roadmap.
            </p>
          </div>
          <div>
            <h3>2. Architecture & Build</h3>
            <p>
              Design secure cloud architectures, implement automated delivery platforms, and migrate workloads with minimal disruption.
            </p>
          </div>
          <div>
            <h3>3. Operate & Optimize</h3>
            <p>
              Establish governance, empower teams with enablement programs, and continuously optimize for performance, cost, and resilience.
            </p>
          </div>
        </div>
      </div>
      <div className={styles.processMedia}>
        <img
          src="https://picsum.photos/540/560?business"
          alt="Consulting workshop discussing technology roadmap"
          loading="lazy"
        />
      </div>
    </section>
  </div>
);

export default Services;