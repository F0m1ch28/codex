import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.col}>
        <h4 className={styles.title}>TechSolutions Inc.</h4>
        <p className={styles.text}>
          Driving digital evolution through cloud architectures, secure platforms, and data-driven intelligence.
        </p>
      </div>
      <div className={styles.col}>
        <h4 className={styles.subtitle}>Contact</h4>
        <ul className={styles.list}>
          <li>123 Innovation Drive, Tech Park, San Francisco, CA 94105</li>
          <li>Phone: <a href="tel:+15551234567">+1 (555) 123-4567</a></li>
          <li>Email: <a href="mailto:info@techsolutions-inc.com">info@techsolutions-inc.com</a></li>
        </ul>
      </div>
      <div className={styles.col}>
        <h4 className={styles.subtitle}>Quick Links</h4>
        <ul className={styles.list}>
          <li><NavLink to="/privacy">Privacy Policy</NavLink></li>
          <li><NavLink to="/terms">Terms of Service</NavLink></li>
          <li><NavLink to="/cookie-policy">Cookie Policy</NavLink></li>
          <li><NavLink to="/contact">Contact Us</NavLink></li>
        </ul>
      </div>
    </div>
    <div className={styles.bottomBar}>
      <p>&copy; {new Date().getFullYear()} TechSolutions Inc. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;