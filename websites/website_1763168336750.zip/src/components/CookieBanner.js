import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem('cookieConsent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem('cookieConsent', choice);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.message}>
        We use cookies to enhance your browsing experience, analyze site traffic, and support marketing efforts.
        For more information, please review our <Link to="/cookie-policy">Cookie Policy</Link>.
      </p>
      <div className={styles.actions}>
        <button type="button" className={styles.reject} onClick={() => handleChoice('declined')}>
          Decline
        </button>
        <button type="button" className={styles.accept} onClick={() => handleChoice('accepted')}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;