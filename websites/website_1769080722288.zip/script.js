document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');
  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const open = navMenu.classList.toggle('open');
      navToggle.classList.toggle('is-active', open);
      navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('open');
        navToggle.classList.remove('is-active');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const currentYearEls = document.querySelectorAll('.current-year');
  const year = new Date().getFullYear();
  currentYearEls.forEach(el => {
    el.textContent = year;
  });

  const animateItems = document.querySelectorAll('[data-animate]');
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (prefersReducedMotion || !('IntersectionObserver' in window)) {
    animateItems.forEach(item => item.classList.add('is-visible'));
  } else {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.18 });
    animateItems.forEach(item => observer.observe(item));
  }

  const cookieBanner = document.getElementById('cookieBanner');
  const cookieAccept = document.getElementById('cookieAccept');
  const cookieDecline = document.getElementById('cookieDecline');
  const cookieChoice = localStorage.getItem('syer-cookie-choice');
  if (cookieBanner) {
    if (!cookieChoice) {
      cookieBanner.classList.add('is-visible');
    }
    const handleChoice = value => {
      localStorage.setItem('syer-cookie-choice', value);
      cookieBanner.classList.remove('is-visible');
    };
    if (cookieAccept) {
      cookieAccept.addEventListener('click', () => handleChoice('accepted'));
    }
    if (cookieDecline) {
      cookieDecline.addEventListener('click', () => handleChoice('declined'));
    }
  }

  const forms = document.querySelectorAll('.js-form');
  const toast = document.querySelector('.form-toast');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (toast) {
        toast.textContent = 'Mensaje enviado. Redirigiendo a la confirmación.';
        toast.classList.add('show');
        setTimeout(() => {
          toast.classList.remove('show');
        }, 1800);
      }
      setTimeout(() => {
        window.location.href = form.getAttribute('action');
      }, 1400);
    });
  });
});