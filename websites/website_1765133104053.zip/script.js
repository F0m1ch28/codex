document.addEventListener('DOMContentLoaded', () => {
    // Navigation toggle
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav-list');

    if (navToggle && navList) {
        navToggle.addEventListener('click', () => {
            const isOpen = navList.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });

        navList.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navList.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    // Cookie banner
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = cookieBanner?.querySelector('[data-cookie-accept]');
    const declineBtn = cookieBanner?.querySelector('[data-cookie-decline]');
    const storageKey = 'shepherdpro-cookie-consent';

    const showBanner = () => {
        if (!cookieBanner) return;
        cookieBanner.style.display = 'block';
    };

    const hideBanner = () => {
        if (!cookieBanner) return;
        cookieBanner.style.display = 'none';
    };

    const storedConsent = localStorage.getItem(storageKey);
    if (!storedConsent) {
        setTimeout(showBanner, 800);
    }

    acceptBtn?.addEventListener('click', () => {
        localStorage.setItem(storageKey, 'accepted');
        hideBanner();
    });

    declineBtn?.addEventListener('click', () => {
        localStorage.setItem(storageKey, 'declined');
        hideBanner();
    });

    // FAQ accordion
    const accordions = document.querySelectorAll('.accordion');
    accordions.forEach(acc => {
        const buttons = acc.querySelectorAll('.accordion-trigger');
        buttons.forEach(btn => {
            const panel = btn.nextElementSibling;
            btn.addEventListener('click', () => {
                const expanded = btn.getAttribute('aria-expanded') === 'true';
                btn.setAttribute('aria-expanded', String(!expanded));
                if (!expanded) {
                    panel.classList.add('open');
                    panel.style.maxHeight = panel.scrollHeight + 'px';
                } else {
                    panel.classList.remove('open');
                    panel.style.maxHeight = null;
                }
            });
        });
    });

    // Form validation messages (client-side)
    const form = document.querySelector('.contact-form');
    if (form) {
        form.addEventListener('submit', (e) => {
            if (!form.checkValidity()) {
                e.preventDefault();
                form.querySelectorAll(':invalid').forEach(field => {
                    const error = field.parentElement.querySelector('.error-msg');
                    if (error) {
                        error.style.display = 'block';
                    }
                });
            }
        });

        form.querySelectorAll('input, textarea, select').forEach(field => {
            field.addEventListener('input', () => {
                if (field.validity.valid) {
                    const error = field.parentElement.querySelector('.error-msg');
                    if (error) {
                        error.style.display = 'none';
                    }
                }
            });
        });
    }
});