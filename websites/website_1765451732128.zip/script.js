document.addEventListener("DOMContentLoaded", () => {
  // Mobile navigation toggle
  const navToggle = document.querySelector("[data-nav-toggle]");
  const nav = document.querySelector("[data-nav]");
  if (nav && navToggle) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      nav.classList.toggle("is-open");
    });
    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        nav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  // Cookie banner
  const cookieBanner = document.querySelector("[data-cookie-banner]");
  const acceptBtn = document.querySelector("[data-accept-cookies]");
  const declineBtn = document.querySelector("[data-decline-cookies]");
  const cookieKey = "lcCookieChoice";

  const showCookieBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.add("is-visible");
    }
  };

  const hideCookieBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.remove("is-visible");
    }
  };

  const storedCookieChoice = localStorage.getItem(cookieKey);
  if (!storedCookieChoice) {
    setTimeout(showCookieBanner, 800);
  }

  const saveCookieChoice = (value) => {
    localStorage.setItem(cookieKey, value);
    hideCookieBanner();
  };

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => saveCookieChoice("accepted"));
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => saveCookieChoice("declined"));
  }

  // Course filters
  const filterButtons = document.querySelectorAll("[data-filter]");
  const courseCards = document.querySelectorAll("[data-category]");
  if (filterButtons.length && courseCards.length) {
    filterButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const filterValue = button.dataset.filter;
        filterButtons.forEach((btn) => btn.classList.remove("is-active"));
        button.classList.add("is-active");

        courseCards.forEach((card) => {
          const categories = card.dataset.category.split(",");
          if (filterValue === "all" || categories.includes(filterValue)) {
            card.classList.remove("is-hidden");
          } else {
            card.classList.add("is-hidden");
          }
        });
      });
    });
  }

  // FAQ accordion
  const accordionButtons = document.querySelectorAll("[data-accordion-button]");
  if (accordionButtons.length) {
    accordionButtons.forEach((button) => {
      const content = button.nextElementSibling;
      button.addEventListener("click", () => {
        const isExpanded = button.getAttribute("aria-expanded") === "true";
        button.setAttribute("aria-expanded", String(!isExpanded));

        if (!isExpanded) {
          content.classList.add("is-open");
          content.style.maxHeight = content.scrollHeight + "px";
        } else {
          content.classList.remove("is-open");
          content.style.maxHeight = null;
        }
      });
    });
  }

  // Contact form validation
  const contactForm = document.querySelector("[data-contact-form]");
  if (contactForm) {
    const statusEl = contactForm.querySelector("[data-form-status]");
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const name = formData.get("full-name").trim();
      const email = formData.get("email").trim();
      const company = formData.get("company").trim();
      const message = formData.get("message").trim();

      const errors = [];

      if (!name) {
        errors.push("Please enter your name.");
      }
      if (!company) {
        errors.push("Please provide your company name.");
      }
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        errors.push("Enter a valid work email address.");
      }
      if (message.length < 20) {
        errors.push("Your message should be at least 20 characters long.");
      }

      if (errors.length) {
        statusEl.textContent = errors.join(" ");
        statusEl.classList.add("is-visible", "is-error");
        statusEl.classList.remove("is-success");
      } else {
        statusEl.textContent = "Thank you! Your request has been received. We will contact you within one business day.";
        statusEl.classList.add("is-visible");
        statusEl.classList.remove("is-error");
        contactForm.reset();
      }
    });
  }
});