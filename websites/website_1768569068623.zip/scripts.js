document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-menu a');
    const header = document.querySelector('.site-header');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            navMenu.classList.toggle('active');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('active')) {
                    navMenu.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });

        document.addEventListener('scroll', () => {
            if (window.scrollY > 30) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');
    const storageKey = 'federamzix-cookie-pref';

    if (cookieBanner && acceptBtn && declineBtn) {
        const preference = localStorage.getItem(storageKey);
        if (!preference) {
            requestAnimationFrame(() => cookieBanner.classList.add('show'));
        }

        const closeBanner = decision => {
            localStorage.setItem(storageKey, decision);
            cookieBanner.classList.remove('show');
        };

        acceptBtn.addEventListener('click', () => closeBanner('accepted'));
        declineBtn.addEventListener('click', () => closeBanner('declined'));
    }
});