document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      navToggle.classList.toggle('is-active');
      primaryNav.classList.toggle('is-open');
    });

    primaryNav.addEventListener('click', (event) => {
      if (event.target.closest('a') && window.innerWidth < 768) {
        navToggle.setAttribute('aria-expanded', 'false');
        navToggle.classList.remove('is-active');
        primaryNav.classList.remove('is-open');
      }
    });
  }

  const cookieBanner = document.getElementById('cookieBanner');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
    const rejectBtn = cookieBanner.querySelector('[data-cookie="reject"]');
    const cookieKey = 'telegramhaCookieConsent';

    const hideBanner = () => {
      cookieBanner.classList.remove('is-visible');
    };

    const storedConsent = localStorage.getItem(cookieKey);
    if (!storedConsent) {
      cookieBanner.classList.add('is-visible');
    }

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => {
        localStorage.setItem(cookieKey, 'accepted');
        hideBanner();
      });
    }

    if (rejectBtn) {
      rejectBtn.addEventListener('click', () => {
        localStorage.setItem(cookieKey, 'rejected');
        hideBanner();
      });
    }
  }

  document.querySelectorAll('[data-current-year]').forEach((element) => {
    element.textContent = new Date().getFullYear();
  });
});