document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptCookiesBtn = document.querySelector(".cookie-accept");
  const declineCookiesBtn = document.querySelector(".cookie-decline");
  const cookieSettingsBtn = document.querySelector(".cookie-settings");
  const statusMessage = document.querySelector(".status-message");
  const form = document.querySelector("form[data-form='contact']");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", !expanded);
      nav.classList.toggle("open");
      document.body.classList.toggle("no-scroll", !expanded);
    });

    nav.querySelectorAll(".nav-link").forEach((link) => {
      link.addEventListener("click", () => {
        nav.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
        document.body.classList.remove("no-scroll");
      });
    });
  }

  const cookieKey = "alveroNimbusCookieConsent";
  const savedConsent = localStorage.getItem(cookieKey);

  const showCookieBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.add("active");
    }
  };

  if (!savedConsent && cookieBanner) {
    setTimeout(showCookieBanner, 800);
  }

  const handleConsent = (value) => {
    localStorage.setItem(cookieKey, value);
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
  };

  if (acceptCookiesBtn) {
    acceptCookiesBtn.addEventListener("click", () => handleConsent("accepted"));
  }

  if (declineCookiesBtn) {
    declineCookiesBtn.addEventListener("click", () => handleConsent("declined"));
  }

  if (cookieSettingsBtn) {
    cookieSettingsBtn.addEventListener("click", (event) => {
      event.preventDefault();
      handleConsent("");
      setTimeout(showCookieBanner, 200);
    });
  }

  document.querySelectorAll("[data-toggle]").forEach((toggleButton) => {
    toggleButton.addEventListener("click", () => {
      const targetId = toggleButton.getAttribute("data-target");
      const target = document.getElementById(targetId);
      if (target) {
        target.classList.toggle("open");
        const expanded = toggleButton.getAttribute("aria-expanded") === "true";
        toggleButton.setAttribute("aria-expanded", (!expanded).toString());
      }
    });
  });

  document.querySelectorAll(".faq-question").forEach((btn) => {
    btn.addEventListener("click", () => {
      const parent = btn.closest(".faq-item");
      parent.classList.toggle("open");
      const expanded = btn.getAttribute("aria-expanded") === "true";
      btn.setAttribute("aria-expanded", (!expanded).toString());
    });
  });

  document.querySelectorAll(".exercise-trigger").forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.getAttribute("data-target");
      const target = document.getElementById(targetId);
      if (target) {
        target.classList.toggle("open");
        btn.classList.toggle("active");
        btn.querySelector("span").textContent = target.classList.contains("open")
          ? "Simulation beendet"
          : "Simulation starten";
      }
    });
  });

  if (form && statusMessage) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const allValid = form.checkValidity();

      statusMessage.style.display = "block";
      if (allValid) {
        statusMessage.textContent =
          "Vielen Dank! Wir melden uns innerhalb von 24 Stunden bei Ihnen.";
        statusMessage.classList.remove("error");
        statusMessage.classList.add("success");
        form.reset();
      } else {
        statusMessage.textContent =
          "Bitte füllen Sie alle erforderlichen Felder korrekt aus.";
        statusMessage.classList.remove("success");
        statusMessage.classList.add("error");
      }
    });
  }
});