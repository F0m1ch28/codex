document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-links');
    const scrollBtn = document.getElementById('scrollTopButton');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const currentYearEl = document.getElementById('currentYear');

    // Mobile navigation toggle
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            navMenu.classList.toggle('open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    // Highlight active nav link
    const currentPage = document.body.dataset.page;
    if (currentPage) {
        const activeLink = document.querySelector(`a[data-link="${currentPage}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }
    }

    // Scroll to top button
    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 400) {
                scrollBtn.classList.add('show');
            } else {
                scrollBtn.classList.remove('show');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // Cookie banner
    const COOKIE_KEY = 'ddwCookieConsent';
    const hasConsent = localStorage.getItem(COOKIE_KEY);

    if (!hasConsent && cookieBanner) {
        cookieBanner.classList.add('show');
    }

    if (acceptCookiesBtn && cookieBanner) {
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem(COOKIE_KEY, 'accepted');
            cookieBanner.classList.remove('show');
        });
    }

    // Update year in footer
    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    // Contact form submission (AJAX)
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        const formStatus = document.getElementById('formStatus');
        contactForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            if (!contactForm.reportValidity()) {
                return;
            }
            if (formStatus) {
                formStatus.textContent = 'Sending...';
            }
            try {
                const formData = new FormData(contactForm);
                const response = await fetch(contactForm.action, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                if (response.ok) {
                    if (formStatus) {
                        formStatus.textContent = 'Thank you for your message. Our team will respond within one business day.';
                        formStatus.style.color = '#1c64f2';
                    }
                    contactForm.reset();
                } else {
                    throw new Error('Network response was not ok');
                }
            } catch (error) {
                if (formStatus) {
                    formStatus.textContent = 'We were unable to send your message. Please email us directly at contact@dominiondataworks.ca.';
                    formStatus.style.color = '#b00020';
                }
            }
        });
    }
});