document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function () {
            navLinks.classList.toggle('active');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-btn');

    if (cookieBanner) {
        const consentStatus = localStorage.getItem('transphjqi_cookie_consent');

        if (!consentStatus) {
            setTimeout(() => {
                cookieBanner.classList.add('active');
            }, 600);
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', function (event) {
                event.preventDefault();
                const choice = this.dataset.choice;
                localStorage.setItem('transphjqi_cookie_consent', choice);
                cookieBanner.classList.remove('active');
                const targetUrl = this.getAttribute('href');
                if (targetUrl) {
                    window.location.href = targetUrl;
                }
            });
        });
    }

    const programButtons = document.querySelectorAll('.program-button');
    const programDetails = document.querySelector('.program-details');

    if (programButtons.length && programDetails) {
        programButtons.forEach(button => {
            button.addEventListener('click', function () {
                programButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                const description = this.dataset.description;
                const outcomes = this.dataset.outcomes.split('|').map(item => `<li><strong>${item.split(':')[0].trim()}:</strong> ${item.split(':')[1].trim()}</li>`).join('');
                programDetails.innerHTML = `
                    <h3>${this.dataset.title}</h3>
                    <p>${description}</p>
                    <ul class="list-check">${outcomes}</ul>
                    <a class="cta-button secondary" href="services.html">Request Program Details</a>
                `;
            });
        });

        const initialButton = document.querySelector('.program-button.active') || programButtons[0];
        if (initialButton) {
            initialButton.click();
        }
    }
});