// @ts-check
import React from "react";
import { Routes, Route, Outlet, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTopButton from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Contact from "./pages/Contact";
import ContactThanks from "./pages/ContactThanks";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import Blog from "./pages/Blog";
import BlogContextSwitching from "./pages/BlogContextSwitching";
import BlogCloudPatterns from "./pages/BlogCloudPatterns";
import BlogDevopsCulture from "./pages/BlogDevopsCulture";
import Workflows from "./pages/Workflows";
import Mindset from "./pages/Mindset";
import Queue from "./pages/Queue";
import Archives from "./pages/Archives";
import Notes from "./pages/Notes";
import NotFound from "./pages/NotFound";

const PageWrapper = () => {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <motion.main
        key={location.pathname}
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -16 }}
        transition={{ duration: 0.35, ease: "easeInOut" }}
        className="min-h-screen bg-slate-900"
      >
        <Outlet />
      </motion.main>
    </AnimatePresence>
  );
};

const App = () => {
  return (
    <div className="bg-slate-900 text-slate-100">
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <Header />
      <PageWrapper />
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;