// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const About = () => (
  <>
    <Helmet>
      <title>About DevLayer | Mission, Values, Editorial Practice</title>
      <meta
        name="description"
        content="Discover DevLayer’s mission, editorial values, methodology, and the team shaping narratives around developer workflows, software systems, and cloud infrastructure."
      />
    </Helmet>

    <section className="container mx-auto px-4 py-16 lg:py-24">
      <h1 className="font-satoshi text-4xl text-slate-100">About DevLayer</h1>
      <p className="mt-4 text-slate-300 max-w-3xl">
        DevLayer was founded in Toronto to elevate the discourse around platform engineering. We believe technical writing should support developer cognition while honoring the complexity of modern software systems.
      </p>

      <div className="mt-12 grid gap-10 lg:grid-cols-2">
        <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
          <h2 className="text-2xl font-semibold text-slate-100">Mission</h2>
          <p className="mt-3 text-slate-400">
            To provide engineering communities with thoughtful editorial insight that improves decision-making, strengthens workflows, and nurtures humane platform culture.
          </p>
        </div>
        <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
          <h2 className="text-2xl font-semibold text-slate-100">Editorial Values</h2>
          <ul className="mt-4 space-y-3 text-sm text-slate-400">
            <li>Clarity without simplification.</li>
            <li>Empathy rooted in developer experience.</li>
            <li>Evidence-based analysis guided by research.</li>
            <li>Respect for privacy and intellectual stewardship.</li>
          </ul>
        </div>
      </div>

      <div className="mt-12 rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
        <h2 className="text-2xl font-semibold text-slate-100">Editorial Methodology</h2>
        <p className="mt-4 text-slate-400">
          Our methodology blends qualitative interviews, data instrumentation, and historical research. We synthesize signals into layered documentation that aligns architecture, workflows, and team dynamics.
        </p>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          <div className="rounded-2xl border border-slate-800 p-6">
            <h3 className="text-lg font-semibold text-slate-100">Field Observation</h3>
            <p className="mt-2 text-sm text-slate-400">
              Shadowing sprints, rituals, and incident reviews to capture real-world dynamics.
            </p>
          </div>
          <div className="rounded-2xl border border-slate-800 p-6">
            <h3 className="text-lg font-semibold text-slate-100">Evidence Synthesis</h3>
            <p className="mt-2 text-sm text-slate-400">
              Mapping data sources, system diagrams, and interviews into coherent narratives.
            </p>
          </div>
          <div className="rounded-2xl border border-slate-800 p-6">
            <h3 className="text-lg font-semibold text-slate-100">Iterative Review</h3>
            <p className="mt-2 text-sm text-slate-400">
              Collaborative editing cycles with stakeholders to ensure accuracy and resonance.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-12 grid gap-10 lg:grid-cols-2">
        <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
          <h2 className="text-2xl font-semibold text-slate-100">Ethics</h2>
          <p className="mt-3 text-slate-400">
            We honor confidentiality agreements, secure sensitive data, and prioritize consent. Editorial outputs are purpose-driven artifacts that respect every contributor’s voice.
          </p>
        </div>
        <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
          <h2 className="text-2xl font-semibold text-slate-100">History</h2>
          <p className="mt-3 text-slate-400">
            DevLayer emerged from a collective of platform engineers and editors who saw a gap between technical accuracy and narrative impact. We have grown into a trusted partner for research-driven engineering teams across Canada and beyond.
          </p>
        </div>
      </div>

      <div className="mt-12 rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
        <h2 className="text-2xl font-semibold text-slate-100">Editorial Contributors</h2>
        <ul className="mt-4 grid gap-4 md:grid-cols-2 text-sm text-slate-400">
          <li>
            <span className="text-slate-200 font-medium">Elena Marquez</span> — Editor-in-Chief, specializing in platform storytelling and knowledge design.
          </li>
          <li>
            <span className="text-slate-200 font-medium">Thierry Ouellet</span> — Research Lead focused on data ethnography and engineering psychology.
          </li>
          <li>
            <span className="text-slate-200 font-medium">Sahana Iyer</span> — Workflow Analyst translating developer rituals into actionable insights.
          </li>
          <li>
            <span className="text-slate-200 font-medium">Devon Park</span> — Systems Historian curating archives, RFC retrospectives, and legacy documentation.
          </li>
        </ul>
      </div>
    </section>
  </>
);

export default About;